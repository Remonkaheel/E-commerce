/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.Binder;
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.PropertyException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.glassfish.jaxb.core.unmarshaller.InfosetScanner;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.DOMOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.output.XmlOutput;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.InterningXmlVisitor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.SAXConnector;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallerImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XmlVisitor;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinderImpl<XmlNode>
/*     */   extends Binder<XmlNode>
/*     */ {
/*     */   private final JAXBContextImpl context;
/*     */   private UnmarshallerImpl unmarshaller;
/*     */   private MarshallerImpl marshaller;
/*     */   private final InfosetScanner<XmlNode> scanner;
/*  61 */   private final AssociationMap<XmlNode> assoc = new AssociationMap<>();
/*     */   
/*     */   BinderImpl(JAXBContextImpl _context, InfosetScanner<XmlNode> scanner) {
/*  64 */     this.context = _context;
/*  65 */     this.scanner = scanner;
/*     */   }
/*     */   
/*     */   private UnmarshallerImpl getUnmarshaller() {
/*  69 */     if (this.unmarshaller == null)
/*  70 */       this.unmarshaller = new UnmarshallerImpl(this.context, this.assoc); 
/*  71 */     return this.unmarshaller;
/*     */   }
/*     */   
/*     */   private MarshallerImpl getMarshaller() {
/*  75 */     if (this.marshaller == null)
/*  76 */       this.marshaller = new MarshallerImpl(this.context, this.assoc); 
/*  77 */     return this.marshaller;
/*     */   }
/*     */ 
/*     */   
/*     */   public void marshal(Object jaxbObject, XmlNode xmlNode) throws JAXBException {
/*  82 */     if (xmlNode == null || jaxbObject == null)
/*  83 */       throw new IllegalArgumentException(); 
/*  84 */     getMarshaller().marshal(jaxbObject, (XmlOutput)createOutput(xmlNode));
/*     */   }
/*     */ 
/*     */   
/*     */   private DOMOutput createOutput(XmlNode xmlNode) {
/*  89 */     return new DOMOutput((Node)xmlNode, this.assoc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object updateJAXB(XmlNode xmlNode) throws JAXBException {
/*  95 */     return associativeUnmarshal(xmlNode, true, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(XmlNode xmlNode) throws JAXBException {
/* 100 */     return associativeUnmarshal(xmlNode, false, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XmlNode xmlNode, Class<T> expectedType) throws JAXBException {
/* 105 */     if (expectedType == null) throw new IllegalArgumentException(); 
/* 106 */     return (JAXBElement<T>)associativeUnmarshal(xmlNode, true, expectedType);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSchema(Schema schema) {
/* 111 */     getMarshaller().setSchema(schema);
/* 112 */     getUnmarshaller().setSchema(schema);
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/* 117 */     return getUnmarshaller().getSchema();
/*     */   }
/*     */   
/*     */   private Object associativeUnmarshal(XmlNode xmlNode, boolean inplace, Class<?> expectedType) throws JAXBException {
/* 121 */     if (xmlNode == null) {
/* 122 */       throw new IllegalArgumentException();
/*     */     }
/* 124 */     JaxBeanInfo<?> bi = null;
/* 125 */     if (expectedType != null) {
/* 126 */       bi = this.context.getBeanInfo(expectedType, true);
/*     */     }
/*     */     
/* 129 */     InterningXmlVisitor handler = new InterningXmlVisitor(getUnmarshaller().createUnmarshallerHandler(this.scanner, inplace, bi));
/* 130 */     this.scanner.setContentHandler((ContentHandler)new SAXConnector((XmlVisitor)handler, this.scanner.getLocator()));
/*     */     try {
/* 132 */       this.scanner.scan(xmlNode);
/* 133 */     } catch (SAXException e) {
/* 134 */       throw this.unmarshaller.createUnmarshalException(e);
/*     */     } 
/*     */     
/* 137 */     return handler.getContext().getResult();
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlNode getXMLNode(Object jaxbObject) {
/* 142 */     if (jaxbObject == null)
/* 143 */       throw new IllegalArgumentException(); 
/* 144 */     AssociationMap.Entry<XmlNode> e = this.assoc.byPeer(jaxbObject);
/* 145 */     if (e == null) return null; 
/* 146 */     return e.element();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getJAXBNode(XmlNode xmlNode) {
/* 151 */     if (xmlNode == null)
/* 152 */       throw new IllegalArgumentException(); 
/* 153 */     AssociationMap.Entry<XmlNode> e = this.assoc.byElement(xmlNode);
/* 154 */     if (e == null) return null; 
/* 155 */     if (e.outer() != null) return e.outer(); 
/* 156 */     return e.inner();
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlNode updateXML(Object jaxbObject) throws JAXBException {
/* 161 */     return updateXML(jaxbObject, getXMLNode(jaxbObject));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlNode updateXML(Object jaxbObject, XmlNode xmlNode) throws JAXBException {
/* 167 */     if (jaxbObject == null || xmlNode == null) throw new IllegalArgumentException();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     Element e = (Element)xmlNode;
/* 173 */     Node ns = e.getNextSibling();
/* 174 */     Node p = e.getParentNode();
/* 175 */     p.removeChild(e);
/*     */ 
/*     */ 
/*     */     
/* 179 */     JaxBeanInfo bi = this.context.getBeanInfo(jaxbObject, true);
/* 180 */     if (!bi.isElement()) {
/* 181 */       jaxbObject = new JAXBElement(new QName(e.getNamespaceURI(), e.getLocalName()), bi.jaxbType, jaxbObject);
/*     */     }
/*     */     
/* 184 */     getMarshaller().marshal(jaxbObject, p);
/* 185 */     Node newNode = p.getLastChild();
/* 186 */     p.removeChild(newNode);
/* 187 */     p.insertBefore(newNode, ns);
/*     */     
/* 189 */     return (XmlNode)newNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEventHandler(ValidationEventHandler handler) throws JAXBException {
/* 194 */     getUnmarshaller().setEventHandler(handler);
/* 195 */     getMarshaller().setEventHandler(handler);
/*     */   }
/*     */ 
/*     */   
/*     */   public ValidationEventHandler getEventHandler() {
/* 200 */     return getUnmarshaller().getEventHandler();
/*     */   }
/*     */   
/*     */   public void setMarshallerListener(Marshaller.Listener listener) {
/* 204 */     getMarshaller().setListener(listener);
/*     */   }
/*     */   
/*     */   public Marshaller.Listener getMarshallerListener() {
/* 208 */     return getMarshaller().getListener();
/*     */   }
/*     */   
/*     */   public void setUnmarshallerListener(Unmarshaller.Listener listener) {
/* 212 */     getUnmarshaller().setListener(listener);
/*     */   }
/*     */   
/*     */   public Unmarshaller.Listener getUnmarshallerListener() {
/* 216 */     return getUnmarshaller().getListener();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws PropertyException {
/* 221 */     if (name == null) {
/* 222 */       throw new IllegalArgumentException(Messages.NULL_PROPERTY_NAME.format(new Object[0]));
/*     */     }
/*     */     
/* 225 */     if (excludeProperty(name)) {
/* 226 */       throw new PropertyException(name);
/*     */     }
/*     */     
/* 229 */     Object prop = null;
/* 230 */     PropertyException pe = null;
/*     */     
/*     */     try {
/* 233 */       prop = getMarshaller().getProperty(name);
/* 234 */       return prop;
/* 235 */     } catch (PropertyException p) {
/* 236 */       pe = p;
/*     */ 
/*     */       
/*     */       try {
/* 240 */         prop = getUnmarshaller().getProperty(name);
/* 241 */         return prop;
/* 242 */       } catch (PropertyException propertyException) {
/* 243 */         pe = propertyException;
/*     */ 
/*     */         
/* 246 */         pe.setStackTrace(Thread.currentThread().getStackTrace());
/* 247 */         throw pe;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void setProperty(String name, Object value) throws PropertyException {
/* 252 */     if (name == null) {
/* 253 */       throw new IllegalArgumentException(Messages.NULL_PROPERTY_NAME.format(new Object[0]));
/*     */     }
/*     */     
/* 256 */     if (excludeProperty(name)) {
/* 257 */       throw new PropertyException(name, value);
/*     */     }
/*     */     
/* 260 */     PropertyException pe = null;
/*     */     
/*     */     try {
/* 263 */       getMarshaller().setProperty(name, value);
/*     */       return;
/* 265 */     } catch (PropertyException p) {
/* 266 */       pe = p;
/*     */ 
/*     */       
/*     */       try {
/* 270 */         getUnmarshaller().setProperty(name, value);
/*     */         return;
/* 272 */       } catch (PropertyException propertyException) {
/* 273 */         pe = propertyException;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 278 */         pe.setStackTrace(Thread.currentThread().getStackTrace());
/* 279 */         throw pe;
/*     */       } 
/*     */     } 
/*     */   } private boolean excludeProperty(String name) {
/* 283 */     return (name.equals("org.glassfish.jaxb.characterEscapeHandler") || name
/*     */       
/* 285 */       .equals("org.glassfish.jaxb.xmlDeclaration") || name
/* 286 */       .equals("org.glassfish.jaxb.xmlHeaders"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\BinderImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */