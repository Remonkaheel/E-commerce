/*    */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*    */ 
/*    */ import org.glassfish.jaxb.core.marshaller.SAX2DOMEx;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.AssociationMap;
/*    */ import org.w3c.dom.Node;
/*    */ import org.xml.sax.ContentHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DOMOutput
/*    */   extends SAXOutput
/*    */ {
/*    */   private final AssociationMap assoc;
/*    */   
/*    */   public DOMOutput(Node node, AssociationMap assoc) {
/* 30 */     super((ContentHandler)new SAX2DOMEx(node));
/* 31 */     this.assoc = assoc;
/* 32 */     assert assoc != null;
/*    */   }
/*    */   
/*    */   private SAX2DOMEx getBuilder() {
/* 36 */     return (SAX2DOMEx)this.out;
/*    */   }
/*    */ 
/*    */   
/*    */   public void endStartTag() throws SAXException {
/* 41 */     super.endStartTag();
/*    */     
/* 43 */     Object op = this.nsContext.getCurrent().getOuterPeer();
/* 44 */     if (op != null) {
/* 45 */       this.assoc.addOuter(getBuilder().getCurrentElement(), op);
/*    */     }
/* 47 */     Object ip = this.nsContext.getCurrent().getInnerPeer();
/* 48 */     if (ip != null)
/* 49 */       this.assoc.addInner(getBuilder().getCurrentElement(), ip); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\DOMOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */