package org.glassfish.jaxb.runtime.v2.schemagen.xmlschema;

import com.sun.xml.txw2.TypedXmlWriter;
import com.sun.xml.txw2.annotation.XmlAttribute;
import com.sun.xml.txw2.annotation.XmlElement;

@XmlElement("schema")
public interface Schema extends TypedXmlWriter, SchemaTop {
  @XmlElement
  Annotation annotation();
  
  @XmlElement("import")
  Import _import();
  
  @XmlAttribute
  Schema targetNamespace(String paramString);
  
  @XmlAttribute(ns = "http://www.w3.org/XML/1998/namespace")
  Schema lang(String paramString);
  
  @XmlAttribute
  Schema id(String paramString);
  
  @XmlAttribute
  Schema elementFormDefault(String paramString);
  
  @XmlAttribute
  Schema attributeFormDefault(String paramString);
  
  @XmlAttribute
  Schema blockDefault(String paramString);
  
  @XmlAttribute
  Schema blockDefault(String[] paramArrayOfString);
  
  @XmlAttribute
  Schema finalDefault(String paramString);
  
  @XmlAttribute
  Schema finalDefault(String[] paramArrayOfString);
  
  @XmlAttribute
  Schema version(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\schemagen\xmlschema\Schema.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */