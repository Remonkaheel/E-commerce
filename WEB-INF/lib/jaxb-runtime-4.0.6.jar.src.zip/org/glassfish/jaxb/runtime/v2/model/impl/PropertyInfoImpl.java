/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.activation.MimeType;
/*     */ import jakarta.xml.bind.annotation.XmlAttachmentRef;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElementWrapper;
/*     */ import jakarta.xml.bind.annotation.XmlID;
/*     */ import jakarta.xml.bind.annotation.XmlIDREF;
/*     */ import jakarta.xml.bind.annotation.XmlInlineBinaryData;
/*     */ import jakarta.xml.bind.annotation.XmlMimeType;
/*     */ import jakarta.xml.bind.annotation.XmlNsForm;
/*     */ import jakarta.xml.bind.annotation.XmlSchema;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapters;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.v2.TODO;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.SwaRefAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PropertyInfoImpl<T, C, F, M>
/*     */   implements PropertyInfo<T, C>, Locatable, Comparable<PropertyInfoImpl<T, C, F, M>>
/*     */ {
/*     */   protected final PropertySeed<T, C, F, M> seed;
/*     */   private final boolean isCollection;
/*     */   private final ID id;
/*     */   private final MimeType expectedMimeType;
/*     */   private final boolean inlineBinary;
/*     */   private final QName schemaType;
/*     */   protected final ClassInfoImpl<T, C, F, M> parent;
/*     */   private final Adapter<T, C> adapter;
/*     */   
/*     */   protected PropertyInfoImpl(ClassInfoImpl<T, C, F, M> parent, PropertySeed<T, C, F, M> spi) {
/*  57 */     this.seed = spi;
/*  58 */     this.parent = parent;
/*     */     
/*  60 */     if (parent == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       throw new AssertionError();
/*     */     }
/*  70 */     MimeType mt = Util.calcExpectedMediaType(this.seed, parent.builder);
/*  71 */     if (mt != null && !(kind()).canHaveXmlMimeType) {
/*  72 */       parent.builder.reportError(new IllegalAnnotationException(Messages.ILLEGAL_ANNOTATION
/*  73 */             .format(new Object[] { XmlMimeType.class.getName() }, ), this.seed
/*  74 */             .readAnnotation(XmlMimeType.class)));
/*     */       
/*  76 */       mt = null;
/*     */     } 
/*  78 */     this.expectedMimeType = mt;
/*  79 */     this.inlineBinary = this.seed.hasAnnotation(XmlInlineBinaryData.class);
/*     */     
/*  81 */     T t = this.seed.getRawType();
/*     */ 
/*     */     
/*  84 */     XmlJavaTypeAdapter xjta = getApplicableAdapter(t);
/*  85 */     if (xjta != null) {
/*  86 */       this.isCollection = false;
/*  87 */       this.adapter = new Adapter(xjta, reader(), nav());
/*     */     }
/*     */     else {
/*     */       
/*  91 */       this
/*  92 */         .isCollection = (nav().isSubClassOf(t, nav().ref(Collection.class)) || nav().isArrayButNotByteArray(t));
/*     */       
/*  94 */       xjta = getApplicableAdapter(getIndividualType());
/*  95 */       if (xjta == null) {
/*     */         
/*  97 */         XmlAttachmentRef xsa = (XmlAttachmentRef)this.seed.readAnnotation(XmlAttachmentRef.class);
/*  98 */         if (xsa != null) {
/*  99 */           parent.builder.hasSwaRef = true;
/* 100 */           this.adapter = new Adapter(nav().asDecl(SwaRefAdapter.class), nav());
/*     */         } else {
/* 102 */           this.adapter = null;
/*     */ 
/*     */ 
/*     */           
/* 106 */           xjta = (XmlJavaTypeAdapter)this.seed.readAnnotation(XmlJavaTypeAdapter.class);
/* 107 */           if (xjta != null) {
/* 108 */             T ad = (T)reader().getClassValue((Annotation)xjta, "value");
/* 109 */             parent.builder.reportError(new IllegalAnnotationException(Messages.UNMATCHABLE_ADAPTER
/* 110 */                   .format(new Object[] {
/* 111 */                       nav().getTypeName(ad), nav().getTypeName(t)
/*     */                     }, ), (Annotation)xjta));
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 117 */         this.adapter = new Adapter(xjta, reader(), nav());
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     this.id = calcId();
/* 122 */     this.schemaType = Util.calcSchemaType(reader(), this.seed, parent.clazz, 
/* 123 */         getIndividualType(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassInfoImpl<T, C, F, M> parent() {
/* 129 */     return this.parent;
/*     */   }
/*     */   
/*     */   protected final Navigator<T, C, F, M> nav() {
/* 133 */     return this.parent.nav();
/*     */   }
/*     */   protected final AnnotationReader<T, C, F, M> reader() {
/* 136 */     return this.parent.reader();
/*     */   }
/*     */   
/*     */   public T getRawType() {
/* 140 */     return this.seed.getRawType();
/*     */   }
/*     */   
/*     */   public T getIndividualType() {
/* 144 */     if (this.adapter != null)
/* 145 */       return (T)this.adapter.defaultType; 
/* 146 */     T raw = getRawType();
/* 147 */     if (!isCollection()) {
/* 148 */       return raw;
/*     */     }
/* 150 */     if (nav().isArrayButNotByteArray(raw)) {
/* 151 */       return (T)nav().getComponentType(raw);
/*     */     }
/* 153 */     T bt = (T)nav().getBaseClass(raw, nav().asDecl(Collection.class));
/* 154 */     if (nav().isParameterizedType(bt)) {
/* 155 */       return (T)nav().getTypeArgument(bt, 0);
/*     */     }
/* 157 */     return (T)nav().ref(Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 163 */     return this.seed.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isApplicable(XmlJavaTypeAdapter jta, T declaredType) {
/* 170 */     if (jta == null) return false;
/*     */     
/* 172 */     T type = (T)reader().getClassValue((Annotation)jta, "type");
/* 173 */     if (nav().isSameType(declaredType, type)) {
/* 174 */       return true;
/*     */     }
/* 176 */     T ad = (T)reader().getClassValue((Annotation)jta, "value");
/* 177 */     T ba = (T)nav().getBaseClass(ad, nav().asDecl(XmlAdapter.class));
/* 178 */     if (!nav().isParameterizedType(ba))
/* 179 */       return true; 
/* 180 */     T inMemType = (T)nav().getTypeArgument(ba, 1);
/*     */     
/* 182 */     return nav().isSubClassOf(declaredType, inMemType);
/*     */   }
/*     */   
/*     */   private XmlJavaTypeAdapter getApplicableAdapter(T type) {
/* 186 */     XmlJavaTypeAdapter jta = (XmlJavaTypeAdapter)this.seed.readAnnotation(XmlJavaTypeAdapter.class);
/* 187 */     if (jta != null && isApplicable(jta, type)) {
/* 188 */       return jta;
/*     */     }
/*     */     
/* 191 */     XmlJavaTypeAdapters jtas = (XmlJavaTypeAdapters)reader().getPackageAnnotation(XmlJavaTypeAdapters.class, this.parent.clazz, this.seed);
/* 192 */     if (jtas != null)
/* 193 */       for (XmlJavaTypeAdapter xjta : jtas.value()) {
/* 194 */         if (isApplicable(xjta, type)) {
/* 195 */           return xjta;
/*     */         }
/*     */       }  
/* 198 */     jta = (XmlJavaTypeAdapter)reader().getPackageAnnotation(XmlJavaTypeAdapter.class, this.parent.clazz, this.seed);
/* 199 */     if (isApplicable(jta, type)) {
/* 200 */       return jta;
/*     */     }
/*     */     
/* 203 */     C refType = (C)nav().asDecl(type);
/* 204 */     if (refType != null) {
/* 205 */       jta = (XmlJavaTypeAdapter)reader().getClassAnnotation(XmlJavaTypeAdapter.class, refType, this.seed);
/* 206 */       if (jta != null && isApplicable(jta, type)) {
/* 207 */         return jta;
/*     */       }
/*     */     } 
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Adapter<T, C> getAdapter() {
/* 219 */     return this.adapter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String displayName() {
/* 225 */     return nav().getClassName(this.parent.getClazz()) + "#" + nav().getClassName(this.parent.getClazz());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ID id() {
/* 230 */     return this.id;
/*     */   }
/*     */   
/*     */   private ID calcId() {
/* 234 */     if (this.seed.hasAnnotation(XmlID.class)) {
/*     */       
/* 236 */       if (!nav().isSameType(getIndividualType(), nav().ref(String.class))) {
/* 237 */         this.parent.builder.reportError(new IllegalAnnotationException(Messages.ID_MUST_BE_STRING
/* 238 */               .format(new Object[] { getName() }, ), this.seed));
/*     */       }
/* 240 */       return ID.ID;
/*     */     } 
/* 242 */     if (this.seed.hasAnnotation(XmlIDREF.class)) {
/* 243 */       return ID.IDREF;
/*     */     }
/* 245 */     return ID.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final MimeType getExpectedMimeType() {
/* 251 */     return this.expectedMimeType;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean inlineBinaryData() {
/* 256 */     return this.inlineBinary;
/*     */   }
/*     */ 
/*     */   
/*     */   public final QName getSchemaType() {
/* 261 */     return this.schemaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isCollection() {
/* 266 */     return this.isCollection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void link() {
/* 275 */     if (this.id == ID.IDREF)
/*     */     {
/* 277 */       for (TypeInfo<T, C> ti : (Iterable<TypeInfo<T, C>>)ref()) {
/* 278 */         if (!ti.canBeReferencedByIDREF()) {
/* 279 */           this.parent.builder.reportError(new IllegalAnnotationException(Messages.INVALID_IDREF
/* 280 */                 .format(new Object[] {
/* 281 */                     this.parent.builder.nav.getTypeName(ti.getType())
/*     */                   }, ), this));
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locatable getUpstream() {
/* 292 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 297 */     return this.seed.getLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final QName calcXmlName(XmlElement e) {
/* 312 */     if (e != null) {
/* 313 */       return calcXmlName(e.namespace(), e.name());
/*     */     }
/* 315 */     return calcXmlName("##default", "##default");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final QName calcXmlName(XmlElementWrapper e) {
/* 322 */     if (e != null) {
/* 323 */       return calcXmlName(e.namespace(), e.name());
/*     */     }
/* 325 */     return calcXmlName("##default", "##default");
/*     */   }
/*     */ 
/*     */   
/*     */   private QName calcXmlName(String uri, String local) {
/* 330 */     TODO.checkSpec();
/* 331 */     if (local.length() == 0 || local.equals("##default"))
/* 332 */       local = this.seed.getName(); 
/* 333 */     if (uri.equals("##default")) {
/* 334 */       XmlSchema xs = (XmlSchema)reader().getPackageAnnotation(XmlSchema.class, this.parent.getClazz(), this);
/*     */ 
/*     */       
/* 337 */       if (xs != null) {
/* 338 */         QName typeName; switch (xs.elementFormDefault()) {
/*     */           case QUALIFIED:
/* 340 */             typeName = this.parent.getTypeName();
/* 341 */             if (typeName != null) {
/* 342 */               uri = typeName.getNamespaceURI();
/*     */             } else {
/* 344 */               uri = xs.namespace();
/* 345 */             }  if (uri.length() == 0)
/* 346 */               uri = this.parent.builder.defaultNsUri; 
/*     */             break;
/*     */           case UNQUALIFIED:
/*     */           case UNSET:
/* 350 */             uri = ""; break;
/*     */         } 
/*     */       } else {
/* 353 */         uri = "";
/*     */       } 
/*     */     } 
/* 356 */     return new QName(uri.intern(), local.intern());
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(PropertyInfoImpl<T, C, F, M> that) {
/* 361 */     return getName().compareTo(that.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public final <A extends Annotation> A readAnnotation(Class<A> annotationType) {
/* 366 */     return (A)this.seed.readAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasAnnotation(Class<? extends Annotation> annotationType) {
/* 371 */     return this.seed.hasAnnotation(annotationType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\PropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */