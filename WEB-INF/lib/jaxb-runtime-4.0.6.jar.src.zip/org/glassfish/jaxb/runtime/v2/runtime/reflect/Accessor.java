/*     */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*     */ 
/*     */ import com.sun.istack.Nullable;
/*     */ import jakarta.activation.DataHandler;
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import java.awt.Image;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.datatype.Duration;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ import javax.xml.transform.Source;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Adapter;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Receiver;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Accessor<BeanT, ValueT>
/*     */   implements Receiver
/*     */ {
/*     */   public final Class<ValueT> valueType;
/*     */   
/*     */   public Class<ValueT> getValueType() {
/*  53 */     return this.valueType;
/*     */   }
/*     */   
/*     */   protected Accessor(Class<ValueT> valueType) {
/*  57 */     this.valueType = valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Accessor<BeanT, ValueT> optimize(@Nullable JAXBContextImpl context) {
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ValueT get(BeanT paramBeanT) throws AccessorException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void set(BeanT paramBeanT, ValueT paramValueT) throws AccessorException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUnadapted(BeanT bean) throws AccessorException {
/* 102 */     return get(bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAdapted() {
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnadapted(BeanT bean, Object value) throws AccessorException {
/* 122 */     set(bean, (ValueT)value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(UnmarshallingContext.State state, Object o) throws SAXException {
/*     */     try {
/* 129 */       set((BeanT)state.getTarget(), (ValueT)o);
/* 130 */     } catch (AccessorException e) {
/* 131 */       Loader.handleGenericException((Exception)e, true);
/* 132 */     } catch (IllegalAccessError iae) {
/*     */       
/* 134 */       Loader.handleGenericError(iae);
/*     */     } 
/*     */   }
/*     */   
/* 138 */   private static List<Class> nonAbstractableClasses = Arrays.asList(new Class[] { Object.class, Calendar.class, Duration.class, XMLGregorianCalendar.class, Image.class, DataHandler.class, Source.class, Date.class, File.class, URI.class, URL.class, Class.class, String.class, Source.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueTypeAbstractable() {
/* 156 */     return !nonAbstractableClasses.contains(getValueType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbstractable(Class clazz) {
/* 165 */     return !nonAbstractableClasses.contains(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> Accessor<BeanT, T> adapt(Class<T> targetType, Class<? extends XmlAdapter<T, ValueT>> adapter) {
/* 173 */     return new AdaptedAccessor<>(targetType, this, adapter);
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T> Accessor<BeanT, T> adapt(Adapter<Type, Class<?>> adapter) {
/* 178 */     return new AdaptedAccessor<>((Class<T>)Utils.REFLECTION_NAVIGATOR
/* 179 */         .erasure(adapter.defaultType), this, (Class<? extends XmlAdapter<T, ValueT>>)adapter.adapterType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean accessWarned = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FieldReflection<BeanT, ValueT>
/*     */     extends Accessor<BeanT, ValueT>
/*     */   {
/*     */     public final Field f;
/*     */ 
/*     */ 
/*     */     
/* 197 */     private static final Logger logger = Utils.getClassLogger();
/*     */     
/*     */     public FieldReflection(Field f) {
/* 200 */       this(f, false);
/*     */     }
/*     */ 
/*     */     
/*     */     public FieldReflection(Field f, boolean supressAccessorWarnings) {
/* 205 */       super((Class)f.getType());
/* 206 */       this.f = f;
/*     */       
/* 208 */       int mod = f.getModifiers();
/* 209 */       if (!Modifier.isPublic(mod) || Modifier.isFinal(mod) || !Modifier.isPublic(f.getDeclaringClass().getModifiers())) {
/*     */         
/*     */         try {
/*     */           
/* 213 */           f.setAccessible(true);
/* 214 */         } catch (SecurityException e) {
/* 215 */           if (!Accessor.accessWarned && !supressAccessorWarnings)
/*     */           {
/* 217 */             logger.log(Level.WARNING, Messages.UNABLE_TO_ACCESS_NON_PUBLIC_FIELD.format(new Object[] { f
/* 218 */                     .getDeclaringClass().getName(), f
/* 219 */                     .getName() }, ), e);
/*     */           }
/*     */           
/* 222 */           Accessor.accessWarned = true;
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueT get(BeanT bean) {
/*     */       try {
/* 231 */         return (ValueT)this.f.get(bean);
/* 232 */       } catch (IllegalAccessException e) {
/* 233 */         throw new IllegalAccessError(e.getMessage());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void set(BeanT bean, ValueT value) {
/*     */       try {
/* 241 */         if (value == null)
/* 242 */           value = (ValueT)Accessor.uninitializedValues.get(this.valueType); 
/* 243 */         this.f.set(bean, value);
/* 244 */       } catch (IllegalAccessException e) {
/* 245 */         throw new IllegalAccessError(e.getMessage());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Accessor<BeanT, ValueT> optimize(JAXBContextImpl context) {
/* 251 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class ReadOnlyFieldReflection<BeanT, ValueT>
/*     */     extends FieldReflection<BeanT, ValueT>
/*     */   {
/*     */     public ReadOnlyFieldReflection(Field f, boolean supressAccessorWarnings) {
/* 260 */       super(f, supressAccessorWarnings);
/*     */     }
/*     */     public ReadOnlyFieldReflection(Field f) {
/* 263 */       super(f);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void set(BeanT bean, ValueT value) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Accessor<BeanT, ValueT> optimize(JAXBContextImpl context) {
/* 273 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class GetterSetterReflection<BeanT, ValueT>
/*     */     extends Accessor<BeanT, ValueT>
/*     */   {
/*     */     public final Method getter;
/*     */     
/*     */     public final Method setter;
/*     */     
/* 285 */     private static final Logger logger = Utils.getClassLogger();
/*     */ 
/*     */     
/*     */     public GetterSetterReflection(Method getter, Method setter) {
/* 289 */       super(
/* 290 */           (getter != null) ? 
/* 291 */           (Class)getter.getReturnType() : 
/* 292 */           (Class)setter.getParameterTypes()[0]);
/* 293 */       this.getter = getter;
/* 294 */       this.setter = setter;
/*     */       
/* 296 */       if (getter != null)
/* 297 */         makeAccessible(getter); 
/* 298 */       if (setter != null)
/* 299 */         makeAccessible(setter); 
/*     */     }
/*     */     
/*     */     private void makeAccessible(Method m) {
/* 303 */       if (!Modifier.isPublic(m.getModifiers()) || !Modifier.isPublic(m.getDeclaringClass().getModifiers())) {
/*     */         try {
/* 305 */           m.setAccessible(true);
/* 306 */         } catch (SecurityException e) {
/* 307 */           if (!Accessor.accessWarned)
/*     */           {
/* 309 */             logger.log(Level.WARNING, Messages.UNABLE_TO_ACCESS_NON_PUBLIC_FIELD.format(new Object[] { m
/* 310 */                     .getDeclaringClass().getName(), m
/* 311 */                     .getName() }, ), e);
/*     */           }
/* 313 */           Accessor.accessWarned = true;
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueT get(BeanT bean) throws AccessorException {
/*     */       try {
/* 322 */         return (ValueT)this.getter.invoke(bean, new Object[0]);
/* 323 */       } catch (IllegalAccessException e) {
/* 324 */         throw new IllegalAccessError(e.getMessage());
/* 325 */       } catch (InvocationTargetException e) {
/* 326 */         throw handleInvocationTargetException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void set(BeanT bean, ValueT value) throws AccessorException {
/*     */       try {
/* 334 */         if (value == null)
/* 335 */           value = (ValueT)Accessor.uninitializedValues.get(this.valueType); 
/* 336 */         this.setter.invoke(bean, new Object[] { value });
/* 337 */       } catch (IllegalAccessException e) {
/* 338 */         throw new IllegalAccessError(e.getMessage());
/* 339 */       } catch (InvocationTargetException e) {
/* 340 */         throw handleInvocationTargetException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private AccessorException handleInvocationTargetException(InvocationTargetException e) {
/* 346 */       Throwable t = e.getTargetException();
/* 347 */       if (t instanceof RuntimeException)
/* 348 */         throw (RuntimeException)t; 
/* 349 */       if (t instanceof Error) {
/* 350 */         throw (Error)t;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 357 */       return new AccessorException(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public Accessor<BeanT, ValueT> optimize(JAXBContextImpl context) {
/* 362 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GetterOnlyReflection<BeanT, ValueT>
/*     */     extends GetterSetterReflection<BeanT, ValueT>
/*     */   {
/*     */     public GetterOnlyReflection(Method getter) {
/* 373 */       super(getter, null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(BeanT bean, ValueT value) throws AccessorException {
/* 378 */       throw new AccessorException(Messages.NO_SETTER.format(new Object[] { this.getter.toString() }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SetterOnlyReflection<BeanT, ValueT>
/*     */     extends GetterSetterReflection<BeanT, ValueT>
/*     */   {
/*     */     public SetterOnlyReflection(Method setter) {
/* 389 */       super(null, setter);
/*     */     }
/*     */ 
/*     */     
/*     */     public ValueT get(BeanT bean) throws AccessorException {
/* 394 */       throw new AccessorException(Messages.NO_GETTER.format(new Object[] { this.setter.toString() }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A, B> Accessor<A, B> getErrorInstance() {
/* 403 */     return ERROR;
/*     */   }
/*     */   
/* 406 */   private static final Accessor ERROR = new Accessor<Object, Object>(Object.class)
/*     */     {
/*     */       public Object get(Object o) {
/* 409 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void set(Object o, Object o1) {}
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 420 */   public static final Accessor<JAXBElement, Object> JAXB_ELEMENT_VALUE = new Accessor<JAXBElement, Object>(Object.class)
/*     */     {
/*     */       public Object get(JAXBElement jaxbElement) {
/* 423 */         return jaxbElement.getValue();
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(JAXBElement jaxbElement, Object o) {
/* 428 */         jaxbElement.setValue(o);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 435 */   private static final Map<Class<?>, Object> uninitializedValues = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 448 */     uninitializedValues.put(byte.class, Byte.valueOf((byte)0));
/* 449 */     uninitializedValues.put(boolean.class, Boolean.valueOf(false));
/* 450 */     uninitializedValues.put(char.class, Character.valueOf(false));
/* 451 */     uninitializedValues.put(float.class, Float.valueOf(0.0F));
/* 452 */     uninitializedValues.put(double.class, Double.valueOf(0.0D));
/* 453 */     uninitializedValues.put(int.class, Integer.valueOf(0));
/* 454 */     uninitializedValues.put(long.class, Long.valueOf(0L));
/* 455 */     uninitializedValues.put(short.class, Short.valueOf((short)0));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\Accessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */