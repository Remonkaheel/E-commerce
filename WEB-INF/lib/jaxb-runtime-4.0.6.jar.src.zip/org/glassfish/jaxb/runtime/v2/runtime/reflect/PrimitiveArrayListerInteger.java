/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerInteger<BeanT>
/*    */   extends Lister<BeanT, int[], Integer, PrimitiveArrayListerInteger.IntegerArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     primitiveArrayListers.put(int.class, new PrimitiveArrayListerInteger());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Integer> iterator(final int[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Integer>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Integer next() {
/* 47 */           return Integer.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public IntegerArrayPack startPacking(BeanT current, Accessor<BeanT, int[]> acc) {
/* 54 */     return new IntegerArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(IntegerArrayPack objects, Integer o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(IntegerArrayPack pack, BeanT bean, Accessor<BeanT, int[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, int[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new int[0]);
/*    */   }
/*    */   
/*    */   static final class IntegerArrayPack {
/* 73 */     int[] buf = new int[16];
/*    */     int size;
/*    */     
/*    */     void add(Integer b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         int[] nb = new int[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.intValue(); 
/*    */     }
/*    */     
/*    */     int[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       int[] r = new int[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerInteger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */