/*      */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*      */ 
/*      */ import com.sun.istack.FinalArrayList;
/*      */ import jakarta.xml.bind.annotation.XmlAccessOrder;
/*      */ import jakarta.xml.bind.annotation.XmlAccessType;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorOrder;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*      */ import jakarta.xml.bind.annotation.XmlAnyAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlAnyElement;
/*      */ import jakarta.xml.bind.annotation.XmlAttachmentRef;
/*      */ import jakarta.xml.bind.annotation.XmlAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import jakarta.xml.bind.annotation.XmlElementRef;
/*      */ import jakarta.xml.bind.annotation.XmlElementRefs;
/*      */ import jakarta.xml.bind.annotation.XmlElementWrapper;
/*      */ import jakarta.xml.bind.annotation.XmlElements;
/*      */ import jakarta.xml.bind.annotation.XmlID;
/*      */ import jakarta.xml.bind.annotation.XmlIDREF;
/*      */ import jakarta.xml.bind.annotation.XmlInlineBinaryData;
/*      */ import jakarta.xml.bind.annotation.XmlList;
/*      */ import jakarta.xml.bind.annotation.XmlMimeType;
/*      */ import jakarta.xml.bind.annotation.XmlMixed;
/*      */ import jakarta.xml.bind.annotation.XmlSchemaType;
/*      */ import jakarta.xml.bind.annotation.XmlTransient;
/*      */ import jakarta.xml.bind.annotation.XmlType;
/*      */ import jakarta.xml.bind.annotation.XmlValue;
/*      */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*      */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*      */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapters;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.glassfish.jaxb.core.annotation.OverrideAnnotationOf;
/*      */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*      */ import org.glassfish.jaxb.core.v2.model.core.AttributePropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.Element;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*      */ import org.glassfish.jaxb.core.v2.model.core.MapPropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*      */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ReferencePropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.model.core.ValuePropertyInfo;
/*      */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*      */ import org.glassfish.jaxb.core.v2.runtime.Location;
/*      */ import org.glassfish.jaxb.core.v2.util.EditDistance;
/*      */ import org.glassfish.jaxb.runtime.v2.model.annotation.MethodLocatable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassInfoImpl<T, C, F, M>
/*      */   extends TypeInfoImpl<T, C, F, M>
/*      */   implements ClassInfo<T, C>, Element<T, C>
/*      */ {
/*      */   protected final C clazz;
/*      */   private final QName elementName;
/*      */   private final QName typeName;
/*      */   private FinalArrayList<PropertyInfoImpl<T, C, F, M>> properties;
/*      */   private String[] propOrder;
/*      */   private ClassInfoImpl<T, C, F, M> baseClass;
/*      */   private boolean baseClassComputed = false;
/*      */   private boolean hasSubClasses = false;
/*      */   protected PropertySeed<T, C, F, M> attributeWildcard;
/*  136 */   private M factoryMethod = null;
/*      */   
/*      */   ClassInfoImpl(ModelBuilder<T, C, F, M> builder, Locatable upstream, C clazz) {
/*  139 */     super(builder, upstream);
/*  140 */     this.clazz = clazz;
/*  141 */     assert clazz != null;
/*      */ 
/*      */     
/*  144 */     this.elementName = parseElementName(clazz);
/*      */ 
/*      */     
/*  147 */     XmlType t = (XmlType)reader().getClassAnnotation(XmlType.class, clazz, this);
/*  148 */     this.typeName = parseTypeName(clazz, t);
/*      */     
/*  150 */     if (t != null) {
/*  151 */       String[] propOrder = t.propOrder();
/*  152 */       if (propOrder.length == 0) {
/*  153 */         this.propOrder = null;
/*      */       }
/*  155 */       else if (propOrder[0].length() == 0) {
/*  156 */         this.propOrder = DEFAULT_ORDER;
/*      */       } else {
/*  158 */         this.propOrder = propOrder;
/*      */       } 
/*      */     } else {
/*  161 */       this.propOrder = DEFAULT_ORDER;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  166 */     XmlAccessorOrder xao = (XmlAccessorOrder)reader().getPackageAnnotation(XmlAccessorOrder.class, clazz, this);
/*  167 */     if (xao != null && xao.value() == XmlAccessOrder.UNDEFINED) {
/*  168 */       this.propOrder = null;
/*      */     }
/*      */ 
/*      */     
/*  172 */     xao = (XmlAccessorOrder)reader().getClassAnnotation(XmlAccessorOrder.class, clazz, this);
/*  173 */     if (xao != null && xao.value() == XmlAccessOrder.UNDEFINED) {
/*  174 */       this.propOrder = null;
/*      */     }
/*      */     
/*  177 */     if (nav().isInterface(clazz)) {
/*  178 */       builder.reportError(new IllegalAnnotationException(Messages.CANT_HANDLE_INTERFACE
/*  179 */             .format(new Object[] { nav().getClassName(clazz) }, ), this));
/*      */     }
/*      */ 
/*      */     
/*  183 */     if (!hasFactoryConstructor(t) && 
/*  184 */       !nav().hasDefaultConstructor(clazz)) {
/*  185 */       if (nav().isInnerClass(clazz)) {
/*  186 */         builder.reportError(new IllegalAnnotationException(Messages.CANT_HANDLE_INNER_CLASS
/*  187 */               .format(new Object[] { nav().getClassName(clazz) }, ), this));
/*  188 */       } else if (this.elementName != null) {
/*  189 */         builder.reportError(new IllegalAnnotationException(Messages.NO_DEFAULT_CONSTRUCTOR
/*  190 */               .format(new Object[] { nav().getClassName(clazz) }, ), this));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassInfoImpl<T, C, F, M> getBaseClass() {
/*  199 */     if (!this.baseClassComputed) {
/*      */       
/*  201 */       C s = (C)nav().getSuperClass(this.clazz);
/*  202 */       if (s == null || s == nav().asDecl(Object.class)) {
/*  203 */         this.baseClass = null;
/*      */       } else {
/*  205 */         NonElement<T, C> b = this.builder.getClassInfo(s, true, this);
/*  206 */         if (b instanceof ClassInfoImpl) {
/*  207 */           this.baseClass = (ClassInfoImpl)b;
/*  208 */           this.baseClass.hasSubClasses = true;
/*      */         } else {
/*  210 */           this.baseClass = null;
/*      */         } 
/*      */       } 
/*  213 */       this.baseClassComputed = true;
/*      */     } 
/*  215 */     return this.baseClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Element<T, C> getSubstitutionHead() {
/*  225 */     ClassInfoImpl<T, C, F, M> c = getBaseClass();
/*  226 */     while (c != null && !c.isElement())
/*  227 */       c = c.getBaseClass(); 
/*  228 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   public final C getClazz() {
/*  233 */     return this.clazz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ClassInfoImpl<T, C, F, M> getScope() {
/*  246 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final T getType() {
/*  251 */     return (T)nav().use(this.clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canBeReferencedByIDREF() {
/*  260 */     for (PropertyInfo<T, C> p : getProperties()) {
/*  261 */       if (p.id() == ID.ID)
/*  262 */         return true; 
/*      */     } 
/*  264 */     ClassInfoImpl<T, C, F, M> base = getBaseClass();
/*  265 */     if (base != null) {
/*  266 */       return base.canBeReferencedByIDREF();
/*      */     }
/*  268 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getName() {
/*  273 */     return nav().getClassName(this.clazz);
/*      */   }
/*      */   
/*      */   public <A extends Annotation> A readAnnotation(Class<A> a) {
/*  277 */     return (A)reader().getClassAnnotation(a, this.clazz, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public Element<T, C> asElement() {
/*  282 */     if (isElement()) {
/*  283 */       return this;
/*      */     }
/*  285 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public List<? extends PropertyInfo<T, C>> getProperties() {
/*  290 */     if (this.properties != null) return (List)this.properties;
/*      */ 
/*      */     
/*  293 */     XmlAccessType at = getAccessType();
/*      */     
/*  295 */     this.properties = new FinalArrayList();
/*      */     
/*  297 */     findFieldProperties(this.clazz, at);
/*      */     
/*  299 */     findGetterSetterProperties(at);
/*      */     
/*  301 */     if (this.propOrder == DEFAULT_ORDER || this.propOrder == null) {
/*  302 */       XmlAccessOrder ao = getAccessorOrder();
/*  303 */       if (ao == XmlAccessOrder.ALPHABETICAL) {
/*  304 */         Collections.sort((List<PropertyInfoImpl<T, C, F, M>>)this.properties);
/*      */       }
/*      */     } else {
/*  307 */       PropertySorter sorter = new PropertySorter();
/*  308 */       for (PropertyInfoImpl<T, C, F, M> p : this.properties) {
/*  309 */         sorter.checkedGet(p);
/*      */       }
/*  311 */       Collections.sort((List<PropertyInfoImpl<T, C, F, M>>)this.properties, sorter);
/*  312 */       sorter.checkUnusedProperties();
/*      */     } 
/*      */ 
/*      */     
/*  316 */     PropertyInfoImpl<T, C, F, M> vp = null;
/*  317 */     PropertyInfoImpl<T, C, F, M> ep = null;
/*      */     
/*  319 */     for (PropertyInfoImpl<T, C, F, M> p : this.properties) {
/*  320 */       switch (p.kind()) {
/*      */         case TRANSIENT:
/*      */         case ANY_ATTRIBUTE:
/*      */         case ATTRIBUTE:
/*  324 */           ep = p;
/*      */           continue;
/*      */         case VALUE:
/*  327 */           if (vp != null)
/*      */           {
/*  329 */             this.builder.reportError(new IllegalAnnotationException(Messages.MULTIPLE_VALUE_PROPERTY
/*  330 */                   .format(new Object[0]), vp, p));
/*      */           }
/*      */           
/*  333 */           if (getBaseClass() != null) {
/*  334 */             this.builder.reportError(new IllegalAnnotationException(Messages.XMLVALUE_IN_DERIVED_TYPE
/*  335 */                   .format(new Object[0]), p));
/*      */           }
/*  337 */           vp = p;
/*      */           continue;
/*      */         
/*      */         case ELEMENT:
/*      */           continue;
/*      */       } 
/*      */       
/*      */       assert false;
/*      */     } 
/*  346 */     if (ep != null && vp != null)
/*      */     {
/*  348 */       this.builder.reportError(new IllegalAnnotationException(Messages.ELEMENT_AND_VALUE_PROPERTY
/*  349 */             .format(new Object[0]), vp, ep));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  355 */     return (List)this.properties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void findFieldProperties(C c, XmlAccessType at) {
/*  361 */     C sc = (C)nav().getSuperClass(c);
/*  362 */     if (shouldRecurseSuperClass(sc)) {
/*  363 */       findFieldProperties(sc, at);
/*      */     }
/*      */     
/*  366 */     for (F f : nav().getDeclaredFields(c)) {
/*  367 */       Annotation[] annotations = reader().getAllFieldAnnotations(f, this);
/*  368 */       boolean isDummy = reader().hasFieldAnnotation(OverrideAnnotationOf.class, f);
/*      */       
/*  370 */       if (nav().isTransient(f)) {
/*      */         
/*  372 */         if (hasJAXBAnnotation(annotations))
/*  373 */           this.builder.reportError(new IllegalAnnotationException(Messages.TRANSIENT_FIELD_NOT_BINDABLE
/*  374 */                 .format(new Object[] { nav().getFieldName(f)
/*  375 */                   }, ), getSomeJAXBAnnotation(annotations)));  continue;
/*      */       } 
/*  377 */       if (nav().isStaticField(f)) {
/*      */         
/*  379 */         if (hasJAXBAnnotation(annotations))
/*  380 */           addProperty(createFieldSeed(f), annotations, false);  continue;
/*      */       } 
/*  382 */       if (at == XmlAccessType.FIELD || (at == XmlAccessType.PUBLIC_MEMBER && 
/*  383 */         nav().isPublicField(f)) || 
/*  384 */         hasJAXBAnnotation(annotations)) {
/*  385 */         if (isDummy) {
/*  386 */           ClassInfo<T, C> top = getBaseClass();
/*  387 */           while (top != null && top.getProperty("content") == null) {
/*  388 */             top = top.getBaseClass();
/*      */           }
/*  390 */           DummyPropertyInfo prop = (DummyPropertyInfo)top.getProperty("content");
/*  391 */           PropertySeed<T, C, F, M> seed = createFieldSeed(f);
/*  392 */           prop.addType((PropertyInfo)createReferenceProperty(seed));
/*      */         } else {
/*  394 */           addProperty(createFieldSeed(f), annotations, false);
/*      */         } 
/*      */       }
/*  397 */       checkFieldXmlLocation(f);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasValueProperty() {
/*  404 */     ClassInfoImpl<T, C, F, M> bc = getBaseClass();
/*  405 */     if (bc != null && bc.hasValueProperty()) {
/*  406 */       return true;
/*      */     }
/*  408 */     for (PropertyInfo<T, C> p : getProperties()) {
/*  409 */       if (p instanceof ValuePropertyInfo) return true;
/*      */     
/*      */     } 
/*  412 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public PropertyInfo<T, C> getProperty(String name) {
/*  417 */     for (PropertyInfo<T, C> p : getProperties()) {
/*  418 */       if (p.getName().equals(name))
/*  419 */         return p; 
/*      */     } 
/*  421 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkFieldXmlLocation(F f) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T extends Annotation> T getClassOrPackageAnnotation(Class<T> type) {
/*  434 */     Annotation annotation = reader().getClassAnnotation(type, this.clazz, this);
/*  435 */     if (annotation != null) {
/*  436 */       return (T)annotation;
/*      */     }
/*  438 */     return (T)reader().getPackageAnnotation(type, this.clazz, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XmlAccessType getAccessType() {
/*  446 */     XmlAccessorType xat = getClassOrPackageAnnotation(XmlAccessorType.class);
/*  447 */     if (xat != null) {
/*  448 */       return xat.value();
/*      */     }
/*  450 */     return XmlAccessType.PUBLIC_MEMBER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XmlAccessOrder getAccessorOrder() {
/*  457 */     XmlAccessorOrder xao = getClassOrPackageAnnotation(XmlAccessorOrder.class);
/*  458 */     if (xao != null) {
/*  459 */       return xao.value();
/*      */     }
/*  461 */     return XmlAccessOrder.UNDEFINED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class PropertySorter
/*      */     extends HashMap<String, Integer>
/*      */     implements Comparator<PropertyInfoImpl>
/*      */   {
/*      */     private static final long serialVersionUID = 8074459976041391290L;
/*      */ 
/*      */ 
/*      */     
/*  475 */     PropertyInfoImpl[] used = new PropertyInfoImpl[ClassInfoImpl.this.propOrder.length];
/*      */ 
/*      */ 
/*      */     
/*      */     private Set<String> collidedNames;
/*      */ 
/*      */ 
/*      */     
/*      */     PropertySorter() {
/*  484 */       super(ClassInfoImpl.this.propOrder.length);
/*  485 */       for (String name : ClassInfoImpl.this.propOrder) {
/*  486 */         if (put(name, Integer.valueOf(size())) != null)
/*      */         {
/*  488 */           ClassInfoImpl.this.builder.reportError(new IllegalAnnotationException(Messages.DUPLICATE_ENTRY_IN_PROP_ORDER
/*  489 */                 .format(new Object[] { name }, ), ClassInfoImpl.this));
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     public int compare(PropertyInfoImpl o1, PropertyInfoImpl o2) {
/*  495 */       int lhs = checkedGet(o1);
/*  496 */       int rhs = checkedGet(o2);
/*      */       
/*  498 */       return lhs - rhs;
/*      */     }
/*      */     
/*      */     private int checkedGet(PropertyInfoImpl p) {
/*  502 */       Integer i = get(p.getName());
/*  503 */       if (i == null) {
/*      */         
/*  505 */         if ((p.kind()).isOrdered) {
/*  506 */           ClassInfoImpl.this.builder.reportError(new IllegalAnnotationException(Messages.PROPERTY_MISSING_FROM_ORDER
/*  507 */                 .format(new Object[] { p.getName() }, ), p));
/*      */         }
/*      */         
/*  510 */         i = Integer.valueOf(size());
/*  511 */         put(p.getName(), i);
/*      */       } 
/*      */ 
/*      */       
/*  515 */       int ii = i.intValue();
/*  516 */       if (ii < this.used.length) {
/*  517 */         if (this.used[ii] != null && this.used[ii] != p) {
/*  518 */           if (this.collidedNames == null) this.collidedNames = new HashSet<>();
/*      */           
/*  520 */           if (this.collidedNames.add(p.getName()))
/*      */           {
/*  522 */             ClassInfoImpl.this.builder.reportError(new IllegalAnnotationException(Messages.DUPLICATE_PROPERTIES
/*  523 */                   .format(new Object[] { p.getName() }, ), p, this.used[ii])); } 
/*      */         } 
/*  525 */         this.used[ii] = p;
/*      */       } 
/*      */       
/*  528 */       return i.intValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void checkUnusedProperties() {
/*  535 */       for (int i = 0; i < this.used.length; i++) {
/*  536 */         if (this.used[i] == null) {
/*  537 */           String unusedName = ClassInfoImpl.this.propOrder[i];
/*  538 */           String nearest = EditDistance.findNearest(unusedName, new AbstractList<String>()
/*      */               {
/*      */                 public String get(int index) {
/*  541 */                   return ((PropertyInfoImpl)ClassInfoImpl.this.properties.get(index)).getName();
/*      */                 }
/*      */ 
/*      */                 
/*      */                 public int size() {
/*  546 */                   return ClassInfoImpl.this.properties.size();
/*      */                 }
/*      */               });
/*  549 */           boolean isOverriding = (i <= ClassInfoImpl.this.properties.size() - 1 && ((PropertyInfoImpl)ClassInfoImpl.this.properties.get(i)).hasAnnotation((Class)OverrideAnnotationOf.class));
/*  550 */           if (!isOverriding) {
/*  551 */             ClassInfoImpl.this.builder.reportError(new IllegalAnnotationException(Messages.PROPERTY_ORDER_CONTAINS_UNUSED_ENTRY
/*  552 */                   .format(new Object[] { unusedName, nearest }, ), ClassInfoImpl.this));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean hasProperties() {
/*  560 */     return !this.properties.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   private static <T> T pickOne(T... args) {
/*  569 */     for (T arg : args) {
/*  570 */       if (arg != null)
/*  571 */         return arg; 
/*  572 */     }  return null;
/*      */   }
/*      */   class null extends AbstractList<String> {
/*      */     public String get(int index) { return ((PropertyInfoImpl)ClassInfoImpl.this.properties.get(index)).getName(); } public int size() { return ClassInfoImpl.this.properties.size(); } } @SafeVarargs
/*      */   private static <T> List<T> makeSet(T... args) {
/*  577 */     FinalArrayList<T> finalArrayList = new FinalArrayList();
/*  578 */     for (T arg : args) {
/*  579 */       if (arg != null) finalArrayList.add(arg); 
/*  580 */     }  return (List<T>)finalArrayList;
/*      */   }
/*      */   
/*      */   private static final class ConflictException extends Exception {
/*      */     private static final long serialVersionUID = -8261248191127673032L;
/*      */     final List<Annotation> annotations;
/*      */     
/*      */     public ConflictException(List<Annotation> one) {
/*  588 */       this.annotations = one;
/*      */     } }
/*      */   
/*      */   private static final class DuplicateException extends Exception { private static final long serialVersionUID = -2996855754364938240L;
/*      */     final Annotation a1;
/*      */     final Annotation a2;
/*      */     
/*      */     public DuplicateException(Annotation a1, Annotation a2) {
/*  596 */       this.a1 = a1;
/*  597 */       this.a2 = a2;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum SecondaryAnnotation
/*      */   {
/*  606 */     JAVA_TYPE(1, new Class[] { XmlJavaTypeAdapter.class }),
/*  607 */     ID_IDREF(2, new Class[] { XmlID.class, XmlIDREF.class }),
/*  608 */     BINARY(4, new Class[] { XmlInlineBinaryData.class, XmlMimeType.class, XmlAttachmentRef.class }),
/*  609 */     ELEMENT_WRAPPER(8, new Class[] { XmlElementWrapper.class }),
/*  610 */     LIST(16, new Class[] { XmlList.class }),
/*  611 */     SCHEMA_TYPE(32, new Class[] { XmlSchemaType.class });
/*      */ 
/*      */ 
/*      */     
/*      */     final int bitMask;
/*      */ 
/*      */ 
/*      */     
/*      */     final Class<? extends Annotation>[] members;
/*      */ 
/*      */ 
/*      */     
/*      */     SecondaryAnnotation(int bitMask, Class<? extends Annotation>[] members) {
/*  624 */       this.bitMask = bitMask;
/*  625 */       this.members = members;
/*      */     }
/*      */   }
/*      */   
/*  629 */   private static final SecondaryAnnotation[] SECONDARY_ANNOTATIONS = SecondaryAnnotation.values();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum PropertyGroup
/*      */   {
/*  638 */     TRANSIENT((String)new boolean[] { false, false, false, false, false, false }),
/*  639 */     ANY_ATTRIBUTE((String)new boolean[] { true, false, false, false, false, false }),
/*  640 */     ATTRIBUTE((String)new boolean[] { true, true, true, false, true, true }),
/*  641 */     VALUE((String)new boolean[] { true, true, true, false, true, true }),
/*  642 */     ELEMENT((String)new boolean[] { true, true, true, true, true, true }),
/*  643 */     ELEMENT_REF((String)new boolean[] { true, false, false, true, false, false }),
/*  644 */     MAP((String)new boolean[] { false, false, false, true, false, false });
/*      */ 
/*      */ 
/*      */     
/*      */     final int allowedsecondaryAnnotations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     PropertyGroup(boolean... bits) {
/*  654 */       int mask = 0;
/*  655 */       assert bits.length == ClassInfoImpl.SECONDARY_ANNOTATIONS.length;
/*  656 */       for (int i = 0; i < bits.length; i++) {
/*  657 */         if (bits[i])
/*  658 */           mask |= (ClassInfoImpl.SECONDARY_ANNOTATIONS[i]).bitMask; 
/*      */       } 
/*  660 */       this.allowedsecondaryAnnotations = mask ^ 0xFFFFFFFF;
/*      */     }
/*      */     
/*      */     boolean allows(ClassInfoImpl.SecondaryAnnotation a) {
/*  664 */       return ((this.allowedsecondaryAnnotations & a.bitMask) == 0);
/*      */     }
/*      */   }
/*      */   
/*  668 */   private static final Annotation[] EMPTY_ANNOTATIONS = new Annotation[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  673 */   private static final HashMap<Class, Integer> ANNOTATION_NUMBER_MAP = new HashMap<>();
/*      */   static {
/*  675 */     Class[] annotations = { XmlTransient.class, XmlAnyAttribute.class, XmlAttribute.class, XmlValue.class, XmlElement.class, XmlElements.class, XmlElementRef.class, XmlElementRefs.class, XmlAnyElement.class, XmlMixed.class, OverrideAnnotationOf.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  689 */     HashMap<Class<?>, Integer> m = ANNOTATION_NUMBER_MAP;
/*      */ 
/*      */     
/*  692 */     for (Class<?> c : annotations) {
/*  693 */       m.put(c, Integer.valueOf(m.size()));
/*      */     }
/*      */     
/*  696 */     int index = 20;
/*  697 */     for (SecondaryAnnotation sa : SECONDARY_ANNOTATIONS) {
/*  698 */       for (Class<? extends Annotation> member : sa.members)
/*  699 */         m.put(member, Integer.valueOf(index)); 
/*  700 */       index++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkConflict(Annotation a, Annotation b) throws DuplicateException {
/*  705 */     assert b != null;
/*  706 */     if (a != null) {
/*  707 */       throw new DuplicateException(a, b);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addProperty(PropertySeed<T, C, F, M> seed, Annotation[] annotations, boolean dummy) {
/*  731 */     XmlTransient t = null;
/*  732 */     XmlAnyAttribute aa = null;
/*  733 */     XmlAttribute a = null;
/*  734 */     XmlValue v = null;
/*  735 */     XmlElement e1 = null;
/*  736 */     XmlElements e2 = null;
/*  737 */     XmlElementRef r1 = null;
/*  738 */     XmlElementRefs r2 = null;
/*  739 */     XmlAnyElement xae = null;
/*  740 */     XmlMixed mx = null;
/*  741 */     OverrideAnnotationOf ov = null;
/*      */ 
/*      */     
/*  744 */     int secondaryAnnotations = 0;
/*      */     
/*      */     try {
/*  747 */       for (Annotation ann : annotations) {
/*  748 */         Integer index = ANNOTATION_NUMBER_MAP.get(ann.annotationType());
/*  749 */         if (index != null) {
/*  750 */           switch (index.intValue()) { case 0:
/*  751 */               checkConflict((Annotation)t, ann); t = (XmlTransient)ann; break;
/*  752 */             case 1: checkConflict((Annotation)aa, ann); aa = (XmlAnyAttribute)ann; break;
/*  753 */             case 2: checkConflict((Annotation)a, ann); a = (XmlAttribute)ann; break;
/*  754 */             case 3: checkConflict((Annotation)v, ann); v = (XmlValue)ann; break;
/*  755 */             case 4: checkConflict((Annotation)e1, ann); e1 = (XmlElement)ann; break;
/*  756 */             case 5: checkConflict((Annotation)e2, ann); e2 = (XmlElements)ann; break;
/*  757 */             case 6: checkConflict((Annotation)r1, ann); r1 = (XmlElementRef)ann; break;
/*  758 */             case 7: checkConflict((Annotation)r2, ann); r2 = (XmlElementRefs)ann; break;
/*  759 */             case 8: checkConflict((Annotation)xae, ann); xae = (XmlAnyElement)ann; break;
/*  760 */             case 9: checkConflict((Annotation)mx, ann); mx = (XmlMixed)ann; break;
/*  761 */             case 10: checkConflict((Annotation)ov, ann); ov = (OverrideAnnotationOf)ann;
/*      */               break;
/*      */             default:
/*  764 */               secondaryAnnotations |= 1 << index.intValue() - 20;
/*      */               break; }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */       } 
/*  771 */       PropertyGroup group = null;
/*  772 */       int groupCount = 0;
/*      */       
/*  774 */       if (t != null) {
/*  775 */         group = PropertyGroup.TRANSIENT;
/*  776 */         groupCount++;
/*      */       } 
/*  778 */       if (aa != null) {
/*  779 */         group = PropertyGroup.ANY_ATTRIBUTE;
/*  780 */         groupCount++;
/*      */       } 
/*  782 */       if (a != null) {
/*  783 */         group = PropertyGroup.ATTRIBUTE;
/*  784 */         groupCount++;
/*      */       } 
/*  786 */       if (v != null) {
/*  787 */         group = PropertyGroup.VALUE;
/*  788 */         groupCount++;
/*      */       } 
/*  790 */       if (e1 != null || e2 != null) {
/*  791 */         group = PropertyGroup.ELEMENT;
/*  792 */         groupCount++;
/*      */       } 
/*  794 */       if (r1 != null || r2 != null || xae != null || mx != null || ov != null) {
/*  795 */         group = PropertyGroup.ELEMENT_REF;
/*  796 */         groupCount++;
/*      */       } 
/*      */       
/*  799 */       if (groupCount > 1) {
/*      */         
/*  801 */         List<Annotation> err = makeSet(new Annotation[] { (Annotation)t, (Annotation)aa, (Annotation)a, (Annotation)v, pickOne(new Annotation[] { (Annotation)e1, (Annotation)e2 }), pickOne(new Annotation[] { (Annotation)r1, (Annotation)r2, (Annotation)xae }) });
/*  802 */         throw new ConflictException(err);
/*      */       } 
/*      */       
/*  805 */       if (group == null) {
/*      */ 
/*      */         
/*  808 */         assert groupCount == 0;
/*      */ 
/*      */         
/*  811 */         if (nav().isSubClassOf(seed.getRawType(), nav().ref(Map.class)) && 
/*  812 */           !hasApplicableAdapter(seed, seed.getRawType())) {
/*  813 */           group = PropertyGroup.MAP;
/*      */         } else {
/*  815 */           group = PropertyGroup.ELEMENT;
/*      */         } 
/*  817 */       } else if (group.equals(PropertyGroup.ELEMENT)) {
/*      */ 
/*      */         
/*  820 */         if (nav().isSubClassOf(seed.getRawType(), nav().ref(Map.class)) && 
/*  821 */           !hasApplicableAdapter(seed, seed.getRawType())) {
/*  822 */           group = PropertyGroup.MAP;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  828 */       if ((secondaryAnnotations & group.allowedsecondaryAnnotations) != 0) {
/*      */         
/*  830 */         for (SecondaryAnnotation sa : SECONDARY_ANNOTATIONS) {
/*  831 */           if (!group.allows(sa))
/*      */           {
/*  833 */             for (Class<? extends Annotation> m : sa.members) {
/*  834 */               Annotation offender = seed.readAnnotation(m);
/*  835 */               if (offender != null) {
/*      */                 
/*  837 */                 this.builder.reportError(new IllegalAnnotationException(Messages.ANNOTATION_NOT_ALLOWED
/*  838 */                       .format(new Object[] { m.getSimpleName() }, ), offender));
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */         
/*      */         assert false;
/*      */       } 
/*  848 */       switch (group) {
/*      */         case TRANSIENT:
/*      */           return;
/*      */         
/*      */         case ANY_ATTRIBUTE:
/*  853 */           if (this.attributeWildcard != null) {
/*  854 */             this.builder.reportError(new IllegalAnnotationException(Messages.TWO_ATTRIBUTE_WILDCARDS
/*  855 */                   .format(new Object[] {
/*  856 */                       nav().getClassName(getClazz()) }, ), (Annotation)aa, this.attributeWildcard));
/*      */             return;
/*      */           } 
/*  859 */           this.attributeWildcard = seed;
/*      */           
/*  861 */           if (inheritsAttributeWildcard()) {
/*  862 */             this.builder.reportError(new IllegalAnnotationException(Messages.SUPER_CLASS_HAS_WILDCARD
/*  863 */                   .format(new Object[0]), (Annotation)aa, 
/*  864 */                   getInheritedAttributeWildcard()));
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  869 */           if (!nav().isSubClassOf(seed.getRawType(), nav().ref(Map.class))) {
/*  870 */             this.builder.reportError(new IllegalAnnotationException(Messages.INVALID_ATTRIBUTE_WILDCARD_TYPE
/*  871 */                   .format(new Object[] { nav().getTypeName(seed.getRawType()) }, ), (Annotation)aa, 
/*  872 */                   getInheritedAttributeWildcard()));
/*      */             return;
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case ATTRIBUTE:
/*  879 */           this.properties.add(createAttributeProperty(seed));
/*      */           return;
/*      */         case VALUE:
/*  882 */           this.properties.add(createValueProperty(seed));
/*      */           return;
/*      */         case ELEMENT:
/*  885 */           this.properties.add(createElementProperty(seed));
/*      */           return;
/*      */         case ELEMENT_REF:
/*  888 */           this.properties.add(createReferenceProperty(seed));
/*      */           return;
/*      */         case MAP:
/*  891 */           this.properties.add(createMapProperty(seed));
/*      */           return;
/*      */       } 
/*      */       
/*      */       assert false;
/*  896 */     } catch (ConflictException x) {
/*      */       
/*  898 */       List<Annotation> err = x.annotations;
/*      */       
/*  900 */       this.builder.reportError(new IllegalAnnotationException(Messages.MUTUALLY_EXCLUSIVE_ANNOTATIONS
/*  901 */             .format(new Object[] {
/*  902 */                 nav().getClassName(getClazz()) + "#" + nav().getClassName(getClazz()), ((Annotation)err
/*  903 */                 .get(0)).annotationType().getName(), ((Annotation)err.get(1)).annotationType().getName()
/*  904 */               }, ), err.get(0), err.get(1)));
/*      */     
/*      */     }
/*  907 */     catch (DuplicateException e) {
/*      */       
/*  909 */       this.builder.reportError(new IllegalAnnotationException(Messages.DUPLICATE_ANNOTATIONS
/*  910 */             .format(new Object[] { e.a1.annotationType().getName() }, ), e.a1, e.a2));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ReferencePropertyInfo<T, C> createReferenceProperty(PropertySeed<T, C, F, M> seed) {
/*  918 */     return new ReferencePropertyInfoImpl<>(this, seed);
/*      */   }
/*      */   
/*      */   protected AttributePropertyInfo<T, C> createAttributeProperty(PropertySeed<T, C, F, M> seed) {
/*  922 */     return new AttributePropertyInfoImpl<>(this, seed);
/*      */   }
/*      */   
/*      */   protected ValuePropertyInfo<T, C> createValueProperty(PropertySeed<T, C, F, M> seed) {
/*  926 */     return new ValuePropertyInfoImpl<>(this, seed);
/*      */   }
/*      */   
/*      */   protected ElementPropertyInfo<T, C> createElementProperty(PropertySeed<T, C, F, M> seed) {
/*  930 */     return new ElementPropertyInfoImpl<>(this, seed);
/*      */   }
/*      */   
/*      */   protected MapPropertyInfo<T, C> createMapProperty(PropertySeed<T, C, F, M> seed) {
/*  934 */     return new MapPropertyInfoImpl<>(this, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findGetterSetterProperties(XmlAccessType at) {
/*  944 */     Map<String, M> getters = new LinkedHashMap<>();
/*  945 */     Map<String, M> setters = new LinkedHashMap<>();
/*      */     
/*  947 */     C c = this.clazz;
/*      */     do {
/*  949 */       collectGetterSetters(this.clazz, getters, setters);
/*      */ 
/*      */       
/*  952 */       c = (C)nav().getSuperClass(c);
/*  953 */     } while (shouldRecurseSuperClass(c));
/*      */ 
/*      */ 
/*      */     
/*  957 */     Set<String> complete = new TreeSet<>(getters.keySet());
/*  958 */     complete.retainAll(setters.keySet());
/*      */     
/*  960 */     resurrect(getters, complete);
/*  961 */     resurrect(setters, complete);
/*      */ 
/*      */     
/*  964 */     for (String name : complete) {
/*  965 */       M getter = getters.get(name);
/*  966 */       M setter = setters.get(name);
/*      */       
/*  968 */       Annotation[] ga = (getter != null) ? reader().getAllMethodAnnotations(getter, (Locatable)new MethodLocatable(this, getter, nav())) : EMPTY_ANNOTATIONS;
/*  969 */       Annotation[] sa = (setter != null) ? reader().getAllMethodAnnotations(setter, (Locatable)new MethodLocatable(this, setter, nav())) : EMPTY_ANNOTATIONS;
/*      */       
/*  971 */       boolean hasAnnotation = (hasJAXBAnnotation(ga) || hasJAXBAnnotation(sa));
/*  972 */       boolean isOverriding = false;
/*  973 */       if (!hasAnnotation)
/*      */       {
/*      */ 
/*      */         
/*  977 */         isOverriding = (getter != null && nav().isOverriding(getter, c) && setter != null && nav().isOverriding(setter, c));
/*      */       }
/*      */       
/*  980 */       if ((at == XmlAccessType.PROPERTY && !isOverriding) || (at == XmlAccessType.PUBLIC_MEMBER && 
/*  981 */         isConsideredPublic(getter) && isConsideredPublic(setter) && !isOverriding) || hasAnnotation) {
/*      */         Annotation[] r;
/*      */         
/*  984 */         if (getter != null && setter != null && 
/*  985 */           !nav().isSameType(nav().getReturnType(getter), nav().getMethodParameters(setter)[0])) {
/*      */           
/*  987 */           this.builder.reportError(new IllegalAnnotationException(Messages.GETTER_SETTER_INCOMPATIBLE_TYPE
/*  988 */                 .format(new Object[] {
/*  989 */                     nav().getTypeName(nav().getReturnType(getter)), 
/*  990 */                     nav().getTypeName(nav().getMethodParameters(setter)[0])
/*      */                   },
/*  992 */                 ), (Locatable)new MethodLocatable(this, getter, nav()), (Locatable)new MethodLocatable(this, setter, 
/*  993 */                   nav())));
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  999 */         if (ga.length == 0) {
/* 1000 */           r = sa;
/*      */         }
/* 1002 */         else if (sa.length == 0) {
/* 1003 */           r = ga;
/*      */         } else {
/* 1005 */           r = new Annotation[ga.length + sa.length];
/* 1006 */           System.arraycopy(ga, 0, r, 0, ga.length);
/* 1007 */           System.arraycopy(sa, 0, r, ga.length, sa.length);
/*      */         } 
/*      */         
/* 1010 */         addProperty(createAccessorSeed(getter, setter), r, false);
/*      */       } 
/*      */     } 
/*      */     
/* 1014 */     getters.keySet().removeAll(complete);
/* 1015 */     setters.keySet().removeAll(complete);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void collectGetterSetters(C c, Map<String, M> getters, Map<String, M> setters) {
/* 1032 */     C sc = (C)nav().getSuperClass(c);
/* 1033 */     if (shouldRecurseSuperClass(sc)) {
/* 1034 */       collectGetterSetters(sc, getters, setters);
/*      */     }
/* 1036 */     Collection<? extends M> methods = nav().getDeclaredMethods(c);
/* 1037 */     Map<String, List<M>> allSetters = new LinkedHashMap<>();
/* 1038 */     for (M method : methods) {
/* 1039 */       boolean used = false;
/*      */       
/* 1041 */       if (nav().isBridgeMethod(method)) {
/*      */         continue;
/*      */       }
/* 1044 */       String name = nav().getMethodName(method);
/* 1045 */       int arity = (nav().getMethodParameters(method)).length;
/*      */       
/* 1047 */       if (nav().isStaticMethod(method)) {
/* 1048 */         ensureNoAnnotation(method);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1053 */       String propName = getPropertyNameFromGetMethod(name);
/* 1054 */       if (propName != null && arity == 0) {
/* 1055 */         getters.put(propName, method);
/* 1056 */         used = true;
/*      */       } 
/*      */ 
/*      */       
/* 1060 */       propName = getPropertyNameFromSetMethod(name);
/* 1061 */       if (propName != null && arity == 1) {
/* 1062 */         List<M> propSetters = allSetters.computeIfAbsent(propName, k -> new ArrayList());
/* 1063 */         propSetters.add(method);
/* 1064 */         used = true;
/*      */       } 
/*      */       
/* 1067 */       if (!used) {
/* 1068 */         ensureNoAnnotation(method);
/*      */       }
/*      */     } 
/*      */     
/* 1072 */     for (Map.Entry<String, M> entry : getters.entrySet()) {
/* 1073 */       String propName = entry.getKey();
/* 1074 */       M getter = entry.getValue();
/* 1075 */       List<M> propSetters = allSetters.remove(propName);
/* 1076 */       if (null == propSetters) {
/*      */         continue;
/*      */       }
/*      */       
/* 1080 */       T getterType = (T)nav().getReturnType(getter);
/* 1081 */       for (M setter : propSetters) {
/* 1082 */         T setterType = (T)nav().getMethodParameters(setter)[0];
/* 1083 */         if (nav().isSameType(setterType, getterType)) {
/* 1084 */           setters.put(propName, setter);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1091 */     for (Map.Entry<String, List<M>> e : allSetters.entrySet()) {
/* 1092 */       setters.put(e.getKey(), ((List<M>)e.getValue()).get(0));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shouldRecurseSuperClass(C sc) {
/* 1100 */     return (sc != null && (this.builder
/* 1101 */       .isReplaced(sc) || reader().hasClassAnnotation(sc, XmlTransient.class)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isConsideredPublic(M m) {
/* 1108 */     return (m == null || nav().isPublicMethod(m));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resurrect(Map<String, M> methods, Set<String> complete) {
/* 1116 */     for (Map.Entry<String, M> e : methods.entrySet()) {
/* 1117 */       if (complete.contains(e.getKey()))
/*      */         continue; 
/* 1119 */       if (hasJAXBAnnotation(reader().getAllMethodAnnotations(e.getValue(), this))) {
/* 1120 */         complete.add(e.getKey());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ensureNoAnnotation(M method) {
/* 1129 */     Annotation[] annotations = reader().getAllMethodAnnotations(method, this);
/* 1130 */     for (Annotation a : annotations) {
/* 1131 */       if (isJAXBAnnotation(a)) {
/* 1132 */         this.builder.reportError(new IllegalAnnotationException(Messages.ANNOTATION_ON_WRONG_METHOD
/* 1133 */               .format(new Object[0]), a));
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isJAXBAnnotation(Annotation a) {
/* 1144 */     return ANNOTATION_NUMBER_MAP.containsKey(a.annotationType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean hasJAXBAnnotation(Annotation[] annotations) {
/* 1151 */     return (getSomeJAXBAnnotation(annotations) != null);
/*      */   }
/*      */   
/*      */   private static Annotation getSomeJAXBAnnotation(Annotation[] annotations) {
/* 1155 */     for (Annotation a : annotations) {
/* 1156 */       if (isJAXBAnnotation(a))
/* 1157 */         return a; 
/* 1158 */     }  return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getPropertyNameFromGetMethod(String name) {
/* 1169 */     if (name.startsWith("get") && name.length() > 3)
/* 1170 */       return name.substring(3); 
/* 1171 */     if (name.startsWith("is") && name.length() > 2)
/* 1172 */       return name.substring(2); 
/* 1173 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getPropertyNameFromSetMethod(String name) {
/* 1183 */     if (name.startsWith("set") && name.length() > 3)
/* 1184 */       return name.substring(3); 
/* 1185 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertySeed<T, C, F, M> createFieldSeed(F f) {
/* 1195 */     return new FieldPropertySeed<>(this, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertySeed<T, C, F, M> createAccessorSeed(M getter, M setter) {
/* 1202 */     return new GetterSetterPropertySeed<>(this, getter, setter);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isElement() {
/* 1207 */     return (this.elementName != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAbstract() {
/* 1212 */     return nav().isAbstract(this.clazz);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOrdered() {
/* 1217 */     return (this.propOrder != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isFinal() {
/* 1222 */     return nav().isFinal(this.clazz);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean hasSubClasses() {
/* 1227 */     return this.hasSubClasses;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean hasAttributeWildcard() {
/* 1232 */     return (declaresAttributeWildcard() || inheritsAttributeWildcard());
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean inheritsAttributeWildcard() {
/* 1237 */     return (getInheritedAttributeWildcard() != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean declaresAttributeWildcard() {
/* 1242 */     return (this.attributeWildcard != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PropertySeed<T, C, F, M> getInheritedAttributeWildcard() {
/* 1249 */     for (ClassInfoImpl<T, C, F, M> c = getBaseClass(); c != null; c = c.getBaseClass()) {
/* 1250 */       if (c.attributeWildcard != null)
/* 1251 */         return c.attributeWildcard; 
/* 1252 */     }  return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final QName getElementName() {
/* 1257 */     return this.elementName;
/*      */   }
/*      */ 
/*      */   
/*      */   public final QName getTypeName() {
/* 1262 */     return this.typeName;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isSimpleType() {
/* 1267 */     List<? extends PropertyInfo> props = (List)getProperties();
/* 1268 */     if (props.size() != 1) return false; 
/* 1269 */     return (((PropertyInfo)props.get(0)).kind() == PropertyKind.VALUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void link() {
/* 1277 */     getProperties();
/*      */ 
/*      */     
/* 1280 */     Map<String, PropertyInfoImpl> names = new HashMap<>();
/* 1281 */     for (PropertyInfoImpl<T, C, F, M> p : this.properties) {
/* 1282 */       p.link();
/* 1283 */       PropertyInfoImpl old = names.put(p.getName(), p);
/* 1284 */       if (old != null) {
/* 1285 */         this.builder.reportError(new IllegalAnnotationException(Messages.PROPERTY_COLLISION
/* 1286 */               .format(new Object[] { p.getName() }, ), p, old));
/*      */       }
/*      */     } 
/*      */     
/* 1290 */     super.link();
/*      */   }
/*      */ 
/*      */   
/*      */   public Location getLocation() {
/* 1295 */     return nav().getClassLocation(this.clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasFactoryConstructor(XmlType t) {
/* 1307 */     if (t == null) return false;
/*      */     
/* 1309 */     String method = t.factoryMethod();
/* 1310 */     T fClass = (T)reader().getClassValue((Annotation)t, "factoryClass");
/* 1311 */     if (method.length() > 0) {
/* 1312 */       if (nav().isSameType(fClass, nav().ref(XmlType.DEFAULT.class))) {
/* 1313 */         fClass = (T)nav().use(this.clazz);
/*      */       }
/* 1315 */       for (M m : nav().getDeclaredMethods(nav().asDecl(fClass))) {
/*      */         
/* 1317 */         if (nav().getMethodName(m).equals(method) && 
/* 1318 */           nav().isSameType(nav().getReturnType(m), nav().use(this.clazz)) && (
/* 1319 */           nav().getMethodParameters(m)).length == 0 && 
/* 1320 */           nav().isStaticMethod(m)) {
/* 1321 */           this.factoryMethod = m;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1325 */       if (this.factoryMethod == null) {
/* 1326 */         this.builder.reportError(new IllegalAnnotationException(Messages.NO_FACTORY_METHOD
/* 1327 */               .format(new Object[] { nav().getClassName(nav().asDecl(fClass)), method }, ), this));
/*      */       }
/* 1329 */     } else if (!nav().isSameType(fClass, nav().ref(XmlType.DEFAULT.class))) {
/* 1330 */       this.builder.reportError(new IllegalAnnotationException(Messages.FACTORY_CLASS_NEEDS_FACTORY_METHOD
/* 1331 */             .format(new Object[] { nav().getClassName(nav().asDecl(fClass)) }, ), this));
/*      */     } 
/* 1333 */     return (this.factoryMethod != null);
/*      */   }
/*      */   
/*      */   public Method getFactoryMethod() {
/* 1337 */     return (Method)this.factoryMethod;
/*      */   }
/*      */   
/*      */   private boolean hasApplicableAdapter(PropertySeed<T, C, F, M> seed, T type) {
/* 1341 */     XmlJavaTypeAdapter jta = (XmlJavaTypeAdapter)seed.readAnnotation(XmlJavaTypeAdapter.class);
/* 1342 */     if (jta != null && isApplicable(jta, type)) {
/* 1343 */       return true;
/*      */     }
/*      */     
/* 1346 */     XmlJavaTypeAdapters jtas = (XmlJavaTypeAdapters)reader().getPackageAnnotation(XmlJavaTypeAdapters.class, this.clazz, seed);
/* 1347 */     if (jtas != null) {
/* 1348 */       for (XmlJavaTypeAdapter xjta : jtas.value()) {
/* 1349 */         if (isApplicable(xjta, type)) {
/* 1350 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/* 1354 */     jta = (XmlJavaTypeAdapter)reader().getPackageAnnotation(XmlJavaTypeAdapter.class, this.clazz, seed);
/* 1355 */     if (isApplicable(jta, type)) {
/* 1356 */       return true;
/*      */     }
/*      */     
/* 1359 */     C refType = (C)nav().asDecl(type);
/* 1360 */     if (refType != null) {
/* 1361 */       jta = (XmlJavaTypeAdapter)reader().getClassAnnotation(XmlJavaTypeAdapter.class, refType, seed);
/* 1362 */       if (jta != null && isApplicable(jta, type)) {
/* 1363 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1367 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isApplicable(XmlJavaTypeAdapter jta, T declaredType) {
/* 1371 */     if (jta == null) return false;
/*      */     
/* 1373 */     T type = (T)reader().getClassValue((Annotation)jta, "type");
/* 1374 */     if (nav().isSameType(declaredType, type)) {
/* 1375 */       return true;
/*      */     }
/* 1377 */     T ad = (T)reader().getClassValue((Annotation)jta, "value");
/* 1378 */     T ba = (T)nav().getBaseClass(ad, nav().asDecl(XmlAdapter.class));
/* 1379 */     if (!nav().isParameterizedType(ba)) {
/* 1380 */       return true;
/*      */     }
/* 1382 */     T inMemType = (T)nav().getTypeArgument(ba, 1);
/*      */     
/* 1384 */     return nav().isSubClassOf(declaredType, inMemType);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1389 */     return "ClassInfo(" + this.clazz + ")";
/*      */   }
/*      */   
/* 1392 */   private static final String[] DEFAULT_ORDER = new String[0];
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\ClassInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */