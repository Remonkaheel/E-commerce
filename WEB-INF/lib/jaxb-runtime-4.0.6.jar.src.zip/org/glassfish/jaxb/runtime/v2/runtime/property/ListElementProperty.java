/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeRef;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.ListTransducedAccessorImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.DefaultValueLoaderDecorator;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.LeafPropertyLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ListElementProperty<BeanT, ListT, ItemT>
/*     */   extends ArrayProperty<BeanT, ListT, ItemT>
/*     */ {
/*     */   private final Name tagName;
/*     */   private final String defaultValue;
/*     */   private final TransducedAccessor<BeanT> xacc;
/*     */   
/*     */   public ListElementProperty(JAXBContextImpl grammar, RuntimeElementPropertyInfo prop) {
/*  52 */     super(grammar, (RuntimePropertyInfo)prop);
/*     */     
/*  54 */     assert prop.isValueList();
/*  55 */     assert prop.getTypes().size() == 1;
/*  56 */     RuntimeTypeRef ref = prop.getTypes().get(0);
/*     */     
/*  58 */     this.tagName = grammar.nameBuilder.createElementName(ref.getTagName());
/*  59 */     this.defaultValue = ref.getDefaultValue();
/*     */ 
/*     */     
/*  62 */     Transducer xducer = ref.getTransducer();
/*     */     
/*  64 */     this.xacc = (TransducedAccessor<BeanT>)new ListTransducedAccessorImpl(xducer, this.acc, this.lister);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyKind getKind() {
/*  69 */     return PropertyKind.ELEMENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> handlers) {
/*  74 */     LeafPropertyLoader leafPropertyLoader = new LeafPropertyLoader(this.xacc);
/*  75 */     DefaultValueLoaderDecorator defaultValueLoaderDecorator = new DefaultValueLoaderDecorator((Loader)leafPropertyLoader, this.defaultValue);
/*  76 */     handlers.put(this.tagName, new ChildLoader((Loader)defaultValueLoaderDecorator, null));
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT o, XMLSerializer w, Object outerPeer) throws SAXException, AccessorException, IOException, XMLStreamException {
/*  81 */     ListT list = (ListT)this.acc.get(o);
/*     */     
/*  83 */     if (list != null) {
/*  84 */       if (this.xacc.useNamespace()) {
/*  85 */         w.startElement(this.tagName, null);
/*  86 */         this.xacc.declareNamespace(o, w);
/*  87 */         w.endNamespaceDecls(list);
/*  88 */         w.endAttributes();
/*  89 */         this.xacc.writeText(w, o, this.fieldName);
/*  90 */         w.endElement();
/*     */       } else {
/*  92 */         this.xacc.writeLeafElement(w, this.tagName, o, this.fieldName);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/*  99 */     if (this.tagName != null && 
/* 100 */       this.tagName.equals(nsUri, localName)) {
/* 101 */       return this.acc;
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\ListElementProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */