/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ import org.glassfish.jaxb.core.v2.model.core.ErrorHandler;
/*    */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractInlineAnnotationReaderImpl<T, C, F, M>
/*    */   implements AnnotationReader<T, C, F, M>
/*    */ {
/*    */   private ErrorHandler errorHandler;
/*    */   
/*    */   public void setErrorHandler(ErrorHandler errorHandler) {
/* 40 */     if (errorHandler == null)
/* 41 */       throw new IllegalArgumentException(); 
/* 42 */     this.errorHandler = errorHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final ErrorHandler getErrorHandler() {
/* 49 */     assert this.errorHandler != null : "error handler must be set before use";
/* 50 */     return this.errorHandler;
/*    */   }
/*    */ 
/*    */   
/*    */   public final <A extends Annotation> A getMethodAnnotation(Class<A> annotation, M getter, M setter, Locatable srcPos) {
/* 55 */     Annotation annotation1 = (getter == null) ? null : getMethodAnnotation(annotation, getter, srcPos);
/* 56 */     Annotation annotation2 = (setter == null) ? null : getMethodAnnotation(annotation, setter, srcPos);
/*    */     
/* 58 */     if (annotation1 == null) {
/* 59 */       return (A)annotation2;
/*    */     }
/* 61 */     if (annotation2 == null) {
/* 62 */       return (A)annotation1;
/*    */     }
/*    */     
/* 65 */     getErrorHandler().error(new IllegalAnnotationException(Messages.DUPLICATE_ANNOTATIONS
/* 66 */           .format(new Object[] {
/* 67 */               annotation.getName(), fullName(getter), fullName(setter)
/*    */             }, ), annotation1, annotation2));
/*    */     
/* 70 */     return (A)annotation1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasMethodAnnotation(Class<? extends Annotation> annotation, String propertyName, M getter, M setter, Locatable srcPos) {
/* 77 */     boolean x = (getter != null && hasMethodAnnotation(annotation, getter));
/* 78 */     boolean y = (setter != null && hasMethodAnnotation(annotation, setter));
/*    */     
/* 80 */     if (x && y)
/*    */     {
/* 82 */       getMethodAnnotation(annotation, getter, setter, srcPos);
/*    */     }
/*    */     
/* 85 */     return (x || y);
/*    */   }
/*    */   
/*    */   protected abstract String fullName(M paramM);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\AbstractInlineAnnotationReaderImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */