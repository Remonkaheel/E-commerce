/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringWriter;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*     */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UTF8XmlOutput
/*     */   extends XmlOutputAbstractImpl
/*     */ {
/*     */   protected final OutputStream out;
/*  35 */   private Encoded[] prefixes = new Encoded[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int prefixCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Encoded[] localNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private final Encoded textBuffer = new Encoded();
/*     */ 
/*     */ 
/*     */   
/*  58 */   protected final byte[] octetBuffer = new byte[1024];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int octetBufferIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean closeStartTagPending = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private String header;
/*     */ 
/*     */ 
/*     */   
/*  75 */   private CharacterEscapeHandler escapeHandler = null;
/*     */   
/*     */   private final byte[] XMLNS_EQUALS;
/*     */   
/*     */   private final byte[] XMLNS_COLON;
/*     */   
/*     */   private final byte[] EQUALS;
/*     */   
/*     */   private final byte[] CLOSE_TAG;
/*     */   
/*     */   private final byte[] EMPTY_TAG;
/*     */   
/*     */   private final byte[] XML_DECL;
/*     */ 
/*     */   
/*     */   public void setHeader(String header) {
/*  91 */     this.header = header;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws IOException, SAXException, XMLStreamException {
/*  96 */     super.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/*     */     
/*  98 */     this.octetBufferIndex = 0;
/*  99 */     if (!fragment) {
/* 100 */       write(this.XML_DECL);
/*     */     }
/* 102 */     if (this.header != null) {
/* 103 */       this.textBuffer.set(this.header);
/* 104 */       this.textBuffer.write(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/* 110 */     flushBuffer();
/* 111 */     super.endDocument(fragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void closeStartTag() throws IOException {
/* 118 */     if (this.closeStartTagPending) {
/* 119 */       write(62);
/* 120 */       this.closeStartTagPending = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(int prefix, String localName) throws IOException {
/* 126 */     closeStartTag();
/* 127 */     int base = pushNsDecls();
/* 128 */     write(60);
/* 129 */     writeName(prefix, localName);
/* 130 */     writeNsDecls(base);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(Name name) throws IOException {
/* 135 */     closeStartTag();
/* 136 */     int base = pushNsDecls();
/* 137 */     write(60);
/* 138 */     writeName(name);
/* 139 */     writeNsDecls(base);
/*     */   }
/*     */   
/*     */   private int pushNsDecls() {
/* 143 */     int total = this.nsContext.count();
/* 144 */     NamespaceContextImpl.Element ns = this.nsContext.getCurrent();
/*     */     
/* 146 */     if (total > this.prefixes.length) {
/*     */       
/* 148 */       int m = Math.max(total, this.prefixes.length * 2);
/* 149 */       Encoded[] buf = new Encoded[m];
/* 150 */       System.arraycopy(this.prefixes, 0, buf, 0, this.prefixes.length);
/* 151 */       for (int j = this.prefixes.length; j < buf.length; j++)
/* 152 */         buf[j] = new Encoded(); 
/* 153 */       this.prefixes = buf;
/*     */     } 
/*     */     
/* 156 */     int base = Math.min(this.prefixCount, ns.getBase());
/* 157 */     int size = this.nsContext.count();
/* 158 */     for (int i = base; i < size; i++) {
/* 159 */       String p = this.nsContext.getPrefix(i);
/*     */       
/* 161 */       Encoded e = this.prefixes[i];
/*     */       
/* 163 */       if (p.length() == 0) {
/* 164 */         e.buf = EMPTY_BYTE_ARRAY;
/* 165 */         e.len = 0;
/*     */       } else {
/* 167 */         e.set(p);
/* 168 */         e.append(':');
/*     */       } 
/*     */     } 
/* 171 */     this.prefixCount = size;
/* 172 */     return base;
/*     */   }
/*     */   
/*     */   protected void writeNsDecls(int base) throws IOException {
/* 176 */     NamespaceContextImpl.Element ns = this.nsContext.getCurrent();
/* 177 */     int size = this.nsContext.count();
/*     */     
/* 179 */     for (int i = ns.getBase(); i < size; i++) {
/* 180 */       writeNsDecl(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void writeNsDecl(int prefixIndex) throws IOException {
/* 187 */     String p = this.nsContext.getPrefix(prefixIndex);
/*     */     
/* 189 */     if (p.length() == 0) {
/* 190 */       if (this.nsContext.getCurrent().isRootElement() && this.nsContext
/* 191 */         .getNamespaceURI(prefixIndex).length() == 0)
/*     */         return; 
/* 193 */       write(this.XMLNS_EQUALS);
/*     */     } else {
/* 195 */       Encoded e = this.prefixes[prefixIndex];
/* 196 */       write(this.XMLNS_COLON);
/* 197 */       write(e.buf, 0, e.len - 1);
/* 198 */       write(this.EQUALS);
/*     */     } 
/* 200 */     doText(this.nsContext.getNamespaceURI(prefixIndex), true);
/* 201 */     write(34);
/*     */   }
/*     */   
/*     */   private void writePrefix(int prefix) throws IOException {
/* 205 */     this.prefixes[prefix].write(this);
/*     */   }
/*     */   
/*     */   private void writeName(Name name) throws IOException {
/* 209 */     writePrefix(this.nsUriIndex2prefixIndex[name.nsUriIndex]);
/* 210 */     this.localNames[name.localNameIndex].write(this);
/*     */   }
/*     */   
/*     */   private void writeName(int prefix, String localName) throws IOException {
/* 214 */     writePrefix(prefix);
/* 215 */     this.textBuffer.set(localName);
/* 216 */     this.textBuffer.write(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void attribute(Name name, String value) throws IOException {
/* 221 */     write(32);
/* 222 */     if (name.nsUriIndex == -1) {
/* 223 */       this.localNames[name.localNameIndex].write(this);
/*     */     } else {
/* 225 */       writeName(name);
/* 226 */     }  write(this.EQUALS);
/* 227 */     doText(value, true);
/* 228 */     write(34);
/*     */   }
/*     */ 
/*     */   
/*     */   public void attribute(int prefix, String localName, String value) throws IOException {
/* 233 */     write(32);
/* 234 */     if (prefix == -1) {
/* 235 */       this.textBuffer.set(localName);
/* 236 */       this.textBuffer.write(this);
/*     */     } else {
/* 238 */       writeName(prefix, localName);
/* 239 */     }  write(this.EQUALS);
/* 240 */     doText(value, true);
/* 241 */     write(34);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endStartTag() throws IOException {
/* 246 */     this.closeStartTagPending = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(Name name) throws IOException {
/* 251 */     if (this.closeStartTagPending) {
/* 252 */       write(this.EMPTY_TAG);
/* 253 */       this.closeStartTagPending = false;
/*     */     } else {
/* 255 */       write(this.CLOSE_TAG);
/* 256 */       writeName(name);
/* 257 */       write(62);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTag(int prefix, String localName) throws IOException {
/* 263 */     if (this.closeStartTagPending) {
/* 264 */       write(this.EMPTY_TAG);
/* 265 */       this.closeStartTagPending = false;
/*     */     } else {
/* 267 */       write(this.CLOSE_TAG);
/* 268 */       writeName(prefix, localName);
/* 269 */       write(62);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(String value, boolean needSP) throws IOException {
/* 275 */     closeStartTag();
/* 276 */     if (needSP)
/* 277 */       write(32); 
/* 278 */     doText(value, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(Pcdata value, boolean needSP) throws IOException {
/* 283 */     closeStartTag();
/* 284 */     if (needSP)
/* 285 */       write(32); 
/* 286 */     value.writeTo(this);
/*     */   }
/*     */   
/*     */   private void doText(String value, boolean isAttribute) throws IOException {
/* 290 */     if (this.escapeHandler != null) {
/* 291 */       StringWriter sw = new StringWriter();
/* 292 */       this.escapeHandler.escape(value.toCharArray(), 0, value.length(), isAttribute, sw);
/* 293 */       this.textBuffer.set(sw.toString());
/*     */     } else {
/* 295 */       this.textBuffer.setEscape(value, isAttribute);
/*     */     } 
/* 297 */     this.textBuffer.write(this);
/*     */   }
/*     */   
/*     */   public final void text(int value) throws IOException {
/* 301 */     closeStartTag();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     boolean minus = (value < 0);
/* 309 */     this.textBuffer.ensureSize(11);
/* 310 */     byte[] buf = this.textBuffer.buf;
/* 311 */     int idx = 11;
/*     */     
/*     */     do {
/* 314 */       int r = value % 10;
/* 315 */       if (r < 0) r = -r; 
/* 316 */       buf[--idx] = (byte)(0x30 | r);
/* 317 */       value /= 10;
/* 318 */     } while (value != 0);
/*     */     
/* 320 */     if (minus) buf[--idx] = 45;
/*     */     
/* 322 */     write(buf, idx, 11 - idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(byte[] data, int dataLen) throws IOException {
/* 334 */     closeStartTag();
/*     */     
/* 336 */     int start = 0;
/*     */     
/* 338 */     while (dataLen > 0) {
/*     */       
/* 340 */       int batchSize = Math.min((this.octetBuffer.length - this.octetBufferIndex) / 4 * 3, dataLen);
/*     */ 
/*     */       
/* 343 */       this.octetBufferIndex = DatatypeConverterImpl._printBase64Binary(data, start, batchSize, this.octetBuffer, this.octetBufferIndex);
/*     */       
/* 345 */       if (batchSize < dataLen) {
/* 346 */         flushBuffer();
/*     */       }
/* 348 */       start += batchSize;
/* 349 */       dataLen -= batchSize;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(int i) throws IOException {
/* 368 */     if (this.octetBufferIndex < this.octetBuffer.length) {
/* 369 */       this.octetBuffer[this.octetBufferIndex++] = (byte)i;
/*     */     } else {
/* 371 */       this.out.write(this.octetBuffer);
/* 372 */       this.octetBufferIndex = 1;
/* 373 */       this.octetBuffer[0] = (byte)i;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void write(byte[] b) throws IOException {
/* 378 */     write(b, 0, b.length);
/*     */   }
/*     */   
/*     */   protected final void write(byte[] b, int start, int length) throws IOException {
/* 382 */     if (this.octetBufferIndex + length < this.octetBuffer.length) {
/* 383 */       System.arraycopy(b, start, this.octetBuffer, this.octetBufferIndex, length);
/* 384 */       this.octetBufferIndex += length;
/*     */     } else {
/* 386 */       this.out.write(this.octetBuffer, 0, this.octetBufferIndex);
/* 387 */       this.out.write(b, start, length);
/* 388 */       this.octetBufferIndex = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void flushBuffer() throws IOException {
/* 393 */     this.out.write(this.octetBuffer, 0, this.octetBufferIndex);
/* 394 */     this.octetBufferIndex = 0;
/*     */   }
/*     */   
/*     */   static byte[] toBytes(String s) {
/* 398 */     byte[] buf = new byte[s.length()];
/* 399 */     for (int i = s.length() - 1; i >= 0; i--)
/* 400 */       buf[i] = (byte)s.charAt(i); 
/* 401 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public UTF8XmlOutput(OutputStream out, Encoded[] localNames, CharacterEscapeHandler escapeHandler) {
/* 406 */     this.XMLNS_EQUALS = (byte[])_XMLNS_EQUALS.clone();
/* 407 */     this.XMLNS_COLON = (byte[])_XMLNS_COLON.clone();
/* 408 */     this.EQUALS = (byte[])_EQUALS.clone();
/* 409 */     this.CLOSE_TAG = (byte[])_CLOSE_TAG.clone();
/* 410 */     this.EMPTY_TAG = (byte[])_EMPTY_TAG.clone();
/* 411 */     this.XML_DECL = (byte[])_XML_DECL.clone(); this.out = out; this.localNames = localNames;
/*     */     for (int i = 0; i < this.prefixes.length; i++)
/*     */       this.prefixes[i] = new Encoded(); 
/* 414 */     this.escapeHandler = escapeHandler; } private static final byte[] _XMLNS_EQUALS = toBytes(" xmlns=\"");
/* 415 */   private static final byte[] _XMLNS_COLON = toBytes(" xmlns:");
/* 416 */   private static final byte[] _EQUALS = toBytes("=\"");
/* 417 */   private static final byte[] _CLOSE_TAG = toBytes("</");
/* 418 */   private static final byte[] _EMPTY_TAG = toBytes("/>");
/* 419 */   private static final byte[] _XML_DECL = toBytes("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
/*     */ 
/*     */   
/* 422 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\UTF8XmlOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */