/*     */ package org.glassfish.jaxb.runtime.v2.runtime.output;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Constructor;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*     */ import org.glassfish.jaxb.core.marshaller.NoEscapeHandler;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLStreamWriterOutput
/*     */   extends XmlOutputAbstractImpl
/*     */ {
/*     */   private final XMLStreamWriter out;
/*     */   private final CharacterEscapeHandler escapeHandler;
/*     */   private final XmlStreamOutWriterAdapter writerWrapper;
/*     */   
/*     */   public static XmlOutput create(XMLStreamWriter out, JAXBContextImpl context, CharacterEscapeHandler escapeHandler) {
/*  43 */     Class<?> writerClass = out.getClass();
/*  44 */     if (writerClass == FI_STAX_WRITER_CLASS) {
/*     */       try {
/*  46 */         return FI_OUTPUT_CTOR.newInstance(new Object[] { out, context });
/*  47 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/*  50 */     if (STAXEX_WRITER_CLASS != null && STAXEX_WRITER_CLASS.isAssignableFrom(writerClass)) {
/*     */       try {
/*  52 */         return STAXEX_OUTPUT_CTOR.newInstance(new Object[] { out });
/*  53 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  58 */     CharacterEscapeHandler xmlStreamEscapeHandler = (escapeHandler != null) ? escapeHandler : (CharacterEscapeHandler)NoEscapeHandler.theInstance;
/*     */ 
/*     */     
/*  61 */     return new XMLStreamWriterOutput(out, xmlStreamEscapeHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected final char[] buf = new char[256];
/*     */   
/*     */   protected XMLStreamWriterOutput(XMLStreamWriter out, CharacterEscapeHandler escapeHandler) {
/*  74 */     this.out = out;
/*  75 */     this.escapeHandler = escapeHandler;
/*  76 */     this.writerWrapper = new XmlStreamOutWriterAdapter(out);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDocument(XMLSerializer serializer, boolean fragment, int[] nsUriIndex2prefixIndex, NamespaceContextImpl nsContext) throws IOException, SAXException, XMLStreamException {
/*  82 */     super.startDocument(serializer, fragment, nsUriIndex2prefixIndex, nsContext);
/*  83 */     if (!fragment) {
/*  84 */       this.out.writeStartDocument();
/*     */     }
/*     */   }
/*     */   
/*     */   public void endDocument(boolean fragment) throws IOException, SAXException, XMLStreamException {
/*  89 */     if (!fragment) {
/*  90 */       this.out.writeEndDocument();
/*  91 */       this.out.flush();
/*     */     } 
/*  93 */     super.endDocument(fragment);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginStartTag(int prefix, String localName) throws IOException, XMLStreamException {
/*  98 */     this.out.writeStartElement(this.nsContext
/*  99 */         .getPrefix(prefix), localName, this.nsContext
/*     */         
/* 101 */         .getNamespaceURI(prefix));
/*     */     
/* 103 */     NamespaceContextImpl.Element nse = this.nsContext.getCurrent();
/* 104 */     if (nse.count() > 0) {
/* 105 */       for (int i = nse.count() - 1; i >= 0; i--) {
/* 106 */         String uri = nse.getNsUri(i);
/* 107 */         if (uri.length() != 0 || nse.getBase() != 1)
/*     */         {
/* 109 */           this.out.writeNamespace(nse.getPrefix(i), uri);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void attribute(int prefix, String localName, String value) throws IOException, XMLStreamException {
/* 116 */     if (prefix == -1) {
/* 117 */       this.out.writeAttribute(localName, value);
/*     */     } else {
/* 119 */       this.out.writeAttribute(this.nsContext
/* 120 */           .getPrefix(prefix), this.nsContext
/* 121 */           .getNamespaceURI(prefix), localName, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endStartTag() throws IOException, SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endTag(int prefix, String localName) throws IOException, SAXException, XMLStreamException {
/* 132 */     this.out.writeEndElement();
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(String value, boolean needsSeparatingWhitespace) throws IOException, SAXException, XMLStreamException {
/* 137 */     if (needsSeparatingWhitespace)
/* 138 */       this.out.writeCharacters(" "); 
/* 139 */     this.escapeHandler.escape(value.toCharArray(), 0, value.length(), false, this.writerWrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(Pcdata value, boolean needsSeparatingWhitespace) throws IOException, SAXException, XMLStreamException {
/* 144 */     if (needsSeparatingWhitespace) {
/* 145 */       this.out.writeCharacters(" ");
/*     */     }
/* 147 */     int len = value.length();
/* 148 */     if (len < this.buf.length) {
/* 149 */       value.writeTo(this.buf, 0);
/* 150 */       this.out.writeCharacters(this.buf, 0, len);
/*     */     } else {
/* 152 */       this.out.writeCharacters(value.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   private static final Class FI_STAX_WRITER_CLASS = initFIStAXWriterClass();
/* 160 */   private static final Constructor<? extends XmlOutput> FI_OUTPUT_CTOR = initFastInfosetOutputClass();
/*     */   
/*     */   private static Class initFIStAXWriterClass() {
/*     */     try {
/* 164 */       Class<?> llfisw = Class.forName("org.jvnet.fastinfoset.stax.LowLevelFastInfosetStreamWriter");
/* 165 */       Class<?> sds = Class.forName("com.sun.xml.fastinfoset.stax.StAXDocumentSerializer");
/*     */       
/* 167 */       if (llfisw.isAssignableFrom(sds)) {
/* 168 */         return sds;
/*     */       }
/* 170 */       return null;
/* 171 */     } catch (Throwable e) {
/* 172 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Constructor<? extends XmlOutput> initFastInfosetOutputClass() {
/*     */     try {
/* 178 */       if (FI_STAX_WRITER_CLASS == null)
/* 179 */         return null; 
/* 180 */       Class<?> c = Class.forName("org.glassfish.jaxb.runtime.v2.runtime.output.FastInfosetStreamWriterOutput");
/* 181 */       return (Constructor)c.getConstructor(new Class[] { FI_STAX_WRITER_CLASS, JAXBContextImpl.class });
/* 182 */     } catch (Throwable e) {
/* 183 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   private static final Class STAXEX_WRITER_CLASS = initStAXExWriterClass();
/* 191 */   private static final Constructor<? extends XmlOutput> STAXEX_OUTPUT_CTOR = initStAXExOutputClass();
/*     */   
/*     */   private static Class initStAXExWriterClass() {
/*     */     try {
/* 195 */       return Class.forName("org.jvnet.staxex.XMLStreamWriterEx");
/* 196 */     } catch (Throwable e) {
/* 197 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Constructor<? extends XmlOutput> initStAXExOutputClass() {
/*     */     try {
/* 203 */       Class<?> c = Class.forName("org.glassfish.jaxb.runtime.v2.runtime.output.StAXExStreamWriterOutput");
/* 204 */       return (Constructor)c.getConstructor(new Class[] { STAXEX_WRITER_CLASS });
/* 205 */     } catch (Throwable e) {
/* 206 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class XmlStreamOutWriterAdapter
/*     */     extends Writer {
/*     */     private final XMLStreamWriter writer;
/*     */     
/*     */     private XmlStreamOutWriterAdapter(XMLStreamWriter writer) {
/* 215 */       this.writer = writer;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(char[] cbuf, int off, int len) throws IOException {
/*     */       try {
/* 221 */         this.writer.writeCharacters(cbuf, off, len);
/* 222 */       } catch (XMLStreamException e) {
/* 223 */         throw new IOException("Error writing XML stream", e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void writeEntityRef(String entityReference) throws XMLStreamException {
/* 228 */       this.writer.writeEntityRef(entityReference);
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() throws IOException {
/*     */       try {
/* 234 */         this.writer.flush();
/* 235 */       } catch (XMLStreamException e) {
/* 236 */         throw new IOException("Error flushing XML stream", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/*     */       try {
/* 243 */         this.writer.close();
/* 244 */       } catch (XMLStreamException e) {
/* 245 */         throw new IOException("Error closing XML stream", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\output\XMLStreamWriterOutput.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */