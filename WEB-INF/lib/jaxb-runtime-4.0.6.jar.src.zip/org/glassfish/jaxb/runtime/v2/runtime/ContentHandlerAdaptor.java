/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import com.sun.istack.SAXException2;
/*     */ import java.io.IOException;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ContentHandlerAdaptor
/*     */   extends DefaultHandler
/*     */ {
/*  32 */   private final FinalArrayList<String> prefixMap = new FinalArrayList();
/*     */ 
/*     */   
/*     */   private final XMLSerializer serializer;
/*     */   
/*  37 */   private final StringBuffer text = new StringBuffer();
/*     */ 
/*     */   
/*     */   ContentHandlerAdaptor(XMLSerializer _serializer) {
/*  41 */     this.serializer = _serializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startDocument() {
/*  46 */     this.prefixMap.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startPrefixMapping(String prefix, String uri) {
/*  51 */     this.prefixMap.add(prefix);
/*  52 */     this.prefixMap.add(uri);
/*     */   }
/*     */   
/*     */   private boolean containsPrefixMapping(String prefix, String uri) {
/*  56 */     for (int i = 0; i < this.prefixMap.size(); i += 2) {
/*  57 */       if (((String)this.prefixMap.get(i)).equals(prefix) && ((String)this.prefixMap
/*  58 */         .get(i + 1)).equals(uri))
/*  59 */         return true; 
/*     */     } 
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
/*     */     try {
/*  68 */       flushText();
/*     */       
/*  70 */       int len = atts.getLength();
/*     */       
/*  72 */       String p = getPrefix(qName);
/*     */ 
/*     */       
/*  75 */       if (containsPrefixMapping(p, namespaceURI)) {
/*  76 */         this.serializer.startElementForce(namespaceURI, localName, p, null);
/*     */       } else {
/*  78 */         this.serializer.startElement(namespaceURI, localName, p, null);
/*     */       } 
/*     */       int i;
/*  81 */       for (i = 0; i < this.prefixMap.size(); i += 2)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*  86 */         this.serializer.getNamespaceContext().force((String)this.prefixMap
/*  87 */             .get(i + 1), (String)this.prefixMap.get(i));
/*     */       }
/*     */ 
/*     */       
/*  91 */       for (i = 0; i < len; i++) {
/*  92 */         String qname = atts.getQName(i);
/*  93 */         if (!qname.startsWith("xmlns") && atts.getURI(i).length() != 0) {
/*     */           
/*  95 */           String prefix = getPrefix(qname);
/*     */           
/*  97 */           this.serializer.getNamespaceContext().declareNamespace(atts
/*  98 */               .getURI(i), prefix, true);
/*     */         } 
/*     */       } 
/* 101 */       this.serializer.endNamespaceDecls(null);
/*     */       
/* 103 */       for (i = 0; i < len; i++) {
/*     */         
/* 105 */         if (!atts.getQName(i).startsWith("xmlns"))
/*     */         {
/* 107 */           this.serializer.attribute(atts.getURI(i), atts.getLocalName(i), atts.getValue(i)); } 
/*     */       } 
/* 109 */       this.prefixMap.clear();
/* 110 */       this.serializer.endAttributes();
/* 111 */     } catch (IOException|XMLStreamException e) {
/* 112 */       throw new SAXException2(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getPrefix(String qname) {
/* 117 */     int idx = qname.indexOf(':');
/* 118 */     return (idx == -1) ? "" : qname.substring(0, idx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
/*     */     try {
/* 124 */       flushText();
/* 125 */       this.serializer.endElement();
/* 126 */     } catch (IOException|XMLStreamException e) {
/* 127 */       throw new SAXException2(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void flushText() throws SAXException, IOException, XMLStreamException {
/* 132 */     if (this.text.length() != 0) {
/* 133 */       this.serializer.text(this.text.toString(), (String)null);
/* 134 */       this.text.setLength(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/* 140 */     this.text.append(ch, start, length);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\ContentHandlerAdaptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */