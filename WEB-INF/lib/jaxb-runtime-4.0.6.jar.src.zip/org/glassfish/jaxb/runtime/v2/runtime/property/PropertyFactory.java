/*     */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collection;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ClassInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeAttributePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementPropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeValuePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyFactory
/*     */ {
/*     */   private static final Constructor<? extends Property>[] propImpls;
/*     */   
/*     */   static {
/*  38 */     Class[] arrayOfClass = { SingleElementLeafProperty.class, null, null, ArrayElementLeafProperty.class, null, null, SingleElementNodeProperty.class, SingleReferenceNodeProperty.class, SingleMapNodeProperty.class, ArrayElementNodeProperty.class, ArrayReferenceNodeProperty.class, null };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     propImpls = (Constructor<? extends Property>[])new Constructor[arrayOfClass.length];
/*  57 */     for (int i = 0; i < propImpls.length; i++) {
/*  58 */       if (arrayOfClass[i] != null)
/*     */       {
/*  60 */         propImpls[i] = (Constructor)arrayOfClass[i].getConstructors()[0];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Property create(JAXBContextImpl grammar, RuntimePropertyInfo info) {
/*  70 */     PropertyKind kind = info.kind();
/*     */     
/*  72 */     switch (kind) {
/*     */       case ATTRIBUTE:
/*  74 */         return new AttributeProperty(grammar, (RuntimeAttributePropertyInfo)info);
/*     */       case VALUE:
/*  76 */         return new ValueProperty(grammar, (RuntimeValuePropertyInfo)info);
/*     */       case ELEMENT:
/*  78 */         if (((RuntimeElementPropertyInfo)info).isValueList()) {
/*  79 */           return new ListElementProperty<>(grammar, (RuntimeElementPropertyInfo)info);
/*     */         }
/*     */         break;
/*     */       case REFERENCE:
/*     */       case MAP:
/*     */         break;
/*     */       default:
/*     */         assert false;
/*     */         break;
/*     */     } 
/*  89 */     boolean isCollection = info.isCollection();
/*  90 */     boolean isLeaf = isLeaf(info);
/*     */     
/*  92 */     Constructor<? extends Property> c = propImpls[(isLeaf ? 0 : 6) + (isCollection ? 3 : 0) + kind.propertyIndex];
/*     */     try {
/*  94 */       return c.newInstance(new Object[] { grammar, info });
/*  95 */     } catch (InstantiationException e) {
/*  96 */       throw new InstantiationError(e.getMessage());
/*  97 */     } catch (IllegalAccessException e) {
/*  98 */       throw new IllegalAccessError(e.getMessage());
/*  99 */     } catch (InvocationTargetException e) {
/* 100 */       Throwable t = e.getCause();
/* 101 */       if (t instanceof Error)
/* 102 */         throw (Error)t; 
/* 103 */       if (t instanceof RuntimeException) {
/* 104 */         throw (RuntimeException)t;
/*     */       }
/* 106 */       throw new AssertionError(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isLeaf(RuntimePropertyInfo info) {
/* 115 */     Collection<? extends RuntimeTypeInfo> types = info.ref();
/* 116 */     if (types.size() != 1) return false;
/*     */     
/* 118 */     RuntimeTypeInfo rti = types.iterator().next();
/* 119 */     if (!(rti instanceof RuntimeNonElement)) return false;
/*     */     
/* 121 */     if (info.id() == ID.IDREF)
/*     */     {
/* 123 */       return true;
/*     */     }
/*     */     
/* 126 */     if (rti instanceof ClassInfo && ((ClassInfo)rti).hasSubClasses()) return false;
/*     */     
/* 128 */     if (((RuntimeNonElement)rti).getTransducer() == null)
/*     */     {
/*     */ 
/*     */       
/* 132 */       return false;
/*     */     }
/* 134 */     return info.getIndividualType().equals(rti.getType());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\PropertyFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */