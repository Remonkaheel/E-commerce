/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.Coordinator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AdaptedAccessor<BeanT, InMemValueT, OnWireValueT>
/*    */   extends Accessor<BeanT, OnWireValueT>
/*    */ {
/*    */   private final Accessor<BeanT, InMemValueT> core;
/*    */   private final Class<? extends XmlAdapter<OnWireValueT, InMemValueT>> adapter;
/*    */   private XmlAdapter<OnWireValueT, InMemValueT> staticAdapter;
/*    */   
/*    */   AdaptedAccessor(Class<OnWireValueT> targetType, Accessor<BeanT, InMemValueT> extThis, Class<? extends XmlAdapter<OnWireValueT, InMemValueT>> adapter) {
/* 30 */     super(targetType);
/* 31 */     this.core = extThis;
/* 32 */     this.adapter = adapter;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAdapted() {
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public OnWireValueT get(BeanT bean) throws AccessorException {
/* 42 */     InMemValueT v = this.core.get(bean);
/*    */     
/* 44 */     XmlAdapter<OnWireValueT, InMemValueT> a = getAdapter();
/*    */     try {
/* 46 */       return (OnWireValueT)a.marshal(v);
/* 47 */     } catch (Exception e) {
/* 48 */       throw new AccessorException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(BeanT bean, OnWireValueT o) throws AccessorException {
/* 54 */     XmlAdapter<OnWireValueT, InMemValueT> a = getAdapter();
/*    */     try {
/* 56 */       this.core.set(bean, (o == null) ? null : (InMemValueT)a.unmarshal(o));
/* 57 */     } catch (Exception e) {
/* 58 */       throw new AccessorException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getUnadapted(BeanT bean) throws AccessorException {
/* 64 */     return this.core.getUnadapted(bean);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUnadapted(BeanT bean, Object value) throws AccessorException {
/* 69 */     this.core.setUnadapted(bean, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private XmlAdapter<OnWireValueT, InMemValueT> getAdapter() {
/* 80 */     Coordinator coordinator = Coordinator._getInstance();
/* 81 */     if (coordinator != null) {
/* 82 */       return coordinator.getAdapter(this.adapter);
/*    */     }
/* 84 */     synchronized (this) {
/* 85 */       if (this.staticAdapter == null)
/* 86 */         this.staticAdapter = (XmlAdapter<OnWireValueT, InMemValueT>)ClassFactory.create(this.adapter); 
/*    */     } 
/* 88 */     return this.staticAdapter;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\AdaptedAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */