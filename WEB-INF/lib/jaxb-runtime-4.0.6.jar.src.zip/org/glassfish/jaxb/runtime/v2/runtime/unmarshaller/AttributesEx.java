package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;

import org.xml.sax.Attributes;

public interface AttributesEx extends Attributes {
  CharSequence getData(int paramInt);
  
  CharSequence getData(String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\AttributesEx.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */