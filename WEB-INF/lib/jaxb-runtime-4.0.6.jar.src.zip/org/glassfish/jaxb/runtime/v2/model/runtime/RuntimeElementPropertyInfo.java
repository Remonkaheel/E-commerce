package org.glassfish.jaxb.runtime.v2.model.runtime;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.List;
import org.glassfish.jaxb.core.v2.model.core.ElementPropertyInfo;

public interface RuntimeElementPropertyInfo extends ElementPropertyInfo<Type, Class>, RuntimePropertyInfo {
  Collection<? extends RuntimeTypeInfo> ref();
  
  List<? extends RuntimeTypeRef> getTypes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\runtime\RuntimeElementPropertyInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */