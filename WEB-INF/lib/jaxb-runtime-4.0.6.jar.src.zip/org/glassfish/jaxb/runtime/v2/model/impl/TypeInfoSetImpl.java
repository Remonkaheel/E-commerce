/*     */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Marshaller;
/*     */ import jakarta.xml.bind.annotation.XmlNs;
/*     */ import jakarta.xml.bind.annotation.XmlNsForm;
/*     */ import jakarta.xml.bind.annotation.XmlRegistry;
/*     */ import jakarta.xml.bind.annotation.XmlSchema;
/*     */ import jakarta.xml.bind.annotation.XmlTransient;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.transform.Result;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.AnnotationReader;
/*     */ import org.glassfish.jaxb.core.v2.model.core.BuiltinLeafInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ElementInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.LeafInfo;
/*     */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*     */ import org.glassfish.jaxb.core.v2.model.core.Ref;
/*     */ import org.glassfish.jaxb.core.v2.model.core.TypeInfoSet;
/*     */ import org.glassfish.jaxb.core.v2.model.nav.Navigator;
/*     */ import org.glassfish.jaxb.core.v2.runtime.IllegalAnnotationException;
/*     */ import org.glassfish.jaxb.core.v2.runtime.RuntimeUtil;
/*     */ import org.glassfish.jaxb.core.v2.util.FlattenIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TypeInfoSetImpl<T, C, F, M>
/*     */   implements TypeInfoSet<T, C, F, M>
/*     */ {
/*     */   @XmlTransient
/*     */   public final Navigator<T, C, F, M> nav;
/*     */   @XmlTransient
/*     */   public final AnnotationReader<T, C, F, M> reader;
/*  52 */   private final Map<T, BuiltinLeafInfo<T, C>> builtins = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  56 */   private final Map<C, EnumLeafInfoImpl<T, C, F, M>> enums = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  60 */   private final Map<T, ArrayInfoImpl<T, C, F, M>> arrays = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlJavaTypeAdapter(RuntimeUtil.ToStringAdapter.class)
/*  71 */   private final Map<C, ClassInfoImpl<T, C, F, M>> beans = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlTransient
/*  77 */   private final Map<C, ClassInfoImpl<T, C, F, M>> beansView = Collections.unmodifiableMap(this.beans);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private final Map<C, Map<QName, ElementInfoImpl<T, C, F, M>>> elementMappings = new LinkedHashMap<>();
/*     */ 
/*     */   
/*  85 */   private final Iterable<? extends ElementInfoImpl<T, C, F, M>> allElements = (Iterable)new Iterable<ElementInfoImpl<ElementInfoImpl<T, C, F, M>, C, F, M>>()
/*     */     {
/*     */       public Iterator<ElementInfoImpl<T, C, F, M>> iterator()
/*     */       {
/*  89 */         return (Iterator<ElementInfoImpl<T, C, F, M>>)new FlattenIterator(TypeInfoSetImpl.this.elementMappings.values());
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final NonElement<T, C> anyType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Map<String, String>> xmlNsCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInfoSetImpl(Navigator<T, C, F, M> nav, AnnotationReader<T, C, F, M> reader, Map<T, ? extends BuiltinLeafInfoImpl<T, C>> leaves) {
/* 111 */     this.nav = nav;
/* 112 */     this.reader = reader;
/* 113 */     this.builtins.putAll((Map)leaves);
/*     */     
/* 115 */     this.anyType = createAnyType();
/*     */ 
/*     */     
/* 118 */     for (Map.Entry<Class<?>, Class<?>> e : (Iterable<Map.Entry<Class<?>, Class<?>>>)RuntimeUtil.primitiveToBox.entrySet()) {
/* 119 */       this.builtins.put((T)nav.getPrimitive(e.getKey()), leaves.get(nav.ref(e.getValue())));
/*     */     }
/*     */ 
/*     */     
/* 123 */     this.elementMappings.put(null, new LinkedHashMap<>());
/*     */   }
/*     */   
/*     */   protected NonElement<T, C> createAnyType() {
/* 127 */     return new AnyTypeImpl<>(this.nav);
/*     */   }
/*     */ 
/*     */   
/*     */   public Navigator<T, C, F, M> getNavigator() {
/* 132 */     return this.nav;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(ClassInfoImpl<T, C, F, M> ci) {
/* 139 */     this.beans.put(ci.getClazz(), ci);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(EnumLeafInfoImpl<T, C, F, M> li) {
/* 146 */     this.enums.put(li.clazz, li);
/*     */   }
/*     */   
/*     */   public void add(ArrayInfoImpl<T, C, F, M> ai) {
/* 150 */     this.arrays.put(ai.getType(), ai);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getTypeInfo(T type) {
/* 162 */     type = (T)this.nav.erasure(type);
/*     */     
/* 164 */     LeafInfo<T, C> l = (LeafInfo<T, C>)this.builtins.get(type);
/* 165 */     if (l != null) return (NonElement<T, C>)l;
/*     */     
/* 167 */     if (this.nav.isArray(type)) {
/* 168 */       return (NonElement<T, C>)this.arrays.get(type);
/*     */     }
/*     */     
/* 171 */     C d = (C)this.nav.asDecl(type);
/* 172 */     if (d == null) return null; 
/* 173 */     return getClassInfo(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getAnyTypeInfo() {
/* 178 */     return this.anyType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getTypeInfo(Ref<T, C> ref) {
/* 187 */     assert !ref.valueList;
/* 188 */     C c = (C)this.nav.asDecl(ref.type);
/* 189 */     if (c != null && this.reader.getClassAnnotation(XmlRegistry.class, c, null) != null) {
/* 190 */       return null;
/*     */     }
/* 192 */     return getTypeInfo((T)ref.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<C, ? extends ClassInfoImpl<T, C, F, M>> beans() {
/* 200 */     return this.beansView;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<T, ? extends BuiltinLeafInfo<T, C>> builtins() {
/* 205 */     return this.builtins;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<C, ? extends EnumLeafInfoImpl<T, C, F, M>> enums() {
/* 210 */     return this.enums;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<? extends T, ? extends ArrayInfoImpl<T, C, F, M>> arrays() {
/* 215 */     return this.arrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonElement<T, C> getClassInfo(C type) {
/* 231 */     LeafInfo<T, C> l = (LeafInfo<T, C>)this.builtins.get(this.nav.use(type));
/* 232 */     if (l != null) return (NonElement<T, C>)l;
/*     */     
/* 234 */     l = (LeafInfo<T, C>)this.enums.get(type);
/* 235 */     if (l != null) return (NonElement<T, C>)l;
/*     */     
/* 237 */     if (this.nav.asDecl(Object.class).equals(type)) {
/* 238 */       return this.anyType;
/*     */     }
/* 240 */     return (NonElement<T, C>)this.beans.get(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementInfoImpl<T, C, F, M> getElementInfo(C scope, QName name) {
/* 245 */     while (scope != null) {
/* 246 */       Map<QName, ElementInfoImpl<T, C, F, M>> m = this.elementMappings.get(scope);
/* 247 */       if (m != null) {
/* 248 */         ElementInfoImpl<T, C, F, M> r = m.get(name);
/* 249 */         if (r != null) return r; 
/*     */       } 
/* 251 */       scope = (C)this.nav.getSuperClass(scope);
/*     */     } 
/* 253 */     return (ElementInfoImpl<T, C, F, M>)((Map)this.elementMappings.get(null)).get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(ElementInfoImpl<T, C, F, M> ei, ModelBuilder<T, C, F, M> builder) {
/* 261 */     C scope = null;
/* 262 */     if (ei.getScope() != null) {
/* 263 */       scope = (C)ei.getScope().getClazz();
/*     */     }
/* 265 */     Map<QName, ElementInfoImpl<T, C, F, M>> m = this.elementMappings.computeIfAbsent(scope, k -> new LinkedHashMap<>());
/*     */     
/* 267 */     ElementInfoImpl<T, C, F, M> existing = m.put(ei.getElementName(), ei);
/*     */     
/* 269 */     if (existing != null) {
/* 270 */       QName en = ei.getElementName();
/* 271 */       builder.reportError(new IllegalAnnotationException(Messages.CONFLICTING_XML_ELEMENT_MAPPING
/*     */             
/* 273 */             .format(new Object[] { en.getNamespaceURI(), en.getLocalPart() }, ), ei, existing));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<QName, ? extends ElementInfoImpl<T, C, F, M>> getElementMappings(C scope) {
/* 280 */     return this.elementMappings.get(scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<? extends ElementInfoImpl<T, C, F, M>> getAllElements() {
/* 285 */     return this.allElements;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getXmlNs(String namespaceUri) {
/* 290 */     if (this.xmlNsCache == null) {
/* 291 */       Map<String, Map<String, String>> xmlNsCache = new HashMap<>();
/*     */       
/* 293 */       for (ClassInfoImpl<T, C, F, M> ci : beans().values()) {
/* 294 */         XmlSchema xs = (XmlSchema)this.reader.getPackageAnnotation(XmlSchema.class, ci.getClazz(), null);
/* 295 */         if (xs == null) {
/*     */           continue;
/*     */         }
/* 298 */         String uri = xs.namespace();
/* 299 */         Map<String, String> m = xmlNsCache.computeIfAbsent(uri, k -> new HashMap<>());
/*     */         
/* 301 */         for (XmlNs xns : xs.xmlns()) {
/* 302 */           m.put(xns.prefix(), xns.namespaceURI());
/*     */         }
/*     */       } 
/*     */       
/* 306 */       this.xmlNsCache = xmlNsCache;
/*     */     } 
/*     */     
/* 309 */     Map<String, String> r = this.xmlNsCache.get(namespaceUri);
/* 310 */     if (r != null) return r; 
/* 311 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getSchemaLocations() {
/* 316 */     Map<String, String> r = new HashMap<>();
/* 317 */     for (ClassInfoImpl<T, C, F, M> ci : beans().values()) {
/* 318 */       XmlSchema xs = (XmlSchema)this.reader.getPackageAnnotation(XmlSchema.class, ci.getClazz(), null);
/* 319 */       if (xs == null) {
/*     */         continue;
/*     */       }
/* 322 */       String loc = xs.location();
/* 323 */       if (loc.equals("##generate")) {
/*     */         continue;
/*     */       }
/* 326 */       r.put(xs.namespace(), loc);
/*     */     } 
/* 328 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public final XmlNsForm getElementFormDefault(String nsUri) {
/* 333 */     for (ClassInfoImpl<T, C, F, M> ci : beans().values()) {
/* 334 */       XmlSchema xs = (XmlSchema)this.reader.getPackageAnnotation(XmlSchema.class, ci.getClazz(), null);
/* 335 */       if (xs == null) {
/*     */         continue;
/*     */       }
/* 338 */       if (!xs.namespace().equals(nsUri)) {
/*     */         continue;
/*     */       }
/* 341 */       XmlNsForm xnf = xs.elementFormDefault();
/* 342 */       if (xnf != XmlNsForm.UNSET)
/* 343 */         return xnf; 
/*     */     } 
/* 345 */     return XmlNsForm.UNSET;
/*     */   }
/*     */ 
/*     */   
/*     */   public final XmlNsForm getAttributeFormDefault(String nsUri) {
/* 350 */     for (ClassInfoImpl<T, C, F, M> ci : beans().values()) {
/* 351 */       XmlSchema xs = (XmlSchema)this.reader.getPackageAnnotation(XmlSchema.class, ci.getClazz(), null);
/* 352 */       if (xs == null) {
/*     */         continue;
/*     */       }
/* 355 */       if (!xs.namespace().equals(nsUri)) {
/*     */         continue;
/*     */       }
/* 358 */       XmlNsForm xnf = xs.attributeFormDefault();
/* 359 */       if (xnf != XmlNsForm.UNSET)
/* 360 */         return xnf; 
/*     */     } 
/* 362 */     return XmlNsForm.UNSET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(Result out) throws JAXBException {
/* 374 */     JAXBContext context = JAXBContext.newInstance(new Class[] { getClass() });
/* 375 */     Marshaller m = context.createMarshaller();
/* 376 */     m.marshal(this, out);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\TypeInfoSetImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */