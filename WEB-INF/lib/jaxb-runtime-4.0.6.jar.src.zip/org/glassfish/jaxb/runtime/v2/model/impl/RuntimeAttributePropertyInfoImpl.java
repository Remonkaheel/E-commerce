/*    */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.glassfish.jaxb.core.v2.model.core.NonElement;
/*    */ import org.glassfish.jaxb.core.v2.model.core.PropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeAttributePropertyInfo;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeNonElement;
/*    */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RuntimeAttributePropertyInfoImpl
/*    */   extends AttributePropertyInfoImpl<Type, Class, Field, Method>
/*    */   implements RuntimeAttributePropertyInfo
/*    */ {
/*    */   RuntimeAttributePropertyInfoImpl(RuntimeClassInfoImpl classInfo, PropertySeed<Type, Class<?>, Field, Method> seed) {
/* 29 */     super(classInfo, seed);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean elementOnlyContent() {
/* 34 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimeNonElement getTarget() {
/* 39 */     return (RuntimeNonElement)super.getTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<? extends RuntimeNonElement> ref() {
/* 44 */     return (List)super.ref();
/*    */   }
/*    */ 
/*    */   
/*    */   public RuntimePropertyInfo getSource() {
/* 49 */     return (RuntimePropertyInfo)this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void link() {
/* 54 */     getTransducer();
/* 55 */     super.link();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeAttributePropertyInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */