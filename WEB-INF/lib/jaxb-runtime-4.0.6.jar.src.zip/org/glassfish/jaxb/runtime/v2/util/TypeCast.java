/*    */ package org.glassfish.jaxb.runtime.v2.util;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeCast
/*    */ {
/*    */   public static <K, V> Map<K, V> checkedCast(Map<?, ?> m, Class<K> keyType, Class<V> valueType) {
/* 30 */     if (m == null)
/* 31 */       return null; 
/* 32 */     for (Map.Entry<?, ?> e : m.entrySet()) {
/* 33 */       if (!keyType.isInstance(e.getKey()))
/* 34 */         throw new ClassCastException(e.getKey().getClass().toString()); 
/* 35 */       if (!valueType.isInstance(e.getValue()))
/* 36 */         throw new ClassCastException(e.getValue().getClass().toString()); 
/*    */     } 
/* 38 */     return (Map)m;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v\\util\TypeCast.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */