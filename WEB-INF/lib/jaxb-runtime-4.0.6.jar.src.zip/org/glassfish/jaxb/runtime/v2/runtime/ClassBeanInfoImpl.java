/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import com.sun.istack.FinalArrayList;
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ import org.glassfish.jaxb.core.v2.ClassFactory;
/*     */ import org.glassfish.jaxb.core.v2.model.core.ID;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeClassInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.AttributeProperty;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.Property;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.PropertyFactory;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.StructureLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.XsiTypeLoader;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.LocatorImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassBeanInfoImpl<BeanT>
/*     */   extends JaxBeanInfo<BeanT>
/*     */   implements AttributeAccessor<BeanT>
/*     */ {
/*     */   public final Property<BeanT>[] properties;
/*     */   private Property<? super BeanT> idProperty;
/*     */   private Loader loader;
/*     */   private Loader loaderWithTypeSubst;
/*     */   private RuntimeClassInfo ci;
/*     */   private final Accessor<? super BeanT, Map<QName, String>> inheritedAttWildcard;
/*     */   private final Transducer<BeanT> xducer;
/*     */   public final ClassBeanInfoImpl<? super BeanT> superClazz;
/*     */   private final Accessor<? super BeanT, Locator> xmlLocatorField;
/*     */   private final Name tagName;
/*     */   private boolean retainPropertyInfo = false;
/*     */   private AttributeProperty<BeanT>[] attributeProperties;
/*     */   private Property<BeanT>[] uriProperties;
/*     */   private final Method factoryMethod;
/*     */   
/*     */   ClassBeanInfoImpl(JAXBContextImpl owner, RuntimeClassInfo ci) {
/* 107 */     super(owner, (RuntimeTypeInfo)ci, (Class<BeanT>)ci.getClazz(), ci.getTypeName(), ci.isElement(), false, true);
/*     */     
/* 109 */     this.ci = ci;
/* 110 */     this.inheritedAttWildcard = ci.getAttributeWildcard();
/* 111 */     this.xducer = ci.getTransducer();
/* 112 */     this.factoryMethod = ci.getFactoryMethod();
/* 113 */     this.retainPropertyInfo = owner.retainPropertyInfo;
/*     */ 
/*     */     
/* 116 */     if (this.factoryMethod != null) {
/* 117 */       int classMod = this.factoryMethod.getDeclaringClass().getModifiers();
/*     */       
/* 119 */       if (!Modifier.isPublic(classMod) || !Modifier.isPublic(this.factoryMethod.getModifiers())) {
/*     */         
/*     */         try {
/* 122 */           this.factoryMethod.setAccessible(true);
/* 123 */         } catch (SecurityException e) {
/*     */           
/* 125 */           logger.log(Level.FINE, "Unable to make the method of " + this.factoryMethod + " accessible", e);
/* 126 */           throw e;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (ci.getBaseClass() == null) {
/* 133 */       this.superClazz = null;
/*     */     } else {
/* 135 */       this.superClazz = owner.getOrCreate(ci.getBaseClass());
/*     */     } 
/* 137 */     if (this.superClazz != null && this.superClazz.xmlLocatorField != null) {
/* 138 */       this.xmlLocatorField = this.superClazz.xmlLocatorField;
/*     */     } else {
/* 140 */       this.xmlLocatorField = ci.getLocatorField();
/*     */     } 
/*     */     
/* 143 */     Collection<? extends RuntimePropertyInfo> ps = ci.getProperties();
/* 144 */     this.properties = (Property<BeanT>[])new Property[ps.size()];
/* 145 */     int idx = 0;
/* 146 */     boolean elementOnly = true;
/* 147 */     for (RuntimePropertyInfo info : ps) {
/* 148 */       Property<? super BeanT> p = PropertyFactory.create(owner, info);
/* 149 */       if (info.id() == ID.ID)
/* 150 */         this.idProperty = p; 
/* 151 */       this.properties[idx++] = (Property)p;
/* 152 */       elementOnly &= info.elementOnlyContent();
/* 153 */       checkOverrideProperties(p);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 158 */     hasElementOnlyContentModel(elementOnly);
/*     */ 
/*     */     
/* 161 */     if (ci.isElement()) {
/* 162 */       this.tagName = owner.nameBuilder.createElementName(ci.getElementName());
/*     */     } else {
/* 164 */       this.tagName = null;
/*     */     } 
/* 166 */     setLifecycleFlags();
/*     */   }
/*     */   
/*     */   private void checkOverrideProperties(Property p) {
/* 170 */     ClassBeanInfoImpl<BeanT> bi = this; ClassBeanInfoImpl<? super BeanT> classBeanInfoImpl;
/* 171 */     while ((classBeanInfoImpl = bi.superClazz) != null) {
/* 172 */       Property<BeanT>[] arrayOfProperty = classBeanInfoImpl.properties;
/* 173 */       if (arrayOfProperty == null)
/* 174 */         break;  for (Property<BeanT> superProperty : arrayOfProperty) {
/* 175 */         if (superProperty != null) {
/* 176 */           String spName = superProperty.getFieldName();
/* 177 */           if (spName != null && spName.equals(p.getFieldName())) {
/* 178 */             superProperty.setHiddenByOverride(true);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void link(JAXBContextImpl grammar) {
/* 187 */     if (this.uriProperties != null) {
/*     */       return;
/*     */     }
/* 190 */     super.link(grammar);
/*     */     
/* 192 */     if (this.superClazz != null) {
/* 193 */       this.superClazz.link(grammar);
/*     */     }
/* 195 */     getLoader(grammar, true);
/*     */ 
/*     */     
/* 198 */     if (this.superClazz != null) {
/* 199 */       if (this.idProperty == null) {
/* 200 */         this.idProperty = this.superClazz.idProperty;
/*     */       }
/* 202 */       if (!this.superClazz.hasElementOnlyContentModel()) {
/* 203 */         hasElementOnlyContentModel(false);
/*     */       }
/*     */     } 
/*     */     
/* 207 */     FinalArrayList<AttributeProperty> finalArrayList = new FinalArrayList();
/* 208 */     FinalArrayList<Property<BeanT>> finalArrayList1 = new FinalArrayList();
/* 209 */     for (ClassBeanInfoImpl<BeanT> bi = this; bi != null; classBeanInfoImpl = bi.superClazz) {
/* 210 */       ClassBeanInfoImpl<? super BeanT> classBeanInfoImpl; for (int i = 0; i < bi.properties.length; i++) {
/* 211 */         Property<BeanT> p = bi.properties[i];
/* 212 */         if (p instanceof AttributeProperty)
/* 213 */           finalArrayList.add((AttributeProperty)p); 
/* 214 */         if (p.hasSerializeURIAction())
/* 215 */           finalArrayList1.add(p); 
/*     */       } 
/*     */     } 
/* 218 */     if (grammar.c14nSupport) {
/* 219 */       Collections.sort((List<AttributeProperty>)finalArrayList);
/*     */     }
/* 221 */     if (finalArrayList.isEmpty()) {
/* 222 */       this.attributeProperties = (AttributeProperty<BeanT>[])EMPTY_PROPERTIES;
/*     */     } else {
/* 224 */       this.attributeProperties = finalArrayList.<AttributeProperty<BeanT>>toArray((AttributeProperty<BeanT>[])new AttributeProperty[0]);
/*     */     } 
/* 226 */     if (finalArrayList1.isEmpty()) {
/* 227 */       this.uriProperties = (Property<BeanT>[])EMPTY_PROPERTIES;
/*     */     } else {
/* 229 */       this.uriProperties = finalArrayList1.<Property<BeanT>>toArray((Property<BeanT>[])new Property[0]);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void wrapUp() {
/* 234 */     for (Property<BeanT> p : this.properties)
/* 235 */       p.wrapUp(); 
/* 236 */     this.ci = null;
/* 237 */     super.wrapUp();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementNamespaceURI(BeanT bean) {
/* 242 */     return this.tagName.nsUri;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementLocalName(BeanT bean) {
/* 247 */     return this.tagName.localName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanT createInstance(UnmarshallingContext context) throws IllegalAccessException, InvocationTargetException, InstantiationException, SAXException {
/* 253 */     BeanT bean = null;
/* 254 */     if (this.factoryMethod == null) {
/* 255 */       bean = (BeanT)ClassFactory.create0(this.jaxbType);
/*     */     } else {
/* 257 */       Object o = ClassFactory.create(this.factoryMethod);
/* 258 */       if (this.jaxbType.isInstance(o)) {
/* 259 */         bean = (BeanT)o;
/*     */       } else {
/* 261 */         throw new InstantiationException("The factory method didn't return a correct object");
/*     */       } 
/*     */     } 
/*     */     
/* 265 */     if (this.xmlLocatorField != null)
/*     */       
/*     */       try {
/* 268 */         this.xmlLocatorField.set(bean, new LocatorImpl((Locator)context.getLocator()));
/* 269 */       } catch (AccessorException e) {
/* 270 */         context.handleError((Exception)e);
/*     */       }  
/* 272 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reset(BeanT bean, UnmarshallingContext context) throws SAXException {
/*     */     try {
/* 278 */       if (this.superClazz != null)
/* 279 */         this.superClazz.reset(bean, context); 
/* 280 */       for (Property<BeanT> p : this.properties)
/* 281 */         p.reset(bean); 
/* 282 */       return true;
/* 283 */     } catch (AccessorException e) {
/* 284 */       context.handleError((Exception)e);
/* 285 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId(BeanT bean, XMLSerializer target) throws SAXException {
/* 291 */     if (this.idProperty != null) {
/*     */       try {
/* 293 */         return this.idProperty.getIdValue(bean);
/* 294 */       } catch (AccessorException e) {
/* 295 */         target.reportError(null, (Throwable)e);
/*     */       } 
/*     */     }
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeRoot(BeanT bean, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 303 */     if (this.tagName == null) {
/* 304 */       String message; Class<?> beanClass = bean.getClass();
/*     */       
/* 306 */       if (beanClass.isAnnotationPresent((Class)XmlRootElement.class)) {
/* 307 */         message = Messages.UNABLE_TO_MARSHAL_UNBOUND_CLASS.format(new Object[] { beanClass.getName() });
/*     */       } else {
/* 309 */         message = Messages.UNABLE_TO_MARSHAL_NON_ELEMENT.format(new Object[] { beanClass.getName() });
/*     */       } 
/* 311 */       target.reportError((ValidationEvent)new ValidationEventImpl(1, message, null, null));
/*     */     } else {
/* 313 */       target.startElement(this.tagName, bean);
/* 314 */       target.childAsSoleContent(bean, null);
/* 315 */       target.endElement();
/* 316 */       if (this.retainPropertyInfo) {
/* 317 */         target.currentProperty.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(BeanT bean, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 324 */     if (this.superClazz != null) {
/* 325 */       this.superClazz.serializeBody(bean, target);
/*     */     }
/*     */     try {
/* 328 */       for (Property<BeanT> p : this.properties) {
/* 329 */         if (this.retainPropertyInfo) {
/* 330 */           target.currentProperty.set(p);
/*     */         }
/* 332 */         boolean isThereAnOverridingProperty = p.isHiddenByOverride();
/* 333 */         if (!isThereAnOverridingProperty || bean.getClass().equals(this.jaxbType)) {
/* 334 */           p.serializeBody(bean, target, null);
/* 335 */         } else if (isThereAnOverridingProperty) {
/*     */           
/* 337 */           Class<?> beanSuperClass = bean.getClass().getSuperclass();
/* 338 */           if (Utils.REFLECTION_NAVIGATOR.getDeclaredField(beanSuperClass, p.getFieldName()) == null) {
/* 339 */             p.serializeBody(bean, target, null);
/*     */           }
/*     */         } 
/*     */       } 
/* 343 */     } catch (AccessorException e) {
/* 344 */       target.reportError(null, (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeAttributes(BeanT bean, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 350 */     for (AttributeProperty<BeanT> p : this.attributeProperties) {
/*     */       try {
/* 352 */         if (this.retainPropertyInfo) {
/* 353 */           Property parentProperty = target.getCurrentProperty();
/* 354 */           target.currentProperty.set(p);
/* 355 */           p.serializeAttributes(bean, target);
/* 356 */           target.currentProperty.set(parentProperty);
/*     */         } else {
/* 358 */           p.serializeAttributes(bean, target);
/*     */         } 
/* 360 */         if (p.attName.equals("http://www.w3.org/2001/XMLSchema-instance", "nil")) {
/* 361 */           this.isNilIncluded = true;
/*     */         }
/* 363 */       } catch (AccessorException e) {
/* 364 */         target.reportError(null, (Throwable)e);
/*     */       } 
/*     */     } 
/*     */     try {
/* 368 */       if (this.inheritedAttWildcard != null) {
/* 369 */         Map<QName, String> map = (Map<QName, String>)this.inheritedAttWildcard.get(bean);
/* 370 */         target.attWildcardAsAttributes(map, null);
/*     */       } 
/* 372 */     } catch (AccessorException e) {
/* 373 */       target.reportError(null, (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeURIs(BeanT bean, XMLSerializer target) throws SAXException {
/*     */     try {
/* 380 */       if (this.retainPropertyInfo) {
/* 381 */         Property parentProperty = target.getCurrentProperty();
/* 382 */         for (Property<BeanT> p : this.uriProperties) {
/* 383 */           target.currentProperty.set(p);
/* 384 */           p.serializeURIs(bean, target);
/*     */         } 
/* 386 */         target.currentProperty.set(parentProperty);
/*     */       } else {
/* 388 */         for (Property<BeanT> p : this.uriProperties) {
/* 389 */           p.serializeURIs(bean, target);
/*     */         }
/*     */       } 
/* 392 */       if (this.inheritedAttWildcard != null) {
/* 393 */         Map<QName, String> map = (Map<QName, String>)this.inheritedAttWildcard.get(bean);
/* 394 */         target.attWildcardAsURIs(map, null);
/*     */       } 
/* 396 */     } catch (AccessorException e) {
/* 397 */       target.reportError(null, (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Loader getLoader(JAXBContextImpl context, boolean typeSubstitutionCapable) {
/* 403 */     if (this.loader == null) {
/*     */ 
/*     */       
/* 406 */       StructureLoader sl = new StructureLoader(this);
/* 407 */       this.loader = (Loader)sl;
/* 408 */       if (this.ci.hasSubClasses()) {
/* 409 */         this.loaderWithTypeSubst = (Loader)new XsiTypeLoader(this);
/*     */       } else {
/*     */         
/* 412 */         this.loaderWithTypeSubst = this.loader;
/*     */       } 
/*     */       
/* 415 */       sl.init(context, this, this.ci.getAttributeWildcard());
/*     */     } 
/* 417 */     if (typeSubstitutionCapable) {
/* 418 */       return this.loaderWithTypeSubst;
/*     */     }
/* 420 */     return this.loader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Transducer<BeanT> getTransducer() {
/* 425 */     return this.xducer;
/*     */   }
/*     */   
/* 428 */   private static final AttributeProperty[] EMPTY_PROPERTIES = new AttributeProperty[0];
/*     */   
/* 430 */   private static final Logger logger = Utils.getClassLogger();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\ClassBeanInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */