/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlRegistry;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlRegistryQuick
/*    */   extends Quick
/*    */   implements XmlRegistry
/*    */ {
/*    */   private final XmlRegistry core;
/*    */   
/*    */   public XmlRegistryQuick(Locatable upstream, XmlRegistry core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlRegistryQuick(upstream, (XmlRegistry)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlRegistry> annotationType() {
/* 47 */     return XmlRegistry.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlRegistryQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */