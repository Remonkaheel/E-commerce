/*      */ package org.glassfish.jaxb.runtime.v2.model.impl;
/*      */ 
/*      */ import com.sun.istack.ByteArrayDataSource;
/*      */ import jakarta.activation.DataHandler;
/*      */ import jakarta.activation.DataSource;
/*      */ import jakarta.activation.MimeType;
/*      */ import jakarta.activation.MimeTypeParseException;
/*      */ import jakarta.xml.bind.MarshalException;
/*      */ import jakarta.xml.bind.ValidationEvent;
/*      */ import jakarta.xml.bind.helpers.ValidationEventImpl;
/*      */ import java.awt.Component;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.MediaTracker;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Type;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.UUID;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.imageio.ImageWriter;
/*      */ import javax.imageio.stream.ImageOutputStream;
/*      */ import javax.xml.datatype.DatatypeConstants;
/*      */ import javax.xml.datatype.Duration;
/*      */ import javax.xml.datatype.XMLGregorianCalendar;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.transform.Source;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.glassfish.jaxb.core.Utils;
/*      */ import org.glassfish.jaxb.core.WhiteSpaceProcessor;
/*      */ import org.glassfish.jaxb.core.v2.TODO;
/*      */ import org.glassfish.jaxb.runtime.DatatypeConverterImpl;
/*      */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*      */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeBuiltinLeafInfo;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.Name;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.Transducer;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.output.Pcdata;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Base64Data;
/*      */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*      */ import org.glassfish.jaxb.runtime.v2.util.ByteArrayOutputStreamEx;
/*      */ import org.glassfish.jaxb.runtime.v2.util.DataSourceSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ public abstract class RuntimeBuiltinLeafInfoImpl<T>
/*      */   extends BuiltinLeafInfoImpl<Type, Class>
/*      */   implements RuntimeBuiltinLeafInfo, Transducer<T>
/*      */ {
/*   78 */   private static final Logger logger = Utils.getClassLogger();
/*      */   
/*      */   private RuntimeBuiltinLeafInfoImpl(Class type, QName... typeNames) {
/*   81 */     super(type, typeNames);
/*   82 */     LEAVES.put(type, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final Class getClazz() {
/*   87 */     return (Class)getType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <V> Transducer<V> getTransducer() {
/*   94 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean useNamespace() {
/*   99 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void declareNamespace(T o, XMLSerializer w) throws AccessorException {}
/*      */ 
/*      */   
/*      */   public QName getTypeName(T instance) {
/*  108 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static abstract class StringImpl<T>
/*      */     extends RuntimeBuiltinLeafInfoImpl<T>
/*      */   {
/*      */     protected StringImpl(Class<T> type, QName... typeNames) {
/*  116 */       super(type, typeNames);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void writeText(XMLSerializer w, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/*  124 */       w.text(print(o), fieldName);
/*      */     }
/*      */ 
/*      */     
/*      */     public void writeLeafElement(XMLSerializer w, Name tagName, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/*  129 */       w.leafElement(tagName, print(o), fieldName);
/*      */     }
/*      */     
/*      */     public abstract String print(T param1T) throws AccessorException;
/*      */   }
/*      */   
/*      */   private static abstract class PcdataImpl<T>
/*      */     extends RuntimeBuiltinLeafInfoImpl<T> {
/*      */     protected PcdataImpl(Class<T> type, QName... typeNames) {
/*  138 */       super(type, typeNames);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void writeText(XMLSerializer w, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/*  146 */       w.text(print(o), fieldName);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void writeLeafElement(XMLSerializer w, Name tagName, T o, String fieldName) throws IOException, SAXException, XMLStreamException, AccessorException {
/*  151 */       w.leafElement(tagName, print(o), fieldName);
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract Pcdata print(T param1T) throws AccessorException;
/*      */   }
/*      */ 
/*      */   
/*  159 */   public static final Map<Type, RuntimeBuiltinLeafInfoImpl<?>> LEAVES = new HashMap<>(); public static final RuntimeBuiltinLeafInfoImpl<String> STRING;
/*      */   
/*      */   private static QName createXS(String typeName) {
/*  162 */     return new QName("http://www.w3.org/2001/XMLSchema", typeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DATE = "date";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final List<RuntimeBuiltinLeafInfoImpl<?>> builtinBeanInfos;
/*      */ 
/*      */   
/*      */   public static final String MAP_ANYURI_TO_URI = "mapAnyUriToUri";
/*      */ 
/*      */   
/*      */   public static final String USE_OLD_GMONTH_MAPPING = "jaxb.ri.useOldGmonthMapping";
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  183 */     String MAP_ANYURI_TO_URI_VALUE = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*      */         {
/*      */           public String run()
/*      */           {
/*  187 */             return System.getProperty("mapAnyUriToUri");
/*      */           }
/*      */         });
/*      */     
/*  191 */     (new QName[10])[0] = 
/*  192 */       createXS("string"); (new QName[10])[1] = 
/*  193 */       createXS("anySimpleType"); (new QName[10])[2] = 
/*  194 */       createXS("normalizedString"); (new QName[10])[3] = 
/*  195 */       createXS("anyURI"); (new QName[10])[4] = 
/*  196 */       createXS("token"); (new QName[10])[5] = 
/*  197 */       createXS("language"); (new QName[10])[6] = 
/*  198 */       createXS("Name"); (new QName[10])[7] = 
/*  199 */       createXS("NCName"); (new QName[10])[8] = 
/*  200 */       createXS("NMTOKEN"); (new QName[10])[9] = 
/*  201 */       createXS("ENTITY");
/*      */     
/*  203 */     (new QName[9])[0] = 
/*  204 */       createXS("string"); (new QName[9])[1] = 
/*  205 */       createXS("anySimpleType"); (new QName[9])[2] = 
/*  206 */       createXS("normalizedString"); (new QName[9])[3] = 
/*  207 */       createXS("token"); (new QName[9])[4] = 
/*  208 */       createXS("language"); (new QName[9])[5] = 
/*  209 */       createXS("Name"); (new QName[9])[6] = 
/*  210 */       createXS("NCName"); (new QName[9])[7] = 
/*  211 */       createXS("NMTOKEN"); (new QName[9])[8] = 
/*  212 */       createXS("ENTITY"); QName[] qnames = (MAP_ANYURI_TO_URI_VALUE == null) ? new QName[10] : new QName[9];
/*      */     
/*  214 */     STRING = new StringImplImpl(String.class, qnames);
/*      */     
/*  216 */     ArrayList<RuntimeBuiltinLeafInfoImpl<?>> secondaryList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  234 */     secondaryList.add(new StringImpl<Character>(Character.class, new QName[] {
/*  235 */             createXS("unsignedShort")
/*      */           })
/*      */         {
/*      */           public Character parse(CharSequence text)
/*      */           {
/*  240 */             return Character.valueOf((char)DatatypeConverterImpl._parseInt(text));
/*      */           }
/*      */           
/*      */           public String print(Character v) {
/*  244 */             return Integer.toString(v.charValue());
/*      */           }
/*      */         });
/*  247 */     secondaryList.add(new StringImpl<Calendar>(Calendar.class, new QName[] { DatatypeConstants.DATETIME })
/*      */         {
/*      */           
/*      */           public Calendar parse(CharSequence text)
/*      */           {
/*  252 */             return DatatypeConverterImpl._parseDateTime(text.toString());
/*      */           }
/*      */ 
/*      */           
/*      */           public String print(Calendar v) {
/*  257 */             return DatatypeConverterImpl._printDateTime(v);
/*      */           }
/*      */         });
/*  260 */     secondaryList.add(new StringImpl<GregorianCalendar>(GregorianCalendar.class, new QName[] { DatatypeConstants.DATETIME })
/*      */         {
/*      */           
/*      */           public GregorianCalendar parse(CharSequence text)
/*      */           {
/*  265 */             return DatatypeConverterImpl._parseDateTime(text.toString());
/*      */           }
/*      */ 
/*      */           
/*      */           public String print(GregorianCalendar v) {
/*  270 */             return DatatypeConverterImpl._printDateTime(v);
/*      */           }
/*      */         });
/*  273 */     secondaryList.add(new StringImpl<Date>(Date.class, new QName[] { DatatypeConstants.DATETIME })
/*      */         {
/*      */           
/*      */           public Date parse(CharSequence text)
/*      */           {
/*  278 */             return DatatypeConverterImpl._parseDateTime(text.toString()).getTime();
/*      */           }
/*      */ 
/*      */           
/*      */           public String print(Date v) {
/*  283 */             XMLSerializer xs = XMLSerializer.getInstance();
/*  284 */             QName type = xs.getSchemaType();
/*  285 */             GregorianCalendar cal = new GregorianCalendar(0, 0, 0);
/*  286 */             cal.setTime(v);
/*  287 */             if (type != null && "http://www.w3.org/2001/XMLSchema".equals(type.getNamespaceURI()) && "date"
/*  288 */               .equals(type.getLocalPart())) {
/*  289 */               return DatatypeConverterImpl._printDate(cal);
/*      */             }
/*  291 */             return DatatypeConverterImpl._printDateTime(cal);
/*      */           }
/*      */         });
/*      */     
/*  295 */     secondaryList.add(new StringImpl<File>(File.class, new QName[] {
/*  296 */             createXS("string")
/*      */           }) {
/*      */           public File parse(CharSequence text) {
/*  299 */             return new File(WhiteSpaceProcessor.trim(text).toString());
/*      */           }
/*      */           
/*      */           public String print(File v) {
/*  303 */             return v.getPath();
/*      */           }
/*      */         });
/*  306 */     secondaryList.add(new StringImpl<URL>(URL.class, new QName[] {
/*  307 */             createXS("anyURI")
/*      */           }) {
/*      */           public URL parse(CharSequence text) throws SAXException {
/*  310 */             TODO.checkSpec("JSR222 Issue #42");
/*      */             try {
/*  312 */               return new URL(WhiteSpaceProcessor.trim(text).toString());
/*  313 */             } catch (MalformedURLException e) {
/*  314 */               UnmarshallingContext.getInstance().handleError(e);
/*  315 */               return null;
/*      */             } 
/*      */           }
/*      */           
/*      */           public String print(URL v) {
/*  320 */             return v.toExternalForm();
/*      */           }
/*      */         });
/*  323 */     if (MAP_ANYURI_TO_URI_VALUE == null) {
/*  324 */       secondaryList.add(new StringImpl<URI>(URI.class, new QName[] {
/*  325 */               createXS("string")
/*      */             }) {
/*      */             public URI parse(CharSequence text) throws SAXException {
/*      */               try {
/*  329 */                 return new URI(text.toString());
/*  330 */               } catch (URISyntaxException e) {
/*  331 */                 UnmarshallingContext.getInstance().handleError(e);
/*  332 */                 return null;
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public String print(URI v) {
/*  338 */               return v.toString();
/*      */             }
/*      */           });
/*      */     }
/*  342 */     secondaryList.add(new StringImpl<Class>(Class.class, new QName[] {
/*  343 */             createXS("string")
/*      */           }) {
/*      */           public Class parse(CharSequence text) throws SAXException {
/*  346 */             TODO.checkSpec("JSR222 Issue #42");
/*      */             try {
/*  348 */               String name = WhiteSpaceProcessor.trim(text).toString();
/*  349 */               ClassLoader cl = (UnmarshallingContext.getInstance()).classLoader;
/*  350 */               if (cl == null) {
/*  351 */                 cl = Thread.currentThread().getContextClassLoader();
/*      */               }
/*  353 */               if (cl != null) {
/*  354 */                 return cl.loadClass(name);
/*      */               }
/*  356 */               return Class.forName(name);
/*  357 */             } catch (ClassNotFoundException e) {
/*  358 */               UnmarshallingContext.getInstance().handleError(e);
/*  359 */               return null;
/*      */             } 
/*      */           }
/*      */           
/*      */           public String print(Class v) {
/*  364 */             return v.getName();
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  372 */     secondaryList.add(new PcdataImpl<Image>(Image.class, new QName[] {
/*  373 */             createXS("base64Binary")
/*      */           }) {
/*      */           public Image parse(CharSequence text) throws SAXException {
/*      */             try {
/*      */               InputStream is;
/*  378 */               if (text instanceof Base64Data) {
/*  379 */                 is = ((Base64Data)text).getInputStream();
/*      */               } else {
/*  381 */                 is = new ByteArrayInputStream(RuntimeBuiltinLeafInfoImpl.decodeBase64(text));
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/*  388 */                 return ImageIO.read(is);
/*      */               } finally {
/*  390 */                 is.close();
/*      */               } 
/*  392 */             } catch (IOException e) {
/*  393 */               UnmarshallingContext.getInstance().handleError(e);
/*  394 */               return null;
/*      */             } 
/*      */           }
/*      */           
/*      */           private BufferedImage convertToBufferedImage(Image image) throws IOException {
/*  399 */             if (image instanceof BufferedImage) {
/*  400 */               return (BufferedImage)image;
/*      */             }
/*      */             
/*  403 */             MediaTracker tracker = new MediaTracker(new Component() {  });
/*  404 */             tracker.addImage(image, 0);
/*      */             try {
/*  406 */               tracker.waitForAll();
/*  407 */             } catch (InterruptedException e) {
/*  408 */               throw new IOException(e.getMessage());
/*      */             } 
/*      */ 
/*      */             
/*  412 */             BufferedImage bufImage = new BufferedImage(image.getWidth(null), image.getHeight(null), 2);
/*      */ 
/*      */             
/*  415 */             Graphics g = bufImage.createGraphics();
/*  416 */             g.drawImage(image, 0, 0, null);
/*  417 */             return bufImage;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public Base64Data print(Image v) {
/*  423 */             ByteArrayOutputStreamEx imageData = new ByteArrayOutputStreamEx();
/*  424 */             XMLSerializer xs = XMLSerializer.getInstance();
/*      */             
/*  426 */             String mimeType = xs.getXMIMEContentType();
/*  427 */             if (mimeType == null || mimeType.startsWith("image/*"))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  433 */               mimeType = "image/png";
/*      */             }
/*      */             try {
/*  436 */               Iterator<ImageWriter> itr = ImageIO.getImageWritersByMIMEType(mimeType);
/*  437 */               if (itr.hasNext()) {
/*  438 */                 ImageWriter w = itr.next();
/*  439 */                 ImageOutputStream os = ImageIO.createImageOutputStream(imageData);
/*  440 */                 w.setOutput(os);
/*  441 */                 w.write(convertToBufferedImage(v));
/*  442 */                 os.close();
/*  443 */                 w.dispose();
/*      */               } else {
/*      */                 
/*  446 */                 xs.handleEvent((ValidationEvent)new ValidationEventImpl(1, Messages.NO_IMAGE_WRITER
/*      */                       
/*  448 */                       .format(new Object[] { mimeType }, ), xs
/*  449 */                       .getCurrentLocation(null)));
/*      */                 
/*  451 */                 throw new RuntimeException("no encoder for MIME type " + mimeType);
/*      */               } 
/*  453 */             } catch (IOException e) {
/*  454 */               xs.handleError(e);
/*      */               
/*  456 */               throw new RuntimeException(e);
/*      */             } 
/*  458 */             Base64Data bd = new Base64Data();
/*  459 */             imageData.set(bd, mimeType);
/*  460 */             return bd;
/*      */           }
/*      */         });
/*  463 */     secondaryList.add(new PcdataImpl<DataHandler>(DataHandler.class, new QName[] {
/*  464 */             createXS("base64Binary")
/*      */           }) {
/*      */           public DataHandler parse(CharSequence text) {
/*  467 */             if (text instanceof Base64Data) {
/*  468 */               return ((Base64Data)text).getDataHandler();
/*      */             }
/*  470 */             return new DataHandler((DataSource)new ByteArrayDataSource(RuntimeBuiltinLeafInfoImpl.decodeBase64(text), 
/*  471 */                   UnmarshallingContext.getInstance().getXMIMEContentType()));
/*      */           }
/*      */ 
/*      */           
/*      */           public Base64Data print(DataHandler v) {
/*  476 */             Base64Data bd = new Base64Data();
/*  477 */             bd.set(v);
/*  478 */             return bd;
/*      */           }
/*      */         });
/*  481 */     secondaryList.add(new PcdataImpl<Source>(Source.class, new QName[] {
/*  482 */             createXS("base64Binary")
/*      */           }) {
/*      */           public Source parse(CharSequence text) throws SAXException {
/*      */             try {
/*  486 */               if (text instanceof Base64Data) {
/*  487 */                 return (Source)new DataSourceSource(((Base64Data)text).getDataHandler());
/*      */               }
/*  489 */               return (Source)new DataSourceSource((DataSource)new ByteArrayDataSource(RuntimeBuiltinLeafInfoImpl.decodeBase64(text), 
/*  490 */                     UnmarshallingContext.getInstance().getXMIMEContentType()));
/*  491 */             } catch (MimeTypeParseException e) {
/*  492 */               UnmarshallingContext.getInstance().handleError((Exception)e);
/*  493 */               return null;
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Base64Data print(Source v) {
/*  499 */             XMLSerializer xs = XMLSerializer.getInstance();
/*  500 */             Base64Data bd = new Base64Data();
/*      */             
/*  502 */             String contentType = xs.getXMIMEContentType();
/*  503 */             MimeType mt = null;
/*  504 */             if (contentType != null) {
/*      */               try {
/*  506 */                 mt = new MimeType(contentType);
/*  507 */               } catch (MimeTypeParseException e) {
/*  508 */                 xs.handleError((Exception)e);
/*      */               } 
/*      */             }
/*      */             
/*  512 */             if (v instanceof DataSourceSource) {
/*      */ 
/*      */               
/*  515 */               DataSource ds = ((DataSourceSource)v).getDataSource();
/*      */               
/*  517 */               String dsct = ds.getContentType();
/*  518 */               if (dsct != null && (contentType == null || contentType.equals(dsct))) {
/*  519 */                 bd.set(new DataHandler(ds));
/*  520 */                 return bd;
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  527 */             String charset = null;
/*  528 */             if (mt != null)
/*  529 */               charset = mt.getParameter("charset"); 
/*  530 */             if (charset == null) {
/*  531 */               charset = "UTF-8";
/*      */             }
/*      */             try {
/*  534 */               ByteArrayOutputStreamEx baos = new ByteArrayOutputStreamEx();
/*  535 */               Transformer tr = xs.getIdentityTransformer();
/*  536 */               String defaultEncoding = tr.getOutputProperty("encoding");
/*  537 */               tr.setOutputProperty("encoding", charset);
/*  538 */               tr.transform(v, new StreamResult(new OutputStreamWriter((OutputStream)baos, charset)));
/*  539 */               tr.setOutputProperty("encoding", defaultEncoding);
/*  540 */               baos.set(bd, "application/xml; charset=" + charset);
/*  541 */               return bd;
/*  542 */             } catch (TransformerException e) {
/*      */               
/*  544 */               xs.handleError(e);
/*  545 */             } catch (UnsupportedEncodingException e) {
/*  546 */               xs.handleError(e);
/*      */             } 
/*      */ 
/*      */             
/*  550 */             bd.set(new byte[0], "application/xml");
/*  551 */             return bd;
/*      */           }
/*      */         });
/*  554 */     secondaryList.add(new StringImpl<XMLGregorianCalendar>(XMLGregorianCalendar.class, new QName[] {
/*      */             
/*  556 */             createXS("anySimpleType"), DatatypeConstants.DATE, DatatypeConstants.DATETIME, DatatypeConstants.TIME, DatatypeConstants.GMONTH, DatatypeConstants.GDAY, DatatypeConstants.GYEAR, DatatypeConstants.GYEARMONTH, DatatypeConstants.GMONTHDAY
/*      */           })
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(XMLGregorianCalendar cal)
/*      */           {
/*  568 */             XMLSerializer xs = XMLSerializer.getInstance();
/*      */             
/*  570 */             QName type = xs.getSchemaType();
/*  571 */             if (type != null) {
/*      */               try {
/*  573 */                 RuntimeBuiltinLeafInfoImpl.checkXmlGregorianCalendarFieldRef(type, cal);
/*  574 */                 String format = RuntimeBuiltinLeafInfoImpl.xmlGregorianCalendarFormatString.get(type);
/*  575 */                 if (format != null) {
/*  576 */                   return format(format, cal);
/*      */                 }
/*  578 */               } catch (MarshalException e) {
/*      */                 
/*  580 */                 xs.handleEvent((ValidationEvent)new ValidationEventImpl(0, e.getMessage(), xs
/*  581 */                       .getCurrentLocation(null)));
/*  582 */                 return "";
/*      */               } 
/*      */             }
/*  585 */             return cal.toXMLFormat();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public XMLGregorianCalendar parse(CharSequence lexical) throws SAXException {
/*      */             try {
/*  592 */               return DatatypeConverterImpl.getDatatypeFactory()
/*  593 */                 .newXMLGregorianCalendar(lexical.toString().trim());
/*  594 */             } catch (Exception e) {
/*  595 */               UnmarshallingContext.getInstance().handleError(e);
/*  596 */               return null;
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           private String format(String format, XMLGregorianCalendar value) {
/*  602 */             StringBuilder buf = new StringBuilder();
/*  603 */             int fidx = 0, flen = format.length();
/*      */             
/*  605 */             while (fidx < flen) {
/*  606 */               int offset; char fch = format.charAt(fidx++);
/*  607 */               if (fch != '%') {
/*  608 */                 buf.append(fch);
/*      */                 
/*      */                 continue;
/*      */               } 
/*  612 */               switch (format.charAt(fidx++)) {
/*      */                 case 'Y':
/*  614 */                   printNumber(buf, value.getEonAndYear(), 4);
/*      */                   continue;
/*      */                 case 'M':
/*  617 */                   printNumber(buf, value.getMonth(), 2);
/*      */                   continue;
/*      */                 case 'D':
/*  620 */                   printNumber(buf, value.getDay(), 2);
/*      */                   continue;
/*      */                 case 'h':
/*  623 */                   printNumber(buf, value.getHour(), 2);
/*      */                   continue;
/*      */                 case 'm':
/*  626 */                   printNumber(buf, value.getMinute(), 2);
/*      */                   continue;
/*      */                 case 's':
/*  629 */                   printNumber(buf, value.getSecond(), 2);
/*  630 */                   if (value.getFractionalSecond() != null) {
/*  631 */                     String frac = value.getFractionalSecond().toPlainString();
/*      */                     
/*  633 */                     buf.append(frac.substring(1));
/*      */                   } 
/*      */                   continue;
/*      */                 case 'z':
/*  637 */                   offset = value.getTimezone();
/*  638 */                   if (offset == 0) {
/*  639 */                     buf.append('Z'); continue;
/*  640 */                   }  if (offset != Integer.MIN_VALUE) {
/*  641 */                     if (offset < 0) {
/*  642 */                       buf.append('-');
/*  643 */                       offset *= -1;
/*      */                     } else {
/*  645 */                       buf.append('+');
/*      */                     } 
/*  647 */                     printNumber(buf, offset / 60, 2);
/*  648 */                     buf.append(':');
/*  649 */                     printNumber(buf, offset % 60, 2);
/*      */                   } 
/*      */                   continue;
/*      */               } 
/*  653 */               throw new InternalError();
/*      */             } 
/*      */ 
/*      */             
/*  657 */             return buf.toString();
/*      */           }
/*      */           private void printNumber(StringBuilder out, BigInteger number, int nDigits) {
/*  660 */             String s = number.toString();
/*  661 */             for (int i = s.length(); i < nDigits; i++)
/*  662 */               out.append('0'); 
/*  663 */             out.append(s);
/*      */           }
/*      */           private void printNumber(StringBuilder out, int number, int nDigits) {
/*  666 */             String s = String.valueOf(number);
/*  667 */             for (int i = s.length(); i < nDigits; i++)
/*  668 */               out.append('0'); 
/*  669 */             out.append(s);
/*      */           }
/*      */           
/*      */           public QName getTypeName(XMLGregorianCalendar cal) {
/*  673 */             return cal.getXMLSchemaType();
/*      */           }
/*      */         });
/*      */     
/*  677 */     ArrayList<RuntimeBuiltinLeafInfoImpl<?>> primaryList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  682 */     primaryList.add(STRING);
/*  683 */     primaryList.add(new StringImpl<Boolean>(Boolean.class, new QName[] {
/*  684 */             createXS("boolean")
/*      */           })
/*      */         {
/*      */           public Boolean parse(CharSequence text)
/*      */           {
/*  689 */             return DatatypeConverterImpl._parseBoolean(text);
/*      */           }
/*      */ 
/*      */           
/*      */           public String print(Boolean v) {
/*  694 */             return v.toString();
/*      */           }
/*      */         });
/*  697 */     primaryList.add(new PcdataImpl<byte[]>(byte[].class, new QName[] {
/*  698 */             createXS("base64Binary"), 
/*  699 */             createXS("hexBinary")
/*      */           })
/*      */         {
/*      */           public byte[] parse(CharSequence text) {
/*  703 */             return RuntimeBuiltinLeafInfoImpl.decodeBase64(text);
/*      */           }
/*      */ 
/*      */           
/*      */           public Base64Data print(byte[] v) {
/*  708 */             XMLSerializer w = XMLSerializer.getInstance();
/*  709 */             Base64Data bd = new Base64Data();
/*  710 */             String mimeType = w.getXMIMEContentType();
/*  711 */             bd.set(v, mimeType);
/*  712 */             return bd;
/*      */           }
/*      */         });
/*  715 */     primaryList.add(new StringImpl<Byte>(Byte.class, new QName[] {
/*  716 */             createXS("byte")
/*      */           })
/*      */         {
/*      */           public Byte parse(CharSequence text)
/*      */           {
/*  721 */             return Byte.valueOf(DatatypeConverterImpl._parseByte(text));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Byte v) {
/*  727 */             return DatatypeConverterImpl._printByte(v.byteValue());
/*      */           }
/*      */         });
/*  730 */     primaryList.add(new StringImpl<Short>(Short.class, new QName[] {
/*  731 */             createXS("short"), 
/*  732 */             createXS("unsignedByte")
/*      */           })
/*      */         {
/*      */           public Short parse(CharSequence text)
/*      */           {
/*  737 */             return Short.valueOf(DatatypeConverterImpl._parseShort(text));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Short v) {
/*  743 */             return DatatypeConverterImpl._printShort(v.shortValue());
/*      */           }
/*      */         });
/*  746 */     primaryList.add(new StringImpl<Integer>(Integer.class, new QName[] {
/*  747 */             createXS("int"), 
/*  748 */             createXS("unsignedShort")
/*      */           })
/*      */         {
/*      */           public Integer parse(CharSequence text)
/*      */           {
/*  753 */             return Integer.valueOf(DatatypeConverterImpl._parseInt(text));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Integer v) {
/*  759 */             return DatatypeConverterImpl._printInt(v.intValue());
/*      */           }
/*      */         });
/*  762 */     primaryList.add(new StringImpl<Long>(Long.class, new QName[] {
/*      */             
/*  764 */             createXS("long"), 
/*  765 */             createXS("unsignedInt")
/*      */           })
/*      */         {
/*      */           public Long parse(CharSequence text)
/*      */           {
/*  770 */             return Long.valueOf(DatatypeConverterImpl._parseLong(text));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Long v) {
/*  776 */             return DatatypeConverterImpl._printLong(v.longValue());
/*      */           }
/*      */         });
/*  779 */     primaryList.add(new StringImpl<Float>(Float.class, new QName[] {
/*      */             
/*  781 */             createXS("float")
/*      */           })
/*      */         {
/*      */           public Float parse(CharSequence text)
/*      */           {
/*  786 */             return Float.valueOf(DatatypeConverterImpl._parseFloat(text.toString()));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Float v) {
/*  792 */             return DatatypeConverterImpl._printFloat(v.floatValue());
/*      */           }
/*      */         });
/*  795 */     primaryList.add(new StringImpl<Double>(Double.class, new QName[] {
/*      */             
/*  797 */             createXS("double")
/*      */           })
/*      */         {
/*      */           public Double parse(CharSequence text)
/*      */           {
/*  802 */             return Double.valueOf(DatatypeConverterImpl._parseDouble(text));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Double v) {
/*  808 */             return DatatypeConverterImpl._printDouble(v.doubleValue());
/*      */           }
/*      */         });
/*  811 */     primaryList.add(new StringImpl<BigInteger>(BigInteger.class, new QName[] {
/*      */             
/*  813 */             createXS("integer"), 
/*  814 */             createXS("positiveInteger"), 
/*  815 */             createXS("negativeInteger"), 
/*  816 */             createXS("nonPositiveInteger"), 
/*  817 */             createXS("nonNegativeInteger"), 
/*  818 */             createXS("unsignedLong")
/*      */           })
/*      */         {
/*      */           public BigInteger parse(CharSequence text)
/*      */           {
/*  823 */             return DatatypeConverterImpl._parseInteger(text);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(BigInteger v) {
/*  829 */             return DatatypeConverterImpl._printInteger(v);
/*      */           }
/*      */         });
/*  832 */     primaryList.add(new StringImpl<BigDecimal>(BigDecimal.class, new QName[] {
/*      */             
/*  834 */             createXS("decimal")
/*      */           })
/*      */         {
/*      */           public BigDecimal parse(CharSequence text)
/*      */           {
/*  839 */             return DatatypeConverterImpl._parseDecimal(text.toString());
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(BigDecimal v) {
/*  845 */             return DatatypeConverterImpl._printDecimal(v);
/*      */           }
/*      */         });
/*      */     
/*  849 */     primaryList.add(new StringImpl<QName>(QName.class, new QName[] {
/*      */             
/*  851 */             createXS("QName")
/*      */           })
/*      */         {
/*      */           public QName parse(CharSequence text) throws SAXException
/*      */           {
/*      */             try {
/*  857 */               return DatatypeConverterImpl._parseQName(text.toString(), (NamespaceContext)UnmarshallingContext.getInstance());
/*  858 */             } catch (IllegalArgumentException e) {
/*  859 */               UnmarshallingContext.getInstance().handleError(e);
/*  860 */               return null;
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(QName v) {
/*  867 */             return DatatypeConverterImpl._printQName(v, (NamespaceContext)XMLSerializer.getInstance().getNamespaceContext());
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean useNamespace() {
/*  872 */             return true;
/*      */           }
/*      */ 
/*      */           
/*      */           public void declareNamespace(QName v, XMLSerializer w) {
/*  877 */             w.getNamespaceContext().declareNamespace(v.getNamespaceURI(), v.getPrefix(), false);
/*      */           }
/*      */         });
/*  880 */     if (MAP_ANYURI_TO_URI_VALUE != null) {
/*  881 */       primaryList.add(new StringImpl<URI>(URI.class, new QName[] {
/*  882 */               createXS("anyURI")
/*      */             }) {
/*      */             public URI parse(CharSequence text) throws SAXException {
/*      */               try {
/*  886 */                 return new URI(text.toString());
/*  887 */               } catch (URISyntaxException e) {
/*  888 */                 UnmarshallingContext.getInstance().handleError(e);
/*  889 */                 return null;
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public String print(URI v) {
/*  895 */               return v.toString();
/*      */             }
/*      */           });
/*      */     }
/*  899 */     primaryList.add(new StringImpl<Duration>(Duration.class, new QName[] {
/*  900 */             createXS("duration")
/*      */           }) {
/*      */           public String print(Duration duration) {
/*  903 */             return duration.toString();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public Duration parse(CharSequence lexical) {
/*  909 */             TODO.checkSpec("JSR222 Issue #42");
/*  910 */             return DatatypeConverterImpl.getDatatypeFactory().newDuration(lexical.toString());
/*      */           }
/*      */         });
/*      */     
/*  914 */     primaryList.add(new StringImpl<Void>(Void.class, new QName[0])
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public String print(Void value)
/*      */           {
/*  921 */             return "";
/*      */           }
/*      */ 
/*      */           
/*      */           public Void parse(CharSequence lexical) {
/*  926 */             return null;
/*      */           }
/*      */         });
/*      */     
/*  930 */     List<RuntimeBuiltinLeafInfoImpl<?>> l = new ArrayList<>(secondaryList.size() + primaryList.size() + 1);
/*  931 */     l.addAll(secondaryList);
/*      */ 
/*      */     
/*      */     try {
/*  935 */       l.add(new UUIDImpl());
/*  936 */     } catch (LinkageError linkageError) {}
/*      */ 
/*      */ 
/*      */     
/*  940 */     l.addAll(primaryList);
/*      */     
/*  942 */     builtinBeanInfos = Collections.unmodifiableList(l);
/*      */   }
/*      */ 
/*      */   
/*      */   private static byte[] decodeBase64(CharSequence text) {
/*  947 */     if (text instanceof Base64Data) {
/*  948 */       Base64Data base64Data = (Base64Data)text;
/*  949 */       return base64Data.getExact();
/*      */     } 
/*  951 */     return DatatypeConverterImpl._parseBase64Binary(text.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkXmlGregorianCalendarFieldRef(QName type, XMLGregorianCalendar cal) throws MarshalException {
/*  957 */     StringBuilder buf = new StringBuilder();
/*  958 */     int bitField = ((Integer)xmlGregorianCalendarFieldRef.get(type)).intValue();
/*  959 */     int l = 1;
/*  960 */     int pos = 0;
/*  961 */     while (bitField != 0) {
/*  962 */       int bit = bitField & 0x1;
/*  963 */       bitField >>>= 4;
/*  964 */       pos++;
/*      */       
/*  966 */       if (bit == 1) {
/*  967 */         switch (pos) {
/*      */           case 1:
/*  969 */             if (cal.getSecond() == Integer.MIN_VALUE) {
/*  970 */               buf.append("  ").append(Messages.XMLGREGORIANCALENDAR_SEC);
/*      */             }
/*      */           
/*      */           case 2:
/*  974 */             if (cal.getMinute() == Integer.MIN_VALUE) {
/*  975 */               buf.append("  ").append(Messages.XMLGREGORIANCALENDAR_MIN);
/*      */             }
/*      */           
/*      */           case 3:
/*  979 */             if (cal.getHour() == Integer.MIN_VALUE) {
/*  980 */               buf.append("  ").append(Messages.XMLGREGORIANCALENDAR_HR);
/*      */             }
/*      */           
/*      */           case 4:
/*  984 */             if (cal.getDay() == Integer.MIN_VALUE) {
/*  985 */               buf.append("  ").append(Messages.XMLGREGORIANCALENDAR_DAY);
/*      */             }
/*      */           
/*      */           case 5:
/*  989 */             if (cal.getMonth() == Integer.MIN_VALUE) {
/*  990 */               buf.append("  ").append(Messages.XMLGREGORIANCALENDAR_MONTH);
/*      */             }
/*      */           
/*      */           case 6:
/*  994 */             if (cal.getYear() == Integer.MIN_VALUE) {
/*  995 */               buf.append("  ").append(Messages.XMLGREGORIANCALENDAR_YEAR);
/*      */             }
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */     } 
/* 1003 */     if (buf.length() > 0) {
/* 1004 */       throw new MarshalException(Messages.XMLGREGORIANCALENDAR_INVALID
/* 1005 */           .format(new Object[] { type.getLocalPart() }) + Messages.XMLGREGORIANCALENDAR_INVALID.format(new Object[] { type.getLocalPart() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1013 */   private static final Map<QName, String> xmlGregorianCalendarFormatString = new HashMap<>();
/*      */   
/*      */   static {
/* 1016 */     Map<QName, String> m = xmlGregorianCalendarFormatString;
/*      */     
/* 1018 */     m.put(DatatypeConstants.DATETIME, "%Y-%M-%DT%h:%m:%s%z");
/* 1019 */     m.put(DatatypeConstants.DATE, "%Y-%M-%D%z");
/* 1020 */     m.put(DatatypeConstants.TIME, "%h:%m:%s%z");
/* 1021 */     String oldGmonthMappingProperty = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*      */         {
/*      */           public String run() {
/* 1024 */             return System.getProperty("jaxb.ri.useOldGmonthMapping");
/*      */           }
/*      */         });
/* 1027 */     if (oldGmonthMappingProperty == null) {
/* 1028 */       m.put(DatatypeConstants.GMONTH, "--%M%z");
/*      */     } else {
/* 1030 */       if (logger.isLoggable(Level.FINE)) {
/* 1031 */         logger.log(Level.FINE, "Old GMonth mapping used.");
/*      */       }
/* 1033 */       m.put(DatatypeConstants.GMONTH, "--%M--%z");
/*      */     } 
/* 1035 */     m.put(DatatypeConstants.GDAY, "---%D%z");
/* 1036 */     m.put(DatatypeConstants.GYEAR, "%Y%z");
/* 1037 */     m.put(DatatypeConstants.GYEARMONTH, "%Y-%M%z");
/* 1038 */     m.put(DatatypeConstants.GMONTHDAY, "--%M-%D%z");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1051 */   private static final Map<QName, Integer> xmlGregorianCalendarFieldRef = new HashMap<>();
/*      */   
/*      */   static {
/* 1054 */     Map<QName, Integer> f = xmlGregorianCalendarFieldRef;
/* 1055 */     f.put(DatatypeConstants.DATETIME, Integer.valueOf(17895697));
/* 1056 */     f.put(DatatypeConstants.DATE, Integer.valueOf(17895424));
/* 1057 */     f.put(DatatypeConstants.TIME, Integer.valueOf(16777489));
/* 1058 */     f.put(DatatypeConstants.GDAY, Integer.valueOf(16781312));
/* 1059 */     f.put(DatatypeConstants.GMONTH, Integer.valueOf(16842752));
/* 1060 */     f.put(DatatypeConstants.GYEAR, Integer.valueOf(17825792));
/* 1061 */     f.put(DatatypeConstants.GYEARMONTH, Integer.valueOf(17891328));
/* 1062 */     f.put(DatatypeConstants.GMONTHDAY, Integer.valueOf(16846848));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class UUIDImpl
/*      */     extends StringImpl<UUID>
/*      */   {
/*      */     public UUIDImpl() {
/* 1072 */       super(UUID.class, new QName[] { RuntimeBuiltinLeafInfoImpl.createXS("string") });
/*      */     }
/*      */ 
/*      */     
/*      */     public UUID parse(CharSequence text) throws SAXException {
/* 1077 */       TODO.checkSpec("JSR222 Issue #42");
/*      */       try {
/* 1079 */         return UUID.fromString(WhiteSpaceProcessor.trim(text).toString());
/* 1080 */       } catch (IllegalArgumentException e) {
/* 1081 */         UnmarshallingContext.getInstance().handleError(e);
/* 1082 */         return null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public String print(UUID v) {
/* 1088 */       return v.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StringImplImpl
/*      */     extends StringImpl<String> {
/*      */     public StringImplImpl(Class<String> type, QName[] typeNames) {
/* 1095 */       super(type, typeNames);
/*      */     }
/*      */ 
/*      */     
/*      */     public String parse(CharSequence text) {
/* 1100 */       return text.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public String print(String s) {
/* 1105 */       return s;
/*      */     }
/*      */ 
/*      */     
/*      */     public final void writeText(XMLSerializer w, String o, String fieldName) throws IOException, SAXException, XMLStreamException {
/* 1110 */       w.text(o, fieldName);
/*      */     }
/*      */ 
/*      */     
/*      */     public final void writeLeafElement(XMLSerializer w, Name tagName, String o, String fieldName) throws IOException, SAXException, XMLStreamException {
/* 1115 */       w.leafElement(tagName, o, fieldName);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\impl\RuntimeBuiltinLeafInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */