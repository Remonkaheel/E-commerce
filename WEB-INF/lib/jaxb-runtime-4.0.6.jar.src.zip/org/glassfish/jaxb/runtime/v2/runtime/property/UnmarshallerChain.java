/*    */ package org.glassfish.jaxb.runtime.v2.runtime.property;
/*    */ 
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnmarshallerChain
/*    */ {
/* 33 */   private int offset = 0;
/*    */   
/*    */   public final JAXBContextImpl context;
/*    */   
/*    */   public UnmarshallerChain(JAXBContextImpl context) {
/* 38 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int allocateOffset() {
/* 45 */     return this.offset++;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getScopeSize() {
/* 52 */     return this.offset;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\property\UnmarshallerChain.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */