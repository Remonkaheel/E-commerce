/*     */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.glassfish.jaxb.core.Utils;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.ClassBeanInfoImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JAXBContextImpl;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.JaxBeanInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.AttributeProperty;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.Property;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.StructureLoaderBuilder;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.UnmarshallerChain;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.TransducedAccessor;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StructureLoader
/*     */   extends Loader
/*     */ {
/*  52 */   private final QNameMap<ChildLoader> childUnmarshallers = new QNameMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChildLoader catchAll;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChildLoader textHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QNameMap<TransducedAccessor> attUnmarshallers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Accessor<Object, Map<QName, String>> attCatchAll;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JaxBeanInfo beanInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int frameSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructureLoader(ClassBeanInfoImpl beanInfo) {
/*  88 */     super(true);
/*  89 */     this.beanInfo = (JaxBeanInfo)beanInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(JAXBContextImpl context, ClassBeanInfoImpl beanInfo, Accessor<?, Map<QName, String>> attWildcard) {
/* 100 */     UnmarshallerChain chain = new UnmarshallerChain(context);
/* 101 */     for (ClassBeanInfoImpl bi = beanInfo; bi != null; bi = bi.superClazz) {
/* 102 */       for (int i = bi.properties.length - 1; i >= 0; i--) {
/* 103 */         AttributeProperty ap; Property p = bi.properties[i];
/*     */         
/* 105 */         switch (p.getKind()) {
/*     */           case ATTRIBUTE:
/* 107 */             if (this.attUnmarshallers == null)
/* 108 */               this.attUnmarshallers = new QNameMap(); 
/* 109 */             ap = (AttributeProperty)p;
/* 110 */             this.attUnmarshallers.put(ap.attName.toQName(), ap.xacc);
/*     */             break;
/*     */           case ELEMENT:
/*     */           case REFERENCE:
/*     */           case MAP:
/*     */           case VALUE:
/* 116 */             p.buildChildElementUnmarshallers(chain, this.childUnmarshallers);
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 122 */     this.frameSize = chain.getScopeSize();
/*     */     
/* 124 */     this.textHandler = (ChildLoader)this.childUnmarshallers.get(StructureLoaderBuilder.TEXT_HANDLER);
/* 125 */     this.catchAll = (ChildLoader)this.childUnmarshallers.get(StructureLoaderBuilder.CATCH_ALL);
/*     */     
/* 127 */     if (attWildcard != null) {
/* 128 */       this.attCatchAll = (Accessor)attWildcard;
/*     */ 
/*     */       
/* 131 */       if (this.attUnmarshallers == null)
/* 132 */         this.attUnmarshallers = EMPTY; 
/*     */     } else {
/* 134 */       this.attCatchAll = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 140 */     UnmarshallingContext context = state.getContext();
/*     */ 
/*     */ 
/*     */     
/* 144 */     assert !this.beanInfo.isImmutable();
/*     */ 
/*     */     
/* 147 */     Object child = context.getInnerPeer();
/*     */     
/* 149 */     if (child != null && this.beanInfo.jaxbType != child.getClass()) {
/* 150 */       child = null;
/*     */     }
/* 152 */     if (child != null) {
/* 153 */       this.beanInfo.reset(child, context);
/*     */     }
/* 155 */     if (child == null) {
/* 156 */       child = context.createInstance(this.beanInfo);
/*     */     }
/* 158 */     context.recordInnerPeer(child);
/*     */     
/* 160 */     state.setTarget(child);
/*     */     
/* 162 */     fireBeforeUnmarshal(this.beanInfo, child, state);
/*     */ 
/*     */     
/* 165 */     context.startScope(this.frameSize);
/*     */     
/* 167 */     if (this.attUnmarshallers != null) {
/* 168 */       Attributes atts = ea.atts;
/* 169 */       for (int i = 0; i < atts.getLength(); i++) {
/* 170 */         String auri = atts.getURI(i);
/*     */         
/* 172 */         String alocal = atts.getLocalName(i);
/* 173 */         if ("".equals(alocal)) {
/* 174 */           alocal = atts.getQName(i);
/*     */         }
/* 176 */         String avalue = atts.getValue(i);
/* 177 */         TransducedAccessor xacc = (TransducedAccessor)this.attUnmarshallers.get(auri, alocal);
/*     */         try {
/* 179 */           if (xacc != null) {
/* 180 */             xacc.parse(child, avalue);
/* 181 */           } else if (this.attCatchAll != null) {
/* 182 */             String qname = atts.getQName(i);
/* 183 */             if (!"http://www.w3.org/2001/XMLSchema-instance".equals(atts.getURI(i)))
/*     */             { String prefix;
/* 185 */               Object o = state.getTarget();
/* 186 */               Map<QName, String> map = (Map<QName, String>)this.attCatchAll.get(o);
/* 187 */               if (map == null) {
/*     */ 
/*     */ 
/*     */                 
/* 191 */                 if (this.attCatchAll.valueType.isAssignableFrom(HashMap.class)) {
/* 192 */                   map = new HashMap<>();
/*     */                 }
/*     */                 else {
/*     */                   
/* 196 */                   context.handleError(Messages.UNABLE_TO_CREATE_MAP.format(new Object[] { this.attCatchAll.valueType }));
/*     */                   return;
/*     */                 } 
/* 199 */                 this.attCatchAll.set(o, map);
/*     */               } 
/*     */ 
/*     */               
/* 203 */               int idx = qname.indexOf(':');
/* 204 */               if (idx < 0) { prefix = ""; }
/* 205 */               else { prefix = qname.substring(0, idx); }
/*     */               
/* 207 */               map.put(new QName(auri, alocal, prefix), avalue); } 
/*     */           } 
/* 209 */         } catch (AccessorException e) {
/* 210 */           handleGenericException((Exception)e, true);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void childElement(UnmarshallingContext.State state, TagName arg) throws SAXException {
/* 218 */     ChildLoader child = (ChildLoader)this.childUnmarshallers.get(arg.uri, arg.local);
/* 219 */     if (child == null) {
/* 220 */       Boolean backupWithParentNamespace = (state.getContext().getJAXBContext()).backupWithParentNamespace;
/* 221 */       backupWithParentNamespace = Boolean.valueOf((backupWithParentNamespace != null) ? 
/* 222 */           backupWithParentNamespace.booleanValue() : 
/* 223 */           Boolean.parseBoolean(Utils.getSystemProperty("org.glassfish.jaxb.backupWithParentNamespace")));
/* 224 */       if (this.beanInfo != null && this.beanInfo.getTypeNames() != null && backupWithParentNamespace.booleanValue()) {
/* 225 */         Iterator<?> typeNamesIt = this.beanInfo.getTypeNames().iterator();
/* 226 */         QName parentQName = null;
/* 227 */         if (typeNamesIt != null && typeNamesIt.hasNext() && this.catchAll == null) {
/* 228 */           parentQName = (QName)typeNamesIt.next();
/* 229 */           String parentUri = parentQName.getNamespaceURI();
/* 230 */           child = (ChildLoader)this.childUnmarshallers.get(parentUri, arg.local);
/*     */         } 
/*     */       } 
/* 233 */       if (child == null) {
/* 234 */         child = this.catchAll;
/* 235 */         if (child == null) {
/* 236 */           super.childElement(state, arg);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 242 */     state.setLoader(child.loader);
/* 243 */     state.setReceiver(child.receiver);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedChildElements() {
/* 248 */     return this.childUnmarshallers.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<QName> getExpectedAttributes() {
/* 253 */     return this.attUnmarshallers.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(UnmarshallingContext.State state, CharSequence text) throws SAXException {
/* 258 */     if (this.textHandler != null) {
/* 259 */       this.textHandler.loader.text(state, text);
/*     */     }
/*     */   }
/*     */   
/*     */   public void leaveElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 264 */     state.getContext().endScope(this.frameSize);
/* 265 */     fireAfterUnmarshal(this.beanInfo, state.getTarget(), state.getPrev());
/*     */   }
/*     */   
/* 268 */   private static final QNameMap<TransducedAccessor> EMPTY = new QNameMap();
/*     */   
/*     */   public JaxBeanInfo getBeanInfo() {
/* 271 */     return this.beanInfo;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\StructureLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */