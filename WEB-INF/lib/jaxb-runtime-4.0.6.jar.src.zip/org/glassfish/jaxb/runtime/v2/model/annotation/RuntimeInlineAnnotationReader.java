/*     */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RuntimeInlineAnnotationReader
/*     */   extends AbstractInlineAnnotationReaderImpl<Type, Class, Field, Method>
/*     */   implements RuntimeAnnotationReader
/*     */ {
/*     */   public <A extends Annotation> A getFieldAnnotation(Class<A> annotation, Field field, Locatable srcPos) {
/*  39 */     return LocatableAnnotation.create(field.getAnnotation(annotation), srcPos);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFieldAnnotation(Class<? extends Annotation> annotationType, Field field) {
/*  44 */     return field.isAnnotationPresent(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasClassAnnotation(Class clazz, Class<? extends Annotation> annotationType) {
/*  49 */     return clazz.isAnnotationPresent(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getAllFieldAnnotations(Field field, Locatable srcPos) {
/*  54 */     Annotation[] r = field.getAnnotations();
/*  55 */     for (int i = 0; i < r.length; i++) {
/*  56 */       r[i] = LocatableAnnotation.create(r[i], srcPos);
/*     */     }
/*  58 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotation, Method method, Locatable srcPos) {
/*  63 */     return LocatableAnnotation.create(method.getAnnotation(annotation), srcPos);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMethodAnnotation(Class<? extends Annotation> annotation, Method method) {
/*  68 */     return method.isAnnotationPresent(annotation);
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getAllMethodAnnotations(Method method, Locatable srcPos) {
/*  73 */     Annotation[] r = method.getAnnotations();
/*  74 */     for (int i = 0; i < r.length; i++) {
/*  75 */       r[i] = LocatableAnnotation.create(r[i], srcPos);
/*     */     }
/*  77 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getMethodParameterAnnotation(Class<A> annotation, Method method, int paramIndex, Locatable srcPos) {
/*  82 */     Annotation[] pa = method.getParameterAnnotations()[paramIndex];
/*  83 */     for (Annotation a : pa) {
/*  84 */       if (a.annotationType() == annotation)
/*  85 */         return LocatableAnnotation.create((A)a, srcPos); 
/*     */     } 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getClassAnnotation(Class<A> a, Class clazz, Locatable srcPos) {
/*  92 */     return LocatableAnnotation.create((A)clazz.getAnnotation(a), srcPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private final Map<Class<? extends Annotation>, Map<Package, Annotation>> packageCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getPackageAnnotation(Class<A> a, Class clazz, Locatable srcPos) {
/* 104 */     Package p = clazz.getPackage();
/* 105 */     if (p == null) return null;
/*     */     
/* 107 */     Map<Package, Annotation> cache = this.packageCache.computeIfAbsent(a, k -> new HashMap<>());
/*     */     
/* 109 */     if (cache.containsKey(p)) {
/* 110 */       return (A)cache.get(p);
/*     */     }
/* 112 */     A ann = LocatableAnnotation.create(p.getAnnotation(a), srcPos);
/* 113 */     cache.put(p, (Annotation)ann);
/* 114 */     return ann;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getClassValue(Annotation a, String name) {
/*     */     try {
/* 121 */       return (Class)a.annotationType().getMethod(name, new Class[0]).invoke(a, new Object[0]);
/* 122 */     } catch (IllegalAccessException e) {
/*     */       
/* 124 */       throw new IllegalAccessError(e.getMessage());
/* 125 */     } catch (InvocationTargetException e) {
/*     */       
/* 127 */       throw new InternalError(Messages.CLASS_NOT_FOUND.format(new Object[] { a.annotationType(), e.getMessage() }));
/* 128 */     } catch (NoSuchMethodException e) {
/* 129 */       throw new NoSuchMethodError(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Class[] getClassArrayValue(Annotation a, String name) {
/*     */     try {
/* 136 */       return (Class[])a.annotationType().getMethod(name, new Class[0]).invoke(a, new Object[0]);
/* 137 */     } catch (IllegalAccessException e) {
/*     */       
/* 139 */       throw new IllegalAccessError(e.getMessage());
/* 140 */     } catch (InvocationTargetException e) {
/*     */       
/* 142 */       throw new InternalError(e.getMessage());
/* 143 */     } catch (NoSuchMethodException e) {
/* 144 */       throw new NoSuchMethodError(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String fullName(Method m) {
/* 150 */     return m.getDeclaringClass().getName() + "#" + m.getDeclaringClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\RuntimeInlineAnnotationReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */