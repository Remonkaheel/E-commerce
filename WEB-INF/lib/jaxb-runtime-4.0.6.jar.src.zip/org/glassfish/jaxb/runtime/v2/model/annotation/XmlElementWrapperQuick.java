/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlElementWrapper;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlElementWrapperQuick
/*    */   extends Quick
/*    */   implements XmlElementWrapper
/*    */ {
/*    */   private final XmlElementWrapper core;
/*    */   
/*    */   public XmlElementWrapperQuick(Locatable upstream, XmlElementWrapper core) {
/* 31 */     super(upstream);
/* 32 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 37 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 42 */     return new XmlElementWrapperQuick(upstream, (XmlElementWrapper)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlElementWrapper> annotationType() {
/* 47 */     return XmlElementWrapper.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public String name() {
/* 52 */     return this.core.name();
/*    */   }
/*    */ 
/*    */   
/*    */   public String namespace() {
/* 57 */     return this.core.namespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean nillable() {
/* 62 */     return this.core.nillable();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean required() {
/* 67 */     return this.core.required();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlElementWrapperQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */