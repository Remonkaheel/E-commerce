/*     */ package org.glassfish.jaxb.runtime.v2.runtime;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.glassfish.jaxb.core.v2.model.core.PropertyKind;
/*     */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeElementInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimePropertyInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.model.runtime.RuntimeTypeInfo;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.Property;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.PropertyFactory;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.property.UnmarshallerChain;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.ChildLoader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Discarder;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Intercepter;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.Loader;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.TagName;
/*     */ import org.glassfish.jaxb.runtime.v2.runtime.unmarshaller.UnmarshallingContext;
/*     */ import org.glassfish.jaxb.runtime.v2.util.QNameMap;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ElementBeanInfoImpl
/*     */   extends JaxBeanInfo<JAXBElement>
/*     */ {
/*     */   private Loader loader;
/*     */   private final Property property;
/*     */   private final QName tagName;
/*     */   public final Class expectedType;
/*     */   private final Class scope;
/*     */   private final Constructor<? extends JAXBElement> constructor;
/*     */   
/*     */   ElementBeanInfoImpl(JAXBContextImpl grammar, RuntimeElementInfo rei) {
/*  56 */     super(grammar, (RuntimeTypeInfo)rei, rei.getType(), true, false, true);
/*     */     
/*  58 */     this.property = PropertyFactory.create(grammar, (RuntimePropertyInfo)rei.getProperty());
/*     */     
/*  60 */     this.tagName = rei.getElementName();
/*  61 */     this.expectedType = (Class)Utils.REFLECTION_NAVIGATOR.erasure(rei.getContentInMemoryType());
/*  62 */     this.scope = (rei.getScope() == null) ? JAXBElement.GlobalScope.class : (Class)rei.getScope().getClazz();
/*     */     
/*  64 */     Class<JAXBElement> type = (Class)Utils.REFLECTION_NAVIGATOR.erasure(rei.getType());
/*  65 */     if (type == JAXBElement.class) {
/*  66 */       this.constructor = null;
/*     */     } else {
/*     */       try {
/*  69 */         this.constructor = type.getConstructor(new Class[] { this.expectedType });
/*  70 */       } catch (NoSuchMethodException e) {
/*  71 */         NoSuchMethodError x = new NoSuchMethodError("Failed to find the constructor for " + type + " with " + this.expectedType);
/*  72 */         x.initCause(e);
/*  73 */         throw x;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementBeanInfoImpl(final JAXBContextImpl grammar) {
/*  87 */     super(grammar, null, JAXBElement.class, true, false, true);
/*  88 */     this.tagName = null;
/*  89 */     this.expectedType = null;
/*  90 */     this.scope = null;
/*  91 */     this.constructor = null;
/*     */     
/*  93 */     this.property = new Property<JAXBElement>()
/*     */       {
/*     */         public void reset(JAXBElement o) {
/*  96 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         
/*     */         public void serializeBody(JAXBElement e, XMLSerializer target, Object outerPeer) throws SAXException, IOException, XMLStreamException {
/* 101 */           Class scope = e.getScope();
/* 102 */           if (e.isGlobalScope()) scope = null; 
/* 103 */           QName n = e.getName();
/* 104 */           ElementBeanInfoImpl bi = grammar.getElement(scope, n);
/* 105 */           if (bi == null) {
/*     */             JaxBeanInfo<?> tbi;
/*     */             
/*     */             try {
/* 109 */               tbi = grammar.getBeanInfo(e.getDeclaredType(), true);
/* 110 */             } catch (JAXBException x) {
/*     */               
/* 112 */               target.reportError(null, (Throwable)x);
/*     */               return;
/*     */             } 
/* 115 */             Object value = e.getValue();
/* 116 */             target.startElement(n.getNamespaceURI(), n.getLocalPart(), n.getPrefix(), null);
/* 117 */             if (value == null) {
/* 118 */               target.writeXsiNilTrue();
/*     */             } else {
/* 120 */               target.childAsXsiType(value, "value", tbi, false);
/*     */             } 
/* 122 */             target.endElement();
/*     */           } else {
/*     */             try {
/* 125 */               bi.property.serializeBody(e, target, e);
/* 126 */             } catch (AccessorException x) {
/* 127 */               JaxBeanInfo tbi; target.reportError(null, (Throwable)tbi);
/*     */             } 
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void serializeURIs(JAXBElement o, XMLSerializer target) {}
/*     */ 
/*     */         
/*     */         public boolean hasSerializeURIAction() {
/* 138 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getIdValue(JAXBElement o) {
/* 143 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public PropertyKind getKind() {
/* 148 */           return PropertyKind.ELEMENT;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void buildChildElementUnmarshallers(UnmarshallerChain chain, QNameMap<ChildLoader> handlers) {}
/*     */ 
/*     */         
/*     */         public Accessor getElementPropertyAccessor(String nsUri, String localName) {
/* 157 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void wrapUp() {}
/*     */ 
/*     */         
/*     */         public RuntimePropertyInfo getInfo() {
/* 166 */           return ElementBeanInfoImpl.this.property.getInfo();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isHiddenByOverride() {
/* 171 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public void setHiddenByOverride(boolean hidden) {
/* 176 */           throw new UnsupportedOperationException("Not supported on jaxbelements.");
/*     */         }
/*     */ 
/*     */         
/*     */         public String getFieldName() {
/* 181 */           return null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class IntercepterLoader
/*     */     extends Loader
/*     */     implements Intercepter
/*     */   {
/*     */     private final Loader core;
/*     */ 
/*     */ 
/*     */     
/*     */     public IntercepterLoader(Loader core) {
/* 197 */       this.core = core;
/*     */     }
/*     */ 
/*     */     
/*     */     public void startElement(UnmarshallingContext.State state, TagName ea) throws SAXException {
/* 202 */       state.setLoader(this.core);
/* 203 */       state.setIntercepter(this);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       UnmarshallingContext context = state.getContext();
/*     */ 
/*     */       
/* 211 */       Object child = context.getOuterPeer();
/*     */       
/* 213 */       if (child != null && ElementBeanInfoImpl.this.jaxbType != child.getClass()) {
/* 214 */         child = null;
/*     */       }
/* 216 */       if (child != null) {
/* 217 */         ElementBeanInfoImpl.this.reset((JAXBElement)child, context);
/*     */       }
/* 219 */       if (child == null) {
/* 220 */         child = context.createInstance(ElementBeanInfoImpl.this);
/*     */       }
/* 222 */       fireBeforeUnmarshal(ElementBeanInfoImpl.this, child, state);
/*     */       
/* 224 */       context.recordOuterPeer(child);
/* 225 */       UnmarshallingContext.State p = state.getPrev();
/* 226 */       p.setBackup(p.getTarget());
/* 227 */       p.setTarget(child);
/*     */       
/* 229 */       this.core.startElement(state, ea);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object intercept(UnmarshallingContext.State state, Object o) throws SAXException {
/* 234 */       JAXBElement e = (JAXBElement)state.getTarget();
/* 235 */       state.setTarget(state.getBackup());
/* 236 */       state.setBackup(null);
/*     */       
/* 238 */       if (state.isNil()) {
/* 239 */         e.setNil(true);
/* 240 */         state.setNil(false);
/*     */       } 
/*     */       
/* 243 */       if (o != null)
/*     */       {
/*     */         
/* 246 */         e.setValue(o);
/*     */       }
/* 248 */       fireAfterUnmarshal(ElementBeanInfoImpl.this, e, state);
/*     */       
/* 250 */       return e;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementNamespaceURI(JAXBElement e) {
/* 256 */     return e.getName().getNamespaceURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getElementLocalName(JAXBElement e) {
/* 261 */     return e.getName().getLocalPart();
/*     */   }
/*     */ 
/*     */   
/*     */   public Loader getLoader(JAXBContextImpl context, boolean typeSubstitutionCapable) {
/* 266 */     if (this.loader == null) {
/*     */       
/* 268 */       UnmarshallerChain c = new UnmarshallerChain(context);
/* 269 */       QNameMap<ChildLoader> result = new QNameMap();
/* 270 */       this.property.buildChildElementUnmarshallers(c, result);
/* 271 */       if (result.size() == 1) {
/*     */         
/* 273 */         this.loader = new IntercepterLoader(((ChildLoader)result.getOne().getValue()).loader);
/*     */       } else {
/*     */         
/* 276 */         this.loader = Discarder.INSTANCE;
/*     */       } 
/* 278 */     }  return this.loader;
/*     */   }
/*     */ 
/*     */   
/*     */   public JAXBElement createInstance(UnmarshallingContext context) throws IllegalAccessException, InvocationTargetException, InstantiationException {
/* 283 */     return createInstanceFromValue(null);
/*     */   }
/*     */   
/*     */   public JAXBElement createInstanceFromValue(Object o) throws IllegalAccessException, InvocationTargetException, InstantiationException {
/* 287 */     if (this.constructor == null) {
/* 288 */       return new JAXBElement(this.tagName, this.expectedType, this.scope, o);
/*     */     }
/* 290 */     return this.constructor.newInstance(new Object[] { o });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reset(JAXBElement e, UnmarshallingContext context) {
/* 295 */     e.setValue(null);
/* 296 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId(JAXBElement e, XMLSerializer target) {
/* 306 */     Object o = e.getValue();
/* 307 */     if (o instanceof String) {
/* 308 */       return (String)o;
/*     */     }
/* 310 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeBody(JAXBElement element, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/*     */     try {
/* 316 */       this.property.serializeBody(element, target, null);
/* 317 */     } catch (AccessorException x) {
/* 318 */       target.reportError(null, (Throwable)x);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeRoot(JAXBElement e, XMLSerializer target) throws SAXException, IOException, XMLStreamException {
/* 324 */     serializeBody(e, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAttributes(JAXBElement e, XMLSerializer target) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeURIs(JAXBElement e, XMLSerializer target) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Transducer<JAXBElement> getTransducer() {
/* 339 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void wrapUp() {
/* 344 */     super.wrapUp();
/* 345 */     this.property.wrapUp();
/*     */   }
/*     */ 
/*     */   
/*     */   public void link(JAXBContextImpl grammar) {
/* 350 */     super.link(grammar);
/* 351 */     getLoader(grammar, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\ElementBeanInfoImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */