/*    */ package org.glassfish.jaxb.runtime.v2.runtime.reflect;
/*    */ 
/*    */ import jakarta.xml.bind.JAXBException;
/*    */ import org.glassfish.jaxb.runtime.api.AccessorException;
/*    */ import org.glassfish.jaxb.runtime.v2.runtime.XMLSerializer;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrimitiveArrayListerDouble<BeanT>
/*    */   extends Lister<BeanT, double[], Double, PrimitiveArrayListerDouble.DoubleArrayPack>
/*    */ {
/*    */   static void register() {
/* 32 */     Lister.primitiveArrayListers.put(double.class, new PrimitiveArrayListerDouble());
/*    */   }
/*    */ 
/*    */   
/*    */   public ListIterator<Double> iterator(final double[] objects, XMLSerializer context) {
/* 37 */     return new ListIterator<Double>() {
/* 38 */         int idx = 0;
/*    */ 
/*    */         
/*    */         public boolean hasNext() {
/* 42 */           return (this.idx < objects.length);
/*    */         }
/*    */ 
/*    */         
/*    */         public Double next() {
/* 47 */           return Double.valueOf(objects[this.idx++]);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public DoubleArrayPack startPacking(BeanT current, Accessor<BeanT, double[]> acc) {
/* 54 */     return new DoubleArrayPack();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addToPack(DoubleArrayPack objects, Double o) {
/* 59 */     objects.add(o);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endPacking(DoubleArrayPack pack, BeanT bean, Accessor<BeanT, double[]> acc) throws AccessorException {
/* 64 */     acc.set(bean, pack.build());
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(BeanT o, Accessor<BeanT, double[]> acc) throws AccessorException {
/* 69 */     acc.set(o, new double[0]);
/*    */   }
/*    */   
/*    */   static final class DoubleArrayPack {
/* 73 */     double[] buf = new double[16];
/*    */     int size;
/*    */     
/*    */     void add(Double b) {
/* 77 */       if (this.buf.length == this.size) {
/*    */         
/* 79 */         double[] nb = new double[this.buf.length * 2];
/* 80 */         System.arraycopy(this.buf, 0, nb, 0, this.buf.length);
/* 81 */         this.buf = nb;
/*    */       } 
/* 83 */       if (b != null)
/* 84 */         this.buf[this.size++] = b.doubleValue(); 
/*    */     }
/*    */     
/*    */     double[] build() {
/* 88 */       if (this.buf.length == this.size)
/*    */       {
/* 90 */         return this.buf;
/*    */       }
/* 92 */       double[] r = new double[this.size];
/* 93 */       System.arraycopy(this.buf, 0, r, 0, this.size);
/* 94 */       return r;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtime\reflect\PrimitiveArrayListerDouble.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */