/*    */ package org.glassfish.jaxb.runtime.v2.model.annotation;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessOrder;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorOrder;
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.glassfish.jaxb.core.v2.model.annotation.Locatable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XmlAccessorOrderQuick
/*    */   extends Quick
/*    */   implements XmlAccessorOrder
/*    */ {
/*    */   private final XmlAccessorOrder core;
/*    */   
/*    */   public XmlAccessorOrderQuick(Locatable upstream, XmlAccessorOrder core) {
/* 32 */     super(upstream);
/* 33 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Annotation getAnnotation() {
/* 38 */     return (Annotation)this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Quick newInstance(Locatable upstream, Annotation core) {
/* 43 */     return new XmlAccessorOrderQuick(upstream, (XmlAccessorOrder)core);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<XmlAccessorOrder> annotationType() {
/* 48 */     return XmlAccessorOrder.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public XmlAccessOrder value() {
/* 53 */     return this.core.value();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\model\annotation\XmlAccessorOrderQuick.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */