/*    */ package org.glassfish.jaxb.runtime.v2.runtime.unmarshaller;
/*    */ 
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamReader;
/*    */ import org.jvnet.staxex.Base64Data;
/*    */ import org.jvnet.staxex.XMLStreamReaderEx;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StAXExConnector
/*    */   extends StAXStreamConnector
/*    */ {
/*    */   private final XMLStreamReaderEx in;
/*    */   
/*    */   public StAXExConnector(XMLStreamReaderEx in, XmlVisitor visitor) {
/* 33 */     super((XMLStreamReader)in, visitor);
/* 34 */     this.in = in;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void handleCharacters() throws XMLStreamException, SAXException {
/* 39 */     if (this.predictor.expectText()) {
/* 40 */       CharSequence pcdata = this.in.getPCDATA();
/* 41 */       if (pcdata instanceof Base64Data) {
/* 42 */         Base64Data bd = (Base64Data)pcdata;
/* 43 */         Base64Data binary = new Base64Data();
/* 44 */         if (!bd.hasData()) {
/* 45 */           binary.set(bd.getDataHandler());
/*    */         } else {
/* 47 */           binary.set(bd.get(), bd.getDataLen(), bd.getMimeType());
/*    */         } 
/*    */         
/* 50 */         this.visitor.text((CharSequence)binary);
/* 51 */         this.textReported = true;
/*    */       } else {
/* 53 */         this.buffer.append(pcdata);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\v2\runtim\\unmarshaller\StAXExConnector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */