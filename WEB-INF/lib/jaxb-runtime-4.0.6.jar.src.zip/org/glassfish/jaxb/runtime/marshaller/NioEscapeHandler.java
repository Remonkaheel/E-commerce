/*    */ package org.glassfish.jaxb.runtime.marshaller;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.CharsetEncoder;
/*    */ import org.glassfish.jaxb.core.marshaller.CharacterEscapeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NioEscapeHandler
/*    */   implements CharacterEscapeHandler
/*    */ {
/*    */   private final CharsetEncoder encoder;
/*    */   
/*    */   public NioEscapeHandler(String charsetName) {
/* 47 */     this.encoder = Charset.forName(charsetName).newEncoder();
/*    */   }
/*    */ 
/*    */   
/*    */   public void escape(char[] ch, int start, int length, boolean isAttVal, Writer out) throws IOException {
/* 52 */     int limit = start + length;
/* 53 */     for (int i = start; i < limit; i++) {
/* 54 */       switch (ch[i]) {
/*    */         case '&':
/* 56 */           out.write("&amp;");
/*    */           break;
/*    */         case '<':
/* 59 */           out.write("&lt;");
/*    */           break;
/*    */         case '>':
/* 62 */           out.write("&gt;");
/*    */           break;
/*    */         case '"':
/* 65 */           if (isAttVal) {
/* 66 */             out.write("&quot;"); break;
/*    */           } 
/* 68 */           out.write(34);
/*    */           break;
/*    */         
/*    */         default:
/* 72 */           if (this.encoder.canEncode(ch[i])) {
/* 73 */             out.write(ch[i]); break;
/*    */           } 
/* 75 */           out.write("&#");
/* 76 */           out.write(Integer.toString(ch[i]));
/* 77 */           out.write(59);
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\marshaller\NioEscapeHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */