package org.glassfish.jaxb.runtime.api;

public class CompositeStructure {
  public Bridge[] bridges;
  
  public Object[] values;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\api\CompositeStructure.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */