package org.glassfish.jaxb.runtime.api;

public abstract class RawAccessor<B, V> {
  public abstract V get(B paramB) throws AccessorException;
  
  public abstract void set(B paramB, V paramV) throws AccessorException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\api\RawAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */