/*     */ package org.glassfish.jaxb.runtime.api;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeReference
/*     */ {
/*     */   public final QName tagName;
/*     */   public final Type type;
/*     */   public final Annotation[] annotations;
/*     */   
/*     */   public TypeReference(QName tagName, Type type, Annotation... annotations) {
/*  52 */     if (tagName == null || type == null || annotations == null) {
/*  53 */       String nullArgs = "";
/*     */       
/*  55 */       if (tagName == null) nullArgs = "tagName"; 
/*  56 */       if (type == null) nullArgs = nullArgs + nullArgs; 
/*  57 */       if (annotations == null) nullArgs = nullArgs + nullArgs;
/*     */       
/*  59 */       Messages.ARGUMENT_CANT_BE_NULL.format(new Object[] { nullArgs });
/*     */       
/*  61 */       throw new IllegalArgumentException(Messages.ARGUMENT_CANT_BE_NULL.format(new Object[] { nullArgs }));
/*     */     } 
/*     */     
/*  64 */     this.tagName = new QName(tagName.getNamespaceURI().intern(), tagName.getLocalPart().intern(), tagName.getPrefix());
/*  65 */     this.type = type;
/*  66 */     this.annotations = annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A get(Class<A> annotationType) {
/*  74 */     for (Annotation a : this.annotations) {
/*  75 */       if (a.annotationType() == annotationType)
/*  76 */         return annotationType.cast(a); 
/*     */     } 
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeReference toItemType() {
/*  90 */     Type base = (Type)Utils.REFLECTION_NAVIGATOR.getBaseClass(this.type, Collection.class);
/*  91 */     if (base == null) {
/*  92 */       return this;
/*     */     }
/*  94 */     return new TypeReference(this.tagName, (Type)Utils.REFLECTION_NAVIGATOR.getTypeArgument(base, 0), new Annotation[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  99 */     if (this == o) return true; 
/* 100 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/* 102 */     TypeReference that = (TypeReference)o;
/*     */     
/* 104 */     if (!Arrays.equals((Object[])this.annotations, (Object[])that.annotations)) return false; 
/* 105 */     if (!this.tagName.equals(that.tagName)) return false; 
/* 106 */     return this.type.equals(that.type);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 111 */     int result = this.tagName.hashCode();
/* 112 */     result = 31 * result + this.type.hashCode();
/* 113 */     result = 31 * result + Arrays.hashCode((Object[])this.annotations);
/* 114 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\api\TypeReference.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */