/*    */ package org.glassfish.jaxb.runtime.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AccessorException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3825830567556994999L;
/*    */   
/*    */   public AccessorException() {}
/*    */   
/*    */   public AccessorException(String message) {
/* 39 */     super(message);
/*    */   }
/*    */   
/*    */   public AccessorException(String message, Throwable cause) {
/* 43 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public AccessorException(Throwable cause) {
/* 47 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\api\AccessorException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */