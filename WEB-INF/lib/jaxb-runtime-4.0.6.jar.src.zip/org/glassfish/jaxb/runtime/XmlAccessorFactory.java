package org.glassfish.jaxb.runtime;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.PACKAGE})
public @interface XmlAccessorFactory {
  Class<? extends AccessorFactory> value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\XmlAccessorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */