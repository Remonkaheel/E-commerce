package org.glassfish.jaxb.runtime;

import jakarta.xml.bind.JAXBException;
import java.lang.reflect.Field;
import org.glassfish.jaxb.runtime.v2.runtime.reflect.Accessor;

public interface InternalAccessorFactory extends AccessorFactory {
  Accessor createFieldAccessor(Class paramClass, Field paramField, boolean paramBoolean1, boolean paramBoolean2) throws JAXBException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\InternalAccessorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */