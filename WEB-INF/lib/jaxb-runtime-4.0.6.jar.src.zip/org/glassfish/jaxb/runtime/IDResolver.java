package org.glassfish.jaxb.runtime;

import jakarta.xml.bind.ValidationEventHandler;
import java.util.concurrent.Callable;
import org.xml.sax.SAXException;

public abstract class IDResolver {
  public void startDocument(ValidationEventHandler eventHandler) throws SAXException {}
  
  public void endDocument() throws SAXException {}
  
  public abstract void bind(String paramString, Object paramObject) throws SAXException;
  
  public abstract Callable<?> resolve(String paramString, Class paramClass) throws SAXException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\IDResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */