package org.glassfish.jaxb.runtime;

import jakarta.xml.bind.Marshaller;

public interface CycleRecoverable {
  Object onCycleDetected(Context paramContext);
  
  public static interface Context {
    Marshaller getMarshaller();
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jaxb-runtime-4.0.6.jar!\org\glassfish\jaxb\runtime\CycleRecoverable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */