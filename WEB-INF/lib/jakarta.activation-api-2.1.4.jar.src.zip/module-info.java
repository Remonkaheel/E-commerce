module jakarta.activation {
  requires java.base;
  requires java.logging;
  requires java.desktop;
  
  exports jakarta.activation;
  exports jakarta.activation.spi;
  
  uses jakarta.activation.spi.MailcapRegistryProvider;
  uses jakarta.activation.spi.MimeTypeRegistryProvider;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */