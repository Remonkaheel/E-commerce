/*    */ package jakarta.activation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedDataTypeException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = -3584600599376858820L;
/*    */   
/*    */   public UnsupportedDataTypeException() {}
/*    */   
/*    */   public UnsupportedDataTypeException(String s) {
/* 41 */     super(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\UnsupportedDataTypeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */