/*     */ package jakarta.activation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SecuritySupport
/*     */ {
/*     */   public static ClassLoader getContextClassLoader() {
/*  28 */     return AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>() {
/*     */           public ClassLoader run() {
/*  30 */             ClassLoader cl = null;
/*     */             try {
/*  32 */               cl = Thread.currentThread().getContextClassLoader();
/*  33 */             } catch (SecurityException securityException) {}
/*  34 */             return cl;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static InputStream getResourceAsStream(final Class<?> c, final String name) throws IOException {
/*     */     try {
/*  42 */       return AccessController.<InputStream>doPrivileged(new PrivilegedExceptionAction<InputStream>() {
/*     */             public InputStream run() throws IOException {
/*  44 */               return c.getResourceAsStream(name);
/*     */             }
/*     */           });
/*  47 */     } catch (PrivilegedActionException e) {
/*  48 */       throw (IOException)e.getException();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static URL[] getResources(final ClassLoader cl, final String name) {
/*  53 */     return AccessController.<URL[]>doPrivileged((PrivilegedAction)new PrivilegedAction<URL[]>() {
/*     */           public URL[] run() {
/*  55 */             URL[] ret = null;
/*     */             
/*  57 */             try { List<URL> v = new ArrayList<>();
/*  58 */               Enumeration<URL> e = cl.getResources(name);
/*  59 */               while (e != null && e.hasMoreElements()) {
/*  60 */                 URL url = e.nextElement();
/*  61 */                 if (url != null)
/*  62 */                   v.add(url); 
/*     */               } 
/*  64 */               if (v.size() > 0) {
/*  65 */                 ret = new URL[v.size()];
/*  66 */                 ret = v.<URL>toArray(ret);
/*     */               }  }
/*  68 */             catch (IOException iOException) {  }
/*  69 */             catch (SecurityException securityException) {}
/*  70 */             return ret;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static URL[] getSystemResources(final String name) {
/*  76 */     return AccessController.<URL[]>doPrivileged((PrivilegedAction)new PrivilegedAction<URL[]>() {
/*     */           public URL[] run() {
/*  78 */             URL[] ret = null;
/*     */             
/*  80 */             try { List<URL> v = new ArrayList<>();
/*  81 */               Enumeration<URL> e = ClassLoader.getSystemResources(name);
/*  82 */               while (e != null && e.hasMoreElements()) {
/*  83 */                 URL url = e.nextElement();
/*  84 */                 if (url != null)
/*  85 */                   v.add(url); 
/*     */               } 
/*  87 */               if (v.size() > 0) {
/*  88 */                 ret = new URL[v.size()];
/*  89 */                 ret = v.<URL>toArray(ret);
/*     */               }  }
/*  91 */             catch (IOException iOException) {  }
/*  92 */             catch (SecurityException securityException) {}
/*  93 */             return ret;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static InputStream openStream(final URL url) throws IOException {
/*     */     try {
/* 100 */       return AccessController.<InputStream>doPrivileged(new PrivilegedExceptionAction<InputStream>() {
/*     */             public InputStream run() throws IOException {
/* 102 */               return url.openStream();
/*     */             }
/*     */           });
/* 105 */     } catch (PrivilegedActionException e) {
/* 106 */       throw (IOException)e.getException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\SecuritySupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */