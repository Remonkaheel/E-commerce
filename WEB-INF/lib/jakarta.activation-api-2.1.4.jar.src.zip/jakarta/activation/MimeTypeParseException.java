/*    */ package jakarta.activation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeTypeParseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1855296571002626216L;
/*    */   
/*    */   public MimeTypeParseException() {}
/*    */   
/*    */   public MimeTypeParseException(String s) {
/* 33 */     super(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MimeTypeParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */