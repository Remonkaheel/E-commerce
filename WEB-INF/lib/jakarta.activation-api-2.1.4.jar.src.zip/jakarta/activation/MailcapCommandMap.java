/*     */ package jakarta.activation;
/*     */ 
/*     */ import jakarta.activation.spi.MailcapRegistryProvider;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailcapCommandMap
/*     */   extends CommandMap
/*     */ {
/*     */   private MailcapRegistry[] DB;
/*     */   private static final int PROG = 0;
/*     */   private static final String confDir;
/*     */   
/*     */   static {
/* 119 */     String dir = null;
/*     */     try {
/* 121 */       dir = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */           {
/*     */             public String run() {
/* 124 */               String home = System.getProperty("java.home");
/* 125 */               String newdir = home + File.separator + "conf";
/* 126 */               File conf = new File(newdir);
/* 127 */               if (conf.exists()) {
/* 128 */                 return newdir + File.separator;
/*     */               }
/* 130 */               return home + File.separator + "lib" + File.separator;
/*     */             }
/*     */           });
/* 133 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 136 */     confDir = dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap() {
/* 144 */     List<MailcapRegistry> dbv = new ArrayList<>(5);
/* 145 */     MailcapRegistry mf = null;
/* 146 */     dbv.add(null);
/*     */     
/* 148 */     LogSupport.log("MailcapCommandMap: load HOME");
/*     */     try {
/* 150 */       String user_home = System.getProperty("user.home");
/*     */       
/* 152 */       if (user_home != null) {
/* 153 */         String[] paths = { user_home + File.separator + ".jakarta.mailcap", user_home + File.separator + ".mailcap" };
/* 154 */         for (String path : paths) {
/* 155 */           mf = loadFile(path);
/* 156 */           if (mf != null) {
/* 157 */             dbv.add(mf);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 162 */     } catch (SecurityException securityException) {}
/*     */     
/* 164 */     LogSupport.log("MailcapCommandMap: load SYS");
/*     */     
/*     */     try {
/* 167 */       if (confDir != null) {
/* 168 */         String[] confs = { "jakarta.mailcap", "mailcap" };
/* 169 */         for (String conf : confs) {
/* 170 */           mf = loadFile(confDir + conf);
/* 171 */           if (mf != null) {
/* 172 */             dbv.add(mf);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 177 */     } catch (SecurityException securityException) {}
/*     */     
/* 179 */     LogSupport.log("MailcapCommandMap: load JAR");
/*     */     
/* 181 */     loadAllResources(dbv, new String[] { "META-INF/jakarta.mailcap", "META-INF/mailcap" });
/*     */     
/* 183 */     LogSupport.log("MailcapCommandMap: load DEF");
/* 184 */     mf = loadResource(new String[] { "/META-INF/jakarta.mailcap.default", "/META-INF/mailcap.default" });
/*     */     
/* 186 */     if (mf != null) {
/* 187 */       dbv.add(mf);
/*     */     }
/* 189 */     this.DB = new MailcapRegistry[dbv.size()];
/* 190 */     this.DB = dbv.<MailcapRegistry>toArray(this.DB);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MailcapRegistry loadResource(String... names) {
/* 197 */     for (String name : names) { 
/* 198 */       try { InputStream clis = SecuritySupport.getResourceAsStream(getClass(), name); 
/* 199 */         try { if (clis != null)
/* 200 */           { MailcapRegistry mf = getImplementation().getByInputStream(clis);
/* 201 */             if (LogSupport.isLoggable()) {
/* 202 */               LogSupport.log("MailcapCommandMap: successfully loaded jakarta.mailcap file: " + name);
/*     */             }
/* 204 */             MailcapRegistry mailcapRegistry1 = mf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 210 */             if (clis != null) clis.close();  return mailcapRegistry1; }  if (LogSupport.isLoggable()) LogSupport.log("MailcapCommandMap: not loading jakarta.mailcap file: " + name);  if (clis != null) clis.close();  } catch (Throwable throwable) { if (clis != null) try { clis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException|SecurityException e)
/* 211 */       { if (LogSupport.isLoggable())
/* 212 */           LogSupport.log("MailcapCommandMap: can't load " + name, e);  }
/* 213 */       catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e)
/* 214 */       { if (LogSupport.isLoggable()) {
/* 215 */           LogSupport.log("Cannot find or load an implementation for MailcapRegistryProvider. MailcapRegistry: can't load " + name, e);
/*     */         } }
/*     */        }
/*     */ 
/*     */     
/* 220 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAllResources(List<MailcapRegistry> v, String... names) {
/* 227 */     boolean anyLoaded = false;
/* 228 */     for (String name : names) {
/*     */       try {
/*     */         URL[] urls;
/* 231 */         ClassLoader cld = null;
/*     */         
/* 233 */         cld = SecuritySupport.getContextClassLoader();
/* 234 */         if (cld == null)
/* 235 */           cld = getClass().getClassLoader(); 
/* 236 */         if (cld != null) {
/* 237 */           urls = SecuritySupport.getResources(cld, name);
/*     */         } else {
/* 239 */           urls = SecuritySupport.getSystemResources(name);
/* 240 */         }  if (urls != null) {
/* 241 */           if (LogSupport.isLoggable())
/* 242 */             LogSupport.log("MailcapCommandMap: getResources"); 
/* 243 */           for (int i = 0; i < urls.length; i++) {
/* 244 */             URL url = urls[i];
/* 245 */             if (LogSupport.isLoggable())
/* 246 */               LogSupport.log("MailcapCommandMap: URL " + url);  
/* 247 */             try { InputStream clis = SecuritySupport.openStream(url); 
/* 248 */               try { if (clis != null) {
/* 249 */                   v.add(getImplementation().getByInputStream(clis));
/* 250 */                   anyLoaded = true;
/* 251 */                   if (LogSupport.isLoggable()) {
/* 252 */                     LogSupport.log("MailcapCommandMap: successfully loaded jakarta.mailcap file from URL: " + url);
/*     */                   
/*     */                   }
/*     */                 
/*     */                 }
/* 257 */                 else if (LogSupport.isLoggable()) {
/* 258 */                   LogSupport.log("MailcapCommandMap: not loading jakarta.mailcap file from URL: " + url);
/*     */                 } 
/*     */ 
/*     */                 
/* 262 */                 if (clis != null) clis.close();  } catch (Throwable throwable) { if (clis != null) try { clis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException|SecurityException ioex)
/* 263 */             { if (LogSupport.isLoggable()) {
/* 264 */                 LogSupport.log("MailcapCommandMap: can't load " + url, ioex);
/*     */               } }
/* 266 */             catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e)
/* 267 */             { if (LogSupport.isLoggable()) {
/* 268 */                 LogSupport.log("Cannot find or load an implementation for MailcapRegistryProvider. MailcapRegistry: can't load " + name, e);
/*     */               } }
/*     */           
/*     */           } 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/* 276 */       } catch (Exception ex) {
/* 277 */         if (LogSupport.isLoggable()) {
/* 278 */           LogSupport.log("MailcapCommandMap: can't load " + name, ex);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 283 */     if (!anyLoaded) {
/* 284 */       if (LogSupport.isLoggable())
/* 285 */         LogSupport.log("MailcapCommandMap: !anyLoaded"); 
/* 286 */       String[] resources = new String[names.length];
/* 287 */       for (int i = 0; i < names.length; i++) {
/* 288 */         resources[i] = "/" + names[i];
/*     */       }
/* 290 */       MailcapRegistry mf = loadResource(resources);
/* 291 */       if (mf != null) {
/* 292 */         v.add(mf);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MailcapRegistry loadFile(String name) {
/* 300 */     MailcapRegistry mtf = null;
/*     */     
/*     */     try {
/* 303 */       mtf = getImplementation().getByFileName(name);
/* 304 */     } catch (IOException e) {
/* 305 */       if (LogSupport.isLoggable()) {
/* 306 */         LogSupport.log("MailcapRegistry: can't load from file - " + name, e);
/*     */       }
/* 308 */     } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 309 */       if (LogSupport.isLoggable()) {
/* 310 */         LogSupport.log("Cannot find or load an implementation for MailcapRegistryProvider. MailcapRegistry: can't load " + name, e);
/*     */       }
/*     */     } 
/*     */     
/* 314 */     return mtf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap(String fileName) throws IOException {
/* 325 */     this();
/* 326 */     if (this.DB[0] == null) {
/*     */       try {
/* 328 */         this.DB[0] = getImplementation().getByFileName(fileName);
/* 329 */       } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 330 */         String message = "Cannot find or load an implementation for MailcapRegistryProvider. MailcapRegistry: can't load " + fileName;
/*     */         
/* 332 */         if (LogSupport.isLoggable()) {
/* 333 */           LogSupport.log(message, e);
/*     */         }
/* 335 */         throw new IOException(message, e);
/*     */       } 
/*     */     }
/* 338 */     if (this.DB[0] != null && LogSupport.isLoggable()) {
/* 339 */       LogSupport.log("MailcapCommandMap: load PROG from " + fileName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailcapCommandMap(InputStream is) {
/* 351 */     this();
/*     */     
/* 353 */     if (this.DB[0] == null) {
/*     */       try {
/* 355 */         this.DB[0] = getImplementation().getByInputStream(is);
/* 356 */       } catch (IOException iOException) {
/*     */       
/* 358 */       } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 359 */         if (LogSupport.isLoggable()) {
/* 360 */           LogSupport.log("Cannot find or load an implementation for MailcapRegistryProvider.MailcapRegistry: can't load InputStream", e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 365 */     if (this.DB[0] != null && LogSupport.isLoggable()) {
/* 366 */       LogSupport.log("MailcapCommandMap: load PROG");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CommandInfo[] getPreferredCommands(String mimeType) {
/* 384 */     List<CommandInfo> cmdList = new ArrayList<>();
/* 385 */     if (mimeType != null)
/* 386 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 388 */     for (i = 0; i < this.DB.length; i++) {
/* 389 */       if (this.DB[i] != null) {
/*     */         
/* 391 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapList(mimeType);
/* 392 */         if (cmdMap != null) {
/* 393 */           appendPrefCmdsToList(cmdMap, cmdList);
/*     */         }
/*     */       } 
/*     */     } 
/* 397 */     for (i = 0; i < this.DB.length; i++) {
/* 398 */       if (this.DB[i] != null) {
/*     */         
/* 400 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 401 */         if (cmdMap != null)
/* 402 */           appendPrefCmdsToList(cmdMap, cmdList); 
/*     */       } 
/*     */     } 
/* 405 */     CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
/* 406 */     cmdInfos = cmdList.<CommandInfo>toArray(cmdInfos);
/*     */     
/* 408 */     return cmdInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendPrefCmdsToList(Map<String, List<String>> cmdHash, List<CommandInfo> cmdList) {
/* 415 */     Iterator<String> verb_enum = cmdHash.keySet().iterator();
/*     */     
/* 417 */     while (verb_enum.hasNext()) {
/* 418 */       String verb = verb_enum.next();
/* 419 */       if (!checkForVerb(cmdList, verb)) {
/* 420 */         List<String> cmdList2 = cmdHash.get(verb);
/* 421 */         String className = cmdList2.get(0);
/* 422 */         cmdList.add(new CommandInfo(verb, className));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkForVerb(List<CommandInfo> cmdList, String verb) {
/* 432 */     Iterator<CommandInfo> ee = cmdList.iterator();
/* 433 */     while (ee.hasNext()) {
/* 434 */       String enum_verb = ((CommandInfo)ee.next()).getCommandName();
/* 435 */       if (enum_verb.equals(verb))
/* 436 */         return true; 
/*     */     } 
/* 438 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CommandInfo[] getAllCommands(String mimeType) {
/* 449 */     List<CommandInfo> cmdList = new ArrayList<>();
/* 450 */     if (mimeType != null)
/* 451 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 453 */     for (i = 0; i < this.DB.length; i++) {
/* 454 */       if (this.DB[i] != null) {
/*     */         
/* 456 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapList(mimeType);
/* 457 */         if (cmdMap != null) {
/* 458 */           appendCmdsToList(cmdMap, cmdList);
/*     */         }
/*     */       } 
/*     */     } 
/* 462 */     for (i = 0; i < this.DB.length; i++) {
/* 463 */       if (this.DB[i] != null) {
/*     */         
/* 465 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 466 */         if (cmdMap != null)
/* 467 */           appendCmdsToList(cmdMap, cmdList); 
/*     */       } 
/*     */     } 
/* 470 */     CommandInfo[] cmdInfos = new CommandInfo[cmdList.size()];
/* 471 */     cmdInfos = cmdList.<CommandInfo>toArray(cmdInfos);
/*     */     
/* 473 */     return cmdInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendCmdsToList(Map<String, List<String>> typeHash, List<CommandInfo> cmdList) {
/* 480 */     Iterator<String> verb_enum = typeHash.keySet().iterator();
/*     */     
/* 482 */     while (verb_enum.hasNext()) {
/* 483 */       String verb = verb_enum.next();
/* 484 */       List<String> cmdList2 = typeHash.get(verb);
/* 485 */       Iterator<String> cmd_enum = cmdList2.iterator();
/*     */       
/* 487 */       while (cmd_enum.hasNext()) {
/* 488 */         String cmd = cmd_enum.next();
/* 489 */         cmdList.add(new CommandInfo(verb, cmd));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CommandInfo getCommand(String mimeType, String cmdName) {
/* 504 */     if (mimeType != null)
/* 505 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 507 */     for (i = 0; i < this.DB.length; i++) {
/* 508 */       if (this.DB[i] != null) {
/*     */         
/* 510 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapList(mimeType);
/* 511 */         if (cmdMap != null) {
/*     */           
/* 513 */           List<String> v = cmdMap.get(cmdName);
/* 514 */           if (v != null) {
/* 515 */             String cmdClassName = v.get(0);
/*     */             
/* 517 */             if (cmdClassName != null) {
/* 518 */               return new CommandInfo(cmdName, cmdClassName);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 524 */     for (i = 0; i < this.DB.length; i++) {
/* 525 */       if (this.DB[i] != null) {
/*     */         
/* 527 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 528 */         if (cmdMap != null) {
/*     */           
/* 530 */           List<String> v = cmdMap.get(cmdName);
/* 531 */           if (v != null) {
/* 532 */             String cmdClassName = v.get(0);
/*     */             
/* 534 */             if (cmdClassName != null)
/* 535 */               return new CommandInfo(cmdName, cmdClassName); 
/*     */           } 
/*     */         } 
/*     */       } 
/* 539 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addMailcap(String mail_cap) {
/* 553 */     LogSupport.log("MailcapCommandMap: add to PROG");
/*     */     try {
/* 555 */       if (this.DB[0] == null) {
/* 556 */         this.DB[0] = getImplementation().getInMemory();
/*     */       }
/* 558 */       this.DB[0].appendToMailcap(mail_cap);
/* 559 */     } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 560 */       if (LogSupport.isLoggable()) {
/* 561 */         LogSupport.log("Cannot find or load an implementation for MailcapRegistryProvider. MailcapRegistry: can't load", e);
/*     */       }
/*     */       
/* 564 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized DataContentHandler createDataContentHandler(String mimeType) {
/* 576 */     if (LogSupport.isLoggable()) {
/* 577 */       LogSupport.log("MailcapCommandMap: createDataContentHandler for " + mimeType);
/*     */     }
/* 579 */     if (mimeType != null)
/* 580 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH); 
/*     */     int i;
/* 582 */     for (i = 0; i < this.DB.length; i++) {
/* 583 */       if (this.DB[i] != null) {
/*     */         
/* 585 */         if (LogSupport.isLoggable())
/* 586 */           LogSupport.log("  search DB #" + i); 
/* 587 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapList(mimeType);
/* 588 */         if (cmdMap != null) {
/* 589 */           List<String> v = cmdMap.get("content-handler");
/* 590 */           if (v != null) {
/* 591 */             String name = v.get(0);
/* 592 */             DataContentHandler dch = getDataContentHandler(name);
/* 593 */             if (dch != null) {
/* 594 */               return dch;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 600 */     for (i = 0; i < this.DB.length; i++) {
/* 601 */       if (this.DB[i] != null) {
/*     */         
/* 603 */         if (LogSupport.isLoggable())
/* 604 */           LogSupport.log("  search fallback DB #" + i); 
/* 605 */         Map<String, List<String>> cmdMap = this.DB[i].getMailcapFallbackList(mimeType);
/* 606 */         if (cmdMap != null) {
/* 607 */           List<String> v = cmdMap.get("content-handler");
/* 608 */           if (v != null) {
/* 609 */             String name = v.get(0);
/* 610 */             DataContentHandler dch = getDataContentHandler(name);
/* 611 */             if (dch != null)
/* 612 */               return dch; 
/*     */           } 
/*     */         } 
/*     */       } 
/* 616 */     }  return null;
/*     */   }
/*     */   
/*     */   private DataContentHandler getDataContentHandler(String name) {
/* 620 */     if (LogSupport.isLoggable())
/* 621 */       LogSupport.log("    got content-handler"); 
/* 622 */     if (LogSupport.isLoggable())
/* 623 */       LogSupport.log("      class " + name); 
/*     */     try {
/* 625 */       ClassLoader cld = null;
/*     */       
/* 627 */       cld = SecuritySupport.getContextClassLoader();
/* 628 */       if (cld == null)
/* 629 */         cld = getClass().getClassLoader(); 
/* 630 */       Class<?> cl = null;
/*     */       try {
/* 632 */         cl = cld.loadClass(name);
/* 633 */       } catch (Exception ex) {
/*     */         
/* 635 */         cl = Class.forName(name);
/*     */       } 
/* 637 */       if (cl != null)
/* 638 */         return cl
/* 639 */           .getConstructor(new Class[0]).newInstance(new Object[0]); 
/* 640 */     } catch (ReflectiveOperationException e) {
/* 641 */       if (LogSupport.isLoggable())
/* 642 */         LogSupport.log("Can't load DCH " + name, e); 
/*     */     } 
/* 644 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String[] getMimeTypes() {
/* 654 */     List<String> mtList = new ArrayList<>();
/*     */     
/* 656 */     for (int i = 0; i < this.DB.length; i++) {
/* 657 */       if (this.DB[i] != null) {
/*     */         
/* 659 */         String[] ts = this.DB[i].getMimeTypes();
/* 660 */         if (ts != null)
/* 661 */           for (int j = 0; j < ts.length; j++) {
/*     */             
/* 663 */             if (!mtList.contains(ts[j])) {
/* 664 */               mtList.add(ts[j]);
/*     */             }
/*     */           }  
/*     */       } 
/*     */     } 
/* 669 */     String[] mts = new String[mtList.size()];
/* 670 */     mts = mtList.<String>toArray(mts);
/*     */     
/* 672 */     return mts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String[] getNativeCommands(String mimeType) {
/* 691 */     List<String> cmdList = new ArrayList<>();
/* 692 */     if (mimeType != null) {
/* 693 */       mimeType = mimeType.toLowerCase(Locale.ENGLISH);
/*     */     }
/* 695 */     for (int i = 0; i < this.DB.length; i++) {
/* 696 */       if (this.DB[i] != null) {
/*     */         
/* 698 */         String[] arrayOfString = this.DB[i].getNativeCommands(mimeType);
/* 699 */         if (arrayOfString != null)
/* 700 */           for (int j = 0; j < arrayOfString.length; j++) {
/*     */             
/* 702 */             if (!cmdList.contains(arrayOfString[j])) {
/* 703 */               cmdList.add(arrayOfString[j]);
/*     */             }
/*     */           }  
/*     */       } 
/*     */     } 
/* 708 */     String[] cmds = new String[cmdList.size()];
/* 709 */     cmds = cmdList.<String>toArray(cmds);
/*     */     
/* 711 */     return cmds;
/*     */   }
/*     */   
/*     */   private MailcapRegistryProvider getImplementation() {
/* 715 */     if (System.getSecurityManager() != null) {
/* 716 */       return AccessController.<MailcapRegistryProvider>doPrivileged(new PrivilegedAction<MailcapRegistryProvider>() {
/*     */             public MailcapRegistryProvider run() {
/* 718 */               return FactoryFinder.<MailcapRegistryProvider>find(MailcapRegistryProvider.class);
/*     */             }
/*     */           });
/*     */     }
/* 722 */     return FactoryFinder.<MailcapRegistryProvider>find(MailcapRegistryProvider.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MailcapCommandMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */