/*    */ package jakarta.activation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MimeTypeRegistry
/*    */ {
/*    */   MimeTypeEntry getMimeTypeEntry(String paramString);
/*    */   
/*    */   default String getMIMETypeString(String file_ext) {
/* 40 */     MimeTypeEntry entry = getMimeTypeEntry(file_ext);
/*    */     
/* 42 */     if (entry != null) {
/* 43 */       return entry.getMIMEType();
/*    */     }
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   void appendToRegistry(String paramString);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MimeTypeRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */