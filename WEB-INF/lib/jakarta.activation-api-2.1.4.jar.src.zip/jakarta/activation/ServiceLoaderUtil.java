/*    */ package jakarta.activation;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.ServiceLoader;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ServiceLoaderUtil
/*    */ {
/*    */   static <P, T extends Exception> P firstByServiceLoader(Class<P> spiClass, ClassLoader loader, Logger logger, ExceptionHandler<T> handler) throws T {
/* 30 */     logger.log(Level.FINE, "Using java.util.ServiceLoader to find {0}", spiClass.getName());
/*    */     
/*    */     try {
/* 33 */       ServiceLoader<P> serviceLoader = ServiceLoader.load(spiClass, loader);
/*    */       
/* 35 */       Iterator<P> iterator = serviceLoader.iterator(); if (iterator.hasNext()) { P impl = iterator.next();
/* 36 */         logger.log(Level.FINE, "ServiceProvider loading Facility used; returning object [{0}]", impl.getClass().getName());
/*    */         
/* 38 */         return impl; }
/*    */     
/* 40 */     } catch (Throwable t) {
/* 41 */       throw handler.createException(t, "Error while searching for service [" + spiClass.getName() + "]");
/*    */     } 
/* 43 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   static void checkPackageAccess(String className) {
/* 48 */     SecurityManager s = System.getSecurityManager();
/* 49 */     if (s != null) {
/* 50 */       int i = className.lastIndexOf('.');
/* 51 */       if (i != -1) {
/* 52 */         s.checkPackageAccess(className.substring(0, i));
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   static <P> Class<P> nullSafeLoadClass(String className, ClassLoader classLoader) throws ClassNotFoundException {
/* 59 */     if (classLoader == null) {
/* 60 */       classLoader = ClassLoader.getSystemClassLoader();
/*    */     }
/* 62 */     return (Class)Class.forName(className, false, classLoader);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <P, T extends Exception> P newInstance(String className, Class<P> service, ClassLoader classLoader, ExceptionHandler<T> handler) throws T {
/*    */     try {
/* 70 */       Class<P> cls = safeLoadClass(className, classLoader);
/* 71 */       return service.cast(cls.getConstructor(new Class[0]).newInstance(new Object[0]));
/* 72 */     } catch (ClassNotFoundException x) {
/* 73 */       throw handler.createException(x, "Provider " + className + " not found");
/* 74 */     } catch (Exception x) {
/* 75 */       throw handler.createException(x, "Provider " + className + " could not be instantiated: " + x);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static <P> Class<P> safeLoadClass(String className, ClassLoader classLoader) throws ClassNotFoundException {
/* 82 */     checkPackageAccess(className);
/* 83 */     return nullSafeLoadClass(className, classLoader);
/*    */   }
/*    */   
/*    */   static abstract class ExceptionHandler<T extends Exception> {
/*    */     public abstract T createException(Throwable param1Throwable, String param1String);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\ServiceLoaderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */