/*     */ package jakarta.activation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PipedInputStream;
/*     */ import java.io.PipedOutputStream;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataHandler
/*     */ {
/*  54 */   private DataSource dataSource = null;
/*  55 */   private DataSource objDataSource = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private Object object = null;
/*  61 */   private String objectMimeType = null;
/*     */ 
/*     */   
/*  64 */   private CommandMap currentCommandMap = null;
/*     */ 
/*     */   
/*  67 */   private static final ActivationDataFlavor[] emptyFlavors = new ActivationDataFlavor[0];
/*     */   
/*  69 */   private ActivationDataFlavor[] transferFlavors = emptyFlavors;
/*     */ 
/*     */   
/*  72 */   private DataContentHandler dataContentHandler = null;
/*  73 */   private DataContentHandler factoryDCH = null;
/*     */ 
/*     */   
/*  76 */   private static DataContentHandlerFactory factory = null;
/*  77 */   private DataContentHandlerFactory oldFactory = null;
/*     */   
/*  79 */   private String shortType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler(DataSource ds) {
/*  90 */     this.dataSource = ds;
/*  91 */     this.oldFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler(Object obj, String mimeType) {
/* 104 */     this.object = obj;
/* 105 */     this.objectMimeType = mimeType;
/* 106 */     this.oldFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler(URL url) {
/* 117 */     this.dataSource = new URLDataSource(url);
/* 118 */     this.oldFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized CommandMap getCommandMap() {
/* 125 */     if (this.currentCommandMap != null) {
/* 126 */       return this.currentCommandMap;
/*     */     }
/* 128 */     return CommandMap.getDefaultCommandMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource getDataSource() {
/* 146 */     if (this.dataSource == null) {
/*     */       
/* 148 */       if (this.objDataSource == null)
/* 149 */         this.objDataSource = new DataHandlerDataSource(this); 
/* 150 */       return this.objDataSource;
/*     */     } 
/* 152 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 164 */     if (this.dataSource != null) {
/* 165 */       return this.dataSource.getName();
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 178 */     if (this.dataSource != null) {
/* 179 */       return this.dataSource.getContentType();
/*     */     }
/* 181 */     return this.objectMimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 209 */     InputStream ins = null;
/*     */     
/* 211 */     if (this.dataSource != null) {
/* 212 */       ins = this.dataSource.getInputStream();
/*     */     } else {
/* 214 */       DataContentHandler dch = getDataContentHandler();
/*     */       
/* 216 */       if (dch == null) {
/* 217 */         throw new UnsupportedDataTypeException("no DCH for MIME type " + 
/* 218 */             getBaseType());
/*     */       }
/* 220 */       if (dch instanceof ObjectDataContentHandler && (
/* 221 */         (ObjectDataContentHandler)dch).getDCH() == null) {
/* 222 */         throw new UnsupportedDataTypeException("no object DCH for MIME type " + 
/* 223 */             getBaseType());
/*     */       }
/*     */       
/* 226 */       final DataContentHandler fdch = dch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       final PipedOutputStream pos = new PipedOutputStream();
/* 235 */       PipedInputStream pin = new PipedInputStream(pos);
/* 236 */       (new Thread(new Runnable()
/*     */           {
/*     */             public void run() {
/*     */               
/* 240 */               try { fdch.writeTo(DataHandler.this.object, DataHandler.this.objectMimeType, pos); }
/* 241 */               catch (IOException iOException)
/*     */               
/*     */               { 
/*     */                 try {
/* 245 */                   pos.close();
/* 246 */                 } catch (IOException iOException1) {} } finally { try { pos.close(); } catch (IOException iOException) {} }
/*     */ 
/*     */             
/*     */             }
/* 250 */           }"DataHandler.getInputStream")).start();
/* 251 */       ins = pin;
/*     */     } 
/*     */     
/* 254 */     return ins;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream os) throws IOException {
/* 274 */     if (this.dataSource != null) {
/* 275 */       InputStream is = null;
/* 276 */       byte[] data = new byte[8192];
/*     */ 
/*     */       
/* 279 */       is = this.dataSource.getInputStream();
/*     */       try {
/*     */         int bytes_read;
/* 282 */         while ((bytes_read = is.read(data)) > 0) {
/* 283 */           os.write(data, 0, bytes_read);
/*     */         }
/*     */       } finally {
/* 286 */         is.close();
/* 287 */         is = null;
/*     */       } 
/*     */     } else {
/* 290 */       DataContentHandler dch = getDataContentHandler();
/* 291 */       dch.writeTo(this.object, this.objectMimeType, os);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 309 */     if (this.dataSource != null) {
/* 310 */       return this.dataSource.getOutputStream();
/*     */     }
/* 312 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ActivationDataFlavor[] getTransferDataFlavors() {
/* 340 */     if (factory != this.oldFactory) {
/* 341 */       this.transferFlavors = emptyFlavors;
/*     */     }
/*     */     
/* 344 */     if (this.transferFlavors == emptyFlavors)
/* 345 */       this.transferFlavors = getDataContentHandler().getTransferDataFlavors(); 
/* 346 */     if (this.transferFlavors == emptyFlavors) {
/* 347 */       return this.transferFlavors;
/*     */     }
/* 349 */     return (ActivationDataFlavor[])this.transferFlavors.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDataFlavorSupported(ActivationDataFlavor flavor) {
/* 365 */     ActivationDataFlavor[] lFlavors = getTransferDataFlavors();
/*     */     
/* 367 */     for (int i = 0; i < lFlavors.length; i++) {
/* 368 */       if (lFlavors[i].equals(flavor))
/* 369 */         return true; 
/*     */     } 
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTransferData(ActivationDataFlavor flavor) throws IOException {
/* 409 */     return getDataContentHandler().getTransferData(flavor, this.dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setCommandMap(CommandMap commandMap) {
/* 425 */     if (commandMap != this.currentCommandMap || commandMap == null) {
/*     */       
/* 427 */       this.transferFlavors = emptyFlavors;
/* 428 */       this.dataContentHandler = null;
/*     */       
/* 430 */       this.currentCommandMap = commandMap;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo[] getPreferredCommands() {
/* 448 */     if (this.dataSource != null) {
/* 449 */       return getCommandMap().getPreferredCommands(getBaseType(), this.dataSource);
/*     */     }
/*     */     
/* 452 */     return getCommandMap().getPreferredCommands(getBaseType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo[] getAllCommands() {
/* 468 */     if (this.dataSource != null) {
/* 469 */       return getCommandMap().getAllCommands(getBaseType(), this.dataSource);
/*     */     }
/* 471 */     return getCommandMap().getAllCommands(getBaseType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo getCommand(String cmdName) {
/* 487 */     if (this.dataSource != null) {
/* 488 */       return getCommandMap().getCommand(getBaseType(), cmdName, this.dataSource);
/*     */     }
/*     */     
/* 491 */     return getCommandMap().getCommand(getBaseType(), cmdName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getContent() throws IOException {
/* 512 */     if (this.object != null) {
/* 513 */       return this.object;
/*     */     }
/* 515 */     return getDataContentHandler().getContent(getDataSource());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBean(CommandInfo cmdinfo) {
/* 531 */     Object bean = null;
/*     */ 
/*     */ 
/*     */     
/* 535 */     try { ClassLoader cld = null;
/*     */       
/* 537 */       cld = SecuritySupport.getContextClassLoader();
/* 538 */       if (cld == null)
/* 539 */         cld = getClass().getClassLoader(); 
/* 540 */       bean = cmdinfo.getCommandObject(this, cld); }
/* 541 */     catch (IOException iOException) {  }
/* 542 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */     
/* 544 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized DataContentHandler getDataContentHandler() {
/* 567 */     if (factory != this.oldFactory) {
/* 568 */       this.oldFactory = factory;
/* 569 */       this.factoryDCH = null;
/* 570 */       this.dataContentHandler = null;
/* 571 */       this.transferFlavors = emptyFlavors;
/*     */     } 
/*     */     
/* 574 */     if (this.dataContentHandler != null) {
/* 575 */       return this.dataContentHandler;
/*     */     }
/* 577 */     String simpleMT = getBaseType();
/*     */     
/* 579 */     if (this.factoryDCH == null && factory != null) {
/* 580 */       this.factoryDCH = factory.createDataContentHandler(simpleMT);
/*     */     }
/* 582 */     if (this.factoryDCH != null) {
/* 583 */       this.dataContentHandler = this.factoryDCH;
/*     */     }
/* 585 */     if (this.dataContentHandler == null) {
/* 586 */       if (this.dataSource != null) {
/* 587 */         this
/* 588 */           .dataContentHandler = getCommandMap().createDataContentHandler(simpleMT, this.dataSource);
/*     */       } else {
/* 590 */         this
/* 591 */           .dataContentHandler = getCommandMap().createDataContentHandler(simpleMT);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 596 */     if (this.dataSource != null) {
/* 597 */       this.dataContentHandler = new DataSourceDataContentHandler(this.dataContentHandler, this.dataSource);
/*     */     }
/*     */     else {
/*     */       
/* 601 */       this.dataContentHandler = new ObjectDataContentHandler(this.dataContentHandler, this.object, this.objectMimeType);
/*     */     } 
/*     */ 
/*     */     
/* 605 */     return this.dataContentHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized String getBaseType() {
/* 613 */     if (this.shortType == null) {
/* 614 */       String ct = getContentType();
/*     */       try {
/* 616 */         MimeType mt = new MimeType(ct);
/* 617 */         this.shortType = mt.getBaseType();
/* 618 */       } catch (MimeTypeParseException e) {
/* 619 */         this.shortType = ct;
/*     */       } 
/*     */     } 
/* 622 */     return this.shortType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDataContentHandlerFactory(DataContentHandlerFactory newFactory) {
/* 640 */     if (factory != null) {
/* 641 */       throw new Error("DataContentHandlerFactory already defined");
/*     */     }
/* 643 */     SecurityManager security = System.getSecurityManager();
/* 644 */     if (security != null)
/*     */       
/*     */       try {
/* 647 */         security.checkSetFactory();
/* 648 */       } catch (SecurityException ex) {
/*     */ 
/*     */ 
/*     */         
/* 652 */         if (DataHandler.class.getClassLoader() != newFactory
/* 653 */           .getClass().getClassLoader()) {
/* 654 */           throw ex;
/*     */         }
/*     */       }  
/* 657 */     factory = newFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\DataHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */