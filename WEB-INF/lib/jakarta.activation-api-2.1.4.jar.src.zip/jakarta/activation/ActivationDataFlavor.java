/*     */ package jakarta.activation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActivationDataFlavor
/*     */ {
/*  37 */   private String mimeType = null;
/*  38 */   private MimeType mimeObject = null;
/*  39 */   private String humanPresentableName = null;
/*  40 */   private Class<?> representationClass = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivationDataFlavor(Class<?> representationClass, String mimeType, String humanPresentableName) {
/*  60 */     this.mimeType = mimeType;
/*  61 */     this.humanPresentableName = humanPresentableName;
/*  62 */     this.representationClass = representationClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivationDataFlavor(Class<?> representationClass, String humanPresentableName) {
/*  85 */     this.mimeType = "application/x-java-serialized-object";
/*  86 */     this.representationClass = representationClass;
/*  87 */     this.humanPresentableName = humanPresentableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActivationDataFlavor(String mimeType, String humanPresentableName) {
/* 107 */     this.mimeType = mimeType;
/*     */     try {
/* 109 */       this.representationClass = Class.forName("java.io.InputStream");
/* 110 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 113 */     this.humanPresentableName = humanPresentableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMimeType() {
/* 122 */     return this.mimeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getRepresentationClass() {
/* 131 */     return this.representationClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHumanPresentableName() {
/* 140 */     return this.humanPresentableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHumanPresentableName(String humanPresentableName) {
/* 149 */     this.humanPresentableName = humanPresentableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(ActivationDataFlavor dataFlavor) {
/* 161 */     return (isMimeTypeEqual(dataFlavor.mimeType) && dataFlavor
/* 162 */       .getRepresentationClass() == this.representationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 171 */     return (o instanceof ActivationDataFlavor && 
/* 172 */       equals((ActivationDataFlavor)o));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean equals(String s) {
/* 190 */     if (s == null || this.mimeType == null)
/* 191 */       return false; 
/* 192 */     return isMimeTypeEqual(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 206 */     int total = 0;
/*     */     
/* 208 */     if (this.representationClass != null) {
/* 209 */       total += this.representationClass.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMimeTypeEqual(String mimeType) {
/* 229 */     MimeType mt = null;
/*     */     try {
/* 231 */       if (this.mimeObject == null)
/* 232 */         this.mimeObject = new MimeType(this.mimeType); 
/* 233 */       mt = new MimeType(mimeType);
/* 234 */     } catch (MimeTypeParseException e) {
/*     */       
/* 236 */       return this.mimeType.equalsIgnoreCase(mimeType);
/*     */     } 
/*     */     
/* 239 */     return this.mimeObject.match(mt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String normalizeMimeTypeParameter(String parameterName, String parameterValue) {
/* 260 */     return parameterValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String normalizeMimeType(String mimeType) {
/* 277 */     return mimeType;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\ActivationDataFlavor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */