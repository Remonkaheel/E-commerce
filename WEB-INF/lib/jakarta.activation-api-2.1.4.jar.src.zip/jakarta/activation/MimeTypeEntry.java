/*    */ package jakarta.activation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeTypeEntry
/*    */ {
/*    */   private String type;
/*    */   private String extension;
/*    */   
/*    */   public MimeTypeEntry(String mime_type, String file_ext) {
/* 27 */     this.type = mime_type;
/* 28 */     this.extension = file_ext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMIMEType() {
/* 37 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getFileExtension() {
/* 46 */     return this.extension;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     return "MIMETypeEntry: " + this.type + ", " + this.extension;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MimeTypeEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */