/*     */ package jakarta.activation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryFinder
/*     */ {
/*  24 */   private static final Logger logger = Logger.getLogger("jakarta.activation");
/*     */   
/*  26 */   private static final ServiceLoaderUtil.ExceptionHandler<RuntimeException> EXCEPTION_HANDLER = new ServiceLoaderUtil.ExceptionHandler<RuntimeException>()
/*     */     {
/*     */       public RuntimeException createException(Throwable throwable, String message)
/*     */       {
/*  30 */         return new IllegalStateException(message, throwable);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> T find(Class<T> factoryClass) throws RuntimeException {
/*  46 */     for (ClassLoader l : getClassLoaders(new Class[] { Thread.class, FactoryFinder.class, System.class })) {
/*     */ 
/*     */ 
/*     */       
/*  50 */       T f = find(factoryClass, l);
/*  51 */       if (f != null) {
/*  52 */         return f;
/*     */       }
/*     */     } 
/*     */     
/*  56 */     throw (RuntimeException)EXCEPTION_HANDLER.createException((Throwable)null, "Provider for " + factoryClass
/*  57 */         .getName() + " cannot be found");
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> T find(Class<T> factoryClass, ClassLoader loader) throws RuntimeException {
/*  62 */     String className = fromSystemProperty(factoryClass.getName());
/*  63 */     if (className != null) {
/*  64 */       T t = newInstance(className, factoryClass, loader);
/*  65 */       if (t != null) {
/*  66 */         return t;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  71 */     T factory = (T)ServiceLoaderUtil.firstByServiceLoader(factoryClass, loader, logger, EXCEPTION_HANDLER);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     if (factory != null) {
/*  77 */       return factory;
/*     */     }
/*     */ 
/*     */     
/*  81 */     T result = lookupUsingHk2ServiceLoader(factoryClass, loader);
/*  82 */     if (result != null) {
/*  83 */       return result;
/*     */     }
/*     */     
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T newInstance(String className, Class<? extends T> service, ClassLoader loader) throws RuntimeException {
/*  92 */     return ServiceLoaderUtil.newInstance(className, service, loader, EXCEPTION_HANDLER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String fromSystemProperty(String factoryId) {
/* 100 */     String systemProp = getSystemProperty(factoryId);
/* 101 */     return systemProp;
/*     */   }
/*     */   
/*     */   private static String getSystemProperty(final String property) {
/* 105 */     logger.log(Level.FINE, "Checking system property {0}", property);
/* 106 */     String value = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/* 109 */             return System.getProperty(property);
/*     */           }
/*     */         });
/* 112 */     logFound(value);
/* 113 */     return value;
/*     */   }
/*     */   
/*     */   private static void logFound(String value) {
/* 117 */     if (value != null) {
/* 118 */       logger.log(Level.FINE, "  found {0}", value);
/*     */     } else {
/* 120 */       logger.log(Level.FINE, "  not found");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Class<?>[] getHk2ServiceLoaderTargets(Class<?> factoryClass) {
/* 125 */     ClassLoader[] loaders = getClassLoaders(new Class[] { Thread.class, factoryClass, System.class });
/*     */     
/* 127 */     Class<?>[] classes = new Class[loaders.length];
/* 128 */     int w = 0;
/* 129 */     for (ClassLoader loader : loaders) {
/* 130 */       if (loader != null) {
/*     */         try {
/* 132 */           classes[w++] = Class.forName("org.glassfish.hk2.osgiresourcelocator.ServiceLoader", false, loader);
/* 133 */         } catch (Exception|LinkageError exception) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 138 */     if (classes.length != w) {
/* 139 */       classes = (Class[])Arrays.<Class<?>[]>copyOf((Class<?>[][])classes, w);
/*     */     }
/* 141 */     return classes;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> T lookupUsingHk2ServiceLoader(Class<T> factoryClass, ClassLoader loader) {
/* 146 */     for (Class<?> target : getHk2ServiceLoaderTargets(factoryClass)) {
/*     */       
/*     */       try {
/* 149 */         Class<?> serviceClass = Class.forName(factoryClass.getName(), false, loader);
/* 150 */         Class<?>[] args = new Class[] { serviceClass };
/* 151 */         Method m = target.getMethod("lookupProviderInstances", new Class[] { Class.class });
/* 152 */         Iterable<?> iterable = (Iterable)m.invoke(null, (Object[])args);
/* 153 */         if (iterable != null) {
/* 154 */           Iterator<?> iter = iterable.iterator();
/* 155 */           if (iter.hasNext()) {
/* 156 */             return factoryClass.cast(iter.next());
/*     */           }
/*     */         } 
/* 159 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 163 */     return null;
/*     */   }
/*     */   
/*     */   private static ClassLoader[] getClassLoaders(Class<?>... classes) {
/* 167 */     return AccessController.<ClassLoader[]>doPrivileged((PrivilegedAction)new PrivilegedAction<ClassLoader[]>()
/*     */         {
/*     */           public ClassLoader[] run()
/*     */           {
/* 171 */             ClassLoader[] loaders = new ClassLoader[classes.length];
/* 172 */             int w = 0;
/* 173 */             for (Class<?> k : classes) {
/* 174 */               ClassLoader cl = null;
/* 175 */               if (k == Thread.class) {
/*     */                 try {
/* 177 */                   cl = Thread.currentThread().getContextClassLoader();
/* 178 */                 } catch (SecurityException securityException) {}
/*     */               }
/* 180 */               else if (k == System.class) {
/*     */                 try {
/* 182 */                   cl = ClassLoader.getSystemClassLoader();
/* 183 */                 } catch (SecurityException securityException) {}
/*     */               } else {
/*     */                 
/*     */                 try {
/* 187 */                   cl = k.getClassLoader();
/* 188 */                 } catch (SecurityException securityException) {}
/*     */               } 
/*     */ 
/*     */               
/* 192 */               if (cl != null) {
/* 193 */                 loaders[w++] = cl;
/*     */               }
/*     */             } 
/*     */             
/* 197 */             if (loaders.length != w) {
/* 198 */               loaders = Arrays.<ClassLoader>copyOf(loaders, w);
/*     */             }
/* 200 */             return loaders;
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\FactoryFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */