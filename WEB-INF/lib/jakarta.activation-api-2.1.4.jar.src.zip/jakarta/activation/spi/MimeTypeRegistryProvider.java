package jakarta.activation.spi;

import jakarta.activation.MimeTypeRegistry;
import java.io.IOException;
import java.io.InputStream;

public interface MimeTypeRegistryProvider {
  MimeTypeRegistry getByFileName(String paramString) throws IOException;
  
  MimeTypeRegistry getByInputStream(InputStream paramInputStream) throws IOException;
  
  MimeTypeRegistry getInMemory();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\spi\MimeTypeRegistryProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */