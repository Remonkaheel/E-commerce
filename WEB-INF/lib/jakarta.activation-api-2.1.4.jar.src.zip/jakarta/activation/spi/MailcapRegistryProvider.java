package jakarta.activation.spi;

import jakarta.activation.MailcapRegistry;
import java.io.IOException;
import java.io.InputStream;

public interface MailcapRegistryProvider {
  MailcapRegistry getByFileName(String paramString) throws IOException;
  
  MailcapRegistry getByInputStream(InputStream paramInputStream) throws IOException;
  
  MailcapRegistry getInMemory();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\spi\MailcapRegistryProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */