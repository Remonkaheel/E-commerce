/*    */ package jakarta.activation;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LogSupport
/*    */ {
/*    */   private static boolean debug = false;
/*    */   private static Logger logger;
/* 21 */   private static final Level level = Level.FINE;
/*    */ 
/*    */   
/*    */   static {
/*    */     try {
/* 26 */       debug = (Boolean.getBoolean("jakarta.activation.debug") || Boolean.getBoolean("javax.activation.debug"));
/* 27 */     } catch (Throwable throwable) {}
/*    */ 
/*    */     
/* 30 */     logger = Logger.getLogger("jakarta.activation");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void log(String msg) {
/* 41 */     if (debug)
/* 42 */       System.out.println(msg); 
/* 43 */     logger.log(level, msg);
/*    */   }
/*    */   
/*    */   public static void log(String msg, Throwable t) {
/* 47 */     if (debug)
/* 48 */       System.out.println(msg + "; Exception: " + t); 
/* 49 */     logger.log(level, msg, t);
/*    */   }
/*    */   
/*    */   public static boolean isLoggable() {
/* 53 */     return (debug || logger.isLoggable(level));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\LogSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */