/*     */ package jakarta.activation;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandInfo
/*     */ {
/*     */   private String verb;
/*     */   private String className;
/*     */   
/*     */   public CommandInfo(String verb, String className) {
/*  43 */     this.verb = verb;
/*  44 */     this.className = className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommandName() {
/*  53 */     return this.verb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommandClass() {
/*  67 */     return this.className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCommandObject(DataHandler dh, ClassLoader loader) throws IOException, ClassNotFoundException {
/* 110 */     Object new_bean = null;
/*     */ 
/*     */     
/* 113 */     new_bean = Beans.instantiate(loader, this.className);
/*     */ 
/*     */     
/* 116 */     if (new_bean != null) {
/* 117 */       if (new_bean instanceof CommandObject) {
/* 118 */         ((CommandObject)new_bean).setCommandContext(this.verb, dh);
/* 119 */       } else if (new_bean instanceof Externalizable && 
/* 120 */         dh != null) {
/* 121 */         InputStream is = dh.getInputStream();
/* 122 */         if (is != null) {
/* 123 */           ((Externalizable)new_bean).readExternal(new ObjectInputStream(is));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 130 */     return new_bean;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Beans
/*     */   {
/*     */     static final Method instantiateMethod;
/*     */ 
/*     */     
/*     */     static {
/*     */       Method m;
/*     */       try {
/* 143 */         Class<?> c = Class.forName("java.beans.Beans");
/* 144 */         m = c.getDeclaredMethod("instantiate", new Class[] { ClassLoader.class, String.class });
/* 145 */       } catch (ClassNotFoundException|NoSuchMethodException e) {
/* 146 */         m = null;
/*     */       } 
/* 148 */       instantiateMethod = m;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Object instantiate(ClassLoader loader, String cn) throws IOException, ClassNotFoundException {
/* 159 */       if (instantiateMethod != null)
/*     */         
/*     */         try {
/*     */           
/* 163 */           return instantiateMethod.invoke(null, new Object[] { loader, cn });
/* 164 */         } catch (InvocationTargetException|IllegalAccessException e) {
/* 165 */           Exception exception = e;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 206 */           return null;
/*     */         }  
/*     */       SecurityManager security = System.getSecurityManager();
/*     */       if (security != null) {
/*     */         String cname = cn.replace('/', '.');
/*     */         if (cname.startsWith("[")) {
/*     */           int b = cname.lastIndexOf('[') + 2;
/*     */           if (b > 1 && b < cname.length())
/*     */             cname = cname.substring(b); 
/*     */         } 
/*     */         int i = cname.lastIndexOf('.');
/*     */         if (i != -1)
/*     */           security.checkPackageAccess(cname.substring(0, i)); 
/*     */       } 
/*     */       if (loader == null)
/*     */         loader = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>() {
/*     */               public ClassLoader run() {
/*     */                 ClassLoader cl = null;
/*     */                 try {
/*     */                   cl = ClassLoader.getSystemClassLoader();
/*     */                 } catch (SecurityException securityException) {}
/*     */                 return cl;
/*     */               }
/*     */             }); 
/*     */       Class<?> beanClass = Class.forName(cn, true, loader);
/*     */       try {
/*     */         return beanClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*     */       } catch (Exception ex) {
/*     */         throw new ClassNotFoundException(beanClass + ": " + ex, ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\CommandInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */