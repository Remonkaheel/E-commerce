/*     */ package jakarta.activation;
/*     */ 
/*     */ import jakarta.activation.spi.MimeTypeRegistryProvider;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimetypesFileTypeMap
/*     */   extends FileTypeMap
/*     */ {
/*     */   private MimeTypeRegistry[] DB;
/*     */   private static final int PROG = 0;
/*     */   private static final String defaultType = "application/octet-stream";
/*     */   private static final String confDir;
/*     */   
/*     */   static {
/*  72 */     String dir = null;
/*     */     try {
/*  74 */       dir = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */           {
/*     */             public String run() {
/*  77 */               String home = System.getProperty("java.home");
/*  78 */               String newdir = home + File.separator + "conf";
/*  79 */               File conf = new File(newdir);
/*  80 */               if (conf.exists()) {
/*  81 */                 return newdir + File.separator;
/*     */               }
/*  83 */               return home + File.separator + "lib" + File.separator;
/*     */             }
/*     */           });
/*  86 */     } catch (Exception ex) {
/*  87 */       if (LogSupport.isLoggable())
/*  88 */         LogSupport.log("Exception during MimetypesFileTypeMap class loading", ex); 
/*     */     } 
/*  90 */     confDir = dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap() {
/*  97 */     Vector<MimeTypeRegistry> dbv = new Vector<>(5);
/*  98 */     MimeTypeRegistry mf = null;
/*  99 */     dbv.addElement(null);
/*     */     
/* 101 */     LogSupport.log("MimetypesFileTypeMap: load HOME");
/*     */     try {
/* 103 */       String user_home = System.getProperty("user.home");
/*     */       
/* 105 */       if (user_home != null) {
/* 106 */         String[] paths = { user_home + File.separator + ".jakarta.mime.types", user_home + File.separator + ".mime.types" };
/* 107 */         for (String path : paths) {
/* 108 */           mf = loadFile(path);
/* 109 */           if (mf != null) {
/* 110 */             dbv.addElement(mf);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 115 */     } catch (SecurityException ex) {
/* 116 */       if (LogSupport.isLoggable()) {
/* 117 */         LogSupport.log("Exception during MimetypesFileTypeMap class instantiation", ex);
/*     */       }
/*     */     } 
/* 120 */     LogSupport.log("MimetypesFileTypeMap: load SYS");
/*     */     
/*     */     try {
/* 123 */       if (confDir != null) {
/* 124 */         String[] confs = { "jakarta.mime.types", "mime.types" };
/* 125 */         for (String conf : confs) {
/* 126 */           mf = loadFile(confDir + conf);
/* 127 */           if (mf != null) {
/* 128 */             dbv.addElement(mf);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 133 */     } catch (SecurityException ex) {
/* 134 */       if (LogSupport.isLoggable()) {
/* 135 */         LogSupport.log("Exception during MimetypesFileTypeMap class instantiation", ex);
/*     */       }
/*     */     } 
/* 138 */     LogSupport.log("MimetypesFileTypeMap: load JAR");
/*     */     
/* 140 */     loadAllResources(dbv, new String[] { "META-INF/jakarta.mime.types", "META-INF/mime.types" });
/*     */     
/* 142 */     LogSupport.log("MimetypesFileTypeMap: load DEF");
/* 143 */     mf = loadResource(new String[] { "/META-INF/jakarta.mimetypes.default", "/META-INF/mimetypes.default" });
/*     */     
/* 145 */     if (mf != null) {
/* 146 */       dbv.addElement(mf);
/*     */     }
/* 148 */     this.DB = new MimeTypeRegistry[dbv.size()];
/* 149 */     dbv.copyInto((Object[])this.DB);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeTypeRegistry loadResource(String... names) {
/* 156 */     for (String name : names) {
/* 157 */       InputStream clis = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAllResources(Vector<MimeTypeRegistry> v, String... names) {
/* 196 */     boolean anyLoaded = false;
/* 197 */     for (String name : names) {
/*     */       try {
/*     */         URL[] urls;
/* 200 */         ClassLoader cld = null;
/*     */         
/* 202 */         cld = SecuritySupport.getContextClassLoader();
/* 203 */         if (cld == null)
/* 204 */           cld = getClass().getClassLoader(); 
/* 205 */         if (cld != null) {
/* 206 */           urls = SecuritySupport.getResources(cld, name);
/*     */         } else {
/* 208 */           urls = SecuritySupport.getSystemResources(name);
/* 209 */         }  if (urls != null) {
/* 210 */           if (LogSupport.isLoggable())
/* 211 */             LogSupport.log("MimetypesFileTypeMap: getResources"); 
/* 212 */           for (int i = 0; i < urls.length; i++) {
/* 213 */             URL url = urls[i];
/* 214 */             InputStream clis = null;
/* 215 */             if (LogSupport.isLoggable());
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/* 256 */       } catch (Exception ex) {
/* 257 */         if (LogSupport.isLoggable()) {
/* 258 */           LogSupport.log("MimetypesFileTypeMap: can't load " + name, ex);
/*     */         }
/*     */       } 
/*     */     } 
/* 262 */     if (!anyLoaded) {
/* 263 */       LogSupport.log("MimetypesFileTypeMap: !anyLoaded");
/* 264 */       String[] resources = new String[names.length];
/* 265 */       for (int i = 0; i < names.length; i++) {
/* 266 */         resources[i] = "/" + names[i];
/*     */       }
/* 268 */       MimeTypeRegistry mf = loadResource(resources);
/* 269 */       if (mf != null) {
/* 270 */         v.addElement(mf);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeTypeRegistry loadFile(String name) {
/* 278 */     MimeTypeRegistry mtf = null;
/*     */     
/*     */     try {
/* 281 */       mtf = getImplementation().getByFileName(name);
/* 282 */     } catch (IOException e) {
/* 283 */       if (LogSupport.isLoggable()) {
/* 284 */         LogSupport.log("MimeTypeRegistry: can't load from file - " + name, e);
/*     */       }
/* 286 */     } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 287 */       if (LogSupport.isLoggable()) {
/* 288 */         LogSupport.log("Cannot find or load an implementation for MimeTypeRegistryProvider.MimeTypeRegistry: can't load " + name, e);
/*     */       }
/*     */     } 
/*     */     
/* 292 */     return mtf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap(String mimeTypeFileName) throws IOException {
/* 303 */     this();
/*     */     try {
/* 305 */       this.DB[0] = getImplementation().getByFileName(mimeTypeFileName);
/* 306 */     } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 307 */       String errorMessage = "Cannot find or load an implementation for MimeTypeRegistryProvider.MimeTypeRegistry: can't load " + mimeTypeFileName;
/*     */       
/* 309 */       if (LogSupport.isLoggable()) {
/* 310 */         LogSupport.log(errorMessage, e);
/*     */       }
/* 312 */       throw new IOException(errorMessage, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap(InputStream is) {
/* 323 */     this();
/*     */     try {
/* 325 */       this.DB[0] = getImplementation().getByInputStream(is);
/* 326 */     } catch (IOException iOException) {
/*     */     
/* 328 */     } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 329 */       if (LogSupport.isLoggable()) {
/* 330 */         LogSupport.log("Cannot find or load an implementation for MimeTypeRegistryProvider.MimeTypeRegistry: can't load InputStream", e);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addMimeTypes(String mime_types) {
/*     */     try {
/* 344 */       if (this.DB[0] == null) {
/* 345 */         this.DB[0] = getImplementation().getInMemory();
/*     */       }
/* 347 */       this.DB[0].appendToRegistry(mime_types);
/* 348 */     } catch (NoSuchElementException|IllegalStateException|java.util.ServiceConfigurationError e) {
/* 349 */       if (LogSupport.isLoggable()) {
/* 350 */         LogSupport.log("Cannot find or load an implementation for MimeTypeRegistryProvider.MimeTypeRegistry: can't add " + mime_types, e);
/*     */       }
/*     */       
/* 353 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType(File f) {
/* 366 */     return getContentType(f.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String getContentType(String filename) {
/* 379 */     int dot_pos = filename.lastIndexOf(".");
/*     */     
/* 381 */     if (dot_pos < 0) {
/* 382 */       return "application/octet-stream";
/*     */     }
/* 384 */     String file_ext = filename.substring(dot_pos + 1);
/* 385 */     if (file_ext.length() == 0) {
/* 386 */       return "application/octet-stream";
/*     */     }
/* 388 */     for (int i = 0; i < this.DB.length; i++) {
/* 389 */       if (this.DB[i] != null) {
/*     */         
/* 391 */         String result = this.DB[i].getMIMETypeString(file_ext);
/* 392 */         if (result != null)
/* 393 */           return result; 
/*     */       } 
/* 395 */     }  return "application/octet-stream";
/*     */   }
/*     */   
/*     */   private MimeTypeRegistryProvider getImplementation() {
/* 399 */     if (System.getSecurityManager() != null) {
/* 400 */       return AccessController.<MimeTypeRegistryProvider>doPrivileged(new PrivilegedAction<MimeTypeRegistryProvider>() {
/*     */             public MimeTypeRegistryProvider run() {
/* 402 */               return FactoryFinder.<MimeTypeRegistryProvider>find(MimeTypeRegistryProvider.class);
/*     */             }
/*     */           });
/*     */     }
/* 406 */     return FactoryFinder.<MimeTypeRegistryProvider>find(MimeTypeRegistryProvider.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MimetypesFileTypeMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */