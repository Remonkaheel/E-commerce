/*     */ package jakarta.activation;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeType
/*     */   implements Externalizable
/*     */ {
/*     */   private String primaryType;
/*     */   private String subType;
/*     */   private MimeTypeParameterList parameters;
/*     */   private static final long serialVersionUID = 7548163901563814301L;
/*     */   private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
/*     */   
/*     */   public MimeType() {
/*  37 */     this.primaryType = "application";
/*  38 */     this.subType = "*";
/*  39 */     this.parameters = new MimeTypeParameterList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeType(String rawdata) throws MimeTypeParseException {
/*  49 */     parse(rawdata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeType(String primary, String sub) throws MimeTypeParseException {
/*  63 */     if (isValidToken(primary)) {
/*  64 */       this.primaryType = primary.toLowerCase(Locale.ENGLISH);
/*     */     } else {
/*  66 */       throw new MimeTypeParseException("Primary type is invalid.");
/*     */     } 
/*     */ 
/*     */     
/*  70 */     if (isValidToken(sub)) {
/*  71 */       this.subType = sub.toLowerCase(Locale.ENGLISH);
/*     */     } else {
/*  73 */       throw new MimeTypeParseException("Sub type is invalid.");
/*     */     } 
/*     */     
/*  76 */     this.parameters = new MimeTypeParameterList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(String rawdata) throws MimeTypeParseException {
/*  83 */     int slashIndex = rawdata.indexOf('/');
/*  84 */     int semIndex = rawdata.indexOf(';');
/*  85 */     if (slashIndex < 0 && semIndex < 0)
/*     */     {
/*     */       
/*  88 */       throw new MimeTypeParseException("Unable to find a sub type."); } 
/*  89 */     if (slashIndex < 0 && semIndex >= 0)
/*     */     {
/*     */       
/*  92 */       throw new MimeTypeParseException("Unable to find a sub type."); } 
/*  93 */     if (slashIndex >= 0 && semIndex < 0) {
/*     */       
/*  95 */       this
/*  96 */         .primaryType = rawdata.substring(0, slashIndex).trim().toLowerCase(Locale.ENGLISH);
/*  97 */       this
/*  98 */         .subType = rawdata.substring(slashIndex + 1).trim().toLowerCase(Locale.ENGLISH);
/*  99 */       this.parameters = new MimeTypeParameterList();
/* 100 */     } else if (slashIndex < semIndex) {
/*     */       
/* 102 */       this
/* 103 */         .primaryType = rawdata.substring(0, slashIndex).trim().toLowerCase(Locale.ENGLISH);
/* 104 */       this
/* 105 */         .subType = rawdata.substring(slashIndex + 1, semIndex).trim().toLowerCase(Locale.ENGLISH);
/* 106 */       this.parameters = new MimeTypeParameterList(rawdata.substring(semIndex));
/*     */     }
/*     */     else {
/*     */       
/* 110 */       throw new MimeTypeParseException("Unable to find a sub type.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (!isValidToken(this.primaryType)) {
/* 117 */       throw new MimeTypeParseException("Primary type is invalid.");
/*     */     }
/*     */     
/* 120 */     if (!isValidToken(this.subType)) {
/* 121 */       throw new MimeTypeParseException("Sub type is invalid.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrimaryType() {
/* 130 */     return this.primaryType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimaryType(String primary) throws MimeTypeParseException {
/* 142 */     if (!isValidToken(this.primaryType))
/* 143 */       throw new MimeTypeParseException("Primary type is invalid."); 
/* 144 */     this.primaryType = primary.toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubType() {
/* 153 */     return this.subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubType(String sub) throws MimeTypeParseException {
/* 165 */     if (!isValidToken(this.subType))
/* 166 */       throw new MimeTypeParseException("Sub type is invalid."); 
/* 167 */     this.subType = sub.toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeParameterList getParameters() {
/* 176 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 187 */     return this.parameters.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String name, String value) {
/* 198 */     this.parameters.set(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParameter(String name) {
/* 207 */     this.parameters.remove(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 214 */     return getBaseType() + this.parameters.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseType() {
/* 224 */     return this.primaryType + "/" + this.subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(MimeType type) {
/* 235 */     return (this.primaryType.equals(type.getPrimaryType()) && (this.subType
/* 236 */       .equals("*") || type
/* 237 */       .getSubType().equals("*") || this.subType
/* 238 */       .equals(type.getSubType())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(String rawdata) throws MimeTypeParseException {
/* 250 */     return match(new MimeType(rawdata));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 263 */     out.writeUTF(toString());
/* 264 */     out.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/*     */     try {
/* 281 */       parse(in.readUTF());
/* 282 */     } catch (MimeTypeParseException e) {
/* 283 */       throw new IOException(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTokenChar(char c) {
/* 293 */     return (c > ' ' && c < '' && "()<>@,;:/[]?=\\\"".indexOf(c) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValidToken(String s) {
/* 300 */     int len = s.length();
/* 301 */     if (len > 0) {
/* 302 */       for (int i = 0; i < len; i++) {
/* 303 */         char c = s.charAt(i);
/* 304 */         if (!isTokenChar(c)) {
/* 305 */           return false;
/*     */         }
/*     */       } 
/* 308 */       return true;
/*     */     } 
/* 310 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MimeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */