package jakarta.activation;

import java.io.IOException;
import java.io.OutputStream;

public interface DataContentHandler {
  ActivationDataFlavor[] getTransferDataFlavors();
  
  Object getTransferData(ActivationDataFlavor paramActivationDataFlavor, DataSource paramDataSource) throws IOException;
  
  Object getContent(DataSource paramDataSource) throws IOException;
  
  void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\DataContentHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */