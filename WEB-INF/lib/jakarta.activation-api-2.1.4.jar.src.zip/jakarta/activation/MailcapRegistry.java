package jakarta.activation;

import java.util.List;
import java.util.Map;

public interface MailcapRegistry {
  Map<String, List<String>> getMailcapList(String paramString);
  
  Map<String, List<String>> getMailcapFallbackList(String paramString);
  
  String[] getMimeTypes();
  
  String[] getNativeCommands(String paramString);
  
  void appendToMailcap(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\MailcapRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */