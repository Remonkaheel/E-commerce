package jakarta.activation;

import java.io.IOException;

public interface CommandObject {
  void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.activation-api-2.1.4.jar!\jakarta\activation\CommandObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */