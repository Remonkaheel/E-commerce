package jakarta.transaction;

public interface UserTransaction {
  void begin() throws NotSupportedException, SystemException;
  
  void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, IllegalStateException, SystemException;
  
  void rollback() throws IllegalStateException, SecurityException, SystemException;
  
  void setRollbackOnly() throws IllegalStateException, SystemException;
  
  int getStatus() throws SystemException;
  
  void setTransactionTimeout(int paramInt) throws SystemException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\UserTransaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */