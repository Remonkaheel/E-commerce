/*    */ package jakarta.transaction;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionRequiredException
/*    */   extends RemoteException
/*    */ {
/*    */   private static final long serialVersionUID = -1898806419937446439L;
/*    */   
/*    */   public TransactionRequiredException() {}
/*    */   
/*    */   public TransactionRequiredException(String msg) {
/* 40 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\TransactionRequiredException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */