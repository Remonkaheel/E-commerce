/*    */ package jakarta.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionalException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -8196645329560986417L;
/*    */   
/*    */   public TransactionalException(String s, Throwable throwable) {
/* 43 */     super(s, throwable);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\TransactionalException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */