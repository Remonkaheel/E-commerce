/*    */ package jakarta.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeuristicCommitException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3977609782149921760L;
/*    */   
/*    */   public HeuristicCommitException() {}
/*    */   
/*    */   public HeuristicCommitException(String msg) {
/* 40 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\HeuristicCommitException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */