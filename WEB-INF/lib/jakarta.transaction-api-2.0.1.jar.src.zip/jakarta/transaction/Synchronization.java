package jakarta.transaction;

public interface Synchronization {
  void beforeCompletion();
  
  void afterCompletion(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\Synchronization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */