/*    */ package jakarta.transaction;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionRolledbackException
/*    */   extends RemoteException
/*    */ {
/*    */   private static final long serialVersionUID = -3142798139623020577L;
/*    */   
/*    */   public TransactionRolledbackException() {}
/*    */   
/*    */   public TransactionRolledbackException(String msg) {
/* 43 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\TransactionRolledbackException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */