/*    */ package jakarta.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeuristicRollbackException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3483618944556408897L;
/*    */   
/*    */   public HeuristicRollbackException() {}
/*    */   
/*    */   public HeuristicRollbackException(String msg) {
/* 39 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\HeuristicRollbackException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */