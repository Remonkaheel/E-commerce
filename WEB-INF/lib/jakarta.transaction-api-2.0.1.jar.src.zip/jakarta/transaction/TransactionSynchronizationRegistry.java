package jakarta.transaction;

public interface TransactionSynchronizationRegistry {
  Object getTransactionKey();
  
  void putResource(Object paramObject1, Object paramObject2);
  
  Object getResource(Object paramObject);
  
  void registerInterposedSynchronization(Synchronization paramSynchronization);
  
  int getTransactionStatus();
  
  void setRollbackOnly();
  
  boolean getRollbackOnly();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\TransactionSynchronizationRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */