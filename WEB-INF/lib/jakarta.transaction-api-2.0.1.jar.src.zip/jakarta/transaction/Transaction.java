package jakarta.transaction;

import javax.transaction.xa.XAResource;

public interface Transaction {
  void commit() throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, IllegalStateException, SystemException;
  
  boolean delistResource(XAResource paramXAResource, int paramInt) throws IllegalStateException, SystemException;
  
  boolean enlistResource(XAResource paramXAResource) throws RollbackException, IllegalStateException, SystemException;
  
  int getStatus() throws SystemException;
  
  void registerSynchronization(Synchronization paramSynchronization) throws RollbackException, IllegalStateException, SystemException;
  
  void rollback() throws IllegalStateException, SystemException;
  
  void setRollbackOnly() throws IllegalStateException, SystemException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\Transaction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */