/*    */ package jakarta.transaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeuristicMixedException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 2345014349685956666L;
/*    */   
/*    */   public HeuristicMixedException() {}
/*    */   
/*    */   public HeuristicMixedException(String msg) {
/* 40 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\HeuristicMixedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */