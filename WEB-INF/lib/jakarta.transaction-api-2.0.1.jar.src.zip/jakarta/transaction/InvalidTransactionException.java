/*    */ package jakarta.transaction;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidTransactionException
/*    */   extends RemoteException
/*    */ {
/*    */   private static final long serialVersionUID = 3597320220337691496L;
/*    */   
/*    */   public InvalidTransactionException() {}
/*    */   
/*    */   public InvalidTransactionException(String msg) {
/* 40 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\jakarta\transaction\InvalidTransactionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */