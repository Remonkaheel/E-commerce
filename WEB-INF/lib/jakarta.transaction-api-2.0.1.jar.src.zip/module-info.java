module jakarta.transaction {
  requires java.base;
  requires java.rmi;
  requires transitive java.transaction.xa;
  requires transitive jakarta.cdi;
  requires jakarta.interceptor;
  
  exports jakarta.transaction;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jakarta.transaction-api-2.0.1.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */