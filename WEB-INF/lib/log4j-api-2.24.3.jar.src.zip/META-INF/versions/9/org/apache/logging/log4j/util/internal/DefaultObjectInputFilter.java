/*    */ package META-INF.versions.9.org.apache.logging.log4j.util.internal;
/*    */ 
/*    */ import java.io.ObjectInputFilter;
/*    */ import org.apache.logging.log4j.util.internal.SerializationUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultObjectInputFilter
/*    */   implements ObjectInputFilter
/*    */ {
/*    */   private final ObjectInputFilter delegate;
/*    */   
/*    */   public DefaultObjectInputFilter() {
/* 29 */     this.delegate = null;
/*    */   }
/*    */   
/*    */   public DefaultObjectInputFilter(ObjectInputFilter filter) {
/* 33 */     this.delegate = filter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static org.apache.logging.log4j.util.internal.DefaultObjectInputFilter newInstance(ObjectInputFilter filter) {
/* 42 */     return new org.apache.logging.log4j.util.internal.DefaultObjectInputFilter(filter);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ObjectInputFilter.Status checkInput(ObjectInputFilter.FilterInfo filterInfo) {
/* 48 */     if (this.delegate != null) {
/* 49 */       ObjectInputFilter.Status status = this.delegate.checkInput(filterInfo);
/* 50 */       if (status != ObjectInputFilter.Status.UNDECIDED) {
/* 51 */         return status;
/*    */       }
/*    */     } 
/* 54 */     ObjectInputFilter serialFilter = ObjectInputFilter.Config.getSerialFilter();
/* 55 */     if (serialFilter != null) {
/* 56 */       ObjectInputFilter.Status status = serialFilter.checkInput(filterInfo);
/* 57 */       if (status != ObjectInputFilter.Status.UNDECIDED)
/*    */       {
/* 59 */         return status;
/*    */       }
/*    */     } 
/* 62 */     Class<?> serialClass = filterInfo.serialClass();
/* 63 */     if (serialClass != null) {
/* 64 */       String name = SerializationUtil.stripArray(serialClass);
/* 65 */       if (isAllowedByDefault(name)) {
/* 66 */         return ObjectInputFilter.Status.ALLOWED;
/*    */       }
/*    */     } else {
/*    */       
/* 70 */       return ObjectInputFilter.Status.ALLOWED;
/*    */     } 
/* 72 */     return ObjectInputFilter.Status.REJECTED;
/*    */   }
/*    */   
/*    */   private static boolean isAllowedByDefault(String name) {
/* 76 */     return (isRequiredPackage(name) || SerializationUtil.REQUIRED_JAVA_CLASSES.contains(name));
/*    */   }
/*    */   
/*    */   private static boolean isRequiredPackage(String name) {
/* 80 */     for (String packageName : SerializationUtil.REQUIRED_JAVA_PACKAGES) {
/* 81 */       if (name.startsWith(packageName)) {
/* 82 */         return true;
/*    */       }
/*    */     } 
/* 85 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\META-INF\versions\9\org\apache\logging\log4\\util\internal\DefaultObjectInputFilter.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */