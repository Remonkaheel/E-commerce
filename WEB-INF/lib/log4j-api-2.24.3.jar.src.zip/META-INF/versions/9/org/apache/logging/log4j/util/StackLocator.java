/*     */ package META-INF.versions.9.org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.logging.log4j.util.PrivateSecurityManagerStackTraceUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackLocator
/*     */ {
/*  28 */   private static final StackWalker WALKER = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);
/*     */   
/*  30 */   private static final StackWalker STACK_WALKER = StackWalker.getInstance();
/*     */   
/*  32 */   private static final org.apache.logging.log4j.util.StackLocator INSTANCE = new org.apache.logging.log4j.util.StackLocator();
/*     */   
/*     */   public static org.apache.logging.log4j.util.StackLocator getInstance() {
/*  35 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCallerClass(Class<?> sentinelClass, Predicate<Class<?>> callerPredicate) {
/*  41 */     if (sentinelClass == null) {
/*  42 */       throw new IllegalArgumentException("sentinelClass cannot be null");
/*     */     }
/*  44 */     if (callerPredicate == null) {
/*  45 */       throw new IllegalArgumentException("callerPredicate cannot be null");
/*     */     }
/*  47 */     return WALKER.<Class<?>>walk(s -> (Class)s.map(StackWalker.StackFrame::getDeclaringClass).dropWhile(()).dropWhile(()).findFirst().orElse(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCallerClass(String fqcn) {
/*  57 */     return getCallerClass(fqcn, "");
/*     */   }
/*     */   
/*     */   public Class<?> getCallerClass(String fqcn, String pkg) {
/*  61 */     return ((Optional)WALKER.<Optional>walk(s -> s.dropWhile(()).dropWhile(()).dropWhile(()).findFirst()))
/*     */ 
/*     */ 
/*     */       
/*  65 */       .map(StackWalker.StackFrame::getDeclaringClass)
/*  66 */       .orElse(null);
/*     */   }
/*     */   
/*     */   public Class<?> getCallerClass(Class<?> anchor) {
/*  70 */     return ((Optional)WALKER.<Optional>walk(s -> s.dropWhile(()).dropWhile(()).findFirst()))
/*     */ 
/*     */       
/*  73 */       .map(StackWalker.StackFrame::getDeclaringClass)
/*  74 */       .orElse(null);
/*     */   }
/*     */   
/*     */   public Class<?> getCallerClass(int depth) {
/*  78 */     return ((Optional)WALKER.<Optional>walk(s -> s.skip(depth).findFirst()))
/*  79 */       .map(StackWalker.StackFrame::getDeclaringClass)
/*  80 */       .orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Deque<Class<?>> getCurrentStackTrace() {
/*  85 */     if (PrivateSecurityManagerStackTraceUtil.isEnabled()) {
/*  86 */       return PrivateSecurityManagerStackTraceUtil.getCurrentStackTrace();
/*     */     }
/*  88 */     Deque<Class<?>> stack = new ArrayDeque<>();
/*  89 */     return WALKER.<Deque<Class<?>>>walk(s -> {
/*     */           s.forEach(());
/*     */           return stack;
/*     */         });
/*     */   }
/*     */   
/*     */   public StackTraceElement calcLocation(String fqcnOfLogger) {
/*  96 */     return ((Optional)STACK_WALKER
/*  97 */       .<Optional>walk(s -> s.dropWhile(()).dropWhile(()).findFirst()))
/*     */ 
/*     */ 
/*     */       
/* 101 */       .map(StackWalker.StackFrame::toStackTraceElement)
/* 102 */       .orElse(null);
/*     */   }
/*     */   
/*     */   public StackTraceElement getStackTraceElement(int depth) {
/* 106 */     return ((Optional)STACK_WALKER
/* 107 */       .<Optional>walk(s -> s.skip(depth).findFirst()))
/* 108 */       .map(StackWalker.StackFrame::toStackTraceElement)
/* 109 */       .orElse(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\META-INF\versions\9\org\apache\logging\log4\\util\StackLocator.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */