module org.apache.logging.log4j {
  requires java.base;
  requires java.management;
  requires java.sql;
  requires org.jspecify;
  requires org.osgi.core;
  
  exports org.apache.logging.log4j;
  exports org.apache.logging.log4j.message;
  exports org.apache.logging.log4j.simple;
  exports org.apache.logging.log4j.spi;
  exports org.apache.logging.log4j.status;
  exports org.apache.logging.log4j.util;
  
  uses org.apache.logging.log4j.message.ThreadDumpMessage$ThreadInfoFactory;
  uses org.apache.logging.log4j.spi.Provider;
  uses org.apache.logging.log4j.util.PropertySource;
  
  provides org.apache.logging.log4j.util.PropertySource with
    org.apache.logging.log4j.util.EnvironmentPropertySource,
    org.apache.logging.log4j.util.SystemPropertiesPropertySource;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */