/*     */ package org.apache.logging.log4j.internal.map;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.apache.logging.log4j.util.BiConsumer;
/*     */ import org.apache.logging.log4j.util.ReadOnlyStringMap;
/*     */ import org.apache.logging.log4j.util.TriConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnmodifiableArrayBackedMap
/*     */   extends AbstractMap<String, String>
/*     */   implements Serializable, ReadOnlyStringMap
/*     */ {
/*     */   private static final long serialVersionUID = 6849423432534211514L;
/*     */   
/*     */   private class UnmodifiableEntry
/*     */     implements Map.Entry<String, String>
/*     */   {
/*     */     private int index;
/*     */     
/*     */     public UnmodifiableEntry(int index) {
/*  75 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getKey() {
/*  80 */       return (String)UnmodifiableArrayBackedMap.this.backingArray[UnmodifiableArrayBackedMap.getArrayIndexForKey(this.index)];
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/*  85 */       return (String)UnmodifiableArrayBackedMap.this.backingArray[UnmodifiableArrayBackedMap.getArrayIndexForValue(this.index)];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  93 */       String key = (String)UnmodifiableArrayBackedMap.this.backingArray[UnmodifiableArrayBackedMap.getArrayIndexForKey(this.index)];
/*  94 */       String value = (String)UnmodifiableArrayBackedMap.this.backingArray[UnmodifiableArrayBackedMap.getArrayIndexForValue(this.index)];
/*  95 */       return Objects.hashCode(key) ^ Objects.hashCode(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String setValue(String value) {
/* 100 */       throw new UnsupportedOperationException("Cannot update Entry instances in UnmodifiableArrayBackedMap");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class UnmodifiableEntryIterator
/*     */     implements Iterator<Map.Entry<String, String>>
/*     */   {
/*     */     private int index;
/*     */     
/*     */     private UnmodifiableEntryIterator() {}
/*     */     
/*     */     public boolean hasNext() {
/* 113 */       return (this.index < UnmodifiableArrayBackedMap.this.numEntries);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<String, String> next() {
/* 118 */       return new UnmodifiableArrayBackedMap.UnmodifiableEntry(this.index++);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class UnmodifiableEntrySet
/*     */     extends AbstractSet<Map.Entry<String, String>>
/*     */   {
/*     */     private UnmodifiableEntrySet() {}
/*     */ 
/*     */     
/*     */     public boolean add(Map.Entry<String, String> e) {
/* 130 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends Map.Entry<String, String>> c) {
/* 135 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Map.Entry<String, String>> iterator() {
/* 140 */       return new UnmodifiableArrayBackedMap.UnmodifiableEntryIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 145 */       return UnmodifiableArrayBackedMap.this.numEntries;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 151 */   public static final UnmodifiableArrayBackedMap EMPTY_MAP = new UnmodifiableArrayBackedMap(0);
/*     */   
/*     */   private static final int NUM_FIXED_ARRAY_ENTRIES = 1;
/*     */   
/*     */   private static int getArrayIndexForKey(int entryIndex) {
/* 156 */     return 2 * entryIndex + 1;
/*     */   }
/*     */   private Object[] backingArray; private int numEntries;
/*     */   private static int getArrayIndexForValue(int entryIndex) {
/* 160 */     return 2 * entryIndex + 1 + 1;
/*     */   }
/*     */   
/*     */   public static UnmodifiableArrayBackedMap getMap(Object[] backingArray) {
/* 164 */     if (backingArray == null || backingArray.length == 1) {
/* 165 */       return EMPTY_MAP;
/*     */     }
/* 167 */     return new UnmodifiableArrayBackedMap(backingArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UnmodifiableArrayBackedMap(int capacity) {
/* 181 */     this.backingArray = new Object[capacity * 2 + 1];
/* 182 */     this.backingArray[0] = Integer.valueOf(0);
/*     */   }
/*     */   
/*     */   private UnmodifiableArrayBackedMap(Object[] backingArray) {
/* 186 */     this.numEntries = (backingArray == null) ? 0 : ((Integer)backingArray[0]).intValue();
/* 187 */     this.backingArray = backingArray;
/*     */   }
/*     */   
/*     */   UnmodifiableArrayBackedMap(UnmodifiableArrayBackedMap other) {
/* 191 */     this.backingArray = other.backingArray;
/* 192 */     this.numEntries = other.numEntries;
/*     */   }
/*     */   
/*     */   private void add(String key, String value) {
/* 196 */     this.backingArray[getArrayIndexForKey(this.numEntries)] = key;
/* 197 */     this.backingArray[getArrayIndexForValue(this.numEntries)] = value;
/* 198 */     this.numEntries++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 203 */     throw new UnsupportedOperationException("Instance cannot be cleared, reuse EMPTY_MAP instead.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 211 */     return containsKey((String)key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 216 */     int hashCode = key.hashCode();
/* 217 */     for (int i = 0; i < this.numEntries; i++) {
/* 218 */       if (this.backingArray[getArrayIndexForKey(i)].hashCode() == hashCode && this.backingArray[
/* 219 */           getArrayIndexForKey(i)].equals(key)) {
/* 220 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 224 */     return false;
/*     */   }
/*     */   
/*     */   public Object[] getBackingArray() {
/* 228 */     return this.backingArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 237 */     for (int i = 0; i < this.numEntries; i++) {
/* 238 */       Object valueInMap = this.backingArray[getArrayIndexForValue(i)];
/* 239 */       if (value == null) {
/* 240 */         if (valueInMap == null) {
/* 241 */           return true;
/*     */         }
/* 243 */       } else if (value.equals(valueInMap)) {
/* 244 */         return true;
/*     */       } 
/*     */     } 
/* 247 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnmodifiableArrayBackedMap copyAndPut(String key, String value) {
/* 259 */     UnmodifiableArrayBackedMap newMap = new UnmodifiableArrayBackedMap(this.numEntries + 1);
/*     */     
/* 261 */     if (this.numEntries > 0) {
/* 262 */       System.arraycopy(this.backingArray, 1, newMap.backingArray, 1, this.numEntries * 2);
/* 263 */       newMap.numEntries = this.numEntries;
/*     */     } 
/* 265 */     newMap.addOrOverwriteKey(key, value);
/* 266 */     newMap.updateNumEntriesInArray();
/* 267 */     return newMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnmodifiableArrayBackedMap copyAndPutAll(Map<String, String> entriesToAdd) {
/* 280 */     UnmodifiableArrayBackedMap newMap = new UnmodifiableArrayBackedMap(this.numEntries + entriesToAdd.size());
/*     */ 
/*     */     
/* 283 */     if (this.numEntries > 0) {
/* 284 */       System.arraycopy(this.backingArray, 0, newMap.backingArray, 0, this.numEntries * 2 + 1);
/* 285 */       newMap.numEntries = this.numEntries;
/*     */     } 
/*     */     
/* 288 */     for (Map.Entry<String, String> entry : entriesToAdd.entrySet()) {
/* 289 */       String key = entry.getKey();
/* 290 */       String value = entry.getValue();
/* 291 */       if (!isEmpty()) {
/*     */ 
/*     */         
/* 294 */         newMap.addOrOverwriteKey(key, value);
/*     */         continue;
/*     */       } 
/* 297 */       newMap.add(key, value);
/*     */     } 
/*     */ 
/*     */     
/* 301 */     newMap.updateNumEntriesInArray();
/* 302 */     return newMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnmodifiableArrayBackedMap copyAndRemove(String key) {
/* 314 */     int indexToRemove = -1;
/* 315 */     for (int oldIndex = this.numEntries - 1; oldIndex >= 0; oldIndex--) {
/* 316 */       if (this.backingArray[getArrayIndexForKey(oldIndex)].hashCode() == key.hashCode() && this.backingArray[
/* 317 */           getArrayIndexForKey(oldIndex)].equals(key)) {
/* 318 */         indexToRemove = oldIndex;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 323 */     if (indexToRemove == -1)
/*     */     {
/* 325 */       return this; } 
/* 326 */     if (this.numEntries == 1)
/*     */     {
/* 328 */       return EMPTY_MAP;
/*     */     }
/* 330 */     UnmodifiableArrayBackedMap newMap = new UnmodifiableArrayBackedMap(this.numEntries);
/* 331 */     if (indexToRemove > 0)
/*     */     {
/* 333 */       System.arraycopy(this.backingArray, 1, newMap.backingArray, 1, indexToRemove * 2);
/*     */     }
/* 335 */     if (indexToRemove + 1 < this.numEntries) {
/*     */       
/* 337 */       int nextIndexToCopy = indexToRemove + 1;
/* 338 */       int numRemainingEntries = this.numEntries - nextIndexToCopy;
/* 339 */       System.arraycopy(this.backingArray, 
/*     */           
/* 341 */           getArrayIndexForKey(nextIndexToCopy), newMap.backingArray, 
/*     */           
/* 343 */           getArrayIndexForKey(indexToRemove), numRemainingEntries * 2);
/*     */     } 
/*     */ 
/*     */     
/* 347 */     this.numEntries--;
/* 348 */     newMap.updateNumEntriesInArray();
/* 349 */     return newMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnmodifiableArrayBackedMap copyAndRemoveAll(Iterable<String> keysToRemoveIterable) {
/*     */     Set<String> keysToRemove;
/* 358 */     if (isEmpty()) {
/* 359 */       return EMPTY_MAP;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 364 */     if (keysToRemoveIterable instanceof Set) {
/* 365 */       keysToRemove = (Set<String>)keysToRemoveIterable;
/*     */     } else {
/* 367 */       keysToRemove = new HashSet<>();
/* 368 */       for (String key : keysToRemoveIterable) {
/* 369 */         keysToRemove.add(key);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 374 */     UnmodifiableArrayBackedMap oldMap = this;
/* 375 */     int oldMapEntryCount = oldMap.numEntries;
/* 376 */     UnmodifiableArrayBackedMap newMap = new UnmodifiableArrayBackedMap(oldMapEntryCount);
/*     */ 
/*     */     
/* 379 */     if (keysToRemove.isEmpty()) {
/* 380 */       System.arraycopy(oldMap.backingArray, 0, newMap.backingArray, 0, oldMapEntryCount * 2);
/* 381 */       newMap.numEntries = oldMapEntryCount;
/* 382 */       return this;
/*     */     } 
/*     */ 
/*     */     
/* 386 */     int newMapEntryIndex = 0;
/* 387 */     for (int oldMapEntryIndex = 0; oldMapEntryIndex < oldMapEntryCount; oldMapEntryIndex++) {
/* 388 */       int oldMapKeyIndex = getArrayIndexForKey(oldMapEntryIndex);
/* 389 */       Object key = oldMap.backingArray[oldMapKeyIndex];
/*     */ 
/*     */ 
/*     */       
/* 393 */       boolean removed = keysToRemove.contains(key);
/* 394 */       if (!removed) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 399 */         int oldMapValueIndex = getArrayIndexForValue(oldMapEntryIndex);
/* 400 */         Object value = oldMap.backingArray[oldMapValueIndex];
/* 401 */         int newMapKeyIndex = getArrayIndexForKey(newMapEntryIndex);
/* 402 */         int newMapValueIndex = getArrayIndexForValue(newMapEntryIndex);
/* 403 */         newMap.backingArray[newMapKeyIndex] = key;
/* 404 */         newMap.backingArray[newMapValueIndex] = value;
/* 405 */         newMapEntryIndex++;
/*     */       } 
/*     */     } 
/*     */     
/* 409 */     newMap.numEntries = newMapEntryIndex;
/* 410 */     newMap.updateNumEntriesInArray();
/* 411 */     return newMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateNumEntriesInArray() {
/* 420 */     this.backingArray[0] = Integer.valueOf(this.numEntries);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<? super String, ? super String> action) {
/* 428 */     for (int i = 0; i < this.numEntries; i++) {
/*     */       
/* 430 */       String key = (String)this.backingArray[getArrayIndexForKey(i)];
/* 431 */       String value = (String)this.backingArray[getArrayIndexForValue(i)];
/* 432 */       action.accept(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> void forEach(BiConsumer<String, ? super V> action) {
/* 442 */     for (int i = 0; i < this.numEntries; i++) {
/*     */       
/* 444 */       String key = (String)this.backingArray[getArrayIndexForKey(i)];
/* 445 */       V value = (V)this.backingArray[getArrayIndexForValue(i)];
/* 446 */       action.accept(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <V, S> void forEach(TriConsumer<String, ? super V, S> action, S state) {
/* 452 */     for (int i = 0; i < this.numEntries; i++) {
/*     */       
/* 454 */       String key = (String)this.backingArray[getArrayIndexForKey(i)];
/* 455 */       V value = (V)this.backingArray[getArrayIndexForValue(i)];
/* 456 */       action.accept(key, value, state);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, String>> entrySet() {
/* 462 */     return new UnmodifiableEntrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(Object key) {
/* 470 */     return getValue((String)key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> V getValue(String key) {
/* 476 */     if (this.numEntries == 0) {
/* 477 */       return null;
/*     */     }
/* 479 */     int hashCode = key.hashCode();
/* 480 */     for (int i = 0; i < this.numEntries; i++) {
/* 481 */       if (this.backingArray[getArrayIndexForKey(i)].hashCode() == hashCode && this.backingArray[
/* 482 */           getArrayIndexForKey(i)].equals(key)) {
/* 483 */         return (V)this.backingArray[getArrayIndexForValue(i)];
/*     */       }
/*     */     } 
/* 486 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addOrOverwriteKey(String key, String value) {
/* 497 */     int keyHashCode = key.hashCode();
/* 498 */     for (int i = 0; i < this.numEntries; i++) {
/* 499 */       if (this.backingArray[getArrayIndexForKey(i)].hashCode() == keyHashCode && this.backingArray[
/* 500 */           getArrayIndexForKey(i)].equals(key)) {
/*     */         
/* 502 */         this.backingArray[getArrayIndexForValue(i)] = value;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 508 */     add(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String put(String key, String value) {
/* 513 */     throw new UnsupportedOperationException("put() is not supported, use copyAndPut instead");
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends String> m) {
/* 518 */     throw new UnsupportedOperationException("putAll() is not supported, use copyAndPutAll instead");
/*     */   }
/*     */ 
/*     */   
/*     */   public String remove(Object key) {
/* 523 */     throw new UnsupportedOperationException("remove() is not supported, use copyAndRemove instead");
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 528 */     return this.numEntries;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toMap() {
/* 533 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\internal\map\UnmodifiableArrayBackedMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */