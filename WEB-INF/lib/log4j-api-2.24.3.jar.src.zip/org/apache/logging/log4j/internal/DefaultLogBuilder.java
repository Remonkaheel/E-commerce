/*     */ package org.apache.logging.log4j.internal;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.logging.log4j.BridgeAware;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogBuilder;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.SimpleMessage;
/*     */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.LambdaUtil;
/*     */ import org.apache.logging.log4j.util.StackLocatorUtil;
/*     */ import org.apache.logging.log4j.util.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultLogBuilder
/*     */   implements BridgeAware, LogBuilder
/*     */ {
/*  38 */   private static Message EMPTY_MESSAGE = (Message)new SimpleMessage("");
/*  39 */   private static final String FQCN = DefaultLogBuilder.class.getName();
/*  40 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */   
/*     */   private ExtendedLogger logger;
/*     */   private Level level;
/*     */   private Marker marker;
/*     */   private Throwable throwable;
/*     */   private StackTraceElement location;
/*     */   private volatile boolean inUse;
/*     */   private long threadId;
/*  49 */   private String fqcn = FQCN;
/*     */   
/*     */   public DefaultLogBuilder(ExtendedLogger logger, Level level) {
/*  52 */     this.logger = logger;
/*  53 */     this.level = level;
/*  54 */     this.threadId = Thread.currentThread().getId();
/*  55 */     this.inUse = (level != null);
/*     */   }
/*     */   
/*     */   public DefaultLogBuilder() {
/*  59 */     this(null, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEntryPoint(String fqcn) {
/*  64 */     this.fqcn = fqcn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogBuilder reset(ExtendedLogger logger, Level level) {
/*  73 */     this.logger = logger;
/*  74 */     this.level = level;
/*  75 */     this.marker = null;
/*  76 */     this.throwable = null;
/*  77 */     this.location = null;
/*  78 */     this.inUse = true;
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withMarker(Marker marker) {
/*  84 */     this.marker = marker;
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withThrowable(Throwable throwable) {
/*  90 */     this.throwable = throwable;
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withLocation() {
/*  96 */     this.location = StackLocatorUtil.getStackTraceElement(2);
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogBuilder withLocation(StackTraceElement location) {
/* 102 */     this.location = location;
/* 103 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isInUse() {
/* 107 */     return this.inUse;
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Message message) {
/* 112 */     if (isValid() && isEnabled(message)) {
/* 113 */       logMessage(message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Message logAndGet(Supplier<Message> messageSupplier) {
/* 120 */     Message message = null;
/* 121 */     if (isValid() && isEnabled(message = (Message)messageSupplier.get())) {
/* 122 */       logMessage(message);
/*     */     }
/* 124 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(CharSequence message) {
/* 129 */     if (isValid() && isEnabled(message)) {
/* 130 */       logMessage(this.logger.getMessageFactory().newMessage(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message) {
/* 136 */     if (isValid() && isEnabled(message)) {
/* 137 */       logMessage(this.logger.getMessageFactory().newMessage(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object... params) {
/* 143 */     if (isValid() && isEnabled(message, params)) {
/* 144 */       logMessage(this.logger.getMessageFactory().newMessage(message, params));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Supplier<?>... params) {
/*     */     Object[] objs;
/* 152 */     if (isValid() && isEnabled(message, objs = LambdaUtil.getAll((Supplier[])params))) {
/* 153 */       logMessage(this.logger.getMessageFactory().newMessage(message, objs));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(Supplier<Message> messageSupplier) {
/* 160 */     logAndGet(messageSupplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Object message) {
/* 165 */     if (isValid() && isEnabled(message)) {
/* 166 */       logMessage(this.logger.getMessageFactory().newMessage(message));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0) {
/* 172 */     if (isValid() && isEnabled(message, p0)) {
/* 173 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1) {
/* 179 */     if (isValid() && isEnabled(message, p0, p1)) {
/* 180 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2) {
/* 186 */     if (isValid() && isEnabled(message, p0, p1, p2)) {
/* 187 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3) {
/* 193 */     if (isValid() && isEnabled(message, p0, p1, p2, p3)) {
/* 194 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 200 */     if (isValid() && isEnabled(message, p0, p1, p2, p3, p4)) {
/* 201 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 207 */     if (isValid() && isEnabled(message, p0, p1, p2, p3, p4, p5)) {
/* 208 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 214 */     if (isValid() && isEnabled(message, p0, p1, p2, p3, p4, p5, p6)) {
/* 215 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 222 */     if (isValid() && isEnabled(message, p0, p1, p2, p3, p4, p5, p6, p7)) {
/* 223 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 239 */     if (isValid() && isEnabled(message, p0, p1, p2, p3, p4, p5, p6, p7, p8)) {
/* 240 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7, p8 }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 257 */     if (isValid() && isEnabled(message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)) {
/* 258 */       logMessage(this.logger.getMessageFactory().newMessage(message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void log() {
/* 264 */     if (isValid() && isEnabled(EMPTY_MESSAGE)) {
/* 265 */       logMessage(EMPTY_MESSAGE);
/*     */     }
/*     */   }
/*     */   
/*     */   private void logMessage(Message message) {
/*     */     try {
/* 271 */       this.logger.logMessage(this.level, this.marker, this.fqcn, this.location, message, this.throwable);
/*     */     } finally {
/* 273 */       this.inUse = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isValid() {
/* 278 */     if (!this.inUse) {
/* 279 */       LOGGER.warn("Attempt to reuse LogBuilder was ignored. {}", StackLocatorUtil.getCallerClass(2));
/* 280 */       return false;
/*     */     } 
/* 282 */     if (this.threadId != Thread.currentThread().getId()) {
/* 283 */       LOGGER.warn("LogBuilder can only be used on the owning thread. {}", StackLocatorUtil.getCallerClass(2));
/* 284 */       return false;
/*     */     } 
/* 286 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(Message message) {
/* 290 */     return this.logger.isEnabled(this.level, this.marker, message, this.throwable);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(CharSequence message) {
/* 294 */     return this.logger.isEnabled(this.level, this.marker, message, this.throwable);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message) {
/* 298 */     return this.logger.isEnabled(this.level, this.marker, message, this.throwable);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object... params) {
/*     */     Object[] newParams;
/* 303 */     if (this.throwable != null) {
/* 304 */       newParams = Arrays.copyOf(params, params.length + 1);
/* 305 */       newParams[params.length] = this.throwable;
/*     */     } else {
/* 307 */       newParams = params;
/*     */     } 
/* 309 */     return this.logger.isEnabled(this.level, this.marker, message, newParams);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(Object message) {
/* 313 */     return this.logger.isEnabled(this.level, this.marker, message, this.throwable);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0) {
/* 317 */     return (this.throwable != null) ? 
/* 318 */       this.logger.isEnabled(this.level, this.marker, message, p0, this.throwable) : 
/* 319 */       this.logger.isEnabled(this.level, this.marker, message, p0);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1) {
/* 323 */     return (this.throwable != null) ? 
/* 324 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, this.throwable) : 
/* 325 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2) {
/* 329 */     return (this.throwable != null) ? 
/* 330 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, this.throwable) : 
/* 331 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3) {
/* 335 */     return (this.throwable != null) ? 
/* 336 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, this.throwable) : 
/* 337 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 341 */     return (this.throwable != null) ? 
/* 342 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, this.throwable) : 
/* 343 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4);
/*     */   }
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 347 */     return (this.throwable != null) ? 
/* 348 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, this.throwable) : 
/* 349 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 354 */     return (this.throwable != null) ? 
/* 355 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6, this.throwable) : 
/* 356 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 361 */     return (this.throwable != null) ? 
/* 362 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6, p7, this.throwable) : 
/* 363 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 377 */     return (this.throwable != null) ? 
/* 378 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, this.throwable) : 
/* 379 */       this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEnabled(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 394 */     return (this.throwable != null) ? 
/* 395 */       this.logger.isEnabled(this.level, this.marker, message, new Object[] { p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, this.throwable
/* 396 */         }) : this.logger.isEnabled(this.level, this.marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\internal\DefaultLogBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */