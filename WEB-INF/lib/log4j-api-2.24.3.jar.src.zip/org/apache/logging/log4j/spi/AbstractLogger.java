/*      */ package org.apache.logging.log4j.spi;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.util.function.Supplier;
/*      */ import org.apache.logging.log4j.Level;
/*      */ import org.apache.logging.log4j.LogBuilder;
/*      */ import org.apache.logging.log4j.LoggingException;
/*      */ import org.apache.logging.log4j.Marker;
/*      */ import org.apache.logging.log4j.MarkerManager;
/*      */ import org.apache.logging.log4j.internal.DefaultLogBuilder;
/*      */ import org.apache.logging.log4j.message.DefaultFlowMessageFactory;
/*      */ import org.apache.logging.log4j.message.EntryMessage;
/*      */ import org.apache.logging.log4j.message.FlowMessageFactory;
/*      */ import org.apache.logging.log4j.message.Message;
/*      */ import org.apache.logging.log4j.message.MessageFactory;
/*      */ import org.apache.logging.log4j.message.MessageFactory2;
/*      */ import org.apache.logging.log4j.message.ParameterizedMessageFactory;
/*      */ import org.apache.logging.log4j.message.ReusableMessageFactory;
/*      */ import org.apache.logging.log4j.message.StringFormattedMessage;
/*      */ import org.apache.logging.log4j.status.StatusLogger;
/*      */ import org.apache.logging.log4j.util.Constants;
/*      */ import org.apache.logging.log4j.util.LambdaUtil;
/*      */ import org.apache.logging.log4j.util.MessageSupplier;
/*      */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*      */ import org.apache.logging.log4j.util.StackLocatorUtil;
/*      */ import org.apache.logging.log4j.util.Supplier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractLogger
/*      */   implements ExtendedLogger, LocationAwareLogger, Serializable
/*      */ {
/*   55 */   public static final Marker FLOW_MARKER = MarkerManager.getMarker("FLOW");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   60 */   public static final Marker ENTRY_MARKER = MarkerManager.getMarker("ENTER").setParents(new Marker[] { FLOW_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   65 */   public static final Marker EXIT_MARKER = MarkerManager.getMarker("EXIT").setParents(new Marker[] { FLOW_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   70 */   public static final Marker EXCEPTION_MARKER = MarkerManager.getMarker("EXCEPTION");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   76 */   public static final Marker THROWING_MARKER = MarkerManager.getMarker("THROWING").setParents(new Marker[] { EXCEPTION_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   public static final Marker CATCHING_MARKER = MarkerManager.getMarker("CATCHING").setParents(new Marker[] { EXCEPTION_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   87 */   public static final Class<? extends MessageFactory> DEFAULT_MESSAGE_FACTORY_CLASS = (Class)ParameterizedMessageFactory.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   public static final Class<? extends FlowMessageFactory> DEFAULT_FLOW_MESSAGE_FACTORY_CLASS = (Class)DefaultFlowMessageFactory.class;
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 2L;
/*      */   
/*   98 */   private static final String FQCN = AbstractLogger.class.getName();
/*      */   
/*      */   private static final String THROWING = "Throwing";
/*      */   private static final String CATCHING = "Catching";
/*      */   protected final String name;
/*      */   private final MessageFactory2 messageFactory;
/*      */   private final FlowMessageFactory flowMessageFactory;
/*  105 */   private static final ThreadLocal<int[]> recursionDepthHolder = (ThreadLocal)new ThreadLocal<>();
/*  106 */   private static final ThreadLocal<DefaultLogBuilder> logBuilder = ThreadLocal.withInitial(DefaultLogBuilder::new);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractLogger() {
/*  112 */     this((String)null, (MessageFactory)null, (FlowMessageFactory)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractLogger(String name) {
/*  121 */     this(name, (MessageFactory)null, (FlowMessageFactory)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractLogger(String name, MessageFactory messageFactory) {
/*  131 */     this(name, messageFactory, (FlowMessageFactory)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractLogger(String name, MessageFactory messageFactory, FlowMessageFactory flowMessageFactory) {
/*  143 */     if (name != null) {
/*  144 */       this.name = name;
/*      */     } else {
/*  146 */       Class<? extends AbstractLogger> clazz = (Class)getClass();
/*  147 */       String canonicalName = clazz.getCanonicalName();
/*  148 */       this.name = (canonicalName != null) ? canonicalName : clazz.getName();
/*      */     } 
/*  150 */     this
/*  151 */       .messageFactory = (messageFactory != null) ? adaptMessageFactory(messageFactory) : (MessageFactory2)ParameterizedMessageFactory.INSTANCE;
/*  152 */     this.flowMessageFactory = (flowMessageFactory != null) ? flowMessageFactory : DefaultFlowMessageFactory.INSTANCE;
/*      */   }
/*      */   
/*      */   private static MessageFactory2 adaptMessageFactory(MessageFactory result) {
/*  156 */     if (result instanceof MessageFactory2) {
/*  157 */       return (MessageFactory2)result;
/*      */     }
/*  159 */     return new MessageFactory2Adapter(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkMessageFactory(ExtendedLogger logger, MessageFactory messageFactory) {
/*  171 */     String name = logger.getName();
/*  172 */     MessageFactory loggerMessageFactory = logger.getMessageFactory();
/*  173 */     if (messageFactory != null && !loggerMessageFactory.equals(messageFactory)) {
/*  174 */       StatusLogger.getLogger()
/*  175 */         .warn("The Logger {} was created with the message factory {} and is now requested with the message factory {}, which may create log events with unexpected formatting.", name, loggerMessageFactory, messageFactory);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  181 */     else if (messageFactory == null && !loggerMessageFactory.getClass().equals(DEFAULT_MESSAGE_FACTORY_CLASS)) {
/*  182 */       StatusLogger.getLogger()
/*  183 */         .warn("The Logger {} was created with the message factory {} and is now requested with a null message factory (defaults to {}), which may create log events with unexpected formatting.", name, loggerMessageFactory, DEFAULT_MESSAGE_FACTORY_CLASS
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  189 */           .getName());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void catching(Level level, Throwable throwable) {
/*  195 */     catching(FQCN, level, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void catching(String fqcn, Level level, Throwable throwable) {
/*  206 */     if (isEnabled(level, CATCHING_MARKER, (Object)null, (Throwable)null)) {
/*  207 */       logMessageSafely(fqcn, level, CATCHING_MARKER, catchingMsg(throwable), throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void catching(Throwable throwable) {
/*  213 */     if (isEnabled(Level.ERROR, CATCHING_MARKER, (Object)null, (Throwable)null)) {
/*  214 */       logMessageSafely(FQCN, Level.ERROR, CATCHING_MARKER, catchingMsg(throwable), throwable);
/*      */     }
/*      */   }
/*      */   
/*      */   protected Message catchingMsg(Throwable throwable) {
/*  219 */     return this.messageFactory.newMessage("Catching");
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, CharSequence message) {
/*  224 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, CharSequence message, Throwable throwable) {
/*  229 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Message message) {
/*  234 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Message message, Throwable throwable) {
/*  239 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Object message) {
/*  244 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Object message, Throwable throwable) {
/*  249 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message) {
/*  254 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object... params) {
/*  259 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Throwable throwable) {
/*  264 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Message message) {
/*  269 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Message message, Throwable throwable) {
/*  274 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(CharSequence message) {
/*  279 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(CharSequence message, Throwable throwable) {
/*  284 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Object message) {
/*  289 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Object message, Throwable throwable) {
/*  294 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message) {
/*  299 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object... params) {
/*  304 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Throwable throwable) {
/*  309 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Supplier<?> messageSupplier) {
/*  315 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Supplier<?> messageSupplier, Throwable throwable) {
/*  321 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Supplier<?> messageSupplier) {
/*  327 */     logIfEnabled(FQCN, Level.DEBUG, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Supplier<?>... paramSuppliers) {
/*  333 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/*  339 */     logIfEnabled(FQCN, Level.DEBUG, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Supplier<?>... paramSuppliers) {
/*  345 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, MessageSupplier messageSupplier) {
/*  350 */     logIfEnabled(FQCN, Level.DEBUG, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/*  355 */     logIfEnabled(FQCN, Level.DEBUG, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(MessageSupplier messageSupplier) {
/*  360 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(MessageSupplier messageSupplier, Throwable throwable) {
/*  365 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0) {
/*  370 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1) {
/*  375 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2) {
/*  380 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/*  391 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  403 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  416 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  430 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  445 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  461 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  478 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0) {
/*  483 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1) {
/*  488 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2) {
/*  493 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3) {
/*  498 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  504 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  516 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  529 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  543 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  558 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  574 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EntryMessage enter(String fqcn, String format, Supplier<?>... paramSuppliers) {
/*  586 */     EntryMessage entryMsg = null;
/*  587 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  588 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, 
/*      */ 
/*      */ 
/*      */           
/*  592 */           (Message)(entryMsg = this.flowMessageFactory.newEntryMessage(format, LambdaUtil.getAll((Supplier[])paramSuppliers))), (Throwable)null);
/*      */     }
/*      */     
/*  595 */     return entryMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected EntryMessage enter(String fqcn, String format, MessageSupplier... paramSuppliers) {
/*  607 */     EntryMessage entryMsg = null;
/*  608 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  609 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)(entryMsg = entryMsg(format, paramSuppliers)), (Throwable)null);
/*      */     }
/*  611 */     return entryMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EntryMessage enter(String fqcn, String format, Object... params) {
/*  622 */     EntryMessage entryMsg = null;
/*  623 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  624 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, 
/*      */ 
/*      */ 
/*      */           
/*  628 */           (Message)(entryMsg = this.flowMessageFactory.newEntryMessage(format, params)), (Throwable)null);
/*      */     }
/*      */     
/*  631 */     return entryMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected EntryMessage enter(String fqcn, MessageSupplier messageSupplier) {
/*  642 */     EntryMessage message = null;
/*  643 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  644 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, 
/*      */ 
/*      */ 
/*      */           
/*  648 */           (Message)(message = this.flowMessageFactory.newEntryMessage(messageSupplier.get())), (Throwable)null);
/*      */     }
/*      */     
/*  651 */     return message;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EntryMessage enter(String fqcn, Message message) {
/*  664 */     EntryMessage flowMessage = null;
/*  665 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  666 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, 
/*  667 */           (Message)(flowMessage = this.flowMessageFactory.newEntryMessage(message)), (Throwable)null);
/*      */     }
/*  669 */     return flowMessage;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void entry() {
/*  675 */     entry(FQCN, (Object[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void entry(Object... params) {
/*  681 */     entry(FQCN, params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void entry(String fqcn, Object... params) {
/*  692 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  693 */       if (params == null) {
/*  694 */         logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)entryMsg((String)null, (Supplier<?>[])null), (Throwable)null);
/*      */       } else {
/*  696 */         logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)entryMsg((String)null, params), (Throwable)null);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected EntryMessage entryMsg(String format, Object... params) {
/*  702 */     return this.flowMessageFactory.newEntryMessage(format, params);
/*      */   }
/*      */   
/*      */   protected EntryMessage entryMsg(String format, MessageSupplier... paramSuppliers) {
/*  706 */     int count = (paramSuppliers == null) ? 0 : paramSuppliers.length;
/*  707 */     Object[] params = new Object[count];
/*  708 */     for (int i = 0; i < count; i++) {
/*  709 */       params[i] = paramSuppliers[i].get();
/*      */     }
/*  711 */     return entryMsg(format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   protected EntryMessage entryMsg(String format, Supplier<?>... paramSuppliers) {
/*  716 */     return entryMsg(format, LambdaUtil.getAll((Supplier[])paramSuppliers));
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Message message) {
/*  721 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Message message, Throwable throwable) {
/*  726 */     logIfEnabled(FQCN, Level.ERROR, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, CharSequence message) {
/*  731 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, CharSequence message, Throwable throwable) {
/*  736 */     logIfEnabled(FQCN, Level.ERROR, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Object message) {
/*  741 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Object message, Throwable throwable) {
/*  746 */     logIfEnabled(FQCN, Level.ERROR, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message) {
/*  751 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object... params) {
/*  756 */     logIfEnabled(FQCN, Level.ERROR, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Throwable throwable) {
/*  761 */     logIfEnabled(FQCN, Level.ERROR, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Message message) {
/*  766 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Message message, Throwable throwable) {
/*  771 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(CharSequence message) {
/*  776 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(CharSequence message, Throwable throwable) {
/*  781 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Object message) {
/*  786 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Object message, Throwable throwable) {
/*  791 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message) {
/*  796 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object... params) {
/*  801 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Throwable throwable) {
/*  806 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Supplier<?> messageSupplier) {
/*  812 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Supplier<?> messageSupplier, Throwable throwable) {
/*  818 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Supplier<?> messageSupplier) {
/*  824 */     logIfEnabled(FQCN, Level.ERROR, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Supplier<?>... paramSuppliers) {
/*  830 */     logIfEnabled(FQCN, Level.ERROR, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/*  836 */     logIfEnabled(FQCN, Level.ERROR, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Supplier<?>... paramSuppliers) {
/*  842 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, MessageSupplier messageSupplier) {
/*  847 */     logIfEnabled(FQCN, Level.ERROR, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/*  852 */     logIfEnabled(FQCN, Level.ERROR, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(MessageSupplier messageSupplier) {
/*  857 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(MessageSupplier messageSupplier, Throwable throwable) {
/*  862 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0) {
/*  867 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1) {
/*  872 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2) {
/*  877 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/*  888 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  900 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  913 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  927 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  942 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  958 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  975 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0) {
/*  980 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1) {
/*  985 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2) {
/*  990 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3) {
/*  995 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1001 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1013 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1026 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1040 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1055 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1071 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void exit() {
/* 1077 */     exit(FQCN, (Object)null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public <R> R exit(R result) {
/* 1083 */     return exit(FQCN, result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <R> R exit(String fqcn, R result) {
/* 1095 */     if (isEnabled(Level.TRACE, EXIT_MARKER, (CharSequence)null, (Throwable)null)) {
/* 1096 */       logMessageSafely(fqcn, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(null, result), (Throwable)null);
/*      */     }
/* 1098 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <R> R exit(String fqcn, String format, R result) {
/* 1110 */     if (isEnabled(Level.TRACE, EXIT_MARKER, (CharSequence)null, (Throwable)null)) {
/* 1111 */       logMessageSafely(fqcn, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(format, result), (Throwable)null);
/*      */     }
/* 1113 */     return result;
/*      */   }
/*      */   
/*      */   protected Message exitMsg(String format, Object result) {
/* 1117 */     return (Message)this.flowMessageFactory.newExitMessage(format, result);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Message message) {
/* 1122 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Message message, Throwable throwable) {
/* 1127 */     logIfEnabled(FQCN, Level.FATAL, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, CharSequence message) {
/* 1132 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, CharSequence message, Throwable throwable) {
/* 1137 */     logIfEnabled(FQCN, Level.FATAL, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Object message) {
/* 1142 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Object message, Throwable throwable) {
/* 1147 */     logIfEnabled(FQCN, Level.FATAL, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message) {
/* 1152 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object... params) {
/* 1157 */     logIfEnabled(FQCN, Level.FATAL, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Throwable throwable) {
/* 1162 */     logIfEnabled(FQCN, Level.FATAL, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Message message) {
/* 1167 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Message message, Throwable throwable) {
/* 1172 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(CharSequence message) {
/* 1177 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(CharSequence message, Throwable throwable) {
/* 1182 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Object message) {
/* 1187 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Object message, Throwable throwable) {
/* 1192 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message) {
/* 1197 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object... params) {
/* 1202 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Throwable throwable) {
/* 1207 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Supplier<?> messageSupplier) {
/* 1213 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Supplier<?> messageSupplier, Throwable throwable) {
/* 1219 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Supplier<?> messageSupplier) {
/* 1225 */     logIfEnabled(FQCN, Level.FATAL, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 1231 */     logIfEnabled(FQCN, Level.FATAL, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 1237 */     logIfEnabled(FQCN, Level.FATAL, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Supplier<?>... paramSuppliers) {
/* 1243 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, MessageSupplier messageSupplier) {
/* 1248 */     logIfEnabled(FQCN, Level.FATAL, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 1253 */     logIfEnabled(FQCN, Level.FATAL, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(MessageSupplier messageSupplier) {
/* 1258 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(MessageSupplier messageSupplier, Throwable throwable) {
/* 1263 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0) {
/* 1268 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1) {
/* 1273 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 1278 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1289 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1301 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1314 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1328 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1343 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1359 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1376 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0) {
/* 1381 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1) {
/* 1386 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2) {
/* 1391 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3) {
/* 1396 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1402 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1414 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1427 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1441 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1456 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1472 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <MF extends MessageFactory> MF getMessageFactory() {
/* 1478 */     return (MF)this.messageFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowMessageFactory getFlowMessageFactory() {
/* 1483 */     return this.flowMessageFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getName() {
/* 1488 */     return this.name;
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Message message) {
/* 1493 */     logIfEnabled(FQCN, Level.INFO, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Message message, Throwable throwable) {
/* 1498 */     logIfEnabled(FQCN, Level.INFO, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, CharSequence message) {
/* 1503 */     logIfEnabled(FQCN, Level.INFO, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, CharSequence message, Throwable throwable) {
/* 1508 */     logIfEnabled(FQCN, Level.INFO, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Object message) {
/* 1513 */     logIfEnabled(FQCN, Level.INFO, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Object message, Throwable throwable) {
/* 1518 */     logIfEnabled(FQCN, Level.INFO, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message) {
/* 1523 */     logIfEnabled(FQCN, Level.INFO, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object... params) {
/* 1528 */     logIfEnabled(FQCN, Level.INFO, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Throwable throwable) {
/* 1533 */     logIfEnabled(FQCN, Level.INFO, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Message message) {
/* 1538 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Message message, Throwable throwable) {
/* 1543 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(CharSequence message) {
/* 1548 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(CharSequence message, Throwable throwable) {
/* 1553 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Object message) {
/* 1558 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Object message, Throwable throwable) {
/* 1563 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message) {
/* 1568 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object... params) {
/* 1573 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Throwable throwable) {
/* 1578 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Supplier<?> messageSupplier) {
/* 1584 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Supplier<?> messageSupplier, Throwable throwable) {
/* 1590 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Supplier<?> messageSupplier) {
/* 1596 */     logIfEnabled(FQCN, Level.INFO, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 1602 */     logIfEnabled(FQCN, Level.INFO, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 1608 */     logIfEnabled(FQCN, Level.INFO, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Supplier<?>... paramSuppliers) {
/* 1614 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, MessageSupplier messageSupplier) {
/* 1619 */     logIfEnabled(FQCN, Level.INFO, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 1624 */     logIfEnabled(FQCN, Level.INFO, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(MessageSupplier messageSupplier) {
/* 1629 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(MessageSupplier messageSupplier, Throwable throwable) {
/* 1634 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0) {
/* 1639 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1) {
/* 1644 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 1649 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1660 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1672 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1685 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1699 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1714 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1730 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1747 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0) {
/* 1752 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1) {
/* 1757 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2) {
/* 1762 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3) {
/* 1767 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1773 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1785 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1798 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1812 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1827 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1843 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDebugEnabled() {
/* 1848 */     return isEnabled(Level.DEBUG, (Marker)null, (String)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDebugEnabled(Marker marker) {
/* 1853 */     return isEnabled(Level.DEBUG, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled(Level level) {
/* 1858 */     return isEnabled(level, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled(Level level, Marker marker) {
/* 1863 */     return isEnabled(level, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isErrorEnabled() {
/* 1868 */     return isEnabled(Level.ERROR, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isErrorEnabled(Marker marker) {
/* 1873 */     return isEnabled(Level.ERROR, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFatalEnabled() {
/* 1878 */     return isEnabled(Level.FATAL, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFatalEnabled(Marker marker) {
/* 1883 */     return isEnabled(Level.FATAL, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInfoEnabled() {
/* 1888 */     return isEnabled(Level.INFO, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInfoEnabled(Marker marker) {
/* 1893 */     return isEnabled(Level.INFO, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTraceEnabled() {
/* 1898 */     return isEnabled(Level.TRACE, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTraceEnabled(Marker marker) {
/* 1903 */     return isEnabled(Level.TRACE, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWarnEnabled() {
/* 1908 */     return isEnabled(Level.WARN, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWarnEnabled(Marker marker) {
/* 1913 */     return isEnabled(Level.WARN, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Message message) {
/* 1918 */     logIfEnabled(FQCN, level, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Message message, Throwable throwable) {
/* 1923 */     logIfEnabled(FQCN, level, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, CharSequence message) {
/* 1928 */     logIfEnabled(FQCN, level, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, CharSequence message, Throwable throwable) {
/* 1933 */     if (isEnabled(level, marker, message, throwable)) {
/* 1934 */       logMessage(FQCN, level, marker, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Object message) {
/* 1940 */     logIfEnabled(FQCN, level, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Object message, Throwable throwable) {
/* 1945 */     if (isEnabled(level, marker, message, throwable)) {
/* 1946 */       logMessage(FQCN, level, marker, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message) {
/* 1952 */     logIfEnabled(FQCN, level, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object... params) {
/* 1957 */     logIfEnabled(FQCN, level, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Throwable throwable) {
/* 1962 */     logIfEnabled(FQCN, level, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Message message) {
/* 1967 */     logIfEnabled(FQCN, level, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Message message, Throwable throwable) {
/* 1972 */     logIfEnabled(FQCN, level, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, CharSequence message) {
/* 1977 */     logIfEnabled(FQCN, level, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, CharSequence message, Throwable throwable) {
/* 1982 */     logIfEnabled(FQCN, level, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Object message) {
/* 1987 */     logIfEnabled(FQCN, level, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Object message, Throwable throwable) {
/* 1992 */     logIfEnabled(FQCN, level, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message) {
/* 1997 */     logIfEnabled(FQCN, level, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object... params) {
/* 2002 */     logIfEnabled(FQCN, level, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Throwable throwable) {
/* 2007 */     logIfEnabled(FQCN, level, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Supplier<?> messageSupplier) {
/* 2013 */     logIfEnabled(FQCN, level, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Supplier<?> messageSupplier, Throwable throwable) {
/* 2019 */     logIfEnabled(FQCN, level, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Supplier<?> messageSupplier) {
/* 2025 */     logIfEnabled(FQCN, level, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 2031 */     logIfEnabled(FQCN, level, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 2038 */     logIfEnabled(FQCN, level, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Supplier<?>... paramSuppliers) {
/* 2044 */     logIfEnabled(FQCN, level, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, MessageSupplier messageSupplier) {
/* 2049 */     logIfEnabled(FQCN, level, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 2055 */     logIfEnabled(FQCN, level, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, MessageSupplier messageSupplier) {
/* 2060 */     logIfEnabled(FQCN, level, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, MessageSupplier messageSupplier, Throwable throwable) {
/* 2065 */     logIfEnabled(FQCN, level, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0) {
/* 2070 */     logIfEnabled(FQCN, level, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1) {
/* 2075 */     logIfEnabled(FQCN, level, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 2086 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2098 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2111 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2125 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2140 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2156 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2173 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2191 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0) {
/* 2196 */     logIfEnabled(FQCN, level, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1) {
/* 2201 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2) {
/* 2206 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2217 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2229 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2242 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2256 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2271 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2287 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2304 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, Message message, Throwable throwable) {
/* 2314 */     if (isEnabled(level, marker, message, throwable)) {
/* 2315 */       logMessageSafely(fqcn, level, marker, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 2326 */     if (isEnabled(level, marker, messageSupplier, throwable)) {
/* 2327 */       logMessage(fqcn, level, marker, messageSupplier, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, Object message, Throwable throwable) {
/* 2338 */     if (isEnabled(level, marker, message, throwable)) {
/* 2339 */       logMessage(fqcn, level, marker, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, CharSequence message, Throwable throwable) {
/* 2350 */     if (isEnabled(level, marker, message, throwable)) {
/* 2351 */       logMessage(fqcn, level, marker, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 2363 */     if (isEnabled(level, marker, messageSupplier, throwable)) {
/* 2364 */       logMessage(fqcn, level, marker, messageSupplier, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message) {
/* 2370 */     if (isEnabled(level, marker, message)) {
/* 2371 */       logMessage(fqcn, level, marker, message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 2383 */     if (isEnabled(level, marker, message)) {
/* 2384 */       logMessage(fqcn, level, marker, message, paramSuppliers);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object... params) {
/* 2391 */     if (isEnabled(level, marker, message, params)) {
/* 2392 */       logMessage(fqcn, level, marker, message, params);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0) {
/* 2399 */     if (isEnabled(level, marker, message, p0)) {
/* 2400 */       logMessage(fqcn, level, marker, message, p0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1) {
/* 2412 */     if (isEnabled(level, marker, message, p0, p1)) {
/* 2413 */       logMessage(fqcn, level, marker, message, p0, p1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 2426 */     if (isEnabled(level, marker, message, p0, p1, p2)) {
/* 2427 */       logMessage(fqcn, level, marker, message, p0, p1, p2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2441 */     if (isEnabled(level, marker, message, p0, p1, p2, p3)) {
/* 2442 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2457 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4)) {
/* 2458 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2474 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5)) {
/* 2475 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2492 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6)) {
/* 2493 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2511 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7)) {
/* 2512 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2531 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8)) {
/* 2532 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2552 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)) {
/* 2553 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Throwable throwable) {
/* 2564 */     if (isEnabled(level, marker, message, throwable)) {
/* 2565 */       logMessage(fqcn, level, marker, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, CharSequence message, Throwable throwable) {
/* 2575 */     logMessageSafely(fqcn, level, marker, this.messageFactory.newMessage(message), throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, Object message, Throwable throwable) {
/* 2584 */     logMessageSafely(fqcn, level, marker, this.messageFactory.newMessage(message), throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 2593 */     Message message = LambdaUtil.get(messageSupplier);
/*      */     
/* 2595 */     Throwable effectiveThrowable = (throwable == null && message != null) ? message.getThrowable() : throwable;
/* 2596 */     logMessageSafely(fqcn, level, marker, message, effectiveThrowable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 2606 */     Message message = LambdaUtil.getMessage(messageSupplier, (MessageFactory)this.messageFactory);
/*      */     
/* 2608 */     Throwable effectiveThrowable = (throwable == null && message != null) ? message.getThrowable() : throwable;
/* 2609 */     logMessageSafely(fqcn, level, marker, message, effectiveThrowable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Throwable throwable) {
/* 2618 */     logMessageSafely(fqcn, level, marker, this.messageFactory.newMessage(message), throwable);
/*      */   }
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message) {
/* 2622 */     Message msg = this.messageFactory.newMessage(message);
/* 2623 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object... params) {
/* 2628 */     Message msg = this.messageFactory.newMessage(message, params);
/* 2629 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0) {
/* 2634 */     Message msg = this.messageFactory.newMessage(message, p0);
/* 2635 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1) {
/* 2645 */     Message msg = this.messageFactory.newMessage(message, p0, p1);
/* 2646 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 2657 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2);
/* 2658 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2670 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3);
/* 2671 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2684 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4);
/* 2685 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2699 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5);
/* 2700 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2715 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6);
/* 2716 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2732 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6, p7);
/* 2733 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2750 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/* 2751 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2769 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/* 2770 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 2780 */     Message msg = this.messageFactory.newMessage(message, LambdaUtil.getAll((Supplier[])paramSuppliers));
/* 2781 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logMessage(Level level, Marker marker, String fqcn, StackTraceElement location, Message message, Throwable throwable) {
/*      */     try {
/* 2793 */       incrementRecursionDepth();
/* 2794 */       log(level, marker, fqcn, location, message, throwable);
/* 2795 */     } catch (Throwable ex) {
/* 2796 */       handleLogMessageException(ex, fqcn, message);
/*      */     } finally {
/* 2798 */       decrementRecursionDepth();
/* 2799 */       ReusableMessageFactory.release(message);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void log(Level level, Marker marker, String fqcn, StackTraceElement location, Message message, Throwable throwable) {
/* 2810 */     logMessage(fqcn, level, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void printf(Level level, Marker marker, String format, Object... params) {
/* 2815 */     if (isEnabled(level, marker, format, params)) {
/* 2816 */       StringFormattedMessage stringFormattedMessage = new StringFormattedMessage(format, params);
/* 2817 */       logMessageSafely(FQCN, level, marker, (Message)stringFormattedMessage, stringFormattedMessage.getThrowable());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void printf(Level level, String format, Object... params) {
/* 2823 */     if (isEnabled(level, (Marker)null, format, params)) {
/* 2824 */       StringFormattedMessage stringFormattedMessage = new StringFormattedMessage(format, params);
/* 2825 */       logMessageSafely(FQCN, level, (Marker)null, (Message)stringFormattedMessage, stringFormattedMessage.getThrowable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private void logMessageSafely(String fqcn, Level level, Marker marker, Message message, Throwable throwable) {
/*      */     try {
/* 2839 */       logMessageTrackRecursion(fqcn, level, marker, message, throwable);
/*      */     } finally {
/*      */       
/* 2842 */       ReusableMessageFactory.release(message);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private void logMessageTrackRecursion(String fqcn, Level level, Marker marker, Message message, Throwable throwable) {
/*      */     try {
/* 2856 */       incrementRecursionDepth();
/* 2857 */       tryLogMessage(fqcn, getLocation(fqcn), level, marker, message, throwable);
/*      */     } finally {
/* 2859 */       decrementRecursionDepth();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int[] getRecursionDepthHolder() {
/* 2864 */     int[] result = recursionDepthHolder.get();
/* 2865 */     if (result == null) {
/* 2866 */       result = new int[1];
/* 2867 */       recursionDepthHolder.set(result);
/*      */     } 
/* 2869 */     return result;
/*      */   }
/*      */   
/*      */   private static void incrementRecursionDepth() {
/* 2873 */     getRecursionDepthHolder()[0] = getRecursionDepthHolder()[0] + 1;
/*      */   }
/*      */   
/*      */   private static void decrementRecursionDepth() {
/* 2877 */     int newDepth = getRecursionDepthHolder()[0] = getRecursionDepthHolder()[0] - 1;
/* 2878 */     if (newDepth < 0) {
/* 2879 */       throw new IllegalStateException("Recursion depth became negative: " + newDepth);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getRecursionDepth() {
/* 2890 */     return getRecursionDepthHolder()[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private void tryLogMessage(String fqcn, StackTraceElement location, Level level, Marker marker, Message message, Throwable throwable) {
/*      */     try {
/* 2904 */       log(level, marker, fqcn, location, message, throwable);
/* 2905 */     } catch (Throwable t) {
/*      */       
/* 2907 */       handleLogMessageException(t, fqcn, message);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private StackTraceElement getLocation(String fqcn) {
/* 2915 */     return requiresLocation() ? StackLocatorUtil.calcLocation(fqcn) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleLogMessageException(Throwable throwable, String fqcn, Message message) {
/* 2921 */     if (throwable instanceof LoggingException) {
/* 2922 */       throw (LoggingException)throwable;
/*      */     }
/* 2924 */     StatusLogger.getLogger()
/* 2925 */       .warn("{} caught {} logging {}: {}", fqcn, throwable
/*      */ 
/*      */         
/* 2928 */         .getClass().getName(), message
/* 2929 */         .getClass().getSimpleName(), message
/* 2930 */         .getFormat(), throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends Throwable> T throwing(T throwable) {
/* 2936 */     return throwing(FQCN, Level.ERROR, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends Throwable> T throwing(Level level, T throwable) {
/* 2941 */     return throwing(FQCN, level, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Throwable> T throwing(String fqcn, Level level, T throwable) {
/* 2954 */     if (isEnabled(level, THROWING_MARKER, (Object)null, (Throwable)null)) {
/* 2955 */       logMessageSafely(fqcn, level, THROWING_MARKER, throwingMsg((Throwable)throwable), (Throwable)throwable);
/*      */     }
/* 2957 */     return throwable;
/*      */   }
/*      */   
/*      */   protected Message throwingMsg(Throwable throwable) {
/* 2961 */     return this.messageFactory.newMessage("Throwing");
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Message message) {
/* 2966 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Message message, Throwable throwable) {
/* 2971 */     logIfEnabled(FQCN, Level.TRACE, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, CharSequence message) {
/* 2976 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, CharSequence message, Throwable throwable) {
/* 2981 */     logIfEnabled(FQCN, Level.TRACE, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Object message) {
/* 2986 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Object message, Throwable throwable) {
/* 2991 */     logIfEnabled(FQCN, Level.TRACE, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message) {
/* 2996 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object... params) {
/* 3001 */     logIfEnabled(FQCN, Level.TRACE, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Throwable throwable) {
/* 3006 */     logIfEnabled(FQCN, Level.TRACE, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Message message) {
/* 3011 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Message message, Throwable throwable) {
/* 3016 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(CharSequence message) {
/* 3021 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(CharSequence message, Throwable throwable) {
/* 3026 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Object message) {
/* 3031 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Object message, Throwable throwable) {
/* 3036 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message) {
/* 3041 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object... params) {
/* 3046 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Throwable throwable) {
/* 3051 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Supplier<?> messageSupplier) {
/* 3057 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Supplier<?> messageSupplier, Throwable throwable) {
/* 3063 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Supplier<?> messageSupplier) {
/* 3069 */     logIfEnabled(FQCN, Level.TRACE, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 3075 */     logIfEnabled(FQCN, Level.TRACE, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 3081 */     logIfEnabled(FQCN, Level.TRACE, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Supplier<?>... paramSuppliers) {
/* 3087 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, MessageSupplier messageSupplier) {
/* 3092 */     logIfEnabled(FQCN, Level.TRACE, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 3097 */     logIfEnabled(FQCN, Level.TRACE, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(MessageSupplier messageSupplier) {
/* 3102 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(MessageSupplier messageSupplier, Throwable throwable) {
/* 3107 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0) {
/* 3112 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1) {
/* 3117 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 3122 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 3133 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 3145 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 3158 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 3172 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 3187 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 3203 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 3220 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0) {
/* 3225 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1) {
/* 3230 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2) {
/* 3235 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3) {
/* 3240 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 3246 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 3258 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 3271 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 3285 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 3300 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 3316 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry() {
/* 3321 */     return enter(FQCN, (String)null, (Object[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(String format, Object... params) {
/* 3326 */     return enter(FQCN, format, params);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(Supplier<?>... paramSuppliers) {
/* 3332 */     return enter(FQCN, (String)null, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(String format, Supplier<?>... paramSuppliers) {
/* 3338 */     return enter(FQCN, format, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(Message message) {
/* 3343 */     return enter(FQCN, message);
/*      */   }
/*      */ 
/*      */   
/*      */   public void traceExit() {
/* 3348 */     exit(FQCN, (String)null, (Object)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public <R> R traceExit(R result) {
/* 3353 */     return exit(FQCN, (String)null, result);
/*      */   }
/*      */ 
/*      */   
/*      */   public <R> R traceExit(String format, R result) {
/* 3358 */     return exit(FQCN, format, result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traceExit(EntryMessage message) {
/* 3365 */     if (message != null && isEnabled(Level.TRACE, EXIT_MARKER, (Message)message, (Throwable)null)) {
/* 3366 */       logMessageSafely(FQCN, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(message), (Throwable)null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> R traceExit(EntryMessage message, R result) {
/* 3374 */     if (message != null && isEnabled(Level.TRACE, EXIT_MARKER, (Message)message, (Throwable)null)) {
/* 3375 */       logMessageSafely(FQCN, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(result, message), (Throwable)null);
/*      */     }
/* 3377 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> R traceExit(Message message, R result) {
/* 3384 */     if (message != null && isEnabled(Level.TRACE, EXIT_MARKER, message, (Throwable)null)) {
/* 3385 */       logMessageSafely(FQCN, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(result, message), (Throwable)null);
/*      */     }
/* 3387 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Message message) {
/* 3392 */     logIfEnabled(FQCN, Level.WARN, marker, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Message message, Throwable throwable) {
/* 3397 */     logIfEnabled(FQCN, Level.WARN, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, CharSequence message) {
/* 3402 */     logIfEnabled(FQCN, Level.WARN, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, CharSequence message, Throwable throwable) {
/* 3407 */     logIfEnabled(FQCN, Level.WARN, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Object message) {
/* 3412 */     logIfEnabled(FQCN, Level.WARN, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Object message, Throwable throwable) {
/* 3417 */     logIfEnabled(FQCN, Level.WARN, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message) {
/* 3422 */     logIfEnabled(FQCN, Level.WARN, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object... params) {
/* 3427 */     logIfEnabled(FQCN, Level.WARN, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Throwable throwable) {
/* 3432 */     logIfEnabled(FQCN, Level.WARN, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Message message) {
/* 3437 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (message != null) ? message.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Message message, Throwable throwable) {
/* 3442 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(CharSequence message) {
/* 3447 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(CharSequence message, Throwable throwable) {
/* 3452 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Object message) {
/* 3457 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Object message, Throwable throwable) {
/* 3462 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message) {
/* 3467 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object... params) {
/* 3472 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Throwable throwable) {
/* 3477 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Supplier<?> messageSupplier) {
/* 3483 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Supplier<?> messageSupplier, Throwable throwable) {
/* 3489 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Supplier<?> messageSupplier) {
/* 3495 */     logIfEnabled(FQCN, Level.WARN, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 3501 */     logIfEnabled(FQCN, Level.WARN, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Supplier<?> messageSupplier, Throwable throwable) {
/* 3507 */     logIfEnabled(FQCN, Level.WARN, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Supplier<?>... paramSuppliers) {
/* 3513 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, MessageSupplier messageSupplier) {
/* 3518 */     logIfEnabled(FQCN, Level.WARN, marker, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, MessageSupplier messageSupplier, Throwable throwable) {
/* 3523 */     logIfEnabled(FQCN, Level.WARN, marker, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(MessageSupplier messageSupplier) {
/* 3528 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, messageSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(MessageSupplier messageSupplier, Throwable throwable) {
/* 3533 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, messageSupplier, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0) {
/* 3538 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1) {
/* 3543 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 3548 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 3559 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 3571 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 3584 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 3598 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 3613 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 3629 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 3646 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0) {
/* 3651 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1) {
/* 3656 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2) {
/* 3661 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3) {
/* 3666 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 3672 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 3684 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 3697 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 3711 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 3726 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 3742 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */   
/*      */   protected boolean requiresLocation() {
/* 3746 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atTrace() {
/* 3756 */     return atLevel(Level.TRACE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atDebug() {
/* 3766 */     return atLevel(Level.DEBUG);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atInfo() {
/* 3776 */     return atLevel(Level.INFO);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atWarn() {
/* 3786 */     return atLevel(Level.WARN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atError() {
/* 3796 */     return atLevel(Level.ERROR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atFatal() {
/* 3806 */     return atLevel(Level.FATAL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder always() {
/* 3816 */     return getLogBuilder(Level.OFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogBuilder atLevel(Level level) {
/* 3826 */     if (isEnabled(level)) {
/* 3827 */       return getLogBuilder(level);
/*      */     }
/* 3829 */     return LogBuilder.NOOP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LogBuilder getLogBuilder(Level level) {
/* 3838 */     if (Constants.ENABLE_THREADLOCALS) {
/* 3839 */       DefaultLogBuilder builder = logBuilder.get();
/* 3840 */       if (!builder.isInUse()) {
/* 3841 */         return builder.reset(this, level);
/*      */       }
/*      */     } 
/* 3844 */     return (LogBuilder)new DefaultLogBuilder(this, level);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\AbstractLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */