package org.apache.logging.log4j.spi;

public interface LoggerContextShutdownAware {
  void contextShutdown(LoggerContext paramLoggerContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\LoggerContextShutdownAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */