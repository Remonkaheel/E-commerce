/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.util.LoaderUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLoggerAdapter<L>
/*     */   implements LoggerAdapter<L>, LoggerContextShutdownAware
/*     */ {
/*  40 */   protected final Map<LoggerContext, ConcurrentMap<String, L>> registry = new ConcurrentHashMap<>();
/*     */   
/*  42 */   private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*     */ 
/*     */   
/*     */   public L getLogger(String name) {
/*  46 */     LoggerContext context = getContext();
/*  47 */     ConcurrentMap<String, L> loggers = getLoggersInContext(context);
/*  48 */     L logger = loggers.get(name);
/*  49 */     if (logger != null) {
/*  50 */       return logger;
/*     */     }
/*  52 */     loggers.putIfAbsent(name, newLogger(name, context));
/*  53 */     return loggers.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void contextShutdown(LoggerContext loggerContext) {
/*  58 */     this.registry.remove(loggerContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentMap<String, L> getLoggersInContext(LoggerContext context) {
/*     */     ConcurrentMap<String, L> loggers;
/*  69 */     this.lock.readLock().lock();
/*     */     try {
/*  71 */       loggers = this.registry.get(context);
/*     */     } finally {
/*  73 */       this.lock.readLock().unlock();
/*     */     } 
/*     */     
/*  76 */     if (loggers != null) {
/*  77 */       return loggers;
/*     */     }
/*  79 */     this.lock.writeLock().lock();
/*     */     try {
/*  81 */       loggers = this.registry.get(context);
/*  82 */       if (loggers == null) {
/*  83 */         loggers = new ConcurrentHashMap<>();
/*  84 */         this.registry.put(context, loggers);
/*  85 */         if (context instanceof LoggerContextShutdownEnabled) {
/*  86 */           ((LoggerContextShutdownEnabled)context).addShutdownListener(this);
/*     */         }
/*     */       } 
/*  89 */       return loggers;
/*     */     } finally {
/*  91 */       this.lock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<LoggerContext> getLoggerContexts() {
/*  99 */     return new HashSet<>(this.registry.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract L newLogger(String paramString, LoggerContext paramLoggerContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract LoggerContext getContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LoggerContext getContext(Class<?> callerClass) {
/* 129 */     ClassLoader cl = null;
/* 130 */     if (callerClass != null) {
/* 131 */       cl = callerClass.getClassLoader();
/*     */     }
/* 133 */     if (cl == null) {
/* 134 */       cl = LoaderUtil.getThreadContextClassLoader();
/*     */     }
/* 136 */     return LogManager.getContext(cl, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 141 */     this.lock.writeLock().lock();
/*     */     try {
/* 143 */       this.registry.clear();
/*     */     } finally {
/* 145 */       this.lock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\AbstractLoggerAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */