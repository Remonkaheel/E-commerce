/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerRegistry<T extends ExtendedLogger>
/*     */ {
/*  41 */   private final Map<String, Map<MessageFactory, T>> loggerByMessageFactoryByName = new HashMap<>();
/*     */   
/*  43 */   private final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */   
/*  45 */   private final Lock readLock = this.lock.readLock();
/*     */   
/*  47 */   private final Lock writeLock = this.lock.writeLock();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface MapFactory<T extends ExtendedLogger>
/*     */   {
/*     */     Map<String, T> createInnerMap();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Map<String, Map<String, T>> createOuterMap();
/*     */ 
/*     */ 
/*     */     
/*     */     void putIfAbsent(Map<String, T> param1Map, String param1String, T param1T);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConcurrentMapFactory<T extends ExtendedLogger>
/*     */     implements MapFactory<T>
/*     */   {
/*     */     public Map<String, T> createInnerMap() {
/*  72 */       return new ConcurrentHashMap<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, Map<String, T>> createOuterMap() {
/*  77 */       return new ConcurrentHashMap<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public void putIfAbsent(Map<String, T> innerMap, String name, T logger) {
/*  82 */       innerMap.putIfAbsent(name, logger);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class WeakMapFactory<T extends ExtendedLogger>
/*     */     implements MapFactory<T>
/*     */   {
/*     */     public Map<String, T> createInnerMap() {
/*  95 */       return new WeakHashMap<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, Map<String, T>> createOuterMap() {
/* 100 */       return new WeakHashMap<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public void putIfAbsent(Map<String, T> innerMap, String name, T logger) {
/* 105 */       innerMap.put(name, logger);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggerRegistry(MapFactory<T> mapFactory) {
/* 117 */     this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getLogger(String name) {
/* 131 */     Objects.requireNonNull(name, "name");
/* 132 */     return getLogger(name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getLogger(String name, MessageFactory messageFactory) {
/* 148 */     Objects.requireNonNull(name, "name");
/* 149 */     this.readLock.lock();
/*     */     try {
/* 151 */       Map<MessageFactory, T> loggerByMessageFactory = this.loggerByMessageFactoryByName.get(name);
/*     */       
/* 153 */       MessageFactory effectiveMessageFactory = (messageFactory != null) ? messageFactory : (MessageFactory)ParameterizedMessageFactory.INSTANCE;
/* 154 */       return (T)((loggerByMessageFactory == null) ? null : (ExtendedLogger)loggerByMessageFactory.get(effectiveMessageFactory));
/*     */     } finally {
/* 156 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<T> getLoggers() {
/* 161 */     this.readLock.lock();
/*     */     try {
/* 163 */       return (Collection)this.loggerByMessageFactoryByName.values().stream()
/* 164 */         .flatMap(loggerByMessageFactory -> loggerByMessageFactory.values().stream())
/* 165 */         .collect(Collectors.toList());
/*     */     } finally {
/* 167 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<T> getLoggers(Collection<T> destination) {
/* 172 */     Objects.requireNonNull(destination, "destination");
/* 173 */     destination.addAll(getLoggers());
/* 174 */     return destination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLogger(String name) {
/* 188 */     Objects.requireNonNull(name, "name");
/* 189 */     T logger = getLogger(name);
/* 190 */     return (logger != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLogger(String name, MessageFactory messageFactory) {
/* 207 */     Objects.requireNonNull(name, "name");
/* 208 */     T logger = getLogger(name, messageFactory);
/* 209 */     return (logger != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLogger(String name, Class<? extends MessageFactory> messageFactoryClass) {
/* 221 */     Objects.requireNonNull(name, "name");
/* 222 */     Objects.requireNonNull(messageFactoryClass, "messageFactoryClass");
/* 223 */     this.readLock.lock();
/*     */     try {
/* 225 */       return ((Map)this.loggerByMessageFactoryByName.getOrDefault(name, Collections.emptyMap())).keySet().stream()
/* 226 */         .anyMatch(messageFactory -> messageFactoryClass.equals(messageFactory.getClass()));
/*     */     } finally {
/* 228 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putIfAbsent(String name, MessageFactory messageFactory, T logger) {
/* 246 */     Objects.requireNonNull(name, "name");
/* 247 */     Objects.requireNonNull(logger, "logger");
/*     */ 
/*     */     
/* 250 */     this.writeLock.lock();
/*     */     
/*     */     try {
/* 253 */       MessageFactory effectiveMessageFactory = (messageFactory != null) ? messageFactory : (MessageFactory)ParameterizedMessageFactory.INSTANCE;
/*     */       
/* 255 */       ((Map<MessageFactory, T>)this.loggerByMessageFactoryByName
/* 256 */         .computeIfAbsent(name, this::createLoggerRefByMessageFactoryMap))
/* 257 */         .putIfAbsent(effectiveMessageFactory, logger);
/*     */       
/* 259 */       if (!name.equals(logger.getName()) || !effectiveMessageFactory.equals(logger.getMessageFactory())) {
/* 260 */         ((Map<MessageFactory, T>)this.loggerByMessageFactoryByName
/* 261 */           .computeIfAbsent(logger.getName(), this::createLoggerRefByMessageFactoryMap))
/* 262 */           .putIfAbsent(logger.getMessageFactory(), logger);
/*     */       }
/*     */     } finally {
/* 265 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<MessageFactory, T> createLoggerRefByMessageFactoryMap(String ignored) {
/* 270 */     return new WeakHashMap<>();
/*     */   }
/*     */   
/*     */   public LoggerRegistry() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\LoggerRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */