/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.apache.logging.log4j.internal.map.UnmodifiableArrayBackedMap;
/*     */ import org.apache.logging.log4j.util.BiConsumer;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.ReadOnlyStringMap;
/*     */ import org.apache.logging.log4j.util.TriConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultThreadContextMap
/*     */   implements ThreadContextMap, ReadOnlyStringMap
/*     */ {
/*     */   private static final long serialVersionUID = -2635197170958057849L;
/*     */   public static final String INHERITABLE_MAP = "isThreadContextMapInheritable";
/*     */   private ThreadLocal<Object[]> localState;
/*     */   
/*     */   public DefaultThreadContextMap() {
/*  53 */     this(PropertiesUtil.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultThreadContextMap(boolean ignored) {
/*  61 */     this(PropertiesUtil.getProperties());
/*     */   }
/*     */   
/*     */   DefaultThreadContextMap(PropertiesUtil properties) {
/*  65 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  72 */       .localState = properties.getBooleanProperty("isThreadContextMapInheritable") ? new InheritableThreadLocal<Object[]>() { protected Object[] childValue(Object[] parentValue) { return parentValue; } } : new ThreadLocal();
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String key, String value) {
/*  77 */     Object[] state = this.localState.get();
/*  78 */     this.localState.set(UnmodifiableArrayBackedMap.getMap(state).copyAndPut(key, value).getBackingArray());
/*     */   }
/*     */   
/*     */   public void putAll(Map<String, String> m) {
/*  82 */     Object[] state = this.localState.get();
/*  83 */     this.localState.set(UnmodifiableArrayBackedMap.getMap(state).copyAndPutAll(m).getBackingArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String key) {
/*  88 */     Object[] state = this.localState.get();
/*  89 */     return (state == null) ? null : UnmodifiableArrayBackedMap.getMap(state).get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/*  94 */     Object[] state = this.localState.get();
/*  95 */     if (state != null) {
/*  96 */       this.localState.set(UnmodifiableArrayBackedMap.getMap(state).copyAndRemove(key).getBackingArray());
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeAll(Iterable<String> keys) {
/* 101 */     Object[] state = this.localState.get();
/* 102 */     if (state != null) {
/* 103 */       this.localState.set(UnmodifiableArrayBackedMap.getMap(state).copyAndRemoveAll(keys).getBackingArray());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 109 */     this.localState.remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toMap() {
/* 114 */     return getCopy();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 119 */     Object[] state = this.localState.get();
/* 120 */     return (state != null && UnmodifiableArrayBackedMap.getMap(state).containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> void forEach(BiConsumer<String, ? super V> action) {
/* 125 */     Object[] state = this.localState.get();
/* 126 */     if (state == null) {
/*     */       return;
/*     */     }
/* 129 */     UnmodifiableArrayBackedMap.getMap(state).forEach(action);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V, S> void forEach(TriConsumer<String, ? super V, S> action, S state) {
/* 134 */     Object[] localState = this.localState.get();
/* 135 */     if (localState == null) {
/*     */       return;
/*     */     }
/* 138 */     UnmodifiableArrayBackedMap.getMap(localState).forEach(action, state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> V getValue(String key) {
/* 144 */     return (V)get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopy() {
/* 149 */     Object[] state = this.localState.get();
/* 150 */     if (state == null) {
/* 151 */       return new HashMap<>(0);
/*     */     }
/* 153 */     return new HashMap<>((Map<? extends String, ? extends String>)UnmodifiableArrayBackedMap.getMap(state));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getImmutableMapOrNull() {
/* 158 */     Object[] state = this.localState.get();
/* 159 */     return (state == null) ? null : (Map<String, String>)UnmodifiableArrayBackedMap.getMap(state);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 164 */     return (size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 169 */     Object[] state = this.localState.get();
/* 170 */     return UnmodifiableArrayBackedMap.getMap(state).size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 175 */     Object[] state = this.localState.get();
/* 176 */     return (state == null) ? "{}" : UnmodifiableArrayBackedMap.getMap(state).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 181 */     int prime = 31;
/* 182 */     int result = 1;
/* 183 */     Object[] state = this.localState.get();
/* 184 */     result = 31 * result + ((state == null) ? 0 : UnmodifiableArrayBackedMap.getMap(state).hashCode());
/* 185 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 190 */     if (this == obj) {
/* 191 */       return true;
/*     */     }
/* 193 */     if (obj == null) {
/* 194 */       return false;
/*     */     }
/* 196 */     if (!(obj instanceof ThreadContextMap)) {
/* 197 */       return false;
/*     */     }
/* 199 */     ThreadContextMap other = (ThreadContextMap)obj;
/* 200 */     UnmodifiableArrayBackedMap unmodifiableArrayBackedMap = UnmodifiableArrayBackedMap.getMap(this.localState.get());
/* 201 */     Map<String, String> otherMap = other.getImmutableMapOrNull();
/* 202 */     return Objects.equals(unmodifiableArrayBackedMap, otherMap);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\DefaultThreadContextMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */