/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URL;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.simple.SimpleLoggerContextFactory;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.LoaderUtil;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.jspecify.annotations.NullMarked;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @NullMarked
/*     */ public class Provider
/*     */ {
/*     */   protected static final String CURRENT_VERSION = "2.6.0";
/*     */   @Deprecated
/*     */   public static final String FACTORY_PRIORITY = "FactoryPriority";
/*     */   @Deprecated
/*     */   public static final String THREAD_CONTEXT_MAP = "ThreadContextMap";
/*     */   @Deprecated
/*     */   public static final String LOGGER_CONTEXT_FACTORY = "LoggerContextFactory";
/*     */   public static final String PROVIDER_PROPERTY_NAME = "log4j.provider";
/*     */   private static final String DISABLE_CONTEXT_MAP = "log4j2.disableThreadContextMap";
/*     */   private static final String DISABLE_THREAD_CONTEXT = "log4j2.disableThreadContext";
/*     */   private static final int DEFAULT_PRIORITY = -1;
/*  80 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   private final int priority;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   private final String className;
/*     */   
/*     */   private final Class<? extends LoggerContextFactory> loggerContextFactoryClass;
/*     */   
/*     */   @Deprecated
/*     */   private final String threadContextMap;
/*     */   
/*     */   private final Class<? extends ThreadContextMap> threadContextMapClass;
/*     */   
/*     */   private final String versions;
/*     */   
/*     */   @Deprecated
/*     */   private final URL url;
/*     */   
/*     */   @Deprecated
/*     */   private final WeakReference<ClassLoader> classLoader;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Provider(Properties props, URL url, ClassLoader classLoader) {
/* 107 */     this.url = url;
/* 108 */     this.classLoader = new WeakReference<>(classLoader);
/* 109 */     String weight = props.getProperty("FactoryPriority");
/* 110 */     this.priority = (weight == null) ? -1 : Integer.parseInt(weight);
/* 111 */     this.className = props.getProperty("LoggerContextFactory");
/* 112 */     this.threadContextMap = props.getProperty("ThreadContextMap");
/* 113 */     this.loggerContextFactoryClass = null;
/* 114 */     this.threadContextMapClass = null;
/* 115 */     this.versions = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Provider(Integer priority, String versions) {
/* 124 */     this(priority, versions, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Provider(Integer priority, String versions, Class<? extends LoggerContextFactory> loggerContextFactoryClass) {
/* 137 */     this(priority, versions, loggerContextFactoryClass, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Provider(Integer priority, String versions, Class<? extends LoggerContextFactory> loggerContextFactoryClass, Class<? extends ThreadContextMap> threadContextMapClass) {
/* 153 */     this.priority = (priority != null) ? priority.intValue() : -1;
/* 154 */     this.versions = versions;
/* 155 */     this.loggerContextFactoryClass = loggerContextFactoryClass;
/* 156 */     this.threadContextMapClass = threadContextMapClass;
/*     */     
/* 158 */     this.className = null;
/* 159 */     this.threadContextMap = null;
/* 160 */     this.url = null;
/* 161 */     this.classLoader = new WeakReference<>(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersions() {
/* 169 */     return (this.versions != null) ? this.versions : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getPriority() {
/* 180 */     return Integer.valueOf(this.priority);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 190 */     return (this.loggerContextFactoryClass != null) ? this.loggerContextFactoryClass.getName() : this.className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends LoggerContextFactory> loadLoggerContextFactory() {
/* 199 */     if (this.loggerContextFactoryClass != null) {
/* 200 */       return this.loggerContextFactoryClass;
/*     */     }
/* 202 */     String className = getClassName();
/* 203 */     ClassLoader loader = this.classLoader.get();
/*     */ 
/*     */     
/* 206 */     if (loader == null || className == null) {
/* 207 */       return null;
/*     */     }
/*     */     try {
/* 210 */       Class<?> clazz = loader.loadClass(className);
/* 211 */       if (LoggerContextFactory.class.isAssignableFrom(clazz)) {
/* 212 */         return clazz.asSubclass(LoggerContextFactory.class);
/*     */       }
/* 214 */       LOGGER.error("Class {} specified in {} does not extend {}", className, 
/*     */ 
/*     */           
/* 217 */           getUrl(), LoggerContextFactory.class
/* 218 */           .getName());
/*     */     }
/* 220 */     catch (Exception e) {
/* 221 */       LOGGER.error("Unable to create class {} specified in {}", className, getUrl(), e);
/*     */     } 
/* 223 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggerContextFactory getLoggerContextFactory() {
/* 231 */     Class<? extends LoggerContextFactory> implementation = loadLoggerContextFactory();
/* 232 */     if (implementation != null) {
/*     */       try {
/* 234 */         return (LoggerContextFactory)LoaderUtil.newInstanceOf(implementation);
/* 235 */       } catch (ReflectiveOperationException e) {
/* 236 */         LOGGER.error("Failed to instantiate logger context factory {}.", implementation.getName(), e);
/*     */       } 
/*     */     }
/* 239 */     LOGGER.error("Falling back to simple logger context factory: {}", SimpleLoggerContextFactory.class.getName());
/* 240 */     return (LoggerContextFactory)SimpleLoggerContextFactory.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getThreadContextMap() {
/* 249 */     return (this.threadContextMapClass != null) ? this.threadContextMapClass.getName() : this.threadContextMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends ThreadContextMap> loadThreadContextMap() {
/* 259 */     if (this.threadContextMapClass != null) {
/* 260 */       return this.threadContextMapClass;
/*     */     }
/* 262 */     String threadContextMap = getThreadContextMap();
/* 263 */     ClassLoader loader = this.classLoader.get();
/*     */ 
/*     */     
/* 266 */     if (loader == null || threadContextMap == null) {
/* 267 */       return null;
/*     */     }
/*     */     try {
/* 270 */       Class<?> clazz = loader.loadClass(threadContextMap);
/* 271 */       if (ThreadContextMap.class.isAssignableFrom(clazz)) {
/* 272 */         return clazz.asSubclass(ThreadContextMap.class);
/*     */       }
/* 274 */       LOGGER.error("Class {} specified in {} does not extend {}", threadContextMap, 
/*     */ 
/*     */           
/* 277 */           getUrl(), ThreadContextMap.class
/* 278 */           .getName());
/*     */     }
/* 280 */     catch (Exception e) {
/* 281 */       LOGGER.error("Unable to load class {} specified in {}", threadContextMap, this.url, e);
/*     */     } 
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadContextMap getThreadContextMapInstance() {
/* 291 */     Class<? extends ThreadContextMap> implementation = loadThreadContextMap();
/* 292 */     if (implementation != null) {
/*     */       try {
/* 294 */         return (ThreadContextMap)LoaderUtil.newInstanceOf(implementation);
/* 295 */       } catch (ReflectiveOperationException e) {
/* 296 */         LOGGER.error("Failed to instantiate logger context factory {}.", implementation.getName(), e);
/*     */       } 
/*     */     }
/* 299 */     PropertiesUtil props = PropertiesUtil.getProperties();
/* 300 */     return (props.getBooleanProperty("log4j2.disableThreadContextMap") || props.getBooleanProperty("log4j2.disableThreadContext")) ? 
/* 301 */       NoOpThreadContextMap.INSTANCE : 
/* 302 */       new DefaultThreadContextMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public URL getUrl() {
/* 314 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 320 */     StringBuilder result = (new StringBuilder("Provider '")).append(getClass().getName()).append("'");
/* 321 */     if (this.priority != -1) {
/* 322 */       result.append("\n\tpriority = ").append(this.priority);
/*     */     }
/* 324 */     String threadContextMap = getThreadContextMap();
/* 325 */     if (threadContextMap != null) {
/* 326 */       result.append("\n\tthreadContextMap = ").append(threadContextMap);
/*     */     }
/* 328 */     String loggerContextFactory = getClassName();
/* 329 */     if (loggerContextFactory != null) {
/* 330 */       result.append("\n\tloggerContextFactory = ").append(loggerContextFactory);
/*     */     }
/* 332 */     if (this.url != null) {
/* 333 */       result.append("\n\turl = ").append(this.url);
/*     */     }
/* 335 */     if (Provider.class.equals(getClass())) {
/* 336 */       ClassLoader loader = this.classLoader.get();
/* 337 */       if (loader == null) {
/* 338 */         result.append("\n\tclassLoader = null or not reachable");
/*     */       } else {
/* 340 */         result.append("\n\tclassLoader = ").append(loader);
/*     */       } 
/*     */     } 
/* 343 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 348 */     if (this == o) {
/* 349 */       return true;
/*     */     }
/* 351 */     if (o instanceof Provider) {
/* 352 */       Provider provider = (Provider)o;
/* 353 */       return (Objects.equals(Integer.valueOf(this.priority), Integer.valueOf(provider.priority)) && 
/* 354 */         Objects.equals(this.className, provider.className) && 
/* 355 */         Objects.equals(this.loggerContextFactoryClass, provider.loggerContextFactoryClass) && 
/* 356 */         Objects.equals(this.versions, provider.versions));
/*     */     } 
/* 358 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 363 */     return Objects.hash(new Object[] { Integer.valueOf(this.priority), this.className, this.loggerContextFactoryClass, this.versions });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\Provider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */