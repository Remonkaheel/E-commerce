/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.ThreadContext;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultThreadContextStack
/*     */   implements ThreadContextStack, StringBuilderFormattable
/*     */ {
/*  34 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */   
/*     */   private static final long serialVersionUID = 5050501L;
/*     */   
/*  38 */   private static final ThreadLocal<MutableThreadContextStack> STACK = new ThreadLocal<>();
/*     */   
/*     */   private final boolean useStack;
/*     */   
/*     */   public DefaultThreadContextStack() {
/*  43 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultThreadContextStack(boolean useStack) {
/*  51 */     this.useStack = useStack;
/*     */   }
/*     */   
/*     */   private MutableThreadContextStack getNonNullStackCopy() {
/*  55 */     MutableThreadContextStack values = STACK.get();
/*  56 */     return (values == null) ? new MutableThreadContextStack() : (MutableThreadContextStack)values.copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(String s) {
/*  61 */     if (!this.useStack) {
/*  62 */       return false;
/*     */     }
/*  64 */     MutableThreadContextStack copy = getNonNullStackCopy();
/*  65 */     copy.add(s);
/*  66 */     copy.freeze();
/*  67 */     STACK.set(copy);
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends String> strings) {
/*  73 */     if (!this.useStack || strings.isEmpty()) {
/*  74 */       return false;
/*     */     }
/*  76 */     MutableThreadContextStack copy = getNonNullStackCopy();
/*  77 */     copy.addAll(strings);
/*  78 */     copy.freeze();
/*  79 */     STACK.set(copy);
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> asList() {
/*  85 */     MutableThreadContextStack values = STACK.get();
/*  86 */     if (values == null) {
/*  87 */       return Collections.emptyList();
/*     */     }
/*  89 */     return values.asList();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  94 */     STACK.remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/*  99 */     MutableThreadContextStack values = STACK.get();
/* 100 */     return (values != null && values.contains(o));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> objects) {
/* 105 */     if (objects.isEmpty()) {
/* 106 */       return true;
/*     */     }
/*     */     
/* 109 */     MutableThreadContextStack values = STACK.get();
/* 110 */     return (values != null && values.containsAll(objects));
/*     */   }
/*     */ 
/*     */   
/*     */   public ThreadContextStack copy() {
/* 115 */     MutableThreadContextStack values = null;
/* 116 */     if (!this.useStack || (values = STACK.get()) == null) {
/* 117 */       return new MutableThreadContextStack();
/*     */     }
/* 119 */     return values.copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 124 */     if (this == obj) {
/* 125 */       return true;
/*     */     }
/* 127 */     if (obj == null) {
/* 128 */       return false;
/*     */     }
/* 130 */     if (obj instanceof DefaultThreadContextStack) {
/* 131 */       DefaultThreadContextStack defaultThreadContextStack = (DefaultThreadContextStack)obj;
/* 132 */       if (this.useStack != defaultThreadContextStack.useStack) {
/* 133 */         return false;
/*     */       }
/*     */     } 
/* 136 */     if (!(obj instanceof ThreadContextStack)) {
/* 137 */       return false;
/*     */     }
/* 139 */     ThreadContextStack other = (ThreadContextStack)obj;
/* 140 */     MutableThreadContextStack values = STACK.get();
/* 141 */     if (values == null) {
/* 142 */       return false;
/*     */     }
/* 144 */     return values.equals(other);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDepth() {
/* 149 */     MutableThreadContextStack values = STACK.get();
/* 150 */     return (values == null) ? 0 : values.getDepth();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     MutableThreadContextStack values = STACK.get();
/* 156 */     int prime = 31;
/* 157 */     int result = 1;
/*     */     
/* 159 */     result = 31 * result + ((values == null) ? 0 : values.hashCode());
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 165 */     MutableThreadContextStack values = STACK.get();
/* 166 */     return (values == null || values.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> iterator() {
/* 171 */     MutableThreadContextStack values = STACK.get();
/* 172 */     if (values == null) {
/* 173 */       List<String> empty = Collections.emptyList();
/* 174 */       return empty.iterator();
/*     */     } 
/* 176 */     return values.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String peek() {
/* 181 */     MutableThreadContextStack values = STACK.get();
/* 182 */     if (values == null || values.isEmpty()) {
/* 183 */       return "";
/*     */     }
/* 185 */     return values.peek();
/*     */   }
/*     */ 
/*     */   
/*     */   public String pop() {
/* 190 */     if (!this.useStack) {
/* 191 */       return "";
/*     */     }
/* 193 */     MutableThreadContextStack values = STACK.get();
/* 194 */     if (values == null || values.isEmpty())
/*     */     {
/* 196 */       return "";
/*     */     }
/* 198 */     MutableThreadContextStack copy = (MutableThreadContextStack)values.copy();
/* 199 */     String result = copy.pop();
/* 200 */     copy.freeze();
/* 201 */     STACK.set(copy);
/* 202 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void push(String message) {
/* 207 */     if (!this.useStack) {
/*     */       return;
/*     */     }
/* 210 */     add(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 215 */     if (!this.useStack) {
/* 216 */       return false;
/*     */     }
/* 218 */     MutableThreadContextStack values = STACK.get();
/* 219 */     if (values == null || values.isEmpty()) {
/* 220 */       return false;
/*     */     }
/* 222 */     MutableThreadContextStack copy = (MutableThreadContextStack)values.copy();
/* 223 */     boolean result = copy.remove(o);
/* 224 */     copy.freeze();
/* 225 */     STACK.set(copy);
/* 226 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> objects) {
/* 231 */     if (!this.useStack || objects.isEmpty()) {
/* 232 */       return false;
/*     */     }
/* 234 */     MutableThreadContextStack values = STACK.get();
/* 235 */     if (values == null || values.isEmpty()) {
/* 236 */       return false;
/*     */     }
/* 238 */     MutableThreadContextStack copy = (MutableThreadContextStack)values.copy();
/* 239 */     boolean result = copy.removeAll(objects);
/* 240 */     copy.freeze();
/* 241 */     STACK.set(copy);
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> objects) {
/* 247 */     if (!this.useStack || objects.isEmpty()) {
/* 248 */       return false;
/*     */     }
/* 250 */     MutableThreadContextStack values = STACK.get();
/* 251 */     if (values == null || values.isEmpty()) {
/* 252 */       return false;
/*     */     }
/* 254 */     MutableThreadContextStack copy = (MutableThreadContextStack)values.copy();
/* 255 */     boolean result = copy.retainAll(objects);
/* 256 */     copy.freeze();
/* 257 */     STACK.set(copy);
/* 258 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 263 */     MutableThreadContextStack values = STACK.get();
/* 264 */     return (values == null) ? 0 : values.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 269 */     MutableThreadContextStack result = STACK.get();
/* 270 */     if (result == null) {
/* 271 */       return (Object[])Strings.EMPTY_ARRAY;
/*     */     }
/* 273 */     return result.toArray(EMPTY_OBJECT_ARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] ts) {
/* 278 */     MutableThreadContextStack result = STACK.get();
/* 279 */     if (result == null) {
/* 280 */       if (ts.length > 0) {
/* 281 */         ts[0] = null;
/*     */       }
/* 283 */       return ts;
/*     */     } 
/* 285 */     return result.toArray(ts);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 290 */     MutableThreadContextStack values = STACK.get();
/* 291 */     return (values == null) ? "[]" : values.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder buffer) {
/* 296 */     MutableThreadContextStack values = STACK.get();
/* 297 */     if (values == null) {
/* 298 */       buffer.append("[]");
/*     */     } else {
/* 300 */       StringBuilders.appendValue(buffer, values);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void trim(int depth) {
/* 306 */     if (depth < 0) {
/* 307 */       throw new IllegalArgumentException("Maximum stack depth cannot be negative");
/*     */     }
/* 309 */     MutableThreadContextStack values = STACK.get();
/* 310 */     if (values == null) {
/*     */       return;
/*     */     }
/* 313 */     MutableThreadContextStack copy = (MutableThreadContextStack)values.copy();
/* 314 */     copy.trim(depth);
/* 315 */     copy.freeze();
/* 316 */     STACK.set(copy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreadContext.ContextStack getImmutableStackOrNull() {
/* 326 */     return STACK.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\DefaultThreadContextStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */