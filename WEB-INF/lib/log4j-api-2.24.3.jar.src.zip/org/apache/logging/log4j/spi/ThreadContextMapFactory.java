/*    */ package org.apache.logging.log4j.spi;
/*    */ 
/*    */ import org.apache.logging.log4j.util.ProviderUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ThreadContextMapFactory
/*    */ {
/*    */   public static void init() {
/* 51 */     ProviderUtil.getProvider().getThreadContextMapInstance();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static ThreadContextMap createThreadContextMap() {
/* 57 */     return ProviderUtil.getProvider().getThreadContextMapInstance();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\ThreadContextMapFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */