/*    */ package org.apache.logging.log4j.spi;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jspecify.annotations.NullMarked;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @NullMarked
/*    */ public class NoOpThreadContextMap
/*    */   implements ThreadContextMap
/*    */ {
/* 36 */   public static final ThreadContextMap INSTANCE = new NoOpThreadContextMap();
/*    */ 
/*    */   
/*    */   public void clear() {}
/*    */ 
/*    */   
/*    */   public boolean containsKey(String key) {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String get(String key) {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getCopy() {
/* 53 */     return new HashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getImmutableMapOrNull() {
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 63 */     return true;
/*    */   }
/*    */   
/*    */   public void put(String key, String value) {}
/*    */   
/*    */   public void remove(String key) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\spi\NoOpThreadContextMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */