/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import org.apache.logging.log4j.util.Constants;
/*     */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PerformanceSensitive({"allocation"})
/*     */ public class ReusableSimpleMessage
/*     */   implements ReusableMessage, CharSequence, ParameterVisitable, Clearable
/*     */ {
/*     */   private static final long serialVersionUID = -9199974506498249809L;
/*     */   private CharSequence charSequence;
/*     */   
/*     */   public void set(String message) {
/*  32 */     this.charSequence = message;
/*     */   }
/*     */   
/*     */   public void set(CharSequence charSequence) {
/*  36 */     this.charSequence = charSequence;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/*  41 */     return String.valueOf(this.charSequence);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFormat() {
/*  46 */     return (this.charSequence instanceof String) ? (String)this.charSequence : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/*  51 */     return Constants.EMPTY_OBJECT_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder buffer) {
/*  61 */     buffer.append(this.charSequence);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] swapParameters(Object[] emptyReplacement) {
/*  71 */     return emptyReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getParameterCount() {
/*  80 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S> void forEachParameter(ParameterConsumer<S> action, S state) {}
/*     */ 
/*     */   
/*     */   public Message memento() {
/*  88 */     return new SimpleMessage(this.charSequence);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/*  95 */     return (this.charSequence == null) ? 0 : this.charSequence.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/* 100 */     return this.charSequence.charAt(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 105 */     return this.charSequence.subSequence(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 110 */     this.charSequence = null;
/*     */   }
/*     */   
/*     */   private Object writeReplace() {
/* 114 */     return memento();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ReusableSimpleMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */