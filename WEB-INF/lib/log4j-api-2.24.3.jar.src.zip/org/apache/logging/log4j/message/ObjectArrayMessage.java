/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ import org.apache.logging.log4j.util.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectArrayMessage
/*     */   implements Message
/*     */ {
/*     */   private static final long serialVersionUID = -5903272448334166185L;
/*     */   private transient Object[] array;
/*     */   private transient String arrayString;
/*     */   
/*     */   public ObjectArrayMessage(Object... obj) {
/*  50 */     this.array = (obj == null) ? Constants.EMPTY_OBJECT_ARRAY : obj;
/*     */   }
/*     */   
/*     */   private boolean equalObjectsOrStrings(Object[] left, Object[] right) {
/*  54 */     return (Arrays.equals(left, right) || Arrays.toString(left).equals(Arrays.toString(right)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  59 */     if (this == o) {
/*  60 */       return true;
/*     */     }
/*  62 */     if (o == null || getClass() != o.getClass()) {
/*  63 */       return false;
/*     */     }
/*     */     
/*  66 */     ObjectArrayMessage that = (ObjectArrayMessage)o;
/*  67 */     return (this.array == null) ? ((that.array == null)) : equalObjectsOrStrings(this.array, that.array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/*  77 */     return getFormattedMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/*  88 */     if (this.arrayString == null) {
/*  89 */       this.arrayString = Arrays.toString(this.array);
/*     */     }
/*  91 */     return this.arrayString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 101 */     return this.array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 116 */     return Arrays.hashCode(this.array);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 120 */     in.defaultReadObject();
/* 121 */     this.array = (Object[])in.readObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return getFormattedMessage();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 130 */     out.defaultWriteObject();
/* 131 */     out.writeObject(this.array);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ObjectArrayMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */