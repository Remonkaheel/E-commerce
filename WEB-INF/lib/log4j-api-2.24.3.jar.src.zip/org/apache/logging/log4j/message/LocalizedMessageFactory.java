/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalizedMessageFactory
/*     */   extends AbstractMessageFactory
/*     */ {
/*     */   private static final long serialVersionUID = -1996295808703146741L;
/*     */   private final transient ResourceBundle resourceBundle;
/*     */   private final String baseName;
/*     */   
/*     */   public LocalizedMessageFactory(ResourceBundle resourceBundle) {
/*  46 */     this.resourceBundle = resourceBundle;
/*  47 */     this.baseName = null;
/*     */   }
/*     */   
/*     */   public LocalizedMessageFactory(String baseName) {
/*  51 */     this.resourceBundle = null;
/*  52 */     this.baseName = baseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseName() {
/*  61 */     return this.baseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getResourceBundle() {
/*  70 */     return this.resourceBundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String key) {
/*  78 */     if (this.resourceBundle == null) {
/*  79 */       return new LocalizedMessage(this.baseName, key);
/*     */     }
/*  81 */     return new LocalizedMessage(this.resourceBundle, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String key, Object... params) {
/*  95 */     if (this.resourceBundle == null) {
/*  96 */       return new LocalizedMessage(this.baseName, key, params);
/*     */     }
/*  98 */     return new LocalizedMessage(this.resourceBundle, key, params);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 103 */     if (this == object) {
/* 104 */       return true;
/*     */     }
/* 106 */     if (object == null || getClass() != object.getClass()) {
/* 107 */       return false;
/*     */     }
/* 109 */     LocalizedMessageFactory that = (LocalizedMessageFactory)object;
/* 110 */     return (Objects.equals(this.resourceBundle, that.resourceBundle) && Objects.equals(this.baseName, that.baseName));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 115 */     return Objects.hash(new Object[] { this.resourceBundle, this.baseName });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\LocalizedMessageFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */