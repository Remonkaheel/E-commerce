/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFlowMessageFactory
/*     */   implements FlowMessageFactory, Serializable
/*     */ {
/*     */   private static final String EXIT_DEFAULT_PREFIX = "Exit";
/*     */   private static final String ENTRY_DEFAULT_PREFIX = "Enter";
/*     */   private static final long serialVersionUID = 8578655591131397576L;
/*  35 */   public static final FlowMessageFactory INSTANCE = new DefaultFlowMessageFactory();
/*     */ 
/*     */   
/*     */   private final String entryText;
/*     */   
/*     */   private final String exitText;
/*     */ 
/*     */   
/*     */   public DefaultFlowMessageFactory() {
/*  44 */     this("Enter", "Exit");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultFlowMessageFactory(String entryText, String exitText) {
/*  53 */     this.entryText = entryText;
/*  54 */     this.exitText = exitText;
/*     */   }
/*     */   
/*     */   private static class AbstractFlowMessage
/*     */     implements FlowMessage, StringBuilderFormattable {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final Message message;
/*     */     private final String text;
/*     */     
/*     */     AbstractFlowMessage(String text, Message message) {
/*  64 */       this.message = message;
/*  65 */       this.text = text;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormattedMessage() {
/*  70 */       if (this.message != null) {
/*  71 */         return this.text + " " + this.message.getFormattedMessage();
/*     */       }
/*  73 */       return this.text;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormat() {
/*  78 */       if (this.message != null) {
/*  79 */         return this.text + " " + this.message.getFormat();
/*     */       }
/*  81 */       return this.text;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] getParameters() {
/*  86 */       if (this.message != null) {
/*  87 */         return this.message.getParameters();
/*     */       }
/*  89 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable getThrowable() {
/*  94 */       if (this.message != null) {
/*  95 */         return this.message.getThrowable();
/*     */       }
/*  97 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Message getMessage() {
/* 102 */       return this.message;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getText() {
/* 107 */       return this.text;
/*     */     }
/*     */ 
/*     */     
/*     */     public void formatTo(StringBuilder buffer) {
/* 112 */       buffer.append(this.text);
/* 113 */       if (this.message != null) {
/* 114 */         buffer.append(" ");
/* 115 */         StringBuilders.appendValue(buffer, this.message);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SimpleEntryMessage
/*     */     extends AbstractFlowMessage implements EntryMessage {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     SimpleEntryMessage(String entryText, Message message) {
/* 125 */       super(entryText, message);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SimpleExitMessage
/*     */     extends AbstractFlowMessage
/*     */     implements ExitMessage {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final Object result;
/*     */     private final boolean isVoid;
/*     */     
/*     */     SimpleExitMessage(String exitText, EntryMessage message) {
/* 137 */       this(exitText, message.getMessage());
/*     */     }
/*     */     
/*     */     SimpleExitMessage(String exitText, Message message) {
/* 141 */       super(exitText, message);
/* 142 */       this.result = null;
/* 143 */       this.isVoid = true;
/*     */     }
/*     */     
/*     */     SimpleExitMessage(String exitText, Object result, EntryMessage message) {
/* 147 */       this(exitText, result, message.getMessage());
/*     */     }
/*     */     
/*     */     SimpleExitMessage(String exitText, Object result, Message message) {
/* 151 */       super(exitText, message);
/* 152 */       this.result = result;
/* 153 */       this.isVoid = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormattedMessage() {
/* 158 */       String formattedMessage = super.getFormattedMessage();
/* 159 */       if (this.isVoid) {
/* 160 */         return formattedMessage;
/*     */       }
/* 162 */       return formattedMessage + ": " + this.result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEntryText() {
/* 171 */     return this.entryText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExitText() {
/* 179 */     return this.exitText;
/*     */   }
/*     */   
/*     */   public EntryMessage newEntryMessage(String format, Object... params) {
/*     */     Message message;
/* 184 */     boolean hasFormat = Strings.isNotEmpty(format);
/*     */     
/* 186 */     if (params == null || params.length == 0) {
/* 187 */       message = hasFormat ? ParameterizedMessageFactory.INSTANCE.newMessage(format) : null;
/* 188 */     } else if (hasFormat) {
/* 189 */       message = ParameterizedMessageFactory.INSTANCE.newMessage(format, params);
/*     */     } else {
/* 191 */       StringBuilder sb = new StringBuilder("params(");
/* 192 */       for (int i = 0; i < params.length; i++) {
/* 193 */         if (i > 0) {
/* 194 */           sb.append(", ");
/*     */         }
/* 196 */         sb.append("{}");
/*     */       } 
/* 198 */       sb.append(")");
/* 199 */       message = ParameterizedMessageFactory.INSTANCE.newMessage(sb.toString(), params);
/*     */     } 
/* 201 */     return newEntryMessage(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntryMessage newEntryMessage(Message message) {
/* 211 */     return new SimpleEntryMessage(this.entryText, makeImmutable(message));
/*     */   }
/*     */   
/*     */   private Message makeImmutable(Message message) {
/* 215 */     if (message instanceof ReusableMessage) {
/* 216 */       return ((ReusableMessage)message).memento();
/*     */     }
/* 218 */     return message;
/*     */   }
/*     */   
/*     */   public ExitMessage newExitMessage(String format, Object result) {
/*     */     Message message;
/* 223 */     boolean hasFormat = Strings.isNotEmpty(format);
/*     */     
/* 225 */     if (result == null) {
/* 226 */       message = hasFormat ? ParameterizedMessageFactory.INSTANCE.newMessage(format) : null;
/*     */     } else {
/* 228 */       message = ParameterizedMessageFactory.INSTANCE.newMessage(hasFormat ? format : "with({})", result);
/*     */     } 
/* 230 */     return newExitMessage(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public ExitMessage newExitMessage(Message message) {
/* 235 */     return new SimpleExitMessage(this.exitText, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExitMessage newExitMessage(EntryMessage message) {
/* 245 */     return new SimpleExitMessage(this.exitText, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExitMessage newExitMessage(Object result, EntryMessage message) {
/* 255 */     return new SimpleExitMessage(this.exitText, result, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExitMessage newExitMessage(Object result, Message message) {
/* 265 */     return new SimpleExitMessage(this.exitText, result, message);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\DefaultFlowMessageFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */