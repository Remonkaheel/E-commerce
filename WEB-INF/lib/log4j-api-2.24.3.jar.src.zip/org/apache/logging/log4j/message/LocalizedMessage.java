/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalizedMessage
/*     */   implements Message, LoggerNameAwareMessage
/*     */ {
/*     */   private static final long serialVersionUID = 3893703791567290742L;
/*     */   private String baseName;
/*     */   private transient ResourceBundle resourceBundle;
/*     */   private final Locale locale;
/*  46 */   private transient StatusLogger logger = StatusLogger.getLogger();
/*     */   
/*     */   private String loggerName;
/*     */   
/*     */   private String key;
/*     */   
/*     */   private String[] stringArgs;
/*     */   
/*     */   private transient Object[] argArray;
/*     */   
/*     */   private String formattedMessage;
/*     */   
/*     */   private transient Throwable throwable;
/*     */ 
/*     */   
/*     */   public LocalizedMessage(String messagePattern, Object[] arguments) {
/*  62 */     this((ResourceBundle)null, (Locale)null, messagePattern, arguments);
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String baseName, String key, Object[] arguments) {
/*  66 */     this(baseName, (Locale)null, key, arguments);
/*     */   }
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, String key, Object[] arguments) {
/*  70 */     this(bundle, (Locale)null, key, arguments);
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String baseName, Locale locale, String key, Object[] arguments) {
/*  74 */     this.key = key;
/*  75 */     this.argArray = arguments;
/*  76 */     this.throwable = null;
/*  77 */     this.baseName = baseName;
/*  78 */     this.resourceBundle = null;
/*  79 */     this.locale = locale;
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, Locale locale, String key, Object[] arguments) {
/*  84 */     this.key = key;
/*  85 */     this.argArray = arguments;
/*  86 */     this.throwable = null;
/*  87 */     this.baseName = null;
/*  88 */     this.resourceBundle = bundle;
/*  89 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public LocalizedMessage(Locale locale, String key, Object[] arguments) {
/*  93 */     this((ResourceBundle)null, locale, key, arguments);
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String messagePattern, Object arg) {
/*  97 */     this((ResourceBundle)null, (Locale)null, messagePattern, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String baseName, String key, Object arg) {
/* 101 */     this(baseName, (Locale)null, key, new Object[] { arg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, String key) {
/* 108 */     this(bundle, (Locale)null, key, new Object[0]);
/*     */   }
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, String key, Object arg) {
/* 112 */     this(bundle, (Locale)null, key, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String baseName, Locale locale, String key, Object arg) {
/* 116 */     this(baseName, locale, key, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, Locale locale, String key, Object arg) {
/* 120 */     this(bundle, locale, key, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(Locale locale, String key, Object arg) {
/* 124 */     this((ResourceBundle)null, locale, key, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String messagePattern, Object arg1, Object arg2) {
/* 128 */     this((ResourceBundle)null, (Locale)null, messagePattern, new Object[] { arg1, arg2 });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(String baseName, String key, Object arg1, Object arg2) {
/* 132 */     this(baseName, (Locale)null, key, new Object[] { arg1, arg2 });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, String key, Object arg1, Object arg2) {
/* 136 */     this(bundle, (Locale)null, key, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalizedMessage(String baseName, Locale locale, String key, Object arg1, Object arg2) {
/* 141 */     this(baseName, locale, key, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalizedMessage(ResourceBundle bundle, Locale locale, String key, Object arg1, Object arg2) {
/* 146 */     this(bundle, locale, key, new Object[] { arg1, arg2 });
/*     */   }
/*     */   
/*     */   public LocalizedMessage(Locale locale, String key, Object arg1, Object arg2) {
/* 150 */     this((ResourceBundle)null, locale, key, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoggerName(String name) {
/* 160 */     this.loggerName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLoggerName() {
/* 170 */     return this.loggerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 180 */     if (this.formattedMessage != null) {
/* 181 */       return this.formattedMessage;
/*     */     }
/* 183 */     ResourceBundle bundle = this.resourceBundle;
/* 184 */     if (bundle == null) {
/* 185 */       if (this.baseName != null) {
/* 186 */         bundle = getResourceBundle(this.baseName, this.locale, false);
/*     */       } else {
/* 188 */         bundle = getResourceBundle(this.loggerName, this.locale, true);
/*     */       } 
/*     */     }
/* 191 */     String myKey = getFormat();
/* 192 */     String msgPattern = (bundle == null || !bundle.containsKey(myKey)) ? myKey : bundle.getString(myKey);
/* 193 */     Object[] array = (this.argArray == null) ? (Object[])this.stringArgs : this.argArray;
/* 194 */     FormattedMessage msg = new FormattedMessage(msgPattern, array);
/* 195 */     this.formattedMessage = msg.getFormattedMessage();
/* 196 */     this.throwable = msg.getThrowable();
/* 197 */     return this.formattedMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 202 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 207 */     if (this.argArray != null) {
/* 208 */       return this.argArray;
/*     */     }
/* 210 */     return (Object[])this.stringArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 215 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceBundle getResourceBundle(String rbBaseName, Locale resourceBundleLocale, boolean loop) {
/* 229 */     ResourceBundle rb = null;
/*     */     
/* 231 */     if (rbBaseName == null) {
/* 232 */       return null;
/*     */     }
/*     */     try {
/* 235 */       if (resourceBundleLocale != null) {
/* 236 */         rb = ResourceBundle.getBundle(rbBaseName, resourceBundleLocale);
/*     */       } else {
/* 238 */         rb = ResourceBundle.getBundle(rbBaseName);
/*     */       } 
/* 240 */     } catch (MissingResourceException ex) {
/* 241 */       if (!loop) {
/* 242 */         this.logger.debug("Unable to locate ResourceBundle {}", rbBaseName);
/* 243 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     String substr = rbBaseName;
/*     */     int i;
/* 249 */     while (rb == null && (i = substr.lastIndexOf('.')) > 0) {
/* 250 */       substr = substr.substring(0, i);
/*     */       try {
/* 252 */         if (resourceBundleLocale != null) {
/* 253 */           rb = ResourceBundle.getBundle(substr, resourceBundleLocale); continue;
/*     */         } 
/* 255 */         rb = ResourceBundle.getBundle(substr);
/*     */       }
/* 257 */       catch (MissingResourceException ex) {
/* 258 */         this.logger.debug("Unable to locate ResourceBundle {}", substr);
/*     */       } 
/*     */     } 
/* 261 */     return rb;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 266 */     return getFormattedMessage();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 270 */     out.defaultWriteObject();
/* 271 */     getFormattedMessage();
/* 272 */     out.writeUTF(this.formattedMessage);
/* 273 */     out.writeUTF(this.key);
/* 274 */     out.writeUTF(this.baseName);
/* 275 */     out.writeInt(this.argArray.length);
/* 276 */     this.stringArgs = new String[this.argArray.length];
/* 277 */     int i = 0;
/* 278 */     for (Object obj : this.argArray) {
/* 279 */       this.stringArgs[i] = obj.toString();
/* 280 */       i++;
/*     */     } 
/* 282 */     out.writeObject(this.stringArgs);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 286 */     in.defaultReadObject();
/* 287 */     this.formattedMessage = in.readUTF();
/* 288 */     this.key = in.readUTF();
/* 289 */     this.baseName = in.readUTF();
/* 290 */     in.readInt();
/* 291 */     this.stringArgs = (String[])in.readObject();
/* 292 */     this.logger = StatusLogger.getLogger();
/* 293 */     this.resourceBundle = null;
/* 294 */     this.argArray = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\LocalizedMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */