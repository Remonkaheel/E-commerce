/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.logging.log4j.util.BiConsumer;
/*     */ import org.apache.logging.log4j.util.EnglishEnums;
/*     */ import org.apache.logging.log4j.util.IndexedReadOnlyStringMap;
/*     */ import org.apache.logging.log4j.util.IndexedStringMap;
/*     */ import org.apache.logging.log4j.util.MultiFormatStringBuilderFormattable;
/*     */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*     */ import org.apache.logging.log4j.util.SortedArrayStringMap;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ import org.apache.logging.log4j.util.TriConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AsynchronouslyFormattable
/*     */ @PerformanceSensitive({"allocation"})
/*     */ public class MapMessage<M extends MapMessage<M, V>, V>
/*     */   implements MultiFormatStringBuilderFormattable
/*     */ {
/*     */   private static final long serialVersionUID = -5031471831131487120L;
/*     */   private final IndexedStringMap data;
/*     */   
/*     */   public enum MapFormat
/*     */   {
/*  62 */     XML,
/*     */ 
/*     */     
/*  65 */     JSON,
/*     */ 
/*     */     
/*  68 */     JAVA,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     JAVA_UNQUOTED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MapFormat lookupIgnoreCase(String format) {
/*  84 */       return XML.name().equalsIgnoreCase(format) ? 
/*  85 */         XML : (
/*  86 */         JSON.name().equalsIgnoreCase(format) ? 
/*  87 */         JSON : (
/*  88 */         JAVA.name().equalsIgnoreCase(format) ? 
/*  89 */         JAVA : (
/*  90 */         JAVA_UNQUOTED.name().equalsIgnoreCase(format) ? 
/*  91 */         JAVA_UNQUOTED : 
/*  92 */         null)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String[] names() {
/* 101 */       return new String[] { XML.name(), JSON.name(), JAVA.name(), JAVA_UNQUOTED.name() };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapMessage() {
/* 111 */     this.data = (IndexedStringMap)new SortedArrayStringMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapMessage(int initialCapacity) {
/* 120 */     this.data = (IndexedStringMap)new SortedArrayStringMap(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapMessage(Map<String, V> map) {
/* 128 */     this.data = (IndexedStringMap)new SortedArrayStringMap(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getFormats() {
/* 133 */     return MapFormat.names();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 142 */     Object[] result = new Object[this.data.size()];
/* 143 */     for (int i = 0; i < this.data.size(); i++) {
/* 144 */       result[i] = this.data.getValueAt(i);
/*     */     }
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 155 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, V> getData() {
/* 164 */     TreeMap<String, V> result = new TreeMap<>();
/* 165 */     for (int i = 0; i < this.data.size(); i++)
/*     */     {
/* 167 */       result.put(this.data.getKeyAt(i), (V)this.data.getValueAt(i));
/*     */     }
/* 169 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexedReadOnlyStringMap getIndexedReadOnlyStringMap() {
/* 177 */     return (IndexedReadOnlyStringMap)this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 184 */     this.data.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 195 */     return this.data.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String candidateKey, String value) {
/* 204 */     if (value == null) {
/* 205 */       throw new IllegalArgumentException("No value provided for key " + candidateKey);
/*     */     }
/* 207 */     String key = toKey(candidateKey);
/* 208 */     validate(key, value);
/* 209 */     this.data.putValue(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<String, String> map) {
/* 217 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/* 218 */       this.data.putValue(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String key) {
/* 228 */     Object result = this.data.getValue(key);
/* 229 */     return ParameterFormatter.deepToString(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String remove(String key) {
/* 238 */     String result = get(key);
/* 239 */     this.data.remove(key);
/* 240 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asString() {
/* 249 */     return format((MapFormat)null, new StringBuilder()).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asString(String format) {
/*     */     try {
/* 260 */       return format((MapFormat)EnglishEnums.valueOf(MapFormat.class, format), new StringBuilder())
/* 261 */         .toString();
/* 262 */     } catch (IllegalArgumentException ex) {
/* 263 */       return asString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <CV> void forEach(BiConsumer<String, ? super CV> action) {
/* 286 */     this.data.forEach(action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <CV, S> void forEach(TriConsumer<String, ? super CV, S> action, S state) {
/* 315 */     this.data.forEach(action, state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringBuilder format(MapFormat format, StringBuilder sb) {
/* 325 */     if (format == null)
/* 326 */     { appendMap(sb); }
/*     */     else
/* 328 */     { switch (format)
/*     */       { case XML:
/* 330 */           asXml(sb);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 349 */           return sb;case JSON: asJson(sb); return sb;case JAVA: asJava(sb); return sb;case JAVA_UNQUOTED: asJavaUnquoted(sb); return sb; }  appendMap(sb); }  return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void asXml(StringBuilder sb) {
/* 358 */     sb.append("<Map>\n");
/* 359 */     for (int i = 0; i < this.data.size(); i++) {
/* 360 */       sb.append("  <Entry key=\"").append(this.data.getKeyAt(i)).append("\">");
/* 361 */       int size = sb.length();
/* 362 */       ParameterFormatter.recursiveDeepToString(this.data.getValueAt(i), sb);
/* 363 */       StringBuilders.escapeXml(sb, size);
/* 364 */       sb.append("</Entry>\n");
/*     */     } 
/* 366 */     sb.append("</Map>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 375 */     return asString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage(String[] formats) {
/* 391 */     return format(getFormat(formats), new StringBuilder()).toString();
/*     */   }
/*     */   
/*     */   private MapFormat getFormat(String[] formats) {
/* 395 */     if (formats == null || formats.length == 0) {
/* 396 */       return null;
/*     */     }
/* 398 */     for (int i = 0; i < formats.length; i++) {
/* 399 */       MapFormat mapFormat = MapFormat.lookupIgnoreCase(formats[i]);
/* 400 */       if (mapFormat != null) {
/* 401 */         return mapFormat;
/*     */       }
/*     */     } 
/* 404 */     return null;
/*     */   }
/*     */   
/*     */   protected void appendMap(StringBuilder sb) {
/* 408 */     for (int i = 0; i < this.data.size(); i++) {
/* 409 */       if (i > 0) {
/* 410 */         sb.append(' ');
/*     */       }
/* 412 */       sb.append(this.data.getKeyAt(i)).append('=').append('"');
/* 413 */       ParameterFormatter.recursiveDeepToString(this.data.getValueAt(i), sb);
/* 414 */       sb.append('"');
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void asJson(StringBuilder sb) {
/* 419 */     MapMessageJsonFormatter.format(sb, this.data);
/*     */   }
/*     */   
/*     */   protected void asJavaUnquoted(StringBuilder sb) {
/* 423 */     asJava(sb, false);
/*     */   }
/*     */   
/*     */   protected void asJava(StringBuilder sb) {
/* 427 */     asJava(sb, true);
/*     */   }
/*     */   
/*     */   private void asJava(StringBuilder sb, boolean quoted) {
/* 431 */     sb.append('{');
/* 432 */     for (int i = 0; i < this.data.size(); i++) {
/* 433 */       if (i > 0) {
/* 434 */         sb.append(", ");
/*     */       }
/* 436 */       sb.append(this.data.getKeyAt(i)).append('=');
/* 437 */       if (quoted) {
/* 438 */         sb.append('"');
/*     */       }
/* 440 */       ParameterFormatter.recursiveDeepToString(this.data.getValueAt(i), sb);
/* 441 */       if (quoted) {
/* 442 */         sb.append('"');
/*     */       }
/*     */     } 
/* 445 */     sb.append('}');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M newInstance(Map<String, V> map) {
/* 455 */     return (M)new MapMessage(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 460 */     return asString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder buffer) {
/* 465 */     format((MapFormat)null, buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(String[] formats, StringBuilder buffer) {
/* 470 */     format(getFormat(formats), buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 475 */     if (this == o) {
/* 476 */       return true;
/*     */     }
/* 478 */     if (!(o instanceof MapMessage)) {
/* 479 */       return false;
/*     */     }
/*     */     
/* 482 */     MapMessage<?, ?> that = (MapMessage<?, ?>)o;
/*     */     
/* 484 */     return this.data.equals(that.data);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 489 */     return this.data.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 499 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, boolean value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, byte value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, char value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, double value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, float value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, int value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, long value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, Object value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, short value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, String value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toKey(String candidateKey) {
/* 600 */     return candidateKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, boolean value) {
/* 612 */     String key = toKey(candidateKey);
/* 613 */     validate(key, value);
/* 614 */     this.data.putValue(key, Boolean.valueOf(value));
/* 615 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, byte value) {
/* 627 */     String key = toKey(candidateKey);
/* 628 */     validate(key, value);
/* 629 */     this.data.putValue(key, Byte.valueOf(value));
/* 630 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, char value) {
/* 642 */     String key = toKey(candidateKey);
/* 643 */     validate(key, value);
/* 644 */     this.data.putValue(key, Character.valueOf(value));
/* 645 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, double value) {
/* 657 */     String key = toKey(candidateKey);
/* 658 */     validate(key, value);
/* 659 */     this.data.putValue(key, Double.valueOf(value));
/* 660 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, float value) {
/* 672 */     String key = toKey(candidateKey);
/* 673 */     validate(key, value);
/* 674 */     this.data.putValue(key, Float.valueOf(value));
/* 675 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, int value) {
/* 687 */     String key = toKey(candidateKey);
/* 688 */     validate(key, value);
/* 689 */     this.data.putValue(key, Integer.valueOf(value));
/* 690 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, long value) {
/* 702 */     String key = toKey(candidateKey);
/* 703 */     validate(key, value);
/* 704 */     this.data.putValue(key, Long.valueOf(value));
/* 705 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, Object value) {
/* 717 */     String key = toKey(candidateKey);
/* 718 */     validate(key, value);
/* 719 */     this.data.putValue(key, value);
/* 720 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, short value) {
/* 732 */     String key = toKey(candidateKey);
/* 733 */     validate(key, value);
/* 734 */     this.data.putValue(key, Short.valueOf(value));
/* 735 */     return (M)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M with(String candidateKey, String value) {
/* 746 */     String key = toKey(candidateKey);
/* 747 */     put(key, value);
/* 748 */     return (M)this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\MapMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */