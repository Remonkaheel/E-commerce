/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BasicThreadInformation
/*     */   implements ThreadInformation
/*     */ {
/*     */   private static final int HASH_SHIFT = 32;
/*     */   private static final int HASH_MULTIPLIER = 31;
/*     */   private final long id;
/*     */   private final String name;
/*     */   private final Thread.State state;
/*     */   private final int priority;
/*     */   private final boolean isDaemon;
/*     */   private final String threadGroupName;
/*     */   
/*     */   BasicThreadInformation(Thread thread) {
/*  42 */     this.id = thread.getId();
/*  43 */     this.name = thread.getName();
/*     */     
/*  45 */     this.state = thread.getState();
/*  46 */     this.priority = thread.getPriority();
/*     */     
/*  48 */     this.isDaemon = thread.isDaemon();
/*  49 */     ThreadGroup group = thread.getThreadGroup();
/*  50 */     this.threadGroupName = (group == null) ? null : group.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  55 */     if (this == o) {
/*  56 */       return true;
/*     */     }
/*  58 */     if (!(o instanceof BasicThreadInformation)) {
/*  59 */       return false;
/*     */     }
/*     */     
/*  62 */     BasicThreadInformation that = (BasicThreadInformation)o;
/*     */     
/*  64 */     if (this.id != that.id) {
/*  65 */       return false;
/*     */     }
/*  67 */     return (this.name != null) ? this.name.equals(that.name) : ((that.name == null));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  72 */     int result = (int)(this.id ^ this.id >>> 32L);
/*  73 */     result = 31 * result + ((this.name != null) ? this.name.hashCode() : 0);
/*  74 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printThreadInfo(StringBuilder sb) {
/*  83 */     StringBuilders.appendDqValue(sb, this.name).append(' ');
/*  84 */     if (this.isDaemon) {
/*  85 */       sb.append("daemon ");
/*     */     }
/*  87 */     sb.append("prio=").append(this.priority).append(" tid=").append(this.id).append(' ');
/*  88 */     if (this.threadGroupName != null) {
/*  89 */       StringBuilders.appendKeyDqValue(sb, "group", this.threadGroupName);
/*     */     }
/*  91 */     sb.append('\n');
/*  92 */     sb.append("\tThread state: ").append(this.state.name()).append('\n');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStack(StringBuilder sb, StackTraceElement[] trace) {
/* 102 */     for (StackTraceElement element : trace)
/* 103 */       sb.append("\tat ").append(element).append('\n'); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\BasicThreadInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */