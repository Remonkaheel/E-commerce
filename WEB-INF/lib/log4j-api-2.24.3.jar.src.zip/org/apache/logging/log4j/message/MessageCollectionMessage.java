package org.apache.logging.log4j.message;

public interface MessageCollectionMessage<T> extends Message, Iterable<T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\MessageCollectionMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */