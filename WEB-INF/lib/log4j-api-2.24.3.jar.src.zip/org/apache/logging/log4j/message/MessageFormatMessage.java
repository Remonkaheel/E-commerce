/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.IllegalFormatException;
/*     */ import java.util.Locale;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageFormatMessage
/*     */   implements Message
/*     */ {
/*  34 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   
/*     */   private static final int HASHVAL = 31;
/*     */ 
/*     */   
/*     */   private String messagePattern;
/*     */ 
/*     */   
/*     */   private transient Object[] parameters;
/*     */ 
/*     */   
/*     */   private String[] serializedParameters;
/*     */ 
/*     */   
/*     */   private transient String formattedMessage;
/*     */   
/*     */   private transient Throwable throwable;
/*     */   
/*     */   private final Locale locale;
/*     */ 
/*     */   
/*     */   public MessageFormatMessage(Locale locale, String messagePattern, Object... parameters) {
/*  60 */     this.locale = locale;
/*  61 */     this.messagePattern = messagePattern;
/*  62 */     this.parameters = parameters;
/*  63 */     int length = (parameters == null) ? 0 : parameters.length;
/*  64 */     if (length > 0 && parameters[length - 1] instanceof Throwable) {
/*  65 */       this.throwable = (Throwable)parameters[length - 1];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageFormatMessage(String messagePattern, Object... parameters) {
/*  76 */     this(Locale.getDefault(Locale.Category.FORMAT), messagePattern, parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/*  85 */     if (this.formattedMessage == null) {
/*  86 */       this.formattedMessage = formatMessage(this.messagePattern, this.parameters);
/*     */     }
/*  88 */     return this.formattedMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/*  97 */     return this.messagePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 106 */     if (this.parameters != null) {
/* 107 */       return this.parameters;
/*     */     }
/* 109 */     return (Object[])this.serializedParameters;
/*     */   }
/*     */   
/*     */   protected String formatMessage(String msgPattern, Object... args) {
/*     */     try {
/* 114 */       MessageFormat temp = new MessageFormat(msgPattern, this.locale);
/* 115 */       return temp.format(args);
/* 116 */     } catch (IllegalFormatException ife) {
/* 117 */       LOGGER.error("Unable to format msg: {}", msgPattern, ife);
/* 118 */       return msgPattern;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 124 */     if (this == o) {
/* 125 */       return true;
/*     */     }
/* 127 */     if (!(o instanceof MessageFormatMessage)) {
/* 128 */       return false;
/*     */     }
/*     */     
/* 131 */     MessageFormatMessage that = (MessageFormatMessage)o;
/*     */     
/* 133 */     if ((this.messagePattern != null) ? !this.messagePattern.equals(that.messagePattern) : (that.messagePattern != null)) {
/* 134 */       return false;
/*     */     }
/* 136 */     return Arrays.equals((Object[])this.serializedParameters, (Object[])that.serializedParameters);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 141 */     int result = (this.messagePattern != null) ? this.messagePattern.hashCode() : 0;
/* 142 */     result = 31 * result + ((this.serializedParameters != null) ? Arrays.hashCode((Object[])this.serializedParameters) : 0);
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return getFormattedMessage();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 152 */     getFormattedMessage();
/* 153 */     out.writeUTF(this.formattedMessage);
/* 154 */     out.writeUTF(this.messagePattern);
/* 155 */     int length = (this.parameters == null) ? 0 : this.parameters.length;
/* 156 */     out.writeInt(length);
/* 157 */     this.serializedParameters = new String[length];
/* 158 */     if (length > 0) {
/* 159 */       for (int i = 0; i < length; i++) {
/* 160 */         this.serializedParameters[i] = String.valueOf(this.parameters[i]);
/* 161 */         out.writeUTF(this.serializedParameters[i]);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException {
/* 167 */     this.parameters = null;
/* 168 */     this.throwable = null;
/* 169 */     this.formattedMessage = in.readUTF();
/* 170 */     this.messagePattern = in.readUTF();
/* 171 */     int length = in.readInt();
/* 172 */     this.serializedParameters = new String[length];
/* 173 */     for (int i = 0; i < length; i++) {
/* 174 */       this.serializedParameters[i] = in.readUTF();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 185 */     return this.throwable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\MessageFormatMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */