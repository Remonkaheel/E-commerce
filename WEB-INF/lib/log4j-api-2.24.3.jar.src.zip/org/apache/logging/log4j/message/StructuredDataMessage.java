/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.util.EnglishEnums;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AsynchronouslyFormattable
/*     */ public class StructuredDataMessage
/*     */   extends MapMessage<StructuredDataMessage, String>
/*     */ {
/*     */   private static final long serialVersionUID = 1703221292892071920L;
/*     */   private static final int MAX_LENGTH = 32;
/*     */   private static final int HASHVAL = 31;
/*     */   private StructuredDataId id;
/*     */   private String message;
/*     */   private String type;
/*     */   private final int maxLength;
/*     */   
/*     */   public enum Format
/*     */   {
/*  54 */     XML,
/*     */     
/*  56 */     FULL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(String id, String msg, String type) {
/*  66 */     this(id, msg, type, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(String id, String msg, String type, int maxLength) {
/*  79 */     this.id = new StructuredDataId(id, null, null, maxLength);
/*  80 */     this.message = msg;
/*  81 */     this.type = type;
/*  82 */     this.maxLength = maxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(String id, String msg, String type, Map<String, String> data) {
/*  94 */     this(id, msg, type, data, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(String id, String msg, String type, Map<String, String> data, int maxLength) {
/* 109 */     super(data);
/* 110 */     this.id = new StructuredDataId(id, null, null, maxLength);
/* 111 */     this.message = msg;
/* 112 */     this.type = type;
/* 113 */     this.maxLength = maxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(StructuredDataId id, String msg, String type) {
/* 123 */     this(id, msg, type, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(StructuredDataId id, String msg, String type, int maxLength) {
/* 135 */     this.id = id;
/* 136 */     this.message = msg;
/* 137 */     this.type = type;
/* 138 */     this.maxLength = maxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(StructuredDataId id, String msg, String type, Map<String, String> data) {
/* 151 */     this(id, msg, type, data, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataMessage(StructuredDataId id, String msg, String type, Map<String, String> data, int maxLength) {
/* 170 */     super(data);
/* 171 */     this.id = id;
/* 172 */     this.message = msg;
/* 173 */     this.type = type;
/* 174 */     this.maxLength = maxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StructuredDataMessage(StructuredDataMessage msg, Map<String, String> map) {
/* 183 */     super(map);
/* 184 */     this.id = msg.id;
/* 185 */     this.message = msg.message;
/* 186 */     this.type = msg.type;
/* 187 */     this.maxLength = 32;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StructuredDataMessage() {
/* 194 */     this.maxLength = 32;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFormats() {
/* 203 */     String[] formats = new String[(Format.values()).length];
/* 204 */     int i = 0;
/* 205 */     for (Format format : Format.values()) {
/* 206 */       formats[i++] = format.name();
/*     */     }
/* 208 */     return formats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId getId() {
/* 216 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setId(String id) {
/* 224 */     this.id = new StructuredDataId(id, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setId(StructuredDataId id) {
/* 232 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 240 */     return this.type;
/*     */   }
/*     */   
/*     */   protected void setType(String type) {
/* 244 */     if (type.length() > 32) {
/* 245 */       throw new IllegalArgumentException("structured data type exceeds maximum length of 32 characters: " + type);
/*     */     }
/* 247 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder buffer) {
/* 252 */     asString(Format.FULL, null, buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(String[] formats, StringBuilder buffer) {
/* 257 */     asString(getFormat(formats), null, buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 266 */     return this.message;
/*     */   }
/*     */   
/*     */   protected void setMessageFormat(String msg) {
/* 270 */     this.message = msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asString() {
/* 280 */     return asString(Format.FULL, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asString(String format) {
/*     */     try {
/* 292 */       return asString((Format)EnglishEnums.valueOf(Format.class, format), null);
/* 293 */     } catch (IllegalArgumentException ex) {
/* 294 */       return asString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String asString(Format format, StructuredDataId structuredDataId) {
/* 308 */     StringBuilder sb = new StringBuilder();
/* 309 */     asString(format, structuredDataId, sb);
/* 310 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void asString(Format format, StructuredDataId structuredDataId, StringBuilder sb) {
/* 323 */     boolean full = Format.FULL.equals(format);
/* 324 */     if (full) {
/* 325 */       String myType = getType();
/* 326 */       if (myType == null) {
/*     */         return;
/*     */       }
/* 329 */       sb.append(getType()).append(' ');
/*     */     } 
/* 331 */     StructuredDataId sdId = getId();
/* 332 */     if (sdId != null) {
/* 333 */       sdId = sdId.makeId(structuredDataId);
/*     */     } else {
/* 335 */       sdId = structuredDataId;
/*     */     } 
/* 337 */     if (sdId == null || sdId.getName() == null) {
/*     */       return;
/*     */     }
/* 340 */     if (Format.XML.equals(format)) {
/* 341 */       asXml(sdId, sb);
/*     */       return;
/*     */     } 
/* 344 */     sb.append('[');
/* 345 */     StringBuilders.appendValue(sb, sdId);
/* 346 */     sb.append(' ');
/* 347 */     appendMap(sb);
/* 348 */     sb.append(']');
/* 349 */     if (full) {
/* 350 */       String msg = getFormat();
/* 351 */       if (msg != null) {
/* 352 */         sb.append(' ').append(msg);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void asXml(StructuredDataId structuredDataId, StringBuilder sb) {
/* 358 */     sb.append("<StructuredData>\n");
/* 359 */     sb.append("<type>").append(this.type).append("</type>\n");
/* 360 */     sb.append("<id>").append(structuredDataId).append("</id>\n");
/* 361 */     asXml(sb);
/* 362 */     sb.append("\n</StructuredData>\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 371 */     return asString(Format.FULL, (StructuredDataId)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage(String[] formats) {
/* 385 */     return asString(getFormat(formats), (StructuredDataId)null);
/*     */   }
/*     */   
/*     */   private Format getFormat(String[] formats) {
/* 389 */     if (formats != null && formats.length > 0) {
/* 390 */       for (int i = 0; i < formats.length; i++) {
/* 391 */         String format = formats[i];
/* 392 */         if (Format.XML.name().equalsIgnoreCase(format))
/* 393 */           return Format.XML; 
/* 394 */         if (Format.FULL.name().equalsIgnoreCase(format)) {
/* 395 */           return Format.FULL;
/*     */         }
/*     */       } 
/* 398 */       return null;
/*     */     } 
/* 400 */     return Format.FULL;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 405 */     return asString((Format)null, (StructuredDataId)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public StructuredDataMessage newInstance(Map<String, String> map) {
/* 410 */     return new StructuredDataMessage(this, map);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 415 */     if (this == o) {
/* 416 */       return true;
/*     */     }
/* 418 */     if (!(o instanceof StructuredDataMessage)) {
/* 419 */       return false;
/*     */     }
/*     */     
/* 422 */     StructuredDataMessage that = (StructuredDataMessage)o;
/*     */     
/* 424 */     if (!super.equals(o)) {
/* 425 */       return false;
/*     */     }
/* 427 */     if ((this.type != null) ? !this.type.equals(that.type) : (that.type != null)) {
/* 428 */       return false;
/*     */     }
/* 430 */     if ((this.id != null) ? !this.id.equals(that.id) : (that.id != null)) {
/* 431 */       return false;
/*     */     }
/* 433 */     if ((this.message != null) ? !this.message.equals(that.message) : (that.message != null)) {
/* 434 */       return false;
/*     */     }
/*     */     
/* 437 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 442 */     int result = super.hashCode();
/* 443 */     result = 31 * result + ((this.type != null) ? this.type.hashCode() : 0);
/* 444 */     result = 31 * result + ((this.id != null) ? this.id.hashCode() : 0);
/* 445 */     result = 31 * result + ((this.message != null) ? this.message.hashCode() : 0);
/* 446 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate(String key, boolean value) {
/* 451 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, byte value) {
/* 459 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, char value) {
/* 467 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, double value) {
/* 475 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, float value) {
/* 483 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, int value) {
/* 491 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, long value) {
/* 499 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, Object value) {
/* 507 */     validateKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate(String key, short value) {
/* 515 */     validateKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate(String key, String value) {
/* 520 */     validateKey(key);
/*     */   }
/*     */   
/*     */   protected void validateKey(String key) {
/* 524 */     if (this.maxLength > 0 && key.length() > this.maxLength) {
/* 525 */       throw new IllegalArgumentException("Structured data keys are limited to " + this.maxLength + " characters. key: " + key);
/*     */     }
/*     */     
/* 528 */     for (int i = 0; i < key.length(); i++) {
/* 529 */       char c = key.charAt(i);
/* 530 */       if (c < '!' || c > '~' || c == '=' || c == ']' || c == '"')
/* 531 */         throw new IllegalArgumentException("Structured data keys must contain printable US ASCII charactersand may not contain a space, =, ], or \""); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\StructuredDataMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */