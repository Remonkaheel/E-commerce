/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.time.ZoneId;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParameterFormatter
/*     */ {
/*     */   static final String RECURSION_PREFIX = "[...";
/*     */   static final String RECURSION_SUFFIX = "...]";
/*     */   static final String ERROR_PREFIX = "[!!!";
/*     */   static final String ERROR_SEPARATOR = "=>";
/*     */   static final String ERROR_MSG_SEPARATOR = ":";
/*     */   static final String ERROR_SUFFIX = "!!!]";
/*     */   private static final char DELIM_START = '{';
/*     */   private static final char DELIM_STOP = '}';
/*     */   private static final char ESCAPE_CHAR = '\\';
/*  68 */   private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ").withZone(ZoneId.systemDefault());
/*     */   
/*  70 */   private static final Logger STATUS_LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MessagePatternAnalysis analyzePattern(String pattern, int argCount) {
/*  96 */     MessagePatternAnalysis analysis = new MessagePatternAnalysis();
/*  97 */     analyzePattern(pattern, argCount, analysis);
/*  98 */     return analysis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void analyzePattern(String pattern, int argCount, MessagePatternAnalysis analysis) {
/*     */     int l;
/* 126 */     if (pattern == null || (l = pattern.length()) < 2) {
/* 127 */       analysis.placeholderCount = 0;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 132 */     boolean escaped = false;
/* 133 */     analysis.placeholderCount = 0;
/* 134 */     analysis.escapedCharFound = false;
/* 135 */     for (int i = 0; i < l - 1; i++) {
/* 136 */       char c = pattern.charAt(i);
/* 137 */       if (c == '\\') {
/* 138 */         analysis.escapedCharFound = true;
/* 139 */         escaped = !escaped;
/*     */       }
/* 141 */       else if (escaped) {
/* 142 */         escaped = false;
/* 143 */       } else if (c == '{' && pattern.charAt(i + 1) == '}') {
/* 144 */         if (argCount < 0 || analysis.placeholderCount < argCount) {
/* 145 */           analysis.ensurePlaceholderCharIndicesCapacity(argCount);
/* 146 */           analysis.placeholderCharIndices[analysis.placeholderCount++] = i++;
/*     */         }
/*     */         else {
/*     */           
/* 150 */           analysis.placeholderCount++;
/* 151 */           i++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MessagePatternAnalysis
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = -5974082575968329887L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final int PLACEHOLDER_CHAR_INDEX_BUFFER_INITIAL_SIZE = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final int PLACEHOLDER_CHAR_INDEX_BUFFER_SIZE_INCREMENT = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int placeholderCount;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int[] placeholderCharIndices;
/*     */ 
/*     */ 
/*     */     
/*     */     boolean escapedCharFound;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void ensurePlaceholderCharIndicesCapacity(int argCount) {
/* 194 */       if (this.placeholderCharIndices == null) {
/* 195 */         int length = Math.max(argCount, 8);
/* 196 */         this.placeholderCharIndices = new int[length];
/*     */ 
/*     */       
/*     */       }
/* 200 */       else if (this.placeholderCount >= this.placeholderCharIndices.length) {
/*     */ 
/*     */         
/* 203 */         int newLength = (argCount > 0) ? argCount : Math.addExact(this.placeholderCharIndices.length, 8);
/* 204 */         int[] newPlaceholderCharIndices = new int[newLength];
/* 205 */         System.arraycopy(this.placeholderCharIndices, 0, newPlaceholderCharIndices, 0, this.placeholderCount);
/* 206 */         this.placeholderCharIndices = newPlaceholderCharIndices;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String format(String pattern, Object[] args, int argCount) {
/* 220 */     StringBuilder result = new StringBuilder();
/* 221 */     MessagePatternAnalysis analysis = analyzePattern(pattern, argCount);
/* 222 */     formatMessage(result, pattern, args, argCount, analysis);
/* 223 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void formatMessage(StringBuilder buffer, String pattern, Object[] args, int argCount, MessagePatternAnalysis analysis) {
/* 242 */     if (pattern == null || args == null || analysis.placeholderCount == 0) {
/* 243 */       buffer.append(pattern);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 248 */     if (analysis.placeholderCount != argCount) {
/*     */       
/* 250 */       int noThrowableArgCount = (argCount < 1) ? 0 : (argCount - ((args[argCount - 1] instanceof Throwable) ? 1 : 0));
/* 251 */       if (analysis.placeholderCount != noThrowableArgCount) {
/* 252 */         STATUS_LOGGER.warn("found {} argument placeholders, but provided {} for pattern `{}`", 
/*     */             
/* 254 */             Integer.valueOf(analysis.placeholderCount), 
/* 255 */             Integer.valueOf(argCount), pattern);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (analysis.escapedCharFound) {
/* 262 */       formatMessageContainingEscapes(buffer, pattern, args, argCount, analysis);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 267 */       formatMessageContainingNoEscapes(buffer, pattern, args, argCount, analysis);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void formatMessageContainingNoEscapes(StringBuilder buffer, String pattern, Object[] args, int argCount, MessagePatternAnalysis analysis) {
/* 279 */     int precedingTextStartIndex = 0;
/* 280 */     int argLimit = Math.min(analysis.placeholderCount, argCount);
/* 281 */     for (int argIndex = 0; argIndex < argLimit; argIndex++) {
/* 282 */       int placeholderCharIndex = analysis.placeholderCharIndices[argIndex];
/* 283 */       buffer.append(pattern, precedingTextStartIndex, placeholderCharIndex);
/* 284 */       recursiveDeepToString(args[argIndex], buffer);
/* 285 */       precedingTextStartIndex = placeholderCharIndex + 2;
/*     */     } 
/*     */ 
/*     */     
/* 289 */     buffer.append(pattern, precedingTextStartIndex, pattern.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void formatMessageContainingEscapes(StringBuilder buffer, String pattern, Object[] args, int argCount, MessagePatternAnalysis analysis) {
/* 300 */     int precedingTextStartIndex = 0;
/* 301 */     int argLimit = Math.min(analysis.placeholderCount, argCount);
/* 302 */     for (int argIndex = 0; argIndex < argLimit; argIndex++) {
/* 303 */       int placeholderCharIndex = analysis.placeholderCharIndices[argIndex];
/* 304 */       copyMessagePatternContainingEscapes(buffer, pattern, precedingTextStartIndex, placeholderCharIndex);
/* 305 */       recursiveDeepToString(args[argIndex], buffer);
/* 306 */       precedingTextStartIndex = placeholderCharIndex + 2;
/*     */     } 
/*     */ 
/*     */     
/* 310 */     copyMessagePatternContainingEscapes(buffer, pattern, precedingTextStartIndex, pattern.length());
/*     */   }
/*     */ 
/*     */   
/*     */   private static void copyMessagePatternContainingEscapes(StringBuilder buffer, String pattern, int startIndex, int endIndex) {
/* 315 */     boolean escaped = false;
/* 316 */     int i = startIndex;
/* 317 */     for (; i < endIndex; i++) {
/* 318 */       char c = pattern.charAt(i);
/* 319 */       if (c == '\\') {
/* 320 */         if (escaped) {
/*     */           
/* 322 */           escaped = false;
/*     */         } else {
/* 324 */           escaped = true;
/* 325 */           buffer.append(c);
/*     */         }
/*     */       
/* 328 */       } else if (escaped) {
/* 329 */         if (c == '{' && pattern.charAt(i + 1) == '}') {
/*     */           
/* 331 */           buffer.setLength(buffer.length() - 1);
/* 332 */           buffer.append("{}");
/* 333 */           i++;
/*     */         } else {
/* 335 */           buffer.append(c);
/*     */         } 
/* 337 */         escaped = false;
/*     */       } else {
/* 339 */         buffer.append(c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String deepToString(Object o) {
/* 364 */     if (o == null) {
/* 365 */       return null;
/*     */     }
/*     */     
/* 368 */     if (o instanceof String) {
/* 369 */       return (String)o;
/*     */     }
/* 371 */     if (o instanceof Integer) {
/* 372 */       return Integer.toString(((Integer)o).intValue());
/*     */     }
/* 374 */     if (o instanceof Long) {
/* 375 */       return Long.toString(((Long)o).longValue());
/*     */     }
/* 377 */     if (o instanceof Double) {
/* 378 */       return Double.toString(((Double)o).doubleValue());
/*     */     }
/* 380 */     if (o instanceof Boolean) {
/* 381 */       return Boolean.toString(((Boolean)o).booleanValue());
/*     */     }
/* 383 */     if (o instanceof Character) {
/* 384 */       return Character.toString(((Character)o).charValue());
/*     */     }
/* 386 */     if (o instanceof Short) {
/* 387 */       return Short.toString(((Short)o).shortValue());
/*     */     }
/* 389 */     if (o instanceof Float) {
/* 390 */       return Float.toString(((Float)o).floatValue());
/*     */     }
/* 392 */     if (o instanceof Byte) {
/* 393 */       return Byte.toString(((Byte)o).byteValue());
/*     */     }
/* 395 */     StringBuilder str = new StringBuilder();
/* 396 */     recursiveDeepToString(o, str);
/* 397 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void recursiveDeepToString(Object o, StringBuilder str) {
/* 419 */     recursiveDeepToString(o, str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void recursiveDeepToString(Object o, StringBuilder str, Set<Object> dejaVu) {
/* 444 */     if (appendSpecialTypes(o, str)) {
/*     */       return;
/*     */     }
/* 447 */     if (isMaybeRecursive(o)) {
/* 448 */       appendPotentiallyRecursiveValue(o, str, dejaVu);
/*     */     } else {
/* 450 */       tryObjectToString(o, str);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean appendSpecialTypes(Object o, StringBuilder str) {
/* 455 */     return (StringBuilders.appendSpecificTypes(str, o) || appendDate(o, str));
/*     */   }
/*     */   
/*     */   private static boolean appendDate(Object o, StringBuilder str) {
/* 459 */     if (!(o instanceof Date)) {
/* 460 */       return false;
/*     */     }
/* 462 */     DATE_FORMATTER.formatTo(((Date)o).toInstant(), str);
/* 463 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isMaybeRecursive(Object o) {
/* 470 */     return (o.getClass().isArray() || o instanceof Map || o instanceof Collection);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void appendPotentiallyRecursiveValue(Object o, StringBuilder str, Set<Object> dejaVu) {
/* 475 */     Class<?> oClass = o.getClass();
/* 476 */     if (oClass.isArray()) {
/* 477 */       appendArray(o, str, dejaVu, oClass);
/* 478 */     } else if (o instanceof Map) {
/* 479 */       appendMap(o, str, dejaVu);
/* 480 */     } else if (o instanceof Collection) {
/* 481 */       appendCollection(o, str, dejaVu);
/*     */     } else {
/* 483 */       throw new IllegalArgumentException("was expecting a container, found " + oClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void appendArray(Object o, StringBuilder str, Set<Object> dejaVu, Class<?> oClass) {
/* 489 */     if (oClass == byte[].class) {
/* 490 */       str.append(Arrays.toString((byte[])o));
/* 491 */     } else if (oClass == short[].class) {
/* 492 */       str.append(Arrays.toString((short[])o));
/* 493 */     } else if (oClass == int[].class) {
/* 494 */       str.append(Arrays.toString((int[])o));
/* 495 */     } else if (oClass == long[].class) {
/* 496 */       str.append(Arrays.toString((long[])o));
/* 497 */     } else if (oClass == float[].class) {
/* 498 */       str.append(Arrays.toString((float[])o));
/* 499 */     } else if (oClass == double[].class) {
/* 500 */       str.append(Arrays.toString((double[])o));
/* 501 */     } else if (oClass == boolean[].class) {
/* 502 */       str.append(Arrays.toString((boolean[])o));
/* 503 */     } else if (oClass == char[].class) {
/* 504 */       str.append(Arrays.toString((char[])o));
/*     */     } else {
/*     */       
/* 507 */       Set<Object> effectiveDejaVu = getOrCreateDejaVu(dejaVu);
/* 508 */       boolean seen = !effectiveDejaVu.add(o);
/* 509 */       if (seen) {
/* 510 */         String id = identityToString(o);
/* 511 */         str.append("[...").append(id).append("...]");
/*     */       } else {
/* 513 */         Object[] oArray = (Object[])o;
/* 514 */         str.append('[');
/* 515 */         boolean first = true;
/* 516 */         for (Object current : oArray) {
/* 517 */           if (first) {
/* 518 */             first = false;
/*     */           } else {
/* 520 */             str.append(", ");
/*     */           } 
/* 522 */           recursiveDeepToString(current, str, cloneDejaVu(effectiveDejaVu));
/*     */         } 
/* 524 */         str.append(']');
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void appendMap(Object o, StringBuilder str, Set<Object> dejaVu) {
/* 533 */     Set<Object> effectiveDejaVu = getOrCreateDejaVu(dejaVu);
/* 534 */     boolean seen = !effectiveDejaVu.add(o);
/* 535 */     if (seen) {
/* 536 */       String id = identityToString(o);
/* 537 */       str.append("[...").append(id).append("...]");
/*     */     } else {
/* 539 */       Map<?, ?> oMap = (Map<?, ?>)o;
/* 540 */       str.append('{');
/* 541 */       boolean isFirst = true;
/* 542 */       for (Map.Entry<?, ?> entry : oMap.entrySet()) {
/* 543 */         if (isFirst) {
/* 544 */           isFirst = false;
/*     */         } else {
/* 546 */           str.append(", ");
/*     */         } 
/* 548 */         Object key = entry.getKey();
/* 549 */         Object value = entry.getValue();
/* 550 */         recursiveDeepToString(key, str, cloneDejaVu(effectiveDejaVu));
/* 551 */         str.append('=');
/* 552 */         recursiveDeepToString(value, str, cloneDejaVu(effectiveDejaVu));
/*     */       } 
/* 554 */       str.append('}');
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void appendCollection(Object o, StringBuilder str, Set<Object> dejaVu) {
/* 562 */     Set<Object> effectiveDejaVu = getOrCreateDejaVu(dejaVu);
/* 563 */     boolean seen = !effectiveDejaVu.add(o);
/* 564 */     if (seen) {
/* 565 */       String id = identityToString(o);
/* 566 */       str.append("[...").append(id).append("...]");
/*     */     } else {
/* 568 */       Collection<?> oCol = (Collection)o;
/* 569 */       str.append('[');
/* 570 */       boolean isFirst = true;
/* 571 */       for (Object anOCol : oCol) {
/* 572 */         if (isFirst) {
/* 573 */           isFirst = false;
/*     */         } else {
/* 575 */           str.append(", ");
/*     */         } 
/* 577 */         recursiveDeepToString(anOCol, str, cloneDejaVu(effectiveDejaVu));
/*     */       } 
/* 579 */       str.append(']');
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Set<Object> getOrCreateDejaVu(Set<Object> dejaVu) {
/* 584 */     return (dejaVu == null) ? createDejaVu() : dejaVu;
/*     */   }
/*     */   
/*     */   private static Set<Object> createDejaVu() {
/* 588 */     return Collections.newSetFromMap(new IdentityHashMap<>());
/*     */   }
/*     */   
/*     */   private static Set<Object> cloneDejaVu(Set<Object> dejaVu) {
/* 592 */     Set<Object> clonedDejaVu = createDejaVu();
/* 593 */     clonedDejaVu.addAll(dejaVu);
/* 594 */     return clonedDejaVu;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void tryObjectToString(Object o, StringBuilder str) {
/*     */     try {
/* 600 */       str.append(o.toString());
/* 601 */     } catch (Throwable t) {
/* 602 */       handleErrorInObjectToString(o, str, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void handleErrorInObjectToString(Object o, StringBuilder str, Throwable t) {
/* 607 */     str.append("[!!!");
/* 608 */     str.append(identityToString(o));
/* 609 */     str.append("=>");
/* 610 */     String msg = t.getMessage();
/* 611 */     String className = t.getClass().getName();
/* 612 */     str.append(className);
/* 613 */     if (!className.equals(msg)) {
/* 614 */       str.append(":");
/* 615 */       str.append(msg);
/*     */     } 
/* 617 */     str.append("!!!]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String identityToString(Object obj) {
/* 641 */     if (obj == null) {
/* 642 */       return null;
/*     */     }
/* 644 */     return obj.getClass().getName() + '@' + Integer.toHexString(System.identityHashCode(obj));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ParameterFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */