/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.util.IndexedStringMap;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum MapMessageJsonFormatter
/*     */ {
/*     */   public static final int MAX_DEPTH;
/*     */   private static final char DQUOTE = '"';
/*     */   private static final char RBRACE = ']';
/*     */   private static final char LBRACE = '[';
/*     */   private static final char COMMA = ',';
/*     */   private static final char RCURLY = '}';
/*     */   private static final char LCURLY = '{';
/*     */   private static final char COLON = ':';
/*     */   
/*     */   static {
/*  50 */     MAX_DEPTH = readMaxDepth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int readMaxDepth() {
/*  68 */     int maxDepth = PropertiesUtil.getProperties().getIntegerProperty("log4j2.mapMessage.jsonFormatter.maxDepth", 8);
/*  69 */     if (maxDepth < 0) {
/*  70 */       throw new IllegalArgumentException("was expecting a positive maxDepth, found: " + maxDepth);
/*     */     }
/*  72 */     return maxDepth;
/*     */   }
/*     */   
/*     */   static void format(StringBuilder sb, Object object) {
/*  76 */     format(sb, object, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void format(StringBuilder sb, Object object, int depth) {
/*  81 */     if (depth >= MAX_DEPTH) {
/*  82 */       throw new IllegalArgumentException("maxDepth has been exceeded");
/*     */     }
/*     */ 
/*     */     
/*  86 */     if (object == null) {
/*  87 */       sb.append("null");
/*     */ 
/*     */     
/*     */     }
/*  91 */     else if (object instanceof IndexedStringMap) {
/*  92 */       IndexedStringMap map = (IndexedStringMap)object;
/*  93 */       formatIndexedStringMap(sb, map, depth);
/*  94 */     } else if (object instanceof Map) {
/*     */       
/*  96 */       Map<Object, Object> map = (Map<Object, Object>)object;
/*  97 */       formatMap(sb, map, depth);
/*     */ 
/*     */     
/*     */     }
/* 101 */     else if (object instanceof List) {
/*     */       
/* 103 */       List<Object> list = (List<Object>)object;
/* 104 */       formatList(sb, list, depth);
/* 105 */     } else if (object instanceof Collection) {
/*     */       
/* 107 */       Collection<Object> collection = (Collection<Object>)object;
/* 108 */       formatCollection(sb, collection, depth);
/*     */ 
/*     */     
/*     */     }
/* 112 */     else if (object instanceof Number) {
/* 113 */       Number number = (Number)object;
/* 114 */       formatNumber(sb, number);
/* 115 */     } else if (object instanceof Boolean) {
/* 116 */       boolean booleanValue = ((Boolean)object).booleanValue();
/* 117 */       formatBoolean(sb, booleanValue);
/*     */ 
/*     */     
/*     */     }
/* 121 */     else if (object instanceof StringBuilderFormattable) {
/* 122 */       StringBuilderFormattable formattable = (StringBuilderFormattable)object;
/* 123 */       formatFormattable(sb, formattable);
/*     */ 
/*     */     
/*     */     }
/* 127 */     else if (object instanceof char[]) {
/* 128 */       char[] charValues = (char[])object;
/* 129 */       formatCharArray(sb, charValues);
/* 130 */     } else if (object instanceof boolean[]) {
/* 131 */       boolean[] booleanValues = (boolean[])object;
/* 132 */       formatBooleanArray(sb, booleanValues);
/* 133 */     } else if (object instanceof byte[]) {
/* 134 */       byte[] byteValues = (byte[])object;
/* 135 */       formatByteArray(sb, byteValues);
/* 136 */     } else if (object instanceof short[]) {
/* 137 */       short[] shortValues = (short[])object;
/* 138 */       formatShortArray(sb, shortValues);
/* 139 */     } else if (object instanceof int[]) {
/* 140 */       int[] intValues = (int[])object;
/* 141 */       formatIntArray(sb, intValues);
/* 142 */     } else if (object instanceof long[]) {
/* 143 */       long[] longValues = (long[])object;
/* 144 */       formatLongArray(sb, longValues);
/* 145 */     } else if (object instanceof float[]) {
/* 146 */       float[] floatValues = (float[])object;
/* 147 */       formatFloatArray(sb, floatValues);
/* 148 */     } else if (object instanceof double[]) {
/* 149 */       double[] doubleValues = (double[])object;
/* 150 */       formatDoubleArray(sb, doubleValues);
/* 151 */     } else if (object instanceof Object[]) {
/* 152 */       Object[] objectValues = (Object[])object;
/* 153 */       formatObjectArray(sb, objectValues, depth);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 158 */       formatString(sb, object);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void formatIndexedStringMap(StringBuilder sb, IndexedStringMap map, int depth) {
/* 163 */     sb.append('{');
/* 164 */     int nextDepth = depth + 1;
/* 165 */     for (int entryIndex = 0; entryIndex < map.size(); entryIndex++) {
/* 166 */       String key = map.getKeyAt(entryIndex);
/* 167 */       Object value = map.getValueAt(entryIndex);
/* 168 */       if (entryIndex > 0) {
/* 169 */         sb.append(',');
/*     */       }
/* 171 */       sb.append('"');
/* 172 */       int keyStartIndex = sb.length();
/* 173 */       sb.append(key);
/* 174 */       StringBuilders.escapeJson(sb, keyStartIndex);
/* 175 */       sb.append('"').append(':');
/* 176 */       format(sb, value, nextDepth);
/*     */     } 
/* 178 */     sb.append('}');
/*     */   }
/*     */   
/*     */   private static void formatMap(StringBuilder sb, Map<Object, Object> map, int depth) {
/* 182 */     sb.append('{');
/* 183 */     int nextDepth = depth + 1;
/* 184 */     boolean[] firstEntry = { true };
/* 185 */     map.forEach((key, value) -> {
/*     */           if (key == null) {
/*     */             throw new IllegalArgumentException("null keys are not allowed");
/*     */           }
/*     */           if (firstEntry[0]) {
/*     */             firstEntry[0] = false;
/*     */           } else {
/*     */             sb.append(',');
/*     */           } 
/*     */           sb.append('"');
/*     */           String keyString = String.valueOf(key);
/*     */           int keyStartIndex = sb.length();
/*     */           sb.append(keyString);
/*     */           StringBuilders.escapeJson(sb, keyStartIndex);
/*     */           sb.append('"').append(':');
/*     */           format(sb, value, nextDepth);
/*     */         });
/* 202 */     sb.append('}');
/*     */   }
/*     */   
/*     */   private static void formatList(StringBuilder sb, List<Object> items, int depth) {
/* 206 */     sb.append('[');
/* 207 */     int nextDepth = depth + 1;
/* 208 */     for (int itemIndex = 0; itemIndex < items.size(); itemIndex++) {
/* 209 */       if (itemIndex > 0) {
/* 210 */         sb.append(',');
/*     */       }
/* 212 */       Object item = items.get(itemIndex);
/* 213 */       format(sb, item, nextDepth);
/*     */     } 
/* 215 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatCollection(StringBuilder sb, Collection<Object> items, int depth) {
/* 219 */     sb.append('[');
/* 220 */     int nextDepth = depth + 1;
/* 221 */     boolean[] firstItem = { true };
/* 222 */     items.forEach(item -> {
/*     */           if (firstItem[0]) {
/*     */             firstItem[0] = false;
/*     */           } else {
/*     */             sb.append(',');
/*     */           } 
/*     */           format(sb, item, nextDepth);
/*     */         });
/* 230 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatNumber(StringBuilder sb, Number number) {
/* 234 */     if (number instanceof BigDecimal) {
/* 235 */       BigDecimal decimalNumber = (BigDecimal)number;
/* 236 */       sb.append(decimalNumber.toString());
/* 237 */     } else if (number instanceof Double) {
/* 238 */       double doubleNumber = ((Double)number).doubleValue();
/* 239 */       sb.append(doubleNumber);
/* 240 */     } else if (number instanceof Float) {
/* 241 */       float floatNumber = ((Float)number).floatValue();
/* 242 */       sb.append(floatNumber);
/* 243 */     } else if (number instanceof Byte || number instanceof Short || number instanceof Integer || number instanceof Long) {
/*     */ 
/*     */ 
/*     */       
/* 247 */       long longNumber = number.longValue();
/* 248 */       sb.append(longNumber);
/*     */     } else {
/* 250 */       long longNumber = number.longValue();
/* 251 */       double doubleValue = number.doubleValue();
/* 252 */       if (Double.compare(longNumber, doubleValue) == 0) {
/* 253 */         sb.append(longNumber);
/*     */       } else {
/* 255 */         sb.append(doubleValue);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void formatBoolean(StringBuilder sb, boolean booleanValue) {
/* 261 */     sb.append(booleanValue);
/*     */   }
/*     */   
/*     */   private static void formatFormattable(StringBuilder sb, StringBuilderFormattable formattable) {
/* 265 */     sb.append('"');
/* 266 */     int startIndex = sb.length();
/* 267 */     formattable.formatTo(sb);
/* 268 */     StringBuilders.escapeJson(sb, startIndex);
/* 269 */     sb.append('"');
/*     */   }
/*     */   
/*     */   private static void formatCharArray(StringBuilder sb, char[] items) {
/* 273 */     sb.append('[');
/* 274 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 275 */       if (itemIndex > 0) {
/* 276 */         sb.append(',');
/*     */       }
/* 278 */       char item = items[itemIndex];
/* 279 */       sb.append('"');
/* 280 */       int startIndex = sb.length();
/* 281 */       sb.append(item);
/* 282 */       StringBuilders.escapeJson(sb, startIndex);
/* 283 */       sb.append('"');
/*     */     } 
/* 285 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatBooleanArray(StringBuilder sb, boolean[] items) {
/* 289 */     sb.append('[');
/* 290 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 291 */       if (itemIndex > 0) {
/* 292 */         sb.append(',');
/*     */       }
/* 294 */       boolean item = items[itemIndex];
/* 295 */       sb.append(item);
/*     */     } 
/* 297 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatByteArray(StringBuilder sb, byte[] items) {
/* 301 */     sb.append('[');
/* 302 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 303 */       if (itemIndex > 0) {
/* 304 */         sb.append(',');
/*     */       }
/* 306 */       byte item = items[itemIndex];
/* 307 */       sb.append(item);
/*     */     } 
/* 309 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatShortArray(StringBuilder sb, short[] items) {
/* 313 */     sb.append('[');
/* 314 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 315 */       if (itemIndex > 0) {
/* 316 */         sb.append(',');
/*     */       }
/* 318 */       short item = items[itemIndex];
/* 319 */       sb.append(item);
/*     */     } 
/* 321 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatIntArray(StringBuilder sb, int[] items) {
/* 325 */     sb.append('[');
/* 326 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 327 */       if (itemIndex > 0) {
/* 328 */         sb.append(',');
/*     */       }
/* 330 */       int item = items[itemIndex];
/* 331 */       sb.append(item);
/*     */     } 
/* 333 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatLongArray(StringBuilder sb, long[] items) {
/* 337 */     sb.append('[');
/* 338 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 339 */       if (itemIndex > 0) {
/* 340 */         sb.append(',');
/*     */       }
/* 342 */       long item = items[itemIndex];
/* 343 */       sb.append(item);
/*     */     } 
/* 345 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatFloatArray(StringBuilder sb, float[] items) {
/* 349 */     sb.append('[');
/* 350 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 351 */       if (itemIndex > 0) {
/* 352 */         sb.append(',');
/*     */       }
/* 354 */       float item = items[itemIndex];
/* 355 */       sb.append(item);
/*     */     } 
/* 357 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatDoubleArray(StringBuilder sb, double[] items) {
/* 361 */     sb.append('[');
/* 362 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 363 */       if (itemIndex > 0) {
/* 364 */         sb.append(',');
/*     */       }
/* 366 */       double item = items[itemIndex];
/* 367 */       sb.append(item);
/*     */     } 
/* 369 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatObjectArray(StringBuilder sb, Object[] items, int depth) {
/* 373 */     sb.append('[');
/* 374 */     int nextDepth = depth + 1;
/* 375 */     for (int itemIndex = 0; itemIndex < items.length; itemIndex++) {
/* 376 */       if (itemIndex > 0) {
/* 377 */         sb.append(',');
/*     */       }
/* 379 */       Object item = items[itemIndex];
/* 380 */       format(sb, item, nextDepth);
/*     */     } 
/* 382 */     sb.append(']');
/*     */   }
/*     */   
/*     */   private static void formatString(StringBuilder sb, Object value) {
/* 386 */     sb.append('"');
/* 387 */     int startIndex = sb.length();
/* 388 */     String valueString = String.valueOf(value);
/* 389 */     sb.append(valueString);
/* 390 */     StringBuilders.escapeJson(sb, startIndex);
/* 391 */     sb.append('"');
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\MapMessageJsonFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */