/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import aQute.bnd.annotation.baseline.BaselineIgnore;
/*     */ import com.google.errorprone.annotations.InlineMe;
/*     */ import java.io.Serializable;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructuredDataId
/*     */   implements Serializable, StringBuilderFormattable
/*     */ {
/*  33 */   public static final StructuredDataId TIME_QUALITY = new StructuredDataId("timeQuality", null, new String[] { "tzKnown", "isSynced", "syncAccuracy" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   public static final StructuredDataId ORIGIN = new StructuredDataId("origin", null, new String[] { "ip", "enterpriseId", "software", "swVersion" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final StructuredDataId META = new StructuredDataId("meta", null, new String[] { "sequenceId", "sysUpTime", "language" });
/*     */ 
/*     */   
/*     */   public static final String RESERVED = "-1";
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = -8252896346202183738L;
/*     */ 
/*     */   
/*     */   private static final int MAX_LENGTH = 32;
/*     */   
/*     */   private static final String AT_SIGN = "@";
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final String enterpriseNumber;
/*     */   
/*     */   private final String[] required;
/*     */   
/*     */   private final String[] optional;
/*     */ 
/*     */   
/*     */   public StructuredDataId(String name) {
/*  68 */     this(name, (String[])null, (String[])null, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId(String name, int maxLength) {
/*  78 */     this(name, (String[])null, (String[])null, maxLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId(String name, String[] required, String[] optional) {
/*  88 */     this(name, required, optional, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId(String name, String[] required, String[] optional, int maxLength) {
/* 101 */     int index = -1;
/* 102 */     if (name != null) {
/* 103 */       if (maxLength <= 0) {
/* 104 */         maxLength = 32;
/*     */       }
/* 106 */       if (name.length() > maxLength) {
/* 107 */         throw new IllegalArgumentException(
/* 108 */             String.format("Length of id %s exceeds maximum of %d characters", new Object[] { name, Integer.valueOf(maxLength) }));
/*     */       }
/* 110 */       index = name.indexOf("@");
/*     */     } 
/*     */     
/* 113 */     if (index > 0) {
/* 114 */       this.name = name.substring(0, index);
/* 115 */       this.enterpriseNumber = name.substring(index + 1).trim();
/*     */     } else {
/* 117 */       this.name = name;
/* 118 */       this.enterpriseNumber = "-1";
/*     */     } 
/* 120 */     this.required = required;
/* 121 */     this.optional = optional;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId(String name, String enterpriseNumber, String[] required, String[] optional) {
/* 134 */     this(name, enterpriseNumber, required, optional, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @InlineMe(replacement = "this(name, String.valueOf(enterpriseNumber), required, optional)")
/*     */   public StructuredDataId(String name, int enterpriseNumber, String[] required, String[] optional) {
/* 150 */     this(name, String.valueOf(enterpriseNumber), required, optional);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId(String name, String enterpriseNumber, String[] required, String[] optional, int maxLength) {
/* 169 */     if (name == null) {
/* 170 */       throw new IllegalArgumentException("No structured id name was supplied");
/*     */     }
/* 172 */     if (name.contains("@")) {
/* 173 */       throw new IllegalArgumentException("Structured id name cannot contain an " + Strings.quote("@"));
/*     */     }
/* 175 */     if ("-1".equals(enterpriseNumber)) {
/* 176 */       throw new IllegalArgumentException("No enterprise number was supplied");
/*     */     }
/* 178 */     this.name = name;
/* 179 */     this.enterpriseNumber = enterpriseNumber;
/* 180 */     String id = name + "@" + enterpriseNumber;
/* 181 */     if (maxLength > 0 && id.length() > maxLength) {
/* 182 */       throw new IllegalArgumentException("Length of id exceeds maximum of " + maxLength + " characters: " + id);
/*     */     }
/* 184 */     this.required = required;
/* 185 */     this.optional = optional;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @InlineMe(replacement = "this(name, String.valueOf(enterpriseNumber), required, optional, maxLength)")
/*     */   public StructuredDataId(String name, int enterpriseNumber, String[] required, String[] optional, int maxLength) {
/* 207 */     this(name, String.valueOf(enterpriseNumber), required, optional, maxLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId makeId(StructuredDataId id) {
/* 217 */     if (id == null) {
/* 218 */       return this;
/*     */     }
/* 220 */     return makeId(id.getName(), id.getEnterpriseNumber());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuredDataId makeId(String defaultId, String anEnterpriseNumber) {
/*     */     String id;
/*     */     String[] req;
/*     */     String[] opt;
/* 234 */     if ("-1".equals(anEnterpriseNumber)) {
/* 235 */       return this;
/*     */     }
/* 237 */     if (this.name != null) {
/* 238 */       id = this.name;
/* 239 */       req = this.required;
/* 240 */       opt = this.optional;
/*     */     } else {
/* 242 */       id = defaultId;
/* 243 */       req = null;
/* 244 */       opt = null;
/*     */     } 
/*     */     
/* 247 */     return new StructuredDataId(id, anEnterpriseNumber, req, opt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @BaselineIgnore("2.22.0")
/*     */   @InlineMe(replacement = "this.makeId(defaultId, String.valueOf(anEnterpriseNumber))")
/*     */   public final StructuredDataId makeId(String defaultId, int anEnterpriseNumber) {
/* 263 */     return makeId(defaultId, String.valueOf(anEnterpriseNumber));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRequired() {
/* 272 */     return this.required;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getOptional() {
/* 281 */     return this.optional;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 290 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEnterpriseNumber() {
/* 299 */     return this.enterpriseNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReserved() {
/* 308 */     return "-1".equals(this.enterpriseNumber);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 313 */     StringBuilder sb = new StringBuilder(this.name.length() + 10);
/* 314 */     formatTo(sb);
/* 315 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder buffer) {
/* 320 */     if (isReserved()) {
/* 321 */       buffer.append(this.name);
/*     */     } else {
/* 323 */       buffer.append(this.name).append("@").append(this.enterpriseNumber);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\StructuredDataId.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */