/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import aQute.bnd.annotation.spi.ServiceConsumer;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.ServiceLoader;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.Lazy;
/*     */ import org.apache.logging.log4j.util.ServiceLoaderUtil;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AsynchronouslyFormattable
/*     */ @ServiceConsumer(value = ThreadDumpMessage.ThreadInfoFactory.class, resolution = "optional", cardinality = "single")
/*     */ public class ThreadDumpMessage
/*     */   implements Message, StringBuilderFormattable
/*     */ {
/*     */   private static final long serialVersionUID = -1103400781608841088L;
/*  44 */   private static final Lazy<ThreadInfoFactory> FACTORY = Lazy.lazy(ThreadDumpMessage::initFactory);
/*     */ 
/*     */   
/*     */   private volatile Map<ThreadInformation, StackTraceElement[]> threads;
/*     */   
/*     */   private final String title;
/*     */   
/*     */   private String formattedMessage;
/*     */ 
/*     */   
/*     */   public ThreadDumpMessage(String title) {
/*  55 */     this.title = (title == null) ? "" : title;
/*  56 */     this.threads = ((ThreadInfoFactory)FACTORY.get()).createThreadInfo();
/*     */   }
/*     */   
/*     */   private ThreadDumpMessage(String formattedMsg, String title) {
/*  60 */     this.formattedMessage = formattedMsg;
/*  61 */     this.title = (title == null) ? "" : title;
/*     */   }
/*     */   
/*     */   private static ThreadInfoFactory initFactory() {
/*  65 */     return ServiceLoaderUtil.safeStream(ThreadInfoFactory.class, 
/*     */         
/*  67 */         ServiceLoader.load(ThreadInfoFactory.class, ThreadDumpMessage.class.getClassLoader()), 
/*  68 */         (Logger)StatusLogger.getLogger())
/*  69 */       .findFirst()
/*  70 */       .orElseGet(() -> new BasicThreadInfoFactory());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     return getFormattedMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/*  84 */     if (this.formattedMessage != null) {
/*  85 */       return this.formattedMessage;
/*     */     }
/*  87 */     StringBuilder sb = new StringBuilder(255);
/*  88 */     formatTo(sb);
/*  89 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder sb) {
/*  94 */     sb.append(this.title);
/*  95 */     if (this.title.length() > 0) {
/*  96 */       sb.append('\n');
/*     */     }
/*  98 */     for (Map.Entry<ThreadInformation, StackTraceElement[]> entry : this.threads.entrySet()) {
/*  99 */       ThreadInformation info = entry.getKey();
/* 100 */       info.printThreadInfo(sb);
/* 101 */       info.printStack(sb, entry.getValue());
/* 102 */       sb.append('\n');
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 112 */     return (this.title == null) ? "" : this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object writeReplace() {
/* 130 */     return new ThreadDumpMessageProxy(this);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 134 */     throw new InvalidObjectException("Proxy required");
/*     */   }
/*     */   
/*     */   public static interface ThreadInfoFactory {
/*     */     Map<ThreadInformation, StackTraceElement[]> createThreadInfo();
/*     */   }
/*     */   
/*     */   private static class ThreadDumpMessageProxy implements Serializable {
/*     */     private static final long serialVersionUID = -3476620450287648269L;
/*     */     private final String formattedMsg;
/*     */     private final String title;
/*     */     
/*     */     ThreadDumpMessageProxy(ThreadDumpMessage msg) {
/* 147 */       this.formattedMsg = msg.getFormattedMessage();
/* 148 */       this.title = msg.title;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 156 */       return new ThreadDumpMessage(this.formattedMsg, this.title);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BasicThreadInfoFactory
/*     */     implements ThreadInfoFactory
/*     */   {
/*     */     private BasicThreadInfoFactory() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<ThreadInformation, StackTraceElement[]> createThreadInfo() {
/* 176 */       Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
/* 177 */       Map<ThreadInformation, StackTraceElement[]> threads = (Map)new HashMap<>(map.size());
/* 178 */       for (Map.Entry<Thread, StackTraceElement[]> entry : map.entrySet()) {
/* 179 */         threads.put(new BasicThreadInformation(entry.getKey()), entry.getValue());
/*     */       }
/* 181 */       return threads;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 192 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ThreadDumpMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */