/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.text.Format;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormattedMessage
/*     */   implements Message
/*     */ {
/*     */   private static final long serialVersionUID = -665975803997290697L;
/*     */   private static final int HASHVAL = 31;
/*     */   private String messagePattern;
/*     */   private transient Object[] argArray;
/*     */   private String[] stringArgs;
/*     */   private transient String formattedMessage;
/*     */   private final Throwable throwable;
/*     */   private Message message;
/*     */   private final Locale locale;
/*     */   
/*     */   public FormattedMessage(Locale locale, String messagePattern, Object arg) {
/*  52 */     this(locale, messagePattern, new Object[] { arg }, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(Locale locale, String messagePattern, Object arg1, Object arg2) {
/*  64 */     this(locale, messagePattern, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(Locale locale, String messagePattern, Object... arguments) {
/*  75 */     this(locale, messagePattern, arguments, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(Locale locale, String messagePattern, Object[] arguments, Throwable throwable) {
/*  88 */     this.locale = locale;
/*  89 */     this.messagePattern = messagePattern;
/*  90 */     this.argArray = arguments;
/*  91 */     this.throwable = throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(String messagePattern, Object arg) {
/* 100 */     this(messagePattern, new Object[] { arg }, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(String messagePattern, Object arg1, Object arg2) {
/* 110 */     this(messagePattern, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(String messagePattern, Object... arguments) {
/* 119 */     this(messagePattern, arguments, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattedMessage(String messagePattern, Object[] arguments, Throwable throwable) {
/* 129 */     this.locale = Locale.getDefault(Locale.Category.FORMAT);
/* 130 */     this.messagePattern = messagePattern;
/* 131 */     this.argArray = arguments;
/* 132 */     this.throwable = throwable;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 137 */     if (this == o) {
/* 138 */       return true;
/*     */     }
/* 140 */     if (!(o instanceof FormattedMessage)) {
/* 141 */       return false;
/*     */     }
/*     */     
/* 144 */     FormattedMessage that = (FormattedMessage)o;
/*     */     
/* 146 */     if ((this.messagePattern != null) ? !this.messagePattern.equals(that.messagePattern) : (that.messagePattern != null)) {
/* 147 */       return false;
/*     */     }
/* 149 */     return Arrays.equals((Object[])this.stringArgs, (Object[])that.stringArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 158 */     return this.messagePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 167 */     if (this.formattedMessage == null) {
/* 168 */       if (this.message == null) {
/* 169 */         this.message = getMessage(this.messagePattern, this.argArray, this.throwable);
/*     */       }
/* 171 */       this.formattedMessage = this.message.getFormattedMessage();
/*     */     } 
/* 173 */     return this.formattedMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Message getMessage(String msgPattern, Object[] args, Throwable aThrowable) {
/*     */     try {
/* 198 */       MessageFormat format = new MessageFormat(msgPattern);
/* 199 */       Format[] formats = format.getFormats();
/* 200 */       if (formats.length > 0) {
/* 201 */         return new MessageFormatMessage(this.locale, msgPattern, args);
/*     */       }
/* 203 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if ((ParameterFormatter.analyzePattern(msgPattern, 1)).placeholderCount > 0 || msgPattern.indexOf('%') == -1) {
/* 209 */       return new ParameterizedMessage(msgPattern, args, aThrowable);
/*     */     }
/*     */     
/* 212 */     return new StringFormattedMessage(this.locale, msgPattern, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 221 */     if (this.argArray != null) {
/* 222 */       return this.argArray;
/*     */     }
/* 224 */     return (Object[])this.stringArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 229 */     if (this.throwable != null) {
/* 230 */       return this.throwable;
/*     */     }
/* 232 */     if (this.message == null) {
/* 233 */       this.message = getMessage(this.messagePattern, this.argArray, null);
/*     */     }
/* 235 */     return this.message.getThrowable();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 240 */     int result = (this.messagePattern != null) ? this.messagePattern.hashCode() : 0;
/* 241 */     result = 31 * result + ((this.stringArgs != null) ? Arrays.hashCode((Object[])this.stringArgs) : 0);
/* 242 */     return result;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 246 */     in.defaultReadObject();
/* 247 */     this.formattedMessage = in.readUTF();
/* 248 */     this.messagePattern = in.readUTF();
/* 249 */     int length = in.readInt();
/* 250 */     this.stringArgs = new String[length];
/* 251 */     for (int i = 0; i < length; i++) {
/* 252 */       this.stringArgs[i] = in.readUTF();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 258 */     return getFormattedMessage();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 262 */     out.defaultWriteObject();
/* 263 */     getFormattedMessage();
/* 264 */     out.writeUTF(this.formattedMessage);
/* 265 */     out.writeUTF(this.messagePattern);
/* 266 */     out.writeInt(this.argArray.length);
/* 267 */     this.stringArgs = new String[this.argArray.length];
/* 268 */     int i = 0;
/* 269 */     for (Object obj : this.argArray) {
/* 270 */       String string = String.valueOf(obj);
/* 271 */       this.stringArgs[i] = string;
/* 272 */       out.writeUTF(string);
/* 273 */       i++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\FormattedMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */