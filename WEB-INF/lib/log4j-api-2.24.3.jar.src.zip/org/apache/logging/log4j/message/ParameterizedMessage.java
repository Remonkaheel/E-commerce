/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import com.google.errorprone.annotations.InlineMe;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import org.apache.logging.log4j.util.Constants;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ import org.apache.logging.log4j.util.internal.SerializationUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizedMessage
/*     */   implements Message, StringBuilderFormattable
/*     */ {
/*     */   public static final String RECURSION_PREFIX = "[...";
/*     */   public static final String RECURSION_SUFFIX = "...]";
/*     */   public static final String ERROR_PREFIX = "[!!!";
/*     */   public static final String ERROR_SEPARATOR = "=>";
/*     */   public static final String ERROR_MSG_SEPARATOR = ":";
/*     */   public static final String ERROR_SUFFIX = "!!!]";
/*     */   private static final long serialVersionUID = -665975803997290697L;
/*     */   private final String pattern;
/*     */   private transient Object[] args;
/*     */   private final transient Throwable throwable;
/*     */   private final ParameterFormatter.MessagePatternAnalysis patternAnalysis;
/*  83 */   private static final ThreadLocal<FormatBufferHolder> FORMAT_BUFFER_HOLDER_REF = Constants.ENABLE_THREADLOCALS ? ThreadLocal.<FormatBufferHolder>withInitial(() -> new FormatBufferHolder()) : null;
/*     */   private String formattedMessage;
/*     */   
/*     */   private static final class FormatBufferHolder {
/*  87 */     private final StringBuilder buffer = new StringBuilder(Constants.MAX_REUSABLE_MESSAGE_SIZE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private FormatBufferHolder() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean used = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @InlineMe(replacement = "this(pattern, Arrays.stream(args).toArray(Object[]::new), throwable)", imports = {"java.util.Arrays"})
/*     */   public ParameterizedMessage(String pattern, String[] args, Throwable throwable) {
/* 122 */     this(pattern, Arrays.<String>stream(args).toArray(x$0 -> new Object[x$0]), throwable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedMessage(String pattern, Object[] args, Throwable throwable) {
/* 140 */     this.args = args;
/* 141 */     this.pattern = pattern;
/* 142 */     this.patternAnalysis = ParameterFormatter.analyzePattern(pattern, (args != null) ? args.length : 0);
/* 143 */     this.throwable = determineThrowable(throwable, this.args, this.patternAnalysis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Throwable determineThrowable(Throwable throwable, Object[] args, ParameterFormatter.MessagePatternAnalysis analysis) {
/* 150 */     if (throwable != null) {
/* 151 */       return throwable;
/*     */     }
/*     */ 
/*     */     
/* 155 */     if (args != null && args.length > analysis.placeholderCount) {
/* 156 */       Object lastArg = args[args.length - 1];
/* 157 */       if (lastArg instanceof Throwable) {
/* 158 */         return (Throwable)lastArg;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedMessage(String pattern, Object... args) {
/* 176 */     this(pattern, args, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedMessage(String pattern, Object arg) {
/* 189 */     this(pattern, new Object[] { arg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedMessage(String pattern, Object arg0, Object arg1) {
/* 203 */     this(pattern, new Object[] { arg0, arg1 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 211 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 219 */     return this.args;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 233 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 246 */     if (this.formattedMessage == null) {
/*     */       FormatBufferHolder bufferHolder;
/*     */       
/* 249 */       if (FORMAT_BUFFER_HOLDER_REF == null || (bufferHolder = FORMAT_BUFFER_HOLDER_REF.get()).used) {
/* 250 */         StringBuilder buffer = new StringBuilder(Constants.MAX_REUSABLE_MESSAGE_SIZE);
/* 251 */         formatTo(buffer);
/* 252 */         this.formattedMessage = buffer.toString();
/*     */       }
/*     */       else {
/*     */         
/* 256 */         bufferHolder.used = true;
/* 257 */         StringBuilder buffer = bufferHolder.buffer;
/*     */         try {
/* 259 */           formatTo(buffer);
/* 260 */           this.formattedMessage = buffer.toString();
/*     */         } finally {
/* 262 */           StringBuilders.trimToMaxSize(buffer, Constants.MAX_REUSABLE_MESSAGE_SIZE);
/* 263 */           buffer.setLength(0);
/* 264 */           bufferHolder.used = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 268 */     return this.formattedMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder buffer) {
/* 273 */     if (this.formattedMessage != null) {
/* 274 */       buffer.append(this.formattedMessage);
/*     */     } else {
/* 276 */       int argCount = (this.args != null) ? this.args.length : 0;
/* 277 */       ParameterFormatter.formatMessage(buffer, this.pattern, this.args, argCount, this.patternAnalysis);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(String pattern, Object[] args) {
/* 287 */     int argCount = (args != null) ? args.length : 0;
/* 288 */     return ParameterFormatter.format(pattern, args, argCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 293 */     if (this == object) {
/* 294 */       return true;
/*     */     }
/* 296 */     if (!(object instanceof ParameterizedMessage)) {
/* 297 */       return false;
/*     */     }
/* 299 */     ParameterizedMessage that = (ParameterizedMessage)object;
/* 300 */     return (Objects.equals(this.pattern, that.pattern) && Arrays.equals(this.args, that.args));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 305 */     int result = (this.pattern != null) ? this.pattern.hashCode() : 0;
/* 306 */     result = 31 * result + ((this.args != null) ? Arrays.hashCode(this.args) : 0);
/* 307 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countArgumentPlaceholders(String pattern) {
/* 315 */     if (pattern == null) {
/* 316 */       return 0;
/*     */     }
/* 318 */     return (ParameterFormatter.analyzePattern(pattern, -1)).placeholderCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String deepToString(Object o) {
/* 340 */     return ParameterFormatter.deepToString(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String identityToString(Object obj) {
/* 364 */     return ParameterFormatter.identityToString(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 371 */     return "ParameterizedMessage[messagePattern=" + this.pattern + ", argCount=" + this.args.length + ", throwableProvided=" + ((this.throwable != null) ? 1 : 0) + ']';
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 376 */     out.defaultWriteObject();
/* 377 */     out.writeInt(this.args.length);
/* 378 */     for (Object arg : this.args) {
/* 379 */       Serializable serializableArg = (arg instanceof Serializable) ? (Serializable)arg : String.valueOf(arg);
/* 380 */       SerializationUtil.writeWrappedObject(serializableArg, out);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 385 */     SerializationUtil.assertFiltered(in);
/* 386 */     in.defaultReadObject();
/* 387 */     int argCount = in.readInt();
/* 388 */     this.args = new Object[argCount];
/* 389 */     for (int argIndex = 0; argIndex < this.args.length; argIndex++)
/* 390 */       this.args[argIndex] = SerializationUtil.readWrappedObject(in); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ParameterizedMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */