/*    */ package org.apache.logging.log4j.message;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructuredDataCollectionMessage
/*    */   implements StringBuilderFormattable, MessageCollectionMessage<StructuredDataMessage>
/*    */ {
/*    */   private static final long serialVersionUID = 5725337076388822924L;
/*    */   private final List<StructuredDataMessage> structuredDataMessageList;
/*    */   
/*    */   public StructuredDataCollectionMessage(List<StructuredDataMessage> messages) {
/* 34 */     this.structuredDataMessageList = messages;
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<StructuredDataMessage> iterator() {
/* 39 */     return this.structuredDataMessageList.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFormattedMessage() {
/* 44 */     StringBuilder sb = new StringBuilder();
/* 45 */     formatTo(sb);
/* 46 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFormat() {
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     for (StructuredDataMessage msg : this.structuredDataMessageList) {
/* 53 */       if (msg.getFormat() != null) {
/* 54 */         if (sb.length() > 0) {
/* 55 */           sb.append(", ");
/*    */         }
/* 57 */         sb.append(msg.getFormat());
/*    */       } 
/*    */     } 
/* 60 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void formatTo(StringBuilder buffer) {
/* 65 */     for (StructuredDataMessage msg : this.structuredDataMessageList) {
/* 66 */       msg.formatTo(buffer);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] getParameters() {
/* 72 */     List<Object[]> objectList = new ArrayList();
/* 73 */     int count = 0;
/* 74 */     for (StructuredDataMessage msg : this.structuredDataMessageList) {
/* 75 */       Object[] arrayOfObject = msg.getParameters();
/* 76 */       if (arrayOfObject != null) {
/* 77 */         objectList.add(arrayOfObject);
/* 78 */         count += arrayOfObject.length;
/*    */       } 
/*    */     } 
/* 81 */     Object[] objects = new Object[count];
/* 82 */     int index = 0;
/* 83 */     for (Object[] objs : objectList) {
/* 84 */       for (Object obj : objs) {
/* 85 */         objects[index++] = obj;
/*    */       }
/*    */     } 
/* 88 */     return objects;
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable getThrowable() {
/* 93 */     for (StructuredDataMessage msg : this.structuredDataMessageList) {
/* 94 */       Throwable t = msg.getThrowable();
/* 95 */       if (t != null) {
/* 96 */         return t;
/*    */       }
/*    */     } 
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\StructuredDataCollectionMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */