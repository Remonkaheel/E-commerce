/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.IllegalFormatException;
/*     */ import java.util.Locale;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringFormattedMessage
/*     */   implements Message
/*     */ {
/*  41 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = -665975803997290697L;
/*     */ 
/*     */   
/*     */   private static final int HASHVAL = 31;
/*     */   
/*     */   private String messagePattern;
/*     */   
/*     */   private transient Object[] argArray;
/*     */   
/*     */   private String[] stringArgs;
/*     */   
/*     */   private transient String formattedMessage;
/*     */   
/*     */   private transient Throwable throwable;
/*     */   
/*     */   private final Locale locale;
/*     */ 
/*     */   
/*     */   public StringFormattedMessage(Locale locale, String messagePattern, Object... arguments) {
/*  63 */     this.locale = locale;
/*  64 */     this.messagePattern = messagePattern;
/*  65 */     this.argArray = arguments;
/*  66 */     if (arguments != null && arguments.length > 0 && arguments[arguments.length - 1] instanceof Throwable) {
/*  67 */       this.throwable = (Throwable)arguments[arguments.length - 1];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringFormattedMessage(String messagePattern, Object... arguments) {
/*  79 */     this(Locale.getDefault(Locale.Category.FORMAT), messagePattern, arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/*  88 */     if (this.formattedMessage == null) {
/*  89 */       this.formattedMessage = formatMessage(this.messagePattern, this.argArray);
/*     */     }
/*  91 */     return this.formattedMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 100 */     return this.messagePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 109 */     if (this.argArray != null) {
/* 110 */       return this.argArray;
/*     */     }
/* 112 */     return (Object[])this.stringArgs;
/*     */   }
/*     */   
/*     */   protected String formatMessage(String msgPattern, Object... args) {
/* 116 */     if (args != null && args.length == 0)
/*     */     {
/* 118 */       return msgPattern;
/*     */     }
/*     */     try {
/* 121 */       return String.format(this.locale, msgPattern, args);
/* 122 */     } catch (IllegalFormatException ife) {
/* 123 */       LOGGER.error("Unable to format msg: {}", msgPattern, ife);
/* 124 */       return msgPattern;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 130 */     if (this == o) {
/* 131 */       return true;
/*     */     }
/* 133 */     if (!(o instanceof StringFormattedMessage)) {
/* 134 */       return false;
/*     */     }
/*     */     
/* 137 */     StringFormattedMessage that = (StringFormattedMessage)o;
/*     */     
/* 139 */     if ((this.messagePattern != null) ? !this.messagePattern.equals(that.messagePattern) : (that.messagePattern != null)) {
/* 140 */       return false;
/*     */     }
/*     */     
/* 143 */     return Arrays.equals((Object[])this.stringArgs, (Object[])that.stringArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 148 */     int result = (this.messagePattern != null) ? this.messagePattern.hashCode() : 0;
/* 149 */     result = 31 * result + ((this.stringArgs != null) ? Arrays.hashCode((Object[])this.stringArgs) : 0);
/* 150 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     return getFormattedMessage();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 159 */     out.defaultWriteObject();
/* 160 */     getFormattedMessage();
/* 161 */     out.writeUTF(this.formattedMessage);
/* 162 */     out.writeUTF(this.messagePattern);
/* 163 */     out.writeInt(this.argArray.length);
/* 164 */     this.stringArgs = new String[this.argArray.length];
/* 165 */     int i = 0;
/* 166 */     for (Object obj : this.argArray) {
/* 167 */       String string = String.valueOf(obj);
/* 168 */       this.stringArgs[i] = string;
/* 169 */       out.writeUTF(string);
/* 170 */       i++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 175 */     in.defaultReadObject();
/* 176 */     this.formattedMessage = in.readUTF();
/* 177 */     this.messagePattern = in.readUTF();
/* 178 */     int length = in.readInt();
/* 179 */     this.stringArgs = new String[length];
/* 180 */     for (int i = 0; i < length; i++) {
/* 181 */       this.stringArgs[i] = in.readUTF();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 192 */     return this.throwable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\StringFormattedMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */