/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PerformanceSensitive({"allocation"})
/*     */ public final class ReusableMessageFactory
/*     */   implements MessageFactory2, Serializable
/*     */ {
/*  42 */   public static final ReusableMessageFactory INSTANCE = new ReusableMessageFactory();
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   private final transient ThreadLocal<ReusableParameterizedMessage> threadLocalParameterized = new ThreadLocal<>();
/*  46 */   private final transient ThreadLocal<ReusableSimpleMessage> threadLocalSimpleMessage = new ThreadLocal<>();
/*  47 */   private final transient ThreadLocal<ReusableObjectMessage> threadLocalObjectMessage = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReusableParameterizedMessage getParameterized() {
/*  55 */     ReusableParameterizedMessage result = this.threadLocalParameterized.get();
/*  56 */     if (result == null) {
/*  57 */       result = new ReusableParameterizedMessage();
/*  58 */       this.threadLocalParameterized.set(result);
/*     */     } 
/*  60 */     return result.reserved ? (new ReusableParameterizedMessage()).reserve() : result.reserve();
/*     */   }
/*     */   
/*     */   private ReusableSimpleMessage getSimple() {
/*  64 */     ReusableSimpleMessage result = this.threadLocalSimpleMessage.get();
/*  65 */     if (result == null) {
/*  66 */       result = new ReusableSimpleMessage();
/*  67 */       this.threadLocalSimpleMessage.set(result);
/*     */     } 
/*  69 */     return result;
/*     */   }
/*     */   
/*     */   private ReusableObjectMessage getObject() {
/*  73 */     ReusableObjectMessage result = this.threadLocalObjectMessage.get();
/*  74 */     if (result == null) {
/*  75 */       result = new ReusableObjectMessage();
/*  76 */       this.threadLocalObjectMessage.set(result);
/*     */     } 
/*  78 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void release(Message message) {
/*  89 */     if (message instanceof Clearable) {
/*  90 */       ((Clearable)message).clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Message newMessage(CharSequence charSequence) {
/*  96 */     ReusableSimpleMessage result = getSimple();
/*  97 */     result.set(charSequence);
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object... params) {
/* 112 */     return getParameterized().set(message, params);
/*     */   }
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0) {
/* 117 */     return getParameterized().set(message, p0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1) {
/* 122 */     return getParameterized().set(message, p0, p1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2) {
/* 127 */     return getParameterized().set(message, p0, p1, p2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3) {
/* 133 */     return getParameterized().set(message, p0, p1, p2, p3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 139 */     return getParameterized().set(message, p0, p1, p2, p3, p4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 151 */     return getParameterized().set(message, p0, p1, p2, p3, p4, p5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 164 */     return getParameterized().set(message, p0, p1, p2, p3, p4, p5, p6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 178 */     return getParameterized().set(message, p0, p1, p2, p3, p4, p5, p6, p7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 193 */     return getParameterized().set(message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 209 */     return getParameterized().set(message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message) {
/* 222 */     ReusableSimpleMessage result = getSimple();
/* 223 */     result.set(message);
/* 224 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(Object message) {
/* 237 */     ReusableObjectMessage result = getObject();
/* 238 */     result.set(message);
/* 239 */     return result;
/*     */   }
/*     */   
/*     */   private Object writeReplace() {
/* 243 */     return new SerializationProxy();
/*     */   }
/*     */   
/*     */   private static class SerializationProxy implements Serializable {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private Object readResolve() {
/* 250 */       return ReusableMessageFactory.INSTANCE;
/*     */     }
/*     */     
/*     */     private SerializationProxy() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ReusableMessageFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */