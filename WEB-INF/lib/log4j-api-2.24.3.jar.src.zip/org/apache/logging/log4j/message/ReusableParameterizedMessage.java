/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.logging.log4j.util.Constants;
/*     */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PerformanceSensitive({"allocation"})
/*     */ public class ReusableParameterizedMessage
/*     */   implements ReusableMessage, ParameterVisitable, Clearable
/*     */ {
/*     */   private static final int MAX_PARAMS = 10;
/*     */   private static final long serialVersionUID = 7800075879295123856L;
/*     */   private String messagePattern;
/*  40 */   private final ParameterFormatter.MessagePatternAnalysis patternAnalysis = new ParameterFormatter.MessagePatternAnalysis();
/*  41 */   private final StringBuilder formatBuffer = new StringBuilder(Constants.MAX_REUSABLE_MESSAGE_SIZE);
/*     */   private int argCount;
/*     */   private transient Object[] varargs;
/*  44 */   private transient Object[] params = new Object[10];
/*     */ 
/*     */   
/*     */   private transient Throwable throwable;
/*     */ 
/*     */   
/*     */   transient boolean reserved = false;
/*     */ 
/*     */   
/*     */   private Object[] getTrimmedParams() {
/*  54 */     return (this.varargs == null) ? Arrays.<Object>copyOf(this.params, this.argCount) : this.varargs;
/*     */   }
/*     */   
/*     */   private Object[] getParams() {
/*  58 */     return (this.varargs == null) ? this.params : this.varargs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] swapParameters(Object[] emptyReplacement) {
/*     */     Object[] result;
/*  65 */     if (this.varargs == null) {
/*  66 */       result = this.params;
/*  67 */       if (emptyReplacement.length >= 10) {
/*  68 */         this.params = emptyReplacement;
/*  69 */       } else if (this.argCount <= emptyReplacement.length) {
/*     */ 
/*     */         
/*  72 */         System.arraycopy(this.params, 0, emptyReplacement, 0, this.argCount);
/*     */         
/*  74 */         for (int i = 0; i < this.argCount; i++) {
/*  75 */           this.params[i] = null;
/*     */         }
/*  77 */         result = emptyReplacement;
/*     */       } else {
/*     */         
/*  80 */         this.params = new Object[10];
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  90 */       if (this.argCount <= emptyReplacement.length) {
/*  91 */         result = emptyReplacement;
/*     */       } else {
/*  93 */         result = new Object[this.argCount];
/*     */       } 
/*     */       
/*  96 */       System.arraycopy(this.varargs, 0, result, 0, this.argCount);
/*     */     } 
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public short getParameterCount() {
/* 104 */     return (short)this.argCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S> void forEachParameter(ParameterConsumer<S> action, S state) {
/* 109 */     Object[] parameters = getParams(); short i;
/* 110 */     for (i = 0; i < this.argCount; i = (short)(i + 1)) {
/* 111 */       action.accept(parameters[i], i, state);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Message memento() {
/* 117 */     return new ParameterizedMessage(this.messagePattern, getTrimmedParams());
/*     */   }
/*     */   
/*     */   private void init(String messagePattern, int argCount, Object[] args) {
/* 121 */     this.varargs = null;
/* 122 */     this.messagePattern = messagePattern;
/* 123 */     this.argCount = argCount;
/* 124 */     ParameterFormatter.analyzePattern(messagePattern, argCount, this.patternAnalysis);
/* 125 */     this.throwable = determineThrowable(args, argCount, this.patternAnalysis.placeholderCount);
/*     */   }
/*     */   
/*     */   private static Throwable determineThrowable(Object[] args, int argCount, int placeholderCount) {
/* 129 */     if (placeholderCount < argCount) {
/* 130 */       Object lastArg = args[argCount - 1];
/* 131 */       if (lastArg instanceof Throwable) {
/* 132 */         return (Throwable)lastArg;
/*     */       }
/*     */     } 
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object... arguments) {
/* 139 */     init(messagePattern, (arguments == null) ? 0 : arguments.length, arguments);
/* 140 */     this.varargs = arguments;
/* 141 */     return this;
/*     */   }
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0) {
/* 145 */     this.params[0] = p0;
/* 146 */     init(messagePattern, 1, this.params);
/* 147 */     return this;
/*     */   }
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1) {
/* 151 */     this.params[0] = p0;
/* 152 */     this.params[1] = p1;
/* 153 */     init(messagePattern, 2, this.params);
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2) {
/* 159 */     this.params[0] = p0;
/* 160 */     this.params[1] = p1;
/* 161 */     this.params[2] = p2;
/* 162 */     init(messagePattern, 3, this.params);
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3) {
/* 168 */     this.params[0] = p0;
/* 169 */     this.params[1] = p1;
/* 170 */     this.params[2] = p2;
/* 171 */     this.params[3] = p3;
/* 172 */     init(messagePattern, 4, this.params);
/* 173 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 183 */     this.params[0] = p0;
/* 184 */     this.params[1] = p1;
/* 185 */     this.params[2] = p2;
/* 186 */     this.params[3] = p3;
/* 187 */     this.params[4] = p4;
/* 188 */     init(messagePattern, 5, this.params);
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 200 */     this.params[0] = p0;
/* 201 */     this.params[1] = p1;
/* 202 */     this.params[2] = p2;
/* 203 */     this.params[3] = p3;
/* 204 */     this.params[4] = p4;
/* 205 */     this.params[5] = p5;
/* 206 */     init(messagePattern, 6, this.params);
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 219 */     this.params[0] = p0;
/* 220 */     this.params[1] = p1;
/* 221 */     this.params[2] = p2;
/* 222 */     this.params[3] = p3;
/* 223 */     this.params[4] = p4;
/* 224 */     this.params[5] = p5;
/* 225 */     this.params[6] = p6;
/* 226 */     init(messagePattern, 7, this.params);
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 240 */     this.params[0] = p0;
/* 241 */     this.params[1] = p1;
/* 242 */     this.params[2] = p2;
/* 243 */     this.params[3] = p3;
/* 244 */     this.params[4] = p4;
/* 245 */     this.params[5] = p5;
/* 246 */     this.params[6] = p6;
/* 247 */     this.params[7] = p7;
/* 248 */     init(messagePattern, 8, this.params);
/* 249 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 263 */     this.params[0] = p0;
/* 264 */     this.params[1] = p1;
/* 265 */     this.params[2] = p2;
/* 266 */     this.params[3] = p3;
/* 267 */     this.params[4] = p4;
/* 268 */     this.params[5] = p5;
/* 269 */     this.params[6] = p6;
/* 270 */     this.params[7] = p7;
/* 271 */     this.params[8] = p8;
/* 272 */     init(messagePattern, 9, this.params);
/* 273 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 288 */     this.params[0] = p0;
/* 289 */     this.params[1] = p1;
/* 290 */     this.params[2] = p2;
/* 291 */     this.params[3] = p3;
/* 292 */     this.params[4] = p4;
/* 293 */     this.params[5] = p5;
/* 294 */     this.params[6] = p6;
/* 295 */     this.params[7] = p7;
/* 296 */     this.params[8] = p8;
/* 297 */     this.params[9] = p9;
/* 298 */     init(messagePattern, 10, this.params);
/* 299 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 308 */     return this.messagePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 317 */     return getTrimmedParams();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 331 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/*     */     try {
/* 341 */       formatTo(this.formatBuffer);
/* 342 */       return this.formatBuffer.toString();
/*     */     } finally {
/* 344 */       StringBuilders.trimToMaxSize(this.formatBuffer, Constants.MAX_REUSABLE_MESSAGE_SIZE);
/* 345 */       this.formatBuffer.setLength(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder builder) {
/* 351 */     ParameterFormatter.formatMessage(builder, this.messagePattern, getParams(), this.argCount, this.patternAnalysis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReusableParameterizedMessage reserve() {
/* 360 */     this.reserved = true;
/* 361 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 368 */     return "ReusableParameterizedMessage[messagePattern=" + getFormat() + ", argCount=" + getParameterCount() + ", throwableProvided=" + (
/* 369 */       (getThrowable() != null) ? 1 : 0) + ']';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 376 */     this.reserved = false;
/* 377 */     this.varargs = null;
/* 378 */     this.messagePattern = null;
/* 379 */     this.throwable = null;
/*     */     
/* 381 */     int placeholderCharIndicesMaxLength = 16;
/* 382 */     if (this.patternAnalysis.placeholderCharIndices != null && this.patternAnalysis.placeholderCharIndices.length > 16)
/*     */     {
/* 384 */       this.patternAnalysis.placeholderCharIndices = new int[16];
/*     */     }
/*     */   }
/*     */   
/*     */   private Object writeReplace() {
/* 389 */     return memento();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ReusableParameterizedMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */