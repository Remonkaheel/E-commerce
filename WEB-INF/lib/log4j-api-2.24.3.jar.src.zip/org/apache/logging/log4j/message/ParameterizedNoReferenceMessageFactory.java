/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParameterizedNoReferenceMessageFactory
/*     */   extends AbstractMessageFactory
/*     */ {
/*     */   private static final long serialVersionUID = 5027639245636870500L;
/*     */   
/*     */   static class StatusMessage
/*     */     implements Message
/*     */   {
/*     */     private static final long serialVersionUID = 4199272162767841280L;
/*     */     private final String formattedMessage;
/*     */     private final Throwable throwable;
/*     */     
/*     */     public StatusMessage(String formattedMessage, Throwable throwable) {
/*  56 */       this.formattedMessage = formattedMessage;
/*  57 */       this.throwable = throwable;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormattedMessage() {
/*  62 */       return this.formattedMessage;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormat() {
/*  67 */       return this.formattedMessage;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] getParameters() {
/*  72 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable getThrowable() {
/*  77 */       return this.throwable;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final ParameterizedNoReferenceMessageFactory INSTANCE = new ParameterizedNoReferenceMessageFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object... params) {
/* 102 */     if (params == null) {
/* 103 */       return new SimpleMessage(message);
/*     */     }
/* 105 */     ParameterizedMessage msg = new ParameterizedMessage(message, params);
/* 106 */     return new StatusMessage(msg.getFormattedMessage(), msg.getThrowable());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\message\ParameterizedNoReferenceMessageFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */