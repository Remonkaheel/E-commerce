/*     */ package org.apache.logging.log4j.status;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.Nullable;
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.time.Instant;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Objects;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusData
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4341916115118014017L;
/*     */   private final Instant instant;
/*     */   private final DateTimeFormatter instantFormatter;
/*     */   @Nullable
/*     */   private final StackTraceElement caller;
/*     */   private final Level level;
/*     */   private final Message message;
/*     */   private final String threadName;
/*     */   @Nullable
/*     */   private final Throwable throwable;
/*     */   
/*     */   public StatusData(@Nullable StackTraceElement caller, Level level, Message message, @Nullable Throwable throwable, @Nullable String threadName) {
/*  70 */     this(caller, level, message, throwable, threadName, null, Instant.now());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StatusData(@Nullable StackTraceElement caller, Level level, Message message, @Nullable Throwable throwable, @Nullable String threadName, @Nullable DateTimeFormatter instantFormatter, Instant instant) {
/*  82 */     this.instantFormatter = (instantFormatter != null) ? instantFormatter : DateTimeFormatter.ISO_INSTANT;
/*  83 */     this.instant = instant;
/*  84 */     this.caller = caller;
/*  85 */     this.level = Objects.<Level>requireNonNull(level, "level");
/*  86 */     this.message = Objects.<Message>requireNonNull(message, "message");
/*  87 */     this.throwable = throwable;
/*  88 */     this
/*  89 */       .threadName = (threadName != null) ? threadName : Thread.currentThread().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getInstant() {
/*  98 */     return this.instant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public long getTimestamp() {
/* 109 */     return this.instant.toEpochMilli();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public StackTraceElement getStackTraceElement() {
/* 119 */     return this.caller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getLevel() {
/* 128 */     return this.level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message getMessage() {
/* 137 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getThreadName() {
/* 146 */     return this.threadName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getThrowable() {
/* 156 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"INFORMATION_EXPOSURE_THROUGH_AN_ERROR_MESSAGE"}, justification = "Log4j prints stacktraces only to logs, which should be private.")
/*     */   public String getFormattedStatus() {
/*     */     Throwable effectiveThrowable;
/* 169 */     StringBuilder sb = new StringBuilder();
/* 170 */     this.instantFormatter.formatTo(this.instant, sb);
/* 171 */     sb.append(' ');
/* 172 */     sb.append(getThreadName());
/* 173 */     sb.append(' ');
/* 174 */     sb.append(this.level.toString());
/* 175 */     sb.append(' ');
/* 176 */     sb.append(this.message.getFormattedMessage());
/* 177 */     Object[] parameters = this.message.getParameters();
/*     */     
/* 179 */     if (this.throwable == null && parameters != null && parameters[parameters.length - 1] instanceof Throwable) {
/* 180 */       effectiveThrowable = (Throwable)parameters[parameters.length - 1];
/*     */     } else {
/* 182 */       effectiveThrowable = this.throwable;
/*     */     } 
/* 184 */     if (effectiveThrowable != null) {
/* 185 */       sb.append(' ');
/* 186 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 187 */       effectiveThrowable.printStackTrace(new PrintStream(baos));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 193 */       sb.append(baos);
/*     */     } 
/* 195 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     return getMessage().getFormattedMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\status\StatusData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */