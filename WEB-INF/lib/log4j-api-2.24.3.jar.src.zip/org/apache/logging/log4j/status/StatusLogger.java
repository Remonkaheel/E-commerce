/*     */ package org.apache.logging.log4j.status;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.Nullable;
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneId;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.message.ParameterizedNoReferenceMessageFactory;
/*     */ import org.apache.logging.log4j.spi.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusLogger
/*     */   extends AbstractLogger
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   private static final String DEBUG_PROPERTY_NAME = "log4j2.debug";
/*     */   public static final String MAX_STATUS_ENTRIES = "log4j2.status.entries";
/*     */   static final int DEFAULT_FALLBACK_LISTENER_BUFFER_CAPACITY = 0;
/*     */   public static final String DEFAULT_STATUS_LISTENER_LEVEL = "log4j2.StatusLogger.level";
/* 181 */   static final Level DEFAULT_FALLBACK_LISTENER_LEVEL = Level.ERROR;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String STATUS_DATE_FORMAT = "log4j2.StatusLogger.dateFormat";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String STATUS_DATE_FORMAT_ZONE = "log4j2.StatusLogger.dateFormatZone";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PROPERTIES_FILE_NAME = "log4j2.StatusLogger.properties";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Config config;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StatusConsoleListener fallbackListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<StatusListener> listeners;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Config
/*     */   {
/* 219 */     private static final Config INSTANCE = new Config();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final boolean debugEnabled;
/*     */ 
/*     */ 
/*     */     
/*     */     final int bufferCapacity;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     final Level fallbackListenerLevel;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     final DateTimeFormatter instantFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Config(boolean debugEnabled, int bufferCapacity, @Nullable DateTimeFormatter instantFormatter) {
/* 244 */       this.debugEnabled = debugEnabled;
/* 245 */       if (bufferCapacity < 0) {
/* 246 */         throw new IllegalArgumentException("was expecting a positive `bufferCapacity`, found: " + bufferCapacity);
/*     */       }
/*     */       
/* 249 */       this.bufferCapacity = bufferCapacity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 256 */       this.fallbackListenerLevel = null;
/* 257 */       this.instantFormatter = instantFormatter;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Config() {
/* 264 */       this(StatusLogger.PropertiesUtilsDouble.readAllAvailableProperties());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Config(Properties... propertiesList) {
/* 271 */       this(StatusLogger.PropertiesUtilsDouble.normalizeProperties(propertiesList));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Config(Map<String, Object> normalizedProperties) {
/* 278 */       this.debugEnabled = readDebugEnabled(normalizedProperties);
/* 279 */       this.bufferCapacity = readBufferCapacity(normalizedProperties);
/* 280 */       this.fallbackListenerLevel = readFallbackListenerLevel(normalizedProperties);
/* 281 */       this.instantFormatter = readInstantFormatter(normalizedProperties);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Config getInstance() {
/* 290 */       return INSTANCE;
/*     */     }
/*     */     
/*     */     private static boolean readDebugEnabled(Map<String, Object> normalizedProperties) {
/* 294 */       String debug = StatusLogger.PropertiesUtilsDouble.readProperty(normalizedProperties, "log4j2.debug");
/* 295 */       return (debug != null && !"false".equalsIgnoreCase(debug));
/*     */     }
/*     */     
/*     */     private static int readBufferCapacity(Map<String, Object> normalizedProperties) {
/* 299 */       String propertyName = "log4j2.status.entries";
/* 300 */       String capacityString = StatusLogger.PropertiesUtilsDouble.readProperty(normalizedProperties, "log4j2.status.entries");
/* 301 */       int defaultCapacity = 0;
/* 302 */       int effectiveCapacity = 0;
/* 303 */       if (capacityString != null) {
/*     */         try {
/* 305 */           int capacity = Integer.parseInt(capacityString);
/* 306 */           if (capacity < 0) {
/*     */             
/* 308 */             String message = String.format("was expecting a positive buffer capacity, found: %d", new Object[] { Integer.valueOf(capacity) });
/* 309 */             throw new IllegalArgumentException(message);
/*     */           } 
/* 311 */           effectiveCapacity = capacity;
/* 312 */         } catch (Exception error) {
/* 313 */           String message = String.format("Failed reading the buffer capacity from the `%s` property: `%s`. Falling back to the default: %d.", new Object[] { "log4j2.status.entries", capacityString, 
/*     */                 
/* 315 */                 Integer.valueOf(0) });
/* 316 */           IllegalArgumentException extendedError = new IllegalArgumentException(message, error);
/*     */ 
/*     */           
/* 319 */           extendedError.printStackTrace(System.err);
/*     */         } 
/*     */       }
/* 322 */       return effectiveCapacity;
/*     */     }
/*     */     
/*     */     private static Level readFallbackListenerLevel(Map<String, Object> normalizedProperties) {
/* 326 */       String propertyName = "log4j2.StatusLogger.level";
/* 327 */       String level = StatusLogger.PropertiesUtilsDouble.readProperty(normalizedProperties, "log4j2.StatusLogger.level");
/* 328 */       Level defaultLevel = StatusLogger.DEFAULT_FALLBACK_LISTENER_LEVEL;
/*     */       try {
/* 330 */         return (level != null) ? Level.valueOf(level) : defaultLevel;
/* 331 */       } catch (Exception error) {
/* 332 */         String message = String.format("Failed reading the level from the `%s` property: `%s`. Falling back to the default: `%s`.", new Object[] { "log4j2.StatusLogger.level", level, defaultLevel });
/*     */ 
/*     */         
/* 335 */         IllegalArgumentException extendedError = new IllegalArgumentException(message, error);
/*     */ 
/*     */         
/* 338 */         extendedError.printStackTrace(System.err);
/* 339 */         return defaultLevel;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private static DateTimeFormatter readInstantFormatter(Map<String, Object> normalizedProperties) {
/*     */       DateTimeFormatter formatter;
/* 347 */       String formatPropertyName = "log4j2.StatusLogger.dateFormat";
/* 348 */       String format = StatusLogger.PropertiesUtilsDouble.readProperty(normalizedProperties, "log4j2.StatusLogger.dateFormat");
/* 349 */       if (format == null) {
/* 350 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 354 */         formatter = DateTimeFormatter.ofPattern(format);
/* 355 */       } catch (Exception error) {
/* 356 */         String message = String.format("failed reading the instant format from the `%s` property: `%s`", new Object[] { "log4j2.StatusLogger.dateFormat", format });
/*     */         
/* 358 */         IllegalArgumentException extendedError = new IllegalArgumentException(message, error);
/*     */ 
/*     */         
/* 361 */         extendedError.printStackTrace(System.err);
/* 362 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 366 */       String zonePropertyName = "log4j2.StatusLogger.dateFormatZone";
/* 367 */       String zoneIdString = StatusLogger.PropertiesUtilsDouble.readProperty(normalizedProperties, "log4j2.StatusLogger.dateFormatZone");
/* 368 */       ZoneId defaultZoneId = ZoneId.systemDefault();
/* 369 */       ZoneId zoneId = defaultZoneId;
/* 370 */       if (zoneIdString != null) {
/*     */         try {
/* 372 */           zoneId = ZoneId.of(zoneIdString);
/* 373 */         } catch (Exception error) {
/* 374 */           String message = String.format("Failed reading the instant formatting zone ID from the `%s` property: `%s`. Falling back to the default: `%s`.", new Object[] { "log4j2.StatusLogger.dateFormatZone", zoneIdString, defaultZoneId });
/*     */ 
/*     */           
/* 377 */           IllegalArgumentException extendedError = new IllegalArgumentException(message, error);
/*     */ 
/*     */           
/* 380 */           extendedError.printStackTrace(System.err);
/*     */         } 
/*     */       }
/* 383 */       return formatter.withZone(zoneId);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PropertiesUtilsDouble
/*     */   {
/*     */     @Nullable
/*     */     static String readProperty(Map<String, Object> normalizedProperties, String propertyName) {
/* 400 */       String normalizedPropertyName = normalizePropertyName(propertyName);
/* 401 */       Object value = normalizedProperties.get(normalizedPropertyName);
/* 402 */       return (value instanceof String) ? (String)value : null;
/*     */     }
/*     */     
/*     */     static Map<String, Object> readAllAvailableProperties() {
/* 406 */       Properties systemProperties = System.getProperties();
/* 407 */       Properties environmentProperties = readEnvironmentProperties();
/* 408 */       Properties fileProvidedProperties = readPropertiesFile("log4j2.StatusLogger.properties");
/* 409 */       return normalizeProperties(new Properties[] { systemProperties, environmentProperties, fileProvidedProperties });
/*     */     }
/*     */     
/*     */     private static Properties readEnvironmentProperties() {
/* 413 */       Properties properties = new Properties();
/* 414 */       properties.putAll(System.getenv());
/* 415 */       return properties;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Properties readPropertiesFile(String propertiesFileName) {
/* 424 */       Properties properties = new Properties();
/*     */ 
/*     */ 
/*     */       
/* 428 */       String resourceName = '/' + propertiesFileName;
/* 429 */       URL url = StatusLogger.class.getResource(resourceName);
/* 430 */       if (url == null)
/* 431 */         return properties; 
/*     */       
/* 433 */       try { InputStream stream = url.openStream(); 
/* 434 */         try { properties.load(stream);
/* 435 */           if (stream != null) stream.close();  } catch (Throwable throwable) { if (stream != null) try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException error)
/* 436 */       { String message = String.format("failed reading properties from `%s`", new Object[] { propertiesFileName });
/* 437 */         RuntimeException extendedError = new RuntimeException(message, error);
/*     */ 
/*     */         
/* 440 */         extendedError.printStackTrace(System.err); }
/*     */       
/* 442 */       return properties;
/*     */     }
/*     */     
/*     */     private static Map<String, Object> normalizeProperties(Properties... propertiesList) {
/* 446 */       Map<String, Object> map = new HashMap<>();
/* 447 */       for (Properties properties : propertiesList) {
/* 448 */         properties.forEach((name, value) -> {
/*     */               boolean relevant = isRelevantPropertyName(name);
/*     */               if (relevant) {
/*     */                 String normalizedName = normalizePropertyName((String)name);
/*     */                 map.put(normalizedName, value);
/*     */               } 
/*     */             });
/*     */       } 
/* 456 */       return map;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean isRelevantPropertyName(@Nullable Object propertyName) {
/* 465 */       return (propertyName instanceof String && ((String)propertyName).matches("^(?i)log4j.*"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static String normalizePropertyName(String propertyName) {
/* 479 */       return propertyName
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 484 */         .replaceAll("[._-]", "")
/*     */ 
/*     */ 
/*     */         
/* 488 */         .replaceAll("\\P{InBasic_Latin}", ".")
/*     */         
/* 490 */         .toLowerCase(Locale.US)
/* 491 */         .replaceAll("^log4j2", "log4j");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class InstanceHolder
/*     */   {
/* 506 */     private static volatile StatusLogger INSTANCE = new StatusLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 515 */   private final transient ReadWriteLock listenerLock = new ReentrantReadWriteLock();
/*     */   
/* 517 */   private final transient Lock listenerReadLock = this.listenerLock.readLock();
/*     */   
/* 519 */   private final transient Lock listenerWriteLock = this.listenerLock.writeLock();
/*     */   
/* 521 */   private final Queue<StatusData> buffer = new ConcurrentLinkedQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StatusLogger() {
/* 530 */     this(StatusLogger.class
/* 531 */         .getSimpleName(), (MessageFactory)ParameterizedNoReferenceMessageFactory.INSTANCE, 
/*     */         
/* 533 */         Config.getInstance(), new StatusConsoleListener(
/* 534 */           Objects.<Level>requireNonNull((Config.getInstance()).fallbackListenerLevel)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StatusLogger(String name, MessageFactory messageFactory, Config config, StatusConsoleListener fallbackListener) {
/* 553 */     super(Objects.<String>requireNonNull(name, "name"), Objects.<MessageFactory>requireNonNull(messageFactory, "messageFactory"));
/* 554 */     this.config = Objects.<Config>requireNonNull(config, "config");
/* 555 */     this.fallbackListener = Objects.<StatusConsoleListener>requireNonNull(fallbackListener, "fallbackListener");
/* 556 */     this.listeners = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StatusLogger getLogger() {
/* 565 */     return InstanceHolder.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLogger(StatusLogger logger) {
/* 577 */     InstanceHolder.INSTANCE = Objects.<StatusLogger>requireNonNull(logger, "logger");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StatusConsoleListener getFallbackListener() {
/* 586 */     return this.fallbackListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setLevel(Level level) {
/* 597 */     Objects.requireNonNull(level, "level");
/* 598 */     this.fallbackListener.setLevel(level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerListener(StatusListener listener) {
/* 607 */     Objects.requireNonNull(listener, "listener");
/* 608 */     this.listenerWriteLock.lock();
/*     */     try {
/* 610 */       this.listeners.add(listener);
/*     */     } finally {
/* 612 */       this.listenerWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(StatusListener listener) {
/* 622 */     Objects.requireNonNull(listener, "listener");
/* 623 */     this.listenerWriteLock.lock();
/*     */     try {
/* 625 */       this.listeners.remove(listener);
/* 626 */       closeListenerSafely(listener);
/*     */     } finally {
/* 628 */       this.listenerWriteLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void updateListenerLevel(Level level) {
/* 640 */     Objects.requireNonNull(level, "level");
/* 641 */     this.fallbackListener.setLevel(level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<StatusListener> getListeners() {
/* 650 */     this.listenerReadLock.lock();
/*     */     try {
/* 652 */       return Collections.unmodifiableCollection(this.listeners);
/*     */     } finally {
/* 654 */       this.listenerReadLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 662 */     this.listenerWriteLock.lock();
/*     */     try {
/* 664 */       Iterator<StatusListener> listenerIterator = this.listeners.iterator();
/* 665 */       while (listenerIterator.hasNext()) {
/* 666 */         StatusListener listener = listenerIterator.next();
/* 667 */         closeListenerSafely(listener);
/* 668 */         listenerIterator.remove();
/*     */       } 
/*     */     } finally {
/* 671 */       this.listenerWriteLock.unlock();
/*     */     } 
/* 673 */     this.fallbackListener.close();
/* 674 */     this.buffer.clear();
/*     */   }
/*     */   
/*     */   private static void closeListenerSafely(StatusListener listener) {
/*     */     try {
/* 679 */       listener.close();
/* 680 */     } catch (IOException error) {
/* 681 */       String message = String.format("failed closing listener: %s", new Object[] { listener });
/* 682 */       RuntimeException extendedError = new RuntimeException(message, error);
/*     */ 
/*     */       
/* 685 */       extendedError.printStackTrace(System.err);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<StatusData> getStatusData() {
/* 700 */     return Collections.unmodifiableList(new ArrayList<>(this.buffer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void clear() {
/* 710 */     this.buffer.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getLevel() {
/* 720 */     Level leastSpecificLevel = this.fallbackListener.getStatusLevel();
/*     */     
/* 722 */     for (int listenerIndex = 0; listenerIndex < this.listeners.size(); listenerIndex++) {
/* 723 */       StatusListener listener = this.listeners.get(listenerIndex);
/* 724 */       Level listenerLevel = listener.getStatusLevel();
/* 725 */       if (listenerLevel.isLessSpecificThan(leastSpecificLevel)) {
/* 726 */         leastSpecificLevel = listenerLevel;
/*     */       }
/*     */     } 
/* 729 */     return leastSpecificLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings({"INFORMATION_EXPOSURE_THROUGH_AN_ERROR_MESSAGE"})
/*     */   public void logMessage(String fqcn, Level level, Marker marker, Message message, Throwable throwable) {
/*     */     try {
/* 741 */       StatusData statusData = createStatusData(fqcn, level, message, throwable);
/* 742 */       buffer(statusData);
/* 743 */       notifyListeners(statusData);
/* 744 */     } catch (Exception error) {
/*     */ 
/*     */       
/* 747 */       error.printStackTrace(System.err);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void buffer(StatusData statusData) {
/* 752 */     if (this.config.bufferCapacity == 0) {
/*     */       return;
/*     */     }
/* 755 */     this.buffer.add(statusData);
/* 756 */     while (this.buffer.size() >= this.config.bufferCapacity) {
/* 757 */       this.buffer.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyListeners(StatusData statusData) {
/*     */     boolean foundListeners;
/* 763 */     this.listenerReadLock.lock();
/*     */     try {
/* 765 */       foundListeners = !this.listeners.isEmpty();
/* 766 */       this.listeners.forEach(listener -> notifyListener(listener, statusData));
/*     */     } finally {
/* 768 */       this.listenerReadLock.unlock();
/*     */     } 
/* 770 */     if (!foundListeners) {
/* 771 */       notifyListener(this.fallbackListener, statusData);
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyListener(StatusListener listener, StatusData statusData) {
/* 776 */     boolean levelEnabled = isLevelEnabled(listener.getStatusLevel(), statusData.getLevel());
/* 777 */     if (levelEnabled) {
/* 778 */       listener.log(statusData);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StatusData createStatusData(@Nullable String fqcn, Level level, Message message, @Nullable Throwable throwable) {
/* 787 */     StackTraceElement caller = getStackTraceElement(fqcn);
/* 788 */     Instant instant = Instant.now();
/* 789 */     return new StatusData(caller, level, message, throwable, null, this.config.instantFormatter, instant);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static StackTraceElement getStackTraceElement(@Nullable String fqcn) {
/* 794 */     if (fqcn == null) {
/* 795 */       return null;
/*     */     }
/* 797 */     boolean next = false;
/* 798 */     StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
/* 799 */     for (StackTraceElement element : stackTrace) {
/* 800 */       String className = element.getClassName();
/* 801 */       if (next && !fqcn.equals(className)) {
/* 802 */         return element;
/*     */       }
/* 804 */       if (fqcn.equals(className)) {
/* 805 */         next = true;
/* 806 */       } else if ("?".equals(className)) {
/*     */         break;
/*     */       } 
/*     */     } 
/* 810 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Throwable throwable) {
/* 815 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message) {
/* 820 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object... params) {
/* 825 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0) {
/* 830 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1) {
/* 836 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 847 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 859 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 872 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 886 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 901 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 917 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 934 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 952 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, CharSequence message, Throwable throwable) {
/* 958 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, Object message, Throwable throwable) {
/* 963 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, Message message, Throwable throwable) {
/* 968 */     return isEnabled(level, marker);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level messageLevel, Marker marker) {
/* 973 */     Objects.requireNonNull(messageLevel, "messageLevel");
/* 974 */     Level loggerLevel = getLevel();
/* 975 */     return isLevelEnabled(loggerLevel, messageLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLevelEnabled(Level filteringLevel, Level messageLevel) {
/* 986 */     return (this.config.debugEnabled || filteringLevel.isLessSpecificThan(messageLevel));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\status\StatusLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */