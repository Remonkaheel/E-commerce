/*     */ package org.apache.logging.log4j.status;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusConsoleListener
/*     */   implements StatusListener
/*     */ {
/*  35 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Level initialLevel;
/*     */ 
/*     */ 
/*     */   
/*     */   private final PrintStream initialStream;
/*     */ 
/*     */   
/*     */   private volatile Level level;
/*     */ 
/*     */   
/*     */   private volatile PrintStream stream;
/*     */ 
/*     */ 
/*     */   
/*     */   public StatusConsoleListener(Level level) {
/*  54 */     this(level, System.out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StatusConsoleListener(Level level, PrintStream stream) {
/*  68 */     this.initialLevel = this.level = Objects.requireNonNull(level, "level");
/*  69 */     this.initialStream = this.stream = Objects.requireNonNull(stream, "stream");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevel(Level level) {
/*  79 */     Objects.requireNonNull(level, "level");
/*     */     
/*  81 */     if (!this.level.equals(level)) {
/*  82 */       this.lock.lock();
/*     */       try {
/*  84 */         this.level = level;
/*     */       } finally {
/*  86 */         this.lock.unlock();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStream(PrintStream stream) {
/*  99 */     Objects.requireNonNull(stream, "stream");
/*     */     
/* 101 */     if (this.stream != stream) {
/* 102 */       OutputStream oldStream = null;
/* 103 */       this.lock.lock();
/*     */       try {
/* 105 */         if (this.stream != stream) {
/* 106 */           oldStream = this.stream;
/* 107 */           this.stream = stream;
/*     */         } 
/*     */       } finally {
/* 110 */         this.lock.unlock();
/*     */       } 
/* 112 */       if (oldStream != null) {
/* 113 */         closeNonSystemStream(oldStream);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getStatusLevel() {
/* 125 */     return this.level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(StatusData data) {
/* 136 */     Objects.requireNonNull(data, "data");
/* 137 */     String formattedStatus = data.getFormattedStatus();
/* 138 */     this.stream.println(formattedStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setFilters(String... filters) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     OutputStream oldStream;
/* 156 */     this.lock.lock();
/*     */     try {
/* 158 */       oldStream = this.stream;
/* 159 */       this.stream = this.initialStream;
/* 160 */       this.level = this.initialLevel;
/*     */     } finally {
/* 162 */       this.lock.unlock();
/*     */     } 
/* 164 */     closeNonSystemStream(oldStream);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void closeNonSystemStream(OutputStream stream) {
/* 169 */     if (stream != System.out && stream != System.err)
/*     */       try {
/* 171 */         stream.close();
/* 172 */       } catch (IOException error) {
/*     */ 
/*     */         
/* 175 */         error.printStackTrace(System.err);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\status\StatusConsoleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */