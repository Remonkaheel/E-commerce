/*     */ package org.apache.logging.log4j.simple;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessageFactory;
/*     */ import org.apache.logging.log4j.simple.internal.SimpleProvider;
/*     */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*     */ import org.apache.logging.log4j.spi.LoggerContext;
/*     */ import org.apache.logging.log4j.spi.LoggerRegistry;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleLoggerContext
/*     */   implements LoggerContext
/*     */ {
/*  37 */   static final SimpleLoggerContext INSTANCE = new SimpleLoggerContext();
/*     */ 
/*     */   
/*     */   protected static final String DEFAULT_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/*     */ 
/*     */   
/*     */   protected static final String SYSTEM_PREFIX = "org.apache.logging.log4j.simplelog.";
/*     */   
/*  45 */   private static final MessageFactory DEFAULT_MESSAGE_FACTORY = (MessageFactory)ParameterizedMessageFactory.INSTANCE;
/*     */ 
/*     */   
/*     */   private final PropertiesUtil props;
/*     */ 
/*     */   
/*     */   private final boolean showLogName;
/*     */ 
/*     */   
/*     */   private final boolean showShortName;
/*     */ 
/*     */   
/*     */   private final boolean showDateTime;
/*     */ 
/*     */   
/*     */   private final boolean showContextMap;
/*     */ 
/*     */   
/*     */   private final String dateTimeFormat;
/*     */ 
/*     */   
/*     */   private final Level defaultLevel;
/*     */ 
/*     */   
/*     */   private final PrintStream stream;
/*     */   
/*  71 */   private final LoggerRegistry<ExtendedLogger> loggerRegistry = new LoggerRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"PATH_TRAVERSAL_OUT"}, justification = "Opens a file retrieved from configuration (Log4j properties)")
/*     */   public SimpleLoggerContext() {
/*  80 */     SimpleProvider.Config config = SimpleProvider.Config.INSTANCE;
/*  81 */     this.props = config.props;
/*  82 */     this.showContextMap = config.showContextMap;
/*  83 */     this.showLogName = config.showLogName;
/*  84 */     this.showShortName = config.showShortName;
/*  85 */     this.showDateTime = config.showDateTime;
/*  86 */     this.defaultLevel = config.defaultLevel;
/*  87 */     this.dateTimeFormat = config.dateTimeFormat;
/*  88 */     this.stream = config.stream;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getExternalContext() {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExtendedLogger getLogger(String name) {
/*  98 */     return getLogger(name, DEFAULT_MESSAGE_FACTORY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedLogger getLogger(String name, MessageFactory messageFactory) {
/* 104 */     MessageFactory effectiveMessageFactory = (messageFactory != null) ? messageFactory : DEFAULT_MESSAGE_FACTORY;
/* 105 */     ExtendedLogger oldLogger = this.loggerRegistry.getLogger(name, effectiveMessageFactory);
/* 106 */     if (oldLogger != null) {
/* 107 */       return oldLogger;
/*     */     }
/* 109 */     ExtendedLogger newLogger = createLogger(name, effectiveMessageFactory);
/* 110 */     this.loggerRegistry.putIfAbsent(name, effectiveMessageFactory, newLogger);
/* 111 */     return this.loggerRegistry.getLogger(name, effectiveMessageFactory);
/*     */   }
/*     */   
/*     */   private ExtendedLogger createLogger(String name, MessageFactory messageFactory) {
/* 115 */     return (ExtendedLogger)new SimpleLogger(name, this.defaultLevel, this.showLogName, this.showShortName, this.showDateTime, this.showContextMap, this.dateTimeFormat, messageFactory, this.props, this.stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggerRegistry<ExtendedLogger> getLoggerRegistry() {
/* 136 */     return this.loggerRegistry;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasLogger(String name) {
/* 141 */     return this.loggerRegistry.hasLogger(name, DEFAULT_MESSAGE_FACTORY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasLogger(String name, Class<? extends MessageFactory> messageFactoryClass) {
/* 146 */     return this.loggerRegistry.hasLogger(name, messageFactoryClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLogger(String name, MessageFactory messageFactory) {
/* 152 */     MessageFactory effectiveMessageFactory = (messageFactory != null) ? messageFactory : DEFAULT_MESSAGE_FACTORY;
/* 153 */     return this.loggerRegistry.hasLogger(name, effectiveMessageFactory);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\simple\SimpleLoggerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */