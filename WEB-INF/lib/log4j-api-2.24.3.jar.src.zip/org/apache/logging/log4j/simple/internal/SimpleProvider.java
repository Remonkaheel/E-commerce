/*     */ package org.apache.logging.log4j.simple.internal;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.simple.SimpleLoggerContextFactory;
/*     */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*     */ import org.apache.logging.log4j.spi.NoOpThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.Provider;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMap;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.jspecify.annotations.NullMarked;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @NullMarked
/*     */ public final class SimpleProvider
/*     */   extends Provider
/*     */ {
/*     */   private final ThreadContextMap threadContextMap;
/*     */   
/*     */   public SimpleProvider() {
/*  44 */     super(null, "2.6.0");
/*  45 */     this
/*  46 */       .threadContextMap = Config.INSTANCE.showContextMap ? super.getThreadContextMapInstance() : NoOpThreadContextMap.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public LoggerContextFactory getLoggerContextFactory() {
/*  51 */     return (LoggerContextFactory)SimpleLoggerContextFactory.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public ThreadContextMap getThreadContextMapInstance() {
/*  56 */     return this.threadContextMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Config
/*     */   {
/*     */     private static final String DEFAULT_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss:SSS zzz";
/*     */     
/*     */     private static final String SYSTEM_PREFIX = "org.apache.logging.log4j.simplelog.";
/*     */     
/*     */     private static final String SYSTEM_OUT = "system.out";
/*     */     
/*     */     private static final String SYSTEM_ERR = "system.err";
/*     */     
/*  71 */     public static final Config INSTANCE = new Config();
/*     */     
/*     */     public final PropertiesUtil props;
/*     */     
/*     */     public final boolean showContextMap;
/*     */     
/*     */     public final boolean showLogName;
/*     */     
/*     */     public final boolean showShortName;
/*     */     
/*     */     public final boolean showDateTime;
/*     */     
/*     */     public final Level defaultLevel;
/*     */     
/*     */     public final String dateTimeFormat;
/*     */     public final PrintStream stream;
/*     */     
/*     */     private Config() {
/*     */       PrintStream ps;
/*  90 */       this.props = new PropertiesUtil("log4j2.simplelog.properties");
/*     */       
/*  92 */       this.showContextMap = this.props.getBooleanProperty("org.apache.logging.log4j.simplelog.showContextMap", false);
/*  93 */       this.showLogName = this.props.getBooleanProperty("org.apache.logging.log4j.simplelog.showlogname", false);
/*  94 */       this.showShortName = this.props.getBooleanProperty("org.apache.logging.log4j.simplelog.showShortLogname", true);
/*  95 */       this.showDateTime = this.props.getBooleanProperty("org.apache.logging.log4j.simplelog.showdatetime", false);
/*  96 */       String lvl = this.props.getStringProperty("org.apache.logging.log4j.simplelog.level");
/*  97 */       this.defaultLevel = Level.toLevel(lvl, Level.ERROR);
/*     */       
/*  99 */       this
/*     */         
/* 101 */         .dateTimeFormat = this.showDateTime ? this.props.getStringProperty("org.apache.logging.log4j.simplelog.dateTimeFormat", "yyyy/MM/dd HH:mm:ss:SSS zzz") : null;
/*     */       
/* 103 */       String fileName = this.props.getStringProperty("org.apache.logging.log4j.simplelog.logFile", "system.err");
/*     */       
/* 105 */       if ("system.err".equalsIgnoreCase(fileName)) {
/* 106 */         ps = System.err;
/* 107 */       } else if ("system.out".equalsIgnoreCase(fileName)) {
/* 108 */         ps = System.out;
/*     */       } else {
/*     */         try {
/* 111 */           ps = new PrintStream(new FileOutputStream(fileName));
/* 112 */         } catch (FileNotFoundException fnfe) {
/* 113 */           ps = System.err;
/*     */         } 
/*     */       } 
/* 116 */       this.stream = ps;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\simple\internal\SimpleProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */