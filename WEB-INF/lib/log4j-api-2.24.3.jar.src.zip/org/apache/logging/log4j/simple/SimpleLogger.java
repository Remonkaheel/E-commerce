/*     */ package org.apache.logging.log4j.simple;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.ThreadContext;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.spi.AbstractLogger;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleLogger
/*     */   extends AbstractLogger
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final char SPACE = ' ';
/*     */   private final DateFormat dateFormatter;
/*     */   private Level level;
/*     */   private final boolean showDateTime;
/*     */   private final boolean showContextMap;
/*     */   private PrintStream stream;
/*     */   private final String logName;
/*     */   
/*     */   public SimpleLogger(String name, Level defaultLevel, boolean showLogName, boolean showShortLogName, boolean showDateTime, boolean showContextMap, String dateTimeFormat, MessageFactory messageFactory, PropertiesUtil props, PrintStream stream) {
/*  72 */     super(name, messageFactory);
/*  73 */     String lvl = props.getStringProperty("org.apache.logging.log4j.simplelog." + name + ".level");
/*  74 */     this.level = Level.toLevel(lvl, defaultLevel);
/*  75 */     if (showShortLogName) {
/*  76 */       int index = name.lastIndexOf(".");
/*  77 */       if (index > 0 && index < name.length()) {
/*  78 */         this.logName = name.substring(index + 1);
/*     */       } else {
/*  80 */         this.logName = name;
/*     */       } 
/*  82 */     } else if (showLogName) {
/*  83 */       this.logName = name;
/*     */     } else {
/*  85 */       this.logName = null;
/*     */     } 
/*  87 */     this.showDateTime = showDateTime;
/*  88 */     this.showContextMap = showContextMap;
/*  89 */     this.stream = stream;
/*     */     
/*  91 */     if (showDateTime) {
/*     */       DateFormat format;
/*     */       try {
/*  94 */         format = new SimpleDateFormat(dateTimeFormat);
/*  95 */       } catch (IllegalArgumentException e) {
/*     */         
/*  97 */         format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS zzz");
/*     */       } 
/*  99 */       this.dateFormatter = format;
/*     */     } else {
/* 101 */       this.dateFormatter = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Level getLevel() {
/* 107 */     return this.level;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, Message msg, Throwable t) {
/* 112 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, CharSequence msg, Throwable t) {
/* 117 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, Object msg, Throwable t) {
/* 122 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String msg) {
/* 127 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String msg, Object... p1) {
/* 132 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0) {
/* 137 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1) {
/* 143 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 154 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 166 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 179 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 193 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 208 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 224 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 241 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 259 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Level testLevel, Marker marker, String msg, Throwable t) {
/* 264 */     return (this.level.intLevel() >= testLevel.intLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"INFORMATION_EXPOSURE_THROUGH_AN_ERROR_MESSAGE"}, justification = "Log4j prints stacktraces only to logs, which should be private.")
/*     */   public void logMessage(String fqcn, Level mgsLevel, Marker marker, Message msg, Throwable throwable) {
/*     */     Throwable t;
/* 277 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 279 */     if (this.showDateTime) {
/* 280 */       String dateText; Date now = new Date();
/*     */       
/* 282 */       synchronized (this.dateFormatter) {
/* 283 */         dateText = this.dateFormatter.format(now);
/*     */       } 
/* 285 */       sb.append(dateText);
/* 286 */       sb.append(' ');
/*     */     } 
/*     */     
/* 289 */     sb.append(mgsLevel.toString());
/* 290 */     sb.append(' ');
/* 291 */     if (Strings.isNotEmpty(this.logName)) {
/* 292 */       sb.append(this.logName);
/* 293 */       sb.append(' ');
/*     */     } 
/* 295 */     sb.append(msg.getFormattedMessage());
/* 296 */     if (this.showContextMap) {
/* 297 */       Map<String, String> mdc = ThreadContext.getImmutableContext();
/* 298 */       if (mdc.size() > 0) {
/* 299 */         sb.append(' ');
/* 300 */         sb.append(mdc.toString());
/* 301 */         sb.append(' ');
/*     */       } 
/*     */     } 
/* 304 */     Object[] params = msg.getParameters();
/*     */     
/* 306 */     if (throwable == null && params != null && params.length > 0 && params[params.length - 1] instanceof Throwable) {
/*     */ 
/*     */ 
/*     */       
/* 310 */       t = (Throwable)params[params.length - 1];
/*     */     } else {
/* 312 */       t = throwable;
/*     */     } 
/* 314 */     this.stream.println(sb.toString());
/* 315 */     if (t != null) {
/* 316 */       this.stream.print(' ');
/* 317 */       t.printStackTrace(this.stream);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLevel(Level level) {
/* 322 */     if (level != null) {
/* 323 */       this.level = level;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStream(PrintStream stream) {
/* 328 */     this.stream = stream;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\simple\SimpleLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */