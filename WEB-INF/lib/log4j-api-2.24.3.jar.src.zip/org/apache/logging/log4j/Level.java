/*     */ package org.apache.logging.log4j;
/*     */ 
/*     */ import aQute.bnd.annotation.baseline.BaselineIgnore;
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.apache.logging.log4j.spi.StandardLevel;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @BaselineIgnore("2.22.0")
/*     */ public final class Level
/*     */   implements Comparable<Level>, Serializable
/*     */ {
/*  81 */   private static final Level[] EMPTY_ARRAY = new Level[0];
/*     */   
/*  83 */   private static final ConcurrentMap<String, Level> LEVELS = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public static final Level OFF = new Level("OFF", StandardLevel.OFF.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public static final Level FATAL = new Level("FATAL", StandardLevel.FATAL.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public static final Level ERROR = new Level("ERROR", StandardLevel.ERROR.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final Level WARN = new Level("WARN", StandardLevel.WARN.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final Level INFO = new Level("INFO", StandardLevel.INFO.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final Level DEBUG = new Level("DEBUG", StandardLevel.DEBUG.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final Level TRACE = new Level("TRACE", StandardLevel.TRACE.intLevel());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public static final Level ALL = new Level("ALL", StandardLevel.ALL.intLevel());
/*     */ 
/*     */   
/*     */   public static final String CATEGORY = "Level";
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1581082L;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final int intLevel;
/*     */   
/*     */   private final StandardLevel standardLevel;
/*     */ 
/*     */   
/*     */   private Level(String name, int intLevel) {
/* 139 */     if (Strings.isEmpty(name)) {
/* 140 */       throw new IllegalArgumentException("Illegal null or empty Level name.");
/*     */     }
/* 142 */     if (intLevel < 0) {
/* 143 */       throw new IllegalArgumentException("Illegal Level int less than zero.");
/*     */     }
/* 145 */     this.name = name;
/* 146 */     this.intLevel = intLevel;
/* 147 */     this.standardLevel = StandardLevel.getStandardLevel(intLevel);
/* 148 */     if (LEVELS.putIfAbsent(Strings.toRootUpperCase(name.trim()), this) != null) {
/* 149 */       throw new IllegalStateException("Level " + name + " has already been defined.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int intLevel() {
/* 159 */     return this.intLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardLevel getStandardLevel() {
/* 168 */     return this.standardLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInRange(Level minLevel, Level maxLevel) {
/* 181 */     return (this.intLevel >= minLevel.intLevel && this.intLevel <= maxLevel.intLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLessSpecificThan(Level level) {
/* 199 */     return (this.intLevel >= level.intLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMoreSpecificThan(Level level) {
/* 215 */     return (this.intLevel <= level.intLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level clone() throws CloneNotSupportedException {
/* 222 */     throw new CloneNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Level other) {
/* 228 */     return (this.intLevel < other.intLevel) ? -1 : ((this.intLevel > other.intLevel) ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 233 */     return (other instanceof Level && other == this);
/*     */   }
/*     */   
/*     */   public Class<Level> getDeclaringClass() {
/* 237 */     return Level.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 242 */     return this.name.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 251 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 256 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level forName(String name, int intValue) {
/* 268 */     if (Strings.isEmpty(name)) {
/* 269 */       throw new IllegalArgumentException("Illegal null or empty Level name.");
/*     */     }
/* 271 */     String normalizedName = Strings.toRootUpperCase(name.trim());
/* 272 */     Level level = LEVELS.get(normalizedName);
/* 273 */     if (level != null) {
/* 274 */       return level;
/*     */     }
/*     */     
/*     */     try {
/* 278 */       return new Level(name, intValue);
/* 279 */     } catch (IllegalStateException ex) {
/*     */       
/* 281 */       return LEVELS.get(normalizedName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level getLevel(String name) {
/* 293 */     if (Strings.isEmpty(name)) {
/* 294 */       throw new IllegalArgumentException("Illegal null or empty Level name.");
/*     */     }
/* 296 */     return LEVELS.get(Strings.toRootUpperCase(name.trim()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(String level) {
/* 307 */     return toLevel(level, DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(String name, Level defaultLevel) {
/* 319 */     if (name == null) {
/* 320 */       return defaultLevel;
/*     */     }
/* 322 */     Level level = LEVELS.get(Strings.toRootUpperCase(name.trim()));
/* 323 */     return (level == null) ? defaultLevel : level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level[] values() {
/* 332 */     return (Level[])LEVELS.values().toArray((Object[])EMPTY_ARRAY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level valueOf(String name) {
/* 344 */     Objects.requireNonNull(name, "No level name given.");
/* 345 */     String levelName = Strings.toRootUpperCase(name.trim());
/* 346 */     Level level = LEVELS.get(levelName);
/* 347 */     if (level != null) {
/* 348 */       return level;
/*     */     }
/* 350 */     throw new IllegalArgumentException("Unknown level constant [" + levelName + "].");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Enum<T>> T valueOf(Class<T> enumType, String name) {
/* 367 */     return Enum.valueOf(enumType, name);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object readResolve() {
/* 372 */     return valueOf(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\Level.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */