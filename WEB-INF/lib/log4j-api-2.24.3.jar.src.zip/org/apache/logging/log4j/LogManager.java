/*     */ package org.apache.logging.log4j;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.apache.logging.log4j.internal.LogManagerStatus;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.message.StringFormatterMessageFactory;
/*     */ import org.apache.logging.log4j.simple.SimpleLoggerContextFactory;
/*     */ import org.apache.logging.log4j.spi.LoggerContext;
/*     */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*     */ import org.apache.logging.log4j.spi.Terminable;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.ProviderUtil;
/*     */ import org.apache.logging.log4j.util.StackLocatorUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogManager
/*     */ {
/*     */   @Deprecated
/*     */   public static final String FACTORY_PROPERTY_NAME = "log4j2.loggerContextFactory";
/*     */   public static final String ROOT_LOGGER_NAME = "";
/*  56 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*  59 */   private static final String FQCN = LogManager.class.getName();
/*     */ 
/*     */   
/*  62 */   private static volatile LoggerContextFactory factory = ProviderUtil.getProvider().getLoggerContextFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  69 */     LogManagerStatus.setInitialized(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean exists(String name) {
/*  85 */     return getContext().hasLogger(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext() {
/*     */     try {
/*  99 */       return factory.getContext(FQCN, null, null, true);
/* 100 */     } catch (IllegalStateException ex) {
/* 101 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 102 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, null, null, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext(boolean currentContext) {
/*     */     try {
/* 118 */       return factory.getContext(FQCN, null, null, currentContext, null, null);
/* 119 */     } catch (IllegalStateException ex) {
/* 120 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 121 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, null, null, currentContext, null, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext(ClassLoader loader, boolean currentContext) {
/*     */     try {
/* 138 */       return factory.getContext(FQCN, loader, null, currentContext);
/* 139 */     } catch (IllegalStateException ex) {
/* 140 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 141 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, loader, null, currentContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext(ClassLoader loader, boolean currentContext, Object externalContext) {
/*     */     try {
/* 160 */       return factory.getContext(FQCN, loader, externalContext, currentContext);
/* 161 */     } catch (IllegalStateException ex) {
/* 162 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 163 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, loader, externalContext, currentContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext(ClassLoader loader, boolean currentContext, URI configLocation) {
/*     */     try {
/* 182 */       return factory.getContext(FQCN, loader, null, currentContext, configLocation, null);
/* 183 */     } catch (IllegalStateException ex) {
/* 184 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 185 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, loader, null, currentContext, configLocation, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext(ClassLoader loader, boolean currentContext, Object externalContext, URI configLocation) {
/*     */     try {
/* 209 */       return factory.getContext(FQCN, loader, externalContext, currentContext, configLocation, null);
/* 210 */     } catch (IllegalStateException ex) {
/* 211 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 212 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, loader, externalContext, currentContext, configLocation, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContext getContext(ClassLoader loader, boolean currentContext, Object externalContext, URI configLocation, String name) {
/*     */     try {
/* 238 */       return factory.getContext(FQCN, loader, externalContext, currentContext, configLocation, name);
/* 239 */     } catch (IllegalStateException ex) {
/* 240 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 241 */       return SimpleLoggerContextFactory.INSTANCE.getContext(FQCN, loader, externalContext, currentContext, configLocation, name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static LoggerContext getContext(String fqcn, boolean currentContext) {
/*     */     try {
/* 258 */       return factory.getContext(fqcn, null, null, currentContext);
/* 259 */     } catch (IllegalStateException ex) {
/* 260 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 261 */       return SimpleLoggerContextFactory.INSTANCE.getContext(fqcn, null, null, currentContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static LoggerContext getContext(String fqcn, ClassLoader loader, boolean currentContext) {
/*     */     try {
/* 280 */       return factory.getContext(fqcn, loader, null, currentContext);
/* 281 */     } catch (IllegalStateException ex) {
/* 282 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 283 */       return SimpleLoggerContextFactory.INSTANCE.getContext(fqcn, loader, null, currentContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static LoggerContext getContext(String fqcn, ClassLoader loader, boolean currentContext, URI configLocation, String name) {
/*     */     try {
/* 308 */       return factory.getContext(fqcn, loader, null, currentContext, configLocation, name);
/* 309 */     } catch (IllegalStateException ex) {
/* 310 */       LOGGER.warn("{} Using SimpleLogger", ex.getMessage());
/* 311 */       return SimpleLoggerContextFactory.INSTANCE.getContext(fqcn, loader, null, currentContext);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown() {
/* 325 */     shutdown(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown(boolean currentContext) {
/* 345 */     factory.shutdown(FQCN, null, currentContext, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown(boolean currentContext, boolean allContexts) {
/* 366 */     factory.shutdown(FQCN, null, currentContext, allContexts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown(LoggerContext context) {
/* 380 */     if (context instanceof Terminable) {
/* 381 */       ((Terminable)context).terminate();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoggerContextFactory getFactory() {
/* 391 */     return factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setFactory(LoggerContextFactory factory) {
/* 409 */     LogManager.factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getFormatterLogger() {
/* 423 */     return getFormatterLogger(StackLocatorUtil.getCallerClass(2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getFormatterLogger(Class<?> clazz) {
/* 454 */     return getLogger(
/* 455 */         (clazz != null) ? clazz : StackLocatorUtil.getCallerClass(2), (MessageFactory)StringFormatterMessageFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getFormatterLogger(Object value) {
/* 486 */     return getLogger(
/* 487 */         (value != null) ? value.getClass() : StackLocatorUtil.getCallerClass(2), (MessageFactory)StringFormatterMessageFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getFormatterLogger(String name) {
/* 518 */     return (name == null) ? 
/* 519 */       getFormatterLogger(StackLocatorUtil.getCallerClass(2)) : 
/* 520 */       getLogger(name, (MessageFactory)StringFormatterMessageFactory.INSTANCE);
/*     */   }
/*     */   
/*     */   private static Class<?> callerClass(Class<?> clazz) {
/* 524 */     if (clazz != null) {
/* 525 */       return clazz;
/*     */     }
/* 527 */     Class<?> candidate = StackLocatorUtil.getCallerClass(3);
/* 528 */     if (candidate == null) {
/* 529 */       throw new UnsupportedOperationException("No class provided, and an appropriate one cannot be found.");
/*     */     }
/* 531 */     return candidate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger() {
/* 541 */     return getLogger(StackLocatorUtil.getCallerClass(2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Class<?> clazz) {
/* 554 */     Class<?> cls = callerClass(clazz);
/* 555 */     return (Logger)getContext(cls.getClassLoader(), false).getLogger(cls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Class<?> clazz, MessageFactory messageFactory) {
/* 570 */     Class<?> cls = callerClass(clazz);
/* 571 */     return (Logger)getContext(cls.getClassLoader(), false).getLogger(cls, messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(MessageFactory messageFactory) {
/* 583 */     return getLogger(StackLocatorUtil.getCallerClass(2), messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Object value) {
/* 596 */     return getLogger((value != null) ? value.getClass() : StackLocatorUtil.getCallerClass(2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Object value, MessageFactory messageFactory) {
/* 611 */     return getLogger((value != null) ? value.getClass() : StackLocatorUtil.getCallerClass(2), messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(String name) {
/* 622 */     return (name != null) ? (Logger)getContext(false).getLogger(name) : getLogger(StackLocatorUtil.getCallerClass(2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(String name, MessageFactory messageFactory) {
/* 635 */     return (name != null) ? 
/* 636 */       (Logger)getContext(false).getLogger(name, messageFactory) : 
/* 637 */       getLogger(StackLocatorUtil.getCallerClass(2), messageFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Logger getLogger(String fqcn, String name) {
/* 648 */     return (Logger)factory.getContext(fqcn, null, null, false).getLogger(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getRootLogger() {
/* 657 */     return getLogger("");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\LogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */