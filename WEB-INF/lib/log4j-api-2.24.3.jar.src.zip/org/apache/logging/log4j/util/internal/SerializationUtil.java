/*     */ package org.apache.logging.log4j.util.internal;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.apache.logging.log4j.util.FilteredObjectInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SerializationUtil
/*     */ {
/*     */   private static final String DEFAULT_FILTER_CLASS = "org.apache.logging.log4j.util.internal.DefaultObjectInputFilter";
/*     */   private static final Method setObjectInputFilter;
/*     */   private static final Method getObjectInputFilter;
/*     */   private static final Method newObjectInputFilter;
/*     */   public static final List<String> REQUIRED_JAVA_CLASSES;
/*     */   public static final List<String> REQUIRED_JAVA_PACKAGES;
/*     */   
/*     */   static {
/*  47 */     Method[] methods = ObjectInputStream.class.getMethods();
/*  48 */     Method setMethod = null;
/*  49 */     Method getMethod = null;
/*  50 */     for (Method method : methods) {
/*  51 */       if (method.getName().equals("setObjectInputFilter")) {
/*  52 */         setMethod = method;
/*  53 */       } else if (method.getName().equals("getObjectInputFilter")) {
/*  54 */         getMethod = method;
/*     */       } 
/*     */     } 
/*  57 */     Method newMethod = null;
/*     */     try {
/*  59 */       if (setMethod != null) {
/*  60 */         Class<?> clazz = Class.forName("org.apache.logging.log4j.util.internal.DefaultObjectInputFilter");
/*  61 */         methods = clazz.getMethods();
/*  62 */         for (Method method : methods) {
/*  63 */           if (method.getName().equals("newInstance") && Modifier.isStatic(method.getModifiers())) {
/*  64 */             newMethod = method;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*  69 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*  72 */     newObjectInputFilter = newMethod;
/*  73 */     setObjectInputFilter = setMethod;
/*  74 */     getObjectInputFilter = getMethod;
/*     */ 
/*     */     
/*  77 */     REQUIRED_JAVA_CLASSES = Arrays.asList(new String[] { "java.math.BigDecimal", "java.math.BigInteger", "java.rmi.MarshalledObject", "boolean", "byte", "char", "double", "float", "int", "long", "short" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     REQUIRED_JAVA_PACKAGES = Arrays.asList(new String[] { "java.lang.", "java.time.", "java.util.", "org.apache.logging.log4j." });
/*     */   }
/*     */   
/*  96 */   public static void writeWrappedObject(Serializable obj, ObjectOutputStream out) throws IOException { ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*  97 */     ObjectOutputStream oos = new ObjectOutputStream(bout); try {
/*  98 */       oos.writeObject(obj);
/*  99 */       oos.flush();
/* 100 */       out.writeObject(bout.toByteArray());
/* 101 */       oos.close();
/*     */     } catch (Throwable throwable) {
/*     */       try {
/*     */         oos.close();
/*     */       } catch (Throwable throwable1) {
/*     */         throwable.addSuppressed(throwable1);
/*     */       }  throw throwable;
/*     */     }  } @SuppressFBWarnings(value = {"OBJECT_DESERIALIZATION"}, justification = "Object deserialization uses either Java 9 native filter or our custom filter to limit the kinds of classes deserialized.") public static Object readWrappedObject(ObjectInputStream in) throws IOException, ClassNotFoundException { ObjectInputStream ois;
/* 109 */     assertFiltered(in);
/* 110 */     byte[] data = (byte[])in.readObject();
/* 111 */     ByteArrayInputStream bin = new ByteArrayInputStream(data);
/*     */     
/* 113 */     if (in instanceof FilteredObjectInputStream) {
/* 114 */       FilteredObjectInputStream filteredObjectInputStream = new FilteredObjectInputStream(bin, ((FilteredObjectInputStream)in).getAllowedClasses());
/*     */     } else {
/*     */       try {
/* 117 */         Object obj = getObjectInputFilter.invoke(in, new Object[0]);
/* 118 */         Object filter = newObjectInputFilter.invoke(null, new Object[] { obj });
/* 119 */         ois = new ObjectInputStream(bin);
/* 120 */         setObjectInputFilter.invoke(ois, new Object[] { filter });
/* 121 */       } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException ex) {
/* 122 */         throw new StreamCorruptedException("Unable to set ObjectInputFilter on stream");
/*     */       } 
/*     */     } 
/*     */     try {
/* 126 */       return ois.readObject();
/* 127 */     } catch (Exception|LinkageError e) {
/* 128 */       StatusLogger.getLogger().warn("Ignoring {} during deserialization", e.getMessage());
/* 129 */       return null;
/*     */     } finally {
/* 131 */       ois.close();
/*     */     }  }
/*     */ 
/*     */   
/*     */   public static void assertFiltered(ObjectInputStream stream) {
/* 136 */     if (!(stream instanceof FilteredObjectInputStream) && setObjectInputFilter == null) {
/* 137 */       throw new IllegalArgumentException("readObject requires a FilteredObjectInputStream or an ObjectInputStream that accepts an ObjectInputFilter");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripArray(Class<?> clazz) {
/* 150 */     Class<?> currentClazz = clazz;
/* 151 */     while (currentClazz.isArray()) {
/* 152 */       currentClazz = currentClazz.getComponentType();
/*     */     }
/* 154 */     return currentClazz.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripArray(String name) {
/* 166 */     int offset = name.lastIndexOf('[') + 1;
/* 167 */     if (offset == 0) {
/* 168 */       return name;
/*     */     }
/*     */     
/* 171 */     if (name.charAt(offset) == 'L') {
/* 172 */       return name.substring(offset + 1, name.length() - 1);
/*     */     }
/*     */     
/* 175 */     switch (name.substring(offset)) {
/*     */       case "Z":
/* 177 */         return "boolean";
/*     */       case "B":
/* 179 */         return "byte";
/*     */       case "C":
/* 181 */         return "char";
/*     */       case "D":
/* 183 */         return "double";
/*     */       case "F":
/* 185 */         return "float";
/*     */       case "I":
/* 187 */         return "int";
/*     */       case "J":
/* 189 */         return "long";
/*     */       case "S":
/* 191 */         return "short";
/*     */     } 
/* 193 */     throw new IllegalArgumentException("Unsupported array class signature '" + name + "'");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\internal\SerializationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */