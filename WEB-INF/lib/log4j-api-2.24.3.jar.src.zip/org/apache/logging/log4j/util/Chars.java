/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @InternalApi
/*    */ public final class Chars
/*    */ {
/*    */   public static final char CR = '\r';
/*    */   public static final char DQUOTE = '"';
/*    */   public static final char EQ = '=';
/*    */   public static final char LF = '\n';
/*    */   public static final char NUL = '\000';
/*    */   public static final char QUOTE = '\'';
/*    */   public static final char SPACE = ' ';
/*    */   public static final char TAB = '\t';
/*    */   
/*    */   public static char getUpperCaseHex(int digit) {
/* 56 */     if (digit < 0 || digit >= 16) {
/* 57 */       return Character.MIN_VALUE;
/*    */     }
/* 59 */     return (digit < 10) ? getNumericalDigit(digit) : getUpperCaseAlphaDigit(digit);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static char getLowerCaseHex(int digit) {
/* 69 */     if (digit < 0 || digit >= 16) {
/* 70 */       return Character.MIN_VALUE;
/*    */     }
/* 72 */     return (digit < 10) ? getNumericalDigit(digit) : getLowerCaseAlphaDigit(digit);
/*    */   }
/*    */   
/*    */   private static char getNumericalDigit(int digit) {
/* 76 */     return (char)(48 + digit);
/*    */   }
/*    */   
/*    */   private static char getUpperCaseAlphaDigit(int digit) {
/* 80 */     return (char)(65 + digit - 10);
/*    */   }
/*    */   
/*    */   private static char getLowerCaseAlphaDigit(int digit) {
/* 84 */     return (char)(97 + digit - 10);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Chars.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */