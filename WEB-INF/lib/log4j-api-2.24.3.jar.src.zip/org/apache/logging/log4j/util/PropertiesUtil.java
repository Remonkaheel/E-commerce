/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import aQute.bnd.annotation.spi.ServiceConsumer;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.time.temporal.TemporalUnit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ServiceConsumer(value = PropertySource.class, resolution = "optional", cardinality = "multiple")
/*     */ public final class PropertiesUtil
/*     */ {
/*  62 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   private static final String LOG4J_PROPERTIES_FILE_NAME = "log4j2.component.properties";
/*     */   
/*     */   private static final String LOG4J_SYSTEM_PROPERTIES_FILE_NAME = "log4j2.system.properties";
/*     */   
/*  69 */   private static final Lazy<PropertiesUtil> COMPONENT_PROPERTIES = Lazy.lazy(() -> new PropertiesUtil("log4j2.component.properties", false));
/*     */   
/*  71 */   private static final Pattern DURATION_PATTERN = Pattern.compile("([+-]?\\d+)\\s*(\\w+)?", 2);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Environment environment;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesUtil(Properties props) {
/*  81 */     this(new PropertiesPropertySource(props));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesUtil(String propertiesFileName) {
/*  91 */     this(propertiesFileName, true);
/*     */   }
/*     */   
/*     */   private PropertiesUtil(String propertiesFileName, boolean useTccl) {
/*  95 */     this(new PropertyFilePropertySource(propertiesFileName, useTccl));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertiesUtil(PropertySource source) {
/* 103 */     this.environment = new Environment(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Properties loadClose(InputStream in, Object source) {
/* 114 */     Properties props = new Properties();
/* 115 */     if (null != in) {
/*     */       try {
/* 117 */         props.load(in);
/* 118 */       } catch (IOException error) {
/* 119 */         LOGGER.error("Unable to read source `{}`", source, error);
/*     */       } finally {
/*     */         try {
/* 122 */           in.close();
/* 123 */         } catch (IOException error) {
/* 124 */           LOGGER.error("Unable to close source `{}`", source, error);
/*     */         } 
/*     */       } 
/*     */     }
/* 128 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertiesUtil getProperties() {
/* 137 */     return COMPONENT_PROPERTIES.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertySource(PropertySource propertySource) {
/* 146 */     this.environment.addPropertySource(Objects.<PropertySource>requireNonNull(propertySource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertySource(PropertySource propertySource) {
/* 155 */     this.environment.removePropertySource(Objects.<PropertySource>requireNonNull(propertySource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty(String name) {
/* 165 */     return this.environment.containsKey(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String name) {
/* 177 */     return getBooleanProperty(name, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String name, boolean defaultValue) {
/* 188 */     String prop = getStringProperty(name);
/* 189 */     return (prop == null) ? defaultValue : "true".equalsIgnoreCase(prop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String name, boolean defaultValueIfAbsent, boolean defaultValueIfPresent) {
/* 202 */     String prop = getStringProperty(name);
/* 203 */     return (prop == null) ? 
/* 204 */       defaultValueIfAbsent : (
/* 205 */       prop.isEmpty() ? defaultValueIfPresent : "true".equalsIgnoreCase(prop));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getBooleanProperty(String[] prefixes, String key, Supplier<Boolean> supplier) {
/* 218 */     for (String prefix : prefixes) {
/* 219 */       if (hasProperty(prefix + key)) {
/* 220 */         return Boolean.valueOf(getBooleanProperty(prefix + key));
/*     */       }
/*     */     } 
/* 223 */     return (supplier != null) ? supplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharsetProperty(String name) {
/* 233 */     return getCharsetProperty(name, Charset.defaultCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharsetProperty(String name, Charset defaultValue) {
/* 245 */     String charsetName = getStringProperty(name);
/* 246 */     if (charsetName == null) {
/* 247 */       return defaultValue;
/*     */     }
/* 249 */     if (Charset.isSupported(charsetName)) {
/* 250 */       return Charset.forName(charsetName);
/*     */     }
/* 252 */     ResourceBundle bundle = getCharsetsResourceBundle();
/* 253 */     if (bundle.containsKey(name)) {
/* 254 */       String mapped = bundle.getString(name);
/* 255 */       if (Charset.isSupported(mapped)) {
/* 256 */         return Charset.forName(mapped);
/*     */       }
/*     */     } 
/* 259 */     LOGGER.warn("Unable to read charset `{}` from property `{}`. Falling back to the default: `{}`", charsetName, name, defaultValue);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleProperty(String name, double defaultValue) {
/* 275 */     String prop = getStringProperty(name);
/* 276 */     if (prop != null) {
/*     */       try {
/* 278 */         return Double.parseDouble(prop);
/* 279 */       } catch (NumberFormatException e) {
/* 280 */         LOGGER.warn("Unable to read double `{}` from property `{}`. Falling back to the default: `{}`", prop, name, 
/*     */ 
/*     */ 
/*     */             
/* 284 */             Double.valueOf(defaultValue), e);
/*     */       } 
/*     */     }
/*     */     
/* 288 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerProperty(String name, int defaultValue) {
/* 300 */     String prop = getStringProperty(name);
/* 301 */     if (prop != null) {
/*     */       try {
/* 303 */         return Integer.parseInt(prop.trim());
/* 304 */       } catch (NumberFormatException e) {
/* 305 */         LOGGER.warn("Unable to read int `{}` from property `{}`. Falling back to the default: `{}`", prop, name, 
/*     */ 
/*     */ 
/*     */             
/* 309 */             Integer.valueOf(defaultValue), e);
/*     */       } 
/*     */     }
/*     */     
/* 313 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getIntegerProperty(String[] prefixes, String key, Supplier<Integer> supplier) {
/* 326 */     for (String prefix : prefixes) {
/* 327 */       if (hasProperty(prefix + key)) {
/* 328 */         return Integer.valueOf(getIntegerProperty(prefix + key, 0));
/*     */       }
/*     */     } 
/* 331 */     return (supplier != null) ? supplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongProperty(String name, long defaultValue) {
/* 342 */     String prop = getStringProperty(name);
/* 343 */     if (prop != null) {
/*     */       try {
/* 345 */         return Long.parseLong(prop);
/* 346 */       } catch (NumberFormatException e) {
/* 347 */         LOGGER.warn("Unable to read long `{}` from property `{}`. Falling back to the default: `{}`", prop, name, 
/*     */ 
/*     */ 
/*     */             
/* 351 */             Long.valueOf(defaultValue), e);
/*     */       } 
/*     */     }
/*     */     
/* 355 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getLongProperty(String[] prefixes, String key, Supplier<Long> supplier) {
/* 368 */     for (String prefix : prefixes) {
/* 369 */       if (hasProperty(prefix + key)) {
/* 370 */         return Long.valueOf(getLongProperty(prefix + key, 0L));
/*     */       }
/*     */     } 
/* 373 */     return (supplier != null) ? supplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration getDurationProperty(String name, Duration defaultValue) {
/* 385 */     String prop = getStringProperty(name);
/*     */     try {
/* 387 */       return parseDuration(prop);
/* 388 */     } catch (IllegalArgumentException e) {
/* 389 */       LOGGER.warn("Unable to read duration `{}` from property `{}`.\nExpected format 'n unit', where 'n' is an integer and 'unit' is one of: {}.", prop, name, TimeUnit
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 394 */           .getValidUnits().collect(Collectors.joining(", ")), e);
/*     */ 
/*     */       
/* 397 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration getDurationProperty(String[] prefixes, String key, Supplier<Duration> supplier) {
/* 410 */     for (String prefix : prefixes) {
/* 411 */       if (hasProperty(prefix + key)) {
/* 412 */         return getDurationProperty(prefix + key, null);
/*     */       }
/*     */     } 
/* 415 */     return (supplier != null) ? supplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String[] prefixes, String key, Supplier<String> supplier) {
/* 428 */     for (String prefix : prefixes) {
/* 429 */       String result = getStringProperty(prefix + key);
/* 430 */       if (result != null) {
/* 431 */         return result;
/*     */       }
/*     */     } 
/* 434 */     return (supplier != null) ? supplier.get() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String name) {
/* 444 */     return this.environment.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String name, String defaultValue) {
/* 455 */     String prop = getStringProperty(name);
/* 456 */     return (prop == null) ? defaultValue : prop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getSystemProperties() {
/*     */     try {
/* 466 */       return new Properties(System.getProperties());
/* 467 */     } catch (SecurityException error) {
/* 468 */       LOGGER.error("Unable to access system properties.", error);
/*     */       
/* 470 */       return new Properties();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void reload() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Environment
/*     */   {
/* 498 */     private final Set<PropertySource> sources = ConcurrentHashMap.newKeySet();
/* 499 */     private final ThreadLocal<PropertySource> CURRENT_PROPERTY_SOURCE = new ThreadLocal<>();
/*     */     
/*     */     private Environment(PropertySource propertySource) {
/* 502 */       PropertySource sysProps = new PropertyFilePropertySource("log4j2.system.properties", false);
/*     */       try {
/* 504 */         sysProps.forEach((key, value) -> {
/*     */               if (System.getProperty(key) == null) {
/*     */                 System.setProperty(key, value);
/*     */               }
/*     */             });
/* 509 */       } catch (SecurityException e) {
/* 510 */         PropertiesUtil.LOGGER.warn("Unable to set Java system properties from {} file, due to security restrictions.", "log4j2.system.properties", e);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 515 */       this.sources.add(propertySource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 521 */       Objects.requireNonNull(this.sources); ServiceLoaderUtil.<PropertySource>safeStream(PropertySource.class, ServiceLoader.load(PropertySource.class, PropertiesUtil.class.getClassLoader()), PropertiesUtil.LOGGER).forEach(this.sources::add);
/*     */     }
/*     */     
/*     */     private void addPropertySource(PropertySource propertySource) {
/* 525 */       this.sources.add(propertySource);
/*     */     }
/*     */     
/*     */     private void removePropertySource(PropertySource propertySource) {
/* 529 */       this.sources.remove(propertySource);
/*     */     }
/*     */     
/*     */     private String get(String key) {
/* 533 */       List<CharSequence> tokens = PropertySource.Util.tokenize(key);
/* 534 */       return this.sources.stream()
/* 535 */         .sorted(PropertySource.Comparator.INSTANCE)
/* 536 */         .map(source -> {
/*     */             if (!tokens.isEmpty()) {
/*     */               String normalKey = Objects.toString(source.getNormalForm(tokens), null);
/*     */               
/*     */               if (normalKey != null && sourceContainsProperty(source, normalKey)) {
/*     */                 return sourceGetProperty(source, normalKey);
/*     */               }
/*     */             } 
/*     */             return sourceGetProperty(source, key);
/* 545 */           }).filter(Objects::nonNull)
/* 546 */         .findFirst()
/* 547 */         .orElse(null);
/*     */     }
/*     */     
/*     */     private boolean sourceContainsProperty(PropertySource source, String key) {
/* 551 */       PropertySource recursiveSource = this.CURRENT_PROPERTY_SOURCE.get();
/* 552 */       if (recursiveSource == null) {
/* 553 */         this.CURRENT_PROPERTY_SOURCE.set(source);
/*     */         try {
/* 555 */           return source.containsProperty(key);
/* 556 */         } catch (Exception e) {
/* 557 */           PropertiesUtil.LOGGER.warn("Failed to retrieve Log4j property {} from property source {}.", key, source, e);
/*     */         } finally {
/* 559 */           this.CURRENT_PROPERTY_SOURCE.remove();
/*     */         } 
/*     */       } 
/* 562 */       PropertiesUtil.LOGGER.warn("Recursive call to `containsProperty()` from property source {}.", recursiveSource);
/* 563 */       return false;
/*     */     }
/*     */     
/*     */     private String sourceGetProperty(PropertySource source, String key) {
/* 567 */       PropertySource recursiveSource = this.CURRENT_PROPERTY_SOURCE.get();
/* 568 */       if (recursiveSource == null) {
/* 569 */         this.CURRENT_PROPERTY_SOURCE.set(source);
/*     */         try {
/* 571 */           return source.getProperty(key);
/* 572 */         } catch (Exception e) {
/* 573 */           PropertiesUtil.LOGGER.warn("Failed to retrieve Log4j property {} from property source {}.", key, source, e);
/*     */         } finally {
/* 575 */           this.CURRENT_PROPERTY_SOURCE.remove();
/*     */         } 
/*     */       } 
/* 578 */       PropertiesUtil.LOGGER.warn("Recursive call to `getProperty()` from property source {}.", recursiveSource);
/* 579 */       return null;
/*     */     }
/*     */     
/*     */     private boolean containsKey(String key) {
/* 583 */       List<CharSequence> tokens = PropertySource.Util.tokenize(key);
/* 584 */       return this.sources.stream().anyMatch(s -> {
/*     */             CharSequence normalizedKey = tokens.isEmpty() ? null : s.getNormalForm(tokens);
/* 586 */             return (sourceContainsProperty(s, key) || (normalizedKey != null && sourceContainsProperty(s, normalizedKey.toString())));
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties extractSubset(Properties properties, String prefix) {
/* 601 */     Properties subset = new Properties();
/*     */     
/* 603 */     if (prefix == null || prefix.isEmpty()) {
/* 604 */       return subset;
/*     */     }
/*     */     
/* 607 */     String prefixToMatch = (prefix.charAt(prefix.length() - 1) != '.') ? (prefix + '.') : prefix;
/*     */     
/* 609 */     Collection<String> keys = new ArrayList<>();
/*     */     
/* 611 */     for (String key : properties.stringPropertyNames()) {
/* 612 */       if (key.startsWith(prefixToMatch)) {
/* 613 */         subset.setProperty(key.substring(prefixToMatch.length()), properties.getProperty(key));
/* 614 */         keys.add(key);
/*     */       } 
/*     */     } 
/* 617 */     for (String key : keys) {
/* 618 */       properties.remove(key);
/*     */     }
/*     */     
/* 621 */     return subset;
/*     */   }
/*     */   
/*     */   static ResourceBundle getCharsetsResourceBundle() {
/* 625 */     return ResourceBundle.getBundle("Log4j-charsets");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Properties> partitionOnCommonPrefixes(Properties properties) {
/* 637 */     return partitionOnCommonPrefixes(properties, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Properties> partitionOnCommonPrefixes(Properties properties, boolean includeBaseKey) {
/* 651 */     Map<String, Properties> parts = new ConcurrentHashMap<>();
/* 652 */     for (String key : properties.stringPropertyNames()) {
/* 653 */       int idx = key.indexOf('.');
/* 654 */       if (idx < 0) {
/* 655 */         if (includeBaseKey) {
/* 656 */           if (!parts.containsKey(key)) {
/* 657 */             parts.put(key, new Properties());
/*     */           }
/* 659 */           ((Properties)parts.get(key)).setProperty("", properties.getProperty(key));
/*     */         } 
/*     */         continue;
/*     */       } 
/* 663 */       String prefix = key.substring(0, idx);
/* 664 */       if (!parts.containsKey(prefix)) {
/* 665 */         parts.put(prefix, new Properties());
/*     */       }
/* 667 */       ((Properties)parts.get(prefix)).setProperty(key.substring(idx + 1), properties.getProperty(key));
/*     */     } 
/* 669 */     return parts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOsWindows() {
/* 678 */     return SystemPropertiesPropertySource.getSystemProperty("os.name", "").startsWith("Windows");
/*     */   }
/*     */   
/*     */   static Duration parseDuration(CharSequence value) {
/* 682 */     Matcher matcher = DURATION_PATTERN.matcher(value);
/* 683 */     if (matcher.matches()) {
/* 684 */       return Duration.of(parseDurationAmount(matcher.group(1)), TimeUnit.parseUnit(matcher.group(2)));
/*     */     }
/* 686 */     throw new IllegalArgumentException("Invalid duration value '" + value + "'.");
/*     */   }
/*     */   
/*     */   private static long parseDurationAmount(String amount) {
/*     */     try {
/* 691 */       return Long.parseLong(amount);
/* 692 */     } catch (NumberFormatException e) {
/* 693 */       throw new IllegalArgumentException("Invalid duration amount '" + amount + "'", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private enum TimeUnit {
/* 698 */     NANOS((String)new String[] { "ns", "nano", "nanos", "nanosecond", "nanoseconds" }, ChronoUnit.NANOS),
/* 699 */     MICROS((String)new String[] { "us", "micro", "micros", "microsecond", "microseconds" }, ChronoUnit.MICROS),
/* 700 */     MILLIS((String)new String[] { "ms", "milli", "millis", "millisecond", "milliseconds" }, ChronoUnit.MILLIS),
/* 701 */     SECONDS((String)new String[] { "s", "second", "seconds" }, ChronoUnit.SECONDS),
/* 702 */     MINUTES((String)new String[] { "m", "minute", "minutes" }, ChronoUnit.MINUTES),
/* 703 */     HOURS((String)new String[] { "h", "hour", "hours" }, ChronoUnit.HOURS),
/* 704 */     DAYS((String)new String[] { "d", "day", "days" }, ChronoUnit.DAYS);
/*     */     
/*     */     private final String[] descriptions;
/*     */     private final TemporalUnit timeUnit;
/*     */     
/*     */     TimeUnit(String[] descriptions, TemporalUnit timeUnit) {
/* 710 */       this.descriptions = descriptions;
/* 711 */       this.timeUnit = timeUnit;
/*     */     }
/*     */     
/*     */     private static Stream<String> getValidUnits() {
/* 715 */       return Arrays.<TimeUnit>stream(values()).flatMap(unit -> Arrays.stream(unit.descriptions));
/*     */     }
/*     */     
/*     */     private static TemporalUnit parseUnit(String unit) {
/* 719 */       if (unit != null) {
/* 720 */         for (TimeUnit value : values()) {
/* 721 */           for (String description : value.descriptions) {
/* 722 */             if (unit.equals(description)) {
/* 723 */               return value.timeUnit;
/*     */             }
/*     */           } 
/*     */         } 
/* 727 */         throw new IllegalArgumentException("Invalid duration unit '" + unit + "'");
/*     */       } 
/* 729 */       return ChronoUnit.MILLIS;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\PropertiesUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */