/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import aQute.bnd.annotation.spi.ServiceProvider;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ServiceProvider(value = PropertySource.class, resolution = "optional")
/*     */ public class SystemPropertiesPropertySource
/*     */   implements PropertySource
/*     */ {
/*  37 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */   
/*     */   private static final int DEFAULT_PRIORITY = 0;
/*     */   private static final String PREFIX = "log4j2.";
/*  41 */   private static final PropertySource INSTANCE = new SystemPropertiesPropertySource();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertySource provider() {
/*  49 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   public static String getSystemProperty(String key, String defaultValue) {
/*  53 */     String value = INSTANCE.getProperty(key);
/*  54 */     return (value != null) ? value : defaultValue;
/*     */   }
/*     */   
/*     */   private static void logException(SecurityException error) {
/*  58 */     LOGGER.error("The Java system properties are not available to Log4j due to security restrictions.", error);
/*     */   }
/*     */   
/*     */   private static void logException(SecurityException error, String key) {
/*  62 */     LOGGER.error("The Java system property {} is not available to Log4j due to security restrictions.", key, error);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPriority() {
/*  67 */     return 0;
/*     */   }
/*     */   
/*     */   public void forEach(BiConsumer<String, String> action) {
/*     */     Properties properties;
/*     */     Object[] keySet;
/*     */     try {
/*  74 */       properties = System.getProperties();
/*  75 */     } catch (SecurityException e) {
/*  76 */       logException(e);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  82 */     synchronized (properties) {
/*  83 */       keySet = properties.keySet().toArray();
/*     */     } 
/*     */ 
/*     */     
/*  87 */     for (Object key : keySet) {
/*  88 */       String keyStr = Objects.toString(key, null);
/*  89 */       action.accept(keyStr, properties.getProperty(keyStr));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence getNormalForm(Iterable<? extends CharSequence> tokens) {
/*  95 */     return "log4j2." + PropertySource.Util.joinAsCamelCase(tokens);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getPropertyNames() {
/*     */     try {
/* 101 */       return System.getProperties().stringPropertyNames();
/* 102 */     } catch (SecurityException e) {
/* 103 */       logException(e);
/*     */       
/* 105 */       return super.getPropertyNames();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getProperty(String key) {
/*     */     try {
/* 111 */       return System.getProperty(key);
/* 112 */     } catch (SecurityException e) {
/* 113 */       logException(e, key);
/*     */       
/* 115 */       return super.getProperty(key);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean containsProperty(String key) {
/* 120 */     return (getProperty(key) != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\SystemPropertiesPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */