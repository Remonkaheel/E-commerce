/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import aQute.bnd.annotation.spi.ServiceProvider;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ServiceProvider(value = PropertySource.class, resolution = "optional")
/*     */ public class EnvironmentPropertySource
/*     */   implements PropertySource
/*     */ {
/*  38 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */   
/*     */   private static final String PREFIX = "LOG4J_";
/*     */   private static final int DEFAULT_PRIORITY = 100;
/*  42 */   private static final PropertySource INSTANCE = new EnvironmentPropertySource();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertySource provider() {
/*  50 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPriority() {
/*  55 */     return 100;
/*     */   }
/*     */   
/*     */   private static void logException(SecurityException error) {
/*  59 */     LOGGER.error("The environment variables are not available to Log4j due to security restrictions.", error);
/*     */   }
/*     */   
/*     */   private static void logException(SecurityException error, String key) {
/*  63 */     LOGGER.error("The environment variable {} is not available to Log4j due to security restrictions.", key, error);
/*     */   }
/*     */ 
/*     */   
/*     */   public void forEach(BiConsumer<String, String> action) {
/*     */     Map<String, String> getenv;
/*     */     try {
/*  70 */       getenv = System.getenv();
/*  71 */     } catch (SecurityException e) {
/*  72 */       logException(e);
/*     */       return;
/*     */     } 
/*  75 */     for (Map.Entry<String, String> entry : getenv.entrySet()) {
/*  76 */       String key = entry.getKey();
/*  77 */       if (key.startsWith("LOG4J_")) {
/*  78 */         action.accept(key.substring("LOG4J_".length()), entry.getValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence getNormalForm(Iterable<? extends CharSequence> tokens) {
/*  85 */     StringBuilder sb = new StringBuilder("LOG4J");
/*  86 */     boolean empty = true;
/*  87 */     for (CharSequence token : tokens) {
/*  88 */       empty = false;
/*  89 */       sb.append('_');
/*  90 */       for (int i = 0; i < token.length(); i++) {
/*  91 */         sb.append(Character.toUpperCase(token.charAt(i)));
/*     */       }
/*     */     } 
/*  94 */     return empty ? null : sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getPropertyNames() {
/*     */     try {
/* 100 */       return System.getenv().keySet();
/* 101 */     } catch (SecurityException e) {
/* 102 */       logException(e);
/*     */       
/* 104 */       return super.getPropertyNames();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getProperty(String key) {
/*     */     try {
/* 110 */       return System.getenv(key);
/* 111 */     } catch (SecurityException e) {
/* 112 */       logException(e, key);
/*     */       
/* 114 */       return super.getProperty(key);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean containsProperty(String key) {
/*     */     try {
/* 120 */       return System.getenv().containsKey(key);
/* 121 */     } catch (SecurityException e) {
/* 122 */       logException(e, key);
/* 123 */       return super.containsProperty(key);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\EnvironmentPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */