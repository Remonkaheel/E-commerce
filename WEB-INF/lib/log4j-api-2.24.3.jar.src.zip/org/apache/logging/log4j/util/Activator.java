/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.security.Permission;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*     */ import org.apache.logging.log4j.spi.Provider;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.osgi.annotation.bundle.Header;
/*     */ import org.osgi.annotation.bundle.Headers;
/*     */ import org.osgi.framework.AdaptPermission;
/*     */ import org.osgi.framework.AdminPermission;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ import org.osgi.framework.wiring.BundleWire;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Headers({@Header(name = "Bundle-Activator", value = "${@class}"), @Header(name = "Bundle-ActivationPolicy", value = "lazy")})
/*     */ @InternalApi
/*     */ public class Activator
/*     */   implements BundleActivator, SynchronousBundleListener
/*     */ {
/*  53 */   private static final SecurityManager SECURITY_MANAGER = System.getSecurityManager();
/*     */   
/*  55 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   private boolean lockingProviderUtil;
/*     */ 
/*     */   
/*     */   private static void checkPermission(Permission permission) {
/*  62 */     if (SECURITY_MANAGER != null) {
/*  63 */       SECURITY_MANAGER.checkPermission(permission);
/*     */     }
/*     */   }
/*     */   
/*     */   private void loadProvider(Bundle bundle) {
/*  68 */     if (bundle.getState() == 1) {
/*     */       return;
/*     */     }
/*     */     try {
/*  72 */       checkPermission((Permission)new AdminPermission(bundle, "resource"));
/*  73 */       checkPermission((Permission)new AdaptPermission(BundleWiring.class.getName(), bundle, "adapt"));
/*  74 */       BundleContext bundleContext = bundle.getBundleContext();
/*  75 */       if (bundleContext == null) {
/*  76 */         LOGGER.debug("Bundle {} has no context (state={}), skipping loading provider", bundle
/*     */             
/*  78 */             .getSymbolicName(), 
/*  79 */             toStateString(bundle.getState()));
/*     */       } else {
/*  81 */         loadProvider(bundleContext, (BundleWiring)bundle.adapt(BundleWiring.class));
/*     */       } 
/*  83 */     } catch (SecurityException e) {
/*  84 */       LOGGER.debug("Cannot access bundle [{}] contents. Ignoring.", bundle.getSymbolicName(), e);
/*  85 */     } catch (Exception e) {
/*  86 */       LOGGER.warn("Problem checking bundle {} for Log4j 2 provider.", bundle.getSymbolicName(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String toStateString(int state) {
/*  91 */     switch (state) {
/*     */       case 1:
/*  93 */         return "UNINSTALLED";
/*     */       case 2:
/*  95 */         return "INSTALLED";
/*     */       case 4:
/*  97 */         return "RESOLVED";
/*     */       case 8:
/*  99 */         return "STARTING";
/*     */       case 16:
/* 101 */         return "STOPPING";
/*     */       case 32:
/* 103 */         return "ACTIVE";
/*     */     } 
/* 105 */     return Integer.toString(state);
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadProvider(BundleContext bundleContext, BundleWiring bundleWiring) {
/* 110 */     String filter = "(APIVersion>=2.6.0)";
/*     */     
/*     */     try {
/* 113 */       Collection<ServiceReference<Provider>> serviceReferences = bundleContext.getServiceReferences(Provider.class, "(APIVersion>=2.6.0)");
/* 114 */       Provider maxProvider = null;
/* 115 */       for (ServiceReference<Provider> serviceReference : serviceReferences) {
/* 116 */         Provider provider = (Provider)bundleContext.getService(serviceReference);
/* 117 */         if (maxProvider == null || provider.getPriority().intValue() > maxProvider.getPriority().intValue()) {
/* 118 */           maxProvider = provider;
/*     */         }
/*     */       } 
/* 121 */       if (maxProvider != null) {
/* 122 */         ProviderUtil.addProvider(maxProvider);
/*     */       }
/* 124 */     } catch (InvalidSyntaxException ex) {
/* 125 */       LOGGER.error("Invalid service filter: (APIVersion>=2.6.0)", (Throwable)ex);
/*     */     } 
/* 127 */     List<URL> urls = bundleWiring.findEntries("META-INF", "log4j-provider.properties", 0);
/* 128 */     for (URL url : urls) {
/* 129 */       ProviderUtil.loadProvider(url, bundleWiring.getClassLoader());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(BundleContext bundleContext) throws Exception {
/* 135 */     ProviderUtil.STARTUP_LOCK.lock();
/* 136 */     this.lockingProviderUtil = true;
/* 137 */     BundleWiring self = (BundleWiring)bundleContext.getBundle().adapt(BundleWiring.class);
/* 138 */     List<BundleWire> required = self.getRequiredWires(LoggerContextFactory.class.getName());
/* 139 */     for (BundleWire wire : required) {
/* 140 */       loadProvider(bundleContext, wire.getProviderWiring());
/*     */     }
/* 142 */     bundleContext.addBundleListener((BundleListener)this);
/* 143 */     Bundle[] bundles = bundleContext.getBundles();
/* 144 */     for (Bundle bundle : bundles) {
/* 145 */       loadProvider(bundle);
/*     */     }
/* 147 */     unlockIfReady();
/*     */   }
/*     */   
/*     */   private void unlockIfReady() {
/* 151 */     if (this.lockingProviderUtil && !ProviderUtil.PROVIDERS.isEmpty()) {
/* 152 */       ProviderUtil.STARTUP_LOCK.unlock();
/* 153 */       this.lockingProviderUtil = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(BundleContext bundleContext) throws Exception {
/* 159 */     bundleContext.removeBundleListener((BundleListener)this);
/* 160 */     unlockIfReady();
/*     */   }
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 165 */     switch (event.getType()) {
/*     */       case 2:
/* 167 */         loadProvider(event.getBundle());
/* 168 */         unlockIfReady();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Activator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */