/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import aQute.bnd.annotation.baseline.BaselineIgnore;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.ServiceConfigurationError;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.Spliterators;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ @BaselineIgnore("2.24.0")
/*     */ public final class ServiceLoaderUtil
/*     */ {
/*     */   private static final int MAX_BROKEN_SERVICES = 8;
/*     */   
/*     */   public static <S> Stream<S> safeStream(Class<S> serviceType, ServiceLoader<? extends S> serviceLoader, Logger logger) {
/*  73 */     Objects.requireNonNull(serviceLoader, "serviceLoader");
/*  74 */     Collection<Class<?>> classes = new HashSet<>();
/*     */     
/*  76 */     Stream<S> services = StreamSupport.stream(new ServiceLoaderSpliterator<>(serviceType, serviceLoader, logger), false);
/*     */     
/*  78 */     Class<?> callerClass = StackLocatorUtil.getCallerClass(2);
/*     */ 
/*     */     
/*  81 */     Stream<S> allServices = (OsgiServiceLocator.isAvailable() && callerClass != null) ? Stream.<S>concat(services, OsgiServiceLocator.loadServices(serviceType, callerClass, logger)) : services;
/*  82 */     return allServices
/*     */       
/*  84 */       .filter(service -> classes.add(service.getClass()));
/*     */   }
/*     */   
/*     */   private static final class ServiceLoaderSpliterator<S>
/*     */     extends Spliterators.AbstractSpliterator<S> {
/*     */     private final String serviceName;
/*     */     private final Iterator<? extends S> serviceIterator;
/*     */     private final Logger logger;
/*     */     
/*     */     private ServiceLoaderSpliterator(Class<S> serviceType, Iterable<? extends S> serviceLoader, Logger logger) {
/*  94 */       super(Long.MAX_VALUE, 1296);
/*  95 */       this.serviceName = serviceType.getName();
/*  96 */       this.serviceIterator = serviceLoader.iterator();
/*  97 */       this.logger = logger;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean tryAdvance(Consumer<? super S> action) {
/* 102 */       int i = 8;
/* 103 */       while (i-- > 0) {
/*     */         try {
/* 105 */           if (this.serviceIterator.hasNext()) {
/* 106 */             action.accept(this.serviceIterator.next());
/* 107 */             return true;
/*     */           } 
/* 109 */         } catch (ServiceConfigurationError|LinkageError e) {
/* 110 */           this.logger.warn("Unable to load implementation for service {}", this.serviceName, e);
/* 111 */         } catch (Exception e) {
/* 112 */           this.logger.warn("Unexpected exception  while loading implementation for service {}", this.serviceName, e);
/* 113 */           throw e;
/*     */         } 
/*     */       } 
/* 116 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\ServiceLoaderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */