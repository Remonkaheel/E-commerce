package org.apache.logging.log4j.util;

import org.osgi.annotation.bundle.Export;
import org.osgi.annotation.versioning.Version;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */