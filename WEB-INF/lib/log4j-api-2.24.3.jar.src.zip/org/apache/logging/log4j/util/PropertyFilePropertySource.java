/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.status.StatusLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyFilePropertySource
/*    */   extends PropertiesPropertySource
/*    */ {
/* 34 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*    */   
/*    */   public PropertyFilePropertySource(String fileName) {
/* 37 */     this(fileName, true);
/*    */   }
/*    */   
/*    */   public PropertyFilePropertySource(String fileName, boolean useTccl) {
/* 41 */     super(loadPropertiesFile(fileName, useTccl));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressFBWarnings(value = {"URLCONNECTION_SSRF_FD"}, justification = "This property source should only be used with hardcoded file names.")
/*    */   private static Properties loadPropertiesFile(String fileName, boolean useTccl) {
/* 48 */     Properties props = new Properties();
/* 49 */     for (URL url : LoaderUtil.findResources(fileName, useTccl)) { 
/* 50 */       try { InputStream in = url.openStream(); 
/* 51 */         try { props.load(in);
/* 52 */           if (in != null) in.close();  } catch (Throwable throwable) { if (in != null) try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException error)
/* 53 */       { LOGGER.error("Unable to read URL `{}`", url, error); }
/*    */        }
/*    */     
/* 56 */     return props;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\PropertyFilePropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */