/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessIdUtil
/*    */ {
/*    */   public static final String DEFAULT_PROCESSID = "-";
/*    */   
/*    */   public static String getProcessId() {
/*    */     try {
/* 36 */       Class<?> managementFactoryClass = Class.forName("java.lang.management.ManagementFactory");
/* 37 */       Method getRuntimeMXBean = managementFactoryClass.getDeclaredMethod("getRuntimeMXBean", new Class[0]);
/* 38 */       Class<?> runtimeMXBeanClass = Class.forName("java.lang.management.RuntimeMXBean");
/* 39 */       Method getName = runtimeMXBeanClass.getDeclaredMethod("getName", new Class[0]);
/*    */       
/* 41 */       Object runtimeMXBean = getRuntimeMXBean.invoke(null, new Object[0]);
/* 42 */       String name = (String)getName.invoke(runtimeMXBean, new Object[0]);
/*    */       
/* 44 */       return name.split("@", 2)[0];
/* 45 */     } catch (Exception ex) {
/*    */       try {
/* 47 */         return (new File("/proc/self")).getCanonicalFile().getName();
/* 48 */       } catch (IOException iOException) {
/*    */ 
/*    */ 
/*    */         
/* 52 */         return "-";
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\ProcessIdUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */