/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ import java.util.function.BooleanSupplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LazyBoolean
/*    */   implements BooleanSupplier
/*    */ {
/*    */   private final BooleanSupplier supplier;
/* 25 */   private final Lock lock = new ReentrantLock();
/*    */   private volatile boolean initialized;
/*    */   private volatile boolean value;
/*    */   
/*    */   public LazyBoolean(BooleanSupplier supplier) {
/* 30 */     this.supplier = supplier;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getAsBoolean() {
/* 35 */     boolean uninitialized = !this.initialized;
/* 36 */     boolean value = this.value;
/* 37 */     if (uninitialized) {
/* 38 */       this.lock.lock();
/*    */       try {
/* 40 */         uninitialized = !this.initialized;
/* 41 */         if (uninitialized) {
/* 42 */           this.value = value = this.supplier.getAsBoolean();
/* 43 */           this.initialized = true;
/*    */         } 
/*    */       } finally {
/* 46 */         this.lock.unlock();
/*    */       } 
/*    */     } 
/* 49 */     return value;
/*    */   }
/*    */   
/*    */   public void setAsBoolean(boolean b) {
/* 53 */     this.lock.lock();
/*    */     try {
/* 55 */       this.initialized = false;
/* 56 */       this.value = b;
/* 57 */       this.initialized = true;
/*    */     } finally {
/* 59 */       this.lock.unlock();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void reset() {
/* 64 */     this.initialized = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\LazyBoolean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */