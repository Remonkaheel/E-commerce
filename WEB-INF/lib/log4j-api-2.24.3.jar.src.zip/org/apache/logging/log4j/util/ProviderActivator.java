/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import org.apache.logging.log4j.spi.Provider;
/*    */ import org.osgi.framework.BundleActivator;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ProviderActivator
/*    */   implements BundleActivator
/*    */ {
/*    */   public static final String API_VERSION = "APIVersion";
/*    */   private final Provider provider;
/* 33 */   private ServiceRegistration<Provider> providerRegistration = null;
/*    */   
/*    */   protected ProviderActivator(Provider provider) {
/* 36 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void start(BundleContext context) throws Exception {
/* 42 */     Hashtable<String, String> props = new Hashtable<>();
/* 43 */     props.put("APIVersion", this.provider.getVersions());
/* 44 */     this.providerRegistration = context.registerService(Provider.class, this.provider, props);
/*    */   }
/*    */ 
/*    */   
/*    */   public void stop(BundleContext context) throws Exception {
/* 49 */     if (this.providerRegistration != null)
/* 50 */       this.providerRegistration.unregister(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\ProviderActivator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */