/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PropertySource
/*     */ {
/*     */   int getPriority();
/*     */   
/*     */   default void forEach(BiConsumer<String, String> action) {}
/*     */   
/*     */   default Collection<String> getPropertyNames() {
/*  61 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default CharSequence getNormalForm(Iterable<? extends CharSequence> tokens) {
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getProperty(String key) {
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean containsProperty(String key) {
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Comparator
/*     */     implements java.util.Comparator<PropertySource>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 103 */     static final Comparator INSTANCE = new Comparator();
/*     */ 
/*     */     
/*     */     public int compare(PropertySource o1, PropertySource o2) {
/* 107 */       return Integer.compare((
/* 108 */           (PropertySource)Objects.<PropertySource>requireNonNull(o1)).getPriority(), (
/* 109 */           (PropertySource)Objects.<PropertySource>requireNonNull(o2)).getPriority());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Util
/*     */   {
/* 119 */     private static final Pattern PREFIX_PATTERN = Pattern.compile("(^log4j2?[-._/]?|^org\\.apache\\.logging\\.log4j\\.)|(?=AsyncLogger(Config)?\\.)", 2);
/*     */ 
/*     */ 
/*     */     
/* 123 */     private static final Pattern PROPERTY_TOKENIZER = Pattern.compile("([A-Z]*[a-z0-9]+|[A-Z0-9]+)[-._/]?");
/* 124 */     private static final Map<CharSequence, List<CharSequence>> CACHE = new ConcurrentHashMap<>();
/*     */ 
/*     */     
/*     */     static {
/* 128 */       CACHE.put("disableThreadContext", Arrays.asList(new CharSequence[] { "disable", "thread", "context" }));
/* 129 */       CACHE.put("disableThreadContextStack", Arrays.asList(new CharSequence[] { "disable", "thread", "context", "stack" }));
/* 130 */       CACHE.put("disableThreadContextMap", Arrays.asList(new CharSequence[] { "disable", "thread", "context", "map" }));
/* 131 */       CACHE.put("isThreadContextMapInheritable", Arrays.asList(new CharSequence[] { "is", "thread", "context", "map", "inheritable" }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static List<CharSequence> tokenize(CharSequence value) {
/* 147 */       if (CACHE.containsKey(value.toString())) {
/* 148 */         return CACHE.get(value.toString());
/*     */       }
/* 150 */       List<CharSequence> tokens = new ArrayList<>();
/* 151 */       int start = 0;
/* 152 */       Matcher prefixMatcher = PREFIX_PATTERN.matcher(value);
/* 153 */       if (prefixMatcher.find(start)) {
/* 154 */         start = prefixMatcher.end();
/* 155 */         Matcher matcher = PROPERTY_TOKENIZER.matcher(value);
/* 156 */         while (matcher.find(start)) {
/* 157 */           tokens.add(Strings.toRootLowerCase(matcher.group(1)));
/* 158 */           start = matcher.end();
/*     */         } 
/*     */       } 
/* 161 */       CACHE.put(value, tokens);
/* 162 */       return tokens;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static CharSequence joinAsCamelCase(Iterable<? extends CharSequence> tokens) {
/* 172 */       StringBuilder sb = new StringBuilder();
/* 173 */       boolean first = true;
/* 174 */       for (CharSequence token : tokens) {
/* 175 */         if (first) {
/* 176 */           sb.append(token);
/*     */         } else {
/* 178 */           sb.append(Character.toUpperCase(token.charAt(0)));
/* 179 */           if (token.length() > 1) {
/* 180 */             sb.append(token.subSequence(1, token.length()));
/*     */           }
/*     */         } 
/* 183 */         first = false;
/*     */       } 
/* 185 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\PropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */