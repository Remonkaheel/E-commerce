/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ public final class LoaderUtil
/*     */ {
/*  44 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String IGNORE_TCCL_PROPERTY = "log4j.ignoreTCL";
/*     */ 
/*     */ 
/*     */   
/*     */   private static Boolean ignoreTCCL;
/*     */ 
/*     */ 
/*     */   
/*  57 */   static final RuntimePermission GET_CLASS_LOADER = new RuntimePermission("getClassLoader");
/*  58 */   static final LazyBoolean GET_CLASS_LOADER_DISABLED = new LazyBoolean(() -> {
/*     */         if (System.getSecurityManager() == null) {
/*     */           return false;
/*     */         }
/*     */         
/*     */         try {
/*     */           AccessController.checkPermission(GET_CLASS_LOADER);
/*     */           return false;
/*  66 */         } catch (SecurityException ignored) {
/*     */           try {
/*     */             AccessController.doPrivileged(());
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return false;
/*  74 */           } catch (SecurityException ignore) {
/*     */             return true;
/*     */           } 
/*     */         } 
/*     */       });
/*     */ 
/*     */   
/*  81 */   private static final PrivilegedAction<ClassLoader> TCCL_GETTER = new ThreadContextClassLoaderGetter();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getClassLoader() {
/*  91 */     return getClassLoader(LoaderUtil.class, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ClassLoader getClassLoader(Class<?> class1, Class<?> class2) {
/*  96 */     PrivilegedAction<ClassLoader> action = () -> {
/*     */         ClassLoader loader1 = (class1 == null) ? null : class1.getClassLoader();
/*     */ 
/*     */         
/*     */         ClassLoader loader2 = (class2 == null) ? null : class2.getClassLoader();
/*     */         
/*     */         ClassLoader referenceLoader = GET_CLASS_LOADER_DISABLED.getAsBoolean() ? getThisClassLoader() : Thread.currentThread().getContextClassLoader();
/*     */         
/*     */         return isChild(referenceLoader, loader1) ? (isChild(referenceLoader, loader2) ? referenceLoader : loader2) : (isChild(loader1, loader2) ? loader1 : loader2);
/*     */       };
/*     */     
/* 107 */     return runPrivileged(action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isChild(ClassLoader loader1, ClassLoader loader2) {
/* 119 */     if (loader1 != null && loader2 != null) {
/* 120 */       ClassLoader parent = loader1.getParent();
/* 121 */       while (parent != null && parent != loader2) {
/* 122 */         parent = parent.getParent();
/*     */       }
/*     */       
/* 125 */       return (parent != null);
/*     */     } 
/* 127 */     return (loader1 != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getThreadContextClassLoader() {
/*     */     try {
/* 143 */       return GET_CLASS_LOADER_DISABLED.getAsBoolean() ? getThisClassLoader() : runPrivileged(TCCL_GETTER);
/* 144 */     } catch (SecurityException ignored) {
/* 145 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static ClassLoader getThisClassLoader() {
/* 150 */     return LoaderUtil.class.getClassLoader();
/*     */   }
/*     */   
/*     */   private static <T> T runPrivileged(PrivilegedAction<T> action) {
/* 154 */     return (System.getSecurityManager() != null) ? AccessController.<T>doPrivileged(action) : action.run();
/*     */   }
/*     */   
/*     */   private static class ThreadContextClassLoaderGetter
/*     */     implements PrivilegedAction<ClassLoader> {
/*     */     public ClassLoader run() {
/* 160 */       ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/* 161 */       if (contextClassLoader != null) {
/* 162 */         return contextClassLoader;
/*     */       }
/* 164 */       ClassLoader thisClassLoader = LoaderUtil.getThisClassLoader();
/* 165 */       if (thisClassLoader != null || LoaderUtil.GET_CLASS_LOADER_DISABLED.getAsBoolean()) {
/* 166 */         return thisClassLoader;
/*     */       }
/* 168 */       return ClassLoader.getSystemClassLoader();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ThreadContextClassLoaderGetter() {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isClassAvailable(String className) {
/*     */     try {
/* 181 */       loadClass(className);
/* 182 */       return true;
/* 183 */     } catch (ClassNotFoundException|LinkageError e) {
/* 184 */       return false;
/* 185 */     } catch (Throwable error) {
/* 186 */       LOGGER.error("Unknown error while checking existence of class `{}`", className, error);
/* 187 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String className) throws ClassNotFoundException {
/* 203 */     ClassLoader classLoader = isIgnoreTccl() ? getThisClassLoader() : getThreadContextClassLoader();
/* 204 */     if (classLoader == null) {
/* 205 */       classLoader = getThisClassLoader();
/*     */     }
/* 207 */     return Class.forName(className, true, classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClassUnchecked(String className) {
/*     */     try {
/* 224 */       return loadClass(className);
/* 225 */     } catch (ClassNotFoundException e) {
/* 226 */       NoClassDefFoundError error = new NoClassDefFoundError(e.getMessage());
/* 227 */       error.initCause(e);
/* 228 */       throw error;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOf(Class<T> clazz) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
/* 248 */     Constructor<T> constructor = clazz.getDeclaredConstructor(new Class[0]);
/* 249 */     return constructor.newInstance(new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOfUnchecked(Class<T> clazz) {
/*     */     try {
/* 268 */       return newInstanceOf(clazz);
/* 269 */     } catch (NoSuchMethodException e) {
/* 270 */       NoSuchMethodError error = new NoSuchMethodError(e.getMessage());
/* 271 */       error.initCause(e);
/* 272 */       throw error;
/* 273 */     } catch (InvocationTargetException e) {
/* 274 */       Throwable cause = e.getCause();
/* 275 */       throw new InternalException(cause);
/* 276 */     } catch (InstantiationException e) {
/* 277 */       InstantiationError error = new InstantiationError(e.getMessage());
/* 278 */       error.initCause(e);
/* 279 */       throw error;
/* 280 */     } catch (IllegalAccessException e) {
/* 281 */       IllegalAccessError error = new IllegalAccessError(e.getMessage());
/* 282 */       error.initCause(e);
/* 283 */       throw error;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOf(String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException {
/* 307 */     Class<T> clazz = Cast.<Class<T>>cast(loadClass(className));
/* 308 */     return newInstanceOf(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newCheckedInstanceOfProperty(String propertyName, Class<T> clazz) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
/* 332 */     return newCheckedInstanceOfProperty(propertyName, clazz, () -> null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newCheckedInstanceOfProperty(String propertyName, Class<T> clazz, Supplier<T> defaultSupplier) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
/* 358 */     String className = PropertiesUtil.getProperties().getStringProperty(propertyName);
/* 359 */     if (className == null) {
/* 360 */       return defaultSupplier.get();
/*     */     }
/* 362 */     return newCheckedInstanceOf(className, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOfUnchecked(String className) {
/* 384 */     Class<T> clazz = Cast.<Class<T>>cast(loadClassUnchecked(className));
/* 385 */     return newInstanceOfUnchecked(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newCheckedInstanceOf(String className, Class<T> clazz) throws ClassNotFoundException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
/* 409 */     return newInstanceOf((Class)loadClass(className).asSubclass(clazz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOfUnchecked(String className, Class<T> supertype) {
/* 432 */     Class<? extends T> clazz = loadClassUnchecked(className).asSubclass(supertype);
/* 433 */     return newInstanceOfUnchecked((Class)clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isIgnoreTccl() {
/* 438 */     if (ignoreTCCL == null) {
/* 439 */       String ignoreTccl = PropertiesUtil.getProperties().getStringProperty("log4j.ignoreTCL", null);
/* 440 */       ignoreTCCL = Boolean.valueOf((ignoreTccl != null && !"false".equalsIgnoreCase(ignoreTccl.trim())));
/*     */     } 
/* 442 */     return ignoreTCCL.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<URL> findResources(String resource) {
/* 453 */     return findResources(resource, true);
/*     */   }
/*     */   
/*     */   static Collection<URL> findResources(String resource, boolean useTccl) {
/* 457 */     Collection<UrlResource> urlResources = findUrlResources(resource, useTccl);
/* 458 */     Collection<URL> resources = new LinkedHashSet<>(urlResources.size());
/* 459 */     for (UrlResource urlResource : urlResources) {
/* 460 */       resources.add(urlResource.getUrl());
/*     */     }
/* 462 */     return resources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Collection<UrlResource> findUrlResources(String resource, boolean useTccl) {
/* 470 */     ClassLoader[] candidates = { useTccl ? getThreadContextClassLoader() : null, LoaderUtil.class.getClassLoader(), GET_CLASS_LOADER_DISABLED.getAsBoolean() ? null : ClassLoader.getSystemClassLoader() };
/*     */ 
/*     */     
/* 473 */     Collection<UrlResource> resources = new LinkedHashSet<>();
/* 474 */     for (ClassLoader cl : candidates) {
/* 475 */       if (cl != null) {
/*     */         try {
/* 477 */           Enumeration<URL> resourceEnum = cl.getResources(resource);
/* 478 */           while (resourceEnum.hasMoreElements()) {
/* 479 */             resources.add(new UrlResource(cl, resourceEnum.nextElement()));
/*     */           }
/* 481 */         } catch (IOException error) {
/* 482 */           LOGGER.error("failed to collect resources of name `{}`", resource, error);
/*     */         } 
/*     */       }
/*     */     } 
/* 486 */     return resources;
/*     */   }
/*     */ 
/*     */   
/*     */   static class UrlResource
/*     */   {
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */     private final URL url;
/*     */     
/*     */     UrlResource(ClassLoader classLoader, URL url) {
/* 497 */       this.classLoader = classLoader;
/* 498 */       this.url = url;
/*     */     }
/*     */     
/*     */     public ClassLoader getClassLoader() {
/* 502 */       return this.classLoader;
/*     */     }
/*     */     
/*     */     public URL getUrl() {
/* 506 */       return this.url;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 511 */       if (this == o) {
/* 512 */         return true;
/*     */       }
/* 514 */       if (!(o instanceof UrlResource)) {
/* 515 */         return false;
/*     */       }
/*     */       
/* 518 */       UrlResource that = (UrlResource)o;
/*     */       
/* 520 */       return (Objects.equals(this.classLoader, that.classLoader) && Objects.equals(this.url, that.url));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 525 */       return Objects.hashCode(this.classLoader) + Objects.hashCode(this.url);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\LoaderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */