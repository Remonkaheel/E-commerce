/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.apache.logging.log4j.util.internal.SerializationUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilteredObjectInputStream
/*    */   extends ObjectInputStream
/*    */ {
/*    */   private final Collection<String> allowedExtraClasses;
/*    */   
/*    */   public FilteredObjectInputStream() throws IOException, SecurityException {
/* 42 */     this.allowedExtraClasses = Collections.emptySet();
/*    */   }
/*    */   
/*    */   public FilteredObjectInputStream(InputStream inputStream) throws IOException {
/* 46 */     super(inputStream);
/* 47 */     this.allowedExtraClasses = Collections.emptySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public FilteredObjectInputStream(Collection<String> allowedExtraClasses) throws IOException, SecurityException {
/* 52 */     this.allowedExtraClasses = allowedExtraClasses;
/*    */   }
/*    */ 
/*    */   
/*    */   public FilteredObjectInputStream(InputStream inputStream, Collection<String> allowedExtraClasses) throws IOException {
/* 57 */     super(inputStream);
/* 58 */     this.allowedExtraClasses = allowedExtraClasses;
/*    */   }
/*    */   
/*    */   public Collection<String> getAllowedClasses() {
/* 62 */     return this.allowedExtraClasses;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException {
/* 67 */     String name = SerializationUtil.stripArray(desc.getName());
/* 68 */     if (!isAllowedByDefault(name) && !this.allowedExtraClasses.contains(name)) {
/* 69 */       throw new InvalidObjectException("Class is not allowed for deserialization: " + name);
/*    */     }
/* 71 */     return super.resolveClass(desc);
/*    */   }
/*    */   
/*    */   private static boolean isAllowedByDefault(String name) {
/* 75 */     return (isRequiredPackage(name) || SerializationUtil.REQUIRED_JAVA_CLASSES.contains(name));
/*    */   }
/*    */   
/*    */   private static boolean isRequiredPackage(String name) {
/* 79 */     for (String packageName : SerializationUtil.REQUIRED_JAVA_PACKAGES) {
/* 80 */       if (name.startsWith(packageName)) {
/* 81 */         return true;
/*    */       }
/*    */     } 
/* 84 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\FilteredObjectInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */