/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import org.apache.logging.log4j.message.Message;
/*    */ import org.apache.logging.log4j.message.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LambdaUtil
/*    */ {
/*    */   public static Object[] getAll(Supplier<?>... suppliers) {
/* 39 */     if (suppliers == null) {
/* 40 */       return null;
/*    */     }
/* 42 */     Object[] result = new Object[suppliers.length];
/* 43 */     for (int i = 0; i < result.length; i++) {
/* 44 */       result[i] = get(suppliers[i]);
/*    */     }
/* 46 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object get(Supplier<?> supplier) {
/* 57 */     if (supplier == null) {
/* 58 */       return null;
/*    */     }
/* 60 */     Object result = supplier.get();
/* 61 */     return (result instanceof Message) ? ((Message)result).getFormattedMessage() : result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Message get(MessageSupplier supplier) {
/* 71 */     if (supplier == null) {
/* 72 */       return null;
/*    */     }
/* 74 */     return supplier.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Message getMessage(Supplier<?> supplier, MessageFactory messageFactory) {
/* 85 */     if (supplier == null) {
/* 86 */       return null;
/*    */     }
/* 88 */     Object result = supplier.get();
/* 89 */     return (result instanceof Message) ? (Message)result : messageFactory.newMessage(result);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\LambdaUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */