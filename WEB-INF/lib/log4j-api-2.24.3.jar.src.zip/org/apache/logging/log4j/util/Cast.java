/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @InternalApi
/*    */ public final class Cast
/*    */ {
/*    */   public static <T> T cast(Object o) {
/* 31 */     if (o == null) {
/* 32 */       return null;
/*    */     }
/*    */     
/* 35 */     T t = (T)o;
/* 36 */     return t;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Cast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */