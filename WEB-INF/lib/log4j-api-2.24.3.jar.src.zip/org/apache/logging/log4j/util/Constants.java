/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Constants
/*     */ {
/*  44 */   public static final boolean IS_WEB_APP = PropertiesUtil.getProperties()
/*  45 */     .getBooleanProperty("log4j2.is.webapp", (
/*     */       
/*  47 */       isClassAvailable("javax.servlet.Servlet") || isClassAvailable("jakarta.servlet.Servlet")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final boolean ENABLE_THREADLOCALS = PropertiesUtil.getProperties().getBooleanProperty("log4j2.enable.threadlocals", !IS_WEB_APP);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final int JAVA_MAJOR_VERSION = getMajorVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public static final int MAX_REUSABLE_MESSAGE_SIZE = size("log4j.maxReusableMsgSize", 518);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOG4J2_DEBUG = "log4j2.debug";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int size(String property, int defaultValue) {
/*  96 */     return PropertiesUtil.getProperties().getIntegerProperty(property, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isClassAvailable(String className) {
/*     */     try {
/* 107 */       return (LoaderUtil.loadClass(className) != null);
/* 108 */     } catch (Throwable e) {
/* 109 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getMajorVersion() {
/* 129 */     return getMajorVersion(System.getProperty("java.version"));
/*     */   }
/*     */ 
/*     */   
/*     */   static int getMajorVersion(String version) {
/* 134 */     String[] parts = version.split("-|\\.", 3);
/*     */     
/*     */     try {
/* 137 */       int token = Integer.parseInt(parts[0]);
/* 138 */       boolean isJEP223 = (token != 1);
/* 139 */       if (isJEP223) {
/* 140 */         return token;
/*     */       }
/* 142 */       return Integer.parseInt(parts[1]);
/* 143 */     } catch (Exception ex) {
/* 144 */       return 0;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */