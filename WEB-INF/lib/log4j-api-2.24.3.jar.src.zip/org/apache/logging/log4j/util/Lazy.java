/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Lazy<T>
/*    */   extends Supplier<T>
/*    */ {
/*    */   default T get() {
/* 39 */     return value();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default <R> Lazy<R> map(Function<? super T, ? extends R> function) {
/* 46 */     return lazy(() -> function.apply(value()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Lazy<T> lazy(Supplier<T> supplier) {
/* 66 */     Objects.requireNonNull(supplier);
/* 67 */     return new LazyUtil.SafeLazy<>(supplier);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Lazy<T> value(T value) {
/* 74 */     return new LazyUtil.Constant<>(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Lazy<T> weak(T value) {
/* 81 */     return new LazyUtil.WeakConstant<>(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Lazy<T> pure(Supplier<T> supplier) {
/* 90 */     Objects.requireNonNull(supplier);
/* 91 */     return new LazyUtil.PureLazy<>(supplier);
/*    */   }
/*    */   
/*    */   T value();
/*    */   
/*    */   boolean isInitialized();
/*    */   
/*    */   void set(T paramT);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Lazy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */