/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.ArrayDeque;
/*    */ import java.util.Collections;
/*    */ import java.util.Deque;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PrivateSecurityManagerStackTraceUtil
/*    */ {
/*    */   private static final PrivateSecurityManager SECURITY_MANAGER;
/*    */   
/*    */   static {
/*    */     PrivateSecurityManager psm;
/*    */     try {
/* 34 */       SecurityManager sm = System.getSecurityManager();
/* 35 */       if (sm != null) {
/* 36 */         sm.checkPermission(new RuntimePermission("createSecurityManager"));
/*    */       }
/* 38 */       psm = new PrivateSecurityManager();
/* 39 */     } catch (SecurityException ignored) {
/* 40 */       psm = null;
/*    */     } 
/*    */     
/* 43 */     SECURITY_MANAGER = psm;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean isEnabled() {
/* 51 */     return (SECURITY_MANAGER != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Deque<Class<?>> getCurrentStackTrace() {
/* 66 */     Class<?>[] array = SECURITY_MANAGER.getClassContext();
/* 67 */     Deque<Class<?>> classes = new ArrayDeque<>(array.length);
/* 68 */     Collections.addAll(classes, array);
/* 69 */     return classes;
/*    */   }
/*    */   
/*    */   private static final class PrivateSecurityManager extends SecurityManager {
/*    */     private PrivateSecurityManager() {}
/*    */     
/*    */     protected Class<?>[] getClassContext() {
/* 76 */       return super.getClassContext();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\PrivateSecurityManagerStackTraceUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */