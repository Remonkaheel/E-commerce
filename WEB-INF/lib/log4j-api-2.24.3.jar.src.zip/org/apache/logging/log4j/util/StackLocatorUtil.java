/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.util.Deque;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ public final class StackLocatorUtil
/*     */ {
/*  29 */   private static StackLocator stackLocator = null;
/*     */   private static volatile boolean errorLogged;
/*     */   
/*     */   static {
/*  33 */     stackLocator = StackLocator.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static Class<?> getCallerClass(int depth) {
/*  44 */     return stackLocator.getCallerClass(depth + 1);
/*     */   }
/*     */   
/*     */   public static StackTraceElement getStackTraceElement(int depth) {
/*  48 */     return stackLocator.getStackTraceElement(depth + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static Class<?> getCallerClass(String fqcn) {
/*  57 */     return getCallerClass(fqcn, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static Class<?> getCallerClass(String fqcn, String pkg) {
/*  69 */     return stackLocator.getCallerClass(fqcn, pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static ClassLoader getCallerClassLoader(int depth) {
/*  90 */     Class<?> callerClass = stackLocator.getCallerClass(depth + 1);
/*  91 */     return (callerClass != null) ? callerClass.getClassLoader() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static Class<?> getCallerClass(Class<?> sentinelClass, Predicate<Class<?>> callerPredicate) {
/* 103 */     return stackLocator.getCallerClass(sentinelClass, callerPredicate);
/*     */   }
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static Class<?> getCallerClass(Class<?> anchor) {
/* 109 */     return stackLocator.getCallerClass(anchor);
/*     */   }
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public static Deque<Class<?>> getCurrentStackTrace() {
/* 115 */     return stackLocator.getCurrentStackTrace();
/*     */   }
/*     */   
/*     */   public static StackTraceElement calcLocation(String fqcnOfLogger) {
/*     */     try {
/* 120 */       return stackLocator.calcLocation(fqcnOfLogger);
/* 121 */     } catch (NoSuchElementException ex) {
/* 122 */       if (!errorLogged) {
/* 123 */         errorLogged = true;
/* 124 */         StatusLogger.getLogger().warn("Unable to locate stack trace element for {}", fqcnOfLogger, ex);
/*     */       } 
/* 126 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\StackLocatorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */