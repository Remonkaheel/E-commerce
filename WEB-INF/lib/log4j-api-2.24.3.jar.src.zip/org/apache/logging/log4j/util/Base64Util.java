/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.nio.charset.Charset;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.LoggingException;
/*    */ import org.apache.logging.log4j.status.StatusLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Base64Util
/*    */ {
/* 31 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*    */   
/* 33 */   private static Method encodeMethod = null;
/* 34 */   private static Object encoder = null;
/*    */   
/*    */   static {
/*    */     try {
/* 38 */       Class<?> clazz = LoaderUtil.loadClass("java.util.Base64");
/* 39 */       Class<?> encoderClazz = LoaderUtil.loadClass("java.util.Base64$Encoder");
/* 40 */       Method method = clazz.getMethod("getEncoder", new Class[0]);
/* 41 */       encoder = method.invoke(null, new Object[0]);
/* 42 */       encodeMethod = encoderClazz.getMethod("encodeToString", new Class[] { byte[].class });
/* 43 */     } catch (Exception ex) {
/*    */       try {
/* 45 */         Class<?> clazz = LoaderUtil.loadClass("javax.xml.bind.DataTypeConverter");
/* 46 */         encodeMethod = clazz.getMethod("printBase64Binary", new Class[0]);
/* 47 */       } catch (Exception ex2) {
/* 48 */         LOGGER.error("Unable to create a Base64 Encoder", ex2);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static String encode(String str) {
/* 60 */     if (str == null) {
/* 61 */       return null;
/*    */     }
/* 63 */     byte[] data = str.getBytes(Charset.defaultCharset());
/* 64 */     if (encodeMethod != null) {
/*    */       try {
/* 66 */         return (String)encodeMethod.invoke(encoder, new Object[] { data });
/* 67 */       } catch (Exception ex) {
/* 68 */         throw new LoggingException("Unable to encode String", ex);
/*    */       } 
/*    */     }
/* 71 */     throw new LoggingException("No Encoder, unable to encode string");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Base64Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */