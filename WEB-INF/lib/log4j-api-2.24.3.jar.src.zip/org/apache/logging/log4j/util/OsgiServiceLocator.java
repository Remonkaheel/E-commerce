/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OsgiServiceLocator
/*     */ {
/*  31 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */   
/*  33 */   private static final boolean OSGI_AVAILABLE = checkOsgiAvailable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean checkOsgiAvailable() {
/*     */     try {
/*  41 */       Class<?> clazz = Class.forName("org.osgi.framework.FrameworkUtil"); return 
/*  42 */         (clazz.getMethod("getBundle", new Class[] { Class.class }).invoke(null, new Object[] { OsgiServiceLocator.class }) != null);
/*  43 */     } catch (ClassNotFoundException|NoSuchMethodException|LinkageError e) {
/*  44 */       return false;
/*  45 */     } catch (Throwable error) {
/*  46 */       LOGGER.error("Unknown error checking OSGI environment.", error);
/*  47 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isAvailable() {
/*  52 */     return OSGI_AVAILABLE;
/*     */   }
/*     */   
/*     */   public static <T> Stream<T> loadServices(Class<T> serviceType, MethodHandles.Lookup lookup) {
/*  56 */     return loadServices(serviceType, lookup, true);
/*     */   }
/*     */   
/*     */   public static <T> Stream<T> loadServices(Class<T> serviceType, MethodHandles.Lookup lookup, boolean verbose) {
/*  60 */     Class<?> lookupClass = ((MethodHandles.Lookup)Objects.<MethodHandles.Lookup>requireNonNull(lookup, "lookup")).lookupClass();
/*  61 */     return loadServices(serviceType, lookupClass, (Logger)StatusLogger.getLogger());
/*     */   }
/*     */   
/*     */   static <T> Stream<T> loadServices(Class<T> serviceType, Class<?> callerClass, Logger logger) {
/*  65 */     Bundle bundle = FrameworkUtil.getBundle(callerClass);
/*  66 */     if (bundle != null && !isFragment(bundle)) {
/*  67 */       BundleContext ctx = bundle.getBundleContext();
/*  68 */       if (ctx == null) {
/*     */ 
/*     */         
/*  71 */         Objects.requireNonNull(serviceType); (new Supplier[3])[0] = serviceType::getName;
/*  72 */         Objects.requireNonNull(bundle); logger.warn("Unable to load OSGi services for service {}: bundle {} (state {}) does not have a valid BundleContext", new Supplier[] { null, bundle::getSymbolicName, () -> {
/*     */                 switch (bundle.getState()) {
/*     */                   case 1:
/*     */                     return "UNINSTALLED";
/*     */                   
/*     */                   case 2:
/*     */                     return "INSTALLED";
/*     */                   
/*     */                   case 4:
/*     */                     return "RESOLVED";
/*     */                   
/*     */                   case 8:
/*     */                     return "STARTING";
/*     */                   case 16:
/*     */                     return "STOPPING";
/*     */                   case 32:
/*     */                     return "ACTIVE";
/*     */                 } 
/*     */                 return "UNKNOWN";
/*     */               } });
/*     */       } else {
/*     */         try {
/*  94 */           Objects.requireNonNull(ctx); return ctx.getServiceReferences(serviceType, null).stream().map(ctx::getService);
/*  95 */         } catch (Exception e) {
/*  96 */           logger.error("Unable to load OSGI services for service {}", serviceType, e);
/*     */         } 
/*     */       } 
/*     */     } 
/* 100 */     return Stream.empty();
/*     */   }
/*     */   
/*     */   private static boolean isFragment(Bundle bundle) {
/*     */     try {
/* 105 */       return ((((BundleRevision)bundle.adapt(BundleRevision.class)).getTypes() & 0x1) != 0);
/* 106 */     } catch (SecurityException ignored) {
/* 107 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\OsgiServiceLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */