/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LazyUtil
/*     */ {
/*  25 */   private static final Object NULL = new Object()
/*     */     {
/*     */       public String toString() {
/*  28 */         return "null";
/*     */       }
/*     */     };
/*     */   
/*     */   static Object wrapNull(Object value) {
/*  33 */     return (value == null) ? NULL : value;
/*     */   }
/*     */   
/*     */   static <T> T unwrapNull(Object value) {
/*  37 */     return (value == NULL) ? null : Cast.<T>cast(value);
/*     */   }
/*     */   
/*     */   static class Constant<T> implements Lazy<T> {
/*     */     private final T value;
/*     */     
/*     */     Constant(T value) {
/*  44 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public T value() {
/*  49 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInitialized() {
/*  54 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(T newValue) {
/*  59 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  64 */       return String.valueOf(this.value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class WeakConstant<T> implements Lazy<T> {
/*     */     private final WeakReference<T> reference;
/*     */     
/*     */     WeakConstant(T value) {
/*  72 */       this.reference = new WeakReference<>(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public T value() {
/*  77 */       return this.reference.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInitialized() {
/*  82 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(T newValue) {
/*  87 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  92 */       return String.valueOf(value());
/*     */     }
/*     */   }
/*     */   
/*     */   static class SafeLazy<T> implements Lazy<T> {
/*  97 */     private final Lock lock = new ReentrantLock();
/*     */     private final Supplier<T> supplier;
/*     */     private volatile Object value;
/*     */     
/*     */     SafeLazy(Supplier<T> supplier) {
/* 102 */       this.supplier = supplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public T value() {
/* 107 */       Object value = this.value;
/* 108 */       if (value == null) {
/* 109 */         this.lock.lock();
/*     */         try {
/* 111 */           value = this.value;
/* 112 */           if (value == null) {
/* 113 */             value = this.supplier.get();
/* 114 */             this.value = LazyUtil.wrapNull(value);
/*     */           } 
/*     */         } finally {
/* 117 */           this.lock.unlock();
/*     */         } 
/*     */       } 
/* 120 */       return LazyUtil.unwrapNull(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(T newValue) {
/* 125 */       this.value = newValue;
/*     */     }
/*     */     
/*     */     public void reset() {
/* 129 */       this.value = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInitialized() {
/* 134 */       return (this.value != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 139 */       return isInitialized() ? String.valueOf(this.value) : "Lazy value not initialized";
/*     */     }
/*     */   }
/*     */   
/*     */   static class PureLazy<T> implements Lazy<T> {
/*     */     private final Supplier<T> supplier;
/*     */     private Object value;
/*     */     
/*     */     public PureLazy(Supplier<T> supplier) {
/* 148 */       this.supplier = supplier;
/*     */     }
/*     */ 
/*     */     
/*     */     public T value() {
/* 153 */       Object value = this.value;
/* 154 */       if (value == null) {
/* 155 */         value = this.supplier.get();
/* 156 */         this.value = LazyUtil.wrapNull(value);
/*     */       } 
/* 158 */       return LazyUtil.unwrapNull(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInitialized() {
/* 163 */       return (this.value != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(T newValue) {
/* 168 */       this.value = newValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\LazyUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */