/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.function.Predicate;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ public final class StackLocator
/*     */ {
/*  56 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   static final int JDK_7U25_OFFSET;
/*     */ 
/*     */   
/*     */   private static final Method GET_CALLER_CLASS_METHOD;
/*     */   
/*     */   private static final StackLocator INSTANCE;
/*     */   
/*  66 */   private static final Class<?> DEFAULT_CALLER_CLASS = null;
/*     */ 
/*     */   
/*     */   static {
/*  70 */     int java7u25CompensationOffset = 0;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  75 */       Class<?> sunReflectionClass = Class.forName("sun.reflect.Reflection", true, ClassLoader.getSystemClassLoader());
/*  76 */       getCallerClassMethod = sunReflectionClass.getDeclaredMethod("getCallerClass", new Class[] { int.class });
/*  77 */       Object o = getCallerClassMethod.invoke(null, new Object[] { Integer.valueOf(0) });
/*  78 */       getCallerClassMethod.invoke(null, new Object[] { Integer.valueOf(0) });
/*  79 */       if (o == null || o != sunReflectionClass) {
/*  80 */         getCallerClassMethod = null;
/*  81 */         java7u25CompensationOffset = -1;
/*     */       } else {
/*  83 */         o = getCallerClassMethod.invoke(null, new Object[] { Integer.valueOf(1) });
/*  84 */         if (o == sunReflectionClass) {
/*  85 */           LOGGER.warn("Unexpected result from `sun.reflect.Reflection.getCallerClass(int)`, adjusting offset for future calls.");
/*     */           
/*  87 */           java7u25CompensationOffset = 1;
/*     */         } 
/*     */       } 
/*  90 */     } catch (Exception|LinkageError e) {
/*     */       
/*  92 */       LOGGER.warn(
/*  93 */           System.getProperty("java.version", "").startsWith("1.8") ? 
/*  94 */           "`sun.reflect.Reflection.getCallerClass(int)` is not supported. This will impact location-based features." : 
/*  95 */           "Runtime environment or build system does not support multi-release JARs. This will impact location-based features.");
/*  96 */       getCallerClassMethod = null;
/*  97 */       java7u25CompensationOffset = -1;
/*     */     } 
/*     */     
/* 100 */     GET_CALLER_CLASS_METHOD = getCallerClassMethod;
/* 101 */     JDK_7U25_OFFSET = java7u25CompensationOffset;
/* 102 */     INSTANCE = new StackLocator();
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/*     */     Method getCallerClassMethod;
/*     */   }
/*     */   
/*     */   public static StackLocator getInstance() {
/* 111 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(Class<?> sentinelClass, Predicate<Class<?>> callerPredicate) {
/* 121 */     if (sentinelClass == null) {
/* 122 */       throw new IllegalArgumentException("sentinelClass cannot be null");
/*     */     }
/* 124 */     if (callerPredicate == null) {
/* 125 */       throw new IllegalArgumentException("callerPredicate cannot be null");
/*     */     }
/* 127 */     boolean foundSentinel = false;
/*     */     Class<?> clazz;
/* 129 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 130 */       if (sentinelClass.equals(clazz)) {
/* 131 */         foundSentinel = true;
/* 132 */       } else if (foundSentinel && callerPredicate.test(clazz)) {
/* 133 */         return clazz;
/*     */       } 
/*     */     } 
/* 136 */     return DEFAULT_CALLER_CLASS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(int depth) {
/* 157 */     if (depth < 0) {
/* 158 */       throw new IndexOutOfBoundsException(Integer.toString(depth));
/*     */     }
/* 160 */     if (GET_CALLER_CLASS_METHOD == null) {
/* 161 */       return DEFAULT_CALLER_CLASS;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 166 */       return (Class)GET_CALLER_CLASS_METHOD.invoke(null, new Object[] { Integer.valueOf(depth + 1 + JDK_7U25_OFFSET) });
/* 167 */     } catch (Exception e) {
/*     */ 
/*     */       
/* 170 */       return DEFAULT_CALLER_CLASS;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(String fqcn, String pkg) {
/* 177 */     boolean next = false;
/*     */     Class<?> clazz;
/* 179 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 180 */       if (fqcn.equals(clazz.getName())) {
/* 181 */         next = true;
/*     */       
/*     */       }
/* 184 */       else if (next && clazz.getName().startsWith(pkg)) {
/* 185 */         return clazz;
/*     */       } 
/*     */     } 
/*     */     
/* 189 */     return DEFAULT_CALLER_CLASS;
/*     */   }
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(Class<?> anchor) {
/* 195 */     boolean next = false;
/*     */     Class<?> clazz;
/* 197 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 198 */       if (anchor.equals(clazz)) {
/* 199 */         next = true;
/*     */       
/*     */       }
/* 202 */       else if (next) {
/* 203 */         return clazz;
/*     */       } 
/*     */     } 
/* 206 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Deque<Class<?>> getCurrentStackTrace() {
/* 213 */     if (PrivateSecurityManagerStackTraceUtil.isEnabled()) {
/* 214 */       return PrivateSecurityManagerStackTraceUtil.getCurrentStackTrace();
/*     */     }
/*     */     
/* 217 */     Deque<Class<?>> classes = new ArrayDeque<>();
/*     */     Class<?> clazz;
/* 219 */     for (int i = 1; null != (clazz = getCallerClass(i)); i++) {
/* 220 */       classes.addLast(clazz);
/*     */     }
/* 222 */     return classes;
/*     */   }
/*     */   
/*     */   public StackTraceElement calcLocation(String fqcnOfLogger) {
/* 226 */     if (fqcnOfLogger == null) {
/* 227 */       return null;
/*     */     }
/*     */     
/* 230 */     StackTraceElement[] stackTrace = (new Throwable()).getStackTrace();
/* 231 */     boolean found = false;
/* 232 */     for (int i = 0; i < stackTrace.length; i++) {
/* 233 */       String className = stackTrace[i].getClassName();
/* 234 */       if (fqcnOfLogger.equals(className)) {
/* 235 */         found = true;
/*     */       
/*     */       }
/* 238 */       else if (found && !fqcnOfLogger.equals(className)) {
/* 239 */         return stackTrace[i];
/*     */       } 
/*     */     } 
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StackTraceElement getStackTraceElement(int depth) {
/* 248 */     int i = 0;
/* 249 */     for (StackTraceElement element : (new Throwable()).getStackTrace()) {
/* 250 */       if (isValid(element)) {
/* 251 */         if (i == depth) {
/* 252 */           return element;
/*     */         }
/* 254 */         i++;
/*     */       } 
/*     */     } 
/* 257 */     throw new IndexOutOfBoundsException(Integer.toString(depth));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isValid(StackTraceElement element) {
/* 262 */     if (element.isNativeMethod()) {
/* 263 */       return false;
/*     */     }
/* 265 */     String cn = element.getClassName();
/*     */     
/* 267 */     if (cn.startsWith("sun.reflect.")) {
/* 268 */       return false;
/*     */     }
/* 270 */     String mn = element.getMethodName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     if (cn.startsWith("java.lang.reflect.") && (mn.equals("invoke") || mn.equals("newInstance"))) {
/* 276 */       return false;
/*     */     }
/*     */     
/* 279 */     if (cn.startsWith("jdk.internal.reflect.")) {
/* 280 */       return false;
/*     */     }
/*     */     
/* 283 */     if (cn.equals("java.lang.Class") && mn.equals("newInstance")) {
/* 284 */       return false;
/*     */     }
/*     */     
/* 287 */     if (cn.equals("java.lang.invoke.MethodHandle") && mn.startsWith("invoke")) {
/* 288 */       return false;
/*     */     }
/*     */     
/* 291 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\StackLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */