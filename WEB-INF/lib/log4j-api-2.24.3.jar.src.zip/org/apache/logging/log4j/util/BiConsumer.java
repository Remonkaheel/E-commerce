package org.apache.logging.log4j.util;

import java.util.function.BiConsumer;

@FunctionalInterface
public interface BiConsumer<K, V> extends BiConsumer<K, V> {
  void accept(K paramK, V paramV);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\BiConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */