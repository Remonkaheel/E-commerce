/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ public final class StringBuilders
/*     */ {
/*     */   private static final Class<?> timeClass;
/*     */   private static final Class<?> dateClass;
/*     */   
/*     */   static {
/*     */     Class<?> clazz;
/*     */     try {
/*  35 */       clazz = Class.forName("java.sql.Time");
/*  36 */     } catch (ClassNotFoundException ex) {
/*  37 */       clazz = null;
/*     */     } 
/*  39 */     timeClass = clazz;
/*     */     
/*     */     try {
/*  42 */       clazz = Class.forName("java.sql.Date");
/*  43 */     } catch (ClassNotFoundException ex) {
/*  44 */       clazz = null;
/*     */     } 
/*  46 */     dateClass = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder appendDqValue(StringBuilder sb, Object value) {
/*  59 */     return sb.append('"').append(value).append('"');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder appendKeyDqValue(StringBuilder sb, Map.Entry<String, String> entry) {
/*  70 */     return appendKeyDqValue(sb, entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder appendKeyDqValue(StringBuilder sb, String key, Object value) {
/*  82 */     return sb.append(key)
/*  83 */       .append('=')
/*  84 */       .append('"')
/*  85 */       .append(value)
/*  86 */       .append('"');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendValue(StringBuilder stringBuilder, Object obj) {
/*  97 */     if (!appendSpecificTypes(stringBuilder, obj)) {
/*  98 */       stringBuilder.append(obj);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean appendSpecificTypes(StringBuilder stringBuilder, Object obj) {
/* 103 */     if (obj == null || obj instanceof String) {
/* 104 */       stringBuilder.append((String)obj);
/* 105 */     } else if (obj instanceof StringBuilderFormattable) {
/* 106 */       ((StringBuilderFormattable)obj).formatTo(stringBuilder);
/* 107 */     } else if (obj instanceof CharSequence) {
/* 108 */       stringBuilder.append((CharSequence)obj);
/* 109 */     } else if (obj instanceof Integer) {
/* 110 */       stringBuilder.append(((Integer)obj).intValue());
/* 111 */     } else if (obj instanceof Long) {
/* 112 */       stringBuilder.append(((Long)obj).longValue());
/* 113 */     } else if (obj instanceof Double) {
/* 114 */       stringBuilder.append(((Double)obj).doubleValue());
/* 115 */     } else if (obj instanceof Boolean) {
/* 116 */       stringBuilder.append(((Boolean)obj).booleanValue());
/* 117 */     } else if (obj instanceof Character) {
/* 118 */       stringBuilder.append(((Character)obj).charValue());
/* 119 */     } else if (obj instanceof Short) {
/* 120 */       stringBuilder.append(((Short)obj).shortValue());
/* 121 */     } else if (obj instanceof Float) {
/* 122 */       stringBuilder.append(((Float)obj).floatValue());
/* 123 */     } else if (obj instanceof Byte) {
/* 124 */       stringBuilder.append(((Byte)obj).byteValue());
/* 125 */     } else if (isTime(obj) || isDate(obj) || obj instanceof java.time.temporal.Temporal) {
/* 126 */       stringBuilder.append(obj);
/*     */     } else {
/* 128 */       return false;
/*     */     } 
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTime(Object obj) {
/* 137 */     return (timeClass != null && timeClass.isAssignableFrom(obj.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isDate(Object obj) {
/* 144 */     return (dateClass != null && dateClass.isAssignableFrom(obj.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(CharSequence left, int leftOffset, int leftLength, CharSequence right, int rightOffset, int rightLength) {
/* 166 */     if (leftLength == rightLength) {
/* 167 */       for (int i = 0; i < rightLength; i++) {
/* 168 */         if (left.charAt(i + leftOffset) != right.charAt(i + rightOffset)) {
/* 169 */           return false;
/*     */         }
/*     */       } 
/* 172 */       return true;
/*     */     } 
/* 174 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalsIgnoreCase(CharSequence left, int leftOffset, int leftLength, CharSequence right, int rightOffset, int rightLength) {
/* 196 */     if (leftLength == rightLength) {
/* 197 */       for (int i = 0; i < rightLength; i++) {
/* 198 */         if (Character.toLowerCase(left.charAt(i + leftOffset)) != Character.toLowerCase(right.charAt(i + rightOffset))) {
/* 199 */           return false;
/*     */         }
/*     */       } 
/* 202 */       return true;
/*     */     } 
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void trimToMaxSize(StringBuilder stringBuilder, int maxSize) {
/* 216 */     if (stringBuilder != null && stringBuilder.capacity() > maxSize) {
/* 217 */       stringBuilder.setLength(maxSize);
/* 218 */       stringBuilder.trimToSize();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void escapeJson(StringBuilder toAppendTo, int start) {
/* 223 */     int escapeCount = 0;
/* 224 */     for (int i = start; i < toAppendTo.length(); i++) {
/* 225 */       char c = toAppendTo.charAt(i);
/* 226 */       switch (c) {
/*     */         case '\b':
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\f':
/*     */         case '\r':
/*     */         case '"':
/*     */         case '\\':
/* 234 */           escapeCount++;
/*     */           break;
/*     */         default:
/* 237 */           if (Character.isISOControl(c)) {
/* 238 */             escapeCount += 5;
/*     */           }
/*     */           break;
/*     */       } 
/*     */     } 
/* 243 */     int lastChar = toAppendTo.length() - 1;
/* 244 */     toAppendTo.setLength(toAppendTo.length() + escapeCount);
/* 245 */     int lastPos = toAppendTo.length() - 1;
/*     */     
/* 247 */     for (int j = lastChar; lastPos > j; j--) {
/* 248 */       char c = toAppendTo.charAt(j);
/* 249 */       switch (c) {
/*     */         case '\b':
/* 251 */           lastPos = escapeAndDecrement(toAppendTo, lastPos, 'b');
/*     */           break;
/*     */         
/*     */         case '\t':
/* 255 */           lastPos = escapeAndDecrement(toAppendTo, lastPos, 't');
/*     */           break;
/*     */         
/*     */         case '\f':
/* 259 */           lastPos = escapeAndDecrement(toAppendTo, lastPos, 'f');
/*     */           break;
/*     */         
/*     */         case '\n':
/* 263 */           lastPos = escapeAndDecrement(toAppendTo, lastPos, 'n');
/*     */           break;
/*     */         
/*     */         case '\r':
/* 267 */           lastPos = escapeAndDecrement(toAppendTo, lastPos, 'r');
/*     */           break;
/*     */         
/*     */         case '"':
/*     */         case '\\':
/* 272 */           lastPos = escapeAndDecrement(toAppendTo, lastPos, c);
/*     */           break;
/*     */         
/*     */         default:
/* 276 */           if (Character.isISOControl(c)) {
/*     */             
/* 278 */             toAppendTo.setCharAt(lastPos--, Chars.getUpperCaseHex(c & 0xF));
/* 279 */             toAppendTo.setCharAt(lastPos--, Chars.getUpperCaseHex((c & 0xF0) >> 4));
/* 280 */             toAppendTo.setCharAt(lastPos--, '0');
/* 281 */             toAppendTo.setCharAt(lastPos--, '0');
/* 282 */             toAppendTo.setCharAt(lastPos--, 'u');
/* 283 */             toAppendTo.setCharAt(lastPos--, '\\'); break;
/*     */           } 
/* 285 */           toAppendTo.setCharAt(lastPos, c);
/* 286 */           lastPos--;
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int escapeAndDecrement(StringBuilder toAppendTo, int lastPos, char c) {
/* 293 */     toAppendTo.setCharAt(lastPos--, c);
/* 294 */     toAppendTo.setCharAt(lastPos--, '\\');
/* 295 */     return lastPos;
/*     */   }
/*     */   
/*     */   public static void escapeXml(StringBuilder toAppendTo, int start) {
/* 299 */     int escapeCount = 0;
/* 300 */     for (int i = start; i < toAppendTo.length(); i++) {
/* 301 */       char c = toAppendTo.charAt(i);
/* 302 */       switch (c) {
/*     */         case '&':
/* 304 */           escapeCount += 4;
/*     */           break;
/*     */         case '<':
/*     */         case '>':
/* 308 */           escapeCount += 3;
/*     */           break;
/*     */         case '"':
/*     */         case '\'':
/* 312 */           escapeCount += 5;
/*     */           break;
/*     */       } 
/*     */     } 
/* 316 */     int lastChar = toAppendTo.length() - 1;
/* 317 */     toAppendTo.setLength(toAppendTo.length() + escapeCount);
/* 318 */     int lastPos = toAppendTo.length() - 1;
/*     */     
/* 320 */     for (int j = lastChar; lastPos > j; j--) {
/* 321 */       char c = toAppendTo.charAt(j);
/* 322 */       switch (c) {
/*     */         case '&':
/* 324 */           toAppendTo.setCharAt(lastPos--, ';');
/* 325 */           toAppendTo.setCharAt(lastPos--, 'p');
/* 326 */           toAppendTo.setCharAt(lastPos--, 'm');
/* 327 */           toAppendTo.setCharAt(lastPos--, 'a');
/* 328 */           toAppendTo.setCharAt(lastPos--, '&');
/*     */           break;
/*     */         case '<':
/* 331 */           toAppendTo.setCharAt(lastPos--, ';');
/* 332 */           toAppendTo.setCharAt(lastPos--, 't');
/* 333 */           toAppendTo.setCharAt(lastPos--, 'l');
/* 334 */           toAppendTo.setCharAt(lastPos--, '&');
/*     */           break;
/*     */         case '>':
/* 337 */           toAppendTo.setCharAt(lastPos--, ';');
/* 338 */           toAppendTo.setCharAt(lastPos--, 't');
/* 339 */           toAppendTo.setCharAt(lastPos--, 'g');
/* 340 */           toAppendTo.setCharAt(lastPos--, '&');
/*     */           break;
/*     */         case '"':
/* 343 */           toAppendTo.setCharAt(lastPos--, ';');
/* 344 */           toAppendTo.setCharAt(lastPos--, 't');
/* 345 */           toAppendTo.setCharAt(lastPos--, 'o');
/* 346 */           toAppendTo.setCharAt(lastPos--, 'u');
/* 347 */           toAppendTo.setCharAt(lastPos--, 'q');
/* 348 */           toAppendTo.setCharAt(lastPos--, '&');
/*     */           break;
/*     */         case '\'':
/* 351 */           toAppendTo.setCharAt(lastPos--, ';');
/* 352 */           toAppendTo.setCharAt(lastPos--, 's');
/* 353 */           toAppendTo.setCharAt(lastPos--, 'o');
/* 354 */           toAppendTo.setCharAt(lastPos--, 'p');
/* 355 */           toAppendTo.setCharAt(lastPos--, 'a');
/* 356 */           toAppendTo.setCharAt(lastPos--, '&');
/*     */           break;
/*     */         default:
/* 359 */           toAppendTo.setCharAt(lastPos--, c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\StringBuilders.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */