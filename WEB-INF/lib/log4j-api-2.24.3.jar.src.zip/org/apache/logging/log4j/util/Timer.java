/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.DecimalFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Timer
/*     */   implements Serializable, StringBuilderFormattable
/*     */ {
/*     */   private static final long serialVersionUID = 9175191792439630013L;
/*     */   private final String name;
/*     */   private Status status;
/*     */   private long elapsedTime;
/*     */   private final int iterations;
/*     */   
/*     */   public enum Status
/*     */   {
/*  33 */     Started,
/*  34 */     Stopped,
/*  35 */     Paused;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static long NANO_PER_SECOND = 1000000000L;
/*  42 */   private static long NANO_PER_MINUTE = NANO_PER_SECOND * 60L;
/*  43 */   private static long NANO_PER_HOUR = NANO_PER_MINUTE * 60L;
/*  44 */   private ThreadLocal<Long> startTime = new ThreadLocal<Long>()
/*     */     {
/*     */       protected Long initialValue() {
/*  47 */         return Long.valueOf(0L);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer(String name) {
/*  56 */     this(name, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer(String name, int iterations) {
/*  65 */     this.name = name;
/*  66 */     this.status = Status.Stopped;
/*  67 */     this.iterations = (iterations > 0) ? iterations : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start() {
/*  74 */     this.startTime.set(Long.valueOf(System.nanoTime()));
/*  75 */     this.elapsedTime = 0L;
/*  76 */     this.status = Status.Started;
/*     */   }
/*     */   
/*     */   public synchronized void startOrResume() {
/*  80 */     if (this.status == Status.Stopped) {
/*  81 */       start();
/*     */     } else {
/*  83 */       resume();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String stop() {
/*  91 */     this.elapsedTime += System.nanoTime() - ((Long)this.startTime.get()).longValue();
/*  92 */     this.startTime.set(Long.valueOf(0L));
/*  93 */     this.status = Status.Stopped;
/*  94 */     return toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void pause() {
/* 101 */     this.elapsedTime += System.nanoTime() - ((Long)this.startTime.get()).longValue();
/* 102 */     this.startTime.set(Long.valueOf(0L));
/* 103 */     this.status = Status.Paused;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void resume() {
/* 110 */     this.startTime.set(Long.valueOf(System.nanoTime()));
/* 111 */     this.status = Status.Started;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 119 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getElapsedTime() {
/* 128 */     return this.elapsedTime / 1000000L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getElapsedNanoTime() {
/* 137 */     return this.elapsedTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Status getStatus() {
/* 146 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 154 */     StringBuilder result = new StringBuilder();
/* 155 */     formatTo(result);
/* 156 */     return result.toString();
/*     */   } public void formatTo(StringBuilder buffer) {
/*     */     long nanoseconds, hours, minutes, seconds;
/*     */     String elapsed;
/*     */     DecimalFormat numFormat;
/* 161 */     buffer.append("Timer ").append(this.name);
/* 162 */     switch (this.status) {
/*     */       case Started:
/* 164 */         buffer.append(" started");
/*     */         return;
/*     */       case Paused:
/* 167 */         buffer.append(" paused");
/*     */         return;
/*     */       case Stopped:
/* 170 */         nanoseconds = this.elapsedTime;
/*     */         
/* 172 */         hours = nanoseconds / NANO_PER_HOUR;
/*     */         
/* 174 */         nanoseconds %= NANO_PER_HOUR;
/*     */         
/* 176 */         minutes = nanoseconds / NANO_PER_MINUTE;
/*     */         
/* 178 */         nanoseconds %= NANO_PER_MINUTE;
/*     */         
/* 180 */         seconds = nanoseconds / NANO_PER_SECOND;
/*     */         
/* 182 */         nanoseconds %= NANO_PER_SECOND;
/*     */         
/* 184 */         elapsed = "";
/*     */         
/* 186 */         if (hours > 0L) {
/* 187 */           elapsed = elapsed + hours + " hours ";
/*     */         }
/* 189 */         if (minutes > 0L || hours > 0L) {
/* 190 */           elapsed = elapsed + minutes + " minutes ";
/*     */         }
/*     */ 
/*     */         
/* 194 */         numFormat = new DecimalFormat("#0");
/* 195 */         elapsed = elapsed + numFormat.format(seconds) + '.';
/* 196 */         numFormat = new DecimalFormat("000000000");
/* 197 */         elapsed = elapsed + numFormat.format(nanoseconds) + " seconds";
/* 198 */         buffer.append(" stopped. Elapsed time: ").append(elapsed);
/* 199 */         if (this.iterations > 0) {
/* 200 */           nanoseconds = this.elapsedTime / this.iterations;
/*     */           
/* 202 */           hours = nanoseconds / NANO_PER_HOUR;
/*     */           
/* 204 */           nanoseconds %= NANO_PER_HOUR;
/*     */           
/* 206 */           minutes = nanoseconds / NANO_PER_MINUTE;
/*     */           
/* 208 */           nanoseconds %= NANO_PER_MINUTE;
/*     */           
/* 210 */           seconds = nanoseconds / NANO_PER_SECOND;
/*     */           
/* 212 */           nanoseconds %= NANO_PER_SECOND;
/*     */           
/* 214 */           elapsed = "";
/*     */           
/* 216 */           if (hours > 0L) {
/* 217 */             elapsed = elapsed + hours + " hours ";
/*     */           }
/* 219 */           if (minutes > 0L || hours > 0L) {
/* 220 */             elapsed = elapsed + minutes + " minutes ";
/*     */           }
/*     */           
/* 223 */           numFormat = new DecimalFormat("#0");
/* 224 */           elapsed = elapsed + numFormat.format(seconds) + '.';
/* 225 */           numFormat = new DecimalFormat("000000000");
/* 226 */           elapsed = elapsed + numFormat.format(nanoseconds) + " seconds";
/* 227 */           buffer.append(" Average per iteration: ").append(elapsed);
/*     */         } 
/*     */         return;
/*     */     } 
/* 231 */     buffer.append(' ').append(this.status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 238 */     if (this == o) {
/* 239 */       return true;
/*     */     }
/* 241 */     if (!(o instanceof Timer)) {
/* 242 */       return false;
/*     */     }
/*     */     
/* 245 */     Timer timer = (Timer)o;
/*     */     
/* 247 */     if (this.elapsedTime != timer.elapsedTime) {
/* 248 */       return false;
/*     */     }
/* 250 */     if (this.startTime != timer.startTime) {
/* 251 */       return false;
/*     */     }
/* 253 */     if ((this.name != null) ? !this.name.equals(timer.name) : (timer.name != null)) {
/* 254 */       return false;
/*     */     }
/* 256 */     if ((this.status != null) ? !this.status.equals(timer.status) : (timer.status != null)) {
/* 257 */       return false;
/*     */     }
/*     */     
/* 260 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 266 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 267 */     result = 29 * result + ((this.status != null) ? this.status.hashCode() : 0);
/* 268 */     long time = ((Long)this.startTime.get()).longValue();
/* 269 */     result = 29 * result + (int)(time ^ time >>> 32L);
/* 270 */     result = 29 * result + (int)(this.elapsedTime ^ this.elapsedTime >>> 32L);
/* 271 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Timer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */