/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PerformanceSensitive({"allocation"})
/*     */ public class Unbox
/*     */ {
/*  50 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */   private static final int BITS_PER_INT = 32;
/*     */   private static final int RINGBUFFER_MIN_SIZE = 32;
/*  53 */   private static final int RINGBUFFER_SIZE = calculateRingBufferSize("log4j.unbox.ringbuffer.size");
/*  54 */   private static final int MASK = RINGBUFFER_SIZE - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WebSafeState
/*     */   {
/*  71 */     private final ThreadLocal<StringBuilder[]> ringBuffer = (ThreadLocal)new ThreadLocal<>();
/*  72 */     private final ThreadLocal<int[]> current = (ThreadLocal)new ThreadLocal<>();
/*     */     
/*     */     public StringBuilder getStringBuilder() {
/*  75 */       StringBuilder[] array = this.ringBuffer.get();
/*  76 */       if (array == null) {
/*  77 */         array = new StringBuilder[Unbox.RINGBUFFER_SIZE];
/*  78 */         for (int i = 0; i < array.length; i++) {
/*  79 */           array[i] = new StringBuilder(21);
/*     */         }
/*  81 */         this.ringBuffer.set(array);
/*  82 */         this.current.set(new int[1]);
/*     */       } 
/*  84 */       int[] index = this.current.get();
/*  85 */       index[0] = index[0] + 1; StringBuilder result = array[Unbox.MASK & index[0]];
/*  86 */       result.setLength(0);
/*  87 */       return result;
/*     */     }
/*     */     
/*     */     private WebSafeState() {} }
/*     */   
/*  92 */   private static class State { private final StringBuilder[] ringBuffer = new StringBuilder[Unbox.RINGBUFFER_SIZE];
/*     */     private int current;
/*     */     
/*     */     State() {
/*  96 */       for (int i = 0; i < this.ringBuffer.length; i++) {
/*  97 */         this.ringBuffer[i] = new StringBuilder(21);
/*     */       }
/*     */     }
/*     */     
/*     */     public StringBuilder getStringBuilder() {
/* 102 */       StringBuilder result = this.ringBuffer[Unbox.MASK & this.current++];
/* 103 */       result.setLength(0);
/* 104 */       return result;
/*     */     } }
/*     */ 
/*     */   
/* 108 */   private static ThreadLocal<State> threadLocalState = new ThreadLocal<>();
/* 109 */   private static WebSafeState webSafeState = new WebSafeState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int calculateRingBufferSize(String propertyName) {
/* 117 */     String userPreferredRBSize = PropertiesUtil.getProperties().getStringProperty(propertyName, String.valueOf(32));
/*     */     try {
/* 119 */       int size = Integer.parseInt(userPreferredRBSize.trim());
/* 120 */       if (size < 32) {
/* 121 */         size = 32;
/* 122 */         LOGGER.warn("Invalid {} {}, using minimum size {}.", propertyName, userPreferredRBSize, 
/*     */ 
/*     */ 
/*     */             
/* 126 */             Integer.valueOf(32));
/*     */       } 
/* 128 */       return ceilingNextPowerOfTwo(size);
/* 129 */     } catch (Exception ex) {
/* 130 */       LOGGER.warn("Invalid {} {}, using default size {}.", propertyName, userPreferredRBSize, 
/* 131 */           Integer.valueOf(32));
/* 132 */       return 32;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int ceilingNextPowerOfTwo(int x) {
/* 145 */     return 1 << 32 - Integer.numberOfLeadingZeros(x - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(float value) {
/* 157 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(double value) {
/* 169 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(short value) {
/* 181 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(int value) {
/* 193 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(char value) {
/* 205 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(long value) {
/* 217 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(byte value) {
/* 229 */     return getSB().append(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive({"allocation"})
/*     */   public static StringBuilder box(boolean value) {
/* 241 */     return getSB().append(value);
/*     */   }
/*     */   
/*     */   private static State getState() {
/* 245 */     State state = threadLocalState.get();
/* 246 */     if (state == null) {
/* 247 */       state = new State();
/* 248 */       threadLocalState.set(state);
/*     */     } 
/* 250 */     return state;
/*     */   }
/*     */   
/*     */   private static StringBuilder getSB() {
/* 254 */     return Constants.ENABLE_THREADLOCALS ? getState().getStringBuilder() : webSafeState.getStringBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   static int getRingbufferSize() {
/* 259 */     return RINGBUFFER_SIZE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Unbox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */