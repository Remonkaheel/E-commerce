/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesPropertySource
/*    */   implements PropertySource
/*    */ {
/*    */   private static final int DEFAULT_PRIORITY = 200;
/*    */   private static final String PREFIX = "log4j2.";
/*    */   private final Properties properties;
/*    */   private final int priority;
/*    */   
/*    */   public PropertiesPropertySource(Properties properties) {
/* 38 */     this(properties, 200);
/*    */   }
/*    */   
/*    */   public PropertiesPropertySource(Properties properties, int priority) {
/* 42 */     this.properties = properties;
/* 43 */     this.priority = priority;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPriority() {
/* 48 */     return this.priority;
/*    */   }
/*    */ 
/*    */   
/*    */   public void forEach(BiConsumer<String, String> action) {
/* 53 */     for (Map.Entry<Object, Object> entry : this.properties.entrySet()) {
/* 54 */       action.accept((String)entry.getKey(), (String)entry.getValue());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public CharSequence getNormalForm(Iterable<? extends CharSequence> tokens) {
/* 60 */     CharSequence camelCase = PropertySource.Util.joinAsCamelCase(tokens);
/* 61 */     return (camelCase.length() > 0) ? ("log4j2." + camelCase) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<String> getPropertyNames() {
/* 66 */     return this.properties.stringPropertyNames();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProperty(String key) {
/* 71 */     return this.properties.getProperty(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean containsProperty(String key) {
/* 76 */     return (getProperty(key) != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\PropertiesPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */