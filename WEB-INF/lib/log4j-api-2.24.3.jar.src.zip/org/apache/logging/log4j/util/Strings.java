/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ public final class Strings
/*     */ {
/*     */   private static final int MAX_FORMAT_BUFFER_LENGTH = 518;
/*  37 */   private static final ThreadLocal<StringBuilder> FORMAT_BUFFER_REF = ThreadLocal.withInitial(StringBuilder::new);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String EMPTY = "";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String COMMA_DELIMITED_RE = "\\s*,\\s*";
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final String[] EMPTY_ARRAY = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final String LINE_SEPARATOR = System.lineSeparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String dquote(String str) {
/*  64 */     return '"' + str + '"';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBlank(String s) {
/*  75 */     if (s == null || s.isEmpty()) {
/*  76 */       return true;
/*     */     }
/*  78 */     for (int i = 0; i < s.length(); i++) {
/*  79 */       char c = s.charAt(i);
/*  80 */       if (!Character.isWhitespace(c)) {
/*  81 */         return false;
/*     */       }
/*     */     } 
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(CharSequence cs) {
/* 113 */     return (cs == null || cs.length() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotBlank(String s) {
/* 123 */     return !isBlank(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(CharSequence cs) {
/* 147 */     return !isEmpty(cs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Iterable<?> iterable, char separator) {
/* 162 */     if (iterable == null) {
/* 163 */       return null;
/*     */     }
/* 165 */     return join(iterable.iterator(), separator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Iterator<?> iterator, char separator) {
/* 182 */     if (iterator == null) {
/* 183 */       return null;
/*     */     }
/* 185 */     if (!iterator.hasNext()) {
/* 186 */       return "";
/*     */     }
/* 188 */     Object first = iterator.next();
/* 189 */     if (!iterator.hasNext()) {
/* 190 */       return Objects.toString(first, "");
/*     */     }
/*     */ 
/*     */     
/* 194 */     StringBuilder buf = new StringBuilder(256);
/* 195 */     if (first != null) {
/* 196 */       buf.append(first);
/*     */     }
/*     */     
/* 199 */     while (iterator.hasNext()) {
/* 200 */       buf.append(separator);
/* 201 */       Object obj = iterator.next();
/* 202 */       if (obj != null) {
/* 203 */         buf.append(obj);
/*     */       }
/*     */     } 
/*     */     
/* 207 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static String[] splitList(String string) {
/* 211 */     return (string != null) ? string.split("\\s*,\\s*") : new String[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String left(String str, int len) {
/* 239 */     if (str == null) {
/* 240 */       return null;
/*     */     }
/* 242 */     if (len < 0) {
/* 243 */       return "";
/*     */     }
/* 245 */     if (str.length() <= len) {
/* 246 */       return str;
/*     */     }
/* 248 */     return str.substring(0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String str) {
/* 258 */     return '\'' + str + '\'';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String trimToNull(String str) {
/* 286 */     String ts = (str == null) ? null : str.trim();
/* 287 */     return isEmpty(ts) ? null : ts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toRootLowerCase(String str) {
/* 301 */     return str.toLowerCase(Locale.ROOT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toRootUpperCase(String str) {
/* 311 */     return str.toUpperCase(Locale.ROOT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String concat(String str1, String str2) {
/* 321 */     if (isEmpty(str1))
/* 322 */       return str2; 
/* 323 */     if (isEmpty(str2)) {
/* 324 */       return str1;
/*     */     }
/* 326 */     StringBuilder sb = FORMAT_BUFFER_REF.get();
/*     */     try {
/* 328 */       return sb.append(str1).append(str2).toString();
/*     */     } finally {
/* 330 */       StringBuilders.trimToMaxSize(sb, 518);
/* 331 */       sb.setLength(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String repeat(String str, int count) {
/* 343 */     Objects.requireNonNull(str, "str");
/* 344 */     if (count < 0) {
/* 345 */       throw new IllegalArgumentException("count");
/*     */     }
/* 347 */     StringBuilder sb = FORMAT_BUFFER_REF.get();
/*     */     try {
/* 349 */       for (int index = 0; index < count; index++) {
/* 350 */         sb.append(str);
/*     */       }
/* 352 */       return sb.toString();
/*     */     } finally {
/* 354 */       StringBuilders.trimToMaxSize(sb, 518);
/* 355 */       sb.setLength(0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\Strings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */