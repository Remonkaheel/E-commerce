/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import aQute.bnd.annotation.spi.ServiceConsumer;
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Properties;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.simple.internal.SimpleProvider;
/*     */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*     */ import org.apache.logging.log4j.spi.Provider;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @InternalApi
/*     */ @ServiceConsumer(value = Provider.class, resolution = "optional", cardinality = "multiple")
/*     */ public final class ProviderUtil
/*     */ {
/*     */   static final String PROVIDER_RESOURCE = "META-INF/log4j-provider.properties";
/*  63 */   static final Collection<Provider> PROVIDERS = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   static final Lock STARTUP_LOCK = new ReentrantLock();
/*     */   
/*  74 */   private static final String[] COMPATIBLE_API_VERSIONS = new String[] { "2.6.0" };
/*  75 */   private static final Logger LOGGER = (Logger)StatusLogger.getLogger();
/*     */ 
/*     */   
/*     */   private static volatile Provider PROVIDER;
/*     */ 
/*     */   
/*     */   static void addProvider(Provider provider) {
/*  82 */     if (validVersion(provider.getVersions())) {
/*  83 */       PROVIDERS.add(provider);
/*  84 */       LOGGER.debug("Loaded provider:\n{}", provider);
/*     */     } else {
/*  86 */       LOGGER.warn("Ignoring provider for incompatible version {}:\n{}", provider.getVersions(), provider);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"URLCONNECTION_SSRF_FD"}, justification = "Uses a fixed URL that ends in 'META-INF/log4j-provider.properties'.")
/*     */   static void loadProvider(URL url, ClassLoader cl) {
/*     */     try {
/* 103 */       Properties props = PropertiesUtil.loadClose(url.openStream(), url);
/* 104 */       addProvider(new Provider(props, url, cl));
/* 105 */     } catch (IOException e) {
/* 106 */       LOGGER.error("Unable to open {}", url, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static void loadProviders(Enumeration<URL> urls, ClassLoader cl) {
/* 115 */     if (urls != null) {
/* 116 */       while (urls.hasMoreElements()) {
/* 117 */         loadProvider(urls.nextElement(), cl);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Provider getProvider() {
/* 126 */     lazyInit();
/* 127 */     return PROVIDER;
/*     */   }
/*     */   
/*     */   public static Iterable<Provider> getProviders() {
/* 131 */     lazyInit();
/* 132 */     return PROVIDERS;
/*     */   }
/*     */   
/*     */   public static boolean hasProviders() {
/* 136 */     lazyInit();
/* 137 */     return !PROVIDERS.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void lazyInit() {
/* 148 */     if (PROVIDER == null) {
/*     */       try {
/* 150 */         STARTUP_LOCK.lockInterruptibly();
/*     */         try {
/* 152 */           if (PROVIDER == null) {
/* 153 */             ServiceLoaderUtil.<Provider>safeStream(Provider.class, 
/*     */                 
/* 155 */                 ServiceLoader.load(Provider.class, ProviderUtil.class.getClassLoader()), LOGGER)
/*     */               
/* 157 */               .filter(provider -> validVersion(provider.getVersions()))
/* 158 */               .forEach(ProviderUtil::addProvider);
/*     */ 
/*     */             
/* 161 */             for (LoaderUtil.UrlResource resource : LoaderUtil.findUrlResources("META-INF/log4j-provider.properties", false)) {
/* 162 */               loadProvider(resource.getUrl(), resource.getClassLoader());
/*     */             }
/* 164 */             PROVIDER = selectProvider(PropertiesUtil.getProperties(), PROVIDERS, LOGGER);
/*     */           } 
/*     */         } finally {
/* 167 */           STARTUP_LOCK.unlock();
/*     */         } 
/* 169 */       } catch (InterruptedException e) {
/* 170 */         LOGGER.fatal("Interrupted before Log4j Providers could be loaded.", e);
/* 171 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Provider selectProvider(PropertiesUtil properties, Collection<Provider> providers, Logger statusLogger) {
/* 182 */     Provider selected = null;
/*     */     
/* 184 */     String providerClass = properties.getStringProperty("log4j.provider");
/* 185 */     if (providerClass != null) {
/* 186 */       if (SimpleProvider.class.getName().equals(providerClass)) {
/* 187 */         SimpleProvider simpleProvider = new SimpleProvider();
/*     */       } else {
/*     */         try {
/* 190 */           selected = LoaderUtil.<Provider>newInstanceOf(providerClass);
/* 191 */         } catch (Exception e) {
/* 192 */           statusLogger.error("Unable to create provider {}.\nFalling back to default selection process.", PROVIDER, e);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 198 */     String factoryClassName = properties.getStringProperty("log4j2.loggerContextFactory");
/* 199 */     if (factoryClassName != null) {
/* 200 */       if (selected != null) {
/* 201 */         statusLogger.warn("Ignoring {} system property, since {} was set.", "log4j2.loggerContextFactory", "log4j.provider");
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 207 */         statusLogger.warn("Usage of the {} property is deprecated. Use the {} property instead.", "log4j2.loggerContextFactory", "log4j.provider");
/*     */ 
/*     */ 
/*     */         
/* 211 */         for (Provider provider : providers) {
/* 212 */           if (factoryClassName.equals(provider.getClassName())) {
/* 213 */             selected = provider;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 219 */       if (selected == null) {
/* 220 */         statusLogger.warn("No provider found using {} as logger context factory. The factory will be instantiated directly.", factoryClassName);
/*     */ 
/*     */         
/*     */         try {
/* 224 */           Class<?> clazz = LoaderUtil.loadClass(factoryClassName);
/* 225 */           if (LoggerContextFactory.class.isAssignableFrom(clazz)) {
/* 226 */             selected = new Provider(null, "", clazz.asSubclass(LoggerContextFactory.class));
/*     */           } else {
/* 228 */             statusLogger.error("Class {} specified in the {} system property does not extend {}", factoryClassName, "log4j2.loggerContextFactory", LoggerContextFactory.class
/*     */ 
/*     */ 
/*     */                 
/* 232 */                 .getName());
/*     */           } 
/* 234 */         } catch (Exception e) {
/* 235 */           statusLogger.error("Unable to create class {} specified in the {} system property", factoryClassName, "log4j2.loggerContextFactory", e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     if (selected == null) {
/* 245 */       Comparator<Provider> comparator = Comparator.comparing(Provider::getPriority);
/* 246 */       switch (providers.size()) {
/*     */         case 0:
/* 248 */           statusLogger.error("Log4j API could not find a logging provider.");
/*     */           break;
/*     */         case 1:
/*     */           break;
/*     */         default:
/* 253 */           statusLogger.warn(providers.stream()
/* 254 */               .sorted(comparator)
/* 255 */               .map(Provider::toString)
/* 256 */               .collect(Collectors.joining("\n", "Log4j API found multiple logging providers:\n", "")));
/*     */           break;
/*     */       } 
/* 259 */       selected = providers.stream().max(comparator).orElseGet(SimpleProvider::new);
/*     */     } 
/* 261 */     statusLogger.info("Using provider:\n{}", selected);
/* 262 */     return selected;
/*     */   }
/*     */   
/*     */   public static ClassLoader findClassLoader() {
/* 266 */     return LoaderUtil.getThreadContextClassLoader();
/*     */   }
/*     */   
/*     */   private static boolean validVersion(String version) {
/* 270 */     for (String v : COMPATIBLE_API_VERSIONS) {
/* 271 */       if (version.startsWith(v)) {
/* 272 */         return true;
/*     */       }
/*     */     } 
/* 275 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4\\util\ProviderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */