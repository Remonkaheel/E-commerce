/*     */ package org.apache.logging.log4j;
/*     */ 
/*     */ import com.google.errorprone.annotations.InlineMe;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Function;
/*     */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*     */ import org.apache.logging.log4j.util.StringBuilderFormattable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MarkerManager
/*     */ {
/*  31 */   private static final ConcurrentMap<String, Marker> MARKERS = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear() {
/*  41 */     MARKERS.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean exists(String key) {
/*  52 */     return MARKERS.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Marker getMarker(String name) {
/*  63 */     return MARKERS.computeIfAbsent(name, Log4jMarker::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Marker getMarker(String name, String parent) {
/*  77 */     Marker parentMarker = MARKERS.get(parent);
/*  78 */     if (parentMarker == null) {
/*  79 */       throw new IllegalArgumentException("Parent Marker " + parent + " has not been defined");
/*     */     }
/*  81 */     return getMarker(name).addParents(new Marker[] { parentMarker });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @InlineMe(replacement = "MarkerManager.getMarker(name).addParents(parent)", imports = {"org.apache.logging.log4j.MarkerManager"})
/*     */   public static Marker getMarker(String name, Marker parent) {
/*  98 */     return getMarker(name).addParents(new Marker[] { parent });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Log4jMarker
/*     */     implements Marker, StringBuilderFormattable
/*     */   {
/*     */     private static final long serialVersionUID = 100L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private volatile Marker[] parents;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Log4jMarker() {
/* 125 */       this.name = null;
/* 126 */       this.parents = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Log4jMarker(String name) {
/* 138 */       MarkerManager.requireNonNull(name, "Marker name cannot be null.");
/* 139 */       this.name = name;
/* 140 */       this.parents = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized Marker addParents(Marker... parentMarkers) {
/* 147 */       MarkerManager.requireNonNull(parentMarkers, "A parent marker must be specified");
/*     */ 
/*     */       
/* 150 */       Marker[] localParents = this.parents;
/*     */       
/* 152 */       int count = 0;
/* 153 */       int size = parentMarkers.length;
/* 154 */       if (localParents != null) {
/* 155 */         for (Marker parent : parentMarkers) {
/* 156 */           if (!contains(parent, localParents) && !parent.isInstanceOf(this)) {
/* 157 */             count++;
/*     */           }
/*     */         } 
/* 160 */         if (count == 0) {
/* 161 */           return this;
/*     */         }
/* 163 */         size = localParents.length + count;
/*     */       } 
/* 165 */       Marker[] markers = new Marker[size];
/* 166 */       if (localParents != null)
/*     */       {
/*     */         
/* 169 */         System.arraycopy(localParents, 0, markers, 0, localParents.length);
/*     */       }
/* 171 */       int index = (localParents == null) ? 0 : localParents.length;
/* 172 */       for (Marker parent : parentMarkers) {
/* 173 */         if (localParents == null || (!contains(parent, localParents) && !parent.isInstanceOf(this))) {
/* 174 */           markers[index++] = parent;
/*     */         }
/*     */       } 
/* 177 */       this.parents = markers;
/* 178 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized boolean remove(Marker parent) {
/* 183 */       MarkerManager.requireNonNull(parent, "A parent marker must be specified");
/* 184 */       Marker[] localParents = this.parents;
/* 185 */       if (localParents == null) {
/* 186 */         return false;
/*     */       }
/* 188 */       int localParentsLength = localParents.length;
/* 189 */       if (localParentsLength == 1) {
/* 190 */         if (localParents[0].equals(parent)) {
/* 191 */           this.parents = null;
/* 192 */           return true;
/*     */         } 
/* 194 */         return false;
/*     */       } 
/* 196 */       int index = 0;
/* 197 */       Marker[] markers = new Marker[localParentsLength - 1];
/*     */       
/* 199 */       for (int i = 0; i < localParentsLength; i++) {
/* 200 */         Marker marker = localParents[i];
/* 201 */         if (!marker.equals(parent)) {
/* 202 */           if (index == localParentsLength - 1)
/*     */           {
/* 204 */             return false;
/*     */           }
/* 206 */           markers[index++] = marker;
/*     */         } 
/*     */       } 
/* 209 */       this.parents = markers;
/* 210 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public Marker setParents(Marker... markers) {
/* 215 */       if (markers == null || markers.length == 0) {
/* 216 */         this.parents = null;
/*     */       } else {
/* 218 */         Marker[] array = new Marker[markers.length];
/* 219 */         System.arraycopy(markers, 0, array, 0, markers.length);
/* 220 */         this.parents = array;
/*     */       } 
/* 222 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 227 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public Marker[] getParents() {
/* 232 */       Marker[] parentsSnapshot = this.parents;
/* 233 */       if (parentsSnapshot == null) {
/* 234 */         return null;
/*     */       }
/* 236 */       return Arrays.<Marker>copyOf(parentsSnapshot, parentsSnapshot.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasParents() {
/* 241 */       return (this.parents != null);
/*     */     }
/*     */ 
/*     */     
/*     */     @PerformanceSensitive({"allocation", "unrolled"})
/*     */     public boolean isInstanceOf(Marker marker) {
/* 247 */       MarkerManager.requireNonNull(marker, "A marker parameter is required");
/* 248 */       if (this == marker) {
/* 249 */         return true;
/*     */       }
/* 251 */       Marker[] localParents = this.parents;
/* 252 */       if (localParents != null) {
/*     */         
/* 254 */         int localParentsLength = localParents.length;
/* 255 */         if (localParentsLength == 1) {
/* 256 */           return checkParent(localParents[0], marker);
/*     */         }
/* 258 */         if (localParentsLength == 2) {
/* 259 */           return (checkParent(localParents[0], marker) || checkParent(localParents[1], marker));
/*     */         }
/*     */         
/* 262 */         for (int i = 0; i < localParentsLength; i++) {
/* 263 */           Marker localParent = localParents[i];
/* 264 */           if (checkParent(localParent, marker)) {
/* 265 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 269 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @PerformanceSensitive({"allocation", "unrolled"})
/*     */     public boolean isInstanceOf(String markerName) {
/* 275 */       MarkerManager.requireNonNull(markerName, "A marker name is required");
/* 276 */       if (markerName.equals(getName())) {
/* 277 */         return true;
/*     */       }
/*     */       
/* 280 */       Marker marker = (Marker)MarkerManager.MARKERS.get(markerName);
/* 281 */       if (marker == null) {
/* 282 */         return false;
/*     */       }
/* 284 */       Marker[] localParents = this.parents;
/* 285 */       if (localParents != null) {
/* 286 */         int localParentsLength = localParents.length;
/* 287 */         if (localParentsLength == 1) {
/* 288 */           return checkParent(localParents[0], marker);
/*     */         }
/* 290 */         if (localParentsLength == 2) {
/* 291 */           return (checkParent(localParents[0], marker) || checkParent(localParents[1], marker));
/*     */         }
/*     */         
/* 294 */         for (int i = 0; i < localParentsLength; i++) {
/* 295 */           Marker localParent = localParents[i];
/* 296 */           if (checkParent(localParent, marker)) {
/* 297 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 302 */       return false;
/*     */     }
/*     */     
/*     */     @PerformanceSensitive({"allocation", "unrolled"})
/*     */     private static boolean checkParent(Marker parent, Marker marker) {
/* 307 */       if (parent == marker) {
/* 308 */         return true;
/*     */       }
/*     */       
/* 311 */       Marker[] localParents = (parent instanceof Log4jMarker) ? ((Log4jMarker)parent).parents : parent.getParents();
/* 312 */       if (localParents != null) {
/* 313 */         int localParentsLength = localParents.length;
/* 314 */         if (localParentsLength == 1) {
/* 315 */           return checkParent(localParents[0], marker);
/*     */         }
/* 317 */         if (localParentsLength == 2) {
/* 318 */           return (checkParent(localParents[0], marker) || checkParent(localParents[1], marker));
/*     */         }
/*     */         
/* 321 */         for (int i = 0; i < localParentsLength; i++) {
/* 322 */           Marker localParent = localParents[i];
/* 323 */           if (checkParent(localParent, marker)) {
/* 324 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 328 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @PerformanceSensitive({"allocation"})
/*     */     private static boolean contains(Marker parent, Marker... localParents) {
/* 338 */       for (int i = 0, localParentsLength = localParents.length; i < localParentsLength; i++) {
/* 339 */         Marker marker = localParents[i];
/* 340 */         if (marker == parent) {
/* 341 */           return true;
/*     */         }
/*     */       } 
/* 344 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 349 */       if (this == o) {
/* 350 */         return true;
/*     */       }
/* 352 */       if (o == null || !(o instanceof Marker)) {
/* 353 */         return false;
/*     */       }
/* 355 */       Marker marker = (Marker)o;
/* 356 */       return this.name.equals(marker.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 361 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 367 */       StringBuilder sb = new StringBuilder();
/* 368 */       formatTo(sb);
/* 369 */       return sb.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public void formatTo(StringBuilder sb) {
/* 374 */       sb.append(this.name);
/* 375 */       Marker[] localParents = this.parents;
/* 376 */       if (localParents != null) {
/* 377 */         addParentInfo(sb, localParents);
/*     */       }
/*     */     }
/*     */     
/*     */     @PerformanceSensitive({"allocation"})
/*     */     private static void addParentInfo(StringBuilder sb, Marker... parents) {
/* 383 */       sb.append("[ ");
/* 384 */       boolean first = true;
/*     */       
/* 386 */       for (int i = 0, parentsLength = parents.length; i < parentsLength; i++) {
/* 387 */         Marker marker = parents[i];
/* 388 */         if (!first) {
/* 389 */           sb.append(", ");
/*     */         }
/* 391 */         first = false;
/* 392 */         sb.append(marker.getName());
/* 393 */         Marker[] p = (marker instanceof Log4jMarker) ? ((Log4jMarker)marker).parents : marker.getParents();
/* 394 */         if (p != null) {
/* 395 */           addParentInfo(sb, p);
/*     */         }
/*     */       } 
/* 398 */       sb.append(" ]");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void requireNonNull(Object obj, String message) {
/* 404 */     if (obj == null)
/* 405 */       throw new IllegalArgumentException(message); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\MarkerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */