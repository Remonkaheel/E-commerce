/*     */ package org.apache.logging.log4j;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloseableThreadContext
/*     */ {
/*     */   public static Instance push(String message) {
/*  49 */     return (new Instance()).push(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instance push(String message, Object... args) {
/*  61 */     return (new Instance()).push(message, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instance put(String key, String value) {
/*  74 */     return (new Instance()).put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instance pushAll(List<String> messages) {
/*  86 */     return (new Instance()).pushAll(messages);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Instance putAll(Map<String, String> values) {
/*  99 */     return (new Instance()).putAll(values);
/*     */   }
/*     */   
/*     */   public static class Instance
/*     */     implements AutoCloseable {
/* 104 */     private int pushCount = 0;
/* 105 */     private final Map<String, String> originalValues = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Instance push(String message) {
/* 117 */       ThreadContext.push(message);
/* 118 */       this.pushCount++;
/* 119 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Instance push(String message, Object[] args) {
/* 131 */       ThreadContext.push(message, args);
/* 132 */       this.pushCount++;
/* 133 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Instance put(String key, String value) {
/* 147 */       if (!this.originalValues.containsKey(key)) {
/* 148 */         this.originalValues.put(key, ThreadContext.get(key));
/*     */       }
/* 150 */       ThreadContext.put(key, value);
/* 151 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Instance putAll(Map<String, String> values) {
/* 164 */       Map<String, String> currentValues = ThreadContext.getContext();
/* 165 */       ThreadContext.putAll(values);
/* 166 */       for (String key : values.keySet()) {
/* 167 */         if (!this.originalValues.containsKey(key)) {
/* 168 */           this.originalValues.put(key, currentValues.get(key));
/*     */         }
/*     */       } 
/* 171 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Instance pushAll(List<String> messages) {
/* 183 */       for (String message : messages) {
/* 184 */         push(message);
/*     */       }
/* 186 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 201 */       closeStack();
/* 202 */       closeMap();
/*     */     }
/*     */     
/*     */     private void closeMap() {
/* 206 */       Map<String, String> valuesToReplace = new HashMap<>(this.originalValues.size());
/* 207 */       List<String> keysToRemove = new ArrayList<>(this.originalValues.size());
/* 208 */       for (Map.Entry<String, String> entry : this.originalValues.entrySet()) {
/* 209 */         String key = entry.getKey();
/* 210 */         String originalValue = entry.getValue();
/* 211 */         if (null == originalValue) {
/* 212 */           keysToRemove.add(key); continue;
/*     */         } 
/* 214 */         valuesToReplace.put(key, originalValue);
/*     */       } 
/*     */       
/* 217 */       if (!valuesToReplace.isEmpty()) {
/* 218 */         ThreadContext.putAll(valuesToReplace);
/*     */       }
/* 220 */       if (!keysToRemove.isEmpty()) {
/* 221 */         ThreadContext.removeAll(keysToRemove);
/*     */       }
/*     */     }
/*     */     
/*     */     private void closeStack() {
/* 226 */       for (int i = 0; i < this.pushCount; i++) {
/* 227 */         ThreadContext.pop();
/*     */       }
/* 229 */       this.pushCount = 0;
/*     */     }
/*     */     
/*     */     private Instance() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\CloseableThreadContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */