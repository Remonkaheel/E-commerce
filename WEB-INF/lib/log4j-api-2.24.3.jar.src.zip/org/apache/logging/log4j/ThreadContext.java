/*     */ package org.apache.logging.log4j;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*     */ import org.apache.logging.log4j.spi.CleanableThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.DefaultThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.DefaultThreadContextStack;
/*     */ import org.apache.logging.log4j.spi.MutableThreadContextStack;
/*     */ import org.apache.logging.log4j.spi.ReadOnlyThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMap2;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMapFactory;
/*     */ import org.apache.logging.log4j.spi.ThreadContextStack;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.ProviderUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThreadContext
/*     */ {
/*     */   private static class EmptyThreadContextStack
/*     */     extends AbstractCollection<String>
/*     */     implements ThreadContextStack
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private EmptyThreadContextStack() {}
/*     */     
/*     */     public String pop() {
/*  59 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String peek() {
/*  64 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void push(String message) {
/*  69 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getDepth() {
/*  74 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> asList() {
/*  79 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void trim(int depth) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*  90 */       return (o instanceof Collection && ((Collection)o).isEmpty());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  96 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public ThreadContext.ContextStack copy() {
/* 101 */       return (ThreadContext.ContextStack)new MutableThreadContextStack();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] ignored) {
/* 106 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(String ignored) {
/* 111 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {}
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> ignored) {
/* 119 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends String> ignored) {
/* 124 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> ignored) {
/* 129 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> ignored) {
/* 134 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<String> iterator() {
/* 139 */       return Collections.emptyIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 144 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public ThreadContext.ContextStack getImmutableStackOrNull() {
/* 149 */       return (ThreadContext.ContextStack)this;
/*     */     }
/*     */   } public static interface ContextStack extends Serializable, Collection<String> { String pop(); String peek(); void push(String param1String); int getDepth();
/*     */     List<String> asList();
/*     */     void trim(int param1Int);
/*     */     ContextStack copy();
/*     */     ContextStack getImmutableStackOrNull(); }
/*     */   private static final class NoOpThreadContextStack extends EmptyThreadContextStack { public boolean add(String ignored) {
/* 157 */       return false;
/*     */     }
/*     */     private NoOpThreadContextStack() {}
/*     */     
/*     */     public boolean addAll(Collection<? extends String> ignored) {
/* 162 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void push(String ignored) {}
/*     */ 
/*     */     
/*     */     public boolean remove(Object ignored) {
/* 170 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> ignored) {
/* 175 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> ignored) {
/* 180 */       return false;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public static final Map<String, String> EMPTY_MAP = Collections.emptyMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public static final ThreadContextStack EMPTY_STACK = new EmptyThreadContextStack();
/*     */   
/*     */   private static final String DISABLE_STACK = "disableThreadContextStack";
/*     */   
/*     */   private static final String DISABLE_ALL = "disableThreadContext";
/*     */   
/*     */   private static ThreadContextStack contextStack;
/*     */   private static ThreadContextMap contextMap;
/*     */   private static ReadOnlyThreadContextMap readOnlyContextMap;
/*     */   
/*     */   static {
/* 208 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void init() {
/* 219 */     PropertiesUtil properties = PropertiesUtil.getProperties();
/*     */ 
/*     */     
/* 222 */     contextStack = (properties.getBooleanProperty("disableThreadContextStack") || properties.getBooleanProperty("disableThreadContext")) ? new NoOpThreadContextStack() : (ThreadContextStack)new DefaultThreadContextStack();
/*     */ 
/*     */     
/* 225 */     ThreadContextMapFactory.init();
/* 226 */     contextMap = ProviderUtil.getProvider().getThreadContextMapInstance();
/*     */     
/* 228 */     readOnlyContextMap = (contextMap instanceof ReadOnlyThreadContextMap) ? (ReadOnlyThreadContextMap)contextMap : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void put(String key, String value) {
/* 243 */     contextMap.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putIfNull(String key, String value) {
/* 259 */     if (!contextMap.containsKey(key)) {
/* 260 */       contextMap.put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putAll(Map<String, String> m) {
/* 274 */     if (contextMap instanceof ThreadContextMap2) {
/* 275 */       ((ThreadContextMap2)contextMap).putAll(m);
/* 276 */     } else if (contextMap instanceof DefaultThreadContextMap) {
/* 277 */       ((DefaultThreadContextMap)contextMap).putAll(m);
/*     */     } else {
/* 279 */       for (Map.Entry<String, String> entry : m.entrySet()) {
/* 280 */         contextMap.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(String key) {
/* 296 */     return contextMap.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String key) {
/* 305 */     contextMap.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeAll(Iterable<String> keys) {
/* 316 */     if (contextMap instanceof CleanableThreadContextMap) {
/* 317 */       ((CleanableThreadContextMap)contextMap).removeAll(keys);
/* 318 */     } else if (contextMap instanceof DefaultThreadContextMap) {
/* 319 */       ((DefaultThreadContextMap)contextMap).removeAll(keys);
/*     */     } else {
/* 321 */       for (String key : keys) {
/* 322 */         contextMap.remove(key);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearMap() {
/* 331 */     contextMap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearAll() {
/* 338 */     clearMap();
/* 339 */     clearStack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean containsKey(String key) {
/* 349 */     return contextMap.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getContext() {
/* 358 */     return contextMap.getCopy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getImmutableContext() {
/* 367 */     Map<String, String> map = contextMap.getImmutableMapOrNull();
/* 368 */     return (map == null) ? EMPTY_MAP : map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyThreadContextMap getThreadContextMap() {
/* 386 */     return readOnlyContextMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty() {
/* 395 */     return contextMap.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearStack() {
/* 402 */     contextStack.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContextStack cloneStack() {
/* 411 */     return contextStack.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContextStack getImmutableStack() {
/* 420 */     ContextStack result = contextStack.getImmutableStackOrNull();
/* 421 */     return (result == null) ? (ContextStack)EMPTY_STACK : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStack(Collection<String> stack) {
/* 430 */     if (stack.isEmpty()) {
/*     */       return;
/*     */     }
/* 433 */     contextStack.clear();
/* 434 */     contextStack.addAll(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDepth() {
/* 445 */     return contextStack.getDepth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String pop() {
/* 459 */     return contextStack.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String peek() {
/* 473 */     return contextStack.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void push(String message) {
/* 486 */     contextStack.push(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void push(String message, Object... args) {
/* 502 */     contextStack.push(ParameterizedMessage.format(message, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeStack() {
/* 522 */     contextStack.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void trim(int depth) {
/* 558 */     contextStack.trim(depth);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\log4j-api-2.24.3.jar!\org\apache\logging\log4j\ThreadContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */