/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanWrapperImpl
/*     */   extends AbstractNestablePropertyAccessor
/*     */   implements BeanWrapper
/*     */ {
/*     */   @Nullable
/*     */   private CachedIntrospectionResults cachedIntrospectionResults;
/*     */   
/*     */   public BeanWrapperImpl() {
/*  77 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanWrapperImpl(boolean registerDefaultEditors) {
/*  87 */     super(registerDefaultEditors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanWrapperImpl(Object object) {
/*  95 */     super(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanWrapperImpl(Class<?> clazz) {
/* 103 */     super(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanWrapperImpl(Object object, String nestedPath, Object rootObject) {
/* 114 */     super(object, nestedPath, rootObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanWrapperImpl(Object object, String nestedPath, BeanWrapperImpl parent) {
/* 125 */     super(object, nestedPath, parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanInstance(Object object) {
/* 136 */     this.wrappedObject = object;
/* 137 */     this.rootObject = object;
/* 138 */     this.typeConverterDelegate = new TypeConverterDelegate(this, this.wrappedObject);
/* 139 */     setIntrospectionClass(object.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWrappedInstance(Object object, @Nullable String nestedPath, @Nullable Object rootObject) {
/* 144 */     super.setWrappedInstance(object, nestedPath, rootObject);
/* 145 */     setIntrospectionClass(getWrappedClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setIntrospectionClass(Class<?> clazz) {
/* 154 */     if (this.cachedIntrospectionResults != null && this.cachedIntrospectionResults.getBeanClass() != clazz) {
/* 155 */       this.cachedIntrospectionResults = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CachedIntrospectionResults getCachedIntrospectionResults() {
/* 164 */     if (this.cachedIntrospectionResults == null) {
/* 165 */       this.cachedIntrospectionResults = CachedIntrospectionResults.forClass(getWrappedClass());
/*     */     }
/* 167 */     return this.cachedIntrospectionResults;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object convertForProperty(@Nullable Object value, String propertyName) throws TypeMismatchException {
/* 183 */     CachedIntrospectionResults cachedIntrospectionResults = getCachedIntrospectionResults();
/* 184 */     PropertyDescriptor pd = cachedIntrospectionResults.getPropertyDescriptor(propertyName);
/* 185 */     if (pd == null) {
/* 186 */       throw new InvalidPropertyException(getRootClass(), getNestedPath() + getNestedPath(), "No property '" + propertyName + "' found");
/*     */     }
/*     */     
/* 189 */     TypeDescriptor td = ((GenericTypeAwarePropertyDescriptor)pd).getTypeDescriptor();
/* 190 */     return convertForProperty(propertyName, (Object)null, value, td);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected BeanPropertyHandler getLocalPropertyHandler(String propertyName) {
/* 196 */     PropertyDescriptor pd = getCachedIntrospectionResults().getPropertyDescriptor(propertyName);
/* 197 */     return (pd != null) ? new BeanPropertyHandler((GenericTypeAwarePropertyDescriptor)pd) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BeanWrapperImpl newNestedPropertyAccessor(Object object, String nestedPath) {
/* 202 */     return new BeanWrapperImpl(object, nestedPath, this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NotWritablePropertyException createNotWritablePropertyException(String propertyName) {
/* 207 */     PropertyMatches matches = PropertyMatches.forProperty(propertyName, getRootClass());
/* 208 */     throw new NotWritablePropertyException(getRootClass(), getNestedPath() + getNestedPath(), matches
/* 209 */         .buildErrorMessage(), matches.getPossibleMatches());
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors() {
/* 214 */     return getCachedIntrospectionResults().getPropertyDescriptors();
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyDescriptor getPropertyDescriptor(String propertyName) throws InvalidPropertyException {
/* 219 */     BeanWrapperImpl nestedBw = (BeanWrapperImpl)getPropertyAccessorForPropertyPath(propertyName);
/* 220 */     String finalPath = getFinalPath(nestedBw, propertyName);
/* 221 */     PropertyDescriptor pd = nestedBw.getCachedIntrospectionResults().getPropertyDescriptor(finalPath);
/* 222 */     if (pd == null) {
/* 223 */       throw new InvalidPropertyException(getRootClass(), getNestedPath() + getNestedPath(), "No property '" + propertyName + "' found");
/*     */     }
/*     */     
/* 226 */     return pd;
/*     */   }
/*     */   
/*     */   private class BeanPropertyHandler
/*     */     extends AbstractNestablePropertyAccessor.PropertyHandler
/*     */   {
/*     */     private final GenericTypeAwarePropertyDescriptor pd;
/*     */     
/*     */     public BeanPropertyHandler(GenericTypeAwarePropertyDescriptor pd) {
/* 235 */       super(pd.getPropertyType(), (pd.getReadMethod() != null), (pd.getWriteMethod() != null));
/* 236 */       this.pd = pd;
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeDescriptor toTypeDescriptor() {
/* 241 */       return this.pd.getTypeDescriptor();
/*     */     }
/*     */ 
/*     */     
/*     */     public ResolvableType getResolvableType() {
/* 246 */       return this.pd.getReadMethodType();
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeDescriptor getMapValueType(int nestingLevel) {
/* 251 */       return new TypeDescriptor(this.pd
/* 252 */           .getReadMethodType().getNested(nestingLevel).asMap().getGeneric(new int[] { 1 }, ), null, this.pd
/* 253 */           .getTypeDescriptor().getAnnotations());
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeDescriptor getCollectionType(int nestingLevel) {
/* 258 */       return new TypeDescriptor(this.pd
/* 259 */           .getReadMethodType().getNested(nestingLevel).asCollection().getGeneric(new int[0]), null, this.pd
/* 260 */           .getTypeDescriptor().getAnnotations());
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public TypeDescriptor nested(int level) {
/* 266 */       return this.pd.getTypeDescriptor().nested(level);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getValue() throws Exception {
/* 272 */       Method readMethod = this.pd.getReadMethod();
/* 273 */       Assert.state((readMethod != null), "No read method available");
/* 274 */       ReflectionUtils.makeAccessible(readMethod);
/* 275 */       return readMethod.invoke(BeanWrapperImpl.this.getWrappedInstance(), (Object[])null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(@Nullable Object value) throws Exception {
/* 280 */       Method writeMethod = this.pd.getWriteMethodForActualAccess();
/* 281 */       ReflectionUtils.makeAccessible(writeMethod);
/* 282 */       writeMethod.invoke(BeanWrapperImpl.this.getWrappedInstance(), new Object[] { value });
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setValueFallbackIfPossible(@Nullable Object value) {
/*     */       try {
/* 288 */         Method writeMethod = this.pd.getWriteMethodFallback((value != null) ? value.getClass() : null);
/* 289 */         if (writeMethod == null) {
/* 290 */           writeMethod = this.pd.getUniqueWriteMethodFallback();
/* 291 */           if (writeMethod != null)
/*     */           {
/*     */             
/* 294 */             value = BeanWrapperImpl.this.convertForProperty(this.pd.getName(), (Object)null, value, new TypeDescriptor(new MethodParameter(writeMethod, 0)));
/*     */           }
/*     */         } 
/*     */         
/* 298 */         if (writeMethod != null) {
/* 299 */           ReflectionUtils.makeAccessible(writeMethod);
/* 300 */           writeMethod.invoke(BeanWrapperImpl.this.getWrappedInstance(), new Object[] { value });
/* 301 */           return true;
/*     */         }
/*     */       
/* 304 */       } catch (Exception ex) {
/* 305 */         LogFactory.getLog(BeanPropertyHandler.class).debug("Write method fallback failed", ex);
/*     */       } 
/* 307 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\BeanWrapperImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */