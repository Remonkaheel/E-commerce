/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Spliterator;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutablePropertyValues
/*     */   implements PropertyValues, Serializable
/*     */ {
/*     */   private final List<PropertyValue> propertyValueList;
/*     */   @Nullable
/*     */   private Set<String> processedProperties;
/*     */   private volatile boolean converted;
/*     */   
/*     */   public MutablePropertyValues() {
/*  60 */     this.propertyValueList = new ArrayList<>(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues(@Nullable PropertyValues original) {
/*  73 */     if (original != null) {
/*  74 */       PropertyValue[] pvs = original.getPropertyValues();
/*  75 */       this.propertyValueList = new ArrayList<>(pvs.length);
/*  76 */       for (PropertyValue pv : pvs) {
/*  77 */         this.propertyValueList.add(new PropertyValue(pv));
/*     */       }
/*     */     } else {
/*     */       
/*  81 */       this.propertyValueList = new ArrayList<>(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues(@Nullable Map<?, ?> original) {
/*  93 */     if (original != null) {
/*  94 */       this.propertyValueList = new ArrayList<>(original.size());
/*  95 */       original.forEach((attrName, attrValue) -> this.propertyValueList.add(new PropertyValue(attrName.toString(), attrValue)));
/*     */     }
/*     */     else {
/*     */       
/*  99 */       this.propertyValueList = new ArrayList<>(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues(@Nullable List<PropertyValue> propertyValueList) {
/* 111 */     this
/* 112 */       .propertyValueList = (propertyValueList != null) ? propertyValueList : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PropertyValue> getPropertyValueList() {
/* 123 */     return this.propertyValueList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 130 */     return this.propertyValueList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues addPropertyValues(@Nullable PropertyValues other) {
/* 141 */     if (other != null) {
/* 142 */       PropertyValue[] pvs = other.getPropertyValues();
/* 143 */       for (PropertyValue pv : pvs) {
/* 144 */         addPropertyValue(new PropertyValue(pv));
/*     */       }
/*     */     } 
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues addPropertyValues(@Nullable Map<?, ?> other) {
/* 157 */     if (other != null) {
/* 158 */       other.forEach((attrName, attrValue) -> addPropertyValue(new PropertyValue(attrName.toString(), attrValue)));
/*     */     }
/*     */     
/* 161 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues addPropertyValue(PropertyValue pv) {
/* 171 */     for (int i = 0; i < this.propertyValueList.size(); i++) {
/* 172 */       PropertyValue currentPv = this.propertyValueList.get(i);
/* 173 */       if (currentPv.getName().equals(pv.getName())) {
/* 174 */         pv = mergeIfRequired(pv, currentPv);
/* 175 */         setPropertyValueAt(pv, i);
/* 176 */         return this;
/*     */       } 
/*     */     } 
/* 179 */     this.propertyValueList.add(pv);
/* 180 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyValue(String propertyName, Object propertyValue) {
/* 193 */     addPropertyValue(new PropertyValue(propertyName, propertyValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutablePropertyValues add(String propertyName, @Nullable Object propertyValue) {
/* 204 */     addPropertyValue(new PropertyValue(propertyName, propertyValue));
/* 205 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyValueAt(PropertyValue pv, int i) {
/* 213 */     this.propertyValueList.set(i, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PropertyValue mergeIfRequired(PropertyValue newPv, PropertyValue currentPv) {
/* 222 */     Object value = newPv.getValue();
/* 223 */     if (value instanceof Mergeable) { Mergeable mergeable = (Mergeable)value;
/* 224 */       if (mergeable.isMergeEnabled()) {
/* 225 */         Object merged = mergeable.merge(currentPv.getValue());
/* 226 */         return new PropertyValue(newPv.getName(), merged);
/*     */       }  }
/*     */     
/* 229 */     return newPv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyValue(PropertyValue pv) {
/* 237 */     this.propertyValueList.remove(pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyValue(String propertyName) {
/* 246 */     this.propertyValueList.remove(getPropertyValue(propertyName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<PropertyValue> iterator() {
/* 252 */     return Collections.<PropertyValue>unmodifiableList(this.propertyValueList).iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Spliterator<PropertyValue> spliterator() {
/* 257 */     return this.propertyValueList.spliterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<PropertyValue> stream() {
/* 262 */     return this.propertyValueList.stream();
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyValue[] getPropertyValues() {
/* 267 */     return this.propertyValueList.<PropertyValue>toArray(new PropertyValue[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyValue getPropertyValue(String propertyName) {
/* 273 */     for (PropertyValue pv : this.propertyValueList) {
/* 274 */       if (pv.getName().equals(propertyName)) {
/* 275 */         return pv;
/*     */       }
/*     */     } 
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object get(String propertyName) {
/* 291 */     PropertyValue pv = getPropertyValue(propertyName);
/* 292 */     return (pv != null) ? pv.getValue() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyValues changesSince(PropertyValues old) {
/* 297 */     MutablePropertyValues changes = new MutablePropertyValues();
/* 298 */     if (old == this) {
/* 299 */       return changes;
/*     */     }
/*     */ 
/*     */     
/* 303 */     for (PropertyValue newPv : this.propertyValueList) {
/*     */       
/* 305 */       PropertyValue pvOld = old.getPropertyValue(newPv.getName());
/* 306 */       if (pvOld == null || !pvOld.equals(newPv)) {
/* 307 */         changes.addPropertyValue(newPv);
/*     */       }
/*     */     } 
/* 310 */     return changes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String propertyName) {
/* 315 */     return (getPropertyValue(propertyName) != null || (this.processedProperties != null && this.processedProperties
/* 316 */       .contains(propertyName)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 321 */     return this.propertyValueList.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerProcessedProperty(String propertyName) {
/* 334 */     if (this.processedProperties == null) {
/* 335 */       this.processedProperties = new HashSet<>(4);
/*     */     }
/* 337 */     this.processedProperties.add(propertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearProcessedProperty(String propertyName) {
/* 345 */     if (this.processedProperties != null) {
/* 346 */       this.processedProperties.remove(propertyName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConverted() {
/* 355 */     this.converted = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConverted() {
/* 363 */     return this.converted;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 369 */     if (this != other) { if (other instanceof MutablePropertyValues) { MutablePropertyValues that = (MutablePropertyValues)other; if (this.propertyValueList
/* 370 */           .equals(that.propertyValueList)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 375 */     return this.propertyValueList.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 380 */     PropertyValue[] pvs = getPropertyValues();
/* 381 */     if (pvs.length > 0) {
/* 382 */       return "PropertyValues: length=" + pvs.length + "; " + StringUtils.arrayToDelimitedString((Object[])pvs, "; ");
/*     */     }
/* 384 */     return "PropertyValues: length=0";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\MutablePropertyValues.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */