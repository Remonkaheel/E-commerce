/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.BeanInfo;
/*    */ import java.beans.IntrospectionException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.lang.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedBeanInfoFactory
/*    */   extends StandardBeanInfoFactory
/*    */ {
/*    */   @NonNull
/*    */   public BeanInfo getBeanInfo(Class<?> beanClass) throws IntrospectionException {
/* 48 */     BeanInfo beanInfo = super.getBeanInfo(beanClass);
/* 49 */     return supports(beanClass) ? new ExtendedBeanInfo(beanInfo) : beanInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean supports(Class<?> beanClass) {
/* 57 */     for (Method method : beanClass.getMethods()) {
/* 58 */       if (ExtendedBeanInfo.isCandidateWriteMethod(method)) {
/* 59 */         return true;
/*    */       }
/*    */     } 
/* 62 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\ExtendedBeanInfoFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */