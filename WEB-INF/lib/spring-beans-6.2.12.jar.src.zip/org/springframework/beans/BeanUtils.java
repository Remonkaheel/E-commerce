/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.ConstructorProperties;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.RecordComponent;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.full.KClasses;
/*     */ import kotlin.reflect.jvm.KCallablesJvm;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BeanUtils
/*     */ {
/*  75 */   private static final ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */ 
/*     */ 
/*     */   
/*  79 */   private static final Set<Class<?>> unknownEditorTypes = Collections.newSetFromMap((Map<Class<?>, Boolean>)new ConcurrentReferenceHashMap(64));
/*     */   
/*  81 */   private static final Map<Class<?>, Object> DEFAULT_TYPE_VALUES = Map.of(boolean.class, 
/*  82 */       Boolean.valueOf(false), byte.class, 
/*  83 */       Byte.valueOf((byte)0), short.class, 
/*  84 */       Short.valueOf((short)0), int.class, 
/*  85 */       Integer.valueOf(0), long.class, 
/*  86 */       Long.valueOf(0L), float.class, 
/*  87 */       Float.valueOf(0.0F), double.class, 
/*  88 */       Double.valueOf(0.0D), char.class, 
/*  89 */       Character.valueOf(false));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static <T> T instantiate(Class<T> clazz) throws BeanInstantiationException {
/* 103 */     Assert.notNull(clazz, "Class must not be null");
/* 104 */     if (clazz.isInterface()) {
/* 105 */       throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */     }
/*     */     try {
/* 108 */       return clazz.newInstance();
/*     */     }
/* 110 */     catch (InstantiationException ex) {
/* 111 */       throw new BeanInstantiationException(clazz, "Is it an abstract class?", ex);
/*     */     }
/* 113 */     catch (IllegalAccessException ex) {
/* 114 */       throw new BeanInstantiationException(clazz, "Is the constructor accessible?", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T instantiateClass(Class<T> clazz) throws BeanInstantiationException {
/*     */     Constructor<T> ctor;
/* 135 */     Assert.notNull(clazz, "Class must not be null");
/* 136 */     if (clazz.isInterface()) {
/* 137 */       throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */     }
/*     */     
/*     */     try {
/* 141 */       ctor = clazz.getDeclaredConstructor(new Class[0]);
/*     */     }
/* 143 */     catch (NoSuchMethodException ex) {
/* 144 */       ctor = findPrimaryConstructor(clazz);
/* 145 */       if (ctor == null) {
/* 146 */         throw new BeanInstantiationException(clazz, "No default constructor found", ex);
/*     */       }
/*     */     }
/* 149 */     catch (LinkageError err) {
/* 150 */       throw new BeanInstantiationException(clazz, "Unresolvable class definition", err);
/*     */     } 
/* 152 */     return instantiateClass(ctor, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T instantiateClass(Class<?> clazz, Class<T> assignableTo) throws BeanInstantiationException {
/* 170 */     Assert.isAssignable(assignableTo, clazz);
/* 171 */     return instantiateClass((Class)clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T instantiateClass(Constructor<T> ctor, Object... args) throws BeanInstantiationException {
/* 187 */     Assert.notNull(ctor, "Constructor must not be null");
/*     */     try {
/* 189 */       ReflectionUtils.makeAccessible(ctor);
/* 190 */       if (KotlinDetector.isKotlinReflectPresent() && KotlinDetector.isKotlinType(ctor.getDeclaringClass())) {
/* 191 */         return KotlinDelegate.instantiateClass(ctor, args);
/*     */       }
/*     */       
/* 194 */       int parameterCount = ctor.getParameterCount();
/* 195 */       Assert.isTrue((args.length <= parameterCount), "Can't specify more arguments than constructor parameters");
/* 196 */       if (parameterCount == 0) {
/* 197 */         return ctor.newInstance(new Object[0]);
/*     */       }
/* 199 */       Class<?>[] parameterTypes = ctor.getParameterTypes();
/* 200 */       Object[] argsWithDefaultValues = new Object[args.length];
/* 201 */       for (int i = 0; i < args.length; i++) {
/* 202 */         if (args[i] == null) {
/* 203 */           Class<?> parameterType = parameterTypes[i];
/* 204 */           argsWithDefaultValues[i] = parameterType.isPrimitive() ? DEFAULT_TYPE_VALUES.get(parameterType) : null;
/*     */         } else {
/*     */           
/* 207 */           argsWithDefaultValues[i] = args[i];
/*     */         } 
/*     */       } 
/* 210 */       return ctor.newInstance(argsWithDefaultValues);
/*     */     
/*     */     }
/* 213 */     catch (InstantiationException ex) {
/* 214 */       throw new BeanInstantiationException(ctor, "Is it an abstract class?", ex);
/*     */     }
/* 216 */     catch (IllegalAccessException ex) {
/* 217 */       throw new BeanInstantiationException(ctor, "Is the constructor accessible?", ex);
/*     */     }
/* 219 */     catch (IllegalArgumentException ex) {
/* 220 */       throw new BeanInstantiationException(ctor, "Illegal arguments for constructor", ex);
/*     */     }
/* 222 */     catch (InvocationTargetException ex) {
/* 223 */       throw new BeanInstantiationException(ctor, "Constructor threw exception", ex.getTargetException());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Constructor<T> getResolvableConstructor(Class<T> clazz) {
/* 240 */     Constructor<T> ctor = findPrimaryConstructor(clazz);
/* 241 */     if (ctor != null) {
/* 242 */       return ctor;
/*     */     }
/*     */     
/* 245 */     Constructor[] arrayOfConstructor = (Constructor[])clazz.getConstructors();
/* 246 */     if (arrayOfConstructor.length == 1)
/*     */     {
/* 248 */       return arrayOfConstructor[0];
/*     */     }
/* 250 */     if (arrayOfConstructor.length == 0) {
/*     */       
/* 252 */       arrayOfConstructor = (Constructor[])clazz.getDeclaredConstructors();
/* 253 */       if (arrayOfConstructor.length == 1)
/*     */       {
/* 255 */         return arrayOfConstructor[0];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 261 */       return clazz.getDeclaredConstructor(new Class[0]);
/*     */     }
/* 263 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 268 */       throw new IllegalStateException("No primary or single unique constructor found for " + String.valueOf(clazz));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> Constructor<T> findPrimaryConstructor(Class<T> clazz) {
/* 283 */     Assert.notNull(clazz, "Class must not be null");
/* 284 */     if (KotlinDetector.isKotlinReflectPresent() && KotlinDetector.isKotlinType(clazz)) {
/* 285 */       return KotlinDelegate.findPrimaryConstructor(clazz);
/*     */     }
/* 287 */     if (clazz.isRecord()) {
/*     */       
/*     */       try {
/* 290 */         RecordComponent[] components = clazz.getRecordComponents();
/* 291 */         Class<?>[] paramTypes = new Class[components.length];
/* 292 */         for (int i = 0; i < components.length; i++) {
/* 293 */           paramTypes[i] = components[i].getType();
/*     */         }
/* 295 */         return clazz.getDeclaredConstructor(paramTypes);
/*     */       }
/* 297 */       catch (NoSuchMethodException noSuchMethodException) {}
/*     */     }
/*     */     
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method findMethod(Class<?> clazz, String methodName, Class<?>... paramTypes) {
/*     */     try {
/* 320 */       return clazz.getMethod(methodName, paramTypes);
/*     */     }
/* 322 */     catch (NoSuchMethodException ex) {
/* 323 */       return findDeclaredMethod(clazz, methodName, paramTypes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method findDeclaredMethod(Class<?> clazz, String methodName, Class<?>... paramTypes) {
/*     */     try {
/* 341 */       return clazz.getDeclaredMethod(methodName, paramTypes);
/*     */     }
/* 343 */     catch (NoSuchMethodException ex) {
/* 344 */       if (clazz.getSuperclass() != null) {
/* 345 */         return findDeclaredMethod(clazz.getSuperclass(), methodName, paramTypes);
/*     */       }
/* 347 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method findMethodWithMinimalParameters(Class<?> clazz, String methodName) throws IllegalArgumentException {
/* 370 */     Method targetMethod = findMethodWithMinimalParameters(clazz.getMethods(), methodName);
/* 371 */     if (targetMethod == null) {
/* 372 */       targetMethod = findDeclaredMethodWithMinimalParameters(clazz, methodName);
/*     */     }
/* 374 */     return targetMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method findDeclaredMethodWithMinimalParameters(Class<?> clazz, String methodName) throws IllegalArgumentException {
/* 393 */     Method targetMethod = findMethodWithMinimalParameters(clazz.getDeclaredMethods(), methodName);
/* 394 */     if (targetMethod == null && clazz.getSuperclass() != null) {
/* 395 */       targetMethod = findDeclaredMethodWithMinimalParameters(clazz.getSuperclass(), methodName);
/*     */     }
/* 397 */     return targetMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method findMethodWithMinimalParameters(Method[] methods, String methodName) throws IllegalArgumentException {
/* 413 */     Method targetMethod = null;
/* 414 */     int numMethodsFoundWithCurrentMinimumArgs = 0;
/* 415 */     for (Method method : methods) {
/* 416 */       if (method.getName().equals(methodName)) {
/* 417 */         int numParams = method.getParameterCount();
/* 418 */         if (targetMethod == null || numParams < targetMethod.getParameterCount()) {
/* 419 */           targetMethod = method;
/* 420 */           numMethodsFoundWithCurrentMinimumArgs = 1;
/*     */         }
/* 422 */         else if (!method.isBridge() && targetMethod.getParameterCount() == numParams) {
/* 423 */           if (targetMethod.isBridge()) {
/*     */             
/* 425 */             targetMethod = method;
/*     */           }
/*     */           else {
/*     */             
/* 429 */             numMethodsFoundWithCurrentMinimumArgs++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 434 */     if (numMethodsFoundWithCurrentMinimumArgs > 1) {
/* 435 */       throw new IllegalArgumentException("Cannot resolve method '" + methodName + "' to a unique method. Attempted to resolve to overloaded method with the least number of parameters but there were " + numMethodsFoundWithCurrentMinimumArgs + " candidates.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 440 */     return targetMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method resolveSignature(String signature, Class<?> clazz) {
/* 463 */     Assert.hasText(signature, "'signature' must not be empty");
/* 464 */     Assert.notNull(clazz, "Class must not be null");
/* 465 */     int startParen = signature.indexOf('(');
/* 466 */     int endParen = signature.indexOf(')');
/* 467 */     if (startParen > -1 && endParen == -1) {
/* 468 */       throw new IllegalArgumentException("Invalid method signature '" + signature + "': expected closing ')' for args list");
/*     */     }
/*     */     
/* 471 */     if (startParen == -1 && endParen > -1) {
/* 472 */       throw new IllegalArgumentException("Invalid method signature '" + signature + "': expected opening '(' for args list");
/*     */     }
/*     */     
/* 475 */     if (startParen == -1) {
/* 476 */       return findMethodWithMinimalParameters(clazz, signature);
/*     */     }
/*     */     
/* 479 */     String methodName = signature.substring(0, startParen);
/*     */     
/* 481 */     String[] parameterTypeNames = StringUtils.commaDelimitedListToStringArray(signature.substring(startParen + 1, endParen));
/* 482 */     Class<?>[] parameterTypes = new Class[parameterTypeNames.length];
/* 483 */     for (int i = 0; i < parameterTypeNames.length; i++) {
/* 484 */       String parameterTypeName = parameterTypeNames[i].trim();
/*     */       try {
/* 486 */         parameterTypes[i] = ClassUtils.forName(parameterTypeName, clazz.getClassLoader());
/*     */       }
/* 488 */       catch (Throwable ex) {
/* 489 */         throw new IllegalArgumentException("Invalid method signature: unable to resolve type [" + parameterTypeName + "] for argument " + i + ". Root cause: " + String.valueOf(ex));
/*     */       } 
/*     */     } 
/*     */     
/* 493 */     return findMethod(clazz, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyDescriptor[] getPropertyDescriptors(Class<?> clazz) throws BeansException {
/* 505 */     return CachedIntrospectionResults.forClass(clazz).getPropertyDescriptors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static PropertyDescriptor getPropertyDescriptor(Class<?> clazz, String propertyName) throws BeansException {
/* 517 */     return CachedIntrospectionResults.forClass(clazz).getPropertyDescriptor(propertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static PropertyDescriptor findPropertyForMethod(Method method) throws BeansException {
/* 531 */     return findPropertyForMethod(method, method.getDeclaringClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static PropertyDescriptor findPropertyForMethod(Method method, Class<?> clazz) throws BeansException {
/* 546 */     Assert.notNull(method, "Method must not be null");
/* 547 */     PropertyDescriptor[] pds = getPropertyDescriptors(clazz);
/* 548 */     for (PropertyDescriptor pd : pds) {
/* 549 */       if (method.equals(pd.getReadMethod()) || method.equals(pd.getWriteMethod())) {
/* 550 */         return pd;
/*     */       }
/*     */     } 
/* 553 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static PropertyEditor findEditorByConvention(@Nullable Class<?> targetType) {
/* 567 */     if (targetType == null || targetType.isArray() || unknownEditorTypes.contains(targetType)) {
/* 568 */       return null;
/*     */     }
/*     */     
/* 571 */     ClassLoader cl = targetType.getClassLoader();
/* 572 */     if (cl == null) {
/*     */       try {
/* 574 */         cl = ClassLoader.getSystemClassLoader();
/* 575 */         if (cl == null) {
/* 576 */           return null;
/*     */         }
/*     */       }
/* 579 */       catch (Throwable ex) {
/*     */         
/* 581 */         return null;
/*     */       } 
/*     */     }
/*     */     
/* 585 */     String targetTypeName = targetType.getName();
/* 586 */     String editorName = targetTypeName + "Editor";
/*     */     try {
/* 588 */       Class<?> editorClass = cl.loadClass(editorName);
/* 589 */       if (editorClass != null) {
/* 590 */         if (!PropertyEditor.class.isAssignableFrom(editorClass)) {
/* 591 */           unknownEditorTypes.add(targetType);
/* 592 */           return null;
/*     */         } 
/* 594 */         return (PropertyEditor)instantiateClass(editorClass);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 599 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 602 */     unknownEditorTypes.add(targetType);
/* 603 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> findPropertyType(String propertyName, @Nullable Class<?>... beanClasses) {
/* 614 */     if (beanClasses != null) {
/* 615 */       for (Class<?> beanClass : beanClasses) {
/* 616 */         PropertyDescriptor pd = getPropertyDescriptor(beanClass, propertyName);
/* 617 */         if (pd != null) {
/* 618 */           return pd.getPropertyType();
/*     */         }
/*     */       } 
/*     */     }
/* 622 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasUniqueWriteMethod(PropertyDescriptor pd) {
/* 633 */     if (pd instanceof GenericTypeAwarePropertyDescriptor) { GenericTypeAwarePropertyDescriptor gpd = (GenericTypeAwarePropertyDescriptor)pd;
/* 634 */       return gpd.hasUniqueWriteMethod(); }
/*     */ 
/*     */     
/* 637 */     return (pd.getWriteMethod() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodParameter getWriteMethodParameter(PropertyDescriptor pd) {
/* 648 */     if (pd instanceof GenericTypeAwarePropertyDescriptor) { GenericTypeAwarePropertyDescriptor gpd = (GenericTypeAwarePropertyDescriptor)pd;
/* 649 */       return new MethodParameter(gpd.getWriteMethodParameter()); }
/*     */ 
/*     */     
/* 652 */     Method writeMethod = pd.getWriteMethod();
/* 653 */     Assert.state((writeMethod != null), "No write method available");
/* 654 */     return new MethodParameter(writeMethod, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getParameterNames(Constructor<?> ctor) {
/* 670 */     ConstructorProperties cp = ctor.<ConstructorProperties>getAnnotation(ConstructorProperties.class);
/* 671 */     String[] paramNames = (cp != null) ? cp.value() : parameterNameDiscoverer.getParameterNames(ctor);
/* 672 */     Assert.state((paramNames != null), () -> "Cannot resolve parameter names for constructor " + String.valueOf(ctor));
/*     */     
/* 674 */     int parameterCount = (KotlinDetector.isKotlinReflectPresent() && KotlinDelegate.hasDefaultConstructorMarker(ctor)) ? (ctor.getParameterCount() - 1) : ctor.getParameterCount();
/* 675 */     Assert.state((paramNames.length == parameterCount), () -> "Invalid number of parameter names: " + paramNames.length + " for constructor " + String.valueOf(ctor));
/*     */     
/* 677 */     return paramNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleProperty(Class<?> type) {
/* 693 */     Assert.notNull(type, "'type' must not be null");
/* 694 */     return (isSimpleValueType(type) || (type.isArray() && isSimpleValueType(type.componentType())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleValueType(Class<?> type) {
/* 713 */     return ClassUtils.isSimpleValueType(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyProperties(Object source, Object target) throws BeansException {
/* 748 */     copyProperties(source, target, null, (String[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyProperties(Object source, Object target, Class<?> editable) throws BeansException {
/* 769 */     copyProperties(source, target, editable, (String[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyProperties(Object source, Object target, String... ignoreProperties) throws BeansException {
/* 790 */     copyProperties(source, target, null, ignoreProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void copyProperties(Object source, Object target, @Nullable Class<?> editable, @Nullable String... ignoreProperties) throws BeansException {
/* 811 */     Assert.notNull(source, "Source must not be null");
/* 812 */     Assert.notNull(target, "Target must not be null");
/*     */     
/* 814 */     Class<?> actualEditable = target.getClass();
/* 815 */     if (editable != null) {
/* 816 */       if (!editable.isInstance(target)) {
/* 817 */         throw new IllegalArgumentException("Target class [" + target.getClass().getName() + "] not assignable to editable class [" + editable
/* 818 */             .getName() + "]");
/*     */       }
/* 820 */       actualEditable = editable;
/*     */     } 
/* 822 */     PropertyDescriptor[] targetPds = getPropertyDescriptors(actualEditable);
/* 823 */     Set<String> ignoredProps = (ignoreProperties != null) ? new HashSet<>(Arrays.asList(ignoreProperties)) : null;
/*     */     
/* 825 */     CachedIntrospectionResults sourceResults = (actualEditable != source.getClass()) ? CachedIntrospectionResults.forClass(source.getClass()) : null;
/*     */     
/* 827 */     for (PropertyDescriptor targetPd : targetPds) {
/* 828 */       Method writeMethod = targetPd.getWriteMethod();
/* 829 */       if (writeMethod != null && (ignoredProps == null || !ignoredProps.contains(targetPd.getName()))) {
/*     */         
/* 831 */         PropertyDescriptor sourcePd = (sourceResults != null) ? sourceResults.getPropertyDescriptor(targetPd.getName()) : targetPd;
/* 832 */         if (sourcePd != null) {
/* 833 */           Method readMethod = sourcePd.getReadMethod();
/* 834 */           if (readMethod != null && 
/* 835 */             isAssignable(writeMethod, readMethod, sourcePd, targetPd)) {
/*     */             try {
/* 837 */               ReflectionUtils.makeAccessible(readMethod);
/* 838 */               Object value = readMethod.invoke(source, new Object[0]);
/* 839 */               ReflectionUtils.makeAccessible(writeMethod);
/* 840 */               writeMethod.invoke(target, new Object[] { value });
/*     */             }
/* 842 */             catch (Throwable ex) {
/* 843 */               throw new FatalBeanException("Could not copy property '" + targetPd
/* 844 */                   .getName() + "' from source to target", ex);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAssignable(Method writeMethod, Method readMethod, PropertyDescriptor sourcePd, PropertyDescriptor targetPd) {
/* 856 */     Type paramType = writeMethod.getGenericParameterTypes()[0];
/* 857 */     if (paramType instanceof Class) { Class<?> clazz = (Class)paramType;
/* 858 */       return ClassUtils.isAssignable(clazz, readMethod.getReturnType()); }
/*     */     
/* 860 */     if (paramType.equals(readMethod.getGenericReturnType())) {
/* 861 */       return true;
/*     */     }
/*     */     
/* 864 */     ResolvableType sourceType = ((GenericTypeAwarePropertyDescriptor)sourcePd).getReadMethodType();
/* 865 */     ResolvableType targetType = ((GenericTypeAwarePropertyDescriptor)targetPd).getWriteMethodType();
/*     */     
/* 867 */     return (sourceType.hasUnresolvableGenerics() || targetType.hasUnresolvableGenerics()) ? 
/* 868 */       ClassUtils.isAssignable(writeMethod.getParameterTypes()[0], readMethod.getReturnType()) : 
/* 869 */       targetType.isAssignableFrom(sourceType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     @Nullable
/*     */     public static <T> Constructor<T> findPrimaryConstructor(Class<T> clazz) {
/*     */       try {
/* 889 */         KClass<T> kClass = JvmClassMappingKt.getKotlinClass(clazz);
/* 890 */         KFunction<T> primaryCtor = KClasses.getPrimaryConstructor(kClass);
/* 891 */         if (primaryCtor == null) {
/* 892 */           return null;
/*     */         }
/* 894 */         if (KotlinDetector.isInlineClass(clazz)) {
/* 895 */           Constructor[] arrayOfConstructor = (Constructor[])clazz.getDeclaredConstructors();
/* 896 */           Assert.state((arrayOfConstructor.length == 1), "Kotlin value classes annotated with @JvmInline are expected to have a single JVM constructor");
/*     */           
/* 898 */           return arrayOfConstructor[0];
/*     */         } 
/* 900 */         Constructor<T> constructor = ReflectJvmMapping.getJavaConstructor(primaryCtor);
/* 901 */         if (constructor == null) {
/* 902 */           throw new IllegalStateException("Failed to find Java constructor for Kotlin primary constructor: " + clazz
/* 903 */               .getName());
/*     */         }
/* 905 */         return constructor;
/*     */       }
/* 907 */       catch (UnsupportedOperationException ex) {
/* 908 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <T> T instantiateClass(Constructor<T> ctor, Object... args) throws IllegalAccessException, InvocationTargetException, InstantiationException {
/* 921 */       KFunction<T> kotlinConstructor = ReflectJvmMapping.getKotlinFunction(ctor);
/* 922 */       if (kotlinConstructor == null) {
/* 923 */         return ctor.newInstance(args);
/*     */       }
/*     */       
/* 926 */       if (!Modifier.isPublic(ctor.getModifiers()) || !Modifier.isPublic(ctor.getDeclaringClass().getModifiers())) {
/* 927 */         KCallablesJvm.setAccessible((KCallable)kotlinConstructor, true);
/*     */       }
/*     */       
/* 930 */       List<KParameter> parameters = kotlinConstructor.getParameters();
/*     */       
/* 932 */       Assert.isTrue((args.length <= parameters.size()), "Number of provided arguments must be less than or equal to the number of constructor parameters");
/*     */       
/* 934 */       if (parameters.isEmpty()) {
/* 935 */         return (T)kotlinConstructor.call(new Object[0]);
/*     */       }
/* 937 */       Map<KParameter, Object> argParameters = CollectionUtils.newHashMap(parameters.size());
/* 938 */       for (int i = 0; i < args.length; i++) {
/* 939 */         if (!((KParameter)parameters.get(i)).isOptional() || args[i] != null) {
/* 940 */           argParameters.put(parameters.get(i), args[i]);
/*     */         }
/*     */       } 
/* 943 */       return (T)kotlinConstructor.callBy(argParameters);
/*     */     }
/*     */     
/*     */     public static boolean hasDefaultConstructorMarker(Constructor<?> ctor) {
/* 947 */       int parameterCount = ctor.getParameterCount();
/* 948 */       return (parameterCount > 0 && ctor.getParameters()[parameterCount - 1].getType() == DefaultConstructorMarker.class);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\BeanUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */