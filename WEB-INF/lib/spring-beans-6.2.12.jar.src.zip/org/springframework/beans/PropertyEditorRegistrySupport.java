/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Path;
/*     */ import java.time.ZoneId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Currency;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TimeZone;
/*     */ import java.util.UUID;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.propertyeditors.ByteArrayPropertyEditor;
/*     */ import org.springframework.beans.propertyeditors.CharArrayPropertyEditor;
/*     */ import org.springframework.beans.propertyeditors.CharacterEditor;
/*     */ import org.springframework.beans.propertyeditors.CharsetEditor;
/*     */ import org.springframework.beans.propertyeditors.ClassArrayEditor;
/*     */ import org.springframework.beans.propertyeditors.ClassEditor;
/*     */ import org.springframework.beans.propertyeditors.CurrencyEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomBooleanEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomCollectionEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomMapEditor;
/*     */ import org.springframework.beans.propertyeditors.CustomNumberEditor;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.beans.propertyeditors.InputSourceEditor;
/*     */ import org.springframework.beans.propertyeditors.InputStreamEditor;
/*     */ import org.springframework.beans.propertyeditors.LocaleEditor;
/*     */ import org.springframework.beans.propertyeditors.PathEditor;
/*     */ import org.springframework.beans.propertyeditors.PatternEditor;
/*     */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*     */ import org.springframework.beans.propertyeditors.ReaderEditor;
/*     */ import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
/*     */ import org.springframework.beans.propertyeditors.TimeZoneEditor;
/*     */ import org.springframework.beans.propertyeditors.URIEditor;
/*     */ import org.springframework.beans.propertyeditors.URLEditor;
/*     */ import org.springframework.beans.propertyeditors.UUIDEditor;
/*     */ import org.springframework.beans.propertyeditors.ZoneIdEditor;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourceArrayPropertyEditor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyEditorRegistrySupport
/*     */   implements PropertyEditorRegistry
/*     */ {
/*     */   @Nullable
/*     */   private ConversionService conversionService;
/*     */   private boolean defaultEditorsActive = false;
/*     */   private boolean configValueEditorsActive = false;
/*     */   @Nullable
/*     */   private PropertyEditorRegistrar defaultEditorRegistrar;
/*     */   @Nullable
/*     */   private Map<Class<?>, PropertyEditor> defaultEditors;
/*     */   @Nullable
/*     */   private Map<Class<?>, PropertyEditor> overriddenDefaultEditors;
/*     */   @Nullable
/*     */   private Map<Class<?>, PropertyEditor> customEditors;
/*     */   @Nullable
/*     */   private Map<String, CustomEditorHolder> customEditorsForPath;
/*     */   @Nullable
/*     */   private Map<Class<?>, PropertyEditor> customEditorCache;
/*     */   
/*     */   public void setConversionService(@Nullable ConversionService conversionService) {
/* 126 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ConversionService getConversionService() {
/* 134 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerDefaultEditors() {
/* 147 */     this.defaultEditorsActive = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void useConfigValueEditors() {
/* 158 */     this.configValueEditorsActive = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultEditorRegistrar(PropertyEditorRegistrar registrar) {
/* 171 */     this.defaultEditorRegistrar = registrar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void overrideDefaultEditor(Class<?> requiredType, PropertyEditor propertyEditor) {
/* 184 */     if (this.overriddenDefaultEditors == null) {
/* 185 */       this.overriddenDefaultEditors = new HashMap<>();
/*     */     }
/* 187 */     this.overriddenDefaultEditors.put(requiredType, propertyEditor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyEditor getDefaultEditor(Class<?> requiredType) {
/* 200 */     if (!this.defaultEditorsActive) {
/* 201 */       return null;
/*     */     }
/* 203 */     if (this.overriddenDefaultEditors == null && this.defaultEditorRegistrar != null) {
/* 204 */       this.defaultEditorRegistrar.registerCustomEditors(this);
/*     */     }
/* 206 */     if (this.overriddenDefaultEditors != null) {
/* 207 */       PropertyEditor editor = this.overriddenDefaultEditors.get(requiredType);
/* 208 */       if (editor != null) {
/* 209 */         return editor;
/*     */       }
/*     */     } 
/* 212 */     if (this.defaultEditors == null) {
/* 213 */       createDefaultEditors();
/*     */     }
/* 215 */     return this.defaultEditors.get(requiredType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createDefaultEditors() {
/* 222 */     this.defaultEditors = new HashMap<>(64);
/*     */ 
/*     */ 
/*     */     
/* 226 */     this.defaultEditors.put(Charset.class, new CharsetEditor());
/* 227 */     this.defaultEditors.put(Class.class, new ClassEditor());
/* 228 */     this.defaultEditors.put(Class[].class, new ClassArrayEditor());
/* 229 */     this.defaultEditors.put(Currency.class, new CurrencyEditor());
/* 230 */     this.defaultEditors.put(File.class, new FileEditor());
/* 231 */     this.defaultEditors.put(InputStream.class, new InputStreamEditor());
/* 232 */     this.defaultEditors.put(InputSource.class, new InputSourceEditor());
/* 233 */     this.defaultEditors.put(Locale.class, new LocaleEditor());
/* 234 */     this.defaultEditors.put(Path.class, new PathEditor());
/* 235 */     this.defaultEditors.put(Pattern.class, new PatternEditor());
/* 236 */     this.defaultEditors.put(Properties.class, new PropertiesEditor());
/* 237 */     this.defaultEditors.put(Reader.class, new ReaderEditor());
/* 238 */     this.defaultEditors.put(Resource[].class, new ResourceArrayPropertyEditor());
/* 239 */     this.defaultEditors.put(TimeZone.class, new TimeZoneEditor());
/* 240 */     this.defaultEditors.put(URI.class, new URIEditor());
/* 241 */     this.defaultEditors.put(URL.class, new URLEditor());
/* 242 */     this.defaultEditors.put(UUID.class, new UUIDEditor());
/* 243 */     this.defaultEditors.put(ZoneId.class, new ZoneIdEditor());
/*     */ 
/*     */ 
/*     */     
/* 247 */     this.defaultEditors.put(Collection.class, new CustomCollectionEditor(Collection.class));
/* 248 */     this.defaultEditors.put(Set.class, new CustomCollectionEditor(Set.class));
/* 249 */     this.defaultEditors.put(SortedSet.class, new CustomCollectionEditor(SortedSet.class));
/* 250 */     this.defaultEditors.put(List.class, new CustomCollectionEditor(List.class));
/* 251 */     this.defaultEditors.put(SortedMap.class, new CustomMapEditor(SortedMap.class));
/*     */ 
/*     */     
/* 254 */     this.defaultEditors.put(byte[].class, new ByteArrayPropertyEditor());
/* 255 */     this.defaultEditors.put(char[].class, new CharArrayPropertyEditor());
/*     */ 
/*     */     
/* 258 */     this.defaultEditors.put(char.class, new CharacterEditor(false));
/* 259 */     this.defaultEditors.put(Character.class, new CharacterEditor(true));
/*     */ 
/*     */     
/* 262 */     this.defaultEditors.put(boolean.class, new CustomBooleanEditor(false));
/* 263 */     this.defaultEditors.put(Boolean.class, new CustomBooleanEditor(true));
/*     */ 
/*     */ 
/*     */     
/* 267 */     this.defaultEditors.put(byte.class, new CustomNumberEditor(Byte.class, false));
/* 268 */     this.defaultEditors.put(Byte.class, new CustomNumberEditor(Byte.class, true));
/* 269 */     this.defaultEditors.put(short.class, new CustomNumberEditor(Short.class, false));
/* 270 */     this.defaultEditors.put(Short.class, new CustomNumberEditor(Short.class, true));
/* 271 */     this.defaultEditors.put(int.class, new CustomNumberEditor(Integer.class, false));
/* 272 */     this.defaultEditors.put(Integer.class, new CustomNumberEditor(Integer.class, true));
/* 273 */     this.defaultEditors.put(long.class, new CustomNumberEditor(Long.class, false));
/* 274 */     this.defaultEditors.put(Long.class, new CustomNumberEditor(Long.class, true));
/* 275 */     this.defaultEditors.put(float.class, new CustomNumberEditor(Float.class, false));
/* 276 */     this.defaultEditors.put(Float.class, new CustomNumberEditor(Float.class, true));
/* 277 */     this.defaultEditors.put(double.class, new CustomNumberEditor(Double.class, false));
/* 278 */     this.defaultEditors.put(Double.class, new CustomNumberEditor(Double.class, true));
/* 279 */     this.defaultEditors.put(BigDecimal.class, new CustomNumberEditor(BigDecimal.class, true));
/* 280 */     this.defaultEditors.put(BigInteger.class, new CustomNumberEditor(BigInteger.class, true));
/*     */ 
/*     */     
/* 283 */     if (this.configValueEditorsActive) {
/* 284 */       StringArrayPropertyEditor sae = new StringArrayPropertyEditor();
/* 285 */       this.defaultEditors.put(String[].class, sae);
/* 286 */       this.defaultEditors.put(short[].class, sae);
/* 287 */       this.defaultEditors.put(int[].class, sae);
/* 288 */       this.defaultEditors.put(long[].class, sae);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyDefaultEditorsTo(PropertyEditorRegistrySupport target) {
/* 297 */     target.defaultEditorsActive = this.defaultEditorsActive;
/* 298 */     target.configValueEditorsActive = this.configValueEditorsActive;
/* 299 */     target.defaultEditors = this.defaultEditors;
/* 300 */     target.overriddenDefaultEditors = this.overriddenDefaultEditors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerCustomEditor(Class<?> requiredType, PropertyEditor propertyEditor) {
/* 310 */     registerCustomEditor(requiredType, null, propertyEditor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerCustomEditor(@Nullable Class<?> requiredType, @Nullable String propertyPath, PropertyEditor propertyEditor) {
/* 315 */     if (requiredType == null && propertyPath == null) {
/* 316 */       throw new IllegalArgumentException("Either requiredType or propertyPath is required");
/*     */     }
/* 318 */     if (propertyPath != null) {
/* 319 */       if (this.customEditorsForPath == null) {
/* 320 */         this.customEditorsForPath = new LinkedHashMap<>(16);
/*     */       }
/* 322 */       this.customEditorsForPath.put(propertyPath, new CustomEditorHolder(propertyEditor, requiredType));
/*     */     } else {
/*     */       
/* 325 */       if (this.customEditors == null) {
/* 326 */         this.customEditors = new LinkedHashMap<>(16);
/*     */       }
/* 328 */       this.customEditors.put(requiredType, propertyEditor);
/* 329 */       this.customEditorCache = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyEditor findCustomEditor(@Nullable Class<?> requiredType, @Nullable String propertyPath) {
/* 336 */     Class<?> requiredTypeToUse = requiredType;
/* 337 */     if (propertyPath != null) {
/* 338 */       if (this.customEditorsForPath != null) {
/*     */         
/* 340 */         PropertyEditor editor = getCustomEditor(propertyPath, requiredType);
/* 341 */         if (editor == null) {
/* 342 */           List<String> strippedPaths = new ArrayList<>();
/* 343 */           addStrippedPropertyPaths(strippedPaths, "", propertyPath);
/* 344 */           for (Iterator<String> it = strippedPaths.iterator(); it.hasNext() && editor == null; ) {
/* 345 */             String strippedPath = it.next();
/* 346 */             editor = getCustomEditor(strippedPath, requiredType);
/*     */           } 
/*     */         } 
/* 349 */         if (editor != null) {
/* 350 */           return editor;
/*     */         }
/*     */       } 
/* 353 */       if (requiredType == null) {
/* 354 */         requiredTypeToUse = getPropertyType(propertyPath);
/*     */       }
/*     */     } 
/*     */     
/* 358 */     return getCustomEditor(requiredTypeToUse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCustomEditorForElement(@Nullable Class<?> elementType, @Nullable String propertyPath) {
/* 371 */     if (propertyPath != null && this.customEditorsForPath != null) {
/* 372 */       for (Map.Entry<String, CustomEditorHolder> entry : this.customEditorsForPath.entrySet()) {
/* 373 */         if (PropertyAccessorUtils.matchesProperty(entry.getKey(), propertyPath) && ((CustomEditorHolder)entry
/* 374 */           .getValue()).getPropertyEditor(elementType) != null) {
/* 375 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 380 */     return (elementType != null && this.customEditors != null && this.customEditors.containsKey(elementType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?> getPropertyType(String propertyPath) {
/* 396 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PropertyEditor getCustomEditor(String propertyName, @Nullable Class<?> requiredType) {
/* 408 */     CustomEditorHolder holder = (this.customEditorsForPath != null) ? this.customEditorsForPath.get(propertyName) : null;
/* 409 */     return (holder != null) ? holder.getPropertyEditor(requiredType) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PropertyEditor getCustomEditor(@Nullable Class<?> requiredType) {
/* 422 */     if (requiredType == null || this.customEditors == null) {
/* 423 */       return null;
/*     */     }
/*     */     
/* 426 */     PropertyEditor editor = this.customEditors.get(requiredType);
/* 427 */     if (editor == null) {
/*     */       
/* 429 */       if (this.customEditorCache != null) {
/* 430 */         editor = this.customEditorCache.get(requiredType);
/*     */       }
/* 432 */       if (editor == null)
/*     */       {
/* 434 */         for (Map.Entry<Class<?>, PropertyEditor> entry : this.customEditors.entrySet()) {
/* 435 */           Class<?> key = entry.getKey();
/* 436 */           if (key.isAssignableFrom(requiredType)) {
/* 437 */             editor = entry.getValue();
/*     */ 
/*     */             
/* 440 */             if (this.customEditorCache == null) {
/* 441 */               this.customEditorCache = new HashMap<>();
/*     */             }
/* 443 */             this.customEditorCache.put(requiredType, editor);
/* 444 */             if (editor != null) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 451 */     return editor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?> guessPropertyTypeFromEditors(String propertyName) {
/* 462 */     if (this.customEditorsForPath != null) {
/* 463 */       CustomEditorHolder editorHolder = this.customEditorsForPath.get(propertyName);
/* 464 */       if (editorHolder == null) {
/* 465 */         List<String> strippedPaths = new ArrayList<>();
/* 466 */         addStrippedPropertyPaths(strippedPaths, "", propertyName);
/* 467 */         for (Iterator<String> it = strippedPaths.iterator(); it.hasNext() && editorHolder == null; ) {
/* 468 */           String strippedName = it.next();
/* 469 */           editorHolder = this.customEditorsForPath.get(strippedName);
/*     */         } 
/*     */       } 
/* 472 */       if (editorHolder != null) {
/* 473 */         return editorHolder.getRegisteredType();
/*     */       }
/*     */     } 
/* 476 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyCustomEditorsTo(PropertyEditorRegistry target, @Nullable String nestedProperty) {
/* 488 */     String actualPropertyName = (nestedProperty != null) ? PropertyAccessorUtils.getPropertyName(nestedProperty) : null;
/* 489 */     if (this.customEditors != null) {
/* 490 */       Objects.requireNonNull(target); this.customEditors.forEach(target::registerCustomEditor);
/*     */     } 
/* 492 */     if (this.customEditorsForPath != null) {
/* 493 */       this.customEditorsForPath.forEach((editorPath, editorHolder) -> {
/*     */             if (nestedProperty != null) {
/*     */               int pos = PropertyAccessorUtils.getFirstNestedPropertySeparatorIndex(editorPath);
/*     */               if (pos != -1) {
/*     */                 String editorNestedProperty = editorPath.substring(0, pos);
/*     */                 String editorNestedPath = editorPath.substring(pos + 1);
/*     */                 if (editorNestedProperty.equals(nestedProperty) || editorNestedProperty.equals(actualPropertyName)) {
/*     */                   target.registerCustomEditor(editorHolder.getRegisteredType(), editorNestedPath, editorHolder.getPropertyEditor());
/*     */                 }
/*     */               } 
/*     */             } else {
/*     */               target.registerCustomEditor(editorHolder.getRegisteredType(), editorPath, editorHolder.getPropertyEditor());
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addStrippedPropertyPaths(List<String> strippedPaths, String nestedPath, String propertyPath) {
/* 522 */     int startIndex = propertyPath.indexOf('[');
/* 523 */     if (startIndex != -1) {
/* 524 */       int endIndex = propertyPath.indexOf(']');
/* 525 */       if (endIndex != -1) {
/* 526 */         String prefix = propertyPath.substring(0, startIndex);
/* 527 */         String key = propertyPath.substring(startIndex, endIndex + 1);
/* 528 */         String suffix = propertyPath.substring(endIndex + 1);
/*     */         
/* 530 */         strippedPaths.add(nestedPath + nestedPath + prefix);
/*     */         
/* 532 */         addStrippedPropertyPaths(strippedPaths, nestedPath + nestedPath, suffix);
/*     */         
/* 534 */         addStrippedPropertyPaths(strippedPaths, nestedPath + nestedPath + prefix, suffix);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CustomEditorHolder
/*     */   {
/*     */     private final PropertyEditor propertyEditor;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Class<?> registeredType;
/*     */ 
/*     */ 
/*     */     
/*     */     private CustomEditorHolder(PropertyEditor propertyEditor, @Nullable Class<?> registeredType) {
/* 552 */       this.propertyEditor = propertyEditor;
/* 553 */       this.registeredType = registeredType;
/*     */     }
/*     */     
/*     */     private PropertyEditor getPropertyEditor() {
/* 557 */       return this.propertyEditor;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private Class<?> getRegisteredType() {
/* 562 */       return this.registeredType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private PropertyEditor getPropertyEditor(@Nullable Class<?> requiredType) {
/* 573 */       if (this.registeredType == null || (requiredType != null && (
/*     */         
/* 575 */         ClassUtils.isAssignable(this.registeredType, requiredType) || 
/* 576 */         ClassUtils.isAssignable(requiredType, this.registeredType))) || (requiredType == null && 
/*     */         
/* 578 */         !Collection.class.isAssignableFrom(this.registeredType) && !this.registeredType.isArray())) {
/* 579 */         return this.propertyEditor;
/*     */       }
/*     */       
/* 582 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\PropertyEditorRegistrySupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */