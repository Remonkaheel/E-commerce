/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TypeConverterDelegate
/*     */ {
/*  59 */   private static final Log logger = LogFactory.getLog(TypeConverterDelegate.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final PropertyEditorRegistrySupport propertyEditorRegistry;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Object targetObject;
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverterDelegate(PropertyEditorRegistrySupport propertyEditorRegistry) {
/*  72 */     this(propertyEditorRegistry, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverterDelegate(PropertyEditorRegistrySupport propertyEditorRegistry, @Nullable Object targetObject) {
/*  81 */     this.propertyEditorRegistry = propertyEditorRegistry;
/*  82 */     this.targetObject = targetObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T convertIfNecessary(@Nullable String propertyName, @Nullable Object oldValue, Object newValue, @Nullable Class<T> requiredType) throws IllegalArgumentException {
/* 100 */     return convertIfNecessary(propertyName, oldValue, newValue, requiredType, TypeDescriptor.valueOf(requiredType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T convertIfNecessary(@Nullable String propertyName, @Nullable Object oldValue, @Nullable Object newValue, @Nullable Class<T> requiredType, @Nullable TypeDescriptor typeDescriptor) throws IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield propertyEditorRegistry : Lorg/springframework/beans/PropertyEditorRegistrySupport;
/*     */     //   4: aload #4
/*     */     //   6: aload_1
/*     */     //   7: invokevirtual findCustomEditor : (Ljava/lang/Class;Ljava/lang/String;)Ljava/beans/PropertyEditor;
/*     */     //   10: astore #6
/*     */     //   12: aconst_null
/*     */     //   13: astore #7
/*     */     //   15: aload_0
/*     */     //   16: getfield propertyEditorRegistry : Lorg/springframework/beans/PropertyEditorRegistrySupport;
/*     */     //   19: invokevirtual getConversionService : ()Lorg/springframework/core/convert/ConversionService;
/*     */     //   22: astore #8
/*     */     //   24: aload #6
/*     */     //   26: ifnonnull -> 82
/*     */     //   29: aload #8
/*     */     //   31: ifnull -> 82
/*     */     //   34: aload_3
/*     */     //   35: ifnull -> 82
/*     */     //   38: aload #5
/*     */     //   40: ifnull -> 82
/*     */     //   43: aload_3
/*     */     //   44: invokestatic forObject : (Ljava/lang/Object;)Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   47: astore #9
/*     */     //   49: aload #8
/*     */     //   51: aload #9
/*     */     //   53: aload #5
/*     */     //   55: invokeinterface canConvert : (Lorg/springframework/core/convert/TypeDescriptor;Lorg/springframework/core/convert/TypeDescriptor;)Z
/*     */     //   60: ifeq -> 82
/*     */     //   63: aload #8
/*     */     //   65: aload_3
/*     */     //   66: aload #9
/*     */     //   68: aload #5
/*     */     //   70: invokeinterface convert : (Ljava/lang/Object;Lorg/springframework/core/convert/TypeDescriptor;Lorg/springframework/core/convert/TypeDescriptor;)Ljava/lang/Object;
/*     */     //   75: areturn
/*     */     //   76: astore #10
/*     */     //   78: aload #10
/*     */     //   80: astore #7
/*     */     //   82: aload_3
/*     */     //   83: astore #9
/*     */     //   85: aload #6
/*     */     //   87: ifnonnull -> 105
/*     */     //   90: aload #4
/*     */     //   92: ifnull -> 232
/*     */     //   95: aload #4
/*     */     //   97: aload #9
/*     */     //   99: invokestatic isAssignableValue : (Ljava/lang/Class;Ljava/lang/Object;)Z
/*     */     //   102: ifne -> 232
/*     */     //   105: aload #5
/*     */     //   107: ifnull -> 206
/*     */     //   110: aload #4
/*     */     //   112: ifnull -> 206
/*     */     //   115: ldc java/util/Collection
/*     */     //   117: aload #4
/*     */     //   119: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   122: ifeq -> 206
/*     */     //   125: aload #5
/*     */     //   127: invokevirtual getElementTypeDescriptor : ()Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   130: astore #10
/*     */     //   132: aload #10
/*     */     //   134: ifnull -> 206
/*     */     //   137: aload #10
/*     */     //   139: invokevirtual getType : ()Ljava/lang/Class;
/*     */     //   142: astore #11
/*     */     //   144: aload #9
/*     */     //   146: instanceof java/lang/String
/*     */     //   149: ifeq -> 206
/*     */     //   152: aload #9
/*     */     //   154: checkcast java/lang/String
/*     */     //   157: astore #12
/*     */     //   159: ldc java/lang/Class
/*     */     //   161: aload #11
/*     */     //   163: if_acmpeq -> 176
/*     */     //   166: ldc java/lang/Enum
/*     */     //   168: aload #11
/*     */     //   170: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   173: ifeq -> 183
/*     */     //   176: aload #12
/*     */     //   178: invokestatic commaDelimitedListToStringArray : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   181: astore #9
/*     */     //   183: aload #6
/*     */     //   185: ifnonnull -> 206
/*     */     //   188: ldc java/lang/String
/*     */     //   190: aload #11
/*     */     //   192: if_acmpeq -> 206
/*     */     //   195: aload_0
/*     */     //   196: aload #11
/*     */     //   198: invokevirtual arrayType : ()Ljava/lang/Class;
/*     */     //   201: invokevirtual findDefaultEditor : (Ljava/lang/Class;)Ljava/beans/PropertyEditor;
/*     */     //   204: astore #6
/*     */     //   206: aload #6
/*     */     //   208: ifnonnull -> 219
/*     */     //   211: aload_0
/*     */     //   212: aload #4
/*     */     //   214: invokevirtual findDefaultEditor : (Ljava/lang/Class;)Ljava/beans/PropertyEditor;
/*     */     //   217: astore #6
/*     */     //   219: aload_0
/*     */     //   220: aload_2
/*     */     //   221: aload #9
/*     */     //   223: aload #4
/*     */     //   225: aload #6
/*     */     //   227: invokevirtual doConvertValue : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Class;Ljava/beans/PropertyEditor;)Ljava/lang/Object;
/*     */     //   230: astore #9
/*     */     //   232: iconst_0
/*     */     //   233: istore #10
/*     */     //   235: aload #4
/*     */     //   237: ifnull -> 910
/*     */     //   240: aload #9
/*     */     //   242: ifnull -> 695
/*     */     //   245: ldc java/lang/Object
/*     */     //   247: aload #4
/*     */     //   249: if_acmpne -> 255
/*     */     //   252: aload #9
/*     */     //   254: areturn
/*     */     //   255: aload #4
/*     */     //   257: invokevirtual isArray : ()Z
/*     */     //   260: ifeq -> 311
/*     */     //   263: aload #9
/*     */     //   265: instanceof java/lang/String
/*     */     //   268: ifeq -> 298
/*     */     //   271: aload #9
/*     */     //   273: checkcast java/lang/String
/*     */     //   276: astore #13
/*     */     //   278: ldc java/lang/Enum
/*     */     //   280: aload #4
/*     */     //   282: invokevirtual componentType : ()Ljava/lang/Class;
/*     */     //   285: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   288: ifeq -> 298
/*     */     //   291: aload #13
/*     */     //   293: invokestatic commaDelimitedListToStringArray : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   296: astore #9
/*     */     //   298: aload_0
/*     */     //   299: aload #9
/*     */     //   301: aload_1
/*     */     //   302: aload #4
/*     */     //   304: invokevirtual componentType : ()Ljava/lang/Class;
/*     */     //   307: invokevirtual convertToTypedArray : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   310: areturn
/*     */     //   311: aload #9
/*     */     //   313: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   316: invokevirtual isArray : ()Z
/*     */     //   319: ifeq -> 377
/*     */     //   322: ldc java/util/Collection
/*     */     //   324: aload #4
/*     */     //   326: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   329: ifeq -> 354
/*     */     //   332: aload_0
/*     */     //   333: aload #9
/*     */     //   335: invokestatic arrayToList : (Ljava/lang/Object;)Ljava/util/List;
/*     */     //   338: aload_1
/*     */     //   339: aload #4
/*     */     //   341: aload #5
/*     */     //   343: invokevirtual convertToTypedCollection : (Ljava/util/Collection;Ljava/lang/String;Ljava/lang/Class;Lorg/springframework/core/convert/TypeDescriptor;)Ljava/util/Collection;
/*     */     //   346: astore #9
/*     */     //   348: iconst_1
/*     */     //   349: istore #10
/*     */     //   351: goto -> 442
/*     */     //   354: aload #9
/*     */     //   356: invokestatic getLength : (Ljava/lang/Object;)I
/*     */     //   359: iconst_1
/*     */     //   360: if_icmpne -> 442
/*     */     //   363: aload #9
/*     */     //   365: iconst_0
/*     */     //   366: invokestatic get : (Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   369: astore #9
/*     */     //   371: iconst_1
/*     */     //   372: istore #10
/*     */     //   374: goto -> 442
/*     */     //   377: aload #9
/*     */     //   379: instanceof java/util/Collection
/*     */     //   382: ifeq -> 411
/*     */     //   385: aload #9
/*     */     //   387: checkcast java/util/Collection
/*     */     //   390: astore #11
/*     */     //   392: aload_0
/*     */     //   393: aload #11
/*     */     //   395: aload_1
/*     */     //   396: aload #4
/*     */     //   398: aload #5
/*     */     //   400: invokevirtual convertToTypedCollection : (Ljava/util/Collection;Ljava/lang/String;Ljava/lang/Class;Lorg/springframework/core/convert/TypeDescriptor;)Ljava/util/Collection;
/*     */     //   403: astore #9
/*     */     //   405: iconst_1
/*     */     //   406: istore #10
/*     */     //   408: goto -> 442
/*     */     //   411: aload #9
/*     */     //   413: instanceof java/util/Map
/*     */     //   416: ifeq -> 442
/*     */     //   419: aload #9
/*     */     //   421: checkcast java/util/Map
/*     */     //   424: astore #12
/*     */     //   426: aload_0
/*     */     //   427: aload #12
/*     */     //   429: aload_1
/*     */     //   430: aload #4
/*     */     //   432: aload #5
/*     */     //   434: invokevirtual convertToTypedMap : (Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;Lorg/springframework/core/convert/TypeDescriptor;)Ljava/util/Map;
/*     */     //   437: astore #9
/*     */     //   439: iconst_1
/*     */     //   440: istore #10
/*     */     //   442: ldc java/lang/String
/*     */     //   444: aload #4
/*     */     //   446: if_acmpne -> 466
/*     */     //   449: aload #9
/*     */     //   451: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   454: invokestatic isPrimitiveOrWrapper : (Ljava/lang/Class;)Z
/*     */     //   457: ifeq -> 466
/*     */     //   460: aload #9
/*     */     //   462: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   465: areturn
/*     */     //   466: aload #9
/*     */     //   468: instanceof java/lang/String
/*     */     //   471: ifeq -> 655
/*     */     //   474: aload #9
/*     */     //   476: checkcast java/lang/String
/*     */     //   479: astore #11
/*     */     //   481: aload #4
/*     */     //   483: aload #9
/*     */     //   485: invokevirtual isInstance : (Ljava/lang/Object;)Z
/*     */     //   488: ifne -> 655
/*     */     //   491: aload #7
/*     */     //   493: ifnonnull -> 612
/*     */     //   496: aload #4
/*     */     //   498: invokevirtual isInterface : ()Z
/*     */     //   501: ifne -> 612
/*     */     //   504: aload #4
/*     */     //   506: invokevirtual isEnum : ()Z
/*     */     //   509: ifne -> 612
/*     */     //   512: aload #4
/*     */     //   514: iconst_1
/*     */     //   515: anewarray java/lang/Class
/*     */     //   518: dup
/*     */     //   519: iconst_0
/*     */     //   520: ldc java/lang/String
/*     */     //   522: aastore
/*     */     //   523: invokevirtual getConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
/*     */     //   526: astore #13
/*     */     //   528: aload #13
/*     */     //   530: iconst_1
/*     */     //   531: anewarray java/lang/Object
/*     */     //   534: dup
/*     */     //   535: iconst_0
/*     */     //   536: aload #9
/*     */     //   538: aastore
/*     */     //   539: invokestatic instantiateClass : (Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   542: areturn
/*     */     //   543: astore #13
/*     */     //   545: getstatic org/springframework/beans/TypeConverterDelegate.logger : Lorg/apache/commons/logging/Log;
/*     */     //   548: invokeinterface isTraceEnabled : ()Z
/*     */     //   553: ifeq -> 576
/*     */     //   556: getstatic org/springframework/beans/TypeConverterDelegate.logger : Lorg/apache/commons/logging/Log;
/*     */     //   559: aload #4
/*     */     //   561: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   564: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   569: aload #13
/*     */     //   571: invokeinterface trace : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   576: goto -> 612
/*     */     //   579: astore #13
/*     */     //   581: getstatic org/springframework/beans/TypeConverterDelegate.logger : Lorg/apache/commons/logging/Log;
/*     */     //   584: invokeinterface isDebugEnabled : ()Z
/*     */     //   589: ifeq -> 612
/*     */     //   592: getstatic org/springframework/beans/TypeConverterDelegate.logger : Lorg/apache/commons/logging/Log;
/*     */     //   595: aload #4
/*     */     //   597: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   600: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   605: aload #13
/*     */     //   607: invokeinterface debug : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   612: aload #11
/*     */     //   614: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   617: astore #13
/*     */     //   619: aload #4
/*     */     //   621: invokevirtual isEnum : ()Z
/*     */     //   624: ifeq -> 637
/*     */     //   627: aload #13
/*     */     //   629: invokevirtual isEmpty : ()Z
/*     */     //   632: ifeq -> 637
/*     */     //   635: aconst_null
/*     */     //   636: areturn
/*     */     //   637: aload_0
/*     */     //   638: aload #4
/*     */     //   640: aload #13
/*     */     //   642: aload #9
/*     */     //   644: invokevirtual attemptToConvertStringToEnum : (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   647: astore #9
/*     */     //   649: iconst_1
/*     */     //   650: istore #10
/*     */     //   652: goto -> 692
/*     */     //   655: aload #9
/*     */     //   657: instanceof java/lang/Number
/*     */     //   660: ifeq -> 692
/*     */     //   663: aload #9
/*     */     //   665: checkcast java/lang/Number
/*     */     //   668: astore #12
/*     */     //   670: ldc java/lang/Number
/*     */     //   672: aload #4
/*     */     //   674: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   677: ifeq -> 692
/*     */     //   680: aload #12
/*     */     //   682: aload #4
/*     */     //   684: invokestatic convertNumberToTargetClass : (Ljava/lang/Number;Ljava/lang/Class;)Ljava/lang/Number;
/*     */     //   687: astore #9
/*     */     //   689: iconst_1
/*     */     //   690: istore #10
/*     */     //   692: goto -> 707
/*     */     //   695: aload #4
/*     */     //   697: ldc java/util/Optional
/*     */     //   699: if_acmpne -> 707
/*     */     //   702: invokestatic empty : ()Ljava/util/Optional;
/*     */     //   705: astore #9
/*     */     //   707: aload #4
/*     */     //   709: aload #9
/*     */     //   711: invokestatic isAssignableValue : (Ljava/lang/Class;Ljava/lang/Object;)Z
/*     */     //   714: ifne -> 910
/*     */     //   717: aload #7
/*     */     //   719: ifnull -> 725
/*     */     //   722: aload #7
/*     */     //   724: athrow
/*     */     //   725: aload #8
/*     */     //   727: ifnull -> 768
/*     */     //   730: aload #5
/*     */     //   732: ifnull -> 768
/*     */     //   735: aload_3
/*     */     //   736: invokestatic forObject : (Ljava/lang/Object;)Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   739: astore #11
/*     */     //   741: aload #8
/*     */     //   743: aload #11
/*     */     //   745: aload #5
/*     */     //   747: invokeinterface canConvert : (Lorg/springframework/core/convert/TypeDescriptor;Lorg/springframework/core/convert/TypeDescriptor;)Z
/*     */     //   752: ifeq -> 768
/*     */     //   755: aload #8
/*     */     //   757: aload_3
/*     */     //   758: aload #11
/*     */     //   760: aload #5
/*     */     //   762: invokeinterface convert : (Ljava/lang/Object;Lorg/springframework/core/convert/TypeDescriptor;Lorg/springframework/core/convert/TypeDescriptor;)Ljava/lang/Object;
/*     */     //   767: areturn
/*     */     //   768: new java/lang/StringBuilder
/*     */     //   771: dup
/*     */     //   772: invokespecial <init> : ()V
/*     */     //   775: astore #11
/*     */     //   777: aload #11
/*     */     //   779: ldc 'Cannot convert value of type ''
/*     */     //   781: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   784: aload_3
/*     */     //   785: invokestatic getDescriptiveType : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   788: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   791: pop
/*     */     //   792: aload #11
/*     */     //   794: ldc '' to required type ''
/*     */     //   796: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   799: aload #4
/*     */     //   801: invokestatic getQualifiedName : (Ljava/lang/Class;)Ljava/lang/String;
/*     */     //   804: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   807: bipush #39
/*     */     //   809: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   812: pop
/*     */     //   813: aload_1
/*     */     //   814: ifnull -> 834
/*     */     //   817: aload #11
/*     */     //   819: ldc ' for property ''
/*     */     //   821: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   824: aload_1
/*     */     //   825: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   828: bipush #39
/*     */     //   830: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   833: pop
/*     */     //   834: aload #6
/*     */     //   836: ifnull -> 889
/*     */     //   839: aload #11
/*     */     //   841: ldc ': PropertyEditor ['
/*     */     //   843: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   846: aload #6
/*     */     //   848: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   851: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   854: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   857: ldc '] returned inappropriate value of type ''
/*     */     //   859: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   862: aload #9
/*     */     //   864: invokestatic getDescriptiveType : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   867: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   870: bipush #39
/*     */     //   872: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   875: pop
/*     */     //   876: new java/lang/IllegalArgumentException
/*     */     //   879: dup
/*     */     //   880: aload #11
/*     */     //   882: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   885: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   888: athrow
/*     */     //   889: aload #11
/*     */     //   891: ldc ': no matching editors or conversion strategy found'
/*     */     //   893: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   896: pop
/*     */     //   897: new java/lang/IllegalStateException
/*     */     //   900: dup
/*     */     //   901: aload #11
/*     */     //   903: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   906: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   909: athrow
/*     */     //   910: aload #7
/*     */     //   912: ifnull -> 953
/*     */     //   915: aload #6
/*     */     //   917: ifnonnull -> 940
/*     */     //   920: iload #10
/*     */     //   922: ifne -> 940
/*     */     //   925: aload #4
/*     */     //   927: ifnull -> 940
/*     */     //   930: ldc java/lang/Object
/*     */     //   932: aload #4
/*     */     //   934: if_acmpeq -> 940
/*     */     //   937: aload #7
/*     */     //   939: athrow
/*     */     //   940: getstatic org/springframework/beans/TypeConverterDelegate.logger : Lorg/apache/commons/logging/Log;
/*     */     //   943: ldc_w 'Original ConversionService attempt failed - ignored since PropertyEditor based conversion eventually succeeded'
/*     */     //   946: aload #7
/*     */     //   948: invokeinterface debug : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   953: aload #9
/*     */     //   955: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #121	-> 0
/*     */     //   #123	-> 12
/*     */     //   #126	-> 15
/*     */     //   #127	-> 24
/*     */     //   #128	-> 43
/*     */     //   #129	-> 49
/*     */     //   #131	-> 63
/*     */     //   #133	-> 76
/*     */     //   #135	-> 78
/*     */     //   #140	-> 82
/*     */     //   #143	-> 85
/*     */     //   #144	-> 105
/*     */     //   #145	-> 125
/*     */     //   #146	-> 132
/*     */     //   #147	-> 137
/*     */     //   #148	-> 144
/*     */     //   #149	-> 159
/*     */     //   #150	-> 176
/*     */     //   #152	-> 183
/*     */     //   #153	-> 195
/*     */     //   #158	-> 206
/*     */     //   #159	-> 211
/*     */     //   #161	-> 219
/*     */     //   #164	-> 232
/*     */     //   #166	-> 235
/*     */     //   #169	-> 240
/*     */     //   #170	-> 245
/*     */     //   #171	-> 252
/*     */     //   #173	-> 255
/*     */     //   #175	-> 263
/*     */     //   #176	-> 282
/*     */     //   #177	-> 291
/*     */     //   #179	-> 298
/*     */     //   #181	-> 311
/*     */     //   #182	-> 322
/*     */     //   #183	-> 332
/*     */     //   #185	-> 348
/*     */     //   #187	-> 354
/*     */     //   #188	-> 363
/*     */     //   #189	-> 371
/*     */     //   #192	-> 377
/*     */     //   #194	-> 392
/*     */     //   #195	-> 405
/*     */     //   #197	-> 411
/*     */     //   #199	-> 426
/*     */     //   #200	-> 439
/*     */     //   #202	-> 442
/*     */     //   #204	-> 460
/*     */     //   #206	-> 466
/*     */     //   #207	-> 491
/*     */     //   #209	-> 512
/*     */     //   #210	-> 528
/*     */     //   #212	-> 543
/*     */     //   #214	-> 545
/*     */     //   #215	-> 556
/*     */     //   #222	-> 576
/*     */     //   #218	-> 579
/*     */     //   #219	-> 581
/*     */     //   #220	-> 592
/*     */     //   #224	-> 612
/*     */     //   #225	-> 619
/*     */     //   #227	-> 635
/*     */     //   #229	-> 637
/*     */     //   #230	-> 649
/*     */     //   #231	-> 652
/*     */     //   #232	-> 655
/*     */     //   #233	-> 680
/*     */     //   #234	-> 689
/*     */     //   #239	-> 695
/*     */     //   #240	-> 702
/*     */     //   #244	-> 707
/*     */     //   #245	-> 717
/*     */     //   #247	-> 722
/*     */     //   #249	-> 725
/*     */     //   #252	-> 735
/*     */     //   #253	-> 741
/*     */     //   #254	-> 755
/*     */     //   #259	-> 768
/*     */     //   #260	-> 777
/*     */     //   #261	-> 792
/*     */     //   #262	-> 813
/*     */     //   #263	-> 817
/*     */     //   #265	-> 834
/*     */     //   #266	-> 839
/*     */     //   #268	-> 864
/*     */     //   #267	-> 867
/*     */     //   #268	-> 872
/*     */     //   #269	-> 876
/*     */     //   #272	-> 889
/*     */     //   #273	-> 897
/*     */     //   #278	-> 910
/*     */     //   #279	-> 915
/*     */     //   #280	-> 937
/*     */     //   #282	-> 940
/*     */     //   #286	-> 953
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   78	4	10	ex	Lorg/springframework/core/convert/ConversionFailedException;
/*     */     //   49	33	9	sourceTypeDesc	Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   159	47	12	text	Ljava/lang/String;
/*     */     //   144	62	11	elementType	Ljava/lang/Class;
/*     */     //   132	74	10	elementTypeDesc	Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   278	20	13	text	Ljava/lang/String;
/*     */     //   392	19	11	coll	Ljava/util/Collection;
/*     */     //   426	16	12	map	Ljava/util/Map;
/*     */     //   528	15	13	strCtor	Ljava/lang/reflect/Constructor;
/*     */     //   545	31	13	ex	Ljava/lang/NoSuchMethodException;
/*     */     //   581	31	13	ex	Ljava/lang/Exception;
/*     */     //   619	33	13	trimmedValue	Ljava/lang/String;
/*     */     //   481	174	11	text	Ljava/lang/String;
/*     */     //   670	22	12	num	Ljava/lang/Number;
/*     */     //   741	27	11	sourceTypeDesc	Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   777	133	11	msg	Ljava/lang/StringBuilder;
/*     */     //   0	956	0	this	Lorg/springframework/beans/TypeConverterDelegate;
/*     */     //   0	956	1	propertyName	Ljava/lang/String;
/*     */     //   0	956	2	oldValue	Ljava/lang/Object;
/*     */     //   0	956	3	newValue	Ljava/lang/Object;
/*     */     //   0	956	4	requiredType	Ljava/lang/Class;
/*     */     //   0	956	5	typeDescriptor	Lorg/springframework/core/convert/TypeDescriptor;
/*     */     //   12	944	6	editor	Ljava/beans/PropertyEditor;
/*     */     //   15	941	7	conversionAttemptEx	Lorg/springframework/core/convert/ConversionFailedException;
/*     */     //   24	932	8	conversionService	Lorg/springframework/core/convert/ConversionService;
/*     */     //   85	871	9	convertedValue	Ljava/lang/Object;
/*     */     //   235	721	10	standardConversion	Z
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   144	62	11	elementType	Ljava/lang/Class<*>;
/*     */     //   392	19	11	coll	Ljava/util/Collection<*>;
/*     */     //   426	16	12	map	Ljava/util/Map<**>;
/*     */     //   528	15	13	strCtor	Ljava/lang/reflect/Constructor<TT;>;
/*     */     //   0	956	4	requiredType	Ljava/lang/Class<TT;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   63	75	76	org/springframework/core/convert/ConversionFailedException
/*     */     //   512	542	543	java/lang/NoSuchMethodException
/*     */     //   512	542	579	java/lang/Exception
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object attemptToConvertStringToEnum(Class<?> requiredType, String trimmedValue, Object currentConvertedValue) {
/* 290 */     Object convertedValue = currentConvertedValue;
/*     */     
/* 292 */     if (Enum.class == requiredType && this.targetObject != null) {
/*     */       
/* 294 */       int index = trimmedValue.lastIndexOf('.');
/* 295 */       if (index > -1) {
/* 296 */         String enumType = trimmedValue.substring(0, index);
/* 297 */         String fieldName = trimmedValue.substring(index + 1);
/* 298 */         ClassLoader cl = this.targetObject.getClass().getClassLoader();
/*     */         try {
/* 300 */           Class<?> enumValueType = ClassUtils.forName(enumType, cl);
/* 301 */           Field enumField = enumValueType.getField(fieldName);
/* 302 */           convertedValue = enumField.get(null);
/*     */         }
/* 304 */         catch (ClassNotFoundException ex) {
/* 305 */           if (logger.isTraceEnabled()) {
/* 306 */             logger.trace("Enum class [" + enumType + "] cannot be loaded", ex);
/*     */           }
/*     */         }
/* 309 */         catch (Throwable ex) {
/* 310 */           if (logger.isTraceEnabled()) {
/* 311 */             logger.trace("Field [" + fieldName + "] isn't an enum value for type [" + enumType + "]", ex);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 317 */     if (convertedValue == currentConvertedValue) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 322 */         Field enumField = requiredType.getField(trimmedValue);
/* 323 */         ReflectionUtils.makeAccessible(enumField);
/* 324 */         convertedValue = enumField.get(null);
/*     */       }
/* 326 */       catch (Throwable ex) {
/* 327 */         if (logger.isTraceEnabled()) {
/* 328 */           logger.trace("Field [" + String.valueOf(convertedValue) + "] isn't an enum value", ex);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 333 */     return convertedValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PropertyEditor findDefaultEditor(@Nullable Class<?> requiredType) {
/* 342 */     PropertyEditor editor = null;
/* 343 */     if (requiredType != null) {
/*     */       
/* 345 */       editor = this.propertyEditorRegistry.getDefaultEditor(requiredType);
/* 346 */       if (editor == null && String.class != requiredType)
/*     */       {
/* 348 */         editor = BeanUtils.findEditorByConvention(requiredType);
/*     */       }
/*     */     } 
/* 351 */     return editor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object doConvertValue(@Nullable Object oldValue, @Nullable Object newValue, @Nullable Class<?> requiredType, @Nullable PropertyEditor editor) {
/* 369 */     Object convertedValue = newValue;
/*     */     
/* 371 */     if (editor != null && !(convertedValue instanceof String)) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/* 377 */         editor.setValue(convertedValue);
/* 378 */         Object newConvertedValue = editor.getValue();
/* 379 */         if (newConvertedValue != convertedValue) {
/* 380 */           convertedValue = newConvertedValue;
/*     */ 
/*     */           
/* 383 */           editor = null;
/*     */         }
/*     */       
/* 386 */       } catch (Exception ex) {
/* 387 */         if (logger.isDebugEnabled()) {
/* 388 */           logger.debug("PropertyEditor [" + editor.getClass().getName() + "] does not support setValue call", ex);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 394 */     Object returnValue = convertedValue;
/*     */     
/* 396 */     if (requiredType != null && !requiredType.isArray() && convertedValue instanceof String[]) { String[] array = (String[])convertedValue;
/*     */ 
/*     */ 
/*     */       
/* 400 */       if (logger.isTraceEnabled()) {
/* 401 */         logger.trace("Converting String array to comma-delimited String [" + String.valueOf(convertedValue) + "]");
/*     */       }
/* 403 */       convertedValue = StringUtils.arrayToCommaDelimitedString((Object[])array); }
/*     */ 
/*     */     
/* 406 */     if (convertedValue instanceof String) { String newTextValue = (String)convertedValue;
/* 407 */       if (editor != null) {
/*     */         
/* 409 */         if (logger.isTraceEnabled()) {
/* 410 */           logger.trace("Converting String to [" + String.valueOf(requiredType) + "] using property editor [" + String.valueOf(editor) + "]");
/*     */         }
/* 412 */         return doConvertTextValue(oldValue, newTextValue, editor);
/*     */       } 
/* 414 */       if (String.class == requiredType) {
/* 415 */         returnValue = convertedValue;
/*     */       } }
/*     */ 
/*     */     
/* 419 */     return returnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object doConvertTextValue(@Nullable Object oldValue, String newTextValue, PropertyEditor editor) {
/*     */     try {
/* 431 */       editor.setValue(oldValue);
/*     */     }
/* 433 */     catch (Exception ex) {
/* 434 */       if (logger.isDebugEnabled()) {
/* 435 */         logger.debug("PropertyEditor [" + editor.getClass().getName() + "] does not support setValue call", ex);
/*     */       }
/*     */     } 
/*     */     
/* 439 */     editor.setAsText(newTextValue);
/* 440 */     return editor.getValue();
/*     */   }
/*     */   
/*     */   private Object convertToTypedArray(Object input, @Nullable String propertyName, Class<?> componentType) {
/* 444 */     if (input instanceof Collection) { Collection<?> coll = (Collection)input;
/*     */       
/* 446 */       Object object = Array.newInstance(componentType, coll.size());
/* 447 */       int i = 0;
/* 448 */       for (Iterator<?> it = coll.iterator(); it.hasNext(); i++) {
/* 449 */         Object object1 = convertIfNecessary(
/* 450 */             buildIndexedPropertyName(propertyName, i), null, it.next(), componentType);
/* 451 */         Array.set(object, i, object1);
/*     */       } 
/* 453 */       return object; }
/*     */     
/* 455 */     if (input.getClass().isArray()) {
/*     */       
/* 457 */       if (componentType.equals(input.getClass().componentType()) && 
/* 458 */         !this.propertyEditorRegistry.hasCustomEditorForElement(componentType, propertyName)) {
/* 459 */         return input;
/*     */       }
/* 461 */       int arrayLength = Array.getLength(input);
/* 462 */       Object object = Array.newInstance(componentType, arrayLength);
/* 463 */       for (int i = 0; i < arrayLength; i++) {
/* 464 */         Object object1 = convertIfNecessary(
/* 465 */             buildIndexedPropertyName(propertyName, i), null, Array.get(input, i), componentType);
/* 466 */         Array.set(object, i, object1);
/*     */       } 
/* 468 */       return object;
/*     */     } 
/*     */ 
/*     */     
/* 472 */     Object result = Array.newInstance(componentType, 1);
/* 473 */     Object value = convertIfNecessary(
/* 474 */         buildIndexedPropertyName(propertyName, 0), null, input, componentType);
/* 475 */     Array.set(result, 0, value);
/* 476 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<?> convertToTypedCollection(Collection<?> original, @Nullable String propertyName, Class<?> requiredType, @Nullable TypeDescriptor typeDescriptor) {
/*     */     Iterator<?> it;
/*     */     Collection<Object> convertedCopy;
/* 484 */     if (!Collection.class.isAssignableFrom(requiredType)) {
/* 485 */       return original;
/*     */     }
/*     */     
/* 488 */     boolean approximable = CollectionFactory.isApproximableCollectionType(requiredType);
/* 489 */     if (!approximable && !canCreateCopy(requiredType)) {
/* 490 */       if (logger.isDebugEnabled()) {
/* 491 */         logger.debug("Custom Collection type [" + original.getClass().getName() + "] does not allow for creating a copy - injecting original Collection as-is");
/*     */       }
/*     */       
/* 494 */       return original;
/*     */     } 
/*     */     
/* 497 */     boolean originalAllowed = requiredType.isInstance(original);
/* 498 */     TypeDescriptor elementType = (typeDescriptor != null) ? typeDescriptor.getElementTypeDescriptor() : null;
/* 499 */     if (elementType == null && originalAllowed && 
/* 500 */       !this.propertyEditorRegistry.hasCustomEditorForElement(null, propertyName)) {
/* 501 */       return original;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 506 */       it = original.iterator();
/*     */     }
/* 508 */     catch (Throwable ex) {
/* 509 */       if (logger.isDebugEnabled()) {
/* 510 */         logger.debug("Cannot access Collection of type [" + original.getClass().getName() + "] - injecting original Collection as-is: " + String.valueOf(ex));
/*     */       }
/*     */       
/* 513 */       return original;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 518 */       if (approximable && requiredType.isInstance(original)) {
/* 519 */         convertedCopy = CollectionFactory.createApproximateCollection(original, original.size());
/*     */       } else {
/*     */         
/* 522 */         convertedCopy = CollectionFactory.createCollection(requiredType, original.size());
/*     */       }
/*     */     
/* 525 */     } catch (Throwable ex) {
/* 526 */       if (logger.isDebugEnabled()) {
/* 527 */         logger.debug("Cannot create copy of Collection type [" + original.getClass().getName() + "] - injecting original Collection as-is: " + String.valueOf(ex));
/*     */       }
/*     */       
/* 530 */       return original;
/*     */     } 
/*     */     
/* 533 */     for (int i = 0; it.hasNext(); i++) {
/* 534 */       Object element = it.next();
/* 535 */       String indexedPropertyName = buildIndexedPropertyName(propertyName, i);
/* 536 */       Object convertedElement = convertIfNecessary(indexedPropertyName, null, element, 
/* 537 */           (elementType != null) ? elementType.getType() : null, elementType);
/*     */       try {
/* 539 */         convertedCopy.add(convertedElement);
/*     */       }
/* 541 */       catch (Throwable ex) {
/* 542 */         if (logger.isDebugEnabled()) {
/* 543 */           logger.debug("Collection type [" + original.getClass().getName() + "] seems to be read-only - injecting original Collection as-is: " + String.valueOf(ex));
/*     */         }
/*     */         
/* 546 */         return original;
/*     */       } 
/* 548 */       originalAllowed = (originalAllowed && element == convertedElement);
/*     */     } 
/* 550 */     return originalAllowed ? original : convertedCopy;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<?, ?> convertToTypedMap(Map<?, ?> original, @Nullable String propertyName, Class<?> requiredType, @Nullable TypeDescriptor typeDescriptor) {
/*     */     Iterator<?> it;
/*     */     Map<Object, Object> convertedCopy;
/* 557 */     if (!Map.class.isAssignableFrom(requiredType)) {
/* 558 */       return original;
/*     */     }
/*     */     
/* 561 */     boolean approximable = CollectionFactory.isApproximableMapType(requiredType);
/* 562 */     if (!approximable && !canCreateCopy(requiredType)) {
/* 563 */       if (logger.isDebugEnabled()) {
/* 564 */         logger.debug("Custom Map type [" + original.getClass().getName() + "] does not allow for creating a copy - injecting original Map as-is");
/*     */       }
/*     */       
/* 567 */       return original;
/*     */     } 
/*     */     
/* 570 */     boolean originalAllowed = requiredType.isInstance(original);
/* 571 */     TypeDescriptor keyType = (typeDescriptor != null) ? typeDescriptor.getMapKeyTypeDescriptor() : null;
/* 572 */     TypeDescriptor valueType = (typeDescriptor != null) ? typeDescriptor.getMapValueTypeDescriptor() : null;
/* 573 */     if (keyType == null && valueType == null && originalAllowed && 
/* 574 */       !this.propertyEditorRegistry.hasCustomEditorForElement(null, propertyName)) {
/* 575 */       return original;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 580 */       it = original.entrySet().iterator();
/*     */     }
/* 582 */     catch (Throwable ex) {
/* 583 */       if (logger.isDebugEnabled()) {
/* 584 */         logger.debug("Cannot access Map of type [" + original.getClass().getName() + "] - injecting original Map as-is: " + String.valueOf(ex));
/*     */       }
/*     */       
/* 587 */       return original;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 592 */       if (approximable && requiredType.isInstance(original)) {
/* 593 */         convertedCopy = CollectionFactory.createApproximateMap(original, original.size());
/*     */       } else {
/*     */         
/* 596 */         convertedCopy = CollectionFactory.createMap(requiredType, original.size());
/*     */       }
/*     */     
/* 599 */     } catch (Throwable ex) {
/* 600 */       if (logger.isDebugEnabled()) {
/* 601 */         logger.debug("Cannot create copy of Map type [" + original.getClass().getName() + "] - injecting original Map as-is: " + String.valueOf(ex));
/*     */       }
/*     */       
/* 604 */       return original;
/*     */     } 
/*     */     
/* 607 */     while (it.hasNext()) {
/* 608 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)it.next();
/* 609 */       Object key = entry.getKey();
/* 610 */       Object value = entry.getValue();
/* 611 */       String keyedPropertyName = buildKeyedPropertyName(propertyName, key);
/* 612 */       Object convertedKey = convertIfNecessary(keyedPropertyName, null, key, 
/* 613 */           (keyType != null) ? keyType.getType() : null, keyType);
/* 614 */       Object convertedValue = convertIfNecessary(keyedPropertyName, null, value, 
/* 615 */           (valueType != null) ? valueType.getType() : null, valueType);
/*     */       try {
/* 617 */         convertedCopy.put(convertedKey, convertedValue);
/*     */       }
/* 619 */       catch (Throwable ex) {
/* 620 */         if (logger.isDebugEnabled()) {
/* 621 */           logger.debug("Map type [" + original.getClass().getName() + "] seems to be read-only - injecting original Map as-is: " + String.valueOf(ex));
/*     */         }
/*     */         
/* 624 */         return original;
/*     */       } 
/* 626 */       originalAllowed = (originalAllowed && key == convertedKey && value == convertedValue);
/*     */     } 
/* 628 */     return originalAllowed ? original : convertedCopy;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String buildIndexedPropertyName(@Nullable String propertyName, int index) {
/* 633 */     return (propertyName != null) ? (
/* 634 */       propertyName + "[" + propertyName + "]") : 
/* 635 */       null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String buildKeyedPropertyName(@Nullable String propertyName, Object key) {
/* 640 */     return (propertyName != null) ? (
/* 641 */       propertyName + "[" + propertyName + "]") : 
/* 642 */       null;
/*     */   }
/*     */   
/*     */   private boolean canCreateCopy(Class<?> requiredType) {
/* 646 */     return (!requiredType.isInterface() && !Modifier.isAbstract(requiredType.getModifiers()) && 
/* 647 */       Modifier.isPublic(requiredType.getModifiers()) && ClassUtils.hasConstructor(requiredType, new Class[0]));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\TypeConverterDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */