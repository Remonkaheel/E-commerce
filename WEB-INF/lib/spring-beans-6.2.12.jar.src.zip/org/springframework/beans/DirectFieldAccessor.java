/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectFieldAccessor
/*     */   extends AbstractNestablePropertyAccessor
/*     */ {
/*  51 */   private final Map<String, FieldPropertyHandler> fieldMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectFieldAccessor(Object object) {
/*  59 */     super(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DirectFieldAccessor(Object object, String nestedPath, DirectFieldAccessor parent) {
/*  70 */     super(object, nestedPath, parent);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected FieldPropertyHandler getLocalPropertyHandler(String propertyName) {
/*  77 */     FieldPropertyHandler propertyHandler = this.fieldMap.get(propertyName);
/*  78 */     if (propertyHandler == null) {
/*  79 */       Field field = ReflectionUtils.findField(getWrappedClass(), propertyName);
/*  80 */       if (field != null) {
/*  81 */         propertyHandler = new FieldPropertyHandler(field);
/*  82 */         this.fieldMap.put(propertyName, propertyHandler);
/*     */       } 
/*     */     } 
/*  85 */     return propertyHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DirectFieldAccessor newNestedPropertyAccessor(Object object, String nestedPath) {
/*  90 */     return new DirectFieldAccessor(object, nestedPath, this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NotWritablePropertyException createNotWritablePropertyException(String propertyName) {
/*  95 */     PropertyMatches matches = PropertyMatches.forField(propertyName, getRootClass());
/*  96 */     throw new NotWritablePropertyException(getRootClass(), getNestedPath() + getNestedPath(), matches
/*  97 */         .buildErrorMessage(), matches.getPossibleMatches());
/*     */   }
/*     */ 
/*     */   
/*     */   private class FieldPropertyHandler
/*     */     extends AbstractNestablePropertyAccessor.PropertyHandler
/*     */   {
/*     */     private final Field field;
/*     */     private final ResolvableType resolvableType;
/*     */     
/*     */     public FieldPropertyHandler(Field field) {
/* 108 */       super(field.getType(), true, true);
/* 109 */       this.field = field;
/* 110 */       this.resolvableType = ResolvableType.forField(this.field);
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeDescriptor toTypeDescriptor() {
/* 115 */       return new TypeDescriptor(this.resolvableType, this.field.getType(), this.field.getAnnotations());
/*     */     }
/*     */ 
/*     */     
/*     */     public ResolvableType getResolvableType() {
/* 120 */       return this.resolvableType;
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeDescriptor getMapValueType(int nestingLevel) {
/* 125 */       return new TypeDescriptor(this.resolvableType.getNested(nestingLevel).asMap().getGeneric(new int[] { 1 }, ), null, this.field
/* 126 */           .getAnnotations());
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeDescriptor getCollectionType(int nestingLevel) {
/* 131 */       return new TypeDescriptor(this.resolvableType.getNested(nestingLevel).asCollection().getGeneric(new int[0]), null, this.field
/* 132 */           .getAnnotations());
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public TypeDescriptor nested(int level) {
/* 138 */       return TypeDescriptor.nested(this.field, level);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getValue() throws Exception {
/*     */       try {
/* 145 */         ReflectionUtils.makeAccessible(this.field);
/* 146 */         return this.field.get(DirectFieldAccessor.this.getWrappedInstance());
/*     */       }
/* 148 */       catch (IllegalAccessException|java.lang.reflect.InaccessibleObjectException ex) {
/* 149 */         throw new InvalidPropertyException(DirectFieldAccessor.this.getWrappedClass(), this.field
/* 150 */             .getName(), "Field is not accessible", ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(@Nullable Object value) throws Exception {
/*     */       try {
/* 157 */         ReflectionUtils.makeAccessible(this.field);
/* 158 */         this.field.set(DirectFieldAccessor.this.getWrappedInstance(), value);
/*     */       }
/* 160 */       catch (IllegalAccessException|java.lang.reflect.InaccessibleObjectException ex) {
/* 161 */         throw new InvalidPropertyException(DirectFieldAccessor.this.getWrappedClass(), this.field.getName(), "Field is not accessible", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\DirectFieldAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */