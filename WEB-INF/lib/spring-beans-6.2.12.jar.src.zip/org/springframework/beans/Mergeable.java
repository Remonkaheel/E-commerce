package org.springframework.beans;

import org.springframework.lang.Nullable;

public interface Mergeable {
  boolean isMergeEnabled();
  
  Object merge(@Nullable Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\Mergeable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */