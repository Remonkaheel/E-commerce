/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.BeanInfo;
/*    */ import java.beans.IntrospectionException;
/*    */ import java.beans.Introspector;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.SpringProperties;
/*    */ import org.springframework.lang.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardBeanInfoFactory
/*    */   implements BeanInfoFactory, Ordered
/*    */ {
/*    */   public static final String IGNORE_BEANINFO_PROPERTY_NAME = "spring.beaninfo.ignore";
/* 65 */   private static final boolean shouldIntrospectorIgnoreBeaninfoClasses = SpringProperties.getFlag("spring.beaninfo.ignore");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   public BeanInfo getBeanInfo(Class<?> beanClass) throws IntrospectionException {
/* 73 */     BeanInfo beanInfo = shouldIntrospectorIgnoreBeaninfoClasses ? Introspector.getBeanInfo(beanClass, 3) : Introspector.getBeanInfo(beanClass);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 78 */     Class<?> classToFlush = beanClass;
/*    */     do {
/* 80 */       Introspector.flushFromCaches(classToFlush);
/* 81 */       classToFlush = classToFlush.getSuperclass();
/*    */     }
/* 83 */     while (classToFlush != null && classToFlush != Object.class);
/*    */     
/* 85 */     return beanInfo;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 90 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\StandardBeanInfoFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */