/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.BeanDescriptor;
/*    */ import java.beans.BeanInfo;
/*    */ import java.beans.IntrospectionException;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ import java.util.Collection;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.lang.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimpleBeanInfoFactory
/*    */   implements BeanInfoFactory, Ordered
/*    */ {
/*    */   @NonNull
/*    */   public BeanInfo getBeanInfo(final Class<?> beanClass) throws IntrospectionException {
/* 53 */     final Collection<? extends PropertyDescriptor> pds = PropertyDescriptorUtils.determineBasicProperties(beanClass);
/*    */     
/* 55 */     return new SimpleBeanInfo()
/*    */       {
/*    */         public BeanDescriptor getBeanDescriptor() {
/* 58 */           return new BeanDescriptor(beanClass);
/*    */         }
/*    */         
/*    */         public PropertyDescriptor[] getPropertyDescriptors() {
/* 62 */           return (PropertyDescriptor[])pds.toArray((Object[])PropertyDescriptorUtils.EMPTY_PROPERTY_DESCRIPTOR_ARRAY);
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 69 */     return 2147483646;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\SimpleBeanInfoFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */