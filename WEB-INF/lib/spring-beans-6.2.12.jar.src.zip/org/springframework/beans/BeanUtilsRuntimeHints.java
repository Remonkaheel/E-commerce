/*    */ package org.springframework.beans;
/*    */ 
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.core.io.ResourceEditor;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanUtilsRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 37 */     ReflectionHints reflectionHints = hints.reflection();
/* 38 */     reflectionHints.registerType(ResourceEditor.class, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/* 39 */     reflectionHints.registerTypeIfPresent(classLoader, "org.springframework.http.MediaTypeEditor", new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\BeanUtilsRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */