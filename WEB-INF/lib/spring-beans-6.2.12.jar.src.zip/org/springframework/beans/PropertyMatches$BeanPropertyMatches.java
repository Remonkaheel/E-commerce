/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanPropertyMatches
/*     */   extends PropertyMatches
/*     */ {
/*     */   public BeanPropertyMatches(String propertyName, Class<?> beanClass, int maxDistance) {
/* 191 */     super(propertyName, 
/* 192 */         calculateMatches(propertyName, BeanUtils.getPropertyDescriptors(beanClass), maxDistance));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] calculateMatches(String name, PropertyDescriptor[] descriptors, int maxDistance) {
/* 203 */     List<String> candidates = new ArrayList<>();
/* 204 */     for (PropertyDescriptor pd : descriptors) {
/* 205 */       if (pd.getWriteMethod() != null) {
/* 206 */         String possibleAlternative = pd.getName();
/* 207 */         if (PropertyMatches.calculateStringDistance(name, possibleAlternative) <= maxDistance) {
/* 208 */           candidates.add(possibleAlternative);
/*     */         }
/*     */       } 
/*     */     } 
/* 212 */     Collections.sort(candidates);
/* 213 */     return StringUtils.toStringArray(candidates);
/*     */   }
/*     */ 
/*     */   
/*     */   public String buildErrorMessage() {
/* 218 */     StringBuilder msg = new StringBuilder(160);
/* 219 */     msg.append("Bean property '").append(getPropertyName()).append("' is not writable or has an invalid setter method. ");
/*     */     
/* 221 */     if (!ObjectUtils.isEmpty((Object[])getPossibleMatches())) {
/* 222 */       appendHintMessage(msg);
/*     */     } else {
/*     */       
/* 225 */       msg.append("Does the parameter type of the setter match the return type of the getter?");
/*     */     } 
/* 227 */     return msg.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\PropertyMatches$BeanPropertyMatches.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */