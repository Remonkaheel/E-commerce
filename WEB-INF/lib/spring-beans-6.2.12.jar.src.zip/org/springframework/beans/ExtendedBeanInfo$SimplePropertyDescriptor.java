/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimplePropertyDescriptor
/*     */   extends PropertyDescriptor
/*     */ {
/*     */   @Nullable
/*     */   private Method readMethod;
/*     */   @Nullable
/*     */   private Method writeMethod;
/*     */   @Nullable
/*     */   private Class<?> propertyType;
/*     */   @Nullable
/*     */   private Class<?> propertyEditorClass;
/*     */   
/*     */   public SimplePropertyDescriptor(PropertyDescriptor original) throws IntrospectionException {
/* 281 */     this(original.getName(), original.getReadMethod(), original.getWriteMethod());
/* 282 */     PropertyDescriptorUtils.copyNonMethodProperties(original, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimplePropertyDescriptor(String propertyName, @Nullable Method readMethod, Method writeMethod) throws IntrospectionException {
/* 288 */     super(propertyName, null, null);
/* 289 */     this.readMethod = readMethod;
/* 290 */     this.writeMethod = writeMethod;
/* 291 */     this.propertyType = PropertyDescriptorUtils.findPropertyType(readMethod, writeMethod);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getReadMethod() {
/* 297 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadMethod(@Nullable Method readMethod) {
/* 302 */     this.readMethod = readMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getWriteMethod() {
/* 308 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWriteMethod(@Nullable Method writeMethod) {
/* 313 */     this.writeMethod = writeMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPropertyType() {
/* 319 */     if (this.propertyType == null) {
/*     */       try {
/* 321 */         this.propertyType = PropertyDescriptorUtils.findPropertyType(this.readMethod, this.writeMethod);
/*     */       }
/* 323 */       catch (IntrospectionException introspectionException) {}
/*     */     }
/*     */ 
/*     */     
/* 327 */     return this.propertyType;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPropertyEditorClass() {
/* 333 */     return this.propertyEditorClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertyEditorClass(@Nullable Class<?> propertyEditorClass) {
/* 338 */     this.propertyEditorClass = propertyEditorClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 343 */     if (this != other) { if (other instanceof PropertyDescriptor) { PropertyDescriptor that = (PropertyDescriptor)other;
/* 344 */         if (PropertyDescriptorUtils.equals(this, that)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 349 */     return Objects.hash(new Object[] { getReadMethod(), getWriteMethod() });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 354 */     return String.format("%s[name=%s, propertyType=%s, readMethod=%s, writeMethod=%s]", new Object[] {
/* 355 */           getClass().getSimpleName(), getName(), getPropertyType(), this.readMethod, this.writeMethod
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\ExtendedBeanInfo$SimplePropertyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */