package org.springframework.beans;

import org.springframework.core.convert.ConversionService;
import org.springframework.lang.Nullable;

public interface ConfigurablePropertyAccessor extends PropertyAccessor, PropertyEditorRegistry, TypeConverter {
  void setConversionService(@Nullable ConversionService paramConversionService);
  
  @Nullable
  ConversionService getConversionService();
  
  void setExtractOldValueForEditor(boolean paramBoolean);
  
  boolean isExtractOldValueForEditor();
  
  void setAutoGrowNestedPaths(boolean paramBoolean);
  
  boolean isAutoGrowNestedPaths();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\ConfigurablePropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */