/*      */ package org.springframework.beans;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.CollectionFactory;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.core.convert.ConversionException;
/*      */ import org.springframework.core.convert.ConverterNotFoundException;
/*      */ import org.springframework.core.convert.TypeDescriptor;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractNestablePropertyAccessor
/*      */   extends AbstractPropertyAccessor
/*      */ {
/*   77 */   private static final Log logger = LogFactory.getLog(AbstractNestablePropertyAccessor.class);
/*      */   
/*   79 */   private int autoGrowCollectionLimit = Integer.MAX_VALUE;
/*      */   
/*      */   @Nullable
/*      */   Object wrappedObject;
/*      */   
/*   84 */   private String nestedPath = "";
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   Object rootObject;
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Map<String, AbstractNestablePropertyAccessor> nestedPropertyAccessors;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor() {
/*  100 */     this(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor(boolean registerDefaultEditors) {
/*  110 */     if (registerDefaultEditors) {
/*  111 */       registerDefaultEditors();
/*      */     }
/*  113 */     this.typeConverterDelegate = new TypeConverterDelegate(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor(Object object) {
/*  121 */     registerDefaultEditors();
/*  122 */     setWrappedInstance(object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor(Class<?> clazz) {
/*  130 */     registerDefaultEditors();
/*  131 */     setWrappedInstance(BeanUtils.instantiateClass(clazz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor(Object object, String nestedPath, Object rootObject) {
/*  142 */     registerDefaultEditors();
/*  143 */     setWrappedInstance(object, nestedPath, rootObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor(Object object, String nestedPath, AbstractNestablePropertyAccessor parent) {
/*  154 */     setWrappedInstance(object, nestedPath, parent.getWrappedInstance());
/*  155 */     setExtractOldValueForEditor(parent.isExtractOldValueForEditor());
/*  156 */     setAutoGrowNestedPaths(parent.isAutoGrowNestedPaths());
/*  157 */     setAutoGrowCollectionLimit(parent.getAutoGrowCollectionLimit());
/*  158 */     setConversionService(parent.getConversionService());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoGrowCollectionLimit(int autoGrowCollectionLimit) {
/*  167 */     this.autoGrowCollectionLimit = autoGrowCollectionLimit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAutoGrowCollectionLimit() {
/*  174 */     return this.autoGrowCollectionLimit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWrappedInstance(Object object) {
/*  183 */     setWrappedInstance(object, "", (Object)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWrappedInstance(Object object, @Nullable String nestedPath, @Nullable Object rootObject) {
/*  194 */     this.wrappedObject = ObjectUtils.unwrapOptional(object);
/*  195 */     Assert.notNull(this.wrappedObject, "Target object must not be null");
/*  196 */     this.nestedPath = (nestedPath != null) ? nestedPath : "";
/*  197 */     this.rootObject = !this.nestedPath.isEmpty() ? rootObject : this.wrappedObject;
/*  198 */     this.nestedPropertyAccessors = null;
/*  199 */     this.typeConverterDelegate = new TypeConverterDelegate(this, this.wrappedObject);
/*      */   }
/*      */   
/*      */   public final Object getWrappedInstance() {
/*  203 */     Assert.state((this.wrappedObject != null), "No wrapped object");
/*  204 */     return this.wrappedObject;
/*      */   }
/*      */   
/*      */   public final Class<?> getWrappedClass() {
/*  208 */     return getWrappedInstance().getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getNestedPath() {
/*  215 */     return this.nestedPath;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object getRootInstance() {
/*  223 */     Assert.state((this.rootObject != null), "No root object");
/*  224 */     return this.rootObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Class<?> getRootClass() {
/*  232 */     return getRootInstance().getClass();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPropertyValue(String propertyName, @Nullable Object value) throws BeansException {
/*      */     AbstractNestablePropertyAccessor nestedPa;
/*      */     try {
/*  239 */       nestedPa = getPropertyAccessorForPropertyPath(propertyName);
/*      */     }
/*  241 */     catch (NotReadablePropertyException ex) {
/*  242 */       throw new NotWritablePropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Nested property in path '" + propertyName + "' does not exist", ex);
/*      */     } 
/*      */     
/*  245 */     PropertyTokenHolder tokens = getPropertyNameTokens(getFinalPath(nestedPa, propertyName));
/*  246 */     nestedPa.setPropertyValue(tokens, new PropertyValue(propertyName, value));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPropertyValue(PropertyValue pv) throws BeansException {
/*  251 */     PropertyTokenHolder tokens = (PropertyTokenHolder)pv.resolvedTokens;
/*  252 */     if (tokens == null) {
/*  253 */       AbstractNestablePropertyAccessor nestedPa; String propertyName = pv.getName();
/*      */       
/*      */       try {
/*  256 */         nestedPa = getPropertyAccessorForPropertyPath(propertyName);
/*      */       }
/*  258 */       catch (NotReadablePropertyException ex) {
/*  259 */         throw new NotWritablePropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Nested property in path '" + propertyName + "' does not exist", ex);
/*      */       } 
/*      */       
/*  262 */       tokens = getPropertyNameTokens(getFinalPath(nestedPa, propertyName));
/*  263 */       if (nestedPa == this) {
/*  264 */         (pv.getOriginalPropertyValue()).resolvedTokens = tokens;
/*      */       }
/*  266 */       nestedPa.setPropertyValue(tokens, pv);
/*      */     } else {
/*      */       
/*  269 */       setPropertyValue(tokens, pv);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void setPropertyValue(PropertyTokenHolder tokens, PropertyValue pv) throws BeansException {
/*  274 */     if (tokens.keys != null) {
/*  275 */       processKeyedProperty(tokens, pv);
/*      */     } else {
/*      */       
/*  278 */       processLocalProperty(tokens, pv);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void processKeyedProperty(PropertyTokenHolder tokens, PropertyValue pv) {
/*  284 */     Object propValue = getPropertyHoldingValue(tokens);
/*  285 */     PropertyHandler ph = getLocalPropertyHandler(tokens.actualName);
/*  286 */     if (ph == null) {
/*  287 */       throw new InvalidPropertyException(
/*  288 */           getRootClass(), this.nestedPath + this.nestedPath, "No property handler found");
/*      */     }
/*  290 */     Assert.state((tokens.keys != null), "No token keys");
/*  291 */     String lastKey = tokens.keys[tokens.keys.length - 1];
/*      */     
/*  293 */     if (propValue.getClass().isArray())
/*  294 */     { Class<?> componentType = propValue.getClass().componentType();
/*  295 */       int arrayIndex = Integer.parseInt(lastKey);
/*  296 */       Object oldValue = null;
/*      */       try {
/*  298 */         if (isExtractOldValueForEditor() && arrayIndex < Array.getLength(propValue)) {
/*  299 */           oldValue = Array.get(propValue, arrayIndex);
/*      */         }
/*  301 */         Object convertedValue = convertIfNecessary(tokens.canonicalName, oldValue, pv.getValue(), componentType, ph
/*  302 */             .nested(tokens.keys.length));
/*  303 */         int length = Array.getLength(propValue);
/*  304 */         if (arrayIndex >= length && arrayIndex < this.autoGrowCollectionLimit) {
/*  305 */           Object newArray = Array.newInstance(componentType, arrayIndex + 1);
/*  306 */           System.arraycopy(propValue, 0, newArray, 0, length);
/*  307 */           int lastKeyIndex = tokens.canonicalName.lastIndexOf('[');
/*  308 */           String propName = tokens.canonicalName.substring(0, lastKeyIndex);
/*  309 */           setPropertyValue(propName, newArray);
/*  310 */           propValue = getPropertyValue(propName);
/*      */         } 
/*  312 */         Array.set(propValue, arrayIndex, convertedValue);
/*      */       }
/*  314 */       catch (IndexOutOfBoundsException ex) {
/*  315 */         throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Invalid array index in property path '" + tokens.canonicalName + "'", ex);
/*      */       
/*      */       }
/*      */        }
/*      */     
/*  320 */     else if (propValue instanceof List) { List<Object> list = (List)propValue;
/*  321 */       TypeDescriptor requiredType = ph.getCollectionType(tokens.keys.length);
/*  322 */       int index = Integer.parseInt(lastKey);
/*  323 */       Object oldValue = null;
/*  324 */       if (isExtractOldValueForEditor() && index < list.size()) {
/*  325 */         oldValue = list.get(index);
/*      */       }
/*  327 */       Object convertedValue = convertIfNecessary(tokens.canonicalName, oldValue, pv.getValue(), requiredType
/*  328 */           .getResolvableType().resolve(), requiredType);
/*  329 */       int size = list.size();
/*  330 */       if (index >= size && index < this.autoGrowCollectionLimit) {
/*  331 */         for (int i = size; i < index; i++) {
/*      */           try {
/*  333 */             list.add(null);
/*      */           }
/*  335 */           catch (NullPointerException ex) {
/*  336 */             throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot set element with index " + index + " in List of size " + size + ", accessed using property path '" + tokens.canonicalName + "': List does not support filling up gaps with null elements");
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  342 */         list.add(convertedValue);
/*      */       } else {
/*      */         
/*      */         try {
/*  346 */           list.set(index, convertedValue);
/*      */         }
/*  348 */         catch (IndexOutOfBoundsException ex) {
/*  349 */           throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Invalid list index in property path '" + tokens.canonicalName + "'", ex);
/*      */         }
/*      */       
/*      */       }
/*      */        }
/*      */     
/*  355 */     else if (propValue instanceof Map) { Map<Object, Object> map = (Map)propValue;
/*  356 */       TypeDescriptor mapKeyType = ph.getMapKeyType(tokens.keys.length);
/*  357 */       TypeDescriptor mapValueType = ph.getMapValueType(tokens.keys.length);
/*      */ 
/*      */       
/*  360 */       Object convertedMapKey = convertIfNecessary((String)null, (Object)null, lastKey, mapKeyType
/*  361 */           .getResolvableType().resolve(), mapKeyType);
/*  362 */       Object oldValue = null;
/*  363 */       if (isExtractOldValueForEditor()) {
/*  364 */         oldValue = map.get(convertedMapKey);
/*      */       }
/*      */ 
/*      */       
/*  368 */       Object convertedMapValue = convertIfNecessary(tokens.canonicalName, oldValue, pv.getValue(), mapValueType
/*  369 */           .getResolvableType().resolve(), mapValueType);
/*  370 */       map.put(convertedMapKey, convertedMapValue); }
/*      */     
/*      */     else
/*      */     
/*  374 */     { throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Property referenced in indexed property path '" + tokens.canonicalName + "' is neither an array nor a List nor a Map; returned value was [" + String.valueOf(propValue) + "]"); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getPropertyHoldingValue(PropertyTokenHolder tokens) {
/*      */     Object propValue;
/*  382 */     Assert.state((tokens.keys != null), "No token keys");
/*  383 */     PropertyTokenHolder getterTokens = new PropertyTokenHolder(tokens.actualName);
/*  384 */     getterTokens.canonicalName = tokens.canonicalName;
/*  385 */     getterTokens.keys = new String[tokens.keys.length - 1];
/*  386 */     System.arraycopy(tokens.keys, 0, getterTokens.keys, 0, tokens.keys.length - 1);
/*      */ 
/*      */     
/*      */     try {
/*  390 */       propValue = getPropertyValue(getterTokens);
/*      */     }
/*  392 */     catch (NotReadablePropertyException ex) {
/*  393 */       throw new NotWritablePropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot access indexed value in property referenced in indexed property path '" + tokens.canonicalName + "'", ex);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  398 */     if (propValue == null)
/*      */     {
/*  400 */       if (isAutoGrowNestedPaths()) {
/*  401 */         int lastKeyIndex = tokens.canonicalName.lastIndexOf('[');
/*  402 */         getterTokens.canonicalName = tokens.canonicalName.substring(0, lastKeyIndex);
/*  403 */         propValue = setDefaultValue(getterTokens);
/*      */       } else {
/*      */         
/*  406 */         throw new NullValueInNestedPathException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot access indexed value in property referenced in indexed property path '" + tokens.canonicalName + "': returned null");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  411 */     return propValue;
/*      */   }
/*      */   
/*      */   private void processLocalProperty(PropertyTokenHolder tokens, PropertyValue pv) {
/*  415 */     PropertyHandler ph = getLocalPropertyHandler(tokens.actualName);
/*  416 */     if (ph == null || !ph.isWritable()) {
/*  417 */       if (pv.isOptional()) {
/*  418 */         if (logger.isDebugEnabled()) {
/*  419 */           logger.debug("Ignoring optional value for property '" + tokens.actualName + "' - property not found on bean class [" + 
/*  420 */               getRootClass().getName() + "]");
/*      */         }
/*      */         return;
/*      */       } 
/*  424 */       if (this.suppressNotWritablePropertyException) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  429 */       throw createNotWritablePropertyException(tokens.canonicalName);
/*      */     } 
/*      */     
/*  432 */     Object oldValue = null;
/*      */     try {
/*  434 */       Object originalValue = pv.getValue();
/*  435 */       Object valueToApply = originalValue;
/*  436 */       if (!Boolean.FALSE.equals(pv.conversionNecessary)) {
/*  437 */         if (pv.isConverted()) {
/*  438 */           valueToApply = pv.getConvertedValue();
/*      */         } else {
/*      */           
/*  441 */           if (isExtractOldValueForEditor() && ph.isReadable()) {
/*      */             try {
/*  443 */               oldValue = ph.getValue();
/*      */             }
/*  445 */             catch (Exception ex) {
/*  446 */               if (ex instanceof PrivilegedActionException) { PrivilegedActionException pae = (PrivilegedActionException)ex;
/*  447 */                 ex = pae.getException(); }
/*      */               
/*  449 */               if (logger.isDebugEnabled()) {
/*  450 */                 logger.debug("Could not read previous value of property '" + this.nestedPath + tokens.canonicalName + "'", ex);
/*      */               }
/*      */             } 
/*      */           }
/*      */           
/*  455 */           valueToApply = convertForProperty(tokens.canonicalName, oldValue, originalValue, ph
/*  456 */               .toTypeDescriptor());
/*      */         } 
/*  458 */         (pv.getOriginalPropertyValue()).conversionNecessary = Boolean.valueOf((valueToApply != originalValue));
/*      */       } 
/*  460 */       ph.setValue(valueToApply);
/*      */     }
/*  462 */     catch (TypeMismatchException ex) {
/*  463 */       if (!ph.setValueFallbackIfPossible(pv.getValue())) {
/*  464 */         throw ex;
/*      */       }
/*      */     }
/*  467 */     catch (InvocationTargetException ex) {
/*      */       
/*  469 */       PropertyChangeEvent propertyChangeEvent = new PropertyChangeEvent(getRootInstance(), this.nestedPath + this.nestedPath, oldValue, pv.getValue());
/*  470 */       if (ex.getTargetException() instanceof ClassCastException) {
/*  471 */         throw new TypeMismatchException(propertyChangeEvent, ph.getPropertyType(), ex.getTargetException());
/*      */       }
/*      */       
/*  474 */       Throwable cause = ex.getTargetException();
/*  475 */       if (cause instanceof java.lang.reflect.UndeclaredThrowableException)
/*      */       {
/*  477 */         cause = cause.getCause();
/*      */       }
/*  479 */       throw new MethodInvocationException(propertyChangeEvent, cause);
/*      */     
/*      */     }
/*  482 */     catch (Exception ex) {
/*      */       
/*  484 */       PropertyChangeEvent pce = new PropertyChangeEvent(getRootInstance(), this.nestedPath + this.nestedPath, oldValue, pv.getValue());
/*  485 */       throw new MethodInvocationException(pce, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Class<?> getPropertyType(String propertyName) throws BeansException {
/*      */     try {
/*  493 */       PropertyHandler ph = getPropertyHandler(propertyName);
/*  494 */       if (ph != null) {
/*  495 */         return ph.getPropertyType();
/*      */       }
/*      */ 
/*      */       
/*  499 */       Object value = getPropertyValue(propertyName);
/*  500 */       if (value != null) {
/*  501 */         return value.getClass();
/*      */       }
/*      */ 
/*      */       
/*  505 */       Class<?> editorType = guessPropertyTypeFromEditors(propertyName);
/*  506 */       if (editorType != null) {
/*  507 */         return editorType;
/*      */       
/*      */       }
/*      */     }
/*  511 */     catch (InvalidPropertyException invalidPropertyException) {}
/*      */ 
/*      */     
/*  514 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public TypeDescriptor getPropertyTypeDescriptor(String propertyName) throws BeansException {
/*      */     try {
/*  521 */       AbstractNestablePropertyAccessor nestedPa = getPropertyAccessorForPropertyPath(propertyName);
/*  522 */       String finalPath = getFinalPath(nestedPa, propertyName);
/*  523 */       PropertyTokenHolder tokens = getPropertyNameTokens(finalPath);
/*  524 */       PropertyHandler ph = nestedPa.getLocalPropertyHandler(tokens.actualName);
/*  525 */       if (ph != null) {
/*  526 */         if (tokens.keys != null) {
/*  527 */           if (ph.isReadable() || ph.isWritable()) {
/*  528 */             return ph.nested(tokens.keys.length);
/*      */           
/*      */           }
/*      */         }
/*  532 */         else if (ph.isReadable() || ph.isWritable()) {
/*  533 */           return ph.toTypeDescriptor();
/*      */         }
/*      */       
/*      */       }
/*      */     }
/*  538 */     catch (InvalidPropertyException invalidPropertyException) {}
/*      */ 
/*      */     
/*  541 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadableProperty(String propertyName) {
/*      */     try {
/*  547 */       PropertyHandler ph = getPropertyHandler(propertyName);
/*  548 */       if (ph != null) {
/*  549 */         return ph.isReadable();
/*      */       }
/*      */ 
/*      */       
/*  553 */       getPropertyValue(propertyName);
/*  554 */       return true;
/*      */     
/*      */     }
/*  557 */     catch (InvalidPropertyException invalidPropertyException) {
/*      */ 
/*      */       
/*  560 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isWritableProperty(String propertyName) {
/*      */     try {
/*  566 */       PropertyHandler ph = getPropertyHandler(propertyName);
/*  567 */       if (ph != null) {
/*  568 */         return ph.isWritable();
/*      */       }
/*      */ 
/*      */       
/*  572 */       getPropertyValue(propertyName);
/*  573 */       return true;
/*      */     
/*      */     }
/*  576 */     catch (InvalidPropertyException invalidPropertyException) {
/*      */ 
/*      */       
/*  579 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object convertIfNecessary(@Nullable String propertyName, @Nullable Object oldValue, @Nullable Object newValue, @Nullable Class<?> requiredType, @Nullable TypeDescriptor td) throws TypeMismatchException {
/*  587 */     Assert.state((this.typeConverterDelegate != null), "No TypeConverterDelegate");
/*      */     try {
/*  589 */       return this.typeConverterDelegate.convertIfNecessary(propertyName, oldValue, newValue, requiredType, td);
/*      */     }
/*  591 */     catch (ConverterNotFoundException|IllegalStateException ex) {
/*      */       
/*  593 */       PropertyChangeEvent pce = new PropertyChangeEvent(getRootInstance(), this.nestedPath + this.nestedPath, oldValue, newValue);
/*  594 */       throw new ConversionNotSupportedException(pce, requiredType, ex);
/*      */     }
/*  596 */     catch (ConversionException|IllegalArgumentException ex) {
/*      */       
/*  598 */       PropertyChangeEvent pce = new PropertyChangeEvent(getRootInstance(), this.nestedPath + this.nestedPath, oldValue, newValue);
/*  599 */       throw new TypeMismatchException(pce, requiredType, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object convertForProperty(String propertyName, @Nullable Object oldValue, @Nullable Object newValue, TypeDescriptor td) throws TypeMismatchException {
/*  608 */     return convertIfNecessary(propertyName, oldValue, newValue, td.getType(), td);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object getPropertyValue(String propertyName) throws BeansException {
/*  614 */     AbstractNestablePropertyAccessor nestedPa = getPropertyAccessorForPropertyPath(propertyName);
/*  615 */     PropertyTokenHolder tokens = getPropertyNameTokens(getFinalPath(nestedPa, propertyName));
/*  616 */     return nestedPa.getPropertyValue(tokens);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object getPropertyValue(PropertyTokenHolder tokens) throws BeansException {
/*  622 */     String propertyName = tokens.canonicalName;
/*  623 */     String actualName = tokens.actualName;
/*  624 */     PropertyHandler ph = getLocalPropertyHandler(actualName);
/*  625 */     if (ph == null || !ph.isReadable()) {
/*  626 */       throw new NotReadablePropertyException(getRootClass(), this.nestedPath + this.nestedPath);
/*      */     }
/*      */     try {
/*  629 */       Object value = ph.getValue();
/*  630 */       if (tokens.keys != null) {
/*  631 */         if (value == null) {
/*  632 */           if (isAutoGrowNestedPaths()) {
/*  633 */             value = setDefaultValue(new PropertyTokenHolder(tokens.actualName));
/*      */           } else {
/*      */             
/*  636 */             throw new NullValueInNestedPathException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot access indexed value of property referenced in indexed property path '" + propertyName + "': returned null");
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  641 */         StringBuilder indexedPropertyName = new StringBuilder(tokens.actualName);
/*      */         
/*  643 */         for (int i = 0; i < tokens.keys.length; i++) {
/*  644 */           String key = tokens.keys[i];
/*  645 */           if (value == null) {
/*  646 */             throw new NullValueInNestedPathException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot access indexed value of property referenced in indexed property path '" + propertyName + "': returned null");
/*      */           }
/*      */ 
/*      */           
/*  650 */           if (value.getClass().isArray())
/*  651 */           { int index = Integer.parseInt(key);
/*  652 */             value = growArrayIfNecessary(value, index, indexedPropertyName.toString());
/*  653 */             value = Array.get(value, index); }
/*      */           
/*  655 */           else if (value instanceof List) { List<Object> list = (List)value;
/*  656 */             int index = Integer.parseInt(key);
/*  657 */             growCollectionIfNecessary(list, index, indexedPropertyName.toString(), ph, i + 1);
/*  658 */             value = list.get(index); }
/*      */           
/*  660 */           else if (value instanceof Map) { Map map = (Map)value;
/*  661 */             Class<?> mapKeyType = ph.getResolvableType().getNested(i + 1).asMap().resolveGeneric(new int[] { 0 });
/*      */ 
/*      */             
/*  664 */             TypeDescriptor typeDescriptor = TypeDescriptor.valueOf(mapKeyType);
/*  665 */             Object convertedMapKey = convertIfNecessary((String)null, (Object)null, key, mapKeyType, typeDescriptor);
/*  666 */             value = map.get(convertedMapKey); }
/*      */           
/*  668 */           else if (value instanceof Iterable) { Iterable<Object> iterable = (Iterable)value;
/*      */             
/*  670 */             int index = Integer.parseInt(key);
/*  671 */             if (value instanceof Collection) { Collection<?> coll = (Collection)value;
/*  672 */               if (index < 0 || index >= coll.size()) {
/*  673 */                 throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot get element with index " + index + " from Collection of size " + coll
/*      */                     
/*  675 */                     .size() + ", accessed using property path '" + propertyName + "'");
/*      */               } }
/*      */             
/*  678 */             Iterator<Object> it = iterable.iterator();
/*  679 */             boolean found = false;
/*  680 */             int currIndex = 0;
/*  681 */             for (; it.hasNext(); currIndex++) {
/*  682 */               Object elem = it.next();
/*  683 */               if (currIndex == index) {
/*  684 */                 value = elem;
/*  685 */                 found = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/*  689 */             if (!found) {
/*  690 */               throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Cannot get element with index " + index + " from Iterable of size " + currIndex + ", accessed using property path '" + propertyName + "'");
/*      */             
/*      */             } }
/*      */           
/*      */           else
/*      */           
/*  696 */           { throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Property referenced in indexed property path '" + propertyName + "' is neither an array nor a List/Set/Collection/Iterable nor a Map; returned value was [" + String.valueOf(value) + "]"); }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  701 */           indexedPropertyName.append("[").append(key).append("]");
/*      */         } 
/*      */       } 
/*  704 */       return value;
/*      */     }
/*  706 */     catch (InvalidPropertyException ex) {
/*  707 */       throw ex;
/*      */     }
/*  709 */     catch (IndexOutOfBoundsException ex) {
/*  710 */       throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Index of out of bounds in property path '" + propertyName + "'", ex);
/*      */     
/*      */     }
/*  713 */     catch (NumberFormatException|TypeMismatchException ex) {
/*  714 */       throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Invalid index in property path '" + propertyName + "'", ex);
/*      */     
/*      */     }
/*  717 */     catch (InvocationTargetException ex) {
/*  718 */       throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Getter for property '" + actualName + "' threw exception", ex);
/*      */     
/*      */     }
/*  721 */     catch (Exception ex) {
/*  722 */       throw new InvalidPropertyException(getRootClass(), this.nestedPath + this.nestedPath, "Illegal attempt to get property '" + actualName + "' threw exception", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected PropertyHandler getPropertyHandler(String propertyName) throws BeansException {
/*  738 */     Assert.notNull(propertyName, "Property name must not be null");
/*  739 */     AbstractNestablePropertyAccessor nestedPa = getPropertyAccessorForPropertyPath(propertyName);
/*  740 */     return nestedPa.getLocalPropertyHandler(getFinalPath(nestedPa, propertyName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected abstract PropertyHandler getLocalPropertyHandler(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract AbstractNestablePropertyAccessor newNestedPropertyAccessor(Object paramObject, String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract NotWritablePropertyException createNotWritablePropertyException(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object growArrayIfNecessary(Object array, int index, String name) {
/*  768 */     if (!isAutoGrowNestedPaths()) {
/*  769 */       return array;
/*      */     }
/*  771 */     int length = Array.getLength(array);
/*  772 */     if (index >= length && index < this.autoGrowCollectionLimit) {
/*  773 */       Class<?> componentType = array.getClass().componentType();
/*  774 */       Object newArray = Array.newInstance(componentType, index + 1);
/*  775 */       System.arraycopy(array, 0, newArray, 0, length);
/*  776 */       for (int i = length; i < Array.getLength(newArray); i++) {
/*  777 */         Array.set(newArray, i, newValue(componentType, (TypeDescriptor)null, name));
/*      */       }
/*  779 */       setPropertyValue(name, newArray);
/*  780 */       Object defaultValue = getPropertyValue(name);
/*  781 */       Assert.state((defaultValue != null), "Default value must not be null");
/*  782 */       return defaultValue;
/*      */     } 
/*      */     
/*  785 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void growCollectionIfNecessary(Collection<Object> collection, int index, String name, PropertyHandler ph, int nestingLevel) {
/*  792 */     if (!isAutoGrowNestedPaths()) {
/*      */       return;
/*      */     }
/*  795 */     int size = collection.size();
/*  796 */     if (index >= size && index < this.autoGrowCollectionLimit) {
/*  797 */       Class<?> elementType = ph.getResolvableType().getNested(nestingLevel).asCollection().resolveGeneric(new int[0]);
/*  798 */       if (elementType != null) {
/*  799 */         for (int i = collection.size(); i < index + 1; i++) {
/*  800 */           collection.add(newValue(elementType, (TypeDescriptor)null, name));
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFinalPath(AbstractNestablePropertyAccessor pa, String nestedPath) {
/*  813 */     if (pa == this) {
/*  814 */       return nestedPath;
/*      */     }
/*  816 */     return nestedPath.substring(PropertyAccessorUtils.getLastNestedPropertySeparatorIndex(nestedPath) + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractNestablePropertyAccessor getPropertyAccessorForPropertyPath(String propertyPath) {
/*  825 */     int pos = PropertyAccessorUtils.getFirstNestedPropertySeparatorIndex(propertyPath);
/*      */     
/*  827 */     if (pos > -1) {
/*  828 */       String nestedProperty = propertyPath.substring(0, pos);
/*  829 */       String nestedPath = propertyPath.substring(pos + 1);
/*  830 */       AbstractNestablePropertyAccessor nestedPa = getNestedPropertyAccessor(nestedProperty);
/*  831 */       return nestedPa.getPropertyAccessorForPropertyPath(nestedPath);
/*      */     } 
/*      */     
/*  834 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AbstractNestablePropertyAccessor getNestedPropertyAccessor(String nestedProperty) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield nestedPropertyAccessors : Ljava/util/Map;
/*      */     //   4: astore_2
/*      */     //   5: aload_2
/*      */     //   6: ifnonnull -> 22
/*      */     //   9: new java/util/HashMap
/*      */     //   12: dup
/*      */     //   13: invokespecial <init> : ()V
/*      */     //   16: astore_2
/*      */     //   17: aload_0
/*      */     //   18: aload_2
/*      */     //   19: putfield nestedPropertyAccessors : Ljava/util/Map;
/*      */     //   22: aload_0
/*      */     //   23: aload_1
/*      */     //   24: invokevirtual getPropertyNameTokens : (Ljava/lang/String;)Lorg/springframework/beans/AbstractNestablePropertyAccessor$PropertyTokenHolder;
/*      */     //   27: astore_3
/*      */     //   28: aload_3
/*      */     //   29: getfield canonicalName : Ljava/lang/String;
/*      */     //   32: astore #4
/*      */     //   34: aload_0
/*      */     //   35: aload_3
/*      */     //   36: invokevirtual getPropertyValue : (Lorg/springframework/beans/AbstractNestablePropertyAccessor$PropertyTokenHolder;)Ljava/lang/Object;
/*      */     //   39: astore #5
/*      */     //   41: aload #5
/*      */     //   43: ifnull -> 69
/*      */     //   46: aload #5
/*      */     //   48: instanceof java/util/Optional
/*      */     //   51: ifeq -> 109
/*      */     //   54: aload #5
/*      */     //   56: checkcast java/util/Optional
/*      */     //   59: astore #6
/*      */     //   61: aload #6
/*      */     //   63: invokevirtual isEmpty : ()Z
/*      */     //   66: ifeq -> 109
/*      */     //   69: aload_0
/*      */     //   70: invokevirtual isAutoGrowNestedPaths : ()Z
/*      */     //   73: ifeq -> 86
/*      */     //   76: aload_0
/*      */     //   77: aload_3
/*      */     //   78: invokevirtual setDefaultValue : (Lorg/springframework/beans/AbstractNestablePropertyAccessor$PropertyTokenHolder;)Ljava/lang/Object;
/*      */     //   81: astore #5
/*      */     //   83: goto -> 109
/*      */     //   86: new org/springframework/beans/NullValueInNestedPathException
/*      */     //   89: dup
/*      */     //   90: aload_0
/*      */     //   91: invokevirtual getRootClass : ()Ljava/lang/Class;
/*      */     //   94: aload_0
/*      */     //   95: getfield nestedPath : Ljava/lang/String;
/*      */     //   98: aload #4
/*      */     //   100: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   105: invokespecial <init> : (Ljava/lang/Class;Ljava/lang/String;)V
/*      */     //   108: athrow
/*      */     //   109: aload_2
/*      */     //   110: aload #4
/*      */     //   112: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   117: checkcast org/springframework/beans/AbstractNestablePropertyAccessor
/*      */     //   120: astore #6
/*      */     //   122: aload #6
/*      */     //   124: ifnull -> 140
/*      */     //   127: aload #6
/*      */     //   129: invokevirtual getWrappedInstance : ()Ljava/lang/Object;
/*      */     //   132: aload #5
/*      */     //   134: invokestatic unwrapOptional : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   137: if_acmpeq -> 220
/*      */     //   140: getstatic org/springframework/beans/AbstractNestablePropertyAccessor.logger : Lorg/apache/commons/logging/Log;
/*      */     //   143: invokeinterface isTraceEnabled : ()Z
/*      */     //   148: ifeq -> 173
/*      */     //   151: getstatic org/springframework/beans/AbstractNestablePropertyAccessor.logger : Lorg/apache/commons/logging/Log;
/*      */     //   154: aload_0
/*      */     //   155: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   158: invokevirtual getSimpleName : ()Ljava/lang/String;
/*      */     //   161: aload #4
/*      */     //   163: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   168: invokeinterface trace : (Ljava/lang/Object;)V
/*      */     //   173: aload_0
/*      */     //   174: aload #5
/*      */     //   176: aload_0
/*      */     //   177: getfield nestedPath : Ljava/lang/String;
/*      */     //   180: aload #4
/*      */     //   182: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   187: invokevirtual newNestedPropertyAccessor : (Ljava/lang/Object;Ljava/lang/String;)Lorg/springframework/beans/AbstractNestablePropertyAccessor;
/*      */     //   190: astore #6
/*      */     //   192: aload_0
/*      */     //   193: aload #6
/*      */     //   195: invokevirtual copyDefaultEditorsTo : (Lorg/springframework/beans/PropertyEditorRegistrySupport;)V
/*      */     //   198: aload_0
/*      */     //   199: aload #6
/*      */     //   201: aload #4
/*      */     //   203: invokevirtual copyCustomEditorsTo : (Lorg/springframework/beans/PropertyEditorRegistry;Ljava/lang/String;)V
/*      */     //   206: aload_2
/*      */     //   207: aload #4
/*      */     //   209: aload #6
/*      */     //   211: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   216: pop
/*      */     //   217: goto -> 246
/*      */     //   220: getstatic org/springframework/beans/AbstractNestablePropertyAccessor.logger : Lorg/apache/commons/logging/Log;
/*      */     //   223: invokeinterface isTraceEnabled : ()Z
/*      */     //   228: ifeq -> 246
/*      */     //   231: getstatic org/springframework/beans/AbstractNestablePropertyAccessor.logger : Lorg/apache/commons/logging/Log;
/*      */     //   234: aload #4
/*      */     //   236: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   241: invokeinterface trace : (Ljava/lang/Object;)V
/*      */     //   246: aload #6
/*      */     //   248: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #847	-> 0
/*      */     //   #848	-> 5
/*      */     //   #849	-> 9
/*      */     //   #850	-> 17
/*      */     //   #853	-> 22
/*      */     //   #854	-> 28
/*      */     //   #855	-> 34
/*      */     //   #856	-> 41
/*      */     //   #857	-> 69
/*      */     //   #858	-> 76
/*      */     //   #861	-> 86
/*      */     //   #866	-> 109
/*      */     //   #867	-> 122
/*      */     //   #868	-> 140
/*      */     //   #869	-> 151
/*      */     //   #871	-> 173
/*      */     //   #873	-> 192
/*      */     //   #874	-> 198
/*      */     //   #875	-> 206
/*      */     //   #878	-> 220
/*      */     //   #879	-> 231
/*      */     //   #882	-> 246
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   61	8	6	optional	Ljava/util/Optional;
/*      */     //   0	249	0	this	Lorg/springframework/beans/AbstractNestablePropertyAccessor;
/*      */     //   0	249	1	nestedProperty	Ljava/lang/String;
/*      */     //   5	244	2	nestedAccessors	Ljava/util/Map;
/*      */     //   28	221	3	tokens	Lorg/springframework/beans/AbstractNestablePropertyAccessor$PropertyTokenHolder;
/*      */     //   34	215	4	canonicalName	Ljava/lang/String;
/*      */     //   41	208	5	value	Ljava/lang/Object;
/*      */     //   122	127	6	nestedPa	Lorg/springframework/beans/AbstractNestablePropertyAccessor;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   61	8	6	optional	Ljava/util/Optional<*>;
/*      */     //   5	244	2	nestedAccessors	Ljava/util/Map<Ljava/lang/String;Lorg/springframework/beans/AbstractNestablePropertyAccessor;>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object setDefaultValue(PropertyTokenHolder tokens) {
/*  886 */     PropertyValue pv = createDefaultPropertyValue(tokens);
/*  887 */     setPropertyValue(tokens, pv);
/*  888 */     Object defaultValue = getPropertyValue(tokens);
/*  889 */     Assert.state((defaultValue != null), "Default value must not be null");
/*  890 */     return defaultValue;
/*      */   }
/*      */   
/*      */   private PropertyValue createDefaultPropertyValue(PropertyTokenHolder tokens) {
/*  894 */     TypeDescriptor desc = getPropertyTypeDescriptor(tokens.canonicalName);
/*  895 */     if (desc == null) {
/*  896 */       throw new NullValueInNestedPathException(getRootClass(), this.nestedPath + this.nestedPath, "Could not determine property type for auto-growing a default value");
/*      */     }
/*      */     
/*  899 */     Object defaultValue = newValue(desc.getType(), desc, tokens.canonicalName);
/*  900 */     return new PropertyValue(tokens.canonicalName, defaultValue);
/*      */   }
/*      */   
/*      */   private Object newValue(Class<?> type, @Nullable TypeDescriptor desc, String name) {
/*      */     try {
/*  905 */       if (type.isArray()) {
/*  906 */         return createArray(type);
/*      */       }
/*  908 */       if (Collection.class.isAssignableFrom(type)) {
/*  909 */         TypeDescriptor elementDesc = (desc != null) ? desc.getElementTypeDescriptor() : null;
/*  910 */         return CollectionFactory.createCollection(type, (elementDesc != null) ? elementDesc.getType() : null, 16);
/*      */       } 
/*  912 */       if (Map.class.isAssignableFrom(type)) {
/*  913 */         TypeDescriptor keyDesc = (desc != null) ? desc.getMapKeyTypeDescriptor() : null;
/*  914 */         return CollectionFactory.createMap(type, (keyDesc != null) ? keyDesc.getType() : null, 16);
/*      */       } 
/*      */       
/*  917 */       Constructor<?> ctor = type.getDeclaredConstructor(new Class[0]);
/*  918 */       if (Modifier.isPrivate(ctor.getModifiers())) {
/*  919 */         throw new IllegalAccessException("Auto-growing not allowed with private constructor: " + String.valueOf(ctor));
/*      */       }
/*  921 */       return BeanUtils.instantiateClass(ctor, new Object[0]);
/*      */     
/*      */     }
/*  924 */     catch (Throwable ex) {
/*  925 */       throw new NullValueInNestedPathException(getRootClass(), this.nestedPath + this.nestedPath, "Could not instantiate property type [" + type
/*  926 */           .getName() + "] to auto-grow nested property path", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object createArray(Class<?> arrayType) {
/*  936 */     Assert.notNull(arrayType, "Array type must not be null");
/*  937 */     Class<?> componentType = arrayType.componentType();
/*  938 */     if (componentType.isArray()) {
/*  939 */       Object array = Array.newInstance(componentType, 1);
/*  940 */       Array.set(array, 0, createArray(componentType));
/*  941 */       return array;
/*      */     } 
/*      */     
/*  944 */     return Array.newInstance(componentType, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PropertyTokenHolder getPropertyNameTokens(String propertyName) {
/*  954 */     String actualName = null;
/*  955 */     List<String> keys = new ArrayList<>(2);
/*  956 */     int searchIndex = 0;
/*  957 */     while (searchIndex != -1) {
/*  958 */       int keyStart = propertyName.indexOf("[", searchIndex);
/*  959 */       searchIndex = -1;
/*  960 */       if (keyStart != -1) {
/*  961 */         int keyEnd = getPropertyNameKeyEnd(propertyName, keyStart + "[".length());
/*  962 */         if (keyEnd != -1) {
/*  963 */           if (actualName == null) {
/*  964 */             actualName = propertyName.substring(0, keyStart);
/*      */           }
/*  966 */           String key = propertyName.substring(keyStart + "[".length(), keyEnd);
/*  967 */           if ((key.length() > 1 && key.startsWith("'") && key.endsWith("'")) || (key
/*  968 */             .startsWith("\"") && key.endsWith("\""))) {
/*  969 */             key = key.substring(1, key.length() - 1);
/*      */           }
/*  971 */           keys.add(key);
/*  972 */           searchIndex = keyEnd + "]".length();
/*      */         } 
/*      */       } 
/*      */     } 
/*  976 */     PropertyTokenHolder tokens = new PropertyTokenHolder((actualName != null) ? actualName : propertyName);
/*  977 */     if (!keys.isEmpty()) {
/*  978 */       tokens
/*  979 */         .canonicalName = tokens.canonicalName + "[" + tokens.canonicalName + "]";
/*      */       
/*  981 */       tokens.keys = StringUtils.toStringArray(keys);
/*      */     } 
/*  983 */     return tokens;
/*      */   }
/*      */   
/*      */   private int getPropertyNameKeyEnd(String propertyName, int startIndex) {
/*  987 */     int unclosedPrefixes = 0;
/*  988 */     int length = propertyName.length();
/*  989 */     for (int i = startIndex; i < length; i++) {
/*  990 */       switch (propertyName.charAt(i)) {
/*      */         
/*      */         case '[':
/*  993 */           unclosedPrefixes++;
/*      */           break;
/*      */         case ']':
/*  996 */           if (unclosedPrefixes == 0)
/*      */           {
/*      */             
/*  999 */             return i;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1004 */           unclosedPrefixes--;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 1009 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1014 */     String className = getClass().getName();
/* 1015 */     if (this.wrappedObject == null) {
/* 1016 */       return className + ": no wrapped object set";
/*      */     }
/* 1018 */     return className + ": wrapping object [" + className + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class PropertyHandler
/*      */   {
/*      */     @Nullable
/*      */     private final Class<?> propertyType;
/*      */ 
/*      */     
/*      */     private final boolean readable;
/*      */     
/*      */     private final boolean writable;
/*      */ 
/*      */     
/*      */     public PropertyHandler(@Nullable Class<?> propertyType, boolean readable, boolean writable) {
/* 1035 */       this.propertyType = propertyType;
/* 1036 */       this.readable = readable;
/* 1037 */       this.writable = writable;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Class<?> getPropertyType() {
/* 1042 */       return this.propertyType;
/*      */     }
/*      */     
/*      */     public boolean isReadable() {
/* 1046 */       return this.readable;
/*      */     }
/*      */     
/*      */     public boolean isWritable() {
/* 1050 */       return this.writable;
/*      */     }
/*      */     
/*      */     public abstract TypeDescriptor toTypeDescriptor();
/*      */     
/*      */     public abstract ResolvableType getResolvableType();
/*      */     
/*      */     public TypeDescriptor getMapKeyType(int nestingLevel) {
/* 1058 */       return TypeDescriptor.valueOf(getResolvableType().getNested(nestingLevel).asMap().resolveGeneric(new int[] { 0 }));
/*      */     }
/*      */     
/*      */     public TypeDescriptor getMapValueType(int nestingLevel) {
/* 1062 */       return TypeDescriptor.valueOf(getResolvableType().getNested(nestingLevel).asMap().resolveGeneric(new int[] { 1 }));
/*      */     }
/*      */     
/*      */     public TypeDescriptor getCollectionType(int nestingLevel) {
/* 1066 */       return TypeDescriptor.valueOf(getResolvableType().getNested(nestingLevel).asCollection().resolveGeneric(new int[0]));
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public abstract TypeDescriptor nested(int param1Int);
/*      */     
/*      */     @Nullable
/*      */     public abstract Object getValue() throws Exception;
/*      */     
/*      */     public abstract void setValue(@Nullable Object param1Object) throws Exception;
/*      */     
/*      */     public boolean setValueFallbackIfPossible(@Nullable Object value) {
/* 1078 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class PropertyTokenHolder {
/*      */     public String actualName;
/*      */     public String canonicalName;
/*      */     @Nullable
/*      */     public String[] keys;
/*      */     
/*      */     public PropertyTokenHolder(String name) {
/* 1089 */       this.actualName = name;
/* 1090 */       this.canonicalName = name;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\AbstractNestablePropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */