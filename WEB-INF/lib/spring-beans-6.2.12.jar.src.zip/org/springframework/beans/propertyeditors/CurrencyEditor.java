/*    */ package org.springframework.beans.propertyeditors;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Currency;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurrencyEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text) throws IllegalArgumentException {
/* 37 */     if (StringUtils.hasText(text)) {
/* 38 */       text = text.trim();
/*    */     }
/* 40 */     setValue(Currency.getInstance(text));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAsText() {
/* 45 */     Currency value = (Currency)getValue();
/* 46 */     return (value != null) ? value.getCurrencyCode() : "";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\propertyeditors\CurrencyEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */