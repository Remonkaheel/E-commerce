/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.file.FileSystemNotFoundException;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathEditor
/*     */   extends PropertyEditorSupport
/*     */ {
/*     */   private final ResourceEditor resourceEditor;
/*     */   
/*     */   public PathEditor() {
/*  62 */     this.resourceEditor = new ResourceEditor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathEditor(ResourceEditor resourceEditor) {
/*  70 */     Assert.notNull(resourceEditor, "ResourceEditor must not be null");
/*  71 */     this.resourceEditor = resourceEditor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsText(String text) throws IllegalArgumentException {
/*  77 */     boolean nioPathCandidate = !text.startsWith("classpath:");
/*  78 */     if (nioPathCandidate && !text.startsWith("/")) {
/*     */       try {
/*  80 */         URI uri = ResourceUtils.toURI(text);
/*  81 */         String scheme = uri.getScheme();
/*  82 */         if (scheme != null) {
/*     */           
/*  84 */           nioPathCandidate = (scheme.length() == 1);
/*     */           
/*  86 */           setValue(Paths.get(uri).normalize());
/*     */           
/*     */           return;
/*     */         } 
/*  90 */       } catch (URISyntaxException ex) {
/*     */ 
/*     */         
/*  93 */         nioPathCandidate = !text.startsWith("file:");
/*     */       }
/*  95 */       catch (FileSystemNotFoundException|IllegalArgumentException fileSystemNotFoundException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.resourceEditor.setAsText(text);
/* 102 */     Resource resource = (Resource)this.resourceEditor.getValue();
/* 103 */     if (resource == null) {
/* 104 */       setValue(null);
/*     */     }
/* 106 */     else if (nioPathCandidate && (!resource.isFile() || !resource.exists())) {
/* 107 */       setValue(Paths.get(text, new String[0]).normalize());
/*     */     } else {
/*     */       
/*     */       try {
/* 111 */         setValue(resource.getFile().toPath());
/*     */       }
/* 113 */       catch (IOException ex) {
/*     */         
/* 115 */         String msg = "Could not resolve \"" + text + "\" to 'java.nio.file.Path' for " + String.valueOf(resource) + ": " + ex.getMessage();
/* 116 */         if (nioPathCandidate) {
/* 117 */           msg = msg + " - In case of ambiguity, consider adding the 'file:' prefix for an explicit reference to a file system resource of the same name: \"file:" + msg + "\"";
/*     */         }
/*     */         
/* 120 */         throw new IllegalArgumentException(msg);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAsText() {
/* 127 */     Path value = (Path)getValue();
/* 128 */     return (value != null) ? value.toString() : "";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\propertyeditors\PathEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */