/*    */ package org.springframework.beans.propertyeditors;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.ZoneId;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZoneIdEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text) throws IllegalArgumentException {
/* 40 */     if (StringUtils.hasText(text)) {
/* 41 */       text = text.trim();
/*    */     }
/*    */     try {
/* 44 */       setValue(ZoneId.of(text));
/*    */     }
/* 46 */     catch (DateTimeException ex) {
/* 47 */       throw new IllegalArgumentException(ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAsText() {
/* 53 */     ZoneId value = (ZoneId)getValue();
/* 54 */     return (value != null) ? value.getId() : "";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\propertyeditors\ZoneIdEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */