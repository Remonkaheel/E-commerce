/*    */ package org.springframework.beans.propertyeditors;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.TimeZone;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeZoneEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text) throws IllegalArgumentException {
/* 40 */     if (StringUtils.hasText(text)) {
/* 41 */       text = text.trim();
/*    */     }
/* 43 */     setValue(StringUtils.parseTimeZoneString(text));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAsText() {
/* 48 */     TimeZone value = (TimeZone)getValue();
/* 49 */     return (value != null) ? value.getID() : "";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\propertyeditors\TimeZoneEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */