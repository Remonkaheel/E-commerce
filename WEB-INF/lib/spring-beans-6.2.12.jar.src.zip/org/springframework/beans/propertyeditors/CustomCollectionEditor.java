/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomCollectionEditor
/*     */   extends PropertyEditorSupport
/*     */ {
/*     */   private final Class<? extends Collection> collectionType;
/*     */   private final boolean nullAsEmptyCollection;
/*     */   
/*     */   public CustomCollectionEditor(Class<? extends Collection> collectionType) {
/*  67 */     this(collectionType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CustomCollectionEditor(Class<? extends Collection> collectionType, boolean nullAsEmptyCollection) {
/*  90 */     Assert.notNull(collectionType, "Collection type is required");
/*  91 */     if (!Collection.class.isAssignableFrom(collectionType)) {
/*  92 */       throw new IllegalArgumentException("Collection type [" + collectionType
/*  93 */           .getName() + "] does not implement [java.util.Collection]");
/*     */     }
/*  95 */     this.collectionType = collectionType;
/*  96 */     this.nullAsEmptyCollection = nullAsEmptyCollection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsText(String text) throws IllegalArgumentException {
/* 105 */     setValue(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable Object value) {
/* 113 */     if (value == null && this.nullAsEmptyCollection)
/* 114 */     { super.setValue(createCollection(this.collectionType, 0)); }
/*     */     
/* 116 */     else if (value == null || (this.collectionType.isInstance(value) && !alwaysCreateNewCollection()))
/*     */     
/* 118 */     { super.setValue(value); }
/*     */     
/* 120 */     else if (value instanceof Collection) { Collection<?> source = (Collection)value;
/*     */       
/* 122 */       Collection<Object> target = createCollection(this.collectionType, source.size());
/* 123 */       for (Object elem : source) {
/* 124 */         target.add(convertElement(elem));
/*     */       }
/* 126 */       super.setValue(target); }
/*     */     
/* 128 */     else if (value.getClass().isArray())
/*     */     
/* 130 */     { int length = Array.getLength(value);
/* 131 */       Collection<Object> target = createCollection(this.collectionType, length);
/* 132 */       for (int i = 0; i < length; i++) {
/* 133 */         target.add(convertElement(Array.get(value, i)));
/*     */       }
/* 135 */       super.setValue(target); }
/*     */     
/*     */     else
/*     */     
/* 139 */     { Collection<Object> target = createCollection(this.collectionType, 1);
/* 140 */       target.add(convertElement(value));
/* 141 */       super.setValue(target); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> createCollection(Class<? extends Collection> collectionType, int initialCapacity) {
/* 154 */     if (!collectionType.isInterface()) {
/*     */       try {
/* 156 */         return ReflectionUtils.accessibleConstructor(collectionType, new Class[0]).newInstance(new Object[0]);
/*     */       }
/* 158 */       catch (Throwable ex) {
/* 159 */         throw new IllegalArgumentException("Could not instantiate collection class: " + collectionType
/* 160 */             .getName(), ex);
/*     */       } 
/*     */     }
/* 163 */     if (List.class == collectionType) {
/* 164 */       return new ArrayList(initialCapacity);
/*     */     }
/* 166 */     if (SortedSet.class == collectionType) {
/* 167 */       return new TreeSet();
/*     */     }
/*     */     
/* 170 */     return new LinkedHashSet(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean alwaysCreateNewCollection() {
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object convertElement(Object element) {
/* 200 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getAsText() {
/* 211 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\propertyeditors\CustomCollectionEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */