/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInvocationException
/*    */   extends PropertyAccessException
/*    */ {
/*    */   public static final String ERROR_CODE = "methodInvocation";
/*    */   
/*    */   public MethodInvocationException(PropertyChangeEvent propertyChangeEvent, @Nullable Throwable cause) {
/* 45 */     super(propertyChangeEvent, "Property '" + propertyChangeEvent
/* 46 */         .getPropertyName() + "' threw exception: " + String.valueOf(cause), cause);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getErrorCode() {
/* 52 */     return "methodInvocation";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\MethodInvocationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */