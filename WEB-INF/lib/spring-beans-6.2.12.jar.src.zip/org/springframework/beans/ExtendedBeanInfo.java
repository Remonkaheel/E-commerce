/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.EventSetDescriptor;
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.MethodDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExtendedBeanInfo
/*     */   implements BeanInfo
/*     */ {
/*  83 */   private static final Log logger = LogFactory.getLog(ExtendedBeanInfo.class);
/*     */   
/*     */   private final BeanInfo delegate;
/*     */   
/*  87 */   private final Set<PropertyDescriptor> propertyDescriptors = new TreeSet<>(new PropertyDescriptorComparator());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedBeanInfo(BeanInfo delegate) {
/* 101 */     this.delegate = delegate;
/* 102 */     for (PropertyDescriptor pd : delegate.getPropertyDescriptors()) {
/*     */       try {
/* 104 */         IndexedPropertyDescriptor indexedPd = (IndexedPropertyDescriptor)pd; this.propertyDescriptors.add((pd instanceof IndexedPropertyDescriptor) ? 
/* 105 */             new SimpleIndexedPropertyDescriptor(indexedPd) : 
/* 106 */             new SimplePropertyDescriptor(pd));
/*     */       }
/* 108 */       catch (IntrospectionException ex) {
/*     */         
/* 110 */         if (logger.isDebugEnabled()) {
/* 111 */           logger.debug("Ignoring invalid bean property '" + pd.getName() + "': " + ex.getMessage());
/*     */         }
/*     */       } 
/*     */     } 
/* 115 */     MethodDescriptor[] methodDescriptors = delegate.getMethodDescriptors();
/* 116 */     if (methodDescriptors != null) {
/* 117 */       for (Method method : findCandidateWriteMethods(methodDescriptors)) {
/*     */         try {
/* 119 */           handleCandidateWriteMethod(method);
/*     */         }
/* 121 */         catch (IntrospectionException ex) {
/*     */           
/* 123 */           if (logger.isDebugEnabled()) {
/* 124 */             logger.debug("Ignoring candidate write method [" + String.valueOf(method) + "]: " + ex.getMessage());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Method> findCandidateWriteMethods(MethodDescriptor[] methodDescriptors) {
/* 133 */     List<Method> matches = new ArrayList<>();
/* 134 */     for (MethodDescriptor methodDescriptor : methodDescriptors) {
/* 135 */       Method method = methodDescriptor.getMethod();
/* 136 */       if (isCandidateWriteMethod(method)) {
/* 137 */         matches.add(method);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     matches.sort(Comparator.<Method, Comparable>comparing(Method::toString).reversed());
/* 145 */     return matches;
/*     */   }
/*     */   
/*     */   public static boolean isCandidateWriteMethod(Method method) {
/* 149 */     String methodName = method.getName();
/* 150 */     int nParams = method.getParameterCount();
/* 151 */     return (methodName.length() > 3 && methodName.startsWith("set") && Modifier.isPublic(method.getModifiers()) && (
/* 152 */       !void.class.isAssignableFrom(method.getReturnType()) || Modifier.isStatic(method.getModifiers())) && (nParams == 1 || (nParams == 2 && int.class == method
/* 153 */       .getParameterTypes()[0])));
/*     */   }
/*     */   
/*     */   private void handleCandidateWriteMethod(Method method) throws IntrospectionException {
/* 157 */     int nParams = method.getParameterCount();
/* 158 */     String propertyName = propertyNameFor(method);
/* 159 */     Class<?> propertyType = method.getParameterTypes()[nParams - 1];
/* 160 */     PropertyDescriptor existingPd = findExistingPropertyDescriptor(propertyName, propertyType);
/* 161 */     if (nParams == 1) {
/* 162 */       if (existingPd == null) {
/* 163 */         this.propertyDescriptors.add(new SimplePropertyDescriptor(propertyName, null, method));
/*     */       } else {
/*     */         
/* 166 */         existingPd.setWriteMethod(method);
/*     */       }
/*     */     
/* 169 */     } else if (nParams == 2) {
/* 170 */       if (existingPd == null)
/* 171 */       { this.propertyDescriptors.add(new SimpleIndexedPropertyDescriptor(propertyName, null, null, null, method));
/*     */          }
/*     */       
/* 174 */       else if (existingPd instanceof IndexedPropertyDescriptor) { IndexedPropertyDescriptor indexedPd = (IndexedPropertyDescriptor)existingPd;
/* 175 */         indexedPd.setIndexedWriteMethod(method); }
/*     */       else
/*     */       
/* 178 */       { this.propertyDescriptors.remove(existingPd);
/* 179 */         this.propertyDescriptors.add(new SimpleIndexedPropertyDescriptor(propertyName, existingPd
/* 180 */               .getReadMethod(), existingPd.getWriteMethod(), null, method)); }
/*     */     
/*     */     } else {
/*     */       
/* 184 */       throw new IllegalArgumentException("Write method must have exactly 1 or 2 parameters: " + String.valueOf(method));
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private PropertyDescriptor findExistingPropertyDescriptor(String propertyName, Class<?> propertyType) {
/* 190 */     for (PropertyDescriptor pd : this.propertyDescriptors) {
/*     */       
/* 192 */       String candidateName = pd.getName();
/* 193 */       if (pd instanceof IndexedPropertyDescriptor) { IndexedPropertyDescriptor indexedPd = (IndexedPropertyDescriptor)pd;
/* 194 */         Class<?> clazz = indexedPd.getIndexedPropertyType();
/* 195 */         if (candidateName.equals(propertyName) && (clazz
/* 196 */           .equals(propertyType) || clazz.equals(propertyType.componentType()))) {
/* 197 */           return pd;
/*     */         }
/*     */         continue; }
/*     */       
/* 201 */       Class<?> candidateType = pd.getPropertyType();
/* 202 */       if (candidateName.equals(propertyName) && (candidateType
/* 203 */         .equals(propertyType) || propertyType.equals(candidateType.componentType()))) {
/* 204 */         return pd;
/*     */       }
/*     */     } 
/*     */     
/* 208 */     return null;
/*     */   }
/*     */   
/*     */   private String propertyNameFor(Method method) {
/* 212 */     return Introspector.decapitalize(method.getName().substring(3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors() {
/* 224 */     return this.propertyDescriptors.<PropertyDescriptor>toArray(new PropertyDescriptor[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanInfo[] getAdditionalBeanInfo() {
/* 229 */     return this.delegate.getAdditionalBeanInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDescriptor getBeanDescriptor() {
/* 234 */     return this.delegate.getBeanDescriptor();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDefaultEventIndex() {
/* 239 */     return this.delegate.getDefaultEventIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDefaultPropertyIndex() {
/* 244 */     return this.delegate.getDefaultPropertyIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   public EventSetDescriptor[] getEventSetDescriptors() {
/* 249 */     return this.delegate.getEventSetDescriptors();
/*     */   }
/*     */ 
/*     */   
/*     */   public Image getIcon(int iconKind) {
/* 254 */     return this.delegate.getIcon(iconKind);
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodDescriptor[] getMethodDescriptors() {
/* 259 */     return this.delegate.getMethodDescriptors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class SimplePropertyDescriptor
/*     */     extends PropertyDescriptor
/*     */   {
/*     */     @Nullable
/*     */     private Method readMethod;
/*     */     
/*     */     @Nullable
/*     */     private Method writeMethod;
/*     */     
/*     */     @Nullable
/*     */     private Class<?> propertyType;
/*     */     
/*     */     @Nullable
/*     */     private Class<?> propertyEditorClass;
/*     */ 
/*     */     
/*     */     public SimplePropertyDescriptor(PropertyDescriptor original) throws IntrospectionException {
/* 281 */       this(original.getName(), original.getReadMethod(), original.getWriteMethod());
/* 282 */       PropertyDescriptorUtils.copyNonMethodProperties(original, this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SimplePropertyDescriptor(String propertyName, @Nullable Method readMethod, Method writeMethod) throws IntrospectionException {
/* 288 */       super(propertyName, null, null);
/* 289 */       this.readMethod = readMethod;
/* 290 */       this.writeMethod = writeMethod;
/* 291 */       this.propertyType = PropertyDescriptorUtils.findPropertyType(readMethod, writeMethod);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getReadMethod() {
/* 297 */       return this.readMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setReadMethod(@Nullable Method readMethod) {
/* 302 */       this.readMethod = readMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getWriteMethod() {
/* 308 */       return this.writeMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setWriteMethod(@Nullable Method writeMethod) {
/* 313 */       this.writeMethod = writeMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?> getPropertyType() {
/* 319 */       if (this.propertyType == null) {
/*     */         try {
/* 321 */           this.propertyType = PropertyDescriptorUtils.findPropertyType(this.readMethod, this.writeMethod);
/*     */         }
/* 323 */         catch (IntrospectionException introspectionException) {}
/*     */       }
/*     */ 
/*     */       
/* 327 */       return this.propertyType;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?> getPropertyEditorClass() {
/* 333 */       return this.propertyEditorClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setPropertyEditorClass(@Nullable Class<?> propertyEditorClass) {
/* 338 */       this.propertyEditorClass = propertyEditorClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 343 */       if (this != other) { if (other instanceof PropertyDescriptor) { PropertyDescriptor that = (PropertyDescriptor)other;
/* 344 */           if (PropertyDescriptorUtils.equals(this, that)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 349 */       return Objects.hash(new Object[] { getReadMethod(), getWriteMethod() });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 354 */       return String.format("%s[name=%s, propertyType=%s, readMethod=%s, writeMethod=%s]", new Object[] {
/* 355 */             getClass().getSimpleName(), getName(), getPropertyType(), this.readMethod, this.writeMethod
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class SimpleIndexedPropertyDescriptor
/*     */     extends IndexedPropertyDescriptor
/*     */   {
/*     */     @Nullable
/*     */     private Method readMethod;
/*     */     
/*     */     @Nullable
/*     */     private Method writeMethod;
/*     */     
/*     */     @Nullable
/*     */     private Class<?> propertyType;
/*     */     
/*     */     @Nullable
/*     */     private Method indexedReadMethod;
/*     */     
/*     */     @Nullable
/*     */     private Method indexedWriteMethod;
/*     */     
/*     */     @Nullable
/*     */     private Class<?> indexedPropertyType;
/*     */     
/*     */     @Nullable
/*     */     private Class<?> propertyEditorClass;
/*     */ 
/*     */     
/*     */     public SimpleIndexedPropertyDescriptor(IndexedPropertyDescriptor original) throws IntrospectionException {
/* 387 */       this(original.getName(), original.getReadMethod(), original.getWriteMethod(), original
/* 388 */           .getIndexedReadMethod(), original.getIndexedWriteMethod());
/* 389 */       PropertyDescriptorUtils.copyNonMethodProperties(original, this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SimpleIndexedPropertyDescriptor(String propertyName, @Nullable Method readMethod, @Nullable Method writeMethod, @Nullable Method indexedReadMethod, Method indexedWriteMethod) throws IntrospectionException {
/* 396 */       super(propertyName, (Method)null, (Method)null, (Method)null, (Method)null);
/* 397 */       this.readMethod = readMethod;
/* 398 */       this.writeMethod = writeMethod;
/* 399 */       this.propertyType = PropertyDescriptorUtils.findPropertyType(readMethod, writeMethod);
/* 400 */       this.indexedReadMethod = indexedReadMethod;
/* 401 */       this.indexedWriteMethod = indexedWriteMethod;
/* 402 */       this.indexedPropertyType = PropertyDescriptorUtils.findIndexedPropertyType(propertyName, this.propertyType, indexedReadMethod, indexedWriteMethod);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getReadMethod() {
/* 409 */       return this.readMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setReadMethod(@Nullable Method readMethod) {
/* 414 */       this.readMethod = readMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getWriteMethod() {
/* 420 */       return this.writeMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setWriteMethod(@Nullable Method writeMethod) {
/* 425 */       this.writeMethod = writeMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?> getPropertyType() {
/* 431 */       if (this.propertyType == null) {
/*     */         try {
/* 433 */           this.propertyType = PropertyDescriptorUtils.findPropertyType(this.readMethod, this.writeMethod);
/*     */         }
/* 435 */         catch (IntrospectionException introspectionException) {}
/*     */       }
/*     */ 
/*     */       
/* 439 */       return this.propertyType;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getIndexedReadMethod() {
/* 445 */       return this.indexedReadMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setIndexedReadMethod(@Nullable Method indexedReadMethod) throws IntrospectionException {
/* 450 */       this.indexedReadMethod = indexedReadMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getIndexedWriteMethod() {
/* 456 */       return this.indexedWriteMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setIndexedWriteMethod(@Nullable Method indexedWriteMethod) throws IntrospectionException {
/* 461 */       this.indexedWriteMethod = indexedWriteMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?> getIndexedPropertyType() {
/* 467 */       if (this.indexedPropertyType == null) {
/*     */         try {
/* 469 */           this.indexedPropertyType = PropertyDescriptorUtils.findIndexedPropertyType(
/* 470 */               getName(), getPropertyType(), this.indexedReadMethod, this.indexedWriteMethod);
/*     */         }
/* 472 */         catch (IntrospectionException introspectionException) {}
/*     */       }
/*     */ 
/*     */       
/* 476 */       return this.indexedPropertyType;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?> getPropertyEditorClass() {
/* 482 */       return this.propertyEditorClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setPropertyEditorClass(@Nullable Class<?> propertyEditorClass) {
/* 487 */       this.propertyEditorClass = propertyEditorClass;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 495 */       if (this != other) { if (other instanceof IndexedPropertyDescriptor) { IndexedPropertyDescriptor that = (IndexedPropertyDescriptor)other;
/* 496 */           if (ObjectUtils.nullSafeEquals(getIndexedReadMethod(), that.getIndexedReadMethod()) && 
/* 497 */             ObjectUtils.nullSafeEquals(getIndexedWriteMethod(), that.getIndexedWriteMethod()) && 
/* 498 */             ObjectUtils.nullSafeEquals(getIndexedPropertyType(), that.getIndexedPropertyType()) && 
/* 499 */             PropertyDescriptorUtils.equals(this, that)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 504 */       return Objects.hash(new Object[] { getReadMethod(), getWriteMethod(), 
/* 505 */             getIndexedReadMethod(), getIndexedWriteMethod() });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 510 */       return String.format("%s[name=%s, propertyType=%s, indexedPropertyType=%s, readMethod=%s, writeMethod=%s, indexedReadMethod=%s, indexedWriteMethod=%s]", new Object[] {
/*     */             
/* 512 */             getClass().getSimpleName(), getName(), getPropertyType(), getIndexedPropertyType(), this.readMethod, this.writeMethod, this.indexedReadMethod, this.indexedWriteMethod
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class PropertyDescriptorComparator
/*     */     implements Comparator<PropertyDescriptor>
/*     */   {
/*     */     public int compare(PropertyDescriptor desc1, PropertyDescriptor desc2) {
/* 527 */       return desc1.getName().compareTo(desc2.getName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\ExtendedBeanInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */