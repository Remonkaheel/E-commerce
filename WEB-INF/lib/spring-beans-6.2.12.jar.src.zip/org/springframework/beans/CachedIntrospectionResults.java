/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.URL;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CachedIntrospectionResults
/*     */ {
/*  78 */   private static final List<BeanInfoFactory> beanInfoFactories = SpringFactoriesLoader.loadFactories(BeanInfoFactory.class, CachedIntrospectionResults.class
/*  79 */       .getClassLoader());
/*     */   
/*  81 */   private static final SimpleBeanInfoFactory simpleBeanInfoFactory = new SimpleBeanInfoFactory();
/*     */   
/*  83 */   private static final Log logger = LogFactory.getLog(CachedIntrospectionResults.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   static final Set<ClassLoader> acceptedClassLoaders = ConcurrentHashMap.newKeySet(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   static final ConcurrentMap<Class<?>, CachedIntrospectionResults> strongClassCache = new ConcurrentHashMap<>(64);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   static final ConcurrentMap<Class<?>, CachedIntrospectionResults> softClassCache = (ConcurrentMap<Class<?>, CachedIntrospectionResults>)new ConcurrentReferenceHashMap(64);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BeanInfo beanInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, PropertyDescriptor> propertyDescriptors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void acceptClassLoader(@Nullable ClassLoader classLoader) {
/* 119 */     if (classLoader != null) {
/* 120 */       acceptedClassLoaders.add(classLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearClassLoader(@Nullable ClassLoader classLoader) {
/* 131 */     acceptedClassLoaders.removeIf(registeredLoader -> isUnderneathClassLoader(registeredLoader, classLoader));
/*     */     
/* 133 */     strongClassCache.keySet().removeIf(beanClass -> isUnderneathClassLoader(beanClass.getClassLoader(), classLoader));
/*     */     
/* 135 */     softClassCache.keySet().removeIf(beanClass -> isUnderneathClassLoader(beanClass.getClassLoader(), classLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static CachedIntrospectionResults forClass(Class<?> beanClass) throws BeansException {
/*     */     ConcurrentMap<Class<?>, CachedIntrospectionResults> classCacheToUse;
/* 146 */     CachedIntrospectionResults results = strongClassCache.get(beanClass);
/* 147 */     if (results != null) {
/* 148 */       return results;
/*     */     }
/* 150 */     results = softClassCache.get(beanClass);
/* 151 */     if (results != null) {
/* 152 */       return results;
/*     */     }
/*     */     
/* 155 */     results = new CachedIntrospectionResults(beanClass);
/*     */ 
/*     */     
/* 158 */     if (ClassUtils.isCacheSafe(beanClass, CachedIntrospectionResults.class.getClassLoader()) || 
/* 159 */       isClassLoaderAccepted(beanClass.getClassLoader())) {
/* 160 */       classCacheToUse = strongClassCache;
/*     */     } else {
/*     */       
/* 163 */       if (logger.isDebugEnabled()) {
/* 164 */         logger.debug("Not strongly caching class [" + beanClass.getName() + "] because it is not cache-safe");
/*     */       }
/* 166 */       classCacheToUse = softClassCache;
/*     */     } 
/*     */     
/* 169 */     CachedIntrospectionResults existing = classCacheToUse.putIfAbsent(beanClass, results);
/* 170 */     return (existing != null) ? existing : results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isClassLoaderAccepted(ClassLoader classLoader) {
/* 181 */     for (ClassLoader acceptedLoader : acceptedClassLoaders) {
/* 182 */       if (isUnderneathClassLoader(classLoader, acceptedLoader)) {
/* 183 */         return true;
/*     */       }
/*     */     } 
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isUnderneathClassLoader(@Nullable ClassLoader candidate, @Nullable ClassLoader parent) {
/* 196 */     if (candidate == parent) {
/* 197 */       return true;
/*     */     }
/* 199 */     if (candidate == null) {
/* 200 */       return false;
/*     */     }
/* 202 */     ClassLoader classLoaderToCheck = candidate;
/* 203 */     while (classLoaderToCheck != null) {
/* 204 */       classLoaderToCheck = classLoaderToCheck.getParent();
/* 205 */       if (classLoaderToCheck == parent) {
/* 206 */         return true;
/*     */       }
/*     */     } 
/* 209 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static BeanInfo getBeanInfo(Class<?> beanClass) throws IntrospectionException {
/* 219 */     for (BeanInfoFactory beanInfoFactory : beanInfoFactories) {
/* 220 */       BeanInfo beanInfo = beanInfoFactory.getBeanInfo(beanClass);
/* 221 */       if (beanInfo != null) {
/* 222 */         return beanInfo;
/*     */       }
/*     */     } 
/* 225 */     return simpleBeanInfoFactory.getBeanInfo(beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CachedIntrospectionResults(Class<?> beanClass) throws BeansException {
/*     */     try {
/* 243 */       if (logger.isTraceEnabled()) {
/* 244 */         logger.trace("Getting BeanInfo for class [" + beanClass.getName() + "]");
/*     */       }
/* 246 */       this.beanInfo = getBeanInfo(beanClass);
/*     */       
/* 248 */       if (logger.isTraceEnabled()) {
/* 249 */         logger.trace("Caching PropertyDescriptors for class [" + beanClass.getName() + "]");
/*     */       }
/* 251 */       this.propertyDescriptors = new LinkedHashMap<>();
/*     */       
/* 253 */       Set<String> readMethodNames = new HashSet<>();
/*     */ 
/*     */       
/* 256 */       PropertyDescriptor[] pds = this.beanInfo.getPropertyDescriptors();
/* 257 */       for (PropertyDescriptor pd : pds) {
/* 258 */         if (Class.class != beanClass || "name".equals(pd.getName()) || (pd
/* 259 */           .getName().endsWith("Name") && String.class == pd.getPropertyType()))
/*     */         {
/*     */ 
/*     */           
/* 263 */           if (URL.class != beanClass || !"content".equals(pd.getName()))
/*     */           {
/*     */ 
/*     */             
/* 267 */             if (pd.getWriteMethod() != null || !isInvalidReadOnlyPropertyType(pd.getPropertyType(), beanClass)) {
/*     */ 
/*     */ 
/*     */               
/* 271 */               if (logger.isTraceEnabled()) {
/* 272 */                 logger.trace("Found bean property '" + pd.getName() + "'" + (
/* 273 */                     (pd.getPropertyType() != null) ? (" of type [" + pd.getPropertyType().getName() + "]") : "") + (
/* 274 */                     (pd.getPropertyEditorClass() != null) ? ("; editor [" + 
/* 275 */                     pd.getPropertyEditorClass().getName() + "]") : ""));
/*     */               }
/* 277 */               pd = buildGenericTypeAwarePropertyDescriptor(beanClass, pd);
/* 278 */               this.propertyDescriptors.put(pd.getName(), pd);
/* 279 */               Method readMethod = pd.getReadMethod();
/* 280 */               if (readMethod != null) {
/* 281 */                 readMethodNames.add(readMethod.getName());
/*     */               }
/*     */             } 
/*     */           }
/*     */         }
/*     */       } 
/* 287 */       Class<?> currClass = beanClass;
/* 288 */       while (currClass != null && currClass != Object.class) {
/* 289 */         introspectInterfaces(beanClass, currClass, readMethodNames);
/* 290 */         currClass = currClass.getSuperclass();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 296 */       introspectPlainAccessors(beanClass, readMethodNames);
/*     */     }
/* 298 */     catch (IntrospectionException ex) {
/* 299 */       throw new FatalBeanException("Failed to obtain BeanInfo for class [" + beanClass.getName() + "]", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void introspectInterfaces(Class<?> beanClass, Class<?> currClass, Set<String> readMethodNames) throws IntrospectionException {
/* 306 */     for (Class<?> ifc : currClass.getInterfaces()) {
/* 307 */       if (!ClassUtils.isJavaLanguageInterface(ifc)) {
/* 308 */         for (PropertyDescriptor pd : getBeanInfo(ifc).getPropertyDescriptors()) {
/* 309 */           PropertyDescriptor existingPd = this.propertyDescriptors.get(pd.getName());
/* 310 */           if (existingPd == null || (existingPd
/* 311 */             .getReadMethod() == null && pd.getReadMethod() != null)) {
/*     */ 
/*     */             
/* 314 */             pd = buildGenericTypeAwarePropertyDescriptor(beanClass, pd);
/* 315 */             if (pd.getWriteMethod() != null || 
/* 316 */               !isInvalidReadOnlyPropertyType(pd.getPropertyType(), beanClass)) {
/*     */ 
/*     */ 
/*     */               
/* 320 */               this.propertyDescriptors.put(pd.getName(), pd);
/* 321 */               Method readMethod = pd.getReadMethod();
/* 322 */               if (readMethod != null)
/* 323 */                 readMethodNames.add(readMethod.getName()); 
/*     */             } 
/*     */           } 
/*     */         } 
/* 327 */         introspectInterfaces(ifc, ifc, readMethodNames);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void introspectPlainAccessors(Class<?> beanClass, Set<String> readMethodNames) throws IntrospectionException {
/* 335 */     for (Method method : beanClass.getMethods()) {
/* 336 */       if (!this.propertyDescriptors.containsKey(method.getName()) && 
/* 337 */         !readMethodNames.contains(method.getName()) && isPlainAccessor(method)) {
/* 338 */         this.propertyDescriptors.put(method.getName(), new GenericTypeAwarePropertyDescriptor(beanClass, method
/* 339 */               .getName(), method, null, null));
/* 340 */         readMethodNames.add(method.getName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPlainAccessor(Method method) {
/* 346 */     if (Modifier.isStatic(method.getModifiers()) || method
/* 347 */       .getDeclaringClass() == Object.class || method.getDeclaringClass() == Class.class || method
/* 348 */       .getParameterCount() > 0 || method.getReturnType() == void.class || 
/* 349 */       isInvalidReadOnlyPropertyType(method.getReturnType(), method.getDeclaringClass())) {
/* 350 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 354 */       method.getDeclaringClass().getDeclaredField(method.getName());
/* 355 */       return true;
/*     */     }
/* 357 */     catch (Exception ex) {
/* 358 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isInvalidReadOnlyPropertyType(@Nullable Class<?> returnType, Class<?> beanClass) {
/* 363 */     return (returnType != null && (ClassLoader.class.isAssignableFrom(returnType) || ProtectionDomain.class
/* 364 */       .isAssignableFrom(returnType) || (AutoCloseable.class
/* 365 */       .isAssignableFrom(returnType) && 
/* 366 */       !AutoCloseable.class.isAssignableFrom(beanClass))));
/*     */   }
/*     */ 
/*     */   
/*     */   BeanInfo getBeanInfo() {
/* 371 */     return this.beanInfo;
/*     */   }
/*     */   
/*     */   Class<?> getBeanClass() {
/* 375 */     return this.beanInfo.getBeanDescriptor().getBeanClass();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   PropertyDescriptor getPropertyDescriptor(String name) {
/* 380 */     PropertyDescriptor pd = this.propertyDescriptors.get(name);
/* 381 */     if (pd == null && StringUtils.hasLength(name)) {
/*     */       
/* 383 */       pd = this.propertyDescriptors.get(StringUtils.uncapitalize(name));
/* 384 */       if (pd == null) {
/* 385 */         pd = this.propertyDescriptors.get(StringUtils.capitalize(name));
/*     */       }
/*     */     } 
/* 388 */     return pd;
/*     */   }
/*     */   
/*     */   PropertyDescriptor[] getPropertyDescriptors() {
/* 392 */     return (PropertyDescriptor[])this.propertyDescriptors.values().toArray((Object[])PropertyDescriptorUtils.EMPTY_PROPERTY_DESCRIPTOR_ARRAY);
/*     */   }
/*     */   
/*     */   private PropertyDescriptor buildGenericTypeAwarePropertyDescriptor(Class<?> beanClass, PropertyDescriptor pd) {
/*     */     try {
/* 397 */       return new GenericTypeAwarePropertyDescriptor(beanClass, pd.getName(), pd.getReadMethod(), pd
/* 398 */           .getWriteMethod(), pd.getPropertyEditorClass());
/*     */     }
/* 400 */     catch (IntrospectionException ex) {
/* 401 */       throw new FatalBeanException("Failed to re-introspect class [" + beanClass.getName() + "]", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\CachedIntrospectionResults.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */