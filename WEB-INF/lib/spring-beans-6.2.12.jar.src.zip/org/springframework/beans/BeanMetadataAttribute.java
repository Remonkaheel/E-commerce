/*    */ package org.springframework.beans;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanMetadataAttribute
/*    */   implements BeanMetadataElement
/*    */ {
/*    */   private final String name;
/*    */   @Nullable
/*    */   private final Object value;
/*    */   @Nullable
/*    */   private Object source;
/*    */   
/*    */   public BeanMetadataAttribute(String name, @Nullable Object value) {
/* 48 */     Assert.notNull(name, "Name must not be null");
/* 49 */     this.name = name;
/* 50 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 58 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getValue() {
/* 66 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSource(@Nullable Object source) {
/* 74 */     this.source = source;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getSource() {
/* 80 */     return this.source;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 86 */     if (this != other) { if (other instanceof BeanMetadataAttribute) { BeanMetadataAttribute that = (BeanMetadataAttribute)other; if (this.name
/* 87 */           .equals(that.name) && 
/* 88 */           ObjectUtils.nullSafeEquals(this.value, that.value) && 
/* 89 */           ObjectUtils.nullSafeEquals(this.source, that.source)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 94 */     return ObjectUtils.nullSafeHash(new Object[] { this.name, this.value });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 99 */     return "metadata attribute: name='" + this.name + "'; value=" + String.valueOf(this.value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\BeanMetadataAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */