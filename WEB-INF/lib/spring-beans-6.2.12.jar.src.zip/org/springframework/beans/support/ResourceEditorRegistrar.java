/*     */ package org.springframework.beans.support;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Path;
/*     */ import org.springframework.beans.PropertyEditorRegistrar;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.PropertyEditorRegistrySupport;
/*     */ import org.springframework.beans.propertyeditors.ClassArrayEditor;
/*     */ import org.springframework.beans.propertyeditors.ClassEditor;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.beans.propertyeditors.InputSourceEditor;
/*     */ import org.springframework.beans.propertyeditors.InputStreamEditor;
/*     */ import org.springframework.beans.propertyeditors.PathEditor;
/*     */ import org.springframework.beans.propertyeditors.ReaderEditor;
/*     */ import org.springframework.beans.propertyeditors.URIEditor;
/*     */ import org.springframework.beans.propertyeditors.URLEditor;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.core.io.ContextResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.WritableResource;
/*     */ import org.springframework.core.io.support.ResourceArrayPropertyEditor;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceEditorRegistrar
/*     */   implements PropertyEditorRegistrar
/*     */ {
/*     */   private final PropertyResolver propertyResolver;
/*     */   private final ResourceLoader resourceLoader;
/*     */   
/*     */   public ResourceEditorRegistrar(ResourceLoader resourceLoader, PropertyResolver propertyResolver) {
/*  80 */     this.resourceLoader = resourceLoader;
/*  81 */     this.propertyResolver = propertyResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerCustomEditors(PropertyEditorRegistry registry) {
/* 103 */     ResourceEditor baseEditor = new ResourceEditor(this.resourceLoader, this.propertyResolver);
/* 104 */     doRegisterEditor(registry, Resource.class, (PropertyEditor)baseEditor);
/* 105 */     doRegisterEditor(registry, ContextResource.class, (PropertyEditor)baseEditor);
/* 106 */     doRegisterEditor(registry, WritableResource.class, (PropertyEditor)baseEditor);
/* 107 */     doRegisterEditor(registry, InputStream.class, (PropertyEditor)new InputStreamEditor(baseEditor));
/* 108 */     doRegisterEditor(registry, InputSource.class, (PropertyEditor)new InputSourceEditor(baseEditor));
/* 109 */     doRegisterEditor(registry, File.class, (PropertyEditor)new FileEditor(baseEditor));
/* 110 */     doRegisterEditor(registry, Path.class, (PropertyEditor)new PathEditor(baseEditor));
/* 111 */     doRegisterEditor(registry, Reader.class, (PropertyEditor)new ReaderEditor(baseEditor));
/* 112 */     doRegisterEditor(registry, URL.class, (PropertyEditor)new URLEditor(baseEditor));
/*     */     
/* 114 */     ClassLoader classLoader = this.resourceLoader.getClassLoader();
/* 115 */     doRegisterEditor(registry, URI.class, (PropertyEditor)new URIEditor(classLoader));
/* 116 */     doRegisterEditor(registry, Class.class, (PropertyEditor)new ClassEditor(classLoader));
/* 117 */     doRegisterEditor(registry, Class[].class, (PropertyEditor)new ClassArrayEditor(classLoader));
/*     */     
/* 119 */     ResourceLoader resourceLoader = this.resourceLoader; if (resourceLoader instanceof ResourcePatternResolver) { ResourcePatternResolver resourcePatternResolver = (ResourcePatternResolver)resourceLoader;
/* 120 */       doRegisterEditor(registry, Resource[].class, (PropertyEditor)new ResourceArrayPropertyEditor(resourcePatternResolver, this.propertyResolver)); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doRegisterEditor(PropertyEditorRegistry registry, Class<?> requiredType, PropertyEditor editor) {
/* 130 */     if (registry instanceof PropertyEditorRegistrySupport) { PropertyEditorRegistrySupport registrySupport = (PropertyEditorRegistrySupport)registry;
/* 131 */       registrySupport.overrideDefaultEditor(requiredType, editor); }
/*     */     else
/*     */     
/* 134 */     { registry.registerCustomEditor(requiredType, editor); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overridesDefaultEditors() {
/* 143 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\support\ResourceEditorRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */