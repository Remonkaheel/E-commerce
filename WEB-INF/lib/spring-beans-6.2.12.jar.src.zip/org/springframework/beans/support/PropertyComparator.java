/*     */ package org.springframework.beans.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyComparator<T>
/*     */   implements Comparator<T>
/*     */ {
/*  44 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   private final SortDefinition sortDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyComparator(SortDefinition sortDefinition) {
/*  54 */     this.sortDefinition = sortDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyComparator(String property, boolean ignoreCase, boolean ascending) {
/*  64 */     this.sortDefinition = new MutableSortDefinition(property, ignoreCase, ascending);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SortDefinition getSortDefinition() {
/*  71 */     return this.sortDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(T o1, T o2) {
/*     */     int result;
/*  78 */     Object v1 = getPropertyValue(o1);
/*  79 */     Object v2 = getPropertyValue(o2);
/*  80 */     if (this.sortDefinition.isIgnoreCase() && v1 instanceof String) { String text1 = (String)v1; if (v2 instanceof String) { String text2 = (String)v2;
/*  81 */         v1 = text1.toLowerCase(Locale.ROOT);
/*  82 */         v2 = text2.toLowerCase(Locale.ROOT); }
/*     */        }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  89 */       if (v1 != null) {
/*  90 */         result = (v2 != null) ? ((Comparable<Object>)v1).compareTo(v2) : -1;
/*     */       } else {
/*     */         
/*  93 */         result = (v2 != null) ? 1 : 0;
/*     */       }
/*     */     
/*  96 */     } catch (RuntimeException ex) {
/*  97 */       if (this.logger.isDebugEnabled()) {
/*  98 */         this.logger.debug("Could not sort objects [" + String.valueOf(o1) + "] and [" + String.valueOf(o2) + "]", ex);
/*     */       }
/* 100 */       return 0;
/*     */     } 
/*     */     
/* 103 */     return this.sortDefinition.isAscending() ? result : -result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object getPropertyValue(Object obj) {
/*     */     try {
/* 117 */       BeanWrapperImpl beanWrapper = new BeanWrapperImpl(false);
/* 118 */       beanWrapper.setWrappedInstance(obj);
/* 119 */       return beanWrapper.getPropertyValue(this.sortDefinition.getProperty());
/*     */     }
/* 121 */     catch (BeansException ex) {
/* 122 */       this.logger.debug("PropertyComparator could not access property - treating as null for sorting", (Throwable)ex);
/* 123 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sort(List<?> source, SortDefinition sortDefinition) throws BeansException {
/* 137 */     if (StringUtils.hasText(sortDefinition.getProperty())) {
/* 138 */       source.sort(new PropertyComparator(sortDefinition));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sort(Object[] source, SortDefinition sortDefinition) throws BeansException {
/* 151 */     if (StringUtils.hasText(sortDefinition.getProperty()))
/* 152 */       Arrays.sort(source, new PropertyComparator(sortDefinition)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\support\PropertyComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */