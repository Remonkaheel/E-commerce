/*     */ package org.springframework.beans.support;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MethodInvoker;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgumentConvertingMethodInvoker
/*     */   extends MethodInvoker
/*     */ {
/*     */   @Nullable
/*     */   private TypeConverter typeConverter;
/*     */   private boolean useDefaultConverter = true;
/*     */   
/*     */   public void setTypeConverter(@Nullable TypeConverter typeConverter) {
/*  59 */     this.typeConverter = typeConverter;
/*  60 */     this.useDefaultConverter = (typeConverter == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeConverter getTypeConverter() {
/*  72 */     if (this.typeConverter == null && this.useDefaultConverter) {
/*  73 */       this.typeConverter = getDefaultTypeConverter();
/*     */     }
/*  75 */     return this.typeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeConverter getDefaultTypeConverter() {
/*  86 */     return (TypeConverter)new SimpleTypeConverter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerCustomEditor(Class<?> requiredType, PropertyEditor propertyEditor) {
/*     */     PropertyEditorRegistry registry;
/* 100 */     TypeConverter converter = getTypeConverter();
/* 101 */     if (converter instanceof PropertyEditorRegistry) { registry = (PropertyEditorRegistry)converter; }
/* 102 */     else { throw new IllegalStateException("TypeConverter does not implement PropertyEditorRegistry interface: " + String.valueOf(converter)); }
/*     */ 
/*     */     
/* 105 */     registry.registerCustomEditor(requiredType, propertyEditor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Method findMatchingMethod() {
/* 116 */     Method matchingMethod = super.findMatchingMethod();
/*     */     
/* 118 */     if (matchingMethod == null)
/*     */     {
/* 120 */       matchingMethod = doFindMatchingMethod(getArguments());
/*     */     }
/* 122 */     if (matchingMethod == null)
/*     */     {
/* 124 */       matchingMethod = doFindMatchingMethod(new Object[] { getArguments() });
/*     */     }
/* 126 */     return matchingMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Method doFindMatchingMethod(Object[] arguments) {
/* 137 */     TypeConverter converter = getTypeConverter();
/* 138 */     if (converter != null) {
/* 139 */       String targetMethod = getTargetMethod();
/* 140 */       Method matchingMethod = null;
/* 141 */       int argCount = arguments.length;
/* 142 */       Class<?> targetClass = getTargetClass();
/* 143 */       Assert.state((targetClass != null), "No target class set");
/* 144 */       Method[] candidates = ReflectionUtils.getAllDeclaredMethods(targetClass);
/* 145 */       int minTypeDiffWeight = Integer.MAX_VALUE;
/* 146 */       Object[] argumentsToUse = null;
/* 147 */       for (Method candidate : candidates) {
/* 148 */         if (candidate.getName().equals(targetMethod)) {
/*     */           
/* 150 */           int parameterCount = candidate.getParameterCount();
/* 151 */           if (parameterCount == argCount) {
/* 152 */             Class<?>[] paramTypes = candidate.getParameterTypes();
/* 153 */             Object[] convertedArguments = new Object[argCount];
/* 154 */             boolean match = true;
/* 155 */             for (int j = 0; j < argCount && match; j++) {
/*     */               
/*     */               try {
/* 158 */                 convertedArguments[j] = converter.convertIfNecessary(arguments[j], paramTypes[j]);
/*     */               }
/* 160 */               catch (TypeMismatchException ex) {
/*     */                 
/* 162 */                 match = false;
/*     */               } 
/*     */             } 
/* 165 */             if (match) {
/* 166 */               int typeDiffWeight = getTypeDifferenceWeight(paramTypes, convertedArguments);
/* 167 */               if (typeDiffWeight < minTypeDiffWeight) {
/* 168 */                 minTypeDiffWeight = typeDiffWeight;
/* 169 */                 matchingMethod = candidate;
/* 170 */                 argumentsToUse = convertedArguments;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 176 */       if (matchingMethod != null) {
/* 177 */         setArguments(argumentsToUse);
/* 178 */         return matchingMethod;
/*     */       } 
/*     */     } 
/* 181 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\support\ArgumentConvertingMethodInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */