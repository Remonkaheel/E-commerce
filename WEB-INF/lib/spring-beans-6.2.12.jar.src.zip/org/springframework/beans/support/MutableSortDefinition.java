/*     */ package org.springframework.beans.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutableSortDefinition
/*     */   implements SortDefinition, Serializable
/*     */ {
/*  36 */   private String property = "";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreCase = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ascending = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean toggleAscendingOnProperty = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableSortDefinition() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableSortDefinition(SortDefinition source) {
/*  61 */     this.property = source.getProperty();
/*  62 */     this.ignoreCase = source.isIgnoreCase();
/*  63 */     this.ascending = source.isAscending();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableSortDefinition(String property, boolean ignoreCase, boolean ascending) {
/*  73 */     this.property = property;
/*  74 */     this.ignoreCase = ignoreCase;
/*  75 */     this.ascending = ascending;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableSortDefinition(boolean toggleAscendingOnSameProperty) {
/*  85 */     this.toggleAscendingOnProperty = toggleAscendingOnSameProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String property) {
/*  96 */     if (!StringUtils.hasLength(property)) {
/*  97 */       this.property = "";
/*     */     }
/*     */     else {
/*     */       
/* 101 */       if (isToggleAscendingOnProperty()) {
/* 102 */         this.ascending = (!property.equals(this.property) || !this.ascending);
/*     */       }
/* 104 */       this.property = property;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProperty() {
/* 110 */     return this.property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreCase(boolean ignoreCase) {
/* 117 */     this.ignoreCase = ignoreCase;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIgnoreCase() {
/* 122 */     return this.ignoreCase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAscending(boolean ascending) {
/* 129 */     this.ascending = ascending;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAscending() {
/* 134 */     return this.ascending;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToggleAscendingOnProperty(boolean toggleAscendingOnProperty) {
/* 145 */     this.toggleAscendingOnProperty = toggleAscendingOnProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToggleAscendingOnProperty() {
/* 153 */     return this.toggleAscendingOnProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 159 */     if (this != other) { if (other instanceof SortDefinition) { SortDefinition that = (SortDefinition)other;
/* 160 */         if (getProperty().equals(that.getProperty()) && 
/* 161 */           isAscending() == that.isAscending() && 
/* 162 */           isIgnoreCase() == that.isIgnoreCase()); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 167 */     int hashCode = getProperty().hashCode();
/* 168 */     hashCode = 29 * hashCode + (isIgnoreCase() ? 1 : 0);
/* 169 */     hashCode = 29 * hashCode + (isAscending() ? 1 : 0);
/* 170 */     return hashCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\support\MutableSortDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */