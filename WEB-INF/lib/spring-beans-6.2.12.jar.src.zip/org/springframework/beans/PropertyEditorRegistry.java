package org.springframework.beans;

import java.beans.PropertyEditor;
import org.springframework.lang.Nullable;

public interface PropertyEditorRegistry {
  void registerCustomEditor(Class<?> paramClass, PropertyEditor paramPropertyEditor);
  
  void registerCustomEditor(@Nullable Class<?> paramClass, @Nullable String paramString, PropertyEditor paramPropertyEditor);
  
  @Nullable
  PropertyEditor findCustomEditor(@Nullable Class<?> paramClass, @Nullable String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\PropertyEditorRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */