/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.core.convert.ConversionException;
/*    */ import org.springframework.core.convert.ConverterNotFoundException;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TypeConverterSupport
/*    */   extends PropertyEditorRegistrySupport
/*    */   implements TypeConverter
/*    */ {
/*    */   @Nullable
/*    */   TypeConverterDelegate typeConverterDelegate;
/*    */   
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType) throws TypeMismatchException {
/* 45 */     return convertIfNecessary(null, value, requiredType, TypeDescriptor.valueOf(requiredType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable MethodParameter methodParam) throws TypeMismatchException {
/* 53 */     return convertIfNecessary((methodParam != null) ? methodParam.getParameterName() : null, value, requiredType, 
/* 54 */         (methodParam != null) ? new TypeDescriptor(methodParam) : TypeDescriptor.valueOf(requiredType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable Field field) throws TypeMismatchException {
/* 62 */     return convertIfNecessary((field != null) ? field.getName() : null, value, requiredType, 
/* 63 */         (field != null) ? new TypeDescriptor(field) : TypeDescriptor.valueOf(requiredType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable TypeDescriptor typeDescriptor) throws TypeMismatchException {
/* 71 */     return convertIfNecessary(null, value, requiredType, typeDescriptor);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private <T> T convertIfNecessary(@Nullable String propertyName, @Nullable Object value, @Nullable Class<T> requiredType, @Nullable TypeDescriptor typeDescriptor) throws TypeMismatchException {
/* 78 */     Assert.state((this.typeConverterDelegate != null), "No TypeConverterDelegate");
/*    */     try {
/* 80 */       return this.typeConverterDelegate.convertIfNecessary(propertyName, null, value, requiredType, typeDescriptor);
/*    */     
/*    */     }
/* 83 */     catch (ConverterNotFoundException|IllegalStateException ex) {
/* 84 */       throw new ConversionNotSupportedException(value, requiredType, ex);
/*    */     }
/* 86 */     catch (ConversionException|IllegalArgumentException ex) {
/* 87 */       throw new TypeMismatchException(value, requiredType, ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\TypeConverterSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */