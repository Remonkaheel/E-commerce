/*    */ package org.springframework.beans;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotWritablePropertyException
/*    */   extends InvalidPropertyException
/*    */ {
/*    */   @Nullable
/*    */   private final String[] possibleMatches;
/*    */   
/*    */   public NotWritablePropertyException(Class<?> beanClass, String propertyName) {
/* 42 */     super(beanClass, propertyName, "Bean property '" + propertyName + "' is not writable or has an invalid setter method: Does the return type of the getter match the parameter type of the setter?");
/*    */ 
/*    */     
/* 45 */     this.possibleMatches = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NotWritablePropertyException(Class<?> beanClass, String propertyName, String msg) {
/* 55 */     super(beanClass, propertyName, msg);
/* 56 */     this.possibleMatches = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NotWritablePropertyException(Class<?> beanClass, String propertyName, String msg, Throwable cause) {
/* 67 */     super(beanClass, propertyName, msg, cause);
/* 68 */     this.possibleMatches = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NotWritablePropertyException(Class<?> beanClass, String propertyName, String msg, String[] possibleMatches) {
/* 80 */     super(beanClass, propertyName, msg);
/* 81 */     this.possibleMatches = possibleMatches;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String[] getPossibleMatches() {
/* 91 */     return this.possibleMatches;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\NotWritablePropertyException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */