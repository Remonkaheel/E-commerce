package org.springframework.beans;

import java.beans.PropertyDescriptor;

public interface BeanWrapper extends ConfigurablePropertyAccessor {
  void setAutoGrowCollectionLimit(int paramInt);
  
  int getAutoGrowCollectionLimit();
  
  Object getWrappedInstance();
  
  Class<?> getWrappedClass();
  
  PropertyDescriptor[] getPropertyDescriptors();
  
  PropertyDescriptor getPropertyDescriptor(String paramString) throws InvalidPropertyException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\BeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */