/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCreationNotAllowedException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.core.SimpleAliasRegistry;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSingletonBeanRegistry
/*     */   extends SimpleAliasRegistry
/*     */   implements SingletonBeanRegistry
/*     */ {
/*     */   private static final int SUPPRESSED_EXCEPTIONS_LIMIT = 100;
/*  82 */   final Lock singletonLock = new ReentrantLock();
/*     */ 
/*     */   
/*  85 */   private final Map<String, Object> singletonObjects = new ConcurrentHashMap<>(256);
/*     */ 
/*     */   
/*  88 */   private final Map<String, ObjectFactory<?>> singletonFactories = new ConcurrentHashMap<>(16);
/*     */ 
/*     */   
/*  91 */   private final Map<String, Consumer<Object>> singletonCallbacks = new ConcurrentHashMap<>(16);
/*     */ 
/*     */   
/*  94 */   private final Map<String, Object> earlySingletonObjects = new ConcurrentHashMap<>(16);
/*     */ 
/*     */   
/*  97 */   private final Set<String> registeredSingletons = Collections.synchronizedSet(new LinkedHashSet<>(256));
/*     */ 
/*     */   
/* 100 */   private final Set<String> singletonsCurrentlyInCreation = ConcurrentHashMap.newKeySet(16);
/*     */ 
/*     */   
/* 103 */   private final Set<String> inCreationCheckExclusions = ConcurrentHashMap.newKeySet(16);
/*     */ 
/*     */   
/* 106 */   private final Lock lenientCreationLock = new ReentrantLock();
/*     */ 
/*     */   
/* 109 */   private final Condition lenientCreationFinished = this.lenientCreationLock.newCondition();
/*     */ 
/*     */   
/* 112 */   private final Set<String> singletonsInLenientCreation = new HashSet<>();
/*     */ 
/*     */   
/* 115 */   private final Map<Thread, Thread> lenientWaitingThreads = new HashMap<>();
/*     */ 
/*     */   
/* 118 */   private final Map<String, Thread> currentCreationThreads = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   private volatile boolean singletonsCurrentlyInDestruction = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Set<Exception> suppressedExceptions;
/*     */ 
/*     */   
/* 128 */   private final Map<String, DisposableBean> disposableBeans = new LinkedHashMap<>();
/*     */ 
/*     */   
/* 131 */   private final Map<String, Set<String>> containedBeanMap = new ConcurrentHashMap<>(16);
/*     */ 
/*     */   
/* 134 */   private final Map<String, Set<String>> dependentBeanMap = new ConcurrentHashMap<>(64);
/*     */ 
/*     */   
/* 137 */   private final Map<String, Set<String>> dependenciesForBeanMap = new ConcurrentHashMap<>(64);
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerSingleton(String beanName, Object singletonObject) throws IllegalStateException {
/* 142 */     Assert.notNull(beanName, "Bean name must not be null");
/* 143 */     Assert.notNull(singletonObject, "Singleton object must not be null");
/* 144 */     this.singletonLock.lock();
/*     */     try {
/* 146 */       addSingleton(beanName, singletonObject);
/*     */     } finally {
/*     */       
/* 149 */       this.singletonLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addSingleton(String beanName, Object singletonObject) {
/* 160 */     Object oldObject = this.singletonObjects.putIfAbsent(beanName, singletonObject);
/* 161 */     if (oldObject != null) {
/* 162 */       throw new IllegalStateException("Could not register object [" + String.valueOf(singletonObject) + "] under bean name '" + beanName + "': there is already object [" + String.valueOf(oldObject) + "] bound");
/*     */     }
/*     */     
/* 165 */     this.singletonFactories.remove(beanName);
/* 166 */     this.earlySingletonObjects.remove(beanName);
/* 167 */     this.registeredSingletons.add(beanName);
/*     */     
/* 169 */     Consumer<Object> callback = this.singletonCallbacks.get(beanName);
/* 170 */     if (callback != null) {
/* 171 */       callback.accept(singletonObject);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addSingletonFactory(String beanName, ObjectFactory<?> singletonFactory) {
/* 184 */     Assert.notNull(singletonFactory, "Singleton factory must not be null");
/* 185 */     this.singletonFactories.put(beanName, singletonFactory);
/* 186 */     this.earlySingletonObjects.remove(beanName);
/* 187 */     this.registeredSingletons.add(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSingletonCallback(String beanName, Consumer<Object> singletonConsumer) {
/* 192 */     this.singletonCallbacks.put(beanName, singletonConsumer);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSingleton(String beanName) {
/* 198 */     return getSingleton(beanName, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getSingleton(String beanName, boolean allowEarlyReference) {
/* 212 */     Object singletonObject = this.singletonObjects.get(beanName);
/* 213 */     if (singletonObject == null && isSingletonCurrentlyInCreation(beanName)) {
/* 214 */       singletonObject = this.earlySingletonObjects.get(beanName);
/* 215 */       if (singletonObject == null && allowEarlyReference) {
/* 216 */         if (!this.singletonLock.tryLock())
/*     */         {
/* 218 */           return null;
/*     */         }
/*     */         
/*     */         try {
/* 222 */           singletonObject = this.singletonObjects.get(beanName);
/* 223 */           if (singletonObject == null) {
/* 224 */             singletonObject = this.earlySingletonObjects.get(beanName);
/* 225 */             if (singletonObject == null) {
/* 226 */               ObjectFactory<?> singletonFactory = this.singletonFactories.get(beanName);
/* 227 */               if (singletonFactory != null) {
/* 228 */                 singletonObject = singletonFactory.getObject();
/*     */                 
/* 230 */                 if (this.singletonFactories.remove(beanName) != null) {
/* 231 */                   this.earlySingletonObjects.put(beanName, singletonObject);
/*     */                 } else {
/*     */                   
/* 234 */                   singletonObject = this.singletonObjects.get(beanName);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } finally {
/*     */           
/* 241 */           this.singletonLock.unlock();
/*     */         } 
/*     */       } 
/*     */     } 
/* 245 */     return singletonObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSingleton(String beanName, ObjectFactory<?> singletonFactory) {
/* 258 */     Assert.notNull(beanName, "Bean name must not be null");
/*     */     
/* 260 */     Thread currentThread = Thread.currentThread();
/* 261 */     Boolean lockFlag = isCurrentThreadAllowedToHoldSingletonLock();
/* 262 */     boolean acquireLock = !Boolean.FALSE.equals(lockFlag);
/* 263 */     boolean locked = (acquireLock && this.singletonLock.tryLock());
/*     */     
/*     */     try {
/* 266 */       Object singletonObject = this.singletonObjects.get(beanName);
/* 267 */       if (singletonObject == null) {
/* 268 */         if (acquireLock && !locked) {
/* 269 */           if (Boolean.TRUE.equals(lockFlag)) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 274 */             this.lenientCreationLock.lock();
/*     */             try {
/* 276 */               if (this.logger.isInfoEnabled()) {
/* 277 */                 Set<String> lockedBeans = new HashSet<>(this.singletonsCurrentlyInCreation);
/* 278 */                 lockedBeans.removeAll(this.singletonsInLenientCreation);
/* 279 */                 this.logger.info("Obtaining singleton bean '" + beanName + "' in thread \"" + currentThread
/* 280 */                     .getName() + "\" while other thread holds singleton lock for other beans " + String.valueOf(lockedBeans));
/*     */               } 
/*     */               
/* 283 */               this.singletonsInLenientCreation.add(beanName);
/*     */             } finally {
/*     */               
/* 286 */               this.lenientCreationLock.unlock();
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 292 */             this.singletonLock.lock();
/* 293 */             locked = true;
/*     */             
/* 295 */             singletonObject = this.singletonObjects.get(beanName);
/* 296 */             if (singletonObject != null) {
/* 297 */               return singletonObject;
/*     */             }
/*     */           } 
/*     */         }
/*     */         
/* 302 */         if (this.singletonsCurrentlyInDestruction) {
/* 303 */           throw new BeanCreationNotAllowedException(beanName, "Singleton bean creation not allowed while singletons of this factory are in destruction (Do not request a bean from a BeanFactory in a destroy method implementation!)");
/*     */         }
/*     */ 
/*     */         
/* 307 */         if (this.logger.isDebugEnabled()) {
/* 308 */           this.logger.debug("Creating shared instance of singleton bean '" + beanName + "'");
/*     */         }
/*     */         
/*     */         try {
/* 312 */           beforeSingletonCreation(beanName);
/*     */         }
/* 314 */         catch (BeanCurrentlyInCreationException ex) {
/* 315 */           this.lenientCreationLock.lock();
/*     */           try {
/* 317 */             while ((singletonObject = this.singletonObjects.get(beanName)) == null) {
/* 318 */               Thread otherThread = this.currentCreationThreads.get(beanName);
/* 319 */               if (otherThread != null && (otherThread == currentThread || 
/* 320 */                 checkDependentWaitingThreads(otherThread, currentThread))) {
/* 321 */                 throw ex;
/*     */               }
/* 323 */               if (!this.singletonsInLenientCreation.contains(beanName)) {
/*     */                 break;
/*     */               }
/* 326 */               if (otherThread != null) {
/* 327 */                 this.lenientWaitingThreads.put(currentThread, otherThread);
/*     */               }
/*     */               try {
/* 330 */                 this.lenientCreationFinished.await();
/*     */               }
/* 332 */               catch (InterruptedException ie) {
/* 333 */                 currentThread.interrupt();
/*     */               } finally {
/*     */                 
/* 336 */                 if (otherThread != null) {
/* 337 */                   this.lenientWaitingThreads.remove(currentThread);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } finally {
/*     */             
/* 343 */             this.lenientCreationLock.unlock();
/*     */           } 
/* 345 */           if (singletonObject != null) {
/* 346 */             return singletonObject;
/*     */           }
/* 348 */           if (locked) {
/* 349 */             throw ex;
/*     */           }
/*     */           
/* 352 */           this.singletonLock.lock();
/* 353 */           locked = true;
/*     */           
/* 355 */           singletonObject = this.singletonObjects.get(beanName);
/* 356 */           if (singletonObject != null) {
/* 357 */             return singletonObject;
/*     */           }
/* 359 */           beforeSingletonCreation(beanName);
/*     */         } 
/*     */         
/* 362 */         boolean newSingleton = false;
/* 363 */         boolean recordSuppressedExceptions = (locked && this.suppressedExceptions == null);
/* 364 */         if (recordSuppressedExceptions) {
/* 365 */           this.suppressedExceptions = new LinkedHashSet<>();
/*     */         }
/*     */         
/*     */         try {
/* 369 */           singletonObject = this.singletonObjects.get(beanName);
/* 370 */           if (singletonObject == null) {
/* 371 */             this.currentCreationThreads.put(beanName, currentThread);
/*     */             try {
/* 373 */               singletonObject = singletonFactory.getObject();
/*     */             } finally {
/*     */               
/* 376 */               this.currentCreationThreads.remove(beanName);
/*     */             } 
/* 378 */             newSingleton = true;
/*     */           }
/*     */         
/* 381 */         } catch (IllegalStateException ex) {
/*     */ 
/*     */           
/* 384 */           singletonObject = this.singletonObjects.get(beanName);
/* 385 */           if (singletonObject == null) {
/* 386 */             throw ex;
/*     */           }
/*     */         }
/* 389 */         catch (BeanCreationException ex) {
/* 390 */           if (recordSuppressedExceptions) {
/* 391 */             for (Exception suppressedException : this.suppressedExceptions) {
/* 392 */               ex.addRelatedCause(suppressedException);
/*     */             }
/*     */           }
/* 395 */           throw ex;
/*     */         } finally {
/*     */           
/* 398 */           if (recordSuppressedExceptions) {
/* 399 */             this.suppressedExceptions = null;
/*     */           }
/* 401 */           afterSingletonCreation(beanName);
/*     */         } 
/*     */         
/* 404 */         if (newSingleton) {
/*     */           try {
/* 406 */             addSingleton(beanName, singletonObject);
/*     */           }
/* 408 */           catch (IllegalStateException ex) {
/*     */             
/* 410 */             Object object = this.singletonObjects.get(beanName);
/* 411 */             if (singletonObject != object) {
/* 412 */               throw ex;
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/* 417 */       return singletonObject;
/*     */     } finally {
/*     */       
/* 420 */       if (locked) {
/* 421 */         this.singletonLock.unlock();
/*     */       }
/* 423 */       this.lenientCreationLock.lock();
/*     */       try {
/* 425 */         this.singletonsInLenientCreation.remove(beanName);
/* 426 */         this.lenientWaitingThreads.entrySet().removeIf(entry -> (entry.getValue() == currentThread));
/*     */         
/* 428 */         this.lenientCreationFinished.signalAll();
/*     */       } finally {
/*     */         
/* 431 */         this.lenientCreationLock.unlock();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean checkDependentWaitingThreads(Thread waitingThread, Thread candidateThread) {
/* 437 */     Thread threadToCheck = waitingThread;
/* 438 */     while ((threadToCheck = this.lenientWaitingThreads.get(threadToCheck)) != null) {
/* 439 */       if (threadToCheck == candidateThread) {
/* 440 */         return true;
/*     */       }
/*     */     } 
/* 443 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Boolean isCurrentThreadAllowedToHoldSingletonLock() {
/* 462 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onSuppressedException(Exception ex) {
/* 475 */     if (this.suppressedExceptions != null && this.suppressedExceptions.size() < 100) {
/* 476 */       this.suppressedExceptions.add(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeSingleton(String beanName) {
/* 486 */     this.singletonObjects.remove(beanName);
/* 487 */     this.singletonFactories.remove(beanName);
/* 488 */     this.earlySingletonObjects.remove(beanName);
/* 489 */     this.registeredSingletons.remove(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsSingleton(String beanName) {
/* 494 */     return this.singletonObjects.containsKey(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSingletonNames() {
/* 499 */     return StringUtils.toStringArray(this.registeredSingletons);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSingletonCount() {
/* 504 */     return this.registeredSingletons.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentlyInCreation(String beanName, boolean inCreation) {
/* 509 */     Assert.notNull(beanName, "Bean name must not be null");
/* 510 */     if (!inCreation) {
/* 511 */       this.inCreationCheckExclusions.add(beanName);
/*     */     } else {
/*     */       
/* 514 */       this.inCreationCheckExclusions.remove(beanName);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isCurrentlyInCreation(String beanName) {
/* 519 */     Assert.notNull(beanName, "Bean name must not be null");
/* 520 */     return (!this.inCreationCheckExclusions.contains(beanName) && isActuallyInCreation(beanName));
/*     */   }
/*     */   
/*     */   protected boolean isActuallyInCreation(String beanName) {
/* 524 */     return isSingletonCurrentlyInCreation(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingletonCurrentlyInCreation(@Nullable String beanName) {
/* 533 */     return this.singletonsCurrentlyInCreation.contains(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beforeSingletonCreation(String beanName) {
/* 543 */     if (!this.inCreationCheckExclusions.contains(beanName) && !this.singletonsCurrentlyInCreation.add(beanName)) {
/* 544 */       throw new BeanCurrentlyInCreationException(beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterSingletonCreation(String beanName) {
/* 555 */     if (!this.inCreationCheckExclusions.contains(beanName) && !this.singletonsCurrentlyInCreation.remove(beanName)) {
/* 556 */       throw new IllegalStateException("Singleton '" + beanName + "' isn't currently in creation");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerDisposableBean(String beanName, DisposableBean bean) {
/* 571 */     synchronized (this.disposableBeans) {
/* 572 */       this.disposableBeans.put(beanName, bean);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerContainedBean(String containedBeanName, String containingBeanName) {
/* 586 */     synchronized (this.containedBeanMap) {
/*     */       
/* 588 */       Set<String> containedBeans = this.containedBeanMap.computeIfAbsent(containingBeanName, k -> new LinkedHashSet(8));
/* 589 */       if (!containedBeans.add(containedBeanName)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 593 */     registerDependentBean(containedBeanName, containingBeanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerDependentBean(String beanName, String dependentBeanName) {
/* 603 */     String canonicalName = canonicalName(beanName);
/*     */     
/* 605 */     synchronized (this.dependentBeanMap) {
/*     */       
/* 607 */       Set<String> dependentBeans = this.dependentBeanMap.computeIfAbsent(canonicalName, k -> new LinkedHashSet(8));
/* 608 */       if (!dependentBeans.add(dependentBeanName)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 613 */     synchronized (this.dependenciesForBeanMap) {
/*     */       
/* 615 */       Set<String> dependenciesForBean = this.dependenciesForBeanMap.computeIfAbsent(dependentBeanName, k -> new LinkedHashSet(8));
/* 616 */       dependenciesForBean.add(canonicalName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDependent(String beanName, String dependentBeanName) {
/* 628 */     synchronized (this.dependentBeanMap) {
/* 629 */       return isDependent(beanName, dependentBeanName, (Set<String>)null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isDependent(String beanName, String dependentBeanName, @Nullable Set<String> alreadySeen) {
/* 634 */     if (alreadySeen != null && alreadySeen.contains(beanName)) {
/* 635 */       return false;
/*     */     }
/* 637 */     String canonicalName = canonicalName(beanName);
/* 638 */     Set<String> dependentBeans = this.dependentBeanMap.get(canonicalName);
/* 639 */     if (dependentBeans == null || dependentBeans.isEmpty()) {
/* 640 */       return false;
/*     */     }
/* 642 */     if (dependentBeans.contains(dependentBeanName)) {
/* 643 */       return true;
/*     */     }
/* 645 */     if (alreadySeen == null) {
/* 646 */       alreadySeen = new HashSet<>();
/*     */     }
/* 648 */     alreadySeen.add(beanName);
/* 649 */     for (String transitiveDependency : dependentBeans) {
/* 650 */       if (isDependent(transitiveDependency, dependentBeanName, alreadySeen)) {
/* 651 */         return true;
/*     */       }
/*     */     } 
/* 654 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasDependentBean(String beanName) {
/* 662 */     return this.dependentBeanMap.containsKey(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDependentBeans(String beanName) {
/* 671 */     Set<String> dependentBeans = this.dependentBeanMap.get(beanName);
/* 672 */     if (dependentBeans == null) {
/* 673 */       return new String[0];
/*     */     }
/* 675 */     synchronized (this.dependentBeanMap) {
/* 676 */       return StringUtils.toStringArray(dependentBeans);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDependenciesForBean(String beanName) {
/* 687 */     Set<String> dependenciesForBean = this.dependenciesForBeanMap.get(beanName);
/* 688 */     if (dependenciesForBean == null) {
/* 689 */       return new String[0];
/*     */     }
/* 691 */     synchronized (this.dependenciesForBeanMap) {
/* 692 */       return StringUtils.toStringArray(dependenciesForBean);
/*     */     } 
/*     */   }
/*     */   public void destroySingletons() {
/*     */     String[] disposableBeanNames;
/* 697 */     if (this.logger.isTraceEnabled()) {
/* 698 */       this.logger.trace("Destroying singletons in " + String.valueOf(this));
/*     */     }
/* 700 */     this.singletonsCurrentlyInDestruction = true;
/*     */ 
/*     */     
/* 703 */     synchronized (this.disposableBeans) {
/* 704 */       disposableBeanNames = StringUtils.toStringArray(this.disposableBeans.keySet());
/*     */     } 
/* 706 */     for (int i = disposableBeanNames.length - 1; i >= 0; i--) {
/* 707 */       destroySingleton(disposableBeanNames[i]);
/*     */     }
/*     */     
/* 710 */     this.containedBeanMap.clear();
/* 711 */     this.dependentBeanMap.clear();
/* 712 */     this.dependenciesForBeanMap.clear();
/*     */     
/* 714 */     this.singletonLock.lock();
/*     */     try {
/* 716 */       clearSingletonCache();
/*     */     } finally {
/*     */       
/* 719 */       this.singletonLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearSingletonCache() {
/* 728 */     this.singletonObjects.clear();
/* 729 */     this.singletonFactories.clear();
/* 730 */     this.earlySingletonObjects.clear();
/* 731 */     this.registeredSingletons.clear();
/* 732 */     this.singletonsCurrentlyInDestruction = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroySingleton(String beanName) {
/*     */     DisposableBean disposableBean;
/* 745 */     synchronized (this.disposableBeans) {
/* 746 */       disposableBean = this.disposableBeans.remove(beanName);
/*     */     } 
/* 748 */     destroyBean(beanName, disposableBean);
/*     */ 
/*     */ 
/*     */     
/* 752 */     if (!this.singletonsCurrentlyInDestruction)
/*     */     {
/*     */ 
/*     */       
/* 756 */       if (this.currentCreationThreads.get(beanName) == Thread.currentThread()) {
/*     */ 
/*     */         
/* 759 */         removeSingleton(beanName);
/*     */       } else {
/*     */         
/* 762 */         this.singletonLock.lock();
/*     */         try {
/* 764 */           removeSingleton(beanName);
/*     */         } finally {
/*     */           
/* 767 */           this.singletonLock.unlock();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyBean(String beanName, @Nullable DisposableBean bean) {
/*     */     Set<String> dependentBeanNames, containedBeans;
/* 782 */     synchronized (this.dependentBeanMap) {
/*     */       
/* 784 */       dependentBeanNames = this.dependentBeanMap.remove(beanName);
/*     */     } 
/* 786 */     if (dependentBeanNames != null) {
/* 787 */       if (this.logger.isTraceEnabled()) {
/* 788 */         this.logger.trace("Retrieved dependent beans for bean '" + beanName + "': " + String.valueOf(dependentBeanNames));
/*     */       }
/* 790 */       for (String dependentBeanName : dependentBeanNames) {
/* 791 */         destroySingleton(dependentBeanName);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 796 */     if (bean != null) {
/*     */       try {
/* 798 */         bean.destroy();
/*     */       }
/* 800 */       catch (Throwable ex) {
/* 801 */         if (this.logger.isWarnEnabled()) {
/* 802 */           this.logger.warn("Destruction of bean with name '" + beanName + "' threw an exception", ex);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 809 */     synchronized (this.containedBeanMap) {
/*     */       
/* 811 */       containedBeans = this.containedBeanMap.remove(beanName);
/*     */     } 
/* 813 */     if (containedBeans != null) {
/* 814 */       for (String containedBeanName : containedBeans) {
/* 815 */         destroySingleton(containedBeanName);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 820 */     synchronized (this.dependentBeanMap) {
/* 821 */       for (Iterator<Map.Entry<String, Set<String>>> it = this.dependentBeanMap.entrySet().iterator(); it.hasNext(); ) {
/* 822 */         Map.Entry<String, Set<String>> entry = it.next();
/* 823 */         Set<String> dependenciesToClean = entry.getValue();
/* 824 */         dependenciesToClean.remove(beanName);
/* 825 */         if (dependenciesToClean.isEmpty()) {
/* 826 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 832 */     this.dependenciesForBeanMap.remove(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2")
/*     */   public final Object getSingletonMutex() {
/* 838 */     return new Object();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\DefaultSingletonBeanRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */