/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.style.ToStringCreator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RegisteredBean
/*     */ {
/*     */   private final ConfigurableListableBeanFactory beanFactory;
/*     */   private final Supplier<String> beanName;
/*     */   private final boolean generatedBeanName;
/*     */   private final Supplier<RootBeanDefinition> mergedBeanDefinition;
/*     */   @Nullable
/*     */   private final RegisteredBean parent;
/*     */   
/*     */   private RegisteredBean(ConfigurableListableBeanFactory beanFactory, Supplier<String> beanName, boolean generatedBeanName, Supplier<RootBeanDefinition> mergedBeanDefinition, @Nullable RegisteredBean parent) {
/*  68 */     this.beanFactory = beanFactory;
/*  69 */     this.beanName = beanName;
/*  70 */     this.generatedBeanName = generatedBeanName;
/*  71 */     this.mergedBeanDefinition = mergedBeanDefinition;
/*  72 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegisteredBean of(ConfigurableListableBeanFactory beanFactory, String beanName) {
/*  83 */     Assert.notNull(beanFactory, "'beanFactory' must not be null");
/*  84 */     Assert.hasLength(beanName, "'beanName' must not be empty");
/*  85 */     return new RegisteredBean(beanFactory, () -> beanName, false, () -> (RootBeanDefinition)beanFactory.getMergedBeanDefinition(beanName), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static RegisteredBean of(ConfigurableListableBeanFactory beanFactory, String beanName, RootBeanDefinition mbd) {
/*  99 */     return new RegisteredBean(beanFactory, () -> beanName, false, () -> mbd, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegisteredBean ofInnerBean(RegisteredBean parent, BeanDefinitionHolder innerBean) {
/* 109 */     Assert.notNull(innerBean, "'innerBean' must not be null");
/* 110 */     return ofInnerBean(parent, innerBean.getBeanName(), innerBean.getBeanDefinition());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegisteredBean ofInnerBean(RegisteredBean parent, BeanDefinition innerBeanDefinition) {
/* 120 */     return ofInnerBean(parent, null, innerBeanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegisteredBean ofInnerBean(RegisteredBean parent, @Nullable String innerBeanName, BeanDefinition innerBeanDefinition) {
/* 134 */     Assert.notNull(parent, "'parent' must not be null");
/* 135 */     Assert.notNull(innerBeanDefinition, "'innerBeanDefinition' must not be null");
/* 136 */     InnerBeanResolver resolver = new InnerBeanResolver(parent, innerBeanName, innerBeanDefinition);
/*     */     
/* 138 */     Objects.requireNonNull(resolver); Supplier<String> beanName = StringUtils.hasLength(innerBeanName) ? (() -> innerBeanName) : resolver::resolveBeanName;
/*     */     
/* 140 */     Objects.requireNonNull(resolver); return new RegisteredBean(parent.getBeanFactory(), beanName, (innerBeanName == null), resolver::resolveMergedBeanDefinition, parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBeanName() {
/* 149 */     return this.beanName.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGeneratedBeanName() {
/* 157 */     return this.generatedBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurableListableBeanFactory getBeanFactory() {
/* 165 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getBeanClass() {
/* 173 */     return ClassUtils.getUserClass(getBeanType().toClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getBeanType() {
/* 181 */     return getMergedBeanDefinition().getResolvableType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition getMergedBeanDefinition() {
/* 190 */     return this.mergedBeanDefinition.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInnerBean() {
/* 198 */     return (this.parent != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public RegisteredBean getParent() {
/* 207 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1.7")
/*     */   public Executable resolveConstructorOrFactoryMethod() {
/* 217 */     return (new ConstructorResolver((AbstractAutowireCapableBeanFactory)getBeanFactory()))
/* 218 */       .resolveConstructorOrFactoryMethod(getBeanName(), getMergedBeanDefinition());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstantiationDescriptor resolveInstantiationDescriptor() {
/* 228 */     Executable executable = resolveConstructorOrFactoryMethod();
/* 229 */     if (executable instanceof Method) { Method method = (Method)executable; if (!Modifier.isStatic(method.getModifiers())) {
/* 230 */         String factoryBeanName = getMergedBeanDefinition().getFactoryBeanName();
/* 231 */         if (factoryBeanName != null && this.beanFactory.containsBean(factoryBeanName))
/* 232 */           return new InstantiationDescriptor(executable, this.beanFactory
/* 233 */               .getMergedBeanDefinition(factoryBeanName).getResolvableType().toClass()); 
/*     */       }  }
/*     */     
/* 236 */     return new InstantiationDescriptor(executable, executable.getDeclaringClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveAutowiredArgument(DependencyDescriptor descriptor, TypeConverter typeConverter, Set<String> autowiredBeanNames) {
/* 252 */     return (new ConstructorResolver((AbstractAutowireCapableBeanFactory)getBeanFactory()))
/* 253 */       .resolveAutowiredArgument(descriptor, descriptor.getDependencyType(), 
/* 254 */         getBeanName(), autowiredBeanNames, typeConverter, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 260 */     return (new ToStringCreator(this)).append("beanName", getBeanName())
/* 261 */       .append("mergedBeanDefinition", getMergedBeanDefinition()).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class InstantiationDescriptor
/*     */     extends Record
/*     */   {
/*     */     private final Executable executable;
/*     */     
/*     */     private final Class<?> targetClass;
/*     */ 
/*     */     
/*     */     public Class<?> targetClass()
/*     */     {
/* 275 */       return this.targetClass; } public Executable executable() { return this.executable; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/beans/factory/support/RegisteredBean$InstantiationDescriptor;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #275	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/beans/factory/support/RegisteredBean$InstantiationDescriptor;
/* 275 */       //   0	8	1	o	Ljava/lang/Object; } public InstantiationDescriptor(Executable executable, Class<?> targetClass) { this.executable = executable; this.targetClass = targetClass; }
/*     */     public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/beans/factory/support/RegisteredBean$InstantiationDescriptor;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #275	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/support/RegisteredBean$InstantiationDescriptor; }
/*     */     public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/beans/factory/support/RegisteredBean$InstantiationDescriptor;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #275	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/support/RegisteredBean$InstantiationDescriptor; } public InstantiationDescriptor(Executable executable) {
/* 278 */       this(executable, executable.getDeclaringClass());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class InnerBeanResolver
/*     */   {
/*     */     private final RegisteredBean parent;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final String innerBeanName;
/*     */     
/*     */     private final BeanDefinition innerBeanDefinition;
/*     */     
/*     */     @Nullable
/*     */     private volatile String resolvedBeanName;
/*     */ 
/*     */     
/*     */     InnerBeanResolver(RegisteredBean parent, @Nullable String innerBeanName, BeanDefinition innerBeanDefinition) {
/* 299 */       Assert.isInstanceOf(AbstractAutowireCapableBeanFactory.class, parent.getBeanFactory());
/* 300 */       this.parent = parent;
/* 301 */       this.innerBeanName = innerBeanName;
/* 302 */       this.innerBeanDefinition = innerBeanDefinition;
/*     */     }
/*     */     
/*     */     String resolveBeanName() {
/* 306 */       String resolvedBeanName = this.resolvedBeanName;
/* 307 */       if (resolvedBeanName != null) {
/* 308 */         return resolvedBeanName;
/*     */       }
/* 310 */       resolvedBeanName = resolveInnerBean((beanName, mergedBeanDefinition) -> beanName);
/* 311 */       this.resolvedBeanName = resolvedBeanName;
/* 312 */       return resolvedBeanName;
/*     */     }
/*     */     
/*     */     RootBeanDefinition resolveMergedBeanDefinition() {
/* 316 */       return resolveInnerBean((beanName, mergedBeanDefinition) -> mergedBeanDefinition);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private <T> T resolveInnerBean(BiFunction<String, RootBeanDefinition, T> resolver) {
/* 323 */       BeanDefinitionValueResolver beanDefinitionValueResolver = new BeanDefinitionValueResolver((AbstractAutowireCapableBeanFactory)this.parent.getBeanFactory(), this.parent.getBeanName(), this.parent.getMergedBeanDefinition());
/* 324 */       return beanDefinitionValueResolver.resolveInnerBean(this.innerBeanName, this.innerBeanDefinition, resolver);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\RegisteredBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */