/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LookupOverride
/*     */   extends MethodOverride
/*     */ {
/*     */   @Nullable
/*     */   private final String beanName;
/*     */   @Nullable
/*     */   private Method method;
/*     */   
/*     */   public LookupOverride(String methodName, @Nullable String beanName) {
/*  58 */     super(methodName);
/*  59 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LookupOverride(Method method, @Nullable String beanName) {
/*  69 */     super(method.getName());
/*  70 */     this.method = method;
/*  71 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getBeanName() {
/*  80 */     return this.beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Method method) {
/*  93 */     if (this.method != null) {
/*  94 */       return method.equals(this.method);
/*     */     }
/*     */     
/*  97 */     return (method.getName().equals(getMethodName()) && (!isOverloaded() || 
/*  98 */       Modifier.isAbstract(method.getModifiers()) || method.getParameterCount() == 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: instanceof org/springframework/beans/factory/support/LookupOverride
/*     */     //   4: ifeq -> 52
/*     */     //   7: aload_1
/*     */     //   8: checkcast org/springframework/beans/factory/support/LookupOverride
/*     */     //   11: astore_2
/*     */     //   12: aload_0
/*     */     //   13: aload_1
/*     */     //   14: invokespecial equals : (Ljava/lang/Object;)Z
/*     */     //   17: ifeq -> 52
/*     */     //   20: aload_0
/*     */     //   21: getfield method : Ljava/lang/reflect/Method;
/*     */     //   24: aload_2
/*     */     //   25: getfield method : Ljava/lang/reflect/Method;
/*     */     //   28: invokestatic nullSafeEquals : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   31: ifeq -> 52
/*     */     //   34: aload_0
/*     */     //   35: getfield beanName : Ljava/lang/String;
/*     */     //   38: aload_2
/*     */     //   39: getfield beanName : Ljava/lang/String;
/*     */     //   42: invokestatic nullSafeEquals : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   45: ifeq -> 52
/*     */     //   48: iconst_1
/*     */     //   49: goto -> 53
/*     */     //   52: iconst_0
/*     */     //   53: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #106	-> 0
/*     */     //   #105	-> 7
/*     */     //   #106	-> 28
/*     */     //   #107	-> 42
/*     */     //   #105	-> 53
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   12	40	2	that	Lorg/springframework/beans/factory/support/LookupOverride;
/*     */     //   0	54	0	this	Lorg/springframework/beans/factory/support/LookupOverride;
/*     */     //   0	54	1	other	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 112 */     return super.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     return "LookupOverride for method '" + getMethodName() + "'";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\LookupOverride.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */