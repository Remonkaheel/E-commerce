/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.cglib.core.ClassLoaderAwareGeneratorStrategy;
/*     */ import org.springframework.cglib.core.GeneratorStrategy;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CglibSubclassCreator
/*     */ {
/* 103 */   private static final Class<?>[] CALLBACK_TYPES = new Class[] { NoOp.class, CglibSubclassingInstantiationStrategy.LookupOverrideMethodInterceptor.class, CglibSubclassingInstantiationStrategy.ReplaceOverrideMethodInterceptor.class };
/*     */   
/*     */   private final RootBeanDefinition beanDefinition;
/*     */   
/*     */   private final BeanFactory owner;
/*     */ 
/*     */   
/*     */   CglibSubclassCreator(RootBeanDefinition beanDefinition, BeanFactory owner) {
/* 111 */     this.beanDefinition = beanDefinition;
/* 112 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object instantiate(@Nullable Constructor<?> ctor, Object... args) {
/*     */     Object instance;
/* 125 */     Class<?> subclass = createEnhancedSubclass(this.beanDefinition);
/*     */     
/* 127 */     if (ctor == null) {
/* 128 */       instance = BeanUtils.instantiateClass(subclass);
/*     */     } else {
/*     */       
/*     */       try {
/* 132 */         Constructor<?> enhancedSubclassConstructor = subclass.getConstructor(ctor.getParameterTypes());
/* 133 */         instance = enhancedSubclassConstructor.newInstance(args);
/*     */       }
/* 135 */       catch (Exception ex) {
/* 136 */         throw new BeanInstantiationException(this.beanDefinition.getBeanClass(), "Failed to invoke constructor for CGLIB enhanced subclass [" + subclass
/* 137 */             .getName() + "]", ex);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 142 */     Factory factory = (Factory)instance;
/* 143 */     factory.setCallbacks(new Callback[] { (Callback)NoOp.INSTANCE, (Callback)new CglibSubclassingInstantiationStrategy.LookupOverrideMethodInterceptor(this.beanDefinition, this.owner), (Callback)new CglibSubclassingInstantiationStrategy.ReplaceOverrideMethodInterceptor(this.beanDefinition, this.owner) });
/*     */ 
/*     */     
/* 146 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> createEnhancedSubclass(RootBeanDefinition beanDefinition) {
/* 154 */     Enhancer enhancer = new Enhancer();
/* 155 */     enhancer.setSuperclass(beanDefinition.getBeanClass());
/* 156 */     enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 157 */     enhancer.setAttemptLoad(AotDetector.useGeneratedArtifacts());
/* 158 */     BeanFactory beanFactory = this.owner; if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/* 159 */       ClassLoader cl = cbf.getBeanClassLoader();
/* 160 */       enhancer.setStrategy((GeneratorStrategy)new ClassLoaderAwareGeneratorStrategy(cl)); }
/*     */     
/* 162 */     enhancer.setCallbackFilter(new CglibSubclassingInstantiationStrategy.MethodOverrideCallbackFilter(beanDefinition));
/* 163 */     enhancer.setCallbackTypes(CALLBACK_TYPES);
/* 164 */     return enhancer.createClass();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\CglibSubclassingInstantiationStrategy$CglibSubclassCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */