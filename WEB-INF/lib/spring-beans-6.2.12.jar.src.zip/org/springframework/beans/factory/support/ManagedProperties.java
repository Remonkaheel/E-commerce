/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.beans.Mergeable;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagedProperties
/*    */   extends Properties
/*    */   implements Mergeable, BeanMetadataElement
/*    */ {
/*    */   @Nullable
/*    */   private Object source;
/*    */   private boolean mergeEnabled;
/*    */   
/*    */   public void setSource(@Nullable Object source) {
/* 47 */     this.source = source;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getSource() {
/* 53 */     return this.source;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMergeEnabled(boolean mergeEnabled) {
/* 61 */     this.mergeEnabled = mergeEnabled;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isMergeEnabled() {
/* 66 */     return this.mergeEnabled;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object merge(@Nullable Object parent) {
/*    */     Properties properties;
/* 72 */     if (!this.mergeEnabled) {
/* 73 */       throw new IllegalStateException("Not allowed to merge when the 'mergeEnabled' property is set to 'false'");
/*    */     }
/* 75 */     if (parent == null) {
/* 76 */       return this;
/*    */     }
/* 78 */     if (parent instanceof Properties) { properties = (Properties)parent; }
/* 79 */     else { throw new IllegalArgumentException("Cannot merge with object of type [" + String.valueOf(parent.getClass()) + "]"); }
/*    */     
/* 81 */     Properties merged = new ManagedProperties();
/* 82 */     merged.putAll(properties);
/* 83 */     merged.putAll(this);
/* 84 */     return merged;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\ManagedProperties.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */