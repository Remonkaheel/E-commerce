/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.config.AutowiredPropertyMarker;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionCustomizer;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BeanDefinitionBuilder
/*     */ {
/*     */   private final AbstractBeanDefinition beanDefinition;
/*     */   private int constructorArgIndex;
/*     */   
/*     */   public static BeanDefinitionBuilder genericBeanDefinition() {
/*  46 */     return new BeanDefinitionBuilder(new GenericBeanDefinition());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder genericBeanDefinition(String beanClassName) {
/*  54 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder(new GenericBeanDefinition());
/*  55 */     builder.beanDefinition.setBeanClassName(beanClassName);
/*  56 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder genericBeanDefinition(Class<?> beanClass) {
/*  64 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder(new GenericBeanDefinition());
/*  65 */     builder.beanDefinition.setBeanClass(beanClass);
/*  66 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanDefinitionBuilder genericBeanDefinition(Class<T> beanClass, Supplier<T> instanceSupplier) {
/*  76 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder(new GenericBeanDefinition());
/*  77 */     builder.beanDefinition.setBeanClass(beanClass);
/*  78 */     builder.beanDefinition.setInstanceSupplier(instanceSupplier);
/*  79 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(String beanClassName) {
/*  87 */     return rootBeanDefinition(beanClassName, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(String beanClassName, @Nullable String factoryMethodName) {
/*  96 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder(new RootBeanDefinition());
/*  97 */     builder.beanDefinition.setBeanClassName(beanClassName);
/*  98 */     builder.beanDefinition.setFactoryMethodName(factoryMethodName);
/*  99 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(Class<?> beanClass) {
/* 107 */     return rootBeanDefinition(beanClass, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder rootBeanDefinition(Class<?> beanClass, @Nullable String factoryMethodName) {
/* 116 */     BeanDefinitionBuilder builder = new BeanDefinitionBuilder(new RootBeanDefinition());
/* 117 */     builder.beanDefinition.setBeanClass(beanClass);
/* 118 */     builder.beanDefinition.setFactoryMethodName(factoryMethodName);
/* 119 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanDefinitionBuilder rootBeanDefinition(ResolvableType beanType, Supplier<T> instanceSupplier) {
/* 129 */     RootBeanDefinition beanDefinition = new RootBeanDefinition();
/* 130 */     beanDefinition.setTargetType(beanType);
/* 131 */     beanDefinition.setInstanceSupplier(instanceSupplier);
/* 132 */     return new BeanDefinitionBuilder(beanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanDefinitionBuilder rootBeanDefinition(Class<T> beanClass, Supplier<T> instanceSupplier) {
/* 143 */     return rootBeanDefinition(ResolvableType.forClass(beanClass), instanceSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionBuilder childBeanDefinition(String parentName) {
/* 151 */     return new BeanDefinitionBuilder(new ChildBeanDefinition(parentName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanDefinitionBuilder(AbstractBeanDefinition beanDefinition) {
/* 170 */     this.beanDefinition = beanDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractBeanDefinition getRawBeanDefinition() {
/* 178 */     return this.beanDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractBeanDefinition getBeanDefinition() {
/* 185 */     this.beanDefinition.validate();
/* 186 */     return this.beanDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setParentName(String parentName) {
/* 194 */     this.beanDefinition.setParentName(parentName);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setFactoryMethod(String factoryMethod) {
/* 203 */     this.beanDefinition.setFactoryMethodName(factoryMethod);
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setFactoryMethodOnBean(String factoryMethod, String factoryBean) {
/* 215 */     this.beanDefinition.setFactoryMethodName(factoryMethod);
/* 216 */     this.beanDefinition.setFactoryBeanName(factoryBean);
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder addConstructorArgValue(@Nullable Object value) {
/* 225 */     this.beanDefinition.getConstructorArgumentValues().addIndexedArgumentValue(this.constructorArgIndex++, value);
/*     */     
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder addConstructorArgReference(String beanName) {
/* 235 */     this.beanDefinition.getConstructorArgumentValues().addIndexedArgumentValue(this.constructorArgIndex++, new RuntimeBeanReference(beanName));
/*     */     
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder addPropertyValue(String name, @Nullable Object value) {
/* 244 */     this.beanDefinition.getPropertyValues().add(name, value);
/* 245 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder addPropertyReference(String name, String beanName) {
/* 254 */     this.beanDefinition.getPropertyValues().add(name, new RuntimeBeanReference(beanName));
/* 255 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder addAutowiredProperty(String name) {
/* 265 */     this.beanDefinition.getPropertyValues().add(name, AutowiredPropertyMarker.INSTANCE);
/* 266 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setInitMethodName(@Nullable String methodName) {
/* 273 */     this.beanDefinition.setInitMethodName(methodName);
/* 274 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setDestroyMethodName(@Nullable String methodName) {
/* 281 */     this.beanDefinition.setDestroyMethodName(methodName);
/* 282 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setScope(@Nullable String scope) {
/* 292 */     this.beanDefinition.setScope(scope);
/* 293 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setAbstract(boolean flag) {
/* 300 */     this.beanDefinition.setAbstract(flag);
/* 301 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setLazyInit(boolean lazy) {
/* 308 */     this.beanDefinition.setLazyInit(lazy);
/* 309 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setAutowireMode(int autowireMode) {
/* 316 */     this.beanDefinition.setAutowireMode(autowireMode);
/* 317 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setDependencyCheck(int dependencyCheck) {
/* 324 */     this.beanDefinition.setDependencyCheck(dependencyCheck);
/* 325 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder addDependsOn(String beanName) {
/* 333 */     if (this.beanDefinition.getDependsOn() == null) {
/* 334 */       this.beanDefinition.setDependsOn(new String[] { beanName });
/*     */     } else {
/*     */       
/* 337 */       String[] added = (String[])ObjectUtils.addObjectToArray((Object[])this.beanDefinition.getDependsOn(), beanName);
/* 338 */       this.beanDefinition.setDependsOn(added);
/*     */     } 
/* 340 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setPrimary(boolean primary) {
/* 348 */     this.beanDefinition.setPrimary(primary);
/* 349 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setFallback(boolean fallback) {
/* 357 */     this.beanDefinition.setFallback(fallback);
/* 358 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setRole(int role) {
/* 365 */     this.beanDefinition.setRole(role);
/* 366 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder setSynthetic(boolean synthetic) {
/* 375 */     this.beanDefinition.setSynthetic(synthetic);
/* 376 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder applyCustomizers(BeanDefinitionCustomizer... customizers) {
/* 384 */     for (BeanDefinitionCustomizer customizer : customizers) {
/* 385 */       customizer.customize(this.beanDefinition);
/*     */     }
/* 387 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\BeanDefinitionBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */