package org.springframework.beans.factory.support;

import java.io.Serializable;
import org.springframework.beans.factory.ObjectProvider;

interface BeanObjectProvider<T> extends ObjectProvider<T>, Serializable {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\DefaultListableBeanFactory$BeanObjectProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */