/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.beans.ConstructorProperties;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Executable;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Deque;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeanWrapper;
/*      */ import org.springframework.beans.BeanWrapperImpl;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.TypeMismatchException;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.InjectionPoint;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*      */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanReference;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*      */ import org.springframework.beans.factory.config.TypedStringValue;
/*      */ import org.springframework.core.CollectionFactory;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.core.NamedThreadLocal;
/*      */ import org.springframework.core.ParameterNameDiscoverer;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.MethodInvoker;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ConstructorResolver
/*      */ {
/*  101 */   private static final Object[] EMPTY_ARGS = new Object[0];
/*      */   
/*  103 */   private static final NamedThreadLocal<InjectionPoint> currentInjectionPoint = new NamedThreadLocal("Current injection point");
/*      */ 
/*      */ 
/*      */   
/*      */   private final AbstractAutowireCapableBeanFactory beanFactory;
/*      */ 
/*      */ 
/*      */   
/*      */   private final Log logger;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorResolver(AbstractAutowireCapableBeanFactory beanFactory) {
/*  117 */     this.beanFactory = beanFactory;
/*  118 */     this.logger = beanFactory.getLogger();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanWrapper autowireConstructor(String beanName, RootBeanDefinition mbd, @Nullable Constructor<?>[] chosenCtors, @Nullable Object[] explicitArgs) {
/*  138 */     BeanWrapperImpl bw = new BeanWrapperImpl();
/*  139 */     this.beanFactory.initBeanWrapper((BeanWrapper)bw);
/*      */     
/*  141 */     Constructor<?> constructorToUse = null;
/*  142 */     ArgumentsHolder argsHolderToUse = null;
/*  143 */     Object[] argsToUse = null;
/*      */     
/*  145 */     if (explicitArgs != null) {
/*  146 */       argsToUse = explicitArgs;
/*      */     } else {
/*      */       
/*  149 */       Object[] argsToResolve = null;
/*  150 */       synchronized (mbd.constructorArgumentLock) {
/*  151 */         constructorToUse = (Constructor)mbd.resolvedConstructorOrFactoryMethod;
/*  152 */         if (constructorToUse != null && mbd.constructorArgumentsResolved) {
/*      */           
/*  154 */           argsToUse = mbd.resolvedConstructorArguments;
/*  155 */           if (argsToUse == null) {
/*  156 */             argsToResolve = mbd.preparedConstructorArguments;
/*      */           }
/*      */         } 
/*      */       } 
/*  160 */       if (argsToResolve != null) {
/*  161 */         argsToUse = resolvePreparedArguments(beanName, mbd, (BeanWrapper)bw, constructorToUse, argsToResolve);
/*      */       }
/*      */     } 
/*      */     
/*  165 */     if (constructorToUse == null || argsToUse == null) {
/*      */       int minNrOfArgs;
/*  167 */       Constructor<?>[] candidates = chosenCtors;
/*  168 */       if (candidates == null) {
/*  169 */         Class<?> beanClass = mbd.getBeanClass();
/*      */         
/*      */         try {
/*  172 */           candidates = mbd.isNonPublicAccessAllowed() ? beanClass.getDeclaredConstructors() : beanClass.getConstructors();
/*      */         }
/*  174 */         catch (Throwable ex) {
/*  175 */           throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Resolution of declared constructors on bean Class [" + beanClass
/*  176 */               .getName() + "] from ClassLoader [" + 
/*  177 */               String.valueOf(beanClass.getClassLoader()) + "] failed", ex);
/*      */         } 
/*      */       } 
/*      */       
/*  181 */       if (candidates.length == 1 && explicitArgs == null && !mbd.hasConstructorArgumentValues()) {
/*  182 */         Constructor<?> uniqueCandidate = candidates[0];
/*  183 */         if (uniqueCandidate.getParameterCount() == 0) {
/*  184 */           synchronized (mbd.constructorArgumentLock) {
/*  185 */             mbd.resolvedConstructorOrFactoryMethod = uniqueCandidate;
/*  186 */             mbd.constructorArgumentsResolved = true;
/*  187 */             mbd.resolvedConstructorArguments = EMPTY_ARGS;
/*      */           } 
/*  189 */           bw.setBeanInstance(instantiate(beanName, mbd, uniqueCandidate, EMPTY_ARGS));
/*  190 */           return (BeanWrapper)bw;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  196 */       boolean autowiring = (chosenCtors != null || mbd.getResolvedAutowireMode() == 3);
/*  197 */       ConstructorArgumentValues resolvedValues = null;
/*      */ 
/*      */       
/*  200 */       if (explicitArgs != null) {
/*  201 */         minNrOfArgs = explicitArgs.length;
/*      */       } else {
/*      */         
/*  204 */         ConstructorArgumentValues cargs = mbd.getConstructorArgumentValues();
/*  205 */         resolvedValues = new ConstructorArgumentValues();
/*  206 */         minNrOfArgs = resolveConstructorArguments(beanName, mbd, (BeanWrapper)bw, cargs, resolvedValues);
/*      */       } 
/*      */       
/*  209 */       AutowireUtils.sortConstructors(candidates);
/*  210 */       int minTypeDiffWeight = Integer.MAX_VALUE;
/*  211 */       Set<Constructor<?>> ambiguousConstructors = null;
/*  212 */       Deque<UnsatisfiedDependencyException> causes = null;
/*      */       
/*  214 */       for (Constructor<?> candidate : candidates) {
/*  215 */         ArgumentsHolder argsHolder; int parameterCount = candidate.getParameterCount();
/*      */         
/*  217 */         if (constructorToUse != null && argsToUse != null && argsToUse.length > parameterCount) {
/*      */           break;
/*      */         }
/*      */ 
/*      */         
/*  222 */         if (parameterCount < minNrOfArgs) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/*  227 */         Class<?>[] paramTypes = candidate.getParameterTypes();
/*  228 */         if (resolvedValues != null) {
/*      */           try {
/*  230 */             String[] paramNames = null;
/*  231 */             if (resolvedValues.containsNamedArgument()) {
/*  232 */               paramNames = ConstructorPropertiesChecker.evaluate(candidate, parameterCount);
/*  233 */               if (paramNames == null) {
/*  234 */                 ParameterNameDiscoverer pnd = this.beanFactory.getParameterNameDiscoverer();
/*  235 */                 if (pnd != null) {
/*  236 */                   paramNames = pnd.getParameterNames(candidate);
/*      */                 }
/*      */               } 
/*      */             } 
/*  240 */             argsHolder = createArgumentArray(beanName, mbd, resolvedValues, (BeanWrapper)bw, paramTypes, paramNames, 
/*  241 */                 getUserDeclaredConstructor(candidate), autowiring, (candidates.length == 1));
/*      */           }
/*  243 */           catch (UnsatisfiedDependencyException ex) {
/*  244 */             if (this.logger.isTraceEnabled()) {
/*  245 */               this.logger.trace("Ignoring constructor [" + String.valueOf(candidate) + "] of bean '" + beanName + "': " + String.valueOf(ex));
/*      */             }
/*      */             
/*  248 */             if (causes == null) {
/*  249 */               causes = new ArrayDeque<>(1);
/*      */             }
/*  251 */             causes.add(ex);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  257 */           if (parameterCount != explicitArgs.length) {
/*      */             continue;
/*      */           }
/*  260 */           argsHolder = new ArgumentsHolder(explicitArgs);
/*      */         } 
/*      */ 
/*      */         
/*  264 */         int typeDiffWeight = mbd.isLenientConstructorResolution() ? argsHolder.getTypeDifferenceWeight(paramTypes) : argsHolder.getAssignabilityWeight(paramTypes);
/*      */         
/*  266 */         if (typeDiffWeight < minTypeDiffWeight) {
/*  267 */           constructorToUse = candidate;
/*  268 */           argsHolderToUse = argsHolder;
/*  269 */           argsToUse = argsHolder.arguments;
/*  270 */           minTypeDiffWeight = typeDiffWeight;
/*  271 */           ambiguousConstructors = null;
/*      */         }
/*  273 */         else if (constructorToUse != null && typeDiffWeight == minTypeDiffWeight) {
/*  274 */           if (ambiguousConstructors == null) {
/*  275 */             ambiguousConstructors = new LinkedHashSet<>();
/*  276 */             ambiguousConstructors.add(constructorToUse);
/*      */           } 
/*  278 */           ambiguousConstructors.add(candidate);
/*      */         } 
/*      */         continue;
/*      */       } 
/*  282 */       if (constructorToUse == null) {
/*  283 */         if (causes != null) {
/*  284 */           UnsatisfiedDependencyException ex = causes.removeLast();
/*  285 */           for (Exception cause : causes) {
/*  286 */             this.beanFactory.onSuppressedException(cause);
/*      */           }
/*  288 */           throw ex;
/*      */         } 
/*  290 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Could not resolve matching constructor on bean class [" + mbd
/*  291 */             .getBeanClassName() + "] (hint: specify index/type/name arguments for simple parameters to avoid type ambiguities. You should also check the consistency of arguments when mixing indexed and named arguments, especially in case of bean definition inheritance)");
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  296 */       if (ambiguousConstructors != null && !mbd.isLenientConstructorResolution()) {
/*  297 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Ambiguous constructor matches found on bean class [" + mbd
/*  298 */             .getBeanClassName() + "] (hint: specify index/type/name arguments for simple parameters to avoid type ambiguities): " + String.valueOf(ambiguousConstructors));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  303 */       if (explicitArgs == null && argsHolderToUse != null) {
/*  304 */         argsHolderToUse.storeCache(mbd, constructorToUse);
/*      */       }
/*      */     } 
/*      */     
/*  308 */     Assert.state((argsToUse != null), "Unresolved constructor arguments");
/*  309 */     bw.setBeanInstance(instantiate(beanName, mbd, constructorToUse, argsToUse));
/*  310 */     return (BeanWrapper)bw;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object instantiate(String beanName, RootBeanDefinition mbd, Constructor<?> constructorToUse, Object[] argsToUse) {
/*      */     try {
/*  317 */       InstantiationStrategy strategy = this.beanFactory.getInstantiationStrategy();
/*  318 */       return strategy.instantiate(mbd, beanName, (BeanFactory)this.beanFactory, constructorToUse, argsToUse);
/*      */     }
/*  320 */     catch (Throwable ex) {
/*  321 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, ex.getMessage(), ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolveFactoryMethodIfPossible(RootBeanDefinition mbd) {
/*      */     boolean isStatic;
/*  333 */     if (mbd.getFactoryBeanName() != null) {
/*  334 */       factoryClass = this.beanFactory.getType(mbd.getFactoryBeanName());
/*  335 */       isStatic = false;
/*      */     } else {
/*      */       
/*  338 */       factoryClass = mbd.getBeanClass();
/*  339 */       isStatic = true;
/*      */     } 
/*  341 */     Assert.state((factoryClass != null), "Unresolvable factory class");
/*  342 */     Class<?> factoryClass = ClassUtils.getUserClass(factoryClass);
/*      */     
/*  344 */     Method[] candidates = getCandidateMethods(factoryClass, mbd);
/*  345 */     Method uniqueCandidate = null;
/*  346 */     for (Method candidate : candidates) {
/*  347 */       if ((!isStatic || isStaticCandidate(candidate, factoryClass)) && mbd.isFactoryMethod(candidate)) {
/*  348 */         if (uniqueCandidate == null) {
/*  349 */           uniqueCandidate = candidate;
/*      */         }
/*  351 */         else if (isParamMismatch(uniqueCandidate, candidate)) {
/*  352 */           uniqueCandidate = null;
/*      */           break;
/*      */         } 
/*      */       }
/*      */     } 
/*  357 */     mbd.factoryMethodToIntrospect = uniqueCandidate;
/*      */   }
/*      */   
/*      */   private boolean isParamMismatch(Method uniqueCandidate, Method candidate) {
/*  361 */     int uniqueCandidateParameterCount = uniqueCandidate.getParameterCount();
/*  362 */     int candidateParameterCount = candidate.getParameterCount();
/*  363 */     return (uniqueCandidateParameterCount != candidateParameterCount || 
/*  364 */       !Arrays.equals((Object[])uniqueCandidate.getParameterTypes(), (Object[])candidate.getParameterTypes()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Method[] getCandidateMethods(Class<?> factoryClass, RootBeanDefinition mbd) {
/*  373 */     return mbd.isNonPublicAccessAllowed() ? 
/*  374 */       ReflectionUtils.getUniqueDeclaredMethods(factoryClass) : factoryClass.getMethods();
/*      */   }
/*      */   
/*      */   private boolean isStaticCandidate(Method method, Class<?> factoryClass) {
/*  378 */     return (Modifier.isStatic(method.getModifiers()) && method.getDeclaringClass() == factoryClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanWrapper instantiateUsingFactoryMethod(String beanName, RootBeanDefinition mbd, @Nullable Object[] explicitArgs) {
/*      */     Object factoryBean;
/*      */     Class<?> factoryClass;
/*      */     boolean isStatic;
/*  400 */     BeanWrapperImpl bw = new BeanWrapperImpl();
/*  401 */     this.beanFactory.initBeanWrapper((BeanWrapper)bw);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  407 */     String factoryBeanName = mbd.getFactoryBeanName();
/*  408 */     if (factoryBeanName != null) {
/*  409 */       if (factoryBeanName.equals(beanName)) {
/*  410 */         throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "factory-bean reference points back to the same bean definition");
/*      */       }
/*      */       
/*  413 */       factoryBean = this.beanFactory.getBean(factoryBeanName);
/*  414 */       if (mbd.isSingleton() && this.beanFactory.containsSingleton(beanName)) {
/*  415 */         throw new ImplicitlyAppearedSingletonException();
/*      */       }
/*  417 */       this.beanFactory.registerDependentBean(factoryBeanName, beanName);
/*  418 */       factoryClass = factoryBean.getClass();
/*  419 */       isStatic = false;
/*      */     }
/*      */     else {
/*      */       
/*  423 */       if (!mbd.hasBeanClass()) {
/*  424 */         throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "bean definition declares neither a bean class nor a factory-bean reference");
/*      */       }
/*      */       
/*  427 */       factoryBean = null;
/*  428 */       factoryClass = mbd.getBeanClass();
/*  429 */       isStatic = true;
/*      */     } 
/*      */     
/*  432 */     Method factoryMethodToUse = null;
/*  433 */     ArgumentsHolder argsHolderToUse = null;
/*  434 */     Object[] argsToUse = null;
/*      */     
/*  436 */     if (explicitArgs != null) {
/*  437 */       argsToUse = explicitArgs;
/*      */     } else {
/*      */       
/*  440 */       Object[] argsToResolve = null;
/*  441 */       synchronized (mbd.constructorArgumentLock) {
/*  442 */         factoryMethodToUse = (Method)mbd.resolvedConstructorOrFactoryMethod;
/*  443 */         if (factoryMethodToUse != null && mbd.constructorArgumentsResolved) {
/*      */           
/*  445 */           argsToUse = mbd.resolvedConstructorArguments;
/*  446 */           if (argsToUse == null) {
/*  447 */             argsToResolve = mbd.preparedConstructorArguments;
/*      */           }
/*      */         } 
/*      */       } 
/*  451 */       if (argsToResolve != null) {
/*  452 */         argsToUse = resolvePreparedArguments(beanName, mbd, (BeanWrapper)bw, factoryMethodToUse, argsToResolve);
/*      */       }
/*      */     } 
/*      */     
/*  456 */     if (factoryMethodToUse == null || argsToUse == null) {
/*      */       int minNrOfArgs;
/*      */       
/*  459 */       factoryClass = ClassUtils.getUserClass(factoryClass);
/*      */       
/*  461 */       List<Method> candidates = null;
/*  462 */       if (mbd.isFactoryMethodUnique) {
/*  463 */         if (factoryMethodToUse == null) {
/*  464 */           factoryMethodToUse = mbd.getResolvedFactoryMethod();
/*      */         }
/*  466 */         if (factoryMethodToUse != null) {
/*  467 */           candidates = Collections.singletonList(factoryMethodToUse);
/*      */         }
/*      */       } 
/*  470 */       if (candidates == null) {
/*  471 */         candidates = new ArrayList<>();
/*  472 */         Method[] rawCandidates = getCandidateMethods(factoryClass, mbd);
/*  473 */         for (Method candidate : rawCandidates) {
/*  474 */           if ((!isStatic || isStaticCandidate(candidate, factoryClass)) && mbd.isFactoryMethod(candidate)) {
/*  475 */             candidates.add(candidate);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  480 */       if (candidates.size() == 1 && explicitArgs == null && !mbd.hasConstructorArgumentValues()) {
/*  481 */         Method uniqueCandidate = candidates.get(0);
/*  482 */         if (uniqueCandidate.getParameterCount() == 0) {
/*  483 */           mbd.factoryMethodToIntrospect = uniqueCandidate;
/*  484 */           synchronized (mbd.constructorArgumentLock) {
/*  485 */             mbd.resolvedConstructorOrFactoryMethod = uniqueCandidate;
/*  486 */             mbd.constructorArgumentsResolved = true;
/*  487 */             mbd.resolvedConstructorArguments = EMPTY_ARGS;
/*      */           } 
/*  489 */           bw.setBeanInstance(instantiate(beanName, mbd, factoryBean, uniqueCandidate, EMPTY_ARGS));
/*  490 */           return (BeanWrapper)bw;
/*      */         } 
/*      */       } 
/*      */       
/*  494 */       if (candidates.size() > 1) {
/*  495 */         candidates.sort(AutowireUtils.EXECUTABLE_COMPARATOR);
/*      */       }
/*      */       
/*  498 */       ConstructorArgumentValues resolvedValues = null;
/*  499 */       boolean autowiring = (mbd.getResolvedAutowireMode() == 3);
/*  500 */       int minTypeDiffWeight = Integer.MAX_VALUE;
/*  501 */       Set<Method> ambiguousFactoryMethods = null;
/*      */ 
/*      */       
/*  504 */       if (explicitArgs != null) {
/*  505 */         minNrOfArgs = explicitArgs.length;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  510 */       else if (mbd.hasConstructorArgumentValues()) {
/*  511 */         ConstructorArgumentValues cargs = mbd.getConstructorArgumentValues();
/*  512 */         resolvedValues = new ConstructorArgumentValues();
/*  513 */         minNrOfArgs = resolveConstructorArguments(beanName, mbd, (BeanWrapper)bw, cargs, resolvedValues);
/*      */       } else {
/*      */         
/*  516 */         minNrOfArgs = 0;
/*      */       } 
/*      */ 
/*      */       
/*  520 */       Deque<UnsatisfiedDependencyException> causes = null;
/*      */       
/*  522 */       for (Method candidate : candidates) {
/*  523 */         int parameterCount = candidate.getParameterCount();
/*      */         
/*  525 */         if (parameterCount >= minNrOfArgs) {
/*      */           ArgumentsHolder argsHolder;
/*      */           
/*  528 */           Class<?>[] paramTypes = candidate.getParameterTypes();
/*  529 */           if (explicitArgs != null) {
/*      */             
/*  531 */             if (paramTypes.length != explicitArgs.length) {
/*      */               continue;
/*      */             }
/*  534 */             argsHolder = new ArgumentsHolder(explicitArgs);
/*      */           } else {
/*      */ 
/*      */             
/*      */             try {
/*  539 */               String[] paramNames = null;
/*  540 */               if (resolvedValues != null && resolvedValues.containsNamedArgument()) {
/*  541 */                 ParameterNameDiscoverer pnd = this.beanFactory.getParameterNameDiscoverer();
/*  542 */                 if (pnd != null) {
/*  543 */                   paramNames = pnd.getParameterNames(candidate);
/*      */                 }
/*      */               } 
/*  546 */               argsHolder = createArgumentArray(beanName, mbd, resolvedValues, (BeanWrapper)bw, paramTypes, paramNames, candidate, autowiring, 
/*  547 */                   (candidates.size() == 1));
/*      */             }
/*  549 */             catch (UnsatisfiedDependencyException ex) {
/*  550 */               if (this.logger.isTraceEnabled()) {
/*  551 */                 this.logger.trace("Ignoring factory method [" + String.valueOf(candidate) + "] of bean '" + beanName + "': " + String.valueOf(ex));
/*      */               }
/*      */               
/*  554 */               if (causes == null) {
/*  555 */                 causes = new ArrayDeque<>(1);
/*      */               }
/*  557 */               causes.add(ex);
/*      */               
/*      */               continue;
/*      */             } 
/*      */           } 
/*      */           
/*  563 */           int typeDiffWeight = mbd.isLenientConstructorResolution() ? argsHolder.getTypeDifferenceWeight(paramTypes) : argsHolder.getAssignabilityWeight(paramTypes);
/*      */           
/*  565 */           if (typeDiffWeight < minTypeDiffWeight) {
/*  566 */             factoryMethodToUse = candidate;
/*  567 */             argsHolderToUse = argsHolder;
/*  568 */             argsToUse = argsHolder.arguments;
/*  569 */             minTypeDiffWeight = typeDiffWeight;
/*  570 */             ambiguousFactoryMethods = null;
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */ 
/*      */           
/*  577 */           if (factoryMethodToUse != null && typeDiffWeight == minTypeDiffWeight && 
/*  578 */             !mbd.isLenientConstructorResolution() && paramTypes.length == factoryMethodToUse
/*  579 */             .getParameterCount() && 
/*  580 */             !Arrays.equals((Object[])paramTypes, (Object[])factoryMethodToUse.getParameterTypes())) {
/*  581 */             if (ambiguousFactoryMethods == null) {
/*  582 */               ambiguousFactoryMethods = new LinkedHashSet<>();
/*  583 */               ambiguousFactoryMethods.add(factoryMethodToUse);
/*      */             } 
/*  585 */             ambiguousFactoryMethods.add(candidate);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  590 */       if (factoryMethodToUse == null || argsToUse == null) {
/*  591 */         if (causes != null) {
/*  592 */           UnsatisfiedDependencyException ex = causes.removeLast();
/*  593 */           for (Exception cause : causes) {
/*  594 */             this.beanFactory.onSuppressedException(cause);
/*      */           }
/*  596 */           throw ex;
/*      */         } 
/*  598 */         List<String> argTypes = new ArrayList<>(minNrOfArgs);
/*  599 */         if (explicitArgs != null) {
/*  600 */           for (Object arg : explicitArgs) {
/*  601 */             argTypes.add((arg != null) ? arg.getClass().getSimpleName() : "null");
/*      */           }
/*      */         }
/*  604 */         else if (resolvedValues != null) {
/*  605 */           Set<ConstructorArgumentValues.ValueHolder> valueHolders = CollectionUtils.newLinkedHashSet(resolvedValues.getArgumentCount());
/*  606 */           valueHolders.addAll(resolvedValues.getIndexedArgumentValues().values());
/*  607 */           valueHolders.addAll(resolvedValues.getGenericArgumentValues());
/*  608 */           for (ConstructorArgumentValues.ValueHolder value : valueHolders) {
/*      */             
/*  610 */             String argType = (value.getType() != null) ? ClassUtils.getShortName(value.getType()) : ((value.getValue() != null) ? value.getValue().getClass().getSimpleName() : "null");
/*  611 */             argTypes.add(argType);
/*      */           } 
/*      */         } 
/*  614 */         String argDesc = StringUtils.collectionToCommaDelimitedString(argTypes);
/*  615 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "No matching factory method found on class [" + factoryClass
/*  616 */             .getName() + "]: " + (
/*  617 */             (mbd.getFactoryBeanName() != null) ? ("factory bean '" + mbd.getFactoryBeanName() + "'; ") : "") + "factory method '" + mbd
/*  618 */             .getFactoryMethodName() + "(" + argDesc + ")'. Check that a method with the specified name " + (
/*  619 */             (minNrOfArgs > 0) ? "and arguments " : "") + "exists and that it is " + (
/*  620 */             isStatic ? "static" : "non-static") + ".");
/*      */       } 
/*  622 */       if (void.class == factoryMethodToUse.getReturnType()) {
/*  623 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Invalid factory method '" + mbd
/*  624 */             .getFactoryMethodName() + "' on class [" + factoryClass
/*  625 */             .getName() + "]: needs to have a non-void return type!");
/*      */       }
/*  627 */       if (KotlinDetector.isKotlinPresent() && KotlinDetector.isSuspendingFunction(factoryMethodToUse)) {
/*  628 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Invalid factory method '" + mbd
/*  629 */             .getFactoryMethodName() + "' on class [" + factoryClass
/*  630 */             .getName() + "]: suspending functions are not supported!");
/*      */       }
/*  632 */       if (ambiguousFactoryMethods != null) {
/*  633 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Ambiguous factory method matches found on class [" + factoryClass
/*  634 */             .getName() + "] (hint: specify index/type/name arguments for simple parameters to avoid type ambiguities): " + String.valueOf(ambiguousFactoryMethods));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  639 */       if (explicitArgs == null && argsHolderToUse != null) {
/*  640 */         mbd.factoryMethodToIntrospect = factoryMethodToUse;
/*  641 */         argsHolderToUse.storeCache(mbd, factoryMethodToUse);
/*      */       } 
/*      */     } 
/*      */     
/*  645 */     bw.setBeanInstance(instantiate(beanName, mbd, factoryBean, factoryMethodToUse, argsToUse));
/*  646 */     return (BeanWrapper)bw;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object instantiate(String beanName, RootBeanDefinition mbd, @Nullable Object factoryBean, Method factoryMethod, Object[] args) {
/*      */     try {
/*  653 */       return this.beanFactory.getInstantiationStrategy().instantiate(mbd, beanName, (BeanFactory)this.beanFactory, factoryBean, factoryMethod, args);
/*      */     
/*      */     }
/*  656 */     catch (Throwable ex) {
/*  657 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, ex.getMessage(), ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int resolveConstructorArguments(String beanName, RootBeanDefinition mbd, BeanWrapper bw, ConstructorArgumentValues cargs, ConstructorArgumentValues resolvedValues) {
/*  669 */     TypeConverter customConverter = this.beanFactory.getCustomTypeConverter();
/*  670 */     TypeConverter converter = (customConverter != null) ? customConverter : (TypeConverter)bw;
/*  671 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(this.beanFactory, beanName, mbd, converter);
/*      */ 
/*      */     
/*  674 */     int minNrOfArgs = cargs.getArgumentCount();
/*      */     
/*  676 */     for (Map.Entry<Integer, ConstructorArgumentValues.ValueHolder> entry : (Iterable<Map.Entry<Integer, ConstructorArgumentValues.ValueHolder>>)cargs.getIndexedArgumentValues().entrySet()) {
/*  677 */       int index = ((Integer)entry.getKey()).intValue();
/*  678 */       if (index < 0) {
/*  679 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Invalid constructor argument index: " + index);
/*      */       }
/*      */       
/*  682 */       if (index + 1 > minNrOfArgs) {
/*  683 */         minNrOfArgs = index + 1;
/*      */       }
/*  685 */       ConstructorArgumentValues.ValueHolder valueHolder = entry.getValue();
/*  686 */       if (valueHolder.isConverted()) {
/*  687 */         resolvedValues.addIndexedArgumentValue(index, valueHolder);
/*      */         
/*      */         continue;
/*      */       } 
/*  691 */       Object resolvedValue = valueResolver.resolveValueIfNecessary("constructor argument", valueHolder.getValue());
/*      */       
/*  693 */       ConstructorArgumentValues.ValueHolder resolvedValueHolder = new ConstructorArgumentValues.ValueHolder(resolvedValue, valueHolder.getType(), valueHolder.getName());
/*  694 */       resolvedValueHolder.setSource(valueHolder);
/*  695 */       resolvedValues.addIndexedArgumentValue(index, resolvedValueHolder);
/*      */     } 
/*      */ 
/*      */     
/*  699 */     for (ConstructorArgumentValues.ValueHolder valueHolder : cargs.getGenericArgumentValues()) {
/*  700 */       if (valueHolder.isConverted()) {
/*  701 */         resolvedValues.addGenericArgumentValue(valueHolder);
/*      */         
/*      */         continue;
/*      */       } 
/*  705 */       Object resolvedValue = valueResolver.resolveValueIfNecessary("constructor argument", valueHolder.getValue());
/*      */       
/*  707 */       ConstructorArgumentValues.ValueHolder resolvedValueHolder = new ConstructorArgumentValues.ValueHolder(resolvedValue, valueHolder.getType(), valueHolder.getName());
/*  708 */       resolvedValueHolder.setSource(valueHolder);
/*  709 */       resolvedValues.addGenericArgumentValue(resolvedValueHolder);
/*      */     } 
/*      */ 
/*      */     
/*  713 */     return minNrOfArgs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArgumentsHolder createArgumentArray(String beanName, RootBeanDefinition mbd, @Nullable ConstructorArgumentValues resolvedValues, BeanWrapper bw, Class<?>[] paramTypes, @Nullable String[] paramNames, Executable executable, boolean autowiring, boolean fallback) throws UnsatisfiedDependencyException {
/*  725 */     TypeConverter customConverter = this.beanFactory.getCustomTypeConverter();
/*  726 */     TypeConverter converter = (customConverter != null) ? customConverter : (TypeConverter)bw;
/*      */     
/*  728 */     ArgumentsHolder args = new ArgumentsHolder(paramTypes.length);
/*  729 */     Set<ConstructorArgumentValues.ValueHolder> usedValueHolders = new HashSet<>(paramTypes.length);
/*  730 */     Set<String> allAutowiredBeanNames = new LinkedHashSet<>(paramTypes.length * 2);
/*      */     
/*  732 */     for (int paramIndex = 0; paramIndex < paramTypes.length; paramIndex++) {
/*  733 */       Class<?> paramType = paramTypes[paramIndex];
/*  734 */       String paramName = (paramNames != null) ? paramNames[paramIndex] : "";
/*      */       
/*  736 */       ConstructorArgumentValues.ValueHolder valueHolder = null;
/*  737 */       if (resolvedValues != null) {
/*  738 */         valueHolder = resolvedValues.getArgumentValue(paramIndex, paramType, paramName, usedValueHolders);
/*      */ 
/*      */ 
/*      */         
/*  742 */         if (valueHolder == null && (!autowiring || paramTypes.length == resolvedValues.getArgumentCount())) {
/*  743 */           valueHolder = resolvedValues.getGenericArgumentValue(null, null, usedValueHolders);
/*      */         }
/*      */       } 
/*  746 */       if (valueHolder != null) {
/*      */         Object convertedValue;
/*      */         
/*  749 */         usedValueHolders.add(valueHolder);
/*  750 */         Object originalValue = valueHolder.getValue();
/*      */         
/*  752 */         if (valueHolder.isConverted()) {
/*  753 */           convertedValue = valueHolder.getConvertedValue();
/*  754 */           args.preparedArguments[paramIndex] = convertedValue;
/*      */         } else {
/*      */           
/*  757 */           MethodParameter methodParam = MethodParameter.forExecutable(executable, paramIndex);
/*      */           try {
/*  759 */             convertedValue = converter.convertIfNecessary(originalValue, paramType, methodParam);
/*      */           }
/*  761 */           catch (TypeMismatchException ex) {
/*  762 */             throw new UnsatisfiedDependencyException(mbd
/*  763 */                 .getResourceDescription(), beanName, new InjectionPoint(methodParam), "Could not convert argument value of type [" + 
/*      */                 
/*  765 */                 ObjectUtils.nullSafeClassName(valueHolder.getValue()) + "] to required type [" + paramType
/*  766 */                 .getName() + "]: " + ex.getMessage());
/*      */           } 
/*  768 */           Object sourceHolder = valueHolder.getSource();
/*  769 */           if (sourceHolder instanceof ConstructorArgumentValues.ValueHolder) { ConstructorArgumentValues.ValueHolder constructorValueHolder = (ConstructorArgumentValues.ValueHolder)sourceHolder;
/*  770 */             Object sourceValue = constructorValueHolder.getValue();
/*  771 */             args.resolveNecessary = true;
/*  772 */             args.preparedArguments[paramIndex] = sourceValue; }
/*      */         
/*      */         } 
/*  775 */         args.arguments[paramIndex] = convertedValue;
/*  776 */         args.rawArguments[paramIndex] = originalValue;
/*      */       } else {
/*      */         
/*  779 */         MethodParameter methodParam = MethodParameter.forExecutable(executable, paramIndex);
/*      */ 
/*      */         
/*  782 */         if (!autowiring) {
/*  783 */           throw new UnsatisfiedDependencyException(mbd
/*  784 */               .getResourceDescription(), beanName, new InjectionPoint(methodParam), "Ambiguous argument values for parameter of type [" + paramType
/*  785 */               .getName() + "] - did you specify the correct bean references as arguments?");
/*      */         }
/*      */         
/*      */         try {
/*  789 */           ConstructorDependencyDescriptor desc = new ConstructorDependencyDescriptor(methodParam, true);
/*  790 */           Set<String> autowiredBeanNames = new LinkedHashSet<>(2);
/*  791 */           Object arg = resolveAutowiredArgument(desc, paramType, beanName, autowiredBeanNames, converter, fallback);
/*      */           
/*  793 */           if (arg != null) {
/*  794 */             setShortcutIfPossible(desc, paramType, autowiredBeanNames);
/*      */           }
/*  796 */           allAutowiredBeanNames.addAll(autowiredBeanNames);
/*  797 */           args.rawArguments[paramIndex] = arg;
/*  798 */           args.arguments[paramIndex] = arg;
/*  799 */           args.preparedArguments[paramIndex] = desc;
/*  800 */           args.resolveNecessary = true;
/*      */         }
/*  802 */         catch (BeansException ex) {
/*  803 */           Object convertedValue; throw new UnsatisfiedDependencyException(mbd
/*  804 */               .getResourceDescription(), beanName, new InjectionPoint(methodParam), convertedValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  809 */     registerDependentBeans(executable, beanName, allAutowiredBeanNames);
/*      */     
/*  811 */     return args;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] resolvePreparedArguments(String beanName, RootBeanDefinition mbd, BeanWrapper bw, Executable executable, Object[] argsToResolve) {
/*  820 */     TypeConverter customConverter = this.beanFactory.getCustomTypeConverter();
/*  821 */     TypeConverter converter = (customConverter != null) ? customConverter : (TypeConverter)bw;
/*  822 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(this.beanFactory, beanName, mbd, converter);
/*      */     
/*  824 */     Class<?>[] paramTypes = executable.getParameterTypes();
/*      */     
/*  826 */     Object[] resolvedArgs = new Object[argsToResolve.length];
/*  827 */     for (int argIndex = 0; argIndex < argsToResolve.length; argIndex++) {
/*  828 */       Object argValue = argsToResolve[argIndex];
/*  829 */       Class<?> paramType = paramTypes[argIndex];
/*  830 */       boolean convertNecessary = false;
/*  831 */       if (argValue instanceof ConstructorDependencyDescriptor) { ConstructorDependencyDescriptor descriptor = (ConstructorDependencyDescriptor)argValue;
/*      */         try {
/*  833 */           argValue = resolveAutowiredArgument(descriptor, paramType, beanName, null, converter, true);
/*      */         
/*      */         }
/*  836 */         catch (BeansException ex) {
/*      */           
/*  838 */           Set<String> autowiredBeanNames = null;
/*  839 */           if (descriptor.hasShortcut()) {
/*      */             
/*  841 */             descriptor.setShortcut(null);
/*  842 */             autowiredBeanNames = new LinkedHashSet<>(2);
/*      */           } 
/*  844 */           this.logger.debug("Failed to resolve cached argument", (Throwable)ex);
/*  845 */           argValue = resolveAutowiredArgument(descriptor, paramType, beanName, autowiredBeanNames, converter, true);
/*      */           
/*  847 */           if (autowiredBeanNames != null && !descriptor.hasShortcut())
/*      */           {
/*      */             
/*  850 */             if (argValue != null) {
/*  851 */               setShortcutIfPossible(descriptor, paramType, autowiredBeanNames);
/*      */             }
/*  853 */             registerDependentBeans(executable, beanName, autowiredBeanNames);
/*      */           }
/*      */         
/*      */         }  }
/*  857 */       else if (argValue instanceof org.springframework.beans.BeanMetadataElement)
/*  858 */       { argValue = valueResolver.resolveValueIfNecessary("constructor argument", argValue);
/*  859 */         convertNecessary = true; }
/*      */       
/*  861 */       else if (argValue instanceof String) { String text = (String)argValue;
/*  862 */         argValue = this.beanFactory.evaluateBeanDefinitionString(text, mbd);
/*  863 */         convertNecessary = true; }
/*      */       
/*  865 */       if (convertNecessary) {
/*  866 */         MethodParameter methodParam = MethodParameter.forExecutable(executable, argIndex);
/*      */         try {
/*  868 */           argValue = converter.convertIfNecessary(argValue, paramType, methodParam);
/*      */         }
/*  870 */         catch (TypeMismatchException ex) {
/*  871 */           throw new UnsatisfiedDependencyException(mbd
/*  872 */               .getResourceDescription(), beanName, new InjectionPoint(methodParam), "Could not convert argument value of type [" + 
/*  873 */               ObjectUtils.nullSafeClassName(argValue) + "] to required type [" + paramType
/*  874 */               .getName() + "]: " + ex.getMessage());
/*      */         } 
/*      */       } 
/*  877 */       resolvedArgs[argIndex] = argValue;
/*      */     } 
/*  879 */     return resolvedArgs;
/*      */   }
/*      */   
/*      */   private Constructor<?> getUserDeclaredConstructor(Constructor<?> constructor) {
/*  883 */     Class<?> declaringClass = constructor.getDeclaringClass();
/*  884 */     Class<?> userClass = ClassUtils.getUserClass(declaringClass);
/*  885 */     if (userClass != declaringClass) {
/*      */       try {
/*  887 */         return userClass.getDeclaredConstructor(constructor.getParameterTypes());
/*      */       }
/*  889 */       catch (NoSuchMethodException noSuchMethodException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  894 */     return constructor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   Object resolveAutowiredArgument(DependencyDescriptor descriptor, Class<?> paramType, String beanName, @Nullable Set<String> autowiredBeanNames, TypeConverter typeConverter, boolean fallback) {
/*  904 */     if (InjectionPoint.class.isAssignableFrom(paramType)) {
/*  905 */       InjectionPoint injectionPoint = (InjectionPoint)currentInjectionPoint.get();
/*  906 */       if (injectionPoint == null) {
/*  907 */         throw new IllegalStateException("No current InjectionPoint available for " + String.valueOf(descriptor));
/*      */       }
/*  909 */       return injectionPoint;
/*      */     } 
/*      */     
/*      */     try {
/*  913 */       return this.beanFactory.resolveDependency(descriptor, beanName, autowiredBeanNames, typeConverter);
/*      */     }
/*  915 */     catch (NoUniqueBeanDefinitionException ex) {
/*  916 */       throw ex;
/*      */     }
/*  918 */     catch (NoSuchBeanDefinitionException ex) {
/*  919 */       if (fallback) {
/*      */ 
/*      */         
/*  922 */         if (paramType.isArray()) {
/*  923 */           return Array.newInstance(paramType.componentType(), 0);
/*      */         }
/*  925 */         if (CollectionFactory.isApproximableCollectionType(paramType)) {
/*  926 */           return CollectionFactory.createCollection(paramType, 0);
/*      */         }
/*  928 */         if (CollectionFactory.isApproximableMapType(paramType)) {
/*  929 */           return CollectionFactory.createMap(paramType, 0);
/*      */         }
/*      */       } 
/*  932 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setShortcutIfPossible(ConstructorDependencyDescriptor descriptor, Class<?> paramType, Set<String> autowiredBeanNames) {
/*  939 */     if (autowiredBeanNames.size() == 1) {
/*  940 */       String autowiredBeanName = autowiredBeanNames.iterator().next();
/*  941 */       if (this.beanFactory.containsBean(autowiredBeanName) && this.beanFactory
/*  942 */         .isTypeMatch(autowiredBeanName, paramType)) {
/*  943 */         descriptor.setShortcut(autowiredBeanName);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerDependentBeans(Executable executable, String beanName, Set<String> autowiredBeanNames) {
/*  951 */     for (String autowiredBeanName : autowiredBeanNames) {
/*  952 */       this.beanFactory.registerDependentBean(autowiredBeanName, beanName);
/*  953 */       if (this.logger.isDebugEnabled()) {
/*  954 */         this.logger.debug("Autowiring by type from bean name '" + beanName + "' via " + (
/*  955 */             (executable instanceof Constructor) ? "constructor" : "factory method") + " to bean named '" + autowiredBeanName + "'");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Executable resolveConstructorOrFactoryMethod(String beanName, RootBeanDefinition mbd) {
/*  965 */     Supplier<ResolvableType> beanType = () -> getBeanType(beanName, mbd);
/*      */     
/*  967 */     List<ResolvableType> valueTypes = mbd.hasConstructorArgumentValues() ? determineParameterValueTypes(mbd) : Collections.<ResolvableType>emptyList();
/*  968 */     Method resolvedFactoryMethod = resolveFactoryMethod(beanName, mbd, valueTypes);
/*  969 */     if (resolvedFactoryMethod != null) {
/*  970 */       return resolvedFactoryMethod;
/*      */     }
/*      */     
/*  973 */     Class<?> factoryBeanClass = getFactoryBeanClass(beanName, mbd);
/*  974 */     if (factoryBeanClass != null && !factoryBeanClass.equals(mbd.getResolvableType().toClass())) {
/*  975 */       ResolvableType resolvableType = mbd.getResolvableType();
/*      */       
/*  977 */       boolean isCompatible = ResolvableType.forClass(factoryBeanClass).as(FactoryBean.class).getGeneric(new int[] { 0 }).isAssignableFrom(resolvableType);
/*  978 */       Assert.state(isCompatible, () -> String.format("Incompatible target type '%s' for factory bean '%s'", new Object[] { resolvableType.toClass().getName(), factoryBeanClass.getName() }));
/*      */ 
/*      */       
/*  981 */       Constructor<?> constructor1 = resolveConstructor(beanName, mbd, () -> ResolvableType.forClass(factoryBeanClass), valueTypes);
/*      */       
/*  983 */       if (constructor1 != null) {
/*  984 */         return constructor1;
/*      */       }
/*  986 */       throw new IllegalStateException("No suitable FactoryBean constructor found for " + String.valueOf(mbd) + " and argument types " + String.valueOf(valueTypes));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  991 */     Constructor<?> constructor = resolveConstructor(beanName, mbd, beanType, valueTypes);
/*  992 */     if (constructor != null) {
/*  993 */       return constructor;
/*      */     }
/*      */     
/*  996 */     throw new IllegalStateException("No constructor or factory method candidate found for " + String.valueOf(mbd) + " and argument types " + String.valueOf(valueTypes));
/*      */   }
/*      */ 
/*      */   
/*      */   private List<ResolvableType> determineParameterValueTypes(RootBeanDefinition mbd) {
/* 1001 */     List<ResolvableType> parameterTypes = new ArrayList<>();
/* 1002 */     for (ConstructorArgumentValues.ValueHolder valueHolder : mbd.getConstructorArgumentValues().getIndexedArgumentValues().values()) {
/* 1003 */       parameterTypes.add(determineParameterValueType(mbd, valueHolder));
/*      */     }
/* 1005 */     for (ConstructorArgumentValues.ValueHolder valueHolder : mbd.getConstructorArgumentValues().getGenericArgumentValues()) {
/* 1006 */       parameterTypes.add(determineParameterValueType(mbd, valueHolder));
/*      */     }
/* 1008 */     return parameterTypes;
/*      */   }
/*      */   
/*      */   private ResolvableType determineParameterValueType(RootBeanDefinition mbd, ConstructorArgumentValues.ValueHolder valueHolder) {
/* 1012 */     if (valueHolder.getType() != null) {
/* 1013 */       return ResolvableType.forClass(
/* 1014 */           ClassUtils.resolveClassName(valueHolder.getType(), this.beanFactory.getBeanClassLoader()));
/*      */     }
/* 1016 */     Object value = valueHolder.getValue();
/* 1017 */     if (value instanceof BeanReference) { BeanReference br = (BeanReference)value;
/* 1018 */       if (value instanceof RuntimeBeanReference) { RuntimeBeanReference rbr = (RuntimeBeanReference)value;
/* 1019 */         if (rbr.getBeanType() != null) {
/* 1020 */           return ResolvableType.forClass(rbr.getBeanType());
/*      */         } }
/*      */       
/* 1023 */       return ResolvableType.forClass(this.beanFactory.getType(br.getBeanName(), false)); }
/*      */     
/* 1025 */     if (value instanceof BeanDefinition) { BeanDefinition innerBd = (BeanDefinition)value;
/* 1026 */       String nameToUse = "(inner bean)";
/* 1027 */       ResolvableType type = getBeanType(nameToUse, this.beanFactory
/* 1028 */           .getMergedBeanDefinition(nameToUse, innerBd, mbd));
/* 1029 */       return FactoryBean.class.isAssignableFrom(type.toClass()) ? 
/* 1030 */         type.as(FactoryBean.class).getGeneric(new int[] { 0 }) : type; }
/*      */     
/* 1032 */     if (value instanceof TypedStringValue) { TypedStringValue typedValue = (TypedStringValue)value;
/* 1033 */       if (typedValue.hasTargetType()) {
/* 1034 */         return ResolvableType.forClass(typedValue.getTargetType());
/*      */       }
/* 1036 */       return ResolvableType.forClass(String.class); }
/*      */     
/* 1038 */     if (value instanceof Class) { Class<?> clazz = (Class)value;
/* 1039 */       return ResolvableType.forClassWithGenerics(Class.class, new Class[] { clazz }); }
/*      */     
/* 1041 */     return ResolvableType.forInstance(value);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Constructor<?> resolveConstructor(String beanName, RootBeanDefinition mbd, Supplier<ResolvableType> beanType, List<ResolvableType> valueTypes) {
/*      */     Constructor<?>[] arrayOfConstructor;
/* 1048 */     Class<?> type = ClassUtils.getUserClass(((ResolvableType)beanType.get()).toClass());
/* 1049 */     Constructor[] arrayOfConstructor1 = (Constructor[])this.beanFactory.determineConstructorsFromBeanPostProcessors(type, beanName);
/* 1050 */     if (arrayOfConstructor1 == null) {
/* 1051 */       if (!mbd.hasConstructorArgumentValues()) {
/* 1052 */         arrayOfConstructor1 = (Constructor[])mbd.getPreferredConstructors();
/*      */       }
/* 1054 */       if (arrayOfConstructor1 == null) {
/* 1055 */         arrayOfConstructor = mbd.isNonPublicAccessAllowed() ? type.getDeclaredConstructors() : type.getConstructors();
/*      */       }
/*      */     } 
/* 1058 */     if (arrayOfConstructor.length == 1) {
/* 1059 */       return arrayOfConstructor[0];
/*      */     }
/*      */     
/* 1062 */     Function<Constructor<?>, List<ResolvableType>> parameterTypesFactory = executable -> {
/*      */         List<ResolvableType> types = new ArrayList<>();
/*      */         
/*      */         for (int i = 0; i < executable.getParameterCount(); i++) {
/*      */           types.add(ResolvableType.forConstructorParameter(executable, i));
/*      */         }
/*      */         
/*      */         return types;
/*      */       };
/*      */     
/* 1072 */     List<Constructor<?>> matches = Arrays.<Constructor<?>>stream(arrayOfConstructor).filter(executable -> match(parameterTypesFactory.apply(executable), valueTypes, FallbackMode.NONE)).toList();
/* 1073 */     if (matches.size() == 1) {
/* 1074 */       return matches.get(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1080 */     List<Constructor<?>> assignableElementFallbackMatches = Arrays.<Constructor<?>>stream(arrayOfConstructor).filter(executable -> match(parameterTypesFactory.apply(executable), valueTypes, FallbackMode.ASSIGNABLE_ELEMENT)).toList();
/* 1081 */     if (assignableElementFallbackMatches.size() == 1) {
/* 1082 */       return assignableElementFallbackMatches.get(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1088 */     List<Constructor<?>> typeConversionFallbackMatches = Arrays.<Constructor<?>>stream(arrayOfConstructor).filter(executable -> match(parameterTypesFactory.apply(executable), valueTypes, FallbackMode.TYPE_CONVERSION)).toList();
/* 1089 */     return (typeConversionFallbackMatches.size() == 1) ? typeConversionFallbackMatches.get(0) : null;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Method resolveFactoryMethod(String beanName, RootBeanDefinition mbd, List<ResolvableType> valueTypes) {
/* 1094 */     if (mbd.isFactoryMethodUnique) {
/* 1095 */       Method resolvedFactoryMethod = mbd.getResolvedFactoryMethod();
/* 1096 */       if (resolvedFactoryMethod != null) {
/* 1097 */         return resolvedFactoryMethod;
/*      */       }
/*      */     } 
/*      */     
/* 1101 */     String factoryMethodName = mbd.getFactoryMethodName();
/* 1102 */     if (factoryMethodName != null) {
/* 1103 */       Class<?> factoryClass; boolean isStatic; String factoryBeanName = mbd.getFactoryBeanName();
/*      */ 
/*      */       
/* 1106 */       if (factoryBeanName != null) {
/* 1107 */         factoryClass = this.beanFactory.getType(factoryBeanName);
/* 1108 */         isStatic = false;
/*      */       } else {
/*      */         
/* 1111 */         factoryClass = this.beanFactory.resolveBeanClass(mbd, beanName, new Class[0]);
/* 1112 */         isStatic = true;
/*      */       } 
/*      */       
/* 1115 */       Assert.state((factoryClass != null), () -> "Failed to determine bean class of " + String.valueOf(mbd));
/* 1116 */       Method[] rawCandidates = getCandidateMethods(factoryClass, mbd);
/* 1117 */       List<Method> candidates = new ArrayList<>();
/* 1118 */       for (Method candidate : rawCandidates) {
/* 1119 */         if ((!isStatic || isStaticCandidate(candidate, factoryClass)) && mbd.isFactoryMethod(candidate)) {
/* 1120 */           candidates.add(candidate);
/*      */         }
/*      */       } 
/*      */       
/* 1124 */       Method result = null;
/* 1125 */       if (candidates.size() == 1) {
/* 1126 */         result = candidates.get(0);
/*      */       }
/* 1128 */       else if (candidates.size() > 1) {
/* 1129 */         Function<Method, List<ResolvableType>> parameterTypesFactory = method -> {
/*      */             List<ResolvableType> types = new ArrayList<>();
/*      */             for (int i = 0; i < method.getParameterCount(); i++) {
/*      */               types.add(ResolvableType.forMethodParameter(method, i));
/*      */             }
/*      */             return types;
/*      */           };
/* 1136 */         result = resolveFactoryMethod(candidates, parameterTypesFactory, valueTypes);
/*      */       } 
/*      */       
/* 1139 */       if (result == null) {
/* 1140 */         throw new BeanCreationException(mbd.getResourceDescription(), beanName, "No matching factory method found on class [" + factoryClass
/* 1141 */             .getName() + "]: " + (
/* 1142 */             (mbd.getFactoryBeanName() != null) ? ("factory bean '" + 
/* 1143 */             mbd.getFactoryBeanName() + "'; ") : "") + "factory method '" + mbd
/* 1144 */             .getFactoryMethodName() + "'. ");
/*      */       }
/* 1146 */       return result;
/*      */     } 
/*      */     
/* 1149 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Method resolveFactoryMethod(List<Method> executables, Function<Method, List<ResolvableType>> parameterTypesFactory, List<ResolvableType> valueTypes) {
/* 1159 */     List<Method> matches = executables.stream().filter(executable -> match(parameterTypesFactory.apply(executable), valueTypes, FallbackMode.NONE)).toList();
/* 1160 */     if (matches.size() == 1) {
/* 1161 */       return matches.get(0);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1166 */     List<Method> assignableElementFallbackMatches = executables.stream().filter(executable -> match(parameterTypesFactory.apply(executable), valueTypes, FallbackMode.ASSIGNABLE_ELEMENT)).toList();
/* 1167 */     if (assignableElementFallbackMatches.size() == 1) {
/* 1168 */       return assignableElementFallbackMatches.get(0);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1173 */     List<Method> typeConversionFallbackMatches = executables.stream().filter(executable -> match(parameterTypesFactory.apply(executable), valueTypes, FallbackMode.TYPE_CONVERSION)).toList();
/* 1174 */     Assert.state((typeConversionFallbackMatches.size() <= 1), () -> "Multiple matches with parameters '" + String.valueOf(valueTypes) + "': " + String.valueOf(typeConversionFallbackMatches));
/*      */     
/* 1176 */     return (typeConversionFallbackMatches.size() == 1) ? typeConversionFallbackMatches.get(0) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean match(List<ResolvableType> parameterTypes, List<ResolvableType> valueTypes, FallbackMode fallbackMode) {
/* 1182 */     if (parameterTypes.size() != valueTypes.size()) {
/* 1183 */       return false;
/*      */     }
/* 1185 */     for (int i = 0; i < parameterTypes.size(); i++) {
/* 1186 */       if (!isMatch(parameterTypes.get(i), valueTypes.get(i), fallbackMode)) {
/* 1187 */         return false;
/*      */       }
/*      */     } 
/* 1190 */     return true;
/*      */   }
/*      */   
/*      */   private boolean isMatch(ResolvableType parameterType, ResolvableType valueType, FallbackMode fallbackMode) {
/* 1194 */     if (isAssignable(valueType).test(parameterType)) {
/* 1195 */       return true;
/*      */     }
/* 1197 */     switch (fallbackMode) { case ASSIGNABLE_ELEMENT: case TYPE_CONVERSION:  }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Predicate<ResolvableType> isAssignable(ResolvableType valueType) {
/* 1205 */     return parameterType -> (valueType == ResolvableType.NONE || parameterType.isAssignableFrom(valueType));
/*      */   }
/*      */   
/*      */   private ResolvableType extractElementType(ResolvableType parameterType) {
/* 1209 */     if (parameterType.isArray()) {
/* 1210 */       return parameterType.getComponentType();
/*      */     }
/* 1212 */     if (Collection.class.isAssignableFrom(parameterType.toClass())) {
/* 1213 */       return parameterType.as(Collection.class).getGeneric(new int[] { 0 });
/*      */     }
/* 1215 */     return ResolvableType.NONE;
/*      */   }
/*      */   
/*      */   private Predicate<ResolvableType> typeConversionFallback(ResolvableType valueType) {
/* 1219 */     return parameterType -> valueOrCollection(valueType, this::isStringForClassFallback).test(parameterType) ? true : valueOrCollection(valueType, this::isSimpleValueType).test(parameterType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Predicate<ResolvableType> valueOrCollection(ResolvableType valueType, Function<ResolvableType, Predicate<ResolvableType>> predicateProvider) {
/* 1230 */     return parameterType -> ((Predicate<ResolvableType>)predicateProvider.apply(valueType)).test(parameterType) ? true : (((Predicate<ResolvableType>)predicateProvider.apply(extractElementType(valueType))).test(extractElementType(parameterType)) ? true : ((Predicate<ResolvableType>)predicateProvider.apply(valueType)).test(extractElementType(parameterType)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Predicate<ResolvableType> isStringForClassFallback(ResolvableType valueType) {
/* 1251 */     return parameterType -> (valueType.isAssignableFrom(String.class) && parameterType.isAssignableFrom(Class.class));
/*      */   }
/*      */ 
/*      */   
/*      */   private Predicate<ResolvableType> isSimpleValueType(ResolvableType valueType) {
/* 1256 */     return parameterType -> (BeanUtils.isSimpleValueType(parameterType.toClass()) && BeanUtils.isSimpleValueType(valueType.toClass()));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Class<?> getFactoryBeanClass(String beanName, RootBeanDefinition mbd) {
/* 1262 */     Class<?> beanClass = this.beanFactory.resolveBeanClass(mbd, beanName, new Class[0]);
/* 1263 */     return (beanClass != null && FactoryBean.class.isAssignableFrom(beanClass)) ? beanClass : null;
/*      */   }
/*      */   
/*      */   private ResolvableType getBeanType(String beanName, RootBeanDefinition mbd) {
/* 1267 */     ResolvableType resolvableType = mbd.getResolvableType();
/* 1268 */     if (resolvableType != ResolvableType.NONE) {
/* 1269 */       return resolvableType;
/*      */     }
/* 1271 */     return ResolvableType.forClass(this.beanFactory.resolveBeanClass(mbd, beanName, new Class[0]));
/*      */   }
/*      */ 
/*      */   
/*      */   static InjectionPoint setCurrentInjectionPoint(@Nullable InjectionPoint injectionPoint) {
/* 1276 */     InjectionPoint old = (InjectionPoint)currentInjectionPoint.get();
/* 1277 */     if (injectionPoint != null) {
/* 1278 */       currentInjectionPoint.set(injectionPoint);
/*      */     } else {
/*      */       
/* 1281 */       currentInjectionPoint.remove();
/*      */     } 
/* 1283 */     return old;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   static Constructor<?>[] determinePreferredConstructors(Class<?> clazz) {
/* 1293 */     Constructor<?> defaultCtor, primaryCtor = BeanUtils.findPrimaryConstructor(clazz);
/*      */ 
/*      */     
/*      */     try {
/* 1297 */       defaultCtor = clazz.getDeclaredConstructor(new Class[0]);
/*      */     }
/* 1299 */     catch (NoSuchMethodException ex) {
/* 1300 */       defaultCtor = null;
/*      */     } 
/*      */     
/* 1303 */     if (primaryCtor != null) {
/* 1304 */       if (defaultCtor != null && !primaryCtor.equals(defaultCtor)) {
/* 1305 */         return (Constructor<?>[])new Constructor[] { primaryCtor, defaultCtor };
/*      */       }
/*      */       
/* 1308 */       return (Constructor<?>[])new Constructor[] { primaryCtor };
/*      */     } 
/*      */ 
/*      */     
/* 1312 */     Constructor[] arrayOfConstructor = (Constructor[])clazz.getConstructors();
/* 1313 */     if (arrayOfConstructor.length == 1) {
/*      */       
/* 1315 */       if (defaultCtor != null && !arrayOfConstructor[0].equals(defaultCtor)) {
/* 1316 */         return (Constructor<?>[])new Constructor[] { arrayOfConstructor[0], defaultCtor };
/*      */       }
/*      */       
/* 1319 */       return (Constructor<?>[])arrayOfConstructor;
/*      */     } 
/*      */     
/* 1322 */     if (arrayOfConstructor.length == 0) {
/*      */       
/* 1324 */       arrayOfConstructor = (Constructor[])clazz.getDeclaredConstructors();
/* 1325 */       if (arrayOfConstructor.length == 1)
/*      */       {
/* 1327 */         return (Constructor<?>[])arrayOfConstructor;
/*      */       }
/*      */     } 
/*      */     
/* 1331 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ArgumentsHolder
/*      */   {
/*      */     public final Object[] rawArguments;
/*      */ 
/*      */     
/*      */     public final Object[] arguments;
/*      */     
/*      */     public final Object[] preparedArguments;
/*      */     
/*      */     public boolean resolveNecessary = false;
/*      */ 
/*      */     
/*      */     public ArgumentsHolder(int size) {
/* 1349 */       this.rawArguments = new Object[size];
/* 1350 */       this.arguments = new Object[size];
/* 1351 */       this.preparedArguments = new Object[size];
/*      */     }
/*      */     
/*      */     public ArgumentsHolder(Object[] args) {
/* 1355 */       this.rawArguments = args;
/* 1356 */       this.arguments = args;
/* 1357 */       this.preparedArguments = args;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getTypeDifferenceWeight(Class<?>[] paramTypes) {
/* 1365 */       int typeDiffWeight = MethodInvoker.getTypeDifferenceWeight(paramTypes, this.arguments);
/* 1366 */       int rawTypeDiffWeight = MethodInvoker.getTypeDifferenceWeight(paramTypes, this.rawArguments) - 1024;
/* 1367 */       return Math.min(rawTypeDiffWeight, typeDiffWeight);
/*      */     }
/*      */     public int getAssignabilityWeight(Class<?>[] paramTypes) {
/*      */       int i;
/* 1371 */       for (i = 0; i < paramTypes.length; i++) {
/* 1372 */         if (!ClassUtils.isAssignableValue(paramTypes[i], this.arguments[i])) {
/* 1373 */           return Integer.MAX_VALUE;
/*      */         }
/*      */       } 
/* 1376 */       for (i = 0; i < paramTypes.length; i++) {
/* 1377 */         if (!ClassUtils.isAssignableValue(paramTypes[i], this.rawArguments[i])) {
/* 1378 */           return 2147483135;
/*      */         }
/*      */       } 
/* 1381 */       return 2147482623;
/*      */     }
/*      */     
/*      */     public void storeCache(RootBeanDefinition mbd, Executable constructorOrFactoryMethod) {
/* 1385 */       synchronized (mbd.constructorArgumentLock) {
/* 1386 */         mbd.resolvedConstructorOrFactoryMethod = constructorOrFactoryMethod;
/* 1387 */         mbd.constructorArgumentsResolved = true;
/* 1388 */         if (this.resolveNecessary) {
/* 1389 */           mbd.preparedConstructorArguments = this.preparedArguments;
/*      */         } else {
/*      */           
/* 1392 */           mbd.resolvedConstructorArguments = this.arguments;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ConstructorPropertiesChecker
/*      */   {
/*      */     @Nullable
/*      */     public static String[] evaluate(Constructor<?> candidate, int paramCount) {
/* 1406 */       ConstructorProperties cp = candidate.<ConstructorProperties>getAnnotation(ConstructorProperties.class);
/* 1407 */       if (cp != null) {
/* 1408 */         String[] names = cp.value();
/* 1409 */         if (names.length != paramCount) {
/* 1410 */           throw new IllegalStateException("Constructor annotated with @ConstructorProperties but not corresponding to actual number of parameters (" + paramCount + "): " + String.valueOf(candidate));
/*      */         }
/*      */         
/* 1413 */         return names;
/*      */       } 
/*      */       
/* 1416 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ConstructorDependencyDescriptor
/*      */     extends DependencyDescriptor
/*      */   {
/*      */     @Nullable
/*      */     private volatile String shortcut;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ConstructorDependencyDescriptor(MethodParameter methodParameter, boolean required) {
/* 1434 */       super(methodParameter, required);
/*      */     }
/*      */     
/*      */     public void setShortcut(@Nullable String shortcut) {
/* 1438 */       this.shortcut = shortcut;
/*      */     }
/*      */     
/*      */     public boolean hasShortcut() {
/* 1442 */       return (this.shortcut != null);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object resolveShortcut(BeanFactory beanFactory) {
/* 1448 */       String shortcut = this.shortcut;
/* 1449 */       return (shortcut != null) ? beanFactory.getBean(shortcut, getDependencyType()) : null;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean usesStandardBeanLookup() {
/* 1454 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private enum FallbackMode
/*      */   {
/* 1461 */     NONE,
/*      */     
/* 1463 */     ASSIGNABLE_ELEMENT,
/*      */     
/* 1465 */     TYPE_CONVERSION;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\ConstructorResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */