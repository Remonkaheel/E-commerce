/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MethodOverride
/*     */   implements BeanMetadataElement
/*     */ {
/*     */   private final String methodName;
/*     */   private boolean overloaded = true;
/*     */   @Nullable
/*     */   private Object source;
/*     */   
/*     */   protected MethodOverride(String methodName) {
/*  54 */     Assert.notNull(methodName, "Method name must not be null");
/*  55 */     this.methodName = methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodName() {
/*  63 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setOverloaded(boolean overloaded) {
/*  73 */     this.overloaded = overloaded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOverloaded() {
/*  81 */     return this.overloaded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(@Nullable Object source) {
/*  89 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/*  95 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean matches(Method paramMethod);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 110 */     if (this != other) { if (other instanceof MethodOverride) { MethodOverride that = (MethodOverride)other; if (this.methodName
/* 111 */           .equals(that.methodName) && 
/* 112 */           ObjectUtils.nullSafeEquals(this.source, that.source)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 117 */     return Objects.hash(new Object[] { this.methodName, this.source });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\MethodOverride.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */