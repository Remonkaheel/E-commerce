package org.springframework.beans.factory.support;

import java.lang.reflect.Method;

public interface MethodReplacer {
  Object reimplement(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) throws Throwable;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\MethodReplacer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */