/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChildBeanDefinition
/*     */   extends AbstractBeanDefinition
/*     */ {
/*     */   @Nullable
/*     */   private String parentName;
/*     */   
/*     */   public ChildBeanDefinition(String parentName) {
/*  64 */     this.parentName = parentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChildBeanDefinition(String parentName, MutablePropertyValues pvs) {
/*  73 */     super(null, pvs);
/*  74 */     this.parentName = parentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChildBeanDefinition(String parentName, ConstructorArgumentValues cargs, MutablePropertyValues pvs) {
/*  86 */     super(cargs, pvs);
/*  87 */     this.parentName = parentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChildBeanDefinition(String parentName, Class<?> beanClass, ConstructorArgumentValues cargs, MutablePropertyValues pvs) {
/* 101 */     super(cargs, pvs);
/* 102 */     this.parentName = parentName;
/* 103 */     setBeanClass(beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChildBeanDefinition(String parentName, String beanClassName, ConstructorArgumentValues cargs, MutablePropertyValues pvs) {
/* 118 */     super(cargs, pvs);
/* 119 */     this.parentName = parentName;
/* 120 */     setBeanClassName(beanClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChildBeanDefinition(ChildBeanDefinition original) {
/* 129 */     super(original);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentName(@Nullable String parentName) {
/* 135 */     this.parentName = parentName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getParentName() {
/* 141 */     return this.parentName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void validate() throws BeanDefinitionValidationException {
/* 146 */     super.validate();
/* 147 */     if (this.parentName == null) {
/* 148 */       throw new BeanDefinitionValidationException("'parentName' must be set in ChildBeanDefinition");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractBeanDefinition cloneBeanDefinition() {
/* 155 */     return new ChildBeanDefinition(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 160 */     if (this != other) { if (other instanceof ChildBeanDefinition) { ChildBeanDefinition that = (ChildBeanDefinition)other;
/* 161 */         if (ObjectUtils.nullSafeEquals(this.parentName, that.parentName) && super.equals(other)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 166 */     return ObjectUtils.nullSafeHashCode(this.parentName) * 29 + super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     return "Child bean with parent '" + this.parentName + "': " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\ChildBeanDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */