/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MethodDescriptor
/*    */   extends Record
/*    */ {
/*    */   private final Class<?> declaringClass;
/*    */   private final String methodName;
/*    */   private final Class<?>[] parameterTypes;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/beans/factory/support/MethodDescriptor;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/beans/factory/support/MethodDescriptor;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/beans/factory/support/MethodDescriptor;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/beans/factory/support/MethodDescriptor;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/beans/factory/support/MethodDescriptor;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/beans/factory/support/MethodDescriptor;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   MethodDescriptor(Class<?> declaringClass, String methodName, Class<?>... parameterTypes) {
/* 34 */     this.declaringClass = declaringClass; this.methodName = methodName; this.parameterTypes = parameterTypes; } public Class<?> declaringClass() { return this.declaringClass; } public String methodName() { return this.methodName; } public Class<?>[] parameterTypes() { return this.parameterTypes; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static MethodDescriptor create(String beanName, Class<?> beanClass, String methodName) {
/*    */     try {
/* 53 */       Class<?> declaringClass = beanClass;
/* 54 */       String methodNameToUse = methodName;
/*    */ 
/*    */       
/* 57 */       int indexOfDot = methodName.lastIndexOf('.');
/* 58 */       if (indexOfDot > 0) {
/* 59 */         String className = methodName.substring(0, indexOfDot);
/* 60 */         methodNameToUse = methodName.substring(indexOfDot + 1);
/* 61 */         if (!beanClass.getName().equals(className)) {
/* 62 */           declaringClass = ClassUtils.forName(className, beanClass.getClassLoader());
/*    */         }
/*    */       } 
/* 65 */       return new MethodDescriptor(declaringClass, methodNameToUse, new Class[0]);
/*    */     }
/* 67 */     catch (Exception|LinkageError ex) {
/* 68 */       throw new BeanDefinitionValidationException("Could not create MethodDescriptor for method '%s' on bean with name '%s': %s"
/*    */           
/* 70 */           .formatted(new Object[] { methodName, beanName, ex.getMessage() }));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\MethodDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */