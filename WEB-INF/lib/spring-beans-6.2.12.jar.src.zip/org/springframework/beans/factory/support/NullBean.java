/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NullBean
/*    */ {
/*    */   public boolean equals(@Nullable Object other) {
/* 44 */     return (this == other || other == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 49 */     return NullBean.class.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 54 */     return "null";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\NullBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */