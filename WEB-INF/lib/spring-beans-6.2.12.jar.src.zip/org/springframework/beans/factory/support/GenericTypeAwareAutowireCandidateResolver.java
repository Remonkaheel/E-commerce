/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericTypeAwareAutowireCandidateResolver
/*     */   extends SimpleAutowireCandidateResolver
/*     */   implements BeanFactoryAware, Cloneable
/*     */ {
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*  54 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected final BeanFactory getBeanFactory() {
/*  59 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutowireCandidate(BeanDefinitionHolder bdHolder, DependencyDescriptor descriptor) {
/*  65 */     if (!super.isAutowireCandidate(bdHolder, descriptor))
/*     */     {
/*  67 */       return false;
/*     */     }
/*  69 */     return checkGenericTypeMatch(bdHolder, descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkGenericTypeMatch(BeanDefinitionHolder bdHolder, DependencyDescriptor descriptor) {
/*  78 */     ResolvableType dependencyType = descriptor.getResolvableType();
/*  79 */     if (dependencyType.getType() instanceof Class)
/*     */     {
/*  81 */       return true;
/*     */     }
/*     */     
/*  84 */     ResolvableType targetType = null;
/*  85 */     boolean cacheType = false;
/*  86 */     RootBeanDefinition rbd = null;
/*  87 */     BeanDefinition beanDefinition = bdHolder.getBeanDefinition(); if (beanDefinition instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDef = (RootBeanDefinition)beanDefinition;
/*  88 */       rbd = rootBeanDef; }
/*     */     
/*  90 */     if (rbd != null) {
/*  91 */       targetType = rbd.targetType;
/*  92 */       if (targetType == null) {
/*  93 */         cacheType = true;
/*     */         
/*  95 */         targetType = getReturnTypeForFactoryMethod(rbd, descriptor);
/*  96 */         if (targetType == null) {
/*  97 */           RootBeanDefinition dbd = getResolvedDecoratedDefinition(rbd);
/*  98 */           if (dbd != null) {
/*  99 */             targetType = dbd.targetType;
/* 100 */             if (targetType == null) {
/* 101 */               targetType = getReturnTypeForFactoryMethod(dbd, descriptor);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     if (targetType == null) {
/*     */       
/* 110 */       if (this.beanFactory != null) {
/* 111 */         Class<?> beanType = this.beanFactory.getType(bdHolder.getBeanName());
/* 112 */         if (beanType != null) {
/* 113 */           targetType = ResolvableType.forClass(ClassUtils.getUserClass(beanType));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 118 */       if (targetType == null && rbd != null && rbd.hasBeanClass() && rbd.getFactoryMethodName() == null) {
/* 119 */         Class<?> beanClass = rbd.getBeanClass();
/* 120 */         if (!FactoryBean.class.isAssignableFrom(beanClass)) {
/* 121 */           targetType = ResolvableType.forClass(ClassUtils.getUserClass(beanClass));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     if (targetType == null) {
/* 127 */       return true;
/*     */     }
/* 129 */     if (cacheType) {
/* 130 */       rbd.targetType = targetType;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 135 */     Class<?> targetClass = targetType.resolve();
/* 136 */     if (targetClass != null && FactoryBean.class.isAssignableFrom(targetClass)) {
/* 137 */       Class<?> classToMatch = dependencyType.resolve();
/* 138 */       if (classToMatch != null && !FactoryBean.class.isAssignableFrom(classToMatch) && 
/* 139 */         !classToMatch.isAssignableFrom(targetClass)) {
/* 140 */         targetType = targetType.getGeneric(new int[0]);
/* 141 */         if (descriptor.fallbackMatchAllowed())
/*     */         {
/*     */           
/* 144 */           targetType = ResolvableType.forClass(targetType.resolve());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     if (descriptor.fallbackMatchAllowed()) {
/*     */ 
/*     */ 
/*     */       
/* 153 */       if (targetType.hasUnresolvableGenerics()) {
/* 154 */         return dependencyType.isAssignableFromResolvedPart(targetType);
/*     */       }
/* 156 */       if (targetType.resolve() == Properties.class) {
/* 157 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 161 */     return dependencyType.isAssignableFrom(targetType);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected RootBeanDefinition getResolvedDecoratedDefinition(RootBeanDefinition rbd) {
/* 166 */     BeanDefinitionHolder decDef = rbd.getDecoratedDefinition();
/* 167 */     if (decDef != null) { BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)beanFactory;
/* 168 */         if (clbf.containsBeanDefinition(decDef.getBeanName())) {
/* 169 */           BeanDefinition dbd = clbf.getMergedBeanDefinition(decDef.getBeanName());
/* 170 */           if (dbd instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDef = (RootBeanDefinition)dbd;
/* 171 */             return rootBeanDef; }
/*     */         
/*     */         }  }
/*     */        }
/* 175 */      return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected ResolvableType getReturnTypeForFactoryMethod(RootBeanDefinition rbd, DependencyDescriptor descriptor) {
/* 182 */     ResolvableType returnType = rbd.factoryMethodReturnType;
/* 183 */     if (returnType == null) {
/* 184 */       Method factoryMethod = rbd.getResolvedFactoryMethod();
/* 185 */       if (factoryMethod != null) {
/* 186 */         returnType = ResolvableType.forMethodReturnType(factoryMethod);
/*     */       }
/*     */     } 
/* 189 */     if (returnType != null) {
/* 190 */       Class<?> resolvedClass = returnType.resolve();
/* 191 */       if (resolvedClass != null && descriptor.getDependencyType().isAssignableFrom(resolvedClass))
/*     */       {
/*     */ 
/*     */         
/* 195 */         return returnType;
/*     */       }
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutowireCandidateResolver cloneIfNecessary() {
/*     */     try {
/* 211 */       return (AutowireCandidateResolver)clone();
/*     */     }
/* 213 */     catch (CloneNotSupportedException ex) {
/* 214 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\GenericTypeAwareAutowireCandidateResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */