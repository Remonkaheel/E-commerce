/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements DefaultListableBeanFactory.BeanObjectProvider<T>
/*     */ {
/*     */   public T getObject() throws BeansException {
/* 449 */     T resolved = DefaultListableBeanFactory.this.resolveBean(requiredType, (Object[])null, false);
/* 450 */     if (resolved == null) {
/* 451 */       throw new NoSuchBeanDefinitionException(requiredType);
/*     */     }
/* 453 */     return resolved;
/*     */   }
/*     */   
/*     */   public T getObject(Object... args) throws BeansException {
/* 457 */     T resolved = DefaultListableBeanFactory.this.resolveBean(requiredType, args, false);
/* 458 */     if (resolved == null) {
/* 459 */       throw new NoSuchBeanDefinitionException(requiredType);
/*     */     }
/* 461 */     return resolved;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public T getIfAvailable() throws BeansException {
/*     */     try {
/* 467 */       return DefaultListableBeanFactory.this.resolveBean(requiredType, (Object[])null, false);
/*     */     }
/* 469 */     catch (ScopeNotActiveException ex) {
/*     */       
/* 471 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void ifAvailable(Consumer<T> dependencyConsumer) throws BeansException {
/* 476 */     T dependency = getIfAvailable();
/* 477 */     if (dependency != null) {
/*     */       try {
/* 479 */         dependencyConsumer.accept(dependency);
/*     */       }
/* 481 */       catch (ScopeNotActiveException scopeNotActiveException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T getIfUnique() throws BeansException {
/*     */     try {
/* 490 */       return DefaultListableBeanFactory.this.resolveBean(requiredType, (Object[])null, true);
/*     */     }
/* 492 */     catch (ScopeNotActiveException ex) {
/*     */       
/* 494 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void ifUnique(Consumer<T> dependencyConsumer) throws BeansException {
/* 499 */     T dependency = getIfUnique();
/* 500 */     if (dependency != null) {
/*     */       try {
/* 502 */         dependencyConsumer.accept(dependency);
/*     */       }
/* 504 */       catch (ScopeNotActiveException scopeNotActiveException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<T> stream() {
/* 512 */     return Arrays.<String>stream(DefaultListableBeanFactory.this.beanNamesForStream(requiredType, true, allowEagerInit))
/* 513 */       .map(name -> DefaultListableBeanFactory.this.getBean(name))
/* 514 */       .filter(bean -> !(bean instanceof NullBean));
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<T> orderedStream() {
/* 519 */     String[] beanNames = DefaultListableBeanFactory.this.beanNamesForStream(requiredType, true, allowEagerInit);
/* 520 */     if (beanNames.length == 0) {
/* 521 */       return Stream.empty();
/*     */     }
/* 523 */     Map<String, T> matchingBeans = CollectionUtils.newLinkedHashMap(beanNames.length);
/* 524 */     for (String beanName : beanNames) {
/* 525 */       Object beanInstance = DefaultListableBeanFactory.this.getBean(beanName);
/* 526 */       if (!(beanInstance instanceof NullBean)) {
/* 527 */         matchingBeans.put(beanName, (T)beanInstance);
/*     */       }
/*     */     } 
/* 530 */     Stream<T> stream = matchingBeans.values().stream();
/* 531 */     return stream.sorted((Comparator)DefaultListableBeanFactory.this.adaptOrderComparator(matchingBeans));
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<T> stream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/* 536 */     return Arrays.<String>stream(DefaultListableBeanFactory.this.beanNamesForStream(requiredType, includeNonSingletons, allowEagerInit))
/* 537 */       .filter(name -> customFilter.test(DefaultListableBeanFactory.this.getType(name)))
/* 538 */       .map(name -> DefaultListableBeanFactory.this.getBean(name))
/* 539 */       .filter(bean -> !(bean instanceof NullBean));
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<T> orderedStream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/* 544 */     String[] beanNames = DefaultListableBeanFactory.this.beanNamesForStream(requiredType, includeNonSingletons, allowEagerInit);
/* 545 */     if (beanNames.length == 0) {
/* 546 */       return Stream.empty();
/*     */     }
/* 548 */     Map<String, T> matchingBeans = CollectionUtils.newLinkedHashMap(beanNames.length);
/* 549 */     for (String beanName : beanNames) {
/* 550 */       if (customFilter.test(DefaultListableBeanFactory.this.getType(beanName))) {
/* 551 */         Object beanInstance = DefaultListableBeanFactory.this.getBean(beanName);
/* 552 */         if (!(beanInstance instanceof NullBean)) {
/* 553 */           matchingBeans.put(beanName, (T)beanInstance);
/*     */         }
/*     */       } 
/*     */     } 
/* 557 */     return matchingBeans.values().stream().sorted((Comparator)DefaultListableBeanFactory.this.adaptOrderComparator(matchingBeans));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\DefaultListableBeanFactory$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */