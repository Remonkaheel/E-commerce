/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootBeanDefinition
/*     */   extends AbstractBeanDefinition
/*     */ {
/*     */   @Nullable
/*     */   private BeanDefinitionHolder decoratedDefinition;
/*     */   @Nullable
/*     */   private AnnotatedElement qualifiedElement;
/*     */   volatile boolean stale;
/*     */   boolean allowCaching = true;
/*     */   boolean isFactoryMethodUnique;
/*     */   @Nullable
/*     */   volatile ResolvableType targetType;
/*     */   @Nullable
/*     */   volatile Class<?> resolvedTargetType;
/*     */   @Nullable
/*     */   volatile Boolean isFactoryBean;
/*     */   @Nullable
/*     */   volatile ResolvableType factoryMethodReturnType;
/*     */   @Nullable
/*     */   volatile Method factoryMethodToIntrospect;
/*     */   @Nullable
/*     */   volatile String resolvedDestroyMethodName;
/* 102 */   final Object constructorArgumentLock = new Object();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Executable resolvedConstructorOrFactoryMethod;
/*     */ 
/*     */   
/*     */   boolean constructorArgumentsResolved = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Object[] resolvedConstructorArguments;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Object[] preparedConstructorArguments;
/*     */ 
/*     */   
/* 120 */   final Object postProcessingLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean postProcessed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   volatile Boolean beforeInstantiationResolved;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Set<Member> externallyManagedConfigMembers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Set<String> externallyManagedInitMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Set<String> externallyManagedDestroyMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition(@Nullable Class<?> beanClass) {
/* 156 */     setBeanClass(beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0.11")
/*     */   public RootBeanDefinition(@Nullable ResolvableType beanType) {
/* 168 */     setTargetType(beanType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RootBeanDefinition(@Nullable Class<T> beanClass, @Nullable Supplier<T> instanceSupplier) {
/* 181 */     setBeanClass(beanClass);
/* 182 */     setInstanceSupplier(instanceSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RootBeanDefinition(@Nullable Class<T> beanClass, String scope, @Nullable Supplier<T> instanceSupplier) {
/* 196 */     setBeanClass(beanClass);
/* 197 */     setScope(scope);
/* 198 */     setInstanceSupplier(instanceSupplier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition(@Nullable Class<?> beanClass, int autowireMode, boolean dependencyCheck) {
/* 210 */     setBeanClass(beanClass);
/* 211 */     setAutowireMode(autowireMode);
/* 212 */     if (dependencyCheck && getResolvedAutowireMode() != 3) {
/* 213 */       setDependencyCheck(1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition(@Nullable Class<?> beanClass, @Nullable ConstructorArgumentValues cargs, @Nullable MutablePropertyValues pvs) {
/* 227 */     super(cargs, pvs);
/* 228 */     setBeanClass(beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition(String beanClassName) {
/* 238 */     setBeanClassName(beanClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition(String beanClassName, ConstructorArgumentValues cargs, MutablePropertyValues pvs) {
/* 250 */     super(cargs, pvs);
/* 251 */     setBeanClassName(beanClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition(RootBeanDefinition original) {
/* 260 */     super(original);
/* 261 */     this.decoratedDefinition = original.decoratedDefinition;
/* 262 */     this.qualifiedElement = original.qualifiedElement;
/* 263 */     this.allowCaching = original.allowCaching;
/* 264 */     this.isFactoryMethodUnique = original.isFactoryMethodUnique;
/* 265 */     this.targetType = original.targetType;
/* 266 */     this.factoryMethodToIntrospect = original.factoryMethodToIntrospect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RootBeanDefinition(BeanDefinition original) {
/* 275 */     super(original);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getParentName() {
/* 282 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParentName(@Nullable String parentName) {
/* 287 */     if (parentName != null) {
/* 288 */       throw new IllegalArgumentException("Root bean cannot be changed into a child bean with parent reference");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDecoratedDefinition(@Nullable BeanDefinitionHolder decoratedDefinition) {
/* 296 */     this.decoratedDefinition = decoratedDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinitionHolder getDecoratedDefinition() {
/* 304 */     return this.decoratedDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifiedElement(@Nullable AnnotatedElement qualifiedElement) {
/* 315 */     this.qualifiedElement = qualifiedElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public AnnotatedElement getQualifiedElement() {
/* 325 */     return this.qualifiedElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetType(@Nullable ResolvableType targetType) {
/* 333 */     this.targetType = targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetType(@Nullable Class<?> targetType) {
/* 341 */     this.targetType = (targetType != null) ? ResolvableType.forClass(targetType) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getTargetType() {
/* 351 */     if (this.resolvedTargetType != null) {
/* 352 */       return this.resolvedTargetType;
/*     */     }
/* 354 */     ResolvableType targetType = this.targetType;
/* 355 */     return (targetType != null) ? targetType.resolve() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getResolvableType() {
/* 370 */     ResolvableType targetType = this.targetType;
/* 371 */     if (targetType != null) {
/* 372 */       return targetType;
/*     */     }
/* 374 */     ResolvableType returnType = this.factoryMethodReturnType;
/* 375 */     if (returnType != null) {
/* 376 */       return returnType;
/*     */     }
/* 378 */     Method factoryMethod = getResolvedFactoryMethod();
/* 379 */     if (factoryMethod != null) {
/* 380 */       return ResolvableType.forMethodReturnType(factoryMethod);
/*     */     }
/* 382 */     return super.getResolvableType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Constructor<?>[] getPreferredConstructors() {
/* 398 */     Object attribute = getAttribute("preferredConstructors");
/* 399 */     if (attribute == null) {
/* 400 */       return null;
/*     */     }
/* 402 */     if (attribute instanceof Constructor) { Constructor<?> constructor = (Constructor)attribute;
/* 403 */       return (Constructor<?>[])new Constructor[] { constructor }; }
/*     */     
/* 405 */     if (attribute instanceof Constructor[]) return (Constructor<?>[])attribute;
/*     */ 
/*     */     
/* 408 */     throw new IllegalArgumentException("Invalid value type for attribute 'preferredConstructors': " + attribute
/* 409 */         .getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniqueFactoryMethodName(String name) {
/* 416 */     Assert.hasText(name, "Factory method name must not be empty");
/* 417 */     setFactoryMethodName(name);
/* 418 */     this.isFactoryMethodUnique = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNonUniqueFactoryMethodName(String name) {
/* 426 */     Assert.hasText(name, "Factory method name must not be empty");
/* 427 */     setFactoryMethodName(name);
/* 428 */     this.isFactoryMethodUnique = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFactoryMethod(Method candidate) {
/* 435 */     return candidate.getName().equals(getFactoryMethodName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolvedFactoryMethod(@Nullable Method method) {
/* 444 */     this.factoryMethodToIntrospect = method;
/* 445 */     if (method != null) {
/* 446 */       setUniqueFactoryMethodName(method.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getResolvedFactoryMethod() {
/* 456 */     Method factoryMethod = this.factoryMethodToIntrospect;
/* 457 */     if (factoryMethod == null) {
/* 458 */       Supplier<?> supplier = getInstanceSupplier(); if (supplier instanceof InstanceSupplier) { InstanceSupplier<?> instanceSupplier = (InstanceSupplier)supplier;
/* 459 */         factoryMethod = instanceSupplier.getFactoryMethod(); }
/*     */     
/* 461 */     }  return factoryMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAsPostProcessed() {
/* 470 */     synchronized (this.postProcessingLock) {
/* 471 */       this.postProcessed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerExternallyManagedConfigMember(Member configMember) {
/* 479 */     synchronized (this.postProcessingLock) {
/* 480 */       if (this.externallyManagedConfigMembers == null) {
/* 481 */         this.externallyManagedConfigMembers = new LinkedHashSet<>(1);
/*     */       }
/* 483 */       this.externallyManagedConfigMembers.add(configMember);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExternallyManagedConfigMember(Member configMember) {
/* 491 */     synchronized (this.postProcessingLock) {
/* 492 */       return (this.externallyManagedConfigMembers != null && this.externallyManagedConfigMembers
/* 493 */         .contains(configMember));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Member> getExternallyManagedConfigMembers() {
/* 502 */     synchronized (this.postProcessingLock) {
/* 503 */       return (this.externallyManagedConfigMembers != null) ? 
/* 504 */         Collections.<Member>unmodifiableSet(new LinkedHashSet<>(this.externallyManagedConfigMembers)) : 
/* 505 */         Collections.<Member>emptySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerExternallyManagedInitMethod(String initMethod) {
/* 522 */     synchronized (this.postProcessingLock) {
/* 523 */       if (this.externallyManagedInitMethods == null) {
/* 524 */         this.externallyManagedInitMethods = new LinkedHashSet<>(1);
/*     */       }
/* 526 */       this.externallyManagedInitMethods.add(initMethod);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExternallyManagedInitMethod(String initMethod) {
/* 537 */     synchronized (this.postProcessingLock) {
/* 538 */       return (this.externallyManagedInitMethods != null && this.externallyManagedInitMethods
/* 539 */         .contains(initMethod));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasAnyExternallyManagedInitMethod(String initMethod) {
/* 554 */     synchronized (this.postProcessingLock) {
/* 555 */       if (isExternallyManagedInitMethod(initMethod)) {
/* 556 */         return true;
/*     */       }
/* 558 */       return hasAnyExternallyManagedMethod(this.externallyManagedInitMethods, initMethod);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExternallyManagedInitMethods() {
/* 569 */     synchronized (this.postProcessingLock) {
/* 570 */       return (this.externallyManagedInitMethods != null) ? 
/* 571 */         Collections.<String>unmodifiableSet(new LinkedHashSet<>(this.externallyManagedInitMethods)) : 
/* 572 */         Collections.<String>emptySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveDestroyMethodIfNecessary() {
/* 581 */     setDestroyMethodNames(
/* 582 */         DisposableBeanAdapter.inferDestroyMethodsIfNecessary(getResolvableType().toClass(), this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerExternallyManagedDestroyMethod(String destroyMethod) {
/* 597 */     synchronized (this.postProcessingLock) {
/* 598 */       if (this.externallyManagedDestroyMethods == null) {
/* 599 */         this.externallyManagedDestroyMethods = new LinkedHashSet<>(1);
/*     */       }
/* 601 */       this.externallyManagedDestroyMethods.add(destroyMethod);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExternallyManagedDestroyMethod(String destroyMethod) {
/* 612 */     synchronized (this.postProcessingLock) {
/* 613 */       return (this.externallyManagedDestroyMethods != null && this.externallyManagedDestroyMethods
/* 614 */         .contains(destroyMethod));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasAnyExternallyManagedDestroyMethod(String destroyMethod) {
/* 629 */     synchronized (this.postProcessingLock) {
/* 630 */       if (isExternallyManagedDestroyMethod(destroyMethod)) {
/* 631 */         return true;
/*     */       }
/* 633 */       return hasAnyExternallyManagedMethod(this.externallyManagedDestroyMethods, destroyMethod);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean hasAnyExternallyManagedMethod(@Nullable Set<String> candidates, String methodName) {
/* 638 */     if (candidates != null) {
/* 639 */       for (String candidate : candidates) {
/* 640 */         int indexOfDot = candidate.lastIndexOf('.');
/* 641 */         if (indexOfDot > 0) {
/* 642 */           String candidateMethodName = candidate.substring(indexOfDot + 1);
/* 643 */           if (candidateMethodName.equals(methodName)) {
/* 644 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 649 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExternallyManagedDestroyMethods() {
/* 659 */     synchronized (this.postProcessingLock) {
/* 660 */       return (this.externallyManagedDestroyMethods != null) ? 
/* 661 */         Collections.<String>unmodifiableSet(new LinkedHashSet<>(this.externallyManagedDestroyMethods)) : 
/* 662 */         Collections.<String>emptySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RootBeanDefinition cloneBeanDefinition() {
/* 669 */     return new RootBeanDefinition(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 674 */     return (this == other || (other instanceof RootBeanDefinition && super.equals(other)));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 679 */     return "Root bean: " + super.toString();
/*     */   }
/*     */   
/*     */   public RootBeanDefinition() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\RootBeanDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */