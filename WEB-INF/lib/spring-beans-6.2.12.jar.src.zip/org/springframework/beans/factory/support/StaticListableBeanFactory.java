/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanIsNotAFactoryException;
/*     */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticListableBeanFactory
/*     */   implements ListableBeanFactory
/*     */ {
/*     */   private final Map<String, Object> beans;
/*     */   
/*     */   public StaticListableBeanFactory() {
/*  79 */     this.beans = new LinkedHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticListableBeanFactory(Map<String, Object> beans) {
/*  93 */     Assert.notNull(beans, "Beans Map must not be null");
/*  94 */     this.beans = beans;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBean(String name, Object bean) {
/* 105 */     this.beans.put(name, bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBean(String name) throws BeansException {
/* 115 */     String beanName = BeanFactoryUtils.transformedBeanName(name);
/* 116 */     Object bean = obtainBean(beanName);
/*     */     
/* 118 */     if (BeanFactoryUtils.isFactoryDereference(name) && !(bean instanceof FactoryBean)) {
/* 119 */       throw new BeanIsNotAFactoryException(beanName, bean.getClass());
/*     */     }
/*     */     
/* 122 */     if (bean instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)bean; if (!BeanFactoryUtils.isFactoryDereference(name)) {
/*     */         try {
/* 124 */           Object exposedObject = factoryBean.getObject();
/* 125 */           if (exposedObject == null) {
/* 126 */             throw new BeanCreationException(beanName, "FactoryBean exposed null object");
/*     */           }
/* 128 */           return exposedObject;
/*     */         }
/* 130 */         catch (Exception ex) {
/* 131 */           throw new BeanCreationException(beanName, "FactoryBean threw exception on object creation", ex);
/*     */         } 
/*     */       } }
/*     */     
/* 135 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getBean(String name, @Nullable Class<T> requiredType) throws BeansException {
/* 142 */     Object bean = getBean(name);
/* 143 */     if (requiredType != null && !requiredType.isInstance(bean)) {
/* 144 */       throw new BeanNotOfRequiredTypeException(name, requiredType, bean.getClass());
/*     */     }
/* 146 */     return (T)bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getBean(String name, Object... args) throws BeansException {
/* 151 */     if (!ObjectUtils.isEmpty(args)) {
/* 152 */       throw new UnsupportedOperationException("StaticListableBeanFactory does not support explicit bean creation arguments");
/*     */     }
/*     */     
/* 155 */     return getBean(name);
/*     */   }
/*     */   
/*     */   private Object obtainBean(String beanName) {
/* 159 */     Object bean = this.beans.get(beanName);
/* 160 */     if (bean == null) {
/* 161 */       throw new NoSuchBeanDefinitionException(beanName, "Defined beans are [" + 
/* 162 */           StringUtils.collectionToCommaDelimitedString(this.beans.keySet()) + "]");
/*     */     }
/* 164 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getBean(Class<T> requiredType) throws BeansException {
/* 169 */     String[] beanNames = getBeanNamesForType(requiredType);
/* 170 */     if (beanNames.length == 1) {
/* 171 */       return getBean(beanNames[0], requiredType);
/*     */     }
/* 173 */     if (beanNames.length > 1) {
/* 174 */       throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */     }
/*     */     
/* 177 */     throw new NoSuchBeanDefinitionException(requiredType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getBean(Class<T> requiredType, Object... args) throws BeansException {
/* 183 */     if (!ObjectUtils.isEmpty(args)) {
/* 184 */       throw new UnsupportedOperationException("StaticListableBeanFactory does not support explicit bean creation arguments");
/*     */     }
/*     */     
/* 187 */     return getBean(requiredType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> ObjectProvider<T> getBeanProvider(Class<T> requiredType) throws BeansException {
/* 192 */     return getBeanProvider(ResolvableType.forRawClass(requiredType), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> ObjectProvider<T> getBeanProvider(ResolvableType requiredType) {
/* 197 */     return getBeanProvider(requiredType, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsBean(String name) {
/* 202 */     return this.beans.containsKey(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
/* 207 */     String beanName = BeanFactoryUtils.transformedBeanName(name);
/* 208 */     Object bean = obtainBean(beanName);
/* 209 */     if (bean instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)bean; if (!BeanFactoryUtils.isFactoryDereference(name))
/* 210 */         return factoryBean.isSingleton();  }
/*     */     
/* 212 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic transformedBeanName : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   4: astore_2
/*     */     //   5: aload_0
/*     */     //   6: aload_2
/*     */     //   7: invokevirtual obtainBean : (Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   10: astore_3
/*     */     //   11: aload_1
/*     */     //   12: invokestatic isFactoryDereference : (Ljava/lang/String;)Z
/*     */     //   15: ifne -> 68
/*     */     //   18: aload_3
/*     */     //   19: instanceof org/springframework/beans/factory/SmartFactoryBean
/*     */     //   22: ifeq -> 41
/*     */     //   25: aload_3
/*     */     //   26: checkcast org/springframework/beans/factory/SmartFactoryBean
/*     */     //   29: astore #5
/*     */     //   31: aload #5
/*     */     //   33: invokeinterface isPrototype : ()Z
/*     */     //   38: ifne -> 64
/*     */     //   41: aload_3
/*     */     //   42: instanceof org/springframework/beans/factory/FactoryBean
/*     */     //   45: ifeq -> 68
/*     */     //   48: aload_3
/*     */     //   49: checkcast org/springframework/beans/factory/FactoryBean
/*     */     //   52: astore #4
/*     */     //   54: aload #4
/*     */     //   56: invokeinterface isSingleton : ()Z
/*     */     //   61: ifne -> 68
/*     */     //   64: iconst_1
/*     */     //   65: goto -> 69
/*     */     //   68: iconst_0
/*     */     //   69: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #217	-> 0
/*     */     //   #218	-> 5
/*     */     //   #219	-> 11
/*     */     //   #220	-> 25
/*     */     //   #221	-> 48
/*     */     //   #219	-> 69
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   31	10	5	smartFactoryBean	Lorg/springframework/beans/factory/SmartFactoryBean;
/*     */     //   54	10	4	factoryBean	Lorg/springframework/beans/factory/FactoryBean;
/*     */     //   0	70	0	this	Lorg/springframework/beans/factory/support/StaticListableBeanFactory;
/*     */     //   0	70	1	name	Ljava/lang/String;
/*     */     //   5	65	2	beanName	Ljava/lang/String;
/*     */     //   11	59	3	bean	Ljava/lang/Object;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   31	10	5	smartFactoryBean	Lorg/springframework/beans/factory/SmartFactoryBean<*>;
/*     */     //   54	10	4	factoryBean	Lorg/springframework/beans/factory/FactoryBean<*>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTypeMatch(String name, ResolvableType typeToMatch) throws NoSuchBeanDefinitionException {
/* 226 */     Class<?> type = getType(name);
/* 227 */     return (type != null && typeToMatch.isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeMatch(String name, @Nullable Class<?> typeToMatch) throws NoSuchBeanDefinitionException {
/* 232 */     Class<?> type = getType(name);
/* 233 */     return (typeToMatch == null || (type != null && typeToMatch.isAssignableFrom(type)));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException {
/* 239 */     return getType(name, true);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getType(String name, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/* 245 */     String beanName = BeanFactoryUtils.transformedBeanName(name);
/* 246 */     Object bean = obtainBean(beanName);
/* 247 */     if (bean instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)bean; if (!BeanFactoryUtils.isFactoryDereference(name))
/* 248 */         return factoryBean.getObjectType();  }
/*     */     
/* 250 */     return bean.getClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAliases(String name) {
/* 255 */     return new String[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsBeanDefinition(String name) {
/* 265 */     return this.beans.containsKey(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBeanDefinitionCount() {
/* 270 */     return this.beans.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getBeanDefinitionNames() {
/* 275 */     return StringUtils.toStringArray(this.beans.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> ObjectProvider<T> getBeanProvider(Class<T> requiredType, boolean allowEagerInit) {
/* 280 */     return getBeanProvider(ResolvableType.forRawClass(requiredType), allowEagerInit);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ObjectProvider<T> getBeanProvider(final ResolvableType requiredType, boolean allowEagerInit) {
/* 286 */     return new ObjectProvider<T>()
/*     */       {
/*     */         public T getObject() throws BeansException {
/* 289 */           String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 290 */           if (beanNames.length == 1) {
/* 291 */             return (T)StaticListableBeanFactory.this.getBean(beanNames[0]);
/*     */           }
/* 293 */           if (beanNames.length > 1) {
/* 294 */             throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */           }
/*     */           
/* 297 */           throw new NoSuchBeanDefinitionException(requiredType);
/*     */         }
/*     */ 
/*     */         
/*     */         public T getObject(Object... args) throws BeansException {
/* 302 */           String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 303 */           if (beanNames.length == 1) {
/* 304 */             return (T)StaticListableBeanFactory.this.getBean(beanNames[0], args);
/*     */           }
/* 306 */           if (beanNames.length > 1) {
/* 307 */             throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */           }
/*     */           
/* 310 */           throw new NoSuchBeanDefinitionException(requiredType);
/*     */         }
/*     */ 
/*     */         
/*     */         @Nullable
/*     */         public T getIfAvailable() throws BeansException {
/* 316 */           String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 317 */           if (beanNames.length == 1) {
/* 318 */             return (T)StaticListableBeanFactory.this.getBean(beanNames[0]);
/*     */           }
/* 320 */           if (beanNames.length > 1) {
/* 321 */             throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */           }
/*     */           
/* 324 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         @Nullable
/*     */         public T getIfUnique() throws BeansException {
/* 330 */           String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 331 */           if (beanNames.length == 1) {
/* 332 */             return (T)StaticListableBeanFactory.this.getBean(beanNames[0]);
/*     */           }
/*     */           
/* 335 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public Stream<T> stream() {
/* 340 */           return Arrays.<String>stream(StaticListableBeanFactory.this.getBeanNamesForType(requiredType)).map(name -> StaticListableBeanFactory.this.getBean(name));
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getBeanNamesForType(@Nullable ResolvableType type) {
/* 347 */     return getBeanNamesForType(type, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getBeanNamesForType(@Nullable ResolvableType type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 354 */     Class<?> resolved = (type != null) ? type.resolve() : null;
/* 355 */     boolean isFactoryType = (resolved != null && FactoryBean.class.isAssignableFrom(resolved));
/* 356 */     List<String> matches = new ArrayList<>();
/*     */     
/* 358 */     for (Map.Entry<String, Object> entry : this.beans.entrySet()) {
/* 359 */       String beanName = entry.getKey();
/* 360 */       Object beanInstance = entry.getValue();
/* 361 */       if (beanInstance instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)beanInstance; if (!isFactoryType) {
/* 362 */           Class<?> objectType = factoryBean.getObjectType();
/* 363 */           if ((includeNonSingletons || factoryBean.isSingleton()) && (type == null || (objectType != null && type
/* 364 */             .isAssignableFrom(objectType))))
/* 365 */             matches.add(beanName); 
/*     */           continue;
/*     */         }  }
/*     */       
/* 369 */       if (type == null || type.isInstance(beanInstance)) {
/* 370 */         matches.add(beanName);
/*     */       }
/*     */     } 
/*     */     
/* 374 */     return StringUtils.toStringArray(matches);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getBeanNamesForType(@Nullable Class<?> type) {
/* 379 */     return getBeanNamesForType(ResolvableType.forClass(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getBeanNamesForType(@Nullable Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 384 */     return getBeanNamesForType(ResolvableType.forClass(type), includeNonSingletons, allowEagerInit);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Map<String, T> getBeansOfType(@Nullable Class<T> type) throws BeansException {
/* 389 */     return getBeansOfType(type, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Map<String, T> getBeansOfType(@Nullable Class<T> type, boolean includeNonSingletons, boolean allowEagerInit) throws BeansException {
/* 397 */     boolean isFactoryType = (type != null && FactoryBean.class.isAssignableFrom(type));
/* 398 */     Map<String, T> matches = new LinkedHashMap<>();
/*     */     
/* 400 */     for (Map.Entry<String, Object> entry : this.beans.entrySet()) {
/* 401 */       String beanName = entry.getKey();
/* 402 */       Object beanInstance = entry.getValue();
/* 403 */       if (beanInstance instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)beanInstance; if (!isFactoryType) {
/* 404 */           Class<?> objectType = factoryBean.getObjectType();
/* 405 */           if ((includeNonSingletons || factoryBean.isSingleton()) && (type == null || (objectType != null && type
/* 406 */             .isAssignableFrom(objectType))))
/* 407 */             matches.put(beanName, getBean(beanName, type)); 
/*     */           continue;
/*     */         }  }
/*     */       
/* 411 */       if (type == null || type.isInstance(beanInstance)) {
/* 412 */         if (isFactoryType) {
/* 413 */           beanName = "&" + beanName;
/*     */         }
/* 415 */         matches.put(beanName, (T)beanInstance);
/*     */       } 
/*     */     } 
/*     */     
/* 419 */     return matches;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType) {
/* 424 */     List<String> results = new ArrayList<>();
/* 425 */     for (String beanName : this.beans.keySet()) {
/* 426 */       if (findAnnotationOnBean(beanName, annotationType) != null) {
/* 427 */         results.add(beanName);
/*     */       }
/*     */     } 
/* 430 */     return StringUtils.toStringArray(results);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType) throws BeansException {
/* 437 */     Map<String, Object> results = new LinkedHashMap<>();
/* 438 */     for (String beanName : this.beans.keySet()) {
/* 439 */       if (findAnnotationOnBean(beanName, annotationType) != null) {
/* 440 */         results.put(beanName, getBean(beanName));
/*     */       }
/*     */     } 
/* 443 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType) throws NoSuchBeanDefinitionException {
/* 451 */     return findAnnotationOnBean(beanName, annotationType, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/* 460 */     Class<?> beanType = getType(beanName, allowFactoryBeanInit);
/* 461 */     return (beanType != null) ? (A)AnnotatedElementUtils.findMergedAnnotation(beanType, annotationType) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> Set<A> findAllAnnotationsOnBean(String beanName, Class<A> annotationType, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/* 468 */     Class<?> beanType = getType(beanName, allowFactoryBeanInit);
/* 469 */     return (beanType != null) ? 
/* 470 */       AnnotatedElementUtils.findAllMergedAnnotations(beanType, annotationType) : Collections.<A>emptySet();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\StaticListableBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */