/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleInstantiationStrategy
/*     */   implements InstantiationStrategy
/*     */ {
/*  46 */   private static final ThreadLocal<Method> currentlyInvokedFactoryMethod = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Method getCurrentlyInvokedFactoryMethod() {
/*  56 */     return currentlyInvokedFactoryMethod.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public static void setCurrentlyInvokedFactoryMethod(@Nullable Method method) {
/*  68 */     if (method != null) {
/*  69 */       currentlyInvokedFactoryMethod.set(method);
/*     */     } else {
/*     */       
/*  72 */       currentlyInvokedFactoryMethod.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T instantiateWithFactoryMethod(Method method, Supplier<T> instanceSupplier) {
/*  86 */     Method priorInvokedFactoryMethod = currentlyInvokedFactoryMethod.get();
/*     */     try {
/*  88 */       currentlyInvokedFactoryMethod.set(method);
/*  89 */       return instanceSupplier.get();
/*     */     } finally {
/*     */       
/*  92 */       if (priorInvokedFactoryMethod != null) {
/*  93 */         currentlyInvokedFactoryMethod.set(priorInvokedFactoryMethod);
/*     */       } else {
/*     */         
/*  96 */         currentlyInvokedFactoryMethod.remove();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object instantiate(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner) {
/* 105 */     if (!bd.hasMethodOverrides()) {
/*     */       Constructor<?> constructorToUse;
/* 107 */       synchronized (bd.constructorArgumentLock) {
/* 108 */         constructorToUse = (Constructor)bd.resolvedConstructorOrFactoryMethod;
/* 109 */         if (constructorToUse == null) {
/* 110 */           Class<?> clazz = bd.getBeanClass();
/* 111 */           if (clazz.isInterface()) {
/* 112 */             throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */           }
/*     */           try {
/* 115 */             constructorToUse = clazz.getDeclaredConstructor(new Class[0]);
/* 116 */             bd.resolvedConstructorOrFactoryMethod = constructorToUse;
/*     */           }
/* 118 */           catch (Throwable ex) {
/* 119 */             throw new BeanInstantiationException(clazz, "No default constructor found", ex);
/*     */           } 
/*     */         } 
/*     */       } 
/* 123 */       return BeanUtils.instantiateClass(constructorToUse, new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/* 127 */     return instantiateWithMethodInjection(bd, beanName, owner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner) {
/* 138 */     throw new UnsupportedOperationException("Method Injection not supported in SimpleInstantiationStrategy");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object instantiate(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner, Constructor<?> ctor, Object... args) {
/* 145 */     if (!bd.hasMethodOverrides()) {
/* 146 */       return BeanUtils.instantiateClass(ctor, args);
/*     */     }
/*     */     
/* 149 */     return instantiateWithMethodInjection(bd, beanName, owner, ctor, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner, @Nullable Constructor<?> ctor, Object... args) {
/* 162 */     throw new UnsupportedOperationException("Method Injection not supported in SimpleInstantiationStrategy");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object instantiate(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner, @Nullable Object factoryBean, Method factoryMethod, Object... args) {
/* 169 */     return instantiateWithFactoryMethod(factoryMethod, () -> {
/*     */           try {
/*     */             ReflectionUtils.makeAccessible(factoryMethod);
/*     */             
/*     */             Object result = factoryMethod.invoke(factoryBean, args);
/*     */             if (result == null) {
/*     */               result = new NullBean();
/*     */             }
/*     */             return result;
/* 178 */           } catch (IllegalArgumentException ex) {
/*     */             if (factoryBean != null && !factoryMethod.getDeclaringClass().isAssignableFrom(factoryBean.getClass())) {
/*     */               throw new BeanInstantiationException(factoryMethod, "Illegal factory instance for factory method '" + factoryMethod.getName() + "'; instance: " + factoryBean.getClass().getName(), ex);
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             throw new BeanInstantiationException(factoryMethod, "Illegal arguments to factory method '" + factoryMethod.getName() + "'; args: " + StringUtils.arrayToCommaDelimitedString(args), ex);
/* 188 */           } catch (IllegalAccessException|java.lang.reflect.InaccessibleObjectException ex) {
/*     */             
/*     */             throw new BeanInstantiationException(factoryMethod, "Cannot access factory method '" + factoryMethod.getName() + "'; is it public?", ex);
/*     */           }
/* 192 */           catch (InvocationTargetException ex) {
/*     */             String msg = "Factory method '" + factoryMethod.getName() + "' threw exception with message: " + ex.getTargetException().getMessage();
/*     */             if (bd.getFactoryBeanName() != null && owner instanceof ConfigurableBeanFactory) {
/*     */               ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)owner;
/*     */               if (cbf.isCurrentlyInCreation(bd.getFactoryBeanName()))
/*     */                 msg = "Circular reference involving containing bean '" + bd.getFactoryBeanName() + "' - consider declaring the factory method as static for independence from its containing instance. " + msg; 
/*     */             } 
/*     */             throw new BeanInstantiationException(factoryMethod, msg, ex.getTargetException());
/*     */           } 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\SimpleInstantiationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */