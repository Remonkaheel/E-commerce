/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.core.AliasRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BeanDefinitionRegistry
/*     */   extends AliasRegistry
/*     */ {
/*     */   void registerBeanDefinition(String paramString, BeanDefinition paramBeanDefinition) throws BeanDefinitionStoreException;
/*     */   
/*     */   void removeBeanDefinition(String paramString) throws NoSuchBeanDefinitionException;
/*     */   
/*     */   BeanDefinition getBeanDefinition(String paramString) throws NoSuchBeanDefinitionException;
/*     */   
/*     */   boolean containsBeanDefinition(String paramString);
/*     */   
/*     */   String[] getBeanDefinitionNames();
/*     */   
/*     */   int getBeanDefinitionCount();
/*     */   
/*     */   default boolean isBeanDefinitionOverridable(String beanName) {
/* 110 */     return true;
/*     */   }
/*     */   
/*     */   boolean isBeanNameInUse(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\BeanDefinitionRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */