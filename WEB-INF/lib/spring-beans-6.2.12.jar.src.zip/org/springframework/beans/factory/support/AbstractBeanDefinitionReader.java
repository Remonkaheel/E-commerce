/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBeanDefinitionReader
/*     */   implements BeanDefinitionReader, EnvironmentCapable
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final BeanDefinitionRegistry registry;
/*     */   
/*     */   @Nullable
/*     */   private ResourceLoader resourceLoader;
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   private Environment environment;
/*     */   
/*  64 */   private BeanNameGenerator beanNameGenerator = DefaultBeanNameGenerator.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractBeanDefinitionReader(BeanDefinitionRegistry registry) {
/*  85 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  86 */     this.registry = registry;
/*     */ 
/*     */     
/*  89 */     BeanDefinitionRegistry beanDefinitionRegistry = this.registry; if (beanDefinitionRegistry instanceof ResourceLoader) { ResourceLoader _resourceLoader = (ResourceLoader)beanDefinitionRegistry;
/*  90 */       this.resourceLoader = _resourceLoader; }
/*     */     else
/*     */     
/*  93 */     { this.resourceLoader = (ResourceLoader)new PathMatchingResourcePatternResolver(); }
/*     */ 
/*     */ 
/*     */     
/*  97 */     beanDefinitionRegistry = this.registry; if (beanDefinitionRegistry instanceof EnvironmentCapable) { EnvironmentCapable environmentCapable = (EnvironmentCapable)beanDefinitionRegistry;
/*  98 */       this.environment = environmentCapable.getEnvironment(); }
/*     */     else
/*     */     
/* 101 */     { this.environment = (Environment)new StandardEnvironment(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final BeanDefinitionRegistry getRegistry() {
/* 108 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLoader(@Nullable ResourceLoader resourceLoader) {
/* 123 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResourceLoader getResourceLoader() {
/* 129 */     return this.resourceLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(@Nullable ClassLoader beanClassLoader) {
/* 140 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getBeanClassLoader() {
/* 146 */     return this.beanClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 155 */     Assert.notNull(environment, "Environment must not be null");
/* 156 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   public Environment getEnvironment() {
/* 161 */     return this.environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameGenerator(@Nullable BeanNameGenerator beanNameGenerator) {
/* 170 */     this.beanNameGenerator = (beanNameGenerator != null) ? beanNameGenerator : DefaultBeanNameGenerator.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanNameGenerator getBeanNameGenerator() {
/* 175 */     return this.beanNameGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(Resource... resources) throws BeanDefinitionStoreException {
/* 181 */     Assert.notNull(resources, "Resource array must not be null");
/* 182 */     int count = 0;
/* 183 */     for (Resource resource : resources) {
/* 184 */       count += loadBeanDefinitions(resource);
/*     */     }
/* 186 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(String location) throws BeanDefinitionStoreException {
/* 191 */     return loadBeanDefinitions(location, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(String location, @Nullable Set<Resource> actualResources) throws BeanDefinitionStoreException {
/* 210 */     ResourceLoader resourceLoader = getResourceLoader();
/* 211 */     if (resourceLoader == null) {
/* 212 */       throw new BeanDefinitionStoreException("Cannot load bean definitions from location [" + location + "]: no ResourceLoader available");
/*     */     }
/*     */ 
/*     */     
/* 216 */     if (resourceLoader instanceof ResourcePatternResolver) { ResourcePatternResolver resourcePatternResolver = (ResourcePatternResolver)resourceLoader;
/*     */       
/*     */       try {
/* 219 */         Resource[] resources = resourcePatternResolver.getResources(location);
/* 220 */         int i = loadBeanDefinitions(resources);
/* 221 */         if (actualResources != null) {
/* 222 */           Collections.addAll(actualResources, resources);
/*     */         }
/* 224 */         if (this.logger.isTraceEnabled()) {
/* 225 */           this.logger.trace("Loaded " + i + " bean definitions from location pattern [" + location + "]");
/*     */         }
/* 227 */         return i;
/*     */       }
/* 229 */       catch (IOException ex) {
/* 230 */         throw new BeanDefinitionStoreException("Could not resolve bean definition resource pattern [" + location + "]", ex);
/*     */       }  }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     Resource resource = resourceLoader.getResource(location);
/* 237 */     int count = loadBeanDefinitions(resource);
/* 238 */     if (actualResources != null) {
/* 239 */       actualResources.add(resource);
/*     */     }
/* 241 */     if (this.logger.isTraceEnabled()) {
/* 242 */       this.logger.trace("Loaded " + count + " bean definitions from location [" + location + "]");
/*     */     }
/* 244 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(String... locations) throws BeanDefinitionStoreException {
/* 250 */     Assert.notNull(locations, "Location array must not be null");
/* 251 */     int count = 0;
/* 252 */     for (String location : locations) {
/* 253 */       count += loadBeanDefinitions(location);
/*     */     }
/* 255 */     return count;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\AbstractBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */