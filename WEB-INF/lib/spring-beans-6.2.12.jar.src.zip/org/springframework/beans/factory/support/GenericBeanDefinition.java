/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericBeanDefinition
/*    */   extends AbstractBeanDefinition
/*    */ {
/*    */   @Nullable
/*    */   private String parentName;
/*    */   
/*    */   public GenericBeanDefinition() {}
/*    */   
/*    */   public GenericBeanDefinition(BeanDefinition original) {
/* 67 */     super(original);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParentName(@Nullable String parentName) {
/* 73 */     this.parentName = parentName;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getParentName() {
/* 79 */     return this.parentName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AbstractBeanDefinition cloneBeanDefinition() {
/* 85 */     return new GenericBeanDefinition(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 90 */     if (this != other) { if (other instanceof GenericBeanDefinition) { GenericBeanDefinition that = (GenericBeanDefinition)other;
/* 91 */         if (ObjectUtils.nullSafeEquals(this.parentName, that.parentName) && super.equals(other)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public String toString() {
/* 96 */     return (this.parentName != null) ? ("Generic bean with parent '" + 
/* 97 */       this.parentName + "': " + super.toString()) : ("Generic bean: " + 
/*    */       
/* 99 */       super.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\GenericBeanDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */