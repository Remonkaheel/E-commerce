/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements ObjectProvider<T>
/*     */ {
/*     */   public T getObject() throws BeansException {
/* 289 */     String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 290 */     if (beanNames.length == 1) {
/* 291 */       return (T)StaticListableBeanFactory.this.getBean(beanNames[0]);
/*     */     }
/* 293 */     if (beanNames.length > 1) {
/* 294 */       throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */     }
/*     */     
/* 297 */     throw new NoSuchBeanDefinitionException(requiredType);
/*     */   }
/*     */ 
/*     */   
/*     */   public T getObject(Object... args) throws BeansException {
/* 302 */     String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 303 */     if (beanNames.length == 1) {
/* 304 */       return (T)StaticListableBeanFactory.this.getBean(beanNames[0], args);
/*     */     }
/* 306 */     if (beanNames.length > 1) {
/* 307 */       throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */     }
/*     */     
/* 310 */     throw new NoSuchBeanDefinitionException(requiredType);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T getIfAvailable() throws BeansException {
/* 316 */     String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 317 */     if (beanNames.length == 1) {
/* 318 */       return (T)StaticListableBeanFactory.this.getBean(beanNames[0]);
/*     */     }
/* 320 */     if (beanNames.length > 1) {
/* 321 */       throw new NoUniqueBeanDefinitionException(requiredType, beanNames);
/*     */     }
/*     */     
/* 324 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T getIfUnique() throws BeansException {
/* 330 */     String[] beanNames = StaticListableBeanFactory.this.getBeanNamesForType(requiredType);
/* 331 */     if (beanNames.length == 1) {
/* 332 */       return (T)StaticListableBeanFactory.this.getBean(beanNames[0]);
/*     */     }
/*     */     
/* 335 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<T> stream() {
/* 340 */     return Arrays.<String>stream(StaticListableBeanFactory.this.getBeanNamesForType(requiredType)).map(name -> StaticListableBeanFactory.this.getBean(name));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\StaticListableBeanFactory$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */