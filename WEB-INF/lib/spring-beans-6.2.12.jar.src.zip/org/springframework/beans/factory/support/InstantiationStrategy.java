/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InstantiationStrategy
/*    */ {
/*    */   Object instantiate(RootBeanDefinition paramRootBeanDefinition, @Nullable String paramString, BeanFactory paramBeanFactory) throws BeansException;
/*    */   
/*    */   Object instantiate(RootBeanDefinition paramRootBeanDefinition, @Nullable String paramString, BeanFactory paramBeanFactory, Constructor<?> paramConstructor, Object... paramVarArgs) throws BeansException;
/*    */   
/*    */   Object instantiate(RootBeanDefinition paramRootBeanDefinition, @Nullable String paramString, BeanFactory paramBeanFactory, @Nullable Object paramObject, Method paramMethod, Object... paramVarArgs) throws BeansException;
/*    */   
/*    */   default Class<?> getActualBeanClass(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner) {
/* 91 */     return bd.getBeanClass();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\InstantiationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */