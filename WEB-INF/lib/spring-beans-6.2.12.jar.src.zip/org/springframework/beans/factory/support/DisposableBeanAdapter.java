/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DisposableBeanAdapter
/*     */   implements DisposableBean, Runnable, Serializable
/*     */ {
/*     */   private static final String DESTROY_METHOD_NAME = "destroy";
/*     */   private static final String CLOSE_METHOD_NAME = "close";
/*     */   private static final String SHUTDOWN_METHOD_NAME = "shutdown";
/*  77 */   private static final Log logger = LogFactory.getLog(DisposableBeanAdapter.class);
/*     */   
/*  79 */   private static final boolean reactiveStreamsPresent = ClassUtils.isPresent("org.reactivestreams.Publisher", DisposableBeanAdapter.class
/*  80 */       .getClassLoader());
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object bean;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String beanName;
/*     */ 
/*     */   
/*     */   private final boolean nonPublicAccessAllowed;
/*     */ 
/*     */   
/*     */   private final boolean invokeDisposableBean;
/*     */ 
/*     */   
/*     */   private boolean invokeAutoCloseable;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String[] destroyMethodNames;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private transient Method[] destroyMethods;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final List<DestructionAwareBeanPostProcessor> beanPostProcessors;
/*     */ 
/*     */ 
/*     */   
/*     */   public DisposableBeanAdapter(Object bean, String beanName, RootBeanDefinition beanDefinition, List<DestructionAwareBeanPostProcessor> postProcessors) {
/* 114 */     Assert.notNull(bean, "Disposable bean must not be null");
/* 115 */     this.bean = bean;
/* 116 */     this.beanName = beanName;
/* 117 */     this.nonPublicAccessAllowed = beanDefinition.isNonPublicAccessAllowed();
/* 118 */     this
/* 119 */       .invokeDisposableBean = (bean instanceof DisposableBean && !beanDefinition.hasAnyExternallyManagedDestroyMethod("destroy"));
/*     */     
/* 121 */     String[] destroyMethodNames = inferDestroyMethodsIfNecessary(bean.getClass(), beanDefinition);
/* 122 */     if (!ObjectUtils.isEmpty((Object[])destroyMethodNames) && (!this.invokeDisposableBean || 
/* 123 */       !"destroy".equals(destroyMethodNames[0])) && 
/* 124 */       !beanDefinition.hasAnyExternallyManagedDestroyMethod(destroyMethodNames[0])) {
/*     */       
/* 126 */       this
/* 127 */         .invokeAutoCloseable = (bean instanceof AutoCloseable && "close".equals(destroyMethodNames[0]));
/* 128 */       if (!this.invokeAutoCloseable) {
/* 129 */         this.destroyMethodNames = destroyMethodNames;
/* 130 */         List<Method> destroyMethods = new ArrayList<>(destroyMethodNames.length);
/* 131 */         for (String destroyMethodName : destroyMethodNames) {
/* 132 */           Method destroyMethod = determineDestroyMethod(destroyMethodName);
/* 133 */           if (destroyMethod == null) {
/* 134 */             if (beanDefinition.isEnforceDestroyMethod()) {
/* 135 */               throw new BeanDefinitionValidationException("Could not find a destroy method named '" + destroyMethodName + "' on bean with name '" + beanName + "'");
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 140 */             if (destroyMethod.getParameterCount() > 0) {
/* 141 */               Class<?>[] paramTypes = destroyMethod.getParameterTypes();
/* 142 */               if (paramTypes.length > 1) {
/* 143 */                 throw new BeanDefinitionValidationException("Method '" + destroyMethodName + "' of bean '" + beanName + "' has more than one parameter - not supported as destroy method");
/*     */               }
/*     */               
/* 146 */               if (paramTypes.length == 1 && boolean.class != paramTypes[0]) {
/* 147 */                 throw new BeanDefinitionValidationException("Method '" + destroyMethodName + "' of bean '" + beanName + "' has a non-boolean parameter - not supported as destroy method");
/*     */               }
/*     */             } 
/*     */             
/* 151 */             destroyMethod = ClassUtils.getPubliclyAccessibleMethodIfPossible(destroyMethod, bean.getClass());
/* 152 */             destroyMethods.add(destroyMethod);
/*     */           } 
/*     */         } 
/* 155 */         this.destroyMethods = (Method[])destroyMethods.toArray(x$0 -> new Method[x$0]);
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     this.beanPostProcessors = filterPostProcessors(postProcessors, bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DisposableBeanAdapter(Object bean, List<DestructionAwareBeanPostProcessor> postProcessors) {
/* 169 */     Assert.notNull(bean, "Disposable bean must not be null");
/* 170 */     this.bean = bean;
/* 171 */     this.beanName = bean.getClass().getName();
/* 172 */     this.nonPublicAccessAllowed = true;
/* 173 */     this.invokeDisposableBean = this.bean instanceof DisposableBean;
/* 174 */     this.beanPostProcessors = filterPostProcessors(postProcessors, bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DisposableBeanAdapter(Object bean, String beanName, boolean nonPublicAccessAllowed, boolean invokeDisposableBean, boolean invokeAutoCloseable, @Nullable String[] destroyMethodNames, @Nullable List<DestructionAwareBeanPostProcessor> postProcessors) {
/* 184 */     this.bean = bean;
/* 185 */     this.beanName = beanName;
/* 186 */     this.nonPublicAccessAllowed = nonPublicAccessAllowed;
/* 187 */     this.invokeDisposableBean = invokeDisposableBean;
/* 188 */     this.invokeAutoCloseable = invokeAutoCloseable;
/* 189 */     this.destroyMethodNames = destroyMethodNames;
/* 190 */     this.beanPostProcessors = postProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 196 */     destroy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 201 */     if (!CollectionUtils.isEmpty(this.beanPostProcessors)) {
/* 202 */       for (DestructionAwareBeanPostProcessor processor : this.beanPostProcessors) {
/* 203 */         processor.postProcessBeforeDestruction(this.bean, this.beanName);
/*     */       }
/*     */     }
/*     */     
/* 207 */     if (this.invokeDisposableBean) {
/* 208 */       if (logger.isTraceEnabled()) {
/* 209 */         logger.trace("Invoking destroy() on bean with name '" + this.beanName + "'");
/*     */       }
/*     */       try {
/* 212 */         ((DisposableBean)this.bean).destroy();
/*     */       }
/* 214 */       catch (Throwable ex) {
/* 215 */         if (logger.isWarnEnabled()) {
/* 216 */           String msg = "Invocation of destroy method failed on bean with name '" + this.beanName + "'";
/* 217 */           if (logger.isDebugEnabled()) {
/*     */             
/* 219 */             logger.warn(msg, ex);
/*     */           } else {
/*     */             
/* 222 */             logger.warn(msg + ": " + msg);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 228 */     if (this.invokeAutoCloseable) {
/* 229 */       if (logger.isTraceEnabled()) {
/* 230 */         logger.trace("Invoking close() on bean with name '" + this.beanName + "'");
/*     */       }
/*     */       try {
/* 233 */         ((AutoCloseable)this.bean).close();
/*     */       }
/* 235 */       catch (Throwable ex) {
/* 236 */         if (logger.isWarnEnabled()) {
/* 237 */           String msg = "Invocation of close method failed on bean with name '" + this.beanName + "'";
/* 238 */           if (logger.isDebugEnabled()) {
/*     */             
/* 240 */             logger.warn(msg, ex);
/*     */           } else {
/*     */             
/* 243 */             logger.warn(msg + ": " + msg);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 248 */     } else if (this.destroyMethods != null) {
/* 249 */       for (Method destroyMethod : this.destroyMethods) {
/* 250 */         invokeCustomDestroyMethod(destroyMethod);
/*     */       }
/*     */     }
/* 253 */     else if (this.destroyMethodNames != null) {
/* 254 */       for (String destroyMethodName : this.destroyMethodNames) {
/* 255 */         Method destroyMethod = determineDestroyMethod(destroyMethodName);
/* 256 */         if (destroyMethod != null) {
/* 257 */           destroyMethod = ClassUtils.getPubliclyAccessibleMethodIfPossible(destroyMethod, this.bean.getClass());
/* 258 */           invokeCustomDestroyMethod(destroyMethod);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Method determineDestroyMethod(String destroyMethodName) {
/*     */     try {
/* 268 */       Class<?> beanClass = this.bean.getClass();
/* 269 */       MethodDescriptor descriptor = MethodDescriptor.create(this.beanName, beanClass, destroyMethodName);
/* 270 */       String methodName = descriptor.methodName();
/*     */       
/* 272 */       Method destroyMethod = findDestroyMethod(descriptor.declaringClass(), methodName);
/* 273 */       if (destroyMethod != null) {
/* 274 */         return destroyMethod;
/*     */       }
/* 276 */       for (Class<?> beanInterface : ClassUtils.getAllInterfacesForClass(beanClass)) {
/* 277 */         destroyMethod = findDestroyMethod(beanInterface, methodName);
/* 278 */         if (destroyMethod != null) {
/* 279 */           return destroyMethod;
/*     */         }
/*     */       } 
/* 282 */       return null;
/*     */     }
/* 284 */     catch (IllegalArgumentException ex) {
/* 285 */       throw new BeanDefinitionValidationException("Could not find unique destroy method on bean with name '" + this.beanName + ": " + ex
/* 286 */           .getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Method findDestroyMethod(Class<?> clazz, String name) {
/* 292 */     return this.nonPublicAccessAllowed ? 
/* 293 */       BeanUtils.findMethodWithMinimalParameters(clazz, name) : 
/* 294 */       BeanUtils.findMethodWithMinimalParameters(clazz.getMethods(), name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invokeCustomDestroyMethod(Method destroyMethod) {
/* 304 */     if (logger.isTraceEnabled()) {
/* 305 */       logger.trace("Invoking custom destroy method '" + destroyMethod.getName() + "' on bean with name '" + this.beanName + "': " + String.valueOf(destroyMethod));
/*     */     }
/*     */ 
/*     */     
/* 309 */     int paramCount = destroyMethod.getParameterCount();
/* 310 */     Object[] args = new Object[paramCount];
/* 311 */     if (paramCount == 1) {
/* 312 */       args[0] = Boolean.TRUE;
/*     */     }
/*     */     
/*     */     try {
/* 316 */       ReflectionUtils.makeAccessible(destroyMethod);
/* 317 */       Object returnValue = destroyMethod.invoke(this.bean, args);
/*     */       
/* 319 */       if (returnValue == null)
/*     */       
/* 321 */       { logDestroyMethodCompletion(destroyMethod, false); }
/*     */       
/* 323 */       else if (returnValue instanceof Future) { Future<?> future = (Future)returnValue;
/*     */         
/* 325 */         future.get();
/* 326 */         logDestroyMethodCompletion(destroyMethod, true); }
/*     */       
/* 328 */       else if ((!reactiveStreamsPresent || !(new ReactiveDestroyMethodHandler()).await(destroyMethod, returnValue)) && 
/* 329 */         logger.isDebugEnabled())
/* 330 */       { logger.debug("Unknown return value type from custom destroy method '" + destroyMethod.getName() + "' on bean with name '" + this.beanName + "': " + 
/* 331 */             String.valueOf(returnValue.getClass())); }
/*     */ 
/*     */     
/*     */     }
/* 335 */     catch (InvocationTargetException|java.util.concurrent.ExecutionException ex) {
/* 336 */       logDestroyMethodException(destroyMethod, ex.getCause());
/*     */     }
/* 338 */     catch (Throwable ex) {
/* 339 */       if (logger.isWarnEnabled()) {
/* 340 */         logger.warn("Failed to invoke custom destroy method '" + destroyMethod.getName() + "' on bean with name '" + this.beanName + "'", ex);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void logDestroyMethodException(Method destroyMethod, @Nullable Throwable ex) {
/* 347 */     if (logger.isWarnEnabled()) {
/* 348 */       String msg = "Custom destroy method '" + destroyMethod.getName() + "' on bean with name '" + this.beanName + "' propagated an exception";
/*     */       
/* 350 */       if (logger.isDebugEnabled()) {
/*     */         
/* 352 */         logger.warn(msg, ex);
/*     */       } else {
/*     */         
/* 355 */         logger.warn(msg + ": " + msg);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void logDestroyMethodCompletion(Method destroyMethod, boolean async) {
/* 361 */     if (logger.isDebugEnabled()) {
/* 362 */       logger.debug("Custom destroy method '" + destroyMethod.getName() + "' on bean with name '" + this.beanName + "' completed" + (
/* 363 */           async ? " asynchronously" : ""));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object writeReplace() {
/* 373 */     List<DestructionAwareBeanPostProcessor> serializablePostProcessors = null;
/* 374 */     if (this.beanPostProcessors != null) {
/* 375 */       serializablePostProcessors = new ArrayList<>();
/* 376 */       for (DestructionAwareBeanPostProcessor postProcessor : this.beanPostProcessors) {
/* 377 */         if (postProcessor instanceof Serializable) {
/* 378 */           serializablePostProcessors.add(postProcessor);
/*     */         }
/*     */       } 
/*     */     } 
/* 382 */     return new DisposableBeanAdapter(this.bean, this.beanName, this.nonPublicAccessAllowed, this.invokeDisposableBean, this.invokeAutoCloseable, this.destroyMethodNames, serializablePostProcessors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasDestroyMethod(Object bean, RootBeanDefinition beanDefinition) {
/* 394 */     return (bean instanceof DisposableBean || 
/* 395 */       inferDestroyMethodsIfNecessary(bean.getClass(), beanDefinition) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static String[] inferDestroyMethodsIfNecessary(Class<?> target, RootBeanDefinition beanDefinition) {
/* 414 */     String[] destroyMethodNames = beanDefinition.getDestroyMethodNames();
/* 415 */     if (destroyMethodNames != null && destroyMethodNames.length > 1) {
/* 416 */       return destroyMethodNames;
/*     */     }
/*     */     
/* 419 */     String destroyMethodName = beanDefinition.resolvedDestroyMethodName;
/* 420 */     if (destroyMethodName == null) {
/* 421 */       destroyMethodName = beanDefinition.getDestroyMethodName();
/* 422 */       boolean autoCloseable = AutoCloseable.class.isAssignableFrom(target);
/* 423 */       boolean executorService = ExecutorService.class.isAssignableFrom(target);
/* 424 */       if ("(inferred)".equals(destroyMethodName) || (destroyMethodName == null && (autoCloseable || executorService))) {
/*     */ 
/*     */ 
/*     */         
/* 428 */         destroyMethodName = null;
/* 429 */         if (!DisposableBean.class.isAssignableFrom(target)) {
/* 430 */           if (executorService) {
/* 431 */             destroyMethodName = "shutdown";
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 436 */               if (target.getMethod("close", new Class[0]).getDeclaringClass() != ExecutorService.class) {
/* 437 */                 destroyMethodName = "close";
/*     */               }
/*     */             }
/* 440 */             catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */           
/*     */           }
/* 444 */           else if (autoCloseable) {
/* 445 */             destroyMethodName = "close";
/*     */           } else {
/*     */             
/*     */             try {
/* 449 */               destroyMethodName = target.getMethod("close", new Class[0]).getName();
/*     */             }
/* 451 */             catch (NoSuchMethodException ex) {
/*     */               try {
/* 453 */                 destroyMethodName = target.getMethod("shutdown", new Class[0]).getName();
/*     */               }
/* 455 */               catch (NoSuchMethodException noSuchMethodException) {}
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 462 */       beanDefinition.resolvedDestroyMethodName = (destroyMethodName != null) ? destroyMethodName : "";
/*     */     } 
/* 464 */     (new String[1])[0] = destroyMethodName; return StringUtils.hasLength(destroyMethodName) ? new String[1] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasApplicableProcessors(Object bean, List<DestructionAwareBeanPostProcessor> postProcessors) {
/* 473 */     if (!CollectionUtils.isEmpty(postProcessors)) {
/* 474 */       for (DestructionAwareBeanPostProcessor processor : postProcessors) {
/* 475 */         if (processor.requiresDestruction(bean)) {
/* 476 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 480 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static List<DestructionAwareBeanPostProcessor> filterPostProcessors(List<DestructionAwareBeanPostProcessor> processors, Object bean) {
/* 492 */     List<DestructionAwareBeanPostProcessor> filteredPostProcessors = null;
/* 493 */     if (!CollectionUtils.isEmpty(processors)) {
/* 494 */       filteredPostProcessors = new ArrayList<>(processors.size());
/* 495 */       for (DestructionAwareBeanPostProcessor processor : processors) {
/* 496 */         if (processor.requiresDestruction(bean)) {
/* 497 */           filteredPostProcessors.add(processor);
/*     */         }
/*     */       } 
/*     */     } 
/* 501 */     return filteredPostProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ReactiveDestroyMethodHandler
/*     */   {
/*     */     public boolean await(Method destroyMethod, Object returnValue) throws InterruptedException {
/* 511 */       ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(returnValue.getClass());
/* 512 */       if (adapter != null) {
/* 513 */         CountDownLatch latch = new CountDownLatch(1);
/* 514 */         adapter.toPublisher(returnValue).subscribe(new DisposableBeanAdapter.DestroyMethodSubscriber(destroyMethod, latch));
/* 515 */         latch.await();
/* 516 */         return true;
/*     */       } 
/* 518 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class DestroyMethodSubscriber
/*     */     implements Subscriber<Object>
/*     */   {
/*     */     private final Method destroyMethod;
/*     */     
/*     */     private final CountDownLatch latch;
/*     */ 
/*     */     
/*     */     public DestroyMethodSubscriber(Method destroyMethod, CountDownLatch latch) {
/* 533 */       this.destroyMethod = destroyMethod;
/* 534 */       this.latch = latch;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 539 */       s.request(2147483647L);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void onNext(Object o) {}
/*     */ 
/*     */     
/*     */     public void onError(Throwable t) {
/* 548 */       this.latch.countDown();
/* 549 */       DisposableBeanAdapter.this.logDestroyMethodException(this.destroyMethod, t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 554 */       this.latch.countDown();
/* 555 */       DisposableBeanAdapter.this.logDestroyMethodCompletion(this.destroyMethod, true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\DisposableBeanAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */