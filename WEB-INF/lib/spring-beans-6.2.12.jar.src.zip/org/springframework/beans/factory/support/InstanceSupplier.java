/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.ThrowingBiFunction;
/*     */ import org.springframework.util.function.ThrowingSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface InstanceSupplier<T>
/*     */   extends ThrowingSupplier<T>
/*     */ {
/*     */   default T getWithException() {
/*  45 */     throw new IllegalStateException("No RegisteredBean parameter provided");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default Method getFactoryMethod() {
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <V> InstanceSupplier<V> andThen(final ThrowingBiFunction<RegisteredBean, ? super T, ? extends V> after) {
/*  79 */     Assert.notNull(after, "'after' function must not be null");
/*  80 */     return new InstanceSupplier<V>()
/*     */       {
/*     */         public V get(RegisteredBean registeredBean) throws Exception {
/*  83 */           return (V)after.applyWithException(registeredBean, InstanceSupplier.this.get(registeredBean));
/*     */         }
/*     */         
/*     */         @Nullable
/*     */         public Method getFactoryMethod() {
/*  88 */           return InstanceSupplier.this.getFactoryMethod();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> InstanceSupplier<T> using(ThrowingSupplier<T> supplier) {
/* 101 */     Assert.notNull(supplier, "Supplier must not be null");
/* 102 */     if (supplier instanceof InstanceSupplier) { InstanceSupplier<T> instanceSupplier = (InstanceSupplier<T>)supplier;
/* 103 */       return instanceSupplier; }
/*     */     
/* 105 */     return registeredBean -> supplier.getWithException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> InstanceSupplier<T> using(@Nullable final Method factoryMethod, final ThrowingSupplier<T> supplier) {
/* 117 */     Assert.notNull(supplier, "Supplier must not be null");
/*     */     
/* 119 */     if (supplier instanceof InstanceSupplier) { InstanceSupplier<T> instanceSupplier = (InstanceSupplier<T>)supplier; if (instanceSupplier
/* 120 */         .getFactoryMethod() == factoryMethod) {
/* 121 */         return instanceSupplier;
/*     */       } }
/*     */     
/* 124 */     return new InstanceSupplier<T>()
/*     */       {
/*     */         public T get(RegisteredBean registeredBean) throws Exception {
/* 127 */           return (T)supplier.getWithException();
/*     */         }
/*     */         
/*     */         @Nullable
/*     */         public Method getFactoryMethod() {
/* 132 */           return factoryMethod;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> InstanceSupplier<T> of(InstanceSupplier<T> instanceSupplier) {
/* 146 */     Assert.notNull(instanceSupplier, "InstanceSupplier must not be null");
/* 147 */     return instanceSupplier;
/*     */   }
/*     */   
/*     */   T get(RegisteredBean paramRegisteredBean) throws Exception;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\InstanceSupplier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */