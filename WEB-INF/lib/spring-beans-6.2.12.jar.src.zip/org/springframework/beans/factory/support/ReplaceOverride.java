/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplaceOverride
/*     */   extends MethodOverride
/*     */ {
/*     */   private final String methodReplacerBeanName;
/*  43 */   private final List<String> typeIdentifiers = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplaceOverride(String methodName, String methodReplacerBeanName) {
/*  52 */     super(methodName);
/*  53 */     Assert.notNull(methodReplacerBeanName, "Method replacer bean name must not be null");
/*  54 */     this.methodReplacerBeanName = methodReplacerBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplaceOverride(String methodName, String methodReplacerBeanName, List<String> typeIdentifiers) {
/*  65 */     super(methodName);
/*  66 */     Assert.notNull(methodReplacerBeanName, "Method replacer bean name must not be null");
/*  67 */     this.methodReplacerBeanName = methodReplacerBeanName;
/*  68 */     this.typeIdentifiers.addAll(typeIdentifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodReplacerBeanName() {
/*  76 */     return this.methodReplacerBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTypeIdentifier(String identifier) {
/*  85 */     this.typeIdentifiers.add(identifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getTypeIdentifiers() {
/*  94 */     return Collections.unmodifiableList(this.typeIdentifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Method method) {
/* 100 */     if (!method.getName().equals(getMethodName())) {
/* 101 */       return false;
/*     */     }
/* 103 */     if (!isOverloaded())
/*     */     {
/* 105 */       return true;
/*     */     }
/*     */     
/* 108 */     if (this.typeIdentifiers.size() != method.getParameterCount()) {
/* 109 */       return false;
/*     */     }
/* 111 */     Class<?>[] parameterTypes = method.getParameterTypes();
/* 112 */     for (int i = 0; i < this.typeIdentifiers.size(); i++) {
/* 113 */       String identifier = this.typeIdentifiers.get(i);
/* 114 */       if (!parameterTypes[i].getName().contains(identifier)) {
/* 115 */         return false;
/*     */       }
/*     */     } 
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: instanceof org/springframework/beans/factory/support/ReplaceOverride
/*     */     //   4: ifeq -> 54
/*     */     //   7: aload_1
/*     */     //   8: checkcast org/springframework/beans/factory/support/ReplaceOverride
/*     */     //   11: astore_2
/*     */     //   12: aload_0
/*     */     //   13: aload_2
/*     */     //   14: invokespecial equals : (Ljava/lang/Object;)Z
/*     */     //   17: ifeq -> 54
/*     */     //   20: aload_0
/*     */     //   21: getfield methodReplacerBeanName : Ljava/lang/String;
/*     */     //   24: aload_2
/*     */     //   25: getfield methodReplacerBeanName : Ljava/lang/String;
/*     */     //   28: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   31: ifeq -> 54
/*     */     //   34: aload_0
/*     */     //   35: getfield typeIdentifiers : Ljava/util/List;
/*     */     //   38: aload_2
/*     */     //   39: getfield typeIdentifiers : Ljava/util/List;
/*     */     //   42: invokeinterface equals : (Ljava/lang/Object;)Z
/*     */     //   47: ifeq -> 54
/*     */     //   50: iconst_1
/*     */     //   51: goto -> 55
/*     */     //   54: iconst_0
/*     */     //   55: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #125	-> 0
/*     */     //   #124	-> 7
/*     */     //   #125	-> 28
/*     */     //   #126	-> 42
/*     */     //   #124	-> 55
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   12	42	2	that	Lorg/springframework/beans/factory/support/ReplaceOverride;
/*     */     //   0	56	0	this	Lorg/springframework/beans/factory/support/ReplaceOverride;
/*     */     //   0	56	1	other	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 131 */     return Objects.hash(new Object[] { this.methodReplacerBeanName, this.typeIdentifiers });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "ReplaceOverride for method '" + getMethodName() + "'";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\ReplaceOverride.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */