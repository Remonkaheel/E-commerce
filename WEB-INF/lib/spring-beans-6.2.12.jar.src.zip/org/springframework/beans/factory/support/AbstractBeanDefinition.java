/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.Arrays;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Supplier;
/*      */ import org.springframework.beans.BeanMetadataAttributeAccessor;
/*      */ import org.springframework.beans.MutablePropertyValues;
/*      */ import org.springframework.beans.PropertyValues;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.core.AttributeAccessor;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.core.io.DescriptiveResource;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractBeanDefinition
/*      */   extends BeanMetadataAttributeAccessor
/*      */   implements BeanDefinition, Cloneable
/*      */ {
/*      */   public static final String SCOPE_DEFAULT = "";
/*      */   public static final int AUTOWIRE_NO = 0;
/*      */   public static final int AUTOWIRE_BY_NAME = 1;
/*      */   public static final int AUTOWIRE_BY_TYPE = 2;
/*      */   public static final int AUTOWIRE_CONSTRUCTOR = 3;
/*      */   @Deprecated
/*      */   public static final int AUTOWIRE_AUTODETECT = 4;
/*      */   public static final int DEPENDENCY_CHECK_NONE = 0;
/*      */   public static final int DEPENDENCY_CHECK_OBJECTS = 1;
/*      */   public static final int DEPENDENCY_CHECK_SIMPLE = 2;
/*      */   public static final int DEPENDENCY_CHECK_ALL = 3;
/*      */   public static final String PREFERRED_CONSTRUCTORS_ATTRIBUTE = "preferredConstructors";
/*      */   public static final String ORDER_ATTRIBUTE = "order";
/*      */   public static final String INFER_METHOD = "(inferred)";
/*      */   @Nullable
/*      */   private volatile Object beanClass;
/*      */   @Nullable
/*  171 */   private String scope = "";
/*      */ 
/*      */   
/*      */   private boolean abstractFlag = false;
/*      */   
/*      */   private boolean backgroundInit = false;
/*      */   
/*      */   @Nullable
/*      */   private Boolean lazyInit;
/*      */   
/*  181 */   private int autowireMode = 0;
/*      */   
/*  183 */   private int dependencyCheck = 0;
/*      */   
/*      */   @Nullable
/*      */   private String[] dependsOn;
/*      */   
/*      */   private boolean autowireCandidate = true;
/*      */   
/*      */   private boolean defaultCandidate = true;
/*      */   
/*      */   private boolean primary = false;
/*      */   
/*      */   private boolean fallback = false;
/*      */   
/*  196 */   private final Map<String, AutowireCandidateQualifier> qualifiers = new LinkedHashMap<>();
/*      */   
/*      */   @Nullable
/*      */   private Supplier<?> instanceSupplier;
/*      */   
/*      */   private boolean nonPublicAccessAllowed = true;
/*      */   
/*      */   private boolean lenientConstructorResolution = true;
/*      */   
/*      */   @Nullable
/*      */   private String factoryBeanName;
/*      */   
/*      */   @Nullable
/*      */   private String factoryMethodName;
/*      */   
/*      */   @Nullable
/*      */   private ConstructorArgumentValues constructorArgumentValues;
/*      */   
/*      */   @Nullable
/*      */   private MutablePropertyValues propertyValues;
/*      */   
/*  217 */   private MethodOverrides methodOverrides = new MethodOverrides();
/*      */   
/*      */   @Nullable
/*      */   private String[] initMethodNames;
/*      */   
/*      */   @Nullable
/*      */   private String[] destroyMethodNames;
/*      */   
/*      */   private boolean enforceInitMethod = true;
/*      */   
/*      */   private boolean enforceDestroyMethod = true;
/*      */   
/*      */   private boolean synthetic = false;
/*      */   
/*  231 */   private int role = 0;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private String description;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Resource resource;
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractBeanDefinition() {
/*  244 */     this((ConstructorArgumentValues)null, (MutablePropertyValues)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractBeanDefinition(@Nullable ConstructorArgumentValues cargs, @Nullable MutablePropertyValues pvs) {
/*  252 */     this.constructorArgumentValues = cargs;
/*  253 */     this.propertyValues = pvs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractBeanDefinition(BeanDefinition original) {
/*  262 */     setParentName(original.getParentName());
/*  263 */     setBeanClassName(original.getBeanClassName());
/*  264 */     setScope(original.getScope());
/*  265 */     setAbstract(original.isAbstract());
/*  266 */     setFactoryBeanName(original.getFactoryBeanName());
/*  267 */     setFactoryMethodName(original.getFactoryMethodName());
/*  268 */     setRole(original.getRole());
/*  269 */     setSource(original.getSource());
/*  270 */     copyAttributesFrom((AttributeAccessor)original);
/*      */     
/*  272 */     if (original instanceof AbstractBeanDefinition) { AbstractBeanDefinition originalAbd = (AbstractBeanDefinition)original;
/*  273 */       if (originalAbd.hasBeanClass()) {
/*  274 */         setBeanClass(originalAbd.getBeanClass());
/*      */       }
/*  276 */       if (originalAbd.hasConstructorArgumentValues()) {
/*  277 */         setConstructorArgumentValues(new ConstructorArgumentValues(original.getConstructorArgumentValues()));
/*      */       }
/*  279 */       if (originalAbd.hasPropertyValues()) {
/*  280 */         setPropertyValues(new MutablePropertyValues((PropertyValues)original.getPropertyValues()));
/*      */       }
/*  282 */       if (originalAbd.hasMethodOverrides()) {
/*  283 */         setMethodOverrides(new MethodOverrides(originalAbd.getMethodOverrides()));
/*      */       }
/*  285 */       setBackgroundInit(originalAbd.isBackgroundInit());
/*  286 */       Boolean lazyInit = originalAbd.getLazyInit();
/*  287 */       if (lazyInit != null) {
/*  288 */         setLazyInit(lazyInit.booleanValue());
/*      */       }
/*  290 */       setAutowireMode(originalAbd.getAutowireMode());
/*  291 */       setDependencyCheck(originalAbd.getDependencyCheck());
/*  292 */       setDependsOn(originalAbd.getDependsOn());
/*  293 */       setAutowireCandidate(originalAbd.isAutowireCandidate());
/*  294 */       setDefaultCandidate(originalAbd.isDefaultCandidate());
/*  295 */       setPrimary(originalAbd.isPrimary());
/*  296 */       setFallback(originalAbd.isFallback());
/*  297 */       copyQualifiersFrom(originalAbd);
/*  298 */       setInstanceSupplier(originalAbd.getInstanceSupplier());
/*  299 */       setNonPublicAccessAllowed(originalAbd.isNonPublicAccessAllowed());
/*  300 */       setLenientConstructorResolution(originalAbd.isLenientConstructorResolution());
/*  301 */       setInitMethodNames(originalAbd.getInitMethodNames());
/*  302 */       setEnforceInitMethod(originalAbd.isEnforceInitMethod());
/*  303 */       setDestroyMethodNames(originalAbd.getDestroyMethodNames());
/*  304 */       setEnforceDestroyMethod(originalAbd.isEnforceDestroyMethod());
/*  305 */       setSynthetic(originalAbd.isSynthetic());
/*  306 */       setResource(originalAbd.getResource()); }
/*      */     else
/*      */     
/*  309 */     { setConstructorArgumentValues(new ConstructorArgumentValues(original.getConstructorArgumentValues()));
/*  310 */       setPropertyValues(new MutablePropertyValues((PropertyValues)original.getPropertyValues()));
/*  311 */       setLazyInit(original.isLazyInit());
/*  312 */       setResourceDescription(original.getResourceDescription()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void overrideFrom(BeanDefinition other) {
/*  334 */     if (StringUtils.hasLength(other.getBeanClassName())) {
/*  335 */       setBeanClassName(other.getBeanClassName());
/*      */     }
/*  337 */     if (StringUtils.hasLength(other.getScope())) {
/*  338 */       setScope(other.getScope());
/*      */     }
/*  340 */     setAbstract(other.isAbstract());
/*  341 */     if (StringUtils.hasLength(other.getFactoryBeanName())) {
/*  342 */       setFactoryBeanName(other.getFactoryBeanName());
/*      */     }
/*  344 */     if (StringUtils.hasLength(other.getFactoryMethodName())) {
/*  345 */       setFactoryMethodName(other.getFactoryMethodName());
/*      */     }
/*  347 */     setRole(other.getRole());
/*  348 */     setSource(other.getSource());
/*  349 */     copyAttributesFrom((AttributeAccessor)other);
/*      */     
/*  351 */     if (other instanceof AbstractBeanDefinition) { AbstractBeanDefinition otherAbd = (AbstractBeanDefinition)other;
/*  352 */       if (otherAbd.hasBeanClass()) {
/*  353 */         setBeanClass(otherAbd.getBeanClass());
/*      */       }
/*  355 */       if (otherAbd.hasConstructorArgumentValues()) {
/*  356 */         getConstructorArgumentValues().addArgumentValues(other.getConstructorArgumentValues());
/*      */       }
/*  358 */       if (otherAbd.hasPropertyValues()) {
/*  359 */         getPropertyValues().addPropertyValues((PropertyValues)other.getPropertyValues());
/*      */       }
/*  361 */       if (otherAbd.hasMethodOverrides()) {
/*  362 */         getMethodOverrides().addOverrides(otherAbd.getMethodOverrides());
/*      */       }
/*  364 */       setBackgroundInit(otherAbd.isBackgroundInit());
/*  365 */       Boolean lazyInit = otherAbd.getLazyInit();
/*  366 */       if (lazyInit != null) {
/*  367 */         setLazyInit(lazyInit.booleanValue());
/*      */       }
/*  369 */       setAutowireMode(otherAbd.getAutowireMode());
/*  370 */       setDependencyCheck(otherAbd.getDependencyCheck());
/*  371 */       setDependsOn(otherAbd.getDependsOn());
/*  372 */       setAutowireCandidate(otherAbd.isAutowireCandidate());
/*  373 */       setDefaultCandidate(otherAbd.isDefaultCandidate());
/*  374 */       setPrimary(otherAbd.isPrimary());
/*  375 */       setFallback(otherAbd.isFallback());
/*  376 */       copyQualifiersFrom(otherAbd);
/*  377 */       setInstanceSupplier(otherAbd.getInstanceSupplier());
/*  378 */       setNonPublicAccessAllowed(otherAbd.isNonPublicAccessAllowed());
/*  379 */       setLenientConstructorResolution(otherAbd.isLenientConstructorResolution());
/*  380 */       if (otherAbd.getInitMethodNames() != null) {
/*  381 */         setInitMethodNames(otherAbd.getInitMethodNames());
/*  382 */         setEnforceInitMethod(otherAbd.isEnforceInitMethod());
/*      */       } 
/*  384 */       if (otherAbd.getDestroyMethodNames() != null) {
/*  385 */         setDestroyMethodNames(otherAbd.getDestroyMethodNames());
/*  386 */         setEnforceDestroyMethod(otherAbd.isEnforceDestroyMethod());
/*      */       } 
/*  388 */       setSynthetic(otherAbd.isSynthetic());
/*  389 */       setResource(otherAbd.getResource()); }
/*      */     else
/*      */     
/*  392 */     { getConstructorArgumentValues().addArgumentValues(other.getConstructorArgumentValues());
/*  393 */       getPropertyValues().addPropertyValues((PropertyValues)other.getPropertyValues());
/*  394 */       setLazyInit(other.isLazyInit());
/*  395 */       setResourceDescription(other.getResourceDescription()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyDefaults(BeanDefinitionDefaults defaults) {
/*  405 */     Boolean lazyInit = defaults.getLazyInit();
/*  406 */     if (lazyInit != null) {
/*  407 */       setLazyInit(lazyInit.booleanValue());
/*      */     }
/*  409 */     setAutowireMode(defaults.getAutowireMode());
/*  410 */     setDependencyCheck(defaults.getDependencyCheck());
/*  411 */     setInitMethodName(defaults.getInitMethodName());
/*  412 */     setEnforceInitMethod(false);
/*  413 */     setDestroyMethodName(defaults.getDestroyMethodName());
/*  414 */     setEnforceDestroyMethod(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBeanClassName(@Nullable String beanClassName) {
/*  424 */     this.beanClass = beanClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getBeanClassName() {
/*  434 */     Object beanClassObject = this.beanClass;
/*  435 */     Class<?> clazz = (Class)beanClassObject; return (beanClassObject instanceof Class) ? clazz.getName() : (String)beanClassObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBeanClass(@Nullable Class<?> beanClass) {
/*  443 */     this.beanClass = beanClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> getBeanClass() throws IllegalStateException {
/*      */     Class<?> clazz;
/*  468 */     Object beanClassObject = this.beanClass;
/*  469 */     if (beanClassObject == null) {
/*  470 */       throw new IllegalStateException("No bean class specified on bean definition");
/*      */     }
/*  472 */     if (beanClassObject instanceof Class) { clazz = (Class)beanClassObject; }
/*  473 */     else { throw new IllegalStateException("Bean class name [" + String.valueOf(beanClassObject) + "] has not been resolved into an actual Class"); }
/*      */ 
/*      */     
/*  476 */     return clazz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasBeanClass() {
/*  486 */     return this.beanClass instanceof Class;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Class<?> resolveBeanClass(@Nullable ClassLoader classLoader) throws ClassNotFoundException {
/*  499 */     String className = getBeanClassName();
/*  500 */     if (className == null) {
/*  501 */       return null;
/*      */     }
/*  503 */     Class<?> resolvedClass = ClassUtils.forName(className, classLoader);
/*  504 */     this.beanClass = resolvedClass;
/*  505 */     return resolvedClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResolvableType getResolvableType() {
/*  514 */     return hasBeanClass() ? ResolvableType.forClass(getBeanClass()) : ResolvableType.NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScope(@Nullable String scope) {
/*  529 */     this.scope = scope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getScope() {
/*  539 */     return this.scope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSingleton() {
/*  548 */     return ("singleton".equals(this.scope) || "".equals(this.scope));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPrototype() {
/*  557 */     return "prototype".equals(this.scope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAbstract(boolean abstractFlag) {
/*  567 */     this.abstractFlag = abstractFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAbstract() {
/*  576 */     return this.abstractFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackgroundInit(boolean backgroundInit) {
/*  597 */     this.backgroundInit = backgroundInit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBackgroundInit() {
/*  607 */     return this.backgroundInit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLazyInit(boolean lazyInit) {
/*  616 */     this.lazyInit = Boolean.valueOf(lazyInit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLazyInit() {
/*  625 */     return (this.lazyInit != null && this.lazyInit.booleanValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Boolean getLazyInit() {
/*  636 */     return this.lazyInit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutowireMode(int autowireMode) {
/*  653 */     this.autowireMode = autowireMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAutowireMode() {
/*  660 */     return this.autowireMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResolvedAutowireMode() {
/*  671 */     if (this.autowireMode == 4) {
/*      */ 
/*      */ 
/*      */       
/*  675 */       Constructor[] arrayOfConstructor = (Constructor[])getBeanClass().getConstructors();
/*  676 */       for (Constructor<?> constructor : arrayOfConstructor) {
/*  677 */         if (constructor.getParameterCount() == 0) {
/*  678 */           return 2;
/*      */         }
/*      */       } 
/*  681 */       return 3;
/*      */     } 
/*      */     
/*  684 */     return this.autowireMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDependencyCheck(int dependencyCheck) {
/*  698 */     this.dependencyCheck = dependencyCheck;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDependencyCheck() {
/*  705 */     return this.dependencyCheck;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDependsOn(@Nullable String... dependsOn) {
/*  714 */     this.dependsOn = dependsOn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String[] getDependsOn() {
/*  724 */     return this.dependsOn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutowireCandidate(boolean autowireCandidate) {
/*  736 */     this.autowireCandidate = autowireCandidate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAutowireCandidate() {
/*  745 */     return this.autowireCandidate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultCandidate(boolean defaultCandidate) {
/*  758 */     this.defaultCandidate = defaultCandidate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDefaultCandidate() {
/*  769 */     return this.defaultCandidate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrimary(boolean primary) {
/*  778 */     this.primary = primary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPrimary() {
/*  787 */     return this.primary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFallback(boolean fallback) {
/*  796 */     this.fallback = fallback;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFallback() {
/*  805 */     return this.fallback;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addQualifier(AutowireCandidateQualifier qualifier) {
/*  814 */     this.qualifiers.put(qualifier.getTypeName(), qualifier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasQualifier(String typeName) {
/*  821 */     return this.qualifiers.containsKey(typeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public AutowireCandidateQualifier getQualifier(String typeName) {
/*  829 */     return this.qualifiers.get(typeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<AutowireCandidateQualifier> getQualifiers() {
/*  837 */     return new LinkedHashSet<>(this.qualifiers.values());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyQualifiersFrom(AbstractBeanDefinition source) {
/*  845 */     Assert.notNull(source, "Source must not be null");
/*  846 */     this.qualifiers.putAll(source.qualifiers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInstanceSupplier(@Nullable Supplier<?> instanceSupplier) {
/*  860 */     this.instanceSupplier = instanceSupplier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Supplier<?> getInstanceSupplier() {
/*  869 */     return this.instanceSupplier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNonPublicAccessAllowed(boolean nonPublicAccessAllowed) {
/*  884 */     this.nonPublicAccessAllowed = nonPublicAccessAllowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNonPublicAccessAllowed() {
/*  891 */     return this.nonPublicAccessAllowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLenientConstructorResolution(boolean lenientConstructorResolution) {
/*  901 */     this.lenientConstructorResolution = lenientConstructorResolution;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLenientConstructorResolution() {
/*  908 */     return this.lenientConstructorResolution;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFactoryBeanName(@Nullable String factoryBeanName) {
/*  917 */     this.factoryBeanName = factoryBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getFactoryBeanName() {
/*  927 */     return this.factoryBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFactoryMethodName(@Nullable String factoryMethodName) {
/*  938 */     this.factoryMethodName = factoryMethodName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getFactoryMethodName() {
/*  948 */     return this.factoryMethodName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConstructorArgumentValues(ConstructorArgumentValues constructorArgumentValues) {
/*  955 */     this.constructorArgumentValues = constructorArgumentValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorArgumentValues getConstructorArgumentValues() {
/*  964 */     ConstructorArgumentValues cav = this.constructorArgumentValues;
/*  965 */     if (cav == null) {
/*  966 */       cav = new ConstructorArgumentValues();
/*  967 */       this.constructorArgumentValues = cav;
/*      */     } 
/*  969 */     return cav;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasConstructorArgumentValues() {
/*  978 */     return (this.constructorArgumentValues != null && !this.constructorArgumentValues.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPropertyValues(MutablePropertyValues propertyValues) {
/*  985 */     this.propertyValues = propertyValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutablePropertyValues getPropertyValues() {
/*  994 */     MutablePropertyValues pvs = this.propertyValues;
/*  995 */     if (pvs == null) {
/*  996 */       pvs = new MutablePropertyValues();
/*  997 */       this.propertyValues = pvs;
/*      */     } 
/*  999 */     return pvs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasPropertyValues() {
/* 1008 */     return (this.propertyValues != null && !this.propertyValues.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMethodOverrides(MethodOverrides methodOverrides) {
/* 1015 */     this.methodOverrides = methodOverrides;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodOverrides getMethodOverrides() {
/* 1024 */     return this.methodOverrides;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasMethodOverrides() {
/* 1032 */     return !this.methodOverrides.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitMethodNames(@Nullable String... initMethodNames) {
/* 1042 */     this.initMethodNames = initMethodNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String[] getInitMethodNames() {
/* 1051 */     return this.initMethodNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitMethodName(@Nullable String initMethodName) {
/* 1061 */     (new String[1])[0] = initMethodName; this.initMethodNames = (initMethodName != null) ? new String[1] : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getInitMethodName() {
/* 1071 */     return !ObjectUtils.isEmpty((Object[])this.initMethodNames) ? this.initMethodNames[0] : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnforceInitMethod(boolean enforceInitMethod) {
/* 1084 */     this.enforceInitMethod = enforceInitMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnforceInitMethod() {
/* 1092 */     return this.enforceInitMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDestroyMethodNames(@Nullable String... destroyMethodNames) {
/* 1102 */     this.destroyMethodNames = destroyMethodNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String[] getDestroyMethodNames() {
/* 1111 */     return this.destroyMethodNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDestroyMethodName(@Nullable String destroyMethodName) {
/* 1121 */     (new String[1])[0] = destroyMethodName; this.destroyMethodNames = (destroyMethodName != null) ? new String[1] : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getDestroyMethodName() {
/* 1131 */     return !ObjectUtils.isEmpty((Object[])this.destroyMethodNames) ? this.destroyMethodNames[0] : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnforceDestroyMethod(boolean enforceDestroyMethod) {
/* 1144 */     this.enforceDestroyMethod = enforceDestroyMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnforceDestroyMethod() {
/* 1152 */     return this.enforceDestroyMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSynthetic(boolean synthetic) {
/* 1161 */     this.synthetic = synthetic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSynthetic() {
/* 1169 */     return this.synthetic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRole(int role) {
/* 1178 */     this.role = role;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRole() {
/* 1187 */     return this.role;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDescription(@Nullable String description) {
/* 1196 */     this.description = description;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getDescription() {
/* 1206 */     return this.description;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResource(@Nullable Resource resource) {
/* 1214 */     this.resource = resource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Resource getResource() {
/* 1222 */     return this.resource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResourceDescription(@Nullable String resourceDescription) {
/* 1230 */     this.resource = (resourceDescription != null) ? (Resource)new DescriptiveResource(resourceDescription) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getResourceDescription() {
/* 1240 */     return (this.resource != null) ? this.resource.getDescription() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOriginatingBeanDefinition(BeanDefinition originatingBd) {
/* 1247 */     this.resource = (Resource)new BeanDefinitionResource(originatingBd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanDefinition getOriginatingBeanDefinition() {
/* 1257 */     Resource resource = this.resource; BeanDefinitionResource bdr = (BeanDefinitionResource)resource; return (resource instanceof BeanDefinitionResource) ? bdr.getBeanDefinition() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() throws BeanDefinitionValidationException {
/* 1265 */     if (hasMethodOverrides() && getFactoryMethodName() != null) {
/* 1266 */       throw new BeanDefinitionValidationException("Cannot combine factory method with container-generated method overrides: the factory method must create the concrete bean instance.");
/*      */     }
/*      */ 
/*      */     
/* 1270 */     if (hasBeanClass()) {
/* 1271 */       prepareMethodOverrides();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void prepareMethodOverrides() throws BeanDefinitionValidationException {
/* 1282 */     if (hasMethodOverrides()) {
/* 1283 */       getMethodOverrides().getOverrides().forEach(this::prepareMethodOverride);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareMethodOverride(MethodOverride mo) throws BeanDefinitionValidationException {
/* 1295 */     int count = ClassUtils.getMethodCountForName(getBeanClass(), mo.getMethodName());
/* 1296 */     if (count == 0) {
/* 1297 */       throw new BeanDefinitionValidationException("Invalid method override: no method with name '" + mo
/* 1298 */           .getMethodName() + "' on class [" + 
/* 1299 */           getBeanClassName() + "]");
/*      */     }
/* 1301 */     if (count == 1)
/*      */     {
/* 1303 */       mo.setOverloaded(false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object clone() {
/* 1315 */     return cloneBeanDefinition();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract AbstractBeanDefinition cloneBeanDefinition();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(@Nullable Object other) {
/* 1327 */     if (this != other) { if (other instanceof AbstractBeanDefinition) { AbstractBeanDefinition that = (AbstractBeanDefinition)other;
/* 1328 */         if (ObjectUtils.nullSafeEquals(getBeanClassName(), that.getBeanClassName()) && 
/* 1329 */           ObjectUtils.nullSafeEquals(this.scope, that.scope) && this.abstractFlag == that.abstractFlag && this.lazyInit == that.lazyInit && this.autowireMode == that.autowireMode && this.dependencyCheck == that.dependencyCheck && 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1334 */           Arrays.equals((Object[])this.dependsOn, (Object[])that.dependsOn) && this.autowireCandidate == that.autowireCandidate && 
/*      */           
/* 1336 */           ObjectUtils.nullSafeEquals(this.qualifiers, that.qualifiers) && this.primary == that.primary && this.nonPublicAccessAllowed == that.nonPublicAccessAllowed && this.lenientConstructorResolution == that.lenientConstructorResolution && 
/*      */ 
/*      */ 
/*      */           
/* 1340 */           equalsConstructorArgumentValues(that) && 
/* 1341 */           equalsPropertyValues(that) && 
/* 1342 */           ObjectUtils.nullSafeEquals(this.methodOverrides, that.methodOverrides) && 
/* 1343 */           ObjectUtils.nullSafeEquals(this.factoryBeanName, that.factoryBeanName) && 
/* 1344 */           ObjectUtils.nullSafeEquals(this.factoryMethodName, that.factoryMethodName) && 
/* 1345 */           ObjectUtils.nullSafeEquals(this.initMethodNames, that.initMethodNames) && this.enforceInitMethod == that.enforceInitMethod && 
/*      */           
/* 1347 */           ObjectUtils.nullSafeEquals(this.destroyMethodNames, that.destroyMethodNames) && this.enforceDestroyMethod == that.enforceDestroyMethod && this.synthetic == that.synthetic && this.role == that.role && super
/*      */ 
/*      */ 
/*      */           
/* 1351 */           .equals(other)); }
/*      */       
/*      */       return false; }
/*      */      } private boolean equalsConstructorArgumentValues(AbstractBeanDefinition other) {
/* 1355 */     if (!hasConstructorArgumentValues()) {
/* 1356 */       return !other.hasConstructorArgumentValues();
/*      */     }
/* 1358 */     return ObjectUtils.nullSafeEquals(this.constructorArgumentValues, other.constructorArgumentValues);
/*      */   }
/*      */   
/*      */   private boolean equalsPropertyValues(AbstractBeanDefinition other) {
/* 1362 */     if (!hasPropertyValues()) {
/* 1363 */       return !other.hasPropertyValues();
/*      */     }
/* 1365 */     return ObjectUtils.nullSafeEquals(this.propertyValues, other.propertyValues);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1370 */     int hashCode = ObjectUtils.nullSafeHashCode(getBeanClassName());
/* 1371 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.scope);
/* 1372 */     if (hasConstructorArgumentValues()) {
/* 1373 */       hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.constructorArgumentValues);
/*      */     }
/* 1375 */     if (hasPropertyValues()) {
/* 1376 */       hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.propertyValues);
/*      */     }
/* 1378 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.factoryBeanName);
/* 1379 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.factoryMethodName);
/* 1380 */     hashCode = 29 * hashCode + super.hashCode();
/* 1381 */     return hashCode;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1386 */     StringBuilder sb = (new StringBuilder("class=")).append(getBeanClassName());
/* 1387 */     sb.append("; scope=").append(this.scope);
/* 1388 */     sb.append("; abstract=").append(this.abstractFlag);
/* 1389 */     sb.append("; lazyInit=").append(this.lazyInit);
/* 1390 */     sb.append("; autowireMode=").append(this.autowireMode);
/* 1391 */     sb.append("; dependencyCheck=").append(this.dependencyCheck);
/* 1392 */     sb.append("; autowireCandidate=").append(this.autowireCandidate);
/* 1393 */     sb.append("; primary=").append(this.primary);
/* 1394 */     sb.append("; fallback=").append(this.fallback);
/* 1395 */     sb.append("; factoryBeanName=").append(this.factoryBeanName);
/* 1396 */     sb.append("; factoryMethodName=").append(this.factoryMethodName);
/* 1397 */     sb.append("; initMethodNames=").append(Arrays.toString((Object[])this.initMethodNames));
/* 1398 */     sb.append("; destroyMethodNames=").append(Arrays.toString((Object[])this.destroyMethodNames));
/* 1399 */     if (this.resource != null) {
/* 1400 */       sb.append("; defined in ").append(this.resource.getDescription());
/*      */     }
/* 1402 */     return sb.toString();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\AbstractBeanDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */