/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.function.Supplier;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeanWrapper;
/*      */ import org.springframework.beans.BeanWrapperImpl;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.InvalidPropertyException;
/*      */ import org.springframework.beans.MutablePropertyValues;
/*      */ import org.springframework.beans.PropertyAccessorUtils;
/*      */ import org.springframework.beans.PropertyValue;
/*      */ import org.springframework.beans.PropertyValues;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.BeanNameAware;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.InjectionPoint;
/*      */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.AutowiredPropertyMarker;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.TypedStringValue;
/*      */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.core.NamedThreadLocal;
/*      */ import org.springframework.core.ParameterNameDiscoverer;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.function.ThrowingSupplier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractAutowireCapableBeanFactory
/*      */   extends AbstractBeanFactory
/*      */   implements AutowireCapableBeanFactory
/*      */ {
/*      */   private InstantiationStrategy instantiationStrategy;
/*      */   @Nullable
/*  128 */   private ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowCircularReferences = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowRawInjectionDespiteWrapping = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  144 */   private final Set<Class<?>> ignoredDependencyTypes = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   private final Set<Class<?>> ignoredDependencyInterfaces = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   private final NamedThreadLocal<String> currentlyCreatedBean = new NamedThreadLocal("Currently created bean");
/*      */ 
/*      */   
/*  161 */   private final ConcurrentMap<String, BeanWrapper> factoryBeanInstanceCache = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*  164 */   private final ConcurrentMap<Class<?>, Method[]> factoryMethodCandidateCache = (ConcurrentMap)new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*  167 */   private final ConcurrentMap<Class<?>, PropertyDescriptor[]> filteredPropertyDescriptorsCache = (ConcurrentMap)new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractAutowireCapableBeanFactory() {
/*  176 */     ignoreDependencyInterface(BeanNameAware.class);
/*  177 */     ignoreDependencyInterface(BeanFactoryAware.class);
/*  178 */     ignoreDependencyInterface(BeanClassLoaderAware.class);
/*  179 */     this.instantiationStrategy = new CglibSubclassingInstantiationStrategy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractAutowireCapableBeanFactory(@Nullable BeanFactory parentBeanFactory) {
/*  187 */     this();
/*  188 */     setParentBeanFactory(parentBeanFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInstantiationStrategy(InstantiationStrategy instantiationStrategy) {
/*  198 */     this.instantiationStrategy = instantiationStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InstantiationStrategy getInstantiationStrategy() {
/*  205 */     return this.instantiationStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParameterNameDiscoverer(@Nullable ParameterNameDiscoverer parameterNameDiscoverer) {
/*  214 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ParameterNameDiscoverer getParameterNameDiscoverer() {
/*  223 */     return this.parameterNameDiscoverer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowCircularReferences(boolean allowCircularReferences) {
/*  240 */     this.allowCircularReferences = allowCircularReferences;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowCircularReferences() {
/*  249 */     return this.allowCircularReferences;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowRawInjectionDespiteWrapping(boolean allowRawInjectionDespiteWrapping) {
/*  267 */     this.allowRawInjectionDespiteWrapping = allowRawInjectionDespiteWrapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowRawInjectionDespiteWrapping() {
/*  276 */     return this.allowRawInjectionDespiteWrapping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreDependencyType(Class<?> type) {
/*  284 */     this.ignoredDependencyTypes.add(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreDependencyInterface(Class<?> ifc) {
/*  302 */     this.ignoredDependencyInterfaces.add(ifc);
/*      */   }
/*      */ 
/*      */   
/*      */   public void copyConfigurationFrom(ConfigurableBeanFactory otherFactory) {
/*  307 */     super.copyConfigurationFrom(otherFactory);
/*  308 */     if (otherFactory instanceof AbstractAutowireCapableBeanFactory) { AbstractAutowireCapableBeanFactory otherAutowireFactory = (AbstractAutowireCapableBeanFactory)otherFactory;
/*  309 */       this.instantiationStrategy = otherAutowireFactory.instantiationStrategy;
/*  310 */       this.allowCircularReferences = otherAutowireFactory.allowCircularReferences;
/*  311 */       this.ignoredDependencyTypes.addAll(otherAutowireFactory.ignoredDependencyTypes);
/*  312 */       this.ignoredDependencyInterfaces.addAll(otherAutowireFactory.ignoredDependencyInterfaces); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T createBean(Class<T> beanClass) throws BeansException {
/*  325 */     RootBeanDefinition bd = new CreateFromClassBeanDefinition(beanClass);
/*  326 */     bd.setScope("prototype");
/*  327 */     bd.allowCaching = ClassUtils.isCacheSafe(beanClass, getBeanClassLoader());
/*  328 */     return (T)createBean(beanClass.getName(), bd, (Object[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void autowireBean(Object existingBean) {
/*  334 */     RootBeanDefinition bd = new RootBeanDefinition(ClassUtils.getUserClass(existingBean));
/*  335 */     bd.setScope("prototype");
/*  336 */     bd.allowCaching = ClassUtils.isCacheSafe(bd.getBeanClass(), getBeanClassLoader());
/*  337 */     BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl(existingBean);
/*  338 */     initBeanWrapper((BeanWrapper)beanWrapperImpl);
/*  339 */     populateBean(bd.getBeanClass().getName(), bd, (BeanWrapper)beanWrapperImpl);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object configureBean(Object existingBean, String beanName) throws BeansException {
/*  344 */     markBeanAsCreated(beanName);
/*  345 */     BeanDefinition mbd = getMergedBeanDefinition(beanName);
/*  346 */     RootBeanDefinition bd = null;
/*  347 */     if (mbd instanceof RootBeanDefinition) { RootBeanDefinition rbd = (RootBeanDefinition)mbd;
/*  348 */       bd = rbd.isPrototype() ? rbd : rbd.cloneBeanDefinition(); }
/*      */     
/*  350 */     if (bd == null) {
/*  351 */       bd = new RootBeanDefinition(mbd);
/*      */     }
/*  353 */     if (!bd.isPrototype()) {
/*  354 */       bd.setScope("prototype");
/*  355 */       bd.allowCaching = ClassUtils.isCacheSafe(ClassUtils.getUserClass(existingBean), getBeanClassLoader());
/*      */     } 
/*  357 */     BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl(existingBean);
/*  358 */     initBeanWrapper((BeanWrapper)beanWrapperImpl);
/*  359 */     populateBean(beanName, bd, (BeanWrapper)beanWrapperImpl);
/*  360 */     return initializeBean(beanName, existingBean, bd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object createBean(Class<?> beanClass, int autowireMode, boolean dependencyCheck) throws BeansException {
/*  372 */     RootBeanDefinition bd = new RootBeanDefinition(beanClass, autowireMode, dependencyCheck);
/*  373 */     bd.setScope("prototype");
/*  374 */     return createBean(beanClass.getName(), bd, (Object[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object autowire(Class<?> beanClass, int autowireMode, boolean dependencyCheck) throws BeansException {
/*  380 */     RootBeanDefinition bd = new RootBeanDefinition(beanClass, autowireMode, dependencyCheck);
/*  381 */     bd.setScope("prototype");
/*  382 */     if (bd.getResolvedAutowireMode() == 3) {
/*  383 */       return autowireConstructor(beanClass.getName(), bd, (Constructor<?>[])null, (Object[])null).getWrappedInstance();
/*      */     }
/*      */     
/*  386 */     Object bean = getInstantiationStrategy().instantiate(bd, null, (BeanFactory)this);
/*  387 */     populateBean(beanClass.getName(), bd, (BeanWrapper)new BeanWrapperImpl(bean));
/*  388 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void autowireBeanProperties(Object existingBean, int autowireMode, boolean dependencyCheck) throws BeansException {
/*  396 */     if (autowireMode == 3) {
/*  397 */       throw new IllegalArgumentException("AUTOWIRE_CONSTRUCTOR not supported for existing bean instance");
/*      */     }
/*      */ 
/*      */     
/*  401 */     RootBeanDefinition bd = new RootBeanDefinition(ClassUtils.getUserClass(existingBean), autowireMode, dependencyCheck);
/*  402 */     bd.setScope("prototype");
/*  403 */     BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl(existingBean);
/*  404 */     initBeanWrapper((BeanWrapper)beanWrapperImpl);
/*  405 */     populateBean(bd.getBeanClass().getName(), bd, (BeanWrapper)beanWrapperImpl);
/*      */   }
/*      */ 
/*      */   
/*      */   public void applyBeanPropertyValues(Object existingBean, String beanName) throws BeansException {
/*  410 */     markBeanAsCreated(beanName);
/*  411 */     BeanDefinition bd = getMergedBeanDefinition(beanName);
/*  412 */     BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl(existingBean);
/*  413 */     initBeanWrapper((BeanWrapper)beanWrapperImpl);
/*  414 */     applyPropertyValues(beanName, bd, (BeanWrapper)beanWrapperImpl, (PropertyValues)bd.getPropertyValues());
/*      */   }
/*      */ 
/*      */   
/*      */   public Object initializeBean(Object existingBean, String beanName) {
/*  419 */     return initializeBean(beanName, existingBean, (RootBeanDefinition)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1")
/*      */   public Object applyBeanPostProcessorsBeforeInitialization(Object existingBean, String beanName) throws BeansException {
/*  427 */     Object result = existingBean;
/*  428 */     for (BeanPostProcessor processor : getBeanPostProcessors()) {
/*  429 */       Object current = processor.postProcessBeforeInitialization(result, beanName);
/*  430 */       if (current == null) {
/*  431 */         return result;
/*      */       }
/*  433 */       result = current;
/*      */     } 
/*  435 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1")
/*      */   public Object applyBeanPostProcessorsAfterInitialization(Object existingBean, String beanName) throws BeansException {
/*  443 */     Object result = existingBean;
/*  444 */     for (BeanPostProcessor processor : getBeanPostProcessors()) {
/*  445 */       Object current = processor.postProcessAfterInitialization(result, beanName);
/*  446 */       if (current == null) {
/*  447 */         return result;
/*      */       }
/*  449 */       result = current;
/*      */     } 
/*  451 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void destroyBean(Object existingBean) {
/*  456 */     (new DisposableBeanAdapter(existingBean, (getBeanPostProcessorCache()).destructionAware)).destroy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object resolveBeanByName(String name, DependencyDescriptor descriptor) {
/*  466 */     InjectionPoint previousInjectionPoint = ConstructorResolver.setCurrentInjectionPoint((InjectionPoint)descriptor);
/*      */     try {
/*  468 */       return getBean(name, descriptor.getDependencyType());
/*      */     } finally {
/*      */       
/*  471 */       ConstructorResolver.setCurrentInjectionPoint(previousInjectionPoint);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object resolveDependency(DependencyDescriptor descriptor, @Nullable String requestingBeanName) throws BeansException {
/*  478 */     return resolveDependency(descriptor, requestingBeanName, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createBean(String beanName, RootBeanDefinition mbd, @Nullable Object[] args) throws BeanCreationException {
/*  495 */     if (this.logger.isTraceEnabled()) {
/*  496 */       this.logger.trace("Creating instance of bean '" + beanName + "'");
/*      */     }
/*  498 */     RootBeanDefinition mbdToUse = mbd;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  503 */     Class<?> resolvedClass = resolveBeanClass(mbd, beanName, new Class[0]);
/*  504 */     if (resolvedClass != null && !mbd.hasBeanClass() && mbd.getBeanClassName() != null) {
/*  505 */       mbdToUse = new RootBeanDefinition(mbd);
/*  506 */       mbdToUse.setBeanClass(resolvedClass);
/*      */       try {
/*  508 */         mbdToUse.prepareMethodOverrides();
/*      */       }
/*  510 */       catch (BeanDefinitionValidationException ex) {
/*  511 */         throw new BeanDefinitionStoreException(mbdToUse.getResourceDescription(), beanName, "Validation of method overrides failed", ex);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  518 */       Object bean = resolveBeforeInstantiation(beanName, mbdToUse);
/*  519 */       if (bean != null) {
/*  520 */         return bean;
/*      */       }
/*      */     }
/*  523 */     catch (Throwable ex) {
/*  524 */       throw new BeanCreationException(mbdToUse.getResourceDescription(), beanName, "BeanPostProcessor before instantiation of bean failed", ex);
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  529 */       Object beanInstance = doCreateBean(beanName, mbdToUse, args);
/*  530 */       if (this.logger.isTraceEnabled()) {
/*  531 */         this.logger.trace("Finished creating instance of bean '" + beanName + "'");
/*      */       }
/*  533 */       return beanInstance;
/*      */     }
/*  535 */     catch (BeanCreationException|ImplicitlyAppearedSingletonException ex) {
/*      */ 
/*      */       
/*  538 */       throw ex;
/*      */     }
/*  540 */     catch (Throwable ex) {
/*  541 */       throw new BeanCreationException(mbdToUse
/*  542 */           .getResourceDescription(), beanName, "Unexpected exception during bean creation", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object doCreateBean(String beanName, RootBeanDefinition mbd, @Nullable Object[] args) throws BeanCreationException {
/*  564 */     BeanWrapper instanceWrapper = null;
/*  565 */     if (mbd.isSingleton()) {
/*  566 */       instanceWrapper = this.factoryBeanInstanceCache.remove(beanName);
/*      */     }
/*  568 */     if (instanceWrapper == null) {
/*  569 */       instanceWrapper = createBeanInstance(beanName, mbd, args);
/*      */     }
/*  571 */     Object bean = instanceWrapper.getWrappedInstance();
/*  572 */     Class<?> beanType = instanceWrapper.getWrappedClass();
/*  573 */     if (beanType != NullBean.class) {
/*  574 */       mbd.resolvedTargetType = beanType;
/*      */     }
/*      */ 
/*      */     
/*  578 */     synchronized (mbd.postProcessingLock) {
/*  579 */       if (!mbd.postProcessed) {
/*      */         try {
/*  581 */           applyMergedBeanDefinitionPostProcessors(mbd, beanType, beanName);
/*      */         }
/*  583 */         catch (Throwable ex) {
/*  584 */           throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Post-processing of merged bean definition failed", ex);
/*      */         } 
/*      */         
/*  587 */         mbd.markAsPostProcessed();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     boolean earlySingletonExposure = (mbd.isSingleton() && this.allowCircularReferences && isSingletonCurrentlyInCreation(beanName));
/*  595 */     if (earlySingletonExposure) {
/*  596 */       if (this.logger.isTraceEnabled()) {
/*  597 */         this.logger.trace("Eagerly caching bean '" + beanName + "' to allow for resolving potential circular references");
/*      */       }
/*      */       
/*  600 */       addSingletonFactory(beanName, () -> getEarlyBeanReference(beanName, mbd, bean));
/*      */     } 
/*      */ 
/*      */     
/*  604 */     Object exposedObject = bean;
/*      */     try {
/*  606 */       populateBean(beanName, mbd, instanceWrapper);
/*  607 */       exposedObject = initializeBean(beanName, exposedObject, mbd);
/*      */     }
/*  609 */     catch (Throwable ex) {
/*  610 */       if (ex instanceof BeanCreationException) { BeanCreationException bce = (BeanCreationException)ex; if (beanName.equals(bce.getBeanName())) {
/*  611 */           throw bce;
/*      */         } }
/*      */       
/*  614 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, ex.getMessage(), ex);
/*      */     } 
/*      */ 
/*      */     
/*  618 */     if (earlySingletonExposure) {
/*  619 */       Object earlySingletonReference = getSingleton(beanName, false);
/*  620 */       if (earlySingletonReference != null) {
/*  621 */         if (exposedObject == bean) {
/*  622 */           exposedObject = earlySingletonReference;
/*      */         }
/*  624 */         else if (!this.allowRawInjectionDespiteWrapping && hasDependentBean(beanName)) {
/*  625 */           String[] dependentBeans = getDependentBeans(beanName);
/*  626 */           Set<String> actualDependentBeans = CollectionUtils.newLinkedHashSet(dependentBeans.length);
/*  627 */           for (String dependentBean : dependentBeans) {
/*  628 */             if (!removeSingletonIfCreatedForTypeCheckOnly(dependentBean)) {
/*  629 */               actualDependentBeans.add(dependentBean);
/*      */             }
/*      */           } 
/*  632 */           if (!actualDependentBeans.isEmpty()) {
/*  633 */             throw new BeanCurrentlyInCreationException(beanName, "Bean with name '" + beanName + "' has been injected into other beans [" + 
/*      */                 
/*  635 */                 StringUtils.collectionToCommaDelimitedString(actualDependentBeans) + "] in its raw version as part of a circular reference, but has eventually been wrapped. This means that said other beans do not use the final version of the bean. This is often the result of over-eager type matching - consider using 'getBeanNamesForType' with the 'allowEagerInit' flag turned off, for example.");
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  647 */       registerDisposableBeanIfNecessary(beanName, bean, mbd);
/*      */     }
/*  649 */     catch (BeanDefinitionValidationException ex) {
/*  650 */       throw new BeanCreationException(mbd
/*  651 */           .getResourceDescription(), beanName, "Invalid destruction signature", ex);
/*      */     } 
/*      */     
/*  654 */     return exposedObject;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Class<?> predictBeanType(String beanName, RootBeanDefinition mbd, Class<?>... typesToMatch) {
/*  660 */     Class<?> targetType = determineTargetType(beanName, mbd, typesToMatch);
/*      */ 
/*      */     
/*  663 */     if (targetType != null && !mbd.isSynthetic() && hasInstantiationAwareBeanPostProcessors()) {
/*  664 */       boolean matchingOnlyFactoryBean = (typesToMatch.length == 1 && typesToMatch[0] == FactoryBean.class);
/*  665 */       for (SmartInstantiationAwareBeanPostProcessor bp : (getBeanPostProcessorCache()).smartInstantiationAware) {
/*  666 */         Class<?> predicted = bp.predictBeanType(targetType, beanName);
/*  667 */         if (predicted != null && (!matchingOnlyFactoryBean || FactoryBean.class
/*  668 */           .isAssignableFrom(predicted))) {
/*  669 */           return predicted;
/*      */         }
/*      */       } 
/*      */     } 
/*  673 */     return targetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Class<?> determineTargetType(String beanName, RootBeanDefinition mbd, Class<?>... typesToMatch) {
/*  686 */     Class<?> targetType = mbd.getTargetType();
/*  687 */     if (targetType == null) {
/*  688 */       if (mbd.getFactoryMethodName() != null) {
/*  689 */         targetType = getTypeForFactoryMethod(beanName, mbd, typesToMatch);
/*      */       } else {
/*      */         
/*  692 */         targetType = resolveBeanClass(mbd, beanName, typesToMatch);
/*  693 */         if (mbd.hasBeanClass()) {
/*  694 */           targetType = getInstantiationStrategy().getActualBeanClass(mbd, beanName, (BeanFactory)this);
/*      */         }
/*      */       } 
/*  697 */       if (ObjectUtils.isEmpty((Object[])typesToMatch) || getTempClassLoader() == null) {
/*  698 */         mbd.resolvedTargetType = targetType;
/*      */       }
/*      */     } 
/*  701 */     return targetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Class<?> getTypeForFactoryMethod(String beanName, RootBeanDefinition mbd, Class<?>... typesToMatch) {
/*  720 */     ResolvableType cachedReturnType = mbd.factoryMethodReturnType;
/*  721 */     if (cachedReturnType != null) {
/*  722 */       return cachedReturnType.resolve();
/*      */     }
/*      */     
/*  725 */     Class<?> commonType = null;
/*  726 */     Method uniqueCandidate = mbd.factoryMethodToIntrospect;
/*      */     
/*  728 */     if (uniqueCandidate == null) {
/*      */       
/*  730 */       boolean isStatic = true;
/*      */       
/*  732 */       String factoryBeanName = mbd.getFactoryBeanName();
/*  733 */       if (factoryBeanName != null) {
/*  734 */         if (factoryBeanName.equals(beanName)) {
/*  735 */           throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "factory-bean reference points back to the same bean definition");
/*      */         }
/*      */ 
/*      */         
/*  739 */         factoryClass = getType(factoryBeanName);
/*  740 */         isStatic = false;
/*      */       }
/*      */       else {
/*      */         
/*  744 */         factoryClass = resolveBeanClass(mbd, beanName, typesToMatch);
/*      */       } 
/*      */       
/*  747 */       if (factoryClass == null) {
/*  748 */         return null;
/*      */       }
/*  750 */       Class<?> factoryClass = ClassUtils.getUserClass(factoryClass);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  755 */       int minNrOfArgs = mbd.hasConstructorArgumentValues() ? mbd.getConstructorArgumentValues().getArgumentCount() : 0;
/*  756 */       Method[] candidates = this.factoryMethodCandidateCache.computeIfAbsent(factoryClass, clazz -> ReflectionUtils.getUniqueDeclaredMethods(clazz, ReflectionUtils.USER_DECLARED_METHODS));
/*      */ 
/*      */       
/*  759 */       for (Method candidate : candidates) {
/*  760 */         if (Modifier.isStatic(candidate.getModifiers()) == isStatic && mbd.isFactoryMethod(candidate) && candidate
/*  761 */           .getParameterCount() >= minNrOfArgs)
/*      */         {
/*  763 */           if ((candidate.getTypeParameters()).length > 0) {
/*      */             
/*      */             try {
/*  766 */               ConstructorArgumentValues cav = mbd.getConstructorArgumentValues();
/*  767 */               Class<?>[] paramTypes = candidate.getParameterTypes();
/*  768 */               String[] paramNames = null;
/*  769 */               if (cav.containsNamedArgument()) {
/*  770 */                 ParameterNameDiscoverer pnd = getParameterNameDiscoverer();
/*  771 */                 if (pnd != null) {
/*  772 */                   paramNames = pnd.getParameterNames(candidate);
/*      */                 }
/*      */               } 
/*  775 */               Set<ConstructorArgumentValues.ValueHolder> usedValueHolders = CollectionUtils.newHashSet(paramTypes.length);
/*  776 */               Object[] args = new Object[paramTypes.length];
/*  777 */               for (int i = 0; i < args.length; i++) {
/*  778 */                 ConstructorArgumentValues.ValueHolder valueHolder = cav.getArgumentValue(i, paramTypes[i], 
/*  779 */                     (paramNames != null) ? paramNames[i] : null, usedValueHolders);
/*  780 */                 if (valueHolder == null) {
/*  781 */                   valueHolder = cav.getGenericArgumentValue(null, null, usedValueHolders);
/*      */                 }
/*  783 */                 if (valueHolder != null) {
/*  784 */                   args[i] = valueHolder.getValue();
/*  785 */                   usedValueHolders.add(valueHolder);
/*      */                 } 
/*      */               } 
/*  788 */               Class<?> returnType = AutowireUtils.resolveReturnTypeForFactoryMethod(candidate, args, 
/*  789 */                   getBeanClassLoader());
/*      */               
/*  791 */               uniqueCandidate = (commonType == null && returnType == candidate.getReturnType()) ? candidate : null;
/*  792 */               commonType = ClassUtils.determineCommonAncestor(returnType, commonType);
/*  793 */               if (commonType == null)
/*      */               {
/*  795 */                 return null;
/*      */               }
/*      */             }
/*  798 */             catch (Throwable ex) {
/*  799 */               if (this.logger.isDebugEnabled()) {
/*  800 */                 this.logger.debug("Failed to resolve generic return type for factory method: " + String.valueOf(ex));
/*      */               }
/*      */             } 
/*      */           } else {
/*      */             
/*  805 */             uniqueCandidate = (commonType == null) ? candidate : null;
/*  806 */             commonType = ClassUtils.determineCommonAncestor(candidate.getReturnType(), commonType);
/*  807 */             if (commonType == null)
/*      */             {
/*  809 */               return null;
/*      */             }
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/*  815 */       mbd.factoryMethodToIntrospect = uniqueCandidate;
/*  816 */       if (commonType == null) {
/*  817 */         return null;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  825 */       cachedReturnType = (uniqueCandidate != null) ? ResolvableType.forMethodReturnType(uniqueCandidate) : ResolvableType.forClass(commonType);
/*  826 */       mbd.factoryMethodReturnType = cachedReturnType;
/*  827 */       return cachedReturnType.resolve();
/*      */     }
/*  829 */     catch (LinkageError err) {
/*      */       
/*  831 */       if (this.logger.isDebugEnabled()) {
/*  832 */         this.logger.debug("Failed to resolve type for factory method of bean '" + beanName + "': " + 
/*  833 */             String.valueOf((uniqueCandidate != null) ? uniqueCandidate : commonType), err);
/*      */       }
/*  835 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResolvableType getTypeForFactoryBean(String beanName, RootBeanDefinition mbd, boolean allowInit) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_2
/*      */     //   2: invokevirtual getTypeForFactoryBeanFromAttributes : (Lorg/springframework/core/AttributeAccessor;)Lorg/springframework/core/ResolvableType;
/*      */     //   5: astore #4
/*      */     //   7: aload #4
/*      */     //   9: getstatic org/springframework/core/ResolvableType.NONE : Lorg/springframework/core/ResolvableType;
/*      */     //   12: if_acmpeq -> 18
/*      */     //   15: aload #4
/*      */     //   17: areturn
/*      */     //   18: goto -> 44
/*      */     //   21: astore #5
/*      */     //   23: new org/springframework/beans/factory/BeanDefinitionStoreException
/*      */     //   26: dup
/*      */     //   27: aload_2
/*      */     //   28: invokevirtual getResourceDescription : ()Ljava/lang/String;
/*      */     //   31: aload_1
/*      */     //   32: aload #5
/*      */     //   34: invokevirtual getMessage : ()Ljava/lang/String;
/*      */     //   37: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   40: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   43: athrow
/*      */     //   44: aload_2
/*      */     //   45: invokevirtual getInstanceSupplier : ()Ljava/util/function/Supplier;
/*      */     //   48: ifnull -> 107
/*      */     //   51: aload_0
/*      */     //   52: aload_2
/*      */     //   53: getfield targetType : Lorg/springframework/core/ResolvableType;
/*      */     //   56: invokevirtual getFactoryBeanGeneric : (Lorg/springframework/core/ResolvableType;)Lorg/springframework/core/ResolvableType;
/*      */     //   59: astore #4
/*      */     //   61: aload #4
/*      */     //   63: invokevirtual resolve : ()Ljava/lang/Class;
/*      */     //   66: ifnull -> 72
/*      */     //   69: aload #4
/*      */     //   71: areturn
/*      */     //   72: aload_0
/*      */     //   73: aload_2
/*      */     //   74: invokevirtual hasBeanClass : ()Z
/*      */     //   77: ifeq -> 90
/*      */     //   80: aload_2
/*      */     //   81: invokevirtual getBeanClass : ()Ljava/lang/Class;
/*      */     //   84: invokestatic forClass : (Ljava/lang/Class;)Lorg/springframework/core/ResolvableType;
/*      */     //   87: goto -> 91
/*      */     //   90: aconst_null
/*      */     //   91: invokevirtual getFactoryBeanGeneric : (Lorg/springframework/core/ResolvableType;)Lorg/springframework/core/ResolvableType;
/*      */     //   94: astore #4
/*      */     //   96: aload #4
/*      */     //   98: invokevirtual resolve : ()Ljava/lang/Class;
/*      */     //   101: ifnull -> 107
/*      */     //   104: aload #4
/*      */     //   106: areturn
/*      */     //   107: aload_2
/*      */     //   108: invokevirtual getFactoryBeanName : ()Ljava/lang/String;
/*      */     //   111: astore #5
/*      */     //   113: aload_2
/*      */     //   114: invokevirtual getFactoryMethodName : ()Ljava/lang/String;
/*      */     //   117: astore #6
/*      */     //   119: aload #5
/*      */     //   121: ifnull -> 233
/*      */     //   124: aload #6
/*      */     //   126: ifnull -> 220
/*      */     //   129: aload_0
/*      */     //   130: aload #5
/*      */     //   132: invokevirtual getBeanDefinition : (Ljava/lang/String;)Lorg/springframework/beans/factory/config/BeanDefinition;
/*      */     //   135: astore #7
/*      */     //   137: aload #7
/*      */     //   139: instanceof org/springframework/beans/factory/support/AbstractBeanDefinition
/*      */     //   142: ifeq -> 170
/*      */     //   145: aload #7
/*      */     //   147: checkcast org/springframework/beans/factory/support/AbstractBeanDefinition
/*      */     //   150: astore #9
/*      */     //   152: aload #9
/*      */     //   154: invokevirtual hasBeanClass : ()Z
/*      */     //   157: ifeq -> 170
/*      */     //   160: aload #9
/*      */     //   162: invokevirtual getBeanClass : ()Ljava/lang/Class;
/*      */     //   165: astore #8
/*      */     //   167: goto -> 194
/*      */     //   170: aload_0
/*      */     //   171: aload #5
/*      */     //   173: aload #7
/*      */     //   175: invokevirtual getMergedBeanDefinition : (Ljava/lang/String;Lorg/springframework/beans/factory/config/BeanDefinition;)Lorg/springframework/beans/factory/support/RootBeanDefinition;
/*      */     //   178: astore #10
/*      */     //   180: aload_0
/*      */     //   181: aload #5
/*      */     //   183: aload #10
/*      */     //   185: iconst_0
/*      */     //   186: anewarray java/lang/Class
/*      */     //   189: invokevirtual determineTargetType : (Ljava/lang/String;Lorg/springframework/beans/factory/support/RootBeanDefinition;[Ljava/lang/Class;)Ljava/lang/Class;
/*      */     //   192: astore #8
/*      */     //   194: aload #8
/*      */     //   196: ifnull -> 220
/*      */     //   199: aload_0
/*      */     //   200: aload #8
/*      */     //   202: aload #6
/*      */     //   204: invokevirtual getTypeForFactoryBeanFromMethod : (Ljava/lang/Class;Ljava/lang/String;)Lorg/springframework/core/ResolvableType;
/*      */     //   207: astore #4
/*      */     //   209: aload #4
/*      */     //   211: invokevirtual resolve : ()Ljava/lang/Class;
/*      */     //   214: ifnull -> 220
/*      */     //   217: aload #4
/*      */     //   219: areturn
/*      */     //   220: aload_0
/*      */     //   221: aload #5
/*      */     //   223: invokevirtual isBeanEligibleForMetadataCaching : (Ljava/lang/String;)Z
/*      */     //   226: ifne -> 233
/*      */     //   229: getstatic org/springframework/core/ResolvableType.NONE : Lorg/springframework/core/ResolvableType;
/*      */     //   232: areturn
/*      */     //   233: iload_3
/*      */     //   234: ifeq -> 293
/*      */     //   237: aload_2
/*      */     //   238: invokevirtual isSingleton : ()Z
/*      */     //   241: ifeq -> 253
/*      */     //   244: aload_0
/*      */     //   245: aload_1
/*      */     //   246: aload_2
/*      */     //   247: invokevirtual getSingletonFactoryBeanForTypeCheck : (Ljava/lang/String;Lorg/springframework/beans/factory/support/RootBeanDefinition;)Lorg/springframework/beans/factory/FactoryBean;
/*      */     //   250: goto -> 259
/*      */     //   253: aload_0
/*      */     //   254: aload_1
/*      */     //   255: aload_2
/*      */     //   256: invokevirtual getNonSingletonFactoryBeanForTypeCheck : (Ljava/lang/String;Lorg/springframework/beans/factory/support/RootBeanDefinition;)Lorg/springframework/beans/factory/FactoryBean;
/*      */     //   259: astore #7
/*      */     //   261: aload #7
/*      */     //   263: ifnull -> 293
/*      */     //   266: aload_0
/*      */     //   267: aload #7
/*      */     //   269: invokevirtual getTypeForFactoryBean : (Lorg/springframework/beans/factory/FactoryBean;)Ljava/lang/Class;
/*      */     //   272: astore #8
/*      */     //   274: aload #8
/*      */     //   276: ifnull -> 285
/*      */     //   279: aload #8
/*      */     //   281: invokestatic forClass : (Ljava/lang/Class;)Lorg/springframework/core/ResolvableType;
/*      */     //   284: areturn
/*      */     //   285: aload_0
/*      */     //   286: aload_1
/*      */     //   287: aload_2
/*      */     //   288: iconst_1
/*      */     //   289: invokespecial getTypeForFactoryBean : (Ljava/lang/String;Lorg/springframework/beans/factory/support/RootBeanDefinition;Z)Lorg/springframework/core/ResolvableType;
/*      */     //   292: areturn
/*      */     //   293: aload #5
/*      */     //   295: ifnonnull -> 321
/*      */     //   298: aload_2
/*      */     //   299: invokevirtual hasBeanClass : ()Z
/*      */     //   302: ifeq -> 321
/*      */     //   305: aload #6
/*      */     //   307: ifnull -> 321
/*      */     //   310: aload_0
/*      */     //   311: aload_2
/*      */     //   312: invokevirtual getBeanClass : ()Ljava/lang/Class;
/*      */     //   315: aload #6
/*      */     //   317: invokevirtual getTypeForFactoryBeanFromMethod : (Ljava/lang/Class;Ljava/lang/String;)Lorg/springframework/core/ResolvableType;
/*      */     //   320: areturn
/*      */     //   321: aload_2
/*      */     //   322: invokevirtual getInstanceSupplier : ()Ljava/util/function/Supplier;
/*      */     //   325: ifnonnull -> 384
/*      */     //   328: aload_0
/*      */     //   329: aload_2
/*      */     //   330: getfield targetType : Lorg/springframework/core/ResolvableType;
/*      */     //   333: invokevirtual getFactoryBeanGeneric : (Lorg/springframework/core/ResolvableType;)Lorg/springframework/core/ResolvableType;
/*      */     //   336: astore #4
/*      */     //   338: aload #4
/*      */     //   340: invokevirtual resolve : ()Ljava/lang/Class;
/*      */     //   343: ifnull -> 349
/*      */     //   346: aload #4
/*      */     //   348: areturn
/*      */     //   349: aload_0
/*      */     //   350: aload_2
/*      */     //   351: invokevirtual hasBeanClass : ()Z
/*      */     //   354: ifeq -> 367
/*      */     //   357: aload_2
/*      */     //   358: invokevirtual getBeanClass : ()Ljava/lang/Class;
/*      */     //   361: invokestatic forClass : (Ljava/lang/Class;)Lorg/springframework/core/ResolvableType;
/*      */     //   364: goto -> 368
/*      */     //   367: aconst_null
/*      */     //   368: invokevirtual getFactoryBeanGeneric : (Lorg/springframework/core/ResolvableType;)Lorg/springframework/core/ResolvableType;
/*      */     //   371: astore #4
/*      */     //   373: aload #4
/*      */     //   375: invokevirtual resolve : ()Ljava/lang/Class;
/*      */     //   378: ifnull -> 384
/*      */     //   381: aload #4
/*      */     //   383: areturn
/*      */     //   384: getstatic org/springframework/core/ResolvableType.NONE : Lorg/springframework/core/ResolvableType;
/*      */     //   387: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #857	-> 0
/*      */     //   #858	-> 7
/*      */     //   #859	-> 15
/*      */     //   #865	-> 18
/*      */     //   #862	-> 21
/*      */     //   #863	-> 23
/*      */     //   #864	-> 34
/*      */     //   #868	-> 44
/*      */     //   #869	-> 51
/*      */     //   #870	-> 61
/*      */     //   #871	-> 69
/*      */     //   #873	-> 72
/*      */     //   #874	-> 96
/*      */     //   #875	-> 104
/*      */     //   #880	-> 107
/*      */     //   #881	-> 113
/*      */     //   #884	-> 119
/*      */     //   #885	-> 124
/*      */     //   #888	-> 129
/*      */     //   #890	-> 137
/*      */     //   #891	-> 154
/*      */     //   #892	-> 160
/*      */     //   #895	-> 170
/*      */     //   #896	-> 180
/*      */     //   #898	-> 194
/*      */     //   #899	-> 199
/*      */     //   #900	-> 209
/*      */     //   #901	-> 217
/*      */     //   #908	-> 220
/*      */     //   #909	-> 229
/*      */     //   #914	-> 233
/*      */     //   #915	-> 237
/*      */     //   #916	-> 244
/*      */     //   #917	-> 253
/*      */     //   #918	-> 261
/*      */     //   #920	-> 266
/*      */     //   #921	-> 274
/*      */     //   #922	-> 279
/*      */     //   #926	-> 285
/*      */     //   #930	-> 293
/*      */     //   #933	-> 310
/*      */     //   #937	-> 321
/*      */     //   #938	-> 328
/*      */     //   #939	-> 338
/*      */     //   #940	-> 346
/*      */     //   #942	-> 349
/*      */     //   #943	-> 373
/*      */     //   #944	-> 381
/*      */     //   #949	-> 384
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   7	14	4	result	Lorg/springframework/core/ResolvableType;
/*      */     //   23	21	5	ex	Ljava/lang/IllegalArgumentException;
/*      */     //   167	3	8	factoryBeanClass	Ljava/lang/Class;
/*      */     //   152	18	9	abstractBeanDefinition	Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*      */     //   180	14	10	fbmbd	Lorg/springframework/beans/factory/support/RootBeanDefinition;
/*      */     //   137	83	7	factoryBeanDefinition	Lorg/springframework/beans/factory/config/BeanDefinition;
/*      */     //   194	26	8	factoryBeanClass	Ljava/lang/Class;
/*      */     //   274	19	8	type	Ljava/lang/Class;
/*      */     //   261	32	7	factoryBean	Lorg/springframework/beans/factory/FactoryBean;
/*      */     //   0	388	0	this	Lorg/springframework/beans/factory/support/AbstractAutowireCapableBeanFactory;
/*      */     //   0	388	1	beanName	Ljava/lang/String;
/*      */     //   0	388	2	mbd	Lorg/springframework/beans/factory/support/RootBeanDefinition;
/*      */     //   0	388	3	allowInit	Z
/*      */     //   44	344	4	result	Lorg/springframework/core/ResolvableType;
/*      */     //   113	275	5	factoryBeanName	Ljava/lang/String;
/*      */     //   119	269	6	factoryMethodName	Ljava/lang/String;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   167	3	8	factoryBeanClass	Ljava/lang/Class<*>;
/*      */     //   194	26	8	factoryBeanClass	Ljava/lang/Class<*>;
/*      */     //   274	19	8	type	Ljava/lang/Class<*>;
/*      */     //   261	32	7	factoryBean	Lorg/springframework/beans/factory/FactoryBean<*>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	17	21	java/lang/IllegalArgumentException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResolvableType getTypeForFactoryBeanFromMethod(Class<?> beanClass, String factoryMethodName) {
/*  961 */     Class<?> factoryBeanClass = ClassUtils.getUserClass(beanClass);
/*  962 */     FactoryBeanMethodTypeFinder finder = new FactoryBeanMethodTypeFinder(factoryMethodName);
/*  963 */     ReflectionUtils.doWithMethods(factoryBeanClass, finder, ReflectionUtils.USER_DECLARED_METHODS);
/*  964 */     return finder.getResult();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getEarlyBeanReference(String beanName, RootBeanDefinition mbd, Object bean) {
/*  976 */     Object exposedObject = bean;
/*  977 */     if (!mbd.isSynthetic() && hasInstantiationAwareBeanPostProcessors()) {
/*  978 */       for (SmartInstantiationAwareBeanPostProcessor bp : (getBeanPostProcessorCache()).smartInstantiationAware) {
/*  979 */         exposedObject = bp.getEarlyBeanReference(exposedObject, beanName);
/*      */       }
/*      */     }
/*  982 */     return exposedObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private FactoryBean<?> getSingletonFactoryBeanForTypeCheck(String beanName, RootBeanDefinition mbd) {
/* 1000 */     Boolean lockFlag = isCurrentThreadAllowedToHoldSingletonLock();
/* 1001 */     if (lockFlag == null) {
/* 1002 */       this.singletonLock.lock();
/*      */     } else {
/*      */       
/* 1005 */       boolean locked = (lockFlag.booleanValue() && this.singletonLock.tryLock());
/* 1006 */       if (!locked) {
/*      */         
/* 1008 */         resolveBeanClass(mbd, beanName, new Class[0]);
/* 1009 */         return null;
/*      */       } 
/*      */     } 
/*      */     try {
/*      */       Object instance;
/* 1014 */       BeanWrapper bw = this.factoryBeanInstanceCache.get(beanName);
/* 1015 */       if (bw != null) {
/* 1016 */         return (FactoryBean)bw.getWrappedInstance();
/*      */       }
/* 1018 */       Object beanInstance = getSingleton(beanName, false);
/* 1019 */       if (beanInstance instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)beanInstance;
/* 1020 */         return factoryBean; }
/*      */       
/* 1022 */       if (isSingletonCurrentlyInCreation(beanName) || (mbd
/* 1023 */         .getFactoryBeanName() != null && isSingletonCurrentlyInCreation(mbd.getFactoryBeanName()))) {
/* 1024 */         instance = null; return (FactoryBean<?>)instance;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1030 */         beforeSingletonCreation(beanName);
/*      */         
/* 1032 */         instance = resolveBeforeInstantiation(beanName, mbd);
/* 1033 */         if (instance == null) {
/* 1034 */           bw = createBeanInstance(beanName, mbd, (Object[])null);
/* 1035 */           instance = bw.getWrappedInstance();
/* 1036 */           this.factoryBeanInstanceCache.put(beanName, bw);
/*      */         }
/*      */       
/* 1039 */       } catch (UnsatisfiedDependencyException ex) {
/*      */         
/* 1041 */         throw ex;
/*      */       }
/* 1043 */       catch (BeanCreationException ex) {
/*      */ 
/*      */         
/* 1046 */         if (ex.contains(LinkageError.class)) {
/* 1047 */           throw ex;
/*      */         }
/*      */         
/* 1050 */         if (this.logger.isDebugEnabled()) {
/* 1051 */           this.logger.debug("Bean creation exception on singleton FactoryBean type check: " + String.valueOf(ex));
/*      */         }
/* 1053 */         onSuppressedException((Exception)ex);
/* 1054 */         return null;
/*      */       }
/*      */       finally {
/*      */         
/* 1058 */         afterSingletonCreation(beanName);
/*      */       } 
/*      */       
/* 1061 */       return getFactoryBean(beanName, instance);
/*      */     } finally {
/*      */       
/* 1064 */       this.singletonLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private FactoryBean<?> getNonSingletonFactoryBeanForTypeCheck(String beanName, RootBeanDefinition mbd) {
/*      */     Object instance;
/* 1078 */     if (isPrototypeCurrentlyInCreation(beanName)) {
/* 1079 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1085 */       beforePrototypeCreation(beanName);
/*      */       
/* 1087 */       instance = resolveBeforeInstantiation(beanName, mbd);
/* 1088 */       if (instance == null) {
/* 1089 */         BeanWrapper bw = createBeanInstance(beanName, mbd, (Object[])null);
/* 1090 */         instance = bw.getWrappedInstance();
/*      */       }
/*      */     
/* 1093 */     } catch (UnsatisfiedDependencyException ex) {
/*      */       
/* 1095 */       throw ex;
/*      */     }
/* 1097 */     catch (BeanCreationException ex) {
/*      */       
/* 1099 */       if (this.logger.isDebugEnabled()) {
/* 1100 */         this.logger.debug("Bean creation exception on non-singleton FactoryBean type check: " + String.valueOf(ex));
/*      */       }
/* 1102 */       onSuppressedException((Exception)ex);
/* 1103 */       return null;
/*      */     }
/*      */     finally {
/*      */       
/* 1107 */       afterPrototypeCreation(beanName);
/*      */     } 
/*      */     
/* 1110 */     return getFactoryBean(beanName, instance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyMergedBeanDefinitionPostProcessors(RootBeanDefinition mbd, Class<?> beanType, String beanName) {
/* 1122 */     for (MergedBeanDefinitionPostProcessor processor : (getBeanPostProcessorCache()).mergedDefinition) {
/* 1123 */       processor.postProcessMergedBeanDefinition(mbd, beanType, beanName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object resolveBeforeInstantiation(String beanName, RootBeanDefinition mbd) {
/* 1137 */     Object bean = null;
/* 1138 */     if (!Boolean.FALSE.equals(mbd.beforeInstantiationResolved)) {
/*      */       
/* 1140 */       if (!mbd.isSynthetic() && hasInstantiationAwareBeanPostProcessors()) {
/* 1141 */         Class<?> targetType = determineTargetType(beanName, mbd, new Class[0]);
/* 1142 */         if (targetType != null) {
/* 1143 */           bean = applyBeanPostProcessorsBeforeInstantiation(targetType, beanName);
/* 1144 */           if (bean != null) {
/* 1145 */             bean = applyBeanPostProcessorsAfterInitialization(bean, beanName);
/*      */           }
/*      */         } 
/*      */       } 
/* 1149 */       mbd.beforeInstantiationResolved = Boolean.valueOf((bean != null));
/*      */     } 
/* 1151 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object applyBeanPostProcessorsBeforeInstantiation(Class<?> beanClass, String beanName) {
/* 1167 */     for (InstantiationAwareBeanPostProcessor bp : (getBeanPostProcessorCache()).instantiationAware) {
/* 1168 */       Object result = bp.postProcessBeforeInstantiation(beanClass, beanName);
/* 1169 */       if (result != null) {
/* 1170 */         return result;
/*      */       }
/*      */     } 
/* 1173 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanWrapper createBeanInstance(String beanName, RootBeanDefinition mbd, @Nullable Object[] args) {
/* 1190 */     Class<?> beanClass = resolveBeanClass(mbd, beanName, new Class[0]);
/*      */     
/* 1192 */     if (beanClass != null && !Modifier.isPublic(beanClass.getModifiers()) && !mbd.isNonPublicAccessAllowed()) {
/* 1193 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Bean class isn't public, and non-public access not allowed: " + beanClass
/* 1194 */           .getName());
/*      */     }
/*      */     
/* 1197 */     if (args == null) {
/* 1198 */       Supplier<?> instanceSupplier = mbd.getInstanceSupplier();
/* 1199 */       if (instanceSupplier != null) {
/* 1200 */         return obtainFromSupplier(instanceSupplier, beanName, mbd);
/*      */       }
/*      */     } 
/*      */     
/* 1204 */     if (mbd.getFactoryMethodName() != null) {
/* 1205 */       return instantiateUsingFactoryMethod(beanName, mbd, args);
/*      */     }
/*      */ 
/*      */     
/* 1209 */     boolean resolved = false;
/* 1210 */     boolean autowireNecessary = false;
/* 1211 */     if (args == null) {
/* 1212 */       synchronized (mbd.constructorArgumentLock) {
/* 1213 */         if (mbd.resolvedConstructorOrFactoryMethod != null) {
/* 1214 */           resolved = true;
/* 1215 */           autowireNecessary = mbd.constructorArgumentsResolved;
/*      */         } 
/*      */       } 
/*      */     }
/* 1219 */     if (resolved) {
/* 1220 */       if (autowireNecessary) {
/* 1221 */         return autowireConstructor(beanName, mbd, (Constructor<?>[])null, (Object[])null);
/*      */       }
/*      */       
/* 1224 */       return instantiateBean(beanName, mbd);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1229 */     Constructor[] arrayOfConstructor = (Constructor[])determineConstructorsFromBeanPostProcessors(beanClass, beanName);
/* 1230 */     if (arrayOfConstructor != null || mbd.getResolvedAutowireMode() == 3 || mbd
/* 1231 */       .hasConstructorArgumentValues() || !ObjectUtils.isEmpty(args)) {
/* 1232 */       return autowireConstructor(beanName, mbd, (Constructor<?>[])arrayOfConstructor, args);
/*      */     }
/*      */ 
/*      */     
/* 1236 */     arrayOfConstructor = (Constructor[])mbd.getPreferredConstructors();
/* 1237 */     if (arrayOfConstructor != null) {
/* 1238 */       return autowireConstructor(beanName, mbd, (Constructor<?>[])arrayOfConstructor, (Object[])null);
/*      */     }
/*      */ 
/*      */     
/* 1242 */     return instantiateBean(beanName, mbd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanWrapper obtainFromSupplier(Supplier<?> supplier, String beanName, RootBeanDefinition mbd) {
/*      */     Object instance;
/* 1252 */     String outerBean = (String)this.currentlyCreatedBean.get();
/* 1253 */     this.currentlyCreatedBean.set(beanName);
/*      */ 
/*      */     
/*      */     try {
/* 1257 */       instance = obtainInstanceFromSupplier(supplier, beanName, mbd);
/*      */     }
/* 1259 */     catch (Throwable ex) {
/* 1260 */       if (ex instanceof BeansException) { BeansException beansException = (BeansException)ex;
/* 1261 */         throw beansException; }
/*      */       
/* 1263 */       throw new BeanCreationException(beanName, "Instantiation of supplied bean failed", ex);
/*      */     } finally {
/*      */       
/* 1266 */       if (outerBean != null) {
/* 1267 */         this.currentlyCreatedBean.set(outerBean);
/*      */       } else {
/*      */         
/* 1270 */         this.currentlyCreatedBean.remove();
/*      */       } 
/*      */     } 
/*      */     
/* 1274 */     if (instance == null) {
/* 1275 */       instance = new NullBean();
/*      */     }
/* 1277 */     BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl(instance);
/* 1278 */     initBeanWrapper((BeanWrapper)beanWrapperImpl);
/* 1279 */     return (BeanWrapper)beanWrapperImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object obtainInstanceFromSupplier(Supplier<?> supplier, String beanName, RootBeanDefinition mbd) throws Exception {
/* 1294 */     if (supplier instanceof ThrowingSupplier) { ThrowingSupplier<?> throwingSupplier = (ThrowingSupplier)supplier;
/* 1295 */       return throwingSupplier.getWithException(); }
/*      */     
/* 1297 */     return supplier.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getObjectForBeanInstance(Object beanInstance, String name, String beanName, @Nullable RootBeanDefinition mbd) {
/* 1311 */     String currentlyCreatedBean = (String)this.currentlyCreatedBean.get();
/* 1312 */     if (currentlyCreatedBean != null) {
/* 1313 */       registerDependentBean(beanName, currentlyCreatedBean);
/*      */     }
/*      */     
/* 1316 */     return super.getObjectForBeanInstance(beanInstance, name, beanName, mbd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Constructor<?>[] determineConstructorsFromBeanPostProcessors(@Nullable Class<?> beanClass, String beanName) throws BeansException {
/* 1332 */     if (beanClass != null && hasInstantiationAwareBeanPostProcessors()) {
/* 1333 */       for (SmartInstantiationAwareBeanPostProcessor bp : (getBeanPostProcessorCache()).smartInstantiationAware) {
/* 1334 */         Constructor[] arrayOfConstructor = bp.determineCandidateConstructors(beanClass, beanName);
/* 1335 */         if (arrayOfConstructor != null) {
/* 1336 */           return (Constructor<?>[])arrayOfConstructor;
/*      */         }
/*      */       } 
/*      */     }
/* 1340 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanWrapper instantiateBean(String beanName, RootBeanDefinition mbd) {
/*      */     try {
/* 1351 */       Object beanInstance = getInstantiationStrategy().instantiate(mbd, beanName, (BeanFactory)this);
/* 1352 */       BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl(beanInstance);
/* 1353 */       initBeanWrapper((BeanWrapper)beanWrapperImpl);
/* 1354 */       return (BeanWrapper)beanWrapperImpl;
/*      */     }
/* 1356 */     catch (Throwable ex) {
/* 1357 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, ex.getMessage(), ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanWrapper instantiateUsingFactoryMethod(String beanName, RootBeanDefinition mbd, @Nullable Object[] explicitArgs) {
/* 1375 */     return (new ConstructorResolver(this)).instantiateUsingFactoryMethod(beanName, mbd, explicitArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanWrapper autowireConstructor(String beanName, RootBeanDefinition mbd, @Nullable Constructor<?>[] ctors, @Nullable Object[] explicitArgs) {
/* 1395 */     return (new ConstructorResolver(this)).autowireConstructor(beanName, mbd, ctors, explicitArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void populateBean(String beanName, RootBeanDefinition mbd, @Nullable BeanWrapper bw) {
/*      */     PropertyValues propertyValues;
/* 1406 */     if (bw == null) {
/* 1407 */       if (mbd.hasPropertyValues()) {
/* 1408 */         throw new BeanCreationException(mbd
/* 1409 */             .getResourceDescription(), beanName, "Cannot apply property values to null instance");
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1417 */     if (bw.getWrappedClass().isRecord()) {
/* 1418 */       if (mbd.hasPropertyValues()) {
/* 1419 */         throw new BeanCreationException(mbd
/* 1420 */             .getResourceDescription(), beanName, "Cannot apply property values to a record");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1431 */     if (!mbd.isSynthetic() && hasInstantiationAwareBeanPostProcessors()) {
/* 1432 */       for (InstantiationAwareBeanPostProcessor bp : (getBeanPostProcessorCache()).instantiationAware) {
/* 1433 */         if (!bp.postProcessAfterInstantiation(bw.getWrappedInstance(), beanName)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1439 */     MutablePropertyValues mutablePropertyValues = mbd.hasPropertyValues() ? mbd.getPropertyValues() : null;
/*      */     
/* 1441 */     int resolvedAutowireMode = mbd.getResolvedAutowireMode();
/* 1442 */     if (resolvedAutowireMode == 1 || resolvedAutowireMode == 2) {
/* 1443 */       MutablePropertyValues newPvs = new MutablePropertyValues((PropertyValues)mutablePropertyValues);
/*      */       
/* 1445 */       if (resolvedAutowireMode == 1) {
/* 1446 */         autowireByName(beanName, mbd, bw, newPvs);
/*      */       }
/*      */       
/* 1449 */       if (resolvedAutowireMode == 2) {
/* 1450 */         autowireByType(beanName, mbd, bw, newPvs);
/*      */       }
/* 1452 */       mutablePropertyValues = newPvs;
/*      */     } 
/* 1454 */     if (hasInstantiationAwareBeanPostProcessors()) {
/* 1455 */       if (mutablePropertyValues == null) {
/* 1456 */         mutablePropertyValues = mbd.getPropertyValues();
/*      */       }
/* 1458 */       for (InstantiationAwareBeanPostProcessor bp : (getBeanPostProcessorCache()).instantiationAware) {
/* 1459 */         PropertyValues pvsToUse = bp.postProcessProperties((PropertyValues)mutablePropertyValues, bw.getWrappedInstance(), beanName);
/* 1460 */         if (pvsToUse == null) {
/*      */           return;
/*      */         }
/* 1463 */         propertyValues = pvsToUse;
/*      */       } 
/*      */     } 
/*      */     
/* 1467 */     boolean needsDepCheck = (mbd.getDependencyCheck() != 0);
/* 1468 */     if (needsDepCheck) {
/* 1469 */       PropertyDescriptor[] filteredPds = filterPropertyDescriptorsForDependencyCheck(bw, mbd.allowCaching);
/* 1470 */       checkDependencies(beanName, mbd, filteredPds, propertyValues);
/*      */     } 
/*      */     
/* 1473 */     if (propertyValues != null) {
/* 1474 */       applyPropertyValues(beanName, mbd, bw, propertyValues);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void autowireByName(String beanName, AbstractBeanDefinition mbd, BeanWrapper bw, MutablePropertyValues pvs) {
/* 1490 */     String[] propertyNames = unsatisfiedNonSimpleProperties(mbd, bw);
/* 1491 */     for (String propertyName : propertyNames) {
/* 1492 */       if (containsBean(propertyName)) {
/* 1493 */         Object bean = getBean(propertyName);
/* 1494 */         pvs.add(propertyName, bean);
/* 1495 */         registerDependentBean(propertyName, beanName);
/* 1496 */         if (this.logger.isTraceEnabled()) {
/* 1497 */           this.logger.trace("Added autowiring by name from bean name '" + beanName + "' via property '" + propertyName + "' to bean named '" + propertyName + "'");
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1502 */       else if (this.logger.isTraceEnabled()) {
/* 1503 */         this.logger.trace("Not autowiring property '" + propertyName + "' of bean '" + beanName + "' by name: no matching bean found");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void autowireByType(String beanName, AbstractBeanDefinition mbd, BeanWrapper bw, MutablePropertyValues pvs) {
/*      */     BeanWrapper beanWrapper;
/* 1524 */     TypeConverter converter = getCustomTypeConverter();
/* 1525 */     if (converter == null) {
/* 1526 */       beanWrapper = bw;
/*      */     }
/*      */     
/* 1529 */     String[] propertyNames = unsatisfiedNonSimpleProperties(mbd, bw);
/* 1530 */     Set<String> autowiredBeanNames = new LinkedHashSet<>(propertyNames.length * 2);
/* 1531 */     for (String propertyName : propertyNames) {
/*      */       try {
/* 1533 */         PropertyDescriptor pd = bw.getPropertyDescriptor(propertyName);
/*      */ 
/*      */         
/* 1536 */         if (Object.class != pd.getPropertyType()) {
/* 1537 */           MethodParameter methodParam = BeanUtils.getWriteMethodParameter(pd);
/*      */           
/* 1539 */           boolean eager = !(bw.getWrappedInstance() instanceof org.springframework.core.PriorityOrdered);
/* 1540 */           DependencyDescriptor desc = new AutowireByTypeDependencyDescriptor(methodParam, eager);
/* 1541 */           Object autowiredArgument = resolveDependency(desc, beanName, autowiredBeanNames, (TypeConverter)beanWrapper);
/* 1542 */           if (autowiredArgument != null) {
/* 1543 */             pvs.add(propertyName, autowiredArgument);
/*      */           }
/* 1545 */           for (String autowiredBeanName : autowiredBeanNames) {
/* 1546 */             registerDependentBean(autowiredBeanName, beanName);
/* 1547 */             if (this.logger.isTraceEnabled()) {
/* 1548 */               this.logger.trace("Autowiring by type from bean name '" + beanName + "' via property '" + propertyName + "' to bean named '" + autowiredBeanName + "'");
/*      */             }
/*      */           } 
/*      */           
/* 1552 */           autowiredBeanNames.clear();
/*      */         }
/*      */       
/* 1555 */       } catch (BeansException ex) {
/* 1556 */         throw new UnsatisfiedDependencyException(mbd.getResourceDescription(), beanName, propertyName, ex);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] unsatisfiedNonSimpleProperties(AbstractBeanDefinition mbd, BeanWrapper bw) {
/* 1572 */     Set<String> result = new TreeSet<>();
/* 1573 */     MutablePropertyValues mutablePropertyValues = mbd.getPropertyValues();
/* 1574 */     PropertyDescriptor[] pds = bw.getPropertyDescriptors();
/* 1575 */     for (PropertyDescriptor pd : pds) {
/* 1576 */       if (pd.getWriteMethod() != null && !isExcludedFromDependencyCheck(pd) && !mutablePropertyValues.contains(pd.getName()) && 
/* 1577 */         !BeanUtils.isSimpleProperty(pd.getPropertyType())) {
/* 1578 */         result.add(pd.getName());
/*      */       }
/*      */     } 
/* 1581 */     return StringUtils.toStringArray(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertyDescriptor[] filterPropertyDescriptorsForDependencyCheck(BeanWrapper bw, boolean cache) {
/* 1594 */     PropertyDescriptor[] filtered = this.filteredPropertyDescriptorsCache.get(bw.getWrappedClass());
/* 1595 */     if (filtered == null) {
/* 1596 */       filtered = filterPropertyDescriptorsForDependencyCheck(bw);
/* 1597 */       if (cache) {
/*      */         
/* 1599 */         PropertyDescriptor[] existing = this.filteredPropertyDescriptorsCache.putIfAbsent(bw.getWrappedClass(), filtered);
/* 1600 */         if (existing != null) {
/* 1601 */           filtered = existing;
/*      */         }
/*      */       } 
/*      */     } 
/* 1605 */     return filtered;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertyDescriptor[] filterPropertyDescriptorsForDependencyCheck(BeanWrapper bw) {
/* 1616 */     List<PropertyDescriptor> pds = new ArrayList<>(Arrays.asList(bw.getPropertyDescriptors()));
/* 1617 */     pds.removeIf(this::isExcludedFromDependencyCheck);
/* 1618 */     return pds.<PropertyDescriptor>toArray(new PropertyDescriptor[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isExcludedFromDependencyCheck(PropertyDescriptor pd) {
/* 1632 */     return (AutowireUtils.isExcludedFromDependencyCheck(pd) || this.ignoredDependencyTypes
/* 1633 */       .contains(pd.getPropertyType()) || 
/* 1634 */       AutowireUtils.isSetterDefinedInInterface(pd, this.ignoredDependencyInterfaces));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkDependencies(String beanName, AbstractBeanDefinition mbd, PropertyDescriptor[] pds, @Nullable PropertyValues pvs) throws UnsatisfiedDependencyException {
/* 1651 */     int dependencyCheck = mbd.getDependencyCheck();
/* 1652 */     for (PropertyDescriptor pd : pds) {
/* 1653 */       if (pd.getWriteMethod() != null && (pvs == null || !pvs.contains(pd.getName()))) {
/* 1654 */         boolean isSimple = BeanUtils.isSimpleProperty(pd.getPropertyType());
/* 1655 */         boolean unsatisfied = (dependencyCheck == 3 || (isSimple && dependencyCheck == 2) || (!isSimple && dependencyCheck == 1));
/*      */ 
/*      */         
/* 1658 */         if (unsatisfied) {
/* 1659 */           throw new UnsatisfiedDependencyException(mbd.getResourceDescription(), beanName, pd.getName(), "Set this property value or disable dependency checking for this bean.");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyPropertyValues(String beanName, BeanDefinition mbd, BeanWrapper bw, PropertyValues pvs) {
/*      */     List<PropertyValue> original;
/*      */     BeanWrapper beanWrapper;
/* 1676 */     if (pvs.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/* 1680 */     MutablePropertyValues mpvs = null;
/*      */ 
/*      */     
/* 1683 */     if (pvs instanceof MutablePropertyValues) { MutablePropertyValues _mpvs = (MutablePropertyValues)pvs;
/* 1684 */       mpvs = _mpvs;
/* 1685 */       if (mpvs.isConverted()) {
/*      */         
/*      */         try {
/* 1688 */           bw.setPropertyValues((PropertyValues)mpvs);
/*      */           
/*      */           return;
/* 1691 */         } catch (BeansException ex) {
/* 1692 */           throw new BeanCreationException(mbd
/* 1693 */               .getResourceDescription(), beanName, "Error setting property values", ex);
/*      */         } 
/*      */       }
/* 1696 */       original = mpvs.getPropertyValueList(); }
/*      */     else
/*      */     
/* 1699 */     { original = Arrays.asList(pvs.getPropertyValues()); }
/*      */ 
/*      */     
/* 1702 */     TypeConverter converter = getCustomTypeConverter();
/* 1703 */     if (converter == null) {
/* 1704 */       beanWrapper = bw;
/*      */     }
/* 1706 */     BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(this, beanName, mbd, (TypeConverter)beanWrapper);
/*      */ 
/*      */     
/* 1709 */     List<PropertyValue> deepCopy = new ArrayList<>(original.size());
/* 1710 */     boolean resolveNecessary = false;
/* 1711 */     for (PropertyValue pv : original) {
/* 1712 */       if (pv.isConverted()) {
/* 1713 */         deepCopy.add(pv);
/*      */         continue;
/*      */       } 
/* 1716 */       String propertyName = pv.getName();
/* 1717 */       Object originalValue = pv.getValue();
/* 1718 */       if (originalValue == AutowiredPropertyMarker.INSTANCE) {
/* 1719 */         Method writeMethod = bw.getPropertyDescriptor(propertyName).getWriteMethod();
/* 1720 */         if (writeMethod == null) {
/* 1721 */           throw new IllegalArgumentException("Autowire marker for property without write method: " + String.valueOf(pv));
/*      */         }
/* 1723 */         originalValue = new DependencyDescriptor(new MethodParameter(writeMethod, 0), true);
/*      */       } 
/* 1725 */       Object resolvedValue = valueResolver.resolveValueIfNecessary(pv, originalValue);
/* 1726 */       Object convertedValue = resolvedValue;
/* 1727 */       boolean convertible = isConvertibleProperty(propertyName, bw);
/* 1728 */       if (convertible) {
/* 1729 */         convertedValue = convertForProperty(resolvedValue, propertyName, bw, (TypeConverter)beanWrapper);
/*      */       }
/*      */ 
/*      */       
/* 1733 */       if (resolvedValue == originalValue) {
/* 1734 */         if (convertible) {
/* 1735 */           pv.setConvertedValue(convertedValue);
/*      */         }
/* 1737 */         deepCopy.add(pv); continue;
/*      */       } 
/* 1739 */       if (convertible && originalValue instanceof TypedStringValue) { TypedStringValue typedStringValue = (TypedStringValue)originalValue;
/* 1740 */         if (!typedStringValue.isDynamic() && !(convertedValue instanceof java.util.Collection) && 
/* 1741 */           !ObjectUtils.isArray(convertedValue)) {
/* 1742 */           pv.setConvertedValue(convertedValue);
/* 1743 */           deepCopy.add(pv); continue;
/*      */         }  }
/*      */       
/* 1746 */       resolveNecessary = true;
/* 1747 */       deepCopy.add(new PropertyValue(pv, convertedValue));
/*      */     } 
/*      */ 
/*      */     
/* 1751 */     if (mpvs != null && !resolveNecessary) {
/* 1752 */       mpvs.setConverted();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1757 */       bw.setPropertyValues((PropertyValues)new MutablePropertyValues(deepCopy));
/*      */     }
/* 1759 */     catch (BeansException ex) {
/* 1760 */       throw new BeanCreationException(mbd.getResourceDescription(), beanName, ex.getMessage(), ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isConvertibleProperty(String propertyName, BeanWrapper bw) {
/*      */     try {
/* 1769 */       return (!PropertyAccessorUtils.isNestedOrIndexedProperty(propertyName) && 
/* 1770 */         BeanUtils.hasUniqueWriteMethod(bw.getPropertyDescriptor(propertyName)));
/*      */     }
/* 1772 */     catch (InvalidPropertyException ex) {
/* 1773 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object convertForProperty(@Nullable Object value, String propertyName, BeanWrapper bw, TypeConverter converter) {
/* 1784 */     if (converter instanceof BeanWrapperImpl) { BeanWrapperImpl beanWrapper = (BeanWrapperImpl)converter;
/* 1785 */       return beanWrapper.convertForProperty(value, propertyName); }
/*      */ 
/*      */     
/* 1788 */     PropertyDescriptor pd = bw.getPropertyDescriptor(propertyName);
/* 1789 */     MethodParameter methodParam = BeanUtils.getWriteMethodParameter(pd);
/* 1790 */     return converter.convertIfNecessary(value, pd.getPropertyType(), methodParam);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object initializeBean(String beanName, Object bean, @Nullable RootBeanDefinition mbd) {
/* 1814 */     invokeAwareMethods(beanName, bean);
/*      */     
/* 1816 */     Object wrappedBean = bean;
/* 1817 */     if (mbd == null || !mbd.isSynthetic()) {
/* 1818 */       wrappedBean = applyBeanPostProcessorsBeforeInitialization(wrappedBean, beanName);
/*      */     }
/*      */     
/*      */     try {
/* 1822 */       invokeInitMethods(beanName, wrappedBean, mbd);
/*      */     }
/* 1824 */     catch (Throwable ex) {
/* 1825 */       throw new BeanCreationException(
/* 1826 */           (mbd != null) ? mbd.getResourceDescription() : null, beanName, ex.getMessage(), ex);
/*      */     } 
/* 1828 */     if (mbd == null || !mbd.isSynthetic()) {
/* 1829 */       wrappedBean = applyBeanPostProcessorsAfterInitialization(wrappedBean, beanName);
/*      */     }
/*      */     
/* 1832 */     return wrappedBean;
/*      */   }
/*      */   
/*      */   private void invokeAwareMethods(String beanName, Object bean) {
/* 1836 */     if (bean instanceof org.springframework.beans.factory.Aware) {
/* 1837 */       if (bean instanceof BeanNameAware) { BeanNameAware beanNameAware = (BeanNameAware)bean;
/* 1838 */         beanNameAware.setBeanName(beanName); }
/*      */       
/* 1840 */       if (bean instanceof BeanClassLoaderAware) { BeanClassLoaderAware beanClassLoaderAware = (BeanClassLoaderAware)bean;
/* 1841 */         ClassLoader bcl = getBeanClassLoader();
/* 1842 */         if (bcl != null) {
/* 1843 */           beanClassLoaderAware.setBeanClassLoader(bcl);
/*      */         } }
/*      */       
/* 1846 */       if (bean instanceof BeanFactoryAware) { BeanFactoryAware beanFactoryAware = (BeanFactoryAware)bean;
/* 1847 */         beanFactoryAware.setBeanFactory((BeanFactory)this); }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invokeInitMethods(String beanName, Object bean, @Nullable RootBeanDefinition mbd) throws Throwable {
/* 1868 */     boolean isInitializingBean = bean instanceof InitializingBean;
/* 1869 */     if (isInitializingBean && (mbd == null || !mbd.hasAnyExternallyManagedInitMethod("afterPropertiesSet"))) {
/* 1870 */       if (this.logger.isTraceEnabled()) {
/* 1871 */         this.logger.trace("Invoking afterPropertiesSet() on bean with name '" + beanName + "'");
/*      */       }
/* 1873 */       ((InitializingBean)bean).afterPropertiesSet();
/*      */     } 
/*      */     
/* 1876 */     if (mbd != null && bean.getClass() != NullBean.class) {
/* 1877 */       String[] initMethodNames = mbd.getInitMethodNames();
/* 1878 */       if (initMethodNames != null) {
/* 1879 */         for (String initMethodName : initMethodNames) {
/* 1880 */           if (StringUtils.hasLength(initMethodName) && (!isInitializingBean || 
/* 1881 */             !"afterPropertiesSet".equals(initMethodName)) && 
/* 1882 */             !mbd.hasAnyExternallyManagedInitMethod(initMethodName)) {
/* 1883 */             invokeCustomInitMethod(beanName, bean, mbd, initMethodName);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invokeCustomInitMethod(String beanName, Object bean, RootBeanDefinition mbd, String initMethodName) throws Throwable {
/* 1900 */     Class<?> beanClass = bean.getClass();
/* 1901 */     MethodDescriptor descriptor = MethodDescriptor.create(beanName, beanClass, initMethodName);
/* 1902 */     String methodName = descriptor.methodName();
/*      */ 
/*      */ 
/*      */     
/* 1906 */     Method initMethod = mbd.isNonPublicAccessAllowed() ? BeanUtils.findMethod(descriptor.declaringClass(), methodName, new Class[0]) : ClassUtils.getMethodIfAvailable(beanClass, methodName, new Class[0]);
/*      */     
/* 1908 */     if (initMethod == null) {
/* 1909 */       if (mbd.isEnforceInitMethod()) {
/* 1910 */         throw new BeanDefinitionValidationException("Could not find an init method named '" + methodName + "' on bean with name '" + beanName + "'");
/*      */       }
/*      */ 
/*      */       
/* 1914 */       if (this.logger.isTraceEnabled()) {
/* 1915 */         this.logger.trace("No default init method named '" + methodName + "' found on bean with name '" + beanName + "'");
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1923 */     if (this.logger.isTraceEnabled()) {
/* 1924 */       this.logger.trace("Invoking init method '" + methodName + "' on bean with name '" + beanName + "'");
/*      */     }
/* 1926 */     Method methodToInvoke = ClassUtils.getPubliclyAccessibleMethodIfPossible(initMethod, beanClass);
/*      */     
/*      */     try {
/* 1929 */       ReflectionUtils.makeAccessible(methodToInvoke);
/* 1930 */       methodToInvoke.invoke(bean, new Object[0]);
/*      */     }
/* 1932 */     catch (InvocationTargetException ex) {
/* 1933 */       throw ex.getTargetException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object postProcessObjectFromFactoryBean(Object object, String beanName) {
/* 1947 */     return applyBeanPostProcessorsAfterInitialization(object, beanName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeSingleton(String beanName) {
/* 1955 */     super.removeSingleton(beanName);
/* 1956 */     this.factoryBeanInstanceCache.remove(beanName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearSingletonCache() {
/* 1964 */     super.clearSingletonCache();
/* 1965 */     this.factoryBeanInstanceCache.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Log getLogger() {
/* 1973 */     return this.logger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class CreateFromClassBeanDefinition
/*      */     extends RootBeanDefinition
/*      */   {
/*      */     public CreateFromClassBeanDefinition(Class<?> beanClass) {
/* 1987 */       super(beanClass);
/*      */     }
/*      */     
/*      */     public CreateFromClassBeanDefinition(CreateFromClassBeanDefinition original) {
/* 1991 */       super(original);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Constructor<?>[] getPreferredConstructors() {
/* 1997 */       Constructor[] arrayOfConstructor = (Constructor[])super.getPreferredConstructors();
/* 1998 */       if (arrayOfConstructor != null) {
/* 1999 */         return (Constructor<?>[])arrayOfConstructor;
/*      */       }
/* 2001 */       return ConstructorResolver.determinePreferredConstructors(getBeanClass());
/*      */     }
/*      */ 
/*      */     
/*      */     public RootBeanDefinition cloneBeanDefinition() {
/* 2006 */       return new CreateFromClassBeanDefinition(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class AutowireByTypeDependencyDescriptor
/*      */     extends DependencyDescriptor
/*      */   {
/*      */     public AutowireByTypeDependencyDescriptor(MethodParameter methodParameter, boolean eager) {
/* 2019 */       super(methodParameter, false, eager);
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public String getDependencyName() {
/* 2025 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class FactoryBeanMethodTypeFinder
/*      */     implements ReflectionUtils.MethodCallback
/*      */   {
/*      */     private final String factoryMethodName;
/*      */ 
/*      */     
/* 2037 */     private ResolvableType result = ResolvableType.NONE;
/*      */     
/*      */     FactoryBeanMethodTypeFinder(String factoryMethodName) {
/* 2040 */       this.factoryMethodName = factoryMethodName;
/*      */     }
/*      */ 
/*      */     
/*      */     public void doWith(Method method) throws IllegalArgumentException {
/* 2045 */       if (isFactoryBeanMethod(method)) {
/* 2046 */         ResolvableType returnType = ResolvableType.forMethodReturnType(method);
/* 2047 */         ResolvableType candidate = returnType.as(FactoryBean.class).getGeneric(new int[0]);
/* 2048 */         if (this.result == ResolvableType.NONE) {
/* 2049 */           this.result = candidate;
/*      */         } else {
/*      */           
/* 2052 */           Class<?> resolvedResult = this.result.resolve();
/* 2053 */           Class<?> commonAncestor = ClassUtils.determineCommonAncestor(candidate.resolve(), resolvedResult);
/* 2054 */           if (!ObjectUtils.nullSafeEquals(resolvedResult, commonAncestor)) {
/* 2055 */             this.result = ResolvableType.forClass(commonAncestor);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private boolean isFactoryBeanMethod(Method method) {
/* 2062 */       return (method.getName().equals(this.factoryMethodName) && FactoryBean.class
/* 2063 */         .isAssignableFrom(method.getReturnType()));
/*      */     }
/*      */     
/*      */     ResolvableType getResult() {
/* 2067 */       Class<?> resolved = this.result.resolve();
/* 2068 */       boolean foundResult = (resolved != null && resolved != Object.class);
/* 2069 */       return foundResult ? this.result : ResolvableType.NONE;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\AbstractAutowireCapableBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */