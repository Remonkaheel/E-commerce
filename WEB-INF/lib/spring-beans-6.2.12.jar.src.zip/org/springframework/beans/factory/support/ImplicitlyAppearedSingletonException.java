/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImplicitlyAppearedSingletonException
/*    */   extends IllegalStateException
/*    */ {
/*    */   public ImplicitlyAppearedSingletonException() {
/* 31 */     super("About-to-be-created singleton instance implicitly appeared through the creation of the factory bean that its bean definition points to");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\ImplicitlyAppearedSingletonException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */