/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.core.AttributeAccessor;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FactoryBeanRegistrySupport
/*     */   extends DefaultSingletonBeanRegistry
/*     */ {
/*  44 */   private final Map<String, Object> factoryBeanObjectCache = new ConcurrentHashMap<>(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?> getTypeForFactoryBean(FactoryBean<?> factoryBean) {
/*     */     try {
/*  56 */       return factoryBean.getObjectType();
/*     */     }
/*  58 */     catch (Throwable ex) {
/*     */       
/*  60 */       this.logger.info("FactoryBean threw exception from getObjectType, despite the contract saying that it should return null if the type of its object cannot be determined yet", ex);
/*     */       
/*  62 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ResolvableType getTypeForFactoryBeanFromAttributes(AttributeAccessor attributes) {
/*  75 */     Object attribute = attributes.getAttribute("factoryBeanObjectType");
/*  76 */     if (attribute == null) {
/*  77 */       return ResolvableType.NONE;
/*     */     }
/*  79 */     if (attribute instanceof ResolvableType) { ResolvableType resolvableType = (ResolvableType)attribute;
/*  80 */       return resolvableType; }
/*     */     
/*  82 */     if (attribute instanceof Class) { Class<?> clazz = (Class)attribute;
/*  83 */       return ResolvableType.forClass(clazz); }
/*     */     
/*  85 */     throw new IllegalArgumentException("Invalid value type for attribute 'factoryBeanObjectType': " + attribute
/*  86 */         .getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ResolvableType getFactoryBeanGeneric(@Nullable ResolvableType type) {
/*  95 */     return (type != null) ? type.as(FactoryBean.class).getGeneric(new int[0]) : ResolvableType.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getCachedObjectForFactoryBean(String beanName) {
/* 107 */     return this.factoryBeanObjectCache.get(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getObjectFromFactoryBean(FactoryBean<?> factory, String beanName, boolean shouldPostProcess) {
/* 120 */     if (factory.isSingleton() && containsSingleton(beanName)) {
/* 121 */       boolean locked; Boolean lockFlag = isCurrentThreadAllowedToHoldSingletonLock();
/*     */       
/* 123 */       if (lockFlag == null) {
/* 124 */         this.singletonLock.lock();
/* 125 */         locked = true;
/*     */       } else {
/*     */         
/* 128 */         locked = (lockFlag.booleanValue() && this.singletonLock.tryLock());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */       
/*     */       } finally {
/* 175 */         if (locked) {
/* 176 */           this.singletonLock.unlock();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     Object object = doGetObjectFromFactoryBean(factory, beanName);
/* 182 */     if (shouldPostProcess) {
/*     */       try {
/* 184 */         object = postProcessObjectFromFactoryBean(object, beanName);
/*     */       }
/* 186 */       catch (Throwable ex) {
/* 187 */         throw new BeanCreationException(beanName, "Post-processing of FactoryBean's object failed", ex);
/*     */       } 
/*     */     }
/* 190 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object doGetObjectFromFactoryBean(FactoryBean<?> factory, String beanName) throws BeanCreationException {
/*     */     Object object;
/*     */     try {
/* 205 */       object = factory.getObject();
/*     */     }
/* 207 */     catch (FactoryBeanNotInitializedException ex) {
/* 208 */       throw new BeanCurrentlyInCreationException(beanName, ex.toString());
/*     */     }
/* 210 */     catch (Throwable ex) {
/* 211 */       throw new BeanCreationException(beanName, "FactoryBean threw exception on object creation", ex);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 216 */     if (object == null) {
/* 217 */       if (isSingletonCurrentlyInCreation(beanName)) {
/* 218 */         throw new BeanCurrentlyInCreationException(beanName, "FactoryBean which is currently in creation returned null from getObject");
/*     */       }
/*     */       
/* 221 */       object = new NullBean();
/*     */     } 
/* 223 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object postProcessObjectFromFactoryBean(Object object, String beanName) throws BeansException {
/* 237 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FactoryBean<?> getFactoryBean(String beanName, Object beanInstance) throws BeansException {
/*     */     FactoryBean<?> factoryBean;
/* 248 */     if (beanInstance instanceof FactoryBean) { factoryBean = (FactoryBean)beanInstance; }
/* 249 */     else { throw new BeanCreationException(beanName, "Bean instance of type [" + 
/* 250 */           String.valueOf(beanInstance.getClass()) + "] is not a FactoryBean"); }
/*     */     
/* 252 */     return factoryBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeSingleton(String beanName) {
/* 260 */     super.removeSingleton(beanName);
/* 261 */     this.factoryBeanObjectCache.remove(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearSingletonCache() {
/* 269 */     super.clearSingletonCache();
/* 270 */     this.factoryBeanObjectCache.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\FactoryBeanRegistrySupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */