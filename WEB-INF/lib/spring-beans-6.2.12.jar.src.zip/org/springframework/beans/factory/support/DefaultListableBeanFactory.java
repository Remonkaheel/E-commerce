/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import jakarta.inject.Provider;
/*      */ import java.io.IOException;
/*      */ import java.io.NotSerializableException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.Serializable;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.concurrent.CompletionException;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Stream;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.FatalBeanException;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*      */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.InjectionPoint;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*      */ import org.springframework.beans.factory.ObjectFactory;
/*      */ import org.springframework.beans.factory.ObjectProvider;
/*      */ import org.springframework.beans.factory.SmartFactoryBean;
/*      */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.beans.factory.config.NamedBeanHolder;
/*      */ import org.springframework.core.NamedThreadLocal;
/*      */ import org.springframework.core.OrderComparator;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.core.SpringProperties;
/*      */ import org.springframework.core.annotation.MergedAnnotation;
/*      */ import org.springframework.core.annotation.MergedAnnotations;
/*      */ import org.springframework.core.log.LogMessage;
/*      */ import org.springframework.core.metrics.StartupStep;
/*      */ import org.springframework.lang.Contract;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.CompositeIterator;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DefaultListableBeanFactory
/*      */   extends AbstractAutowireCapableBeanFactory
/*      */   implements ConfigurableListableBeanFactory, BeanDefinitionRegistry, Serializable
/*      */ {
/*      */   public static final String STRICT_LOCKING_PROPERTY_NAME = "spring.locking.strict";
/*      */   @Nullable
/*      */   private static Class<?> jakartaInjectProviderClass;
/*      */   
/*      */   static {
/*      */     try {
/*  153 */       jakartaInjectProviderClass = ClassUtils.forName("jakarta.inject.Provider", DefaultListableBeanFactory.class.getClassLoader());
/*      */     }
/*  155 */     catch (ClassNotFoundException ex) {
/*      */       
/*  157 */       jakartaInjectProviderClass = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  163 */   private static final Map<String, Reference<DefaultListableBeanFactory>> serializableFactories = new ConcurrentHashMap<>(8);
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*  168 */   private final Boolean strictLocking = SpringProperties.checkFlag("spring.locking.strict");
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private String serializationId;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Boolean allowBeanDefinitionOverriding;
/*      */ 
/*      */   
/*      */   private boolean allowEagerClassLoading = true;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Executor bootstrapExecutor;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Comparator<Object> dependencyComparator;
/*      */   
/*  189 */   private AutowireCandidateResolver autowireCandidateResolver = SimpleAutowireCandidateResolver.INSTANCE;
/*      */ 
/*      */   
/*  192 */   private final Map<Class<?>, Object> resolvableDependencies = new ConcurrentHashMap<>(16);
/*      */ 
/*      */   
/*  195 */   private final Map<String, BeanDefinition> beanDefinitionMap = new ConcurrentHashMap<>(256);
/*      */ 
/*      */   
/*  198 */   private final Map<String, BeanDefinitionHolder> mergedBeanDefinitionHolders = new ConcurrentHashMap<>(256);
/*      */ 
/*      */   
/*  201 */   private final Map<String, Class<?>> primaryBeanNamesWithType = new ConcurrentHashMap<>(16);
/*      */ 
/*      */   
/*  204 */   private final Map<Class<?>, String[]> allBeanNamesByType = (Map)new ConcurrentHashMap<>(64);
/*      */ 
/*      */   
/*  207 */   private final Map<Class<?>, String[]> singletonBeanNamesByType = (Map)new ConcurrentHashMap<>(64);
/*      */ 
/*      */   
/*  210 */   private volatile List<String> beanDefinitionNames = new ArrayList<>(256);
/*      */ 
/*      */   
/*  213 */   private volatile Set<String> manualSingletonNames = new LinkedHashSet<>(16);
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private volatile String[] frozenBeanDefinitionNames;
/*      */ 
/*      */   
/*      */   private volatile boolean configurationFrozen;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private volatile String mainThreadPrefix;
/*      */   
/*  226 */   private final NamedThreadLocal<PreInstantiation> preInstantiationThread = new NamedThreadLocal("Pre-instantiation thread marker");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DefaultListableBeanFactory(@Nullable BeanFactory parentBeanFactory) {
/*  242 */     super(parentBeanFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSerializationId(@Nullable String serializationId) {
/*  251 */     if (serializationId != null) {
/*  252 */       serializableFactories.put(serializationId, new WeakReference<>(this));
/*      */     }
/*  254 */     else if (this.serializationId != null) {
/*  255 */       serializableFactories.remove(this.serializationId);
/*      */     } 
/*  257 */     this.serializationId = serializationId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getSerializationId() {
/*  267 */     return this.serializationId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding) {
/*  278 */     this.allowBeanDefinitionOverriding = Boolean.valueOf(allowBeanDefinitionOverriding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowBeanDefinitionOverriding() {
/*  287 */     return !Boolean.FALSE.equals(this.allowBeanDefinitionOverriding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowEagerClassLoading(boolean allowEagerClassLoading) {
/*  301 */     this.allowEagerClassLoading = allowEagerClassLoading;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowEagerClassLoading() {
/*  310 */     return this.allowEagerClassLoading;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBootstrapExecutor(@Nullable Executor bootstrapExecutor) {
/*  315 */     this.bootstrapExecutor = bootstrapExecutor;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Executor getBootstrapExecutor() {
/*  321 */     return this.bootstrapExecutor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDependencyComparator(@Nullable Comparator<Object> dependencyComparator) {
/*  331 */     this.dependencyComparator = dependencyComparator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Comparator<Object> getDependencyComparator() {
/*  340 */     return this.dependencyComparator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutowireCandidateResolver(AutowireCandidateResolver autowireCandidateResolver) {
/*  349 */     Assert.notNull(autowireCandidateResolver, "AutowireCandidateResolver must not be null");
/*  350 */     if (autowireCandidateResolver instanceof BeanFactoryAware) { BeanFactoryAware beanFactoryAware = (BeanFactoryAware)autowireCandidateResolver;
/*  351 */       beanFactoryAware.setBeanFactory((BeanFactory)this); }
/*      */     
/*  353 */     this.autowireCandidateResolver = autowireCandidateResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AutowireCandidateResolver getAutowireCandidateResolver() {
/*  360 */     return this.autowireCandidateResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyConfigurationFrom(ConfigurableBeanFactory otherFactory) {
/*  366 */     super.copyConfigurationFrom(otherFactory);
/*  367 */     if (otherFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory otherListableFactory = (DefaultListableBeanFactory)otherFactory;
/*  368 */       this.allowBeanDefinitionOverriding = otherListableFactory.allowBeanDefinitionOverriding;
/*  369 */       this.allowEagerClassLoading = otherListableFactory.allowEagerClassLoading;
/*  370 */       this.bootstrapExecutor = otherListableFactory.bootstrapExecutor;
/*  371 */       this.dependencyComparator = otherListableFactory.dependencyComparator;
/*      */       
/*  373 */       setAutowireCandidateResolver(otherListableFactory.getAutowireCandidateResolver().cloneIfNecessary());
/*      */       
/*  375 */       this.resolvableDependencies.putAll(otherListableFactory.resolvableDependencies); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getBean(Class<T> requiredType) throws BeansException {
/*  386 */     return getBean(requiredType, (Object[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getBean(Class<T> requiredType, @Nullable Object... args) throws BeansException {
/*  392 */     Assert.notNull(requiredType, "Required type must not be null");
/*  393 */     Object resolved = resolveBean(ResolvableType.forRawClass(requiredType), args, false);
/*  394 */     if (resolved == null) {
/*  395 */       throw new NoSuchBeanDefinitionException(requiredType);
/*      */     }
/*  397 */     return (T)resolved;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(Class<T> requiredType) {
/*  402 */     Assert.notNull(requiredType, "Required type must not be null");
/*  403 */     return getBeanProvider(ResolvableType.forRawClass(requiredType), true);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(ResolvableType requiredType) {
/*  408 */     return getBeanProvider(requiredType, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsBeanDefinition(String beanName) {
/*  418 */     Assert.notNull(beanName, "Bean name must not be null");
/*  419 */     return this.beanDefinitionMap.containsKey(beanName);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getBeanDefinitionCount() {
/*  424 */     return this.beanDefinitionMap.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanDefinitionNames() {
/*  429 */     String[] frozenNames = this.frozenBeanDefinitionNames;
/*  430 */     if (frozenNames != null) {
/*  431 */       return (String[])frozenNames.clone();
/*      */     }
/*      */     
/*  434 */     return StringUtils.toStringArray(this.beanDefinitionNames);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(Class<T> requiredType, boolean allowEagerInit) {
/*  440 */     Assert.notNull(requiredType, "Required type must not be null");
/*  441 */     return getBeanProvider(ResolvableType.forRawClass(requiredType), allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> ObjectProvider<T> getBeanProvider(final ResolvableType requiredType, final boolean allowEagerInit) {
/*  446 */     return new BeanObjectProvider<T>()
/*      */       {
/*      */         public T getObject() throws BeansException {
/*  449 */           T resolved = DefaultListableBeanFactory.this.resolveBean(requiredType, (Object[])null, false);
/*  450 */           if (resolved == null) {
/*  451 */             throw new NoSuchBeanDefinitionException(requiredType);
/*      */           }
/*  453 */           return resolved;
/*      */         }
/*      */         
/*      */         public T getObject(Object... args) throws BeansException {
/*  457 */           T resolved = DefaultListableBeanFactory.this.resolveBean(requiredType, args, false);
/*  458 */           if (resolved == null) {
/*  459 */             throw new NoSuchBeanDefinitionException(requiredType);
/*      */           }
/*  461 */           return resolved;
/*      */         }
/*      */         
/*      */         @Nullable
/*      */         public T getIfAvailable() throws BeansException {
/*      */           try {
/*  467 */             return DefaultListableBeanFactory.this.resolveBean(requiredType, (Object[])null, false);
/*      */           }
/*  469 */           catch (ScopeNotActiveException ex) {
/*      */             
/*  471 */             return null;
/*      */           } 
/*      */         }
/*      */         
/*      */         public void ifAvailable(Consumer<T> dependencyConsumer) throws BeansException {
/*  476 */           T dependency = getIfAvailable();
/*  477 */           if (dependency != null) {
/*      */             try {
/*  479 */               dependencyConsumer.accept(dependency);
/*      */             }
/*  481 */             catch (ScopeNotActiveException scopeNotActiveException) {}
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @Nullable
/*      */         public T getIfUnique() throws BeansException {
/*      */           try {
/*  490 */             return DefaultListableBeanFactory.this.resolveBean(requiredType, (Object[])null, true);
/*      */           }
/*  492 */           catch (ScopeNotActiveException ex) {
/*      */             
/*  494 */             return null;
/*      */           } 
/*      */         }
/*      */         
/*      */         public void ifUnique(Consumer<T> dependencyConsumer) throws BeansException {
/*  499 */           T dependency = getIfUnique();
/*  500 */           if (dependency != null) {
/*      */             try {
/*  502 */               dependencyConsumer.accept(dependency);
/*      */             }
/*  504 */             catch (ScopeNotActiveException scopeNotActiveException) {}
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Stream<T> stream() {
/*  512 */           return Arrays.<String>stream(DefaultListableBeanFactory.this.beanNamesForStream(requiredType, true, allowEagerInit))
/*  513 */             .map(name -> DefaultListableBeanFactory.this.getBean(name))
/*  514 */             .filter(bean -> !(bean instanceof NullBean));
/*      */         }
/*      */ 
/*      */         
/*      */         public Stream<T> orderedStream() {
/*  519 */           String[] beanNames = DefaultListableBeanFactory.this.beanNamesForStream(requiredType, true, allowEagerInit);
/*  520 */           if (beanNames.length == 0) {
/*  521 */             return Stream.empty();
/*      */           }
/*  523 */           Map<String, T> matchingBeans = CollectionUtils.newLinkedHashMap(beanNames.length);
/*  524 */           for (String beanName : beanNames) {
/*  525 */             Object beanInstance = DefaultListableBeanFactory.this.getBean(beanName);
/*  526 */             if (!(beanInstance instanceof NullBean)) {
/*  527 */               matchingBeans.put(beanName, (T)beanInstance);
/*      */             }
/*      */           } 
/*  530 */           Stream<T> stream = matchingBeans.values().stream();
/*  531 */           return stream.sorted((Comparator)DefaultListableBeanFactory.this.adaptOrderComparator(matchingBeans));
/*      */         }
/*      */ 
/*      */         
/*      */         public Stream<T> stream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/*  536 */           return Arrays.<String>stream(DefaultListableBeanFactory.this.beanNamesForStream(requiredType, includeNonSingletons, allowEagerInit))
/*  537 */             .filter(name -> customFilter.test(DefaultListableBeanFactory.this.getType(name)))
/*  538 */             .map(name -> DefaultListableBeanFactory.this.getBean(name))
/*  539 */             .filter(bean -> !(bean instanceof NullBean));
/*      */         }
/*      */ 
/*      */         
/*      */         public Stream<T> orderedStream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/*  544 */           String[] beanNames = DefaultListableBeanFactory.this.beanNamesForStream(requiredType, includeNonSingletons, allowEagerInit);
/*  545 */           if (beanNames.length == 0) {
/*  546 */             return Stream.empty();
/*      */           }
/*  548 */           Map<String, T> matchingBeans = CollectionUtils.newLinkedHashMap(beanNames.length);
/*  549 */           for (String beanName : beanNames) {
/*  550 */             if (customFilter.test(DefaultListableBeanFactory.this.getType(beanName))) {
/*  551 */               Object beanInstance = DefaultListableBeanFactory.this.getBean(beanName);
/*  552 */               if (!(beanInstance instanceof NullBean)) {
/*  553 */                 matchingBeans.put(beanName, (T)beanInstance);
/*      */               }
/*      */             } 
/*      */           } 
/*  557 */           return matchingBeans.values().stream().sorted((Comparator)DefaultListableBeanFactory.this.adaptOrderComparator(matchingBeans));
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private <T> T resolveBean(ResolvableType requiredType, @Nullable Object[] args, boolean nonUniqueAsNull) {
/*  564 */     NamedBeanHolder<T> namedBean = resolveNamedBean(requiredType, args, nonUniqueAsNull);
/*  565 */     if (namedBean != null) {
/*  566 */       return (T)namedBean.getBeanInstance();
/*      */     }
/*  568 */     BeanFactory parent = getParentBeanFactory();
/*  569 */     if (parent instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)parent;
/*  570 */       return dlbf.resolveBean(requiredType, args, nonUniqueAsNull); }
/*      */     
/*  572 */     if (parent != null) {
/*  573 */       ObjectProvider<T> parentProvider = parent.getBeanProvider(requiredType);
/*  574 */       if (args != null) {
/*  575 */         return (T)parentProvider.getObject(args);
/*      */       }
/*      */       
/*  578 */       return nonUniqueAsNull ? (T)parentProvider.getIfUnique() : (T)parentProvider.getIfAvailable();
/*      */     } 
/*      */     
/*  581 */     return null;
/*      */   }
/*      */   
/*      */   private String[] beanNamesForStream(ResolvableType requiredType, boolean includeNonSingletons, boolean allowEagerInit) {
/*  585 */     return BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this, requiredType, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(ResolvableType type) {
/*  590 */     return getBeanNamesForType(type, true, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(ResolvableType type, boolean includeNonSingletons, boolean allowEagerInit) {
/*  595 */     Class<?> resolved = type.resolve();
/*  596 */     if (resolved != null && !type.hasGenerics()) {
/*  597 */       return getBeanNamesForType(resolved, includeNonSingletons, allowEagerInit);
/*      */     }
/*      */     
/*  600 */     return doGetBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(@Nullable Class<?> type) {
/*  606 */     return getBeanNamesForType(type, true, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForType(@Nullable Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
/*  611 */     if (!isConfigurationFrozen() || type == null || !allowEagerInit) {
/*  612 */       return doGetBeanNamesForType(ResolvableType.forRawClass(type), includeNonSingletons, allowEagerInit);
/*      */     }
/*      */     
/*  615 */     Map<Class<?>, String[]> cache = includeNonSingletons ? this.allBeanNamesByType : this.singletonBeanNamesByType;
/*  616 */     String[] resolvedBeanNames = cache.get(type);
/*  617 */     if (resolvedBeanNames != null) {
/*  618 */       return resolvedBeanNames;
/*      */     }
/*  620 */     resolvedBeanNames = doGetBeanNamesForType(ResolvableType.forRawClass(type), includeNonSingletons, true);
/*  621 */     if (ClassUtils.isCacheSafe(type, getBeanClassLoader())) {
/*  622 */       cache.put(type, resolvedBeanNames);
/*      */     }
/*  624 */     return resolvedBeanNames;
/*      */   }
/*      */   
/*      */   private String[] doGetBeanNamesForType(ResolvableType type, boolean includeNonSingletons, boolean allowEagerInit) {
/*  628 */     List<String> result = new ArrayList<>();
/*      */ 
/*      */     
/*  631 */     for (String beanName : this.beanDefinitionNames) {
/*      */       
/*  633 */       if (!isAlias(beanName)) {
/*      */         try {
/*  635 */           RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*      */           
/*  637 */           if (!mbd.isAbstract() && (allowEagerInit || ((mbd
/*  638 */             .hasBeanClass() || !mbd.isLazyInit() || isAllowEagerClassLoading()) && 
/*  639 */             !requiresEagerInitForType(mbd.getFactoryBeanName())))) {
/*  640 */             boolean isFactoryBean = isFactoryBean(beanName, mbd);
/*  641 */             BeanDefinitionHolder dbd = mbd.getDecoratedDefinition();
/*  642 */             boolean matchFound = false;
/*  643 */             boolean allowFactoryBeanInit = (allowEagerInit || containsSingleton(beanName));
/*  644 */             boolean isNonLazyDecorated = (dbd != null && !mbd.isLazyInit());
/*  645 */             if (!isFactoryBean) {
/*  646 */               if (includeNonSingletons || isSingleton(beanName, mbd, dbd)) {
/*  647 */                 matchFound = isTypeMatch(beanName, type, allowFactoryBeanInit);
/*      */               }
/*      */             } else {
/*      */               
/*  651 */               if (includeNonSingletons || isNonLazyDecorated) {
/*  652 */                 matchFound = isTypeMatch(beanName, type, allowFactoryBeanInit);
/*      */               }
/*  654 */               else if (allowFactoryBeanInit) {
/*      */ 
/*      */ 
/*      */                 
/*  658 */                 matchFound = (isTypeMatch(beanName, type, allowFactoryBeanInit) && isSingleton(beanName, mbd, dbd));
/*      */               } 
/*  660 */               if (!matchFound) {
/*      */                 
/*  662 */                 beanName = "&" + beanName;
/*  663 */                 if (includeNonSingletons || isSingleton(beanName, mbd, dbd)) {
/*  664 */                   matchFound = isTypeMatch(beanName, type, allowFactoryBeanInit);
/*      */                 }
/*      */               } 
/*      */             } 
/*  668 */             if (matchFound) {
/*  669 */               result.add(beanName);
/*      */             }
/*      */           }
/*      */         
/*  673 */         } catch (CannotLoadBeanClassException|BeanDefinitionStoreException ex) {
/*  674 */           if (allowEagerInit) {
/*  675 */             throw ex;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  680 */           LogMessage message = (ex instanceof CannotLoadBeanClassException) ? LogMessage.format("Ignoring bean class loading failure for bean '%s'", beanName) : LogMessage.format("Ignoring unresolvable metadata in bean definition '%s'", beanName);
/*  681 */           this.logger.trace(message, (Throwable)ex);
/*      */           
/*  683 */           onSuppressedException((Exception)ex);
/*      */         }
/*  685 */         catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  692 */     for (String beanName : this.manualSingletonNames) {
/*      */       
/*      */       try {
/*  695 */         if (isFactoryBean(beanName)) {
/*  696 */           if ((includeNonSingletons || isSingleton(beanName)) && isTypeMatch(beanName, type)) {
/*  697 */             result.add(beanName);
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  702 */           beanName = "&" + beanName;
/*      */         } 
/*      */         
/*  705 */         if (isTypeMatch(beanName, type)) {
/*  706 */           result.add(beanName);
/*      */         }
/*      */       }
/*  709 */       catch (NoSuchBeanDefinitionException ex) {
/*      */         
/*  711 */         this.logger.trace(LogMessage.format("Failed to check manually registered singleton with name '%s'", beanName), (Throwable)ex);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  716 */     return StringUtils.toStringArray(result);
/*      */   }
/*      */   
/*      */   private boolean isSingleton(String beanName, RootBeanDefinition mbd, @Nullable BeanDefinitionHolder dbd) {
/*  720 */     return (dbd != null) ? mbd.isSingleton() : isSingleton(beanName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean requiresEagerInitForType(@Nullable String factoryBeanName) {
/*  731 */     return (factoryBeanName != null && isFactoryBean(factoryBeanName) && !containsSingleton(factoryBeanName));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> Map<String, T> getBeansOfType(@Nullable Class<T> type) throws BeansException {
/*  736 */     return getBeansOfType(type, true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Map<String, T> getBeansOfType(@Nullable Class<T> type, boolean includeNonSingletons, boolean allowEagerInit) throws BeansException {
/*  744 */     String[] beanNames = getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*  745 */     Map<String, T> result = CollectionUtils.newLinkedHashMap(beanNames.length);
/*  746 */     for (String beanName : beanNames) {
/*      */       try {
/*  748 */         Object beanInstance = getBean(beanName);
/*  749 */         if (!(beanInstance instanceof NullBean)) {
/*  750 */           result.put(beanName, (T)beanInstance);
/*      */         }
/*      */       }
/*  753 */       catch (BeanCreationException ex) {
/*  754 */         Throwable rootCause = ex.getMostSpecificCause();
/*  755 */         if (rootCause instanceof BeanCurrentlyInCreationException) { BeanCurrentlyInCreationException bce = (BeanCurrentlyInCreationException)rootCause;
/*  756 */           String exBeanName = bce.getBeanName();
/*  757 */           if (exBeanName != null && isCurrentlyInCreation(exBeanName))
/*  758 */           { if (this.logger.isTraceEnabled()) {
/*  759 */               this.logger.trace("Ignoring match to currently created bean '" + exBeanName + "': " + ex
/*  760 */                   .getMessage());
/*      */             }
/*  762 */             onSuppressedException((Exception)ex);
/*      */              }
/*      */           
/*      */           else
/*      */           
/*      */           { 
/*  768 */             throw ex; }  } else { throw ex; }
/*      */       
/*      */       } 
/*  771 */     }  return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getBeanNamesForAnnotation(Class<? extends Annotation> annotationType) {
/*  776 */     List<String> result = new ArrayList<>();
/*  777 */     for (String beanName : this.beanDefinitionNames) {
/*  778 */       BeanDefinition bd = this.beanDefinitionMap.get(beanName);
/*  779 */       if (bd != null && !bd.isAbstract() && findAnnotationOnBean(beanName, annotationType) != null) {
/*  780 */         result.add(beanName);
/*      */       }
/*      */     } 
/*  783 */     for (String beanName : this.manualSingletonNames) {
/*  784 */       if (!result.contains(beanName) && findAnnotationOnBean(beanName, annotationType) != null) {
/*  785 */         result.add(beanName);
/*      */       }
/*      */     } 
/*  788 */     return StringUtils.toStringArray(result);
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType) {
/*  793 */     String[] beanNames = getBeanNamesForAnnotation(annotationType);
/*  794 */     Map<String, Object> result = CollectionUtils.newLinkedHashMap(beanNames.length);
/*  795 */     for (String beanName : beanNames) {
/*  796 */       Object beanInstance = getBean(beanName);
/*  797 */       if (!(beanInstance instanceof NullBean)) {
/*  798 */         result.put(beanName, beanInstance);
/*      */       }
/*      */     } 
/*  801 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType) throws NoSuchBeanDefinitionException {
/*  809 */     return findAnnotationOnBean(beanName, annotationType, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/*  818 */     Class<?> beanType = getType(beanName, allowFactoryBeanInit);
/*  819 */     if (beanType != null) {
/*      */       
/*  821 */       MergedAnnotation<A> annotation = MergedAnnotations.from(beanType, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType);
/*  822 */       if (annotation.isPresent()) {
/*  823 */         return (A)annotation.synthesize();
/*      */       }
/*      */     } 
/*  826 */     if (containsBeanDefinition(beanName)) {
/*  827 */       RootBeanDefinition bd = getMergedLocalBeanDefinition(beanName);
/*      */       
/*  829 */       if (bd.hasBeanClass() && bd.getFactoryMethodName() == null) {
/*  830 */         Class<?> beanClass = bd.getBeanClass();
/*  831 */         if (beanClass != beanType) {
/*      */           
/*  833 */           MergedAnnotation<A> annotation = MergedAnnotations.from(beanClass, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType);
/*  834 */           if (annotation.isPresent()) {
/*  835 */             return (A)annotation.synthesize();
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  840 */       Method factoryMethod = bd.getResolvedFactoryMethod();
/*  841 */       if (factoryMethod != null) {
/*      */         
/*  843 */         MergedAnnotation<A> annotation = MergedAnnotations.from(factoryMethod, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY).get(annotationType);
/*  844 */         if (annotation.isPresent()) {
/*  845 */           return (A)annotation.synthesize();
/*      */         }
/*      */       } 
/*      */     } 
/*  849 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <A extends Annotation> Set<A> findAllAnnotationsOnBean(String beanName, Class<A> annotationType, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/*  857 */     Set<A> annotations = new LinkedHashSet<>();
/*  858 */     Class<?> beanType = getType(beanName, allowFactoryBeanInit);
/*  859 */     if (beanType != null) {
/*  860 */       MergedAnnotations.from(beanType, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/*  861 */         .stream(annotationType)
/*  862 */         .filter(MergedAnnotation::isPresent)
/*  863 */         .forEach(mergedAnnotation -> annotations.add(mergedAnnotation.synthesize()));
/*      */     }
/*  865 */     if (containsBeanDefinition(beanName)) {
/*  866 */       RootBeanDefinition bd = getMergedLocalBeanDefinition(beanName);
/*      */       
/*  868 */       if (bd.hasBeanClass() && bd.getFactoryMethodName() == null) {
/*  869 */         Class<?> beanClass = bd.getBeanClass();
/*  870 */         if (beanClass != beanType) {
/*  871 */           MergedAnnotations.from(beanClass, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/*  872 */             .stream(annotationType)
/*  873 */             .filter(MergedAnnotation::isPresent)
/*  874 */             .forEach(mergedAnnotation -> annotations.add(mergedAnnotation.synthesize()));
/*      */         }
/*      */       } 
/*      */       
/*  878 */       Method factoryMethod = bd.getResolvedFactoryMethod();
/*  879 */       if (factoryMethod != null) {
/*  880 */         MergedAnnotations.from(factoryMethod, MergedAnnotations.SearchStrategy.TYPE_HIERARCHY)
/*  881 */           .stream(annotationType)
/*  882 */           .filter(MergedAnnotation::isPresent)
/*  883 */           .forEach(mergedAnnotation -> annotations.add(mergedAnnotation.synthesize()));
/*      */       }
/*      */     } 
/*  886 */     return annotations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerResolvableDependency(Class<?> dependencyType, @Nullable Object autowiredValue) {
/*  896 */     Assert.notNull(dependencyType, "Dependency type must not be null");
/*  897 */     if (autowiredValue != null) {
/*  898 */       if (!(autowiredValue instanceof ObjectFactory) && !dependencyType.isInstance(autowiredValue)) {
/*  899 */         throw new IllegalArgumentException("Value [" + String.valueOf(autowiredValue) + "] does not implement specified dependency type [" + dependencyType
/*  900 */             .getName() + "]");
/*      */       }
/*  902 */       this.resolvableDependencies.put(dependencyType, autowiredValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAutowireCandidate(String beanName, DependencyDescriptor descriptor) throws NoSuchBeanDefinitionException {
/*  910 */     return isAutowireCandidate(beanName, descriptor, getAutowireCandidateResolver());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isAutowireCandidate(String beanName, DependencyDescriptor descriptor, AutowireCandidateResolver resolver) throws NoSuchBeanDefinitionException {
/*  925 */     String bdName = transformedBeanName(beanName);
/*  926 */     if (containsBeanDefinition(bdName)) {
/*  927 */       return isAutowireCandidate(beanName, getMergedLocalBeanDefinition(bdName), descriptor, resolver);
/*      */     }
/*  929 */     if (containsSingleton(beanName)) {
/*  930 */       return isAutowireCandidate(beanName, new RootBeanDefinition(getType(beanName)), descriptor, resolver);
/*      */     }
/*      */     
/*  933 */     BeanFactory parent = getParentBeanFactory();
/*  934 */     if (parent instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)parent;
/*      */       
/*  936 */       return dlbf.isAutowireCandidate(beanName, descriptor, resolver); }
/*      */     
/*  938 */     if (parent instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)parent;
/*      */       
/*  940 */       return clbf.isAutowireCandidate(beanName, descriptor); }
/*      */ 
/*      */     
/*  943 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isAutowireCandidate(String beanName, RootBeanDefinition mbd, DependencyDescriptor descriptor, AutowireCandidateResolver resolver) {
/*  959 */     String bdName = transformedBeanName(beanName);
/*  960 */     resolveBeanClass(mbd, bdName, new Class[0]);
/*  961 */     if (mbd.isFactoryMethodUnique && mbd.factoryMethodToIntrospect == null) {
/*  962 */       (new ConstructorResolver(this)).resolveFactoryMethodIfPossible(mbd);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  967 */     BeanDefinitionHolder holder = beanName.equals(bdName) ? this.mergedBeanDefinitionHolders.computeIfAbsent(beanName, key -> new BeanDefinitionHolder(mbd, beanName, getAliases(bdName))) : new BeanDefinitionHolder(mbd, beanName, getAliases(bdName));
/*  968 */     return resolver.isAutowireCandidate(holder, descriptor);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDefinition getBeanDefinition(String beanName) throws NoSuchBeanDefinitionException {
/*  973 */     BeanDefinition bd = this.beanDefinitionMap.get(beanName);
/*  974 */     if (bd == null) {
/*  975 */       if (this.logger.isTraceEnabled()) {
/*  976 */         this.logger.trace("No bean named '" + beanName + "' found in " + String.valueOf(this));
/*      */       }
/*  978 */       throw new NoSuchBeanDefinitionException(beanName);
/*      */     } 
/*  980 */     return bd;
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<String> getBeanNamesIterator() {
/*  985 */     CompositeIterator<String> iterator = new CompositeIterator();
/*  986 */     iterator.add(this.beanDefinitionNames.iterator());
/*  987 */     iterator.add(this.manualSingletonNames.iterator());
/*  988 */     return (Iterator<String>)iterator;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void clearMergedBeanDefinition(String beanName) {
/*  993 */     super.clearMergedBeanDefinition(beanName);
/*  994 */     this.mergedBeanDefinitionHolders.remove(beanName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearMetadataCache() {
/*  999 */     super.clearMetadataCache();
/* 1000 */     this.mergedBeanDefinitionHolders.clear();
/* 1001 */     clearByTypeCache();
/*      */   }
/*      */ 
/*      */   
/*      */   public void freezeConfiguration() {
/* 1006 */     clearMetadataCache();
/* 1007 */     this.configurationFrozen = true;
/* 1008 */     this.frozenBeanDefinitionNames = StringUtils.toStringArray(this.beanDefinitionNames);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isConfigurationFrozen() {
/* 1013 */     return this.configurationFrozen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isBeanEligibleForMetadataCaching(String beanName) {
/* 1023 */     return (this.configurationFrozen || super.isBeanEligibleForMetadataCaching(beanName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object obtainInstanceFromSupplier(Supplier<?> supplier, String beanName, RootBeanDefinition mbd) throws Exception {
/* 1031 */     if (supplier instanceof InstanceSupplier) { InstanceSupplier<?> instanceSupplier = (InstanceSupplier)supplier;
/* 1032 */       return instanceSupplier.get(RegisteredBean.of(this, beanName, mbd)); }
/*      */     
/* 1034 */     return super.obtainInstanceFromSupplier(supplier, beanName, mbd);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void cacheMergedBeanDefinition(RootBeanDefinition mbd, String beanName) {
/* 1039 */     super.cacheMergedBeanDefinition(mbd, beanName);
/* 1040 */     if (mbd.isPrimary()) {
/* 1041 */       this.primaryBeanNamesWithType.put(beanName, Void.class);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void checkMergedBeanDefinition(RootBeanDefinition mbd, String beanName, @Nullable Object[] args) {
/* 1047 */     super.checkMergedBeanDefinition(mbd, beanName, args);
/*      */     
/* 1049 */     if (mbd.isBackgroundInit()) {
/* 1050 */       if (this.preInstantiationThread.get() == PreInstantiation.MAIN && getBootstrapExecutor() != null) {
/* 1051 */         throw new BeanCurrentlyInCreationException(beanName, "Bean marked for background initialization but requested in mainline thread - declare ObjectProvider or lazy injection point in dependent mainline beans");
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1058 */     else if (this.preInstantiationThread.get() == PreInstantiation.BACKGROUND) {
/* 1059 */       throw new BeanCurrentlyInCreationException(beanName, "Bean marked for mainline initialization but requested in background thread - enforce early instantiation in mainline thread through depends-on '" + beanName + "' declaration for dependent background beans");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Boolean isCurrentThreadAllowedToHoldSingletonLock() {
/* 1069 */     String mainThreadPrefix = this.mainThreadPrefix;
/* 1070 */     if (mainThreadPrefix != null) {
/*      */ 
/*      */ 
/*      */       
/* 1074 */       PreInstantiation preInstantiation = (PreInstantiation)this.preInstantiationThread.get();
/* 1075 */       if (preInstantiation != null) {
/*      */ 
/*      */ 
/*      */         
/* 1079 */         switch (preInstantiation) { default: throw new IncompatibleClassChangeError();case MAIN: return 
/* 1080 */               Boolean.TRUE.equals(this.strictLocking) ? null : Boolean.valueOf(true);
/* 1081 */           case BACKGROUND: break; }  return Boolean.valueOf(false);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1086 */       if (Boolean.FALSE.equals(this.strictLocking))
/*      */       {
/* 1088 */         return Boolean.valueOf(true);
/*      */       }
/* 1090 */       if (this.strictLocking == null)
/*      */       {
/* 1092 */         if (!getThreadNamePrefix().equals(mainThreadPrefix))
/*      */         {
/*      */ 
/*      */           
/* 1096 */           return Boolean.valueOf(true);
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1102 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void prepareSingletonBootstrap() {
/* 1107 */     this.mainThreadPrefix = getThreadNamePrefix();
/*      */   }
/*      */ 
/*      */   
/*      */   public void preInstantiateSingletons() throws BeansException {
/* 1112 */     if (this.logger.isTraceEnabled()) {
/* 1113 */       this.logger.trace("Pre-instantiating singletons in " + String.valueOf(this));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1118 */     List<String> beanNames = new ArrayList<>(this.beanDefinitionNames);
/*      */ 
/*      */     
/* 1121 */     this.preInstantiationThread.set(PreInstantiation.MAIN);
/* 1122 */     if (this.mainThreadPrefix == null) {
/* 1123 */       this.mainThreadPrefix = getThreadNamePrefix();
/*      */     }
/*      */     try {
/* 1126 */       List<CompletableFuture<?>> futures = new ArrayList<>();
/* 1127 */       for (String beanName : beanNames) {
/* 1128 */         RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/* 1129 */         if (!mbd.isAbstract() && mbd.isSingleton()) {
/* 1130 */           CompletableFuture<?> future = preInstantiateSingleton(beanName, mbd);
/* 1131 */           if (future != null) {
/* 1132 */             futures.add(future);
/*      */           }
/*      */         } 
/*      */       } 
/* 1136 */       if (!futures.isEmpty()) {
/*      */         try {
/* 1138 */           CompletableFuture.allOf((CompletableFuture<?>[])futures.<CompletableFuture>toArray(new CompletableFuture[0])).join();
/*      */         }
/* 1140 */         catch (CompletionException ex) {
/* 1141 */           ReflectionUtils.rethrowRuntimeException(ex.getCause());
/*      */         } 
/*      */       }
/*      */     } finally {
/*      */       
/* 1146 */       this.mainThreadPrefix = null;
/* 1147 */       this.preInstantiationThread.remove();
/*      */     } 
/*      */ 
/*      */     
/* 1151 */     for (String beanName : beanNames) {
/* 1152 */       Object singletonInstance = getSingleton(beanName, false);
/* 1153 */       if (singletonInstance instanceof SmartInitializingSingleton) { SmartInitializingSingleton smartSingleton = (SmartInitializingSingleton)singletonInstance;
/*      */         
/* 1155 */         StartupStep smartInitialize = getApplicationStartup().start("spring.beans.smart-initialize").tag("beanName", beanName);
/* 1156 */         smartSingleton.afterSingletonsInstantiated();
/* 1157 */         smartInitialize.end(); }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private CompletableFuture<?> preInstantiateSingleton(String beanName, RootBeanDefinition mbd) {
/* 1164 */     if (mbd.isBackgroundInit()) {
/* 1165 */       Executor executor = getBootstrapExecutor();
/* 1166 */       if (executor != null) {
/* 1167 */         String[] dependsOn = mbd.getDependsOn();
/* 1168 */         if (dependsOn != null) {
/* 1169 */           for (String dep : dependsOn) {
/* 1170 */             getBean(dep);
/*      */           }
/*      */         }
/* 1173 */         CompletableFuture<?> future = CompletableFuture.runAsync(() -> instantiateSingletonInBackgroundThread(beanName), executor);
/*      */         
/* 1175 */         addSingletonFactory(beanName, () -> {
/*      */               
/*      */               try {
/*      */                 future.join();
/* 1179 */               } catch (CompletionException ex) {
/*      */                 ReflectionUtils.rethrowRuntimeException(ex.getCause());
/*      */               } 
/*      */               return future;
/*      */             });
/* 1184 */         return !mbd.isLazyInit() ? future : null;
/*      */       } 
/* 1186 */       if (this.logger.isInfoEnabled()) {
/* 1187 */         this.logger.info("Bean '" + beanName + "' marked for background initialization without bootstrap executor configured - falling back to mainline initialization");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1192 */     if (!mbd.isLazyInit()) {
/*      */       try {
/* 1194 */         instantiateSingleton(beanName);
/*      */       }
/* 1196 */       catch (BeanCurrentlyInCreationException ex) {
/* 1197 */         this.logger.info("Bean '" + beanName + "' marked for pre-instantiation (not lazy-init) but currently initialized by other thread - skipping it in mainline thread");
/*      */       } 
/*      */     }
/*      */     
/* 1201 */     return null;
/*      */   }
/*      */   
/*      */   private void instantiateSingletonInBackgroundThread(String beanName) {
/* 1205 */     this.preInstantiationThread.set(PreInstantiation.BACKGROUND);
/*      */     try {
/* 1207 */       instantiateSingleton(beanName);
/*      */     }
/* 1209 */     catch (RuntimeException|Error ex) {
/* 1210 */       if (this.logger.isWarnEnabled()) {
/* 1211 */         this.logger.warn("Failed to instantiate singleton bean '" + beanName + "' in background thread", ex);
/*      */       }
/* 1213 */       throw ex;
/*      */     } finally {
/*      */       
/* 1216 */       this.preInstantiationThread.remove();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void instantiateSingleton(String beanName) {
/* 1221 */     if (isFactoryBean(beanName)) {
/* 1222 */       Object bean = getBean("&" + beanName);
/* 1223 */       if (bean instanceof SmartFactoryBean) { SmartFactoryBean<?> smartFactoryBean = (SmartFactoryBean)bean; if (smartFactoryBean.isEagerInit()) {
/* 1224 */           getBean(beanName);
/*      */         } }
/*      */     
/*      */     } else {
/* 1228 */       getBean(beanName);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String getThreadNamePrefix() {
/* 1233 */     String name = Thread.currentThread().getName();
/* 1234 */     int numberSeparator = name.lastIndexOf('-');
/* 1235 */     return (numberSeparator >= 0) ? name.substring(0, numberSeparator) : name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition) throws BeanDefinitionStoreException {
/* 1247 */     Assert.hasText(beanName, "Bean name must not be empty");
/* 1248 */     Assert.notNull(beanDefinition, "BeanDefinition must not be null");
/*      */     
/* 1250 */     if (beanDefinition instanceof AbstractBeanDefinition) { AbstractBeanDefinition abd = (AbstractBeanDefinition)beanDefinition;
/*      */       try {
/* 1252 */         abd.validate();
/*      */       }
/* 1254 */       catch (BeanDefinitionValidationException ex) {
/* 1255 */         throw new BeanDefinitionStoreException(beanDefinition.getResourceDescription(), beanName, "Validation of bean definition failed", ex);
/*      */       }  }
/*      */ 
/*      */ 
/*      */     
/* 1260 */     BeanDefinition existingDefinition = this.beanDefinitionMap.get(beanName);
/* 1261 */     if (existingDefinition != null) {
/* 1262 */       if (!isBeanDefinitionOverridable(beanName)) {
/* 1263 */         throw new BeanDefinitionOverrideException(beanName, beanDefinition, existingDefinition);
/*      */       }
/*      */       
/* 1266 */       logBeanDefinitionOverriding(beanName, beanDefinition, existingDefinition);
/*      */       
/* 1268 */       this.beanDefinitionMap.put(beanName, beanDefinition);
/*      */     } else {
/*      */       
/* 1271 */       if (isAlias(beanName)) {
/* 1272 */         String aliasedName = canonicalName(beanName);
/* 1273 */         if (!isBeanDefinitionOverridable(aliasedName)) {
/* 1274 */           if (containsBeanDefinition(aliasedName)) {
/* 1275 */             throw new BeanDefinitionOverrideException(beanName, beanDefinition, 
/* 1276 */                 getBeanDefinition(aliasedName));
/*      */           }
/*      */           
/* 1279 */           throw new BeanDefinitionStoreException(beanDefinition.getResourceDescription(), beanName, "Cannot register bean definition for bean '" + beanName + "' since there is already an alias for bean '" + aliasedName + "' bound.");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1285 */         if (this.logger.isInfoEnabled()) {
/* 1286 */           this.logger.info("Removing alias '" + beanName + "' for bean '" + aliasedName + "' due to registration of bean definition for bean '" + beanName + "': [" + String.valueOf(beanDefinition) + "]");
/*      */         }
/*      */ 
/*      */         
/* 1290 */         removeAlias(beanName);
/*      */       } 
/*      */       
/* 1293 */       if (hasBeanCreationStarted()) {
/*      */         
/* 1295 */         synchronized (this.beanDefinitionMap) {
/* 1296 */           this.beanDefinitionMap.put(beanName, beanDefinition);
/* 1297 */           List<String> updatedDefinitions = new ArrayList<>(this.beanDefinitionNames.size() + 1);
/* 1298 */           updatedDefinitions.addAll(this.beanDefinitionNames);
/* 1299 */           updatedDefinitions.add(beanName);
/* 1300 */           this.beanDefinitionNames = updatedDefinitions;
/* 1301 */           removeManualSingletonName(beanName);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1306 */         this.beanDefinitionMap.put(beanName, beanDefinition);
/* 1307 */         this.beanDefinitionNames.add(beanName);
/* 1308 */         removeManualSingletonName(beanName);
/*      */       } 
/* 1310 */       this.frozenBeanDefinitionNames = null;
/*      */     } 
/*      */     
/* 1313 */     if (existingDefinition != null || containsSingleton(beanName)) {
/* 1314 */       resetBeanDefinition(beanName);
/*      */     }
/* 1316 */     else if (isConfigurationFrozen()) {
/* 1317 */       clearByTypeCache();
/*      */     } 
/*      */ 
/*      */     
/* 1321 */     if (beanDefinition.isPrimary()) {
/* 1322 */       this.primaryBeanNamesWithType.put(beanName, Void.class);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void logBeanDefinitionOverriding(String beanName, BeanDefinition beanDefinition, BeanDefinition existingDefinition) {
/* 1329 */     boolean explicitBeanOverride = (this.allowBeanDefinitionOverriding != null);
/* 1330 */     if (existingDefinition.getRole() < beanDefinition.getRole()) {
/*      */       
/* 1332 */       if (this.logger.isInfoEnabled()) {
/* 1333 */         this.logger.info("Overriding user-defined bean definition for bean '" + beanName + "' with a framework-generated bean definition: replacing [" + String.valueOf(existingDefinition) + "] with [" + String.valueOf(beanDefinition) + "]");
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1338 */     else if (!beanDefinition.equals(existingDefinition)) {
/* 1339 */       if (explicitBeanOverride && this.logger.isInfoEnabled()) {
/* 1340 */         this.logger.info("Overriding bean definition for bean '" + beanName + "' with a different definition: replacing [" + String.valueOf(existingDefinition) + "] with [" + String.valueOf(beanDefinition) + "]");
/*      */       }
/*      */ 
/*      */       
/* 1344 */       if (this.logger.isDebugEnabled()) {
/* 1345 */         this.logger.debug("Overriding bean definition for bean '" + beanName + "' with a different definition: replacing [" + String.valueOf(existingDefinition) + "] with [" + String.valueOf(beanDefinition) + "]");
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1351 */       if (explicitBeanOverride && this.logger.isInfoEnabled()) {
/* 1352 */         this.logger.info("Overriding bean definition for bean '" + beanName + "' with an equivalent definition: replacing [" + String.valueOf(existingDefinition) + "] with [" + String.valueOf(beanDefinition) + "]");
/*      */       }
/*      */ 
/*      */       
/* 1356 */       if (this.logger.isTraceEnabled()) {
/* 1357 */         this.logger.trace("Overriding bean definition for bean '" + beanName + "' with an equivalent definition: replacing [" + String.valueOf(existingDefinition) + "] with [" + String.valueOf(beanDefinition) + "]");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBeanDefinition(String beanName) throws NoSuchBeanDefinitionException {
/* 1366 */     Assert.hasText(beanName, "'beanName' must not be empty");
/*      */     
/* 1368 */     BeanDefinition bd = this.beanDefinitionMap.remove(beanName);
/* 1369 */     if (bd == null) {
/* 1370 */       if (this.logger.isTraceEnabled()) {
/* 1371 */         this.logger.trace("No bean named '" + beanName + "' found in " + String.valueOf(this));
/*      */       }
/* 1373 */       throw new NoSuchBeanDefinitionException(beanName);
/*      */     } 
/*      */     
/* 1376 */     if (hasBeanCreationStarted()) {
/*      */       
/* 1378 */       synchronized (this.beanDefinitionMap) {
/* 1379 */         List<String> updatedDefinitions = new ArrayList<>(this.beanDefinitionNames);
/* 1380 */         updatedDefinitions.remove(beanName);
/* 1381 */         this.beanDefinitionNames = updatedDefinitions;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1386 */       this.beanDefinitionNames.remove(beanName);
/*      */     } 
/* 1388 */     this.frozenBeanDefinitionNames = null;
/*      */     
/* 1390 */     resetBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetBeanDefinition(String beanName) {
/* 1406 */     clearMergedBeanDefinition(beanName);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1411 */     destroySingleton(beanName);
/*      */ 
/*      */     
/* 1414 */     this.primaryBeanNamesWithType.remove(beanName);
/*      */ 
/*      */     
/* 1417 */     for (MergedBeanDefinitionPostProcessor processor : (getBeanPostProcessorCache()).mergedDefinition) {
/* 1418 */       processor.resetBeanDefinition(beanName);
/*      */     }
/*      */ 
/*      */     
/* 1422 */     for (String bdName : this.beanDefinitionNames) {
/* 1423 */       if (!beanName.equals(bdName)) {
/* 1424 */         BeanDefinition bd = this.beanDefinitionMap.get(bdName);
/*      */         
/* 1426 */         if (bd != null && beanName.equals(bd.getParentName())) {
/* 1427 */           resetBeanDefinition(bdName);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeanDefinitionOverridable(String beanName) {
/* 1440 */     return isAllowBeanDefinitionOverriding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean allowAliasOverriding() {
/* 1449 */     return isAllowBeanDefinitionOverriding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkForAliasCircle(String name, String alias) {
/* 1457 */     super.checkForAliasCircle(name, alias);
/* 1458 */     if (!isBeanDefinitionOverridable(alias) && containsBeanDefinition(alias)) {
/* 1459 */       throw new IllegalStateException("Cannot register alias '" + alias + "' for name '" + name + "': Alias would override bean definition '" + alias + "'");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addSingleton(String beanName, Object singletonObject) {
/* 1466 */     super.addSingleton(beanName, singletonObject);
/*      */     
/* 1468 */     Predicate<Class<?>> filter = beanType -> (beanType != Object.class && beanType.isInstance(singletonObject));
/* 1469 */     this.allBeanNamesByType.keySet().removeIf(filter);
/* 1470 */     this.singletonBeanNamesByType.keySet().removeIf(filter);
/*      */     
/* 1472 */     if (this.primaryBeanNamesWithType.containsKey(beanName) && singletonObject.getClass() != NullBean.class) {
/* 1473 */       FactoryBean<?> fb = (FactoryBean)singletonObject;
/* 1474 */       Class<?> beanType = (singletonObject instanceof FactoryBean) ? getTypeForFactoryBean(fb) : singletonObject.getClass();
/* 1475 */       if (beanType != null) {
/* 1476 */         this.primaryBeanNamesWithType.put(beanName, beanType);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerSingleton(String beanName, Object singletonObject) throws IllegalStateException {
/* 1483 */     super.registerSingleton(beanName, singletonObject);
/*      */     
/* 1485 */     updateManualSingletonNames(set -> set.add(beanName), set -> !this.beanDefinitionMap.containsKey(beanName));
/* 1486 */     this.allBeanNamesByType.remove(Object.class);
/* 1487 */     this.singletonBeanNamesByType.remove(Object.class);
/*      */   }
/*      */ 
/*      */   
/*      */   public void destroySingletons() {
/* 1492 */     super.destroySingletons();
/* 1493 */     updateManualSingletonNames(Set::clear, set -> !set.isEmpty());
/* 1494 */     clearByTypeCache();
/*      */   }
/*      */ 
/*      */   
/*      */   public void destroySingleton(String beanName) {
/* 1499 */     super.destroySingleton(beanName);
/* 1500 */     removeManualSingletonName(beanName);
/* 1501 */     clearByTypeCache();
/*      */   }
/*      */   
/*      */   private void removeManualSingletonName(String beanName) {
/* 1505 */     updateManualSingletonNames(set -> set.remove(beanName), set -> set.contains(beanName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateManualSingletonNames(Consumer<Set<String>> action, Predicate<Set<String>> condition) {
/* 1515 */     if (hasBeanCreationStarted()) {
/*      */       
/* 1517 */       synchronized (this.beanDefinitionMap) {
/* 1518 */         if (condition.test(this.manualSingletonNames)) {
/* 1519 */           Set<String> updatedSingletons = new LinkedHashSet<>(this.manualSingletonNames);
/* 1520 */           action.accept(updatedSingletons);
/* 1521 */           this.manualSingletonNames = updatedSingletons;
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1527 */     else if (condition.test(this.manualSingletonNames)) {
/* 1528 */       action.accept(this.manualSingletonNames);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void clearByTypeCache() {
/* 1537 */     this.allBeanNamesByType.clear();
/* 1538 */     this.singletonBeanNamesByType.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> NamedBeanHolder<T> resolveNamedBean(Class<T> requiredType) throws BeansException {
/* 1548 */     Assert.notNull(requiredType, "Required type must not be null");
/* 1549 */     NamedBeanHolder<T> namedBean = resolveNamedBean(ResolvableType.forRawClass(requiredType), (Object[])null, false);
/* 1550 */     if (namedBean != null) {
/* 1551 */       return namedBean;
/*      */     }
/* 1553 */     BeanFactory parent = getParentBeanFactory();
/* 1554 */     if (parent instanceof AutowireCapableBeanFactory) { AutowireCapableBeanFactory acbf = (AutowireCapableBeanFactory)parent;
/* 1555 */       return acbf.resolveNamedBean(requiredType); }
/*      */     
/* 1557 */     throw new NoSuchBeanDefinitionException(requiredType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private <T> NamedBeanHolder<T> resolveNamedBean(ResolvableType requiredType, @Nullable Object[] args, boolean nonUniqueAsNull) throws BeansException {
/* 1565 */     Assert.notNull(requiredType, "Required type must not be null");
/* 1566 */     String[] candidateNames = getBeanNamesForType(requiredType);
/*      */     
/* 1568 */     if (candidateNames.length > 1) {
/* 1569 */       List<String> autowireCandidates = new ArrayList<>(candidateNames.length);
/* 1570 */       for (String beanName : candidateNames) {
/* 1571 */         if (!containsBeanDefinition(beanName) || getBeanDefinition(beanName).isAutowireCandidate()) {
/* 1572 */           autowireCandidates.add(beanName);
/*      */         }
/*      */       } 
/* 1575 */       if (!autowireCandidates.isEmpty()) {
/* 1576 */         candidateNames = StringUtils.toStringArray(autowireCandidates);
/*      */       }
/*      */     } 
/*      */     
/* 1580 */     if (candidateNames.length == 1) {
/* 1581 */       return resolveNamedBean(candidateNames[0], requiredType, args);
/*      */     }
/* 1583 */     if (candidateNames.length > 1) {
/* 1584 */       Map<String, Object> candidates = CollectionUtils.newLinkedHashMap(candidateNames.length);
/* 1585 */       for (String beanName : candidateNames) {
/* 1586 */         if (containsSingleton(beanName) && args == null) {
/* 1587 */           Object beanInstance = getBean(beanName);
/* 1588 */           candidates.put(beanName, (beanInstance instanceof NullBean) ? null : beanInstance);
/*      */         } else {
/*      */           
/* 1591 */           candidates.put(beanName, getType(beanName));
/*      */         } 
/*      */       } 
/* 1594 */       String candidateName = determinePrimaryCandidate(candidates, requiredType.toClass());
/* 1595 */       if (candidateName == null) {
/* 1596 */         candidateName = determineHighestPriorityCandidate(candidates, requiredType.toClass());
/*      */       }
/* 1598 */       if (candidateName == null) {
/* 1599 */         candidateName = determineDefaultCandidate(candidates);
/*      */       }
/* 1601 */       if (candidateName != null) {
/* 1602 */         Object beanInstance = candidates.get(candidateName);
/* 1603 */         if (beanInstance == null) {
/* 1604 */           return null;
/*      */         }
/* 1606 */         if (beanInstance instanceof Class) {
/* 1607 */           return resolveNamedBean(candidateName, requiredType, args);
/*      */         }
/* 1609 */         return new NamedBeanHolder(candidateName, beanInstance);
/*      */       } 
/* 1611 */       if (!nonUniqueAsNull) {
/* 1612 */         throw new NoUniqueBeanDefinitionException(requiredType, candidates.keySet());
/*      */       }
/*      */     } 
/*      */     
/* 1616 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private <T> NamedBeanHolder<T> resolveNamedBean(String beanName, ResolvableType requiredType, @Nullable Object[] args) throws BeansException {
/* 1623 */     Object bean = getBean(beanName, (Class<?>)null, args);
/* 1624 */     if (bean instanceof NullBean) {
/* 1625 */       return null;
/*      */     }
/* 1627 */     return new NamedBeanHolder(beanName, adaptBeanInstance(beanName, bean, requiredType.toClass()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object resolveDependency(DependencyDescriptor descriptor, @Nullable String requestingBeanName, @Nullable Set<String> autowiredBeanNames, @Nullable TypeConverter typeConverter) throws BeansException {
/* 1635 */     descriptor.initParameterNameDiscovery(getParameterNameDiscoverer());
/* 1636 */     if (Optional.class == descriptor.getDependencyType()) {
/* 1637 */       return createOptionalDependency(descriptor, requestingBeanName, new Object[0]);
/*      */     }
/* 1639 */     if (ObjectFactory.class == descriptor.getDependencyType() || ObjectProvider.class == descriptor
/* 1640 */       .getDependencyType()) {
/* 1641 */       return new DependencyObjectProvider(descriptor, requestingBeanName);
/*      */     }
/* 1643 */     if (jakartaInjectProviderClass == descriptor.getDependencyType()) {
/* 1644 */       return (new Jsr330Factory()).createDependencyProvider(descriptor, requestingBeanName);
/*      */     }
/* 1646 */     if (descriptor.supportsLazyResolution()) {
/* 1647 */       Object result = getAutowireCandidateResolver().getLazyResolutionProxyIfNecessary(descriptor, requestingBeanName);
/*      */       
/* 1649 */       if (result != null) {
/* 1650 */         return result;
/*      */       }
/*      */     } 
/* 1653 */     return doResolveDependency(descriptor, requestingBeanName, autowiredBeanNames, typeConverter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object doResolveDependency(DependencyDescriptor descriptor, @Nullable String beanName, @Nullable Set<String> autowiredBeanNames, @Nullable TypeConverter typeConverter) throws BeansException {
/* 1661 */     InjectionPoint previousInjectionPoint = ConstructorResolver.setCurrentInjectionPoint((InjectionPoint)descriptor);
/*      */     
/*      */     try {
/* 1664 */       Object autowiredBeanName, instanceCandidate, shortcut = descriptor.resolveShortcut((BeanFactory)this);
/* 1665 */       if (shortcut != null) {
/* 1666 */         return shortcut;
/*      */       }
/*      */       
/* 1669 */       Class<?> type = descriptor.getDependencyType();
/*      */ 
/*      */       
/* 1672 */       Object value = getAutowireCandidateResolver().getSuggestedValue(descriptor);
/* 1673 */       if (value != null) {
/* 1674 */         if (value instanceof String) { String strValue = (String)value;
/* 1675 */           String resolvedValue = resolveEmbeddedValue(strValue);
/*      */           
/* 1677 */           BeanDefinition bd = (beanName != null && containsBean(beanName)) ? getMergedBeanDefinition(beanName) : null;
/* 1678 */           value = evaluateBeanDefinitionString(resolvedValue, bd); }
/*      */         
/* 1680 */         TypeConverter converter = (typeConverter != null) ? typeConverter : getTypeConverter();
/*      */         try {
/* 1682 */           return converter.convertIfNecessary(value, type, descriptor.getTypeDescriptor());
/*      */         }
/* 1684 */         catch (UnsupportedOperationException ex) {
/*      */ 
/*      */ 
/*      */           
/* 1688 */           autowiredBeanName = (descriptor.getField() != null) ? converter.convertIfNecessary(value, type, descriptor.getField()) : converter.convertIfNecessary(value, type, descriptor.getMethodParameter());
/*      */           
/*      */           return autowiredBeanName;
/*      */         } 
/*      */       } 
/* 1693 */       if (descriptor.usesStandardBeanLookup()) {
/* 1694 */         String dependencyName = descriptor.getDependencyName();
/* 1695 */         if (dependencyName == null || !containsBean(dependencyName)) {
/* 1696 */           String suggestedName = getAutowireCandidateResolver().getSuggestedName(descriptor);
/* 1697 */           dependencyName = (suggestedName != null && containsBean(suggestedName)) ? suggestedName : null;
/*      */         } 
/* 1699 */         if (dependencyName != null) {
/* 1700 */           dependencyName = canonicalName(dependencyName);
/* 1701 */           if (isTypeMatch(dependencyName, type) && isAutowireCandidate(dependencyName, descriptor) && 
/* 1702 */             !isFallback(dependencyName) && !hasPrimaryConflict(dependencyName, type) && 
/* 1703 */             !isSelfReference(beanName, dependencyName)) {
/* 1704 */             if (autowiredBeanNames != null) {
/* 1705 */               autowiredBeanNames.add(dependencyName);
/*      */             }
/* 1707 */             boolean preExisting = containsSingleton(dependencyName);
/* 1708 */             Object dependencyBean = getBean(dependencyName);
/* 1709 */             if (preExisting && dependencyBean instanceof NullBean)
/*      */             {
/* 1711 */               dependencyBean = null;
/*      */             }
/* 1713 */             instanceCandidate = resolveInstance(dependencyBean, descriptor, type, dependencyName); return instanceCandidate;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1719 */       Object multipleBeans = resolveMultipleBeans(descriptor, beanName, autowiredBeanNames, typeConverter);
/* 1720 */       if (multipleBeans != null) {
/* 1721 */         return multipleBeans;
/*      */       }
/*      */       
/* 1724 */       Map<String, Object> matchingBeans = findAutowireCandidates(beanName, type, descriptor);
/* 1725 */       if (matchingBeans.isEmpty()) {
/*      */         
/* 1727 */         multipleBeans = resolveMultipleBeansFallback(descriptor, beanName, autowiredBeanNames, typeConverter);
/* 1728 */         if (multipleBeans != null) {
/* 1729 */           return multipleBeans;
/*      */         }
/*      */         
/* 1732 */         if (isRequired(descriptor)) {
/* 1733 */           raiseNoMatchingBeanFound(type, descriptor.getResolvableType(), descriptor);
/*      */         }
/* 1735 */         autowiredBeanName = null; return autowiredBeanName;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1742 */       if (matchingBeans.size() > 1) {
/* 1743 */         autowiredBeanName = determineAutowireCandidate(matchingBeans, descriptor);
/* 1744 */         if (autowiredBeanName == null) {
/* 1745 */           if (isRequired(descriptor) || !indicatesArrayCollectionOrMap(type))
/*      */           {
/* 1747 */             return descriptor.resolveNotUnique(descriptor.getResolvableType(), matchingBeans);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1753 */           return null;
/*      */         } 
/*      */         
/* 1756 */         instanceCandidate = matchingBeans.get(autowiredBeanName);
/*      */       }
/*      */       else {
/*      */         
/* 1760 */         Map.Entry<String, Object> entry = matchingBeans.entrySet().iterator().next();
/* 1761 */         autowiredBeanName = entry.getKey();
/* 1762 */         instanceCandidate = entry.getValue();
/*      */       } 
/*      */ 
/*      */       
/* 1766 */       if (autowiredBeanNames != null) {
/* 1767 */         autowiredBeanNames.add(autowiredBeanName);
/*      */       }
/* 1769 */       if (instanceCandidate instanceof Class) {
/* 1770 */         instanceCandidate = descriptor.resolveCandidate((String)autowiredBeanName, type, (BeanFactory)this);
/*      */       }
/* 1772 */       return resolveInstance(instanceCandidate, descriptor, type, (String)autowiredBeanName);
/*      */     } finally {
/*      */       
/* 1775 */       ConstructorResolver.setCurrentInjectionPoint(previousInjectionPoint);
/*      */     } 
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Object resolveInstance(Object candidate, DependencyDescriptor descriptor, Class<?> type, String name) {
/* 1781 */     Object result = candidate;
/* 1782 */     if (result instanceof NullBean) {
/*      */       
/* 1784 */       if (isRequired(descriptor)) {
/* 1785 */         raiseNoMatchingBeanFound(type, descriptor.getResolvableType(), descriptor);
/*      */       }
/* 1787 */       result = null;
/*      */     } 
/* 1789 */     if (!ClassUtils.isAssignableValue(type, result)) {
/* 1790 */       throw new BeanNotOfRequiredTypeException(name, type, candidate.getClass());
/*      */     }
/* 1792 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object resolveMultipleBeans(DependencyDescriptor descriptor, @Nullable String beanName, @Nullable Set<String> autowiredBeanNames, @Nullable TypeConverter typeConverter) {
/* 1799 */     Class<?> type = descriptor.getDependencyType();
/*      */     
/* 1801 */     if (descriptor instanceof StreamDependencyDescriptor) { StreamDependencyDescriptor streamDependencyDescriptor = (StreamDependencyDescriptor)descriptor;
/* 1802 */       Map<String, Object> matchingBeans = findAutowireCandidates(beanName, type, descriptor);
/* 1803 */       if (autowiredBeanNames != null) {
/* 1804 */         autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */       }
/*      */ 
/*      */       
/* 1808 */       Stream<Object> stream = matchingBeans.keySet().stream().map(name -> descriptor.resolveCandidate(name, type, (BeanFactory)this)).filter(bean -> !(bean instanceof NullBean));
/* 1809 */       if (streamDependencyDescriptor.isOrdered()) {
/* 1810 */         stream = stream.sorted(adaptOrderComparator(matchingBeans));
/*      */       }
/* 1812 */       return stream; }
/*      */     
/* 1814 */     if (type.isArray()) {
/* 1815 */       Class<?> componentType = type.componentType();
/* 1816 */       ResolvableType resolvableType = descriptor.getResolvableType();
/* 1817 */       Class<?> resolvedArrayType = resolvableType.resolve(type);
/* 1818 */       if (resolvedArrayType != type) {
/* 1819 */         componentType = resolvableType.getComponentType().resolve();
/*      */       }
/* 1821 */       if (componentType == null) {
/* 1822 */         return null;
/*      */       }
/* 1824 */       Map<String, Object> matchingBeans = findAutowireCandidates(beanName, componentType, new MultiElementDescriptor(descriptor));
/*      */       
/* 1826 */       if (matchingBeans.isEmpty()) {
/* 1827 */         return null;
/*      */       }
/* 1829 */       if (autowiredBeanNames != null) {
/* 1830 */         autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */       }
/* 1832 */       TypeConverter converter = (typeConverter != null) ? typeConverter : getTypeConverter();
/* 1833 */       Object result = converter.convertIfNecessary(matchingBeans.values(), resolvedArrayType);
/* 1834 */       if (result instanceof Object[]) { Object[] array = (Object[])result; if (array.length > 1) {
/* 1835 */           Comparator<Object> comparator = adaptDependencyComparator(matchingBeans);
/* 1836 */           if (comparator != null)
/* 1837 */             Arrays.sort(array, comparator); 
/*      */         }  }
/*      */       
/* 1840 */       return result;
/*      */     } 
/* 1842 */     if (Collection.class == type || Set.class == type || List.class == type) {
/* 1843 */       return resolveMultipleBeanCollection(descriptor, beanName, autowiredBeanNames, typeConverter);
/*      */     }
/* 1845 */     if (Map.class == type) {
/* 1846 */       return resolveMultipleBeanMap(descriptor, beanName, autowiredBeanNames, typeConverter);
/*      */     }
/* 1848 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object resolveMultipleBeansFallback(DependencyDescriptor descriptor, @Nullable String beanName, @Nullable Set<String> autowiredBeanNames, @Nullable TypeConverter typeConverter) {
/* 1856 */     Class<?> type = descriptor.getDependencyType();
/*      */     
/* 1858 */     if (Collection.class.isAssignableFrom(type) && type.isInterface()) {
/* 1859 */       return resolveMultipleBeanCollection(descriptor, beanName, autowiredBeanNames, typeConverter);
/*      */     }
/* 1861 */     if (Map.class.isAssignableFrom(type) && type.isInterface()) {
/* 1862 */       return resolveMultipleBeanMap(descriptor, beanName, autowiredBeanNames, typeConverter);
/*      */     }
/* 1864 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object resolveMultipleBeanCollection(DependencyDescriptor descriptor, @Nullable String beanName, @Nullable Set<String> autowiredBeanNames, @Nullable TypeConverter typeConverter) {
/* 1871 */     Class<?> elementType = descriptor.getResolvableType().asCollection().resolveGeneric(new int[0]);
/* 1872 */     if (elementType == null) {
/* 1873 */       return null;
/*      */     }
/* 1875 */     Map<String, Object> matchingBeans = findAutowireCandidates(beanName, elementType, new MultiElementDescriptor(descriptor));
/*      */     
/* 1877 */     if (matchingBeans.isEmpty()) {
/* 1878 */       return null;
/*      */     }
/* 1880 */     if (autowiredBeanNames != null) {
/* 1881 */       autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */     }
/* 1883 */     TypeConverter converter = (typeConverter != null) ? typeConverter : getTypeConverter();
/* 1884 */     Object result = converter.convertIfNecessary(matchingBeans.values(), descriptor.getDependencyType());
/* 1885 */     if (result instanceof List) { List<?> list = (List)result; if (list.size() > 1) {
/* 1886 */         Comparator<Object> comparator = adaptDependencyComparator(matchingBeans);
/* 1887 */         if (comparator != null)
/* 1888 */           list.sort(comparator); 
/*      */       }  }
/*      */     
/* 1891 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object resolveMultipleBeanMap(DependencyDescriptor descriptor, @Nullable String beanName, @Nullable Set<String> autowiredBeanNames, @Nullable TypeConverter typeConverter) {
/* 1898 */     ResolvableType mapType = descriptor.getResolvableType().asMap();
/* 1899 */     Class<?> keyType = mapType.resolveGeneric(new int[] { 0 });
/* 1900 */     if (String.class != keyType) {
/* 1901 */       return null;
/*      */     }
/* 1903 */     Class<?> valueType = mapType.resolveGeneric(new int[] { 1 });
/* 1904 */     if (valueType == null) {
/* 1905 */       return null;
/*      */     }
/* 1907 */     Map<String, Object> matchingBeans = findAutowireCandidates(beanName, valueType, new MultiElementDescriptor(descriptor));
/*      */     
/* 1909 */     if (matchingBeans.isEmpty()) {
/* 1910 */       return null;
/*      */     }
/* 1912 */     if (autowiredBeanNames != null) {
/* 1913 */       autowiredBeanNames.addAll(matchingBeans.keySet());
/*      */     }
/* 1915 */     TypeConverter converter = (typeConverter != null) ? typeConverter : getTypeConverter();
/* 1916 */     return converter.convertIfNecessary(matchingBeans, descriptor.getDependencyType());
/*      */   }
/*      */   
/*      */   private boolean indicatesArrayCollectionOrMap(Class<?> type) {
/* 1920 */     return (type.isArray() || (type.isInterface() && (Collection.class
/* 1921 */       .isAssignableFrom(type) || Map.class.isAssignableFrom(type))));
/*      */   }
/*      */   
/*      */   private boolean isRequired(DependencyDescriptor descriptor) {
/* 1925 */     return getAutowireCandidateResolver().isRequired(descriptor);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private Comparator<Object> adaptDependencyComparator(Map<String, ?> matchingBeans) {
/* 1930 */     Comparator<Object> comparator = getDependencyComparator();
/* 1931 */     if (comparator instanceof OrderComparator) { OrderComparator orderComparator = (OrderComparator)comparator;
/* 1932 */       return orderComparator.withSourceProvider(
/* 1933 */           createFactoryAwareOrderSourceProvider(matchingBeans)); }
/*      */ 
/*      */     
/* 1936 */     return comparator;
/*      */   }
/*      */ 
/*      */   
/*      */   private Comparator<Object> adaptOrderComparator(Map<String, ?> matchingBeans) {
/* 1941 */     Comparator<Object> dependencyComparator = getDependencyComparator();
/* 1942 */     OrderComparator orderComparator = (OrderComparator)dependencyComparator;
/* 1943 */     OrderComparator comparator = (dependencyComparator instanceof OrderComparator) ? orderComparator : OrderComparator.INSTANCE;
/* 1944 */     return comparator.withSourceProvider(createFactoryAwareOrderSourceProvider(matchingBeans));
/*      */   }
/*      */   
/*      */   private OrderComparator.OrderSourceProvider createFactoryAwareOrderSourceProvider(Map<String, ?> beans) {
/* 1948 */     IdentityHashMap<Object, String> instancesToBeanNames = new IdentityHashMap<>();
/* 1949 */     beans.forEach((beanName, instance) -> instancesToBeanNames.put(instance, beanName));
/* 1950 */     return new FactoryAwareOrderSourceProvider(instancesToBeanNames);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, Object> findAutowireCandidates(@Nullable String beanName, Class<?> requiredType, DependencyDescriptor descriptor) {
/* 1969 */     String[] candidateNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this, requiredType, true, descriptor
/* 1970 */         .isEager());
/* 1971 */     Map<String, Object> result = CollectionUtils.newLinkedHashMap(candidateNames.length);
/* 1972 */     for (Map.Entry<Class<?>, Object> classObjectEntry : this.resolvableDependencies.entrySet()) {
/* 1973 */       Class<?> autowiringType = classObjectEntry.getKey();
/* 1974 */       if (autowiringType.isAssignableFrom(requiredType)) {
/* 1975 */         Object autowiringValue = classObjectEntry.getValue();
/* 1976 */         autowiringValue = AutowireUtils.resolveAutowiringValue(autowiringValue, requiredType);
/* 1977 */         if (requiredType.isInstance(autowiringValue)) {
/* 1978 */           result.put(ObjectUtils.identityToString(autowiringValue), autowiringValue);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1983 */     for (String candidate : candidateNames) {
/* 1984 */       if (!isSelfReference(beanName, candidate) && isAutowireCandidate(candidate, descriptor)) {
/* 1985 */         addCandidateEntry(result, candidate, descriptor, requiredType);
/*      */       }
/*      */     } 
/* 1988 */     if (result.isEmpty()) {
/* 1989 */       boolean multiple = indicatesArrayCollectionOrMap(requiredType);
/*      */       
/* 1991 */       DependencyDescriptor fallbackDescriptor = descriptor.forFallbackMatch();
/* 1992 */       for (String candidate : candidateNames) {
/* 1993 */         if (!isSelfReference(beanName, candidate) && isAutowireCandidate(candidate, fallbackDescriptor) && (!multiple || 
/* 1994 */           getAutowireCandidateResolver().hasQualifier(descriptor))) {
/* 1995 */           addCandidateEntry(result, candidate, descriptor, requiredType);
/*      */         }
/*      */       } 
/* 1998 */       if (result.isEmpty() && !multiple)
/*      */       {
/*      */         
/* 2001 */         for (String candidate : candidateNames) {
/* 2002 */           if (isSelfReference(beanName, candidate) && (!(descriptor instanceof MultiElementDescriptor) || 
/* 2003 */             !beanName.equals(candidate)) && 
/* 2004 */             isAutowireCandidate(candidate, fallbackDescriptor)) {
/* 2005 */             addCandidateEntry(result, candidate, descriptor, requiredType);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 2010 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addCandidateEntry(Map<String, Object> candidates, String candidateName, DependencyDescriptor descriptor, Class<?> requiredType) {
/* 2020 */     if (descriptor instanceof MultiElementDescriptor) {
/* 2021 */       Object beanInstance = descriptor.resolveCandidate(candidateName, requiredType, (BeanFactory)this);
/* 2022 */       if (!(beanInstance instanceof NullBean)) {
/* 2023 */         candidates.put(candidateName, beanInstance);
/*      */       }
/*      */     } else {
/* 2026 */       if (!containsSingleton(candidateName)) { if (descriptor instanceof StreamDependencyDescriptor) {
/* 2027 */           StreamDependencyDescriptor streamDescriptor = (StreamDependencyDescriptor)descriptor; if (streamDescriptor.isOrdered()) {
/* 2028 */             Object beanInstance = descriptor.resolveCandidate(candidateName, requiredType, (BeanFactory)this);
/*      */           }
/*      */         } 
/*      */         
/* 2032 */         candidates.put(candidateName, getType(candidateName));
/*      */         return; }
/*      */       
/*      */       Object object = descriptor.resolveCandidate(candidateName, requiredType, (BeanFactory)this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected String determineAutowireCandidate(Map<String, Object> candidates, DependencyDescriptor descriptor) {
/* 2046 */     Class<?> requiredType = descriptor.getDependencyType();
/*      */     
/* 2048 */     String primaryCandidate = determinePrimaryCandidate(candidates, requiredType);
/* 2049 */     if (primaryCandidate != null) {
/* 2050 */       return primaryCandidate;
/*      */     }
/*      */     
/* 2053 */     String dependencyName = descriptor.getDependencyName();
/* 2054 */     if (dependencyName != null) {
/* 2055 */       for (String beanName : candidates.keySet()) {
/* 2056 */         if (matchesBeanName(beanName, dependencyName)) {
/* 2057 */           return beanName;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 2062 */     String suggestedName = getAutowireCandidateResolver().getSuggestedName(descriptor);
/* 2063 */     if (suggestedName != null) {
/* 2064 */       for (String beanName : candidates.keySet()) {
/* 2065 */         if (matchesBeanName(beanName, suggestedName)) {
/* 2066 */           return beanName;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 2071 */     String priorityCandidate = determineHighestPriorityCandidate(candidates, requiredType);
/* 2072 */     if (priorityCandidate != null) {
/* 2073 */       return priorityCandidate;
/*      */     }
/*      */     
/* 2076 */     String defaultCandidate = determineDefaultCandidate(candidates);
/* 2077 */     if (defaultCandidate != null) {
/* 2078 */       return defaultCandidate;
/*      */     }
/*      */     
/* 2081 */     for (Map.Entry<String, Object> entry : candidates.entrySet()) {
/* 2082 */       String candidateName = entry.getKey();
/* 2083 */       Object beanInstance = entry.getValue();
/* 2084 */       if (beanInstance != null && this.resolvableDependencies.containsValue(beanInstance)) {
/* 2085 */         return candidateName;
/*      */       }
/*      */     } 
/* 2088 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected String determinePrimaryCandidate(Map<String, Object> candidates, Class<?> requiredType) {
/* 2101 */     String primaryBeanName = null;
/*      */     
/* 2103 */     for (Map.Entry<String, Object> entry : candidates.entrySet()) {
/* 2104 */       String candidateBeanName = entry.getKey();
/* 2105 */       Object beanInstance = entry.getValue();
/* 2106 */       if (isPrimary(candidateBeanName, beanInstance)) {
/* 2107 */         if (primaryBeanName != null) {
/* 2108 */           boolean candidateLocal = containsBeanDefinition(candidateBeanName);
/* 2109 */           boolean primaryLocal = containsBeanDefinition(primaryBeanName);
/* 2110 */           if (candidateLocal == primaryLocal) {
/* 2111 */             String message = "more than one 'primary' bean found among candidates: " + String.valueOf(candidates.keySet());
/* 2112 */             this.logger.trace(message);
/* 2113 */             throw new NoUniqueBeanDefinitionException(requiredType, candidates.size(), message);
/*      */           } 
/* 2115 */           if (candidateLocal) {
/* 2116 */             primaryBeanName = candidateBeanName;
/*      */           }
/*      */           continue;
/*      */         } 
/* 2120 */         primaryBeanName = candidateBeanName;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2125 */     if (primaryBeanName == null) {
/* 2126 */       for (String candidateBeanName : candidates.keySet()) {
/* 2127 */         if (!isFallback(candidateBeanName)) {
/* 2128 */           if (primaryBeanName != null) {
/* 2129 */             return null;
/*      */           }
/* 2131 */           primaryBeanName = candidateBeanName;
/*      */         } 
/*      */       } 
/*      */     }
/* 2135 */     return primaryBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected String determineHighestPriorityCandidate(Map<String, Object> candidates, Class<?> requiredType) {
/* 2154 */     String highestPriorityBeanName = null;
/* 2155 */     Integer highestPriority = null;
/* 2156 */     boolean highestPriorityConflictDetected = false;
/* 2157 */     for (Map.Entry<String, Object> entry : candidates.entrySet()) {
/* 2158 */       String candidateBeanName = entry.getKey();
/* 2159 */       Object beanInstance = entry.getValue();
/* 2160 */       if (beanInstance != null) {
/* 2161 */         Integer candidatePriority = getPriority(beanInstance);
/* 2162 */         if (candidatePriority != null) {
/* 2163 */           if (highestPriority != null) {
/* 2164 */             if (candidatePriority.equals(highestPriority)) {
/* 2165 */               highestPriorityConflictDetected = true; continue;
/*      */             } 
/* 2167 */             if (candidatePriority.intValue() < highestPriority.intValue()) {
/* 2168 */               highestPriorityBeanName = candidateBeanName;
/* 2169 */               highestPriority = candidatePriority;
/* 2170 */               highestPriorityConflictDetected = false;
/*      */             } 
/*      */             continue;
/*      */           } 
/* 2174 */           highestPriorityBeanName = candidateBeanName;
/* 2175 */           highestPriority = candidatePriority;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2181 */     if (highestPriorityConflictDetected) {
/* 2182 */       throw new NoUniqueBeanDefinitionException(requiredType, candidates.size(), "Multiple beans found with the same highest priority (" + highestPriority + ") among candidates: " + 
/*      */           
/* 2184 */           String.valueOf(candidates.keySet()));
/*      */     }
/*      */     
/* 2187 */     return highestPriorityBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isPrimary(String beanName, Object beanInstance) {
/* 2198 */     String transformedBeanName = transformedBeanName(beanName);
/* 2199 */     if (containsBeanDefinition(transformedBeanName)) {
/* 2200 */       return getMergedLocalBeanDefinition(transformedBeanName).isPrimary();
/*      */     }
/* 2202 */     BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory parent = (DefaultListableBeanFactory)beanFactory; if (parent
/* 2203 */         .isPrimary(transformedBeanName, beanInstance)); }
/*      */     
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isFallback(String beanName) {
/* 2213 */     String transformedBeanName = transformedBeanName(beanName);
/* 2214 */     if (containsBeanDefinition(transformedBeanName)) {
/* 2215 */       return getMergedLocalBeanDefinition(transformedBeanName).isFallback();
/*      */     }
/* 2217 */     BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory parent = (DefaultListableBeanFactory)beanFactory; if (parent
/* 2218 */         .isFallback(transformedBeanName)); }
/*      */     
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Integer getPriority(Object beanInstance) {
/* 2235 */     Comparator<Object> comparator = getDependencyComparator();
/* 2236 */     if (comparator instanceof OrderComparator) { OrderComparator orderComparator = (OrderComparator)comparator;
/* 2237 */       return orderComparator.getPriority(beanInstance); }
/*      */     
/* 2239 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private String determineDefaultCandidate(Map<String, Object> candidates) {
/* 2252 */     String defaultBeanName = null;
/* 2253 */     for (String candidateBeanName : candidates.keySet()) {
/* 2254 */       if (AutowireUtils.isDefaultCandidate(this, candidateBeanName)) {
/* 2255 */         if (defaultBeanName != null) {
/* 2256 */           return null;
/*      */         }
/* 2258 */         defaultBeanName = candidateBeanName;
/*      */       } 
/*      */     } 
/* 2261 */     return defaultBeanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean matchesBeanName(String beanName, @Nullable String candidateName) {
/* 2269 */     return (candidateName != null && (candidateName
/* 2270 */       .equals(beanName) || ObjectUtils.containsElement((Object[])getAliases(beanName), candidateName)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Contract("null, _ -> false; _, null -> false;")
/*      */   private boolean isSelfReference(@Nullable String beanName, @Nullable String candidateName) {
/* 2280 */     return (beanName != null && candidateName != null && (beanName
/* 2281 */       .equals(candidateName) || (containsBeanDefinition(candidateName) && beanName
/* 2282 */       .equals(getMergedLocalBeanDefinition(candidateName).getFactoryBeanName()))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasPrimaryConflict(String beanName, Class<?> dependencyType) {
/* 2290 */     for (Map.Entry<String, Class<?>> candidate : this.primaryBeanNamesWithType.entrySet()) {
/* 2291 */       String candidateName = candidate.getKey();
/* 2292 */       Class<?> candidateType = candidate.getValue();
/* 2293 */       if (!candidateName.equals(beanName) && ((candidateType != Void.class) ? dependencyType
/* 2294 */         .isAssignableFrom(candidateType) : 
/* 2295 */         isTypeMatch(candidateName, dependencyType))) {
/* 2296 */         return true;
/*      */       }
/*      */     } 
/* 2299 */     BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory parent = (DefaultListableBeanFactory)beanFactory; if (parent
/* 2300 */         .hasPrimaryConflict(beanName, dependencyType)); }
/*      */     
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void raiseNoMatchingBeanFound(Class<?> type, ResolvableType resolvableType, DependencyDescriptor descriptor) throws BeansException {
/* 2310 */     checkBeanNotOfRequiredType(type, descriptor);
/*      */     
/* 2312 */     throw new NoSuchBeanDefinitionException(resolvableType, "expected at least 1 bean which qualifies as autowire candidate. Dependency annotations: " + 
/*      */         
/* 2314 */         ObjectUtils.nullSafeToString(descriptor.getAnnotations()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkBeanNotOfRequiredType(Class<?> type, DependencyDescriptor descriptor) {
/* 2322 */     for (String beanName : this.beanDefinitionNames) {
/*      */       try {
/* 2324 */         RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/* 2325 */         Class<?> targetType = mbd.getTargetType();
/* 2326 */         if (targetType != null && type.isAssignableFrom(targetType) && 
/* 2327 */           isAutowireCandidate(beanName, mbd, descriptor, getAutowireCandidateResolver()))
/*      */         {
/* 2329 */           Object beanInstance = getSingleton(beanName, false);
/*      */           
/* 2331 */           Class<?> beanType = (beanInstance != null && beanInstance.getClass() != NullBean.class) ? beanInstance.getClass() : predictBeanType(beanName, mbd, new Class[0]);
/* 2332 */           if (beanType != null && !type.isAssignableFrom(beanType)) {
/* 2333 */             throw new BeanNotOfRequiredTypeException(beanName, type, beanType);
/*      */           }
/*      */         }
/*      */       
/* 2337 */       } catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2342 */     BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory parent = (DefaultListableBeanFactory)beanFactory;
/* 2343 */       parent.checkBeanNotOfRequiredType(type, descriptor); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Optional<?> createOptionalDependency(DependencyDescriptor descriptor, @Nullable String beanName, Object... args) {
/* 2353 */     DependencyDescriptor descriptorToUse = new NestedDependencyDescriptor(descriptor)
/*      */       {
/*      */         public boolean isRequired() {
/* 2356 */           return false;
/*      */         }
/*      */         
/*      */         public Object resolveCandidate(String beanName, Class<?> requiredType, BeanFactory beanFactory) {
/* 2360 */           return !ObjectUtils.isEmpty(args) ? beanFactory.getBean(beanName, args) : 
/* 2361 */             super.resolveCandidate(beanName, requiredType, beanFactory);
/*      */         }
/*      */         
/*      */         public boolean usesStandardBeanLookup() {
/* 2365 */           return ObjectUtils.isEmpty(args);
/*      */         }
/*      */       };
/* 2368 */     Object result = doResolveDependency(descriptorToUse, beanName, (Set<String>)null, (TypeConverter)null);
/* 2369 */     Optional<?> optional = (Optional)result; return (result instanceof Optional) ? optional : Optional.ofNullable(result);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2375 */     StringBuilder sb = new StringBuilder(ObjectUtils.identityToString(this));
/* 2376 */     sb.append(": defining beans [");
/* 2377 */     sb.append(StringUtils.collectionToCommaDelimitedString(this.beanDefinitionNames));
/* 2378 */     sb.append("]; ");
/* 2379 */     BeanFactory parent = getParentBeanFactory();
/* 2380 */     if (parent == null) {
/* 2381 */       sb.append("root of factory hierarchy");
/*      */     } else {
/*      */       
/* 2384 */       sb.append("parent: ").append(ObjectUtils.identityToString(parent));
/*      */     } 
/* 2386 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 2396 */     throw new NotSerializableException("DefaultListableBeanFactory itself is not deserializable - just a SerializedBeanFactoryReference is");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object writeReplace() throws ObjectStreamException {
/* 2402 */     if (this.serializationId != null) {
/* 2403 */       return new SerializedBeanFactoryReference(this.serializationId);
/*      */     }
/*      */     
/* 2406 */     throw new NotSerializableException("DefaultListableBeanFactory has no serialization id");
/*      */   }
/*      */ 
/*      */   
/*      */   public DefaultListableBeanFactory() {}
/*      */ 
/*      */   
/*      */   private static class SerializedBeanFactoryReference
/*      */     implements Serializable
/*      */   {
/*      */     private final String id;
/*      */ 
/*      */     
/*      */     public SerializedBeanFactoryReference(String id) {
/* 2420 */       this.id = id;
/*      */     }
/*      */     
/*      */     private Object readResolve() {
/* 2424 */       Reference<?> ref = DefaultListableBeanFactory.serializableFactories.get(this.id);
/* 2425 */       if (ref != null) {
/* 2426 */         Object result = ref.get();
/* 2427 */         if (result != null) {
/* 2428 */           return result;
/*      */         }
/*      */       } 
/*      */       
/* 2432 */       DefaultListableBeanFactory dummyFactory = new DefaultListableBeanFactory();
/* 2433 */       dummyFactory.serializationId = this.id;
/* 2434 */       return dummyFactory;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NestedDependencyDescriptor
/*      */     extends DependencyDescriptor
/*      */   {
/*      */     public NestedDependencyDescriptor(DependencyDescriptor original) {
/* 2445 */       super(original);
/* 2446 */       increaseNestingLevel();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean usesStandardBeanLookup() {
/* 2451 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class MultiElementDescriptor
/*      */     extends NestedDependencyDescriptor
/*      */   {
/*      */     public MultiElementDescriptor(DependencyDescriptor original) {
/* 2462 */       super(original);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class StreamDependencyDescriptor
/*      */     extends DependencyDescriptor
/*      */   {
/*      */     private final boolean ordered;
/*      */ 
/*      */     
/*      */     public StreamDependencyDescriptor(DependencyDescriptor original, boolean ordered) {
/* 2475 */       super(original);
/* 2476 */       this.ordered = ordered;
/*      */     }
/*      */     
/*      */     public boolean isOrdered() {
/* 2480 */       return this.ordered;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class DependencyObjectProvider
/*      */     implements BeanObjectProvider<Object>
/*      */   {
/*      */     private final DependencyDescriptor descriptor;
/*      */ 
/*      */     
/*      */     private final boolean optional;
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     private final String beanName;
/*      */ 
/*      */ 
/*      */     
/*      */     public DependencyObjectProvider(@Nullable DependencyDescriptor descriptor, String beanName) {
/* 2502 */       this.descriptor = new DefaultListableBeanFactory.NestedDependencyDescriptor(descriptor);
/* 2503 */       this.optional = (this.descriptor.getDependencyType() == Optional.class);
/* 2504 */       this.beanName = beanName;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getObject() throws BeansException {
/* 2509 */       if (this.optional) {
/* 2510 */         return DefaultListableBeanFactory.this.createOptionalDependency(this.descriptor, this.beanName, new Object[0]);
/*      */       }
/*      */       
/* 2513 */       Object result = DefaultListableBeanFactory.this.doResolveDependency(this.descriptor, this.beanName, (Set<String>)null, (TypeConverter)null);
/* 2514 */       if (result == null) {
/* 2515 */         throw new NoSuchBeanDefinitionException(this.descriptor.getResolvableType());
/*      */       }
/* 2517 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getObject(Object... args) throws BeansException {
/* 2523 */       if (this.optional) {
/* 2524 */         return DefaultListableBeanFactory.this.createOptionalDependency(this.descriptor, this.beanName, args);
/*      */       }
/*      */       
/* 2527 */       DependencyDescriptor descriptorToUse = new DependencyDescriptor(this.descriptor)
/*      */         {
/*      */           public Object resolveCandidate(String beanName, Class<?> requiredType, BeanFactory beanFactory) {
/* 2530 */             return beanFactory.getBean(beanName, args);
/*      */           }
/*      */         };
/* 2533 */       Object result = DefaultListableBeanFactory.this.doResolveDependency(descriptorToUse, this.beanName, (Set<String>)null, (TypeConverter)null);
/* 2534 */       if (result == null) {
/* 2535 */         throw new NoSuchBeanDefinitionException(this.descriptor.getResolvableType());
/*      */       }
/* 2537 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object getIfAvailable() throws BeansException {
/*      */       try {
/* 2545 */         if (this.optional) {
/* 2546 */           return DefaultListableBeanFactory.this.createOptionalDependency(this.descriptor, this.beanName, new Object[0]);
/*      */         }
/*      */         
/* 2549 */         DependencyDescriptor descriptorToUse = new DependencyDescriptor(this.descriptor)
/*      */           {
/*      */             public boolean isRequired() {
/* 2552 */               return false;
/*      */             }
/*      */             
/*      */             public boolean usesStandardBeanLookup() {
/* 2556 */               return true;
/*      */             }
/*      */           };
/* 2559 */         return DefaultListableBeanFactory.this.doResolveDependency(descriptorToUse, this.beanName, (Set<String>)null, (TypeConverter)null);
/*      */       
/*      */       }
/* 2562 */       catch (ScopeNotActiveException ex) {
/*      */         
/* 2564 */         return null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void ifAvailable(Consumer<Object> dependencyConsumer) throws BeansException {
/* 2570 */       Object dependency = getIfAvailable();
/* 2571 */       if (dependency != null) {
/*      */         try {
/* 2573 */           dependencyConsumer.accept(dependency);
/*      */         }
/* 2575 */         catch (ScopeNotActiveException scopeNotActiveException) {}
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object getIfUnique() throws BeansException {
/* 2584 */       DependencyDescriptor descriptorToUse = new DependencyDescriptor(this.descriptor)
/*      */         {
/*      */           public boolean isRequired() {
/* 2587 */             return false;
/*      */           }
/*      */           
/*      */           public boolean usesStandardBeanLookup() {
/* 2591 */             return true;
/*      */           }
/*      */           
/*      */           @Nullable
/*      */           public Object resolveNotUnique(ResolvableType type, Map<String, Object> matchingBeans) {
/* 2596 */             return null;
/*      */           }
/*      */         };
/*      */       try {
/* 2600 */         if (this.optional) {
/* 2601 */           return DefaultListableBeanFactory.this.createOptionalDependency(descriptorToUse, this.beanName, new Object[0]);
/*      */         }
/*      */         
/* 2604 */         return DefaultListableBeanFactory.this.doResolveDependency(descriptorToUse, this.beanName, (Set<String>)null, (TypeConverter)null);
/*      */       
/*      */       }
/* 2607 */       catch (ScopeNotActiveException ex) {
/*      */         
/* 2609 */         return null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void ifUnique(Consumer<Object> dependencyConsumer) throws BeansException {
/* 2615 */       Object dependency = getIfUnique();
/* 2616 */       if (dependency != null) {
/*      */         try {
/* 2618 */           dependencyConsumer.accept(dependency);
/*      */         }
/* 2620 */         catch (ScopeNotActiveException scopeNotActiveException) {}
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     protected Object getValue() throws BeansException {
/* 2628 */       if (this.optional) {
/* 2629 */         return DefaultListableBeanFactory.this.createOptionalDependency(this.descriptor, this.beanName, new Object[0]);
/*      */       }
/*      */       
/* 2632 */       return DefaultListableBeanFactory.this.doResolveDependency(this.descriptor, this.beanName, (Set<String>)null, (TypeConverter)null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Stream<Object> stream() {
/* 2638 */       return resolveStream(false);
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<Object> orderedStream() {
/* 2643 */       return resolveStream(true);
/*      */     }
/*      */ 
/*      */     
/*      */     private Stream<Object> resolveStream(boolean ordered) {
/* 2648 */       DependencyDescriptor descriptorToUse = new DefaultListableBeanFactory.StreamDependencyDescriptor(this.descriptor, ordered);
/* 2649 */       Object result = DefaultListableBeanFactory.this.doResolveDependency(descriptorToUse, this.beanName, (Set<String>)null, (TypeConverter)null);
/* 2650 */       Stream<Object> stream = (Stream)result; return (result instanceof Stream) ? stream : Stream.<Object>of(result);
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<Object> stream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/* 2655 */       return Arrays.<String>stream(DefaultListableBeanFactory.this.beanNamesForStream(this.descriptor.getResolvableType(), includeNonSingletons, true))
/* 2656 */         .filter(name -> AutowireUtils.isAutowireCandidate(DefaultListableBeanFactory.this, name))
/* 2657 */         .filter(name -> customFilter.test(DefaultListableBeanFactory.this.getType(name)))
/* 2658 */         .map(name -> DefaultListableBeanFactory.this.getBean(name))
/* 2659 */         .filter(bean -> !(bean instanceof NullBean));
/*      */     }
/*      */ 
/*      */     
/*      */     public Stream<Object> orderedStream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/* 2664 */       String[] beanNames = DefaultListableBeanFactory.this.beanNamesForStream(this.descriptor.getResolvableType(), includeNonSingletons, true);
/* 2665 */       if (beanNames.length == 0) {
/* 2666 */         return Stream.empty();
/*      */       }
/* 2668 */       Map<String, Object> matchingBeans = CollectionUtils.newLinkedHashMap(beanNames.length);
/* 2669 */       for (String beanName : beanNames) {
/* 2670 */         if (AutowireUtils.isAutowireCandidate(DefaultListableBeanFactory.this, beanName) && customFilter
/* 2671 */           .test(DefaultListableBeanFactory.this.getType(beanName))) {
/* 2672 */           Object beanInstance = DefaultListableBeanFactory.this.getBean(beanName);
/* 2673 */           if (!(beanInstance instanceof NullBean)) {
/* 2674 */             matchingBeans.put(beanName, beanInstance);
/*      */           }
/*      */         } 
/*      */       } 
/* 2678 */       return matchingBeans.values().stream().sorted(DefaultListableBeanFactory.this.adaptOrderComparator(matchingBeans)); } }
/*      */   class null extends DependencyDescriptor {
/*      */     null(DependencyDescriptor original) { super(original); }
/*      */     public Object resolveCandidate(String beanName, Class<?> requiredType, BeanFactory beanFactory) { return beanFactory.getBean(beanName, args); }
/*      */   }
/*      */   class null extends DependencyDescriptor {
/*      */     null(DependencyDescriptor original) { super(original); }
/*      */     public boolean isRequired() { return false; }
/*      */     public boolean usesStandardBeanLookup() { return true; }
/*      */   }
/*      */   class null extends DependencyDescriptor {
/*      */     null(DependencyDescriptor original) { super(original); } public boolean isRequired() { return false; } public boolean usesStandardBeanLookup() { return true; } @Nullable
/*      */     public Object resolveNotUnique(ResolvableType type, Map<String, Object> matchingBeans) { return null; }
/* 2691 */   } private class Jsr330Factory implements Serializable { public Object createDependencyProvider(DependencyDescriptor descriptor, @Nullable String beanName) { return new Jsr330Provider(descriptor, beanName); }
/*      */ 
/*      */     
/*      */     private class Jsr330Provider
/*      */       extends DefaultListableBeanFactory.DependencyObjectProvider implements Provider<Object> {
/*      */       public Jsr330Provider(@Nullable DependencyDescriptor descriptor, String beanName) {
/* 2697 */         super(descriptor, beanName);
/*      */       }
/*      */ 
/*      */       
/*      */       @Nullable
/*      */       public Object get() throws BeansException {
/* 2703 */         return getValue(); } } } private class Jsr330Provider extends DependencyObjectProvider implements Provider<Object> { public Jsr330Provider(@Nullable DependencyDescriptor descriptor, String beanName) { super(descriptor, beanName); } @Nullable public Object get() throws BeansException { return getValue(); }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class FactoryAwareOrderSourceProvider
/*      */     implements OrderComparator.OrderSourceProvider
/*      */   {
/*      */     private final Map<Object, String> instancesToBeanNames;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FactoryAwareOrderSourceProvider(Map<Object, String> instancesToBeanNames) {
/* 2723 */       this.instancesToBeanNames = instancesToBeanNames;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object getOrderSource(Object obj) {
/* 2729 */       String beanName = this.instancesToBeanNames.get(obj);
/* 2730 */       if (beanName == null) {
/* 2731 */         return null;
/*      */       }
/*      */       try {
/* 2734 */         BeanDefinition beanDefinition = DefaultListableBeanFactory.this.getMergedBeanDefinition(beanName);
/* 2735 */         List<Object> sources = new ArrayList(3);
/* 2736 */         Object orderAttribute = beanDefinition.getAttribute("order");
/* 2737 */         if (orderAttribute != null) {
/* 2738 */           if (orderAttribute instanceof Integer) { Integer order = (Integer)orderAttribute;
/* 2739 */             sources.add(() -> order.intValue()); }
/*      */           else
/*      */           
/* 2742 */           { throw new IllegalStateException("Invalid value type for attribute 'order': " + orderAttribute
/* 2743 */                 .getClass().getName()); }
/*      */         
/*      */         }
/* 2746 */         if (beanDefinition instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDefinition = (RootBeanDefinition)beanDefinition;
/* 2747 */           Method factoryMethod = rootBeanDefinition.getResolvedFactoryMethod();
/* 2748 */           if (factoryMethod != null) {
/* 2749 */             sources.add(factoryMethod);
/*      */           }
/* 2751 */           Class<?> targetType = rootBeanDefinition.getTargetType();
/* 2752 */           if (targetType != null && targetType != obj.getClass()) {
/* 2753 */             sources.add(targetType);
/*      */           } }
/*      */         
/* 2756 */         return sources.toArray();
/*      */       }
/* 2758 */       catch (NoSuchBeanDefinitionException ex) {
/* 2759 */         return null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private enum PreInstantiation
/*      */   {
/* 2767 */     MAIN, BACKGROUND;
/*      */   }
/*      */   
/*      */   private static interface BeanObjectProvider<T> extends ObjectProvider<T>, Serializable {}
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\DefaultListableBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */