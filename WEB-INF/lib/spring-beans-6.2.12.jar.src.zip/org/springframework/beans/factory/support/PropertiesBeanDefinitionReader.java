/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.DefaultPropertiesPersister;
/*     */ import org.springframework.util.PropertiesPersister;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class PropertiesBeanDefinitionReader
/*     */   extends AbstractBeanDefinitionReader
/*     */ {
/*     */   public static final String TRUE_VALUE = "true";
/*     */   public static final String SEPARATOR = ".";
/*     */   public static final String CLASS_KEY = "(class)";
/*     */   public static final String PARENT_KEY = "(parent)";
/*     */   public static final String SCOPE_KEY = "(scope)";
/*     */   public static final String SINGLETON_KEY = "(singleton)";
/*     */   public static final String ABSTRACT_KEY = "(abstract)";
/*     */   public static final String LAZY_INIT_KEY = "(lazy-init)";
/*     */   public static final String REF_SUFFIX = "(ref)";
/*     */   public static final String REF_PREFIX = "*";
/*     */   public static final String CONSTRUCTOR_ARG_PREFIX = "$";
/*     */   @Nullable
/*     */   private String defaultParentBean;
/* 151 */   private PropertiesPersister propertiesPersister = (PropertiesPersister)DefaultPropertiesPersister.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesBeanDefinitionReader(BeanDefinitionRegistry registry) {
/* 160 */     super(registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultParentBean(@Nullable String defaultParentBean) {
/* 177 */     this.defaultParentBean = defaultParentBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getDefaultParentBean() {
/* 185 */     return this.defaultParentBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertiesPersister(@Nullable PropertiesPersister propertiesPersister) {
/* 194 */     this
/* 195 */       .propertiesPersister = (propertiesPersister != null) ? propertiesPersister : (PropertiesPersister)DefaultPropertiesPersister.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesPersister getPropertiesPersister() {
/* 202 */     return this.propertiesPersister;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(Resource resource) throws BeanDefinitionStoreException {
/* 216 */     return loadBeanDefinitions(new EncodedResource(resource), (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(Resource resource, @Nullable String prefix) throws BeanDefinitionStoreException {
/* 228 */     return loadBeanDefinitions(new EncodedResource(resource), prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource) throws BeanDefinitionStoreException {
/* 239 */     return loadBeanDefinitions(encodedResource, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource, @Nullable String prefix) throws BeanDefinitionStoreException {
/* 254 */     if (this.logger.isTraceEnabled()) {
/* 255 */       this.logger.trace("Loading properties bean definitions from " + String.valueOf(encodedResource));
/*     */     }
/*     */     
/* 258 */     Properties props = new Properties();
/*     */     try {
/* 260 */       InputStream is = encodedResource.getResource().getInputStream(); 
/* 261 */       try { if (encodedResource.getEncoding() != null) {
/* 262 */           getPropertiesPersister().load(props, new InputStreamReader(is, encodedResource.getEncoding()));
/*     */         } else {
/*     */           
/* 265 */           getPropertiesPersister().load(props, is);
/*     */         } 
/* 267 */         if (is != null) is.close();  } catch (Throwable throwable) { if (is != null)
/*     */           try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 269 */        int count = registerBeanDefinitions(props, prefix, encodedResource.getResource().getDescription());
/* 270 */       if (this.logger.isDebugEnabled()) {
/* 271 */         this.logger.debug("Loaded " + count + " bean definitions from " + String.valueOf(encodedResource));
/*     */       }
/* 273 */       return count;
/*     */     }
/* 275 */     catch (IOException ex) {
/* 276 */       throw new BeanDefinitionStoreException("Could not parse properties from " + String.valueOf(encodedResource.getResource()), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registerBeanDefinitions(ResourceBundle rb) throws BeanDefinitionStoreException {
/* 289 */     return registerBeanDefinitions(rb, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registerBeanDefinitions(ResourceBundle rb, @Nullable String prefix) throws BeanDefinitionStoreException {
/* 304 */     Map<String, Object> map = new HashMap<>();
/* 305 */     Enumeration<String> keys = rb.getKeys();
/* 306 */     while (keys.hasMoreElements()) {
/* 307 */       String key = keys.nextElement();
/* 308 */       map.put(key, rb.getObject(key));
/*     */     } 
/* 310 */     return registerBeanDefinitions(map, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registerBeanDefinitions(Map<?, ?> map) throws BeansException {
/* 325 */     return registerBeanDefinitions(map, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registerBeanDefinitions(Map<?, ?> map, @Nullable String prefix) throws BeansException {
/* 340 */     return registerBeanDefinitions(map, prefix, "Map " + String.valueOf(map));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registerBeanDefinitions(Map<?, ?> map, @Nullable String prefix, String resourceDescription) throws BeansException {
/* 360 */     if (prefix == null) {
/* 361 */       prefix = "";
/*     */     }
/* 363 */     int beanCount = 0;
/*     */     
/* 365 */     for (Object key : map.keySet()) {
/* 366 */       String keyString; if (key instanceof String) { keyString = (String)key; }
/* 367 */       else { throw new IllegalArgumentException("Illegal key [" + String.valueOf(key) + "]: only Strings allowed"); }
/*     */       
/* 369 */       if (keyString.startsWith(prefix)) {
/*     */         int sepIdx;
/* 371 */         String nameAndProperty = keyString.substring(prefix.length());
/*     */ 
/*     */         
/* 374 */         int propKeyIdx = nameAndProperty.indexOf("[");
/* 375 */         if (propKeyIdx != -1) {
/* 376 */           sepIdx = nameAndProperty.lastIndexOf(".", propKeyIdx);
/*     */         } else {
/*     */           
/* 379 */           sepIdx = nameAndProperty.lastIndexOf(".");
/*     */         } 
/* 381 */         if (sepIdx != -1) {
/* 382 */           String beanName = nameAndProperty.substring(0, sepIdx);
/* 383 */           if (this.logger.isTraceEnabled()) {
/* 384 */             this.logger.trace("Found bean name '" + beanName + "'");
/*     */           }
/* 386 */           if (!getRegistry().containsBeanDefinition(beanName)) {
/*     */             
/* 388 */             registerBeanDefinition(beanName, map, prefix + prefix, resourceDescription);
/* 389 */             beanCount++;
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 395 */         if (this.logger.isDebugEnabled()) {
/* 396 */           this.logger.debug("Invalid bean name and property [" + nameAndProperty + "]");
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 402 */     return beanCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerBeanDefinition(String beanName, Map<?, ?> map, String prefix, String resourceDescription) throws BeansException {
/* 418 */     String className = null;
/* 419 */     String parent = null;
/* 420 */     String scope = "singleton";
/* 421 */     boolean isAbstract = false;
/* 422 */     boolean lazyInit = false;
/*     */     
/* 424 */     ConstructorArgumentValues cas = new ConstructorArgumentValues();
/* 425 */     MutablePropertyValues pvs = new MutablePropertyValues();
/*     */     
/* 427 */     String prefixWithSep = prefix + ".";
/* 428 */     int beginIndex = prefixWithSep.length();
/*     */     
/* 430 */     for (Map.Entry<?, ?> entry : map.entrySet()) {
/* 431 */       String key = ((String)entry.getKey()).strip();
/* 432 */       if (key.startsWith(prefixWithSep)) {
/* 433 */         String property = key.substring(beginIndex);
/* 434 */         if ("(class)".equals(property)) {
/* 435 */           className = ((String)entry.getValue()).strip(); continue;
/*     */         } 
/* 437 */         if ("(parent)".equals(property)) {
/* 438 */           parent = ((String)entry.getValue()).strip(); continue;
/*     */         } 
/* 440 */         if ("(abstract)".equals(property)) {
/* 441 */           String val = ((String)entry.getValue()).strip();
/* 442 */           isAbstract = "true".equals(val); continue;
/*     */         } 
/* 444 */         if ("(scope)".equals(property)) {
/*     */           
/* 446 */           scope = ((String)entry.getValue()).strip(); continue;
/*     */         } 
/* 448 */         if ("(singleton)".equals(property)) {
/*     */           
/* 450 */           String val = ((String)entry.getValue()).strip();
/*     */           
/* 452 */           scope = (!StringUtils.hasLength(val) || "true".equals(val)) ? "singleton" : "prototype"; continue;
/*     */         } 
/* 454 */         if ("(lazy-init)".equals(property)) {
/* 455 */           String val = ((String)entry.getValue()).strip();
/* 456 */           lazyInit = "true".equals(val); continue;
/*     */         } 
/* 458 */         if (property.startsWith("$")) {
/* 459 */           if (property.endsWith("(ref)")) {
/* 460 */             int i = Integer.parseInt(property, 1, property.length() - "(ref)".length(), 10);
/* 461 */             cas.addIndexedArgumentValue(i, new RuntimeBeanReference(entry.getValue().toString()));
/*     */             continue;
/*     */           } 
/* 464 */           int index = Integer.parseInt(property, 1, property.length(), 10);
/* 465 */           cas.addIndexedArgumentValue(index, readValue(entry));
/*     */           continue;
/*     */         } 
/* 468 */         if (property.endsWith("(ref)")) {
/*     */ 
/*     */           
/* 471 */           property = property.substring(0, property.length() - "(ref)".length());
/* 472 */           String ref = ((String)entry.getValue()).strip();
/*     */ 
/*     */ 
/*     */           
/* 476 */           Object val = new RuntimeBeanReference(ref);
/* 477 */           pvs.add(property, val);
/*     */           
/*     */           continue;
/*     */         } 
/* 481 */         pvs.add(property, readValue(entry));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 486 */     if (this.logger.isTraceEnabled()) {
/* 487 */       this.logger.trace("Registering bean definition for bean name '" + beanName + "' with " + String.valueOf(pvs));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 493 */     if (parent == null && className == null && !beanName.equals(this.defaultParentBean)) {
/* 494 */       parent = this.defaultParentBean;
/*     */     }
/*     */     
/*     */     try {
/* 498 */       AbstractBeanDefinition bd = BeanDefinitionReaderUtils.createBeanDefinition(parent, className, 
/* 499 */           getBeanClassLoader());
/* 500 */       bd.setScope(scope);
/* 501 */       bd.setAbstract(isAbstract);
/* 502 */       bd.setLazyInit(lazyInit);
/* 503 */       bd.setConstructorArgumentValues(cas);
/* 504 */       bd.setPropertyValues(pvs);
/* 505 */       getRegistry().registerBeanDefinition(beanName, bd);
/*     */     }
/* 507 */     catch (ClassNotFoundException ex) {
/* 508 */       throw new CannotLoadBeanClassException(resourceDescription, beanName, className, ex);
/*     */     }
/* 510 */     catch (LinkageError err) {
/* 511 */       throw new CannotLoadBeanClassException(resourceDescription, beanName, className, err);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object readValue(Map.Entry<?, ?> entry) {
/* 520 */     Object val = entry.getValue();
/* 521 */     if (val instanceof String) { String strVal = (String)val;
/*     */       
/* 523 */       if (strVal.startsWith("*")) {
/*     */         
/* 525 */         String targetName = strVal.substring(1);
/* 526 */         if (targetName.startsWith("*")) {
/*     */           
/* 528 */           val = targetName;
/*     */         } else {
/*     */           
/* 531 */           val = new RuntimeBeanReference(targetName);
/*     */         } 
/*     */       }  }
/*     */     
/* 535 */     return val;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\PropertiesBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */