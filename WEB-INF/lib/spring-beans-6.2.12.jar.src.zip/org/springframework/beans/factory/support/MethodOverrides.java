/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodOverrides
/*     */ {
/*  39 */   private final Set<MethodOverride> overrides = new CopyOnWriteArraySet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodOverrides() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodOverrides(MethodOverrides other) {
/*  52 */     addOverrides(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOverrides(@Nullable MethodOverrides other) {
/*  60 */     if (other != null) {
/*  61 */       this.overrides.addAll(other.overrides);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOverride(MethodOverride override) {
/*  69 */     this.overrides.add(override);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<MethodOverride> getOverrides() {
/*  78 */     return this.overrides;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  85 */     return this.overrides.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MethodOverride getOverride(Method method) {
/*  95 */     MethodOverride match = null;
/*  96 */     for (MethodOverride candidate : this.overrides) {
/*  97 */       if (candidate.matches(method)) {
/*  98 */         match = candidate;
/*     */       }
/*     */     } 
/* 101 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 107 */     if (this != other) { if (other instanceof MethodOverrides) { MethodOverrides that = (MethodOverrides)other; if (this.overrides
/* 108 */           .equals(that.overrides)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 113 */     return this.overrides.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\MethodOverrides.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */