/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.config.NamedBeanHolder;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanNameReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanDefinitionValueResolver
/*     */ {
/*     */   private final AbstractAutowireCapableBeanFactory beanFactory;
/*     */   private final String beanName;
/*     */   private final BeanDefinition beanDefinition;
/*     */   private final TypeConverter typeConverter;
/*     */   
/*     */   public BeanDefinitionValueResolver(AbstractAutowireCapableBeanFactory beanFactory, String beanName, BeanDefinition beanDefinition, TypeConverter typeConverter) {
/*  87 */     this.beanFactory = beanFactory;
/*  88 */     this.beanName = beanName;
/*  89 */     this.beanDefinition = beanDefinition;
/*  90 */     this.typeConverter = typeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionValueResolver(AbstractAutowireCapableBeanFactory beanFactory, String beanName, BeanDefinition beanDefinition) {
/* 103 */     this.beanFactory = beanFactory;
/* 104 */     this.beanName = beanName;
/* 105 */     this.beanDefinition = beanDefinition;
/* 106 */     BeanWrapperImpl beanWrapperImpl = new BeanWrapperImpl();
/* 107 */     beanFactory.initBeanWrapper((BeanWrapper)beanWrapperImpl);
/* 108 */     this.typeConverter = (TypeConverter)beanWrapperImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveValueIfNecessary(Object argName, @Nullable Object value) {
/* 134 */     if (value instanceof RuntimeBeanReference) { RuntimeBeanReference ref = (RuntimeBeanReference)value;
/* 135 */       return resolveReference(argName, ref); }
/*     */     
/* 137 */     if (value instanceof RuntimeBeanNameReference) { RuntimeBeanNameReference ref = (RuntimeBeanNameReference)value;
/* 138 */       String refName = ref.getBeanName();
/* 139 */       refName = String.valueOf(doEvaluate(refName));
/* 140 */       if (!this.beanFactory.containsBean(refName)) {
/* 141 */         throw new BeanDefinitionStoreException("Invalid bean name '" + refName + "' in bean reference for " + String.valueOf(argName));
/*     */       }
/*     */       
/* 144 */       return refName; }
/*     */     
/* 146 */     if (value instanceof BeanDefinitionHolder) { BeanDefinitionHolder bdHolder = (BeanDefinitionHolder)value;
/*     */       
/* 148 */       return resolveInnerBean(bdHolder.getBeanName(), bdHolder.getBeanDefinition(), (name, mbd) -> resolveInnerBeanValue(argName, name, mbd)); }
/*     */ 
/*     */     
/* 151 */     if (value instanceof BeanDefinition) { BeanDefinition bd = (BeanDefinition)value;
/* 152 */       return resolveInnerBean(null, bd, (name, mbd) -> resolveInnerBeanValue(argName, name, mbd)); }
/*     */ 
/*     */     
/* 155 */     if (value instanceof DependencyDescriptor) { DependencyDescriptor dependencyDescriptor = (DependencyDescriptor)value;
/* 156 */       Set<String> autowiredBeanNames = new LinkedHashSet<>(2);
/* 157 */       Object result = this.beanFactory.resolveDependency(dependencyDescriptor, this.beanName, autowiredBeanNames, this.typeConverter);
/*     */       
/* 159 */       for (String autowiredBeanName : autowiredBeanNames) {
/* 160 */         if (this.beanFactory.containsBean(autowiredBeanName)) {
/* 161 */           this.beanFactory.registerDependentBean(autowiredBeanName, this.beanName);
/*     */         }
/*     */       } 
/* 164 */       return result; }
/*     */     
/* 166 */     if (value instanceof ManagedArray) { ManagedArray managedArray = (ManagedArray)value;
/*     */       
/* 168 */       Class<?> elementType = managedArray.resolvedElementType;
/* 169 */       if (elementType == null) {
/* 170 */         String elementTypeName = managedArray.getElementTypeName();
/* 171 */         if (StringUtils.hasText(elementTypeName)) {
/*     */           try {
/* 173 */             elementType = ClassUtils.forName(elementTypeName, this.beanFactory.getBeanClassLoader());
/* 174 */             managedArray.resolvedElementType = elementType;
/*     */           }
/* 176 */           catch (Throwable ex) {
/*     */             
/* 178 */             throw new BeanCreationException(this.beanDefinition
/* 179 */                 .getResourceDescription(), this.beanName, "Error resolving array type for " + String.valueOf(argName), ex);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 184 */           elementType = Object.class;
/*     */         } 
/*     */       } 
/* 187 */       return resolveManagedArray(argName, (List)value, elementType); }
/*     */     
/* 189 */     if (value instanceof ManagedList) { ManagedList<?> managedList = (ManagedList)value;
/*     */       
/* 191 */       return resolveManagedList(argName, managedList); }
/*     */     
/* 193 */     if (value instanceof ManagedSet) { ManagedSet<?> managedSet = (ManagedSet)value;
/*     */       
/* 195 */       return resolveManagedSet(argName, managedSet); }
/*     */     
/* 197 */     if (value instanceof ManagedMap) { ManagedMap<?, ?> managedMap = (ManagedMap<?, ?>)value;
/*     */       
/* 199 */       return resolveManagedMap(argName, managedMap); }
/*     */     
/* 201 */     if (value instanceof ManagedProperties) { ManagedProperties original = (ManagedProperties)value;
/*     */       
/* 203 */       Properties copy = new Properties();
/* 204 */       original.forEach((propKey, propValue) -> {
/*     */             if (propKey instanceof TypedStringValue) {
/*     */               TypedStringValue typedStringValue = (TypedStringValue)propKey;
/*     */               propKey = evaluate(typedStringValue);
/*     */             } 
/*     */             if (propValue instanceof TypedStringValue) {
/*     */               TypedStringValue typedStringValue = (TypedStringValue)propValue;
/*     */               propValue = evaluate(typedStringValue);
/*     */             } 
/*     */             if (propKey == null || propValue == null) {
/*     */               throw new BeanCreationException(this.beanDefinition.getResourceDescription(), this.beanName, "Error converting Properties key/value pair for " + String.valueOf(argName) + ": resolved to null");
/*     */             }
/*     */             copy.put(propKey, propValue);
/*     */           });
/* 218 */       return copy; }
/*     */     
/* 220 */     if (value instanceof TypedStringValue) { TypedStringValue typedStringValue = (TypedStringValue)value;
/*     */       
/* 222 */       Object valueObject = evaluate(typedStringValue);
/*     */       try {
/* 224 */         Class<?> resolvedTargetType = resolveTargetType(typedStringValue);
/* 225 */         if (resolvedTargetType != null) {
/* 226 */           return this.typeConverter.convertIfNecessary(valueObject, resolvedTargetType);
/*     */         }
/*     */         
/* 229 */         return valueObject;
/*     */       
/*     */       }
/* 232 */       catch (Throwable ex) {
/*     */         
/* 234 */         throw new BeanCreationException(this.beanDefinition
/* 235 */             .getResourceDescription(), this.beanName, "Error converting typed String value for " + String.valueOf(argName), ex);
/*     */       }  }
/*     */ 
/*     */     
/* 239 */     if (value instanceof NullBean) {
/* 240 */       return null;
/*     */     }
/*     */     
/* 243 */     return evaluate(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T resolveInnerBean(@Nullable String innerBeanName, BeanDefinition innerBd, BiFunction<String, RootBeanDefinition, T> resolver) {
/* 261 */     String nameToUse = (innerBeanName != null) ? innerBeanName : ("(inner bean)#" + ObjectUtils.getIdentityHexString(innerBd));
/* 262 */     return resolver.apply(nameToUse, this.beanFactory
/* 263 */         .getMergedBeanDefinition(nameToUse, innerBd, this.beanDefinition));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object evaluate(TypedStringValue value) {
/* 273 */     Object result = doEvaluate(value.getValue());
/* 274 */     if (!ObjectUtils.nullSafeEquals(result, value.getValue())) {
/* 275 */       value.setDynamic();
/*     */     }
/* 277 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object evaluate(@Nullable Object value) {
/* 287 */     if (value instanceof String) { String str = (String)value;
/* 288 */       return doEvaluate(str); }
/*     */     
/* 290 */     if (value instanceof String[]) { String[] values = (String[])value;
/* 291 */       boolean actuallyResolved = false;
/* 292 */       Object[] resolvedValues = new Object[values.length];
/* 293 */       for (int i = 0; i < values.length; i++) {
/* 294 */         String originalValue = values[i];
/* 295 */         Object resolvedValue = doEvaluate(originalValue);
/* 296 */         if (resolvedValue != originalValue) {
/* 297 */           actuallyResolved = true;
/*     */         }
/* 299 */         resolvedValues[i] = resolvedValue;
/*     */       } 
/* 301 */       return actuallyResolved ? resolvedValues : values; }
/*     */ 
/*     */     
/* 304 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object doEvaluate(@Nullable String value) {
/* 315 */     return this.beanFactory.evaluateBeanDefinitionString(value, this.beanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?> resolveTargetType(TypedStringValue value) throws ClassNotFoundException {
/* 327 */     if (value.hasTargetType()) {
/* 328 */       return value.getTargetType();
/*     */     }
/* 330 */     return value.resolveTargetType(this.beanFactory.getBeanClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object resolveReference(Object argName, RuntimeBeanReference ref) {
/*     */     try {
/*     */       Object bean;
/* 340 */       Class<?> beanType = ref.getBeanType();
/* 341 */       if (ref.isToParent()) {
/* 342 */         BeanFactory parent = this.beanFactory.getParentBeanFactory();
/* 343 */         if (parent == null) {
/* 344 */           throw new BeanCreationException(this.beanDefinition
/* 345 */               .getResourceDescription(), this.beanName, "Cannot resolve reference to bean " + String.valueOf(ref) + " in parent factory: no parent factory available");
/*     */         }
/*     */ 
/*     */         
/* 349 */         if (beanType != null) {
/* 350 */           bean = parent.getBean(beanType);
/*     */         } else {
/*     */           
/* 353 */           bean = parent.getBean(String.valueOf(doEvaluate(ref.getBeanName())));
/*     */         } 
/*     */       } else {
/*     */         String resolvedName;
/*     */         
/* 358 */         if (beanType != null) {
/* 359 */           NamedBeanHolder<?> namedBean = this.beanFactory.resolveNamedBean(beanType);
/* 360 */           bean = namedBean.getBeanInstance();
/* 361 */           resolvedName = namedBean.getBeanName();
/*     */         } else {
/*     */           
/* 364 */           resolvedName = String.valueOf(doEvaluate(ref.getBeanName()));
/* 365 */           bean = this.beanFactory.getBean(resolvedName);
/*     */         } 
/* 367 */         this.beanFactory.registerDependentBean(resolvedName, this.beanName);
/*     */       } 
/* 369 */       if (bean instanceof NullBean) {
/* 370 */         bean = null;
/*     */       }
/* 372 */       return bean;
/*     */     }
/* 374 */     catch (BeansException ex) {
/* 375 */       throw new BeanCreationException(this.beanDefinition
/* 376 */           .getResourceDescription(), this.beanName, "Cannot resolve reference to bean '" + ref
/* 377 */           .getBeanName() + "' while setting " + String.valueOf(argName), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object resolveInnerBeanValue(Object argName, String innerBeanName, RootBeanDefinition mbd) {
/*     */     try {
/* 393 */       String actualInnerBeanName = innerBeanName;
/* 394 */       if (mbd.isSingleton()) {
/* 395 */         actualInnerBeanName = adaptInnerBeanName(innerBeanName);
/*     */       }
/* 397 */       this.beanFactory.registerContainedBean(actualInnerBeanName, this.beanName);
/*     */       
/* 399 */       String[] dependsOn = mbd.getDependsOn();
/* 400 */       if (dependsOn != null) {
/* 401 */         for (String dependsOnBean : dependsOn) {
/* 402 */           this.beanFactory.registerDependentBean(dependsOnBean, actualInnerBeanName);
/* 403 */           this.beanFactory.getBean(dependsOnBean);
/*     */         } 
/*     */       }
/*     */       
/* 407 */       Object innerBean = this.beanFactory.createBean(actualInnerBeanName, mbd, (Object[])null);
/* 408 */       if (innerBean instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)innerBean;
/* 409 */         boolean synthetic = mbd.isSynthetic();
/* 410 */         innerBean = this.beanFactory.getObjectFromFactoryBean(factoryBean, actualInnerBeanName, !synthetic); }
/*     */       
/* 412 */       if (innerBean instanceof NullBean) {
/* 413 */         innerBean = null;
/*     */       }
/* 415 */       return innerBean;
/*     */     }
/* 417 */     catch (BeansException ex) {
/* 418 */       throw new BeanCreationException(this.beanDefinition
/* 419 */           .getResourceDescription(), this.beanName, "Cannot create inner bean '" + innerBeanName + "' " + (
/*     */           
/* 421 */           (mbd.getBeanClassName() != null) ? ("of type [" + mbd.getBeanClassName() + "] ") : "") + "while setting " + String.valueOf(argName), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String adaptInnerBeanName(String innerBeanName) {
/* 433 */     String actualInnerBeanName = innerBeanName;
/* 434 */     int counter = 0;
/* 435 */     String prefix = innerBeanName + "#";
/* 436 */     while (this.beanFactory.isBeanNameInUse(actualInnerBeanName)) {
/* 437 */       counter++;
/* 438 */       actualInnerBeanName = prefix + prefix;
/*     */     } 
/* 440 */     return actualInnerBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object resolveManagedArray(Object argName, List<?> ml, Class<?> elementType) {
/* 447 */     Object resolved = Array.newInstance(elementType, ml.size());
/* 448 */     for (int i = 0; i < ml.size(); i++) {
/* 449 */       Array.set(resolved, i, resolveValueIfNecessary(new KeyedArgName(argName, Integer.valueOf(i)), ml.get(i)));
/*     */     }
/* 451 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<?> resolveManagedList(Object argName, List<?> ml) {
/* 458 */     List<Object> resolved = new ArrayList(ml.size());
/* 459 */     for (int i = 0; i < ml.size(); i++) {
/* 460 */       resolved.add(resolveValueIfNecessary(new KeyedArgName(argName, Integer.valueOf(i)), ml.get(i)));
/*     */     }
/* 462 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<?> resolveManagedSet(Object argName, Set<?> ms) {
/* 469 */     Set<Object> resolved = CollectionUtils.newLinkedHashSet(ms.size());
/* 470 */     int i = 0;
/* 471 */     for (Object m : ms) {
/* 472 */       resolved.add(resolveValueIfNecessary(new KeyedArgName(argName, Integer.valueOf(i)), m));
/* 473 */       i++;
/*     */     } 
/* 475 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<?, ?> resolveManagedMap(Object argName, Map<?, ?> mm) {
/* 482 */     Map<Object, Object> resolved = CollectionUtils.newLinkedHashMap(mm.size());
/* 483 */     mm.forEach((key, value) -> {
/*     */           Object resolvedKey = resolveValueIfNecessary(argName, key);
/*     */           Object resolvedValue = resolveValueIfNecessary(new KeyedArgName(argName, key), value);
/*     */           resolved.put(resolvedKey, resolvedValue);
/*     */         });
/* 488 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KeyedArgName
/*     */   {
/*     */     private final Object argName;
/*     */ 
/*     */     
/*     */     private final Object key;
/*     */ 
/*     */     
/*     */     public KeyedArgName(Object argName, Object key) {
/* 502 */       this.argName = argName;
/* 503 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 508 */       return String.valueOf(this.argName) + " with key [" + String.valueOf(this.argName) + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\BeanDefinitionValueResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */