/*      */ package org.springframework.beans.factory.support;
/*      */ 
/*      */ import java.beans.PropertyEditor;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.UnaryOperator;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeanWrapper;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.PropertyEditorRegistrar;
/*      */ import org.springframework.beans.PropertyEditorRegistry;
/*      */ import org.springframework.beans.PropertyEditorRegistrySupport;
/*      */ import org.springframework.beans.SimpleTypeConverter;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.TypeMismatchException;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*      */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanIsAbstractException;
/*      */ import org.springframework.beans.factory.BeanIsNotAFactoryException;
/*      */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*      */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*      */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*      */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.Scope;
/*      */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.core.AttributeAccessor;
/*      */ import org.springframework.core.DecoratingClassLoader;
/*      */ import org.springframework.core.NamedThreadLocal;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.core.log.LogMessage;
/*      */ import org.springframework.core.metrics.ApplicationStartup;
/*      */ import org.springframework.core.metrics.StartupStep;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.StringValueResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractBeanFactory
/*      */   extends FactoryBeanRegistrySupport
/*      */   implements ConfigurableBeanFactory
/*      */ {
/*      */   @Nullable
/*      */   private BeanFactory parentBeanFactory;
/*      */   @Nullable
/*  123 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private ClassLoader tempClassLoader;
/*      */ 
/*      */   
/*      */   private boolean cacheBeanMetadata = true;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private BeanExpressionResolver beanExpressionResolver;
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private ConversionService conversionService;
/*      */ 
/*      */   
/*  141 */   private final Set<PropertyEditorRegistrar> defaultEditorRegistrars = new LinkedHashSet<>(4);
/*      */ 
/*      */   
/*  144 */   private final Set<PropertyEditorRegistrar> propertyEditorRegistrars = new LinkedHashSet<>(4);
/*      */ 
/*      */   
/*  147 */   private final Map<Class<?>, Class<? extends PropertyEditor>> customEditors = new HashMap<>(4);
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private TypeConverter typeConverter;
/*      */ 
/*      */   
/*  154 */   private final List<StringValueResolver> embeddedValueResolvers = new CopyOnWriteArrayList<>();
/*      */ 
/*      */   
/*  157 */   private final List<BeanPostProcessor> beanPostProcessors = new BeanPostProcessorCacheAwareList();
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private BeanPostProcessorCache beanPostProcessorCache;
/*      */ 
/*      */   
/*  164 */   private final Map<String, Scope> scopes = new LinkedHashMap<>(8);
/*      */ 
/*      */   
/*  167 */   private ApplicationStartup applicationStartup = ApplicationStartup.DEFAULT;
/*      */ 
/*      */   
/*  170 */   private final Map<String, RootBeanDefinition> mergedBeanDefinitions = new ConcurrentHashMap<>(256);
/*      */ 
/*      */   
/*  173 */   private final Set<String> alreadyCreated = ConcurrentHashMap.newKeySet(256);
/*      */ 
/*      */   
/*  176 */   private final ThreadLocal<Object> prototypesCurrentlyInCreation = (ThreadLocal<Object>)new NamedThreadLocal("Prototype beans currently in creation");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractBeanFactory(@Nullable BeanFactory parentBeanFactory) {
/*  192 */     this.parentBeanFactory = parentBeanFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getBean(String name) throws BeansException {
/*  202 */     return doGetBean(name, (Class<?>)null, (Object[])null, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException {
/*  207 */     return doGetBean(name, requiredType, (Object[])null, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getBean(String name, Object... args) throws BeansException {
/*  212 */     return doGetBean(name, (Class<?>)null, args, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getBean(String name, @Nullable Class<T> requiredType, @Nullable Object... args) throws BeansException {
/*  227 */     return doGetBean(name, requiredType, args, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> T doGetBean(String name, @Nullable Class<T> requiredType, @Nullable Object[] args, boolean typeCheckOnly) throws BeansException {
/*      */     Object beanInstance;
/*  246 */     String beanName = transformedBeanName(name);
/*      */ 
/*      */ 
/*      */     
/*  250 */     Object sharedInstance = getSingleton(beanName);
/*  251 */     if (sharedInstance != null && args == null) {
/*  252 */       if (this.logger.isTraceEnabled()) {
/*  253 */         if (isSingletonCurrentlyInCreation(beanName)) {
/*  254 */           this.logger.trace("Returning eagerly cached instance of singleton bean '" + beanName + "' that is not fully initialized yet - a consequence of a circular reference");
/*      */         }
/*      */         else {
/*      */           
/*  258 */           this.logger.trace("Returning cached instance of singleton bean '" + beanName + "'");
/*      */         } 
/*      */       }
/*  261 */       beanInstance = getObjectForBeanInstance(sharedInstance, name, beanName, (RootBeanDefinition)null);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  267 */       if (isPrototypeCurrentlyInCreation(beanName)) {
/*  268 */         throw new BeanCurrentlyInCreationException(beanName);
/*      */       }
/*      */ 
/*      */       
/*  272 */       BeanFactory parentBeanFactory = getParentBeanFactory();
/*  273 */       if (parentBeanFactory != null && !containsBeanDefinition(beanName)) {
/*      */         
/*  275 */         String nameToLookup = originalBeanName(name);
/*  276 */         if (parentBeanFactory instanceof AbstractBeanFactory) { AbstractBeanFactory abf = (AbstractBeanFactory)parentBeanFactory;
/*  277 */           return abf.doGetBean(nameToLookup, requiredType, args, typeCheckOnly); }
/*      */         
/*  279 */         if (args != null)
/*      */         {
/*  281 */           return (T)parentBeanFactory.getBean(nameToLookup, args);
/*      */         }
/*  283 */         if (requiredType != null)
/*      */         {
/*  285 */           return (T)parentBeanFactory.getBean(nameToLookup, requiredType);
/*      */         }
/*      */         
/*  288 */         return (T)parentBeanFactory.getBean(nameToLookup);
/*      */       } 
/*      */ 
/*      */       
/*  292 */       if (!typeCheckOnly) {
/*  293 */         markBeanAsCreated(beanName);
/*      */       }
/*      */ 
/*      */       
/*  297 */       StartupStep beanCreation = this.applicationStartup.start("spring.beans.instantiate").tag("beanName", name);
/*      */       try {
/*  299 */         if (requiredType != null) {
/*  300 */           Objects.requireNonNull(requiredType); beanCreation.tag("beanType", requiredType::toString);
/*      */         } 
/*  302 */         RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*  303 */         checkMergedBeanDefinition(mbd, beanName, args);
/*      */ 
/*      */         
/*  306 */         String[] dependsOn = mbd.getDependsOn();
/*  307 */         if (dependsOn != null) {
/*  308 */           for (String dep : dependsOn) {
/*  309 */             if (isDependent(beanName, dep)) {
/*  310 */               throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Circular depends-on relationship between '" + beanName + "' and '" + dep + "'");
/*      */             }
/*      */             
/*  313 */             registerDependentBean(dep, beanName);
/*      */             try {
/*  315 */               getBean(dep);
/*      */             }
/*  317 */             catch (NoSuchBeanDefinitionException ex) {
/*  318 */               throw new BeanCreationException(mbd.getResourceDescription(), beanName, "'" + beanName + "' depends on missing bean '" + dep + "'", ex);
/*      */             
/*      */             }
/*  321 */             catch (BeanCreationException ex) {
/*  322 */               if (requiredType != null)
/*      */               {
/*      */                 
/*  325 */                 throw new BeanCreationException(mbd.getResourceDescription(), beanName, "Failed to initialize dependency '" + ex
/*  326 */                     .getBeanName() + "' of " + requiredType
/*  327 */                     .getSimpleName() + " bean '" + beanName + "': " + ex
/*  328 */                     .getMessage(), ex);
/*      */               }
/*  330 */               throw ex;
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  336 */         if (mbd.isSingleton()) {
/*  337 */           sharedInstance = getSingleton(beanName, () -> {
/*      */                 
/*      */                 try {
/*      */                   return createBean(beanName, mbd, args);
/*  341 */                 } catch (BeansException ex) {
/*      */                   destroySingleton(beanName);
/*      */ 
/*      */                   
/*      */                   throw ex;
/*      */                 } 
/*      */               });
/*      */           
/*  349 */           beanInstance = getObjectForBeanInstance(sharedInstance, name, beanName, mbd);
/*      */         
/*      */         }
/*  352 */         else if (mbd.isPrototype()) {
/*      */           
/*  354 */           Object prototypeInstance = null;
/*      */           try {
/*  356 */             beforePrototypeCreation(beanName);
/*  357 */             prototypeInstance = createBean(beanName, mbd, args);
/*      */           } finally {
/*      */             
/*  360 */             afterPrototypeCreation(beanName);
/*      */           } 
/*  362 */           beanInstance = getObjectForBeanInstance(prototypeInstance, name, beanName, mbd);
/*      */         }
/*      */         else {
/*      */           
/*  366 */           String scopeName = mbd.getScope();
/*  367 */           if (!StringUtils.hasLength(scopeName)) {
/*  368 */             throw new IllegalStateException("No scope name defined for bean '" + beanName + "'");
/*      */           }
/*  370 */           Scope scope = this.scopes.get(scopeName);
/*  371 */           if (scope == null) {
/*  372 */             throw new IllegalStateException("No Scope registered for scope name '" + scopeName + "'");
/*      */           }
/*      */           try {
/*  375 */             Object scopedInstance = scope.get(beanName, () -> {
/*      */                   beforePrototypeCreation(beanName);
/*      */                   
/*      */                   try {
/*      */                     return createBean(beanName, mbd, args);
/*      */                   } finally {
/*      */                     afterPrototypeCreation(beanName);
/*      */                   } 
/*      */                 });
/*  384 */             beanInstance = getObjectForBeanInstance(scopedInstance, name, beanName, mbd);
/*      */           }
/*  386 */           catch (IllegalStateException ex) {
/*  387 */             throw new ScopeNotActiveException(beanName, scopeName, ex);
/*      */           }
/*      */         
/*      */         } 
/*  391 */       } catch (BeansException ex) {
/*  392 */         beanCreation.tag("exception", ex.getClass().toString());
/*  393 */         beanCreation.tag("message", String.valueOf(ex.getMessage()));
/*  394 */         cleanupAfterBeanCreationFailure(beanName);
/*  395 */         throw ex;
/*      */       } finally {
/*      */         
/*  398 */         beanCreation.end();
/*  399 */         if (!isCacheBeanMetadata()) {
/*  400 */           clearMergedBeanDefinition(beanName);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  405 */     return adaptBeanInstance(name, beanInstance, requiredType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   <T> T adaptBeanInstance(String name, Object bean, @Nullable Class<?> requiredType) {
/*  411 */     if (requiredType != null && !requiredType.isInstance(bean)) {
/*      */       try {
/*  413 */         Object convertedBean = getTypeConverter().convertIfNecessary(bean, requiredType);
/*  414 */         if (convertedBean == null) {
/*  415 */           throw new BeanNotOfRequiredTypeException(name, requiredType, bean.getClass());
/*      */         }
/*  417 */         return (T)convertedBean;
/*      */       }
/*  419 */       catch (TypeMismatchException ex) {
/*  420 */         if (this.logger.isTraceEnabled()) {
/*  421 */           this.logger.trace("Failed to convert bean '" + name + "' to required type '" + 
/*  422 */               ClassUtils.getQualifiedName(requiredType) + "'", (Throwable)ex);
/*      */         }
/*  424 */         throw new BeanNotOfRequiredTypeException(name, requiredType, bean.getClass());
/*      */       } 
/*      */     }
/*  427 */     return (T)bean;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsBean(String name) {
/*  432 */     String beanName = transformedBeanName(name);
/*  433 */     if (containsSingleton(beanName) || containsBeanDefinition(beanName)) {
/*  434 */       return (!BeanFactoryUtils.isFactoryDereference(name) || isFactoryBean(name));
/*      */     }
/*      */     
/*  437 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  438 */     return (parentBeanFactory != null && parentBeanFactory.containsBean(originalBeanName(name)));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
/*  443 */     String beanName = transformedBeanName(name);
/*      */     
/*  445 */     Object beanInstance = getSingleton(beanName, false);
/*  446 */     if (beanInstance != null) {
/*  447 */       if (beanInstance instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)beanInstance;
/*  448 */         return (BeanFactoryUtils.isFactoryDereference(name) || factoryBean.isSingleton()); }
/*      */ 
/*      */       
/*  451 */       return !BeanFactoryUtils.isFactoryDereference(name);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  456 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  457 */     if (parentBeanFactory != null && !containsBeanDefinition(beanName))
/*      */     {
/*  459 */       return parentBeanFactory.isSingleton(originalBeanName(name));
/*      */     }
/*      */     
/*  462 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*      */ 
/*      */     
/*  465 */     if (mbd.isSingleton()) {
/*  466 */       if (isFactoryBean(beanName, mbd)) {
/*  467 */         if (BeanFactoryUtils.isFactoryDereference(name)) {
/*  468 */           return true;
/*      */         }
/*  470 */         FactoryBean<?> factoryBean = (FactoryBean)getBean("&" + beanName);
/*  471 */         return factoryBean.isSingleton();
/*      */       } 
/*      */       
/*  474 */       return !BeanFactoryUtils.isFactoryDereference(name);
/*      */     } 
/*      */ 
/*      */     
/*  478 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_1
/*      */     //   2: invokevirtual transformedBeanName : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   5: astore_2
/*      */     //   6: aload_0
/*      */     //   7: invokevirtual getParentBeanFactory : ()Lorg/springframework/beans/factory/BeanFactory;
/*      */     //   10: astore_3
/*      */     //   11: aload_3
/*      */     //   12: ifnull -> 35
/*      */     //   15: aload_0
/*      */     //   16: aload_2
/*      */     //   17: invokevirtual containsBeanDefinition : (Ljava/lang/String;)Z
/*      */     //   20: ifne -> 35
/*      */     //   23: aload_3
/*      */     //   24: aload_0
/*      */     //   25: aload_1
/*      */     //   26: invokevirtual originalBeanName : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   29: invokeinterface isPrototype : (Ljava/lang/String;)Z
/*      */     //   34: ireturn
/*      */     //   35: aload_0
/*      */     //   36: aload_2
/*      */     //   37: invokevirtual getMergedLocalBeanDefinition : (Ljava/lang/String;)Lorg/springframework/beans/factory/support/RootBeanDefinition;
/*      */     //   40: astore #4
/*      */     //   42: aload #4
/*      */     //   44: invokevirtual isPrototype : ()Z
/*      */     //   47: ifeq -> 73
/*      */     //   50: aload_1
/*      */     //   51: invokestatic isFactoryDereference : (Ljava/lang/String;)Z
/*      */     //   54: ifeq -> 67
/*      */     //   57: aload_0
/*      */     //   58: aload_2
/*      */     //   59: aload #4
/*      */     //   61: invokevirtual isFactoryBean : (Ljava/lang/String;Lorg/springframework/beans/factory/support/RootBeanDefinition;)Z
/*      */     //   64: ifeq -> 71
/*      */     //   67: iconst_1
/*      */     //   68: goto -> 72
/*      */     //   71: iconst_0
/*      */     //   72: ireturn
/*      */     //   73: aload_1
/*      */     //   74: invokestatic isFactoryDereference : (Ljava/lang/String;)Z
/*      */     //   77: ifeq -> 82
/*      */     //   80: iconst_0
/*      */     //   81: ireturn
/*      */     //   82: aload_0
/*      */     //   83: aload_2
/*      */     //   84: aload #4
/*      */     //   86: invokevirtual isFactoryBean : (Ljava/lang/String;Lorg/springframework/beans/factory/support/RootBeanDefinition;)Z
/*      */     //   89: ifeq -> 148
/*      */     //   92: aload_0
/*      */     //   93: aload_2
/*      */     //   94: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   99: invokevirtual getBean : (Ljava/lang/String;)Ljava/lang/Object;
/*      */     //   102: checkcast org/springframework/beans/factory/FactoryBean
/*      */     //   105: astore #5
/*      */     //   107: aload #5
/*      */     //   109: instanceof org/springframework/beans/factory/SmartFactoryBean
/*      */     //   112: ifeq -> 132
/*      */     //   115: aload #5
/*      */     //   117: checkcast org/springframework/beans/factory/SmartFactoryBean
/*      */     //   120: astore #6
/*      */     //   122: aload #6
/*      */     //   124: invokeinterface isPrototype : ()Z
/*      */     //   129: ifne -> 142
/*      */     //   132: aload #5
/*      */     //   134: invokeinterface isSingleton : ()Z
/*      */     //   139: ifne -> 146
/*      */     //   142: iconst_1
/*      */     //   143: goto -> 147
/*      */     //   146: iconst_0
/*      */     //   147: ireturn
/*      */     //   148: iconst_0
/*      */     //   149: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #484	-> 0
/*      */     //   #486	-> 6
/*      */     //   #487	-> 11
/*      */     //   #489	-> 23
/*      */     //   #492	-> 35
/*      */     //   #493	-> 42
/*      */     //   #495	-> 50
/*      */     //   #500	-> 73
/*      */     //   #501	-> 80
/*      */     //   #503	-> 82
/*      */     //   #504	-> 92
/*      */     //   #505	-> 107
/*      */     //   #506	-> 134
/*      */     //   #505	-> 147
/*      */     //   #509	-> 148
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   122	10	6	smartFactoryBean	Lorg/springframework/beans/factory/SmartFactoryBean;
/*      */     //   107	41	5	fb	Lorg/springframework/beans/factory/FactoryBean;
/*      */     //   0	150	0	this	Lorg/springframework/beans/factory/support/AbstractBeanFactory;
/*      */     //   0	150	1	name	Ljava/lang/String;
/*      */     //   6	144	2	beanName	Ljava/lang/String;
/*      */     //   11	139	3	parentBeanFactory	Lorg/springframework/beans/factory/BeanFactory;
/*      */     //   42	108	4	mbd	Lorg/springframework/beans/factory/support/RootBeanDefinition;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   122	10	6	smartFactoryBean	Lorg/springframework/beans/factory/SmartFactoryBean<*>;
/*      */     //   107	41	5	fb	Lorg/springframework/beans/factory/FactoryBean<*>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTypeMatch(String name, ResolvableType typeToMatch) throws NoSuchBeanDefinitionException {
/*  515 */     return isTypeMatch(name, typeToMatch, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isTypeMatch(String name, ResolvableType typeToMatch, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/*  534 */     String beanName = transformedBeanName(name);
/*  535 */     boolean isFactoryDereference = BeanFactoryUtils.isFactoryDereference(name);
/*      */ 
/*      */     
/*  538 */     Object beanInstance = getSingleton(beanName, false);
/*  539 */     if (beanInstance != null && beanInstance.getClass() != NullBean.class) {
/*      */ 
/*      */       
/*  542 */       if (beanInstance instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)beanInstance;
/*  543 */         if (!isFactoryDereference) {
/*  544 */           Class<?> type = getTypeForFactoryBean(factoryBean);
/*  545 */           if (type == null) {
/*  546 */             return false;
/*      */           }
/*  548 */           if (typeToMatch.isAssignableFrom(type)) {
/*  549 */             return true;
/*      */           }
/*  551 */           if (typeToMatch.hasGenerics() && containsBeanDefinition(beanName)) {
/*  552 */             RootBeanDefinition rootBeanDefinition = getMergedLocalBeanDefinition(beanName);
/*  553 */             ResolvableType targetType = rootBeanDefinition.targetType;
/*  554 */             if (targetType == null) {
/*  555 */               targetType = rootBeanDefinition.factoryMethodReturnType;
/*      */             }
/*  557 */             if (targetType == null) {
/*  558 */               return false;
/*      */             }
/*  560 */             Class<?> targetClass = targetType.resolve();
/*  561 */             if (targetClass != null && FactoryBean.class.isAssignableFrom(targetClass)) {
/*  562 */               Class<?> clazz = typeToMatch.resolve();
/*  563 */               if (clazz != null && !FactoryBean.class.isAssignableFrom(clazz) && 
/*  564 */                 !clazz.isAssignableFrom(targetType.toClass())) {
/*  565 */                 return typeToMatch.isAssignableFrom(targetType.getGeneric(new int[0]));
/*      */               }
/*      */             } else {
/*      */               
/*  569 */               return typeToMatch.isAssignableFrom(targetType);
/*      */             } 
/*      */           } 
/*  572 */           return false;
/*      */         }
/*      */          }
/*  575 */       else if (isFactoryDereference)
/*  576 */       { return false; }
/*      */ 
/*      */ 
/*      */       
/*  580 */       if (typeToMatch.isInstance(beanInstance))
/*      */       {
/*  582 */         return true;
/*      */       }
/*  584 */       if (typeToMatch.hasGenerics() && containsBeanDefinition(beanName)) {
/*      */         
/*  586 */         RootBeanDefinition rootBeanDefinition = getMergedLocalBeanDefinition(beanName);
/*  587 */         Class<?> targetType = rootBeanDefinition.getTargetType();
/*  588 */         if (targetType != null && targetType != ClassUtils.getUserClass(beanInstance)) {
/*      */           
/*  590 */           Class<?> clazz = typeToMatch.resolve();
/*  591 */           if (clazz != null && !clazz.isInstance(beanInstance)) {
/*  592 */             return false;
/*      */           }
/*  594 */           if (typeToMatch.isAssignableFrom(targetType)) {
/*  595 */             return true;
/*      */           }
/*      */         } 
/*  598 */         ResolvableType resolvableType = rootBeanDefinition.targetType;
/*  599 */         if (resolvableType == null) {
/*  600 */           resolvableType = rootBeanDefinition.factoryMethodReturnType;
/*      */         }
/*  602 */         return (resolvableType != null && typeToMatch.isAssignableFrom(resolvableType));
/*      */       } 
/*      */       
/*  605 */       return false;
/*      */     } 
/*      */     
/*  608 */     if (containsSingleton(beanName) && !containsBeanDefinition(beanName))
/*      */     {
/*  610 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  614 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  615 */     if (parentBeanFactory != null && !containsBeanDefinition(beanName))
/*      */     {
/*  617 */       return parentBeanFactory.isTypeMatch(originalBeanName(name), typeToMatch);
/*      */     }
/*      */ 
/*      */     
/*  621 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*  622 */     BeanDefinitionHolder dbd = mbd.getDecoratedDefinition();
/*      */ 
/*      */     
/*  625 */     Class<?> classToMatch = typeToMatch.resolve();
/*  626 */     if (classToMatch == null) {
/*  627 */       classToMatch = FactoryBean.class;
/*      */     }
/*      */     
/*  630 */     (new Class[1])[0] = classToMatch; (new Class[2])[0] = FactoryBean.class; (new Class[2])[1] = classToMatch; Class<?>[] typesToMatch = (FactoryBean.class == classToMatch) ? new Class[1] : new Class[2];
/*      */ 
/*      */     
/*  633 */     Class<?> predictedType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  638 */     if (!isFactoryDereference && dbd != null && isFactoryBean(beanName, mbd))
/*      */     {
/*      */       
/*  641 */       if (!mbd.isLazyInit() || allowFactoryBeanInit) {
/*  642 */         RootBeanDefinition tbd = getMergedBeanDefinition(dbd.getBeanName(), dbd.getBeanDefinition(), mbd);
/*  643 */         Class<?> targetType = predictBeanType(dbd.getBeanName(), tbd, typesToMatch);
/*  644 */         if (targetType != null && !FactoryBean.class.isAssignableFrom(targetType)) {
/*  645 */           predictedType = targetType;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  651 */     if (predictedType == null) {
/*  652 */       predictedType = predictBeanType(beanName, mbd, typesToMatch);
/*  653 */       if (predictedType == null) {
/*  654 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  659 */     ResolvableType beanType = null;
/*      */ 
/*      */     
/*  662 */     if (FactoryBean.class.isAssignableFrom(predictedType)) {
/*  663 */       if (beanInstance == null && !isFactoryDereference) {
/*  664 */         beanType = getTypeForFactoryBean(beanName, mbd, allowFactoryBeanInit);
/*  665 */         predictedType = beanType.resolve();
/*  666 */         if (predictedType == null) {
/*  667 */           return false;
/*      */         }
/*      */       }
/*      */     
/*  671 */     } else if (isFactoryDereference) {
/*      */ 
/*      */ 
/*      */       
/*  675 */       predictedType = predictBeanType(beanName, mbd, new Class[] { FactoryBean.class });
/*  676 */       if (predictedType == null || !FactoryBean.class.isAssignableFrom(predictedType)) {
/*  677 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  683 */     if (beanType == null) {
/*  684 */       ResolvableType definedType = mbd.targetType;
/*  685 */       if (definedType == null) {
/*  686 */         definedType = mbd.factoryMethodReturnType;
/*      */       }
/*  688 */       if (definedType != null && definedType.resolve() == predictedType) {
/*  689 */         beanType = definedType;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  694 */     if (beanType != null) {
/*  695 */       return typeToMatch.isAssignableFrom(beanType);
/*      */     }
/*      */ 
/*      */     
/*  699 */     return typeToMatch.isAssignableFrom(predictedType);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTypeMatch(String name, Class<?> typeToMatch) throws NoSuchBeanDefinitionException {
/*  704 */     return isTypeMatch(name, ResolvableType.forRawClass(typeToMatch));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException {
/*  710 */     return getType(name, true);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Class<?> getType(String name, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException {
/*  716 */     String beanName = transformedBeanName(name);
/*      */ 
/*      */     
/*  719 */     Object beanInstance = getSingleton(beanName, false);
/*  720 */     if (beanInstance != null && beanInstance.getClass() != NullBean.class) {
/*  721 */       if (beanInstance instanceof FactoryBean) { FactoryBean<?> factoryBean = (FactoryBean)beanInstance; if (!BeanFactoryUtils.isFactoryDereference(name)) {
/*  722 */           return getTypeForFactoryBean(factoryBean);
/*      */         } }
/*      */       
/*  725 */       return beanInstance.getClass();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  730 */     BeanFactory parentBeanFactory = getParentBeanFactory();
/*  731 */     if (parentBeanFactory != null && !containsBeanDefinition(beanName))
/*      */     {
/*  733 */       return parentBeanFactory.getType(originalBeanName(name));
/*      */     }
/*      */     
/*  736 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/*  737 */     Class<?> beanClass = predictBeanType(beanName, mbd, new Class[0]);
/*      */     
/*  739 */     if (beanClass != null)
/*      */     {
/*  741 */       if (FactoryBean.class.isAssignableFrom(beanClass)) {
/*  742 */         if (!BeanFactoryUtils.isFactoryDereference(name))
/*      */         {
/*  744 */           beanClass = getTypeForFactoryBean(beanName, mbd, allowFactoryBeanInit).resolve();
/*      */         }
/*      */       }
/*  747 */       else if (BeanFactoryUtils.isFactoryDereference(name)) {
/*  748 */         return null;
/*      */       } 
/*      */     }
/*      */     
/*  752 */     if (beanClass == null) {
/*      */ 
/*      */       
/*  755 */       BeanDefinitionHolder dbd = mbd.getDecoratedDefinition();
/*  756 */       if (dbd != null && !BeanFactoryUtils.isFactoryDereference(name)) {
/*  757 */         RootBeanDefinition tbd = getMergedBeanDefinition(dbd.getBeanName(), dbd.getBeanDefinition(), mbd);
/*  758 */         Class<?> targetClass = predictBeanType(dbd.getBeanName(), tbd, new Class[0]);
/*  759 */         if (targetClass != null && !FactoryBean.class.isAssignableFrom(targetClass)) {
/*  760 */           return targetClass;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  765 */     return beanClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getAliases(String name) {
/*  770 */     String beanName = transformedBeanName(name);
/*  771 */     List<String> aliases = new ArrayList<>();
/*  772 */     boolean hasFactoryPrefix = (!name.isEmpty() && name.charAt(0) == '&');
/*  773 */     String fullBeanName = beanName;
/*  774 */     if (hasFactoryPrefix) {
/*  775 */       fullBeanName = "&" + beanName;
/*      */     }
/*  777 */     if (!fullBeanName.equals(name)) {
/*  778 */       aliases.add(fullBeanName);
/*      */     }
/*  780 */     String[] retrievedAliases = super.getAliases(beanName);
/*  781 */     String prefix = hasFactoryPrefix ? "&" : "";
/*  782 */     for (String retrievedAlias : retrievedAliases) {
/*  783 */       String alias = prefix + prefix;
/*  784 */       if (!alias.equals(name)) {
/*  785 */         aliases.add(alias);
/*      */       }
/*      */     } 
/*  788 */     if (!containsSingleton(beanName) && !containsBeanDefinition(beanName)) {
/*  789 */       BeanFactory parentBeanFactory = getParentBeanFactory();
/*  790 */       if (parentBeanFactory != null) {
/*  791 */         aliases.addAll(Arrays.asList(parentBeanFactory.getAliases(fullBeanName)));
/*      */       }
/*      */     } 
/*  794 */     return StringUtils.toStringArray(aliases);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanFactory getParentBeanFactory() {
/*  805 */     return this.parentBeanFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsLocalBean(String name) {
/*  810 */     String beanName = transformedBeanName(name);
/*  811 */     return ((containsSingleton(beanName) || containsBeanDefinition(beanName)) && (
/*  812 */       !BeanFactoryUtils.isFactoryDereference(name) || isFactoryBean(beanName)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParentBeanFactory(@Nullable BeanFactory parentBeanFactory) {
/*  822 */     if (this.parentBeanFactory != null && this.parentBeanFactory != parentBeanFactory) {
/*  823 */       throw new IllegalStateException("Already associated with parent BeanFactory: " + String.valueOf(this.parentBeanFactory));
/*      */     }
/*  825 */     if (this == parentBeanFactory) {
/*  826 */       throw new IllegalStateException("Cannot set parent bean factory to self");
/*      */     }
/*  828 */     this.parentBeanFactory = parentBeanFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBeanClassLoader(@Nullable ClassLoader beanClassLoader) {
/*  833 */     this.beanClassLoader = (beanClassLoader != null) ? beanClassLoader : ClassUtils.getDefaultClassLoader();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ClassLoader getBeanClassLoader() {
/*  839 */     return this.beanClassLoader;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTempClassLoader(@Nullable ClassLoader tempClassLoader) {
/*  844 */     this.tempClassLoader = tempClassLoader;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ClassLoader getTempClassLoader() {
/*  850 */     return this.tempClassLoader;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCacheBeanMetadata(boolean cacheBeanMetadata) {
/*  855 */     this.cacheBeanMetadata = cacheBeanMetadata;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCacheBeanMetadata() {
/*  860 */     return this.cacheBeanMetadata;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBeanExpressionResolver(@Nullable BeanExpressionResolver resolver) {
/*  865 */     this.beanExpressionResolver = resolver;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanExpressionResolver getBeanExpressionResolver() {
/*  871 */     return this.beanExpressionResolver;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setConversionService(@Nullable ConversionService conversionService) {
/*  876 */     this.conversionService = conversionService;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public ConversionService getConversionService() {
/*  882 */     return this.conversionService;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPropertyEditorRegistrar(PropertyEditorRegistrar registrar) {
/*  887 */     Assert.notNull(registrar, "PropertyEditorRegistrar must not be null");
/*  888 */     if (registrar.overridesDefaultEditors()) {
/*  889 */       this.defaultEditorRegistrars.add(registrar);
/*      */     } else {
/*      */       
/*  892 */       this.propertyEditorRegistrars.add(registrar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<PropertyEditorRegistrar> getPropertyEditorRegistrars() {
/*  900 */     return this.propertyEditorRegistrars;
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerCustomEditor(Class<?> requiredType, Class<? extends PropertyEditor> propertyEditorClass) {
/*  905 */     Assert.notNull(requiredType, "Required type must not be null");
/*  906 */     Assert.notNull(propertyEditorClass, "PropertyEditor class must not be null");
/*  907 */     this.customEditors.put(requiredType, propertyEditorClass);
/*      */   }
/*      */ 
/*      */   
/*      */   public void copyRegisteredEditorsTo(PropertyEditorRegistry registry) {
/*  912 */     registerCustomEditors(registry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<Class<?>, Class<? extends PropertyEditor>> getCustomEditors() {
/*  919 */     return this.customEditors;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTypeConverter(TypeConverter typeConverter) {
/*  924 */     this.typeConverter = typeConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected TypeConverter getCustomTypeConverter() {
/*  933 */     return this.typeConverter;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeConverter getTypeConverter() {
/*  938 */     TypeConverter customConverter = getCustomTypeConverter();
/*  939 */     if (customConverter != null) {
/*  940 */       return customConverter;
/*      */     }
/*      */ 
/*      */     
/*  944 */     SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/*  945 */     typeConverter.setConversionService(getConversionService());
/*  946 */     registerCustomEditors((PropertyEditorRegistry)typeConverter);
/*  947 */     return (TypeConverter)typeConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEmbeddedValueResolver(StringValueResolver valueResolver) {
/*  953 */     Assert.notNull(valueResolver, "StringValueResolver must not be null");
/*  954 */     this.embeddedValueResolvers.add(valueResolver);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasEmbeddedValueResolver() {
/*  959 */     return !this.embeddedValueResolvers.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String resolveEmbeddedValue(@Nullable String value) {
/*  965 */     if (value == null) {
/*  966 */       return null;
/*      */     }
/*  968 */     String result = value;
/*  969 */     for (StringValueResolver resolver : this.embeddedValueResolvers) {
/*  970 */       result = resolver.resolveStringValue(result);
/*  971 */       if (result == null) {
/*  972 */         return null;
/*      */       }
/*      */     } 
/*  975 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBeanPostProcessor(BeanPostProcessor beanPostProcessor) {
/*  980 */     Assert.notNull(beanPostProcessor, "BeanPostProcessor must not be null");
/*  981 */     synchronized (this.beanPostProcessors) {
/*      */       
/*  983 */       this.beanPostProcessors.remove(beanPostProcessor);
/*      */       
/*  985 */       this.beanPostProcessors.add(beanPostProcessor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBeanPostProcessors(Collection<? extends BeanPostProcessor> beanPostProcessors) {
/*  996 */     synchronized (this.beanPostProcessors) {
/*      */       
/*  998 */       this.beanPostProcessors.removeAll(beanPostProcessors);
/*      */       
/* 1000 */       this.beanPostProcessors.addAll(beanPostProcessors);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getBeanPostProcessorCount() {
/* 1006 */     return this.beanPostProcessors.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<BeanPostProcessor> getBeanPostProcessors() {
/* 1014 */     return this.beanPostProcessors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BeanPostProcessorCache getBeanPostProcessorCache() {
/* 1023 */     synchronized (this.beanPostProcessors) {
/* 1024 */       BeanPostProcessorCache bppCache = this.beanPostProcessorCache;
/* 1025 */       if (bppCache == null) {
/* 1026 */         bppCache = new BeanPostProcessorCache();
/* 1027 */         for (BeanPostProcessor bpp : this.beanPostProcessors) {
/* 1028 */           if (bpp instanceof InstantiationAwareBeanPostProcessor) { InstantiationAwareBeanPostProcessor instantiationAwareBpp = (InstantiationAwareBeanPostProcessor)bpp;
/* 1029 */             bppCache.instantiationAware.add(instantiationAwareBpp);
/* 1030 */             if (bpp instanceof SmartInstantiationAwareBeanPostProcessor) { SmartInstantiationAwareBeanPostProcessor smartInstantiationAwareBpp = (SmartInstantiationAwareBeanPostProcessor)bpp;
/* 1031 */               bppCache.smartInstantiationAware.add(smartInstantiationAwareBpp); }
/*      */              }
/*      */           
/* 1034 */           if (bpp instanceof DestructionAwareBeanPostProcessor) { DestructionAwareBeanPostProcessor destructionAwareBpp = (DestructionAwareBeanPostProcessor)bpp;
/* 1035 */             bppCache.destructionAware.add(destructionAwareBpp); }
/*      */           
/* 1037 */           if (bpp instanceof MergedBeanDefinitionPostProcessor) { MergedBeanDefinitionPostProcessor mergedBeanDefBpp = (MergedBeanDefinitionPostProcessor)bpp;
/* 1038 */             bppCache.mergedDefinition.add(mergedBeanDefBpp); }
/*      */         
/*      */         } 
/* 1041 */         this.beanPostProcessorCache = bppCache;
/*      */       } 
/* 1043 */       return bppCache;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void resetBeanPostProcessorCache() {
/* 1048 */     synchronized (this.beanPostProcessors) {
/* 1049 */       this.beanPostProcessorCache = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasInstantiationAwareBeanPostProcessors() {
/* 1060 */     return !(getBeanPostProcessorCache()).instantiationAware.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasDestructionAwareBeanPostProcessors() {
/* 1070 */     return !(getBeanPostProcessorCache()).destructionAware.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerScope(String scopeName, Scope scope) {
/* 1075 */     Assert.notNull(scopeName, "Scope identifier must not be null");
/* 1076 */     Assert.notNull(scope, "Scope must not be null");
/* 1077 */     if ("singleton".equals(scopeName) || "prototype".equals(scopeName)) {
/* 1078 */       throw new IllegalArgumentException("Cannot replace existing scopes 'singleton' and 'prototype'");
/*      */     }
/* 1080 */     Scope previous = this.scopes.put(scopeName, scope);
/* 1081 */     if (previous != null && previous != scope) {
/* 1082 */       if (this.logger.isDebugEnabled()) {
/* 1083 */         this.logger.debug("Replacing scope '" + scopeName + "' from [" + String.valueOf(previous) + "] to [" + String.valueOf(scope) + "]");
/*      */       
/*      */       }
/*      */     }
/* 1087 */     else if (this.logger.isTraceEnabled()) {
/* 1088 */       this.logger.trace("Registering scope '" + scopeName + "' with implementation [" + String.valueOf(scope) + "]");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getRegisteredScopeNames() {
/* 1095 */     return StringUtils.toStringArray(this.scopes.keySet());
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Scope getRegisteredScope(String scopeName) {
/* 1101 */     Assert.notNull(scopeName, "Scope identifier must not be null");
/* 1102 */     return this.scopes.get(scopeName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setApplicationStartup(ApplicationStartup applicationStartup) {
/* 1107 */     Assert.notNull(applicationStartup, "ApplicationStartup must not be null");
/* 1108 */     this.applicationStartup = applicationStartup;
/*      */   }
/*      */ 
/*      */   
/*      */   public ApplicationStartup getApplicationStartup() {
/* 1113 */     return this.applicationStartup;
/*      */   }
/*      */ 
/*      */   
/*      */   public void copyConfigurationFrom(ConfigurableBeanFactory otherFactory) {
/* 1118 */     Assert.notNull(otherFactory, "BeanFactory must not be null");
/* 1119 */     setBeanClassLoader(otherFactory.getBeanClassLoader());
/* 1120 */     setCacheBeanMetadata(otherFactory.isCacheBeanMetadata());
/* 1121 */     setBeanExpressionResolver(otherFactory.getBeanExpressionResolver());
/* 1122 */     setConversionService(otherFactory.getConversionService());
/* 1123 */     if (otherFactory instanceof AbstractBeanFactory) { AbstractBeanFactory otherAbstractFactory = (AbstractBeanFactory)otherFactory;
/* 1124 */       this.defaultEditorRegistrars.addAll(otherAbstractFactory.defaultEditorRegistrars);
/* 1125 */       this.propertyEditorRegistrars.addAll(otherAbstractFactory.propertyEditorRegistrars);
/* 1126 */       this.customEditors.putAll(otherAbstractFactory.customEditors);
/* 1127 */       this.typeConverter = otherAbstractFactory.typeConverter;
/* 1128 */       this.beanPostProcessors.addAll(otherAbstractFactory.beanPostProcessors);
/* 1129 */       this.scopes.putAll(otherAbstractFactory.scopes); }
/*      */     else
/*      */     
/* 1132 */     { setTypeConverter(otherFactory.getTypeConverter());
/* 1133 */       String[] otherScopeNames = otherFactory.getRegisteredScopeNames();
/* 1134 */       for (String scopeName : otherScopeNames) {
/* 1135 */         this.scopes.put(scopeName, otherFactory.getRegisteredScope(scopeName));
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDefinition getMergedBeanDefinition(String name) throws BeansException {
/* 1153 */     String beanName = transformedBeanName(name);
/*      */     
/* 1155 */     BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory parent = (ConfigurableBeanFactory)beanFactory; if (!containsBeanDefinition(beanName)) {
/* 1156 */         return parent.getMergedBeanDefinition(beanName);
/*      */       } }
/*      */     
/* 1159 */     return getMergedLocalBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFactoryBean(String name) throws NoSuchBeanDefinitionException {
/* 1164 */     String beanName = transformedBeanName(name);
/* 1165 */     Object beanInstance = getSingleton(beanName, false);
/* 1166 */     if (beanInstance != null) {
/* 1167 */       return beanInstance instanceof FactoryBean;
/*      */     }
/*      */     
/* 1170 */     if (!containsBeanDefinition(beanName)) { BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/*      */         
/* 1172 */         return cbf.isFactoryBean(name); }
/*      */        }
/* 1174 */      return isFactoryBean(beanName, getMergedLocalBeanDefinition(beanName));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isActuallyInCreation(String beanName) {
/* 1179 */     return (isSingletonCurrentlyInCreation(beanName) || isPrototypeCurrentlyInCreation(beanName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isPrototypeCurrentlyInCreation(String beanName) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield prototypesCurrentlyInCreation : Ljava/lang/ThreadLocal;
/*      */     //   4: invokevirtual get : ()Ljava/lang/Object;
/*      */     //   7: astore_2
/*      */     //   8: aload_2
/*      */     //   9: ifnull -> 46
/*      */     //   12: aload_2
/*      */     //   13: aload_1
/*      */     //   14: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   17: ifne -> 42
/*      */     //   20: aload_2
/*      */     //   21: instanceof java/util/Set
/*      */     //   24: ifeq -> 46
/*      */     //   27: aload_2
/*      */     //   28: checkcast java/util/Set
/*      */     //   31: astore_3
/*      */     //   32: aload_3
/*      */     //   33: aload_1
/*      */     //   34: invokeinterface contains : (Ljava/lang/Object;)Z
/*      */     //   39: ifeq -> 46
/*      */     //   42: iconst_1
/*      */     //   43: goto -> 47
/*      */     //   46: iconst_0
/*      */     //   47: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1188	-> 0
/*      */     //   #1189	-> 8
/*      */     //   #1190	-> 14
/*      */     //   #1189	-> 47
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   32	10	3	set	Ljava/util/Set;
/*      */     //   0	48	0	this	Lorg/springframework/beans/factory/support/AbstractBeanFactory;
/*      */     //   0	48	1	beanName	Ljava/lang/String;
/*      */     //   8	40	2	curVal	Ljava/lang/Object;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   32	10	3	set	Ljava/util/Set<*>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void beforePrototypeCreation(String beanName) {
/* 1201 */     Object curVal = this.prototypesCurrentlyInCreation.get();
/* 1202 */     if (curVal == null)
/* 1203 */     { this.prototypesCurrentlyInCreation.set(beanName); }
/*      */     
/* 1205 */     else if (curVal instanceof String) { String strValue = (String)curVal;
/* 1206 */       Set<String> beanNameSet = CollectionUtils.newHashSet(2);
/* 1207 */       beanNameSet.add(strValue);
/* 1208 */       beanNameSet.add(beanName);
/* 1209 */       this.prototypesCurrentlyInCreation.set(beanNameSet); }
/*      */     else
/*      */     
/* 1212 */     { Set<String> beanNameSet = (Set<String>)curVal;
/* 1213 */       beanNameSet.add(beanName); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void afterPrototypeCreation(String beanName) {
/* 1225 */     Object curVal = this.prototypesCurrentlyInCreation.get();
/* 1226 */     if (curVal instanceof String)
/* 1227 */     { this.prototypesCurrentlyInCreation.remove(); }
/*      */     
/* 1229 */     else if (curVal instanceof Set) { Set<?> beanNameSet = (Set)curVal;
/* 1230 */       beanNameSet.remove(beanName);
/* 1231 */       if (beanNameSet.isEmpty()) {
/* 1232 */         this.prototypesCurrentlyInCreation.remove();
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public void destroyBean(String beanName, Object beanInstance) {
/* 1239 */     destroyBean(beanName, beanInstance, getMergedLocalBeanDefinition(beanName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void destroyBean(String beanName, Object bean, RootBeanDefinition mbd) {
/* 1250 */     (new DisposableBeanAdapter(bean, beanName, mbd, 
/* 1251 */         (getBeanPostProcessorCache()).destructionAware)).destroy();
/*      */   }
/*      */ 
/*      */   
/*      */   public void destroyScopedBean(String beanName) {
/* 1256 */     RootBeanDefinition mbd = getMergedLocalBeanDefinition(beanName);
/* 1257 */     if (mbd.isSingleton() || mbd.isPrototype()) {
/* 1258 */       throw new IllegalArgumentException("Bean name '" + beanName + "' does not correspond to an object in a mutable scope");
/*      */     }
/*      */     
/* 1261 */     String scopeName = mbd.getScope();
/* 1262 */     Scope scope = this.scopes.get(scopeName);
/* 1263 */     if (scope == null) {
/* 1264 */       throw new IllegalStateException("No Scope SPI registered for scope name '" + scopeName + "'");
/*      */     }
/* 1266 */     Object bean = scope.remove(beanName);
/* 1267 */     if (bean != null) {
/* 1268 */       destroyBean(beanName, bean, mbd);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String transformedBeanName(String name) {
/* 1284 */     return canonicalName(BeanFactoryUtils.transformedBeanName(name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String originalBeanName(String name) {
/* 1293 */     String beanName = transformedBeanName(name);
/* 1294 */     if (!name.isEmpty() && name.charAt(0) == '&') {
/* 1295 */       beanName = "&" + beanName;
/*      */     }
/* 1297 */     return beanName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeanWrapper(BeanWrapper bw) {
/* 1309 */     bw.setConversionService(getConversionService());
/* 1310 */     registerCustomEditors((PropertyEditorRegistry)bw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerCustomEditors(PropertyEditorRegistry registry) {
/* 1322 */     if (registry instanceof PropertyEditorRegistrySupport) { PropertyEditorRegistrySupport registrySupport = (PropertyEditorRegistrySupport)registry;
/* 1323 */       registrySupport.useConfigValueEditors();
/* 1324 */       if (!this.defaultEditorRegistrars.isEmpty())
/*      */       {
/* 1326 */         registrySupport.setDefaultEditorRegistrar(new BeanFactoryDefaultEditorRegistrar());
/*      */       } }
/*      */     
/* 1329 */     else if (!this.defaultEditorRegistrars.isEmpty())
/*      */     
/* 1331 */     { applyEditorRegistrars(registry, this.defaultEditorRegistrars); }
/*      */ 
/*      */     
/* 1334 */     if (!this.propertyEditorRegistrars.isEmpty()) {
/* 1335 */       applyEditorRegistrars(registry, this.propertyEditorRegistrars);
/*      */     }
/* 1337 */     if (!this.customEditors.isEmpty()) {
/* 1338 */       this.customEditors.forEach((requiredType, editorClass) -> registry.registerCustomEditor(requiredType, (PropertyEditor)BeanUtils.instantiateClass(editorClass)));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void applyEditorRegistrars(PropertyEditorRegistry registry, Set<PropertyEditorRegistrar> registrars) {
/* 1344 */     for (PropertyEditorRegistrar registrar : registrars) {
/*      */       try {
/* 1346 */         registrar.registerCustomEditors(registry);
/*      */       }
/* 1348 */       catch (BeanCreationException ex) {
/* 1349 */         Throwable rootCause = ex.getMostSpecificCause();
/* 1350 */         if (rootCause instanceof BeanCurrentlyInCreationException) { BeanCurrentlyInCreationException bce = (BeanCurrentlyInCreationException)rootCause;
/* 1351 */           String bceBeanName = bce.getBeanName();
/* 1352 */           if (bceBeanName != null && isCurrentlyInCreation(bceBeanName)) {
/* 1353 */             if (this.logger.isDebugEnabled()) {
/* 1354 */               this.logger.debug("PropertyEditorRegistrar [" + registrar.getClass().getName() + "] failed because it tried to obtain currently created bean '" + ex
/*      */                   
/* 1356 */                   .getBeanName() + "': " + ex.getMessage());
/*      */             }
/* 1358 */             onSuppressedException((Exception)ex);
/*      */             return;
/*      */           }  }
/*      */         
/* 1362 */         throw ex;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RootBeanDefinition getMergedLocalBeanDefinition(String beanName) throws BeansException {
/* 1377 */     RootBeanDefinition mbd = this.mergedBeanDefinitions.get(beanName);
/* 1378 */     if (mbd != null && !mbd.stale) {
/* 1379 */       return mbd;
/*      */     }
/* 1381 */     return getMergedBeanDefinition(beanName, getBeanDefinition(beanName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RootBeanDefinition getMergedBeanDefinition(String beanName, BeanDefinition bd) throws BeanDefinitionStoreException {
/* 1395 */     return getMergedBeanDefinition(beanName, bd, (BeanDefinition)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RootBeanDefinition getMergedBeanDefinition(String beanName, BeanDefinition bd, @Nullable BeanDefinition containingBd) throws BeanDefinitionStoreException {
/* 1412 */     synchronized (this.mergedBeanDefinitions) {
/* 1413 */       RootBeanDefinition mbd = null;
/* 1414 */       RootBeanDefinition previous = null;
/*      */ 
/*      */       
/* 1417 */       if (containingBd == null) {
/* 1418 */         mbd = this.mergedBeanDefinitions.get(beanName);
/*      */       }
/*      */       
/* 1421 */       if (mbd == null || mbd.stale) {
/* 1422 */         previous = mbd;
/* 1423 */         if (bd.getParentName() == null) {
/*      */           
/* 1425 */           if (bd instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDef = (RootBeanDefinition)bd;
/* 1426 */             mbd = rootBeanDef.cloneBeanDefinition(); }
/*      */           else
/*      */           
/* 1429 */           { mbd = new RootBeanDefinition(bd); }
/*      */         
/*      */         } else {
/*      */           BeanDefinition pbd;
/*      */ 
/*      */           
/*      */           try {
/* 1436 */             String parentBeanName = transformedBeanName(bd.getParentName());
/* 1437 */             if (!beanName.equals(parentBeanName)) {
/* 1438 */               pbd = getMergedBeanDefinition(parentBeanName);
/*      */             } else {
/*      */               
/* 1441 */               BeanFactory beanFactory = getParentBeanFactory(); if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory parent = (ConfigurableBeanFactory)beanFactory;
/* 1442 */                 pbd = parent.getMergedBeanDefinition(parentBeanName); }
/*      */               else
/*      */               
/* 1445 */               { throw new NoSuchBeanDefinitionException(parentBeanName, "Parent name '" + parentBeanName + "' is equal to bean name '" + beanName + "': cannot be resolved without a ConfigurableBeanFactory parent"); }
/*      */ 
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1451 */           catch (NoSuchBeanDefinitionException ex) {
/* 1452 */             throw new BeanDefinitionStoreException(bd.getResourceDescription(), beanName, "Could not resolve parent bean definition '" + bd
/* 1453 */                 .getParentName() + "'", ex);
/*      */           } 
/*      */           
/* 1456 */           mbd = new RootBeanDefinition(pbd);
/* 1457 */           mbd.overrideFrom(bd);
/*      */         } 
/*      */ 
/*      */         
/* 1461 */         if (!StringUtils.hasLength(mbd.getScope())) {
/* 1462 */           mbd.setScope("singleton");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1469 */         if (containingBd != null && !containingBd.isSingleton() && mbd.isSingleton()) {
/* 1470 */           mbd.setScope(containingBd.getScope());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1475 */         if (containingBd == null && (isCacheBeanMetadata() || isBeanEligibleForMetadataCaching(beanName))) {
/* 1476 */           cacheMergedBeanDefinition(mbd, beanName);
/*      */         }
/*      */       } 
/* 1479 */       if (previous != null) {
/* 1480 */         copyRelevantMergedBeanDefinitionCaches(previous, mbd);
/*      */       }
/* 1482 */       return mbd;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void copyRelevantMergedBeanDefinitionCaches(RootBeanDefinition previous, RootBeanDefinition mbd) {
/* 1487 */     if (ObjectUtils.nullSafeEquals(mbd.getBeanClassName(), previous.getBeanClassName()) && 
/* 1488 */       ObjectUtils.nullSafeEquals(mbd.getFactoryBeanName(), previous.getFactoryBeanName()) && 
/* 1489 */       ObjectUtils.nullSafeEquals(mbd.getFactoryMethodName(), previous.getFactoryMethodName())) {
/* 1490 */       ResolvableType targetType = mbd.targetType;
/* 1491 */       ResolvableType previousTargetType = previous.targetType;
/* 1492 */       if (targetType == null || targetType.equals(previousTargetType)) {
/* 1493 */         mbd.targetType = previousTargetType;
/* 1494 */         mbd.isFactoryBean = previous.isFactoryBean;
/* 1495 */         mbd.resolvedTargetType = previous.resolvedTargetType;
/* 1496 */         mbd.factoryMethodReturnType = previous.factoryMethodReturnType;
/* 1497 */         mbd.factoryMethodToIntrospect = previous.factoryMethodToIntrospect;
/*      */       } 
/* 1499 */       if (previous.hasMethodOverrides()) {
/* 1500 */         mbd.setMethodOverrides(new MethodOverrides(previous.getMethodOverrides()));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cacheMergedBeanDefinition(RootBeanDefinition mbd, String beanName) {
/* 1514 */     this.mergedBeanDefinitions.put(beanName, mbd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkMergedBeanDefinition(RootBeanDefinition mbd, String beanName, @Nullable Object[] args) {
/* 1525 */     if (mbd.isAbstract()) {
/* 1526 */       throw new BeanIsAbstractException(beanName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearMergedBeanDefinition(String beanName) {
/* 1536 */     RootBeanDefinition bd = this.mergedBeanDefinitions.get(beanName);
/* 1537 */     if (bd != null) {
/* 1538 */       bd.stale = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearMetadataCache() {
/* 1551 */     this.mergedBeanDefinitions.forEach((beanName, bd) -> {
/*      */           if (!isBeanEligibleForMetadataCaching(beanName)) {
/*      */             bd.stale = true;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Class<?> resolveBeanClass(RootBeanDefinition mbd, String beanName, Class<?>... typesToMatch) throws CannotLoadBeanClassException {
/*      */     try {
/* 1574 */       if (mbd.hasBeanClass()) {
/* 1575 */         return mbd.getBeanClass();
/*      */       }
/* 1577 */       Class<?> beanClass = doResolveBeanClass(mbd, typesToMatch);
/* 1578 */       if (mbd.hasBeanClass()) {
/* 1579 */         mbd.prepareMethodOverrides();
/*      */       }
/* 1581 */       return beanClass;
/*      */     }
/* 1583 */     catch (ClassNotFoundException ex) {
/* 1584 */       throw new CannotLoadBeanClassException(mbd.getResourceDescription(), beanName, mbd.getBeanClassName(), ex);
/*      */     }
/* 1586 */     catch (LinkageError err) {
/* 1587 */       throw new CannotLoadBeanClassException(mbd.getResourceDescription(), beanName, mbd.getBeanClassName(), err);
/*      */     }
/* 1589 */     catch (BeanDefinitionValidationException ex) {
/* 1590 */       throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, "Validation of method overrides failed", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Class<?> doResolveBeanClass(RootBeanDefinition mbd, Class<?>... typesToMatch) throws ClassNotFoundException {
/* 1599 */     ClassLoader beanClassLoader = getBeanClassLoader();
/* 1600 */     ClassLoader dynamicLoader = beanClassLoader;
/* 1601 */     boolean freshResolve = false;
/*      */     
/* 1603 */     if (!ObjectUtils.isEmpty((Object[])typesToMatch)) {
/*      */ 
/*      */       
/* 1606 */       ClassLoader tempClassLoader = getTempClassLoader();
/* 1607 */       if (tempClassLoader != null) {
/* 1608 */         dynamicLoader = tempClassLoader;
/* 1609 */         freshResolve = true;
/* 1610 */         if (tempClassLoader instanceof DecoratingClassLoader) { DecoratingClassLoader dcl = (DecoratingClassLoader)tempClassLoader;
/* 1611 */           for (Class<?> typeToMatch : typesToMatch) {
/* 1612 */             dcl.excludeClass(typeToMatch.getName());
/*      */           } }
/*      */       
/*      */       } 
/*      */     } 
/*      */     
/* 1618 */     String className = mbd.getBeanClassName();
/* 1619 */     if (className != null) {
/* 1620 */       Object evaluated = evaluateBeanDefinitionString(className, mbd);
/* 1621 */       if (!className.equals(evaluated)) {
/*      */         
/* 1623 */         if (evaluated instanceof Class) { Class<?> clazz = (Class)evaluated;
/* 1624 */           return clazz; }
/*      */         
/* 1626 */         if (evaluated instanceof String) { String name = (String)evaluated;
/* 1627 */           className = name;
/* 1628 */           freshResolve = true; }
/*      */         else
/*      */         
/* 1631 */         { throw new IllegalStateException("Invalid class name expression result: " + String.valueOf(evaluated)); }
/*      */       
/*      */       } 
/* 1634 */       if (freshResolve) {
/*      */ 
/*      */         
/* 1637 */         if (dynamicLoader != null) {
/*      */           try {
/* 1639 */             return dynamicLoader.loadClass(className);
/*      */           }
/* 1641 */           catch (ClassNotFoundException ex) {
/* 1642 */             if (this.logger.isTraceEnabled()) {
/* 1643 */               this.logger.trace("Could not load class [" + className + "] from " + String.valueOf(dynamicLoader) + ": " + String.valueOf(ex));
/*      */             }
/*      */           } 
/*      */         }
/* 1647 */         return ClassUtils.forName(className, dynamicLoader);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1652 */     return mbd.resolveBeanClass(beanClassLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object evaluateBeanDefinitionString(@Nullable String value, @Nullable BeanDefinition beanDefinition) {
/* 1665 */     if (this.beanExpressionResolver == null) {
/* 1666 */       return value;
/*      */     }
/*      */     
/* 1669 */     Scope scope = null;
/* 1670 */     if (beanDefinition != null) {
/* 1671 */       String scopeName = beanDefinition.getScope();
/* 1672 */       if (scopeName != null) {
/* 1673 */         scope = getRegisteredScope(scopeName);
/*      */       }
/*      */     } 
/* 1676 */     return this.beanExpressionResolver.evaluate(value, new BeanExpressionContext(this, scope));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Class<?> predictBeanType(String beanName, RootBeanDefinition mbd, Class<?>... typesToMatch) {
/* 1697 */     Class<?> targetType = mbd.getTargetType();
/* 1698 */     if (targetType != null) {
/* 1699 */       return targetType;
/*      */     }
/* 1701 */     if (mbd.getFactoryMethodName() != null) {
/* 1702 */       return null;
/*      */     }
/* 1704 */     return resolveBeanClass(mbd, beanName, typesToMatch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isFactoryBean(String beanName, RootBeanDefinition mbd) {
/* 1713 */     Boolean result = mbd.isFactoryBean;
/* 1714 */     if (result == null) {
/* 1715 */       Class<?> beanType = predictBeanType(beanName, mbd, new Class[] { FactoryBean.class });
/* 1716 */       result = Boolean.valueOf((beanType != null && FactoryBean.class.isAssignableFrom(beanType)));
/* 1717 */       mbd.isFactoryBean = result;
/*      */     } 
/* 1719 */     return result.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResolvableType getTypeForFactoryBean(String beanName, RootBeanDefinition mbd, boolean allowInit) {
/*      */     try {
/* 1748 */       ResolvableType result = getTypeForFactoryBeanFromAttributes((AttributeAccessor)mbd);
/* 1749 */       if (result != ResolvableType.NONE) {
/* 1750 */         return result;
/*      */       }
/*      */     }
/* 1753 */     catch (IllegalArgumentException ex) {
/* 1754 */       throw new BeanDefinitionStoreException(mbd.getResourceDescription(), beanName, 
/* 1755 */           String.valueOf(ex.getMessage()));
/*      */     } 
/*      */     
/* 1758 */     if (allowInit && mbd.isSingleton()) {
/*      */       try {
/* 1760 */         FactoryBean<?> factoryBean = doGetBean("&" + beanName, FactoryBean.class, (Object[])null, true);
/* 1761 */         Class<?> objectType = getTypeForFactoryBean(factoryBean);
/* 1762 */         return (objectType != null) ? ResolvableType.forClass(objectType) : ResolvableType.NONE;
/*      */       }
/* 1764 */       catch (BeanCreationException ex) {
/* 1765 */         if (ex.contains(BeanCurrentlyInCreationException.class)) {
/* 1766 */           this.logger.trace(LogMessage.format("Bean currently in creation on FactoryBean type check: %s", ex));
/*      */         }
/* 1768 */         else if (mbd.isLazyInit()) {
/* 1769 */           this.logger.trace(LogMessage.format("Bean creation exception on lazy FactoryBean type check: %s", ex));
/*      */         } else {
/*      */           
/* 1772 */           this.logger.debug(LogMessage.format("Bean creation exception on eager FactoryBean type check: %s", ex));
/*      */         } 
/* 1774 */         onSuppressedException((Exception)ex);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1779 */     return ResolvableType.NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void markBeanAsCreated(String beanName) {
/* 1789 */     if (!this.alreadyCreated.contains(beanName)) {
/* 1790 */       synchronized (this.mergedBeanDefinitions) {
/* 1791 */         if (!isBeanEligibleForMetadataCaching(beanName))
/*      */         {
/*      */           
/* 1794 */           clearMergedBeanDefinition(beanName);
/*      */         }
/* 1796 */         this.alreadyCreated.add(beanName);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanupAfterBeanCreationFailure(String beanName) {
/* 1806 */     synchronized (this.mergedBeanDefinitions) {
/* 1807 */       this.alreadyCreated.remove(beanName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isBeanEligibleForMetadataCaching(String beanName) {
/* 1819 */     return this.alreadyCreated.contains(beanName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean removeSingletonIfCreatedForTypeCheckOnly(String beanName) {
/* 1829 */     if (!this.alreadyCreated.contains(beanName)) {
/* 1830 */       removeSingleton(beanName);
/* 1831 */       return true;
/*      */     } 
/*      */     
/* 1834 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasBeanCreationStarted() {
/* 1845 */     return !this.alreadyCreated.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getObjectForBeanInstance(Object beanInstance, String name, String beanName, @Nullable RootBeanDefinition mbd) {
/*      */     FactoryBean<?> factoryBean;
/* 1861 */     if (BeanFactoryUtils.isFactoryDereference(name)) {
/* 1862 */       if (beanInstance instanceof NullBean) {
/* 1863 */         return beanInstance;
/*      */       }
/* 1865 */       if (!(beanInstance instanceof FactoryBean)) {
/* 1866 */         throw new BeanIsNotAFactoryException(beanName, beanInstance.getClass());
/*      */       }
/* 1868 */       if (mbd != null) {
/* 1869 */         mbd.isFactoryBean = Boolean.valueOf(true);
/*      */       }
/* 1871 */       return beanInstance;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1877 */     if (beanInstance instanceof FactoryBean) { factoryBean = (FactoryBean)beanInstance; }
/* 1878 */     else { return beanInstance; }
/*      */ 
/*      */     
/* 1881 */     Object object = null;
/* 1882 */     if (mbd != null) {
/* 1883 */       mbd.isFactoryBean = Boolean.valueOf(true);
/*      */     } else {
/*      */       
/* 1886 */       object = getCachedObjectForFactoryBean(beanName);
/*      */     } 
/* 1888 */     if (object == null) {
/*      */ 
/*      */       
/* 1891 */       if (mbd == null && containsBeanDefinition(beanName)) {
/* 1892 */         mbd = getMergedLocalBeanDefinition(beanName);
/*      */       }
/* 1894 */       boolean synthetic = (mbd != null && mbd.isSynthetic());
/* 1895 */       object = getObjectFromFactoryBean(factoryBean, beanName, !synthetic);
/*      */     } 
/* 1897 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeanNameInUse(String beanName) {
/* 1907 */     return (isAlias(beanName) || containsLocalBean(beanName) || hasDependentBean(beanName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean requiresDestruction(Object bean, RootBeanDefinition mbd) {
/* 1921 */     return (bean.getClass() != NullBean.class && (DisposableBeanAdapter.hasDestroyMethod(bean, mbd) || (
/* 1922 */       hasDestructionAwareBeanPostProcessors() && DisposableBeanAdapter.hasApplicableProcessors(bean, 
/* 1923 */         (getBeanPostProcessorCache()).destructionAware))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerDisposableBeanIfNecessary(String beanName, Object bean, RootBeanDefinition mbd) {
/* 1939 */     if (!mbd.isPrototype() && requiresDestruction(bean, mbd)) {
/* 1940 */       if (mbd.isSingleton()) {
/*      */ 
/*      */ 
/*      */         
/* 1944 */         registerDisposableBean(beanName, new DisposableBeanAdapter(bean, beanName, mbd, 
/* 1945 */               (getBeanPostProcessorCache()).destructionAware));
/*      */       }
/*      */       else {
/*      */         
/* 1949 */         Scope scope = this.scopes.get(mbd.getScope());
/* 1950 */         if (scope == null) {
/* 1951 */           throw new IllegalStateException("No Scope registered for scope name '" + mbd.getScope() + "'");
/*      */         }
/* 1953 */         scope.registerDestructionCallback(beanName, new DisposableBeanAdapter(bean, beanName, mbd, 
/* 1954 */               (getBeanPostProcessorCache()).destructionAware));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractBeanFactory() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean containsBeanDefinition(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract BeanDefinition getBeanDefinition(String paramString) throws BeansException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract Object createBean(String paramString, RootBeanDefinition paramRootBeanDefinition, @Nullable Object[] paramArrayOfObject) throws BeanCreationException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class BeanPostProcessorCacheAwareList
/*      */     extends CopyOnWriteArrayList<BeanPostProcessor>
/*      */   {
/*      */     public BeanPostProcessor set(int index, BeanPostProcessor element) {
/* 2027 */       BeanPostProcessor result = super.set(index, element);
/* 2028 */       AbstractBeanFactory.this.resetBeanPostProcessorCache();
/* 2029 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(BeanPostProcessor o) {
/* 2034 */       boolean success = super.add(o);
/* 2035 */       AbstractBeanFactory.this.resetBeanPostProcessorCache();
/* 2036 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(int index, BeanPostProcessor element) {
/* 2041 */       super.add(index, element);
/* 2042 */       AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */     }
/*      */ 
/*      */     
/*      */     public BeanPostProcessor remove(int index) {
/* 2047 */       BeanPostProcessor result = super.remove(index);
/* 2048 */       AbstractBeanFactory.this.resetBeanPostProcessorCache();
/* 2049 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object o) {
/* 2054 */       boolean success = super.remove(o);
/* 2055 */       if (success) {
/* 2056 */         AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */       }
/* 2058 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> c) {
/* 2063 */       boolean success = super.removeAll(c);
/* 2064 */       if (success) {
/* 2065 */         AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */       }
/* 2067 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> c) {
/* 2072 */       boolean success = super.retainAll(c);
/* 2073 */       if (success) {
/* 2074 */         AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */       }
/* 2076 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends BeanPostProcessor> c) {
/* 2081 */       boolean success = super.addAll(c);
/* 2082 */       if (success) {
/* 2083 */         AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */       }
/* 2085 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(int index, Collection<? extends BeanPostProcessor> c) {
/* 2090 */       boolean success = super.addAll(index, c);
/* 2091 */       if (success) {
/* 2092 */         AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */       }
/* 2094 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeIf(Predicate<? super BeanPostProcessor> filter) {
/* 2099 */       boolean success = super.removeIf(filter);
/* 2100 */       if (success) {
/* 2101 */         AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */       }
/* 2103 */       return success;
/*      */     }
/*      */ 
/*      */     
/*      */     public void replaceAll(UnaryOperator<BeanPostProcessor> operator) {
/* 2108 */       super.replaceAll(operator);
/* 2109 */       AbstractBeanFactory.this.resetBeanPostProcessorCache();
/*      */     }
/*      */   }
/*      */   
/*      */   static class BeanPostProcessorCache
/*      */   {
/*      */     final List<InstantiationAwareBeanPostProcessor> instantiationAware;
/*      */     final List<SmartInstantiationAwareBeanPostProcessor> smartInstantiationAware;
/*      */     final List<DestructionAwareBeanPostProcessor> destructionAware;
/*      */     final List<MergedBeanDefinitionPostProcessor> mergedDefinition;
/*      */     
/*      */     BeanPostProcessorCache() {
/* 2121 */       this.instantiationAware = new ArrayList<>();
/*      */       
/* 2123 */       this.smartInstantiationAware = new ArrayList<>();
/*      */       
/* 2125 */       this.destructionAware = new ArrayList<>();
/*      */       
/* 2127 */       this.mergedDefinition = new ArrayList<>();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class BeanFactoryDefaultEditorRegistrar
/*      */     implements PropertyEditorRegistrar
/*      */   {
/*      */     public void registerCustomEditors(PropertyEditorRegistry registry) {
/* 2142 */       AbstractBeanFactory.this.applyEditorRegistrars(registry, AbstractBeanFactory.this.defaultEditorRegistrars);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\AbstractBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */