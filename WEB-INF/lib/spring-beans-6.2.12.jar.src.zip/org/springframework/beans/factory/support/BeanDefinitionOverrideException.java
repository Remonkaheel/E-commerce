/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.lang.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanDefinitionOverrideException
/*     */   extends BeanDefinitionStoreException
/*     */ {
/*     */   private final BeanDefinition beanDefinition;
/*     */   private final BeanDefinition existingDefinition;
/*     */   
/*     */   public BeanDefinitionOverrideException(String beanName, BeanDefinition beanDefinition, BeanDefinition existingDefinition) {
/*  50 */     super(beanDefinition.getResourceDescription(), beanName, "Cannot register bean definition [" + String.valueOf(beanDefinition) + "] for bean '" + beanName + "' since there is already [" + String.valueOf(existingDefinition) + "] bound.");
/*     */ 
/*     */     
/*  53 */     this.beanDefinition = beanDefinition;
/*  54 */     this.existingDefinition = existingDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionOverrideException(String beanName, BeanDefinition beanDefinition, BeanDefinition existingDefinition, String msg) {
/*  68 */     super(beanDefinition.getResourceDescription(), beanName, msg);
/*  69 */     this.beanDefinition = beanDefinition;
/*  70 */     this.existingDefinition = existingDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public String getResourceDescription() {
/*  80 */     return String.valueOf(super.getResourceDescription());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public String getBeanName() {
/*  89 */     return String.valueOf(super.getBeanName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition getBeanDefinition() {
/*  97 */     return this.beanDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition getExistingDefinition() {
/* 105 */     return this.existingDefinition;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\BeanDefinitionOverrideException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */