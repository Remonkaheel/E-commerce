/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.cglib.core.ClassLoaderAwareGeneratorStrategy;
/*     */ import org.springframework.cglib.core.GeneratorStrategy;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CglibSubclassingInstantiationStrategy
/*     */   extends SimpleInstantiationStrategy
/*     */ {
/*     */   private static final int PASSTHROUGH = 0;
/*     */   private static final int LOOKUP_OVERRIDE = 1;
/*     */   private static final int METHOD_REPLACER = 2;
/*     */   
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner) {
/*  78 */     return instantiateWithMethodInjection(bd, beanName, owner, null, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object instantiateWithMethodInjection(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner, @Nullable Constructor<?> ctor, Object... args) {
/*  85 */     return (new CglibSubclassCreator(bd, owner)).instantiate(ctor, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getActualBeanClass(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner) {
/*  90 */     if (!bd.hasMethodOverrides()) {
/*  91 */       return super.getActualBeanClass(bd, beanName, owner);
/*     */     }
/*  93 */     return (new CglibSubclassCreator(bd, owner)).createEnhancedSubclass(bd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CglibSubclassCreator
/*     */   {
/* 103 */     private static final Class<?>[] CALLBACK_TYPES = new Class[] { NoOp.class, CglibSubclassingInstantiationStrategy.LookupOverrideMethodInterceptor.class, CglibSubclassingInstantiationStrategy.ReplaceOverrideMethodInterceptor.class };
/*     */     
/*     */     private final RootBeanDefinition beanDefinition;
/*     */     
/*     */     private final BeanFactory owner;
/*     */ 
/*     */     
/*     */     CglibSubclassCreator(RootBeanDefinition beanDefinition, BeanFactory owner) {
/* 111 */       this.beanDefinition = beanDefinition;
/* 112 */       this.owner = owner;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object instantiate(@Nullable Constructor<?> ctor, Object... args) {
/*     */       Object instance;
/* 125 */       Class<?> subclass = createEnhancedSubclass(this.beanDefinition);
/*     */       
/* 127 */       if (ctor == null) {
/* 128 */         instance = BeanUtils.instantiateClass(subclass);
/*     */       } else {
/*     */         
/*     */         try {
/* 132 */           Constructor<?> enhancedSubclassConstructor = subclass.getConstructor(ctor.getParameterTypes());
/* 133 */           instance = enhancedSubclassConstructor.newInstance(args);
/*     */         }
/* 135 */         catch (Exception ex) {
/* 136 */           throw new BeanInstantiationException(this.beanDefinition.getBeanClass(), "Failed to invoke constructor for CGLIB enhanced subclass [" + subclass
/* 137 */               .getName() + "]", ex);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 142 */       Factory factory = (Factory)instance;
/* 143 */       factory.setCallbacks(new Callback[] { (Callback)NoOp.INSTANCE, (Callback)new CglibSubclassingInstantiationStrategy.LookupOverrideMethodInterceptor(this.beanDefinition, this.owner), (Callback)new CglibSubclassingInstantiationStrategy.ReplaceOverrideMethodInterceptor(this.beanDefinition, this.owner) });
/*     */ 
/*     */       
/* 146 */       return instance;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> createEnhancedSubclass(RootBeanDefinition beanDefinition) {
/* 154 */       Enhancer enhancer = new Enhancer();
/* 155 */       enhancer.setSuperclass(beanDefinition.getBeanClass());
/* 156 */       enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 157 */       enhancer.setAttemptLoad(AotDetector.useGeneratedArtifacts());
/* 158 */       BeanFactory beanFactory = this.owner; if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/* 159 */         ClassLoader cl = cbf.getBeanClassLoader();
/* 160 */         enhancer.setStrategy((GeneratorStrategy)new ClassLoaderAwareGeneratorStrategy(cl)); }
/*     */       
/* 162 */       enhancer.setCallbackFilter(new CglibSubclassingInstantiationStrategy.MethodOverrideCallbackFilter(beanDefinition));
/* 163 */       enhancer.setCallbackTypes(CALLBACK_TYPES);
/* 164 */       return enhancer.createClass();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CglibIdentitySupport
/*     */   {
/*     */     private final RootBeanDefinition beanDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CglibIdentitySupport(RootBeanDefinition beanDefinition) {
/* 179 */       this.beanDefinition = beanDefinition;
/*     */     }
/*     */     
/*     */     public RootBeanDefinition getBeanDefinition() {
/* 183 */       return this.beanDefinition;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 188 */       return (other != null && getClass() == other.getClass() && this.beanDefinition
/* 189 */         .equals(((CglibIdentitySupport)other).beanDefinition));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 194 */       return this.beanDefinition.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MethodOverrideCallbackFilter
/*     */     extends CglibIdentitySupport
/*     */     implements CallbackFilter
/*     */   {
/* 204 */     private static final Log logger = LogFactory.getLog(MethodOverrideCallbackFilter.class);
/*     */     
/*     */     public MethodOverrideCallbackFilter(RootBeanDefinition beanDefinition) {
/* 207 */       super(beanDefinition);
/*     */     }
/*     */ 
/*     */     
/*     */     public int accept(Method method) {
/* 212 */       MethodOverride methodOverride = getBeanDefinition().getMethodOverrides().getOverride(method);
/* 213 */       if (logger.isTraceEnabled()) {
/* 214 */         logger.trace("MethodOverride for " + String.valueOf(method) + ": " + String.valueOf(methodOverride));
/*     */       }
/* 216 */       if (methodOverride == null) {
/* 217 */         return 0;
/*     */       }
/* 219 */       if (methodOverride instanceof LookupOverride) {
/* 220 */         return 1;
/*     */       }
/* 222 */       if (methodOverride instanceof ReplaceOverride) {
/* 223 */         return 2;
/*     */       }
/* 225 */       throw new UnsupportedOperationException("Unexpected MethodOverride subclass: " + methodOverride
/* 226 */           .getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LookupOverrideMethodInterceptor
/*     */     extends CglibIdentitySupport
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final BeanFactory owner;
/*     */ 
/*     */     
/*     */     public LookupOverrideMethodInterceptor(RootBeanDefinition beanDefinition, BeanFactory owner) {
/* 240 */       super(beanDefinition);
/* 241 */       this.owner = owner;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy mp) throws Throwable {
/* 248 */       LookupOverride lo = (LookupOverride)getBeanDefinition().getMethodOverrides().getOverride(method);
/* 249 */       Assert.state((lo != null), "LookupOverride not found");
/* 250 */       Object[] argsToUse = (args.length > 0) ? args : null;
/* 251 */       if (StringUtils.hasText(lo.getBeanName())) {
/*     */         
/* 253 */         Object bean = (argsToUse != null) ? this.owner.getBean(lo.getBeanName(), argsToUse) : this.owner.getBean(lo.getBeanName());
/*     */         
/* 255 */         return bean.equals((Object)null) ? null : bean;
/*     */       } 
/*     */ 
/*     */       
/* 259 */       ResolvableType genericReturnType = ResolvableType.forMethodReturnType(method);
/* 260 */       return (argsToUse != null) ? this.owner.getBeanProvider(genericReturnType).getObject(argsToUse) : 
/* 261 */         this.owner.getBeanProvider(genericReturnType).getObject();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ReplaceOverrideMethodInterceptor
/*     */     extends CglibIdentitySupport
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final BeanFactory owner;
/*     */ 
/*     */ 
/*     */     
/*     */     public ReplaceOverrideMethodInterceptor(RootBeanDefinition beanDefinition, BeanFactory owner) {
/* 276 */       super(beanDefinition);
/* 277 */       this.owner = owner;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy mp) throws Throwable {
/* 283 */       ReplaceOverride ro = (ReplaceOverride)getBeanDefinition().getMethodOverrides().getOverride(method);
/* 284 */       Assert.state((ro != null), "ReplaceOverride not found");
/* 285 */       MethodReplacer mr = (MethodReplacer)this.owner.getBean(ro.getMethodReplacerBeanName(), MethodReplacer.class);
/* 286 */       return processReturnType(method, mr.reimplement(obj, method, args));
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private <T> T processReturnType(Method method, @Nullable T returnValue) {
/* 291 */       Class<?> returnType = method.getReturnType();
/* 292 */       if (returnValue == null && returnType != void.class && returnType.isPrimitive()) {
/* 293 */         throw new IllegalStateException("Null return value from MethodReplacer does not match primitive return type for: " + String.valueOf(method));
/*     */       }
/*     */       
/* 296 */       return returnValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\CglibSubclassingInstantiationStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */