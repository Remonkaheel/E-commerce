/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AutowireUtils
/*     */ {
/*     */   public static final Comparator<Executable> EXECUTABLE_COMPARATOR;
/*     */   
/*     */   static {
/*  57 */     EXECUTABLE_COMPARATOR = ((e1, e2) -> {
/*     */         int result = Boolean.compare(Modifier.isPublic(e2.getModifiers()), Modifier.isPublic(e1.getModifiers()));
/*     */         return (result != 0) ? result : Integer.compare(e2.getParameterCount(), e1.getParameterCount());
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sortConstructors(Constructor<?>[] constructors) {
/*  71 */     Arrays.sort((Executable[])constructors, EXECUTABLE_COMPARATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sortFactoryMethods(Method[] factoryMethods) {
/*  82 */     Arrays.sort((Executable[])factoryMethods, EXECUTABLE_COMPARATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isExcludedFromDependencyCheck(PropertyDescriptor pd) {
/*  92 */     Method wm = pd.getWriteMethod();
/*  93 */     if (wm == null) {
/*  94 */       return false;
/*     */     }
/*  96 */     if (!wm.getDeclaringClass().getName().contains("$$"))
/*     */     {
/*  98 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 102 */     Class<?> superclass = wm.getDeclaringClass().getSuperclass();
/* 103 */     return !ClassUtils.hasMethod(superclass, wm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSetterDefinedInInterface(PropertyDescriptor pd, Set<Class<?>> interfaces) {
/* 114 */     Method setter = pd.getWriteMethod();
/* 115 */     if (setter != null) {
/* 116 */       Class<?> targetClass = setter.getDeclaringClass();
/* 117 */       for (Class<?> ifc : interfaces) {
/* 118 */         if (ifc.isAssignableFrom(targetClass) && ClassUtils.hasMethod(ifc, setter)) {
/* 119 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object resolveAutowiringValue(Object autowiringValue, Class<?> requiredType) {
/* 134 */     if (autowiringValue instanceof ObjectFactory) { ObjectFactory<?> factory = (ObjectFactory)autowiringValue; if (!requiredType.isInstance(autowiringValue))
/* 135 */         if (autowiringValue instanceof Serializable && requiredType.isInterface()) {
/* 136 */           autowiringValue = Proxy.newProxyInstance(requiredType.getClassLoader(), new Class[] { requiredType }, new ObjectFactoryDelegatingInvocationHandler(factory));
/*     */         }
/*     */         else {
/*     */           
/* 140 */           return factory.getObject();
/*     */         }   }
/*     */     
/* 143 */     return autowiringValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> resolveReturnTypeForFactoryMethod(Method method, Object[] args, @Nullable ClassLoader classLoader) {
/* 180 */     Assert.notNull(method, "Method must not be null");
/* 181 */     Assert.notNull(args, "Argument array must not be null");
/*     */     
/* 183 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])method.getTypeParameters();
/* 184 */     Type genericReturnType = method.getGenericReturnType();
/* 185 */     Type[] methodParameterTypes = method.getGenericParameterTypes();
/* 186 */     Assert.isTrue((args.length == methodParameterTypes.length), "Argument array does not match parameter count");
/*     */ 
/*     */ 
/*     */     
/* 190 */     boolean locallyDeclaredTypeVariableMatchesReturnType = false;
/* 191 */     for (TypeVariable<Method> currentTypeVariable : arrayOfTypeVariable) {
/* 192 */       if (currentTypeVariable.equals(genericReturnType)) {
/* 193 */         locallyDeclaredTypeVariableMatchesReturnType = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 198 */     if (locallyDeclaredTypeVariableMatchesReturnType) {
/* 199 */       for (int i = 0; i < methodParameterTypes.length; i++) {
/* 200 */         Type methodParameterType = methodParameterTypes[i];
/* 201 */         Object arg = args[i];
/* 202 */         if (methodParameterType.equals(genericReturnType)) {
/* 203 */           if (arg instanceof TypedStringValue) { TypedStringValue typedValue = (TypedStringValue)arg;
/* 204 */             if (typedValue.hasTargetType()) {
/* 205 */               return typedValue.getTargetType();
/*     */             }
/*     */             try {
/* 208 */               Class<?> resolvedType = typedValue.resolveTargetType(classLoader);
/* 209 */               if (resolvedType != null) {
/* 210 */                 return resolvedType;
/*     */               }
/*     */             }
/* 213 */             catch (ClassNotFoundException ex) {
/* 214 */               throw new IllegalStateException("Failed to resolve value type [" + typedValue
/* 215 */                   .getTargetTypeName() + "] for factory method argument", ex);
/*     */             }
/*     */              }
/* 218 */           else if (arg != null && !(arg instanceof org.springframework.beans.BeanMetadataElement))
/*     */           
/* 220 */           { return arg.getClass(); }
/*     */           
/* 222 */           return method.getReturnType();
/*     */         } 
/* 224 */         if (methodParameterType instanceof ParameterizedType) { ParameterizedType parameterizedType = (ParameterizedType)methodParameterType;
/* 225 */           Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
/* 226 */           for (Type typeArg : actualTypeArguments) {
/* 227 */             if (typeArg.equals(genericReturnType)) {
/* 228 */               if (arg instanceof Class) { Class<?> clazz = (Class)arg;
/* 229 */                 return clazz; }
/*     */ 
/*     */               
/* 232 */               String className = null;
/* 233 */               if (arg instanceof String) { String name = (String)arg;
/* 234 */                 className = name; }
/*     */               
/* 236 */               else if (arg instanceof TypedStringValue) { TypedStringValue typedValue = (TypedStringValue)arg;
/* 237 */                 String targetTypeName = typedValue.getTargetTypeName();
/* 238 */                 if (targetTypeName == null || Class.class.getName().equals(targetTypeName)) {
/* 239 */                   className = typedValue.getValue();
/*     */                 } }
/*     */               
/* 242 */               if (className != null) {
/*     */                 try {
/* 244 */                   return ClassUtils.forName(className, classLoader);
/*     */                 }
/* 246 */                 catch (ClassNotFoundException ex) {
/* 247 */                   throw new IllegalStateException("Could not resolve class name [" + String.valueOf(arg) + "] for factory method argument", ex);
/*     */                 } 
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 253 */               return method.getReturnType();
/*     */             } 
/*     */           }  }
/*     */       
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 262 */     return method.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAutowireCandidate(ConfigurableBeanFactory beanFactory, String beanName) {
/*     */     try {
/* 275 */       return beanFactory.getMergedBeanDefinition(beanName).isAutowireCandidate();
/*     */     }
/* 277 */     catch (NoSuchBeanDefinitionException ex) {
/*     */       
/* 279 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDefaultCandidate(ConfigurableBeanFactory beanFactory, String beanName) {
/*     */     try {
/* 293 */       BeanDefinition mbd = beanFactory.getMergedBeanDefinition(beanName);
/* 294 */       if (mbd instanceof AbstractBeanDefinition) { AbstractBeanDefinition abd = (AbstractBeanDefinition)mbd; if (abd.isDefaultCandidate()); return false; }
/*     */     
/* 296 */     } catch (NoSuchBeanDefinitionException ex) {
/*     */       
/* 298 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ObjectFactoryDelegatingInvocationHandler
/*     */     implements InvocationHandler, Serializable
/*     */   {
/*     */     private final ObjectFactory<?> objectFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     ObjectFactoryDelegatingInvocationHandler(ObjectFactory<?> objectFactory) {
/* 312 */       this.objectFactory = objectFactory;
/*     */     } public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Boolean bool;
/*     */       Integer integer;
/*     */       String str;
/* 317 */       switch (method.getName()) { case "equals":
/* 318 */           bool = Boolean.valueOf((proxy == args[0]));
/* 319 */         case "hashCode": integer = Integer.valueOf(System.identityHashCode(proxy));
/* 320 */         case "toString": str = this.objectFactory.toString(); }
/*     */       
/*     */       try {
/* 323 */         Object object = method.invoke(this.objectFactory.getObject(), args);
/*     */       }
/* 325 */       catch (InvocationTargetException ex) {
/* 326 */         throw ex.getTargetException();
/*     */       } 
/*     */       return object;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\support\AutowireUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */