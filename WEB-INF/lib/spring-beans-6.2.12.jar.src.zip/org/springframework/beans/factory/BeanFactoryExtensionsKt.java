package org.springframework.beans.factory;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.ResolvableType;

@Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000&\n\002\b\002\n\002\020\000\n\002\030\002\n\002\b\002\n\002\020\021\n\002\b\002\n\002\020\016\n\002\b\002\n\002\030\002\n\000\032\036\020\000\032\002H\001\"\n\b\000\020\001\030\001*\0020\002*\0020\003H\b¢\006\002\020\004\0322\020\000\032\002H\001\"\n\b\000\020\001\030\001*\0020\002*\0020\0032\022\020\005\032\n\022\006\b\001\022\0020\0020\006\"\0020\002H\b¢\006\002\020\007\032&\020\000\032\002H\001\"\n\b\000\020\001\030\001*\0020\002*\0020\0032\006\020\b\032\0020\tH\b¢\006\002\020\n\032\037\020\013\032\b\022\004\022\002H\0010\f\"\n\b\000\020\001\030\001*\0020\002*\0020\003H\b¨\006\r"}, d2 = {"getBean", "T", "", "Lorg/springframework/beans/factory/BeanFactory;", "(Lorg/springframework/beans/factory/BeanFactory;)Ljava/lang/Object;", "args", "", "(Lorg/springframework/beans/factory/BeanFactory;[Ljava/lang/Object;)Ljava/lang/Object;", "name", "", "(Lorg/springframework/beans/factory/BeanFactory;Ljava/lang/String;)Ljava/lang/Object;", "getBeanProvider", "Lorg/springframework/beans/factory/ObjectProvider;", "spring-beans"})
@SourceDebugExtension({"SMAP\nBeanFactoryExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BeanFactoryExtensions.kt\norg/springframework/beans/factory/BeanFactoryExtensionsKt\n*L\n1#1,66:1\n64#1:67\n64#1:68\n*S KotlinDebug\n*F\n+ 1 BeanFactoryExtensions.kt\norg/springframework/beans/factory/BeanFactoryExtensionsKt\n*L\n30#1:67\n53#1:68\n*E\n"})
public final class BeanFactoryExtensionsKt {
  @Metadata(mv = {1, 7, 0}, k = 1, xi = 176, d1 = {"\000\013\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001¨\006\002"}, d2 = {"org/springframework/beans/factory/BeanFactoryExtensionsKt$getBeanProvider$1", "Lorg/springframework/core/ParameterizedTypeReference;", "spring-beans"})
  @SourceDebugExtension({"SMAP\nBeanFactoryExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BeanFactoryExtensions.kt\norg/springframework/beans/factory/BeanFactoryExtensionsKt$getBeanProvider$1\n*L\n1#1,66:1\n*E\n"})
  public static final class BeanFactoryExtensionsKt$getBeanProvider$1 extends ParameterizedTypeReference<T> {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\BeanFactoryExtensionsKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */