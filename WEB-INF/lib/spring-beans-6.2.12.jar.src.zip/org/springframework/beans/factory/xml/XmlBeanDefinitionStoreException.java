/*    */ package org.springframework.beans.factory.xml;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlBeanDefinitionStoreException
/*    */   extends BeanDefinitionStoreException
/*    */ {
/*    */   public XmlBeanDefinitionStoreException(String resourceDescription, String msg, SAXException cause) {
/* 45 */     super(resourceDescription, msg, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLineNumber() {
/* 54 */     Throwable cause = getCause();
/* 55 */     if (cause instanceof SAXParseException) { SAXParseException parseEx = (SAXParseException)cause;
/* 56 */       return parseEx.getLineNumber(); }
/*    */     
/* 58 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\XmlBeanDefinitionStoreException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */