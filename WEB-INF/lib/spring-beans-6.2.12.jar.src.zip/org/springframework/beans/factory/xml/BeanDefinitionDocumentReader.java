package org.springframework.beans.factory.xml;

import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.w3c.dom.Document;

public interface BeanDefinitionDocumentReader {
  void registerBeanDefinitions(Document paramDocument, XmlReaderContext paramXmlReaderContext) throws BeanDefinitionStoreException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\BeanDefinitionDocumentReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */