package org.springframework.beans.factory.xml;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.lang.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public interface NamespaceHandler {
  void init();
  
  @Nullable
  BeanDefinition parse(Element paramElement, ParserContext paramParserContext);
  
  @Nullable
  BeanDefinitionHolder decorate(Node paramNode, BeanDefinitionHolder paramBeanDefinitionHolder, ParserContext paramParserContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\NamespaceHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */