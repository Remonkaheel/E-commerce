/*      */ package org.springframework.beans.factory.xml;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeanMetadataAttribute;
/*      */ import org.springframework.beans.BeanMetadataAttributeAccessor;
/*      */ import org.springframework.beans.PropertyValue;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*      */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*      */ import org.springframework.beans.factory.config.RuntimeBeanNameReference;
/*      */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*      */ import org.springframework.beans.factory.config.TypedStringValue;
/*      */ import org.springframework.beans.factory.parsing.BeanEntry;
/*      */ import org.springframework.beans.factory.parsing.ConstructorArgumentEntry;
/*      */ import org.springframework.beans.factory.parsing.ParseState;
/*      */ import org.springframework.beans.factory.parsing.PropertyEntry;
/*      */ import org.springframework.beans.factory.parsing.QualifierEntry;
/*      */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*      */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*      */ import org.springframework.beans.factory.support.LookupOverride;
/*      */ import org.springframework.beans.factory.support.ManagedArray;
/*      */ import org.springframework.beans.factory.support.ManagedList;
/*      */ import org.springframework.beans.factory.support.ManagedMap;
/*      */ import org.springframework.beans.factory.support.ManagedProperties;
/*      */ import org.springframework.beans.factory.support.ManagedSet;
/*      */ import org.springframework.beans.factory.support.MethodOverride;
/*      */ import org.springframework.beans.factory.support.MethodOverrides;
/*      */ import org.springframework.beans.factory.support.ReplaceOverride;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.PatternMatchUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.xml.DomUtils;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BeanDefinitionParserDelegate
/*      */ {
/*      */   public static final String BEANS_NAMESPACE_URI = "http://www.springframework.org/schema/beans";
/*      */   public static final String MULTI_VALUE_ATTRIBUTE_DELIMITERS = ",; ";
/*      */   public static final String TRUE_VALUE = "true";
/*      */   public static final String FALSE_VALUE = "false";
/*      */   public static final String DEFAULT_VALUE = "default";
/*      */   public static final String DESCRIPTION_ELEMENT = "description";
/*      */   public static final String AUTOWIRE_NO_VALUE = "no";
/*      */   public static final String AUTOWIRE_BY_NAME_VALUE = "byName";
/*      */   public static final String AUTOWIRE_BY_TYPE_VALUE = "byType";
/*      */   public static final String AUTOWIRE_CONSTRUCTOR_VALUE = "constructor";
/*      */   public static final String AUTOWIRE_AUTODETECT_VALUE = "autodetect";
/*      */   public static final String NAME_ATTRIBUTE = "name";
/*      */   public static final String BEAN_ELEMENT = "bean";
/*      */   public static final String META_ELEMENT = "meta";
/*      */   public static final String ID_ATTRIBUTE = "id";
/*      */   public static final String PARENT_ATTRIBUTE = "parent";
/*      */   public static final String CLASS_ATTRIBUTE = "class";
/*      */   public static final String ABSTRACT_ATTRIBUTE = "abstract";
/*      */   public static final String SCOPE_ATTRIBUTE = "scope";
/*      */   private static final String SINGLETON_ATTRIBUTE = "singleton";
/*      */   public static final String LAZY_INIT_ATTRIBUTE = "lazy-init";
/*      */   public static final String AUTOWIRE_ATTRIBUTE = "autowire";
/*      */   public static final String AUTOWIRE_CANDIDATE_ATTRIBUTE = "autowire-candidate";
/*      */   public static final String PRIMARY_ATTRIBUTE = "primary";
/*      */   public static final String DEPENDS_ON_ATTRIBUTE = "depends-on";
/*      */   public static final String INIT_METHOD_ATTRIBUTE = "init-method";
/*      */   public static final String DESTROY_METHOD_ATTRIBUTE = "destroy-method";
/*      */   public static final String FACTORY_METHOD_ATTRIBUTE = "factory-method";
/*      */   public static final String FACTORY_BEAN_ATTRIBUTE = "factory-bean";
/*      */   public static final String CONSTRUCTOR_ARG_ELEMENT = "constructor-arg";
/*      */   public static final String INDEX_ATTRIBUTE = "index";
/*      */   public static final String TYPE_ATTRIBUTE = "type";
/*      */   public static final String VALUE_TYPE_ATTRIBUTE = "value-type";
/*      */   public static final String KEY_TYPE_ATTRIBUTE = "key-type";
/*      */   public static final String PROPERTY_ELEMENT = "property";
/*      */   public static final String REF_ATTRIBUTE = "ref";
/*      */   public static final String VALUE_ATTRIBUTE = "value";
/*      */   public static final String LOOKUP_METHOD_ELEMENT = "lookup-method";
/*      */   public static final String REPLACED_METHOD_ELEMENT = "replaced-method";
/*      */   public static final String REPLACER_ATTRIBUTE = "replacer";
/*      */   public static final String ARG_TYPE_ELEMENT = "arg-type";
/*      */   public static final String ARG_TYPE_MATCH_ATTRIBUTE = "match";
/*      */   public static final String REF_ELEMENT = "ref";
/*      */   public static final String IDREF_ELEMENT = "idref";
/*      */   public static final String BEAN_REF_ATTRIBUTE = "bean";
/*      */   public static final String PARENT_REF_ATTRIBUTE = "parent";
/*      */   public static final String VALUE_ELEMENT = "value";
/*      */   public static final String NULL_ELEMENT = "null";
/*      */   public static final String ARRAY_ELEMENT = "array";
/*      */   public static final String LIST_ELEMENT = "list";
/*      */   public static final String SET_ELEMENT = "set";
/*      */   public static final String MAP_ELEMENT = "map";
/*      */   public static final String ENTRY_ELEMENT = "entry";
/*      */   public static final String KEY_ELEMENT = "key";
/*      */   public static final String KEY_ATTRIBUTE = "key";
/*      */   public static final String KEY_REF_ATTRIBUTE = "key-ref";
/*      */   public static final String VALUE_REF_ATTRIBUTE = "value-ref";
/*      */   public static final String PROPS_ELEMENT = "props";
/*      */   public static final String PROP_ELEMENT = "prop";
/*      */   public static final String MERGE_ATTRIBUTE = "merge";
/*      */   public static final String QUALIFIER_ELEMENT = "qualifier";
/*      */   public static final String QUALIFIER_ATTRIBUTE_ELEMENT = "attribute";
/*      */   public static final String DEFAULT_LAZY_INIT_ATTRIBUTE = "default-lazy-init";
/*      */   public static final String DEFAULT_MERGE_ATTRIBUTE = "default-merge";
/*      */   public static final String DEFAULT_AUTOWIRE_ATTRIBUTE = "default-autowire";
/*      */   public static final String DEFAULT_AUTOWIRE_CANDIDATES_ATTRIBUTE = "default-autowire-candidates";
/*      */   public static final String DEFAULT_INIT_METHOD_ATTRIBUTE = "default-init-method";
/*      */   public static final String DEFAULT_DESTROY_METHOD_ATTRIBUTE = "default-destroy-method";
/*  228 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   
/*      */   private final XmlReaderContext readerContext;
/*      */   
/*  232 */   private final DocumentDefaultsDefinition defaults = new DocumentDefaultsDefinition();
/*      */   
/*  234 */   private final ParseState parseState = new ParseState();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  241 */   private final Set<String> usedNames = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDefinitionParserDelegate(XmlReaderContext readerContext) {
/*  249 */     Assert.notNull(readerContext, "XmlReaderContext must not be null");
/*  250 */     this.readerContext = readerContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final XmlReaderContext getReaderContext() {
/*  258 */     return this.readerContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object extractSource(Element ele) {
/*  267 */     return this.readerContext.extractSource(ele);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void error(String message, Node source) {
/*  274 */     this.readerContext.error(message, source, this.parseState.snapshot());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void error(String message, Element source) {
/*  281 */     this.readerContext.error(message, source, this.parseState.snapshot());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void error(String message, Element source, Throwable cause) {
/*  288 */     this.readerContext.error(message, source, this.parseState.snapshot(), cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initDefaults(Element root) {
/*  296 */     initDefaults(root, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initDefaults(Element root, @Nullable BeanDefinitionParserDelegate parent) {
/*  308 */     populateDefaults(this.defaults, (parent != null) ? parent.defaults : null, root);
/*  309 */     this.readerContext.fireDefaultsRegistered(this.defaults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void populateDefaults(DocumentDefaultsDefinition defaults, @Nullable DocumentDefaultsDefinition parentDefaults, Element root) {
/*  322 */     String lazyInit = root.getAttribute("default-lazy-init");
/*  323 */     if (isDefaultValue(lazyInit))
/*      */     {
/*  325 */       lazyInit = (parentDefaults != null) ? parentDefaults.getLazyInit() : "false";
/*      */     }
/*  327 */     defaults.setLazyInit(lazyInit);
/*      */     
/*  329 */     String merge = root.getAttribute("default-merge");
/*  330 */     if (isDefaultValue(merge))
/*      */     {
/*  332 */       merge = (parentDefaults != null) ? parentDefaults.getMerge() : "false";
/*      */     }
/*  334 */     defaults.setMerge(merge);
/*      */     
/*  336 */     String autowire = root.getAttribute("default-autowire");
/*  337 */     if (isDefaultValue(autowire))
/*      */     {
/*  339 */       autowire = (parentDefaults != null) ? parentDefaults.getAutowire() : "no";
/*      */     }
/*  341 */     defaults.setAutowire(autowire);
/*      */     
/*  343 */     if (root.hasAttribute("default-autowire-candidates")) {
/*  344 */       defaults.setAutowireCandidates(root.getAttribute("default-autowire-candidates"));
/*      */     }
/*  346 */     else if (parentDefaults != null) {
/*  347 */       defaults.setAutowireCandidates(parentDefaults.getAutowireCandidates());
/*      */     } 
/*      */     
/*  350 */     if (root.hasAttribute("default-init-method")) {
/*  351 */       defaults.setInitMethod(root.getAttribute("default-init-method"));
/*      */     }
/*  353 */     else if (parentDefaults != null) {
/*  354 */       defaults.setInitMethod(parentDefaults.getInitMethod());
/*      */     } 
/*      */     
/*  357 */     if (root.hasAttribute("default-destroy-method")) {
/*  358 */       defaults.setDestroyMethod(root.getAttribute("default-destroy-method"));
/*      */     }
/*  360 */     else if (parentDefaults != null) {
/*  361 */       defaults.setDestroyMethod(parentDefaults.getDestroyMethod());
/*      */     } 
/*      */     
/*  364 */     defaults.setSource(this.readerContext.extractSource(root));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DocumentDefaultsDefinition getDefaults() {
/*  371 */     return this.defaults;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDefinitionDefaults getBeanDefinitionDefaults() {
/*  379 */     BeanDefinitionDefaults bdd = new BeanDefinitionDefaults();
/*  380 */     bdd.setLazyInit("true".equalsIgnoreCase(this.defaults.getLazyInit()));
/*  381 */     bdd.setAutowireMode(getAutowireMode("default"));
/*  382 */     bdd.setInitMethodName(this.defaults.getInitMethod());
/*  383 */     bdd.setDestroyMethodName(this.defaults.getDestroyMethod());
/*  384 */     return bdd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String[] getAutowireCandidatePatterns() {
/*  393 */     String candidatePattern = this.defaults.getAutowireCandidates();
/*  394 */     return (candidatePattern != null) ? StringUtils.commaDelimitedListToStringArray(candidatePattern) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanDefinitionHolder parseBeanDefinitionElement(Element ele) {
/*  405 */     return parseBeanDefinitionElement(ele, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanDefinitionHolder parseBeanDefinitionElement(Element ele, @Nullable BeanDefinition containingBean) {
/*  416 */     String id = ele.getAttribute("id");
/*  417 */     String nameAttr = ele.getAttribute("name");
/*      */     
/*  419 */     List<String> aliases = new ArrayList<>();
/*  420 */     if (StringUtils.hasLength(nameAttr)) {
/*  421 */       String[] nameArr = StringUtils.tokenizeToStringArray(nameAttr, ",; ");
/*  422 */       aliases.addAll(Arrays.asList(nameArr));
/*      */     } 
/*      */     
/*  425 */     String beanName = id;
/*  426 */     if (!StringUtils.hasText(beanName) && !aliases.isEmpty()) {
/*  427 */       beanName = aliases.remove(0);
/*  428 */       if (this.logger.isTraceEnabled()) {
/*  429 */         this.logger.trace("No XML 'id' specified - using '" + beanName + "' as bean name and " + String.valueOf(aliases) + " as aliases");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  434 */     if (containingBean == null) {
/*  435 */       checkNameUniqueness(beanName, aliases, ele);
/*      */     }
/*      */     
/*  438 */     AbstractBeanDefinition beanDefinition = parseBeanDefinitionElement(ele, beanName, containingBean);
/*  439 */     if (beanDefinition != null) {
/*  440 */       if (!StringUtils.hasText(beanName)) {
/*      */         try {
/*  442 */           if (containingBean != null) {
/*  443 */             beanName = BeanDefinitionReaderUtils.generateBeanName((BeanDefinition)beanDefinition, this.readerContext
/*  444 */                 .getRegistry(), true);
/*      */           } else {
/*      */             
/*  447 */             beanName = this.readerContext.generateBeanName((BeanDefinition)beanDefinition);
/*      */ 
/*      */ 
/*      */             
/*  451 */             String beanClassName = beanDefinition.getBeanClassName();
/*  452 */             if (beanClassName != null && beanName
/*  453 */               .startsWith(beanClassName) && beanName.length() > beanClassName.length() && 
/*  454 */               !this.readerContext.getRegistry().isBeanNameInUse(beanClassName)) {
/*  455 */               aliases.add(beanClassName);
/*      */             }
/*      */           } 
/*  458 */           if (this.logger.isTraceEnabled()) {
/*  459 */             this.logger.trace("Neither XML 'id' nor 'name' specified - using generated bean name [" + beanName + "]");
/*      */           
/*      */           }
/*      */         }
/*  463 */         catch (Exception ex) {
/*  464 */           error(ex.getMessage(), ele);
/*  465 */           return null;
/*      */         } 
/*      */       }
/*  468 */       String[] aliasesArray = StringUtils.toStringArray(aliases);
/*  469 */       return new BeanDefinitionHolder((BeanDefinition)beanDefinition, beanName, aliasesArray);
/*      */     } 
/*      */     
/*  472 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkNameUniqueness(String beanName, List<String> aliases, Element beanElement) {
/*  480 */     String foundName = null;
/*      */     
/*  482 */     if (StringUtils.hasText(beanName) && this.usedNames.contains(beanName)) {
/*  483 */       foundName = beanName;
/*      */     }
/*  485 */     if (foundName == null) {
/*  486 */       foundName = (String)CollectionUtils.findFirstMatch(this.usedNames, aliases);
/*      */     }
/*  488 */     if (foundName != null) {
/*  489 */       error("Bean name '" + foundName + "' is already used in this <beans> element", beanElement);
/*      */     }
/*      */     
/*  492 */     this.usedNames.add(beanName);
/*  493 */     this.usedNames.addAll(aliases);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public AbstractBeanDefinition parseBeanDefinitionElement(Element ele, String beanName, @Nullable BeanDefinition containingBean) {
/*  504 */     this.parseState.push((ParseState.Entry)new BeanEntry(beanName));
/*      */     
/*  506 */     String className = null;
/*  507 */     if (ele.hasAttribute("class")) {
/*  508 */       className = ele.getAttribute("class").trim();
/*      */     }
/*  510 */     String parent = null;
/*  511 */     if (ele.hasAttribute("parent")) {
/*  512 */       parent = ele.getAttribute("parent");
/*      */     }
/*      */     
/*      */     try {
/*  516 */       AbstractBeanDefinition bd = createBeanDefinition(className, parent);
/*      */       
/*  518 */       parseBeanDefinitionAttributes(ele, beanName, containingBean, bd);
/*  519 */       bd.setDescription(DomUtils.getChildElementValueByTagName(ele, "description"));
/*      */       
/*  521 */       parseMetaElements(ele, (BeanMetadataAttributeAccessor)bd);
/*  522 */       parseLookupOverrideSubElements(ele, bd.getMethodOverrides());
/*  523 */       parseReplacedMethodSubElements(ele, bd.getMethodOverrides());
/*      */       
/*  525 */       parseConstructorArgElements(ele, (BeanDefinition)bd);
/*  526 */       parsePropertyElements(ele, (BeanDefinition)bd);
/*  527 */       parseQualifierElements(ele, bd);
/*      */       
/*  529 */       bd.setResource(this.readerContext.getResource());
/*  530 */       bd.setSource(extractSource(ele));
/*      */       
/*  532 */       return bd;
/*      */     }
/*  534 */     catch (ClassNotFoundException ex) {
/*  535 */       error("Bean class [" + className + "] not found", ele, ex);
/*      */     }
/*  537 */     catch (NoClassDefFoundError err) {
/*  538 */       error("Class that bean class [" + className + "] depends on not found", ele, err);
/*      */     }
/*  540 */     catch (Throwable ex) {
/*  541 */       error("Unexpected failure during bean definition parsing", ele, ex);
/*      */     } finally {
/*      */       
/*  544 */       this.parseState.pop();
/*      */     } 
/*      */     
/*  547 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractBeanDefinition parseBeanDefinitionAttributes(Element ele, String beanName, @Nullable BeanDefinition containingBean, AbstractBeanDefinition bd) {
/*  560 */     if (ele.hasAttribute("singleton")) {
/*  561 */       error("Old 1.x 'singleton' attribute in use - upgrade to 'scope' declaration", ele);
/*      */     }
/*  563 */     else if (ele.hasAttribute("scope")) {
/*  564 */       bd.setScope(ele.getAttribute("scope"));
/*      */     }
/*  566 */     else if (containingBean != null) {
/*      */       
/*  568 */       bd.setScope(containingBean.getScope());
/*      */     } 
/*      */     
/*  571 */     if (ele.hasAttribute("abstract")) {
/*  572 */       bd.setAbstract("true".equals(ele.getAttribute("abstract")));
/*      */     }
/*      */     
/*  575 */     String lazyInit = ele.getAttribute("lazy-init");
/*  576 */     if (isDefaultValue(lazyInit)) {
/*  577 */       lazyInit = this.defaults.getLazyInit();
/*      */     }
/*  579 */     bd.setLazyInit("true".equals(lazyInit));
/*      */     
/*  581 */     String autowire = ele.getAttribute("autowire");
/*  582 */     bd.setAutowireMode(getAutowireMode(autowire));
/*      */     
/*  584 */     if (ele.hasAttribute("depends-on")) {
/*  585 */       String dependsOn = ele.getAttribute("depends-on");
/*  586 */       bd.setDependsOn(StringUtils.tokenizeToStringArray(dependsOn, ",; "));
/*      */     } 
/*      */     
/*  589 */     String autowireCandidate = ele.getAttribute("autowire-candidate");
/*  590 */     if (isDefaultValue(autowireCandidate)) {
/*  591 */       String candidatePattern = this.defaults.getAutowireCandidates();
/*  592 */       if (candidatePattern != null) {
/*  593 */         String[] patterns = StringUtils.commaDelimitedListToStringArray(candidatePattern);
/*  594 */         bd.setAutowireCandidate(PatternMatchUtils.simpleMatch(patterns, beanName));
/*      */       } 
/*      */     } else {
/*      */       
/*  598 */       bd.setAutowireCandidate("true".equals(autowireCandidate));
/*      */     } 
/*      */     
/*  601 */     if (ele.hasAttribute("primary")) {
/*  602 */       bd.setPrimary("true".equals(ele.getAttribute("primary")));
/*      */     }
/*      */     
/*  605 */     if (ele.hasAttribute("init-method")) {
/*  606 */       String initMethodName = ele.getAttribute("init-method");
/*  607 */       bd.setInitMethodName(initMethodName);
/*      */     }
/*  609 */     else if (this.defaults.getInitMethod() != null) {
/*  610 */       bd.setInitMethodName(this.defaults.getInitMethod());
/*  611 */       bd.setEnforceInitMethod(false);
/*      */     } 
/*      */     
/*  614 */     if (ele.hasAttribute("destroy-method")) {
/*  615 */       String destroyMethodName = ele.getAttribute("destroy-method");
/*  616 */       bd.setDestroyMethodName(destroyMethodName);
/*      */     }
/*  618 */     else if (this.defaults.getDestroyMethod() != null) {
/*  619 */       bd.setDestroyMethodName(this.defaults.getDestroyMethod());
/*  620 */       bd.setEnforceDestroyMethod(false);
/*      */     } 
/*      */     
/*  623 */     if (ele.hasAttribute("factory-method")) {
/*  624 */       bd.setFactoryMethodName(ele.getAttribute("factory-method"));
/*      */     }
/*  626 */     if (ele.hasAttribute("factory-bean")) {
/*  627 */       bd.setFactoryBeanName(ele.getAttribute("factory-bean"));
/*      */     }
/*      */     
/*  630 */     return bd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractBeanDefinition createBeanDefinition(@Nullable String className, @Nullable String parentName) throws ClassNotFoundException {
/*  643 */     return BeanDefinitionReaderUtils.createBeanDefinition(parentName, className, this.readerContext
/*  644 */         .getBeanClassLoader());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseMetaElements(Element ele, BeanMetadataAttributeAccessor attributeAccessor) {
/*  651 */     NodeList nl = ele.getChildNodes();
/*  652 */     for (int i = 0; i < nl.getLength(); i++) {
/*  653 */       Node node = nl.item(i);
/*  654 */       if (isCandidateElement(node) && nodeNameEquals(node, "meta")) {
/*  655 */         Element metaElement = (Element)node;
/*  656 */         String key = metaElement.getAttribute("key");
/*  657 */         String value = metaElement.getAttribute("value");
/*  658 */         BeanMetadataAttribute attribute = new BeanMetadataAttribute(key, value);
/*  659 */         attribute.setSource(extractSource(metaElement));
/*  660 */         attributeAccessor.addMetadataAttribute(attribute);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAutowireMode(String attrValue) {
/*  671 */     String attr = attrValue;
/*  672 */     if (isDefaultValue(attr)) {
/*  673 */       attr = this.defaults.getAutowire();
/*      */     }
/*  675 */     int autowire = 0;
/*  676 */     if ("byName".equals(attr)) {
/*  677 */       autowire = 1;
/*      */     }
/*  679 */     else if ("byType".equals(attr)) {
/*  680 */       autowire = 2;
/*      */     }
/*  682 */     else if ("constructor".equals(attr)) {
/*  683 */       autowire = 3;
/*      */     }
/*  685 */     else if ("autodetect".equals(attr)) {
/*  686 */       autowire = 4;
/*      */     } 
/*      */     
/*  689 */     return autowire;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseConstructorArgElements(Element beanEle, BeanDefinition bd) {
/*  696 */     NodeList nl = beanEle.getChildNodes();
/*  697 */     for (int i = 0; i < nl.getLength(); i++) {
/*  698 */       Node node = nl.item(i);
/*  699 */       if (isCandidateElement(node) && nodeNameEquals(node, "constructor-arg")) {
/*  700 */         parseConstructorArgElement((Element)node, bd);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parsePropertyElements(Element beanEle, BeanDefinition bd) {
/*  709 */     NodeList nl = beanEle.getChildNodes();
/*  710 */     for (int i = 0; i < nl.getLength(); i++) {
/*  711 */       Node node = nl.item(i);
/*  712 */       if (isCandidateElement(node) && nodeNameEquals(node, "property")) {
/*  713 */         parsePropertyElement((Element)node, bd);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseQualifierElements(Element beanEle, AbstractBeanDefinition bd) {
/*  722 */     NodeList nl = beanEle.getChildNodes();
/*  723 */     for (int i = 0; i < nl.getLength(); i++) {
/*  724 */       Node node = nl.item(i);
/*  725 */       if (isCandidateElement(node) && nodeNameEquals(node, "qualifier")) {
/*  726 */         parseQualifierElement((Element)node, bd);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseLookupOverrideSubElements(Element beanEle, MethodOverrides overrides) {
/*  735 */     NodeList nl = beanEle.getChildNodes();
/*  736 */     for (int i = 0; i < nl.getLength(); i++) {
/*  737 */       Node node = nl.item(i);
/*  738 */       if (isCandidateElement(node) && nodeNameEquals(node, "lookup-method")) {
/*  739 */         Element ele = (Element)node;
/*  740 */         String methodName = ele.getAttribute("name");
/*  741 */         String beanRef = ele.getAttribute("bean");
/*  742 */         LookupOverride override = new LookupOverride(methodName, beanRef);
/*  743 */         override.setSource(extractSource(ele));
/*  744 */         overrides.addOverride((MethodOverride)override);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseReplacedMethodSubElements(Element beanEle, MethodOverrides overrides) {
/*  753 */     NodeList nl = beanEle.getChildNodes();
/*  754 */     for (int i = 0; i < nl.getLength(); i++) {
/*  755 */       Node node = nl.item(i);
/*  756 */       if (isCandidateElement(node) && nodeNameEquals(node, "replaced-method")) {
/*  757 */         Element replacedMethodEle = (Element)node;
/*  758 */         String name = replacedMethodEle.getAttribute("name");
/*  759 */         String callback = replacedMethodEle.getAttribute("replacer");
/*  760 */         ReplaceOverride replaceOverride = new ReplaceOverride(name, callback);
/*      */         
/*  762 */         List<Element> argTypeEles = DomUtils.getChildElementsByTagName(replacedMethodEle, "arg-type");
/*  763 */         for (Element argTypeEle : argTypeEles) {
/*  764 */           String match = argTypeEle.getAttribute("match");
/*  765 */           match = StringUtils.hasText(match) ? match : DomUtils.getTextValue(argTypeEle);
/*  766 */           if (StringUtils.hasText(match)) {
/*  767 */             replaceOverride.addTypeIdentifier(match);
/*      */           }
/*      */         } 
/*  770 */         replaceOverride.setSource(extractSource(replacedMethodEle));
/*  771 */         overrides.addOverride((MethodOverride)replaceOverride);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseConstructorArgElement(Element ele, BeanDefinition bd) {
/*  780 */     String indexAttr = ele.getAttribute("index");
/*  781 */     String typeAttr = ele.getAttribute("type");
/*  782 */     String nameAttr = ele.getAttribute("name");
/*  783 */     if (StringUtils.hasLength(indexAttr)) {
/*      */       try {
/*  785 */         int index = Integer.parseInt(indexAttr);
/*  786 */         if (index < 0) {
/*  787 */           error("'index' cannot be lower than 0", ele);
/*      */         } else {
/*      */           
/*      */           try {
/*  791 */             this.parseState.push((ParseState.Entry)new ConstructorArgumentEntry(index));
/*  792 */             Object value = parsePropertyValue(ele, bd, null);
/*  793 */             ConstructorArgumentValues.ValueHolder valueHolder = new ConstructorArgumentValues.ValueHolder(value);
/*  794 */             if (StringUtils.hasLength(typeAttr)) {
/*  795 */               valueHolder.setType(typeAttr);
/*      */             }
/*  797 */             if (StringUtils.hasLength(nameAttr)) {
/*  798 */               valueHolder.setName(nameAttr);
/*      */             }
/*  800 */             valueHolder.setSource(extractSource(ele));
/*  801 */             if (bd.getConstructorArgumentValues().hasIndexedArgumentValue(index)) {
/*  802 */               error("Ambiguous constructor-arg entries for index " + index, ele);
/*      */             } else {
/*      */               
/*  805 */               bd.getConstructorArgumentValues().addIndexedArgumentValue(index, valueHolder);
/*      */             } 
/*      */           } finally {
/*      */             
/*  809 */             this.parseState.pop();
/*      */           }
/*      */         
/*      */         } 
/*  813 */       } catch (NumberFormatException ex) {
/*  814 */         error("Attribute 'index' of tag 'constructor-arg' must be an integer", ele);
/*      */       } 
/*      */     } else {
/*      */       
/*      */       try {
/*  819 */         this.parseState.push((ParseState.Entry)new ConstructorArgumentEntry());
/*  820 */         Object value = parsePropertyValue(ele, bd, null);
/*  821 */         ConstructorArgumentValues.ValueHolder valueHolder = new ConstructorArgumentValues.ValueHolder(value);
/*  822 */         if (StringUtils.hasLength(typeAttr)) {
/*  823 */           valueHolder.setType(typeAttr);
/*      */         }
/*  825 */         if (StringUtils.hasLength(nameAttr)) {
/*  826 */           valueHolder.setName(nameAttr);
/*      */         }
/*  828 */         valueHolder.setSource(extractSource(ele));
/*  829 */         bd.getConstructorArgumentValues().addGenericArgumentValue(valueHolder);
/*      */       } finally {
/*      */         
/*  832 */         this.parseState.pop();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parsePropertyElement(Element ele, BeanDefinition bd) {
/*  841 */     String propertyName = ele.getAttribute("name");
/*  842 */     if (!StringUtils.hasLength(propertyName)) {
/*  843 */       error("Tag 'property' must have a 'name' attribute", ele);
/*      */       return;
/*      */     } 
/*  846 */     this.parseState.push((ParseState.Entry)new PropertyEntry(propertyName));
/*      */     try {
/*  848 */       if (bd.getPropertyValues().contains(propertyName)) {
/*  849 */         error("Multiple 'property' definitions for property '" + propertyName + "'", ele);
/*      */         return;
/*      */       } 
/*  852 */       Object val = parsePropertyValue(ele, bd, propertyName);
/*  853 */       PropertyValue pv = new PropertyValue(propertyName, val);
/*  854 */       parseMetaElements(ele, (BeanMetadataAttributeAccessor)pv);
/*  855 */       pv.setSource(extractSource(ele));
/*  856 */       bd.getPropertyValues().addPropertyValue(pv);
/*      */     } finally {
/*      */       
/*  859 */       this.parseState.pop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseQualifierElement(Element ele, AbstractBeanDefinition bd) {
/*  867 */     String typeName = ele.getAttribute("type");
/*  868 */     if (!StringUtils.hasLength(typeName)) {
/*  869 */       error("Tag 'qualifier' must have a 'type' attribute", ele);
/*      */       return;
/*      */     } 
/*  872 */     this.parseState.push((ParseState.Entry)new QualifierEntry(typeName));
/*      */     try {
/*  874 */       AutowireCandidateQualifier qualifier = new AutowireCandidateQualifier(typeName);
/*  875 */       qualifier.setSource(extractSource(ele));
/*  876 */       String value = ele.getAttribute("value");
/*  877 */       if (StringUtils.hasLength(value)) {
/*  878 */         qualifier.setAttribute("value", value);
/*      */       }
/*  880 */       NodeList nl = ele.getChildNodes();
/*  881 */       for (int i = 0; i < nl.getLength(); i++) {
/*  882 */         Node node = nl.item(i);
/*  883 */         if (isCandidateElement(node) && nodeNameEquals(node, "attribute")) {
/*  884 */           Element attributeEle = (Element)node;
/*  885 */           String attributeName = attributeEle.getAttribute("key");
/*  886 */           String attributeValue = attributeEle.getAttribute("value");
/*  887 */           if (StringUtils.hasLength(attributeName) && StringUtils.hasLength(attributeValue)) {
/*  888 */             BeanMetadataAttribute attribute = new BeanMetadataAttribute(attributeName, attributeValue);
/*  889 */             attribute.setSource(extractSource(attributeEle));
/*  890 */             qualifier.addMetadataAttribute(attribute);
/*      */           } else {
/*      */             
/*  893 */             error("Qualifier 'attribute' tag must have a 'key' and 'value'", attributeEle);
/*      */             return;
/*      */           } 
/*      */         } 
/*      */       } 
/*  898 */       bd.addQualifier(qualifier);
/*      */     } finally {
/*      */       
/*  901 */       this.parseState.pop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object parsePropertyValue(Element ele, BeanDefinition bd, @Nullable String propertyName) {
/*  913 */     String elementName = (propertyName != null) ? ("<property> element for property '" + propertyName + "'") : "<constructor-arg> element";
/*      */ 
/*      */     
/*  916 */     NodeList nl = ele.getChildNodes();
/*  917 */     Element subElement = null;
/*  918 */     for (int i = 0; i < nl.getLength(); i++) {
/*  919 */       Node node = nl.item(i);
/*  920 */       if (node instanceof Element) { Element currentElement = (Element)node; if (!nodeNameEquals(node, "description") && 
/*  921 */           !nodeNameEquals(node, "meta"))
/*      */         {
/*  923 */           if (subElement != null) {
/*  924 */             error(elementName + " must not contain more than one sub-element", ele);
/*      */           } else {
/*      */             
/*  927 */             subElement = currentElement;
/*      */           } 
/*      */         } }
/*      */     
/*      */     } 
/*  932 */     boolean hasRefAttribute = ele.hasAttribute("ref");
/*  933 */     boolean hasValueAttribute = ele.hasAttribute("value");
/*  934 */     if ((hasRefAttribute && hasValueAttribute) || ((hasRefAttribute || hasValueAttribute) && subElement != null))
/*      */     {
/*  936 */       error(elementName + " is only allowed to contain either 'ref' attribute OR 'value' attribute OR sub-element", ele);
/*      */     }
/*      */ 
/*      */     
/*  940 */     if (hasRefAttribute) {
/*  941 */       String refName = ele.getAttribute("ref");
/*  942 */       if (!StringUtils.hasText(refName)) {
/*  943 */         error(elementName + " contains empty 'ref' attribute", ele);
/*      */       }
/*  945 */       RuntimeBeanReference ref = new RuntimeBeanReference(refName);
/*  946 */       ref.setSource(extractSource(ele));
/*  947 */       return ref;
/*      */     } 
/*  949 */     if (hasValueAttribute) {
/*  950 */       TypedStringValue valueHolder = new TypedStringValue(ele.getAttribute("value"));
/*  951 */       valueHolder.setSource(extractSource(ele));
/*  952 */       return valueHolder;
/*      */     } 
/*  954 */     if (subElement != null) {
/*  955 */       return parsePropertySubElement(subElement, bd);
/*      */     }
/*      */ 
/*      */     
/*  959 */     error(elementName + " must specify a ref or value", ele);
/*  960 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object parsePropertySubElement(Element ele, @Nullable BeanDefinition bd) {
/*  972 */     return parsePropertySubElement(ele, bd, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object parsePropertySubElement(Element ele, @Nullable BeanDefinition bd, @Nullable String defaultValueType) {
/*  985 */     if (!isDefaultNamespace(ele)) {
/*  986 */       return parseNestedCustomElement(ele, bd);
/*      */     }
/*  988 */     if (nodeNameEquals(ele, "bean")) {
/*  989 */       BeanDefinitionHolder nestedBd = parseBeanDefinitionElement(ele, bd);
/*  990 */       if (nestedBd != null) {
/*  991 */         nestedBd = decorateBeanDefinitionIfRequired(ele, nestedBd, bd);
/*      */       }
/*  993 */       return nestedBd;
/*      */     } 
/*  995 */     if (nodeNameEquals(ele, "ref")) {
/*      */       
/*  997 */       String refName = ele.getAttribute("bean");
/*  998 */       boolean toParent = false;
/*  999 */       if (!StringUtils.hasLength(refName)) {
/*      */         
/* 1001 */         refName = ele.getAttribute("parent");
/* 1002 */         toParent = true;
/* 1003 */         if (!StringUtils.hasLength(refName)) {
/* 1004 */           error("'bean' or 'parent' is required for <ref> element", ele);
/* 1005 */           return null;
/*      */         } 
/*      */       } 
/* 1008 */       if (!StringUtils.hasText(refName)) {
/* 1009 */         error("<ref> element contains empty target attribute", ele);
/* 1010 */         return null;
/*      */       } 
/* 1012 */       RuntimeBeanReference ref = new RuntimeBeanReference(refName, toParent);
/* 1013 */       ref.setSource(extractSource(ele));
/* 1014 */       return ref;
/*      */     } 
/* 1016 */     if (nodeNameEquals(ele, "idref")) {
/* 1017 */       return parseIdRefElement(ele);
/*      */     }
/* 1019 */     if (nodeNameEquals(ele, "value")) {
/* 1020 */       return parseValueElement(ele, defaultValueType);
/*      */     }
/* 1022 */     if (nodeNameEquals(ele, "null")) {
/*      */ 
/*      */       
/* 1025 */       TypedStringValue nullHolder = new TypedStringValue(null);
/* 1026 */       nullHolder.setSource(extractSource(ele));
/* 1027 */       return nullHolder;
/*      */     } 
/* 1029 */     if (nodeNameEquals(ele, "array")) {
/* 1030 */       return parseArrayElement(ele, bd);
/*      */     }
/* 1032 */     if (nodeNameEquals(ele, "list")) {
/* 1033 */       return parseListElement(ele, bd);
/*      */     }
/* 1035 */     if (nodeNameEquals(ele, "set")) {
/* 1036 */       return parseSetElement(ele, bd);
/*      */     }
/* 1038 */     if (nodeNameEquals(ele, "map")) {
/* 1039 */       return parseMapElement(ele, bd);
/*      */     }
/* 1041 */     if (nodeNameEquals(ele, "props")) {
/* 1042 */       return parsePropsElement(ele);
/*      */     }
/*      */     
/* 1045 */     error("Unknown property sub-element: [" + ele.getNodeName() + "]", ele);
/* 1046 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object parseIdRefElement(Element ele) {
/* 1056 */     String refName = ele.getAttribute("bean");
/* 1057 */     if (!StringUtils.hasLength(refName)) {
/* 1058 */       error("'bean' is required for <idref> element", ele);
/* 1059 */       return null;
/*      */     } 
/* 1061 */     if (!StringUtils.hasText(refName)) {
/* 1062 */       error("<idref> element contains empty target attribute", ele);
/* 1063 */       return null;
/*      */     } 
/* 1065 */     RuntimeBeanNameReference ref = new RuntimeBeanNameReference(refName);
/* 1066 */     ref.setSource(extractSource(ele));
/* 1067 */     return ref;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object parseValueElement(Element ele, @Nullable String defaultTypeName) {
/* 1075 */     String value = DomUtils.getTextValue(ele);
/* 1076 */     String specifiedTypeName = ele.getAttribute("type");
/* 1077 */     String typeName = specifiedTypeName;
/* 1078 */     if (!StringUtils.hasText(typeName)) {
/* 1079 */       typeName = defaultTypeName;
/*      */     }
/*      */     try {
/* 1082 */       TypedStringValue typedValue = buildTypedStringValue(value, typeName);
/* 1083 */       typedValue.setSource(extractSource(ele));
/* 1084 */       typedValue.setSpecifiedTypeName(specifiedTypeName);
/* 1085 */       return typedValue;
/*      */     }
/* 1087 */     catch (ClassNotFoundException ex) {
/* 1088 */       error("Type class [" + typeName + "] not found for <value> element", ele, ex);
/* 1089 */       return value;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypedStringValue buildTypedStringValue(String value, @Nullable String targetTypeName) throws ClassNotFoundException {
/*      */     TypedStringValue typedValue;
/* 1100 */     ClassLoader classLoader = this.readerContext.getBeanClassLoader();
/*      */     
/* 1102 */     if (!StringUtils.hasText(targetTypeName)) {
/* 1103 */       typedValue = new TypedStringValue(value);
/*      */     }
/* 1105 */     else if (classLoader != null) {
/* 1106 */       Class<?> targetType = ClassUtils.forName(targetTypeName, classLoader);
/* 1107 */       typedValue = new TypedStringValue(value, targetType);
/*      */     } else {
/*      */       
/* 1110 */       typedValue = new TypedStringValue(value, targetTypeName);
/*      */     } 
/* 1112 */     return typedValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object parseArrayElement(Element arrayEle, @Nullable BeanDefinition bd) {
/* 1119 */     String elementType = arrayEle.getAttribute("value-type");
/* 1120 */     NodeList nl = arrayEle.getChildNodes();
/* 1121 */     ManagedArray target = new ManagedArray(elementType, nl.getLength());
/* 1122 */     target.setSource(extractSource(arrayEle));
/* 1123 */     target.setElementTypeName(elementType);
/* 1124 */     target.setMergeEnabled(parseMergeAttribute(arrayEle));
/* 1125 */     parseCollectionElements(nl, (Collection<Object>)target, bd, elementType);
/* 1126 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Object> parseListElement(Element collectionEle, @Nullable BeanDefinition bd) {
/* 1133 */     String defaultElementType = collectionEle.getAttribute("value-type");
/* 1134 */     NodeList nl = collectionEle.getChildNodes();
/* 1135 */     ManagedList<Object> target = new ManagedList(nl.getLength());
/* 1136 */     target.setSource(extractSource(collectionEle));
/* 1137 */     target.setElementTypeName(defaultElementType);
/* 1138 */     target.setMergeEnabled(parseMergeAttribute(collectionEle));
/* 1139 */     parseCollectionElements(nl, (Collection<Object>)target, bd, defaultElementType);
/* 1140 */     return (List<Object>)target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Object> parseSetElement(Element collectionEle, @Nullable BeanDefinition bd) {
/* 1147 */     String defaultElementType = collectionEle.getAttribute("value-type");
/* 1148 */     NodeList nl = collectionEle.getChildNodes();
/* 1149 */     ManagedSet<Object> target = new ManagedSet(nl.getLength());
/* 1150 */     target.setSource(extractSource(collectionEle));
/* 1151 */     target.setElementTypeName(defaultElementType);
/* 1152 */     target.setMergeEnabled(parseMergeAttribute(collectionEle));
/* 1153 */     parseCollectionElements(nl, (Collection<Object>)target, bd, defaultElementType);
/* 1154 */     return (Set<Object>)target;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseCollectionElements(NodeList elementNodes, Collection<Object> target, @Nullable BeanDefinition bd, String defaultElementType) {
/* 1160 */     for (int i = 0; i < elementNodes.getLength(); i++) {
/* 1161 */       Node node = elementNodes.item(i);
/* 1162 */       if (node instanceof Element) { Element currentElement = (Element)node; if (!nodeNameEquals(node, "description")) {
/* 1163 */           target.add(parsePropertySubElement(currentElement, bd, defaultElementType));
/*      */         } }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<Object, Object> parseMapElement(Element mapEle, @Nullable BeanDefinition bd) {
/* 1172 */     String defaultKeyType = mapEle.getAttribute("key-type");
/* 1173 */     String defaultValueType = mapEle.getAttribute("value-type");
/*      */     
/* 1175 */     List<Element> entryEles = DomUtils.getChildElementsByTagName(mapEle, "entry");
/* 1176 */     ManagedMap<Object, Object> map = new ManagedMap(entryEles.size());
/* 1177 */     map.setSource(extractSource(mapEle));
/* 1178 */     map.setKeyTypeName(defaultKeyType);
/* 1179 */     map.setValueTypeName(defaultValueType);
/* 1180 */     map.setMergeEnabled(parseMergeAttribute(mapEle));
/*      */     
/* 1182 */     for (Element entryEle : entryEles) {
/*      */ 
/*      */       
/* 1185 */       NodeList entrySubNodes = entryEle.getChildNodes();
/* 1186 */       Element keyEle = null;
/* 1187 */       Element valueEle = null;
/* 1188 */       for (int j = 0; j < entrySubNodes.getLength(); j++) {
/* 1189 */         Node node = entrySubNodes.item(j);
/* 1190 */         if (node instanceof Element) { Element candidateEle = (Element)node;
/* 1191 */           if (nodeNameEquals(candidateEle, "key")) {
/* 1192 */             if (keyEle != null) {
/* 1193 */               error("<entry> element is only allowed to contain one <key> sub-element", entryEle);
/*      */             } else {
/*      */               
/* 1196 */               keyEle = candidateEle;
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1201 */           else if (!nodeNameEquals(candidateEle, "description")) {
/*      */ 
/*      */             
/* 1204 */             if (valueEle != null) {
/* 1205 */               error("<entry> element must not contain more than one value sub-element", entryEle);
/*      */             } else {
/*      */               
/* 1208 */               valueEle = candidateEle;
/*      */             } 
/*      */           }  }
/*      */       
/*      */       } 
/*      */ 
/*      */       
/* 1215 */       Object key = null;
/* 1216 */       boolean hasKeyAttribute = entryEle.hasAttribute("key");
/* 1217 */       boolean hasKeyRefAttribute = entryEle.hasAttribute("key-ref");
/* 1218 */       if ((hasKeyAttribute && hasKeyRefAttribute) || ((hasKeyAttribute || hasKeyRefAttribute) && keyEle != null))
/*      */       {
/* 1220 */         error("<entry> element is only allowed to contain either a 'key' attribute OR a 'key-ref' attribute OR a <key> sub-element", entryEle);
/*      */       }
/*      */       
/* 1223 */       if (hasKeyAttribute) {
/* 1224 */         key = buildTypedStringValueForMap(entryEle.getAttribute("key"), defaultKeyType, entryEle);
/*      */       }
/* 1226 */       else if (hasKeyRefAttribute) {
/* 1227 */         String refName = entryEle.getAttribute("key-ref");
/* 1228 */         if (!StringUtils.hasText(refName)) {
/* 1229 */           error("<entry> element contains empty 'key-ref' attribute", entryEle);
/*      */         }
/* 1231 */         RuntimeBeanReference ref = new RuntimeBeanReference(refName);
/* 1232 */         ref.setSource(extractSource(entryEle));
/* 1233 */         key = ref;
/*      */       }
/* 1235 */       else if (keyEle != null) {
/* 1236 */         key = parseKeyElement(keyEle, bd, defaultKeyType);
/*      */       } else {
/*      */         
/* 1239 */         error("<entry> element must specify a key", entryEle);
/*      */       } 
/*      */ 
/*      */       
/* 1243 */       Object value = null;
/* 1244 */       boolean hasValueAttribute = entryEle.hasAttribute("value");
/* 1245 */       boolean hasValueRefAttribute = entryEle.hasAttribute("value-ref");
/* 1246 */       boolean hasValueTypeAttribute = entryEle.hasAttribute("value-type");
/* 1247 */       if ((hasValueAttribute && hasValueRefAttribute) || ((hasValueAttribute || hasValueRefAttribute) && valueEle != null))
/*      */       {
/* 1249 */         error("<entry> element is only allowed to contain either 'value' attribute OR 'value-ref' attribute OR <value> sub-element", entryEle);
/*      */       }
/*      */       
/* 1252 */       if ((hasValueTypeAttribute && hasValueRefAttribute) || (hasValueTypeAttribute && !hasValueAttribute) || (hasValueTypeAttribute && valueEle != null))
/*      */       {
/*      */         
/* 1255 */         error("<entry> element is only allowed to contain a 'value-type' attribute when it has a 'value' attribute", entryEle);
/*      */       }
/*      */       
/* 1258 */       if (hasValueAttribute) {
/* 1259 */         String valueType = entryEle.getAttribute("value-type");
/* 1260 */         if (!StringUtils.hasText(valueType)) {
/* 1261 */           valueType = defaultValueType;
/*      */         }
/* 1263 */         value = buildTypedStringValueForMap(entryEle.getAttribute("value"), valueType, entryEle);
/*      */       }
/* 1265 */       else if (hasValueRefAttribute) {
/* 1266 */         String refName = entryEle.getAttribute("value-ref");
/* 1267 */         if (!StringUtils.hasText(refName)) {
/* 1268 */           error("<entry> element contains empty 'value-ref' attribute", entryEle);
/*      */         }
/* 1270 */         RuntimeBeanReference ref = new RuntimeBeanReference(refName);
/* 1271 */         ref.setSource(extractSource(entryEle));
/* 1272 */         value = ref;
/*      */       }
/* 1274 */       else if (valueEle != null) {
/* 1275 */         value = parsePropertySubElement(valueEle, bd, defaultValueType);
/*      */       } else {
/*      */         
/* 1278 */         error("<entry> element must specify a value", entryEle);
/*      */       } 
/*      */ 
/*      */       
/* 1282 */       map.put(key, value);
/*      */     } 
/*      */     
/* 1285 */     return (Map<Object, Object>)map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object buildTypedStringValueForMap(String value, String defaultTypeName, Element entryEle) {
/*      */     try {
/* 1294 */       TypedStringValue typedValue = buildTypedStringValue(value, defaultTypeName);
/* 1295 */       typedValue.setSource(extractSource(entryEle));
/* 1296 */       return typedValue;
/*      */     }
/* 1298 */     catch (ClassNotFoundException ex) {
/* 1299 */       error("Type class [" + defaultTypeName + "] not found for Map key/value type", entryEle, ex);
/* 1300 */       return value;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected Object parseKeyElement(Element keyEle, @Nullable BeanDefinition bd, String defaultKeyTypeName) {
/* 1309 */     NodeList nl = keyEle.getChildNodes();
/* 1310 */     Element subElement = null;
/* 1311 */     for (int i = 0; i < nl.getLength(); i++) {
/* 1312 */       Node node = nl.item(i);
/* 1313 */       if (node instanceof Element) { Element currentElement = (Element)node;
/*      */         
/* 1315 */         if (subElement != null) {
/* 1316 */           error("<key> element must not contain more than one value sub-element", keyEle);
/*      */         } else {
/*      */           
/* 1319 */           subElement = currentElement;
/*      */         }  }
/*      */     
/*      */     } 
/* 1323 */     if (subElement == null) {
/* 1324 */       return null;
/*      */     }
/* 1326 */     return parsePropertySubElement(subElement, bd, defaultKeyTypeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties parsePropsElement(Element propsEle) {
/* 1333 */     ManagedProperties props = new ManagedProperties();
/* 1334 */     props.setSource(extractSource(propsEle));
/* 1335 */     props.setMergeEnabled(parseMergeAttribute(propsEle));
/*      */     
/* 1337 */     List<Element> propEles = DomUtils.getChildElementsByTagName(propsEle, "prop");
/* 1338 */     for (Element propEle : propEles) {
/* 1339 */       String key = propEle.getAttribute("key");
/*      */ 
/*      */       
/* 1342 */       String value = DomUtils.getTextValue(propEle).trim();
/* 1343 */       TypedStringValue keyHolder = new TypedStringValue(key);
/* 1344 */       keyHolder.setSource(extractSource(propEle));
/* 1345 */       TypedStringValue valueHolder = new TypedStringValue(value);
/* 1346 */       valueHolder.setSource(extractSource(propEle));
/* 1347 */       props.put(keyHolder, valueHolder);
/*      */     } 
/*      */     
/* 1350 */     return (Properties)props;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean parseMergeAttribute(Element collectionElement) {
/* 1357 */     String value = collectionElement.getAttribute("merge");
/* 1358 */     if (isDefaultValue(value)) {
/* 1359 */       value = this.defaults.getMerge();
/*      */     }
/* 1361 */     return "true".equals(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanDefinition parseCustomElement(Element ele) {
/* 1371 */     return parseCustomElement(ele, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanDefinition parseCustomElement(Element ele, @Nullable BeanDefinition containingBd) {
/* 1382 */     String namespaceUri = getNamespaceURI(ele);
/* 1383 */     if (namespaceUri == null) {
/* 1384 */       return null;
/*      */     }
/* 1386 */     NamespaceHandler handler = this.readerContext.getNamespaceHandlerResolver().resolve(namespaceUri);
/* 1387 */     if (handler == null) {
/* 1388 */       error("Unable to locate Spring NamespaceHandler for XML schema namespace [" + namespaceUri + "]", ele);
/* 1389 */       return null;
/*      */     } 
/* 1391 */     return handler.parse(ele, new ParserContext(this.readerContext, this, containingBd));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDefinitionHolder decorateBeanDefinitionIfRequired(Element ele, BeanDefinitionHolder originalDef) {
/* 1401 */     return decorateBeanDefinitionIfRequired(ele, originalDef, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDefinitionHolder decorateBeanDefinitionIfRequired(Element ele, BeanDefinitionHolder originalDef, @Nullable BeanDefinition containingBd) {
/* 1414 */     BeanDefinitionHolder finalDefinition = originalDef;
/*      */ 
/*      */     
/* 1417 */     NamedNodeMap attributes = ele.getAttributes();
/* 1418 */     for (int i = 0; i < attributes.getLength(); i++) {
/* 1419 */       Node node = attributes.item(i);
/* 1420 */       finalDefinition = decorateIfRequired(node, finalDefinition, containingBd);
/*      */     } 
/*      */ 
/*      */     
/* 1424 */     NodeList children = ele.getChildNodes();
/* 1425 */     for (int j = 0; j < children.getLength(); j++) {
/* 1426 */       Node node = children.item(j);
/* 1427 */       if (node.getNodeType() == 1) {
/* 1428 */         finalDefinition = decorateIfRequired(node, finalDefinition, containingBd);
/*      */       }
/*      */     } 
/* 1431 */     return finalDefinition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDefinitionHolder decorateIfRequired(Node node, BeanDefinitionHolder originalDef, @Nullable BeanDefinition containingBd) {
/* 1445 */     String namespaceUri = getNamespaceURI(node);
/* 1446 */     if (namespaceUri != null && !isDefaultNamespace(namespaceUri)) {
/* 1447 */       NamespaceHandler handler = this.readerContext.getNamespaceHandlerResolver().resolve(namespaceUri);
/* 1448 */       if (handler != null) {
/*      */         
/* 1450 */         BeanDefinitionHolder decorated = handler.decorate(node, originalDef, new ParserContext(this.readerContext, this, containingBd));
/* 1451 */         if (decorated != null) {
/* 1452 */           return decorated;
/*      */         }
/*      */       }
/* 1455 */       else if (namespaceUri.startsWith("http://www.springframework.org/schema/")) {
/* 1456 */         error("Unable to locate Spring NamespaceHandler for XML schema namespace [" + namespaceUri + "]", node);
/*      */ 
/*      */       
/*      */       }
/* 1460 */       else if (this.logger.isDebugEnabled()) {
/* 1461 */         this.logger.debug("No Spring NamespaceHandler found for XML schema namespace [" + namespaceUri + "]");
/*      */       } 
/*      */     } 
/*      */     
/* 1465 */     return originalDef;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private BeanDefinitionHolder parseNestedCustomElement(Element ele, @Nullable BeanDefinition containingBd) {
/* 1470 */     BeanDefinition innerDefinition = parseCustomElement(ele, containingBd);
/* 1471 */     if (innerDefinition == null) {
/* 1472 */       error("Incorrect usage of element '" + ele.getNodeName() + "' in a nested manner. This tag cannot be used nested inside <property>.", ele);
/*      */       
/* 1474 */       return null;
/*      */     } 
/*      */     
/* 1477 */     String id = ele.getNodeName() + "#" + ele.getNodeName();
/* 1478 */     if (this.logger.isTraceEnabled()) {
/* 1479 */       this.logger.trace("Using generated bean name [" + id + "] for nested custom element '" + ele
/* 1480 */           .getNodeName() + "'");
/*      */     }
/* 1482 */     return new BeanDefinitionHolder(innerDefinition, id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getNamespaceURI(Node node) {
/* 1495 */     return node.getNamespaceURI();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLocalName(Node node) {
/* 1506 */     return node.getLocalName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nodeNameEquals(Node node, String desiredName) {
/* 1519 */     return (desiredName.equals(node.getNodeName()) || desiredName.equals(getLocalName(node)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDefaultNamespace(@Nullable String namespaceUri) {
/* 1526 */     return (!StringUtils.hasLength(namespaceUri) || "http://www.springframework.org/schema/beans".equals(namespaceUri));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDefaultNamespace(Node node) {
/* 1533 */     return isDefaultNamespace(getNamespaceURI(node));
/*      */   }
/*      */   
/*      */   private boolean isDefaultValue(String value) {
/* 1537 */     return (!StringUtils.hasLength(value) || "default".equals(value));
/*      */   }
/*      */   
/*      */   private boolean isCandidateElement(Node node) {
/* 1541 */     return (node instanceof Element && (isDefaultNamespace(node) || !isDefaultNamespace(node.getParentNode())));
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\BeanDefinitionParserDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */