/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleConstructorNamespaceHandler
/*     */   implements NamespaceHandler
/*     */ {
/*     */   private static final String REF_SUFFIX = "-ref";
/*     */   private static final String DELIMITER_PREFIX = "_";
/*     */   
/*     */   public void init() {}
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*  74 */     parserContext.getReaderContext().error("Class [" + 
/*  75 */         getClass().getName() + "] does not support custom elements.", element);
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinitionHolder decorate(Node node, BeanDefinitionHolder definition, ParserContext parserContext) {
/*  81 */     if (node instanceof Attr) { Attr attr = (Attr)node;
/*  82 */       String argName = parserContext.getDelegate().getLocalName(attr).strip();
/*  83 */       String argValue = attr.getValue().strip();
/*     */       
/*  85 */       ConstructorArgumentValues cvs = definition.getBeanDefinition().getConstructorArgumentValues();
/*  86 */       boolean ref = false;
/*     */ 
/*     */       
/*  89 */       if (argName.endsWith("-ref")) {
/*  90 */         ref = true;
/*  91 */         argName = argName.substring(0, argName.length() - "-ref".length());
/*     */       } 
/*     */       
/*  94 */       ConstructorArgumentValues.ValueHolder valueHolder = new ConstructorArgumentValues.ValueHolder(ref ? new RuntimeBeanReference(argValue) : argValue);
/*  95 */       valueHolder.setSource(parserContext.getReaderContext().extractSource(attr));
/*     */ 
/*     */       
/*  98 */       if (argName.startsWith("_")) {
/*  99 */         String arg = argName.substring(1).trim();
/*     */ 
/*     */         
/* 102 */         if (!StringUtils.hasText(arg)) {
/* 103 */           cvs.addGenericArgumentValue(valueHolder);
/*     */         }
/*     */         else {
/*     */           
/* 107 */           int index = -1;
/*     */           try {
/* 109 */             index = Integer.parseInt(arg);
/*     */           }
/* 111 */           catch (NumberFormatException ex) {
/* 112 */             parserContext.getReaderContext().error("Constructor argument '" + argName + "' specifies an invalid integer", attr);
/*     */           } 
/*     */           
/* 115 */           if (index < 0) {
/* 116 */             parserContext.getReaderContext().error("Constructor argument '" + argName + "' specifies a negative index", attr);
/*     */           }
/*     */ 
/*     */           
/* 120 */           if (cvs.hasIndexedArgumentValue(index)) {
/* 121 */             parserContext.getReaderContext().error("Constructor argument '" + argName + "' with index " + index + " already defined using <constructor-arg>. Only one approach may be used per argument.", attr);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 126 */           cvs.addIndexedArgumentValue(index, valueHolder);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 131 */         String name = Conventions.attributeNameToPropertyName(argName);
/* 132 */         if (containsArgWithName(name, cvs)) {
/* 133 */           parserContext.getReaderContext().error("Constructor argument '" + argName + "' already defined using <constructor-arg>. Only one approach may be used per argument.", attr);
/*     */         }
/*     */ 
/*     */         
/* 137 */         valueHolder.setName(Conventions.attributeNameToPropertyName(argName));
/* 138 */         cvs.addGenericArgumentValue(valueHolder);
/*     */       }  }
/*     */     
/* 141 */     return definition;
/*     */   }
/*     */   
/*     */   private boolean containsArgWithName(String name, ConstructorArgumentValues cvs) {
/* 145 */     return (checkName(name, cvs.getGenericArgumentValues()) || 
/* 146 */       checkName(name, cvs.getIndexedArgumentValues().values()));
/*     */   }
/*     */   
/*     */   private boolean checkName(String name, Collection<ConstructorArgumentValues.ValueHolder> values) {
/* 150 */     for (ConstructorArgumentValues.ValueHolder holder : values) {
/* 151 */       if (name.equals(holder.getName())) {
/* 152 */         return true;
/*     */       }
/*     */     } 
/* 155 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\SimpleConstructorNamespaceHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */