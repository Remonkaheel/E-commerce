/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import org.springframework.beans.factory.config.PropertyPathFactoryBean;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertyPathBeanDefinitionParser
/*     */   extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   protected Class<?> getBeanClass(Element element) {
/*  81 */     return PropertyPathFactoryBean.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
/*  86 */     String path = element.getAttribute("path");
/*  87 */     if (!StringUtils.hasText(path)) {
/*  88 */       parserContext.getReaderContext().error("Attribute 'path' must not be empty", element);
/*     */       return;
/*     */     } 
/*  91 */     int dotIndex = path.indexOf('.');
/*  92 */     if (dotIndex == -1) {
/*  93 */       parserContext.getReaderContext().error("Attribute 'path' must follow pattern 'beanName.propertyName'", element);
/*     */       
/*     */       return;
/*     */     } 
/*  97 */     String beanName = path.substring(0, dotIndex);
/*  98 */     String propertyPath = path.substring(dotIndex + 1);
/*  99 */     builder.addPropertyValue("targetBeanName", beanName);
/* 100 */     builder.addPropertyValue("propertyPath", propertyPath);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext) {
/* 105 */     String id = super.resolveId(element, definition, parserContext);
/* 106 */     if (!StringUtils.hasText(id)) {
/* 107 */       id = element.getAttribute("path");
/*     */     }
/* 109 */     return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\UtilNamespaceHandler$PropertyPathBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */