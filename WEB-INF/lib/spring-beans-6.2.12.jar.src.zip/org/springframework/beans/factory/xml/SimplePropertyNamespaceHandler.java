/*    */ package org.springframework.beans.factory.xml;
/*    */ 
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.core.Conventions;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.w3c.dom.Attr;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimplePropertyNamespaceHandler
/*    */   implements NamespaceHandler
/*    */ {
/*    */   private static final String REF_SUFFIX = "-ref";
/*    */   
/*    */   public void init() {}
/*    */   
/*    */   @Nullable
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 63 */     parserContext.getReaderContext().error("Class [" + 
/* 64 */         getClass().getName() + "] does not support custom elements.", element);
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public BeanDefinitionHolder decorate(Node node, BeanDefinitionHolder definition, ParserContext parserContext) {
/* 70 */     if (node instanceof Attr) { Attr attr = (Attr)node;
/* 71 */       String propertyName = parserContext.getDelegate().getLocalName(attr);
/* 72 */       String propertyValue = attr.getValue();
/* 73 */       MutablePropertyValues pvs = definition.getBeanDefinition().getPropertyValues();
/* 74 */       if (pvs.contains(propertyName)) {
/* 75 */         parserContext.getReaderContext().error("Property '" + propertyName + "' is already defined using both <property> and inline syntax. Only one approach may be used per property.", attr);
/*    */       }
/*    */       
/* 78 */       if (propertyName.endsWith("-ref")) {
/* 79 */         propertyName = propertyName.substring(0, propertyName.length() - "-ref".length());
/* 80 */         pvs.add(Conventions.attributeNameToPropertyName(propertyName), new RuntimeBeanReference(propertyValue));
/*    */       } else {
/*    */         
/* 83 */         pvs.add(Conventions.attributeNameToPropertyName(propertyName), propertyValue);
/*    */       }  }
/*    */     
/* 86 */     return definition;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\SimplePropertyNamespaceHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */