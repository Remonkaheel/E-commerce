/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceEntityResolver
/*     */   extends DelegatingEntityResolver
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(ResourceEntityResolver.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceEntityResolver(ResourceLoader resourceLoader) {
/*  69 */     super(resourceLoader.getClassLoader());
/*  70 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InputSource resolveEntity(@Nullable String publicId, @Nullable String systemId) throws SAXException, IOException {
/*  79 */     InputSource source = super.resolveEntity(publicId, systemId);
/*     */     
/*  81 */     if (source == null && systemId != null) {
/*  82 */       String resourcePath = null;
/*     */       try {
/*  84 */         String decodedSystemId = URLDecoder.decode(systemId, StandardCharsets.UTF_8);
/*  85 */         String givenUrl = ResourceUtils.toURL(decodedSystemId).toString();
/*  86 */         String systemRootUrl = (new File("")).toURI().toURL().toString();
/*     */         
/*  88 */         if (givenUrl.startsWith(systemRootUrl)) {
/*  89 */           resourcePath = givenUrl.substring(systemRootUrl.length());
/*     */         }
/*     */       }
/*  92 */       catch (Exception ex) {
/*     */         
/*  94 */         if (logger.isDebugEnabled()) {
/*  95 */           logger.debug("Could not resolve XML entity [" + systemId + "] against system root URL", ex);
/*     */         }
/*     */         
/*  98 */         resourcePath = systemId;
/*     */       } 
/* 100 */       if (resourcePath != null) {
/* 101 */         if (logger.isTraceEnabled()) {
/* 102 */           logger.trace("Trying to locate XML entity [" + systemId + "] as resource [" + resourcePath + "]");
/*     */         }
/* 104 */         Resource resource = this.resourceLoader.getResource(resourcePath);
/* 105 */         source = new InputSource(resource.getInputStream());
/* 106 */         source.setPublicId(publicId);
/* 107 */         source.setSystemId(systemId);
/* 108 */         if (logger.isDebugEnabled()) {
/* 109 */           logger.debug("Found XML entity [" + systemId + "]: " + String.valueOf(resource));
/*     */         }
/*     */       }
/* 112 */       else if (systemId.endsWith(".dtd") || systemId.endsWith(".xsd")) {
/* 113 */         source = resolveSchemaEntity(publicId, systemId);
/*     */       } 
/*     */     } 
/*     */     
/* 117 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected InputSource resolveSchemaEntity(@Nullable String publicId, String systemId) {
/*     */     InputSource source;
/* 142 */     String url = systemId;
/* 143 */     if (url.startsWith("http:")) {
/* 144 */       url = "https:" + url.substring(5);
/*     */     }
/* 146 */     if (logger.isWarnEnabled()) {
/* 147 */       logger.warn("DTD/XSD XML entity [" + systemId + "] not found, falling back to remote https resolution");
/*     */     }
/*     */     try {
/* 150 */       source = new InputSource(ResourceUtils.toURL(url).openStream());
/* 151 */       source.setPublicId(publicId);
/* 152 */       source.setSystemId(systemId);
/*     */     }
/* 154 */     catch (IOException ex) {
/* 155 */       if (logger.isDebugEnabled()) {
/* 156 */         logger.debug("Could not resolve XML entity [" + systemId + "] through URL [" + url + "]", ex);
/*     */       }
/*     */       
/* 159 */       source = null;
/*     */     } 
/* 161 */     return source;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\ResourceEntityResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */