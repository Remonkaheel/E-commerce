/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDocumentLoader
/*     */   implements DocumentLoader
/*     */ {
/*     */   private static final String SCHEMA_LANGUAGE_ATTRIBUTE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
/*     */   private static final String XSD_SCHEMA_LANGUAGE = "http://www.w3.org/2001/XMLSchema";
/*  61 */   private static final Log logger = LogFactory.getLog(DefaultDocumentLoader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document loadDocument(InputSource inputSource, EntityResolver entityResolver, ErrorHandler errorHandler, int validationMode, boolean namespaceAware) throws Exception {
/*  72 */     DocumentBuilderFactory factory = createDocumentBuilderFactory(validationMode, namespaceAware);
/*  73 */     if (logger.isTraceEnabled()) {
/*  74 */       logger.trace("Using JAXP provider [" + factory.getClass().getName() + "]");
/*     */     }
/*  76 */     DocumentBuilder builder = createDocumentBuilder(factory, entityResolver, errorHandler);
/*  77 */     return builder.parse(inputSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DocumentBuilderFactory createDocumentBuilderFactory(int validationMode, boolean namespaceAware) throws ParserConfigurationException {
/*  94 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  95 */     factory.setNamespaceAware(namespaceAware);
/*     */     
/*  97 */     if (validationMode != 0) {
/*  98 */       factory.setValidating(true);
/*  99 */       if (validationMode == 3) {
/*     */         
/* 101 */         factory.setNamespaceAware(true);
/*     */         try {
/* 103 */           factory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
/*     */         }
/* 105 */         catch (IllegalArgumentException ex) {
/* 106 */           ParserConfigurationException pcex = new ParserConfigurationException("Unable to validate using XSD: Your JAXP provider [" + String.valueOf(factory) + "] does not support XML Schema. Are you running on Java 1.4 with Apache Crimson? Upgrade to Apache Xerces (or Java 1.5) for full XSD support.");
/*     */ 
/*     */ 
/*     */           
/* 110 */           pcex.initCause(ex);
/* 111 */           throw pcex;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DocumentBuilder createDocumentBuilder(DocumentBuilderFactory factory, @Nullable EntityResolver entityResolver, @Nullable ErrorHandler errorHandler) throws ParserConfigurationException {
/* 134 */     DocumentBuilder docBuilder = factory.newDocumentBuilder();
/* 135 */     if (entityResolver != null) {
/* 136 */       docBuilder.setEntityResolver(entityResolver);
/*     */     }
/* 138 */     if (errorHandler != null) {
/* 139 */       docBuilder.setErrorHandler(errorHandler);
/*     */     }
/* 141 */     return docBuilder;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\DefaultDocumentLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */