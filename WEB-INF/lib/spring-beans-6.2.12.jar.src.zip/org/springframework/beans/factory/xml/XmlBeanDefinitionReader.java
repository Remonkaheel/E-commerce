/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.parsing.EmptyReaderEventListener;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.NullSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.ReaderEventListener;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.xml.SimpleSaxErrorHandler;
/*     */ import org.springframework.util.xml.XmlValidationModeDetector;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlBeanDefinitionReader
/*     */   extends AbstractBeanDefinitionReader
/*     */ {
/*     */   public static final int VALIDATION_NONE = 0;
/*     */   public static final int VALIDATION_AUTO = 1;
/*     */   public static final int VALIDATION_DTD = 2;
/*     */   public static final int VALIDATION_XSD = 3;
/* 107 */   private static final Map<String, Integer> constants = Map.of("VALIDATION_NONE", 
/* 108 */       Integer.valueOf(0), "VALIDATION_AUTO", 
/* 109 */       Integer.valueOf(1), "VALIDATION_DTD", 
/* 110 */       Integer.valueOf(2), "VALIDATION_XSD", 
/* 111 */       Integer.valueOf(3));
/*     */ 
/*     */   
/* 114 */   private int validationMode = 1;
/*     */   
/*     */   private boolean namespaceAware = false;
/*     */   
/* 118 */   private Class<? extends BeanDefinitionDocumentReader> documentReaderClass = (Class)DefaultBeanDefinitionDocumentReader.class;
/*     */ 
/*     */   
/* 121 */   private ProblemReporter problemReporter = (ProblemReporter)new FailFastProblemReporter();
/*     */   
/* 123 */   private ReaderEventListener eventListener = (ReaderEventListener)new EmptyReaderEventListener();
/*     */   
/* 125 */   private SourceExtractor sourceExtractor = (SourceExtractor)new NullSourceExtractor();
/*     */   
/*     */   @Nullable
/*     */   private NamespaceHandlerResolver namespaceHandlerResolver;
/*     */   
/* 130 */   private DocumentLoader documentLoader = new DefaultDocumentLoader();
/*     */   
/*     */   @Nullable
/*     */   private EntityResolver entityResolver;
/*     */   
/* 135 */   private ErrorHandler errorHandler = (ErrorHandler)new SimpleSaxErrorHandler(this.logger);
/*     */   
/* 137 */   private final XmlValidationModeDetector validationModeDetector = new XmlValidationModeDetector();
/*     */   
/* 139 */   private final ThreadLocal<Set<EncodedResource>> resourcesCurrentlyBeingLoaded = NamedThreadLocal.withInitial("XML bean definition resources currently being loaded", () -> new HashSet(4));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlBeanDefinitionReader(BeanDefinitionRegistry registry) {
/* 149 */     super(registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidating(boolean validating) {
/* 161 */     this.validationMode = validating ? 1 : 0;
/* 162 */     this.namespaceAware = !validating;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidationModeName(String validationModeName) {
/* 170 */     Assert.hasText(validationModeName, "'validationModeName' must not be null or blank");
/* 171 */     Integer validationMode = constants.get(validationModeName);
/* 172 */     Assert.notNull(validationMode, "Only validation mode constants allowed");
/* 173 */     this.validationMode = validationMode.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidationMode(int validationMode) {
/* 183 */     Assert.isTrue(constants.containsValue(Integer.valueOf(validationMode)), "Only values of validation mode constants allowed");
/*     */     
/* 185 */     this.validationMode = validationMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValidationMode() {
/* 192 */     return this.validationMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespaceAware(boolean namespaceAware) {
/* 203 */     this.namespaceAware = namespaceAware;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNamespaceAware() {
/* 210 */     return this.namespaceAware;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProblemReporter(@Nullable ProblemReporter problemReporter) {
/* 220 */     this.problemReporter = (problemReporter != null) ? problemReporter : (ProblemReporter)new FailFastProblemReporter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventListener(@Nullable ReaderEventListener eventListener) {
/* 230 */     this.eventListener = (eventListener != null) ? eventListener : (ReaderEventListener)new EmptyReaderEventListener();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceExtractor(@Nullable SourceExtractor sourceExtractor) {
/* 240 */     this.sourceExtractor = (sourceExtractor != null) ? sourceExtractor : (SourceExtractor)new NullSourceExtractor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespaceHandlerResolver(@Nullable NamespaceHandlerResolver namespaceHandlerResolver) {
/* 249 */     this.namespaceHandlerResolver = namespaceHandlerResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentLoader(@Nullable DocumentLoader documentLoader) {
/* 258 */     this.documentLoader = (documentLoader != null) ? documentLoader : new DefaultDocumentLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityResolver(@Nullable EntityResolver entityResolver) {
/* 267 */     this.entityResolver = entityResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityResolver getEntityResolver() {
/* 275 */     if (this.entityResolver == null) {
/*     */       
/* 277 */       ResourceLoader resourceLoader = getResourceLoader();
/* 278 */       if (resourceLoader != null) {
/* 279 */         this.entityResolver = new ResourceEntityResolver(resourceLoader);
/*     */       } else {
/*     */         
/* 282 */         this.entityResolver = new DelegatingEntityResolver(getBeanClassLoader());
/*     */       } 
/*     */     } 
/* 285 */     return this.entityResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorHandler(ErrorHandler errorHandler) {
/* 297 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentReaderClass(Class<? extends BeanDefinitionDocumentReader> documentReaderClass) {
/* 307 */     this.documentReaderClass = documentReaderClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(Resource resource) throws BeanDefinitionStoreException {
/* 319 */     return loadBeanDefinitions(new EncodedResource(resource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource) throws BeanDefinitionStoreException {
/* 330 */     Assert.notNull(encodedResource, "EncodedResource must not be null");
/* 331 */     if (this.logger.isTraceEnabled()) {
/* 332 */       this.logger.trace("Loading XML bean definitions from " + String.valueOf(encodedResource));
/*     */     }
/*     */     
/* 335 */     Set<EncodedResource> currentResources = this.resourcesCurrentlyBeingLoaded.get();
/*     */     
/* 337 */     if (!currentResources.add(encodedResource)) {
/* 338 */       throw new BeanDefinitionStoreException("Detected cyclic loading of " + String.valueOf(encodedResource) + " - check your import definitions!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/* 349 */     } catch (IOException ex) {
/* 350 */       throw new BeanDefinitionStoreException("IOException parsing XML document from " + 
/* 351 */           String.valueOf(encodedResource.getResource()), ex);
/*     */     } finally {
/*     */       
/* 354 */       currentResources.remove(encodedResource);
/* 355 */       if (currentResources.isEmpty()) {
/* 356 */         this.resourcesCurrentlyBeingLoaded.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(InputSource inputSource) throws BeanDefinitionStoreException {
/* 368 */     return loadBeanDefinitions(inputSource, "resource loaded through SAX InputSource");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(InputSource inputSource, @Nullable String resourceDescription) throws BeanDefinitionStoreException {
/* 382 */     return doLoadBeanDefinitions(inputSource, (Resource)new DescriptiveResource(resourceDescription));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int doLoadBeanDefinitions(InputSource inputSource, Resource resource) throws BeanDefinitionStoreException {
/*     */     try {
/* 399 */       Document doc = doLoadDocument(inputSource, resource);
/* 400 */       int count = registerBeanDefinitions(doc, resource);
/* 401 */       if (this.logger.isDebugEnabled()) {
/* 402 */         this.logger.debug("Loaded " + count + " bean definitions from " + String.valueOf(resource));
/*     */       }
/* 404 */       return count;
/*     */     }
/* 406 */     catch (BeanDefinitionStoreException ex) {
/* 407 */       throw ex;
/*     */     }
/* 409 */     catch (SAXParseException ex) {
/* 410 */       throw new XmlBeanDefinitionStoreException(resource.getDescription(), "Line " + ex
/* 411 */           .getLineNumber() + " in XML document from " + String.valueOf(resource) + " is invalid", ex);
/*     */     }
/* 413 */     catch (SAXException ex) {
/* 414 */       throw new XmlBeanDefinitionStoreException(resource.getDescription(), "XML document from " + String.valueOf(resource) + " is invalid", ex);
/*     */     
/*     */     }
/* 417 */     catch (ParserConfigurationException ex) {
/* 418 */       throw new BeanDefinitionStoreException(resource.getDescription(), "Parser configuration exception parsing XML from " + String.valueOf(resource), ex);
/*     */     
/*     */     }
/* 421 */     catch (IOException ex) {
/* 422 */       throw new BeanDefinitionStoreException(resource.getDescription(), "IOException parsing XML document from " + String.valueOf(resource), ex);
/*     */     
/*     */     }
/* 425 */     catch (Throwable ex) {
/* 426 */       throw new BeanDefinitionStoreException(resource.getDescription(), "Unexpected exception parsing XML document from " + String.valueOf(resource), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Document doLoadDocument(InputSource inputSource, Resource resource) throws Exception {
/* 441 */     return this.documentLoader.loadDocument(inputSource, getEntityResolver(), this.errorHandler, 
/* 442 */         getValidationModeForResource(resource), isNamespaceAware());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getValidationModeForResource(Resource resource) {
/* 454 */     int validationModeToUse = getValidationMode();
/* 455 */     if (validationModeToUse != 1) {
/* 456 */       return validationModeToUse;
/*     */     }
/* 458 */     int detectedMode = detectValidationMode(resource);
/* 459 */     if (detectedMode != 1) {
/* 460 */       return detectedMode;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 465 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int detectValidationMode(Resource resource) {
/*     */     InputStream inputStream;
/* 476 */     if (resource.isOpen()) {
/* 477 */       throw new BeanDefinitionStoreException("Passed-in Resource [" + String.valueOf(resource) + "] contains an open stream: cannot determine validation mode automatically. Either pass in a Resource that is able to create fresh streams, or explicitly specify the validationMode on your XmlBeanDefinitionReader instance.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 486 */       inputStream = resource.getInputStream();
/*     */     }
/* 488 */     catch (IOException ex) {
/* 489 */       throw new BeanDefinitionStoreException("Unable to determine validation mode for [" + String.valueOf(resource) + "]: cannot open InputStream. Did you attempt to load directly from a SAX InputSource without specifying the validationMode on your XmlBeanDefinitionReader instance?", ex);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 496 */       return this.validationModeDetector.detectValidationMode(inputStream);
/*     */     }
/* 498 */     catch (IOException ex) {
/* 499 */       throw new BeanDefinitionStoreException("Unable to determine validation mode for [" + String.valueOf(resource) + "]: an error occurred whilst reading from the InputStream.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int registerBeanDefinitions(Document doc, Resource resource) throws BeanDefinitionStoreException {
/* 518 */     BeanDefinitionDocumentReader documentReader = createBeanDefinitionDocumentReader();
/* 519 */     int countBefore = getRegistry().getBeanDefinitionCount();
/* 520 */     documentReader.registerBeanDefinitions(doc, createReaderContext(resource));
/* 521 */     return getRegistry().getBeanDefinitionCount() - countBefore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanDefinitionDocumentReader createBeanDefinitionDocumentReader() {
/* 531 */     return (BeanDefinitionDocumentReader)BeanUtils.instantiateClass(this.documentReaderClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlReaderContext createReaderContext(Resource resource) {
/* 538 */     return new XmlReaderContext(resource, this.problemReporter, this.eventListener, this.sourceExtractor, this, 
/* 539 */         getNamespaceHandlerResolver());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceHandlerResolver getNamespaceHandlerResolver() {
/* 547 */     if (this.namespaceHandlerResolver == null) {
/* 548 */       this.namespaceHandlerResolver = createDefaultNamespaceHandlerResolver();
/*     */     }
/* 550 */     return this.namespaceHandlerResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NamespaceHandlerResolver createDefaultNamespaceHandlerResolver() {
/* 559 */     ResourceLoader resourceLoader = getResourceLoader();
/* 560 */     ClassLoader cl = (resourceLoader != null) ? resourceLoader.getClassLoader() : getBeanClassLoader();
/* 561 */     return new DefaultNamespaceHandlerResolver(cl);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\xml\XmlBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */