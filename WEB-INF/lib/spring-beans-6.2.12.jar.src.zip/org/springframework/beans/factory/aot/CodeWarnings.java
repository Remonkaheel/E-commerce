/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.AnnotationSpec;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeWarnings
/*     */ {
/*  46 */   private final Set<String> warnings = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(String warning) {
/*  55 */     this.warnings.add(warning);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeWarnings detectDeprecation(AnnotatedElement... elements) {
/*  64 */     for (AnnotatedElement element : elements) {
/*  65 */       registerDeprecationIfNecessary(element);
/*     */     }
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeWarnings detectDeprecation(Stream<AnnotatedElement> elements) {
/*  76 */     elements.forEach(element -> register(element.<Deprecated>getAnnotation(Deprecated.class)));
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeWarnings detectDeprecation(ResolvableType resolvableType) {
/*  88 */     if (ResolvableType.NONE.equals(resolvableType)) {
/*  89 */       return this;
/*     */     }
/*  91 */     Class<?> type = ClassUtils.getUserClass(resolvableType.toClass());
/*  92 */     detectDeprecation(new AnnotatedElement[] { type });
/*  93 */     if (resolvableType.hasGenerics() && !resolvableType.hasUnresolvableGenerics()) {
/*  94 */       for (ResolvableType generic : resolvableType.getGenerics()) {
/*  95 */         detectDeprecation(generic);
/*     */       }
/*     */     }
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void suppress(MethodSpec.Builder method) {
/* 106 */     suppress(annotationBuilder -> method.addAnnotation(annotationBuilder.build()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void suppress(TypeSpec.Builder type) {
/* 114 */     suppress(annotationBuilder -> type.addAnnotation(annotationBuilder.build()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void suppress(Consumer<AnnotationSpec.Builder> annotationSpec) {
/* 126 */     if (!this.warnings.isEmpty()) {
/*     */       
/* 128 */       AnnotationSpec.Builder annotation = AnnotationSpec.builder(SuppressWarnings.class).addMember("value", generateValueCode());
/* 129 */       annotationSpec.accept(annotation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<String> getWarnings() {
/* 138 */     return Collections.unmodifiableSet(this.warnings);
/*     */   }
/*     */   
/*     */   private void registerDeprecationIfNecessary(@Nullable AnnotatedElement element) {
/* 142 */     if (element == null) {
/*     */       return;
/*     */     }
/* 145 */     register(element.<Deprecated>getAnnotation(Deprecated.class));
/* 146 */     if (element instanceof Class) { Class<?> type = (Class)element;
/* 147 */       registerDeprecationIfNecessary(type.getEnclosingClass()); }
/*     */   
/*     */   }
/*     */   
/*     */   private void register(@Nullable Deprecated annotation) {
/* 152 */     if (annotation != null) {
/* 153 */       if (annotation.forRemoval()) {
/* 154 */         register("removal");
/*     */       } else {
/*     */         
/* 157 */         register("deprecation");
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private CodeBlock generateValueCode() {
/* 163 */     if (this.warnings.size() == 1) {
/* 164 */       return CodeBlock.of("$S", new Object[] { this.warnings.iterator().next() });
/*     */     }
/* 166 */     CodeBlock values = CodeBlock.join(this.warnings.stream()
/* 167 */         .map(warning -> CodeBlock.of("$S", new Object[] { warning })).toList(), ", ");
/* 168 */     return CodeBlock.of("{ $L }", new Object[] { values });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 173 */     return CodeWarnings.class.getSimpleName() + CodeWarnings.class.getSimpleName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\CodeWarnings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */