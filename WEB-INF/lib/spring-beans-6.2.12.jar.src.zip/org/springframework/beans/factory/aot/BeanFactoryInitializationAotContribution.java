package org.springframework.beans.factory.aot;

import org.springframework.aot.generate.GenerationContext;

@FunctionalInterface
public interface BeanFactoryInitializationAotContribution {
  void applyTo(GenerationContext paramGenerationContext, BeanFactoryInitializationCode paramBeanFactoryInitializationCode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanFactoryInitializationAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */