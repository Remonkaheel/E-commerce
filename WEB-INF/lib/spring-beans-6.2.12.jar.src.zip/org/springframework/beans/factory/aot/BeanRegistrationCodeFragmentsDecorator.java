/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.generate.MethodReference;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.javapoet.ClassName;
/*    */ import org.springframework.javapoet.CodeBlock;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanRegistrationCodeFragmentsDecorator
/*    */   implements BeanRegistrationCodeFragments
/*    */ {
/*    */   private final BeanRegistrationCodeFragments delegate;
/*    */   
/*    */   protected BeanRegistrationCodeFragmentsDecorator(BeanRegistrationCodeFragments delegate) {
/* 48 */     Assert.notNull(delegate, "Delegate must not be null");
/* 49 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public ClassName getTarget(RegisteredBean registeredBean) {
/* 54 */     return this.delegate.getTarget(registeredBean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CodeBlock generateNewBeanDefinitionCode(GenerationContext generationContext, ResolvableType beanType, BeanRegistrationCode beanRegistrationCode) {
/* 61 */     return this.delegate.generateNewBeanDefinitionCode(generationContext, beanType, beanRegistrationCode);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CodeBlock generateSetBeanDefinitionPropertiesCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, RootBeanDefinition beanDefinition, Predicate<String> attributeFilter) {
/* 69 */     return this.delegate.generateSetBeanDefinitionPropertiesCode(generationContext, beanRegistrationCode, beanDefinition, attributeFilter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CodeBlock generateSetBeanInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, CodeBlock instanceSupplierCode, List<MethodReference> postProcessors) {
/* 78 */     return this.delegate.generateSetBeanInstanceSupplierCode(generationContext, beanRegistrationCode, instanceSupplierCode, postProcessors);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 87 */     return this.delegate.generateInstanceSupplierCode(generationContext, beanRegistrationCode, allowDirectSupplierShortcut);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CodeBlock generateReturnCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 95 */     return this.delegate.generateReturnCode(generationContext, beanRegistrationCode);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationCodeFragmentsDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */