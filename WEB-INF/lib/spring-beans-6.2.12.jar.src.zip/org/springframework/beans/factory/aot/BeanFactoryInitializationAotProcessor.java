package org.springframework.beans.factory.aot;

import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface BeanFactoryInitializationAotProcessor {
  @Nullable
  BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory paramConfigurableListableBeanFactory);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanFactoryInitializationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */