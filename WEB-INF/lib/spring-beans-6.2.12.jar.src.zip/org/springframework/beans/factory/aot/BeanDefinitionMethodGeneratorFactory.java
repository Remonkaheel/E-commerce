/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanDefinitionMethodGeneratorFactory
/*     */ {
/*  45 */   private static final Log logger = LogFactory.getLog(BeanDefinitionMethodGeneratorFactory.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final AotServices<BeanRegistrationAotProcessor> aotProcessors;
/*     */ 
/*     */ 
/*     */   
/*     */   private final AotServices<BeanRegistrationExcludeFilter> excludeFilters;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BeanDefinitionMethodGeneratorFactory(ConfigurableListableBeanFactory beanFactory) {
/*  59 */     this(AotServices.factoriesAndBeans((ListableBeanFactory)beanFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BeanDefinitionMethodGeneratorFactory(AotServices.Loader loader) {
/*  68 */     this.aotProcessors = loader.load(BeanRegistrationAotProcessor.class);
/*  69 */     this.excludeFilters = loader.load(BeanRegistrationExcludeFilter.class);
/*  70 */     for (BeanRegistrationExcludeFilter excludeFilter : this.excludeFilters) {
/*  71 */       if (this.excludeFilters.getSource(excludeFilter) == AotServices.Source.BEAN_FACTORY) {
/*  72 */         Assert.state((excludeFilter instanceof BeanRegistrationAotProcessor || excludeFilter instanceof BeanFactoryInitializationAotProcessor), () -> "BeanRegistrationExcludeFilter bean of type %s must also implement an AOT processor interface".formatted(new Object[] { excludeFilter.getClass().getName() }));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   BeanDefinitionMethodGenerator getBeanDefinitionMethodGenerator(RegisteredBean registeredBean, @Nullable String currentPropertyName) {
/*  96 */     if (isExcluded(registeredBean)) {
/*  97 */       return null;
/*     */     }
/*  99 */     List<BeanRegistrationAotContribution> contributions = getAotContributions(registeredBean);
/* 100 */     return new BeanDefinitionMethodGenerator(this, registeredBean, currentPropertyName, contributions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   BeanDefinitionMethodGenerator getBeanDefinitionMethodGenerator(RegisteredBean registeredBean) {
/* 115 */     return getBeanDefinitionMethodGenerator(registeredBean, null);
/*     */   }
/*     */   
/*     */   private boolean isExcluded(RegisteredBean registeredBean) {
/* 119 */     if (isImplicitlyExcluded(registeredBean)) {
/* 120 */       return true;
/*     */     }
/* 122 */     for (BeanRegistrationExcludeFilter excludeFilter : this.excludeFilters) {
/* 123 */       if (excludeFilter.isExcludedFromAotProcessing(registeredBean)) {
/* 124 */         logger.trace(LogMessage.format("Excluding registered bean '%s' from bean factory %s due to %s", registeredBean
/*     */               
/* 126 */               .getBeanName(), 
/* 127 */               ObjectUtils.identityToString(registeredBean.getBeanFactory()), excludeFilter
/* 128 */               .getClass().getName()));
/* 129 */         return true;
/*     */       } 
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isImplicitlyExcluded(RegisteredBean registeredBean) {
/* 136 */     if (Boolean.TRUE.equals(registeredBean.getMergedBeanDefinition()
/* 137 */         .getAttribute("aotProcessingIgnoreRegistration"))) {
/* 138 */       return true;
/*     */     }
/* 140 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 141 */     if (BeanFactoryInitializationAotProcessor.class.isAssignableFrom(beanClass)) {
/* 142 */       return true;
/*     */     }
/* 144 */     if (BeanRegistrationAotProcessor.class.isAssignableFrom(beanClass)) {
/* 145 */       BeanRegistrationAotProcessor processor = this.aotProcessors.findByBeanName(registeredBean.getBeanName());
/* 146 */       return (processor == null || processor.isBeanExcludedFromAotProcessing());
/*     */     } 
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   private List<BeanRegistrationAotContribution> getAotContributions(RegisteredBean registeredBean) {
/* 152 */     String beanName = registeredBean.getBeanName();
/* 153 */     List<BeanRegistrationAotContribution> contributions = new ArrayList<>();
/* 154 */     for (BeanRegistrationAotProcessor aotProcessor : this.aotProcessors) {
/* 155 */       BeanRegistrationAotContribution contribution = aotProcessor.processAheadOfTime(registeredBean);
/* 156 */       if (contribution != null) {
/* 157 */         logger.trace(LogMessage.format("Adding bean registration AOT contribution %S from %S to '%S'", contribution
/*     */               
/* 159 */               .getClass().getName(), aotProcessor
/* 160 */               .getClass().getName(), beanName));
/* 161 */         contributions.add(contribution);
/*     */       } 
/*     */     } 
/* 164 */     return contributions;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionMethodGeneratorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */