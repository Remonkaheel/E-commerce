/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.aot.generate.ValueCodeGenerator;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.InstanceSupplier;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.ParameterizedTypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultBeanRegistrationCodeFragments
/*     */   implements BeanRegistrationCodeFragments
/*     */ {
/*  56 */   private static final ValueCodeGenerator valueCodeGenerator = ValueCodeGenerator.withDefaults();
/*     */ 
/*     */   
/*     */   private final BeanRegistrationsCode beanRegistrationsCode;
/*     */ 
/*     */   
/*     */   private final RegisteredBean registeredBean;
/*     */ 
/*     */   
/*     */   private final BeanDefinitionMethodGeneratorFactory beanDefinitionMethodGeneratorFactory;
/*     */   
/*     */   private final Supplier<RegisteredBean.InstantiationDescriptor> instantiationDescriptor;
/*     */ 
/*     */   
/*     */   DefaultBeanRegistrationCodeFragments(BeanRegistrationsCode beanRegistrationsCode, RegisteredBean registeredBean, BeanDefinitionMethodGeneratorFactory beanDefinitionMethodGeneratorFactory) {
/*  71 */     this.beanRegistrationsCode = beanRegistrationsCode;
/*  72 */     this.registeredBean = registeredBean;
/*  73 */     this.beanDefinitionMethodGeneratorFactory = beanDefinitionMethodGeneratorFactory;
/*  74 */     Objects.requireNonNull(registeredBean); this.instantiationDescriptor = (Supplier<RegisteredBean.InstantiationDescriptor>)SingletonSupplier.of(registeredBean::resolveInstantiationDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassName getTarget(RegisteredBean registeredBean) {
/*  80 */     if (hasInstanceSupplier()) {
/*  81 */       throw new AotBeanProcessingException(registeredBean, "instance supplier is not supported");
/*     */     }
/*  83 */     Class<?> target = extractDeclaringClass(registeredBean, this.instantiationDescriptor.get());
/*  84 */     while (target.getName().startsWith("java.") && registeredBean.isInnerBean()) {
/*  85 */       RegisteredBean parent = registeredBean.getParent();
/*  86 */       Assert.state((parent != null), "No parent available for inner bean");
/*  87 */       target = parent.getBeanClass();
/*     */     } 
/*  89 */     return target.isArray() ? ClassName.get(target.getComponentType()) : ClassName.get(target);
/*     */   }
/*     */   
/*     */   private Class<?> extractDeclaringClass(RegisteredBean registeredBean, RegisteredBean.InstantiationDescriptor instantiationDescriptor) {
/*  93 */     Class<?> declaringClass = ClassUtils.getUserClass(instantiationDescriptor.targetClass());
/*  94 */     Executable executable = instantiationDescriptor.executable(); if (executable instanceof Constructor) { Constructor<?> ctor = (Constructor)executable;
/*  95 */       if (AccessControl.forMember(ctor).isPublic() && FactoryBean.class.isAssignableFrom(declaringClass))
/*  96 */         return extractTargetClassFromFactoryBean(declaringClass, registeredBean.getBeanType());  }
/*     */     
/*  98 */     return declaringClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> extractTargetClassFromFactoryBean(Class<?> factoryBeanType, ResolvableType beanType) {
/* 110 */     ResolvableType target = ResolvableType.forType(factoryBeanType).as(FactoryBean.class).getGeneric(new int[] { 0 });
/* 111 */     if (target.getType().equals(Class.class)) {
/* 112 */       return target.toClass();
/*     */     }
/* 114 */     if (factoryBeanType.isAssignableFrom(beanType.toClass())) {
/* 115 */       return beanType.as(FactoryBean.class).getGeneric(new int[] { 0 }).toClass();
/*     */     }
/* 117 */     return beanType.toClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateNewBeanDefinitionCode(GenerationContext generationContext, ResolvableType beanType, BeanRegistrationCode beanRegistrationCode) {
/* 124 */     CodeBlock.Builder code = CodeBlock.builder();
/* 125 */     RootBeanDefinition mbd = this.registeredBean.getMergedBeanDefinition();
/* 126 */     Class<?> beanClass = mbd.hasBeanClass() ? ClassUtils.getUserClass(mbd.getBeanClass()) : null;
/* 127 */     CodeBlock beanClassCode = generateBeanClassCode(beanRegistrationCode
/* 128 */         .getClassName().packageName(), 
/* 129 */         (beanClass != null) ? beanClass : beanType.toClass());
/* 130 */     code.addStatement("$T $L = new $T($L)", new Object[] { RootBeanDefinition.class, "beanDefinition", RootBeanDefinition.class, beanClassCode });
/*     */     
/* 132 */     if (targetTypeNecessary(beanType, beanClass)) {
/* 133 */       code.addStatement("$L.setTargetType($L)", new Object[] { "beanDefinition", generateBeanTypeCode(beanType) });
/*     */     }
/* 135 */     return code.build();
/*     */   }
/*     */   
/*     */   private CodeBlock generateBeanClassCode(String targetPackage, Class<?> beanClass) {
/* 139 */     if (Modifier.isPublic(beanClass.getModifiers()) || targetPackage.equals(beanClass.getPackageName())) {
/* 140 */       return CodeBlock.of("$T.class", new Object[] { beanClass });
/*     */     }
/*     */     
/* 143 */     return CodeBlock.of("$S", new Object[] { beanClass.getName() });
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock generateBeanTypeCode(ResolvableType beanType) {
/* 148 */     if (!beanType.hasGenerics()) {
/* 149 */       return valueCodeGenerator.generateCode(ClassUtils.getUserClass(beanType.toClass()));
/*     */     }
/* 151 */     return valueCodeGenerator.generateCode(beanType);
/*     */   }
/*     */   
/*     */   private boolean targetTypeNecessary(ResolvableType beanType, @Nullable Class<?> beanClass) {
/* 155 */     if (beanType.hasGenerics()) {
/* 156 */       return true;
/*     */     }
/* 158 */     if (beanClass != null && this.registeredBean.getMergedBeanDefinition().getFactoryMethodName() != null) {
/* 159 */       return true;
/*     */     }
/* 161 */     return (beanClass != null && !beanType.toClass().equals(ClassUtils.getUserClass(beanClass)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateSetBeanDefinitionPropertiesCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, RootBeanDefinition beanDefinition, Predicate<String> attributeFilter) {
/* 169 */     AotServices.Loader loader = AotServices.factories(this.registeredBean.getBeanFactory().getBeanClassLoader());
/* 170 */     List<ValueCodeGenerator.Delegate> additionalDelegates = loader.<ValueCodeGenerator.Delegate>load(ValueCodeGenerator.Delegate.class).asList();
/*     */     
/* 172 */     return (new BeanDefinitionPropertiesCodeGenerator(generationContext
/* 173 */         .getRuntimeHints(), attributeFilter, beanRegistrationCode
/* 174 */         .getMethods(), additionalDelegates, (name, value) -> generateValueCode(generationContext, name, value)))
/*     */       
/* 176 */       .generateCode(beanDefinition);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected CodeBlock generateValueCode(GenerationContext generationContext, String name, Object value) {
/* 181 */     RegisteredBean innerRegisteredBean = getInnerRegisteredBean(value);
/* 182 */     if (innerRegisteredBean != null) {
/*     */       
/* 184 */       BeanDefinitionMethodGenerator methodGenerator = this.beanDefinitionMethodGeneratorFactory.getBeanDefinitionMethodGenerator(innerRegisteredBean, name);
/* 185 */       Assert.state((methodGenerator != null), "Unexpected filtering of inner-bean");
/*     */       
/* 187 */       MethodReference generatedMethod = methodGenerator.generateBeanDefinitionMethod(generationContext, this.beanRegistrationsCode);
/* 188 */       return generatedMethod.toInvokeCodeBlock(MethodReference.ArgumentCodeGenerator.none());
/*     */     } 
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RegisteredBean getInnerRegisteredBean(Object value) {
/* 195 */     if (value instanceof BeanDefinitionHolder) { BeanDefinitionHolder beanDefinitionHolder = (BeanDefinitionHolder)value;
/* 196 */       return RegisteredBean.ofInnerBean(this.registeredBean, beanDefinitionHolder); }
/*     */     
/* 198 */     if (value instanceof BeanDefinition) { BeanDefinition beanDefinition = (BeanDefinition)value;
/* 199 */       return RegisteredBean.ofInnerBean(this.registeredBean, beanDefinition); }
/*     */     
/* 201 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateSetBeanInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, CodeBlock instanceSupplierCode, List<MethodReference> postProcessors) {
/* 209 */     CodeBlock.Builder code = CodeBlock.builder();
/* 210 */     if (postProcessors.isEmpty()) {
/* 211 */       code.addStatement("$L.setInstanceSupplier($L)", new Object[] { "beanDefinition", instanceSupplierCode });
/* 212 */       return code.build();
/*     */     } 
/* 214 */     code.addStatement("$T $L = $L", new Object[] {
/* 215 */           ParameterizedTypeName.get(InstanceSupplier.class, new Type[] { this.registeredBean.getBeanClass() }), "instanceSupplier", instanceSupplierCode
/*     */         });
/* 217 */     for (MethodReference postProcessor : postProcessors) {
/* 218 */       code.addStatement("$L = $L.andThen($L)", new Object[] { "instanceSupplier", "instanceSupplier", postProcessor
/* 219 */             .toCodeBlock() });
/*     */     } 
/* 221 */     code.addStatement("$L.setInstanceSupplier($L)", new Object[] { "beanDefinition", "instanceSupplier" });
/*     */     
/* 223 */     return code.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 231 */     if (hasInstanceSupplier()) {
/* 232 */       throw new AotBeanProcessingException(this.registeredBean, "instance supplier is not supported");
/*     */     }
/* 234 */     return (new InstanceSupplierCodeGenerator(generationContext, beanRegistrationCode
/* 235 */         .getClassName(), beanRegistrationCode.getMethods(), allowDirectSupplierShortcut))
/* 236 */       .generateCode(this.registeredBean, this.instantiationDescriptor.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateReturnCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 243 */     CodeBlock.Builder code = CodeBlock.builder();
/* 244 */     code.addStatement("return $L", new Object[] { "beanDefinition" });
/* 245 */     return code.build();
/*     */   }
/*     */   
/*     */   private boolean hasInstanceSupplier() {
/* 249 */     return (this.registeredBean.getMergedBeanDefinition().getInstanceSupplier() != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\DefaultBeanRegistrationCodeFragments.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */