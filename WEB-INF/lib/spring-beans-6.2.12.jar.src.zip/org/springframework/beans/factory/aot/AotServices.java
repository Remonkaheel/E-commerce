/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AotServices<T>
/*     */   implements Iterable<T>
/*     */ {
/*     */   public static final String FACTORIES_RESOURCE_LOCATION = "META-INF/spring/aot.factories";
/*     */   private final List<T> services;
/*     */   private final Map<String, T> beans;
/*     */   private final Map<T, Source> sources;
/*     */   
/*     */   private AotServices(List<T> loaded, Map<String, T> beans) {
/*  61 */     this.services = collectServices(loaded, beans);
/*  62 */     this.sources = collectSources(loaded, beans.values());
/*  63 */     this.beans = beans;
/*     */   }
/*     */   
/*     */   private List<T> collectServices(List<T> loaded, Map<String, T> beans) {
/*  67 */     List<T> services = new ArrayList<>();
/*  68 */     services.addAll(beans.values());
/*  69 */     services.addAll(loaded);
/*  70 */     AnnotationAwareOrderComparator.sort(services);
/*  71 */     return Collections.unmodifiableList(services);
/*     */   }
/*     */   
/*     */   private Map<T, Source> collectSources(Collection<T> loaded, Collection<T> beans) {
/*  75 */     Map<T, Source> sources = new IdentityHashMap<>();
/*  76 */     loaded.forEach(service -> sources.put(service, Source.SPRING_FACTORIES_LOADER));
/*  77 */     beans.forEach(service -> sources.put(service, Source.BEAN_FACTORY));
/*  78 */     return Collections.unmodifiableMap(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Loader factories() {
/*  87 */     return factories((ClassLoader)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Loader factories(@Nullable ClassLoader classLoader) {
/*  97 */     return factories(getSpringFactoriesLoader(classLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Loader factories(SpringFactoriesLoader springFactoriesLoader) {
/* 107 */     Assert.notNull(springFactoriesLoader, "'springFactoriesLoader' must not be null");
/* 108 */     return new Loader(springFactoriesLoader, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Loader factoriesAndBeans(ListableBeanFactory beanFactory) {
/* 119 */     ConfigurableBeanFactory configurableBeanFactory = (ConfigurableBeanFactory)beanFactory;
/* 120 */     ClassLoader classLoader = (beanFactory instanceof ConfigurableBeanFactory) ? configurableBeanFactory.getBeanClassLoader() : null;
/* 121 */     return factoriesAndBeans(getSpringFactoriesLoader(classLoader), beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Loader factoriesAndBeans(SpringFactoriesLoader springFactoriesLoader, ListableBeanFactory beanFactory) {
/* 132 */     Assert.notNull(beanFactory, "'beanFactory' must not be null");
/* 133 */     Assert.notNull(springFactoriesLoader, "'springFactoriesLoader' must not be null");
/* 134 */     return new Loader(springFactoriesLoader, beanFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   private static SpringFactoriesLoader getSpringFactoriesLoader(@Nullable ClassLoader classLoader) {
/* 139 */     return SpringFactoriesLoader.forResourceLocation("META-INF/spring/aot.factories", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 145 */     return this.services.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<T> stream() {
/* 153 */     return this.services.stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> asList() {
/* 161 */     return this.services;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T findByBeanName(String beanName) {
/* 171 */     return this.beans.get(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Source getSource(T service) {
/* 180 */     Source source = this.sources.get(service);
/* 181 */     Assert.state((source != null), () -> "Unable to find service " + ObjectUtils.identityToString(source));
/*     */     
/* 183 */     return source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Loader
/*     */   {
/*     */     private final SpringFactoriesLoader springFactoriesLoader;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ListableBeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     Loader(SpringFactoriesLoader springFactoriesLoader, @Nullable ListableBeanFactory beanFactory) {
/* 199 */       this.springFactoriesLoader = springFactoriesLoader;
/* 200 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> AotServices<T> load(Class<T> type) {
/* 211 */       return new AotServices<>(this.springFactoriesLoader.load(type), loadBeans(type));
/*     */     }
/*     */     
/*     */     private <T> Map<String, T> loadBeans(Class<T> type) {
/* 215 */       return (this.beanFactory != null) ? 
/* 216 */         BeanFactoryUtils.beansOfTypeIncludingAncestors(this.beanFactory, type, true, false) : 
/* 217 */         Collections.<String, T>emptyMap();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Source
/*     */   {
/* 230 */     SPRING_FACTORIES_LOADER,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     BEAN_FACTORY;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AotServices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */