/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface AutowiredArguments
/*    */ {
/*    */   @Nullable
/*    */   default <T> T get(int index, Class<T> requiredType) {
/* 45 */     Object value = getObject(index);
/* 46 */     if (!ClassUtils.isAssignableValue(requiredType, value)) {
/* 47 */       throw new IllegalArgumentException("Argument type mismatch: expected '" + 
/* 48 */           ClassUtils.getQualifiedName(requiredType) + "' for value [" + String.valueOf(value) + "]");
/*    */     }
/* 50 */     return (T)value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   default <T> T get(int index) {
/* 62 */     return (T)getObject(index);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   default Object getObject(int index) {
/* 72 */     return toArray()[index];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Object[] toArray();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static AutowiredArguments of(Object[] arguments) {
/* 88 */     Assert.notNull(arguments, "'arguments' must not be null");
/* 89 */     return () -> arguments;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AutowiredArguments.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */