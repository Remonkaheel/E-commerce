/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.BiConsumer;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanRegistrationsAotContribution
/*     */   implements BeanFactoryInitializationAotContribution
/*     */ {
/*     */   private static final String BEAN_FACTORY_PARAMETER_NAME = "beanFactory";
/*     */   private static final int MAX_REGISTRATIONS_PER_FILE = 5000;
/*     */   private static final int MAX_REGISTRATIONS_PER_METHOD = 1000;
/*  61 */   private static final MethodReference.ArgumentCodeGenerator argumentCodeGenerator = MethodReference.ArgumentCodeGenerator.of(DefaultListableBeanFactory.class, "beanFactory");
/*     */   
/*     */   private final List<Registration> registrations;
/*     */ 
/*     */   
/*     */   BeanRegistrationsAotContribution(List<Registration> registrations) {
/*  67 */     this.registrations = registrations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/*  75 */     GeneratedClass generatedClass = createBeanFactoryRegistrationClass(generationContext);
/*  76 */     BeanRegistrationsCodeGenerator codeGenerator = new BeanRegistrationsCodeGenerator(generatedClass);
/*  77 */     GeneratedMethod generatedBeanDefinitionsMethod = generateBeanRegistrationCode(generationContext, generatedClass, codeGenerator);
/*     */     
/*  79 */     beanFactoryInitializationCode.addInitializer(generatedBeanDefinitionsMethod.toMethodReference());
/*  80 */     GeneratedMethod generatedAliasesMethod = codeGenerator.getMethods().add("registerAliases", this::generateRegisterAliasesMethod);
/*     */     
/*  82 */     beanFactoryInitializationCode.addInitializer(generatedAliasesMethod.toMethodReference());
/*  83 */     generateRegisterHints(generationContext.getRuntimeHints(), this.registrations);
/*     */   }
/*     */   
/*     */   private GeneratedMethod generateBeanRegistrationCode(GenerationContext generationContext, GeneratedClass mainGeneratedClass, BeanRegistrationsCodeGenerator mainCodeGenerator) {
/*  87 */     if (this.registrations.size() < 5000) {
/*  88 */       return generateBeanRegistrationClass(generationContext, mainCodeGenerator, 0, this.registrations.size());
/*     */     }
/*     */     
/*  91 */     return mainGeneratedClass.getMethods().add("registerBeanDefinitions", method -> {
/*     */           method.addJavadoc("Register the bean definitions.", new Object[0]);
/*     */           method.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */           method.addParameter(DefaultListableBeanFactory.class, "beanFactory", new Modifier[0]);
/*     */           CodeBlock.Builder body = CodeBlock.builder();
/*     */           Registration.doWithSlice(this.registrations, 5000, ());
/*     */           method.addCode(body.build());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GeneratedMethod generateBeanRegistrationClass(GenerationContext generationContext, BeanRegistrationsCodeGenerator codeGenerator, int start, int end) {
/* 110 */     return codeGenerator.getMethods().add("registerBeanDefinitions", method -> {
/*     */           method.addJavadoc("Register the bean definitions.", new Object[0]);
/*     */           method.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */           method.addParameter(DefaultListableBeanFactory.class, "beanFactory", new Modifier[0]);
/*     */           List<Registration> sliceRegistrations = this.registrations.subList(start, end);
/*     */           (new BeanDefinitionsRegistrationGenerator(generationContext, codeGenerator, sliceRegistrations, start)).generateBeanRegistrationsCode(method);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private static GeneratedClass createBeanFactoryRegistrationClass(GenerationContext generationContext) {
/* 121 */     return generationContext.getGeneratedClasses()
/* 122 */       .addForFeature("BeanFactoryRegistrations", type -> {
/*     */           type.addJavadoc("Register bean definitions for the bean factory.", new Object[0]);
/*     */           type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */         });
/*     */   }
/*     */   
/*     */   private void generateRegisterAliasesMethod(MethodSpec.Builder method) {
/* 129 */     method.addJavadoc("Register the aliases.", new Object[0]);
/* 130 */     method.addModifiers(new Modifier[] { Modifier.PUBLIC });
/* 131 */     method.addParameter(DefaultListableBeanFactory.class, "beanFactory", new Modifier[0]);
/* 132 */     CodeBlock.Builder code = CodeBlock.builder();
/* 133 */     this.registrations.forEach(registration -> {
/*     */           for (String alias : registration.aliases()) {
/*     */             code.addStatement("$L.registerAlias($S, $S)", new Object[] { "beanFactory", registration.beanName(), alias });
/*     */           } 
/*     */         });
/*     */     
/* 139 */     method.addCode(code.build());
/*     */   }
/*     */   
/*     */   private void generateRegisterHints(RuntimeHints runtimeHints, List<Registration> registrations) {
/* 143 */     registrations.forEach(registration -> {
/*     */           ReflectionHints hints = runtimeHints.reflection();
/*     */           Class<?> beanClass = registration.registeredBean.getBeanClass();
/*     */           hints.registerType(beanClass, new MemberCategory[] { MemberCategory.INTROSPECT_PUBLIC_METHODS, MemberCategory.INTROSPECT_DECLARED_METHODS });
/*     */           hints.registerForInterfaces(beanClass, ());
/*     */         });
/*     */   }
/*     */   
/*     */   static final class Registration
/*     */     extends Record {
/*     */     private final RegisteredBean registeredBean;
/*     */     private final BeanDefinitionMethodGenerator methodGenerator;
/*     */     
/*     */     Registration(RegisteredBean registeredBean, BeanDefinitionMethodGenerator methodGenerator, String[] aliases) {
/* 157 */       this.registeredBean = registeredBean; this.methodGenerator = methodGenerator; this.aliases = aliases; } private final String[] aliases; public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/beans/factory/aot/BeanRegistrationsAotContribution$Registration;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #157	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/aot/BeanRegistrationsAotContribution$Registration; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/beans/factory/aot/BeanRegistrationsAotContribution$Registration;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #157	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/aot/BeanRegistrationsAotContribution$Registration; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/beans/factory/aot/BeanRegistrationsAotContribution$Registration;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #157	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/beans/factory/aot/BeanRegistrationsAotContribution$Registration;
/* 157 */       //   0	8	1	o	Ljava/lang/Object; } public RegisteredBean registeredBean() { return this.registeredBean; } public BeanDefinitionMethodGenerator methodGenerator() { return this.methodGenerator; } public String[] aliases() { return this.aliases; }
/*     */     
/*     */     String beanName() {
/* 160 */       return this.registeredBean.getBeanName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static void doWithSlice(List<Registration> registrations, int sliceSize, BiConsumer<Integer, Integer> action) {
/* 175 */       int index = 0;
/* 176 */       int end = 0;
/* 177 */       while (end < registrations.size()) {
/* 178 */         int start = index * sliceSize;
/* 179 */         end = Math.min(start + sliceSize, registrations.size());
/* 180 */         action.accept(Integer.valueOf(start), Integer.valueOf(end));
/* 181 */         index++;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class BeanRegistrationsCodeGenerator
/*     */     implements BeanRegistrationsCode
/*     */   {
/*     */     private final GeneratedClass generatedClass;
/*     */ 
/*     */ 
/*     */     
/*     */     public BeanRegistrationsCodeGenerator(GeneratedClass generatedClass) {
/* 196 */       this.generatedClass = generatedClass;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassName getClassName() {
/* 202 */       return this.generatedClass.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public GeneratedMethods getMethods() {
/* 207 */       return this.generatedClass.getMethods();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class BeanDefinitionsRegistrationGenerator
/*     */   {
/*     */     private final GenerationContext generationContext;
/*     */ 
/*     */     
/*     */     private final BeanRegistrationsAotContribution.BeanRegistrationsCodeGenerator codeGenerator;
/*     */ 
/*     */     
/*     */     private final List<BeanRegistrationsAotContribution.Registration> registrations;
/*     */ 
/*     */     
/*     */     private final int globalStart;
/*     */ 
/*     */ 
/*     */     
/*     */     BeanDefinitionsRegistrationGenerator(GenerationContext generationContext, BeanRegistrationsAotContribution.BeanRegistrationsCodeGenerator codeGenerator, List<BeanRegistrationsAotContribution.Registration> registrations, int globalStart) {
/* 230 */       this.generationContext = generationContext;
/* 231 */       this.codeGenerator = codeGenerator;
/* 232 */       this.registrations = registrations;
/* 233 */       this.globalStart = globalStart;
/*     */     }
/*     */     
/*     */     void generateBeanRegistrationsCode(MethodSpec.Builder method) {
/* 237 */       if (this.registrations.size() <= 1000) {
/* 238 */         generateRegisterBeanDefinitionMethods(method, this.registrations);
/*     */       } else {
/*     */         
/* 241 */         CodeBlock.Builder code = CodeBlock.builder();
/* 242 */         code.add("// Registration is sliced to avoid exceeding size limit\n", new Object[0]);
/* 243 */         BeanRegistrationsAotContribution.Registration.doWithSlice(this.registrations, 1000, (start, end) -> {
/*     */               GeneratedMethod sliceMethod = generateSliceMethod(start.intValue(), end.intValue());
/*     */               
/*     */               code.addStatement(sliceMethod.toMethodReference().toInvokeCodeBlock(BeanRegistrationsAotContribution.argumentCodeGenerator, this.codeGenerator.getClassName()));
/*     */             });
/*     */         
/* 249 */         method.addCode(code.build());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private GeneratedMethod generateSliceMethod(int start, int end) {
/* 255 */       String description = "Register the bean definitions from %s to %s.".formatted(new Object[] { Integer.valueOf(this.globalStart + start), Integer.valueOf(this.globalStart + end - 1) });
/* 256 */       List<BeanRegistrationsAotContribution.Registration> slice = this.registrations.subList(start, end);
/* 257 */       return this.codeGenerator.getMethods().add("registerBeanDefinitions", method -> {
/*     */             method.addJavadoc(description, new Object[0]);
/*     */             method.addModifiers(new Modifier[] { Modifier.PRIVATE });
/*     */             method.addParameter(DefaultListableBeanFactory.class, "beanFactory", new Modifier[0]);
/*     */             generateRegisterBeanDefinitionMethods(method, slice);
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void generateRegisterBeanDefinitionMethods(MethodSpec.Builder method, Iterable<BeanRegistrationsAotContribution.Registration> registrations) {
/* 269 */       CodeBlock.Builder code = CodeBlock.builder();
/* 270 */       registrations.forEach(registration -> {
/*     */             try {
/*     */               CodeBlock methodInvocation = generateBeanRegistration(registration);
/*     */ 
/*     */               
/*     */               code.addStatement("$L.registerBeanDefinition($S, $L)", new Object[] { "beanFactory", registration.beanName(), methodInvocation });
/* 276 */             } catch (AotException ex) {
/*     */               
/*     */               throw ex;
/* 279 */             } catch (Exception ex) {
/*     */               throw new AotBeanProcessingException(registration.registeredBean, "failed to generate code for bean definition", ex);
/*     */             } 
/*     */           });
/*     */       
/* 284 */       method.addCode(code.build());
/*     */     }
/*     */ 
/*     */     
/*     */     private CodeBlock generateBeanRegistration(BeanRegistrationsAotContribution.Registration registration) {
/* 289 */       MethodReference beanDefinitionMethod = registration.methodGenerator.generateBeanDefinitionMethod(this.generationContext, this.codeGenerator);
/* 290 */       return beanDefinitionMethod.toInvokeCodeBlock(
/* 291 */           MethodReference.ArgumentCodeGenerator.none(), this.codeGenerator.getClassName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationsAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */