/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Executable;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.javapoet.CodeBlock;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutowiredArgumentsCodeGenerator
/*    */ {
/*    */   private final Class<?> target;
/*    */   private final Executable executable;
/*    */   
/*    */   public AutowiredArgumentsCodeGenerator(Class<?> target, Executable executable) {
/* 50 */     this.target = target;
/* 51 */     this.executable = executable;
/*    */   }
/*    */ 
/*    */   
/*    */   public CodeBlock generateCode(Class<?>[] parameterTypes) {
/* 56 */     return generateCode(parameterTypes, 0, "args");
/*    */   }
/*    */   
/*    */   public CodeBlock generateCode(Class<?>[] parameterTypes, int startIndex) {
/* 60 */     return generateCode(parameterTypes, startIndex, "args");
/*    */   }
/*    */   
/*    */   public CodeBlock generateCode(Class<?>[] parameterTypes, int startIndex, String variableName) {
/* 64 */     Assert.notNull(parameterTypes, "'parameterTypes' must not be null");
/* 65 */     Assert.notNull(variableName, "'variableName' must not be null");
/* 66 */     boolean ambiguous = isAmbiguous();
/* 67 */     CodeBlock.Builder code = CodeBlock.builder();
/* 68 */     for (int i = startIndex; i < parameterTypes.length; i++) {
/* 69 */       code.add((i > startIndex) ? ", " : "", new Object[0]);
/* 70 */       if (!ambiguous) {
/* 71 */         code.add("$L.get($L)", new Object[] { variableName, Integer.valueOf(i) });
/*    */       } else {
/*    */         
/* 74 */         code.add("$L.get($L, $T.class)", new Object[] { variableName, Integer.valueOf(i), parameterTypes[i] });
/*    */       } 
/*    */     } 
/* 77 */     return code.build();
/*    */   }
/*    */   
/*    */   private boolean isAmbiguous() {
/* 81 */     Executable executable = this.executable; if (executable instanceof Constructor) { Constructor<?> constructor = (Constructor)executable;
/*    */       
/* 83 */       Objects.requireNonNull(constructor); return Arrays.<Constructor<?>>stream(this.target.getDeclaredConstructors()).filter(Predicate.not(constructor::equals))
/* 84 */         .anyMatch(this::hasSameParameterCount); }
/*    */     
/* 86 */     executable = this.executable; if (executable instanceof Method) { Method method = (Method)executable;
/*    */       
/* 88 */       Objects.requireNonNull(method); return Arrays.<Method>stream(ReflectionUtils.getAllDeclaredMethods(this.target)).filter(Predicate.not(method::equals))
/* 89 */         .filter(candidate -> candidate.getName().equals(method.getName()))
/* 90 */         .anyMatch(this::hasSameParameterCount); }
/*    */     
/* 92 */     return true;
/*    */   }
/*    */   
/*    */   private boolean hasSameParameterCount(Executable executable) {
/* 96 */     return (this.executable.getParameterCount() == executable.getParameterCount());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AutowiredArgumentsCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */