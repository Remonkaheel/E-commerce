/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.function.UnaryOperator;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface BeanRegistrationAotContribution
/*     */ {
/*     */   default BeanRegistrationCodeFragments customizeBeanRegistrationCodeFragments(GenerationContext generationContext, BeanRegistrationCodeFragments codeFragments) {
/*  48 */     return codeFragments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void applyTo(GenerationContext paramGenerationContext, BeanRegistrationCode paramBeanRegistrationCode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BeanRegistrationAotContribution withCustomCodeFragments(final UnaryOperator<BeanRegistrationCodeFragments> defaultCodeFragments) {
/*  70 */     Assert.notNull(defaultCodeFragments, "'defaultCodeFragments' must not be null");
/*     */     
/*  72 */     return new BeanRegistrationAotContribution()
/*     */       {
/*     */         public BeanRegistrationCodeFragments customizeBeanRegistrationCodeFragments(GenerationContext generationContext, BeanRegistrationCodeFragments codeFragments)
/*     */         {
/*  76 */           return defaultCodeFragments.apply(codeFragments);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {}
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static BeanRegistrationAotContribution concat(@Nullable BeanRegistrationAotContribution a, @Nullable BeanRegistrationAotContribution b) {
/*  99 */     if (a == null) {
/* 100 */       return b;
/*     */     }
/* 102 */     if (b == null) {
/* 103 */       return a;
/*     */     }
/* 105 */     return (generationContext, beanRegistrationCode) -> {
/*     */         a.applyTo(generationContext, beanRegistrationCode);
/*     */         b.applyTo(generationContext, beanRegistrationCode);
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */