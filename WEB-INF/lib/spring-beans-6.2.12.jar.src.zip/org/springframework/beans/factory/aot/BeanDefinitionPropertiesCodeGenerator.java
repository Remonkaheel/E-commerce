/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.BiPredicate;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.ValueCodeGenerator;
/*     */ import org.springframework.aot.generate.ValueCodeGeneratorDelegates;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.LookupOverride;
/*     */ import org.springframework.beans.factory.support.MethodOverride;
/*     */ import org.springframework.beans.factory.support.ReplaceOverride;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanDefinitionPropertiesCodeGenerator
/*     */ {
/*  90 */   private static final RootBeanDefinition DEFAULT_BEAN_DEFINITION = new RootBeanDefinition();
/*     */ 
/*     */   
/*     */   private static final String BEAN_DEFINITION_VARIABLE = "beanDefinition";
/*     */ 
/*     */   
/*     */   private final RuntimeHints hints;
/*     */ 
/*     */   
/*     */   private final Predicate<String> attributeFilter;
/*     */ 
/*     */   
/*     */   private final ValueCodeGenerator valueCodeGenerator;
/*     */ 
/*     */   
/*     */   BeanDefinitionPropertiesCodeGenerator(RuntimeHints hints, Predicate<String> attributeFilter, GeneratedMethods generatedMethods, List<ValueCodeGenerator.Delegate> additionalDelegates, BiFunction<String, Object, CodeBlock> customValueCodeGenerator) {
/* 106 */     this.hints = hints;
/* 107 */     this.attributeFilter = attributeFilter;
/* 108 */     List<ValueCodeGenerator.Delegate> allDelegates = new ArrayList<>();
/* 109 */     allDelegates.add((valueCodeGenerator, value) -> (CodeBlock)customValueCodeGenerator.apply(PropertyNamesStack.peek(), value));
/* 110 */     allDelegates.addAll(additionalDelegates);
/* 111 */     allDelegates.addAll(BeanDefinitionPropertyValueCodeGeneratorDelegates.INSTANCES);
/* 112 */     allDelegates.addAll(ValueCodeGeneratorDelegates.INSTANCES);
/* 113 */     this.valueCodeGenerator = ValueCodeGenerator.with(allDelegates).scoped(generatedMethods);
/*     */   }
/*     */ 
/*     */   
/*     */   CodeBlock generateCode(RootBeanDefinition beanDefinition) {
/* 118 */     CodeBlock.Builder code = CodeBlock.builder();
/* 119 */     addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::getScope, this::hasScope, "$L.setScope($S)");
/*     */     
/* 121 */     addStatementForValue(code, (BeanDefinition)beanDefinition, AbstractBeanDefinition::isBackgroundInit, "$L.setBackgroundInit($L)");
/*     */     
/* 123 */     addStatementForValue(code, (BeanDefinition)beanDefinition, AbstractBeanDefinition::getLazyInit, "$L.setLazyInit($L)");
/*     */     
/* 125 */     addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::getDependsOn, this::hasDependsOn, "$L.setDependsOn($L)", this::toStringVarArgs);
/*     */     
/* 127 */     addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::isAutowireCandidate, "$L.setAutowireCandidate($L)");
/*     */     
/* 129 */     addStatementForValue(code, (BeanDefinition)beanDefinition, AbstractBeanDefinition::isDefaultCandidate, "$L.setDefaultCandidate($L)");
/*     */     
/* 131 */     addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::isPrimary, "$L.setPrimary($L)");
/*     */     
/* 133 */     addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::isFallback, "$L.setFallback($L)");
/*     */     
/* 135 */     addStatementForValue(code, (BeanDefinition)beanDefinition, AbstractBeanDefinition::isSynthetic, "$L.setSynthetic($L)");
/*     */     
/* 137 */     addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::getRole, this::hasRole, "$L.setRole($L)", this::toRole);
/*     */     
/* 139 */     addInitDestroyMethods(code, (AbstractBeanDefinition)beanDefinition, beanDefinition.getInitMethodNames(), "$L.setInitMethodNames($L)");
/*     */     
/* 141 */     addInitDestroyMethods(code, (AbstractBeanDefinition)beanDefinition, beanDefinition.getDestroyMethodNames(), "$L.setDestroyMethodNames($L)");
/*     */     
/* 143 */     if (beanDefinition.getFactoryBeanName() != null) {
/* 144 */       addStatementForValue(code, (BeanDefinition)beanDefinition, BeanDefinition::getFactoryBeanName, "$L.setFactoryBeanName(\"$L\")");
/*     */     }
/*     */     
/* 147 */     addConstructorArgumentValues(code, (BeanDefinition)beanDefinition);
/* 148 */     addPropertyValues(code, beanDefinition);
/* 149 */     addAttributes(code, (BeanDefinition)beanDefinition);
/* 150 */     addQualifiers(code, beanDefinition);
/* 151 */     addMethodOverrides(code, beanDefinition);
/* 152 */     return code.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addInitDestroyMethods(CodeBlock.Builder code, AbstractBeanDefinition beanDefinition, @Nullable String[] methodNames, String format) {
/* 159 */     this.hints.reflection().registerType(TypeReference.of("org.reactivestreams.Publisher"), new MemberCategory[0]);
/* 160 */     if (!ObjectUtils.isEmpty((Object[])methodNames)) {
/* 161 */       Class<?> beanType = ClassUtils.getUserClass(beanDefinition.getResolvableType().toClass());
/* 162 */       Arrays.<String>stream(methodNames).forEach(methodName -> addInitDestroyHint(beanType, methodName));
/*     */ 
/*     */       
/* 165 */       CodeBlock arguments = (CodeBlock)Arrays.<String>stream(methodNames).map(name -> CodeBlock.of("$S", new Object[] { name })).collect(CodeBlock.joining(", "));
/* 166 */       code.addStatement(format, new Object[] { "beanDefinition", arguments });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addInitDestroyHint(Class<?> beanUserClass, String methodName) {
/* 171 */     Class<?> methodDeclaringClass = beanUserClass;
/*     */ 
/*     */     
/* 174 */     int indexOfDot = methodName.lastIndexOf('.');
/* 175 */     if (indexOfDot > 0) {
/* 176 */       String className = methodName.substring(0, indexOfDot);
/* 177 */       methodName = methodName.substring(indexOfDot + 1);
/* 178 */       if (!beanUserClass.getName().equals(className)) {
/*     */         try {
/* 180 */           methodDeclaringClass = ClassUtils.forName(className, beanUserClass.getClassLoader());
/*     */         }
/* 182 */         catch (Throwable ex) {
/* 183 */           throw new IllegalStateException("Failed to load Class [" + className + "] from ClassLoader [" + 
/* 184 */               String.valueOf(beanUserClass.getClassLoader()) + "]", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 189 */     Method method = ReflectionUtils.findMethod(methodDeclaringClass, methodName);
/* 190 */     if (method != null) {
/* 191 */       this.hints.reflection().registerMethod(method, ExecutableMode.INVOKE);
/* 192 */       Method publiclyAccessibleMethod = ClassUtils.getPubliclyAccessibleMethodIfPossible(method, beanUserClass);
/* 193 */       if (!publiclyAccessibleMethod.equals(method)) {
/* 194 */         this.hints.reflection().registerMethod(publiclyAccessibleMethod, ExecutableMode.INVOKE);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addConstructorArgumentValues(CodeBlock.Builder code, BeanDefinition beanDefinition) {
/* 200 */     ConstructorArgumentValues constructorValues = beanDefinition.getConstructorArgumentValues();
/* 201 */     Map<Integer, ConstructorArgumentValues.ValueHolder> indexedValues = constructorValues.getIndexedArgumentValues();
/* 202 */     if (!indexedValues.isEmpty()) {
/* 203 */       indexedValues.forEach((index, valueHolder) -> {
/*     */             Object value = valueHolder.getValue();
/*     */             
/*     */             CodeBlock valueCode = castIfNecessary((value == null), Object.class, generateValue(valueHolder.getName(), value));
/*     */             
/*     */             code.addStatement("$L.getConstructorArgumentValues().addIndexedArgumentValue($L, $L)", new Object[] { "beanDefinition", index, valueCode });
/*     */           });
/*     */     }
/*     */     
/* 212 */     List<ConstructorArgumentValues.ValueHolder> genericValues = constructorValues.getGenericArgumentValues();
/* 213 */     if (!genericValues.isEmpty()) {
/* 214 */       genericValues.forEach(valueHolder -> {
/*     */             String valueName = valueHolder.getName();
/*     */             CodeBlock valueCode = generateValue(valueName, valueHolder.getValue());
/*     */             if (valueName != null) {
/*     */               CodeBlock valueTypeCode = this.valueCodeGenerator.generateCode(valueHolder.getType());
/*     */               code.addStatement("$L.getConstructorArgumentValues().addGenericArgumentValue(new $T($L, $L, $S))", new Object[] { "beanDefinition", ConstructorArgumentValues.ValueHolder.class, valueCode, valueTypeCode, valueName });
/*     */             } else if (valueHolder.getType() != null) {
/*     */               code.addStatement("$L.getConstructorArgumentValues().addGenericArgumentValue($L, $S)", new Object[] { "beanDefinition", valueCode, valueHolder.getType() });
/*     */             } else {
/*     */               code.addStatement("$L.getConstructorArgumentValues().addGenericArgumentValue($L)", new Object[] { "beanDefinition", valueCode });
/*     */             } 
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addPropertyValues(CodeBlock.Builder code, RootBeanDefinition beanDefinition) {
/* 236 */     MutablePropertyValues propertyValues = beanDefinition.getPropertyValues();
/* 237 */     if (!propertyValues.isEmpty()) {
/* 238 */       Class<?> infrastructureType = getInfrastructureType(beanDefinition);
/*     */       
/* 240 */       Map<String, Method> writeMethods = (infrastructureType != Object.class) ? getWriteMethods(infrastructureType) : Collections.<String, Method>emptyMap();
/* 241 */       for (PropertyValue propertyValue : propertyValues) {
/* 242 */         String name = propertyValue.getName();
/* 243 */         CodeBlock valueCode = generateValue(name, propertyValue.getValue());
/* 244 */         code.addStatement("$L.getPropertyValues().addPropertyValue($S, $L)", new Object[] { "beanDefinition", name, valueCode });
/*     */         
/* 246 */         Method writeMethod = writeMethods.get(name);
/* 247 */         if (writeMethod != null) {
/* 248 */           registerReflectionHints(beanDefinition, writeMethod);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerReflectionHints(RootBeanDefinition beanDefinition, Method writeMethod) {
/* 255 */     this.hints.reflection().registerMethod(writeMethod, ExecutableMode.INVOKE);
/*     */     
/* 257 */     Class<?> searchType = beanDefinition.getTargetType();
/* 258 */     while (searchType != null && searchType != writeMethod.getDeclaringClass()) {
/* 259 */       this.hints.reflection().registerType(searchType, new MemberCategory[] { MemberCategory.DECLARED_FIELDS });
/* 260 */       searchType = searchType.getSuperclass();
/*     */     } 
/* 262 */     this.hints.reflection().registerType(writeMethod.getDeclaringClass(), new MemberCategory[] { MemberCategory.DECLARED_FIELDS });
/*     */   }
/*     */   
/*     */   private void addQualifiers(CodeBlock.Builder code, RootBeanDefinition beanDefinition) {
/* 266 */     Set<AutowireCandidateQualifier> qualifiers = beanDefinition.getQualifiers();
/* 267 */     if (!qualifiers.isEmpty()) {
/* 268 */       for (AutowireCandidateQualifier qualifier : qualifiers) {
/* 269 */         Collection<CodeBlock> arguments = new ArrayList<>();
/* 270 */         arguments.add(CodeBlock.of("$S", new Object[] { qualifier.getTypeName() }));
/* 271 */         Object qualifierValue = qualifier.getAttribute("value");
/* 272 */         if (qualifierValue != null) {
/* 273 */           arguments.add(generateValue("value", qualifierValue));
/*     */         }
/* 275 */         code.addStatement("$L.addQualifier(new $T($L))", new Object[] { "beanDefinition", AutowireCandidateQualifier.class, 
/* 276 */               CodeBlock.join(arguments, ", ") });
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMethodOverrides(CodeBlock.Builder code, RootBeanDefinition beanDefinition) {
/* 282 */     if (beanDefinition.hasMethodOverrides()) {
/* 283 */       for (MethodOverride methodOverride : beanDefinition.getMethodOverrides().getOverrides()) {
/* 284 */         if (methodOverride instanceof LookupOverride) { LookupOverride lookupOverride = (LookupOverride)methodOverride;
/* 285 */           Collection<CodeBlock> arguments = new ArrayList<>();
/* 286 */           arguments.add(CodeBlock.of("$S", new Object[] { lookupOverride.getMethodName() }));
/* 287 */           arguments.add(CodeBlock.of("$S", new Object[] { lookupOverride.getBeanName() }));
/* 288 */           code.addStatement("$L.getMethodOverrides().addOverride(new $T($L))", new Object[] { "beanDefinition", LookupOverride.class, 
/* 289 */                 CodeBlock.join(arguments, ", ") }); continue; }
/*     */         
/* 291 */         if (methodOverride instanceof ReplaceOverride) { ReplaceOverride replaceOverride = (ReplaceOverride)methodOverride;
/* 292 */           Collection<CodeBlock> arguments = new ArrayList<>();
/* 293 */           arguments.add(CodeBlock.of("$S", new Object[] { replaceOverride.getMethodName() }));
/* 294 */           arguments.add(CodeBlock.of("$S", new Object[] { replaceOverride.getMethodReplacerBeanName() }));
/* 295 */           List<String> typeIdentifiers = replaceOverride.getTypeIdentifiers();
/* 296 */           if (!typeIdentifiers.isEmpty())
/* 297 */             arguments.add(CodeBlock.of("java.util.List.of($S)", new Object[] {
/* 298 */                     StringUtils.collectionToDelimitedString(typeIdentifiers, ", ")
/*     */                   })); 
/* 300 */           code.addStatement("$L.getMethodOverrides().addOverride(new $T($L))", new Object[] { "beanDefinition", ReplaceOverride.class, 
/* 301 */                 CodeBlock.join(arguments, ", ") });
/*     */           continue; }
/*     */         
/* 304 */         throw new UnsupportedOperationException("Unexpected MethodOverride subclass: " + methodOverride
/* 305 */             .getClass().getName());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock generateValue(@Nullable String name, @Nullable Object value) {
/* 312 */     PropertyNamesStack.push(name);
/*     */     try {
/* 314 */       return this.valueCodeGenerator.generateCode(value);
/*     */     } finally {
/*     */       
/* 317 */       PropertyNamesStack.pop();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class<?> getInfrastructureType(RootBeanDefinition beanDefinition) {
/* 322 */     if (beanDefinition.hasBeanClass()) {
/* 323 */       Class<?> beanClass = beanDefinition.getBeanClass();
/* 324 */       if (FactoryBean.class.isAssignableFrom(beanClass)) {
/* 325 */         return beanClass;
/*     */       }
/*     */     } 
/* 328 */     return ClassUtils.getUserClass(beanDefinition.getResolvableType().toClass());
/*     */   }
/*     */   
/*     */   private Map<String, Method> getWriteMethods(Class<?> clazz) {
/* 332 */     Map<String, Method> writeMethods = new HashMap<>();
/* 333 */     for (PropertyDescriptor propertyDescriptor : BeanUtils.getPropertyDescriptors(clazz)) {
/* 334 */       writeMethods.put(propertyDescriptor.getName(), propertyDescriptor.getWriteMethod());
/*     */     }
/* 336 */     return Collections.unmodifiableMap(writeMethods);
/*     */   }
/*     */   
/*     */   private void addAttributes(CodeBlock.Builder code, BeanDefinition beanDefinition) {
/* 340 */     String[] attributeNames = beanDefinition.attributeNames();
/* 341 */     if (!ObjectUtils.isEmpty((Object[])attributeNames)) {
/* 342 */       for (String attributeName : attributeNames) {
/* 343 */         if (this.attributeFilter.test(attributeName)) {
/*     */           
/* 345 */           CodeBlock value = this.valueCodeGenerator.generateCode(beanDefinition.getAttribute(attributeName));
/* 346 */           code.addStatement("$L.setAttribute($S, $L)", new Object[] { "beanDefinition", attributeName, value });
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasScope(String defaultValue, String actualValue) {
/* 354 */     return (StringUtils.hasText(actualValue) && !"singleton".equals(actualValue));
/*     */   }
/*     */   
/*     */   private boolean hasDependsOn(String[] defaultValue, String[] actualValue) {
/* 358 */     return !ObjectUtils.isEmpty((Object[])actualValue);
/*     */   }
/*     */   
/*     */   private boolean hasRole(int defaultValue, int actualValue) {
/* 362 */     return (actualValue != 0);
/*     */   }
/*     */   
/*     */   private CodeBlock toStringVarArgs(String[] strings) {
/* 366 */     return (CodeBlock)Arrays.<String>stream(strings).map(string -> CodeBlock.of("$S", new Object[] { string })).collect(CodeBlock.joining(","));
/*     */   }
/*     */   
/*     */   private Object toRole(int value) {
/* 370 */     switch (value) { case 2: case 1:  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 375 */       Integer.valueOf(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <B extends BeanDefinition, T> void addStatementForValue(CodeBlock.Builder code, BeanDefinition beanDefinition, Function<B, T> getter, String format) {
/* 382 */     addStatementForValue(code, beanDefinition, getter, (defaultValue, actualValue) -> !Objects.equals(defaultValue, actualValue), format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <B extends BeanDefinition, T> void addStatementForValue(CodeBlock.Builder code, BeanDefinition beanDefinition, Function<B, T> getter, BiPredicate<T, T> filter, String format) {
/* 390 */     addStatementForValue(code, beanDefinition, getter, filter, format, actualValue -> actualValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <B extends BeanDefinition, T> void addStatementForValue(CodeBlock.Builder code, BeanDefinition beanDefinition, Function<B, T> getter, BiPredicate<T, T> filter, String format, Function<T, Object> formatter) {
/* 398 */     T defaultValue = getter.apply((B)DEFAULT_BEAN_DEFINITION);
/* 399 */     T actualValue = getter.apply((B)beanDefinition);
/* 400 */     if (filter.test(defaultValue, actualValue)) {
/* 401 */       code.addStatement(format, new Object[] { "beanDefinition", formatter.apply(actualValue) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock castIfNecessary(boolean castNecessary, Class<?> castType, CodeBlock valueCode) {
/* 415 */     return castNecessary ? CodeBlock.of("($T) $L", new Object[] { castType, valueCode }) : valueCode;
/*     */   }
/*     */ 
/*     */   
/*     */   static class PropertyNamesStack
/*     */   {
/* 421 */     private static final ThreadLocal<ArrayDeque<String>> threadLocal = ThreadLocal.withInitial(ArrayDeque::new);
/*     */     
/*     */     static void push(@Nullable String name) {
/* 424 */       String valueToSet = (name != null) ? name : "";
/* 425 */       ((ArrayDeque<String>)threadLocal.get()).push(valueToSet);
/*     */     }
/*     */     
/*     */     static void pop() {
/* 429 */       ((ArrayDeque)threadLocal.get()).pop();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     static String peek() {
/* 434 */       String value = ((ArrayDeque<String>)threadLocal.get()).peek();
/* 435 */       return "".equals(value) ? null : value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionPropertiesCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */