/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.aot.generate.GeneratedMethods;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.generate.MethodReference;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.javapoet.ClassName;
/*    */ import org.springframework.javapoet.CodeBlock;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanRegistrationCodeGenerator
/*    */   implements BeanRegistrationCode
/*    */ {
/*    */   private static final Predicate<String> REJECT_ALL_ATTRIBUTES_FILTER = attribute -> false;
/*    */   private final ClassName className;
/*    */   private final GeneratedMethods generatedMethods;
/* 45 */   private final List<MethodReference> instancePostProcessors = new ArrayList<>();
/*    */ 
/*    */   
/*    */   private final RegisteredBean registeredBean;
/*    */ 
/*    */   
/*    */   private final BeanRegistrationCodeFragments codeFragments;
/*    */ 
/*    */   
/*    */   BeanRegistrationCodeGenerator(ClassName className, GeneratedMethods generatedMethods, RegisteredBean registeredBean, BeanRegistrationCodeFragments codeFragments) {
/* 55 */     this.className = className;
/* 56 */     this.generatedMethods = generatedMethods;
/* 57 */     this.registeredBean = registeredBean;
/* 58 */     this.codeFragments = codeFragments;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ClassName getClassName() {
/* 64 */     return this.className;
/*    */   }
/*    */ 
/*    */   
/*    */   public GeneratedMethods getMethods() {
/* 69 */     return this.generatedMethods;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addInstancePostProcessor(MethodReference methodReference) {
/* 74 */     Assert.notNull(methodReference, "'methodReference' must not be null");
/* 75 */     this.instancePostProcessors.add(methodReference);
/*    */   }
/*    */   
/*    */   CodeBlock generateCode(GenerationContext generationContext) {
/* 79 */     CodeBlock.Builder code = CodeBlock.builder();
/* 80 */     code.add(this.codeFragments.generateNewBeanDefinitionCode(generationContext, this.registeredBean
/* 81 */           .getBeanType(), this));
/* 82 */     code.add(this.codeFragments.generateSetBeanDefinitionPropertiesCode(generationContext, this, this.registeredBean
/* 83 */           .getMergedBeanDefinition(), REJECT_ALL_ATTRIBUTES_FILTER));
/*    */     
/* 85 */     CodeBlock instanceSupplierCode = this.codeFragments.generateInstanceSupplierCode(generationContext, this, this.instancePostProcessors
/* 86 */         .isEmpty());
/* 87 */     code.add(this.codeFragments.generateSetBeanInstanceSupplierCode(generationContext, this, instanceSupplierCode, this.instancePostProcessors));
/*    */     
/* 89 */     code.add(this.codeFragments.generateReturnCode(generationContext, this));
/* 90 */     return code.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */