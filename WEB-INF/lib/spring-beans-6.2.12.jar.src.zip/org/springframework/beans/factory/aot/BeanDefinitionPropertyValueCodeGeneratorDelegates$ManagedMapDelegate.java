/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.springframework.aot.generate.ValueCodeGenerator;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ManagedMapDelegate
/*     */   implements ValueCodeGenerator.Delegate
/*     */ {
/* 102 */   private static final CodeBlock EMPTY_RESULT = CodeBlock.of("$T.ofEntries()", new Object[] { ManagedMap.class });
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/* 107 */     if (value instanceof ManagedMap) { ManagedMap<?, ?> managedMap = (ManagedMap<?, ?>)value;
/* 108 */       return generateManagedMapCode(valueCodeGenerator, managedMap); }
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <K, V> CodeBlock generateManagedMapCode(ValueCodeGenerator valueCodeGenerator, ManagedMap<K, V> managedMap) {
/* 115 */     if (managedMap.isEmpty()) {
/* 116 */       return EMPTY_RESULT;
/*     */     }
/* 118 */     CodeBlock.Builder code = CodeBlock.builder();
/* 119 */     code.add("$T.ofEntries(", new Object[] { ManagedMap.class });
/* 120 */     Iterator<Map.Entry<K, V>> iterator = managedMap.entrySet().iterator();
/* 121 */     while (iterator.hasNext()) {
/* 122 */       Map.Entry<?, ?> entry = iterator.next();
/* 123 */       code.add("$T.entry($L,$L)", new Object[] { Map.class, valueCodeGenerator
/* 124 */             .generateCode(entry.getKey()), valueCodeGenerator
/* 125 */             .generateCode(entry.getValue()) });
/* 126 */       if (iterator.hasNext()) {
/* 127 */         code.add(", ", new Object[0]);
/*     */       }
/*     */     } 
/* 130 */     code.add(")", new Object[0]);
/* 131 */     return code.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionPropertyValueCodeGeneratorDelegates$ManagedMapDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */