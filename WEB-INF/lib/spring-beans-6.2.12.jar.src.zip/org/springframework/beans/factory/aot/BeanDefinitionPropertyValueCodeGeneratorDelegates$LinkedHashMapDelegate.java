/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.ValueCodeGenerator;
/*     */ import org.springframework.aot.generate.ValueCodeGeneratorDelegates;
/*     */ import org.springframework.javapoet.AnnotationSpec;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LinkedHashMapDelegate
/*     */   extends ValueCodeGeneratorDelegates.MapDelegate
/*     */ {
/*     */   @Nullable
/*     */   protected CodeBlock generateMapCode(ValueCodeGenerator valueCodeGenerator, Map<?, ?> map) {
/* 144 */     GeneratedMethods generatedMethods = valueCodeGenerator.getGeneratedMethods();
/* 145 */     if (map instanceof LinkedHashMap && generatedMethods != null) {
/* 146 */       return generateLinkedHashMapCode(valueCodeGenerator, generatedMethods, map);
/*     */     }
/* 148 */     return super.generateMapCode(valueCodeGenerator, map);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateLinkedHashMapCode(ValueCodeGenerator valueCodeGenerator, GeneratedMethods generatedMethods, Map<?, ?> map) {
/* 154 */     GeneratedMethod generatedMethod = generatedMethods.add("getMap", method -> {
/*     */           method.addAnnotation(AnnotationSpec.builder(SuppressWarnings.class).addMember("value", "{\"rawtypes\", \"unchecked\"}", new Object[0]).build());
/*     */ 
/*     */           
/*     */           method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */           
/*     */           method.returns(Map.class);
/*     */           
/*     */           method.addStatement("$T map = new $T($L)", new Object[] { Map.class, LinkedHashMap.class, Integer.valueOf(map.size()) });
/*     */           
/*     */           map.forEach(());
/*     */           
/*     */           method.addStatement("return map", new Object[0]);
/*     */         });
/*     */     
/* 169 */     return CodeBlock.of("$L()", new Object[] { generatedMethod.getName() });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionPropertyValueCodeGeneratorDelegates$LinkedHashMapDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */