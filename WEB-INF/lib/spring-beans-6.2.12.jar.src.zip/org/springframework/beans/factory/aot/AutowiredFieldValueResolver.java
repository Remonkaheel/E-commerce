/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.function.ThrowingConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AutowiredFieldValueResolver
/*     */   extends AutowiredElementResolver
/*     */ {
/*     */   private final String fieldName;
/*     */   private final boolean required;
/*     */   @Nullable
/*     */   private final String shortcutBeanName;
/*     */   
/*     */   private AutowiredFieldValueResolver(String fieldName, boolean required, @Nullable String shortcut) {
/*  65 */     Assert.hasText(fieldName, "'fieldName' must not be empty");
/*  66 */     this.fieldName = fieldName;
/*  67 */     this.required = required;
/*  68 */     this.shortcutBeanName = shortcut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutowiredFieldValueResolver forField(String fieldName) {
/*  79 */     return new AutowiredFieldValueResolver(fieldName, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutowiredFieldValueResolver forRequiredField(String fieldName) {
/*  89 */     return new AutowiredFieldValueResolver(fieldName, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutowiredFieldValueResolver withShortcut(String beanName) {
/* 101 */     return new AutowiredFieldValueResolver(this.fieldName, this.required, beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void resolve(RegisteredBean registeredBean, ThrowingConsumer<T> action) {
/* 111 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 112 */     Assert.notNull(action, "'action' must not be null");
/* 113 */     T resolved = resolve(registeredBean);
/* 114 */     if (resolved != null) {
/* 115 */       action.accept(resolved);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T resolve(RegisteredBean registeredBean, Class<T> requiredType) {
/* 128 */     Object value = resolveObject(registeredBean);
/* 129 */     Assert.isInstanceOf(requiredType, value);
/* 130 */     return (T)value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T resolve(RegisteredBean registeredBean) {
/* 141 */     return (T)resolveObject(registeredBean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveObject(RegisteredBean registeredBean) {
/* 151 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 152 */     return resolveValue(registeredBean, getField(registeredBean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveAndSet(RegisteredBean registeredBean, Object instance) {
/* 162 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 163 */     Assert.notNull(instance, "'instance' must not be null");
/* 164 */     Field field = getField(registeredBean);
/* 165 */     Object resolved = resolveValue(registeredBean, field);
/* 166 */     if (resolved != null) {
/* 167 */       ReflectionUtils.makeAccessible(field);
/* 168 */       ReflectionUtils.setField(field, instance, resolved);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object resolveValue(RegisteredBean registeredBean, Field field) {
/* 174 */     String beanName = registeredBean.getBeanName();
/* 175 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 176 */     ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory();
/* 177 */     DependencyDescriptor descriptor = new DependencyDescriptor(field, this.required);
/* 178 */     descriptor.setContainingClass(beanClass);
/* 179 */     if (this.shortcutBeanName != null) {
/* 180 */       descriptor = new AutowiredElementResolver.ShortcutDependencyDescriptor(descriptor, this.shortcutBeanName);
/*     */     }
/* 182 */     Set<String> autowiredBeanNames = new LinkedHashSet<>(1);
/* 183 */     TypeConverter typeConverter = configurableListableBeanFactory.getTypeConverter();
/*     */     try {
/* 185 */       Assert.isInstanceOf(AutowireCapableBeanFactory.class, configurableListableBeanFactory);
/* 186 */       Object value = ((AutowireCapableBeanFactory)configurableListableBeanFactory).resolveDependency(descriptor, beanName, autowiredBeanNames, typeConverter);
/*     */       
/* 188 */       registerDependentBeans((ConfigurableBeanFactory)configurableListableBeanFactory, beanName, autowiredBeanNames);
/* 189 */       return value;
/*     */     }
/* 191 */     catch (BeansException ex) {
/* 192 */       throw new UnsatisfiedDependencyException(null, beanName, new InjectionPoint(field), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Field getField(RegisteredBean registeredBean) {
/* 197 */     Field field = ReflectionUtils.findField(registeredBean.getBeanClass(), this.fieldName);
/* 198 */     Assert.notNull(field, () -> "No field '" + this.fieldName + "' found on " + registeredBean.getBeanClass().getName());
/*     */     
/* 200 */     return field;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AutowiredFieldValueResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */