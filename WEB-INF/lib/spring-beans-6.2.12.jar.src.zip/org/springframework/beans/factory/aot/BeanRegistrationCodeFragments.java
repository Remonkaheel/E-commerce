package org.springframework.beans.factory.aot;

import java.util.List;
import java.util.function.Predicate;
import org.springframework.aot.generate.GenerationContext;
import org.springframework.aot.generate.MethodReference;
import org.springframework.beans.factory.support.RegisteredBean;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.core.ResolvableType;
import org.springframework.javapoet.ClassName;
import org.springframework.javapoet.CodeBlock;

public interface BeanRegistrationCodeFragments {
  public static final String BEAN_DEFINITION_VARIABLE = "beanDefinition";
  
  public static final String INSTANCE_SUPPLIER_VARIABLE = "instanceSupplier";
  
  ClassName getTarget(RegisteredBean paramRegisteredBean);
  
  CodeBlock generateNewBeanDefinitionCode(GenerationContext paramGenerationContext, ResolvableType paramResolvableType, BeanRegistrationCode paramBeanRegistrationCode);
  
  CodeBlock generateSetBeanDefinitionPropertiesCode(GenerationContext paramGenerationContext, BeanRegistrationCode paramBeanRegistrationCode, RootBeanDefinition paramRootBeanDefinition, Predicate<String> paramPredicate);
  
  CodeBlock generateSetBeanInstanceSupplierCode(GenerationContext paramGenerationContext, BeanRegistrationCode paramBeanRegistrationCode, CodeBlock paramCodeBlock, List<MethodReference> paramList);
  
  CodeBlock generateInstanceSupplierCode(GenerationContext paramGenerationContext, BeanRegistrationCode paramBeanRegistrationCode, boolean paramBoolean);
  
  CodeBlock generateReturnCode(GenerationContext paramGenerationContext, BeanRegistrationCode paramBeanRegistrationCode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationCodeFragments.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */