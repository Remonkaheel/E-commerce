/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AutowiredElementResolver
/*    */ {
/* 41 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void registerDependentBeans(ConfigurableBeanFactory beanFactory, String beanName, Set<String> autowiredBeanNames) {
/* 46 */     for (String autowiredBeanName : autowiredBeanNames) {
/* 47 */       if (beanFactory.containsBean(autowiredBeanName)) {
/* 48 */         beanFactory.registerDependentBean(autowiredBeanName, beanName);
/*    */       }
/* 50 */       this.logger.trace(LogMessage.format("Autowiring by type from bean name %s' to bean named '%s'", beanName, autowiredBeanName));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static class ShortcutDependencyDescriptor
/*    */     extends DependencyDescriptor
/*    */   {
/*    */     private final String shortcut;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public ShortcutDependencyDescriptor(DependencyDescriptor original, String shortcut) {
/* 66 */       super(original);
/* 67 */       this.shortcut = shortcut;
/*    */     }
/*    */ 
/*    */     
/*    */     public Object resolveShortcut(BeanFactory beanFactory) {
/* 72 */       return beanFactory.getBean(this.shortcut, getDependencyType());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AutowiredElementResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */