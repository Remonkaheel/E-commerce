/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BeanRegistrationsAotProcessor
/*    */   implements BeanFactoryInitializationAotProcessor
/*    */ {
/*    */   @Nullable
/*    */   public BeanRegistrationsAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 42 */     BeanDefinitionMethodGeneratorFactory beanDefinitionMethodGeneratorFactory = new BeanDefinitionMethodGeneratorFactory(beanFactory);
/*    */     
/* 44 */     List<BeanRegistrationsAotContribution.Registration> registrations = new ArrayList<>();
/*    */     
/* 46 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 47 */       RegisteredBean registeredBean = RegisteredBean.of(beanFactory, beanName);
/*    */       
/* 49 */       BeanDefinitionMethodGenerator beanDefinitionMethodGenerator = beanDefinitionMethodGeneratorFactory.getBeanDefinitionMethodGenerator(registeredBean);
/* 50 */       if (beanDefinitionMethodGenerator != null) {
/* 51 */         registrations.add(new BeanRegistrationsAotContribution.Registration(registeredBean, beanDefinitionMethodGenerator, beanFactory
/* 52 */               .getAliases(beanName)));
/*    */       }
/*    */     } 
/*    */     
/* 56 */     if (registrations.isEmpty()) {
/* 57 */       return null;
/*    */     }
/* 59 */     return new BeanRegistrationsAotContribution(registrations);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationsAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */