package org.springframework.beans.factory.aot;

import org.springframework.aot.generate.GeneratedMethods;
import org.springframework.aot.generate.MethodReference;
import org.springframework.javapoet.ClassName;

public interface BeanRegistrationCode {
  ClassName getClassName();
  
  GeneratedMethods getMethods();
  
  void addInstancePostProcessor(MethodReference paramMethodReference);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationCode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */