/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import org.springframework.aot.generate.ValueCodeGeneratorDelegates;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.javapoet.CodeBlock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ManagedListDelegate
/*    */   extends ValueCodeGeneratorDelegates.CollectionDelegate<ManagedList<?>>
/*    */ {
/*    */   public ManagedListDelegate() {
/* 81 */     super(ManagedList.class, CodeBlock.of("new $T()", new Object[] { ManagedList.class }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionPropertyValueCodeGeneratorDelegates$ManagedListDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */