/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ShortcutDependencyDescriptor
/*    */   extends DependencyDescriptor
/*    */ {
/*    */   private final String shortcut;
/*    */   
/*    */   public ShortcutDependencyDescriptor(DependencyDescriptor original, String shortcut) {
/* 66 */     super(original);
/* 67 */     this.shortcut = shortcut;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object resolveShortcut(BeanFactory beanFactory) {
/* 72 */     return beanFactory.getBean(this.shortcut, getDependencyType());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AutowiredElementResolver$ShortcutDependencyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */