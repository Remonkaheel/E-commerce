/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BeanDefinitionsRegistrationGenerator
/*     */ {
/*     */   private final GenerationContext generationContext;
/*     */   private final BeanRegistrationsAotContribution.BeanRegistrationsCodeGenerator codeGenerator;
/*     */   private final List<BeanRegistrationsAotContribution.Registration> registrations;
/*     */   private final int globalStart;
/*     */   
/*     */   BeanDefinitionsRegistrationGenerator(GenerationContext generationContext, BeanRegistrationsAotContribution.BeanRegistrationsCodeGenerator codeGenerator, List<BeanRegistrationsAotContribution.Registration> registrations, int globalStart) {
/* 230 */     this.generationContext = generationContext;
/* 231 */     this.codeGenerator = codeGenerator;
/* 232 */     this.registrations = registrations;
/* 233 */     this.globalStart = globalStart;
/*     */   }
/*     */   
/*     */   void generateBeanRegistrationsCode(MethodSpec.Builder method) {
/* 237 */     if (this.registrations.size() <= 1000) {
/* 238 */       generateRegisterBeanDefinitionMethods(method, this.registrations);
/*     */     } else {
/*     */       
/* 241 */       CodeBlock.Builder code = CodeBlock.builder();
/* 242 */       code.add("// Registration is sliced to avoid exceeding size limit\n", new Object[0]);
/* 243 */       BeanRegistrationsAotContribution.Registration.doWithSlice(this.registrations, 1000, (start, end) -> {
/*     */             GeneratedMethod sliceMethod = generateSliceMethod(start.intValue(), end.intValue());
/*     */             
/*     */             code.addStatement(sliceMethod.toMethodReference().toInvokeCodeBlock(BeanRegistrationsAotContribution.argumentCodeGenerator, this.codeGenerator.getClassName()));
/*     */           });
/*     */       
/* 249 */       method.addCode(code.build());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private GeneratedMethod generateSliceMethod(int start, int end) {
/* 255 */     String description = "Register the bean definitions from %s to %s.".formatted(new Object[] { Integer.valueOf(this.globalStart + start), Integer.valueOf(this.globalStart + end - 1) });
/* 256 */     List<BeanRegistrationsAotContribution.Registration> slice = this.registrations.subList(start, end);
/* 257 */     return this.codeGenerator.getMethods().add("registerBeanDefinitions", method -> {
/*     */           method.addJavadoc(description, new Object[0]);
/*     */           method.addModifiers(new Modifier[] { Modifier.PRIVATE });
/*     */           method.addParameter(DefaultListableBeanFactory.class, "beanFactory", new Modifier[0]);
/*     */           generateRegisterBeanDefinitionMethods(method, slice);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateRegisterBeanDefinitionMethods(MethodSpec.Builder method, Iterable<BeanRegistrationsAotContribution.Registration> registrations) {
/* 269 */     CodeBlock.Builder code = CodeBlock.builder();
/* 270 */     registrations.forEach(registration -> {
/*     */           try {
/*     */             CodeBlock methodInvocation = generateBeanRegistration(registration);
/*     */ 
/*     */             
/*     */             code.addStatement("$L.registerBeanDefinition($S, $L)", new Object[] { "beanFactory", registration.beanName(), methodInvocation });
/* 276 */           } catch (AotException ex) {
/*     */             
/*     */             throw ex;
/* 279 */           } catch (Exception ex) {
/*     */             throw new AotBeanProcessingException(registration.registeredBean, "failed to generate code for bean definition", ex);
/*     */           } 
/*     */         });
/*     */     
/* 284 */     method.addCode(code.build());
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock generateBeanRegistration(BeanRegistrationsAotContribution.Registration registration) {
/* 289 */     MethodReference beanDefinitionMethod = registration.methodGenerator.generateBeanDefinitionMethod(this.generationContext, this.codeGenerator);
/* 290 */     return beanDefinitionMethod.toInvokeCodeBlock(
/* 291 */         MethodReference.ArgumentCodeGenerator.none(), this.codeGenerator.getClassName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanRegistrationsAotContribution$BeanDefinitionsRegistrationGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */