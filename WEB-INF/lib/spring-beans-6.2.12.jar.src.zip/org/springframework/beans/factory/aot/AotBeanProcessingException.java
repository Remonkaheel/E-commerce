/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AotBeanProcessingException
/*    */   extends AotProcessingException
/*    */ {
/*    */   private final RootBeanDefinition beanDefinition;
/*    */   
/*    */   public AotBeanProcessingException(RegisteredBean registeredBean, String msg, @Nullable Throwable cause) {
/* 42 */     super(createErrorMessage(registeredBean, msg), cause);
/* 43 */     this.beanDefinition = registeredBean.getMergedBeanDefinition();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AotBeanProcessingException(RegisteredBean registeredBean, String msg) {
/* 53 */     this(registeredBean, msg, null);
/*    */   }
/*    */   
/*    */   private static String createErrorMessage(RegisteredBean registeredBean, String msg) {
/* 57 */     StringBuilder sb = new StringBuilder("Error processing bean with name '");
/* 58 */     sb.append(registeredBean.getBeanName()).append("'");
/* 59 */     String resourceDescription = registeredBean.getMergedBeanDefinition().getResourceDescription();
/* 60 */     if (resourceDescription != null) {
/* 61 */       sb.append(" defined in ").append(resourceDescription);
/*    */     }
/* 63 */     sb.append(": ").append(msg);
/* 64 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RootBeanDefinition getBeanDefinition() {
/* 71 */     return this.beanDefinition;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AotBeanProcessingException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */