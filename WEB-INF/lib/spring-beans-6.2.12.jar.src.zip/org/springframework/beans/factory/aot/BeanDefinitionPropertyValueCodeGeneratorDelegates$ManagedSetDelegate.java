/*    */ package org.springframework.beans.factory.aot;
/*    */ 
/*    */ import org.springframework.aot.generate.ValueCodeGeneratorDelegates;
/*    */ import org.springframework.beans.factory.support.ManagedSet;
/*    */ import org.springframework.javapoet.CodeBlock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ManagedSetDelegate
/*    */   extends ValueCodeGeneratorDelegates.CollectionDelegate<ManagedSet<?>>
/*    */ {
/*    */   public ManagedSetDelegate() {
/* 92 */     super(ManagedSet.class, CodeBlock.of("new $T()", new Object[] { ManagedSet.class }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionPropertyValueCodeGeneratorDelegates$ManagedSetDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */