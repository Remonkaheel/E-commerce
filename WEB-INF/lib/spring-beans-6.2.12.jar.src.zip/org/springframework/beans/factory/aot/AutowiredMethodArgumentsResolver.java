/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.function.ThrowingConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AutowiredMethodArgumentsResolver
/*     */   extends AutowiredElementResolver
/*     */ {
/*     */   private final String methodName;
/*     */   private final Class<?>[] parameterTypes;
/*     */   private final boolean required;
/*     */   @Nullable
/*     */   private final String[] shortcutBeanNames;
/*     */   
/*     */   private AutowiredMethodArgumentsResolver(String methodName, Class<?>[] parameterTypes, boolean required, @Nullable String[] shortcutBeanNames) {
/*  72 */     Assert.hasText(methodName, "'methodName' must not be empty");
/*  73 */     this.methodName = methodName;
/*  74 */     this.parameterTypes = parameterTypes;
/*  75 */     this.required = required;
/*  76 */     this.shortcutBeanNames = shortcutBeanNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutowiredMethodArgumentsResolver forMethod(String methodName, Class<?>... parameterTypes) {
/*  88 */     return new AutowiredMethodArgumentsResolver(methodName, parameterTypes, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AutowiredMethodArgumentsResolver forRequiredMethod(String methodName, Class<?>... parameterTypes) {
/*  99 */     return new AutowiredMethodArgumentsResolver(methodName, parameterTypes, true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AutowiredMethodArgumentsResolver withShortcut(String... beanNames) {
/* 111 */     return new AutowiredMethodArgumentsResolver(this.methodName, this.parameterTypes, this.required, beanNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(RegisteredBean registeredBean, ThrowingConsumer<AutowiredArguments> action) {
/* 121 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 122 */     Assert.notNull(action, "'action' must not be null");
/* 123 */     AutowiredArguments resolved = resolve(registeredBean);
/* 124 */     if (resolved != null) {
/* 125 */       action.accept(resolved);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public AutowiredArguments resolve(RegisteredBean registeredBean) {
/* 136 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 137 */     return resolveArguments(registeredBean, getMethod(registeredBean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveAndInvoke(RegisteredBean registeredBean, Object instance) {
/* 147 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 148 */     Assert.notNull(instance, "'instance' must not be null");
/* 149 */     Method method = getMethod(registeredBean);
/* 150 */     AutowiredArguments resolved = resolveArguments(registeredBean, method);
/* 151 */     if (resolved != null) {
/* 152 */       ReflectionUtils.makeAccessible(method);
/* 153 */       ReflectionUtils.invokeMethod(method, instance, resolved.toArray());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private AutowiredArguments resolveArguments(RegisteredBean registeredBean, Method method) {
/* 161 */     String beanName = registeredBean.getBeanName();
/* 162 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 163 */     ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory();
/* 164 */     Assert.isInstanceOf(AutowireCapableBeanFactory.class, configurableListableBeanFactory);
/* 165 */     AutowireCapableBeanFactory autowireCapableBeanFactory = (AutowireCapableBeanFactory)configurableListableBeanFactory;
/* 166 */     int argumentCount = method.getParameterCount();
/* 167 */     Object[] arguments = new Object[argumentCount];
/* 168 */     Set<String> autowiredBeanNames = CollectionUtils.newLinkedHashSet(argumentCount);
/* 169 */     TypeConverter typeConverter = configurableListableBeanFactory.getTypeConverter();
/* 170 */     for (int i = 0; i < argumentCount; i++) {
/* 171 */       MethodParameter parameter = new MethodParameter(method, i);
/* 172 */       DependencyDescriptor descriptor = new DependencyDescriptor(parameter, this.required);
/* 173 */       descriptor.setContainingClass(beanClass);
/* 174 */       String shortcut = (this.shortcutBeanNames != null) ? this.shortcutBeanNames[i] : null;
/* 175 */       if (shortcut != null) {
/* 176 */         descriptor = new AutowiredElementResolver.ShortcutDependencyDescriptor(descriptor, shortcut);
/*     */       }
/*     */       try {
/* 179 */         Object argument = autowireCapableBeanFactory.resolveDependency(descriptor, beanName, autowiredBeanNames, typeConverter);
/*     */         
/* 181 */         if (argument == null && !this.required) {
/* 182 */           return null;
/*     */         }
/* 184 */         arguments[i] = argument;
/*     */       }
/* 186 */       catch (BeansException ex) {
/* 187 */         throw new UnsatisfiedDependencyException(null, beanName, new InjectionPoint(parameter), ex);
/*     */       } 
/*     */     } 
/* 190 */     registerDependentBeans((ConfigurableBeanFactory)configurableListableBeanFactory, beanName, autowiredBeanNames);
/* 191 */     return AutowiredArguments.of(arguments);
/*     */   }
/*     */   
/*     */   private Method getMethod(RegisteredBean registeredBean) {
/* 195 */     Method method = ReflectionUtils.findMethod(registeredBean.getBeanClass(), this.methodName, this.parameterTypes);
/*     */     
/* 197 */     Assert.notNull(method, () -> "Method '%s' with parameter types [%s] declared on %s could not be found.".formatted(new Object[] { this.methodName, toCommaSeparatedNames(this.parameterTypes), registeredBean.getBeanClass().getName() }));
/*     */ 
/*     */ 
/*     */     
/* 201 */     return method;
/*     */   }
/*     */   
/*     */   private String toCommaSeparatedNames(Class<?>... parameterTypes) {
/* 205 */     return Arrays.<Class<?>>stream(parameterTypes).map(Class::getName)
/* 206 */       .collect(Collectors.joining(", "));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\AutowiredMethodArgumentsResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */