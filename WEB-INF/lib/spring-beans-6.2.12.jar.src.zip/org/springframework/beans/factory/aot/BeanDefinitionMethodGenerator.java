/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanDefinitionMethodGenerator
/*     */ {
/*     */   private final BeanDefinitionMethodGeneratorFactory methodGeneratorFactory;
/*     */   private final RegisteredBean registeredBean;
/*     */   @Nullable
/*     */   private final String currentPropertyName;
/*     */   private final List<BeanRegistrationAotContribution> aotContributions;
/*     */   
/*     */   BeanDefinitionMethodGenerator(BeanDefinitionMethodGeneratorFactory methodGeneratorFactory, RegisteredBean registeredBean, @Nullable String currentPropertyName, List<BeanRegistrationAotContribution> aotContributions) {
/*  68 */     this.methodGeneratorFactory = methodGeneratorFactory;
/*  69 */     this.registeredBean = registeredBean;
/*  70 */     this.currentPropertyName = currentPropertyName;
/*  71 */     this.aotContributions = aotContributions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodReference generateBeanDefinitionMethod(GenerationContext generationContext, BeanRegistrationsCode beanRegistrationsCode) {
/*  84 */     BeanRegistrationCodeFragments codeFragments = getCodeFragments(generationContext, beanRegistrationsCode);
/*  85 */     ClassName target = codeFragments.getTarget(this.registeredBean);
/*  86 */     if (isWritablePackageName(target)) {
/*  87 */       GeneratedClass generatedClass = lookupGeneratedClass(generationContext, target);
/*  88 */       GeneratedMethods generatedMethods1 = generatedClass.getMethods().withPrefix(getName());
/*  89 */       GeneratedMethod generatedMethod1 = generateBeanDefinitionMethod(generationContext, generatedClass
/*  90 */           .getName(), generatedMethods1, codeFragments, Modifier.PUBLIC);
/*  91 */       return generatedMethod1.toMethodReference();
/*     */     } 
/*  93 */     GeneratedMethods generatedMethods = beanRegistrationsCode.getMethods().withPrefix(getName());
/*  94 */     GeneratedMethod generatedMethod = generateBeanDefinitionMethod(generationContext, beanRegistrationsCode
/*  95 */         .getClassName(), generatedMethods, codeFragments, Modifier.PRIVATE);
/*  96 */     return generatedMethod.toMethodReference();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isWritablePackageName(ClassName target) {
/* 105 */     String packageName = target.packageName();
/* 106 */     return (!packageName.startsWith("java.") && !packageName.startsWith("javax."));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static GeneratedClass lookupGeneratedClass(GenerationContext generationContext, ClassName target) {
/* 118 */     ClassName topLevelClassName = target.topLevelClassName();
/*     */     
/* 120 */     GeneratedClass generatedClass = generationContext.getGeneratedClasses().getOrAddForFeatureComponent("BeanDefinitions", topLevelClassName, type -> {
/*     */           type.addJavadoc("Bean definitions for {@link $T}.", new Object[] { topLevelClassName });
/*     */           
/*     */           type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */         });
/* 125 */     List<String> names = target.simpleNames();
/* 126 */     if (names.size() == 1) {
/* 127 */       return generatedClass;
/*     */     }
/*     */     
/* 130 */     List<String> namesToProcess = names.subList(1, names.size());
/* 131 */     ClassName currentTargetClassName = topLevelClassName;
/* 132 */     GeneratedClass tmp = generatedClass;
/* 133 */     for (String nameToProcess : namesToProcess) {
/* 134 */       currentTargetClassName = currentTargetClassName.nestedClass(nameToProcess);
/* 135 */       tmp = createInnerClass(tmp, nameToProcess, currentTargetClassName);
/*     */     } 
/* 137 */     return tmp;
/*     */   }
/*     */   
/*     */   private static GeneratedClass createInnerClass(GeneratedClass generatedClass, String name, ClassName target) {
/* 141 */     return generatedClass.getOrAdd(name, type -> {
/*     */           type.addJavadoc("Bean definitions for {@link $T}.", new Object[] { target });
/*     */           type.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanRegistrationCodeFragments getCodeFragments(GenerationContext generationContext, BeanRegistrationsCode beanRegistrationsCode) {
/* 150 */     BeanRegistrationCodeFragments codeFragments = new DefaultBeanRegistrationCodeFragments(beanRegistrationsCode, this.registeredBean, this.methodGeneratorFactory);
/*     */     
/* 152 */     for (BeanRegistrationAotContribution aotContribution : this.aotContributions) {
/* 153 */       codeFragments = aotContribution.customizeBeanRegistrationCodeFragments(generationContext, codeFragments);
/*     */     }
/* 155 */     return codeFragments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GeneratedMethod generateBeanDefinitionMethod(GenerationContext generationContext, ClassName className, GeneratedMethods generatedMethods, BeanRegistrationCodeFragments codeFragments, Modifier modifier) {
/* 162 */     BeanRegistrationCodeGenerator codeGenerator = new BeanRegistrationCodeGenerator(className, generatedMethods, this.registeredBean, codeFragments);
/*     */ 
/*     */     
/* 165 */     this.aotContributions.forEach(aotContribution -> aotContribution.applyTo(generationContext, codeGenerator));
/*     */     
/* 167 */     CodeWarnings codeWarnings = new CodeWarnings();
/* 168 */     codeWarnings.detectDeprecation(this.registeredBean.getBeanType());
/* 169 */     return generatedMethods.add("getBeanDefinition", method -> {
/*     */           method.addJavadoc("Get the $L definition for '$L'.", new Object[] { this.registeredBean.isInnerBean() ? "inner-bean" : "bean", getName() });
/*     */           method.addModifiers(new Modifier[] { modifier, Modifier.STATIC });
/*     */           codeWarnings.suppress(method);
/*     */           method.returns(BeanDefinition.class);
/*     */           method.addCode(codeGenerator.generateCode(generationContext));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getName() {
/* 181 */     if (this.currentPropertyName != null) {
/* 182 */       return this.currentPropertyName;
/*     */     }
/* 184 */     if (!this.registeredBean.isGeneratedBeanName()) {
/* 185 */       return getSimpleBeanName(this.registeredBean.getBeanName());
/*     */     }
/* 187 */     RegisteredBean nonGeneratedParent = this.registeredBean;
/* 188 */     while (nonGeneratedParent != null && nonGeneratedParent.isGeneratedBeanName()) {
/* 189 */       nonGeneratedParent = nonGeneratedParent.getParent();
/*     */     }
/* 191 */     if (nonGeneratedParent != null) {
/* 192 */       return getSimpleBeanName(nonGeneratedParent.getBeanName()) + "InnerBean";
/*     */     }
/* 194 */     return "innerBean";
/*     */   }
/*     */   
/*     */   private String getSimpleBeanName(String beanName) {
/* 198 */     int lastDot = beanName.lastIndexOf('.');
/* 199 */     beanName = (lastDot != -1) ? beanName.substring(lastDot + 1) : beanName;
/* 200 */     int lastDollar = beanName.lastIndexOf('$');
/* 201 */     beanName = (lastDollar != -1) ? beanName.substring(lastDollar + 1) : beanName;
/* 202 */     return StringUtils.uncapitalize(beanName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionMethodGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */