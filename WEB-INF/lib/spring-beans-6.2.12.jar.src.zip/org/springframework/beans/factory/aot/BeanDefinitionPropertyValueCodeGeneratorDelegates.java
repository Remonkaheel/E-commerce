/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.ValueCodeGenerator;
/*     */ import org.springframework.aot.generate.ValueCodeGeneratorDelegates;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.ManagedSet;
/*     */ import org.springframework.javapoet.AnnotationSpec;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BeanDefinitionPropertyValueCodeGeneratorDelegates
/*     */ {
/*  65 */   public static final List<ValueCodeGenerator.Delegate> INSTANCES = (List)List.of(new ManagedListDelegate(), new ManagedSetDelegate(), new ManagedMapDelegate(), new LinkedHashMapDelegate(), new BeanReferenceDelegate(), new TypedStringValueDelegate());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ManagedListDelegate
/*     */     extends ValueCodeGeneratorDelegates.CollectionDelegate<ManagedList<?>>
/*     */   {
/*     */     public ManagedListDelegate() {
/*  81 */       super(ManagedList.class, CodeBlock.of("new $T()", new Object[] { ManagedList.class }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ManagedSetDelegate
/*     */     extends ValueCodeGeneratorDelegates.CollectionDelegate<ManagedSet<?>>
/*     */   {
/*     */     public ManagedSetDelegate() {
/*  92 */       super(ManagedSet.class, CodeBlock.of("new $T()", new Object[] { ManagedSet.class }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ManagedMapDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/* 102 */     private static final CodeBlock EMPTY_RESULT = CodeBlock.of("$T.ofEntries()", new Object[] { ManagedMap.class });
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/* 107 */       if (value instanceof ManagedMap) { ManagedMap<?, ?> managedMap = (ManagedMap<?, ?>)value;
/* 108 */         return generateManagedMapCode(valueCodeGenerator, managedMap); }
/*     */       
/* 110 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     private <K, V> CodeBlock generateManagedMapCode(ValueCodeGenerator valueCodeGenerator, ManagedMap<K, V> managedMap) {
/* 115 */       if (managedMap.isEmpty()) {
/* 116 */         return EMPTY_RESULT;
/*     */       }
/* 118 */       CodeBlock.Builder code = CodeBlock.builder();
/* 119 */       code.add("$T.ofEntries(", new Object[] { ManagedMap.class });
/* 120 */       Iterator<Map.Entry<K, V>> iterator = managedMap.entrySet().iterator();
/* 121 */       while (iterator.hasNext()) {
/* 122 */         Map.Entry<?, ?> entry = iterator.next();
/* 123 */         code.add("$T.entry($L,$L)", new Object[] { Map.class, valueCodeGenerator
/* 124 */               .generateCode(entry.getKey()), valueCodeGenerator
/* 125 */               .generateCode(entry.getValue()) });
/* 126 */         if (iterator.hasNext()) {
/* 127 */           code.add(", ", new Object[0]);
/*     */         }
/*     */       } 
/* 130 */       code.add(")", new Object[0]);
/* 131 */       return code.build();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LinkedHashMapDelegate
/*     */     extends ValueCodeGeneratorDelegates.MapDelegate
/*     */   {
/*     */     @Nullable
/*     */     protected CodeBlock generateMapCode(ValueCodeGenerator valueCodeGenerator, Map<?, ?> map) {
/* 144 */       GeneratedMethods generatedMethods = valueCodeGenerator.getGeneratedMethods();
/* 145 */       if (map instanceof LinkedHashMap && generatedMethods != null) {
/* 146 */         return generateLinkedHashMapCode(valueCodeGenerator, generatedMethods, map);
/*     */       }
/* 148 */       return super.generateMapCode(valueCodeGenerator, map);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private CodeBlock generateLinkedHashMapCode(ValueCodeGenerator valueCodeGenerator, GeneratedMethods generatedMethods, Map<?, ?> map) {
/* 154 */       GeneratedMethod generatedMethod = generatedMethods.add("getMap", method -> {
/*     */             method.addAnnotation(AnnotationSpec.builder(SuppressWarnings.class).addMember("value", "{\"rawtypes\", \"unchecked\"}", new Object[0]).build());
/*     */ 
/*     */             
/*     */             method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */             
/*     */             method.returns(Map.class);
/*     */             
/*     */             method.addStatement("$T map = new $T($L)", new Object[] { Map.class, LinkedHashMap.class, Integer.valueOf(map.size()) });
/*     */             
/*     */             map.forEach(());
/*     */             
/*     */             method.addStatement("return map", new Object[0]);
/*     */           });
/*     */       
/* 169 */       return CodeBlock.of("$L()", new Object[] { generatedMethod.getName() });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BeanReferenceDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/* 182 */       if (value instanceof RuntimeBeanReference) { RuntimeBeanReference runtimeBeanReference = (RuntimeBeanReference)value; if (runtimeBeanReference
/* 183 */           .getBeanType() != null)
/* 184 */           return CodeBlock.of("new $T($T.class)", new Object[] { RuntimeBeanReference.class, runtimeBeanReference
/* 185 */                 .getBeanType() });  }
/*     */       
/* 187 */       if (value instanceof BeanReference) { BeanReference beanReference = (BeanReference)value;
/* 188 */         return CodeBlock.of("new $T($S)", new Object[] { RuntimeBeanReference.class, beanReference
/* 189 */               .getBeanName() }); }
/*     */       
/* 191 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TypedStringValueDelegate
/*     */     implements ValueCodeGenerator.Delegate
/*     */   {
/*     */     @Nullable
/*     */     public CodeBlock generateCode(ValueCodeGenerator valueCodeGenerator, Object value) {
/* 204 */       if (value instanceof TypedStringValue) { TypedStringValue typedStringValue = (TypedStringValue)value;
/* 205 */         return generateTypeStringValueCode(valueCodeGenerator, typedStringValue); }
/*     */       
/* 207 */       return null;
/*     */     }
/*     */     
/*     */     private CodeBlock generateTypeStringValueCode(ValueCodeGenerator valueCodeGenerator, TypedStringValue typedStringValue) {
/* 211 */       String value = typedStringValue.getValue();
/* 212 */       if (typedStringValue.hasTargetType()) {
/* 213 */         return CodeBlock.of("new $T($S, $L)", new Object[] { TypedStringValue.class, value, valueCodeGenerator
/* 214 */               .generateCode(typedStringValue.getTargetType()) });
/*     */       }
/* 216 */       return valueCodeGenerator.generateCode(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanDefinitionPropertyValueCodeGeneratorDelegates.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */