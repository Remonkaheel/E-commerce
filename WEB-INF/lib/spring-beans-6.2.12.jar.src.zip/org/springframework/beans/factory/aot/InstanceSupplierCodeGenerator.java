/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.InstanceSupplier;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.ParameterizedTypeName;
/*     */ import org.springframework.javapoet.TypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.function.ThrowingSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstanceSupplierCodeGenerator
/*     */ {
/*     */   private static final String REGISTERED_BEAN_PARAMETER_NAME = "registeredBean";
/*     */   private static final String ARGS_PARAMETER_NAME = "args";
/*  86 */   private static final Modifier[] PRIVATE_STATIC = new Modifier[] { Modifier.PRIVATE, Modifier.STATIC };
/*     */ 
/*     */   
/*  89 */   private static final CodeBlock NO_ARGS = CodeBlock.of("", new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final GenerationContext generationContext;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ClassName className;
/*     */ 
/*     */ 
/*     */   
/*     */   private final GeneratedMethods generatedMethods;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean allowDirectSupplierShortcut;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstanceSupplierCodeGenerator(GenerationContext generationContext, ClassName className, GeneratedMethods generatedMethods, boolean allowDirectSupplierShortcut) {
/* 112 */     this.generationContext = generationContext;
/* 113 */     this.className = className;
/* 114 */     this.generatedMethods = generatedMethods;
/* 115 */     this.allowDirectSupplierShortcut = allowDirectSupplierShortcut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1.7")
/*     */   public CodeBlock generateCode(RegisteredBean registeredBean, Executable constructorOrFactoryMethod) {
/* 128 */     return generateCode(registeredBean, new RegisteredBean.InstantiationDescriptor(constructorOrFactoryMethod, constructorOrFactoryMethod
/* 129 */           .getDeclaringClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateCode(RegisteredBean registeredBean, RegisteredBean.InstantiationDescriptor instantiationDescriptor) {
/* 140 */     Executable constructorOrFactoryMethod = instantiationDescriptor.executable();
/* 141 */     registerRuntimeHintsIfNecessary(registeredBean, constructorOrFactoryMethod);
/* 142 */     if (constructorOrFactoryMethod instanceof Constructor) { Constructor<?> constructor = (Constructor)constructorOrFactoryMethod;
/* 143 */       return generateCodeForConstructor(registeredBean, constructor); }
/*     */     
/* 145 */     if (constructorOrFactoryMethod instanceof Method) { Method method = (Method)constructorOrFactoryMethod; if (!KotlinDetector.isSuspendingFunction(method))
/* 146 */         return generateCodeForFactoryMethod(registeredBean, method, instantiationDescriptor.targetClass());  }
/*     */     
/* 148 */     throw new AotBeanProcessingException(registeredBean, "no suitable constructor or factory method found");
/*     */   }
/*     */   
/*     */   private void registerRuntimeHintsIfNecessary(RegisteredBean registeredBean, Executable constructorOrFactoryMethod) {
/* 152 */     ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory(); if (configurableListableBeanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)configurableListableBeanFactory;
/* 153 */       RuntimeHints runtimeHints = this.generationContext.getRuntimeHints();
/* 154 */       ProxyRuntimeHintsRegistrar registrar = new ProxyRuntimeHintsRegistrar(dlbf.getAutowireCandidateResolver());
/* 155 */       registrar.registerRuntimeHints(runtimeHints, constructorOrFactoryMethod); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock generateCodeForConstructor(RegisteredBean registeredBean, Constructor<?> constructor) {
/* 161 */     ConstructorDescriptor descriptor = new ConstructorDescriptor(registeredBean.getBeanName(), constructor, registeredBean.getBeanClass());
/*     */     
/* 163 */     Class<?> publicType = descriptor.publicType();
/* 164 */     if (KotlinDetector.isKotlinReflectPresent() && KotlinDelegate.hasConstructorWithOptionalParameter(publicType)) {
/* 165 */       return generateCodeForInaccessibleConstructor(descriptor, hints -> hints.registerType(publicType, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS }));
/*     */     }
/*     */ 
/*     */     
/* 169 */     if (!isVisible(constructor, constructor.getDeclaringClass()) || registeredBean
/* 170 */       .getMergedBeanDefinition().hasMethodOverrides()) {
/* 171 */       return generateCodeForInaccessibleConstructor(descriptor, hints -> hints.registerConstructor(constructor, ExecutableMode.INVOKE));
/*     */     }
/*     */     
/* 174 */     return generateCodeForAccessibleConstructor(descriptor);
/*     */   }
/*     */   
/*     */   private CodeBlock generateCodeForAccessibleConstructor(ConstructorDescriptor descriptor) {
/* 178 */     Constructor<?> constructor = descriptor.constructor();
/* 179 */     this.generationContext.getRuntimeHints().reflection().registerConstructor(constructor, ExecutableMode.INTROSPECT);
/*     */ 
/*     */     
/* 182 */     if (constructor.getParameterCount() == 0) {
/* 183 */       if (!this.allowDirectSupplierShortcut) {
/* 184 */         return CodeBlock.of("$T.using($T::new)", new Object[] { InstanceSupplier.class, descriptor.actualType() });
/*     */       }
/* 186 */       if (!isThrowingCheckedException(constructor)) {
/* 187 */         return CodeBlock.of("$T::new", new Object[] { descriptor.actualType() });
/*     */       }
/* 189 */       return CodeBlock.of("$T.of($T::new)", new Object[] { ThrowingSupplier.class, descriptor.actualType() });
/*     */     } 
/*     */     
/* 192 */     GeneratedMethod generatedMethod = generateGetInstanceSupplierMethod(method -> buildGetInstanceMethodForConstructor(method, descriptor, PRIVATE_STATIC));
/*     */     
/* 194 */     return generateReturnStatement(generatedMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateCodeForInaccessibleConstructor(ConstructorDescriptor descriptor, Consumer<ReflectionHints> hints) {
/* 200 */     Constructor<?> constructor = descriptor.constructor();
/* 201 */     CodeWarnings codeWarnings = new CodeWarnings();
/* 202 */     codeWarnings.detectDeprecation(new AnnotatedElement[] { constructor.getDeclaringClass(), constructor
/* 203 */         }).detectDeprecation(Arrays.<Parameter>stream(constructor.getParameters()).map(Parameter::getType));
/* 204 */     hints.accept(this.generationContext.getRuntimeHints().reflection());
/*     */     
/* 206 */     GeneratedMethod generatedMethod = generateGetInstanceSupplierMethod(method -> {
/*     */           method.addJavadoc("Get the bean instance supplier for '$L'.", new Object[] { descriptor.beanName() });
/*     */           
/*     */           method.addModifiers(PRIVATE_STATIC);
/*     */           codeWarnings.suppress(method);
/*     */           method.returns((TypeName)ParameterizedTypeName.get(BeanInstanceSupplier.class, new Type[] { descriptor.publicType() }));
/*     */           method.addStatement(generateResolverForConstructor(descriptor));
/*     */         });
/* 214 */     return generateReturnStatement(generatedMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildGetInstanceMethodForConstructor(MethodSpec.Builder method, ConstructorDescriptor descriptor, Modifier... modifiers) {
/* 220 */     Constructor<?> constructor = descriptor.constructor();
/* 221 */     Class<?> publicType = descriptor.publicType();
/* 222 */     Class<?> actualType = descriptor.actualType();
/*     */     
/* 224 */     CodeWarnings codeWarnings = new CodeWarnings();
/* 225 */     codeWarnings.detectDeprecation(new AnnotatedElement[] { actualType, constructor
/* 226 */         }).detectDeprecation(Arrays.<Parameter>stream(constructor.getParameters()).map(Parameter::getType));
/* 227 */     method.addJavadoc("Get the bean instance supplier for '$L'.", new Object[] { descriptor.beanName() });
/* 228 */     method.addModifiers(modifiers);
/* 229 */     codeWarnings.suppress(method);
/* 230 */     method.returns((TypeName)ParameterizedTypeName.get(BeanInstanceSupplier.class, new Type[] { publicType }));
/*     */     
/* 232 */     CodeBlock.Builder code = CodeBlock.builder();
/* 233 */     code.add(generateResolverForConstructor(descriptor));
/* 234 */     boolean hasArguments = (constructor.getParameterCount() > 0);
/* 235 */     boolean onInnerClass = ClassUtils.isInnerClass(actualType);
/*     */ 
/*     */ 
/*     */     
/* 239 */     CodeBlock arguments = hasArguments ? (new AutowiredArgumentsCodeGenerator(actualType, constructor)).generateCode(constructor.getParameterTypes(), onInnerClass ? 1 : 0) : NO_ARGS;
/*     */     
/* 241 */     CodeBlock newInstance = generateNewInstanceCodeForConstructor(actualType, arguments);
/* 242 */     code.add(generateWithGeneratorCode(hasArguments, newInstance));
/* 243 */     method.addStatement(code.build());
/*     */   }
/*     */   
/*     */   private CodeBlock generateResolverForConstructor(ConstructorDescriptor descriptor) {
/* 247 */     CodeBlock parameterTypes = generateParameterTypesCode(descriptor.constructor().getParameterTypes());
/* 248 */     return CodeBlock.of("return $T.<$T>forConstructor($L)", new Object[] { BeanInstanceSupplier.class, descriptor
/* 249 */           .publicType(), parameterTypes });
/*     */   }
/*     */   
/*     */   private CodeBlock generateNewInstanceCodeForConstructor(Class<?> declaringClass, CodeBlock args) {
/* 253 */     if (ClassUtils.isInnerClass(declaringClass)) {
/* 254 */       return CodeBlock.of("$L.getBeanFactory().getBean($T.class).new $L($L)", new Object[] { "registeredBean", declaringClass
/* 255 */             .getEnclosingClass(), declaringClass
/* 256 */             .getSimpleName(), args });
/*     */     }
/* 258 */     return CodeBlock.of("new $T($L)", new Object[] { declaringClass, args });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateCodeForFactoryMethod(RegisteredBean registeredBean, Method factoryMethod, Class<?> targetClass) {
/* 264 */     if (!isVisible(factoryMethod, targetClass)) {
/* 265 */       return generateCodeForInaccessibleFactoryMethod(registeredBean.getBeanName(), factoryMethod, targetClass);
/*     */     }
/* 267 */     return generateCodeForAccessibleFactoryMethod(registeredBean.getBeanName(), factoryMethod, targetClass, registeredBean
/* 268 */         .getMergedBeanDefinition().getFactoryBeanName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateCodeForAccessibleFactoryMethod(String beanName, Method factoryMethod, Class<?> targetClass, @Nullable String factoryBeanName) {
/* 274 */     this.generationContext.getRuntimeHints().reflection().registerMethod(factoryMethod, ExecutableMode.INTROSPECT);
/*     */     
/* 276 */     if (factoryBeanName == null && factoryMethod.getParameterCount() == 0) {
/* 277 */       Class<?> suppliedType = ClassUtils.resolvePrimitiveIfNecessary(factoryMethod.getReturnType());
/* 278 */       CodeBlock.Builder code = CodeBlock.builder();
/* 279 */       code.add("$T.<$T>forFactoryMethod($T.class, $S)", new Object[] { BeanInstanceSupplier.class, suppliedType, targetClass, factoryMethod
/* 280 */             .getName() });
/* 281 */       code.add(".withGenerator(($L) -> $T.$L())", new Object[] { "registeredBean", 
/* 282 */             ClassUtils.getUserClass(targetClass), factoryMethod.getName() });
/* 283 */       return code.build();
/*     */     } 
/*     */     
/* 286 */     GeneratedMethod getInstanceMethod = generateGetInstanceSupplierMethod(method -> buildGetInstanceMethodForFactoryMethod(method, beanName, factoryMethod, targetClass, factoryBeanName, PRIVATE_STATIC));
/*     */ 
/*     */     
/* 289 */     return generateReturnStatement(getInstanceMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateCodeForInaccessibleFactoryMethod(String beanName, Method factoryMethod, Class<?> targetClass) {
/* 295 */     this.generationContext.getRuntimeHints().reflection().registerMethod(factoryMethod, ExecutableMode.INVOKE);
/* 296 */     GeneratedMethod getInstanceMethod = generateGetInstanceSupplierMethod(method -> {
/*     */           CodeWarnings codeWarnings = new CodeWarnings();
/*     */           
/*     */           Class<?> suppliedType = ClassUtils.resolvePrimitiveIfNecessary(factoryMethod.getReturnType());
/*     */           codeWarnings.detectDeprecation(new AnnotatedElement[] { suppliedType, factoryMethod });
/*     */           method.addJavadoc("Get the bean instance supplier for '$L'.", new Object[] { beanName });
/*     */           method.addModifiers(PRIVATE_STATIC);
/*     */           codeWarnings.suppress(method);
/*     */           method.returns((TypeName)ParameterizedTypeName.get(BeanInstanceSupplier.class, new Type[] { suppliedType }));
/*     */           method.addStatement(generateInstanceSupplierForFactoryMethod(factoryMethod, suppliedType, targetClass, factoryMethod.getName()));
/*     */         });
/* 307 */     return generateReturnStatement(getInstanceMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildGetInstanceMethodForFactoryMethod(MethodSpec.Builder method, String beanName, Method factoryMethod, Class<?> targetClass, @Nullable String factoryBeanName, Modifier... modifiers) {
/* 314 */     String factoryMethodName = factoryMethod.getName();
/* 315 */     Class<?> suppliedType = ClassUtils.resolvePrimitiveIfNecessary(factoryMethod.getReturnType());
/* 316 */     CodeWarnings codeWarnings = new CodeWarnings();
/* 317 */     codeWarnings.detectDeprecation(new AnnotatedElement[] { ClassUtils.getUserClass(targetClass), factoryMethod, suppliedType
/* 318 */         }).detectDeprecation(Arrays.<Parameter>stream(factoryMethod.getParameters()).map(Parameter::getType));
/*     */     
/* 320 */     method.addJavadoc("Get the bean instance supplier for '$L'.", new Object[] { beanName });
/* 321 */     method.addModifiers(modifiers);
/* 322 */     codeWarnings.suppress(method);
/* 323 */     method.returns((TypeName)ParameterizedTypeName.get(BeanInstanceSupplier.class, new Type[] { suppliedType }));
/*     */     
/* 325 */     CodeBlock.Builder code = CodeBlock.builder();
/* 326 */     code.add(generateInstanceSupplierForFactoryMethod(factoryMethod, suppliedType, targetClass, factoryMethodName));
/*     */ 
/*     */     
/* 329 */     boolean hasArguments = (factoryMethod.getParameterCount() > 0);
/*     */ 
/*     */     
/* 332 */     CodeBlock arguments = hasArguments ? (new AutowiredArgumentsCodeGenerator(ClassUtils.getUserClass(targetClass), factoryMethod)).generateCode(factoryMethod.getParameterTypes()) : NO_ARGS;
/*     */     
/* 334 */     CodeBlock newInstance = generateNewInstanceCodeForMethod(factoryBeanName, 
/* 335 */         ClassUtils.getUserClass(targetClass), factoryMethodName, arguments);
/* 336 */     code.add(generateWithGeneratorCode(hasArguments, newInstance));
/* 337 */     method.addStatement(code.build());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateInstanceSupplierForFactoryMethod(Method factoryMethod, Class<?> suppliedType, Class<?> targetClass, String factoryMethodName) {
/* 343 */     if (factoryMethod.getParameterCount() == 0) {
/* 344 */       return CodeBlock.of("return $T.<$T>forFactoryMethod($T.class, $S)", new Object[] { BeanInstanceSupplier.class, suppliedType, targetClass, factoryMethodName });
/*     */     }
/*     */ 
/*     */     
/* 348 */     CodeBlock parameterTypes = generateParameterTypesCode(factoryMethod.getParameterTypes());
/* 349 */     return CodeBlock.of("return $T.<$T>forFactoryMethod($T.class, $S, $L)", new Object[] { BeanInstanceSupplier.class, suppliedType, targetClass, factoryMethodName, parameterTypes });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateNewInstanceCodeForMethod(@Nullable String factoryBeanName, Class<?> targetClass, String factoryMethodName, CodeBlock args) {
/* 356 */     if (factoryBeanName == null) {
/* 357 */       return CodeBlock.of("$T.$L($L)", new Object[] { targetClass, factoryMethodName, args });
/*     */     }
/* 359 */     return CodeBlock.of("$L.getBeanFactory().getBean(\"$L\", $T.class).$L($L)", new Object[] { "registeredBean", factoryBeanName, targetClass, factoryMethodName, args });
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock generateReturnStatement(GeneratedMethod generatedMethod) {
/* 364 */     return generatedMethod.toMethodReference().toInvokeCodeBlock(
/* 365 */         MethodReference.ArgumentCodeGenerator.none(), this.className);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateWithGeneratorCode(boolean hasArguments, CodeBlock newInstance) {
/* 371 */     CodeBlock lambdaArguments = hasArguments ? CodeBlock.of("($L, $L)", new Object[] { "registeredBean", "args" }) : CodeBlock.of("($L)", new Object[] { "registeredBean" });
/* 372 */     CodeBlock.Builder code = CodeBlock.builder();
/* 373 */     code.add("\n", new Object[0]);
/* 374 */     code.indent().indent();
/* 375 */     code.add(".withGenerator($L -> $L)", new Object[] { lambdaArguments, newInstance });
/* 376 */     code.unindent().unindent();
/* 377 */     return code.build();
/*     */   }
/*     */   
/*     */   private boolean isVisible(Member member, Class<?> targetClass) {
/* 381 */     AccessControl classAccessControl = AccessControl.forClass(targetClass);
/* 382 */     AccessControl memberAccessControl = AccessControl.forMember(member);
/* 383 */     AccessControl.Visibility visibility = AccessControl.lowest(new AccessControl[] { classAccessControl, memberAccessControl }).getVisibility();
/* 384 */     return (visibility == AccessControl.Visibility.PUBLIC || (visibility != AccessControl.Visibility.PRIVATE && member
/* 385 */       .getDeclaringClass().getPackageName().equals(this.className.packageName())));
/*     */   }
/*     */   
/*     */   private CodeBlock generateParameterTypesCode(Class<?>[] parameterTypes) {
/* 389 */     CodeBlock.Builder code = CodeBlock.builder();
/* 390 */     for (int i = 0; i < parameterTypes.length; i++) {
/* 391 */       code.add((i > 0) ? ", " : "", new Object[0]);
/* 392 */       code.add("$T.class", new Object[] { parameterTypes[i] });
/*     */     } 
/* 394 */     return code.build();
/*     */   }
/*     */   
/*     */   private GeneratedMethod generateGetInstanceSupplierMethod(Consumer<MethodSpec.Builder> method) {
/* 398 */     return this.generatedMethods.add("getInstanceSupplier", method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isThrowingCheckedException(Executable executable) {
/* 405 */     Objects.requireNonNull(Exception.class); return Arrays.<Type>stream(executable.getGenericExceptionTypes()).map(ResolvableType::forType).map(ResolvableType::toClass).anyMatch(Exception.class::isAssignableFrom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     public static boolean hasConstructorWithOptionalParameter(Class<?> beanClass) {
/* 415 */       if (KotlinDetector.isKotlinType(beanClass)) {
/* 416 */         KClass<?> kClass = JvmClassMappingKt.getKotlinClass(beanClass);
/* 417 */         for (KFunction<?> constructor : (Iterable<KFunction<?>>)kClass.getConstructors()) {
/* 418 */           for (KParameter parameter : constructor.getParameters()) {
/* 419 */             if (parameter.isOptional()) {
/* 420 */               return true;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 425 */       return false;
/*     */     } }
/*     */   
/*     */   private static final class ProxyRuntimeHintsRegistrar extends Record { private final AutowireCandidateResolver candidateResolver;
/*     */     
/* 430 */     private ProxyRuntimeHintsRegistrar(AutowireCandidateResolver candidateResolver) { this.candidateResolver = candidateResolver; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ProxyRuntimeHintsRegistrar;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #430	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 430 */       //   0	7	0	this	Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ProxyRuntimeHintsRegistrar; } public AutowireCandidateResolver candidateResolver() { return this.candidateResolver; }
/*     */     public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ProxyRuntimeHintsRegistrar;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #430	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ProxyRuntimeHintsRegistrar; }
/*     */     public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ProxyRuntimeHintsRegistrar;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #430	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ProxyRuntimeHintsRegistrar;
/*     */       //   0	8	1	o	Ljava/lang/Object; } public void registerRuntimeHints(RuntimeHints runtimeHints, Executable executable) {
/* 433 */       Class<?>[] parameterTypes = executable.getParameterTypes();
/* 434 */       for (int i = 0; i < parameterTypes.length; i++) {
/* 435 */         MethodParameter methodParam = MethodParameter.forExecutable(executable, i);
/* 436 */         DependencyDescriptor dependencyDescriptor = new DependencyDescriptor(methodParam, true);
/* 437 */         registerProxyIfNecessary(runtimeHints, dependencyDescriptor);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void registerProxyIfNecessary(RuntimeHints runtimeHints, DependencyDescriptor dependencyDescriptor) {
/* 442 */       Class<?> proxyType = this.candidateResolver.getLazyResolutionProxyClass(dependencyDescriptor, null);
/* 443 */       if (proxyType != null && Proxy.isProxyClass(proxyType))
/* 444 */         runtimeHints.proxies().registerJdkProxy(proxyType.getInterfaces()); 
/*     */     } }
/*     */   static final class ConstructorDescriptor extends Record { private final String beanName;
/*     */     private final Constructor<?> constructor;
/*     */     private final Class<?> publicType;
/*     */     
/* 450 */     ConstructorDescriptor(String beanName, Constructor<?> constructor, Class<?> publicType) { this.beanName = beanName; this.constructor = constructor; this.publicType = publicType; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ConstructorDescriptor;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #450	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ConstructorDescriptor; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ConstructorDescriptor;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #450	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ConstructorDescriptor; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ConstructorDescriptor;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #450	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/beans/factory/aot/InstanceSupplierCodeGenerator$ConstructorDescriptor;
/* 450 */       //   0	8	1	o	Ljava/lang/Object; } public String beanName() { return this.beanName; } public Constructor<?> constructor() { return this.constructor; } public Class<?> publicType() { return this.publicType; }
/*     */     
/*     */     Class<?> actualType() {
/* 453 */       return this.constructor.getDeclaringClass();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\InstanceSupplierCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */