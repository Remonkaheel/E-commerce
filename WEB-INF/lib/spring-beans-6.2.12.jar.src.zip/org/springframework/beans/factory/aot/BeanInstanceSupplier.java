/*     */ package org.springframework.beans.factory.aot;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionValueResolver;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.InstanceSupplier;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.function.ThrowingBiFunction;
/*     */ import org.springframework.util.function.ThrowingFunction;
/*     */ import org.springframework.util.function.ThrowingSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BeanInstanceSupplier<T>
/*     */   extends AutowiredElementResolver
/*     */   implements InstanceSupplier<T>
/*     */ {
/*     */   private final ExecutableLookup lookup;
/*     */   @Nullable
/*     */   private final ThrowingFunction<RegisteredBean, T> generatorWithoutArguments;
/*     */   @Nullable
/*     */   private final ThrowingBiFunction<RegisteredBean, AutowiredArguments, T> generatorWithArguments;
/*     */   @Nullable
/*     */   private final String[] shortcutBeanNames;
/*     */   
/*     */   private BeanInstanceSupplier(ExecutableLookup lookup, @Nullable ThrowingFunction<RegisteredBean, T> generatorWithoutArguments, @Nullable ThrowingBiFunction<RegisteredBean, AutowiredArguments, T> generatorWithArguments, @Nullable String[] shortcutBeanNames) {
/* 104 */     this.lookup = lookup;
/* 105 */     this.generatorWithoutArguments = generatorWithoutArguments;
/* 106 */     this.generatorWithArguments = generatorWithArguments;
/* 107 */     this.shortcutBeanNames = shortcutBeanNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanInstanceSupplier<T> forConstructor(Class<?>... parameterTypes) {
/* 119 */     Assert.notNull(parameterTypes, "'parameterTypes' must not be null");
/* 120 */     Assert.noNullElements((Object[])parameterTypes, "'parameterTypes' must not contain null elements");
/* 121 */     return new BeanInstanceSupplier<>(new ConstructorLookup(parameterTypes), null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> BeanInstanceSupplier<T> forFactoryMethod(Class<?> declaringClass, String methodName, Class<?>... parameterTypes) {
/* 136 */     Assert.notNull(declaringClass, "'declaringClass' must not be null");
/* 137 */     Assert.hasText(methodName, "'methodName' must not be empty");
/* 138 */     Assert.notNull(parameterTypes, "'parameterTypes' must not be null");
/* 139 */     Assert.noNullElements((Object[])parameterTypes, "'parameterTypes' must not contain null elements");
/* 140 */     return new BeanInstanceSupplier<>(new FactoryMethodLookup(declaringClass, methodName, parameterTypes), null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExecutableLookup getLookup() {
/* 147 */     return this.lookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInstanceSupplier<T> withGenerator(ThrowingBiFunction<RegisteredBean, AutowiredArguments, T> generator) {
/* 159 */     Assert.notNull(generator, "'generator' must not be null");
/* 160 */     return new BeanInstanceSupplier(this.lookup, null, generator, this.shortcutBeanNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInstanceSupplier<T> withGenerator(ThrowingFunction<RegisteredBean, T> generator) {
/* 171 */     Assert.notNull(generator, "'generator' must not be null");
/* 172 */     return new BeanInstanceSupplier(this.lookup, generator, null, this.shortcutBeanNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.0.11", forRemoval = true)
/*     */   public BeanInstanceSupplier<T> withGenerator(ThrowingSupplier<T> generator) {
/* 184 */     Assert.notNull(generator, "'generator' must not be null");
/* 185 */     return new BeanInstanceSupplier(this.lookup, registeredBean -> generator.get(), null, this.shortcutBeanNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public BeanInstanceSupplier<T> withShortcuts(String... beanNames) {
/* 196 */     return withShortcut(beanNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInstanceSupplier<T> withShortcut(String... beanNames) {
/* 209 */     return new BeanInstanceSupplier(this.lookup, this.generatorWithoutArguments, this.generatorWithArguments, beanNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get(RegisteredBean registeredBean) {
/* 217 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 218 */     if (this.generatorWithoutArguments != null) {
/* 219 */       Executable executable1 = getFactoryMethodForGenerator();
/* 220 */       return invokeBeanSupplier(executable1, () -> this.generatorWithoutArguments.apply(registeredBean));
/*     */     } 
/* 222 */     if (this.generatorWithArguments != null) {
/* 223 */       Executable executable1 = getFactoryMethodForGenerator();
/* 224 */       AutowiredArguments autowiredArguments = resolveArguments(registeredBean, 
/* 225 */           (executable1 != null) ? executable1 : this.lookup.get(registeredBean));
/* 226 */       return invokeBeanSupplier(executable1, () -> this.generatorWithArguments.apply(registeredBean, arguments));
/*     */     } 
/*     */     
/* 229 */     Executable executable = this.lookup.get(registeredBean);
/* 230 */     Object[] arguments = resolveArguments(registeredBean, executable).toArray();
/* 231 */     return invokeBeanSupplier(executable, () -> instantiate(registeredBean, executable, arguments));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getFactoryMethod() {
/* 239 */     ExecutableLookup executableLookup = this.lookup; if (executableLookup instanceof FactoryMethodLookup) { FactoryMethodLookup factoryMethodLookup = (FactoryMethodLookup)executableLookup;
/* 240 */       return factoryMethodLookup.get(); }
/*     */     
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Method getFactoryMethodForGenerator() {
/* 248 */     ExecutableLookup executableLookup = this.lookup; if (executableLookup instanceof FactoryMethodLookup) { FactoryMethodLookup factoryMethodLookup = (FactoryMethodLookup)executableLookup; if (factoryMethodLookup.declaringClass
/* 249 */         .getName().contains("$$"))
/* 250 */         return factoryMethodLookup.get();  }
/*     */     
/* 252 */     return null;
/*     */   }
/*     */   
/*     */   private T invokeBeanSupplier(@Nullable Executable executable, ThrowingSupplier<T> beanSupplier) {
/* 256 */     if (executable instanceof Method) { Method method = (Method)executable;
/* 257 */       return (T)SimpleInstantiationStrategy.instantiateWithFactoryMethod(method, (Supplier)beanSupplier); }
/*     */     
/* 259 */     return (T)beanSupplier.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AutowiredArguments resolveArguments(RegisteredBean registeredBean) {
/* 268 */     Assert.notNull(registeredBean, "'registeredBean' must not be null");
/* 269 */     return resolveArguments(registeredBean, this.lookup.get(registeredBean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AutowiredArguments resolveArguments(RegisteredBean registeredBean, Executable executable) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: invokevirtual getParameterCount : ()I
/*     */     //   4: istore_3
/*     */     //   5: iload_3
/*     */     //   6: anewarray java/lang/Object
/*     */     //   9: astore #4
/*     */     //   11: aload_0
/*     */     //   12: getfield shortcutBeanNames : [Ljava/lang/String;
/*     */     //   15: ifnull -> 29
/*     */     //   18: aload_0
/*     */     //   19: getfield shortcutBeanNames : [Ljava/lang/String;
/*     */     //   22: arraylength
/*     */     //   23: aload #4
/*     */     //   25: arraylength
/*     */     //   26: if_icmpne -> 33
/*     */     //   29: iconst_1
/*     */     //   30: goto -> 34
/*     */     //   33: iconst_0
/*     */     //   34: aload #4
/*     */     //   36: <illegal opcode> get : ([Ljava/lang/Object;)Ljava/util/function/Supplier;
/*     */     //   41: invokestatic isTrue : (ZLjava/util/function/Supplier;)V
/*     */     //   44: aload_0
/*     */     //   45: aload_1
/*     */     //   46: aload_2
/*     */     //   47: invokevirtual resolveArgumentValues : (Lorg/springframework/beans/factory/support/RegisteredBean;Ljava/lang/reflect/Executable;)[Lorg/springframework/beans/factory/config/ConstructorArgumentValues$ValueHolder;
/*     */     //   50: astore #5
/*     */     //   52: new java/util/LinkedHashSet
/*     */     //   55: dup
/*     */     //   56: aload #4
/*     */     //   58: arraylength
/*     */     //   59: iconst_2
/*     */     //   60: imul
/*     */     //   61: invokespecial <init> : (I)V
/*     */     //   64: astore #6
/*     */     //   66: aload_2
/*     */     //   67: instanceof java/lang/reflect/Constructor
/*     */     //   70: ifeq -> 94
/*     */     //   73: aload_2
/*     */     //   74: checkcast java/lang/reflect/Constructor
/*     */     //   77: astore #8
/*     */     //   79: aload #8
/*     */     //   81: invokevirtual getDeclaringClass : ()Ljava/lang/Class;
/*     */     //   84: invokestatic isInnerClass : (Ljava/lang/Class;)Z
/*     */     //   87: ifeq -> 94
/*     */     //   90: iconst_1
/*     */     //   91: goto -> 95
/*     */     //   94: iconst_0
/*     */     //   95: istore #7
/*     */     //   97: iload #7
/*     */     //   99: istore #8
/*     */     //   101: iload #8
/*     */     //   103: iload_3
/*     */     //   104: if_icmpge -> 195
/*     */     //   107: aload_0
/*     */     //   108: aload_2
/*     */     //   109: iload #8
/*     */     //   111: invokevirtual getMethodParameter : (Ljava/lang/reflect/Executable;I)Lorg/springframework/core/MethodParameter;
/*     */     //   114: astore #9
/*     */     //   116: new org/springframework/beans/factory/config/DependencyDescriptor
/*     */     //   119: dup
/*     */     //   120: aload #9
/*     */     //   122: iconst_1
/*     */     //   123: invokespecial <init> : (Lorg/springframework/core/MethodParameter;Z)V
/*     */     //   126: astore #10
/*     */     //   128: aload_0
/*     */     //   129: getfield shortcutBeanNames : [Ljava/lang/String;
/*     */     //   132: ifnull -> 145
/*     */     //   135: aload_0
/*     */     //   136: getfield shortcutBeanNames : [Ljava/lang/String;
/*     */     //   139: iload #8
/*     */     //   141: aaload
/*     */     //   142: goto -> 146
/*     */     //   145: aconst_null
/*     */     //   146: astore #11
/*     */     //   148: aload #11
/*     */     //   150: ifnull -> 166
/*     */     //   153: new org/springframework/beans/factory/aot/AutowiredElementResolver$ShortcutDependencyDescriptor
/*     */     //   156: dup
/*     */     //   157: aload #10
/*     */     //   159: aload #11
/*     */     //   161: invokespecial <init> : (Lorg/springframework/beans/factory/config/DependencyDescriptor;Ljava/lang/String;)V
/*     */     //   164: astore #10
/*     */     //   166: aload #5
/*     */     //   168: iload #8
/*     */     //   170: aaload
/*     */     //   171: astore #12
/*     */     //   173: aload #4
/*     */     //   175: iload #8
/*     */     //   177: aload_0
/*     */     //   178: aload_1
/*     */     //   179: aload #10
/*     */     //   181: aload #12
/*     */     //   183: aload #6
/*     */     //   185: invokevirtual resolveAutowiredArgument : (Lorg/springframework/beans/factory/support/RegisteredBean;Lorg/springframework/beans/factory/config/DependencyDescriptor;Lorg/springframework/beans/factory/config/ConstructorArgumentValues$ValueHolder;Ljava/util/Set;)Ljava/lang/Object;
/*     */     //   188: aastore
/*     */     //   189: iinc #8, 1
/*     */     //   192: goto -> 101
/*     */     //   195: aload_0
/*     */     //   196: aload_1
/*     */     //   197: invokevirtual getBeanFactory : ()Lorg/springframework/beans/factory/config/ConfigurableListableBeanFactory;
/*     */     //   200: aload_1
/*     */     //   201: invokevirtual getBeanName : ()Ljava/lang/String;
/*     */     //   204: aload #6
/*     */     //   206: invokevirtual registerDependentBeans : (Lorg/springframework/beans/factory/config/ConfigurableBeanFactory;Ljava/lang/String;Ljava/util/Set;)V
/*     */     //   209: aload #4
/*     */     //   211: invokestatic of : ([Ljava/lang/Object;)Lorg/springframework/beans/factory/aot/AutowiredArguments;
/*     */     //   214: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #273	-> 0
/*     */     //   #274	-> 5
/*     */     //   #275	-> 11
/*     */     //   #278	-> 44
/*     */     //   #279	-> 52
/*     */     //   #280	-> 66
/*     */     //   #281	-> 81
/*     */     //   #282	-> 97
/*     */     //   #283	-> 107
/*     */     //   #284	-> 116
/*     */     //   #285	-> 128
/*     */     //   #286	-> 148
/*     */     //   #287	-> 153
/*     */     //   #289	-> 166
/*     */     //   #290	-> 173
/*     */     //   #282	-> 189
/*     */     //   #293	-> 195
/*     */     //   #295	-> 209
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   79	15	8	constructor	Ljava/lang/reflect/Constructor;
/*     */     //   116	73	9	parameter	Lorg/springframework/core/MethodParameter;
/*     */     //   128	61	10	descriptor	Lorg/springframework/beans/factory/config/DependencyDescriptor;
/*     */     //   148	41	11	shortcut	Ljava/lang/String;
/*     */     //   173	16	12	argumentValue	Lorg/springframework/beans/factory/config/ConstructorArgumentValues$ValueHolder;
/*     */     //   101	94	8	i	I
/*     */     //   0	215	0	this	Lorg/springframework/beans/factory/aot/BeanInstanceSupplier;
/*     */     //   0	215	1	registeredBean	Lorg/springframework/beans/factory/support/RegisteredBean;
/*     */     //   0	215	2	executable	Ljava/lang/reflect/Executable;
/*     */     //   5	210	3	parameterCount	I
/*     */     //   11	204	4	resolved	[Ljava/lang/Object;
/*     */     //   52	163	5	argumentValues	[Lorg/springframework/beans/factory/config/ConstructorArgumentValues$ValueHolder;
/*     */     //   66	149	6	autowiredBeanNames	Ljava/util/Set;
/*     */     //   97	118	7	startIndex	I
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   79	15	8	constructor	Ljava/lang/reflect/Constructor<*>;
/*     */     //   0	215	0	this	Lorg/springframework/beans/factory/aot/BeanInstanceSupplier<TT;>;
/*     */     //   66	149	6	autowiredBeanNames	Ljava/util/Set<Ljava/lang/String;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodParameter getMethodParameter(Executable executable, int index) {
/* 299 */     if (executable instanceof Constructor) { Constructor<?> constructor = (Constructor)executable;
/* 300 */       return new MethodParameter(constructor, index); }
/*     */     
/* 302 */     if (executable instanceof Method) { Method method = (Method)executable;
/* 303 */       return new MethodParameter(method, index); }
/*     */     
/* 305 */     throw new IllegalStateException("Unsupported executable: " + executable.getClass().getName());
/*     */   }
/*     */   
/*     */   private ConstructorArgumentValues.ValueHolder[] resolveArgumentValues(RegisteredBean registeredBean, Executable executable) {
/* 309 */     Parameter[] parameters = executable.getParameters();
/* 310 */     ConstructorArgumentValues.ValueHolder[] resolved = new ConstructorArgumentValues.ValueHolder[parameters.length];
/* 311 */     RootBeanDefinition beanDefinition = registeredBean.getMergedBeanDefinition();
/* 312 */     if (beanDefinition.hasConstructorArgumentValues()) {
/* 313 */       ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory(); if (configurableListableBeanFactory instanceof AbstractAutowireCapableBeanFactory) { AbstractAutowireCapableBeanFactory beanFactory = (AbstractAutowireCapableBeanFactory)configurableListableBeanFactory;
/*     */         
/* 315 */         BeanDefinitionValueResolver valueResolver = new BeanDefinitionValueResolver(beanFactory, registeredBean.getBeanName(), (BeanDefinition)beanDefinition, beanFactory.getTypeConverter());
/* 316 */         ConstructorArgumentValues values = resolveConstructorArguments(valueResolver, beanDefinition
/* 317 */             .getConstructorArgumentValues());
/* 318 */         Set<ConstructorArgumentValues.ValueHolder> usedValueHolders = CollectionUtils.newHashSet(parameters.length);
/* 319 */         for (int i = 0; i < parameters.length; i++) {
/* 320 */           Class<?> parameterType = parameters[i].getType();
/* 321 */           String parameterName = parameters[i].isNamePresent() ? parameters[i].getName() : null;
/* 322 */           ConstructorArgumentValues.ValueHolder valueHolder = values.getArgumentValue(i, parameterType, parameterName, usedValueHolders);
/*     */           
/* 324 */           if (valueHolder != null) {
/* 325 */             resolved[i] = valueHolder;
/* 326 */             usedValueHolders.add(valueHolder);
/*     */           } 
/*     */         }  }
/*     */     
/* 330 */     }  return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConstructorArgumentValues resolveConstructorArguments(BeanDefinitionValueResolver valueResolver, ConstructorArgumentValues constructorArguments) {
/* 336 */     ConstructorArgumentValues resolvedConstructorArguments = new ConstructorArgumentValues();
/* 337 */     for (Map.Entry<Integer, ConstructorArgumentValues.ValueHolder> entry : (Iterable<Map.Entry<Integer, ConstructorArgumentValues.ValueHolder>>)constructorArguments.getIndexedArgumentValues().entrySet()) {
/* 338 */       resolvedConstructorArguments.addIndexedArgumentValue(((Integer)entry.getKey()).intValue(), resolveArgumentValue(valueResolver, entry.getValue()));
/*     */     }
/* 340 */     for (ConstructorArgumentValues.ValueHolder valueHolder : constructorArguments.getGenericArgumentValues()) {
/* 341 */       resolvedConstructorArguments.addGenericArgumentValue(resolveArgumentValue(valueResolver, valueHolder));
/*     */     }
/* 343 */     return resolvedConstructorArguments;
/*     */   }
/*     */   
/*     */   private ConstructorArgumentValues.ValueHolder resolveArgumentValue(BeanDefinitionValueResolver resolver, ConstructorArgumentValues.ValueHolder valueHolder) {
/* 347 */     if (valueHolder.isConverted()) {
/* 348 */       return valueHolder;
/*     */     }
/* 350 */     Object value = resolver.resolveValueIfNecessary("constructor argument", valueHolder.getValue());
/* 351 */     ConstructorArgumentValues.ValueHolder resolvedHolder = new ConstructorArgumentValues.ValueHolder(value, valueHolder.getType(), valueHolder.getName());
/* 352 */     resolvedHolder.setSource(valueHolder);
/* 353 */     return resolvedHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object resolveAutowiredArgument(RegisteredBean registeredBean, DependencyDescriptor descriptor, @Nullable ConstructorArgumentValues.ValueHolder argumentValue, Set<String> autowiredBeanNames) {
/* 360 */     TypeConverter typeConverter = registeredBean.getBeanFactory().getTypeConverter();
/* 361 */     if (argumentValue != null) {
/* 362 */       return argumentValue.isConverted() ? argumentValue.getConvertedValue() : 
/* 363 */         typeConverter.convertIfNecessary(argumentValue.getValue(), descriptor
/* 364 */           .getDependencyType(), descriptor.getMethodParameter());
/*     */     }
/*     */     try {
/* 367 */       return registeredBean.resolveAutowiredArgument(descriptor, typeConverter, autowiredBeanNames);
/*     */     }
/* 369 */     catch (BeansException ex) {
/* 370 */       throw new UnsatisfiedDependencyException(null, registeredBean.getBeanName(), descriptor, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object instantiate(RegisteredBean registeredBean, Executable executable, Object[] args) {
/* 375 */     if (executable instanceof Constructor) { Constructor<?> constructor = (Constructor)executable;
/* 376 */       ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory(); if (configurableListableBeanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)configurableListableBeanFactory; if (registeredBean
/* 377 */           .getMergedBeanDefinition().hasMethodOverrides())
/* 378 */           return dlbf.getInstantiationStrategy().instantiate(registeredBean.getMergedBeanDefinition(), registeredBean
/* 379 */               .getBeanName(), (BeanFactory)registeredBean.getBeanFactory());  }
/*     */       
/* 381 */       return BeanUtils.instantiateClass(constructor, args); }
/*     */     
/* 383 */     if (executable instanceof Method) { Method method = (Method)executable;
/* 384 */       Object target = null;
/* 385 */       String factoryBeanName = registeredBean.getMergedBeanDefinition().getFactoryBeanName();
/* 386 */       if (factoryBeanName != null) {
/* 387 */         target = registeredBean.getBeanFactory().getBean(factoryBeanName, method.getDeclaringClass());
/*     */       }
/* 389 */       else if (!Modifier.isStatic(method.getModifiers())) {
/* 390 */         throw new IllegalStateException("Cannot invoke instance method without factoryBeanName: " + String.valueOf(method));
/*     */       } 
/*     */       try {
/* 393 */         ReflectionUtils.makeAccessible(method);
/* 394 */         return method.invoke(target, args);
/*     */       }
/* 396 */       catch (Throwable ex) {
/* 397 */         throw new BeanInstantiationException(method, ex.getMessage(), ex);
/*     */       }  }
/*     */     
/* 400 */     throw new IllegalStateException("Unsupported executable " + executable.getClass().getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toCommaSeparatedNames(Class<?>... parameterTypes) {
/* 405 */     return Arrays.<Class<?>>stream(parameterTypes).map(Class::getName).collect(Collectors.joining(", "));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class ExecutableLookup
/*     */   {
/*     */     abstract Executable get(RegisteredBean param1RegisteredBean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConstructorLookup
/*     */     extends ExecutableLookup
/*     */   {
/*     */     private final Class<?>[] parameterTypes;
/*     */ 
/*     */ 
/*     */     
/*     */     ConstructorLookup(Class<?>[] parameterTypes) {
/* 426 */       this.parameterTypes = parameterTypes;
/*     */     }
/*     */ 
/*     */     
/*     */     public Executable get(RegisteredBean registeredBean) {
/* 431 */       Class<?> beanClass = registeredBean.getMergedBeanDefinition().getBeanClass();
/*     */       try {
/* 433 */         return beanClass.getDeclaredConstructor(this.parameterTypes);
/*     */       }
/* 435 */       catch (NoSuchMethodException ex) {
/* 436 */         throw new IllegalArgumentException("%s cannot be found on %s"
/* 437 */             .formatted(new Object[] { this, beanClass.getName() }, ), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 443 */       return "Constructor with parameter types [%s]".formatted(new Object[] { BeanInstanceSupplier.toCommaSeparatedNames(this.parameterTypes) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class FactoryMethodLookup
/*     */     extends ExecutableLookup
/*     */   {
/*     */     private final Class<?> declaringClass;
/*     */     
/*     */     private final String methodName;
/*     */     
/*     */     private final Class<?>[] parameterTypes;
/*     */     
/*     */     @Nullable
/*     */     private volatile Method resolvedMethod;
/*     */ 
/*     */     
/*     */     FactoryMethodLookup(Class<?> declaringClass, String methodName, Class<?>[] parameterTypes) {
/* 463 */       this.declaringClass = declaringClass;
/* 464 */       this.methodName = methodName;
/* 465 */       this.parameterTypes = parameterTypes;
/*     */     }
/*     */ 
/*     */     
/*     */     public Executable get(RegisteredBean registeredBean) {
/* 470 */       return get();
/*     */     }
/*     */     
/*     */     Method get() {
/* 474 */       Method method = this.resolvedMethod;
/* 475 */       if (method == null) {
/* 476 */         method = ReflectionUtils.findMethod(
/* 477 */             ClassUtils.getUserClass(this.declaringClass), this.methodName, this.parameterTypes);
/* 478 */         Assert.notNull(method, () -> "%s cannot be found".formatted(new Object[] { this }));
/* 479 */         this.resolvedMethod = method;
/*     */       } 
/* 481 */       return method;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 486 */       return "Factory method '%s' with parameter types [%s] declared on %s".formatted(new Object[] { this.methodName, 
/* 487 */             BeanInstanceSupplier.toCommaSeparatedNames(this.parameterTypes), this.declaringClass });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\aot\BeanInstanceSupplier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */