/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ObjectProvider<T>
/*     */   extends ObjectFactory<T>, Iterable<T>
/*     */ {
/*     */   public static final Predicate<Class<?>> UNFILTERED = clazz -> true;
/*     */   
/*     */   default T getObject() throws BeansException {
/*  86 */     Iterator<T> it = iterator();
/*  87 */     if (!it.hasNext()) {
/*  88 */       throw new NoSuchBeanDefinitionException(Object.class);
/*     */     }
/*  90 */     T result = it.next();
/*  91 */     if (it.hasNext()) {
/*  92 */       throw new NoUniqueBeanDefinitionException(Object.class, 2, "more than 1 matching bean");
/*     */     }
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T getObject(Object... args) throws BeansException {
/* 108 */     throw new UnsupportedOperationException("Retrieval with arguments not supported -for custom ObjectProvider classes, implement getObject(Object...) for your purposes");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default T getIfAvailable() throws BeansException {
/*     */     try {
/* 122 */       return getObject();
/*     */     }
/* 124 */     catch (NoUniqueBeanDefinitionException ex) {
/* 125 */       throw ex;
/*     */     }
/* 127 */     catch (NoSuchBeanDefinitionException ex) {
/* 128 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default T getIfAvailable(Supplier<T> defaultSupplier) throws BeansException {
/* 144 */     T dependency = getIfAvailable();
/* 145 */     return (dependency != null) ? dependency : defaultSupplier.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void ifAvailable(Consumer<T> dependencyConsumer) throws BeansException {
/* 158 */     T dependency = getIfAvailable();
/* 159 */     if (dependency != null) {
/* 160 */       dependencyConsumer.accept(dependency);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default T getIfUnique() throws BeansException {
/*     */     try {
/* 175 */       return getObject();
/*     */     }
/* 177 */     catch (NoSuchBeanDefinitionException ex) {
/* 178 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default T getIfUnique(Supplier<T> defaultSupplier) throws BeansException {
/* 195 */     T dependency = getIfUnique();
/* 196 */     return (dependency != null) ? dependency : defaultSupplier.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void ifUnique(Consumer<T> dependencyConsumer) throws BeansException {
/* 209 */     T dependency = getIfUnique();
/* 210 */     if (dependency != null) {
/* 211 */       dependencyConsumer.accept(dependency);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Iterator<T> iterator() {
/* 223 */     return stream().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<T> stream() {
/* 238 */     throw new UnsupportedOperationException("Element access not supported - for custom ObjectProvider classes, implement stream() to enable all other methods");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<T> orderedStream() {
/* 263 */     return stream().sorted((Comparator<? super T>)OrderComparator.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<T> stream(Predicate<Class<?>> customFilter) {
/* 277 */     return stream(customFilter, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<T> orderedStream(Predicate<Class<?>> customFilter) {
/* 291 */     return orderedStream(customFilter, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<T> stream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/* 307 */     if (!includeNonSingletons) {
/* 308 */       throw new UnsupportedOperationException("Only supports includeNonSingletons=true by default");
/*     */     }
/* 310 */     return stream().filter(obj -> customFilter.test(obj.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Stream<T> orderedStream(Predicate<Class<?>> customFilter, boolean includeNonSingletons) {
/* 326 */     if (!includeNonSingletons) {
/* 327 */       throw new UnsupportedOperationException("Only supports includeNonSingletons=true by default");
/*     */     }
/* 329 */     return orderedStream().filter(obj -> customFilter.test(obj.getClass()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\ObjectProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */