/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BeanFactoryUtils
/*     */ {
/*     */   public static final String GENERATED_BEAN_NAME_SEPARATOR = "#";
/*  64 */   private static final Map<String, String> transformedBeanNameCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFactoryDereference(@Nullable String name) {
/*  75 */     return (name != null && !name.isEmpty() && name.charAt(0) == '&');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String transformedBeanName(String name) {
/*  86 */     Assert.notNull(name, "'name' must not be null");
/*  87 */     if (name.isEmpty() || name.charAt(0) != '&') {
/*  88 */       return name;
/*     */     }
/*  90 */     return transformedBeanNameCache.computeIfAbsent(name, beanName -> {
/*     */           while (true) {
/*     */             beanName = beanName.substring(1);
/*     */             if (beanName.charAt(0) != '&') {
/*     */               return beanName;
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isGeneratedBeanName(@Nullable String name) {
/* 109 */     return (name != null && name.contains("#"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String originalBeanName(String name) {
/* 120 */     Assert.notNull(name, "'name' must not be null");
/* 121 */     int separatorIndex = name.indexOf("#");
/* 122 */     return (separatorIndex != -1) ? name.substring(0, separatorIndex) : name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int countBeansIncludingAncestors(ListableBeanFactory lbf) {
/* 138 */     return (beanNamesIncludingAncestors(lbf)).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] beanNamesIncludingAncestors(ListableBeanFactory lbf) {
/* 148 */     return beanNamesForTypeIncludingAncestors(lbf, Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] beanNamesForTypeIncludingAncestors(ListableBeanFactory lbf, ResolvableType type) {
/* 166 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 167 */     String[] result = lbf.getBeanNamesForType(type);
/* 168 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 169 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 170 */         String[] parentResult = beanNamesForTypeIncludingAncestors(pbf, type);
/* 171 */         result = mergeNamesWithParent(result, parentResult, hbf); }
/*     */        }
/*     */     
/* 174 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] beanNamesForTypeIncludingAncestors(ListableBeanFactory lbf, ResolvableType type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 202 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 203 */     String[] result = lbf.getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/* 204 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 205 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 206 */         String[] parentResult = beanNamesForTypeIncludingAncestors(pbf, type, includeNonSingletons, allowEagerInit);
/*     */         
/* 208 */         result = mergeNamesWithParent(result, parentResult, hbf); }
/*     */        }
/*     */     
/* 211 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] beanNamesForTypeIncludingAncestors(ListableBeanFactory lbf, Class<?> type) {
/* 228 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 229 */     String[] result = lbf.getBeanNamesForType(type);
/* 230 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 231 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 232 */         String[] parentResult = beanNamesForTypeIncludingAncestors(pbf, type);
/* 233 */         result = mergeNamesWithParent(result, parentResult, hbf); }
/*     */        }
/*     */     
/* 236 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] beanNamesForTypeIncludingAncestors(ListableBeanFactory lbf, Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 263 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 264 */     String[] result = lbf.getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/* 265 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 266 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 267 */         String[] parentResult = beanNamesForTypeIncludingAncestors(pbf, type, includeNonSingletons, allowEagerInit);
/*     */         
/* 269 */         result = mergeNamesWithParent(result, parentResult, hbf); }
/*     */        }
/*     */     
/* 272 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] beanNamesForAnnotationIncludingAncestors(ListableBeanFactory lbf, Class<? extends Annotation> annotationType) {
/* 288 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 289 */     String[] result = lbf.getBeanNamesForAnnotation(annotationType);
/* 290 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 291 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 292 */         String[] parentResult = beanNamesForAnnotationIncludingAncestors(pbf, annotationType);
/* 293 */         result = mergeNamesWithParent(result, parentResult, hbf); }
/*     */        }
/*     */     
/* 296 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Map<String, T> beansOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type) throws BeansException {
/* 323 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 324 */     Map<String, T> result = new LinkedHashMap<>(4);
/* 325 */     result.putAll(lbf.getBeansOfType(type));
/* 326 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 327 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 328 */         Map<String, T> parentResult = beansOfTypeIncludingAncestors(pbf, type);
/* 329 */         parentResult.forEach((beanName, beanInstance) -> {
/*     */               if (!result.containsKey(beanName) && !hbf.containsLocalBean(beanName)) {
/*     */                 result.put(beanName, beanInstance);
/*     */               }
/*     */             }); }
/*     */        }
/*     */     
/* 336 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Map<String, T> beansOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type, boolean includeNonSingletons, boolean allowEagerInit) throws BeansException {
/* 370 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 371 */     Map<String, T> result = new LinkedHashMap<>(4);
/* 372 */     result.putAll(lbf.getBeansOfType(type, includeNonSingletons, allowEagerInit));
/* 373 */     if (lbf instanceof HierarchicalBeanFactory) { HierarchicalBeanFactory hbf = (HierarchicalBeanFactory)lbf;
/* 374 */       BeanFactory beanFactory = hbf.getParentBeanFactory(); if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory pbf = (ListableBeanFactory)beanFactory;
/* 375 */         Map<String, T> parentResult = beansOfTypeIncludingAncestors(pbf, type, includeNonSingletons, allowEagerInit);
/* 376 */         parentResult.forEach((beanName, beanInstance) -> {
/*     */               if (!result.containsKey(beanName) && !hbf.containsLocalBean(beanName)) {
/*     */                 result.put(beanName, beanInstance);
/*     */               }
/*     */             }); }
/*     */        }
/*     */     
/* 383 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T beanOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type) throws BeansException {
/* 412 */     Map<String, T> beansOfType = beansOfTypeIncludingAncestors(lbf, type);
/* 413 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T beanOfTypeIncludingAncestors(ListableBeanFactory lbf, Class<T> type, boolean includeNonSingletons, boolean allowEagerInit) throws BeansException {
/* 450 */     Map<String, T> beansOfType = beansOfTypeIncludingAncestors(lbf, type, includeNonSingletons, allowEagerInit);
/* 451 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T beanOfType(ListableBeanFactory lbf, Class<T> type) throws BeansException {
/* 472 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 473 */     Map<String, T> beansOfType = lbf.getBeansOfType(type);
/* 474 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T beanOfType(ListableBeanFactory lbf, Class<T> type, boolean includeNonSingletons, boolean allowEagerInit) throws BeansException {
/* 506 */     Assert.notNull(lbf, "ListableBeanFactory must not be null");
/* 507 */     Map<String, T> beansOfType = lbf.getBeansOfType(type, includeNonSingletons, allowEagerInit);
/* 508 */     return uniqueBean(type, beansOfType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] mergeNamesWithParent(String[] result, String[] parentResult, HierarchicalBeanFactory hbf) {
/* 521 */     if (parentResult.length == 0) {
/* 522 */       return result;
/*     */     }
/* 524 */     List<String> merged = new ArrayList<>(result.length + parentResult.length);
/* 525 */     merged.addAll(Arrays.asList(result));
/* 526 */     for (String beanName : parentResult) {
/* 527 */       if (!merged.contains(beanName) && !hbf.containsLocalBean(beanName)) {
/* 528 */         merged.add(beanName);
/*     */       }
/*     */     } 
/* 531 */     return StringUtils.toStringArray(merged);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T uniqueBean(Class<T> type, Map<String, T> matchingBeans) {
/* 543 */     int count = matchingBeans.size();
/* 544 */     if (count == 1) {
/* 545 */       return matchingBeans.values().iterator().next();
/*     */     }
/* 547 */     if (count > 1) {
/* 548 */       throw new NoUniqueBeanDefinitionException(type, matchingBeans.keySet());
/*     */     }
/*     */     
/* 551 */     throw new NoSuchBeanDefinitionException(type);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\BeanFactoryUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */