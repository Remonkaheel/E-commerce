/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.Objects;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InjectionPoint
/*     */ {
/*     */   @Nullable
/*     */   protected MethodParameter methodParameter;
/*     */   @Nullable
/*     */   protected Field field;
/*     */   @Nullable
/*     */   private volatile Annotation[] fieldAnnotations;
/*     */   
/*     */   public InjectionPoint(MethodParameter methodParameter) {
/*  60 */     Assert.notNull(methodParameter, "MethodParameter must not be null");
/*  61 */     this.methodParameter = methodParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InjectionPoint(Field field) {
/*  69 */     Assert.notNull(field, "Field must not be null");
/*  70 */     this.field = field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InjectionPoint(InjectionPoint original) {
/*  78 */     this
/*  79 */       .methodParameter = (original.methodParameter != null) ? new MethodParameter(original.methodParameter) : null;
/*  80 */     this.field = original.field;
/*  81 */     this.fieldAnnotations = original.fieldAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InjectionPoint() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public MethodParameter getMethodParameter() {
/*  98 */     return this.methodParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Field getField() {
/* 108 */     return this.field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MethodParameter obtainMethodParameter() {
/* 118 */     Assert.state((this.methodParameter != null), "MethodParameter is not available");
/* 119 */     return this.methodParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 126 */     if (this.field != null) {
/* 127 */       Annotation[] fieldAnnotations = this.fieldAnnotations;
/* 128 */       if (fieldAnnotations == null) {
/* 129 */         fieldAnnotations = this.field.getAnnotations();
/* 130 */         this.fieldAnnotations = fieldAnnotations;
/*     */       } 
/* 132 */       return fieldAnnotations;
/*     */     } 
/*     */     
/* 135 */     return obtainMethodParameter().getParameterAnnotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A getAnnotation(Class<A> annotationType) {
/* 147 */     return (this.field != null) ? this.field.<A>getAnnotation(annotationType) : 
/* 148 */       (A)obtainMethodParameter().getParameterAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaredType() {
/* 156 */     return (this.field != null) ? this.field.getType() : obtainMethodParameter().getParameterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Member getMember() {
/* 164 */     return (this.field != null) ? this.field : obtainMethodParameter().getMember();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedElement getAnnotatedElement() {
/* 177 */     return (this.field != null) ? this.field : obtainMethodParameter().getAnnotatedElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 183 */     if (this == other) {
/* 184 */       return true;
/*     */     }
/* 186 */     if (other == null || getClass() != other.getClass()) {
/* 187 */       return false;
/*     */     }
/* 189 */     InjectionPoint otherPoint = (InjectionPoint)other;
/* 190 */     return (ObjectUtils.nullSafeEquals(this.field, otherPoint.field) && 
/* 191 */       ObjectUtils.nullSafeEquals(this.methodParameter, otherPoint.methodParameter));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 196 */     return Objects.hash(new Object[] { this.field, this.methodParameter });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 201 */     return (this.field != null) ? ("field '" + this.field.getName() + "'") : String.valueOf(this.methodParameter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\InjectionPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */