package org.springframework.beans.factory.parsing;

import org.springframework.beans.BeanMetadataElement;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanReference;

public interface ComponentDefinition extends BeanMetadataElement {
  String getName();
  
  String getDescription();
  
  BeanDefinition[] getBeanDefinitions();
  
  BeanDefinition[] getInnerBeanDefinitions();
  
  BeanReference[] getBeanReferences();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\parsing\ComponentDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */