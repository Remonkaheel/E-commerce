package org.springframework.beans.factory.parsing;

public interface ProblemReporter {
  void fatal(Problem paramProblem);
  
  void error(Problem paramProblem);
  
  void warning(Problem paramProblem);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\parsing\ProblemReporter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */