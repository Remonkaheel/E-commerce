package org.springframework.beans.factory.parsing;

import java.util.EventListener;

public interface ReaderEventListener extends EventListener {
  void defaultsRegistered(DefaultsDefinition paramDefaultsDefinition);
  
  void componentRegistered(ComponentDefinition paramComponentDefinition);
  
  void aliasRegistered(AliasDefinition paramAliasDefinition);
  
  void importProcessed(ImportDefinition paramImportDefinition);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\parsing\ReaderEventListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */