/*    */ package org.springframework.beans.factory.parsing;
/*    */ 
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QualifierEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String typeName;
/*    */   
/*    */   public QualifierEntry(String typeName) {
/* 37 */     if (!StringUtils.hasText(typeName)) {
/* 38 */       throw new IllegalArgumentException("Invalid qualifier type '" + typeName + "'");
/*    */     }
/* 40 */     this.typeName = typeName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return "Qualifier '" + this.typeName + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\parsing\QualifierEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */