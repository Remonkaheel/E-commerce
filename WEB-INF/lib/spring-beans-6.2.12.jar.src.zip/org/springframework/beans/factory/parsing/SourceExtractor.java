package org.springframework.beans.factory.parsing;

import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface SourceExtractor {
  @Nullable
  Object extractSource(Object paramObject, @Nullable Resource paramResource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\parsing\SourceExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */