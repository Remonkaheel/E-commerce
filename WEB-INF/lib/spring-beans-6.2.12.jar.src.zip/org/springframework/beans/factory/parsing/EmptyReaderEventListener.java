package org.springframework.beans.factory.parsing;

public class EmptyReaderEventListener implements ReaderEventListener {
  public void defaultsRegistered(DefaultsDefinition defaultsDefinition) {}
  
  public void componentRegistered(ComponentDefinition componentDefinition) {}
  
  public void aliasRegistered(AliasDefinition aliasDefinition) {}
  
  public void importProcessed(ImportDefinition importDefinition) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\parsing\EmptyReaderEventListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */