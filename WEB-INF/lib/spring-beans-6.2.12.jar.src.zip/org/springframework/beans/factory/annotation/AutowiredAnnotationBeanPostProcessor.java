/*      */ package org.springframework.beans.factory.annotation;
/*      */ 
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.lang.model.element.Modifier;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.aot.generate.AccessControl;
/*      */ import org.springframework.aot.generate.GeneratedClass;
/*      */ import org.springframework.aot.generate.GeneratedMethod;
/*      */ import org.springframework.aot.generate.GenerationContext;
/*      */ import org.springframework.aot.hint.ExecutableMode;
/*      */ import org.springframework.aot.hint.RuntimeHints;
/*      */ import org.springframework.aot.hint.support.ClassHintUtils;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.PropertyValues;
/*      */ import org.springframework.beans.TypeConverter;
/*      */ import org.springframework.beans.factory.BeanCreationException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.InjectionPoint;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*      */ import org.springframework.beans.factory.aot.AutowiredArgumentsCodeGenerator;
/*      */ import org.springframework.beans.factory.aot.AutowiredFieldValueResolver;
/*      */ import org.springframework.beans.factory.aot.AutowiredMethodArgumentsResolver;
/*      */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*      */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*      */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*      */ import org.springframework.beans.factory.aot.CodeWarnings;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*      */ import org.springframework.beans.factory.support.AbstractAutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*      */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*      */ import org.springframework.beans.factory.support.LookupOverride;
/*      */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*      */ import org.springframework.beans.factory.support.MethodOverride;
/*      */ import org.springframework.beans.factory.support.RegisteredBean;
/*      */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*      */ import org.springframework.core.BridgeMethodResolver;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.core.PriorityOrdered;
/*      */ import org.springframework.core.annotation.AnnotationUtils;
/*      */ import org.springframework.core.annotation.MergedAnnotation;
/*      */ import org.springframework.core.annotation.MergedAnnotations;
/*      */ import org.springframework.core.type.AnnotationMetadata;
/*      */ import org.springframework.core.type.MethodMetadata;
/*      */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*      */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*      */ import org.springframework.javapoet.ClassName;
/*      */ import org.springframework.javapoet.CodeBlock;
/*      */ import org.springframework.javapoet.MethodSpec;
/*      */ import org.springframework.javapoet.TypeSpec;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AutowiredAnnotationBeanPostProcessor
/*      */   implements SmartInstantiationAwareBeanPostProcessor, MergedBeanDefinitionPostProcessor, BeanRegistrationAotProcessor, PriorityOrdered, BeanFactoryAware
/*      */ {
/*  163 */   private static final Constructor<?>[] EMPTY_CONSTRUCTOR_ARRAY = (Constructor<?>[])new Constructor[0];
/*      */ 
/*      */   
/*  166 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   
/*  168 */   private final Set<Class<? extends Annotation>> autowiredAnnotationTypes = CollectionUtils.newLinkedHashSet(4);
/*      */   
/*  170 */   private String requiredParameterName = "required";
/*      */   
/*      */   private boolean requiredParameterValue = true;
/*      */   
/*  174 */   private int order = 2147483645;
/*      */   
/*      */   @Nullable
/*      */   private ConfigurableListableBeanFactory beanFactory;
/*      */   
/*      */   @Nullable
/*      */   private MetadataReaderFactory metadataReaderFactory;
/*      */   
/*  182 */   private final Set<String> lookupMethodsChecked = ConcurrentHashMap.newKeySet(256);
/*      */   
/*  184 */   private final Map<Class<?>, Constructor<?>[]> candidateConstructorsCache = (Map)new ConcurrentHashMap<>(256);
/*      */   
/*  186 */   private final Map<String, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap<>(256);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AutowiredAnnotationBeanPostProcessor() {
/*  197 */     this.autowiredAnnotationTypes.add(Autowired.class);
/*  198 */     this.autowiredAnnotationTypes.add(Value.class);
/*      */     
/*  200 */     ClassLoader classLoader = AutowiredAnnotationBeanPostProcessor.class.getClassLoader();
/*      */     try {
/*  202 */       this.autowiredAnnotationTypes.add(
/*  203 */           ClassUtils.forName("jakarta.inject.Inject", classLoader));
/*  204 */       this.logger.trace("'jakarta.inject.Inject' annotation found and supported for autowiring");
/*      */     }
/*  206 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  211 */       this.autowiredAnnotationTypes.add(
/*  212 */           ClassUtils.forName("javax.inject.Inject", classLoader));
/*  213 */       this.logger.trace("'javax.inject.Inject' annotation found and supported for autowiring");
/*      */     }
/*  215 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutowiredAnnotationType(Class<? extends Annotation> autowiredAnnotationType) {
/*  232 */     Assert.notNull(autowiredAnnotationType, "'autowiredAnnotationType' must not be null");
/*  233 */     this.autowiredAnnotationTypes.clear();
/*  234 */     this.autowiredAnnotationTypes.add(autowiredAnnotationType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutowiredAnnotationTypes(Set<Class<? extends Annotation>> autowiredAnnotationTypes) {
/*  248 */     Assert.notEmpty(autowiredAnnotationTypes, "'autowiredAnnotationTypes' must not be empty");
/*  249 */     this.autowiredAnnotationTypes.clear();
/*  250 */     this.autowiredAnnotationTypes.addAll(autowiredAnnotationTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequiredParameterName(String requiredParameterName) {
/*  258 */     this.requiredParameterName = requiredParameterName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequiredParameterValue(boolean requiredParameterValue) {
/*  268 */     this.requiredParameterValue = requiredParameterValue;
/*      */   }
/*      */   
/*      */   public void setOrder(int order) {
/*  272 */     this.order = order;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOrder() {
/*  277 */     return this.order;
/*      */   }
/*      */   
/*      */   public void setBeanFactory(BeanFactory beanFactory) {
/*      */     ConfigurableListableBeanFactory clbf;
/*  282 */     if (beanFactory instanceof ConfigurableListableBeanFactory) { clbf = (ConfigurableListableBeanFactory)beanFactory; }
/*  283 */     else { throw new IllegalArgumentException("AutowiredAnnotationBeanPostProcessor requires a ConfigurableListableBeanFactory: " + String.valueOf(beanFactory)); }
/*      */ 
/*      */     
/*  286 */     this.beanFactory = clbf;
/*  287 */     this.metadataReaderFactory = (MetadataReaderFactory)new SimpleMetadataReaderFactory(clbf.getBeanClassLoader());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName) {
/*  294 */     findInjectionMetadata(beanName, beanType, beanDefinition);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  299 */     if (beanDefinition.isSingleton()) {
/*  300 */       this.candidateConstructorsCache.remove(beanType);
/*      */       
/*  302 */       if (!beanDefinition.hasMethodOverrides()) {
/*  303 */         this.lookupMethodsChecked.remove(beanName);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetBeanDefinition(String beanName) {
/*  310 */     this.lookupMethodsChecked.remove(beanName);
/*  311 */     this.injectionMetadataCache.remove(beanName);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/*  317 */     Class<?> beanClass = registeredBean.getBeanClass();
/*  318 */     String beanName = registeredBean.getBeanName();
/*  319 */     RootBeanDefinition beanDefinition = registeredBean.getMergedBeanDefinition();
/*  320 */     InjectionMetadata metadata = findInjectionMetadata(beanName, beanClass, beanDefinition);
/*  321 */     Collection<AutowiredElement> autowiredElements = getAutowiredElements(metadata, (PropertyValues)beanDefinition
/*  322 */         .getPropertyValues());
/*  323 */     if (!ObjectUtils.isEmpty(autowiredElements)) {
/*  324 */       return new AotContribution(beanClass, autowiredElements, getAutowireCandidateResolver());
/*      */     }
/*  326 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Collection<AutowiredElement> getAutowiredElements(InjectionMetadata metadata, PropertyValues propertyValues) {
/*  332 */     return (Collection)metadata.getInjectedElements(propertyValues);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private AutowireCandidateResolver getAutowireCandidateResolver() {
/*  337 */     ConfigurableListableBeanFactory configurableListableBeanFactory = this.beanFactory; if (configurableListableBeanFactory instanceof DefaultListableBeanFactory) { DefaultListableBeanFactory lbf = (DefaultListableBeanFactory)configurableListableBeanFactory;
/*  338 */       return lbf.getAutowireCandidateResolver(); }
/*      */     
/*  340 */     return null;
/*      */   }
/*      */   
/*      */   private InjectionMetadata findInjectionMetadata(String beanName, Class<?> beanType, RootBeanDefinition beanDefinition) {
/*  344 */     InjectionMetadata metadata = findAutowiringMetadata(beanName, beanType, null);
/*  345 */     metadata.checkConfigMembers(beanDefinition);
/*  346 */     return metadata;
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<?> determineBeanType(Class<?> beanClass, String beanName) throws BeanCreationException {
/*  351 */     checkLookupMethods(beanClass, beanName);
/*      */ 
/*      */     
/*  354 */     ConfigurableListableBeanFactory configurableListableBeanFactory = this.beanFactory; if (configurableListableBeanFactory instanceof AbstractAutowireCapableBeanFactory) { AbstractAutowireCapableBeanFactory aacBeanFactory = (AbstractAutowireCapableBeanFactory)configurableListableBeanFactory;
/*  355 */       RootBeanDefinition mbd = (RootBeanDefinition)this.beanFactory.getMergedBeanDefinition(beanName);
/*  356 */       if (mbd.getFactoryMethodName() == null && mbd.hasBeanClass()) {
/*  357 */         return aacBeanFactory.getInstantiationStrategy().getActualBeanClass(mbd, beanName, (BeanFactory)aacBeanFactory);
/*      */       } }
/*      */     
/*  360 */     return beanClass;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Constructor<?>[] determineCandidateConstructors(Class<?> beanClass, String beanName) throws BeanCreationException {
/*      */     Constructor<?>[] arrayOfConstructor;
/*  368 */     checkLookupMethods(beanClass, beanName);
/*      */ 
/*      */     
/*  371 */     Constructor[] arrayOfConstructor1 = (Constructor[])this.candidateConstructorsCache.get(beanClass);
/*  372 */     if (arrayOfConstructor1 == null)
/*      */     {
/*  374 */       synchronized (this.candidateConstructorsCache) {
/*  375 */         arrayOfConstructor1 = (Constructor[])this.candidateConstructorsCache.get(beanClass);
/*  376 */         if (arrayOfConstructor1 == null) {
/*      */           Constructor[] arrayOfConstructor2;
/*      */           try {
/*  379 */             arrayOfConstructor2 = (Constructor[])beanClass.getDeclaredConstructors();
/*      */           }
/*  381 */           catch (Throwable ex) {
/*  382 */             throw new BeanCreationException(beanName, "Resolution of declared constructors on bean Class [" + beanClass
/*  383 */                 .getName() + "] from ClassLoader [" + 
/*  384 */                 String.valueOf(beanClass.getClassLoader()) + "] failed", ex);
/*      */           } 
/*  386 */           List<Constructor<?>> candidates = new ArrayList<>(arrayOfConstructor2.length);
/*  387 */           Constructor<?> requiredConstructor = null;
/*  388 */           Constructor<?> defaultConstructor = null;
/*  389 */           Constructor<?> primaryConstructor = BeanUtils.findPrimaryConstructor(beanClass);
/*  390 */           int nonSyntheticConstructors = 0;
/*  391 */           for (Constructor<?> candidate : arrayOfConstructor2) {
/*  392 */             if (!candidate.isSynthetic()) {
/*  393 */               nonSyntheticConstructors++;
/*      */             }
/*  395 */             else if (primaryConstructor != null) {
/*      */               continue;
/*      */             } 
/*  398 */             MergedAnnotation<?> ann = findAutowiredAnnotation(candidate);
/*  399 */             if (ann == null) {
/*  400 */               Class<?> userClass = ClassUtils.getUserClass(beanClass);
/*  401 */               if (userClass != beanClass) {
/*      */                 
/*      */                 try {
/*  404 */                   Constructor<?> superCtor = userClass.getDeclaredConstructor(candidate.getParameterTypes());
/*  405 */                   ann = findAutowiredAnnotation(superCtor);
/*      */                 }
/*  407 */                 catch (NoSuchMethodException noSuchMethodException) {}
/*      */               }
/*      */             } 
/*      */ 
/*      */             
/*  412 */             if (ann != null) {
/*  413 */               if (requiredConstructor != null) {
/*  414 */                 throw new BeanCreationException(beanName, "Invalid autowire-marked constructor: " + String.valueOf(candidate) + ". Found constructor with 'required' Autowired annotation already: " + String.valueOf(requiredConstructor));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*  419 */               boolean required = determineRequiredStatus(ann);
/*  420 */               if (required) {
/*  421 */                 if (!candidates.isEmpty()) {
/*  422 */                   throw new BeanCreationException(beanName, "Invalid autowire-marked constructors: " + String.valueOf(candidates) + ". Found constructor with 'required' Autowired annotation: " + String.valueOf(candidate));
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/*  427 */                 requiredConstructor = candidate;
/*      */               } 
/*  429 */               candidates.add(candidate);
/*      */             }
/*  431 */             else if (candidate.getParameterCount() == 0) {
/*  432 */               defaultConstructor = candidate;
/*      */             }  continue;
/*      */           } 
/*  435 */           if (!candidates.isEmpty()) {
/*      */             
/*  437 */             if (requiredConstructor == null) {
/*  438 */               if (defaultConstructor != null) {
/*  439 */                 candidates.add(defaultConstructor);
/*      */               }
/*  441 */               else if (candidates.size() == 1 && this.logger.isInfoEnabled()) {
/*  442 */                 this.logger.info("Inconsistent constructor declaration on bean with name '" + beanName + "': single autowire-marked constructor flagged as optional - this constructor is effectively required since there is no default constructor to fall back to: " + 
/*      */ 
/*      */                     
/*  445 */                     String.valueOf(candidates.get(0)));
/*      */               } 
/*      */             }
/*  448 */             arrayOfConstructor1 = candidates.<Constructor>toArray((Constructor[])EMPTY_CONSTRUCTOR_ARRAY);
/*      */           }
/*  450 */           else if (arrayOfConstructor2.length == 1 && arrayOfConstructor2[0].getParameterCount() > 0) {
/*  451 */             arrayOfConstructor1 = new Constructor[] { arrayOfConstructor2[0] };
/*      */           }
/*  453 */           else if (nonSyntheticConstructors == 2 && primaryConstructor != null && defaultConstructor != null && 
/*  454 */             !primaryConstructor.equals(defaultConstructor)) {
/*  455 */             arrayOfConstructor1 = new Constructor[] { primaryConstructor, defaultConstructor };
/*      */           }
/*  457 */           else if (nonSyntheticConstructors == 1 && primaryConstructor != null) {
/*  458 */             arrayOfConstructor1 = new Constructor[] { primaryConstructor };
/*      */           } else {
/*      */             
/*  461 */             arrayOfConstructor = EMPTY_CONSTRUCTOR_ARRAY;
/*      */           } 
/*  463 */           this.candidateConstructorsCache.put(beanClass, arrayOfConstructor);
/*      */         } 
/*      */       } 
/*      */     }
/*  467 */     return (arrayOfConstructor.length > 0) ? arrayOfConstructor : null;
/*      */   }
/*      */   
/*      */   private void checkLookupMethods(Class<?> beanClass, String beanName) throws BeanCreationException {
/*  471 */     if (!this.lookupMethodsChecked.contains(beanName)) {
/*  472 */       if (AnnotationUtils.isCandidateClass(beanClass, Lookup.class)) {
/*      */         try {
/*  474 */           Class<?> targetClass = beanClass;
/*      */           do {
/*  476 */             ReflectionUtils.doWithLocalMethods(targetClass, method -> {
/*      */                   Lookup lookup = method.<Lookup>getAnnotation(Lookup.class);
/*      */                   
/*      */                   if (lookup != null) {
/*      */                     Assert.state((this.beanFactory != null), "No BeanFactory available");
/*      */                     
/*      */                     LookupOverride override = new LookupOverride(method, lookup.value());
/*      */                     try {
/*      */                       RootBeanDefinition mbd = (RootBeanDefinition)this.beanFactory.getMergedBeanDefinition(beanName);
/*      */                       mbd.getMethodOverrides().addOverride((MethodOverride)override);
/*  486 */                     } catch (NoSuchBeanDefinitionException ex) {
/*      */                       throw new BeanCreationException(beanName, "Cannot apply @Lookup to beans without corresponding bean definition");
/*      */                     } 
/*      */                   } 
/*      */                 });
/*      */             
/*  492 */             targetClass = targetClass.getSuperclass();
/*      */           }
/*  494 */           while (targetClass != null && targetClass != Object.class);
/*      */         
/*      */         }
/*  497 */         catch (IllegalStateException ex) {
/*  498 */           throw new BeanCreationException(beanName, "Lookup method resolution failed", ex);
/*      */         } 
/*      */       }
/*  501 */       this.lookupMethodsChecked.add(beanName);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) {
/*  507 */     InjectionMetadata metadata = findAutowiringMetadata(beanName, bean.getClass(), pvs);
/*      */     try {
/*  509 */       metadata.inject(bean, beanName, pvs);
/*      */     }
/*  511 */     catch (BeanCreationException ex) {
/*  512 */       throw ex;
/*      */     }
/*  514 */     catch (Throwable ex) {
/*  515 */       throw new BeanCreationException(beanName, "Injection of autowired dependencies failed", ex);
/*      */     } 
/*  517 */     return pvs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void processInjection(Object bean) throws BeanCreationException {
/*  529 */     Class<?> clazz = bean.getClass();
/*  530 */     InjectionMetadata metadata = findAutowiringMetadata(clazz.getName(), clazz, null);
/*      */     try {
/*  532 */       metadata.inject(bean, null, null);
/*      */     }
/*  534 */     catch (BeanCreationException ex) {
/*  535 */       throw ex;
/*      */     }
/*  537 */     catch (Throwable ex) {
/*  538 */       throw new BeanCreationException("Injection of autowired dependencies failed for class [" + String.valueOf(clazz) + "]", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private InjectionMetadata findAutowiringMetadata(String beanName, Class<?> clazz, @Nullable PropertyValues pvs) {
/*  545 */     String cacheKey = StringUtils.hasLength(beanName) ? beanName : clazz.getName();
/*      */     
/*  547 */     InjectionMetadata metadata = this.injectionMetadataCache.get(cacheKey);
/*  548 */     if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/*  549 */       synchronized (this.injectionMetadataCache) {
/*  550 */         metadata = this.injectionMetadataCache.get(cacheKey);
/*  551 */         if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/*  552 */           if (metadata != null) {
/*  553 */             metadata.clear(pvs);
/*      */           }
/*  555 */           metadata = buildAutowiringMetadata(clazz);
/*  556 */           this.injectionMetadataCache.put(cacheKey, metadata);
/*      */         } 
/*      */       } 
/*      */     }
/*  560 */     return metadata;
/*      */   }
/*      */   
/*      */   private InjectionMetadata buildAutowiringMetadata(Class<?> clazz) {
/*  564 */     if (!AnnotationUtils.isCandidateClass(clazz, this.autowiredAnnotationTypes)) {
/*  565 */       return InjectionMetadata.EMPTY;
/*      */     }
/*      */     
/*  568 */     List<InjectionMetadata.InjectedElement> elements = new ArrayList<>();
/*  569 */     Class<?> targetClass = clazz;
/*      */     
/*      */     do {
/*  572 */       List<InjectionMetadata.InjectedElement> fieldElements = new ArrayList<>();
/*  573 */       ReflectionUtils.doWithLocalFields(targetClass, field -> {
/*      */             MergedAnnotation<?> ann = findAutowiredAnnotation(field);
/*      */             
/*      */             if (ann != null) {
/*      */               if (Modifier.isStatic(field.getModifiers())) {
/*      */                 if (this.logger.isInfoEnabled()) {
/*      */                   this.logger.info("Autowired annotation is not supported on static fields: " + String.valueOf(field));
/*      */                 }
/*      */                 return;
/*      */               } 
/*      */               boolean required = determineRequiredStatus(ann);
/*      */               fieldElements.add(new AutowiredFieldElement(field, required));
/*      */             } 
/*      */           });
/*  587 */       List<InjectionMetadata.InjectedElement> methodElements = new ArrayList<>();
/*  588 */       ReflectionUtils.doWithLocalMethods(targetClass, method -> {
/*      */             Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*      */             
/*      */             if (!BridgeMethodResolver.isVisibilityBridgeMethodPair(method, bridgedMethod)) {
/*      */               return;
/*      */             }
/*      */             
/*      */             MergedAnnotation<?> ann = findAutowiredAnnotation(bridgedMethod);
/*      */             
/*      */             if (ann != null && method.equals(ClassUtils.getMostSpecificMethod(method, clazz))) {
/*      */               if (Modifier.isStatic(method.getModifiers())) {
/*      */                 if (this.logger.isInfoEnabled()) {
/*      */                   this.logger.info("Autowired annotation is not supported on static methods: " + String.valueOf(method));
/*      */                 }
/*      */                 return;
/*      */               } 
/*      */               if (method.getParameterCount() == 0) {
/*      */                 if (method.getDeclaringClass().isRecord()) {
/*      */                   return;
/*      */                 }
/*      */                 if (this.logger.isInfoEnabled()) {
/*      */                   this.logger.info("Autowired annotation should only be used on methods with parameters: " + String.valueOf(method));
/*      */                 }
/*      */               } 
/*      */               boolean required = determineRequiredStatus(ann);
/*      */               PropertyDescriptor pd = BeanUtils.findPropertyForMethod(bridgedMethod, clazz);
/*      */               methodElements.add(new AutowiredMethodElement(method, required, pd));
/*      */             } 
/*      */           });
/*  617 */       elements.addAll(0, sortMethodElements(methodElements, targetClass));
/*  618 */       elements.addAll(0, fieldElements);
/*  619 */       targetClass = targetClass.getSuperclass();
/*      */     }
/*  621 */     while (targetClass != null && targetClass != Object.class);
/*      */     
/*  623 */     return InjectionMetadata.forElements(elements, clazz);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private MergedAnnotation<?> findAutowiredAnnotation(AccessibleObject ao) {
/*  628 */     MergedAnnotations annotations = MergedAnnotations.from(ao);
/*  629 */     for (Class<? extends Annotation> type : this.autowiredAnnotationTypes) {
/*  630 */       MergedAnnotation<?> annotation = annotations.get(type);
/*  631 */       if (annotation.isPresent()) {
/*  632 */         return annotation;
/*      */       }
/*      */     } 
/*  635 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean determineRequiredStatus(MergedAnnotation<?> ann) {
/*  647 */     return (ann.getValue(this.requiredParameterName).isEmpty() || this.requiredParameterValue == ann
/*  648 */       .getBoolean(this.requiredParameterName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<InjectionMetadata.InjectedElement> sortMethodElements(List<InjectionMetadata.InjectedElement> methodElements, Class<?> targetClass) {
/*  657 */     if (this.metadataReaderFactory != null && methodElements.size() > 1) {
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */         
/*  663 */         AnnotationMetadata asm = this.metadataReaderFactory.getMetadataReader(targetClass.getName()).getAnnotationMetadata();
/*  664 */         Set<MethodMetadata> asmMethods = asm.getAnnotatedMethods(Autowired.class.getName());
/*  665 */         if (asmMethods.size() >= methodElements.size()) {
/*  666 */           List<InjectionMetadata.InjectedElement> candidateMethods = new ArrayList<>(methodElements);
/*  667 */           List<InjectionMetadata.InjectedElement> selectedMethods = new ArrayList<>(asmMethods.size());
/*  668 */           for (MethodMetadata asmMethod : asmMethods) {
/*  669 */             Iterator<InjectionMetadata.InjectedElement> it; for (it = candidateMethods.iterator(); it.hasNext(); ) {
/*  670 */               InjectionMetadata.InjectedElement element = it.next();
/*  671 */               if (element.getMember().getName().equals(asmMethod.getMethodName())) {
/*  672 */                 selectedMethods.add(element);
/*  673 */                 it.remove();
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  678 */           if (selectedMethods.size() == methodElements.size())
/*      */           {
/*  680 */             return selectedMethods;
/*      */           }
/*      */         }
/*      */       
/*  684 */       } catch (IOException ex) {
/*  685 */         this.logger.debug("Failed to read class file via ASM for determining @Autowired method order", ex);
/*      */       } 
/*      */     }
/*      */     
/*  689 */     return methodElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerDependentBeans(@Nullable String beanName, Set<String> autowiredBeanNames) {
/*  696 */     if (beanName != null) {
/*  697 */       for (String autowiredBeanName : autowiredBeanNames) {
/*  698 */         if (this.beanFactory != null && this.beanFactory.containsBean(autowiredBeanName)) {
/*  699 */           this.beanFactory.registerDependentBean(autowiredBeanName, beanName);
/*      */         }
/*  701 */         if (this.logger.isTraceEnabled()) {
/*  702 */           this.logger.trace("Autowiring by type from bean name '" + beanName + "' to bean named '" + autowiredBeanName + "'");
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Object resolveCachedArgument(@Nullable String beanName, @Nullable Object cachedArgument) {
/*  714 */     if (cachedArgument instanceof DependencyDescriptor) { DependencyDescriptor descriptor = (DependencyDescriptor)cachedArgument;
/*  715 */       Assert.state((this.beanFactory != null), "No BeanFactory available");
/*  716 */       return this.beanFactory.resolveDependency(descriptor, beanName, null, null); }
/*      */ 
/*      */     
/*  719 */     return cachedArgument;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static abstract class AutowiredElement
/*      */     extends InjectionMetadata.InjectedElement
/*      */   {
/*      */     protected final boolean required;
/*      */ 
/*      */ 
/*      */     
/*      */     protected AutowiredElement(Member member, @Nullable PropertyDescriptor pd, boolean required) {
/*  732 */       super(member, pd);
/*  733 */       this.required = required;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class AutowiredFieldElement
/*      */     extends AutowiredElement
/*      */   {
/*      */     private volatile boolean cached;
/*      */     
/*      */     @Nullable
/*      */     private volatile Object cachedFieldValue;
/*      */ 
/*      */     
/*      */     public AutowiredFieldElement(Field field, boolean required) {
/*  749 */       super(field, (PropertyDescriptor)null, required);
/*      */     }
/*      */     
/*      */     protected void inject(Object bean, @Nullable String beanName, @Nullable PropertyValues pvs) throws Throwable {
/*      */       Object value;
/*  754 */       Field field = (Field)this.member;
/*      */       
/*  756 */       if (this.cached) {
/*      */         try {
/*  758 */           value = AutowiredAnnotationBeanPostProcessor.this.resolveCachedArgument(beanName, this.cachedFieldValue);
/*      */         }
/*  760 */         catch (BeansException ex) {
/*      */           
/*  762 */           this.cached = false;
/*  763 */           AutowiredAnnotationBeanPostProcessor.this.logger.debug("Failed to resolve cached argument", (Throwable)ex);
/*  764 */           value = resolveFieldValue(field, bean, beanName);
/*      */         } 
/*      */       } else {
/*      */         
/*  768 */         value = resolveFieldValue(field, bean, beanName);
/*      */       } 
/*  770 */       if (value != null) {
/*  771 */         ReflectionUtils.makeAccessible(field);
/*  772 */         field.set(bean, value);
/*      */       } 
/*      */     }
/*      */     @Nullable
/*      */     private Object resolveFieldValue(Field field, Object bean, @Nullable String beanName) {
/*      */       Object value;
/*  778 */       DependencyDescriptor desc = new DependencyDescriptor(field, this.required);
/*  779 */       desc.setContainingClass(bean.getClass());
/*  780 */       Set<String> autowiredBeanNames = new LinkedHashSet<>(2);
/*  781 */       Assert.state((AutowiredAnnotationBeanPostProcessor.this.beanFactory != null), "No BeanFactory available");
/*  782 */       TypeConverter typeConverter = AutowiredAnnotationBeanPostProcessor.this.beanFactory.getTypeConverter();
/*      */       
/*      */       try {
/*  785 */         value = AutowiredAnnotationBeanPostProcessor.this.beanFactory.resolveDependency(desc, beanName, autowiredBeanNames, typeConverter);
/*      */       }
/*  787 */       catch (BeansException ex) {
/*  788 */         throw new UnsatisfiedDependencyException(null, beanName, new InjectionPoint(field), ex);
/*      */       } 
/*  790 */       synchronized (this) {
/*  791 */         if (!this.cached) {
/*  792 */           if (value != null || this.required) {
/*  793 */             Object cachedFieldValue = desc;
/*  794 */             AutowiredAnnotationBeanPostProcessor.this.registerDependentBeans(beanName, autowiredBeanNames);
/*  795 */             if (value != null && autowiredBeanNames.size() == 1) {
/*  796 */               String autowiredBeanName = autowiredBeanNames.iterator().next();
/*  797 */               if (AutowiredAnnotationBeanPostProcessor.this.beanFactory.containsBean(autowiredBeanName) && AutowiredAnnotationBeanPostProcessor.this.beanFactory
/*  798 */                 .isTypeMatch(autowiredBeanName, field.getType())) {
/*  799 */                 cachedFieldValue = new AutowiredAnnotationBeanPostProcessor.ShortcutDependencyDescriptor(desc, autowiredBeanName);
/*      */               }
/*      */             } 
/*  802 */             this.cachedFieldValue = cachedFieldValue;
/*  803 */             this.cached = true;
/*      */           } else {
/*      */             
/*  806 */             this.cachedFieldValue = null;
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/*  811 */       return value;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class AutowiredMethodElement
/*      */     extends AutowiredElement
/*      */   {
/*      */     private volatile boolean cached;
/*      */     
/*      */     @Nullable
/*      */     private volatile Object[] cachedMethodArguments;
/*      */ 
/*      */     
/*      */     public AutowiredMethodElement(Method method, @Nullable boolean required, PropertyDescriptor pd) {
/*  827 */       super(method, pd, required);
/*      */     }
/*      */     
/*      */     protected void inject(Object bean, @Nullable String beanName, @Nullable PropertyValues pvs) throws Throwable {
/*      */       Object[] arguments;
/*  832 */       if (!shouldInject(pvs)) {
/*      */         return;
/*      */       }
/*  835 */       Method method = (Method)this.member;
/*      */       
/*  837 */       if (this.cached) {
/*      */         try {
/*  839 */           arguments = resolveCachedArguments(beanName, this.cachedMethodArguments);
/*      */         }
/*  841 */         catch (BeansException ex) {
/*      */           
/*  843 */           this.cached = false;
/*  844 */           AutowiredAnnotationBeanPostProcessor.this.logger.debug("Failed to resolve cached argument", (Throwable)ex);
/*  845 */           arguments = resolveMethodArguments(method, bean, beanName);
/*      */         } 
/*      */       } else {
/*      */         
/*  849 */         arguments = resolveMethodArguments(method, bean, beanName);
/*      */       } 
/*  851 */       if (arguments != null) {
/*      */         try {
/*  853 */           ReflectionUtils.makeAccessible(method);
/*  854 */           method.invoke(bean, arguments);
/*      */         }
/*  856 */         catch (InvocationTargetException ex) {
/*  857 */           throw ex.getTargetException();
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     private Object[] resolveCachedArguments(@Nullable String beanName, @Nullable Object[] cachedMethodArguments) {
/*  864 */       if (cachedMethodArguments == null) {
/*  865 */         return null;
/*      */       }
/*  867 */       Object[] arguments = new Object[cachedMethodArguments.length];
/*  868 */       for (int i = 0; i < arguments.length; i++) {
/*  869 */         arguments[i] = AutowiredAnnotationBeanPostProcessor.this.resolveCachedArgument(beanName, cachedMethodArguments[i]);
/*      */       }
/*  871 */       return arguments;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     private Object[] resolveMethodArguments(Method method, Object bean, @Nullable String beanName) {
/*  876 */       int argumentCount = method.getParameterCount();
/*  877 */       Object[] arguments = new Object[argumentCount];
/*  878 */       DependencyDescriptor[] descriptors = new DependencyDescriptor[argumentCount];
/*  879 */       Set<String> autowiredBeanNames = CollectionUtils.newLinkedHashSet(argumentCount);
/*  880 */       Assert.state((AutowiredAnnotationBeanPostProcessor.this.beanFactory != null), "No BeanFactory available");
/*  881 */       TypeConverter typeConverter = AutowiredAnnotationBeanPostProcessor.this.beanFactory.getTypeConverter();
/*  882 */       for (int i = 0; i < arguments.length; i++) {
/*  883 */         MethodParameter methodParam = new MethodParameter(method, i);
/*  884 */         DependencyDescriptor currDesc = new DependencyDescriptor(methodParam, this.required);
/*  885 */         currDesc.setContainingClass(bean.getClass());
/*  886 */         descriptors[i] = currDesc;
/*      */         try {
/*  888 */           Object arg = AutowiredAnnotationBeanPostProcessor.this.beanFactory.resolveDependency(currDesc, beanName, autowiredBeanNames, typeConverter);
/*  889 */           if (arg == null && !this.required && !methodParam.isOptional()) {
/*  890 */             arguments = null;
/*      */             break;
/*      */           } 
/*  893 */           arguments[i] = arg;
/*      */         }
/*  895 */         catch (BeansException ex) {
/*  896 */           throw new UnsatisfiedDependencyException(null, beanName, new InjectionPoint(methodParam), ex);
/*      */         } 
/*      */       } 
/*  899 */       synchronized (this) {
/*  900 */         if (!this.cached) {
/*  901 */           if (arguments != null) {
/*  902 */             DependencyDescriptor[] cachedMethodArguments = Arrays.<DependencyDescriptor>copyOf(descriptors, argumentCount);
/*  903 */             AutowiredAnnotationBeanPostProcessor.this.registerDependentBeans(beanName, autowiredBeanNames);
/*  904 */             if (autowiredBeanNames.size() == argumentCount) {
/*  905 */               Iterator<String> it = autowiredBeanNames.iterator();
/*  906 */               Class<?>[] paramTypes = method.getParameterTypes();
/*  907 */               for (int j = 0; j < paramTypes.length; j++) {
/*  908 */                 String autowiredBeanName = it.next();
/*  909 */                 if (arguments[j] != null && AutowiredAnnotationBeanPostProcessor.this.beanFactory.containsBean(autowiredBeanName) && AutowiredAnnotationBeanPostProcessor.this.beanFactory
/*  910 */                   .isTypeMatch(autowiredBeanName, paramTypes[j])) {
/*  911 */                   cachedMethodArguments[j] = new AutowiredAnnotationBeanPostProcessor.ShortcutDependencyDescriptor(descriptors[j], autowiredBeanName);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/*  916 */             this.cachedMethodArguments = (Object[])cachedMethodArguments;
/*  917 */             this.cached = true;
/*      */           } else {
/*      */             
/*  920 */             this.cachedMethodArguments = null;
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/*  925 */       return arguments;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ShortcutDependencyDescriptor
/*      */     extends DependencyDescriptor
/*      */   {
/*      */     private final String shortcut;
/*      */ 
/*      */ 
/*      */     
/*      */     public ShortcutDependencyDescriptor(DependencyDescriptor original, String shortcut) {
/*  939 */       super(original);
/*  940 */       this.shortcut = shortcut;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object resolveShortcut(BeanFactory beanFactory) {
/*  945 */       return beanFactory.getBean(this.shortcut, getDependencyType());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class AotContribution
/*      */     implements BeanRegistrationAotContribution
/*      */   {
/*      */     private static final String REGISTERED_BEAN_PARAMETER = "registeredBean";
/*      */ 
/*      */     
/*      */     private static final String INSTANCE_PARAMETER = "instance";
/*      */ 
/*      */     
/*      */     private final Class<?> target;
/*      */     
/*      */     private final Collection<AutowiredAnnotationBeanPostProcessor.AutowiredElement> autowiredElements;
/*      */     
/*      */     @Nullable
/*      */     private final AutowireCandidateResolver candidateResolver;
/*      */ 
/*      */     
/*      */     AotContribution(Class<?> target, Collection<AutowiredAnnotationBeanPostProcessor.AutowiredElement> autowiredElements, @Nullable AutowireCandidateResolver candidateResolver) {
/*  969 */       this.target = target;
/*  970 */       this.autowiredElements = autowiredElements;
/*  971 */       this.candidateResolver = candidateResolver;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/*  977 */       GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeatureComponent("Autowiring", this.target, type -> {
/*      */             type.addJavadoc("Autowiring for {@link $T}.", new Object[] { this.target });
/*      */             type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*      */           });
/*  981 */       GeneratedMethod generateMethod = generatedClass.getMethods().add("apply", method -> {
/*      */             method.addJavadoc("Apply the autowiring.", new Object[0]);
/*      */             
/*      */             method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*      */             
/*      */             method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*      */             method.addParameter(this.target, "instance", new Modifier[0]);
/*      */             method.returns(this.target);
/*      */             CodeWarnings codeWarnings = new CodeWarnings();
/*      */             codeWarnings.detectDeprecation(new AnnotatedElement[] { this.target });
/*      */             method.addCode(generateMethodCode(codeWarnings, generatedClass.getName(), generationContext.getRuntimeHints()));
/*      */             codeWarnings.suppress(method);
/*      */           });
/*  994 */       beanRegistrationCode.addInstancePostProcessor(generateMethod.toMethodReference());
/*      */       
/*  996 */       if (this.candidateResolver != null) {
/*  997 */         registerHints(generationContext.getRuntimeHints());
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private CodeBlock generateMethodCode(CodeWarnings codeWarnings, ClassName targetClassName, RuntimeHints hints) {
/* 1004 */       CodeBlock.Builder code = CodeBlock.builder();
/* 1005 */       for (AutowiredAnnotationBeanPostProcessor.AutowiredElement autowiredElement : this.autowiredElements) {
/* 1006 */         code.addStatement(generateMethodStatementForElement(codeWarnings, targetClassName, autowiredElement, hints));
/*      */       }
/*      */       
/* 1009 */       code.addStatement("return $L", new Object[] { "instance" });
/* 1010 */       return code.build();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private CodeBlock generateMethodStatementForElement(CodeWarnings codeWarnings, ClassName targetClassName, AutowiredAnnotationBeanPostProcessor.AutowiredElement autowiredElement, RuntimeHints hints) {
/* 1016 */       Member member = autowiredElement.getMember();
/* 1017 */       boolean required = autowiredElement.required;
/* 1018 */       if (member instanceof Field) { Field field = (Field)member;
/* 1019 */         return generateMethodStatementForField(codeWarnings, targetClassName, field, required, hints); }
/*      */ 
/*      */       
/* 1022 */       if (member instanceof Method) { Method method = (Method)member;
/* 1023 */         return generateMethodStatementForMethod(codeWarnings, targetClassName, method, required, hints); }
/*      */ 
/*      */       
/* 1026 */       throw new IllegalStateException("Unsupported member type " + member
/* 1027 */           .getClass().getName());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private CodeBlock generateMethodStatementForField(CodeWarnings codeWarnings, ClassName targetClassName, Field field, boolean required, RuntimeHints hints) {
/* 1033 */       hints.reflection().registerField(field);
/* 1034 */       CodeBlock resolver = CodeBlock.of("$T.$L($S)", new Object[] { AutowiredFieldValueResolver.class, 
/*      */             
/* 1036 */             !required ? "forField" : "forRequiredField", field.getName() });
/* 1037 */       AccessControl accessControl = AccessControl.forMember(field);
/* 1038 */       if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 1039 */         return CodeBlock.of("$L.resolveAndSet($L, $L)", new Object[] { resolver, "registeredBean", "instance" });
/*      */       }
/*      */ 
/*      */       
/* 1043 */       codeWarnings.detectDeprecation(new AnnotatedElement[] { field });
/* 1044 */       return CodeBlock.of("$L.$L = $L.resolve($L)", new Object[] { "instance", field
/* 1045 */             .getName(), resolver, "registeredBean" });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private CodeBlock generateMethodStatementForMethod(CodeWarnings codeWarnings, ClassName targetClassName, Method method, boolean required, RuntimeHints hints) {
/* 1052 */       CodeBlock.Builder code = CodeBlock.builder();
/* 1053 */       code.add("$T.$L", new Object[] { AutowiredMethodArgumentsResolver.class, 
/* 1054 */             !required ? "forMethod" : "forRequiredMethod" });
/* 1055 */       code.add("($S", new Object[] { method.getName() });
/* 1056 */       if (method.getParameterCount() > 0) {
/* 1057 */         codeWarnings.detectDeprecation((AnnotatedElement[])method.getParameterTypes());
/* 1058 */         code.add(", $L", new Object[] { generateParameterTypesCode(method.getParameterTypes()) });
/*      */       } 
/* 1060 */       code.add(")", new Object[0]);
/* 1061 */       AccessControl accessControl = AccessControl.forMember(method);
/* 1062 */       if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 1063 */         hints.reflection().registerMethod(method, ExecutableMode.INVOKE);
/* 1064 */         code.add(".resolveAndInvoke($L, $L)", new Object[] { "registeredBean", "instance" });
/*      */       } else {
/*      */         
/* 1067 */         codeWarnings.detectDeprecation(new AnnotatedElement[] { method });
/* 1068 */         hints.reflection().registerMethod(method, ExecutableMode.INTROSPECT);
/*      */         
/* 1070 */         CodeBlock arguments = (new AutowiredArgumentsCodeGenerator(this.target, method)).generateCode(method.getParameterTypes());
/* 1071 */         CodeBlock injectionCode = CodeBlock.of("args -> $L.$L($L)", new Object[] { "instance", method
/* 1072 */               .getName(), arguments });
/* 1073 */         code.add(".resolve($L, $L)", new Object[] { "registeredBean", injectionCode });
/*      */       } 
/* 1075 */       return code.build();
/*      */     }
/*      */     
/*      */     private CodeBlock generateParameterTypesCode(Class<?>[] parameterTypes) {
/* 1079 */       return CodeBlock.join(Arrays.<Class<?>>stream(parameterTypes)
/* 1080 */           .map(parameterType -> CodeBlock.of("$T.class", new Object[] { parameterType
/* 1081 */               })).toList(), ", ");
/*      */     }
/*      */     
/*      */     private void registerHints(RuntimeHints runtimeHints) {
/* 1085 */       this.autowiredElements.forEach(autowiredElement -> {
/*      */             boolean required = autowiredElement.required;
/*      */             Member member = autowiredElement.getMember();
/*      */             if (member instanceof Field) {
/*      */               Field field = (Field)member;
/*      */               DependencyDescriptor dependencyDescriptor = new DependencyDescriptor(field, required);
/*      */               registerProxyIfNecessary(runtimeHints, dependencyDescriptor);
/*      */             } 
/*      */             if (member instanceof Method) {
/*      */               Method method = (Method)member;
/*      */               Class<?>[] parameterTypes = method.getParameterTypes();
/*      */               for (int i = 0; i < parameterTypes.length; i++) {
/*      */                 MethodParameter methodParam = new MethodParameter(method, i);
/*      */                 DependencyDescriptor dependencyDescriptor = new DependencyDescriptor(methodParam, required);
/*      */                 registerProxyIfNecessary(runtimeHints, dependencyDescriptor);
/*      */               } 
/*      */             } 
/*      */           });
/*      */     } private void registerProxyIfNecessary(RuntimeHints runtimeHints, DependencyDescriptor dependencyDescriptor) {
/* 1104 */       if (this.candidateResolver != null) {
/*      */         
/* 1106 */         Class<?> proxyClass = this.candidateResolver.getLazyResolutionProxyClass(dependencyDescriptor, null);
/* 1107 */         if (proxyClass != null)
/* 1108 */           ClassHintUtils.registerProxyIfNecessary(proxyClass, runtimeHints); 
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\AutowiredAnnotationBeanPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */