/*    */ package org.springframework.beans.factory.annotation;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JakartaAnnotationsRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 38 */     Stream.<String>of(new String[] { "jakarta.inject.Inject", "jakarta.inject.Provider", "jakarta.inject.Qualifier", "javax.inject.Inject", "javax.inject.Qualifier"
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 44 */         }).forEach(typeName -> hints.reflection().registerType(TypeReference.of(typeName), new org.springframework.aot.hint.MemberCategory[0]));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\JakartaAnnotationsRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */