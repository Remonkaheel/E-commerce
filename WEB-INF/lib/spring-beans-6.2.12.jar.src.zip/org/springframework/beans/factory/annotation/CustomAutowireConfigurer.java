/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomAutowireConfigurer
/*     */   implements BeanFactoryPostProcessor, BeanClassLoaderAware, Ordered
/*     */ {
/*  52 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */   @Nullable
/*     */   private Set<?> customQualifierTypes;
/*     */   
/*     */   @Nullable
/*  58 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */   
/*     */   public void setOrder(int order) {
/*  62 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  67 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(@Nullable ClassLoader beanClassLoader) {
/*  72 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomQualifierTypes(Set<?> customQualifierTypes) {
/*  86 */     this.customQualifierTypes = customQualifierTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/*  93 */     if (this.customQualifierTypes != null) {
/*  94 */       DefaultListableBeanFactory dlbf; if (beanFactory instanceof DefaultListableBeanFactory) { dlbf = (DefaultListableBeanFactory)beanFactory; }
/*  95 */       else { throw new IllegalStateException("CustomAutowireConfigurer needs to operate on a DefaultListableBeanFactory"); }
/*     */ 
/*     */       
/*  98 */       if (!(dlbf.getAutowireCandidateResolver() instanceof QualifierAnnotationAutowireCandidateResolver)) {
/*  99 */         dlbf.setAutowireCandidateResolver((AutowireCandidateResolver)new QualifierAnnotationAutowireCandidateResolver());
/*     */       }
/*     */       
/* 102 */       QualifierAnnotationAutowireCandidateResolver resolver = (QualifierAnnotationAutowireCandidateResolver)dlbf.getAutowireCandidateResolver();
/* 103 */       for (Object value : this.customQualifierTypes) {
/* 104 */         Class<? extends Annotation> customType = null;
/* 105 */         if (value instanceof Class)
/* 106 */         { customType = (Class<? extends Annotation>)value; }
/*     */         
/* 108 */         else if (value instanceof String) { String className = (String)value;
/* 109 */           customType = ClassUtils.resolveClassName(className, this.beanClassLoader); }
/*     */         else
/*     */         
/* 112 */         { throw new IllegalArgumentException("Invalid value [" + String.valueOf(value) + "] for custom qualifier type: needs to be Class or String."); }
/*     */ 
/*     */         
/* 115 */         if (!Annotation.class.isAssignableFrom(customType)) {
/* 116 */           throw new IllegalArgumentException("Qualifier type [" + customType
/* 117 */               .getName() + "] needs to be annotation type");
/*     */         }
/* 119 */         resolver.addQualifierType(customType);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\CustomAutowireConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */