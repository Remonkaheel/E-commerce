/*    */ package org.springframework.beans.factory.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.PropertyValues;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends InjectionMetadata
/*    */ {
/*    */   null(Class<?> targetClass, Collection<InjectionMetadata.InjectedElement> elements) {
/* 54 */     super(targetClass, elements);
/*    */   }
/*    */   protected boolean needsRefresh(Class<?> clazz) {
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public void checkConfigMembers(RootBeanDefinition beanDefinition) {}
/*    */   
/*    */   public void inject(Object target, @Nullable String beanName, @Nullable PropertyValues pvs) {}
/*    */   
/*    */   public void clear(@Nullable PropertyValues pvs) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\InjectionMetadata$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */