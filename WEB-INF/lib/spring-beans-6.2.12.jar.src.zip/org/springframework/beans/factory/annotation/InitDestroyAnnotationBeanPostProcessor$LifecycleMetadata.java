/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LifecycleMetadata
/*     */ {
/*     */   private final Class<?> beanClass;
/*     */   private final Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethods;
/*     */   private final Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethods;
/*     */   @Nullable
/*     */   private volatile Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedInitMethods;
/*     */   @Nullable
/*     */   private volatile Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods;
/*     */   
/*     */   public LifecycleMetadata(Class<?> beanClass, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethods, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethods) {
/* 360 */     this.beanClass = beanClass;
/* 361 */     this.initMethods = initMethods;
/* 362 */     this.destroyMethods = destroyMethods;
/*     */   }
/*     */   
/*     */   public void checkInitDestroyMethods(RootBeanDefinition beanDefinition) {
/* 366 */     Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedInitMethods = CollectionUtils.newLinkedHashSet(this.initMethods.size());
/* 367 */     for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : this.initMethods) {
/* 368 */       String methodIdentifier = lifecycleMethod.getIdentifier();
/* 369 */       if (!beanDefinition.isExternallyManagedInitMethod(methodIdentifier)) {
/* 370 */         beanDefinition.registerExternallyManagedInitMethod(methodIdentifier);
/* 371 */         checkedInitMethods.add(lifecycleMethod);
/* 372 */         if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 373 */           InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Registered init method on class [" + this.beanClass.getName() + "]: " + methodIdentifier);
/*     */         }
/*     */       } 
/*     */     } 
/* 377 */     Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods = CollectionUtils.newLinkedHashSet(this.destroyMethods.size());
/* 378 */     for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : this.destroyMethods) {
/* 379 */       String methodIdentifier = lifecycleMethod.getIdentifier();
/* 380 */       if (!beanDefinition.isExternallyManagedDestroyMethod(methodIdentifier)) {
/* 381 */         beanDefinition.registerExternallyManagedDestroyMethod(methodIdentifier);
/* 382 */         checkedDestroyMethods.add(lifecycleMethod);
/* 383 */         if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 384 */           InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Registered destroy method on class [" + this.beanClass.getName() + "]: " + methodIdentifier);
/*     */         }
/*     */       } 
/*     */     } 
/* 388 */     this.checkedInitMethods = checkedInitMethods;
/* 389 */     this.checkedDestroyMethods = checkedDestroyMethods;
/*     */   }
/*     */   
/*     */   public void invokeInitMethods(Object target, String beanName) throws Throwable {
/* 393 */     Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedInitMethods = this.checkedInitMethods;
/*     */     
/* 395 */     Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethodsToIterate = (checkedInitMethods != null) ? checkedInitMethods : this.initMethods;
/* 396 */     if (!initMethodsToIterate.isEmpty()) {
/* 397 */       for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : initMethodsToIterate) {
/* 398 */         if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 399 */           InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Invoking init method on bean '" + beanName + "': " + String.valueOf(lifecycleMethod.getMethod()));
/*     */         }
/* 401 */         lifecycleMethod.invoke(target);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void invokeDestroyMethods(Object target, String beanName) throws Throwable {
/* 407 */     Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods = this.checkedDestroyMethods;
/*     */     
/* 409 */     Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethodsToUse = (checkedDestroyMethods != null) ? checkedDestroyMethods : this.destroyMethods;
/* 410 */     if (!destroyMethodsToUse.isEmpty()) {
/* 411 */       for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : destroyMethodsToUse) {
/* 412 */         if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 413 */           InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Invoking destroy method on bean '" + beanName + "': " + String.valueOf(lifecycleMethod.getMethod()));
/*     */         }
/* 415 */         lifecycleMethod.invoke(target);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasDestroyMethods() {
/* 421 */     Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods = this.checkedDestroyMethods;
/*     */     
/* 423 */     Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethodsToUse = (checkedDestroyMethods != null) ? checkedDestroyMethods : this.destroyMethods;
/* 424 */     return !destroyMethodsToUse.isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\InitDestroyAnnotationBeanPostProcessor$LifecycleMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */