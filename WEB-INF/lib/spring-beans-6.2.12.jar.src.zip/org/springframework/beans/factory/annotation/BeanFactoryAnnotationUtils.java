/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BeanFactoryAnnotationUtils
/*     */ {
/*     */   public static <T> Map<String, T> qualifiedBeansOfType(ListableBeanFactory beanFactory, Class<T> beanType, String qualifier) throws BeansException {
/*  66 */     String[] candidateBeans = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, beanType);
/*  67 */     Map<String, T> result = new LinkedHashMap<>(4);
/*  68 */     for (String beanName : candidateBeans) {
/*  69 */       Objects.requireNonNull(qualifier); if (isQualifierMatch(qualifier::equals, beanName, (BeanFactory)beanFactory)) {
/*  70 */         result.put(beanName, (T)beanFactory.getBean(beanName, beanType));
/*     */       }
/*     */     } 
/*  73 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T qualifiedBeanOfType(BeanFactory beanFactory, Class<T> beanType, String qualifier) throws BeansException {
/*  92 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*     */     
/*  94 */     if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory lbf = (ListableBeanFactory)beanFactory;
/*     */       
/*  96 */       return qualifiedBeanOfType(lbf, beanType, qualifier); }
/*     */     
/*  98 */     if (beanFactory.containsBean(qualifier) && beanFactory.isTypeMatch(qualifier, beanType))
/*     */     {
/* 100 */       return (T)beanFactory.getBean(qualifier, beanType);
/*     */     }
/*     */     
/* 103 */     throw new NoSuchBeanDefinitionException(qualifier, "No matching " + beanType.getSimpleName() + " bean found for bean name '" + qualifier + "'! (Note: Qualifier matching not supported because given BeanFactory does not implement ConfigurableListableBeanFactory.)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> T qualifiedBeanOfType(ListableBeanFactory beanFactory, Class<T> beanType, String qualifier) {
/* 119 */     String[] candidateBeans = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, beanType);
/* 120 */     String matchingBean = null;
/* 121 */     for (String beanName : candidateBeans) {
/* 122 */       Objects.requireNonNull(qualifier); if (isQualifierMatch(qualifier::equals, beanName, (BeanFactory)beanFactory)) {
/* 123 */         if (matchingBean != null) {
/* 124 */           throw new NoUniqueBeanDefinitionException(beanType, new String[] { matchingBean, beanName });
/*     */         }
/* 126 */         matchingBean = beanName;
/*     */       } 
/*     */     } 
/* 129 */     if (matchingBean != null) {
/* 130 */       return (T)beanFactory.getBean(matchingBean, beanType);
/*     */     }
/* 132 */     if (beanFactory.containsBean(qualifier) && beanFactory.isTypeMatch(qualifier, beanType))
/*     */     {
/* 134 */       return (T)beanFactory.getBean(qualifier, beanType);
/*     */     }
/*     */     
/* 137 */     throw new NoSuchBeanDefinitionException(qualifier, "No matching " + beanType.getSimpleName() + " bean found for qualifier '" + qualifier + "' - neither qualifier match nor bean name match!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String getQualifierValue(AnnotatedElement annotatedElement) {
/* 151 */     Qualifier qualifier = (Qualifier)AnnotationUtils.getAnnotation(annotatedElement, Qualifier.class);
/* 152 */     return (qualifier != null) ? qualifier.value() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isQualifierMatch(Predicate<String> qualifier, String beanName, @Nullable BeanFactory beanFactory) {
/* 169 */     if (qualifier.test(beanName)) {
/* 170 */       return true;
/*     */     }
/* 172 */     if (beanFactory != null) {
/* 173 */       for (String alias : beanFactory.getAliases(beanName)) {
/* 174 */         if (qualifier.test(alias)) {
/* 175 */           return true;
/*     */         }
/*     */       } 
/*     */       try {
/* 179 */         Class<?> beanType = beanFactory.getType(beanName);
/* 180 */         if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/* 181 */           BeanDefinition bd = cbf.getMergedBeanDefinition(beanName);
/*     */           
/* 183 */           if (bd instanceof AbstractBeanDefinition) { AbstractBeanDefinition abd = (AbstractBeanDefinition)bd;
/* 184 */             AutowireCandidateQualifier candidate = abd.getQualifier(Qualifier.class.getName());
/* 185 */             if (candidate != null) {
/* 186 */               Object value = candidate.getAttribute("value");
/* 187 */               if (value != null && qualifier.test(value.toString())) {
/* 188 */                 return true;
/*     */               }
/*     */             }  }
/*     */ 
/*     */           
/* 193 */           if (bd instanceof RootBeanDefinition) { RootBeanDefinition rbd = (RootBeanDefinition)bd;
/* 194 */             Method factoryMethod = rbd.getResolvedFactoryMethod();
/* 195 */             if (factoryMethod != null) {
/* 196 */               Qualifier targetAnnotation = (Qualifier)AnnotationUtils.getAnnotation(factoryMethod, Qualifier.class);
/* 197 */               if (targetAnnotation != null) {
/* 198 */                 return qualifier.test(targetAnnotation.value());
/*     */               }
/*     */             }  }
/*     */            }
/*     */ 
/*     */         
/* 204 */         if (beanType != null) {
/* 205 */           Qualifier targetAnnotation = (Qualifier)AnnotationUtils.getAnnotation(beanType, Qualifier.class);
/* 206 */           if (targetAnnotation != null) {
/* 207 */             return qualifier.test(targetAnnotation.value());
/*     */           }
/*     */         }
/*     */       
/* 211 */       } catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     } 
/*     */ 
/*     */     
/* 215 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\BeanFactoryAnnotationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */