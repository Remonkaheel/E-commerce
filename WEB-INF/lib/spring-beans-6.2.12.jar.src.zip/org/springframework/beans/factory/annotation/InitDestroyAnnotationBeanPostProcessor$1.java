/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends InitDestroyAnnotationBeanPostProcessor.LifecycleMetadata
/*     */ {
/*     */   null(Class<?> beanClass, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethods, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethods) {
/*  91 */     super(beanClass, initMethods, destroyMethods);
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkInitDestroyMethods(RootBeanDefinition beanDefinition) {}
/*     */ 
/*     */   
/*     */   public void invokeInitMethods(Object target, String beanName) {}
/*     */   
/*     */   public void invokeDestroyMethods(Object target, String beanName) {}
/*     */   
/*     */   public boolean hasDestroyMethods() {
/* 103 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\InitDestroyAnnotationBeanPostProcessor$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */