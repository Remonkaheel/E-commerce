/*    */ package org.springframework.beans.factory.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements AnnotatedElement
/*    */ {
/*    */   @Nullable
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationClass) {
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations() {
/* 55 */     return new Annotation[0];
/*    */   }
/*    */   
/*    */   public Annotation[] getDeclaredAnnotations() {
/* 59 */     return new Annotation[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\ParameterResolutionDelegate$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */