/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.lang.Contract;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InjectionMetadata
/*     */ {
/*  54 */   public static final InjectionMetadata EMPTY = new InjectionMetadata(Object.class, Collections.emptyList())
/*     */     {
/*     */       protected boolean needsRefresh(Class<?> clazz) {
/*  57 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void checkConfigMembers(RootBeanDefinition beanDefinition) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public void inject(Object target, @Nullable String beanName, @Nullable PropertyValues pvs) {}
/*     */ 
/*     */ 
/*     */       
/*     */       public void clear(@Nullable PropertyValues pvs) {}
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<?> targetClass;
/*     */ 
/*     */   
/*     */   private final Collection<InjectedElement> injectedElements;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile Set<InjectedElement> checkedElements;
/*     */ 
/*     */ 
/*     */   
/*     */   public InjectionMetadata(Class<?> targetClass, Collection<InjectedElement> elements) {
/*  88 */     this.targetClass = targetClass;
/*  89 */     this.injectedElements = elements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InjectedElement> getInjectedElements() {
/*  98 */     return Collections.unmodifiableCollection(this.injectedElements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InjectedElement> getInjectedElements(@Nullable PropertyValues pvs) {
/* 110 */     return this.injectedElements.stream().filter(candidate -> candidate.shouldInject(pvs)).toList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean needsRefresh(Class<?> clazz) {
/* 120 */     return (this.targetClass != clazz);
/*     */   }
/*     */   
/*     */   public void checkConfigMembers(RootBeanDefinition beanDefinition) {
/* 124 */     if (this.injectedElements.isEmpty()) {
/* 125 */       this.checkedElements = Collections.emptySet();
/*     */     } else {
/*     */       
/* 128 */       Set<InjectedElement> checkedElements = CollectionUtils.newLinkedHashSet(this.injectedElements.size());
/* 129 */       for (InjectedElement element : this.injectedElements) {
/* 130 */         Member member = element.getMember();
/* 131 */         if (!beanDefinition.isExternallyManagedConfigMember(member)) {
/* 132 */           beanDefinition.registerExternallyManagedConfigMember(member);
/* 133 */           checkedElements.add(element);
/*     */         } 
/*     */       } 
/* 136 */       this.checkedElements = checkedElements;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void inject(Object target, @Nullable String beanName, @Nullable PropertyValues pvs) throws Throwable {
/* 141 */     Collection<InjectedElement> checkedElements = this.checkedElements;
/*     */     
/* 143 */     Collection<InjectedElement> elementsToIterate = (checkedElements != null) ? checkedElements : this.injectedElements;
/* 144 */     if (!elementsToIterate.isEmpty()) {
/* 145 */       for (InjectedElement element : elementsToIterate) {
/* 146 */         element.inject(target, beanName, pvs);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear(@Nullable PropertyValues pvs) {
/* 156 */     Collection<InjectedElement> checkedElements = this.checkedElements;
/*     */     
/* 158 */     Collection<InjectedElement> elementsToIterate = (checkedElements != null) ? checkedElements : this.injectedElements;
/* 159 */     if (!elementsToIterate.isEmpty()) {
/* 160 */       for (InjectedElement element : elementsToIterate) {
/* 161 */         element.clearPropertySkipping(pvs);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InjectionMetadata forElements(Collection<InjectedElement> elements, Class<?> clazz) {
/* 175 */     return elements.isEmpty() ? new InjectionMetadata(clazz, Collections.emptyList()) : 
/* 176 */       new InjectionMetadata(clazz, elements);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null, _ -> true")
/*     */   public static boolean needsRefresh(@Nullable InjectionMetadata metadata, Class<?> clazz) {
/* 188 */     return (metadata == null || metadata.needsRefresh(clazz));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class InjectedElement
/*     */   {
/*     */     protected final Member member;
/*     */ 
/*     */     
/*     */     protected final boolean isField;
/*     */     
/*     */     @Nullable
/*     */     protected final PropertyDescriptor pd;
/*     */     
/*     */     @Nullable
/*     */     protected volatile Boolean skip;
/*     */ 
/*     */     
/*     */     protected InjectedElement(Member member, @Nullable PropertyDescriptor pd) {
/* 208 */       this.member = member;
/* 209 */       this.isField = member instanceof Field;
/* 210 */       this.pd = pd;
/*     */     }
/*     */     
/*     */     public final Member getMember() {
/* 214 */       return this.member;
/*     */     }
/*     */     
/*     */     protected final Class<?> getResourceType() {
/* 218 */       if (this.isField) {
/* 219 */         return ((Field)this.member).getType();
/*     */       }
/* 221 */       if (this.pd != null) {
/* 222 */         return this.pd.getPropertyType();
/*     */       }
/*     */       
/* 225 */       return ((Method)this.member).getParameterTypes()[0];
/*     */     }
/*     */ 
/*     */     
/*     */     protected final void checkResourceType(Class<?> resourceType) {
/* 230 */       if (this.isField) {
/* 231 */         Class<?> fieldType = ((Field)this.member).getType();
/* 232 */         if (!resourceType.isAssignableFrom(fieldType) && !fieldType.isAssignableFrom(resourceType)) {
/* 233 */           throw new IllegalStateException("Specified field type [" + String.valueOf(fieldType) + "] is incompatible with resource type [" + resourceType
/* 234 */               .getName() + "]");
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 239 */         Class<?> paramType = (this.pd != null) ? this.pd.getPropertyType() : ((Method)this.member).getParameterTypes()[0];
/* 240 */         if (!resourceType.isAssignableFrom(paramType) && !paramType.isAssignableFrom(resourceType)) {
/* 241 */           throw new IllegalStateException("Specified parameter type [" + String.valueOf(paramType) + "] is incompatible with resource type [" + resourceType
/* 242 */               .getName() + "]");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean shouldInject(@Nullable PropertyValues pvs) {
/* 254 */       if (this.isField) {
/* 255 */         return true;
/*     */       }
/* 257 */       return !checkPropertySkipping(pvs);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void inject(Object target, @Nullable String requestingBeanName, @Nullable PropertyValues pvs) throws Throwable {
/* 266 */       if (!shouldInject(pvs)) {
/*     */         return;
/*     */       }
/* 269 */       if (this.isField) {
/* 270 */         Field field = (Field)this.member;
/* 271 */         ReflectionUtils.makeAccessible(field);
/* 272 */         field.set(target, getResourceToInject(target, requestingBeanName));
/*     */       } else {
/*     */         
/*     */         try {
/* 276 */           Method method = (Method)this.member;
/* 277 */           ReflectionUtils.makeAccessible(method);
/* 278 */           method.invoke(target, new Object[] { getResourceToInject(target, requestingBeanName) });
/*     */         }
/* 280 */         catch (InvocationTargetException ex) {
/* 281 */           throw ex.getTargetException();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean checkPropertySkipping(@Nullable PropertyValues pvs) {
/* 292 */       Boolean skip = this.skip;
/* 293 */       if (skip != null) {
/* 294 */         return skip.booleanValue();
/*     */       }
/* 296 */       if (pvs == null) {
/* 297 */         this.skip = Boolean.valueOf(false);
/* 298 */         return false;
/*     */       } 
/* 300 */       synchronized (pvs) {
/* 301 */         skip = this.skip;
/* 302 */         if (skip != null) {
/* 303 */           return skip.booleanValue();
/*     */         }
/* 305 */         if (this.pd != null) {
/* 306 */           if (pvs.contains(this.pd.getName())) {
/*     */             
/* 308 */             this.skip = Boolean.valueOf(true);
/* 309 */             return true;
/*     */           } 
/* 311 */           if (pvs instanceof MutablePropertyValues) { MutablePropertyValues mpvs = (MutablePropertyValues)pvs;
/* 312 */             mpvs.registerProcessedProperty(this.pd.getName()); }
/*     */         
/*     */         } 
/* 315 */         this.skip = Boolean.valueOf(false);
/* 316 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clearPropertySkipping(@Nullable PropertyValues pvs) {
/* 325 */       if (pvs == null) {
/*     */         return;
/*     */       }
/* 328 */       synchronized (pvs) {
/* 329 */         if (Boolean.FALSE.equals(this.skip) && this.pd != null && pvs instanceof MutablePropertyValues) { MutablePropertyValues mpvs = (MutablePropertyValues)pvs;
/* 330 */           mpvs.clearProcessedProperty(this.pd.getName()); }
/*     */       
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected Object getResourceToInject(Object target, @Nullable String requestingBeanName) {
/* 340 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 345 */       if (this != other) { if (other instanceof InjectedElement) { InjectedElement that = (InjectedElement)other; if (this.member
/* 346 */             .equals(that.member)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 351 */       return this.member.getClass().hashCode() * 29 + this.member.getName().hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 356 */       return getClass().getSimpleName() + " for " + getClass().getSimpleName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\InjectionMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */