/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InitDestroyAnnotationBeanPostProcessor
/*     */   implements DestructionAwareBeanPostProcessor, MergedBeanDefinitionPostProcessor, BeanRegistrationAotProcessor, PriorityOrdered, Serializable
/*     */ {
/*  90 */   private final transient LifecycleMetadata emptyLifecycleMetadata = new LifecycleMetadata(Object.class, 
/*  91 */       Collections.emptyList(), Collections.emptyList())
/*     */     {
/*     */       public void checkInitDestroyMethods(RootBeanDefinition beanDefinition) {}
/*     */ 
/*     */       
/*     */       public void invokeInitMethods(Object target, String beanName) {}
/*     */ 
/*     */       
/*     */       public void invokeDestroyMethods(Object target, String beanName) {}
/*     */ 
/*     */       
/*     */       public boolean hasDestroyMethods() {
/* 103 */         return false;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 108 */   protected transient Log logger = LogFactory.getLog(getClass());
/*     */   
/* 110 */   private final Set<Class<? extends Annotation>> initAnnotationTypes = new LinkedHashSet<>(2);
/*     */   
/* 112 */   private final Set<Class<? extends Annotation>> destroyAnnotationTypes = new LinkedHashSet<>(2);
/*     */   
/* 114 */   private int order = Integer.MAX_VALUE;
/*     */   @Nullable
/* 116 */   private final transient Map<Class<?>, LifecycleMetadata> lifecycleMetadataCache = new ConcurrentHashMap<>(256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitAnnotationType(Class<? extends Annotation> initAnnotationType) {
/* 129 */     this.initAnnotationTypes.clear();
/* 130 */     this.initAnnotationTypes.add(initAnnotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInitAnnotationType(@Nullable Class<? extends Annotation> initAnnotationType) {
/* 140 */     if (initAnnotationType != null) {
/* 141 */       this.initAnnotationTypes.add(initAnnotationType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDestroyAnnotationType(Class<? extends Annotation> destroyAnnotationType) {
/* 154 */     this.destroyAnnotationTypes.clear();
/* 155 */     this.destroyAnnotationTypes.add(destroyAnnotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDestroyAnnotationType(@Nullable Class<? extends Annotation> destroyAnnotationType) {
/* 165 */     if (destroyAnnotationType != null) {
/* 166 */       this.destroyAnnotationTypes.add(destroyAnnotationType);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 171 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 176 */     return this.order;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanClass, String beanName) {
/* 182 */     findLifecycleMetadata(beanDefinition, beanClass);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 188 */     RootBeanDefinition beanDefinition = registeredBean.getMergedBeanDefinition();
/* 189 */     beanDefinition.resolveDestroyMethodIfNecessary();
/* 190 */     LifecycleMetadata metadata = findLifecycleMetadata(beanDefinition, registeredBean.getBeanClass());
/* 191 */     if (!CollectionUtils.isEmpty(metadata.initMethods)) {
/* 192 */       String[] initMethodNames = safeMerge(beanDefinition.getInitMethodNames(), metadata.initMethods);
/* 193 */       beanDefinition.setInitMethodNames(initMethodNames);
/*     */     } 
/* 195 */     if (!CollectionUtils.isEmpty(metadata.destroyMethods)) {
/* 196 */       String[] destroyMethodNames = safeMerge(beanDefinition.getDestroyMethodNames(), metadata.destroyMethods);
/* 197 */       beanDefinition.setDestroyMethodNames(destroyMethodNames);
/*     */     } 
/* 199 */     return null;
/*     */   }
/*     */   
/*     */   private LifecycleMetadata findLifecycleMetadata(RootBeanDefinition beanDefinition, Class<?> beanClass) {
/* 203 */     LifecycleMetadata metadata = findLifecycleMetadata(beanClass);
/* 204 */     metadata.checkInitDestroyMethods(beanDefinition);
/* 205 */     return metadata;
/*     */   }
/*     */   
/*     */   private static String[] safeMerge(@Nullable String[] existingNames, Collection<LifecycleMethod> detectedMethods) {
/* 209 */     Stream<String> detectedNames = detectedMethods.stream().map(LifecycleMethod::getIdentifier);
/*     */     
/* 211 */     Stream<String> mergedNames = (existingNames != null) ? Stream.<String>concat(detectedNames, Stream.of(existingNames)) : detectedNames;
/* 212 */     return (String[])mergedNames.distinct().toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/* 217 */     LifecycleMetadata metadata = findLifecycleMetadata(bean.getClass());
/*     */     try {
/* 219 */       metadata.invokeInitMethods(bean, beanName);
/*     */     }
/* 221 */     catch (InvocationTargetException ex) {
/* 222 */       throw new BeanCreationException(beanName, "Invocation of init method failed", ex.getTargetException());
/*     */     }
/* 224 */     catch (Throwable ex) {
/* 225 */       throw new BeanCreationException(beanName, "Failed to invoke init method", ex);
/*     */     } 
/* 227 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
/* 232 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName) throws BeansException {
/* 237 */     LifecycleMetadata metadata = findLifecycleMetadata(bean.getClass());
/*     */     try {
/* 239 */       metadata.invokeDestroyMethods(bean, beanName);
/*     */     }
/* 241 */     catch (InvocationTargetException ex) {
/* 242 */       String msg = "Destroy method on bean with name '" + beanName + "' threw an exception";
/* 243 */       if (this.logger.isDebugEnabled()) {
/* 244 */         this.logger.warn(msg, ex.getTargetException());
/*     */       }
/* 246 */       else if (this.logger.isWarnEnabled()) {
/* 247 */         this.logger.warn(msg + ": " + msg);
/*     */       }
/*     */     
/* 250 */     } catch (Throwable ex) {
/* 251 */       if (this.logger.isWarnEnabled()) {
/* 252 */         this.logger.warn("Failed to invoke destroy method on bean with name '" + beanName + "'", ex);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresDestruction(Object bean) {
/* 259 */     return findLifecycleMetadata(bean.getClass()).hasDestroyMethods();
/*     */   }
/*     */ 
/*     */   
/*     */   private LifecycleMetadata findLifecycleMetadata(Class<?> beanClass) {
/* 264 */     if (this.lifecycleMetadataCache == null)
/*     */     {
/* 266 */       return buildLifecycleMetadata(beanClass);
/*     */     }
/*     */     
/* 269 */     LifecycleMetadata metadata = this.lifecycleMetadataCache.get(beanClass);
/* 270 */     if (metadata == null) {
/* 271 */       synchronized (this.lifecycleMetadataCache) {
/* 272 */         metadata = this.lifecycleMetadataCache.get(beanClass);
/* 273 */         if (metadata == null) {
/* 274 */           metadata = buildLifecycleMetadata(beanClass);
/* 275 */           this.lifecycleMetadataCache.put(beanClass, metadata);
/*     */         } 
/* 277 */         return metadata;
/*     */       } 
/*     */     }
/* 280 */     return metadata;
/*     */   }
/*     */   
/*     */   private LifecycleMetadata buildLifecycleMetadata(Class<?> beanClass) {
/* 284 */     if (!AnnotationUtils.isCandidateClass(beanClass, this.initAnnotationTypes) && 
/* 285 */       !AnnotationUtils.isCandidateClass(beanClass, this.destroyAnnotationTypes)) {
/* 286 */       return this.emptyLifecycleMetadata;
/*     */     }
/*     */     
/* 289 */     List<LifecycleMethod> initMethods = new ArrayList<>();
/* 290 */     List<LifecycleMethod> destroyMethods = new ArrayList<>();
/* 291 */     Class<?> currentClass = beanClass;
/*     */     
/*     */     do {
/* 294 */       List<LifecycleMethod> currInitMethods = new ArrayList<>();
/* 295 */       List<LifecycleMethod> currDestroyMethods = new ArrayList<>();
/*     */       
/* 297 */       ReflectionUtils.doWithLocalMethods(currentClass, method -> {
/*     */             for (Class<? extends Annotation> initAnnotationType : this.initAnnotationTypes) {
/*     */               if (initAnnotationType != null && method.isAnnotationPresent(initAnnotationType)) {
/*     */                 currInitMethods.add(new LifecycleMethod(method, beanClass));
/*     */                 
/*     */                 if (this.logger.isTraceEnabled()) {
/*     */                   this.logger.trace("Found init method on class [" + beanClass.getName() + "]: " + String.valueOf(method));
/*     */                 }
/*     */               } 
/*     */             } 
/*     */             for (Class<? extends Annotation> destroyAnnotationType : this.destroyAnnotationTypes) {
/*     */               if (destroyAnnotationType != null && method.isAnnotationPresent(destroyAnnotationType)) {
/*     */                 currDestroyMethods.add(new LifecycleMethod(method, beanClass));
/*     */                 if (this.logger.isTraceEnabled()) {
/*     */                   this.logger.trace("Found destroy method on class [" + beanClass.getName() + "]: " + String.valueOf(method));
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           });
/* 316 */       initMethods.addAll(0, currInitMethods);
/* 317 */       destroyMethods.addAll(currDestroyMethods);
/* 318 */       currentClass = currentClass.getSuperclass();
/*     */     }
/* 320 */     while (currentClass != null && currentClass != Object.class);
/*     */     
/* 322 */     return (initMethods.isEmpty() && destroyMethods.isEmpty()) ? this.emptyLifecycleMetadata : 
/* 323 */       new LifecycleMetadata(beanClass, initMethods, destroyMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 333 */     ois.defaultReadObject();
/*     */ 
/*     */     
/* 336 */     this.logger = LogFactory.getLog(getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class LifecycleMetadata
/*     */   {
/*     */     private final Class<?> beanClass;
/*     */ 
/*     */     
/*     */     private final Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethods;
/*     */ 
/*     */     
/*     */     private final Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethods;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private volatile Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedInitMethods;
/*     */     
/*     */     @Nullable
/*     */     private volatile Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods;
/*     */ 
/*     */     
/*     */     public LifecycleMetadata(Class<?> beanClass, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethods, Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethods) {
/* 360 */       this.beanClass = beanClass;
/* 361 */       this.initMethods = initMethods;
/* 362 */       this.destroyMethods = destroyMethods;
/*     */     }
/*     */     
/*     */     public void checkInitDestroyMethods(RootBeanDefinition beanDefinition) {
/* 366 */       Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedInitMethods = CollectionUtils.newLinkedHashSet(this.initMethods.size());
/* 367 */       for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : this.initMethods) {
/* 368 */         String methodIdentifier = lifecycleMethod.getIdentifier();
/* 369 */         if (!beanDefinition.isExternallyManagedInitMethod(methodIdentifier)) {
/* 370 */           beanDefinition.registerExternallyManagedInitMethod(methodIdentifier);
/* 371 */           checkedInitMethods.add(lifecycleMethod);
/* 372 */           if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 373 */             InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Registered init method on class [" + this.beanClass.getName() + "]: " + methodIdentifier);
/*     */           }
/*     */         } 
/*     */       } 
/* 377 */       Set<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods = CollectionUtils.newLinkedHashSet(this.destroyMethods.size());
/* 378 */       for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : this.destroyMethods) {
/* 379 */         String methodIdentifier = lifecycleMethod.getIdentifier();
/* 380 */         if (!beanDefinition.isExternallyManagedDestroyMethod(methodIdentifier)) {
/* 381 */           beanDefinition.registerExternallyManagedDestroyMethod(methodIdentifier);
/* 382 */           checkedDestroyMethods.add(lifecycleMethod);
/* 383 */           if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 384 */             InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Registered destroy method on class [" + this.beanClass.getName() + "]: " + methodIdentifier);
/*     */           }
/*     */         } 
/*     */       } 
/* 388 */       this.checkedInitMethods = checkedInitMethods;
/* 389 */       this.checkedDestroyMethods = checkedDestroyMethods;
/*     */     }
/*     */     
/*     */     public void invokeInitMethods(Object target, String beanName) throws Throwable {
/* 393 */       Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedInitMethods = this.checkedInitMethods;
/*     */       
/* 395 */       Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> initMethodsToIterate = (checkedInitMethods != null) ? checkedInitMethods : this.initMethods;
/* 396 */       if (!initMethodsToIterate.isEmpty()) {
/* 397 */         for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : initMethodsToIterate) {
/* 398 */           if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 399 */             InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Invoking init method on bean '" + beanName + "': " + String.valueOf(lifecycleMethod.getMethod()));
/*     */           }
/* 401 */           lifecycleMethod.invoke(target);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public void invokeDestroyMethods(Object target, String beanName) throws Throwable {
/* 407 */       Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods = this.checkedDestroyMethods;
/*     */       
/* 409 */       Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethodsToUse = (checkedDestroyMethods != null) ? checkedDestroyMethods : this.destroyMethods;
/* 410 */       if (!destroyMethodsToUse.isEmpty()) {
/* 411 */         for (InitDestroyAnnotationBeanPostProcessor.LifecycleMethod lifecycleMethod : destroyMethodsToUse) {
/* 412 */           if (InitDestroyAnnotationBeanPostProcessor.this.logger.isTraceEnabled()) {
/* 413 */             InitDestroyAnnotationBeanPostProcessor.this.logger.trace("Invoking destroy method on bean '" + beanName + "': " + String.valueOf(lifecycleMethod.getMethod()));
/*     */           }
/* 415 */           lifecycleMethod.invoke(target);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean hasDestroyMethods() {
/* 421 */       Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> checkedDestroyMethods = this.checkedDestroyMethods;
/*     */       
/* 423 */       Collection<InitDestroyAnnotationBeanPostProcessor.LifecycleMethod> destroyMethodsToUse = (checkedDestroyMethods != null) ? checkedDestroyMethods : this.destroyMethods;
/* 424 */       return !destroyMethodsToUse.isEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LifecycleMethod
/*     */   {
/*     */     private final Method method;
/*     */ 
/*     */     
/*     */     private final String identifier;
/*     */ 
/*     */     
/*     */     public LifecycleMethod(Method method, Class<?> beanClass) {
/* 439 */       if (method.getParameterCount() != 0) {
/* 440 */         throw new IllegalStateException("Lifecycle annotation requires a no-arg method: " + String.valueOf(method));
/*     */       }
/* 442 */       this.method = method;
/* 443 */       this
/* 444 */         .identifier = isPrivateOrNotVisible(method, beanClass) ? ClassUtils.getQualifiedMethodName(method) : method.getName();
/*     */     }
/*     */     
/*     */     public Method getMethod() {
/* 448 */       return this.method;
/*     */     }
/*     */     
/*     */     public String getIdentifier() {
/* 452 */       return this.identifier;
/*     */     }
/*     */     
/*     */     public void invoke(Object target) throws Throwable {
/* 456 */       ReflectionUtils.makeAccessible(this.method);
/* 457 */       this.method.invoke(target, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 462 */       if (this != other) { if (other instanceof LifecycleMethod) { LifecycleMethod that = (LifecycleMethod)other; if (this.identifier
/* 463 */             .equals(that.identifier)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 468 */       return this.identifier.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean isPrivateOrNotVisible(Method method, Class<?> beanClass) {
/* 477 */       int modifiers = method.getModifiers();
/* 478 */       if (Modifier.isPrivate(modifiers)) {
/* 479 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 483 */       return (!method.getDeclaringClass().getPackageName().equals(beanClass.getPackageName()) && 
/* 484 */         !Modifier.isPublic(modifiers) && !Modifier.isProtected(modifiers));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\InitDestroyAnnotationBeanPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */