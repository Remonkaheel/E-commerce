/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InjectedElement
/*     */ {
/*     */   protected final Member member;
/*     */   protected final boolean isField;
/*     */   @Nullable
/*     */   protected final PropertyDescriptor pd;
/*     */   @Nullable
/*     */   protected volatile Boolean skip;
/*     */   
/*     */   protected InjectedElement(Member member, @Nullable PropertyDescriptor pd) {
/* 208 */     this.member = member;
/* 209 */     this.isField = member instanceof Field;
/* 210 */     this.pd = pd;
/*     */   }
/*     */   
/*     */   public final Member getMember() {
/* 214 */     return this.member;
/*     */   }
/*     */   
/*     */   protected final Class<?> getResourceType() {
/* 218 */     if (this.isField) {
/* 219 */       return ((Field)this.member).getType();
/*     */     }
/* 221 */     if (this.pd != null) {
/* 222 */       return this.pd.getPropertyType();
/*     */     }
/*     */     
/* 225 */     return ((Method)this.member).getParameterTypes()[0];
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void checkResourceType(Class<?> resourceType) {
/* 230 */     if (this.isField) {
/* 231 */       Class<?> fieldType = ((Field)this.member).getType();
/* 232 */       if (!resourceType.isAssignableFrom(fieldType) && !fieldType.isAssignableFrom(resourceType)) {
/* 233 */         throw new IllegalStateException("Specified field type [" + String.valueOf(fieldType) + "] is incompatible with resource type [" + resourceType
/* 234 */             .getName() + "]");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 239 */       Class<?> paramType = (this.pd != null) ? this.pd.getPropertyType() : ((Method)this.member).getParameterTypes()[0];
/* 240 */       if (!resourceType.isAssignableFrom(paramType) && !paramType.isAssignableFrom(resourceType)) {
/* 241 */         throw new IllegalStateException("Specified parameter type [" + String.valueOf(paramType) + "] is incompatible with resource type [" + resourceType
/* 242 */             .getName() + "]");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldInject(@Nullable PropertyValues pvs) {
/* 254 */     if (this.isField) {
/* 255 */       return true;
/*     */     }
/* 257 */     return !checkPropertySkipping(pvs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void inject(Object target, @Nullable String requestingBeanName, @Nullable PropertyValues pvs) throws Throwable {
/* 266 */     if (!shouldInject(pvs)) {
/*     */       return;
/*     */     }
/* 269 */     if (this.isField) {
/* 270 */       Field field = (Field)this.member;
/* 271 */       ReflectionUtils.makeAccessible(field);
/* 272 */       field.set(target, getResourceToInject(target, requestingBeanName));
/*     */     } else {
/*     */       
/*     */       try {
/* 276 */         Method method = (Method)this.member;
/* 277 */         ReflectionUtils.makeAccessible(method);
/* 278 */         method.invoke(target, new Object[] { getResourceToInject(target, requestingBeanName) });
/*     */       }
/* 280 */       catch (InvocationTargetException ex) {
/* 281 */         throw ex.getTargetException();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkPropertySkipping(@Nullable PropertyValues pvs) {
/* 292 */     Boolean skip = this.skip;
/* 293 */     if (skip != null) {
/* 294 */       return skip.booleanValue();
/*     */     }
/* 296 */     if (pvs == null) {
/* 297 */       this.skip = Boolean.valueOf(false);
/* 298 */       return false;
/*     */     } 
/* 300 */     synchronized (pvs) {
/* 301 */       skip = this.skip;
/* 302 */       if (skip != null) {
/* 303 */         return skip.booleanValue();
/*     */       }
/* 305 */       if (this.pd != null) {
/* 306 */         if (pvs.contains(this.pd.getName())) {
/*     */           
/* 308 */           this.skip = Boolean.valueOf(true);
/* 309 */           return true;
/*     */         } 
/* 311 */         if (pvs instanceof MutablePropertyValues) { MutablePropertyValues mpvs = (MutablePropertyValues)pvs;
/* 312 */           mpvs.registerProcessedProperty(this.pd.getName()); }
/*     */       
/*     */       } 
/* 315 */       this.skip = Boolean.valueOf(false);
/* 316 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearPropertySkipping(@Nullable PropertyValues pvs) {
/* 325 */     if (pvs == null) {
/*     */       return;
/*     */     }
/* 328 */     synchronized (pvs) {
/* 329 */       if (Boolean.FALSE.equals(this.skip) && this.pd != null && pvs instanceof MutablePropertyValues) { MutablePropertyValues mpvs = (MutablePropertyValues)pvs;
/* 330 */         mpvs.clearProcessedProperty(this.pd.getName()); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getResourceToInject(Object target, @Nullable String requestingBeanName) {
/* 340 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 345 */     if (this != other) { if (other instanceof InjectedElement) { InjectedElement that = (InjectedElement)other; if (this.member
/* 346 */           .equals(that.member)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 351 */     return this.member.getClass().hashCode() * 29 + this.member.getName().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 356 */     return getClass().getSimpleName() + " for " + getClass().getSimpleName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\InjectionMetadata$InjectedElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */