/*      */ package org.springframework.beans.factory.annotation;
/*      */ 
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import javax.lang.model.element.Modifier;
/*      */ import org.springframework.aot.generate.AccessControl;
/*      */ import org.springframework.aot.generate.GeneratedClass;
/*      */ import org.springframework.aot.generate.GeneratedMethod;
/*      */ import org.springframework.aot.generate.GenerationContext;
/*      */ import org.springframework.aot.hint.ExecutableMode;
/*      */ import org.springframework.aot.hint.RuntimeHints;
/*      */ import org.springframework.aot.hint.support.ClassHintUtils;
/*      */ import org.springframework.beans.factory.aot.AutowiredArgumentsCodeGenerator;
/*      */ import org.springframework.beans.factory.aot.AutowiredFieldValueResolver;
/*      */ import org.springframework.beans.factory.aot.AutowiredMethodArgumentsResolver;
/*      */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*      */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*      */ import org.springframework.beans.factory.aot.CodeWarnings;
/*      */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*      */ import org.springframework.beans.factory.support.AutowireCandidateResolver;
/*      */ import org.springframework.beans.factory.support.RegisteredBean;
/*      */ import org.springframework.core.MethodParameter;
/*      */ import org.springframework.javapoet.ClassName;
/*      */ import org.springframework.javapoet.CodeBlock;
/*      */ import org.springframework.javapoet.MethodSpec;
/*      */ import org.springframework.javapoet.TypeSpec;
/*      */ import org.springframework.lang.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class AotContribution
/*      */   implements BeanRegistrationAotContribution
/*      */ {
/*      */   private static final String REGISTERED_BEAN_PARAMETER = "registeredBean";
/*      */   private static final String INSTANCE_PARAMETER = "instance";
/*      */   private final Class<?> target;
/*      */   private final Collection<AutowiredAnnotationBeanPostProcessor.AutowiredElement> autowiredElements;
/*      */   @Nullable
/*      */   private final AutowireCandidateResolver candidateResolver;
/*      */   
/*      */   AotContribution(Class<?> target, Collection<AutowiredAnnotationBeanPostProcessor.AutowiredElement> autowiredElements, @Nullable AutowireCandidateResolver candidateResolver) {
/*  969 */     this.target = target;
/*  970 */     this.autowiredElements = autowiredElements;
/*  971 */     this.candidateResolver = candidateResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/*  977 */     GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeatureComponent("Autowiring", this.target, type -> {
/*      */           type.addJavadoc("Autowiring for {@link $T}.", new Object[] { this.target });
/*      */           type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*      */         });
/*  981 */     GeneratedMethod generateMethod = generatedClass.getMethods().add("apply", method -> {
/*      */           method.addJavadoc("Apply the autowiring.", new Object[0]);
/*      */           
/*      */           method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*      */           
/*      */           method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*      */           method.addParameter(this.target, "instance", new Modifier[0]);
/*      */           method.returns(this.target);
/*      */           CodeWarnings codeWarnings = new CodeWarnings();
/*      */           codeWarnings.detectDeprecation(new AnnotatedElement[] { this.target });
/*      */           method.addCode(generateMethodCode(codeWarnings, generatedClass.getName(), generationContext.getRuntimeHints()));
/*      */           codeWarnings.suppress(method);
/*      */         });
/*  994 */     beanRegistrationCode.addInstancePostProcessor(generateMethod.toMethodReference());
/*      */     
/*  996 */     if (this.candidateResolver != null) {
/*  997 */       registerHints(generationContext.getRuntimeHints());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private CodeBlock generateMethodCode(CodeWarnings codeWarnings, ClassName targetClassName, RuntimeHints hints) {
/* 1004 */     CodeBlock.Builder code = CodeBlock.builder();
/* 1005 */     for (AutowiredAnnotationBeanPostProcessor.AutowiredElement autowiredElement : this.autowiredElements) {
/* 1006 */       code.addStatement(generateMethodStatementForElement(codeWarnings, targetClassName, autowiredElement, hints));
/*      */     }
/*      */     
/* 1009 */     code.addStatement("return $L", new Object[] { "instance" });
/* 1010 */     return code.build();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private CodeBlock generateMethodStatementForElement(CodeWarnings codeWarnings, ClassName targetClassName, AutowiredAnnotationBeanPostProcessor.AutowiredElement autowiredElement, RuntimeHints hints) {
/* 1016 */     Member member = autowiredElement.getMember();
/* 1017 */     boolean required = autowiredElement.required;
/* 1018 */     if (member instanceof Field) { Field field = (Field)member;
/* 1019 */       return generateMethodStatementForField(codeWarnings, targetClassName, field, required, hints); }
/*      */ 
/*      */     
/* 1022 */     if (member instanceof Method) { Method method = (Method)member;
/* 1023 */       return generateMethodStatementForMethod(codeWarnings, targetClassName, method, required, hints); }
/*      */ 
/*      */     
/* 1026 */     throw new IllegalStateException("Unsupported member type " + member
/* 1027 */         .getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private CodeBlock generateMethodStatementForField(CodeWarnings codeWarnings, ClassName targetClassName, Field field, boolean required, RuntimeHints hints) {
/* 1033 */     hints.reflection().registerField(field);
/* 1034 */     CodeBlock resolver = CodeBlock.of("$T.$L($S)", new Object[] { AutowiredFieldValueResolver.class, 
/*      */           
/* 1036 */           !required ? "forField" : "forRequiredField", field.getName() });
/* 1037 */     AccessControl accessControl = AccessControl.forMember(field);
/* 1038 */     if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 1039 */       return CodeBlock.of("$L.resolveAndSet($L, $L)", new Object[] { resolver, "registeredBean", "instance" });
/*      */     }
/*      */ 
/*      */     
/* 1043 */     codeWarnings.detectDeprecation(new AnnotatedElement[] { field });
/* 1044 */     return CodeBlock.of("$L.$L = $L.resolve($L)", new Object[] { "instance", field
/* 1045 */           .getName(), resolver, "registeredBean" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CodeBlock generateMethodStatementForMethod(CodeWarnings codeWarnings, ClassName targetClassName, Method method, boolean required, RuntimeHints hints) {
/* 1052 */     CodeBlock.Builder code = CodeBlock.builder();
/* 1053 */     code.add("$T.$L", new Object[] { AutowiredMethodArgumentsResolver.class, 
/* 1054 */           !required ? "forMethod" : "forRequiredMethod" });
/* 1055 */     code.add("($S", new Object[] { method.getName() });
/* 1056 */     if (method.getParameterCount() > 0) {
/* 1057 */       codeWarnings.detectDeprecation((AnnotatedElement[])method.getParameterTypes());
/* 1058 */       code.add(", $L", new Object[] { generateParameterTypesCode(method.getParameterTypes()) });
/*      */     } 
/* 1060 */     code.add(")", new Object[0]);
/* 1061 */     AccessControl accessControl = AccessControl.forMember(method);
/* 1062 */     if (!accessControl.isAccessibleFrom(targetClassName)) {
/* 1063 */       hints.reflection().registerMethod(method, ExecutableMode.INVOKE);
/* 1064 */       code.add(".resolveAndInvoke($L, $L)", new Object[] { "registeredBean", "instance" });
/*      */     } else {
/*      */       
/* 1067 */       codeWarnings.detectDeprecation(new AnnotatedElement[] { method });
/* 1068 */       hints.reflection().registerMethod(method, ExecutableMode.INTROSPECT);
/*      */       
/* 1070 */       CodeBlock arguments = (new AutowiredArgumentsCodeGenerator(this.target, method)).generateCode(method.getParameterTypes());
/* 1071 */       CodeBlock injectionCode = CodeBlock.of("args -> $L.$L($L)", new Object[] { "instance", method
/* 1072 */             .getName(), arguments });
/* 1073 */       code.add(".resolve($L, $L)", new Object[] { "registeredBean", injectionCode });
/*      */     } 
/* 1075 */     return code.build();
/*      */   }
/*      */   
/*      */   private CodeBlock generateParameterTypesCode(Class<?>[] parameterTypes) {
/* 1079 */     return CodeBlock.join(Arrays.<Class<?>>stream(parameterTypes)
/* 1080 */         .map(parameterType -> CodeBlock.of("$T.class", new Object[] { parameterType
/* 1081 */             })).toList(), ", ");
/*      */   }
/*      */   
/*      */   private void registerHints(RuntimeHints runtimeHints) {
/* 1085 */     this.autowiredElements.forEach(autowiredElement -> {
/*      */           boolean required = autowiredElement.required;
/*      */           Member member = autowiredElement.getMember();
/*      */           if (member instanceof Field) {
/*      */             Field field = (Field)member;
/*      */             DependencyDescriptor dependencyDescriptor = new DependencyDescriptor(field, required);
/*      */             registerProxyIfNecessary(runtimeHints, dependencyDescriptor);
/*      */           } 
/*      */           if (member instanceof Method) {
/*      */             Method method = (Method)member;
/*      */             Class<?>[] parameterTypes = method.getParameterTypes();
/*      */             for (int i = 0; i < parameterTypes.length; i++) {
/*      */               MethodParameter methodParam = new MethodParameter(method, i);
/*      */               DependencyDescriptor dependencyDescriptor = new DependencyDescriptor(methodParam, required);
/*      */               registerProxyIfNecessary(runtimeHints, dependencyDescriptor);
/*      */             } 
/*      */           } 
/*      */         });
/*      */   } private void registerProxyIfNecessary(RuntimeHints runtimeHints, DependencyDescriptor dependencyDescriptor) {
/* 1104 */     if (this.candidateResolver != null) {
/*      */       
/* 1106 */       Class<?> proxyClass = this.candidateResolver.getLazyResolutionProxyClass(dependencyDescriptor, null);
/* 1107 */       if (proxyClass != null)
/* 1108 */         ClassHintUtils.registerProxyIfNecessary(proxyClass, runtimeHints); 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\AutowiredAnnotationBeanPostProcessor$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */