/*     */ package org.springframework.beans.factory.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.GenericTypeAwareAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifierAnnotationAutowireCandidateResolver
/*     */   extends GenericTypeAwareAutowireCandidateResolver
/*     */ {
/*  64 */   private final Set<Class<? extends Annotation>> qualifierTypes = CollectionUtils.newLinkedHashSet(2);
/*     */   
/*  66 */   private Class<? extends Annotation> valueAnnotationType = (Class)Value.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifierAnnotationAutowireCandidateResolver() {
/*  77 */     this.qualifierTypes.add(Qualifier.class);
/*     */     try {
/*  79 */       this.qualifierTypes.add(ClassUtils.forName("jakarta.inject.Qualifier", QualifierAnnotationAutowireCandidateResolver.class
/*  80 */             .getClassLoader()));
/*     */     }
/*  82 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*     */     try {
/*  86 */       this.qualifierTypes.add(ClassUtils.forName("javax.inject.Qualifier", QualifierAnnotationAutowireCandidateResolver.class
/*  87 */             .getClassLoader()));
/*     */     }
/*  89 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifierAnnotationAutowireCandidateResolver(Class<? extends Annotation> qualifierType) {
/* 100 */     Assert.notNull(qualifierType, "'qualifierType' must not be null");
/* 101 */     this.qualifierTypes.add(qualifierType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifierAnnotationAutowireCandidateResolver(Set<Class<? extends Annotation>> qualifierTypes) {
/* 110 */     Assert.notNull(qualifierTypes, "'qualifierTypes' must not be null");
/* 111 */     this.qualifierTypes.addAll(qualifierTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addQualifierType(Class<? extends Annotation> qualifierType) {
/* 126 */     this.qualifierTypes.add(qualifierType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueAnnotationType(Class<? extends Annotation> valueAnnotationType) {
/* 139 */     this.valueAnnotationType = valueAnnotationType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutowireCandidate(BeanDefinitionHolder bdHolder, DependencyDescriptor descriptor) {
/* 157 */     if (!super.isAutowireCandidate(bdHolder, descriptor)) {
/* 158 */       return false;
/*     */     }
/* 160 */     Boolean checked = checkQualifiers(bdHolder, descriptor.getAnnotations());
/* 161 */     if (checked != Boolean.FALSE) {
/* 162 */       MethodParameter methodParam = descriptor.getMethodParameter();
/* 163 */       if (methodParam != null) {
/* 164 */         Method method = methodParam.getMethod();
/* 165 */         if (method == null || void.class == method.getReturnType()) {
/* 166 */           Boolean methodChecked = checkQualifiers(bdHolder, methodParam.getMethodAnnotations());
/* 167 */           if (methodChecked != null && checked == null) {
/* 168 */             checked = methodChecked;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 173 */     return (checked == Boolean.TRUE || (checked == null && ((RootBeanDefinition)bdHolder
/* 174 */       .getBeanDefinition()).isDefaultCandidate()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Boolean checkQualifiers(BeanDefinitionHolder bdHolder, Annotation[] annotationsToSearch) {
/* 186 */     boolean qualifierFound = false;
/* 187 */     if (!ObjectUtils.isEmpty((Object[])annotationsToSearch)) {
/* 188 */       SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/* 189 */       for (Annotation annotation : annotationsToSearch) {
/* 190 */         Class<? extends Annotation> type = annotation.annotationType();
/* 191 */         if (!isPlainJavaAnnotation(type)) {
/*     */ 
/*     */           
/* 194 */           boolean checkMeta = true;
/* 195 */           boolean fallbackToMeta = false;
/* 196 */           if (isQualifier(type)) {
/* 197 */             qualifierFound = true;
/* 198 */             if (!checkQualifier(bdHolder, annotation, (TypeConverter)typeConverter)) {
/* 199 */               fallbackToMeta = true;
/*     */             } else {
/*     */               
/* 202 */               checkMeta = false;
/*     */             } 
/*     */           } 
/* 205 */           if (checkMeta) {
/* 206 */             boolean foundMeta = false;
/* 207 */             for (Annotation metaAnn : type.getAnnotations()) {
/* 208 */               Class<? extends Annotation> metaType = metaAnn.annotationType();
/* 209 */               if (!isPlainJavaAnnotation(metaType))
/*     */               {
/*     */                 
/* 212 */                 if (isQualifier(metaType)) {
/* 213 */                   qualifierFound = true;
/* 214 */                   foundMeta = true;
/*     */ 
/*     */                   
/* 217 */                   if ((fallbackToMeta && ObjectUtils.isEmpty(AnnotationUtils.getValue(metaAnn))) || 
/* 218 */                     !checkQualifier(bdHolder, metaAnn, (TypeConverter)typeConverter))
/* 219 */                     return Boolean.valueOf(false); 
/*     */                 } 
/*     */               }
/*     */             } 
/* 223 */             if (fallbackToMeta && !foundMeta)
/* 224 */               return Boolean.valueOf(false); 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 229 */     return qualifierFound ? Boolean.valueOf(true) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPlainJavaAnnotation(Class<? extends Annotation> annotationType) {
/* 239 */     return annotationType.getName().startsWith("java.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isQualifier(Class<? extends Annotation> annotationType) {
/* 246 */     for (Class<? extends Annotation> qualifierType : this.qualifierTypes) {
/* 247 */       if (annotationType.equals(qualifierType) || annotationType.isAnnotationPresent(qualifierType)) {
/* 248 */         return true;
/*     */       }
/*     */     } 
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkQualifier(BeanDefinitionHolder bdHolder, Annotation annotation, TypeConverter typeConverter) {
/* 260 */     Class<? extends Annotation> type = annotation.annotationType();
/* 261 */     RootBeanDefinition bd = (RootBeanDefinition)bdHolder.getBeanDefinition();
/*     */     
/* 263 */     AutowireCandidateQualifier qualifier = bd.getQualifier(type.getName());
/* 264 */     if (qualifier == null) {
/* 265 */       qualifier = bd.getQualifier(ClassUtils.getShortName(type));
/*     */     }
/* 267 */     if (qualifier == null) {
/*     */       
/* 269 */       Annotation targetAnnotation = getQualifiedElementAnnotation(bd, type);
/*     */       
/* 271 */       if (targetAnnotation == null) {
/* 272 */         targetAnnotation = getFactoryMethodAnnotation(bd, type);
/*     */       }
/* 274 */       if (targetAnnotation == null) {
/* 275 */         RootBeanDefinition dbd = getResolvedDecoratedDefinition(bd);
/* 276 */         if (dbd != null) {
/* 277 */           targetAnnotation = getFactoryMethodAnnotation(dbd, type);
/*     */         }
/*     */       } 
/* 280 */       if (targetAnnotation == null) {
/* 281 */         BeanFactory beanFactory = getBeanFactory();
/*     */         
/* 283 */         if (beanFactory != null) {
/*     */           try {
/* 285 */             Class<?> beanType = beanFactory.getType(bdHolder.getBeanName());
/* 286 */             if (beanType != null) {
/* 287 */               targetAnnotation = AnnotationUtils.getAnnotation(ClassUtils.getUserClass(beanType), type);
/*     */             }
/*     */           }
/* 290 */           catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */         }
/*     */ 
/*     */         
/* 294 */         if (targetAnnotation == null && bd.hasBeanClass()) {
/* 295 */           targetAnnotation = AnnotationUtils.getAnnotation(ClassUtils.getUserClass(bd.getBeanClass()), type);
/*     */         }
/*     */       } 
/* 298 */       if (targetAnnotation != null && targetAnnotation.equals(annotation)) {
/* 299 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 303 */     Map<String, Object> attributes = AnnotationUtils.getAnnotationAttributes(annotation);
/* 304 */     if (attributes.isEmpty() && qualifier == null)
/*     */     {
/* 306 */       return false;
/*     */     }
/* 308 */     for (Map.Entry<String, Object> entry : attributes.entrySet()) {
/* 309 */       String attributeName = entry.getKey();
/* 310 */       Object expectedValue = entry.getValue();
/* 311 */       Object actualValue = null;
/*     */       
/* 313 */       if (qualifier != null) {
/* 314 */         actualValue = qualifier.getAttribute(attributeName);
/*     */       }
/* 316 */       if (actualValue == null)
/*     */       {
/* 318 */         actualValue = bd.getAttribute(attributeName);
/*     */       }
/* 320 */       if (actualValue == null && attributeName.equals("value") && expectedValue instanceof String) {
/* 321 */         String name = (String)expectedValue; if (bdHolder.matchesName(name)) {
/*     */           continue;
/*     */         }
/*     */       } 
/* 325 */       if (actualValue == null && qualifier != null)
/*     */       {
/* 327 */         actualValue = AnnotationUtils.getDefaultValue(annotation, attributeName);
/*     */       }
/* 329 */       if (actualValue != null) {
/* 330 */         actualValue = typeConverter.convertIfNecessary(actualValue, expectedValue.getClass());
/*     */       }
/* 332 */       if (!ObjectUtils.nullSafeEquals(expectedValue, actualValue)) {
/* 333 */         return false;
/*     */       }
/*     */     } 
/* 336 */     return true;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Annotation getQualifiedElementAnnotation(RootBeanDefinition bd, Class<? extends Annotation> type) {
/* 341 */     AnnotatedElement qualifiedElement = bd.getQualifiedElement();
/* 342 */     return (qualifiedElement != null) ? AnnotationUtils.getAnnotation(qualifiedElement, type) : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Annotation getFactoryMethodAnnotation(RootBeanDefinition bd, Class<? extends Annotation> type) {
/* 347 */     Method resolvedFactoryMethod = bd.getResolvedFactoryMethod();
/* 348 */     return (resolvedFactoryMethod != null) ? AnnotationUtils.getAnnotation(resolvedFactoryMethod, type) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequired(DependencyDescriptor descriptor) {
/* 359 */     if (!super.isRequired(descriptor)) {
/* 360 */       return false;
/*     */     }
/* 362 */     Autowired autowired = (Autowired)descriptor.getAnnotation(Autowired.class);
/* 363 */     return (autowired == null || autowired.required());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasQualifier(DependencyDescriptor descriptor) {
/* 373 */     for (Annotation annotation : descriptor.getAnnotations()) {
/* 374 */       if (isQualifier(annotation.annotationType())) {
/* 375 */         return true;
/*     */       }
/*     */     } 
/* 378 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSuggestedName(DependencyDescriptor descriptor) {
/* 384 */     for (Annotation annotation : descriptor.getAnnotations()) {
/* 385 */       if (isQualifier(annotation.annotationType())) {
/* 386 */         Object value = AnnotationUtils.getValue(annotation);
/* 387 */         if (value instanceof String) { String str = (String)value;
/* 388 */           return str; }
/*     */       
/*     */       } 
/*     */     } 
/* 392 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSuggestedValue(DependencyDescriptor descriptor) {
/* 402 */     Object value = findValue(descriptor.getAnnotations());
/* 403 */     if (value == null) {
/* 404 */       MethodParameter methodParam = descriptor.getMethodParameter();
/* 405 */       if (methodParam != null) {
/* 406 */         value = findValue(methodParam.getMethodAnnotations());
/*     */       }
/*     */     } 
/* 409 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object findValue(Annotation[] annotationsToSearch) {
/* 417 */     if (annotationsToSearch.length > 0) {
/* 418 */       AnnotationAttributes attr = AnnotatedElementUtils.getMergedAnnotationAttributes(
/* 419 */           AnnotatedElementUtils.forAnnotations(annotationsToSearch), this.valueAnnotationType);
/* 420 */       if (attr != null) {
/* 421 */         return extractValue(attr);
/*     */       }
/*     */     } 
/* 424 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object extractValue(AnnotationAttributes attr) {
/* 432 */     Object value = attr.get("value");
/* 433 */     if (value == null) {
/* 434 */       throw new IllegalStateException("Value annotation must have a value attribute");
/*     */     }
/* 436 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\annotation\QualifierAnnotationAutowireCandidateResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */