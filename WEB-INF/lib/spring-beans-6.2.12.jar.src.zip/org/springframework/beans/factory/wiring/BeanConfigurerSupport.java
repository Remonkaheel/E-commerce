/*     */ package org.springframework.beans.factory.wiring;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanConfigurerSupport
/*     */   implements BeanFactoryAware, InitializingBean, DisposableBean
/*     */ {
/*  53 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile BeanWiringInfoResolver beanWiringInfoResolver;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanWiringInfoResolver(BeanWiringInfoResolver beanWiringInfoResolver) {
/*  70 */     Assert.notNull(beanWiringInfoResolver, "BeanWiringInfoResolver must not be null");
/*  71 */     this.beanWiringInfoResolver = beanWiringInfoResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*     */     ConfigurableListableBeanFactory clbf;
/*  79 */     if (beanFactory instanceof ConfigurableListableBeanFactory) { clbf = (ConfigurableListableBeanFactory)beanFactory; }
/*  80 */     else { throw new IllegalArgumentException("Bean configurer aspect needs to run in a ConfigurableListableBeanFactory: " + String.valueOf(beanFactory)); }
/*     */ 
/*     */     
/*  83 */     this.beanFactory = clbf;
/*  84 */     if (this.beanWiringInfoResolver == null) {
/*  85 */       this.beanWiringInfoResolver = createDefaultBeanWiringInfoResolver();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected BeanWiringInfoResolver createDefaultBeanWiringInfoResolver() {
/*  97 */     return new ClassNameBeanWiringInfoResolver();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 105 */     Assert.notNull(this.beanFactory, "BeanFactory must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 114 */     this.beanFactory = null;
/* 115 */     this.beanWiringInfoResolver = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureBean(Object beanInstance) {
/* 126 */     if (this.beanFactory == null) {
/* 127 */       if (this.logger.isDebugEnabled()) {
/* 128 */         this.logger.debug("BeanFactory has not been set on " + ClassUtils.getShortName(getClass()) + ": Make sure this configurer runs in a Spring container. Unable to configure bean of type [" + 
/*     */             
/* 130 */             ClassUtils.getDescriptiveType(beanInstance) + "]. Proceeding without injection.");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     BeanWiringInfoResolver bwiResolver = this.beanWiringInfoResolver;
/* 136 */     Assert.state((bwiResolver != null), "No BeanWiringInfoResolver available");
/* 137 */     BeanWiringInfo bwi = bwiResolver.resolveWiringInfo(beanInstance);
/* 138 */     if (bwi == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 144 */     ConfigurableListableBeanFactory beanFactory = this.beanFactory;
/* 145 */     Assert.state((beanFactory != null), "No BeanFactory available");
/*     */     try {
/* 147 */       String beanName = bwi.getBeanName();
/* 148 */       if (bwi.indicatesAutowiring() || (bwi.isDefaultBeanName() && beanName != null && 
/* 149 */         !beanFactory.containsBean(beanName)))
/*     */       {
/* 151 */         beanFactory.autowireBeanProperties(beanInstance, bwi.getAutowireMode(), bwi.getDependencyCheck());
/* 152 */         beanFactory.initializeBean(beanInstance, (beanName != null) ? beanName : "");
/*     */       }
/*     */       else
/*     */       {
/* 156 */         beanFactory.configureBean(beanInstance, (beanName != null) ? beanName : "");
/*     */       }
/*     */     
/* 159 */     } catch (BeanCreationException ex) {
/* 160 */       Throwable rootCause = ex.getMostSpecificCause();
/* 161 */       if (rootCause instanceof BeanCurrentlyInCreationException) { BeanCurrentlyInCreationException bce = (BeanCurrentlyInCreationException)rootCause;
/* 162 */         String bceBeanName = bce.getBeanName();
/* 163 */         if (bceBeanName != null && beanFactory.isCurrentlyInCreation(bceBeanName)) {
/* 164 */           if (this.logger.isDebugEnabled()) {
/* 165 */             this.logger.debug("Failed to create target bean '" + bce.getBeanName() + "' while configuring object of type [" + beanInstance
/* 166 */                 .getClass().getName() + "] - probably due to a circular reference. This is a common startup situation and usually not fatal. Proceeding without injection. Original exception: " + String.valueOf(ex));
/*     */           }
/*     */           
/*     */           return;
/*     */         }  }
/*     */ 
/*     */       
/* 173 */       throw ex;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\wiring\BeanConfigurerSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */