package org.springframework.beans.factory.wiring;

import org.springframework.lang.Nullable;

public interface BeanWiringInfoResolver {
  @Nullable
  BeanWiringInfo resolveWiringInfo(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\wiring\BeanWiringInfoResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */