package org.springframework.beans.factory;

public interface BeanFactoryInitializer<F extends ListableBeanFactory> {
  void initialize(F paramF);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\BeanFactoryInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */