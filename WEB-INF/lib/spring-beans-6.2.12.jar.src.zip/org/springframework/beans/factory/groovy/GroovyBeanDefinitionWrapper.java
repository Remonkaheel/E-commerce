/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GroovyBeanDefinitionWrapper
/*     */   extends GroovyObjectSupport
/*     */ {
/*     */   private static final String PARENT = "parent";
/*     */   private static final String AUTOWIRE = "autowire";
/*     */   private static final String CONSTRUCTOR_ARGS = "constructorArgs";
/*     */   private static final String FACTORY_BEAN = "factoryBean";
/*     */   private static final String FACTORY_METHOD = "factoryMethod";
/*     */   private static final String INIT_METHOD = "initMethod";
/*     */   private static final String DESTROY_METHOD = "destroyMethod";
/*     */   private static final String SINGLETON = "singleton";
/*  56 */   private static final Set<String> dynamicProperties = Set.of("parent", "autowire", "constructorArgs", "factoryBean", "factoryMethod", "initMethod", "destroyMethod", "singleton");
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final Class<?> clazz;
/*     */   
/*     */   @Nullable
/*     */   private final Collection<?> constructorArgs;
/*     */   
/*     */   @Nullable
/*     */   private AbstractBeanDefinition definition;
/*     */   
/*     */   @Nullable
/*     */   private BeanWrapper definitionWrapper;
/*     */   
/*     */   @Nullable
/*     */   private String parentName;
/*     */ 
/*     */   
/*     */   GroovyBeanDefinitionWrapper(String beanName) {
/*  80 */     this(beanName, null);
/*     */   }
/*     */   
/*     */   GroovyBeanDefinitionWrapper(@Nullable String beanName, @Nullable Class<?> clazz) {
/*  84 */     this(beanName, clazz, null);
/*     */   }
/*     */   
/*     */   GroovyBeanDefinitionWrapper(@Nullable String beanName, @Nullable Class<?> clazz, @Nullable Collection<?> constructorArgs) {
/*  88 */     this.beanName = beanName;
/*  89 */     this.clazz = clazz;
/*  90 */     this.constructorArgs = constructorArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getBeanName() {
/*  96 */     return this.beanName;
/*     */   }
/*     */   
/*     */   void setBeanDefinition(AbstractBeanDefinition definition) {
/* 100 */     this.definition = definition;
/*     */   }
/*     */   
/*     */   AbstractBeanDefinition getBeanDefinition() {
/* 104 */     if (this.definition == null) {
/* 105 */       this.definition = createBeanDefinition();
/*     */     }
/* 107 */     return this.definition;
/*     */   }
/*     */   
/*     */   protected AbstractBeanDefinition createBeanDefinition() {
/* 111 */     GenericBeanDefinition genericBeanDefinition = new GenericBeanDefinition();
/* 112 */     genericBeanDefinition.setBeanClass(this.clazz);
/* 113 */     if (!CollectionUtils.isEmpty(this.constructorArgs)) {
/* 114 */       ConstructorArgumentValues cav = new ConstructorArgumentValues();
/* 115 */       for (Object constructorArg : this.constructorArgs) {
/* 116 */         cav.addGenericArgumentValue(constructorArg);
/*     */       }
/* 118 */       genericBeanDefinition.setConstructorArgumentValues(cav);
/*     */     } 
/* 120 */     if (this.parentName != null) {
/* 121 */       genericBeanDefinition.setParentName(this.parentName);
/*     */     }
/* 123 */     this.definitionWrapper = (BeanWrapper)new BeanWrapperImpl(genericBeanDefinition);
/* 124 */     return (AbstractBeanDefinition)genericBeanDefinition;
/*     */   }
/*     */   
/*     */   void setBeanDefinitionHolder(BeanDefinitionHolder holder) {
/* 128 */     this.definition = (AbstractBeanDefinition)holder.getBeanDefinition();
/* 129 */     this.beanName = holder.getBeanName();
/*     */   }
/*     */   
/*     */   BeanDefinitionHolder getBeanDefinitionHolder() {
/* 133 */     Assert.state((this.beanName != null), "Bean name must be set");
/* 134 */     return new BeanDefinitionHolder((BeanDefinition)getBeanDefinition(), this.beanName);
/*     */   }
/*     */   
/*     */   void setParent(@Nullable Object obj) {
/* 138 */     Assert.notNull(obj, "Parent bean cannot be set to a null runtime bean reference");
/* 139 */     if (obj instanceof String) { String name = (String)obj;
/* 140 */       this.parentName = name; }
/*     */     
/* 142 */     else if (obj instanceof RuntimeBeanReference) { RuntimeBeanReference runtimeBeanReference = (RuntimeBeanReference)obj;
/* 143 */       this.parentName = runtimeBeanReference.getBeanName(); }
/*     */     
/* 145 */     else if (obj instanceof GroovyBeanDefinitionWrapper) { GroovyBeanDefinitionWrapper wrapper = (GroovyBeanDefinitionWrapper)obj;
/* 146 */       this.parentName = wrapper.getBeanName(); }
/*     */     
/* 148 */     getBeanDefinition().setParentName(this.parentName);
/* 149 */     getBeanDefinition().setAbstract(false);
/*     */   }
/*     */   
/*     */   GroovyBeanDefinitionWrapper addProperty(String propertyName, @Nullable Object propertyValue) {
/* 153 */     if (propertyValue instanceof GroovyBeanDefinitionWrapper) { GroovyBeanDefinitionWrapper wrapper = (GroovyBeanDefinitionWrapper)propertyValue;
/* 154 */       propertyValue = wrapper.getBeanDefinition(); }
/*     */     
/* 156 */     getBeanDefinition().getPropertyValues().add(propertyName, propertyValue);
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(String property) {
/* 164 */     Assert.state((this.definitionWrapper != null), "BeanDefinition wrapper not initialized");
/* 165 */     if (this.definitionWrapper.isReadableProperty(property)) {
/* 166 */       return this.definitionWrapper.getPropertyValue(property);
/*     */     }
/* 168 */     if (dynamicProperties.contains(property)) {
/* 169 */       return null;
/*     */     }
/* 171 */     return super.getProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(String property, @Nullable Object newValue) {
/* 176 */     if ("parent".equals(property)) {
/* 177 */       setParent(newValue);
/*     */     } else {
/*     */       
/* 180 */       AbstractBeanDefinition bd = getBeanDefinition();
/* 181 */       Assert.state((this.definitionWrapper != null), "BeanDefinition wrapper not initialized");
/* 182 */       if ("autowire".equals(property))
/* 183 */       { if ("byName".equals(newValue)) {
/* 184 */           bd.setAutowireMode(1);
/*     */         }
/* 186 */         else if ("byType".equals(newValue)) {
/* 187 */           bd.setAutowireMode(2);
/*     */         }
/* 189 */         else if ("constructor".equals(newValue)) {
/* 190 */           bd.setAutowireMode(3);
/*     */         }
/* 192 */         else if (Boolean.TRUE.equals(newValue)) {
/* 193 */           bd.setAutowireMode(1);
/*     */         }
/*     */          }
/*     */       
/* 197 */       else if ("constructorArgs".equals(property) && newValue instanceof List) { List<?> args = (List)newValue;
/* 198 */         ConstructorArgumentValues cav = new ConstructorArgumentValues();
/* 199 */         for (Object arg : args) {
/* 200 */           cav.addGenericArgumentValue(arg);
/*     */         }
/* 202 */         bd.setConstructorArgumentValues(cav);
/*     */          }
/*     */       
/* 205 */       else if ("factoryBean".equals(property))
/* 206 */       { if (newValue != null) {
/* 207 */           bd.setFactoryBeanName(newValue.toString());
/*     */         
/*     */         } }
/*     */       
/* 211 */       else if ("factoryMethod".equals(property))
/* 212 */       { if (newValue != null) {
/* 213 */           bd.setFactoryMethodName(newValue.toString());
/*     */         
/*     */         } }
/*     */       
/* 217 */       else if ("initMethod".equals(property))
/* 218 */       { if (newValue != null) {
/* 219 */           bd.setInitMethodName(newValue.toString());
/*     */         
/*     */         } }
/*     */       
/* 223 */       else if ("destroyMethod".equals(property))
/* 224 */       { if (newValue != null) {
/* 225 */           bd.setDestroyMethodName(newValue.toString());
/*     */         
/*     */         } }
/*     */       
/* 229 */       else if ("singleton".equals(property))
/* 230 */       { bd.setScope(Boolean.TRUE.equals(newValue) ? 
/* 231 */             "singleton" : "prototype"); }
/*     */       
/* 233 */       else if (this.definitionWrapper.isWritableProperty(property))
/* 234 */       { this.definitionWrapper.setPropertyValue(property, newValue); }
/*     */       else
/*     */       
/* 237 */       { super.setProperty(property, newValue); }
/*     */     
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\groovy\GroovyBeanDefinitionWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */