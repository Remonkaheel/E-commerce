/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.Binding;
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import groovy.lang.GroovyShell;
/*     */ import groovy.lang.GroovySystem;
/*     */ import groovy.lang.MetaClass;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.codehaus.groovy.runtime.DefaultGroovyMethods;
/*     */ import org.codehaus.groovy.runtime.InvokerHelper;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanDefinitionParsingException;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.NamespaceHandler;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroovyBeanDefinitionReader
/*     */   extends AbstractBeanDefinitionReader
/*     */   implements GroovyObject
/*     */ {
/*     */   private final XmlBeanDefinitionReader standardXmlBeanDefinitionReader;
/*     */   private final XmlBeanDefinitionReader groovyDslXmlBeanDefinitionReader;
/* 148 */   private final Map<String, String> namespaces = new HashMap<>();
/*     */   
/* 150 */   private final Map<String, DeferredProperty> deferredProperties = new HashMap<>();
/*     */   
/* 152 */   private MetaClass metaClass = GroovySystem.getMetaClassRegistry().getMetaClass(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Binding binding;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private GroovyBeanDefinitionWrapper currentBeanDefinition;
/*     */ 
/*     */ 
/*     */   
/*     */   public GroovyBeanDefinitionReader(BeanDefinitionRegistry registry) {
/* 167 */     super(registry);
/* 168 */     this.standardXmlBeanDefinitionReader = new XmlBeanDefinitionReader(registry);
/* 169 */     this.groovyDslXmlBeanDefinitionReader = new XmlBeanDefinitionReader(registry);
/* 170 */     this.groovyDslXmlBeanDefinitionReader.setValidating(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroovyBeanDefinitionReader(XmlBeanDefinitionReader xmlBeanDefinitionReader) {
/* 183 */     super(xmlBeanDefinitionReader.getRegistry());
/* 184 */     this.standardXmlBeanDefinitionReader = new XmlBeanDefinitionReader(xmlBeanDefinitionReader.getRegistry());
/* 185 */     this.groovyDslXmlBeanDefinitionReader = xmlBeanDefinitionReader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetaClass(MetaClass metaClass) {
/* 191 */     this.metaClass = metaClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public MetaClass getMetaClass() {
/* 196 */     return this.metaClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBinding(Binding binding) {
/* 204 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Binding getBinding() {
/* 212 */     return this.binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(Resource resource) throws BeanDefinitionStoreException {
/* 228 */     return loadBeanDefinitions(new EncodedResource(resource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource) throws BeanDefinitionStoreException {
/* 242 */     String filename = encodedResource.getResource().getFilename();
/* 243 */     if (StringUtils.endsWithIgnoreCase(filename, ".xml")) {
/* 244 */       return this.standardXmlBeanDefinitionReader.loadBeanDefinitions(encodedResource);
/*     */     }
/*     */     
/* 247 */     if (this.logger.isTraceEnabled()) {
/* 248 */       this.logger.trace("Loading Groovy bean definitions from " + String.valueOf(encodedResource));
/*     */     }
/*     */ 
/*     */     
/* 252 */     Closure<Object> beans = new Closure<Object>(this)
/*     */       {
/*     */         @Nullable
/*     */         public Object call(Object... args) {
/* 256 */           GroovyBeanDefinitionReader.this.invokeBeanDefiningClosure((Closure)args[0]);
/* 257 */           return null;
/*     */         }
/*     */       };
/* 260 */     Binding binding = new Binding()
/*     */       {
/*     */         public void setVariable(String name, Object value) {
/* 263 */           if (GroovyBeanDefinitionReader.this.currentBeanDefinition != null) {
/* 264 */             GroovyBeanDefinitionReader.this.applyPropertyToBeanDefinition(name, value);
/*     */           } else {
/*     */             
/* 267 */             super.setVariable(name, value);
/*     */           } 
/*     */         }
/*     */       };
/* 271 */     binding.setVariable("beans", beans);
/*     */     
/* 273 */     int countBefore = getRegistry().getBeanDefinitionCount();
/*     */     try {
/* 275 */       GroovyShell shell = new GroovyShell(getBeanClassLoader(), binding);
/* 276 */       shell.evaluate(encodedResource.getReader(), "beans");
/*     */     }
/* 278 */     catch (Throwable ex) {
/* 279 */       throw new BeanDefinitionParsingException(new Problem("Error evaluating Groovy script: " + ex.getMessage(), new Location(encodedResource
/* 280 */               .getResource()), null, ex));
/*     */     } 
/*     */     
/* 283 */     int count = getRegistry().getBeanDefinitionCount() - countBefore;
/* 284 */     if (this.logger.isDebugEnabled()) {
/* 285 */       this.logger.debug("Loaded " + count + " bean definitions from " + String.valueOf(encodedResource));
/*     */     }
/* 287 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroovyBeanDefinitionReader beans(Closure<?> closure) {
/* 299 */     return invokeBeanDefiningClosure(closure);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericBeanDefinition bean(Class<?> type) {
/* 308 */     GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
/* 309 */     beanDefinition.setBeanClass(type);
/* 310 */     return beanDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractBeanDefinition bean(Class<?> type, Object... args) {
/* 320 */     GroovyBeanDefinitionWrapper current = this.currentBeanDefinition;
/*     */     try {
/* 322 */       Closure<?> callable = null;
/* 323 */       Collection<Object> constructorArgs = null;
/* 324 */       if (!ObjectUtils.isEmpty(args)) {
/* 325 */         int index = args.length;
/* 326 */         Object lastArg = args[index - 1];
/* 327 */         if (lastArg instanceof Closure) { Closure<?> closure = (Closure)lastArg;
/* 328 */           callable = closure;
/* 329 */           index--; }
/*     */         
/* 331 */         constructorArgs = resolveConstructorArguments(args, 0, index);
/*     */       } 
/* 333 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(null, type, constructorArgs);
/* 334 */       if (callable != null) {
/* 335 */         callable.call(this.currentBeanDefinition);
/*     */       }
/* 337 */       return this.currentBeanDefinition.getBeanDefinition();
/*     */     } finally {
/*     */       
/* 340 */       this.currentBeanDefinition = current;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xmlns(Map<String, String> definition) {
/* 349 */     if (!definition.isEmpty()) {
/* 350 */       for (Map.Entry<String, String> entry : definition.entrySet()) {
/* 351 */         String namespace = entry.getKey();
/* 352 */         String uri = entry.getValue();
/* 353 */         if (uri == null) {
/* 354 */           throw new IllegalArgumentException("Namespace definition must supply a non-null URI");
/*     */         }
/*     */         
/* 357 */         NamespaceHandler namespaceHandler = this.groovyDslXmlBeanDefinitionReader.getNamespaceHandlerResolver().resolve(uri);
/* 358 */         if (namespaceHandler == null) {
/* 359 */           throw new BeanDefinitionParsingException(new Problem("No namespace handler found for URI: " + uri, new Location(new DescriptiveResource("Groovy"))));
/*     */         }
/*     */         
/* 362 */         this.namespaces.put(namespace, uri);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void importBeans(String resourcePattern) throws IOException {
/* 373 */     loadBeanDefinitions(resourcePattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invokeMethod(String name, Object arg) {
/* 385 */     Object[] args = (Object[])arg;
/* 386 */     if ("beans".equals(name) && args.length == 1) { Object object = args[0]; if (object instanceof Closure) { Closure<?> closure = (Closure)object;
/* 387 */         return beans(closure); }
/*     */        }
/* 389 */      if ("ref".equals(name)) {
/*     */       String refName;
/* 391 */       if (args[0] == null) {
/* 392 */         throw new IllegalArgumentException("Argument to ref() is not a valid bean or was not found");
/*     */       }
/* 394 */       Object object = args[0]; if (object instanceof RuntimeBeanReference) { RuntimeBeanReference runtimeBeanReference = (RuntimeBeanReference)object;
/* 395 */         refName = runtimeBeanReference.getBeanName(); }
/*     */       else
/*     */       
/* 398 */       { refName = args[0].toString(); }
/*     */       
/* 400 */       boolean parentRef = false;
/* 401 */       if (args.length > 1) { Object object1 = args[1]; if (object1 instanceof Boolean) { Boolean bool = (Boolean)object1;
/* 402 */           parentRef = bool.booleanValue(); }
/*     */          }
/* 404 */        return new RuntimeBeanReference(refName, parentRef);
/*     */     } 
/* 406 */     if (this.namespaces.containsKey(name) && args.length > 0 && args[0] instanceof Closure) {
/* 407 */       GroovyDynamicElementReader reader = createDynamicElementReader(name);
/* 408 */       reader.invokeMethod("doCall", args);
/*     */     } else {
/* 410 */       if (args.length > 0 && args[0] instanceof Closure)
/*     */       {
/* 412 */         return invokeBeanDefiningMethod(name, args);
/*     */       }
/* 414 */       if (args.length > 0 && (args[0] instanceof Class || args[0] instanceof RuntimeBeanReference || args[0] instanceof Map))
/*     */       {
/* 416 */         return invokeBeanDefiningMethod(name, args);
/*     */       }
/* 418 */       if (args.length > 1 && args[args.length - 1] instanceof Closure)
/* 419 */         return invokeBeanDefiningMethod(name, args); 
/*     */     } 
/* 421 */     MetaClass mc = DefaultGroovyMethods.getMetaClass(getRegistry());
/* 422 */     if (!mc.respondsTo(getRegistry(), name, args).isEmpty()) {
/* 423 */       return mc.invokeMethod(getRegistry(), name, args);
/*     */     }
/* 425 */     return this;
/*     */   }
/*     */   
/*     */   private boolean addDeferredProperty(String property, Object newValue) {
/* 429 */     if (newValue instanceof List || newValue instanceof Map) {
/* 430 */       Assert.state((this.currentBeanDefinition != null), "No current bean definition set");
/* 431 */       this.deferredProperties.put(this.currentBeanDefinition.getBeanName() + "." + this.currentBeanDefinition.getBeanName(), new DeferredProperty(this.currentBeanDefinition, property, newValue));
/*     */       
/* 433 */       return true;
/*     */     } 
/* 435 */     return false;
/*     */   }
/*     */   
/*     */   private void finalizeDeferredProperties() {
/* 439 */     for (DeferredProperty dp : this.deferredProperties.values()) {
/* 440 */       Object object = dp.value; if (object instanceof List) { List<?> list = (List)object;
/* 441 */         dp.value = manageListIfNecessary(list); }
/*     */       else
/* 443 */       { object = dp.value; if (object instanceof Map) { Map<?, ?> map = (Map<?, ?>)object;
/* 444 */           dp.value = manageMapIfNecessary(map); }
/*     */          }
/* 446 */        dp.apply();
/*     */     } 
/* 448 */     this.deferredProperties.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GroovyBeanDefinitionReader invokeBeanDefiningClosure(Closure<?> callable) {
/* 457 */     callable.setDelegate(this);
/* 458 */     callable.call();
/* 459 */     finalizeDeferredProperties();
/* 460 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GroovyBeanDefinitionWrapper invokeBeanDefiningMethod(String beanName, Object[] args) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: aload_2
/*     */     //   2: arraylength
/*     */     //   3: iconst_1
/*     */     //   4: isub
/*     */     //   5: aaload
/*     */     //   6: instanceof groovy/lang/Closure
/*     */     //   9: istore_3
/*     */     //   10: aload_2
/*     */     //   11: iconst_0
/*     */     //   12: aaload
/*     */     //   13: astore #7
/*     */     //   15: aload #7
/*     */     //   17: instanceof java/lang/Class
/*     */     //   20: ifeq -> 111
/*     */     //   23: aload #7
/*     */     //   25: checkcast java/lang/Class
/*     */     //   28: astore #4
/*     */     //   30: iload_3
/*     */     //   31: ifeq -> 86
/*     */     //   34: aload_2
/*     */     //   35: arraylength
/*     */     //   36: iconst_1
/*     */     //   37: isub
/*     */     //   38: iconst_1
/*     */     //   39: if_icmpeq -> 69
/*     */     //   42: aload_0
/*     */     //   43: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   46: dup
/*     */     //   47: aload_1
/*     */     //   48: aload #4
/*     */     //   50: aload_0
/*     */     //   51: aload_2
/*     */     //   52: iconst_1
/*     */     //   53: aload_2
/*     */     //   54: arraylength
/*     */     //   55: iconst_1
/*     */     //   56: isub
/*     */     //   57: invokevirtual resolveConstructorArguments : ([Ljava/lang/Object;II)Ljava/util/List;
/*     */     //   60: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;)V
/*     */     //   63: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   66: goto -> 528
/*     */     //   69: aload_0
/*     */     //   70: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   73: dup
/*     */     //   74: aload_1
/*     */     //   75: aload #4
/*     */     //   77: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;)V
/*     */     //   80: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   83: goto -> 528
/*     */     //   86: aload_0
/*     */     //   87: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   90: dup
/*     */     //   91: aload_1
/*     */     //   92: aload #4
/*     */     //   94: aload_0
/*     */     //   95: aload_2
/*     */     //   96: iconst_1
/*     */     //   97: aload_2
/*     */     //   98: arraylength
/*     */     //   99: invokevirtual resolveConstructorArguments : ([Ljava/lang/Object;II)Ljava/util/List;
/*     */     //   102: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;)V
/*     */     //   105: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   108: goto -> 528
/*     */     //   111: aload_2
/*     */     //   112: iconst_0
/*     */     //   113: aaload
/*     */     //   114: astore #7
/*     */     //   116: aload #7
/*     */     //   118: instanceof org/springframework/beans/factory/config/RuntimeBeanReference
/*     */     //   121: ifeq -> 161
/*     */     //   124: aload #7
/*     */     //   126: checkcast org/springframework/beans/factory/config/RuntimeBeanReference
/*     */     //   129: astore #5
/*     */     //   131: aload_0
/*     */     //   132: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   135: dup
/*     */     //   136: aload_1
/*     */     //   137: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   140: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   143: aload_0
/*     */     //   144: getfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   147: invokevirtual getBeanDefinition : ()Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   150: aload #5
/*     */     //   152: invokevirtual getBeanName : ()Ljava/lang/String;
/*     */     //   155: invokevirtual setFactoryBeanName : (Ljava/lang/String;)V
/*     */     //   158: goto -> 528
/*     */     //   161: aload_2
/*     */     //   162: iconst_0
/*     */     //   163: aaload
/*     */     //   164: astore #7
/*     */     //   166: aload #7
/*     */     //   168: instanceof java/util/Map
/*     */     //   171: ifeq -> 457
/*     */     //   174: aload #7
/*     */     //   176: checkcast java/util/Map
/*     */     //   179: astore #6
/*     */     //   181: aload_2
/*     */     //   182: arraylength
/*     */     //   183: iconst_1
/*     */     //   184: if_icmple -> 311
/*     */     //   187: aload_2
/*     */     //   188: iconst_1
/*     */     //   189: aaload
/*     */     //   190: astore #8
/*     */     //   192: aload #8
/*     */     //   194: instanceof java/lang/Class
/*     */     //   197: ifeq -> 311
/*     */     //   200: aload #8
/*     */     //   202: checkcast java/lang/Class
/*     */     //   205: astore #7
/*     */     //   207: aload_0
/*     */     //   208: aload_2
/*     */     //   209: iconst_2
/*     */     //   210: iload_3
/*     */     //   211: ifeq -> 221
/*     */     //   214: aload_2
/*     */     //   215: arraylength
/*     */     //   216: iconst_1
/*     */     //   217: isub
/*     */     //   218: goto -> 223
/*     */     //   221: aload_2
/*     */     //   222: arraylength
/*     */     //   223: invokevirtual resolveConstructorArguments : ([Ljava/lang/Object;II)Ljava/util/List;
/*     */     //   226: astore #8
/*     */     //   228: aload_0
/*     */     //   229: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   232: dup
/*     */     //   233: aload_1
/*     */     //   234: aload #7
/*     */     //   236: aload #8
/*     */     //   238: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;)V
/*     */     //   241: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   244: aload #6
/*     */     //   246: invokeinterface entrySet : ()Ljava/util/Set;
/*     */     //   251: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   256: astore #9
/*     */     //   258: aload #9
/*     */     //   260: invokeinterface hasNext : ()Z
/*     */     //   265: ifeq -> 308
/*     */     //   268: aload #9
/*     */     //   270: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   275: checkcast java/util/Map$Entry
/*     */     //   278: astore #10
/*     */     //   280: aload #10
/*     */     //   282: invokeinterface getKey : ()Ljava/lang/Object;
/*     */     //   287: checkcast java/lang/String
/*     */     //   290: astore #11
/*     */     //   292: aload_0
/*     */     //   293: aload #11
/*     */     //   295: aload #10
/*     */     //   297: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   302: invokevirtual setProperty : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   305: goto -> 258
/*     */     //   308: goto -> 528
/*     */     //   311: aload_0
/*     */     //   312: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   315: dup
/*     */     //   316: aload_1
/*     */     //   317: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   320: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   323: aload #6
/*     */     //   325: invokeinterface entrySet : ()Ljava/util/Set;
/*     */     //   330: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   335: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   340: checkcast java/util/Map$Entry
/*     */     //   343: astore #8
/*     */     //   345: iload_3
/*     */     //   346: ifeq -> 353
/*     */     //   349: iconst_2
/*     */     //   350: goto -> 354
/*     */     //   353: iconst_1
/*     */     //   354: istore #9
/*     */     //   356: aload_2
/*     */     //   357: arraylength
/*     */     //   358: iload #9
/*     */     //   360: if_icmple -> 402
/*     */     //   363: iload_3
/*     */     //   364: ifeq -> 374
/*     */     //   367: aload_2
/*     */     //   368: arraylength
/*     */     //   369: iconst_1
/*     */     //   370: isub
/*     */     //   371: goto -> 376
/*     */     //   374: aload_2
/*     */     //   375: arraylength
/*     */     //   376: istore #10
/*     */     //   378: aload_0
/*     */     //   379: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   382: dup
/*     */     //   383: aload_1
/*     */     //   384: aconst_null
/*     */     //   385: aload_0
/*     */     //   386: aload_2
/*     */     //   387: iconst_1
/*     */     //   388: iload #10
/*     */     //   390: invokevirtual resolveConstructorArguments : ([Ljava/lang/Object;II)Ljava/util/List;
/*     */     //   393: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;)V
/*     */     //   396: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   399: goto -> 414
/*     */     //   402: aload_0
/*     */     //   403: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   406: dup
/*     */     //   407: aload_1
/*     */     //   408: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   411: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   414: aload_0
/*     */     //   415: getfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   418: invokevirtual getBeanDefinition : ()Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   421: aload #8
/*     */     //   423: invokeinterface getKey : ()Ljava/lang/Object;
/*     */     //   428: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   431: invokevirtual setFactoryBeanName : (Ljava/lang/String;)V
/*     */     //   434: aload_0
/*     */     //   435: getfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   438: invokevirtual getBeanDefinition : ()Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   441: aload #8
/*     */     //   443: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   448: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   451: invokevirtual setFactoryMethodName : (Ljava/lang/String;)V
/*     */     //   454: goto -> 528
/*     */     //   457: aload_2
/*     */     //   458: iconst_0
/*     */     //   459: aaload
/*     */     //   460: instanceof groovy/lang/Closure
/*     */     //   463: ifeq -> 492
/*     */     //   466: aload_0
/*     */     //   467: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   470: dup
/*     */     //   471: aload_1
/*     */     //   472: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   475: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   478: aload_0
/*     */     //   479: getfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   482: invokevirtual getBeanDefinition : ()Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   485: iconst_1
/*     */     //   486: invokevirtual setAbstract : (Z)V
/*     */     //   489: goto -> 528
/*     */     //   492: aload_0
/*     */     //   493: aload_2
/*     */     //   494: iconst_0
/*     */     //   495: iload_3
/*     */     //   496: ifeq -> 506
/*     */     //   499: aload_2
/*     */     //   500: arraylength
/*     */     //   501: iconst_1
/*     */     //   502: isub
/*     */     //   503: goto -> 508
/*     */     //   506: aload_2
/*     */     //   507: arraylength
/*     */     //   508: invokevirtual resolveConstructorArguments : ([Ljava/lang/Object;II)Ljava/util/List;
/*     */     //   511: astore #7
/*     */     //   513: aload_0
/*     */     //   514: new org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   517: dup
/*     */     //   518: aload_1
/*     */     //   519: aconst_null
/*     */     //   520: aload #7
/*     */     //   522: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;)V
/*     */     //   525: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   528: iload_3
/*     */     //   529: ifeq -> 565
/*     */     //   532: aload_2
/*     */     //   533: aload_2
/*     */     //   534: arraylength
/*     */     //   535: iconst_1
/*     */     //   536: isub
/*     */     //   537: aaload
/*     */     //   538: checkcast groovy/lang/Closure
/*     */     //   541: astore #4
/*     */     //   543: aload #4
/*     */     //   545: aload_0
/*     */     //   546: invokevirtual setDelegate : (Ljava/lang/Object;)V
/*     */     //   549: aload #4
/*     */     //   551: iconst_1
/*     */     //   552: invokevirtual setResolveStrategy : (I)V
/*     */     //   555: aload #4
/*     */     //   557: aload_0
/*     */     //   558: getfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   561: invokevirtual call : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   564: pop
/*     */     //   565: aload_0
/*     */     //   566: getfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   569: astore #4
/*     */     //   571: aload_0
/*     */     //   572: aconst_null
/*     */     //   573: putfield currentBeanDefinition : Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   576: aload #4
/*     */     //   578: invokevirtual getBeanDefinition : ()Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   581: ldc org/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper
/*     */     //   583: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   586: aload #4
/*     */     //   588: invokevirtual setAttribute : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   591: aload_0
/*     */     //   592: invokevirtual getRegistry : ()Lorg/springframework/beans/factory/support/BeanDefinitionRegistry;
/*     */     //   595: aload_1
/*     */     //   596: aload #4
/*     */     //   598: invokevirtual getBeanDefinition : ()Lorg/springframework/beans/factory/support/AbstractBeanDefinition;
/*     */     //   601: invokeinterface registerBeanDefinition : (Ljava/lang/String;Lorg/springframework/beans/factory/config/BeanDefinition;)V
/*     */     //   606: aload #4
/*     */     //   608: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #471	-> 0
/*     */     //   #472	-> 10
/*     */     //   #473	-> 30
/*     */     //   #474	-> 34
/*     */     //   #475	-> 42
/*     */     //   #476	-> 57
/*     */     //   #479	-> 69
/*     */     //   #483	-> 86
/*     */     //   #484	-> 99
/*     */     //   #487	-> 111
/*     */     //   #488	-> 131
/*     */     //   #489	-> 143
/*     */     //   #491	-> 161
/*     */     //   #493	-> 181
/*     */     //   #494	-> 207
/*     */     //   #495	-> 210
/*     */     //   #496	-> 228
/*     */     //   #497	-> 244
/*     */     //   #498	-> 280
/*     */     //   #499	-> 292
/*     */     //   #500	-> 305
/*     */     //   #501	-> 308
/*     */     //   #504	-> 311
/*     */     //   #506	-> 323
/*     */     //   #509	-> 345
/*     */     //   #511	-> 356
/*     */     //   #513	-> 363
/*     */     //   #514	-> 378
/*     */     //   #515	-> 390
/*     */     //   #516	-> 399
/*     */     //   #518	-> 402
/*     */     //   #520	-> 414
/*     */     //   #521	-> 434
/*     */     //   #522	-> 454
/*     */     //   #525	-> 457
/*     */     //   #526	-> 466
/*     */     //   #527	-> 478
/*     */     //   #530	-> 492
/*     */     //   #531	-> 495
/*     */     //   #532	-> 513
/*     */     //   #535	-> 528
/*     */     //   #536	-> 532
/*     */     //   #537	-> 543
/*     */     //   #538	-> 549
/*     */     //   #539	-> 555
/*     */     //   #542	-> 565
/*     */     //   #543	-> 571
/*     */     //   #544	-> 576
/*     */     //   #545	-> 591
/*     */     //   #546	-> 606
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   30	81	4	beanClass	Ljava/lang/Class;
/*     */     //   131	30	5	runtimeBeanReference	Lorg/springframework/beans/factory/config/RuntimeBeanReference;
/*     */     //   292	13	11	propName	Ljava/lang/String;
/*     */     //   280	25	10	entity	Ljava/util/Map$Entry;
/*     */     //   228	80	8	constructorArgs	Ljava/util/List;
/*     */     //   207	104	7	clazz	Ljava/lang/Class;
/*     */     //   378	21	10	endOfConstructArgs	I
/*     */     //   345	109	8	factoryBeanEntry	Ljava/util/Map$Entry;
/*     */     //   356	98	9	constructorArgsTest	I
/*     */     //   181	276	6	namedArgs	Ljava/util/Map;
/*     */     //   513	15	7	constructorArgs	Ljava/util/List;
/*     */     //   543	22	4	callable	Lgroovy/lang/Closure;
/*     */     //   0	609	0	this	Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionReader;
/*     */     //   0	609	1	beanName	Ljava/lang/String;
/*     */     //   0	609	2	args	[Ljava/lang/Object;
/*     */     //   10	599	3	hasClosureArgument	Z
/*     */     //   571	38	4	beanDefinition	Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   30	81	4	beanClass	Ljava/lang/Class<*>;
/*     */     //   280	25	10	entity	Ljava/util/Map$Entry<**>;
/*     */     //   228	80	8	constructorArgs	Ljava/util/List<Ljava/lang/Object;>;
/*     */     //   207	104	7	clazz	Ljava/lang/Class<*>;
/*     */     //   345	109	8	factoryBeanEntry	Ljava/util/Map$Entry<**>;
/*     */     //   181	276	6	namedArgs	Ljava/util/Map<**>;
/*     */     //   513	15	7	constructorArgs	Ljava/util/List<Ljava/lang/Object;>;
/*     */     //   543	22	4	callable	Lgroovy/lang/Closure<*>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Object> resolveConstructorArguments(Object[] args, int start, int end) {
/* 550 */     Object[] constructorArgs = Arrays.copyOfRange(args, start, end);
/* 551 */     for (int i = 0; i < constructorArgs.length; i++) {
/* 552 */       if (constructorArgs[i] instanceof groovy.lang.GString) {
/* 553 */         constructorArgs[i] = constructorArgs[i].toString();
/*     */       } else {
/* 555 */         Object object = constructorArgs[i]; if (object instanceof List) { List<?> list = (List)object;
/* 556 */           constructorArgs[i] = manageListIfNecessary(list); }
/*     */         else
/* 558 */         { object = constructorArgs[i]; if (object instanceof Map) { Map<?, ?> map = (Map<?, ?>)object;
/* 559 */             constructorArgs[i] = manageMapIfNecessary(map); }  }
/*     */       
/*     */       } 
/* 562 */     }  return List.of(constructorArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object manageMapIfNecessary(Map<?, ?> map) {
/* 572 */     boolean containsRuntimeRefs = false;
/* 573 */     for (Object element : map.values()) {
/* 574 */       if (element instanceof RuntimeBeanReference) {
/* 575 */         containsRuntimeRefs = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 579 */     if (containsRuntimeRefs) {
/* 580 */       ManagedMap<?, ?> managedMap = new ManagedMap();
/* 581 */       managedMap.putAll(map);
/* 582 */       return managedMap;
/*     */     } 
/* 584 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object manageListIfNecessary(List<?> list) {
/* 594 */     boolean containsRuntimeRefs = false;
/* 595 */     for (Object element : list) {
/* 596 */       if (element instanceof RuntimeBeanReference) {
/* 597 */         containsRuntimeRefs = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 601 */     if (containsRuntimeRefs) {
/* 602 */       ManagedList<?> managedList = new ManagedList();
/* 603 */       managedList.addAll(list);
/* 604 */       return managedList;
/*     */     } 
/* 606 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) {
/* 615 */     if (this.currentBeanDefinition != null) {
/* 616 */       applyPropertyToBeanDefinition(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void applyPropertyToBeanDefinition(String name, Object value) {
/* 621 */     if (value instanceof groovy.lang.GString) {
/* 622 */       value = value.toString();
/*     */     }
/* 624 */     if (addDeferredProperty(name, value)) {
/*     */       return;
/*     */     }
/* 627 */     if (value instanceof Closure) { Closure<?> callable = (Closure)value;
/* 628 */       GroovyBeanDefinitionWrapper current = this.currentBeanDefinition;
/*     */       try {
/* 630 */         Class<?> parameterType = callable.getParameterTypes()[0];
/* 631 */         if (Object.class == parameterType) {
/* 632 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper("");
/* 633 */           callable.call(this.currentBeanDefinition);
/*     */         } else {
/*     */           
/* 636 */           this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(null, parameterType);
/* 637 */           callable.call(null);
/*     */         } 
/*     */         
/* 640 */         value = this.currentBeanDefinition.getBeanDefinition();
/*     */       } finally {
/*     */         
/* 643 */         this.currentBeanDefinition = current;
/*     */       }  }
/*     */     
/* 646 */     Assert.state((this.currentBeanDefinition != null), "No current bean definition set");
/* 647 */     this.currentBeanDefinition.addProperty(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(String name) {
/* 663 */     Binding binding = getBinding();
/* 664 */     if (binding != null && binding.hasVariable(name)) {
/* 665 */       return binding.getVariable(name);
/*     */     }
/*     */     
/* 668 */     if (this.namespaces.containsKey(name)) {
/* 669 */       return createDynamicElementReader(name);
/*     */     }
/* 671 */     if (getRegistry().containsBeanDefinition(name)) {
/*     */       
/* 673 */       GroovyBeanDefinitionWrapper beanDefinition = (GroovyBeanDefinitionWrapper)getRegistry().getBeanDefinition(name).getAttribute(GroovyBeanDefinitionWrapper.class.getName());
/* 674 */       if (beanDefinition != null) {
/* 675 */         return new GroovyRuntimeBeanReference(name, beanDefinition, false);
/*     */       }
/*     */       
/* 678 */       return new RuntimeBeanReference(name, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 683 */     if (this.currentBeanDefinition != null) {
/* 684 */       MutablePropertyValues pvs = this.currentBeanDefinition.getBeanDefinition().getPropertyValues();
/* 685 */       if (pvs.contains(name)) {
/* 686 */         return pvs.get(name);
/*     */       }
/*     */       
/* 689 */       DeferredProperty dp = this.deferredProperties.get(this.currentBeanDefinition.getBeanName() + this.currentBeanDefinition.getBeanName());
/* 690 */       if (dp != null) {
/* 691 */         return dp.value;
/*     */       }
/*     */       
/* 694 */       return getMetaClass().getProperty(this, name);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 699 */     return getMetaClass().getProperty(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GroovyDynamicElementReader createDynamicElementReader(String namespace) {
/* 706 */     XmlReaderContext readerContext = this.groovyDslXmlBeanDefinitionReader.createReaderContext((Resource)new DescriptiveResource("Groovy"));
/*     */     
/* 708 */     BeanDefinitionParserDelegate delegate = new BeanDefinitionParserDelegate(readerContext);
/* 709 */     boolean decorating = (this.currentBeanDefinition != null);
/* 710 */     if (!decorating) {
/* 711 */       this.currentBeanDefinition = new GroovyBeanDefinitionWrapper(namespace);
/*     */     }
/* 713 */     return new GroovyDynamicElementReader(namespace, this.namespaces, delegate, this.currentBeanDefinition, decorating)
/*     */       {
/*     */         protected void afterInvocation() {
/* 716 */           if (!this.decorating) {
/* 717 */             GroovyBeanDefinitionReader.this.currentBeanDefinition = null;
/*     */           }
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DeferredProperty
/*     */   {
/*     */     private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object value;
/*     */ 
/*     */ 
/*     */     
/*     */     public DeferredProperty(GroovyBeanDefinitionWrapper beanDefinition, String name, @Nullable Object value) {
/* 740 */       this.beanDefinition = beanDefinition;
/* 741 */       this.name = name;
/* 742 */       this.value = value;
/*     */     }
/*     */     
/*     */     public void apply() {
/* 746 */       this.beanDefinition.addProperty(this.name, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class GroovyRuntimeBeanReference
/*     */     extends RuntimeBeanReference
/*     */     implements GroovyObject
/*     */   {
/*     */     private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */     
/*     */     private MetaClass metaClass;
/*     */ 
/*     */     
/*     */     public GroovyRuntimeBeanReference(String beanName, GroovyBeanDefinitionWrapper beanDefinition, boolean toParent) {
/* 761 */       super(beanName, toParent);
/* 762 */       this.beanDefinition = beanDefinition;
/* 763 */       this.metaClass = InvokerHelper.getMetaClass(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public MetaClass getMetaClass() {
/* 768 */       return this.metaClass;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getProperty(String property) {
/* 774 */       if (property.equals("beanName")) {
/* 775 */         return getBeanName();
/*     */       }
/* 777 */       if (property.equals("source")) {
/* 778 */         return getSource();
/*     */       }
/*     */       
/* 781 */       return new GroovyPropertyValue(property, this.beanDefinition
/* 782 */           .getBeanDefinition().getPropertyValues().get(property));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object invokeMethod(String name, Object args) {
/* 788 */       return this.metaClass.invokeMethod(this, name, args);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setMetaClass(MetaClass metaClass) {
/* 793 */       this.metaClass = metaClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setProperty(String property, Object newValue) {
/* 798 */       if (!GroovyBeanDefinitionReader.this.addDeferredProperty(property, newValue)) {
/* 799 */         this.beanDefinition.getBeanDefinition().getPropertyValues().add(property, newValue);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private class GroovyPropertyValue
/*     */       extends GroovyObjectSupport
/*     */     {
/*     */       private final String propertyName;
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       private final Object propertyValue;
/*     */ 
/*     */       
/*     */       public GroovyPropertyValue(@Nullable String propertyName, Object propertyValue) {
/* 816 */         this.propertyName = propertyName;
/* 817 */         this.propertyValue = propertyValue;
/*     */       }
/*     */ 
/*     */       
/*     */       public void leftShift(Object value) {
/* 822 */         InvokerHelper.invokeMethod(this.propertyValue, "leftShift", value);
/* 823 */         updateDeferredProperties(value);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean add(Object value) {
/* 828 */         boolean retVal = ((Boolean)InvokerHelper.invokeMethod(this.propertyValue, "add", value)).booleanValue();
/* 829 */         updateDeferredProperties(value);
/* 830 */         return retVal;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean addAll(Collection<?> values) {
/* 835 */         boolean retVal = ((Boolean)InvokerHelper.invokeMethod(this.propertyValue, "addAll", values)).booleanValue();
/* 836 */         for (Object value : values) {
/* 837 */           updateDeferredProperties(value);
/*     */         }
/* 839 */         return retVal;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object invokeMethod(String name, Object args) {
/* 844 */         return InvokerHelper.invokeMethod(this.propertyValue, name, args);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getProperty(String name) {
/* 849 */         return InvokerHelper.getProperty(this.propertyValue, name);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setProperty(String name, Object value) {
/* 854 */         InvokerHelper.setProperty(this.propertyValue, name, value);
/*     */       }
/*     */       
/*     */       private void updateDeferredProperties(Object value) {
/* 858 */         if (value instanceof RuntimeBeanReference)
/* 859 */           GroovyBeanDefinitionReader.this.deferredProperties.put(GroovyBeanDefinitionReader.GroovyRuntimeBeanReference.this.beanDefinition.getBeanName(), new GroovyBeanDefinitionReader.DeferredProperty(GroovyBeanDefinitionReader.GroovyRuntimeBeanReference.this.beanDefinition, this.propertyName, this.propertyValue));  } } } private class GroovyPropertyValue extends GroovyObjectSupport { private void updateDeferredProperties(Object value) { if (value instanceof RuntimeBeanReference) GroovyBeanDefinitionReader.this.deferredProperties.put(this.this$1.beanDefinition.getBeanName(), new GroovyBeanDefinitionReader.DeferredProperty(this.this$1.beanDefinition, this.propertyName, this.propertyValue));  }
/*     */ 
/*     */     
/*     */     private final String propertyName;
/*     */     @Nullable
/*     */     private final Object propertyValue;
/*     */     
/*     */     public GroovyPropertyValue(@Nullable String propertyName, Object propertyValue) {
/*     */       this.propertyName = propertyName;
/*     */       this.propertyValue = propertyValue;
/*     */     }
/*     */     
/*     */     public void leftShift(Object value) {
/*     */       InvokerHelper.invokeMethod(this.propertyValue, "leftShift", value);
/*     */       updateDeferredProperties(value);
/*     */     }
/*     */     
/*     */     public boolean add(Object value) {
/*     */       boolean retVal = ((Boolean)InvokerHelper.invokeMethod(this.propertyValue, "add", value)).booleanValue();
/*     */       updateDeferredProperties(value);
/*     */       return retVal;
/*     */     }
/*     */     
/*     */     public boolean addAll(Collection<?> values) {
/*     */       boolean retVal = ((Boolean)InvokerHelper.invokeMethod(this.propertyValue, "addAll", values)).booleanValue();
/*     */       for (Object value : values)
/*     */         updateDeferredProperties(value); 
/*     */       return retVal;
/*     */     }
/*     */     
/*     */     public Object invokeMethod(String name, Object args) {
/*     */       return InvokerHelper.invokeMethod(this.propertyValue, name, args);
/*     */     }
/*     */     
/*     */     public Object getProperty(String name) {
/*     */       return InvokerHelper.getProperty(this.propertyValue, name);
/*     */     }
/*     */     
/*     */     public void setProperty(String name, Object value) {
/*     */       InvokerHelper.setProperty(this.propertyValue, name, value);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\groovy\GroovyBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */