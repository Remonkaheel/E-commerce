/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.xml.StreamingMarkupBuilder;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends Closure<Object>
/*     */ {
/*     */   null(Object owner) {
/*  94 */     super(owner);
/*     */   }
/*     */   public Object call(Object... arguments) {
/*  97 */     ((GroovyObject)getProperty("mkp")).invokeMethod("declareNamespace", new Object[] { this.val$myNamespaces });
/*  98 */     int len = args.length;
/*  99 */     if (len > 0) { Object object = args[len - 1]; if (object instanceof Closure) { Closure<?> callable = (Closure)object;
/* 100 */         callable.setResolveStrategy(1);
/* 101 */         callable.setDelegate(builder); }
/*     */        }
/* 103 */      return ((GroovyObject)((GroovyObject)getDelegate()).getProperty(myNamespace)).invokeMethod(name, args);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\groovy\GroovyDynamicElementReader$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */