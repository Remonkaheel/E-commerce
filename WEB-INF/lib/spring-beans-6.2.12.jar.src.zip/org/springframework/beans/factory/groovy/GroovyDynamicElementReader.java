/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import groovy.lang.Writable;
/*     */ import groovy.xml.StreamingMarkupBuilder;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GroovyDynamicElementReader
/*     */   extends GroovyObjectSupport
/*     */ {
/*     */   private final String rootNamespace;
/*     */   private final Map<String, String> xmlNamespaces;
/*     */   private final BeanDefinitionParserDelegate delegate;
/*     */   private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */   protected final boolean decorating;
/*     */   private boolean callAfterInvocation = true;
/*     */   
/*     */   public GroovyDynamicElementReader(String namespace, Map<String, String> namespaceMap, BeanDefinitionParserDelegate delegate, GroovyBeanDefinitionWrapper beanDefinition, boolean decorating) {
/*  63 */     this.rootNamespace = namespace;
/*  64 */     this.xmlNamespaces = namespaceMap;
/*  65 */     this.delegate = delegate;
/*  66 */     this.beanDefinition = beanDefinition;
/*  67 */     this.decorating = decorating;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invokeMethod(final String name, Object obj) {
/*  74 */     final Object[] args = (Object[])obj;
/*  75 */     if (name.equals("doCall")) {
/*     */       
/*  77 */       Closure<Object> closure = (Closure<Object>)args[0];
/*  78 */       closure.setResolveStrategy(1);
/*  79 */       closure.setDelegate(this);
/*  80 */       Object result = closure.call();
/*     */       
/*  82 */       if (this.callAfterInvocation) {
/*  83 */         afterInvocation();
/*  84 */         this.callAfterInvocation = false;
/*     */       } 
/*  86 */       return result;
/*     */     } 
/*     */     
/*  89 */     final StreamingMarkupBuilder builder = new StreamingMarkupBuilder();
/*  90 */     final String myNamespace = this.rootNamespace;
/*  91 */     final Map<String, String> myNamespaces = this.xmlNamespaces;
/*     */ 
/*     */     
/*  94 */     Closure<Object> callable = new Closure<Object>(this)
/*     */       {
/*     */         public Object call(Object... arguments) {
/*  97 */           ((GroovyObject)getProperty("mkp")).invokeMethod("declareNamespace", new Object[] { this.val$myNamespaces });
/*  98 */           int len = args.length;
/*  99 */           if (len > 0) { Object object = args[len - 1]; if (object instanceof Closure) { Closure<?> callable = (Closure)object;
/* 100 */               callable.setResolveStrategy(1);
/* 101 */               callable.setDelegate(builder); }
/*     */              }
/* 103 */            return ((GroovyObject)((GroovyObject)getDelegate()).getProperty(myNamespace)).invokeMethod(name, args);
/*     */         }
/*     */       };
/*     */     
/* 107 */     callable.setResolveStrategy(1);
/* 108 */     callable.setDelegate(builder);
/* 109 */     Writable writable = (Writable)builder.bind(callable);
/* 110 */     StringWriter sw = new StringWriter();
/*     */     try {
/* 112 */       writable.writeTo(sw);
/*     */     }
/* 114 */     catch (IOException ex) {
/* 115 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */     
/* 118 */     Element element = this.delegate.getReaderContext().readDocumentFromString(sw.toString()).getDocumentElement();
/* 119 */     this.delegate.initDefaults(element);
/* 120 */     if (this.decorating) {
/* 121 */       BeanDefinitionHolder holder = this.beanDefinition.getBeanDefinitionHolder();
/* 122 */       holder = this.delegate.decorateIfRequired(element, holder, null);
/* 123 */       this.beanDefinition.setBeanDefinitionHolder(holder);
/*     */     } else {
/*     */       
/* 126 */       BeanDefinition beanDefinition = this.delegate.parseCustomElement(element);
/* 127 */       if (beanDefinition != null) {
/* 128 */         this.beanDefinition.setBeanDefinition((AbstractBeanDefinition)beanDefinition);
/*     */       }
/*     */     } 
/* 131 */     if (this.callAfterInvocation) {
/* 132 */       afterInvocation();
/* 133 */       this.callAfterInvocation = false;
/*     */     } 
/* 135 */     return element;
/*     */   }
/*     */   
/*     */   protected void afterInvocation() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\groovy\GroovyDynamicElementReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */