package org.springframework.beans.factory;

import org.springframework.beans.BeansException;

public interface BeanFactoryAware extends Aware {
  void setBeanFactory(BeanFactory paramBeanFactory) throws BeansException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\BeanFactoryAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */