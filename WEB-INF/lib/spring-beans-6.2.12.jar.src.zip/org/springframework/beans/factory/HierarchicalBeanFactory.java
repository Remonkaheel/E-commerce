package org.springframework.beans.factory;

import org.springframework.lang.Nullable;

public interface HierarchicalBeanFactory extends BeanFactory {
  @Nullable
  BeanFactory getParentBeanFactory();
  
  boolean containsLocalBean(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\HierarchicalBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */