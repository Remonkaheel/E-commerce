/*    */ package org.springframework.beans.factory.config;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeBeanNameReference
/*    */   implements BeanReference
/*    */ {
/*    */   private final String beanName;
/*    */   @Nullable
/*    */   private Object source;
/*    */   
/*    */   public RuntimeBeanNameReference(String beanName) {
/* 45 */     Assert.hasText(beanName, "'beanName' must not be empty");
/* 46 */     this.beanName = beanName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getBeanName() {
/* 51 */     return this.beanName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSource(@Nullable Object source) {
/* 59 */     this.source = source;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getSource() {
/* 65 */     return this.source;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 71 */     if (this != other) { if (other instanceof RuntimeBeanNameReference) { RuntimeBeanNameReference that = (RuntimeBeanNameReference)other; if (this.beanName
/* 72 */           .equals(that.beanName)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 77 */     return this.beanName.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return "<" + getBeanName() + ">";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\RuntimeBeanNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */