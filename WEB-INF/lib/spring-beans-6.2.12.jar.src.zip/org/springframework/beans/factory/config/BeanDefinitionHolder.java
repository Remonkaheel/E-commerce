/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanDefinitionHolder
/*     */   implements BeanMetadataElement
/*     */ {
/*     */   private final BeanDefinition beanDefinition;
/*     */   private final String beanName;
/*     */   @Nullable
/*     */   private final String[] aliases;
/*     */   
/*     */   public BeanDefinitionHolder(BeanDefinition beanDefinition, String beanName) {
/*  56 */     this(beanDefinition, beanName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionHolder(BeanDefinition beanDefinition, String beanName, @Nullable String[] aliases) {
/*  66 */     Assert.notNull(beanDefinition, "BeanDefinition must not be null");
/*  67 */     Assert.notNull(beanName, "Bean name must not be null");
/*  68 */     this.beanDefinition = beanDefinition;
/*  69 */     this.beanName = beanName;
/*  70 */     this.aliases = aliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionHolder(BeanDefinitionHolder beanDefinitionHolder) {
/*  81 */     Assert.notNull(beanDefinitionHolder, "BeanDefinitionHolder must not be null");
/*  82 */     this.beanDefinition = beanDefinitionHolder.getBeanDefinition();
/*  83 */     this.beanName = beanDefinitionHolder.getBeanName();
/*  84 */     this.aliases = beanDefinitionHolder.getAliases();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition getBeanDefinition() {
/*  92 */     return this.beanDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBeanName() {
/*  99 */     return this.beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getAliases() {
/* 108 */     return this.aliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/* 118 */     return this.beanDefinition.getSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesName(@Nullable String candidateName) {
/* 126 */     return (candidateName != null && (candidateName.equals(this.beanName) || candidateName
/* 127 */       .equals(BeanFactoryUtils.transformedBeanName(this.beanName)) || 
/* 128 */       ObjectUtils.containsElement((Object[])this.aliases, candidateName)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getShortDescription() {
/* 138 */     return (this.aliases == null) ? ("Bean definition with name '" + 
/* 139 */       this.beanName + "'") : ("Bean definition with name '" + 
/*     */       
/* 141 */       this.beanName + "' and aliases [" + StringUtils.arrayToCommaDelimitedString((Object[])this.aliases) + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLongDescription() {
/* 151 */     return getShortDescription() + ": " + getShortDescription();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return getLongDescription();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 168 */     if (this != other) { if (other instanceof BeanDefinitionHolder) { BeanDefinitionHolder that = (BeanDefinitionHolder)other; if (this.beanDefinition
/* 169 */           .equals(that.beanDefinition) && this.beanName
/* 170 */           .equals(that.beanName) && 
/* 171 */           ObjectUtils.nullSafeEquals(this.aliases, that.aliases)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 176 */     return ObjectUtils.nullSafeHash(new Object[] { this.beanDefinition, this.beanName, this.aliases });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\BeanDefinitionHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */