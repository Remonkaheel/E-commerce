package org.springframework.beans.factory.config;

import java.util.Iterator;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.lang.Nullable;

public interface ConfigurableListableBeanFactory extends ListableBeanFactory, AutowireCapableBeanFactory, ConfigurableBeanFactory {
  void ignoreDependencyType(Class<?> paramClass);
  
  void ignoreDependencyInterface(Class<?> paramClass);
  
  void registerResolvableDependency(Class<?> paramClass, @Nullable Object paramObject);
  
  boolean isAutowireCandidate(String paramString, DependencyDescriptor paramDependencyDescriptor) throws NoSuchBeanDefinitionException;
  
  BeanDefinition getBeanDefinition(String paramString) throws NoSuchBeanDefinitionException;
  
  Iterator<String> getBeanNamesIterator();
  
  void clearMetadataCache();
  
  void freezeConfiguration();
  
  boolean isConfigurationFrozen();
  
  default void prepareSingletonBootstrap() {}
  
  void preInstantiateSingletons() throws BeansException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\ConfigurableListableBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */