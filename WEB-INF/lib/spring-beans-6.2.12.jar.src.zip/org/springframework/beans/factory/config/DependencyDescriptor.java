/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import kotlin.reflect.KProperty;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DependencyDescriptor
/*     */   extends InjectionPoint
/*     */   implements Serializable
/*     */ {
/*     */   private final Class<?> declaringClass;
/*     */   @Nullable
/*     */   private String methodName;
/*     */   @Nullable
/*     */   private Class<?>[] parameterTypes;
/*     */   private int parameterIndex;
/*     */   @Nullable
/*     */   private String fieldName;
/*     */   private final boolean required;
/*     */   private final boolean eager;
/*  70 */   private int nestingLevel = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Class<?> containingClass;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile transient ResolvableType resolvableType;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile transient TypeDescriptor typeDescriptor;
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyDescriptor(MethodParameter methodParameter, boolean required) {
/*  89 */     this(methodParameter, required, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyDescriptor(MethodParameter methodParameter, boolean required, boolean eager) {
/* 100 */     super(methodParameter);
/*     */     
/* 102 */     this.declaringClass = methodParameter.getDeclaringClass();
/* 103 */     if (methodParameter.getMethod() != null) {
/* 104 */       this.methodName = methodParameter.getMethod().getName();
/*     */     }
/* 106 */     this.parameterTypes = methodParameter.getExecutable().getParameterTypes();
/* 107 */     this.parameterIndex = methodParameter.getParameterIndex();
/* 108 */     this.containingClass = methodParameter.getContainingClass();
/* 109 */     this.required = required;
/* 110 */     this.eager = eager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyDescriptor(Field field, boolean required) {
/* 120 */     this(field, required, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyDescriptor(Field field, boolean required, boolean eager) {
/* 131 */     super(field);
/*     */     
/* 133 */     this.declaringClass = field.getDeclaringClass();
/* 134 */     this.fieldName = field.getName();
/* 135 */     this.required = required;
/* 136 */     this.eager = eager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyDescriptor(DependencyDescriptor original) {
/* 144 */     super(original);
/*     */     
/* 146 */     this.declaringClass = original.declaringClass;
/* 147 */     this.methodName = original.methodName;
/* 148 */     this.parameterTypes = original.parameterTypes;
/* 149 */     this.parameterIndex = original.parameterIndex;
/* 150 */     this.fieldName = original.fieldName;
/* 151 */     this.required = original.required;
/* 152 */     this.eager = original.eager;
/* 153 */     this.nestingLevel = original.nestingLevel;
/* 154 */     this.containingClass = original.containingClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequired() {
/* 166 */     if (!this.required) {
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     if (this.field != null) {
/* 171 */       return (this.field.getType() != Optional.class && !hasNullableAnnotation() && (
/* 172 */         !KotlinDetector.isKotlinReflectPresent() || 
/* 173 */         !KotlinDetector.isKotlinType(this.field.getDeclaringClass()) || 
/* 174 */         !KotlinDelegate.isNullable(this.field)));
/*     */     }
/*     */     
/* 177 */     return !obtainMethodParameter().isOptional();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasNullableAnnotation() {
/* 187 */     for (Annotation ann : getAnnotations()) {
/* 188 */       if ("Nullable".equals(ann.annotationType().getSimpleName())) {
/* 189 */         return true;
/*     */       }
/*     */     } 
/* 192 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEager() {
/* 200 */     return this.eager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveNotUnique(ResolvableType type, Map<String, Object> matchingBeans) throws BeansException {
/* 218 */     throw new NoUniqueBeanDefinitionException(type, matchingBeans.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object resolveShortcut(BeanFactory beanFactory) throws BeansException {
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolveCandidate(String beanName, Class<?> requiredType, BeanFactory beanFactory) throws BeansException {
/* 254 */     return beanFactory.getBean(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void increaseNestingLevel() {
/* 262 */     this.nestingLevel++;
/* 263 */     this.resolvableType = null;
/* 264 */     if (this.methodParameter != null) {
/* 265 */       this.methodParameter = this.methodParameter.nested();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainingClass(Class<?> containingClass) {
/* 276 */     this.containingClass = containingClass;
/* 277 */     this.resolvableType = null;
/* 278 */     if (this.methodParameter != null) {
/* 279 */       this.methodParameter = this.methodParameter.withContainingClass(containingClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvableType getResolvableType() {
/* 288 */     ResolvableType resolvableType = this.resolvableType;
/* 289 */     if (resolvableType == null) {
/*     */ 
/*     */       
/* 292 */       resolvableType = (this.field != null) ? ResolvableType.forField(this.field, this.nestingLevel, this.containingClass) : ResolvableType.forMethodParameter(obtainMethodParameter());
/* 293 */       this.resolvableType = resolvableType;
/*     */     } 
/* 295 */     return resolvableType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescriptor getTypeDescriptor() {
/* 303 */     TypeDescriptor typeDescriptor = this.typeDescriptor;
/* 304 */     if (typeDescriptor == null) {
/*     */ 
/*     */       
/* 307 */       typeDescriptor = (this.field != null) ? new TypeDescriptor(getResolvableType(), getDependencyType(), getAnnotations()) : new TypeDescriptor(obtainMethodParameter());
/* 308 */       this.typeDescriptor = typeDescriptor;
/*     */     } 
/* 310 */     return typeDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean fallbackMatchAllowed() {
/* 321 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependencyDescriptor forFallbackMatch() {
/* 330 */     return new DependencyDescriptor(this)
/*     */       {
/*     */         public boolean fallbackMatchAllowed() {
/* 333 */           return true;
/*     */         }
/*     */         
/*     */         public boolean usesStandardBeanLookup() {
/* 337 */           return true;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initParameterNameDiscovery(@Nullable ParameterNameDiscoverer parameterNameDiscoverer) {
/* 349 */     if (this.methodParameter != null) {
/* 350 */       this.methodParameter.initParameterNameDiscovery(parameterNameDiscoverer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getDependencyName() {
/* 360 */     return (this.field != null) ? this.field.getName() : obtainMethodParameter().getParameterName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDependencyType() {
/* 368 */     if (this.field != null) {
/* 369 */       if (this.nestingLevel > 1) {
/* 370 */         Class<?> clazz = getResolvableType().getRawClass();
/* 371 */         return (clazz != null) ? clazz : Object.class;
/*     */       } 
/*     */       
/* 374 */       return this.field.getType();
/*     */     } 
/*     */ 
/*     */     
/* 378 */     return obtainMethodParameter().getNestedParameterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsLazyResolution() {
/* 389 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesStandardBeanLookup() {
/* 404 */     return (getClass() == DependencyDescriptor.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: if_acmpne -> 7
/*     */     //   5: iconst_1
/*     */     //   6: ireturn
/*     */     //   7: aload_0
/*     */     //   8: aload_1
/*     */     //   9: invokespecial equals : (Ljava/lang/Object;)Z
/*     */     //   12: ifne -> 17
/*     */     //   15: iconst_0
/*     */     //   16: ireturn
/*     */     //   17: aload_1
/*     */     //   18: instanceof org/springframework/beans/factory/config/DependencyDescriptor
/*     */     //   21: ifeq -> 77
/*     */     //   24: aload_1
/*     */     //   25: checkcast org/springframework/beans/factory/config/DependencyDescriptor
/*     */     //   28: astore_2
/*     */     //   29: aload_0
/*     */     //   30: getfield required : Z
/*     */     //   33: aload_2
/*     */     //   34: getfield required : Z
/*     */     //   37: if_icmpne -> 77
/*     */     //   40: aload_0
/*     */     //   41: getfield eager : Z
/*     */     //   44: aload_2
/*     */     //   45: getfield eager : Z
/*     */     //   48: if_icmpne -> 77
/*     */     //   51: aload_0
/*     */     //   52: getfield nestingLevel : I
/*     */     //   55: aload_2
/*     */     //   56: getfield nestingLevel : I
/*     */     //   59: if_icmpne -> 77
/*     */     //   62: aload_0
/*     */     //   63: getfield containingClass : Ljava/lang/Class;
/*     */     //   66: aload_2
/*     */     //   67: getfield containingClass : Ljava/lang/Class;
/*     */     //   70: if_acmpne -> 77
/*     */     //   73: iconst_1
/*     */     //   74: goto -> 78
/*     */     //   77: iconst_0
/*     */     //   78: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #410	-> 0
/*     */     //   #411	-> 5
/*     */     //   #413	-> 7
/*     */     //   #414	-> 15
/*     */     //   #417	-> 17
/*     */     //   #416	-> 24
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   29	48	2	otherDesc	Lorg/springframework/beans/factory/config/DependencyDescriptor;
/*     */     //   0	79	0	this	Lorg/springframework/beans/factory/config/DependencyDescriptor;
/*     */     //   0	79	1	other	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 423 */     return 31 * super.hashCode() + ObjectUtils.nullSafeHashCode(this.containingClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 433 */     ois.defaultReadObject();
/*     */ 
/*     */     
/*     */     try {
/* 437 */       if (this.fieldName != null) {
/* 438 */         this.field = this.declaringClass.getDeclaredField(this.fieldName);
/*     */       } else {
/*     */         
/* 441 */         if (this.methodName != null) {
/* 442 */           this
/* 443 */             .methodParameter = new MethodParameter(this.declaringClass.getDeclaredMethod(this.methodName, this.parameterTypes), this.parameterIndex);
/*     */         } else {
/*     */           
/* 446 */           this
/* 447 */             .methodParameter = new MethodParameter(this.declaringClass.getDeclaredConstructor(this.parameterTypes), this.parameterIndex);
/*     */         } 
/* 449 */         for (int i = 1; i < this.nestingLevel; i++) {
/* 450 */           this.methodParameter = this.methodParameter.nested();
/*     */         }
/*     */       }
/*     */     
/* 454 */     } catch (Throwable ex) {
/* 455 */       throw new IllegalStateException("Could not find original class structure", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     public static boolean isNullable(Field field) {
/* 469 */       KProperty<?> property = ReflectJvmMapping.getKotlinProperty(field);
/* 470 */       return (property != null && property.getReturnType().isMarkedNullable());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\DependencyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */