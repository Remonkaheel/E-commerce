package org.springframework.beans.factory.config;

import org.springframework.beans.BeanMetadataElement;

public interface BeanReference extends BeanMetadataElement {
  String getBeanName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\BeanReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */