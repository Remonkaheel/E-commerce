/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFactoryBean<T>
/*     */   implements FactoryBean<T>, BeanClassLoaderAware, BeanFactoryAware, InitializingBean, DisposableBean
/*     */ {
/*  67 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private boolean singleton = true;
/*     */   
/*     */   @Nullable
/*  72 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private T singletonInstance;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private T earlySingletonInstance;
/*     */ 
/*     */   
/*     */   public void setSingleton(boolean singleton) {
/*  91 */     this.singleton = singleton;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/*  96 */     return this.singleton;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 101 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(@Nullable BeanFactory beanFactory) {
/* 106 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected BeanFactory getBeanFactory() {
/* 114 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeConverter getBeanTypeConverter() {
/* 126 */     BeanFactory beanFactory = getBeanFactory();
/* 127 */     if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/* 128 */       return cbf.getTypeConverter(); }
/*     */ 
/*     */     
/* 131 */     return (TypeConverter)new SimpleTypeConverter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 140 */     if (isSingleton()) {
/* 141 */       this.initialized = true;
/* 142 */       this.singletonInstance = createInstance();
/* 143 */       this.earlySingletonInstance = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getObject() throws Exception {
/* 156 */     if (isSingleton()) {
/* 157 */       return this.initialized ? this.singletonInstance : getEarlySingletonInstance();
/*     */     }
/*     */     
/* 160 */     return createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private T getEarlySingletonInstance() throws Exception {
/* 170 */     Class<?>[] ifcs = getEarlySingletonInterfaces();
/* 171 */     if (ifcs == null) {
/* 172 */       throw new FactoryBeanNotInitializedException(
/* 173 */           getClass().getName() + " does not support circular references");
/*     */     }
/* 175 */     if (this.earlySingletonInstance == null) {
/* 176 */       this.earlySingletonInstance = (T)Proxy.newProxyInstance(this.beanClassLoader, ifcs, new EarlySingletonInvocationHandler());
/*     */     }
/*     */     
/* 179 */     return this.earlySingletonInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private T getSingletonInstance() throws IllegalStateException {
/* 189 */     Assert.state(this.initialized, "Singleton instance not initialized yet");
/* 190 */     return this.singletonInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/* 199 */     if (isSingleton()) {
/* 200 */       destroyInstance(this.singletonInstance);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public abstract Class<?> getObjectType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T createInstance() throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?>[] getEarlySingletonInterfaces() {
/* 239 */     Class<?> type = getObjectType();
/* 240 */     (new Class[1])[0] = type; return (type != null && type.isInterface()) ? new Class[1] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroyInstance(@Nullable T instance) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class EarlySingletonInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 263 */       if (ReflectionUtils.isEqualsMethod(method))
/*     */       {
/* 265 */         return Boolean.valueOf((proxy == args[0]));
/*     */       }
/* 267 */       if (ReflectionUtils.isHashCodeMethod(method))
/*     */       {
/* 269 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 271 */       if (!AbstractFactoryBean.this.initialized && ReflectionUtils.isToStringMethod(method))
/*     */       {
/* 273 */         return "Early singleton proxy for interfaces " + ObjectUtils.nullSafeToString((Object[])AbstractFactoryBean.this.getEarlySingletonInterfaces());
/*     */       }
/*     */       try {
/* 276 */         return method.invoke(AbstractFactoryBean.this.getSingletonInstance(), args);
/*     */       }
/* 278 */       catch (InvocationTargetException ex) {
/* 279 */         throw ex.getTargetException();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\AbstractFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */