/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyOverrideConfigurer
/*     */   extends PropertyResourceConfigurer
/*     */ {
/*     */   public static final String DEFAULT_BEAN_NAME_SEPARATOR = ".";
/*  74 */   private String beanNameSeparator = ".";
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ignoreInvalidKeys = false;
/*     */ 
/*     */   
/*  81 */   private final Set<String> beanNames = ConcurrentHashMap.newKeySet(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanNameSeparator(String beanNameSeparator) {
/*  89 */     this.beanNameSeparator = beanNameSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreInvalidKeys(boolean ignoreInvalidKeys) {
/*  99 */     this.ignoreInvalidKeys = ignoreInvalidKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props) throws BeansException {
/* 107 */     for (Enumeration<?> names = props.propertyNames(); names.hasMoreElements(); ) {
/* 108 */       String key = (String)names.nextElement();
/*     */       try {
/* 110 */         processKey(beanFactory, key, props.getProperty(key));
/*     */       }
/* 112 */       catch (BeansException ex) {
/* 113 */         String msg = "Could not process key '" + key + "' in PropertyOverrideConfigurer";
/* 114 */         if (!this.ignoreInvalidKeys) {
/* 115 */           throw new BeanInitializationException(msg, ex);
/*     */         }
/* 117 */         if (this.logger.isDebugEnabled()) {
/* 118 */           this.logger.debug(msg, (Throwable)ex);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processKey(ConfigurableListableBeanFactory factory, String key, String value) throws BeansException {
/* 130 */     int separatorIndex = key.indexOf(this.beanNameSeparator);
/* 131 */     if (separatorIndex == -1) {
/* 132 */       throw new BeanInitializationException("Invalid key '" + key + "': expected 'beanName" + this.beanNameSeparator + "property'");
/*     */     }
/*     */     
/* 135 */     String beanName = key.substring(0, separatorIndex);
/* 136 */     String beanProperty = key.substring(separatorIndex + 1);
/* 137 */     this.beanNames.add(beanName);
/* 138 */     applyPropertyValue(factory, beanName, beanProperty, value);
/* 139 */     if (this.logger.isDebugEnabled()) {
/* 140 */       this.logger.debug("Property '" + key + "' set to value [" + value + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyPropertyValue(ConfigurableListableBeanFactory factory, String beanName, String property, String value) {
/* 150 */     BeanDefinition bd = factory.getBeanDefinition(beanName);
/* 151 */     BeanDefinition bdToUse = bd;
/* 152 */     while (bd != null) {
/* 153 */       bdToUse = bd;
/* 154 */       bd = bd.getOriginatingBeanDefinition();
/*     */     } 
/* 156 */     PropertyValue pv = new PropertyValue(property, value);
/* 157 */     pv.setOptional(this.ignoreInvalidKeys);
/* 158 */     bdToUse.getPropertyValues().addPropertyValue(pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPropertyOverridesFor(String beanName) {
/* 169 */     return this.beanNames.contains(beanName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\PropertyOverrideConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */