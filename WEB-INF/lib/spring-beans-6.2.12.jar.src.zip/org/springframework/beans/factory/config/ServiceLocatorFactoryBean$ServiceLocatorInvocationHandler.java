/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServiceLocatorInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 356 */     if (ReflectionUtils.isEqualsMethod(method))
/*     */     {
/* 358 */       return Boolean.valueOf((proxy == args[0]));
/*     */     }
/* 360 */     if (ReflectionUtils.isHashCodeMethod(method))
/*     */     {
/* 362 */       return Integer.valueOf(System.identityHashCode(proxy));
/*     */     }
/* 364 */     if (ReflectionUtils.isToStringMethod(method)) {
/* 365 */       return "Service locator: " + String.valueOf(ServiceLocatorFactoryBean.this.serviceLocatorInterface);
/*     */     }
/*     */     
/* 368 */     return invokeServiceLocatorMethod(method, args);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object invokeServiceLocatorMethod(Method method, Object[] args) throws Exception {
/* 373 */     Class<?> serviceLocatorMethodReturnType = getServiceLocatorMethodReturnType(method);
/*     */     try {
/* 375 */       String beanName = tryGetBeanName(args);
/* 376 */       Assert.state((ServiceLocatorFactoryBean.this.beanFactory != null), "No BeanFactory available");
/* 377 */       if (StringUtils.hasLength(beanName))
/*     */       {
/* 379 */         return ServiceLocatorFactoryBean.this.beanFactory.getBean(beanName, serviceLocatorMethodReturnType);
/*     */       }
/*     */ 
/*     */       
/* 383 */       return ServiceLocatorFactoryBean.this.beanFactory.getBean(serviceLocatorMethodReturnType);
/*     */     
/*     */     }
/* 386 */     catch (BeansException ex) {
/* 387 */       if (ServiceLocatorFactoryBean.this.serviceLocatorExceptionConstructor != null) {
/* 388 */         throw ServiceLocatorFactoryBean.this.createServiceLocatorException(ServiceLocatorFactoryBean.this.serviceLocatorExceptionConstructor, ex);
/*     */       }
/* 390 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String tryGetBeanName(@Nullable Object[] args) {
/* 398 */     String beanName = "";
/* 399 */     if (args != null && args.length == 1 && args[0] != null) {
/* 400 */       beanName = args[0].toString();
/*     */     }
/*     */     
/* 403 */     if (ServiceLocatorFactoryBean.this.serviceMappings != null) {
/* 404 */       String mappedName = ServiceLocatorFactoryBean.this.serviceMappings.getProperty(beanName);
/* 405 */       if (mappedName != null) {
/* 406 */         beanName = mappedName;
/*     */       }
/*     */     } 
/* 409 */     return beanName;
/*     */   }
/*     */   
/*     */   private Class<?> getServiceLocatorMethodReturnType(Method method) throws NoSuchMethodException {
/* 413 */     Assert.state((ServiceLocatorFactoryBean.this.serviceLocatorInterface != null), "No service locator interface specified");
/* 414 */     Class<?>[] paramTypes = method.getParameterTypes();
/* 415 */     Method interfaceMethod = ServiceLocatorFactoryBean.this.serviceLocatorInterface.getMethod(method.getName(), paramTypes);
/* 416 */     Class<?> serviceLocatorReturnType = interfaceMethod.getReturnType();
/*     */ 
/*     */     
/* 419 */     if (paramTypes.length > 1 || void.class == serviceLocatorReturnType) {
/* 420 */       throw new UnsupportedOperationException("May only call methods with signature '<type> xxx()' or '<type> xxx(<idtype> id)' on factory interface, but tried to call: " + String.valueOf(interfaceMethod));
/*     */     }
/*     */ 
/*     */     
/* 424 */     return serviceLocatorReturnType;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\ServiceLocatorFactoryBean$ServiceLocatorInvocationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */