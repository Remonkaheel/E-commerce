/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanDefinitionVisitor
/*     */ {
/*     */   @Nullable
/*     */   private StringValueResolver valueResolver;
/*     */   
/*     */   public BeanDefinitionVisitor(StringValueResolver valueResolver) {
/*  60 */     Assert.notNull(valueResolver, "StringValueResolver must not be null");
/*  61 */     this.valueResolver = valueResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanDefinitionVisitor() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitBeanDefinition(BeanDefinition beanDefinition) {
/*  79 */     visitParentName(beanDefinition);
/*  80 */     visitBeanClassName(beanDefinition);
/*  81 */     visitFactoryBeanName(beanDefinition);
/*  82 */     visitFactoryMethodName(beanDefinition);
/*  83 */     visitScope(beanDefinition);
/*  84 */     if (beanDefinition.hasPropertyValues()) {
/*  85 */       visitPropertyValues(beanDefinition.getPropertyValues());
/*     */     }
/*  87 */     if (beanDefinition.hasConstructorArgumentValues()) {
/*  88 */       ConstructorArgumentValues cas = beanDefinition.getConstructorArgumentValues();
/*  89 */       visitIndexedArgumentValues(cas.getIndexedArgumentValues());
/*  90 */       visitGenericArgumentValues(cas.getGenericArgumentValues());
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitParentName(BeanDefinition beanDefinition) {
/*  95 */     String parentName = beanDefinition.getParentName();
/*  96 */     if (parentName != null) {
/*  97 */       String resolvedName = resolveStringValue(parentName);
/*  98 */       if (!parentName.equals(resolvedName)) {
/*  99 */         beanDefinition.setParentName(resolvedName);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitBeanClassName(BeanDefinition beanDefinition) {
/* 105 */     String beanClassName = beanDefinition.getBeanClassName();
/* 106 */     if (beanClassName != null) {
/* 107 */       String resolvedName = resolveStringValue(beanClassName);
/* 108 */       if (!beanClassName.equals(resolvedName)) {
/* 109 */         beanDefinition.setBeanClassName(resolvedName);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitFactoryBeanName(BeanDefinition beanDefinition) {
/* 115 */     String factoryBeanName = beanDefinition.getFactoryBeanName();
/* 116 */     if (factoryBeanName != null) {
/* 117 */       String resolvedName = resolveStringValue(factoryBeanName);
/* 118 */       if (!factoryBeanName.equals(resolvedName)) {
/* 119 */         beanDefinition.setFactoryBeanName(resolvedName);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitFactoryMethodName(BeanDefinition beanDefinition) {
/* 125 */     String factoryMethodName = beanDefinition.getFactoryMethodName();
/* 126 */     if (factoryMethodName != null) {
/* 127 */       String resolvedName = resolveStringValue(factoryMethodName);
/* 128 */       if (!factoryMethodName.equals(resolvedName)) {
/* 129 */         beanDefinition.setFactoryMethodName(resolvedName);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitScope(BeanDefinition beanDefinition) {
/* 135 */     String scope = beanDefinition.getScope();
/* 136 */     if (scope != null) {
/* 137 */       String resolvedScope = resolveStringValue(scope);
/* 138 */       if (!scope.equals(resolvedScope)) {
/* 139 */         beanDefinition.setScope(resolvedScope);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitPropertyValues(MutablePropertyValues pvs) {
/* 145 */     PropertyValue[] pvArray = pvs.getPropertyValues();
/* 146 */     for (PropertyValue pv : pvArray) {
/* 147 */       Object newVal = resolveValue(pv.getValue());
/* 148 */       if (!ObjectUtils.nullSafeEquals(newVal, pv.getValue())) {
/* 149 */         pvs.add(pv.getName(), newVal);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitIndexedArgumentValues(Map<Integer, ConstructorArgumentValues.ValueHolder> ias) {
/* 155 */     for (ConstructorArgumentValues.ValueHolder valueHolder : ias.values()) {
/* 156 */       Object newVal = resolveValue(valueHolder.getValue());
/* 157 */       if (!ObjectUtils.nullSafeEquals(newVal, valueHolder.getValue())) {
/* 158 */         valueHolder.setValue(newVal);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void visitGenericArgumentValues(List<ConstructorArgumentValues.ValueHolder> gas) {
/* 164 */     for (ConstructorArgumentValues.ValueHolder valueHolder : gas) {
/* 165 */       Object newVal = resolveValue(valueHolder.getValue());
/* 166 */       if (!ObjectUtils.nullSafeEquals(newVal, valueHolder.getValue())) {
/* 167 */         valueHolder.setValue(newVal);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object resolveValue(@Nullable Object value) {
/* 175 */     if (value instanceof BeanDefinition) { BeanDefinition beanDef = (BeanDefinition)value;
/* 176 */       visitBeanDefinition(beanDef); }
/*     */     
/* 178 */     else if (value instanceof BeanDefinitionHolder) { BeanDefinitionHolder beanDefHolder = (BeanDefinitionHolder)value;
/* 179 */       visitBeanDefinition(beanDefHolder.getBeanDefinition()); }
/*     */     
/* 181 */     else if (value instanceof RuntimeBeanReference) { RuntimeBeanReference ref = (RuntimeBeanReference)value;
/* 182 */       String newBeanName = resolveStringValue(ref.getBeanName());
/* 183 */       if (newBeanName == null) {
/* 184 */         return null;
/*     */       }
/* 186 */       if (!newBeanName.equals(ref.getBeanName())) {
/* 187 */         return new RuntimeBeanReference(newBeanName);
/*     */       } }
/*     */     
/* 190 */     else if (value instanceof RuntimeBeanNameReference) { RuntimeBeanNameReference ref = (RuntimeBeanNameReference)value;
/* 191 */       String newBeanName = resolveStringValue(ref.getBeanName());
/* 192 */       if (newBeanName == null) {
/* 193 */         return null;
/*     */       }
/* 195 */       if (!newBeanName.equals(ref.getBeanName())) {
/* 196 */         return new RuntimeBeanNameReference(newBeanName);
/*     */       } }
/*     */     
/* 199 */     else if (value instanceof Object[]) { Object[] array = (Object[])value;
/* 200 */       visitArray(array); }
/*     */     
/* 202 */     else if (value instanceof List) { List list = (List)value;
/* 203 */       visitList(list); }
/*     */     
/* 205 */     else if (value instanceof Set) { Set set = (Set)value;
/* 206 */       visitSet(set); }
/*     */     
/* 208 */     else if (value instanceof Map) { Map<?, ?> map = (Map)value;
/* 209 */       visitMap(map); }
/*     */     
/* 211 */     else if (value instanceof TypedStringValue) { TypedStringValue typedStringValue = (TypedStringValue)value;
/* 212 */       String stringValue = typedStringValue.getValue();
/* 213 */       if (stringValue != null) {
/* 214 */         String visitedString = resolveStringValue(stringValue);
/* 215 */         typedStringValue.setValue(visitedString);
/*     */       }
/*     */        }
/* 218 */     else if (value instanceof String) { String strValue = (String)value;
/* 219 */       return resolveStringValue(strValue); }
/*     */     
/* 221 */     return value;
/*     */   }
/*     */   
/*     */   protected void visitArray(Object[] arrayVal) {
/* 225 */     for (int i = 0; i < arrayVal.length; i++) {
/* 226 */       Object elem = arrayVal[i];
/* 227 */       Object newVal = resolveValue(elem);
/* 228 */       if (!ObjectUtils.nullSafeEquals(newVal, elem)) {
/* 229 */         arrayVal[i] = newVal;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void visitList(List<Object> listVal) {
/* 236 */     for (int i = 0; i < listVal.size(); i++) {
/* 237 */       Object elem = listVal.get(i);
/* 238 */       Object newVal = resolveValue(elem);
/* 239 */       if (!ObjectUtils.nullSafeEquals(newVal, elem)) {
/* 240 */         listVal.set(i, newVal);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void visitSet(Set<Object> setVal) {
/* 247 */     Set<Object> newContent = new LinkedHashSet();
/* 248 */     boolean entriesModified = false;
/* 249 */     for (Object elem : setVal) {
/* 250 */       int elemHash = (elem != null) ? elem.hashCode() : 0;
/* 251 */       Object newVal = resolveValue(elem);
/* 252 */       int newValHash = (newVal != null) ? newVal.hashCode() : 0;
/* 253 */       newContent.add(newVal);
/* 254 */       entriesModified = (entriesModified || newVal != elem || newValHash != elemHash);
/*     */     } 
/* 256 */     if (entriesModified) {
/* 257 */       setVal.clear();
/* 258 */       setVal.addAll(newContent);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void visitMap(Map<?, ?> mapVal) {
/* 264 */     Map<Object, Object> newContent = new LinkedHashMap<>();
/* 265 */     boolean entriesModified = false;
/* 266 */     for (Map.Entry<?, ?> entry : mapVal.entrySet()) {
/* 267 */       Object key = entry.getKey();
/* 268 */       int keyHash = (key != null) ? key.hashCode() : 0;
/* 269 */       Object newKey = resolveValue(key);
/* 270 */       int newKeyHash = (newKey != null) ? newKey.hashCode() : 0;
/* 271 */       Object val = entry.getValue();
/* 272 */       Object newVal = resolveValue(val);
/* 273 */       newContent.put(newKey, newVal);
/* 274 */       entriesModified = (entriesModified || newVal != val || newKey != key || newKeyHash != keyHash);
/*     */     } 
/* 276 */     if (entriesModified) {
/* 277 */       mapVal.clear();
/* 278 */       mapVal.putAll(newContent);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveStringValue(String strVal) {
/* 289 */     if (this.valueResolver == null) {
/* 290 */       throw new IllegalStateException("No StringValueResolver specified - pass a resolver object into the constructor or override the 'resolveStringValue' method");
/*     */     }
/*     */     
/* 293 */     String resolvedValue = this.valueResolver.resolveStringValue(strVal);
/*     */     
/* 295 */     return strVal.equals(resolvedValue) ? strVal : resolvedValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\BeanDefinitionVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */