/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.Yaml;
/*     */ import org.yaml.snakeyaml.constructor.BaseConstructor;
/*     */ import org.yaml.snakeyaml.constructor.Constructor;
/*     */ import org.yaml.snakeyaml.inspector.TagInspector;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.reader.UnicodeReader;
/*     */ import org.yaml.snakeyaml.representer.Representer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class YamlProcessor
/*     */ {
/*  63 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  65 */   private ResolutionMethod resolutionMethod = ResolutionMethod.OVERRIDE;
/*     */   
/*  67 */   private Resource[] resources = new Resource[0];
/*     */   
/*  69 */   private List<DocumentMatcher> documentMatchers = Collections.emptyList();
/*     */   
/*     */   private boolean matchDefault = true;
/*     */   
/*  73 */   private Set<String> supportedTypes = Collections.emptySet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentMatchers(DocumentMatcher... matchers) {
/* 103 */     this.documentMatchers = List.of(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchDefault(boolean matchDefault) {
/* 112 */     this.matchDefault = matchDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolutionMethod(ResolutionMethod resolutionMethod) {
/* 121 */     Assert.notNull(resolutionMethod, "ResolutionMethod must not be null");
/* 122 */     this.resolutionMethod = resolutionMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResources(Resource... resources) {
/* 130 */     this.resources = resources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedTypes(Class<?>... supportedTypes) {
/* 146 */     if (ObjectUtils.isEmpty((Object[])supportedTypes)) {
/* 147 */       this.supportedTypes = Collections.emptySet();
/*     */     } else {
/*     */       
/* 150 */       Assert.noNullElements((Object[])supportedTypes, "'supportedTypes' must not contain null elements");
/* 151 */       this
/* 152 */         .supportedTypes = (Set<String>)Arrays.<Class<?>>stream(supportedTypes).map(Class::getName).collect(Collectors.toUnmodifiableSet());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void process(MatchCallback callback) {
/* 167 */     Yaml yaml = createYaml();
/* 168 */     for (Resource resource : this.resources) {
/* 169 */       boolean found = process(callback, yaml, resource);
/* 170 */       if (this.resolutionMethod == ResolutionMethod.FIRST_FOUND && found) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Yaml createYaml() {
/* 188 */     LoaderOptions loaderOptions = new LoaderOptions();
/* 189 */     loaderOptions.setAllowDuplicateKeys(false);
/* 190 */     loaderOptions.setTagInspector(new SupportedTagInspector());
/* 191 */     DumperOptions dumperOptions = new DumperOptions();
/* 192 */     return new Yaml((BaseConstructor)new Constructor(loaderOptions), new Representer(dumperOptions), dumperOptions, loaderOptions);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean process(MatchCallback callback, Yaml yaml, Resource resource) {
/* 197 */     int count = 0;
/*     */     try {
/* 199 */       if (this.logger.isDebugEnabled()) {
/* 200 */         this.logger.debug("Loading from YAML: " + String.valueOf(resource));
/*     */       }
/* 202 */       UnicodeReader unicodeReader = new UnicodeReader(resource.getInputStream()); 
/* 203 */       try { for (Object object : yaml.loadAll((Reader)unicodeReader)) {
/* 204 */           if (object != null && process(asMap(object), callback)) {
/* 205 */             count++;
/* 206 */             if (this.resolutionMethod == ResolutionMethod.FIRST_FOUND) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */         } 
/* 211 */         if (this.logger.isDebugEnabled()) {
/* 212 */           this.logger.debug("Loaded " + count + " document" + ((count > 1) ? "s" : "") + " from YAML resource: " + String.valueOf(resource));
/*     */         }
/*     */         
/* 215 */         unicodeReader.close(); } catch (Throwable throwable) { try { unicodeReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */     
/* 217 */     } catch (IOException ex) {
/* 218 */       handleProcessError(resource, ex);
/*     */     } 
/* 220 */     return (count > 0);
/*     */   }
/*     */   
/*     */   private void handleProcessError(Resource resource, IOException ex) {
/* 224 */     if (this.resolutionMethod != ResolutionMethod.FIRST_FOUND && this.resolutionMethod != ResolutionMethod.OVERRIDE_AND_IGNORE)
/*     */     {
/* 226 */       throw new IllegalStateException(ex);
/*     */     }
/* 228 */     if (this.logger.isWarnEnabled()) {
/* 229 */       this.logger.warn("Could not load map from " + String.valueOf(resource) + ": " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, Object> asMap(Object object) {
/*     */     Map map;
/* 236 */     Map<String, Object> result = new LinkedHashMap<>();
/* 237 */     if (object instanceof Map) { map = (Map)object; }
/*     */     else
/* 239 */     { result.put("document", object);
/* 240 */       return result; }
/*     */ 
/*     */     
/* 243 */     map.forEach((key, value) -> {
/*     */           if (value instanceof Map) {
/*     */             value = (Object<String, Object>)asMap(value);
/*     */           }
/*     */           
/*     */           if (key instanceof CharSequence) {
/*     */             result.put(key.toString(), value);
/*     */           } else {
/*     */             result.put("[" + key.toString() + "]", value);
/*     */           } 
/*     */         });
/*     */     
/* 255 */     return result;
/*     */   }
/*     */   
/*     */   private boolean process(Map<String, Object> map, MatchCallback callback) {
/* 259 */     Properties properties = CollectionFactory.createStringAdaptingProperties();
/* 260 */     properties.putAll(getFlattenedMap(map));
/*     */     
/* 262 */     if (this.documentMatchers.isEmpty()) {
/* 263 */       if (this.logger.isDebugEnabled()) {
/* 264 */         this.logger.debug("Merging document (no matchers set): " + String.valueOf(map));
/*     */       }
/* 266 */       callback.process(properties, map);
/* 267 */       return true;
/*     */     } 
/*     */     
/* 270 */     MatchStatus result = MatchStatus.ABSTAIN;
/* 271 */     for (DocumentMatcher matcher : this.documentMatchers) {
/* 272 */       MatchStatus match = matcher.matches(properties);
/* 273 */       result = MatchStatus.getMostSpecific(match, result);
/* 274 */       if (match == MatchStatus.FOUND) {
/* 275 */         if (this.logger.isDebugEnabled()) {
/* 276 */           this.logger.debug("Matched document with document matcher: " + String.valueOf(properties));
/*     */         }
/* 278 */         callback.process(properties, map);
/* 279 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 283 */     if (result == MatchStatus.ABSTAIN && this.matchDefault) {
/* 284 */       if (this.logger.isDebugEnabled()) {
/* 285 */         this.logger.debug("Matched document with default matcher: " + String.valueOf(map));
/*     */       }
/* 287 */       callback.process(properties, map);
/* 288 */       return true;
/*     */     } 
/*     */     
/* 291 */     if (this.logger.isDebugEnabled()) {
/* 292 */       this.logger.debug("Unmatched document: " + String.valueOf(map));
/*     */     }
/* 294 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Map<String, Object> getFlattenedMap(Map<String, Object> source) {
/* 307 */     Map<String, Object> result = new LinkedHashMap<>();
/* 308 */     buildFlattenedMap(result, source, null);
/* 309 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildFlattenedMap(Map<String, Object> result, Map<String, Object> source, @Nullable String path) {
/* 314 */     source.forEach((key, value) -> {
/*     */           if (StringUtils.hasText(path)) {
/*     */             if (key.startsWith("[")) {
/*     */               key = path + path;
/*     */             } else {
/*     */               key = path + "." + path;
/*     */             } 
/*     */           }
/*     */           if (value instanceof String) {
/*     */             result.put(key, value);
/*     */           } else if (value instanceof Map) {
/*     */             Map<String, Object> map = (Map)value;
/*     */             buildFlattenedMap(result, map, key);
/*     */           } else if (value instanceof Collection) {
/*     */             Collection collection = (Collection)value;
/*     */             if (collection.isEmpty()) {
/*     */               result.put(key, "");
/*     */             } else {
/*     */               int count = 0;
/*     */               for (Object object : collection) {
/*     */                 buildFlattenedMap(result, Collections.singletonMap("[" + count++ + "]", object), key);
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             result.put(key, (value != null) ? value : "");
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MatchStatus
/*     */   {
/* 390 */     FOUND,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 395 */     NOT_FOUND,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     ABSTAIN;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MatchStatus getMostSpecific(MatchStatus a, MatchStatus b) {
/* 406 */       return (a.ordinal() < b.ordinal()) ? a : b;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ResolutionMethod
/*     */   {
/* 419 */     OVERRIDE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 424 */     OVERRIDE_AND_IGNORE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 429 */     FIRST_FOUND;
/*     */   }
/*     */   
/*     */   private class SupportedTagInspector
/*     */     implements TagInspector
/*     */   {
/*     */     public boolean isGlobalTagAllowed(Tag tag) {
/* 436 */       return YamlProcessor.this.supportedTypes.contains(tag.getClassName());
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface MatchCallback {
/*     */     void process(Properties param1Properties, Map<String, Object> param1Map);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface DocumentMatcher {
/*     */     YamlProcessor.MatchStatus matches(Properties param1Properties);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\YamlProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */