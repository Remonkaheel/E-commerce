package org.springframework.beans.factory.config;

@FunctionalInterface
public interface BeanDefinitionCustomizer {
  void customize(BeanDefinition paramBeanDefinition);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\BeanDefinitionCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */