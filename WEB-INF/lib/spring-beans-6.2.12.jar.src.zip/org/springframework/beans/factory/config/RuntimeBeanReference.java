/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeBeanReference
/*     */   implements BeanReference
/*     */ {
/*     */   private final String beanName;
/*     */   @Nullable
/*     */   private final Class<?> beanType;
/*     */   private final boolean toParent;
/*     */   @Nullable
/*     */   private Object source;
/*     */   
/*     */   public RuntimeBeanReference(String beanName) {
/*  50 */     this(beanName, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeBeanReference(String beanName, boolean toParent) {
/*  61 */     Assert.hasText(beanName, "'beanName' must not be empty");
/*  62 */     this.beanName = beanName;
/*  63 */     this.beanType = null;
/*  64 */     this.toParent = toParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeBeanReference(Class<?> beanType) {
/*  73 */     this(beanType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuntimeBeanReference(Class<?> beanType, boolean toParent) {
/*  85 */     Assert.notNull(beanType, "'beanType' must not be null");
/*  86 */     this.beanName = beanType.getName();
/*  87 */     this.beanType = beanType;
/*  88 */     this.toParent = toParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBeanName() {
/*  99 */     return this.beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getBeanType() {
/* 108 */     return this.beanType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToParent() {
/* 115 */     return this.toParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(@Nullable Object source) {
/* 123 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/* 129 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 135 */     if (this != other) { if (other instanceof RuntimeBeanReference) { RuntimeBeanReference that = (RuntimeBeanReference)other; if (this.beanName
/* 136 */           .equals(that.beanName) && this.beanType == that.beanType && this.toParent == that.toParent); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   }
/*     */   public int hashCode() {
/* 142 */     int result = this.beanName.hashCode();
/* 143 */     result = 29 * result + (this.toParent ? 1 : 0);
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return "<" + getBeanName() + ">";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\RuntimeBeanReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */