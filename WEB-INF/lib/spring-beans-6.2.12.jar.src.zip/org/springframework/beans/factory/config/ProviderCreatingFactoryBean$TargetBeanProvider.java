/*    */ package org.springframework.beans.factory.config;
/*    */ 
/*    */ import jakarta.inject.Provider;
/*    */ import java.io.Serializable;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TargetBeanProvider
/*    */   implements Provider<Object>, Serializable
/*    */ {
/*    */   private final BeanFactory beanFactory;
/*    */   private final String targetBeanName;
/*    */   
/*    */   public TargetBeanProvider(BeanFactory beanFactory, String targetBeanName) {
/* 93 */     this.beanFactory = beanFactory;
/* 94 */     this.targetBeanName = targetBeanName;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object get() throws BeansException {
/* 99 */     return this.beanFactory.getBean(this.targetBeanName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\ProviderCreatingFactoryBean$TargetBeanProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */