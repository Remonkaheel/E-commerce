/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypedStringValue
/*     */   implements BeanMetadataElement, Comparable<TypedStringValue>
/*     */ {
/*     */   @Nullable
/*     */   private String value;
/*     */   @Nullable
/*     */   private volatile Object targetType;
/*     */   @Nullable
/*     */   private Object source;
/*     */   @Nullable
/*     */   private String specifiedTypeName;
/*     */   private volatile boolean dynamic;
/*     */   
/*     */   public TypedStringValue(@Nullable String value) {
/*  62 */     setValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedStringValue(@Nullable String value, Class<?> targetType) {
/*  72 */     setValue(value);
/*  73 */     setTargetType(targetType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedStringValue(@Nullable String value, String targetTypeName) {
/*  83 */     setValue(value);
/*  84 */     setTargetTypeName(targetTypeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable String value) {
/*  94 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getValue() {
/* 102 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetType(Class<?> targetType) {
/* 111 */     Assert.notNull(targetType, "'targetType' must not be null");
/* 112 */     this.targetType = targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getTargetType() {
/*     */     Class<?> clazz;
/* 119 */     Object targetTypeValue = this.targetType;
/* 120 */     if (targetTypeValue instanceof Class) { clazz = (Class)targetTypeValue; }
/* 121 */     else { throw new IllegalStateException("Typed String value does not carry a resolved target type"); }
/*     */     
/* 123 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetTypeName(@Nullable String targetTypeName) {
/* 130 */     this.targetType = targetTypeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTargetTypeName() {
/* 138 */     Object targetTypeValue = this.targetType;
/* 139 */     if (targetTypeValue instanceof Class) { Class<?> clazz = (Class)targetTypeValue;
/* 140 */       return clazz.getName(); }
/*     */ 
/*     */     
/* 143 */     return (String)targetTypeValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTargetType() {
/* 151 */     return this.targetType instanceof Class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> resolveTargetType(@Nullable ClassLoader classLoader) throws ClassNotFoundException {
/* 164 */     String typeName = getTargetTypeName();
/* 165 */     if (typeName == null) {
/* 166 */       return null;
/*     */     }
/* 168 */     Class<?> resolvedClass = ClassUtils.forName(typeName, classLoader);
/* 169 */     this.targetType = resolvedClass;
/* 170 */     return resolvedClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(@Nullable Object source) {
/* 179 */     this.source = source;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/* 185 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpecifiedTypeName(@Nullable String specifiedTypeName) {
/* 192 */     this.specifiedTypeName = specifiedTypeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSpecifiedTypeName() {
/* 200 */     return this.specifiedTypeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDynamic() {
/* 208 */     this.dynamic = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDynamic() {
/* 215 */     return this.dynamic;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(@Nullable TypedStringValue o) {
/* 220 */     return Comparator.<TypedStringValue, Comparable>comparing(TypedStringValue::getValue).compare(this, o);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 225 */     if (this != other) { if (other instanceof TypedStringValue) { TypedStringValue that = (TypedStringValue)other;
/* 226 */         if (ObjectUtils.nullSafeEquals(this.value, that.value) && 
/* 227 */           ObjectUtils.nullSafeEquals(this.targetType, that.targetType)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 232 */     return ObjectUtils.nullSafeHash(new Object[] { this.value, this.targetType });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 237 */     return "TypedStringValue: value [" + this.value + "], target type [" + String.valueOf(this.targetType) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\TypedStringValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */