package org.springframework.beans.factory.config;

import java.util.Map;
import java.util.Properties;

@FunctionalInterface
public interface MatchCallback {
  void process(Properties paramProperties, Map<String, Object> paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\YamlProcessor$MatchCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */