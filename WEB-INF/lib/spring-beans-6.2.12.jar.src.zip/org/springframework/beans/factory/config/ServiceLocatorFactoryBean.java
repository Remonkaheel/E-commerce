/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceLocatorFactoryBean
/*     */   implements FactoryBean<Object>, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private Class<?> serviceLocatorInterface;
/*     */   @Nullable
/*     */   private Constructor<Exception> serviceLocatorExceptionConstructor;
/*     */   @Nullable
/*     */   private Properties serviceMappings;
/*     */   @Nullable
/*     */   private ListableBeanFactory beanFactory;
/*     */   @Nullable
/*     */   private Object proxy;
/*     */   
/*     */   public void setServiceLocatorInterface(Class<?> interfaceType) {
/* 217 */     this.serviceLocatorInterface = interfaceType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceLocatorExceptionClass(Class<? extends Exception> serviceLocatorExceptionClass) {
/* 233 */     this
/* 234 */       .serviceLocatorExceptionConstructor = determineServiceLocatorExceptionConstructor(serviceLocatorExceptionClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceMappings(Properties serviceMappings) {
/* 248 */     this.serviceMappings = serviceMappings;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*     */     ListableBeanFactory lbf;
/* 253 */     if (beanFactory instanceof ListableBeanFactory) { lbf = (ListableBeanFactory)beanFactory; }
/* 254 */     else { throw new FatalBeanException("ServiceLocatorFactoryBean needs to run in a BeanFactory that is a ListableBeanFactory"); }
/*     */ 
/*     */     
/* 257 */     this.beanFactory = lbf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 262 */     if (this.serviceLocatorInterface == null) {
/* 263 */       throw new IllegalArgumentException("Property 'serviceLocatorInterface' is required");
/*     */     }
/*     */ 
/*     */     
/* 267 */     this.proxy = Proxy.newProxyInstance(this.serviceLocatorInterface
/* 268 */         .getClassLoader(), new Class[] { this.serviceLocatorInterface }, new ServiceLocatorInvocationHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Constructor<Exception> determineServiceLocatorExceptionConstructor(Class<? extends Exception> exceptionClass) {
/*     */     try {
/* 287 */       return (Constructor)exceptionClass.getConstructor(new Class[] { String.class, Throwable.class });
/*     */     }
/* 289 */     catch (NoSuchMethodException ex) {
/*     */       try {
/* 291 */         return (Constructor)exceptionClass.getConstructor(new Class[] { Throwable.class });
/*     */       }
/* 293 */       catch (NoSuchMethodException ex2) {
/*     */         try {
/* 295 */           return (Constructor)exceptionClass.getConstructor(new Class[] { String.class });
/*     */         }
/* 297 */         catch (NoSuchMethodException ex3) {
/* 298 */           throw new IllegalArgumentException("Service locator exception [" + exceptionClass
/* 299 */               .getName() + "] neither has a (String, Throwable) constructor nor a (String) constructor");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Exception createServiceLocatorException(Constructor<Exception> exceptionConstructor, BeansException cause) {
/* 317 */     Class<?>[] paramTypes = exceptionConstructor.getParameterTypes();
/* 318 */     Object[] args = new Object[paramTypes.length];
/* 319 */     for (int i = 0; i < paramTypes.length; i++) {
/* 320 */       if (String.class == paramTypes[i]) {
/* 321 */         args[i] = cause.getMessage();
/*     */       }
/* 323 */       else if (paramTypes[i].isInstance(cause)) {
/* 324 */         args[i] = cause;
/*     */       } 
/*     */     } 
/* 327 */     return (Exception)BeanUtils.instantiateClass(exceptionConstructor, args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject() {
/* 334 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectType() {
/* 340 */     return this.serviceLocatorInterface;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 345 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ServiceLocatorInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 356 */       if (ReflectionUtils.isEqualsMethod(method))
/*     */       {
/* 358 */         return Boolean.valueOf((proxy == args[0]));
/*     */       }
/* 360 */       if (ReflectionUtils.isHashCodeMethod(method))
/*     */       {
/* 362 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 364 */       if (ReflectionUtils.isToStringMethod(method)) {
/* 365 */         return "Service locator: " + String.valueOf(ServiceLocatorFactoryBean.this.serviceLocatorInterface);
/*     */       }
/*     */       
/* 368 */       return invokeServiceLocatorMethod(method, args);
/*     */     }
/*     */ 
/*     */     
/*     */     private Object invokeServiceLocatorMethod(Method method, Object[] args) throws Exception {
/* 373 */       Class<?> serviceLocatorMethodReturnType = getServiceLocatorMethodReturnType(method);
/*     */       try {
/* 375 */         String beanName = tryGetBeanName(args);
/* 376 */         Assert.state((ServiceLocatorFactoryBean.this.beanFactory != null), "No BeanFactory available");
/* 377 */         if (StringUtils.hasLength(beanName))
/*     */         {
/* 379 */           return ServiceLocatorFactoryBean.this.beanFactory.getBean(beanName, serviceLocatorMethodReturnType);
/*     */         }
/*     */ 
/*     */         
/* 383 */         return ServiceLocatorFactoryBean.this.beanFactory.getBean(serviceLocatorMethodReturnType);
/*     */       
/*     */       }
/* 386 */       catch (BeansException ex) {
/* 387 */         if (ServiceLocatorFactoryBean.this.serviceLocatorExceptionConstructor != null) {
/* 388 */           throw ServiceLocatorFactoryBean.this.createServiceLocatorException(ServiceLocatorFactoryBean.this.serviceLocatorExceptionConstructor, ex);
/*     */         }
/* 390 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String tryGetBeanName(@Nullable Object[] args) {
/* 398 */       String beanName = "";
/* 399 */       if (args != null && args.length == 1 && args[0] != null) {
/* 400 */         beanName = args[0].toString();
/*     */       }
/*     */       
/* 403 */       if (ServiceLocatorFactoryBean.this.serviceMappings != null) {
/* 404 */         String mappedName = ServiceLocatorFactoryBean.this.serviceMappings.getProperty(beanName);
/* 405 */         if (mappedName != null) {
/* 406 */           beanName = mappedName;
/*     */         }
/*     */       } 
/* 409 */       return beanName;
/*     */     }
/*     */     
/*     */     private Class<?> getServiceLocatorMethodReturnType(Method method) throws NoSuchMethodException {
/* 413 */       Assert.state((ServiceLocatorFactoryBean.this.serviceLocatorInterface != null), "No service locator interface specified");
/* 414 */       Class<?>[] paramTypes = method.getParameterTypes();
/* 415 */       Method interfaceMethod = ServiceLocatorFactoryBean.this.serviceLocatorInterface.getMethod(method.getName(), paramTypes);
/* 416 */       Class<?> serviceLocatorReturnType = interfaceMethod.getReturnType();
/*     */ 
/*     */       
/* 419 */       if (paramTypes.length > 1 || void.class == serviceLocatorReturnType) {
/* 420 */         throw new UnsupportedOperationException("May only call methods with signature '<type> xxx()' or '<type> xxx(<idtype> id)' on factory interface, but tried to call: " + String.valueOf(interfaceMethod));
/*     */       }
/*     */ 
/*     */       
/* 424 */       return serviceLocatorReturnType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\ServiceLocatorFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */