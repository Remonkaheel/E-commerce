/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PropertyPlaceholderHelper;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class PropertyPlaceholderConfigurer
/*     */   extends PlaceholderConfigurerSupport
/*     */ {
/*     */   public static final int SYSTEM_PROPERTIES_MODE_NEVER = 0;
/*     */   public static final int SYSTEM_PROPERTIES_MODE_FALLBACK = 1;
/*     */   public static final int SYSTEM_PROPERTIES_MODE_OVERRIDE = 2;
/*  81 */   private static final Map<String, Integer> constants = Map.of("SYSTEM_PROPERTIES_MODE_NEVER", 
/*  82 */       Integer.valueOf(0), "SYSTEM_PROPERTIES_MODE_FALLBACK", 
/*  83 */       Integer.valueOf(1), "SYSTEM_PROPERTIES_MODE_OVERRIDE", 
/*  84 */       Integer.valueOf(2));
/*     */ 
/*     */ 
/*     */   
/*  88 */   private int systemPropertiesMode = 1;
/*     */ 
/*     */   
/*  91 */   private boolean searchSystemEnvironment = !SpringProperties.getFlag("spring.getenv.ignore");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSystemPropertiesModeName(String constantName) throws IllegalArgumentException {
/* 101 */     Assert.hasText(constantName, "'constantName' must not be null or blank");
/* 102 */     Integer mode = constants.get(constantName);
/* 103 */     Assert.notNull(mode, "Only system properties mode constants allowed");
/* 104 */     this.systemPropertiesMode = mode.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSystemPropertiesMode(int systemPropertiesMode) {
/* 120 */     this.systemPropertiesMode = systemPropertiesMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchSystemEnvironment(boolean searchSystemEnvironment) {
/* 137 */     this.searchSystemEnvironment = searchSystemEnvironment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolvePlaceholder(String placeholder, Properties props, int systemPropertiesMode) {
/* 158 */     String propVal = null;
/* 159 */     if (systemPropertiesMode == 2) {
/* 160 */       propVal = resolveSystemProperty(placeholder);
/*     */     }
/* 162 */     if (propVal == null) {
/* 163 */       propVal = resolvePlaceholder(placeholder, props);
/*     */     }
/* 165 */     if (propVal == null && systemPropertiesMode == 1) {
/* 166 */       propVal = resolveSystemProperty(placeholder);
/*     */     }
/* 168 */     return propVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolvePlaceholder(String placeholder, Properties props) {
/* 186 */     return props.getProperty(placeholder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String resolveSystemProperty(String key) {
/*     */     try {
/* 201 */       String value = System.getProperty(key);
/* 202 */       if (value == null && this.searchSystemEnvironment) {
/* 203 */         value = System.getenv(key);
/*     */       }
/* 205 */       return value;
/*     */     }
/* 207 */     catch (Throwable ex) {
/* 208 */       if (this.logger.isDebugEnabled()) {
/* 209 */         this.logger.debug("Could not access system property '" + key + "': " + String.valueOf(ex));
/*     */       }
/* 211 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props) throws BeansException {
/* 224 */     StringValueResolver valueResolver = new PlaceholderResolvingStringValueResolver(props);
/* 225 */     doProcessProperties(beanFactoryToProcess, valueResolver);
/*     */   }
/*     */ 
/*     */   
/*     */   private class PlaceholderResolvingStringValueResolver
/*     */     implements StringValueResolver
/*     */   {
/*     */     private final PropertyPlaceholderHelper helper;
/*     */     private final PropertyPlaceholderHelper.PlaceholderResolver resolver;
/*     */     
/*     */     public PlaceholderResolvingStringValueResolver(Properties props) {
/* 236 */       this.helper = new PropertyPlaceholderHelper(PropertyPlaceholderConfigurer.this.placeholderPrefix, PropertyPlaceholderConfigurer.this.placeholderSuffix, PropertyPlaceholderConfigurer.this.valueSeparator, PropertyPlaceholderConfigurer.this.escapeCharacter, PropertyPlaceholderConfigurer.this.ignoreUnresolvablePlaceholders);
/*     */ 
/*     */       
/* 239 */       this.resolver = new PropertyPlaceholderConfigurer.PropertyPlaceholderConfigurerResolver(props);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String resolveStringValue(String strVal) throws BeansException {
/* 245 */       String resolved = this.helper.replacePlaceholders(strVal, this.resolver);
/* 246 */       if (PropertyPlaceholderConfigurer.this.trimValues) {
/* 247 */         resolved = resolved.trim();
/*     */       }
/* 249 */       return resolved.equals(PropertyPlaceholderConfigurer.this.nullValue) ? null : resolved;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class PropertyPlaceholderConfigurerResolver
/*     */     implements PropertyPlaceholderHelper.PlaceholderResolver
/*     */   {
/*     */     private final Properties props;
/*     */     
/*     */     private PropertyPlaceholderConfigurerResolver(Properties props) {
/* 259 */       this.props = props;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String resolvePlaceholder(String placeholderName) {
/* 265 */       return PropertyPlaceholderConfigurer.this.resolvePlaceholder(placeholderName, this.props, PropertyPlaceholderConfigurer.this.systemPropertiesMode);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\PropertyPlaceholderConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */