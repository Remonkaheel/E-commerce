package org.springframework.beans.factory.config;

import org.springframework.beans.BeansException;
import org.springframework.lang.Nullable;

public interface BeanExpressionResolver {
  @Nullable
  Object evaluate(@Nullable String paramString, BeanExpressionContext paramBeanExpressionContext) throws BeansException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\BeanExpressionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */