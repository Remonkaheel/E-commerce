package org.springframework.beans.factory.config;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.lang.Nullable;

public interface Scope {
  Object get(String paramString, ObjectFactory<?> paramObjectFactory);
  
  @Nullable
  Object remove(String paramString);
  
  void registerDestructionCallback(String paramString, Runnable paramRunnable);
  
  @Nullable
  Object resolveContextualObject(String paramString);
  
  @Nullable
  String getConversationId();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\Scope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */