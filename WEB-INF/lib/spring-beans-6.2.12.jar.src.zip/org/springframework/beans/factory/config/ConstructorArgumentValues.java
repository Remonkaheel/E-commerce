/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.Mergeable;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorArgumentValues
/*     */ {
/*  46 */   private final Map<Integer, ValueHolder> indexedArgumentValues = new LinkedHashMap<>();
/*     */   
/*  48 */   private final List<ValueHolder> genericArgumentValues = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstructorArgumentValues(ConstructorArgumentValues original) {
/*  62 */     addArgumentValues(original);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addArgumentValues(@Nullable ConstructorArgumentValues other) {
/*  74 */     if (other != null) {
/*  75 */       other.indexedArgumentValues.forEach((index, argValue) -> addOrMergeIndexedArgumentValue(index, argValue.copy()));
/*     */ 
/*     */       
/*  78 */       other.genericArgumentValues.stream()
/*  79 */         .filter(valueHolder -> !this.genericArgumentValues.contains(valueHolder))
/*  80 */         .forEach(valueHolder -> addOrMergeGenericArgumentValue(valueHolder.copy()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIndexedArgumentValue(int index, @Nullable Object value) {
/*  91 */     addIndexedArgumentValue(index, new ValueHolder(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIndexedArgumentValue(int index, @Nullable Object value, String type) {
/* 101 */     addIndexedArgumentValue(index, new ValueHolder(value, type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIndexedArgumentValue(int index, ValueHolder newValue) {
/* 110 */     Assert.isTrue((index >= 0), "Index must not be negative");
/* 111 */     Assert.notNull(newValue, "ValueHolder must not be null");
/* 112 */     addOrMergeIndexedArgumentValue(Integer.valueOf(index), newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addOrMergeIndexedArgumentValue(Integer key, ValueHolder newValue) {
/* 123 */     ValueHolder currentValue = this.indexedArgumentValues.get(key);
/* 124 */     if (currentValue != null) { Object object = newValue.getValue(); if (object instanceof Mergeable) { Mergeable mergeable = (Mergeable)object;
/* 125 */         if (mergeable.isMergeEnabled())
/* 126 */           newValue.setValue(mergeable.merge(currentValue.getValue()));  }
/*     */        }
/*     */     
/* 129 */     this.indexedArgumentValues.put(key, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasIndexedArgumentValue(int index) {
/* 137 */     return this.indexedArgumentValues.containsKey(Integer.valueOf(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getIndexedArgumentValue(int index, @Nullable Class<?> requiredType) {
/* 149 */     return getIndexedArgumentValue(index, requiredType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getIndexedArgumentValue(int index, @Nullable Class<?> requiredType, @Nullable String requiredName) {
/* 163 */     Assert.isTrue((index >= 0), "Index must not be negative");
/* 164 */     ValueHolder valueHolder = this.indexedArgumentValues.get(Integer.valueOf(index));
/* 165 */     if (valueHolder != null && (valueHolder
/* 166 */       .getType() == null || (requiredType != null && 
/* 167 */       ClassUtils.matchesTypeName(requiredType, valueHolder.getType()))) && (valueHolder
/* 168 */       .getName() == null || (requiredName != null && (requiredName
/* 169 */       .isEmpty() || requiredName.equals(valueHolder.getName()))))) {
/* 170 */       return valueHolder;
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, ValueHolder> getIndexedArgumentValues() {
/* 181 */     return Collections.unmodifiableMap(this.indexedArgumentValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGenericArgumentValue(@Nullable Object value) {
/* 192 */     this.genericArgumentValues.add(new ValueHolder(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGenericArgumentValue(Object value, String type) {
/* 203 */     this.genericArgumentValues.add(new ValueHolder(value, type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGenericArgumentValue(ValueHolder newValue) {
/* 216 */     Assert.notNull(newValue, "ValueHolder must not be null");
/* 217 */     if (!this.genericArgumentValues.contains(newValue)) {
/* 218 */       addOrMergeGenericArgumentValue(newValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addOrMergeGenericArgumentValue(ValueHolder newValue) {
/* 228 */     if (newValue.getName() != null) {
/* 229 */       for (Iterator<ValueHolder> it = this.genericArgumentValues.iterator(); it.hasNext(); ) {
/* 230 */         ValueHolder currentValue = it.next();
/* 231 */         if (newValue.getName().equals(currentValue.getName())) {
/* 232 */           Object object = newValue.getValue(); if (object instanceof Mergeable) { Mergeable mergeable = (Mergeable)object;
/* 233 */             if (mergeable.isMergeEnabled()) {
/* 234 */               newValue.setValue(mergeable.merge(currentValue.getValue()));
/*     */             } }
/*     */           
/* 237 */           it.remove();
/*     */         } 
/*     */       } 
/*     */     }
/* 241 */     this.genericArgumentValues.add(newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getGenericArgumentValue(Class<?> requiredType) {
/* 251 */     return getGenericArgumentValue(requiredType, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getGenericArgumentValue(Class<?> requiredType, String requiredName) {
/* 262 */     return getGenericArgumentValue(requiredType, requiredName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getGenericArgumentValue(@Nullable Class<?> requiredType, @Nullable String requiredName, @Nullable Set<ValueHolder> usedValueHolders) {
/* 281 */     for (ValueHolder valueHolder : this.genericArgumentValues) {
/* 282 */       if (usedValueHolders != null && usedValueHolders.contains(valueHolder)) {
/*     */         continue;
/*     */       }
/* 285 */       if (valueHolder.getName() != null && (requiredName == null || (
/* 286 */         !requiredName.isEmpty() && !requiredName.equals(valueHolder.getName())))) {
/*     */         continue;
/*     */       }
/* 289 */       if (valueHolder.getType() != null && (requiredType == null || 
/* 290 */         !ClassUtils.matchesTypeName(requiredType, valueHolder.getType()))) {
/*     */         continue;
/*     */       }
/* 293 */       if (requiredType != null && valueHolder.getType() == null && valueHolder.getName() == null && 
/* 294 */         !ClassUtils.isAssignableValue(requiredType, valueHolder.getValue())) {
/*     */         continue;
/*     */       }
/* 297 */       return valueHolder;
/*     */     } 
/* 299 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ValueHolder> getGenericArgumentValues() {
/* 308 */     return Collections.unmodifiableList(this.genericArgumentValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getArgumentValue(int index, Class<?> requiredType) {
/* 321 */     return getArgumentValue(index, requiredType, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getArgumentValue(int index, Class<?> requiredType, String requiredName) {
/* 334 */     return getArgumentValue(index, requiredType, requiredName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueHolder getArgumentValue(int index, @Nullable Class<?> requiredType, @Nullable String requiredName, @Nullable Set<ValueHolder> usedValueHolders) {
/* 355 */     Assert.isTrue((index >= 0), "Index must not be negative");
/* 356 */     ValueHolder valueHolder = getIndexedArgumentValue(index, requiredType, requiredName);
/* 357 */     if (valueHolder == null) {
/* 358 */       valueHolder = getGenericArgumentValue(requiredType, requiredName, usedValueHolders);
/*     */     }
/* 360 */     return valueHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNamedArgument() {
/* 369 */     for (ValueHolder valueHolder : this.indexedArgumentValues.values()) {
/* 370 */       if (valueHolder.getName() != null) {
/* 371 */         return true;
/*     */       }
/*     */     } 
/* 374 */     for (ValueHolder valueHolder : this.genericArgumentValues) {
/* 375 */       if (valueHolder.getName() != null) {
/* 376 */         return true;
/*     */       }
/*     */     } 
/* 379 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArgumentCount() {
/* 387 */     return this.indexedArgumentValues.size() + this.genericArgumentValues.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 395 */     return (this.indexedArgumentValues.isEmpty() && this.genericArgumentValues.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 402 */     this.indexedArgumentValues.clear();
/* 403 */     this.genericArgumentValues.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     ConstructorArgumentValues that;
/* 409 */     if (this == other) {
/* 410 */       return true;
/*     */     }
/* 412 */     if (other instanceof ConstructorArgumentValues) { that = (ConstructorArgumentValues)other; }
/* 413 */     else { return false; }
/*     */     
/* 415 */     if (this.genericArgumentValues.size() != that.genericArgumentValues.size() || this.indexedArgumentValues
/* 416 */       .size() != that.indexedArgumentValues.size()) {
/* 417 */       return false;
/*     */     }
/* 419 */     Iterator<ValueHolder> it1 = this.genericArgumentValues.iterator();
/* 420 */     Iterator<ValueHolder> it2 = that.genericArgumentValues.iterator();
/* 421 */     while (it1.hasNext() && it2.hasNext()) {
/* 422 */       ValueHolder vh1 = it1.next();
/* 423 */       ValueHolder vh2 = it2.next();
/* 424 */       if (!vh1.contentEquals(vh2)) {
/* 425 */         return false;
/*     */       }
/*     */     } 
/* 428 */     for (Map.Entry<Integer, ValueHolder> entry : this.indexedArgumentValues.entrySet()) {
/* 429 */       ValueHolder vh1 = entry.getValue();
/* 430 */       ValueHolder vh2 = that.indexedArgumentValues.get(entry.getKey());
/* 431 */       if (vh2 == null || !vh1.contentEquals(vh2)) {
/* 432 */         return false;
/*     */       }
/*     */     } 
/* 435 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 440 */     int hashCode = 7;
/* 441 */     for (ValueHolder valueHolder : this.genericArgumentValues) {
/* 442 */       hashCode = 31 * hashCode + valueHolder.contentHashCode();
/*     */     }
/* 444 */     hashCode = 29 * hashCode;
/* 445 */     for (Map.Entry<Integer, ValueHolder> entry : this.indexedArgumentValues.entrySet()) {
/* 446 */       hashCode = 31 * hashCode + (((ValueHolder)entry.getValue()).contentHashCode() ^ ((Integer)entry.getKey()).hashCode());
/*     */     }
/* 448 */     return hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstructorArgumentValues() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ValueHolder
/*     */     implements BeanMetadataElement
/*     */   {
/*     */     @Nullable
/*     */     private Object value;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private String type;
/*     */     
/*     */     @Nullable
/*     */     private String name;
/*     */     
/*     */     @Nullable
/*     */     private Object source;
/*     */     
/*     */     private boolean converted = false;
/*     */     
/*     */     @Nullable
/*     */     private Object convertedValue;
/*     */ 
/*     */     
/*     */     public ValueHolder(@Nullable Object value) {
/* 480 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueHolder(@Nullable Object value, @Nullable String type) {
/* 489 */       this.value = value;
/* 490 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueHolder(@Nullable Object value, @Nullable String type, @Nullable String name) {
/* 500 */       this.value = value;
/* 501 */       this.type = type;
/* 502 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(@Nullable Object value) {
/* 509 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getValue() {
/* 517 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setType(@Nullable String type) {
/* 524 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getType() {
/* 532 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setName(@Nullable String name) {
/* 539 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getName() {
/* 547 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setSource(@Nullable Object source) {
/* 555 */       this.source = source;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getSource() {
/* 561 */       return this.source;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized boolean isConverted() {
/* 569 */       return this.converted;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized void setConvertedValue(@Nullable Object value) {
/* 577 */       this.converted = (value != null);
/* 578 */       this.convertedValue = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public synchronized Object getConvertedValue() {
/* 587 */       return this.convertedValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean contentEquals(ValueHolder other) {
/* 598 */       return (this == other || (
/* 599 */         ObjectUtils.nullSafeEquals(this.value, other.value) && ObjectUtils.nullSafeEquals(this.type, other.type)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int contentHashCode() {
/* 609 */       return ObjectUtils.nullSafeHash(new Object[] { this.value, this.type });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueHolder copy() {
/* 617 */       ValueHolder copy = new ValueHolder(this.value, this.type, this.name);
/* 618 */       copy.setSource(this.source);
/* 619 */       return copy;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\ConstructorArgumentValues.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */