package org.springframework.beans.factory.config;

import java.util.function.Consumer;
import org.springframework.lang.Nullable;

public interface SingletonBeanRegistry {
  void registerSingleton(String paramString, Object paramObject);
  
  void addSingletonCallback(String paramString, Consumer<Object> paramConsumer);
  
  @Nullable
  Object getSingleton(String paramString);
  
  boolean containsSingleton(String paramString);
  
  String[] getSingletonNames();
  
  int getSingletonCount();
  
  @Deprecated(since = "6.2")
  Object getSingletonMutex();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\SingletonBeanRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */