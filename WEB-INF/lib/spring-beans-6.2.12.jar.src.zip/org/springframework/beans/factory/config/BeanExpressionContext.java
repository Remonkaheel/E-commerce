/*    */ package org.springframework.beans.factory.config;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanExpressionContext
/*    */ {
/*    */   private final ConfigurableBeanFactory beanFactory;
/*    */   @Nullable
/*    */   private final Scope scope;
/*    */   
/*    */   public BeanExpressionContext(ConfigurableBeanFactory beanFactory, @Nullable Scope scope) {
/* 37 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 38 */     this.beanFactory = beanFactory;
/* 39 */     this.scope = scope;
/*    */   }
/*    */   
/*    */   public final ConfigurableBeanFactory getBeanFactory() {
/* 43 */     return this.beanFactory;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final Scope getScope() {
/* 48 */     return this.scope;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean containsObject(String key) {
/* 53 */     return (this.beanFactory.containsBean(key) || (this.scope != null && this.scope
/* 54 */       .resolveContextualObject(key) != null));
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Object getObject(String key) {
/* 59 */     if (this.beanFactory.containsBean(key)) {
/* 60 */       return this.beanFactory.getBean(key);
/*    */     }
/* 62 */     if (this.scope != null) {
/* 63 */       return this.scope.resolveContextualObject(key);
/*    */     }
/*    */     
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 73 */     if (this != other) { if (other instanceof BeanExpressionContext) { BeanExpressionContext that = (BeanExpressionContext)other; if (this.beanFactory == that.beanFactory && this.scope == that.scope); }  return false; }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 79 */     return this.beanFactory.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\BeanExpressionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */