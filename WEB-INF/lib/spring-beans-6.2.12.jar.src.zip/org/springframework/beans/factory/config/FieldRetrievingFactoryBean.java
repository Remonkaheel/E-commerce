/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldRetrievingFactoryBean
/*     */   implements FactoryBean<Object>, BeanNameAware, BeanClassLoaderAware, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private Class<?> targetClass;
/*     */   @Nullable
/*     */   private Object targetObject;
/*     */   @Nullable
/*     */   private String targetField;
/*     */   @Nullable
/*     */   private String staticField;
/*     */   @Nullable
/*     */   private String beanName;
/*     */   @Nullable
/*  77 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Field fieldObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetClass(@Nullable Class<?> targetClass) {
/*  92 */     this.targetClass = targetClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getTargetClass() {
/* 100 */     return this.targetClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetObject(@Nullable Object targetObject) {
/* 111 */     this.targetObject = targetObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getTargetObject() {
/* 119 */     return this.targetObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetField(@Nullable String targetField) {
/* 130 */     this.targetField = (targetField != null) ? StringUtils.trimAllWhitespace(targetField) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getTargetField() {
/* 138 */     return this.targetField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStaticField(String staticField) {
/* 149 */     this.staticField = StringUtils.trimAllWhitespace(staticField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanName(String beanName) {
/* 160 */     this.beanName = StringUtils.trimAllWhitespace(BeanFactoryUtils.originalBeanName(beanName));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 165 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws ClassNotFoundException, NoSuchFieldException {
/* 172 */     if (this.targetClass != null && this.targetObject != null) {
/* 173 */       throw new IllegalArgumentException("Specify either targetClass or targetObject, not both");
/*     */     }
/*     */     
/* 176 */     if (this.targetClass == null && this.targetObject == null) {
/* 177 */       if (this.targetField != null) {
/* 178 */         throw new IllegalArgumentException("Specify targetClass or targetObject in combination with targetField");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 183 */       if (this.staticField == null) {
/* 184 */         this.staticField = this.beanName;
/* 185 */         Assert.state((this.staticField != null), "No target field specified");
/*     */       } 
/*     */ 
/*     */       
/* 189 */       int lastDotIndex = this.staticField.lastIndexOf('.');
/* 190 */       if (lastDotIndex == -1 || lastDotIndex == this.staticField.length()) {
/* 191 */         throw new IllegalArgumentException("staticField must be a fully qualified class plus static field name: for example, 'example.MyExampleClass.MY_EXAMPLE_FIELD'");
/*     */       }
/*     */ 
/*     */       
/* 195 */       String className = this.staticField.substring(0, lastDotIndex);
/* 196 */       String fieldName = this.staticField.substring(lastDotIndex + 1);
/* 197 */       this.targetClass = ClassUtils.forName(className, this.beanClassLoader);
/* 198 */       this.targetField = fieldName;
/*     */     
/*     */     }
/* 201 */     else if (this.targetField == null) {
/*     */       
/* 203 */       throw new IllegalArgumentException("targetField is required");
/*     */     } 
/*     */ 
/*     */     
/* 207 */     Class<?> targetClass = (this.targetObject != null) ? this.targetObject.getClass() : this.targetClass;
/* 208 */     this.fieldObject = targetClass.getField(this.targetField);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject() throws IllegalAccessException {
/* 215 */     if (this.fieldObject == null) {
/* 216 */       throw new FactoryBeanNotInitializedException();
/*     */     }
/* 218 */     ReflectionUtils.makeAccessible(this.fieldObject);
/* 219 */     if (this.targetObject != null)
/*     */     {
/* 221 */       return this.fieldObject.get(this.targetObject);
/*     */     }
/*     */ 
/*     */     
/* 225 */     return this.fieldObject.get(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectType() {
/* 232 */     return (this.fieldObject != null) ? this.fieldObject.getType() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 237 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\FieldRetrievingFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */