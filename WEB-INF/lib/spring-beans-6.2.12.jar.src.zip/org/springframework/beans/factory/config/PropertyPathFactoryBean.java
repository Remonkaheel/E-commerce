/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyPathFactoryBean
/*     */   implements FactoryBean<Object>, BeanNameAware, BeanFactoryAware
/*     */ {
/*  88 */   private static final Log logger = LogFactory.getLog(PropertyPathFactoryBean.class);
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private BeanWrapper targetBeanWrapper;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String targetBeanName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String propertyPath;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Class<?> resultType;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetObject(Object targetObject) {
/* 117 */     this.targetBeanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(targetObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetBeanName(String targetBeanName) {
/* 128 */     this.targetBeanName = StringUtils.trimAllWhitespace(targetBeanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyPath(String propertyPath) {
/* 137 */     this.propertyPath = StringUtils.trimAllWhitespace(propertyPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultType(Class<?> resultType) {
/* 149 */     this.resultType = resultType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanName(String beanName) {
/* 160 */     this.beanName = StringUtils.trimAllWhitespace(BeanFactoryUtils.originalBeanName(beanName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 167 */     this.beanFactory = beanFactory;
/*     */     
/* 169 */     if (this.targetBeanWrapper != null && this.targetBeanName != null) {
/* 170 */       throw new IllegalArgumentException("Specify either 'targetObject' or 'targetBeanName', not both");
/*     */     }
/*     */     
/* 173 */     if (this.targetBeanWrapper == null && this.targetBeanName == null) {
/* 174 */       if (this.propertyPath != null) {
/* 175 */         throw new IllegalArgumentException("Specify 'targetObject' or 'targetBeanName' in combination with 'propertyPath'");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 180 */       int dotIndex = (this.beanName != null) ? this.beanName.indexOf('.') : -1;
/* 181 */       if (dotIndex == -1) {
/* 182 */         throw new IllegalArgumentException("Neither 'targetObject' nor 'targetBeanName' specified, and PropertyPathFactoryBean bean name '" + this.beanName + "' does not follow 'beanName.property' syntax");
/*     */       }
/*     */ 
/*     */       
/* 186 */       this.targetBeanName = this.beanName.substring(0, dotIndex);
/* 187 */       this.propertyPath = this.beanName.substring(dotIndex + 1);
/*     */     
/*     */     }
/* 190 */     else if (this.propertyPath == null) {
/*     */       
/* 192 */       throw new IllegalArgumentException("'propertyPath' is required");
/*     */     } 
/*     */     
/* 195 */     if (this.targetBeanWrapper == null && this.beanFactory.isSingleton(this.targetBeanName)) {
/*     */       
/* 197 */       Object bean = this.beanFactory.getBean(this.targetBeanName);
/* 198 */       this.targetBeanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(bean);
/* 199 */       this.resultType = this.targetBeanWrapper.getPropertyType(this.propertyPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject() throws BeansException {
/* 207 */     BeanWrapper target = this.targetBeanWrapper;
/* 208 */     if (target != null) {
/* 209 */       if (logger.isWarnEnabled() && this.targetBeanName != null) {
/* 210 */         BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory; if (cbf
/* 211 */             .isCurrentlyInCreation(this.targetBeanName)) {
/* 212 */             logger.warn("Target bean '" + this.targetBeanName + "' is still in creation due to a circular reference - obtained value for property '" + this.propertyPath + "' may be outdated!");
/*     */           } }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 218 */       Assert.state((this.beanFactory != null), "No BeanFactory available");
/* 219 */       Assert.state((this.targetBeanName != null), "No target bean name specified");
/* 220 */       Object bean = this.beanFactory.getBean(this.targetBeanName);
/* 221 */       target = PropertyAccessorFactory.forBeanPropertyAccess(bean);
/*     */     } 
/* 223 */     Assert.state((this.propertyPath != null), "No property path specified");
/* 224 */     return target.getPropertyValue(this.propertyPath);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectType() {
/* 230 */     return this.resultType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 241 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\config\PropertyPathFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */