/*    */ package org.springframework.beans.factory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanCurrentlyInCreationException
/*    */   extends BeanCreationException
/*    */ {
/*    */   public BeanCurrentlyInCreationException(String beanName) {
/* 35 */     super(beanName, "Requested bean is currently in creation: Is there an unresolvable circular reference or an asynchronous initialization dependency?");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BeanCurrentlyInCreationException(String beanName, String msg) {
/* 45 */     super(beanName, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\BeanCurrentlyInCreationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */