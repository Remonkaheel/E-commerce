package org.springframework.beans.factory;

public interface DisposableBean {
  void destroy() throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\DisposableBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */