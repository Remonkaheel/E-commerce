/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoUniqueBeanDefinitionException
/*     */   extends NoSuchBeanDefinitionException
/*     */ {
/*     */   private final int numberOfBeansFound;
/*     */   @Nullable
/*     */   private final Collection<String> beanNamesFound;
/*     */   
/*     */   public NoUniqueBeanDefinitionException(Class<?> type, Collection<String> beanNamesFound, String message) {
/*  53 */     super(type, message);
/*  54 */     this.numberOfBeansFound = beanNamesFound.size();
/*  55 */     this.beanNamesFound = new ArrayList<>(beanNamesFound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoUniqueBeanDefinitionException(Class<?> type, int numberOfBeansFound, String message) {
/*  65 */     super(type, message);
/*  66 */     this.numberOfBeansFound = numberOfBeansFound;
/*  67 */     this.beanNamesFound = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoUniqueBeanDefinitionException(Class<?> type, Collection<String> beanNamesFound) {
/*  76 */     this(type, beanNamesFound, "expected single matching bean but found " + beanNamesFound.size() + ": " + 
/*  77 */         StringUtils.collectionToCommaDelimitedString(beanNamesFound));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoUniqueBeanDefinitionException(Class<?> type, String... beanNamesFound) {
/*  86 */     this(type, Arrays.asList(beanNamesFound));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoUniqueBeanDefinitionException(ResolvableType type, Collection<String> beanNamesFound) {
/*  96 */     super(type, "expected single matching bean but found " + beanNamesFound.size() + ": " + 
/*  97 */         StringUtils.collectionToCommaDelimitedString(beanNamesFound));
/*  98 */     this.numberOfBeansFound = beanNamesFound.size();
/*  99 */     this.beanNamesFound = new ArrayList<>(beanNamesFound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoUniqueBeanDefinitionException(ResolvableType type, String... beanNamesFound) {
/* 109 */     this(type, Arrays.asList(beanNamesFound));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfBeansFound() {
/* 120 */     return this.numberOfBeansFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Collection<String> getBeanNamesFound() {
/* 131 */     return this.beanNamesFound;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\NoUniqueBeanDefinitionException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */