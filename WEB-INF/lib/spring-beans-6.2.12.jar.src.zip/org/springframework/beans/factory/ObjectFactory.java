package org.springframework.beans.factory;

import org.springframework.beans.BeansException;

@FunctionalInterface
public interface ObjectFactory<T> {
  T getObject() throws BeansException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\ObjectFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */