package org.springframework.beans.factory;

import kotlin.Metadata;
import kotlin.jvm.internal.SourceDebugExtension;
import org.springframework.core.ParameterizedTypeReference;

@Metadata(mv = {1, 7, 0}, k = 1, xi = 176, d1 = {"\000\013\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001¨\006\002¸\006\000"}, d2 = {"org/springframework/beans/factory/BeanFactoryExtensionsKt$getBeanProvider$1", "Lorg/springframework/core/ParameterizedTypeReference;", "spring-beans"})
@SourceDebugExtension({"SMAP\nBeanFactoryExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BeanFactoryExtensions.kt\norg/springframework/beans/factory/BeanFactoryExtensionsKt$getBeanProvider$1\n*L\n1#1,66:1\n*E\n"})
public final class BeanFactoryExtensionsKt$getBean$$inlined$getBeanProvider$2 extends ParameterizedTypeReference<T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\BeanFactoryExtensionsKt$getBean$$inlined$getBeanProvider$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */