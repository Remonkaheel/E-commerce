package org.springframework.beans.factory;

public interface SmartInitializingSingleton {
  void afterSingletonsInstantiated();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\factory\SmartInitializingSingleton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */