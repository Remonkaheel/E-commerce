/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.BeanDescriptor;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends SimpleBeanInfo
/*    */ {
/*    */   public BeanDescriptor getBeanDescriptor() {
/* 58 */     return new BeanDescriptor(beanClass);
/*    */   }
/*    */   
/*    */   public PropertyDescriptor[] getPropertyDescriptors() {
/* 62 */     return (PropertyDescriptor[])pds.toArray((Object[])PropertyDescriptorUtils.EMPTY_PROPERTY_DESCRIPTOR_ARRAY);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\SimpleBeanInfoFactory$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */