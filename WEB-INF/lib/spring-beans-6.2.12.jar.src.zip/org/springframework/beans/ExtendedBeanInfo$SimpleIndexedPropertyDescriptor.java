/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimpleIndexedPropertyDescriptor
/*     */   extends IndexedPropertyDescriptor
/*     */ {
/*     */   @Nullable
/*     */   private Method readMethod;
/*     */   @Nullable
/*     */   private Method writeMethod;
/*     */   @Nullable
/*     */   private Class<?> propertyType;
/*     */   @Nullable
/*     */   private Method indexedReadMethod;
/*     */   @Nullable
/*     */   private Method indexedWriteMethod;
/*     */   @Nullable
/*     */   private Class<?> indexedPropertyType;
/*     */   @Nullable
/*     */   private Class<?> propertyEditorClass;
/*     */   
/*     */   public SimpleIndexedPropertyDescriptor(IndexedPropertyDescriptor original) throws IntrospectionException {
/* 387 */     this(original.getName(), original.getReadMethod(), original.getWriteMethod(), original
/* 388 */         .getIndexedReadMethod(), original.getIndexedWriteMethod());
/* 389 */     PropertyDescriptorUtils.copyNonMethodProperties(original, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleIndexedPropertyDescriptor(String propertyName, @Nullable Method readMethod, @Nullable Method writeMethod, @Nullable Method indexedReadMethod, Method indexedWriteMethod) throws IntrospectionException {
/* 396 */     super(propertyName, (Method)null, (Method)null, (Method)null, (Method)null);
/* 397 */     this.readMethod = readMethod;
/* 398 */     this.writeMethod = writeMethod;
/* 399 */     this.propertyType = PropertyDescriptorUtils.findPropertyType(readMethod, writeMethod);
/* 400 */     this.indexedReadMethod = indexedReadMethod;
/* 401 */     this.indexedWriteMethod = indexedWriteMethod;
/* 402 */     this.indexedPropertyType = PropertyDescriptorUtils.findIndexedPropertyType(propertyName, this.propertyType, indexedReadMethod, indexedWriteMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getReadMethod() {
/* 409 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadMethod(@Nullable Method readMethod) {
/* 414 */     this.readMethod = readMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getWriteMethod() {
/* 420 */     return this.writeMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWriteMethod(@Nullable Method writeMethod) {
/* 425 */     this.writeMethod = writeMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPropertyType() {
/* 431 */     if (this.propertyType == null) {
/*     */       try {
/* 433 */         this.propertyType = PropertyDescriptorUtils.findPropertyType(this.readMethod, this.writeMethod);
/*     */       }
/* 435 */       catch (IntrospectionException introspectionException) {}
/*     */     }
/*     */ 
/*     */     
/* 439 */     return this.propertyType;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getIndexedReadMethod() {
/* 445 */     return this.indexedReadMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIndexedReadMethod(@Nullable Method indexedReadMethod) throws IntrospectionException {
/* 450 */     this.indexedReadMethod = indexedReadMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getIndexedWriteMethod() {
/* 456 */     return this.indexedWriteMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIndexedWriteMethod(@Nullable Method indexedWriteMethod) throws IntrospectionException {
/* 461 */     this.indexedWriteMethod = indexedWriteMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getIndexedPropertyType() {
/* 467 */     if (this.indexedPropertyType == null) {
/*     */       try {
/* 469 */         this.indexedPropertyType = PropertyDescriptorUtils.findIndexedPropertyType(
/* 470 */             getName(), getPropertyType(), this.indexedReadMethod, this.indexedWriteMethod);
/*     */       }
/* 472 */       catch (IntrospectionException introspectionException) {}
/*     */     }
/*     */ 
/*     */     
/* 476 */     return this.indexedPropertyType;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPropertyEditorClass() {
/* 482 */     return this.propertyEditorClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertyEditorClass(@Nullable Class<?> propertyEditorClass) {
/* 487 */     this.propertyEditorClass = propertyEditorClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 495 */     if (this != other) { if (other instanceof IndexedPropertyDescriptor) { IndexedPropertyDescriptor that = (IndexedPropertyDescriptor)other;
/* 496 */         if (ObjectUtils.nullSafeEquals(getIndexedReadMethod(), that.getIndexedReadMethod()) && 
/* 497 */           ObjectUtils.nullSafeEquals(getIndexedWriteMethod(), that.getIndexedWriteMethod()) && 
/* 498 */           ObjectUtils.nullSafeEquals(getIndexedPropertyType(), that.getIndexedPropertyType()) && 
/* 499 */           PropertyDescriptorUtils.equals(this, that)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 504 */     return Objects.hash(new Object[] { getReadMethod(), getWriteMethod(), 
/* 505 */           getIndexedReadMethod(), getIndexedWriteMethod() });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 510 */     return String.format("%s[name=%s, propertyType=%s, indexedPropertyType=%s, readMethod=%s, writeMethod=%s, indexedReadMethod=%s, indexedWriteMethod=%s]", new Object[] {
/*     */           
/* 512 */           getClass().getSimpleName(), getName(), getPropertyType(), getIndexedPropertyType(), this.readMethod, this.writeMethod, this.indexedReadMethod, this.indexedWriteMethod
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\ExtendedBeanInfo$SimpleIndexedPropertyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */