/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanPropertyHandler
/*     */   extends AbstractNestablePropertyAccessor.PropertyHandler
/*     */ {
/*     */   private final GenericTypeAwarePropertyDescriptor pd;
/*     */   
/*     */   public BeanPropertyHandler(GenericTypeAwarePropertyDescriptor pd) {
/* 235 */     super(pd.getPropertyType(), (pd.getReadMethod() != null), (pd.getWriteMethod() != null));
/* 236 */     this.pd = pd;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDescriptor toTypeDescriptor() {
/* 241 */     return this.pd.getTypeDescriptor();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResolvableType getResolvableType() {
/* 246 */     return this.pd.getReadMethodType();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDescriptor getMapValueType(int nestingLevel) {
/* 251 */     return new TypeDescriptor(this.pd
/* 252 */         .getReadMethodType().getNested(nestingLevel).asMap().getGeneric(new int[] { 1 }, ), null, this.pd
/* 253 */         .getTypeDescriptor().getAnnotations());
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDescriptor getCollectionType(int nestingLevel) {
/* 258 */     return new TypeDescriptor(this.pd
/* 259 */         .getReadMethodType().getNested(nestingLevel).asCollection().getGeneric(new int[0]), null, this.pd
/* 260 */         .getTypeDescriptor().getAnnotations());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeDescriptor nested(int level) {
/* 266 */     return this.pd.getTypeDescriptor().nested(level);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue() throws Exception {
/* 272 */     Method readMethod = this.pd.getReadMethod();
/* 273 */     Assert.state((readMethod != null), "No read method available");
/* 274 */     ReflectionUtils.makeAccessible(readMethod);
/* 275 */     return readMethod.invoke(BeanWrapperImpl.this.getWrappedInstance(), (Object[])null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(@Nullable Object value) throws Exception {
/* 280 */     Method writeMethod = this.pd.getWriteMethodForActualAccess();
/* 281 */     ReflectionUtils.makeAccessible(writeMethod);
/* 282 */     writeMethod.invoke(BeanWrapperImpl.this.getWrappedInstance(), new Object[] { value });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setValueFallbackIfPossible(@Nullable Object value) {
/*     */     try {
/* 288 */       Method writeMethod = this.pd.getWriteMethodFallback((value != null) ? value.getClass() : null);
/* 289 */       if (writeMethod == null) {
/* 290 */         writeMethod = this.pd.getUniqueWriteMethodFallback();
/* 291 */         if (writeMethod != null)
/*     */         {
/*     */           
/* 294 */           value = BeanWrapperImpl.this.convertForProperty(this.pd.getName(), null, value, new TypeDescriptor(new MethodParameter(writeMethod, 0)));
/*     */         }
/*     */       } 
/*     */       
/* 298 */       if (writeMethod != null) {
/* 299 */         ReflectionUtils.makeAccessible(writeMethod);
/* 300 */         writeMethod.invoke(BeanWrapperImpl.this.getWrappedInstance(), new Object[] { value });
/* 301 */         return true;
/*     */       }
/*     */     
/* 304 */     } catch (Exception ex) {
/* 305 */       LogFactory.getLog(BeanPropertyHandler.class).debug("Write method fallback failed", ex);
/*     */     } 
/* 307 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\BeanWrapperImpl$BeanPropertyHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */