/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PropertyDescriptorUtils
/*     */ {
/*  41 */   public static final PropertyDescriptor[] EMPTY_PROPERTY_DESCRIPTOR_ARRAY = new PropertyDescriptor[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<? extends PropertyDescriptor> determineBasicProperties(Class<?> beanClass) throws IntrospectionException {
/*  60 */     Map<String, BasicPropertyDescriptor> pdMap = new TreeMap<>();
/*     */     
/*  62 */     for (Method method : beanClass.getMethods()) {
/*  63 */       boolean setter; int nameIndex; String methodName = method.getName();
/*     */ 
/*     */ 
/*     */       
/*  67 */       if (methodName.startsWith("set") && method.getParameterCount() == 1) {
/*  68 */         setter = true;
/*  69 */         nameIndex = 3;
/*     */       }
/*  71 */       else if (methodName.startsWith("get") && method.getParameterCount() == 0 && method.getReturnType() != void.class) {
/*  72 */         setter = false;
/*  73 */         nameIndex = 3;
/*     */       }
/*  75 */       else if (methodName.startsWith("is") && method.getParameterCount() == 0 && method.getReturnType() == boolean.class) {
/*  76 */         setter = false;
/*  77 */         nameIndex = 2;
/*     */       } else {
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/*  83 */       String propertyName = StringUtils.uncapitalizeAsProperty(methodName.substring(nameIndex));
/*  84 */       if (!propertyName.isEmpty()) {
/*     */ 
/*     */ 
/*     */         
/*  88 */         BasicPropertyDescriptor pd = pdMap.get(propertyName);
/*  89 */         if (pd != null) {
/*  90 */           if (setter) {
/*  91 */             Method writeMethod = pd.getWriteMethod();
/*  92 */             if (writeMethod == null || writeMethod
/*  93 */               .getParameterTypes()[0].isAssignableFrom(method.getParameterTypes()[0])) {
/*  94 */               pd.setWriteMethod(method);
/*     */             } else {
/*     */               
/*  97 */               pd.addWriteMethod(method);
/*     */             } 
/*     */           } else {
/*     */             
/* 101 */             Method readMethod = pd.getReadMethod();
/* 102 */             if (readMethod == null || (readMethod
/* 103 */               .getReturnType() == method.getReturnType() && method.getName().startsWith("is"))) {
/* 104 */               pd.setReadMethod(method);
/*     */             }
/*     */           } 
/*     */         } else {
/*     */           
/* 109 */           pd = new BasicPropertyDescriptor(propertyName, !setter ? method : null, setter ? method : null);
/* 110 */           pdMap.put(propertyName, pd);
/*     */         } 
/*     */       }  continue;
/*     */     } 
/* 114 */     return pdMap.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyNonMethodProperties(PropertyDescriptor source, PropertyDescriptor target) {
/* 121 */     target.setExpert(source.isExpert());
/* 122 */     target.setHidden(source.isHidden());
/* 123 */     target.setPreferred(source.isPreferred());
/* 124 */     target.setName(source.getName());
/* 125 */     target.setShortDescription(source.getShortDescription());
/* 126 */     target.setDisplayName(source.getDisplayName());
/*     */ 
/*     */     
/* 129 */     Enumeration<String> keys = source.attributeNames();
/* 130 */     while (keys.hasMoreElements()) {
/* 131 */       String key = keys.nextElement();
/* 132 */       target.setValue(key, source.getValue(key));
/*     */     } 
/*     */ 
/*     */     
/* 136 */     target.setPropertyEditorClass(source.getPropertyEditorClass());
/* 137 */     target.setBound(source.isBound());
/* 138 */     target.setConstrained(source.isConstrained());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Class<?> findPropertyType(@Nullable Method readMethod, @Nullable Method writeMethod) throws IntrospectionException {
/* 148 */     Class<?> propertyType = null;
/*     */     
/* 150 */     if (readMethod != null) {
/* 151 */       if (readMethod.getParameterCount() != 0) {
/* 152 */         throw new IntrospectionException("Bad read method arg count: " + String.valueOf(readMethod));
/*     */       }
/* 154 */       propertyType = readMethod.getReturnType();
/* 155 */       if (propertyType == void.class) {
/* 156 */         throw new IntrospectionException("Read method returns void: " + String.valueOf(readMethod));
/*     */       }
/*     */     } 
/*     */     
/* 160 */     if (writeMethod != null) {
/* 161 */       Class<?>[] params = writeMethod.getParameterTypes();
/* 162 */       if (params.length != 1) {
/* 163 */         throw new IntrospectionException("Bad write method arg count: " + String.valueOf(writeMethod));
/*     */       }
/* 165 */       if (propertyType != null) {
/* 166 */         if (propertyType.isAssignableFrom(params[0]))
/*     */         {
/* 168 */           propertyType = params[0];
/*     */         }
/* 170 */         else if (!params[0].isAssignableFrom(propertyType))
/*     */         {
/*     */ 
/*     */           
/* 174 */           throw new IntrospectionException("Type mismatch between read and write methods: " + String.valueOf(readMethod) + " - " + String.valueOf(writeMethod));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 179 */         propertyType = params[0];
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     return propertyType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Class<?> findIndexedPropertyType(String name, @Nullable Class<?> propertyType, @Nullable Method indexedReadMethod, @Nullable Method indexedWriteMethod) throws IntrospectionException {
/* 193 */     Class<?> indexedPropertyType = null;
/*     */     
/* 195 */     if (indexedReadMethod != null) {
/* 196 */       Class<?>[] params = indexedReadMethod.getParameterTypes();
/* 197 */       if (params.length != 1) {
/* 198 */         throw new IntrospectionException("Bad indexed read method arg count: " + String.valueOf(indexedReadMethod));
/*     */       }
/* 200 */       if (params[0] != int.class) {
/* 201 */         throw new IntrospectionException("Non int index to indexed read method: " + String.valueOf(indexedReadMethod));
/*     */       }
/* 203 */       indexedPropertyType = indexedReadMethod.getReturnType();
/* 204 */       if (indexedPropertyType == void.class) {
/* 205 */         throw new IntrospectionException("Indexed read method returns void: " + String.valueOf(indexedReadMethod));
/*     */       }
/*     */     } 
/*     */     
/* 209 */     if (indexedWriteMethod != null) {
/* 210 */       Class<?>[] params = indexedWriteMethod.getParameterTypes();
/* 211 */       if (params.length != 2) {
/* 212 */         throw new IntrospectionException("Bad indexed write method arg count: " + String.valueOf(indexedWriteMethod));
/*     */       }
/* 214 */       if (params[0] != int.class) {
/* 215 */         throw new IntrospectionException("Non int index to indexed write method: " + String.valueOf(indexedWriteMethod));
/*     */       }
/* 217 */       if (indexedPropertyType != null) {
/* 218 */         if (indexedPropertyType.isAssignableFrom(params[1]))
/*     */         {
/* 220 */           indexedPropertyType = params[1];
/*     */         }
/* 222 */         else if (!params[1].isAssignableFrom(indexedPropertyType))
/*     */         {
/*     */ 
/*     */           
/* 226 */           throw new IntrospectionException("Type mismatch between indexed read and write methods: " + String.valueOf(indexedReadMethod) + " - " + String.valueOf(indexedWriteMethod));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 231 */         indexedPropertyType = params[1];
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     if (propertyType != null && (!propertyType.isArray() || propertyType
/* 236 */       .componentType() != indexedPropertyType)) {
/* 237 */       throw new IntrospectionException("Type mismatch between indexed and non-indexed methods: " + String.valueOf(indexedReadMethod) + " - " + String.valueOf(indexedWriteMethod));
/*     */     }
/*     */ 
/*     */     
/* 241 */     return indexedPropertyType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(PropertyDescriptor pd, PropertyDescriptor otherPd) {
/* 251 */     return (ObjectUtils.nullSafeEquals(pd.getReadMethod(), otherPd.getReadMethod()) && 
/* 252 */       ObjectUtils.nullSafeEquals(pd.getWriteMethod(), otherPd.getWriteMethod()) && 
/* 253 */       ObjectUtils.nullSafeEquals(pd.getPropertyType(), otherPd.getPropertyType()) && 
/* 254 */       ObjectUtils.nullSafeEquals(pd.getPropertyEditorClass(), otherPd.getPropertyEditorClass()) && pd
/* 255 */       .isBound() == otherPd.isBound() && pd.isConstrained() == otherPd.isConstrained());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BasicPropertyDescriptor
/*     */     extends PropertyDescriptor
/*     */   {
/*     */     @Nullable
/*     */     private Method readMethod;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Method writeMethod;
/*     */ 
/*     */     
/* 273 */     private final List<Method> alternativeWriteMethods = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*     */     public BasicPropertyDescriptor(String propertyName, @Nullable Method readMethod, @Nullable Method writeMethod) throws IntrospectionException {
/* 278 */       super(propertyName, readMethod, writeMethod);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setReadMethod(@Nullable Method readMethod) {
/* 283 */       this.readMethod = readMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getReadMethod() {
/* 289 */       return this.readMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setWriteMethod(@Nullable Method writeMethod) {
/* 294 */       this.writeMethod = writeMethod;
/*     */     }
/*     */     
/*     */     public void addWriteMethod(Method writeMethod) {
/* 298 */       if (this.writeMethod != null) {
/* 299 */         this.alternativeWriteMethods.add(this.writeMethod);
/* 300 */         this.writeMethod = null;
/*     */       } 
/* 302 */       this.alternativeWriteMethods.add(writeMethod);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Method getWriteMethod() {
/* 308 */       if (this.writeMethod == null && !this.alternativeWriteMethods.isEmpty()) {
/* 309 */         if (this.readMethod == null) {
/* 310 */           return this.alternativeWriteMethods.get(0);
/*     */         }
/*     */         
/* 313 */         for (Method method : this.alternativeWriteMethods) {
/* 314 */           if (this.readMethod.getReturnType().isAssignableFrom(method.getParameterTypes()[0])) {
/* 315 */             this.writeMethod = method;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 321 */       return this.writeMethod;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\PropertyDescriptorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */