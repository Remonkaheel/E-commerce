/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeMismatchException
/*     */   extends PropertyAccessException
/*     */ {
/*     */   public static final String ERROR_CODE = "typeMismatch";
/*     */   @Nullable
/*     */   private String propertyName;
/*     */   @Nullable
/*     */   private final transient Object value;
/*     */   @Nullable
/*     */   private final Class<?> requiredType;
/*     */   
/*     */   public TypeMismatchException(PropertyChangeEvent propertyChangeEvent, Class<?> requiredType) {
/*  56 */     this(propertyChangeEvent, requiredType, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMismatchException(PropertyChangeEvent propertyChangeEvent, @Nullable Class<?> requiredType, @Nullable Throwable cause) {
/*  68 */     super(propertyChangeEvent, "Failed to convert property value of type '" + 
/*     */         
/*  70 */         ClassUtils.getDescriptiveType(propertyChangeEvent.getNewValue()) + "'" + (
/*  71 */         (requiredType != null) ? (" to required type '" + 
/*  72 */         ClassUtils.getQualifiedName(requiredType) + "'") : "") + (
/*  73 */         (propertyChangeEvent.getPropertyName() != null) ? (" for property '" + 
/*  74 */         propertyChangeEvent.getPropertyName() + "'") : "") + (
/*  75 */         (cause != null) ? ("; " + cause.getMessage()) : ""), cause);
/*     */     
/*  77 */     this.propertyName = propertyChangeEvent.getPropertyName();
/*  78 */     this.value = propertyChangeEvent.getNewValue();
/*  79 */     this.requiredType = requiredType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMismatchException(@Nullable Object value, @Nullable Class<?> requiredType) {
/*  89 */     this(value, requiredType, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMismatchException(@Nullable Object value, @Nullable Class<?> requiredType, @Nullable Throwable cause) {
/* 100 */     super("Failed to convert value of type '" + ClassUtils.getDescriptiveType(value) + "'" + (
/* 101 */         (requiredType != null) ? (" to required type '" + ClassUtils.getQualifiedName(requiredType) + "'") : "") + (
/* 102 */         (cause != null) ? ("; " + cause.getMessage()) : ""), cause);
/*     */     
/* 104 */     this.value = value;
/* 105 */     this.requiredType = requiredType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initPropertyName(String propertyName) {
/* 118 */     Assert.state((this.propertyName == null), "Property name already initialized");
/* 119 */     this.propertyName = propertyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPropertyName() {
/* 128 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getValue() {
/* 137 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getRequiredType() {
/* 145 */     return this.requiredType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorCode() {
/* 150 */     return "typeMismatch";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\TypeMismatchException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */