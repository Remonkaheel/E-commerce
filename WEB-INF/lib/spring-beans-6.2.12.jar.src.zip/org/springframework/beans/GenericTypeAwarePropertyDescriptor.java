/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.Property;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class GenericTypeAwarePropertyDescriptor
/*     */   extends PropertyDescriptor
/*     */ {
/*     */   private final Class<?> beanClass;
/*     */   @Nullable
/*     */   private final Method readMethod;
/*     */   @Nullable
/*     */   private final Method writeMethod;
/*     */   @Nullable
/*     */   private Set<Method> ambiguousWriteMethods;
/*     */   private volatile boolean ambiguousWriteMethodsLogged;
/*     */   @Nullable
/*     */   private MethodParameter writeMethodParameter;
/*     */   @Nullable
/*     */   private volatile ResolvableType writeMethodType;
/*     */   @Nullable
/*     */   private ResolvableType readMethodType;
/*     */   @Nullable
/*     */   private volatile TypeDescriptor typeDescriptor;
/*     */   @Nullable
/*     */   private Class<?> propertyType;
/*     */   @Nullable
/*     */   private final Class<?> propertyEditorClass;
/*     */   
/*     */   public GenericTypeAwarePropertyDescriptor(Class<?> beanClass, String propertyName, @Nullable Method readMethod, @Nullable Method writeMethod, @Nullable Class<?> propertyEditorClass) throws IntrospectionException {
/*  84 */     super(propertyName, (Method)null, (Method)null);
/*  85 */     this.beanClass = beanClass;
/*     */     
/*  87 */     Method readMethodToUse = (readMethod != null) ? BridgeMethodResolver.findBridgedMethod(readMethod) : null;
/*  88 */     Method writeMethodToUse = (writeMethod != null) ? BridgeMethodResolver.findBridgedMethod(writeMethod) : null;
/*  89 */     if (writeMethodToUse == null && readMethodToUse != null) {
/*     */ 
/*     */ 
/*     */       
/*  93 */       Method candidate = ClassUtils.getMethodIfAvailable(this.beanClass, "set" + 
/*  94 */           StringUtils.capitalize(getName()), (Class[])null);
/*  95 */       if (candidate != null && candidate.getParameterCount() == 1) {
/*  96 */         writeMethodToUse = candidate;
/*     */       }
/*     */     } 
/*  99 */     this.readMethod = readMethodToUse;
/* 100 */     this.writeMethod = writeMethodToUse;
/*     */     
/* 102 */     if (this.writeMethod != null) {
/* 103 */       if (this.readMethod == null) {
/*     */ 
/*     */ 
/*     */         
/* 107 */         Set<Method> ambiguousCandidates = new HashSet<>();
/* 108 */         for (Method method : beanClass.getMethods()) {
/* 109 */           if (method.getName().equals(this.writeMethod.getName()) && 
/* 110 */             !method.equals(this.writeMethod) && !method.isBridge() && method
/* 111 */             .getParameterCount() == this.writeMethod.getParameterCount()) {
/* 112 */             ambiguousCandidates.add(method);
/*     */           }
/*     */         } 
/* 115 */         if (!ambiguousCandidates.isEmpty()) {
/* 116 */           this.ambiguousWriteMethods = ambiguousCandidates;
/*     */         }
/*     */       } 
/* 119 */       this.writeMethodParameter = (new MethodParameter(this.writeMethod, 0)).withContainingClass(this.beanClass);
/*     */     } 
/*     */     
/* 122 */     if (this.readMethod != null) {
/* 123 */       this.readMethodType = ResolvableType.forMethodReturnType(this.readMethod, this.beanClass);
/* 124 */       this.propertyType = this.readMethodType.resolve(this.readMethod.getReturnType());
/*     */     }
/* 126 */     else if (this.writeMethodParameter != null) {
/* 127 */       this.propertyType = this.writeMethodParameter.getParameterType();
/*     */     } 
/*     */     
/* 130 */     this.propertyEditorClass = propertyEditorClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getBeanClass() {
/* 135 */     return this.beanClass;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getReadMethod() {
/* 141 */     return this.readMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getWriteMethod() {
/* 147 */     return this.writeMethod;
/*     */   }
/*     */   
/*     */   public Method getWriteMethodForActualAccess() {
/* 151 */     Assert.state((this.writeMethod != null), "No write method available");
/* 152 */     if (this.ambiguousWriteMethods != null && !this.ambiguousWriteMethodsLogged) {
/* 153 */       this.ambiguousWriteMethodsLogged = true;
/* 154 */       LogFactory.getLog(GenericTypeAwarePropertyDescriptor.class).debug("Non-unique JavaBean property '" + 
/* 155 */           getName() + "' being accessed! Ambiguous write methods found next to actually used [" + String.valueOf(this.writeMethod) + "]: " + String.valueOf(this.ambiguousWriteMethods));
/*     */     } 
/*     */     
/* 158 */     return this.writeMethod;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Method getWriteMethodFallback(@Nullable Class<?> valueType) {
/* 163 */     if (this.ambiguousWriteMethods != null) {
/* 164 */       for (Method method : this.ambiguousWriteMethods) {
/* 165 */         Class<?> paramType = method.getParameterTypes()[0];
/* 166 */         if ((valueType != null) ? paramType.isAssignableFrom(valueType) : !paramType.isPrimitive()) {
/* 167 */           return method;
/*     */         }
/*     */       } 
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Method getUniqueWriteMethodFallback() {
/* 176 */     if (this.ambiguousWriteMethods != null && this.ambiguousWriteMethods.size() == 1) {
/* 177 */       return this.ambiguousWriteMethods.iterator().next();
/*     */     }
/* 179 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasUniqueWriteMethod() {
/* 183 */     return (this.writeMethod != null && this.ambiguousWriteMethods == null);
/*     */   }
/*     */   
/*     */   public MethodParameter getWriteMethodParameter() {
/* 187 */     Assert.state((this.writeMethodParameter != null), "No write method available");
/* 188 */     return this.writeMethodParameter;
/*     */   }
/*     */   
/*     */   public ResolvableType getWriteMethodType() {
/* 192 */     ResolvableType writeMethodType = this.writeMethodType;
/* 193 */     if (writeMethodType == null) {
/* 194 */       writeMethodType = ResolvableType.forMethodParameter(getWriteMethodParameter());
/* 195 */       this.writeMethodType = writeMethodType;
/*     */     } 
/* 197 */     return writeMethodType;
/*     */   }
/*     */   
/*     */   public ResolvableType getReadMethodType() {
/* 201 */     Assert.state((this.readMethodType != null), "No read method available");
/* 202 */     return this.readMethodType;
/*     */   }
/*     */   
/*     */   public TypeDescriptor getTypeDescriptor() {
/* 206 */     TypeDescriptor typeDescriptor = this.typeDescriptor;
/* 207 */     if (typeDescriptor == null) {
/* 208 */       Property property = new Property(getBeanClass(), getReadMethod(), getWriteMethod(), getName());
/* 209 */       typeDescriptor = new TypeDescriptor(property);
/* 210 */       this.typeDescriptor = typeDescriptor;
/*     */     } 
/* 212 */     return typeDescriptor;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPropertyType() {
/* 218 */     return this.propertyType;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPropertyEditorClass() {
/* 224 */     return this.propertyEditorClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 230 */     if (this != other) { if (other instanceof GenericTypeAwarePropertyDescriptor) { GenericTypeAwarePropertyDescriptor that = (GenericTypeAwarePropertyDescriptor)other;
/* 231 */         if (getBeanClass().equals(that.getBeanClass()) && 
/* 232 */           PropertyDescriptorUtils.equals(this, that)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 237 */     return Objects.hash(new Object[] { getBeanClass(), getReadMethod(), getWriteMethod() });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-beans-6.2.12.jar!\org\springframework\beans\GenericTypeAwarePropertyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */