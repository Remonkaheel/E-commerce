/*     */ package org.thymeleaf.linkbuilder;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.Contexts;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.IWebContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.unbescape.uri.UriEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardLinkBuilder
/*     */   extends AbstractLinkBuilder
/*     */ {
/*     */   private static final char URL_TEMPLATE_DELIMITER_PREFIX = '{';
/*     */   private static final char URL_TEMPLATE_DELIMITER_SUFFIX = '}';
/*     */   private static final String URL_TEMPLATE_DELIMITER_SEGMENT_PREFIX = "{/";
/*     */   
/*     */   protected enum LinkType
/*     */   {
/*  63 */     ABSOLUTE, CONTEXT_RELATIVE, SERVER_RELATIVE, BASE_RELATIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String buildLink(IExpressionContext context, String base, Map<String, Object> parameters) {
/*     */     LinkType linkType;
/*  81 */     Validate.notNull(context, "Expression context cannot be null");
/*     */     
/*  83 */     if (base == null) {
/*  84 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  89 */     Map<String, Object> linkParameters = (parameters == null || parameters.size() == 0) ? null : new LinkedHashMap<>(parameters);
/*     */     
/*  91 */     filterOutJavaScriptLinks(base);
/*     */ 
/*     */     
/*  94 */     if (isLinkBaseAbsolute(base)) {
/*  95 */       linkType = LinkType.ABSOLUTE;
/*  96 */     } else if (isLinkBaseContextRelative(base)) {
/*  97 */       linkType = LinkType.CONTEXT_RELATIVE;
/*  98 */     } else if (isLinkBaseServerRelative(base)) {
/*  99 */       linkType = LinkType.SERVER_RELATIVE;
/*     */     } else {
/* 101 */       linkType = LinkType.BASE_RELATIVE;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     int hashPosition = findCharInSequence(base, '#');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     boolean mightHaveVariableTemplates = (findCharInSequence(base, '{') >= 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     String contextPath = (linkType == LinkType.CONTEXT_RELATIVE) ? computeContextPath(context, base, parameters) : null;
/* 127 */     boolean contextPathEmpty = (contextPath == null || contextPath.length() == 0 || contextPath.equals("/"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (contextPathEmpty && linkType != LinkType.SERVER_RELATIVE && (linkParameters == null || linkParameters
/* 137 */       .size() == 0) && hashPosition < 0 && !mightHaveVariableTemplates) {
/* 138 */       return processLink(context, base);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     StringBuilder linkBase = new StringBuilder(base);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     String urlFragment = "";
/*     */ 
/*     */     
/* 156 */     if (hashPosition > 0) {
/*     */       
/* 158 */       urlFragment = linkBase.substring(hashPosition);
/* 159 */       linkBase.delete(hashPosition, linkBase.length());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     if (mightHaveVariableTemplates) {
/* 168 */       linkBase = replaceTemplateParamsInBase(linkBase, linkParameters);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     if (linkParameters != null && linkParameters.size() > 0) {
/*     */       
/* 178 */       boolean linkBaseHasQuestionMark = (findCharInSequence(linkBase, '?') >= 0);
/*     */ 
/*     */       
/* 181 */       if (linkBaseHasQuestionMark) {
/* 182 */         linkBase.append('&');
/*     */       } else {
/* 184 */         linkBase.append('?');
/*     */       } 
/*     */ 
/*     */       
/* 188 */       processAllRemainingParametersAsQueryParams(linkBase, linkParameters);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (urlFragment.length() > 0) {
/* 197 */       linkBase.append(urlFragment);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (linkType == LinkType.SERVER_RELATIVE) {
/* 205 */       linkBase.delete(0, 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (linkType == LinkType.CONTEXT_RELATIVE && !contextPathEmpty)
/*     */     {
/* 214 */       linkBase.insert(0, contextPath);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     return processLink(context, linkBase.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findCharInSequence(CharSequence seq, char character) {
/* 231 */     int n = seq.length();
/* 232 */     while (n-- != 0) {
/* 233 */       char c = seq.charAt(n);
/* 234 */       if (c == character) {
/* 235 */         return n;
/*     */       }
/*     */     } 
/* 238 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void filterOutJavaScriptLinks(CharSequence linkBase) {
/* 243 */     if (linkBase.length() >= 11 && 
/* 244 */       Character.toLowerCase(linkBase.charAt(0)) == 'j' && 
/* 245 */       Character.toLowerCase(linkBase.charAt(1)) == 'a' && 
/* 246 */       Character.toLowerCase(linkBase.charAt(2)) == 'v' && 
/* 247 */       Character.toLowerCase(linkBase.charAt(3)) == 'a' && 
/* 248 */       Character.toLowerCase(linkBase.charAt(4)) == 's' && 
/* 249 */       Character.toLowerCase(linkBase.charAt(5)) == 'c' && 
/* 250 */       Character.toLowerCase(linkBase.charAt(6)) == 'r' && 
/* 251 */       Character.toLowerCase(linkBase.charAt(7)) == 'i' && 
/* 252 */       Character.toLowerCase(linkBase.charAt(8)) == 'p' && 
/* 253 */       Character.toLowerCase(linkBase.charAt(9)) == 't' && 
/* 254 */       Character.toLowerCase(linkBase.charAt(10)) == ':')
/*     */     {
/* 256 */       throw new TemplateProcessingException("'javascript:' is forbidden in this context. Link expressions cannot contain inlined JavaScript code.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLinkBaseAbsolute(CharSequence linkBase) {
/* 266 */     int linkBaseLen = linkBase.length();
/* 267 */     if (linkBaseLen < 2) {
/* 268 */       return false;
/*     */     }
/* 270 */     char c0 = linkBase.charAt(0);
/* 271 */     if (c0 == 'm' || c0 == 'M') {
/*     */       
/* 273 */       if (linkBase.length() >= 7 && 
/* 274 */         Character.toLowerCase(linkBase.charAt(1)) == 'a' && 
/* 275 */         Character.toLowerCase(linkBase.charAt(2)) == 'i' && 
/* 276 */         Character.toLowerCase(linkBase.charAt(3)) == 'l' && 
/* 277 */         Character.toLowerCase(linkBase.charAt(4)) == 't' && 
/* 278 */         Character.toLowerCase(linkBase.charAt(5)) == 'o' && 
/* 279 */         Character.toLowerCase(linkBase.charAt(6)) == ':') {
/* 280 */         return true;
/*     */       }
/* 282 */     } else if (c0 == '/') {
/* 283 */       return (linkBase.charAt(1) == '/');
/*     */     } 
/* 285 */     for (int i = 0; i < linkBaseLen - 2; i++) {
/*     */       
/* 287 */       if (linkBase.charAt(i) == ':' && linkBase.charAt(i + 1) == '/' && linkBase.charAt(i + 2) == '/') {
/* 288 */         return true;
/*     */       }
/*     */     } 
/* 291 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLinkBaseContextRelative(CharSequence linkBase) {
/* 297 */     if (linkBase.length() == 0 || linkBase.charAt(0) != '/') {
/* 298 */       return false;
/*     */     }
/* 300 */     return (linkBase.length() == 1 || linkBase.charAt(1) != '/');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLinkBaseServerRelative(CharSequence linkBase) {
/* 306 */     return (linkBase.length() >= 2 && linkBase.charAt(0) == '~' && linkBase.charAt(1) == '/');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder replaceTemplateParamsInBase(StringBuilder linkBase, Map<String, Object> parameters) {
/* 320 */     if (parameters == null) {
/* 321 */       return linkBase;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     int questionMarkPosition = findCharInSequence(linkBase, '?');
/*     */     
/* 333 */     Set<String> parameterNames = parameters.keySet();
/* 334 */     Set<String> alreadyProcessedParameters = null;
/*     */     
/* 336 */     for (String parameterName : parameterNames) {
/*     */ 
/*     */       
/* 339 */       boolean escapeAsPathSegment = false;
/*     */ 
/*     */       
/* 342 */       String template = '{' + parameterName + '}';
/*     */       
/* 344 */       int templateIndex = linkBase.indexOf(template);
/*     */       
/* 346 */       if (templateIndex < 0) {
/* 347 */         template = "{/" + parameterName + '}';
/* 348 */         templateIndex = linkBase.indexOf(template);
/*     */         
/* 350 */         if (templateIndex < 0) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 356 */         escapeAsPathSegment = true;
/*     */       } 
/*     */ 
/*     */       
/* 360 */       if (alreadyProcessedParameters == null) {
/* 361 */         alreadyProcessedParameters = new HashSet<>(parameterNames.size());
/*     */       }
/* 363 */       alreadyProcessedParameters.add(parameterName);
/*     */ 
/*     */       
/* 366 */       Object parameterValue = parameters.get(parameterName);
/* 367 */       String templateReplacement = formatParameterValueAsUnescapedVariableTemplate(parameterValue);
/* 368 */       int templateReplacementLen = templateReplacement.length();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 373 */       int templateLen = template.length();
/* 374 */       int start = templateIndex;
/* 375 */       while (start > -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 380 */         String escapedReplacement = (questionMarkPosition == -1 || start < questionMarkPosition) ? (escapeAsPathSegment ? UriEscape.escapeUriPathSegment(templateReplacement) : UriEscape.escapeUriPath(templateReplacement)) : UriEscape.escapeUriQueryParam(templateReplacement);
/* 381 */         linkBase.replace(start, start + templateLen, escapedReplacement);
/* 382 */         start = linkBase.indexOf(template, start + templateReplacementLen);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 387 */     if (alreadyProcessedParameters != null) {
/* 388 */       for (String alreadyProcessedParameter : alreadyProcessedParameters) {
/* 389 */         parameters.remove(alreadyProcessedParameter);
/*     */       }
/*     */     }
/*     */     
/* 393 */     return linkBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String formatParameterValueAsUnescapedVariableTemplate(Object parameterValue) {
/* 407 */     if (parameterValue == null) {
/* 408 */       return "";
/*     */     }
/*     */     
/* 411 */     if (!(parameterValue instanceof List)) {
/* 412 */       return parameterValue.toString();
/*     */     }
/*     */     
/* 415 */     List<?> values = (List)parameterValue;
/* 416 */     int valuesLen = values.size();
/* 417 */     StringBuilder strBuilder = new StringBuilder(valuesLen * 16);
/* 418 */     for (int i = 0; i < valuesLen; i++) {
/* 419 */       Object valueItem = values.get(i);
/* 420 */       if (strBuilder.length() > 0) {
/* 421 */         strBuilder.append(',');
/*     */       }
/* 423 */       strBuilder.append((valueItem == null) ? "" : valueItem.toString());
/*     */     } 
/* 425 */     return strBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void processAllRemainingParametersAsQueryParams(StringBuilder strBuilder, Map<String, Object> parameters) {
/* 432 */     int parameterSize = parameters.size();
/*     */     
/* 434 */     if (parameterSize <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 438 */     Set<String> parameterNames = parameters.keySet();
/*     */     
/* 440 */     int i = 0;
/* 441 */     for (String parameterName : parameterNames) {
/*     */       
/* 443 */       Object value = parameters.get(parameterName);
/*     */       
/* 445 */       if (value == null) {
/* 446 */         if (i > 0) {
/* 447 */           strBuilder.append('&');
/*     */         }
/* 449 */         strBuilder.append(UriEscape.escapeUriQueryParam(parameterName));
/* 450 */         i++;
/*     */         
/*     */         continue;
/*     */       } 
/* 454 */       if (!(value instanceof List)) {
/* 455 */         if (i > 0) {
/* 456 */           strBuilder.append('&');
/*     */         }
/* 458 */         strBuilder.append(UriEscape.escapeUriQueryParam(parameterName));
/* 459 */         strBuilder.append('=');
/* 460 */         strBuilder.append(UriEscape.escapeUriQueryParam(value.toString()));
/* 461 */         i++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 466 */       List<?> values = (List)value;
/* 467 */       int valuesLen = values.size();
/* 468 */       for (int j = 0; j < valuesLen; j++) {
/* 469 */         Object valueItem = values.get(j);
/* 470 */         if (i > 0 || j > 0) {
/* 471 */           strBuilder.append('&');
/*     */         }
/* 473 */         strBuilder.append(UriEscape.escapeUriQueryParam(parameterName));
/* 474 */         if (valueItem != null) {
/* 475 */           strBuilder.append('=');
/* 476 */           strBuilder.append(UriEscape.escapeUriQueryParam(valueItem.toString()));
/*     */         } 
/*     */       } 
/*     */       
/* 480 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String computeContextPath(IExpressionContext context, String base, Map<String, Object> parameters) {
/* 511 */     if (!Contexts.isWebContext((IContext)context)) {
/* 512 */       throw new TemplateProcessingException("Link base \"" + base + "\" cannot be context relative (/...) unless the context used for executing the engine implements the " + IWebContext.class
/*     */           
/* 514 */           .getName() + " interface");
/*     */     }
/*     */ 
/*     */     
/* 518 */     return Contexts.getWebExchange((IContext)context).getRequest().getApplicationPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String processLink(IExpressionContext context, String link) {
/* 543 */     if (!Contexts.isWebContext((IContext)context)) {
/* 544 */       return link;
/*     */     }
/*     */     
/* 547 */     return Contexts.getWebExchange((IContext)context).transformURL(link);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\linkbuilder\StandardLinkBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */