package org.thymeleaf.linkbuilder;

import java.util.Map;
import org.thymeleaf.context.IExpressionContext;

public interface ILinkBuilder {
  String getName();
  
  Integer getOrder();
  
  String buildLink(IExpressionContext paramIExpressionContext, String paramString, Map<String, Object> paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\linkbuilder\ILinkBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */