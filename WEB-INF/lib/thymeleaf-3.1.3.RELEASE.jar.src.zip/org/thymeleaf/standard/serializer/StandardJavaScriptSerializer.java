/*     */ package org.thymeleaf.standard.serializer;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import com.fasterxml.jackson.core.json.JsonWriteFeature;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.DateFormat;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ import org.thymeleaf.util.DateUtils;
/*     */ import org.unbescape.json.JsonEscape;
/*     */ import org.unbescape.json.JsonEscapeLevel;
/*     */ import org.unbescape.json.JsonEscapeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardJavaScriptSerializer
/*     */   implements IStandardJavaScriptSerializer
/*     */ {
/*  84 */   private static final Logger logger = LoggerFactory.getLogger(StandardJavaScriptSerializer.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final IStandardJavaScriptSerializer delegate;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String computeJacksonPackageNameIfPresent() {
/*     */     try {
/*  95 */       Class<?> objectMapperClass = ObjectMapper.class;
/*  96 */       String objectMapperPackageName = objectMapperClass.getPackage().getName();
/*  97 */       return objectMapperPackageName.substring(0, objectMapperPackageName.length() - ".databind".length());
/*  98 */     } catch (Throwable ignored) {
/*     */       
/* 100 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardJavaScriptSerializer(boolean useJacksonIfAvailable) {
/* 110 */     IStandardJavaScriptSerializer newDelegate = null;
/*     */     
/* 112 */     String jacksonPrefix = useJacksonIfAvailable ? computeJacksonPackageNameIfPresent() : null;
/*     */     
/* 114 */     if (jacksonPrefix != null) {
/*     */       
/*     */       try {
/*     */         
/* 118 */         newDelegate = new JacksonStandardJavaScriptSerializer(jacksonPrefix);
/*     */       }
/* 120 */       catch (Exception e) {
/* 121 */         handleErrorLoggingOnJacksonInitialization(e);
/* 122 */       } catch (NoSuchMethodError e) {
/* 123 */         handleErrorLoggingOnJacksonInitialization(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 128 */     if (newDelegate == null)
/*     */     {
/* 130 */       newDelegate = new DefaultStandardJavaScriptSerializer();
/*     */     }
/*     */     
/* 133 */     this.delegate = newDelegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeValue(Object object, Writer writer) {
/* 140 */     this.delegate.serializeValue(object, writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class JacksonStandardJavaScriptSerializer
/*     */     implements IStandardJavaScriptSerializer
/*     */   {
/*     */     private final ObjectMapper mapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JacksonStandardJavaScriptSerializer(String jacksonPrefix) {
/* 158 */       this.mapper = new ObjectMapper();
/* 159 */       this.mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/* 160 */       this.mapper.disable(new JsonGenerator.Feature[] { JsonGenerator.Feature.AUTO_CLOSE_TARGET });
/* 161 */       this.mapper.getFactory().configure(JsonWriteFeature.ESCAPE_NON_ASCII.mappedFeature(), true);
/* 162 */       this.mapper.getFactory().setCharacterEscapes(new StandardJavaScriptSerializer.JacksonThymeleafCharacterEscapes());
/* 163 */       this.mapper.setDateFormat(new StandardJavaScriptSerializer.JacksonThymeleafISO8601DateFormat());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       Class<?> javaTimeModuleClass = ClassLoaderUtils.findClass(jacksonPrefix + ".datatype.jsr310.JavaTimeModule");
/* 171 */       if (javaTimeModuleClass != null) {
/*     */         
/*     */         try {
/* 174 */           this.mapper.registerModule((Module)javaTimeModuleClass.newInstance());
/* 175 */           this.mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
/* 176 */         } catch (InstantiationException e) {
/* 177 */           throw new ConfigurationException("Exception while trying to initialize JSR310 support for Jackson", e);
/* 178 */         } catch (IllegalAccessException e) {
/* 179 */           throw new ConfigurationException("Exception while trying to initialize JSR310 support for Jackson", e);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeValue(Object object, Writer writer) {
/*     */       try {
/* 188 */         this.mapper.writeValue(writer, object);
/* 189 */       } catch (IOException e) {
/* 190 */         throw new TemplateProcessingException("An exception was raised while trying to serialize object to JavaScript using Jackson", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class JacksonThymeleafISO8601DateFormat
/*     */     extends DateFormat
/*     */   {
/*     */     private static final long serialVersionUID = 1354081220093875129L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SimpleDateFormat dateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JacksonThymeleafISO8601DateFormat() {
/* 231 */       this.dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZ");
/* 232 */       setCalendar(this.dateFormat.getCalendar());
/* 233 */       setNumberFormat(this.dateFormat.getNumberFormat());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition) {
/* 239 */       StringBuffer formatted = this.dateFormat.format(date, toAppendTo, fieldPosition);
/* 240 */       formatted.insert(26, ':');
/* 241 */       return formatted;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Date parse(String source, ParsePosition pos) {
/* 247 */       throw new UnsupportedOperationException("JacksonThymeleafISO8601DateFormat should never be asked for a 'parse' operation");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object clone() {
/* 254 */       JacksonThymeleafISO8601DateFormat other = (JacksonThymeleafISO8601DateFormat)super.clone();
/* 255 */       other.dateFormat = (SimpleDateFormat)this.dateFormat.clone();
/* 256 */       return other;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class JacksonThymeleafCharacterEscapes
/*     */     extends CharacterEscapes
/*     */   {
/* 287 */     private static final int[] CHARACTER_ESCAPES = CharacterEscapes.standardAsciiEscapesForJSON(); static {
/* 288 */       CHARACTER_ESCAPES[47] = -2;
/* 289 */       CHARACTER_ESCAPES[38] = -2;
/*     */     }
/* 291 */     private static final SerializableString SLASH_ESCAPE = (SerializableString)new SerializedString("\\/");
/* 292 */     private static final SerializableString AMPERSAND_ESCAPE = (SerializableString)new SerializedString("\\u0026");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[] getEscapeCodesForAscii() {
/* 302 */       return CHARACTER_ESCAPES;
/*     */     }
/*     */ 
/*     */     
/*     */     public SerializableString getEscapeSequence(int ch) {
/* 307 */       if (ch == 47) {
/* 308 */         return SLASH_ESCAPE;
/*     */       }
/* 310 */       if (ch == 38) {
/* 311 */         return AMPERSAND_ESCAPE;
/*     */       }
/* 313 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class DefaultStandardJavaScriptSerializer
/*     */     implements IStandardJavaScriptSerializer
/*     */   {
/*     */     private DefaultStandardJavaScriptSerializer() {}
/*     */ 
/*     */     
/*     */     public void serializeValue(Object object, Writer writer) {
/*     */       try {
/* 326 */         writeValue(writer, object);
/* 327 */       } catch (IOException e) {
/* 328 */         throw new TemplateProcessingException("An exception was raised while trying to serialize object to JavaScript using the default serializer", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void writeValue(Writer writer, Object object) throws IOException {
/* 335 */       if (object == null) {
/* 336 */         writeNull(writer);
/*     */         return;
/*     */       } 
/* 339 */       if (object instanceof CharSequence) {
/* 340 */         writeString(writer, object.toString());
/*     */         return;
/*     */       } 
/* 343 */       if (object instanceof Character) {
/* 344 */         writeString(writer, object.toString());
/*     */         return;
/*     */       } 
/* 347 */       if (object instanceof Number) {
/* 348 */         writeNumber(writer, (Number)object);
/*     */         return;
/*     */       } 
/* 351 */       if (object instanceof Boolean) {
/* 352 */         writeBoolean(writer, (Boolean)object);
/*     */         return;
/*     */       } 
/* 355 */       if (object instanceof Date) {
/* 356 */         writeDate(writer, (Date)object);
/*     */         return;
/*     */       } 
/* 359 */       if (object instanceof Calendar) {
/* 360 */         writeDate(writer, ((Calendar)object).getTime());
/*     */         return;
/*     */       } 
/* 363 */       if (object.getClass().isArray()) {
/* 364 */         writeArray(writer, object);
/*     */         return;
/*     */       } 
/* 367 */       if (object instanceof Collection) {
/* 368 */         writeCollection(writer, (Collection)object);
/*     */         return;
/*     */       } 
/* 371 */       if (object instanceof Map) {
/* 372 */         writeMap(writer, (Map<?, ?>)object);
/*     */         return;
/*     */       } 
/* 375 */       if (object instanceof Enum) {
/* 376 */         writeEnum(writer, object);
/*     */         return;
/*     */       } 
/* 379 */       writeObject(writer, object);
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeNull(Writer writer) throws IOException {
/* 384 */       writer.write("null");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void writeString(Writer writer, String str) throws IOException {
/* 395 */       writer.write(34);
/* 396 */       writer.write(JsonEscape.escapeJson(str, JsonEscapeType.SINGLE_ESCAPE_CHARS_DEFAULT_TO_UHEXA, JsonEscapeLevel.LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET));
/* 397 */       writer.write(34);
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeNumber(Writer writer, Number number) throws IOException {
/* 402 */       writer.write(number.toString());
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeBoolean(Writer writer, Boolean bool) throws IOException {
/* 407 */       writer.write(bool.toString());
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeDate(Writer writer, Date date) throws IOException {
/* 412 */       writer.write(34);
/* 413 */       writer.write(DateUtils.formatISO(date));
/* 414 */       writer.write(34);
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeArray(Writer writer, Object arrayObj) throws IOException {
/* 419 */       writer.write(91);
/* 420 */       if (arrayObj instanceof Object[]) {
/* 421 */         Object[] array = (Object[])arrayObj;
/* 422 */         boolean first = true;
/* 423 */         for (Object element : array) {
/* 424 */           if (first) {
/* 425 */             first = false;
/*     */           } else {
/* 427 */             writer.write(44);
/*     */           } 
/* 429 */           writeValue(writer, element);
/*     */         } 
/* 431 */       } else if (arrayObj instanceof boolean[]) {
/* 432 */         boolean[] array = (boolean[])arrayObj;
/* 433 */         boolean first = true;
/* 434 */         for (boolean element : array) {
/* 435 */           if (first) {
/* 436 */             first = false;
/*     */           } else {
/* 438 */             writer.write(44);
/*     */           } 
/* 440 */           writeValue(writer, Boolean.valueOf(element));
/*     */         } 
/* 442 */       } else if (arrayObj instanceof byte[]) {
/* 443 */         byte[] array = (byte[])arrayObj;
/* 444 */         boolean first = true;
/* 445 */         for (byte element : array) {
/* 446 */           if (first) {
/* 447 */             first = false;
/*     */           } else {
/* 449 */             writer.write(44);
/*     */           } 
/* 451 */           writeValue(writer, Byte.valueOf(element));
/*     */         } 
/* 453 */       } else if (arrayObj instanceof short[]) {
/* 454 */         short[] array = (short[])arrayObj;
/* 455 */         boolean first = true;
/* 456 */         for (short element : array) {
/* 457 */           if (first) {
/* 458 */             first = false;
/*     */           } else {
/* 460 */             writer.write(44);
/*     */           } 
/* 462 */           writeValue(writer, Short.valueOf(element));
/*     */         } 
/* 464 */       } else if (arrayObj instanceof int[]) {
/* 465 */         int[] array = (int[])arrayObj;
/* 466 */         boolean first = true;
/* 467 */         for (int element : array) {
/* 468 */           if (first) {
/* 469 */             first = false;
/*     */           } else {
/* 471 */             writer.write(44);
/*     */           } 
/* 473 */           writeValue(writer, Integer.valueOf(element));
/*     */         } 
/* 475 */       } else if (arrayObj instanceof long[]) {
/* 476 */         long[] array = (long[])arrayObj;
/* 477 */         boolean first = true;
/* 478 */         for (long element : array) {
/* 479 */           if (first) {
/* 480 */             first = false;
/*     */           } else {
/* 482 */             writer.write(44);
/*     */           } 
/* 484 */           writeValue(writer, Long.valueOf(element));
/*     */         } 
/* 486 */       } else if (arrayObj instanceof float[]) {
/* 487 */         float[] array = (float[])arrayObj;
/* 488 */         boolean first = true;
/* 489 */         for (float element : array) {
/* 490 */           if (first) {
/* 491 */             first = false;
/*     */           } else {
/* 493 */             writer.write(44);
/*     */           } 
/* 495 */           writeValue(writer, Float.valueOf(element));
/*     */         } 
/* 497 */       } else if (arrayObj instanceof double[]) {
/* 498 */         double[] array = (double[])arrayObj;
/* 499 */         boolean first = true;
/* 500 */         for (double element : array) {
/* 501 */           if (first) {
/* 502 */             first = false;
/*     */           } else {
/* 504 */             writer.write(44);
/*     */           } 
/* 506 */           writeValue(writer, Double.valueOf(element));
/*     */         } 
/*     */       } else {
/* 509 */         throw new IllegalArgumentException("Cannot write value \"" + arrayObj + "\" of class " + arrayObj.getClass().getName() + " as an array");
/*     */       } 
/* 511 */       writer.write(93);
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeCollection(Writer writer, Collection<?> collection) throws IOException {
/* 516 */       writer.write(91);
/* 517 */       boolean first = true;
/* 518 */       for (Object element : collection) {
/* 519 */         if (first) {
/* 520 */           first = false;
/*     */         } else {
/* 522 */           writer.write(44);
/*     */         } 
/* 524 */         writeValue(writer, element);
/*     */       } 
/* 526 */       writer.write(93);
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeMap(Writer writer, Map<?, ?> map) throws IOException {
/* 531 */       writer.write(123);
/* 532 */       boolean first = true;
/* 533 */       for (Map.Entry<?, ?> entry : map.entrySet()) {
/* 534 */         if (first) {
/* 535 */           first = false;
/*     */         } else {
/* 537 */           writer.write(44);
/*     */         } 
/* 539 */         writeKeyValue(writer, entry.getKey(), entry.getValue());
/*     */       } 
/* 541 */       writer.write(125);
/*     */     }
/*     */ 
/*     */     
/*     */     private static void writeKeyValue(Writer writer, Object key, Object value) throws IOException {
/* 546 */       writeValue(writer, key);
/* 547 */       writer.write(58);
/* 548 */       writeValue(writer, value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void writeObject(Writer writer, Object object) throws IOException {
/*     */       try {
/* 555 */         PropertyDescriptor[] descriptors = Introspector.getBeanInfo(object.getClass()).getPropertyDescriptors();
/* 556 */         Map<String, Object> properties = new LinkedHashMap<>(descriptors.length + 1, 1.0F);
/* 557 */         for (PropertyDescriptor descriptor : descriptors) {
/* 558 */           Method readMethod = descriptor.getReadMethod();
/* 559 */           if (readMethod != null) {
/* 560 */             String name = descriptor.getName();
/* 561 */             if (!"class".equals(name.toLowerCase())) {
/* 562 */               Object value = readMethod.invoke(object, new Object[0]);
/* 563 */               properties.put(name, value);
/*     */             } 
/*     */           } 
/*     */         } 
/* 567 */         writeMap(writer, properties);
/* 568 */       } catch (IllegalAccessException e) {
/* 569 */         throw new IllegalArgumentException("Could not perform introspection on object of class " + object.getClass().getName(), e);
/* 570 */       } catch (InvocationTargetException e) {
/* 571 */         throw new IllegalArgumentException("Could not perform introspection on object of class " + object.getClass().getName(), e);
/* 572 */       } catch (IntrospectionException e) {
/* 573 */         throw new IllegalArgumentException("Could not perform introspection on object of class " + object.getClass().getName(), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void writeEnum(Writer writer, Object object) throws IOException {
/* 581 */       Enum<?> enumObject = (Enum)object;
/* 582 */       writeString(writer, enumObject.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleErrorLoggingOnJacksonInitialization(Throwable e) {
/* 590 */     String warningMessage = "[THYMELEAF] Could not initialize Jackson-based serializer even if the Jackson library was detected to be present at the classpath. Please make sure you are adding the jackson-databind module to your classpath, and that version is >= 2.5.0. THYMELEAF INITIALIZATION WILL CONTINUE, but Jackson will not be used for JavaScript serialization.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 597 */     if (logger.isDebugEnabled()) {
/* 598 */       logger.warn("[THYMELEAF] Could not initialize Jackson-based serializer even if the Jackson library was detected to be present at the classpath. Please make sure you are adding the jackson-databind module to your classpath, and that version is >= 2.5.0. THYMELEAF INITIALIZATION WILL CONTINUE, but Jackson will not be used for JavaScript serialization.", e);
/*     */     } else {
/*     */       
/* 601 */       logger.warn("[THYMELEAF] Could not initialize Jackson-based serializer even if the Jackson library was detected to be present at the classpath. Please make sure you are adding the jackson-databind module to your classpath, and that version is >= 2.5.0. THYMELEAF INITIALIZATION WILL CONTINUE, but Jackson will not be used for JavaScript serialization. Set the log to DEBUG to see a complete exception trace. Exception message is: " + e
/*     */           
/* 603 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\serializer\StandardJavaScriptSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */