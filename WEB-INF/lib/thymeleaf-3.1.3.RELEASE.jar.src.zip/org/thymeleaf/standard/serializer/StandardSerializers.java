/*     */ package org.thymeleaf.standard.serializer;
/*     */ 
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardSerializers
/*     */ {
/*     */   public static final String STANDARD_JAVASCRIPT_SERIALIZER_ATTRIBUTE_NAME = "StandardJavaScriptSerializer";
/*     */   public static final String STANDARD_CSS_SERIALIZER_ATTRIBUTE_NAME = "StandardCSSSerializer";
/*     */   
/*     */   public static IStandardJavaScriptSerializer getJavaScriptSerializer(IEngineConfiguration configuration) {
/*  71 */     Object serializer = configuration.getExecutionAttributes().get("StandardJavaScriptSerializer");
/*  72 */     if (serializer == null || !(serializer instanceof IStandardJavaScriptSerializer)) {
/*  73 */       throw new TemplateProcessingException("No JavaScript Serializer has been registered as an execution argument. This is a requirement for using Standard serialization, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardJavaScriptSerializer.class
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  78 */           .getName() + " with name \"" + "StandardJavaScriptSerializer" + "\"");
/*     */     }
/*     */     
/*  81 */     return (IStandardJavaScriptSerializer)serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStandardCSSSerializer getCSSSerializer(IEngineConfiguration configuration) {
/*  97 */     Object serializer = configuration.getExecutionAttributes().get("StandardCSSSerializer");
/*  98 */     if (serializer == null || !(serializer instanceof IStandardCSSSerializer)) {
/*  99 */       throw new TemplateProcessingException("No CSS Serializer has been registered as an execution argument. This is a requirement for using Standard serialization, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardCSSSerializer.class
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 104 */           .getName() + " with name \"" + "StandardCSSSerializer" + "\"");
/*     */     }
/*     */     
/* 107 */     return (IStandardCSSSerializer)serializer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\serializer\StandardSerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */