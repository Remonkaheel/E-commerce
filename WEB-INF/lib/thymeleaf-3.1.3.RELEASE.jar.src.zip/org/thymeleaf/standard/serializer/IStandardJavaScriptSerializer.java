package org.thymeleaf.standard.serializer;

import java.io.Writer;

public interface IStandardJavaScriptSerializer {
  void serializeValue(Object paramObject, Writer paramWriter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\serializer\IStandardJavaScriptSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */