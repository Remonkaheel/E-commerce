/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.model.IComment;
/*    */ import org.thymeleaf.processor.comment.AbstractCommentProcessor;
/*    */ import org.thymeleaf.processor.comment.ICommentStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInliningCommentProcessor
/*    */   extends AbstractCommentProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   
/*    */   public StandardInliningCommentProcessor(TemplateMode templateMode) {
/* 39 */     super(templateMode, 1000);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IComment comment, ICommentStructureHandler structureHandler) {
/* 49 */     IInliner inliner = context.getInliner();
/*    */     
/* 51 */     if (inliner == null || inliner == NoOpInliner.INSTANCE) {
/*    */       return;
/*    */     }
/*    */     
/* 55 */     CharSequence inlined = inliner.inline(context, comment);
/* 56 */     if (inlined != null && inlined != comment)
/* 57 */       structureHandler.setContent(inlined); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInliningCommentProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */