/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.AttributeNames;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.LoggingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class StandardIncludeTagProcessor
/*    */   extends AbstractStandardFragmentInsertionTagProcessor
/*    */ {
/* 44 */   private static final Logger LOGGER = LoggerFactory.getLogger(StandardIncludeTagProcessor.class);
/*    */ 
/*    */   
/*    */   public static final int PRECEDENCE = 100;
/*    */ 
/*    */   
/*    */   public static final String ATTR_NAME = "include";
/*    */ 
/*    */   
/*    */   public StandardIncludeTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 54 */     super(templateMode, dialectPrefix, "include", 100, false, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 66 */     if (LOGGER.isWarnEnabled()) {
/* 67 */       LOGGER.warn("[THYMELEAF][{}][{}] Deprecated attribute {} found in template {}, line {}, col {}. Please use {} instead, this deprecated attribute will be removed in future versions of Thymeleaf.", new Object[] {
/*    */ 
/*    */ 
/*    */             
/* 71 */             TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(context.getTemplateData().getTemplate()), attributeName, tag
/* 72 */             .getTemplateName(), 
/* 73 */             Integer.valueOf(tag.getAttribute(attributeName).getLine()), Integer.valueOf(tag.getAttribute(attributeName).getCol()), 
/* 74 */             AttributeNames.forHTMLName(attributeName.getPrefix(), "insert")
/*    */           });
/*    */     }
/* 77 */     super.doProcess(context, tag, attributeName, attributeValue, structureHandler);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardIncludeTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */