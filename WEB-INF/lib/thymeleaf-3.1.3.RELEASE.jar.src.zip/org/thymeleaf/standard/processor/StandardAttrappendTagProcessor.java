/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardAttrappendTagProcessor
/*    */   extends AbstractStandardMultipleAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 900;
/*    */   public static final String ATTR_NAME = "attrappend";
/*    */   
/*    */   public StandardAttrappendTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 38 */     super(templateMode, dialectPrefix, "attrappend", 900, AbstractStandardMultipleAttributeModifierTagProcessor.ModificationType.APPEND, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardAttrappendTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */