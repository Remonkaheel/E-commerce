/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardLangXmlLangTagProcessor
/*    */   extends AbstractStandardDoubleAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 990;
/*    */   public static final String ATTR_NAME = "lang-xmllang";
/*    */   public static final String TARGET_ATTR_NAME_ONE = "lang";
/*    */   public static final String TARGET_ATTR_NAME_TWO = "xml:lang";
/*    */   
/*    */   public StandardLangXmlLangTagProcessor(String dialectPrefix) {
/* 40 */     super(TemplateMode.HTML, dialectPrefix, "lang-xmllang", 990, "lang", "xml:lang", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardLangXmlLangTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */