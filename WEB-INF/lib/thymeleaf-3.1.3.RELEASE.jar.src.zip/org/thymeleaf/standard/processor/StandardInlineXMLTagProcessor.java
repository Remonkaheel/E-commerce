/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.standard.inline.StandardInlineMode;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.standard.inline.StandardXMLInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineXMLTagProcessor
/*    */   extends AbstractStandardTextInlineSettingTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "inline";
/*    */   
/*    */   public StandardInlineXMLTagProcessor(String dialectPrefix) {
/* 47 */     super(TemplateMode.XML, dialectPrefix, "inline", 1000);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IInliner getInliner(ITemplateContext context, StandardInlineMode inlineMode) {
/* 55 */     switch (inlineMode) {
/*    */       case NONE:
/* 57 */         return (IInliner)NoOpInliner.INSTANCE;
/*    */       case XML:
/* 59 */         return (IInliner)new StandardXMLInliner(context.getConfiguration());
/*    */       case TEXT:
/* 61 */         return (IInliner)new StandardTextInliner(context.getConfiguration());
/*    */     } 
/* 63 */     throw new TemplateProcessingException("Invalid inline mode selected: " + inlineMode + ". Allowed inline modes in template mode " + 
/*    */         
/* 65 */         getTemplateMode() + " are: \"" + StandardInlineMode.XML + "\", \"" + StandardInlineMode.TEXT + "\", \"" + StandardInlineMode.NONE + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineXMLTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */