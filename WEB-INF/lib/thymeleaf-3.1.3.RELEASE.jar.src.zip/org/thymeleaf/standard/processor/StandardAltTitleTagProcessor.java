/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardAltTitleTagProcessor
/*    */   extends AbstractStandardDoubleAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 990;
/*    */   public static final String ATTR_NAME = "alt-title";
/*    */   public static final String TARGET_ATTR_NAME_ONE = "alt";
/*    */   public static final String TARGET_ATTR_NAME_TWO = "title";
/*    */   
/*    */   public StandardAltTitleTagProcessor(String dialectPrefix) {
/* 40 */     super(TemplateMode.HTML, dialectPrefix, "alt-title", 990, "alt", "title", true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardAltTitleTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */