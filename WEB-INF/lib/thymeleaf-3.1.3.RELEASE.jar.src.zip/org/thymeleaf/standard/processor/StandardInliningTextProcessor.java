/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.EngineEventUtils;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.model.IText;
/*    */ import org.thymeleaf.processor.text.AbstractTextProcessor;
/*    */ import org.thymeleaf.processor.text.ITextStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInliningTextProcessor
/*    */   extends AbstractTextProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   
/*    */   public StandardInliningTextProcessor(TemplateMode templateMode) {
/* 40 */     super(templateMode, 1000);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IText text, ITextStructureHandler structureHandler) {
/* 49 */     if (EngineEventUtils.isWhitespace(text)) {
/*    */       return;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     IInliner inliner = context.getInliner();
/*    */     
/* 58 */     if (inliner == null || inliner == NoOpInliner.INSTANCE) {
/*    */       return;
/*    */     }
/*    */     
/* 62 */     CharSequence inlined = inliner.inline(context, text);
/* 63 */     if (inlined != null && inlined != text)
/* 64 */       structureHandler.setText(inlined); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInliningTextProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */