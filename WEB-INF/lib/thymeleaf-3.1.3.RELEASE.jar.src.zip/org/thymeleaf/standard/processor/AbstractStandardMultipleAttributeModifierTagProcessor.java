/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.Assignation;
/*     */ import org.thymeleaf.standard.expression.AssignationSequence;
/*     */ import org.thymeleaf.standard.expression.AssignationUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.ArrayUtils;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardMultipleAttributeModifierTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */ {
/*     */   private final ModificationType modificationType;
/*     */   private final boolean restrictedExpressionExecution;
/*     */   
/*     */   protected enum ModificationType
/*     */   {
/*  52 */     SUBSTITUTION, APPEND, PREPEND, APPEND_WITH_SPACE, PREPEND_WITH_SPACE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractStandardMultipleAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, ModificationType modificationType) {
/*  74 */     this(templateMode, dialectPrefix, attrName, precedence, modificationType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractStandardMultipleAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, ModificationType modificationType, boolean restrictedExpressionExecution) {
/*  98 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*  99 */     this.modificationType = modificationType;
/* 100 */     this.restrictedExpressionExecution = restrictedExpressionExecution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 115 */     AssignationSequence assignations = AssignationUtils.parseAssignationSequence((IExpressionContext)context, attributeValue, false);
/*     */     
/* 117 */     if (assignations == null) {
/* 118 */       throw new TemplateProcessingException("Could not parse value as attribute assignations: \"" + attributeValue + "\"");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     StandardExpressionExecutionContext expCtx = this.restrictedExpressionExecution ? StandardExpressionExecutionContext.RESTRICTED : StandardExpressionExecutionContext.NORMAL;
/*     */     
/* 127 */     List<Assignation> assignationValues = assignations.getAssignations();
/* 128 */     int assignationValuesLen = assignationValues.size();
/*     */     
/* 130 */     for (int i = 0; i < assignationValuesLen; i++) {
/*     */       
/* 132 */       Assignation assignation = assignationValues.get(i);
/*     */       
/* 134 */       IStandardExpression leftExpr = assignation.getLeft();
/* 135 */       Object leftValue = leftExpr.execute((IExpressionContext)context, expCtx);
/*     */       
/* 137 */       IStandardExpression rightExpr = assignation.getRight();
/* 138 */       Object rightValue = rightExpr.execute((IExpressionContext)context, expCtx);
/*     */       
/* 140 */       if (rightValue != NoOpToken.VALUE) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 145 */         String newAttributeName = (leftValue == null) ? null : leftValue.toString();
/* 146 */         if (StringUtils.isEmptyOrWhitespace(newAttributeName)) {
/* 147 */           throw new TemplateProcessingException("Attribute name expression evaluated as null or empty: \"" + leftExpr + "\"");
/*     */         }
/*     */ 
/*     */         
/* 151 */         if (getTemplateMode() == TemplateMode.HTML && this.modificationType == ModificationType.SUBSTITUTION && 
/*     */           
/* 153 */           ArrayUtils.contains((Object[])StandardConditionalFixedValueTagProcessor.ATTR_NAMES, newAttributeName)) {
/*     */ 
/*     */ 
/*     */           
/* 157 */           if (EvaluationUtils.evaluateAsBoolean(rightValue)) {
/* 158 */             structureHandler.setAttribute(newAttributeName, newAttributeName);
/*     */           } else {
/* 160 */             structureHandler.removeAttribute(newAttributeName);
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 167 */           String newAttributeValue = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), (rightValue == null) ? null : rightValue.toString());
/* 168 */           if (newAttributeValue == null || newAttributeValue.length() == 0) {
/*     */             
/* 170 */             if (this.modificationType == ModificationType.SUBSTITUTION)
/*     */             {
/* 172 */               structureHandler.removeAttribute(newAttributeName);
/*     */ 
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 178 */           else if (this.modificationType == ModificationType.SUBSTITUTION || 
/* 179 */             !tag.hasAttribute(newAttributeName) || tag
/* 180 */             .getAttributeValue(newAttributeName).length() == 0) {
/*     */             
/* 182 */             structureHandler.setAttribute(newAttributeName, newAttributeValue);
/*     */           } else {
/* 184 */             String currentValue = tag.getAttributeValue(newAttributeName);
/* 185 */             if (this.modificationType == ModificationType.APPEND) {
/* 186 */               structureHandler.setAttribute(newAttributeName, currentValue + newAttributeValue);
/* 187 */             } else if (this.modificationType == ModificationType.APPEND_WITH_SPACE) {
/* 188 */               structureHandler.setAttribute(newAttributeName, currentValue + ' ' + newAttributeValue);
/* 189 */             } else if (this.modificationType == ModificationType.PREPEND) {
/* 190 */               structureHandler.setAttribute(newAttributeName, newAttributeValue + currentValue);
/*     */             } else {
/* 192 */               structureHandler.setAttribute(newAttributeName, newAttributeValue + ' ' + currentValue);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardMultipleAttributeModifierTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */