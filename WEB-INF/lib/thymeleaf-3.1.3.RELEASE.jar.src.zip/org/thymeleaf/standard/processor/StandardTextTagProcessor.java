/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.LazyEscapingCharSequence;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ import org.unbescape.xml.XmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardTextTagProcessor
/*     */   extends AbstractStandardExpressionAttributeTagProcessor
/*     */ {
/*     */   public static final int PRECEDENCE = 1300;
/*     */   public static final String ATTR_NAME = "text";
/*     */   
/*     */   public StandardTextTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/*  48 */     super(templateMode, dialectPrefix, "text", 1300, true, (templateMode == TemplateMode.TEXT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler) {
/*     */     LazyEscapingCharSequence lazyEscapingCharSequence;
/*  61 */     TemplateMode templateMode = getTemplateMode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (templateMode != TemplateMode.JAVASCRIPT && templateMode != TemplateMode.CSS) {
/*     */       
/*  80 */       String input = (expressionResult == null) ? "" : expressionResult.toString();
/*     */       
/*  82 */       if (templateMode == TemplateMode.RAW) {
/*     */ 
/*     */         
/*  85 */         CharSequence text = input;
/*     */ 
/*     */       
/*     */       }
/*  89 */       else if (input.length() > 100) {
/*     */         
/*  91 */         lazyEscapingCharSequence = new LazyEscapingCharSequence(context.getConfiguration(), templateMode, input);
/*     */       } else {
/*     */         
/*  94 */         CharSequence text = produceEscapedOutput(templateMode, input);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 103 */       lazyEscapingCharSequence = new LazyEscapingCharSequence(context.getConfiguration(), templateMode, expressionResult);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 108 */     structureHandler.setBody((CharSequence)lazyEscapingCharSequence, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String produceEscapedOutput(TemplateMode templateMode, String input) {
/* 115 */     switch (templateMode) {
/*     */ 
/*     */       
/*     */       case TEXT:
/*     */       case HTML:
/* 120 */         return HtmlEscape.escapeHtml4Xml(input);
/*     */ 
/*     */       
/*     */       case XML:
/* 124 */         return XmlEscape.escapeXml10(input);
/*     */     } 
/* 126 */     throw new TemplateProcessingException("Unrecognized template mode " + templateMode + ". Cannot produce escaped output for this template mode.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardTextTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */