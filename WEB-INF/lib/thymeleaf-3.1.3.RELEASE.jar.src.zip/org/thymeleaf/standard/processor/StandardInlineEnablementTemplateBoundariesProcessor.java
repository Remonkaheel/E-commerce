/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.model.ITemplateEnd;
/*    */ import org.thymeleaf.model.ITemplateStart;
/*    */ import org.thymeleaf.processor.templateboundaries.AbstractTemplateBoundariesProcessor;
/*    */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesStructureHandler;
/*    */ import org.thymeleaf.standard.inline.StandardCSSInliner;
/*    */ import org.thymeleaf.standard.inline.StandardHTMLInliner;
/*    */ import org.thymeleaf.standard.inline.StandardJavaScriptInliner;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.standard.inline.StandardXMLInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineEnablementTemplateBoundariesProcessor
/*    */   extends AbstractTemplateBoundariesProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 10;
/*    */   
/*    */   public StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode templateMode) {
/* 47 */     super(templateMode, 10);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doProcessTemplateStart(ITemplateContext context, ITemplateStart templateStart, ITemplateBoundariesStructureHandler structureHandler) {
/* 56 */     switch (getTemplateMode()) {
/*    */       
/*    */       case HTML:
/* 59 */         structureHandler.setInliner((IInliner)new StandardHTMLInliner(context.getConfiguration()));
/*    */         return;
/*    */       case XML:
/* 62 */         structureHandler.setInliner((IInliner)new StandardXMLInliner(context.getConfiguration()));
/*    */         return;
/*    */       case TEXT:
/* 65 */         structureHandler.setInliner((IInliner)new StandardTextInliner(context.getConfiguration()));
/*    */         return;
/*    */       case JAVASCRIPT:
/* 68 */         structureHandler.setInliner((IInliner)new StandardJavaScriptInliner(context.getConfiguration()));
/*    */         return;
/*    */       case CSS:
/* 71 */         structureHandler.setInliner((IInliner)new StandardCSSInliner(context.getConfiguration()));
/*    */         return;
/*    */ 
/*    */       
/*    */       case RAW:
/* 76 */         structureHandler.setInliner(null);
/*    */         return;
/*    */     } 
/* 79 */     throw new TemplateProcessingException("Unrecognized template mode: " + 
/* 80 */         getTemplateMode() + ", cannot initialize inlining!");
/*    */   }
/*    */   
/*    */   public void doProcessTemplateEnd(ITemplateContext context, ITemplateEnd templateEnd, ITemplateBoundariesStructureHandler structureHandler) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineEnablementTemplateBoundariesProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */