/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.standard.inline.StandardCSSInliner;
/*    */ import org.thymeleaf.standard.inline.StandardHTMLInliner;
/*    */ import org.thymeleaf.standard.inline.StandardInlineMode;
/*    */ import org.thymeleaf.standard.inline.StandardJavaScriptInliner;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineHTMLTagProcessor
/*    */   extends AbstractStandardTextInlineSettingTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "inline";
/*    */   
/*    */   public StandardInlineHTMLTagProcessor(String dialectPrefix) {
/* 49 */     super(TemplateMode.HTML, dialectPrefix, "inline", 1000);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IInliner getInliner(ITemplateContext context, StandardInlineMode inlineMode) {
/* 57 */     switch (inlineMode) {
/*    */       case NONE:
/* 59 */         return (IInliner)NoOpInliner.INSTANCE;
/*    */       case HTML:
/* 61 */         return (IInliner)new StandardHTMLInliner(context.getConfiguration());
/*    */       case TEXT:
/* 63 */         return (IInliner)new StandardTextInliner(context.getConfiguration());
/*    */       case JAVASCRIPT:
/* 65 */         return (IInliner)new StandardJavaScriptInliner(context.getConfiguration());
/*    */       case CSS:
/* 67 */         return (IInliner)new StandardCSSInliner(context.getConfiguration());
/*    */     } 
/* 69 */     throw new TemplateProcessingException("Invalid inline mode selected: " + inlineMode + ". Allowed inline modes in template mode " + 
/*    */         
/* 71 */         getTemplateMode() + " are: \"" + StandardInlineMode.HTML + "\", \"" + StandardInlineMode.TEXT + "\", \"" + StandardInlineMode.JAVASCRIPT + "\", \"" + StandardInlineMode.CSS + "\" and \"" + StandardInlineMode.NONE + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineHTMLTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */