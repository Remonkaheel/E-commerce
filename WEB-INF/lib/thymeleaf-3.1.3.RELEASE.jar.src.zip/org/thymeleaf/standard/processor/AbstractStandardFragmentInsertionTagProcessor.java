/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.Fragment;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentSignature;
/*     */ import org.thymeleaf.standard.expression.FragmentSignatureUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardFragmentInsertionTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */ {
/*  66 */   private static final Logger LOGGER = LoggerFactory.getLogger(AbstractStandardFragmentInsertionTagProcessor.class);
/*     */ 
/*     */   
/*     */   private static final String FRAGMENT_ATTR_NAME = "fragment";
/*     */ 
/*     */   
/*     */   private final boolean replaceHost;
/*     */ 
/*     */   
/*     */   private final boolean insertOnlyContents;
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractStandardFragmentInsertionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean replaceHost) {
/*  80 */     this(templateMode, dialectPrefix, attrName, precedence, replaceHost, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractStandardFragmentInsertionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean replaceHost, boolean insertOnlyContents) {
/*  91 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*  92 */     this.replaceHost = replaceHost;
/*  93 */     this.insertOnlyContents = insertOnlyContents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 106 */     if (StringUtils.isEmptyOrWhitespace(attributeValue)) {
/* 107 */       throw new TemplateProcessingException("Fragment specifications cannot be empty");
/*     */     }
/*     */     
/* 110 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     Object fragmentObj = computeFragment(context, attributeValue, tag
/* 116 */         .getTemplateName(), tag
/* 117 */         .getAttribute(attributeName).getLine(), tag.getAttribute(attributeName).getCol());
/* 118 */     if (fragmentObj == null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 123 */       throw new TemplateInputException("Error resolving fragment: \"" + attributeValue + "\": template or fragment could not be resolved");
/*     */     }
/*     */ 
/*     */     
/* 127 */     if (fragmentObj == NoOpToken.VALUE) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 132 */     if (fragmentObj == Fragment.EMPTY_FRAGMENT) {
/*     */ 
/*     */ 
/*     */       
/* 136 */       if (this.replaceHost) {
/* 137 */         structureHandler.removeElement();
/*     */       } else {
/* 139 */         structureHandler.removeBody();
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 146 */     Fragment fragment = (Fragment)fragmentObj;
/*     */ 
/*     */     
/* 149 */     TemplateModel fragmentModel = fragment.getTemplateModel();
/* 150 */     Map<String, Object> fragmentParameters = fragment.getParameters();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     boolean signatureApplied = false;
/* 164 */     ITemplateEvent firstEvent = (fragmentModel.size() > 2) ? fragmentModel.get(1) : null;
/* 165 */     if (firstEvent != null && IProcessableElementTag.class.isAssignableFrom(firstEvent.getClass())) {
/*     */       
/* 167 */       String dialectPrefix = attributeName.getPrefix();
/* 168 */       IProcessableElementTag fragmentHolderEvent = (IProcessableElementTag)firstEvent;
/*     */       
/* 170 */       if (fragmentHolderEvent.hasAttribute(dialectPrefix, "fragment")) {
/*     */ 
/*     */ 
/*     */         
/* 174 */         String fragmentSignatureSpec = EscapedAttributeUtils.unescapeAttribute(fragmentModel.getTemplateMode(), fragmentHolderEvent.getAttributeValue(dialectPrefix, "fragment"));
/* 175 */         if (!StringUtils.isEmptyOrWhitespace(fragmentSignatureSpec)) {
/*     */ 
/*     */           
/* 178 */           FragmentSignature fragmentSignature = FragmentSignatureUtils.parseFragmentSignature(configuration, fragmentSignatureSpec);
/* 179 */           if (fragmentSignature != null) {
/*     */ 
/*     */             
/* 182 */             fragmentParameters = FragmentSignatureUtils.processParameters(fragmentSignature, fragmentParameters, fragment.hasSyntheticParameters());
/* 183 */             signatureApplied = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (!signatureApplied && fragment.hasSyntheticParameters()) {
/* 197 */       throw new TemplateProcessingException("Fragment '" + attributeValue + "' specifies synthetic (unnamed) parameters, but the resolved fragment does not match a fragment signature (th:fragment,data-th-fragment) which could apply names to the specified parameters.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     if (context.getTemplateMode() != fragmentModel.getTemplateMode()) {
/*     */ 
/*     */       
/* 220 */       if (this.insertOnlyContents) {
/* 221 */         throw new TemplateProcessingException("Template being processed uses template mode " + context
/* 222 */             .getTemplateMode() + ", inserted fragment \"" + attributeValue + "\" uses template mode " + fragmentModel
/*     */             
/* 224 */             .getTemplateMode() + ". Cross-template-mode fragment insertion is not allowed using the " + attributeName + " attribute, which is no longer recommended for use as of Thymeleaf 3.0. Use {th:insert,data-th-insert} or {th:replace,data-th-replace} instead, which do not remove the container element from the fragment being inserted.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 232 */       if (fragmentParameters != null && fragmentParameters.size() > 0) {
/*     */         
/* 234 */         if (!(context instanceof IEngineContext)) {
/* 235 */           throw new TemplateProcessingException("Parameterized fragment insertion is not supported because local variable support is DISABLED. This is due to the use of an implementation of the " + ITemplateContext.class
/*     */               
/* 237 */               .getName() + " interface that does not provide local-variable support. In order to have local-variable support, the variables map implementation should also implement the " + IEngineContext.class
/*     */               
/* 239 */               .getName() + " interface");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 244 */         ((IEngineContext)context).setVariables(fragmentParameters);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 249 */       FastStringWriter fastStringWriter = new FastStringWriter(200);
/* 250 */       configuration.getTemplateManager().process(fragmentModel, context, (Writer)fastStringWriter);
/*     */ 
/*     */       
/* 253 */       if (this.replaceHost) {
/* 254 */         structureHandler.replaceWith(fastStringWriter.toString(), false);
/*     */       } else {
/* 256 */         structureHandler.setBody(fastStringWriter.toString(), false);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 267 */     TemplateData fragmentTemplateData = fragmentModel.getTemplateData();
/* 268 */     structureHandler.setTemplateData(fragmentTemplateData);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     if (fragmentParameters != null && fragmentParameters.size() > 0) {
/* 275 */       for (Map.Entry<String, Object> fragmentParameterEntry : fragmentParameters.entrySet()) {
/* 276 */         structureHandler.setLocalVariable(fragmentParameterEntry.getKey(), fragmentParameterEntry.getValue());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     if (this.insertOnlyContents && fragmentTemplateData.hasTemplateSelectors()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 293 */       IModel model = fragmentModel.cloneModel();
/* 294 */       int modelLevel = 0;
/* 295 */       int n = model.size();
/* 296 */       while (n-- != 0) {
/*     */         
/* 298 */         ITemplateEvent event = model.get(n);
/*     */         
/* 300 */         if (event instanceof ICloseElementTag) {
/* 301 */           if (((ICloseElementTag)event).isUnmatched()) {
/*     */             continue;
/*     */           }
/*     */           
/* 305 */           if (modelLevel <= 0) {
/* 306 */             model.remove(n);
/*     */           }
/* 308 */           modelLevel++;
/*     */           continue;
/*     */         } 
/* 311 */         if (event instanceof org.thymeleaf.model.IOpenElementTag) {
/* 312 */           modelLevel--;
/* 313 */           if (modelLevel <= 0) {
/* 314 */             model.remove(n);
/*     */           }
/*     */           continue;
/*     */         } 
/* 318 */         if (modelLevel <= 0) {
/* 319 */           model.remove(n);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 324 */       if (this.replaceHost) {
/* 325 */         structureHandler.replaceWith(model, true);
/*     */       } else {
/* 327 */         structureHandler.setBody(model, true);
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 335 */     if (this.replaceHost) {
/* 336 */       structureHandler.replaceWith((IModel)fragmentModel, true);
/*     */     } else {
/* 338 */       structureHandler.setBody((IModel)fragmentModel, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object computeFragment(ITemplateContext context, String input, String templateName, int attributeLine, int attributeCol) {
/*     */     Object fragmentExpressionResult;
/* 353 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*     */     
/* 355 */     String trimmedInput = input.trim();
/*     */     
/* 357 */     if (shouldBeWrappedAsFragmentExpression(trimmedInput)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 365 */       FragmentExpression fragmentExpression1 = (FragmentExpression)expressionParser.parseExpression((IExpressionContext)context, "~{" + trimmedInput + "}");
/*     */ 
/*     */       
/* 368 */       FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression((IExpressionContext)context, fragmentExpression1);
/*     */       
/* 370 */       if (executedFragmentExpression.getFragmentSelectorExpressionResult() == null && executedFragmentExpression.getFragmentParameters() == null) {
/*     */ 
/*     */         
/* 373 */         Object templateNameExpressionResult = executedFragmentExpression.getTemplateNameExpressionResult();
/* 374 */         if (templateNameExpressionResult != null) {
/* 375 */           if (templateNameExpressionResult instanceof Fragment) {
/* 376 */             return templateNameExpressionResult;
/*     */           }
/* 378 */           if (templateNameExpressionResult == NoOpToken.VALUE) {
/* 379 */             return NoOpToken.VALUE;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 384 */       if (LOGGER.isWarnEnabled()) {
/* 385 */         LOGGER.warn("[THYMELEAF][{}][{}] Deprecated unwrapped fragment expression \"{}\" found in template {}, line {}, col {}. Please use the complete syntax of fragment expressions instead (\"{}\"). The old, unwrapped syntax for fragment expressions will be removed in future versions of Thymeleaf.", new Object[] {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 390 */               TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(context.getTemplateData().getTemplate()), trimmedInput, templateName, 
/* 391 */               Integer.valueOf(attributeLine), Integer.valueOf(attributeCol), "~{" + trimmedInput + "}"
/*     */             });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 399 */       return FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 406 */     IStandardExpression fragmentExpression = expressionParser.parseExpression((IExpressionContext)context, trimmedInput);
/*     */ 
/*     */ 
/*     */     
/* 410 */     if (fragmentExpression != null && fragmentExpression instanceof FragmentExpression) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 416 */       FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression((IExpressionContext)context, (FragmentExpression)fragmentExpression);
/*     */ 
/*     */       
/* 419 */       fragmentExpressionResult = FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */     }
/*     */     else {
/*     */       
/* 423 */       fragmentExpressionResult = fragmentExpression.execute((IExpressionContext)context);
/*     */     } 
/*     */ 
/*     */     
/* 427 */     if (fragmentExpressionResult == null || fragmentExpressionResult == NoOpToken.VALUE) {
/* 428 */       return fragmentExpressionResult;
/*     */     }
/*     */     
/* 431 */     if (!(fragmentExpressionResult instanceof Fragment)) {
/* 432 */       throw new TemplateProcessingException("Invalid fragment specification: \"" + input + "\": expression does not return a Fragment object");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 437 */     return fragmentExpressionResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean shouldBeWrappedAsFragmentExpression(String input) {
/* 445 */     int inputLen = input.length();
/* 446 */     if (inputLen > 2 && input.charAt(0) == '~' && input.charAt(1) == '{')
/*     */     {
/* 448 */       return false;
/*     */     }
/*     */     
/* 451 */     int bracketLevel = 0;
/* 452 */     int paramLevel = 0;
/* 453 */     boolean inLiteral = false;
/* 454 */     int n = inputLen;
/* 455 */     int i = 0;
/* 456 */     while (n-- != 0) {
/*     */       
/* 458 */       char c = input.charAt(i);
/*     */       
/* 460 */       if ((c >= 'a' && c <= 'z') || c == ' ') {
/*     */         
/* 462 */         i++;
/*     */         
/*     */         continue;
/*     */       } 
/* 466 */       if (c == '\'') {
/* 467 */         inLiteral = !inLiteral;
/* 468 */       } else if (!inLiteral) {
/* 469 */         if (c == '{') {
/* 470 */           bracketLevel++;
/* 471 */         } else if (c == '}') {
/* 472 */           bracketLevel--;
/* 473 */         } else if (bracketLevel == 0) {
/* 474 */           if (c == '(')
/* 475 */           { paramLevel++; }
/* 476 */           else if (c == ')')
/* 477 */           { paramLevel--; }
/* 478 */           else { if (c == '=' && paramLevel == 1)
/*     */             {
/*     */               
/* 481 */               return true; } 
/* 482 */             if (c == '~' && n != 0 && input.charAt(i + 1) == '{')
/*     */             {
/* 484 */               return false; } 
/* 485 */             if (c == ':' && n != 0 && input.charAt(i + 1) == ':')
/*     */             {
/*     */               
/* 488 */               return true;
/*     */             } }
/*     */         
/*     */         } 
/*     */       } 
/* 493 */       i++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 500 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardFragmentInsertionTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */