/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardReplaceTagProcessor
/*    */   extends AbstractStandardFragmentInsertionTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 100;
/*    */   public static final String ATTR_NAME = "replace";
/*    */   
/*    */   public StandardReplaceTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 41 */     super(templateMode, dialectPrefix, "replace", 100, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardReplaceTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */