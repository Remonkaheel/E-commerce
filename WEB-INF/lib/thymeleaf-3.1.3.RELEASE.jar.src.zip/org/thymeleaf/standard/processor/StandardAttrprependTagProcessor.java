/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardAttrprependTagProcessor
/*    */   extends AbstractStandardMultipleAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 800;
/*    */   public static final String ATTR_NAME = "attrprepend";
/*    */   
/*    */   public StandardAttrprependTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 38 */     super(templateMode, dialectPrefix, "attrprepend", 800, AbstractStandardMultipleAttributeModifierTagProcessor.ModificationType.PREPEND, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardAttrprependTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */