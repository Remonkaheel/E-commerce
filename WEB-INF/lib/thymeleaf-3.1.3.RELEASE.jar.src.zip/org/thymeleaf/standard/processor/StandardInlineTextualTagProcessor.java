/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.standard.inline.StandardCSSInliner;
/*    */ import org.thymeleaf.standard.inline.StandardInlineMode;
/*    */ import org.thymeleaf.standard.inline.StandardJavaScriptInliner;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineTextualTagProcessor
/*    */   extends AbstractStandardTextInlineSettingTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "inline";
/*    */   
/*    */   public StandardInlineTextualTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 49 */     super(templateMode, dialectPrefix, "inline", 1000);
/* 50 */     Validate.isTrue(templateMode.isText(), "Template mode must be a textual one");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IInliner getInliner(ITemplateContext context, StandardInlineMode inlineMode) {
/* 58 */     TemplateMode templateMode = getTemplateMode();
/*    */     
/* 60 */     switch (inlineMode) {
/*    */       case NONE:
/* 62 */         return (IInliner)NoOpInliner.INSTANCE;
/*    */       case TEXT:
/* 64 */         if (templateMode == TemplateMode.TEXT) {
/* 65 */           return (IInliner)new StandardTextInliner(context.getConfiguration());
/*    */         }
/*    */         break;
/*    */       case JAVASCRIPT:
/* 69 */         if (templateMode == TemplateMode.JAVASCRIPT) {
/* 70 */           return (IInliner)new StandardJavaScriptInliner(context.getConfiguration());
/*    */         }
/*    */         break;
/*    */       case CSS:
/* 74 */         if (templateMode == TemplateMode.CSS) {
/* 75 */           return (IInliner)new StandardCSSInliner(context.getConfiguration());
/*    */         }
/*    */         break;
/*    */     } 
/*    */     
/* 80 */     throw new TemplateProcessingException("Invalid inline mode selected: " + inlineMode + ". Allowed inline modes in template mode " + 
/*    */         
/* 82 */         getTemplateMode() + " are: \"" + getTemplateMode() + "\" and \"" + StandardInlineMode.NONE + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineTextualTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */