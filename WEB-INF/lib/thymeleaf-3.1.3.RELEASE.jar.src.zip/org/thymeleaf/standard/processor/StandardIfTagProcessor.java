/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*    */ import org.thymeleaf.standard.expression.StandardExpressions;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardIfTagProcessor
/*    */   extends AbstractStandardConditionalVisibilityTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 300;
/*    */   public static final String ATTR_NAME = "if";
/*    */   
/*    */   public StandardIfTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 44 */     super(templateMode, dialectPrefix, "if", 300);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isVisible(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue) {
/* 55 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*    */ 
/*    */     
/* 58 */     IStandardExpression expression = expressionParser.parseExpression((IExpressionContext)context, attributeValue);
/* 59 */     Object value = expression.execute((IExpressionContext)context);
/*    */     
/* 61 */     return EvaluationUtils.evaluateAsBoolean(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardIfTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */