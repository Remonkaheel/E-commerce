/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeDefinitions;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EscapedAttributeUtils;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardStyleappendTagProcessor
/*    */   extends AbstractStandardExpressionAttributeTagProcessor
/*    */   implements IAttributeDefinitionsAware
/*    */ {
/*    */   public static final int PRECEDENCE = 1100;
/*    */   public static final String ATTR_NAME = "styleappend";
/*    */   public static final String TARGET_ATTR_NAME = "style";
/* 50 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*    */ 
/*    */   
/*    */   private AttributeDefinition targetAttributeDefinition;
/*    */ 
/*    */ 
/*    */   
/*    */   public StandardStyleappendTagProcessor(String dialectPrefix) {
/* 58 */     super(TemplateMode.HTML, dialectPrefix, "styleappend", 1100, true, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions) {
/* 65 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*    */ 
/*    */     
/* 68 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "style");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler) {
/* 83 */     String newAttributeValue = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), (expressionResult == null) ? null : expressionResult.toString());
/*    */ 
/*    */     
/* 86 */     if (newAttributeValue != null && newAttributeValue.length() > 0) {
/*    */       
/* 88 */       AttributeName targetAttributeName = this.targetAttributeDefinition.getAttributeName();
/*    */       
/* 90 */       if (tag.hasAttribute(targetAttributeName)) {
/* 91 */         String currentValue = tag.getAttributeValue(targetAttributeName);
/* 92 */         if (currentValue.length() > 0) {
/* 93 */           newAttributeValue = currentValue + ' ' + newAttributeValue;
/*    */         }
/*    */       } 
/*    */       
/* 97 */       StandardProcessorUtils.setAttribute(structureHandler, this.targetAttributeDefinition, "style", newAttributeValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardStyleappendTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */