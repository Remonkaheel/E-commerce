/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardAssertTagProcessor
/*    */   extends AbstractStandardAssertionTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1550;
/*    */   public static final String ATTR_NAME = "assert";
/*    */   
/*    */   public StandardAssertTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 38 */     super(templateMode, dialectPrefix, "assert", 1550);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardAssertTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */