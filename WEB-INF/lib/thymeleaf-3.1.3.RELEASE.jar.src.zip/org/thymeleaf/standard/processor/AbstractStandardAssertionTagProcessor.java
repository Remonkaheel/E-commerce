/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateAssertionException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.expression.ExpressionSequence;
/*    */ import org.thymeleaf.standard.expression.ExpressionSequenceUtils;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ import org.thymeleaf.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStandardAssertionTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   protected AbstractStandardAssertionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence) {
/* 50 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 62 */     if (StringUtils.isEmptyOrWhitespace(attributeValue)) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 67 */     ExpressionSequence expressionSequence = ExpressionSequenceUtils.parseExpressionSequence((IExpressionContext)context, attributeValue);
/*    */     
/* 69 */     List<IStandardExpression> expressions = expressionSequence.getExpressions();
/*    */     
/* 71 */     for (IStandardExpression expression : expressions) {
/* 72 */       Object expressionResult = expression.execute((IExpressionContext)context);
/* 73 */       boolean expressionBooleanResult = EvaluationUtils.evaluateAsBoolean(expressionResult);
/* 74 */       if (!expressionBooleanResult)
/* 75 */         throw new TemplateAssertionException(expression
/* 76 */             .getStringRepresentation(), tag.getTemplateName(), tag
/* 77 */             .getAttribute(attributeName).getLine(), tag.getAttribute(attributeName).getCol()); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardAssertionTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */