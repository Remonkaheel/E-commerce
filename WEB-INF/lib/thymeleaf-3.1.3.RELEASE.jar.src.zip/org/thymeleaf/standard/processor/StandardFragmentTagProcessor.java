/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractElementTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardFragmentTagProcessor
/*    */   extends AbstractElementTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1500;
/*    */   public static final String ATTR_NAME = "fragment";
/*    */   
/*    */   public StandardFragmentTagProcessor(TemplateMode templateMode, String dialectPrefix) {
/* 46 */     super(templateMode, dialectPrefix, null, false, "fragment", true, 1500);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, IElementTagStructureHandler structureHandler) {
/* 57 */     AttributeName attributeName = getMatchingAttributeName().getMatchingAttributeName();
/* 58 */     structureHandler.removeAttribute(attributeName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardFragmentTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */