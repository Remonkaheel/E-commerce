/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.processor.comment.AbstractCommentProcessor;
/*     */ import org.thymeleaf.processor.comment.ICommentStructureHandler;
/*     */ import org.thymeleaf.standard.util.StandardConditionalCommentUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardConditionalCommentProcessor
/*     */   extends AbstractCommentProcessor
/*     */ {
/*     */   public static final int PRECEDENCE = 1100;
/*     */   
/*     */   public StandardConditionalCommentProcessor() {
/*  47 */     super(TemplateMode.HTML, 1100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doProcess(ITemplateContext context, IComment comment, ICommentStructureHandler structureHandler) {
/*  59 */     StandardConditionalCommentUtils.ConditionalCommentParsingResult parsingResult = StandardConditionalCommentUtils.parseConditionalComment((CharSequence)comment);
/*     */     
/*  61 */     if (parsingResult == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  66 */     String commentStr = comment.getComment();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     TemplateManager templateManager = context.getConfiguration().getTemplateManager();
/*     */ 
/*     */     
/*  76 */     String parsableContent = commentStr.substring(parsingResult.getContentOffset(), parsingResult.getContentOffset() + parsingResult.getContentLen());
/*     */ 
/*     */     
/*  79 */     TemplateModel templateModel = templateManager.parseString(context
/*  80 */         .getTemplateData(), parsableContent, comment
/*  81 */         .getLine(), comment.getCol(), null, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     FastStringWriter writer = new FastStringWriter(200);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     writer.write("[");
/*  92 */     writer.write(commentStr, parsingResult.getStartExpressionOffset(), parsingResult.getStartExpressionLen());
/*  93 */     writer.write("]>");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     templateManager.process(templateModel, context, (Writer)writer);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     writer.write("<![");
/* 104 */     writer.write(commentStr, parsingResult.getEndExpressionOffset(), parsingResult.getEndExpressionLen());
/* 105 */     writer.write("]");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     structureHandler.setContent(writer.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\processor\StandardConditionalCommentProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */