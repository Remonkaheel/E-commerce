/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import ognl.ArrayPropertyAccessor;
/*     */ import ognl.EnumerationPropertyAccessor;
/*     */ import ognl.IteratorPropertyAccessor;
/*     */ import ognl.ListPropertyAccessor;
/*     */ import ognl.MapPropertyAccessor;
/*     */ import ognl.ObjectPropertyAccessor;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.PropertyAccessor;
/*     */ import ognl.SetPropertyAccessor;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.cache.ExpressionCacheKey;
/*     */ import org.thymeleaf.cache.ICache;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.context.IContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OGNLShortcutExpression
/*     */ {
/*  62 */   private static final Logger LOGGER = LoggerFactory.getLogger(OGNLShortcutExpression.class);
/*     */   
/*     */   private static final String EXPRESSION_CACHE_TYPE_OGNL_SHORTCUT = "ognlsc";
/*  65 */   private static final Object[] NO_PARAMS = new Object[0];
/*     */ 
/*     */   
/*     */   private final String[] expressionLevels;
/*     */ 
/*     */   
/*     */   OGNLShortcutExpression(String[] expressionLevels) {
/*  72 */     this.expressionLevels = expressionLevels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object evaluate(IEngineConfiguration configuration, Map<String, Object> context, Object root) throws Exception {
/*  80 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  81 */     ICache<ExpressionCacheKey, Object> expressionCache = (cacheManager == null) ? null : cacheManager.getExpressionCache();
/*     */     
/*  83 */     Object target = root;
/*  84 */     for (String propertyName : this.expressionLevels) {
/*     */ 
/*     */       
/*  87 */       if (target == null) {
/*  88 */         throw new OgnlException("source is null for getProperty(null, \"" + propertyName + "\")");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       Class<?> targetClass = OgnlRuntime.getTargetClass(target);
/*  95 */       PropertyAccessor ognlPropertyAccessor = OgnlRuntime.getPropertyAccessor(targetClass);
/*     */ 
/*     */       
/*  98 */       if (target instanceof Class) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 103 */         target = getObjectProperty(expressionCache, propertyName, target);
/*     */       }
/* 105 */       else if (OGNLContextPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 107 */         target = getContextProperty(propertyName, context, target);
/*     */       }
/* 109 */       else if (ObjectPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 111 */         target = getObjectProperty(expressionCache, propertyName, target);
/*     */       }
/* 113 */       else if (MapPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 115 */         target = getMapProperty(propertyName, (Map<?, ?>)target);
/*     */       }
/* 117 */       else if (ListPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 119 */         target = getListProperty(expressionCache, propertyName, (List)target);
/*     */       }
/* 121 */       else if (SetPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 123 */         target = getSetProperty(expressionCache, propertyName, (Set)target);
/*     */       }
/* 125 */       else if (IteratorPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 127 */         target = getIteratorProperty(expressionCache, propertyName, (Iterator)target);
/*     */       }
/* 129 */       else if (EnumerationPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 131 */         target = getEnumerationProperty(expressionCache, propertyName, (Enumeration)target);
/*     */       }
/* 133 */       else if (ArrayPropertyAccessor.class.equals(ognlPropertyAccessor.getClass())) {
/*     */         
/* 135 */         target = getArrayProperty(expressionCache, propertyName, (Object[])target);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 141 */         throw new OGNLShortcutExpressionNotApplicableException();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 146 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getContextProperty(String propertyName, Map<String, Object> context, Object target) throws OgnlException {
/* 159 */     if ("param".equals(propertyName) && context != null && context
/* 160 */       .containsKey("%RESTRICT_REQUEST_PARAMETERS%")) {
/* 161 */       throw new OgnlException("Access to variable \"" + propertyName + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, accessing request parameters is forbidden in preprocessing and unescaped expressions, and also in fragment inclusion specifications.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     return ((IContext)target).getVariable(propertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getObjectProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Object target) {
/* 175 */     Class<?> currClass = OgnlRuntime.getTargetClass(target);
/* 176 */     ExpressionCacheKey cacheKey = computeMethodCacheKey(currClass, propertyName);
/*     */     
/* 178 */     Method readMethod = null;
/*     */     
/* 180 */     if (expressionCache != null) {
/* 181 */       readMethod = (Method)expressionCache.get(cacheKey);
/*     */     }
/*     */     
/* 184 */     if (readMethod == null) {
/*     */       BeanInfo beanInfo;
/*     */       
/*     */       try {
/* 188 */         beanInfo = Introspector.getBeanInfo(currClass);
/* 189 */       } catch (IntrospectionException e) {
/*     */         
/* 191 */         throw new OGNLShortcutExpressionNotApplicableException();
/*     */       } 
/*     */       
/* 194 */       PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
/* 195 */       if (propertyDescriptors != null) {
/* 196 */         for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
/* 197 */           if (propertyDescriptor.getName().equals(propertyName)) {
/* 198 */             readMethod = propertyDescriptor.getReadMethod();
/* 199 */             if (readMethod != null && expressionCache != null) {
/* 200 */               expressionCache.put(cacheKey, readMethod);
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 209 */     if (readMethod == null)
/*     */     {
/* 211 */       throw new OGNLShortcutExpressionNotApplicableException();
/*     */     }
/*     */     
/*     */     try {
/* 215 */       return readMethod.invoke(target, NO_PARAMS);
/* 216 */     } catch (IllegalAccessException e) {
/*     */       BeanInfo beanInfo;
/* 218 */       throw new OGNLShortcutExpressionNotApplicableException();
/* 219 */     } catch (InvocationTargetException e) {
/*     */       
/* 221 */       throw new OGNLShortcutExpressionNotApplicableException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getMapProperty(String propertyName, Map<?, ?> map) {
/* 243 */     if (propertyName.equals("size")) {
/* 244 */       return Integer.valueOf(map.size());
/*     */     }
/* 246 */     if (propertyName.equals("keys") || propertyName.equals("keySet")) {
/* 247 */       return map.keySet();
/*     */     }
/* 249 */     if (propertyName.equals("values")) {
/* 250 */       return map.values();
/*     */     }
/* 252 */     if (propertyName.equals("isEmpty")) {
/* 253 */       return map.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/* 255 */     return map.get(propertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getListProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, List<?> list) {
/* 274 */     if (propertyName.equals("size")) {
/* 275 */       return Integer.valueOf(list.size());
/*     */     }
/* 277 */     if (propertyName.equals("iterator")) {
/* 278 */       return list.iterator();
/*     */     }
/* 280 */     if (propertyName.equals("isEmpty") || propertyName.equals("empty")) {
/* 281 */       return list.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */ 
/*     */     
/* 285 */     return getObjectProperty(expressionCache, propertyName, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getArrayProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Object[] array) {
/* 304 */     if (propertyName.equals("length")) {
/* 305 */       return Integer.valueOf(Array.getLength(array));
/*     */     }
/*     */ 
/*     */     
/* 309 */     return getObjectProperty(expressionCache, propertyName, array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getEnumerationProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Enumeration enumeration) {
/* 324 */     if (propertyName.equals("next") || propertyName.equals("nextElement")) {
/* 325 */       return enumeration.nextElement();
/*     */     }
/* 327 */     if (propertyName.equals("hasNext") || propertyName.equals("hasMoreElements")) {
/* 328 */       return enumeration.hasMoreElements() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */ 
/*     */     
/* 332 */     return getObjectProperty(expressionCache, propertyName, enumeration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getIteratorProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Iterator<?> iterator) {
/* 347 */     if (propertyName.equals("next")) {
/* 348 */       return iterator.next();
/*     */     }
/* 350 */     if (propertyName.equals("hasNext")) {
/* 351 */       return iterator.hasNext() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */ 
/*     */     
/* 355 */     return getObjectProperty(expressionCache, propertyName, iterator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getSetProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Set<?> set) {
/* 370 */     if (propertyName.equals("size")) {
/* 371 */       return Integer.valueOf(set.size());
/*     */     }
/* 373 */     if (propertyName.equals("iterator")) {
/* 374 */       return set.iterator();
/*     */     }
/* 376 */     if (propertyName.equals("isEmpty")) {
/* 377 */       return set.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */ 
/*     */     
/* 381 */     return getObjectProperty(expressionCache, propertyName, set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] parse(String expression) {
/* 391 */     return doParseExpr(expression, 0, 0, expression.length());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] doParseExpr(String expression, int level, int offset, int len) {
/*     */     String[] result;
/* 398 */     int i = offset;
/* 399 */     boolean firstChar = true;
/*     */     
/* 401 */     while (i < len) {
/*     */       
/* 403 */       int codepoint = Character.codePointAt(expression, i);
/*     */       
/* 405 */       if (codepoint == 46) {
/*     */         break;
/*     */       }
/*     */       
/* 409 */       if (firstChar) {
/* 410 */         if (!Character.isJavaIdentifierStart(codepoint)) {
/* 411 */           return null;
/*     */         }
/* 413 */         firstChar = false;
/*     */       }
/* 415 */       else if (!Character.isJavaIdentifierPart(codepoint)) {
/* 416 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 420 */       i++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 425 */     if (i < len) {
/* 426 */       result = doParseExpr(expression, level + 1, i + 1, len);
/* 427 */       if (result == null) {
/* 428 */         return null;
/*     */       }
/*     */     } else {
/* 431 */       result = new String[level + 1];
/*     */     } 
/*     */     
/* 434 */     result[level] = expression.substring(offset, i);
/*     */     
/* 436 */     if ("true".equalsIgnoreCase(result[level]) || "false".equalsIgnoreCase(result[level]) || "null".equalsIgnoreCase(result[level])) {
/* 437 */       return null;
/*     */     }
/*     */     
/* 440 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ExpressionCacheKey computeMethodCacheKey(Class<?> targetClass, String propertyName) {
/* 447 */     return new ExpressionCacheKey("ognlsc", targetClass.getName(), propertyName);
/*     */   }
/*     */   
/*     */   static class OGNLShortcutExpressionNotApplicableException extends RuntimeException {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLShortcutExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */