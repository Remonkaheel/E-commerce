/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LessOrEqualToExpression
/*     */   extends GreaterLesserExpression
/*     */ {
/*     */   private static final long serialVersionUID = 7042174616566611488L;
/*  51 */   private static final Logger logger = LoggerFactory.getLogger(LessOrEqualToExpression.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public LessOrEqualToExpression(IStandardExpression left, IStandardExpression right) {
/*  56 */     super(left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringRepresentation() {
/*  62 */     return getStringRepresentation("<=");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object executeLessOrEqualTo(IExpressionContext context, LessOrEqualToExpression expression, StandardExpressionExecutionContext expContext) {
/*  76 */     if (logger.isTraceEnabled()) {
/*  77 */       logger.trace("[THYMELEAF][{}] Evaluating LESS OR EQUAL TO expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*  80 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*  81 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  83 */     if (leftValue == null || rightValue == null) {
/*  84 */       throw new TemplateProcessingException("Cannot execute LESS OR EQUAL TO comparison: operands are \"" + 
/*  85 */           LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*     */     }
/*     */     
/*  88 */     leftValue = LiteralValue.unwrap(leftValue);
/*  89 */     rightValue = LiteralValue.unwrap(rightValue);
/*     */     
/*  91 */     Boolean result = null;
/*     */     
/*  93 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  94 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*     */     
/*  96 */     if (leftNumberValue != null && rightNumberValue != null) {
/*  97 */       result = Boolean.valueOf((leftNumberValue.compareTo(rightNumberValue) != 1));
/*     */     }
/*  99 */     else if (leftValue != null && rightValue != null && leftValue
/* 100 */       .getClass().equals(rightValue.getClass()) && Comparable.class
/* 101 */       .isAssignableFrom(leftValue.getClass())) {
/* 102 */       result = Boolean.valueOf((((Comparable<Object>)leftValue).compareTo(rightValue) <= 0));
/*     */     } else {
/* 104 */       throw new TemplateProcessingException("Cannot execute LESS OR EQUAL TO from Expression \"" + expression
/*     */           
/* 106 */           .getStringRepresentation() + "\". Left is \"" + leftValue + "\", right is \"" + rightValue + "\"");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (logger.isTraceEnabled()) {
/* 112 */       logger.trace("[THYMELEAF][{}] Evaluating LESS OR EQUAL TO expression: \"{}\". Left is \"{}\", right is \"{}\". Result is \"{}\"", new Object[] {
/* 113 */             TemplateEngine.threadIndex(), expression.getStringRepresentation(), leftValue, rightValue, result
/*     */           });
/*     */     }
/* 116 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\LessOrEqualToExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */