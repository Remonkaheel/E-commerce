/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FragmentExpression
/*     */   extends SimpleExpression
/*     */ {
/*  53 */   private static final Logger logger = LoggerFactory.getLogger(FragmentExpression.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = -130371297698708001L;
/*     */ 
/*     */   
/*  60 */   public static final FragmentExpression EMPTY_FRAGMENT_EXPRESSION = new FragmentExpression();
/*     */ 
/*     */   
/*     */   private static final String TEMPLATE_NAME_CURRENT_TEMPLATE = "this";
/*     */   
/*     */   private static final String SEPARATOR = "::";
/*     */   
/*     */   static final String UNNAMED_PARAMETERS_PREFIX = "_arg";
/*     */   
/*     */   public static final char SELECTOR = '~';
/*     */   
/*  71 */   private static final Pattern FRAGMENT_PATTERN = Pattern.compile("^\\s*~\\{(.*?)\\}\\s*$", 32);
/*     */ 
/*     */ 
/*     */   
/*     */   private final IStandardExpression templateName;
/*     */ 
/*     */   
/*     */   private final IStandardExpression fragmentSelector;
/*     */ 
/*     */   
/*     */   private final AssignationSequence parameters;
/*     */ 
/*     */   
/*     */   private final boolean syntheticParameters;
/*     */ 
/*     */ 
/*     */   
/*     */   public FragmentExpression(IStandardExpression templateName, IStandardExpression fragmentSelector, AssignationSequence parameters, boolean syntheticParameters) {
/*  89 */     if (templateName == null && fragmentSelector == null) {
/*  90 */       throw new IllegalArgumentException("Fragment Expression cannot have null template name and null fragment selector");
/*     */     }
/*     */     
/*  93 */     this.templateName = templateName;
/*  94 */     this.fragmentSelector = fragmentSelector;
/*  95 */     this.parameters = parameters;
/*  96 */     this.syntheticParameters = (this.parameters != null && this.parameters.size() > 0 && syntheticParameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FragmentExpression() {
/* 103 */     this.templateName = null;
/* 104 */     this.fragmentSelector = null;
/* 105 */     this.parameters = null;
/* 106 */     this.syntheticParameters = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStandardExpression getTemplateName() {
/* 111 */     return this.templateName;
/*     */   }
/*     */   
/*     */   public IStandardExpression getFragmentSelector() {
/* 115 */     return this.fragmentSelector;
/*     */   }
/*     */   
/*     */   public boolean hasFragmentSelector() {
/* 119 */     return (this.fragmentSelector != null);
/*     */   }
/*     */   
/*     */   public AssignationSequence getParameters() {
/* 123 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public boolean hasParameters() {
/* 127 */     return (this.parameters != null && this.parameters.size() > 0);
/*     */   }
/*     */   
/*     */   public boolean hasSyntheticParameters() {
/* 131 */     return this.syntheticParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringRepresentation() {
/* 139 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 141 */     sb.append('~');
/* 142 */     sb.append('{');
/*     */     
/* 144 */     sb.append((this.templateName != null) ? this.templateName.getStringRepresentation() : "");
/*     */     
/* 146 */     if (this.fragmentSelector != null) {
/* 147 */       sb.append(' ');
/* 148 */       sb.append("::");
/* 149 */       sb.append(' ');
/* 150 */       sb.append(this.fragmentSelector.getStringRepresentation());
/*     */     } 
/*     */     
/* 153 */     if (this.parameters != null && this.parameters.size() > 0) {
/* 154 */       sb.append(' ');
/* 155 */       sb.append('(');
/* 156 */       sb.append(StringUtils.join(this.parameters.getAssignations(), ','));
/* 157 */       sb.append(')');
/*     */     } 
/*     */     
/* 160 */     sb.append('}');
/*     */     
/* 162 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FragmentExpression parseFragmentExpression(String input) {
/* 171 */     Matcher matcher = FRAGMENT_PATTERN.matcher(input);
/* 172 */     if (!matcher.matches()) {
/* 173 */       return null;
/*     */     }
/* 175 */     String expression = matcher.group(1);
/* 176 */     if (StringUtils.isEmptyOrWhitespace(expression)) {
/* 177 */       return EMPTY_FRAGMENT_EXPRESSION;
/*     */     }
/* 179 */     return parseFragmentExpressionContent(expression.trim());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static FragmentExpression parseFragmentExpressionContent(String input) {
/*     */     String inputWithoutParameters, parametersStr, templateNameStr, fragmentSpecStr;
/*     */     Expression templateNameExpression, fragmentSpecExpression;
/* 187 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 188 */       return EMPTY_FRAGMENT_EXPRESSION;
/*     */     }
/*     */     
/* 191 */     String trimmedInput = input.trim();
/*     */     
/* 193 */     int lastParenthesesGroupPos = indexOfLastParenthesesGroup(trimmedInput);
/*     */ 
/*     */ 
/*     */     
/* 197 */     if (lastParenthesesGroupPos != -1) {
/* 198 */       parametersStr = trimmedInput.substring(lastParenthesesGroupPos).trim();
/* 199 */       inputWithoutParameters = trimmedInput.substring(0, lastParenthesesGroupPos).trim();
/*     */     } else {
/* 201 */       parametersStr = null;
/* 202 */       inputWithoutParameters = trimmedInput;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     int operatorPos = inputWithoutParameters.indexOf("::");
/* 209 */     if (operatorPos == -1) {
/*     */ 
/*     */ 
/*     */       
/* 213 */       templateNameStr = inputWithoutParameters;
/* 214 */       fragmentSpecStr = null;
/* 215 */       if (StringUtils.isEmptyOrWhitespace(templateNameStr)) {
/* 216 */         if (parametersStr != null) {
/*     */           
/* 218 */           templateNameStr = parametersStr;
/* 219 */           parametersStr = null;
/*     */         } else {
/*     */           
/* 222 */           return null;
/*     */         }
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 229 */       templateNameStr = inputWithoutParameters.substring(0, operatorPos).trim();
/* 230 */       fragmentSpecStr = inputWithoutParameters.substring(operatorPos + "::".length()).trim();
/* 231 */       if (StringUtils.isEmptyOrWhitespace(fragmentSpecStr)) {
/* 232 */         if (parametersStr != null) {
/*     */           
/* 234 */           fragmentSpecStr = parametersStr;
/* 235 */           parametersStr = null;
/*     */         }
/*     */         else {
/*     */           
/* 239 */           return null;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 246 */     if (!StringUtils.isEmptyOrWhitespace(templateNameStr)) {
/* 247 */       templateNameExpression = parseDefaultAsLiteral(templateNameStr);
/* 248 */       if (templateNameExpression == null) {
/* 249 */         return null;
/*     */       }
/*     */     } else {
/* 252 */       templateNameExpression = null;
/*     */     } 
/*     */ 
/*     */     
/* 256 */     if (!StringUtils.isEmptyOrWhitespace(fragmentSpecStr)) {
/* 257 */       fragmentSpecExpression = parseDefaultAsLiteral(fragmentSpecStr);
/* 258 */       if (fragmentSpecExpression == null) {
/* 259 */         return null;
/*     */       }
/*     */     } else {
/* 262 */       fragmentSpecExpression = null;
/*     */     } 
/*     */     
/* 265 */     if (!StringUtils.isEmptyOrWhitespace(parametersStr)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 270 */       AssignationSequence parametersAsSeq = AssignationUtils.internalParseAssignationSequence(parametersStr, false);
/*     */       
/* 272 */       if (parametersAsSeq != null) {
/* 273 */         return new FragmentExpression(templateNameExpression, fragmentSpecExpression, parametersAsSeq, false);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 281 */       ExpressionSequence parametersExpSeq = ExpressionSequenceUtils.internalParseExpressionSequence(parametersStr);
/*     */       
/* 283 */       if (parametersExpSeq != null) {
/*     */         
/* 285 */         AssignationSequence parametersAsSeqFromExp = createSyntheticallyNamedParameterSequence(parametersExpSeq);
/* 286 */         return new FragmentExpression(templateNameExpression, fragmentSpecExpression, parametersAsSeqFromExp, true);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 292 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 296 */     return new FragmentExpression(templateNameExpression, fragmentSpecExpression, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Expression parseDefaultAsLiteral(String input) {
/* 304 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 305 */       return null;
/*     */     }
/*     */     
/* 308 */     Expression expr = Expression.parse(input);
/* 309 */     if (expr == null) {
/* 310 */       return Expression.parse(TextLiteralExpression.wrapStringIntoLiteral(input));
/*     */     }
/* 312 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int indexOfLastParenthesesGroup(String input) {
/* 322 */     int inputLen = input.length();
/* 323 */     char finalC = input.charAt(inputLen - 1);
/* 324 */     if (finalC != ')')
/*     */     {
/* 326 */       return -1;
/*     */     }
/* 328 */     int parenLevel = 1;
/* 329 */     for (int i = inputLen - 2; i >= 0; i--) {
/* 330 */       char c = input.charAt(i);
/* 331 */       if (c == '(') {
/* 332 */         parenLevel--;
/* 333 */         if (parenLevel == 0) {
/*     */           
/* 335 */           if (i == inputLen - 2)
/*     */           {
/* 337 */             return -1;
/*     */           }
/* 339 */           return i;
/*     */         } 
/* 341 */       } else if (c == ')') {
/* 342 */         parenLevel++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 347 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AssignationSequence createSyntheticallyNamedParameterSequence(ExpressionSequence expSeq) {
/* 354 */     List<Assignation> assignations = new ArrayList<>(expSeq.size() + 2);
/*     */     
/* 356 */     int argIndex = 0;
/* 357 */     for (IStandardExpression expression : expSeq.getExpressions()) {
/*     */       
/* 359 */       IStandardExpression parameterName = Expression.parse(TextLiteralExpression.wrapStringIntoLiteral("_arg" + argIndex++));
/* 360 */       assignations.add(new Assignation(parameterName, expression));
/*     */     } 
/*     */     
/* 363 */     return new AssignationSequence(assignations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Fragment executeFragmentExpression(IExpressionContext context, FragmentExpression expression) {
/* 379 */     if (!(context instanceof ITemplateContext)) {
/* 380 */       throw new TemplateProcessingException("Cannot evaluate expression \"" + expression + "\". Fragment expressions can only be evaluated in a template-processing environment (as a part of an in-template expression) where processing context is an implementation of " + ITemplateContext.class
/*     */ 
/*     */           
/* 383 */           .getClass() + ", which it isn't (" + context
/* 384 */           .getClass().getName() + ")");
/*     */     }
/*     */     
/* 387 */     if (expression == EMPTY_FRAGMENT_EXPRESSION) {
/* 388 */       return Fragment.EMPTY_FRAGMENT;
/*     */     }
/*     */     
/* 391 */     return resolveExecutedFragmentExpression((ITemplateContext)context, 
/*     */         
/* 393 */         createExecutedFragmentExpression(context, expression), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExecutedFragmentExpression createExecutedFragmentExpression(IExpressionContext context, FragmentExpression expression) {
/* 405 */     return doCreateExecutedFragmentExpression(context, expression, StandardExpressionExecutionContext.RESTRICTED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ExecutedFragmentExpression doCreateExecutedFragmentExpression(IExpressionContext context, FragmentExpression expression, StandardExpressionExecutionContext expContext) {
/*     */     Object templateNameExpressionResult, fragmentSelectorExpressionResult;
/* 413 */     Validate.notNull(context, "Context cannot be null");
/* 414 */     Validate.notNull(expression, "Fragment Expression cannot be null");
/*     */     
/* 416 */     if (logger.isTraceEnabled()) {
/* 417 */       logger.trace("[THYMELEAF][{}] Evaluating fragment: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 424 */     if (expression == EMPTY_FRAGMENT_EXPRESSION) {
/* 425 */       return ExecutedFragmentExpression.EMPTY_EXECUTED_FRAGMENT_EXPRESSION;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     IStandardExpression templateNameExpression = expression.getTemplateName();
/*     */     
/* 434 */     if (templateNameExpression != null) {
/*     */ 
/*     */       
/* 437 */       templateNameExpressionResult = templateNameExpression.execute(context, StandardExpressionExecutionContext.RESTRICTED);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 442 */       templateNameExpressionResult = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 450 */     Map<String, Object> fragmentParameters = createExecutedFragmentExpressionParameters(context, expression.getParameters(), expression.hasSyntheticParameters(), expContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 457 */     if (expression.hasFragmentSelector()) {
/*     */       
/* 459 */       fragmentSelectorExpressionResult = expression.getFragmentSelector().execute(context, expContext);
/*     */     }
/*     */     else {
/*     */       
/* 463 */       fragmentSelectorExpressionResult = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 470 */     return new ExecutedFragmentExpression(expression, templateNameExpressionResult, fragmentSelectorExpressionResult, fragmentParameters, expression
/*     */ 
/*     */         
/* 473 */         .hasSyntheticParameters());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Object> createExecutedFragmentExpressionParameters(IExpressionContext context, AssignationSequence parameters, boolean syntheticParameters, StandardExpressionExecutionContext expContext) {
/* 484 */     if (parameters == null || parameters.size() == 0) {
/* 485 */       return null;
/*     */     }
/*     */     
/* 488 */     Map<String, Object> parameterValues = new HashMap<>(parameters.size() + 2);
/* 489 */     List<Assignation> assignationValues = parameters.getAssignations();
/* 490 */     int assignationValuesLen = assignationValues.size();
/*     */     
/* 492 */     for (int i = 0; i < assignationValuesLen; i++) {
/*     */       String parameterName;
/* 494 */       Assignation assignation = assignationValues.get(i);
/*     */       
/* 496 */       IStandardExpression parameterNameExpr = assignation.getLeft();
/*     */ 
/*     */       
/* 499 */       if (!syntheticParameters) {
/* 500 */         Object parameterNameValue = parameterNameExpr.execute(context, expContext);
/* 501 */         parameterName = (parameterNameValue == null) ? null : parameterNameValue.toString();
/*     */       } else {
/*     */         
/* 504 */         parameterName = ((TextLiteralExpression)parameterNameExpr).getValue().getValue();
/*     */       } 
/*     */       
/* 507 */       IStandardExpression parameterValueExpr = assignation.getRight();
/* 508 */       Object parameterValueValue = parameterValueExpr.execute(context, expContext);
/*     */       
/* 510 */       parameterValues.put(parameterName, parameterValueValue);
/*     */     } 
/*     */ 
/*     */     
/* 514 */     return parameterValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fragment resolveExecutedFragmentExpression(ITemplateContext context, ExecutedFragmentExpression executedFragmentExpression, boolean failIfNotExists) {
/*     */     TemplateModel fragmentModel;
/* 526 */     if (executedFragmentExpression == ExecutedFragmentExpression.EMPTY_EXECUTED_FRAGMENT_EXPRESSION) {
/* 527 */       return Fragment.EMPTY_FRAGMENT;
/*     */     }
/*     */     
/* 530 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 535 */     String templateName = resolveTemplateName(executedFragmentExpression);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 541 */     Set<String> fragments = resolveFragments(executedFragmentExpression);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 548 */     List<String> templateNameStack = null;
/*     */     
/* 550 */     if (StringUtils.isEmptyOrWhitespace(templateName)) {
/*     */       
/* 552 */       if (fragments == null || fragments.isEmpty()) {
/* 553 */         return null;
/*     */       }
/*     */       
/* 556 */       templateNameStack = new ArrayList<>(3);
/* 557 */       for (int j = context.getTemplateStack().size() - 1; j >= 0; j--) {
/* 558 */         templateNameStack.add(((TemplateData)context.getTemplateStack().get(j)).getTemplate());
/*     */       }
/* 560 */       templateName = templateNameStack.get(0);
/*     */     } 
/*     */ 
/*     */     
/* 564 */     int i = 0;
/*     */     
/*     */     do {
/* 567 */       fragmentModel = configuration.getTemplateManager().parseStandalone(context, templateName, fragments, null, true, failIfNotExists);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 572 */       i++;
/* 573 */     } while (fragmentModel != null && fragmentModel
/* 574 */       .size() <= 2 && templateNameStack != null && i < templateNameStack
/*     */       
/* 576 */       .size() && (
/* 577 */       templateName = templateNameStack.get(i)) != null);
/*     */     
/* 579 */     if (fragmentModel == null)
/*     */     {
/*     */       
/* 582 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 591 */     boolean fragmentIsEmpty = (fragmentModel.size() == 2);
/*     */     
/* 593 */     if (fragmentIsEmpty) {
/*     */ 
/*     */       
/* 596 */       if (failIfNotExists) {
/* 597 */         throw new TemplateInputException("Error resolving fragment: \"" + executedFragmentExpression
/* 598 */             .fragmentExpression.getStringRepresentation() + "\": template or fragment could not be resolved");
/*     */       }
/*     */       
/* 601 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 608 */     return new Fragment(fragmentModel, executedFragmentExpression.fragmentParameters, executedFragmentExpression.syntheticParameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String resolveTemplateName(ExecutedFragmentExpression executedFragmentExpression) {
/* 617 */     Object templateNameObject = executedFragmentExpression.templateNameExpressionResult;
/* 618 */     if (templateNameObject == null)
/*     */     {
/* 620 */       return null;
/*     */     }
/* 622 */     String evaluatedTemplateName = templateNameObject.toString();
/* 623 */     if ("this".equals(evaluatedTemplateName))
/*     */     {
/* 625 */       return null;
/*     */     }
/* 627 */     return templateNameObject.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> resolveFragments(ExecutedFragmentExpression executedFragmentExpression) {
/* 636 */     Object fragmentSelectorObject = executedFragmentExpression.fragmentSelectorExpressionResult;
/* 637 */     if (fragmentSelectorObject != null) {
/*     */       
/* 639 */       String fragmentSelector = fragmentSelectorObject.toString();
/*     */       
/* 641 */       if (fragmentSelector.length() > 3 && fragmentSelector
/* 642 */         .charAt(0) == '[' && fragmentSelector.charAt(fragmentSelector.length() - 1) == ']' && fragmentSelector
/* 643 */         .charAt(fragmentSelector.length() - 2) != '\'')
/*     */       {
/*     */         
/* 646 */         fragmentSelector = fragmentSelector.substring(1, fragmentSelector.length() - 1).trim();
/*     */       }
/*     */       
/* 649 */       if (fragmentSelector.trim().length() > 0) {
/* 650 */         return Collections.singleton(fragmentSelector);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 655 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class ExecutedFragmentExpression
/*     */   {
/* 665 */     public static final ExecutedFragmentExpression EMPTY_EXECUTED_FRAGMENT_EXPRESSION = new ExecutedFragmentExpression(FragmentExpression.EMPTY_FRAGMENT_EXPRESSION, null, null, null, false);
/*     */     
/*     */     private final FragmentExpression fragmentExpression;
/*     */     
/*     */     private final Object templateNameExpressionResult;
/*     */     
/*     */     private final Object fragmentSelectorExpressionResult;
/*     */     
/*     */     private final Map<String, Object> fragmentParameters;
/*     */     
/*     */     private final boolean syntheticParameters;
/*     */ 
/*     */     
/*     */     ExecutedFragmentExpression(FragmentExpression fragmentExpression, Object templateNameExpressionResult, Object fragmentSelectorExpressionResult, Map<String, Object> fragmentParameters, boolean syntheticParameters) {
/* 679 */       this.fragmentExpression = fragmentExpression;
/* 680 */       this.templateNameExpressionResult = templateNameExpressionResult;
/* 681 */       this.fragmentSelectorExpressionResult = fragmentSelectorExpressionResult;
/* 682 */       this.fragmentParameters = fragmentParameters;
/* 683 */       this.syntheticParameters = syntheticParameters;
/*     */     }
/*     */     
/*     */     FragmentExpression getFragmentExpression() {
/* 687 */       return this.fragmentExpression;
/*     */     }
/*     */     
/*     */     public Object getTemplateNameExpressionResult() {
/* 691 */       return this.templateNameExpressionResult;
/*     */     }
/*     */     
/*     */     public Object getFragmentSelectorExpressionResult() {
/* 695 */       return this.fragmentSelectorExpressionResult;
/*     */     }
/*     */     
/*     */     public Map<String, Object> getFragmentParameters() {
/* 699 */       return this.fragmentParameters;
/*     */     }
/*     */     
/*     */     public boolean hasSyntheticParameters() {
/* 703 */       return this.syntheticParameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\FragmentExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */