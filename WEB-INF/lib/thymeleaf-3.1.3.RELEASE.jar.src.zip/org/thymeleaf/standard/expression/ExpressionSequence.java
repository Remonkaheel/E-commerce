/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExpressionSequence
/*    */   implements Iterable<IStandardExpression>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6069208208568731809L;
/*    */   private final List<IStandardExpression> expressions;
/*    */   
/*    */   public ExpressionSequence(List<? extends IStandardExpression> expressions) {
/* 47 */     Validate.notNull(expressions, "Expression list cannot be null");
/* 48 */     Validate.containsNoNulls(expressions, "Expression list cannot contain any nulls");
/* 49 */     this.expressions = Collections.unmodifiableList(expressions);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<IStandardExpression> getExpressions() {
/* 54 */     return this.expressions;
/*    */   }
/*    */   
/*    */   public int size() {
/* 58 */     return this.expressions.size();
/*    */   }
/*    */   
/*    */   public Iterator<IStandardExpression> iterator() {
/* 62 */     return this.expressions.iterator();
/*    */   }
/*    */   
/*    */   public String getStringRepresentation() {
/* 66 */     StringBuilder sb = new StringBuilder();
/* 67 */     if (this.expressions.size() > 0) {
/* 68 */       sb.append(this.expressions.get(0));
/* 69 */       for (int i = 1; i < this.expressions.size(); i++) {
/* 70 */         sb.append(',');
/* 71 */         sb.append(this.expressions.get(i));
/*    */       } 
/*    */     } 
/* 74 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     return getStringRepresentation();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\ExpressionSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */