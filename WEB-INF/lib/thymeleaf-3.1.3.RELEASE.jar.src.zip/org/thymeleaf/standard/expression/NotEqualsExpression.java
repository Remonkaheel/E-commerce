/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NotEqualsExpression
/*     */   extends EqualsNotEqualsExpression
/*     */ {
/*     */   private static final long serialVersionUID = 5831688164085171802L;
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(NotEqualsExpression.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public NotEqualsExpression(IStandardExpression left, IStandardExpression right) {
/*  55 */     super(left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringRepresentation() {
/*  61 */     return getStringRepresentation("!=");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object executeNotEquals(IExpressionContext context, NotEqualsExpression expression, StandardExpressionExecutionContext expContext) {
/*  74 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*  75 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  77 */     leftValue = LiteralValue.unwrap(leftValue);
/*  78 */     rightValue = LiteralValue.unwrap(rightValue);
/*     */     
/*  80 */     if (leftValue == null) {
/*  81 */       return Boolean.valueOf((rightValue != null));
/*     */     }
/*     */     
/*  84 */     Boolean result = null;
/*     */     
/*  86 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  87 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*     */     
/*  89 */     if (leftNumberValue != null && rightNumberValue != null) {
/*  90 */       result = Boolean.valueOf((leftNumberValue.compareTo(rightNumberValue) != 0));
/*     */     } else {
/*  92 */       if (leftValue instanceof Character) {
/*  93 */         leftValue = leftValue.toString();
/*     */       }
/*  95 */       if (rightValue != null && rightValue instanceof Character) {
/*  96 */         rightValue = rightValue.toString();
/*     */       }
/*  98 */       if (rightValue != null && leftValue
/*  99 */         .getClass().equals(rightValue.getClass()) && Comparable.class
/* 100 */         .isAssignableFrom(leftValue.getClass())) {
/* 101 */         result = Boolean.valueOf((((Comparable<Object>)leftValue).compareTo(rightValue) != 0));
/*     */       } else {
/* 103 */         result = Boolean.valueOf(!leftValue.equals(rightValue));
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     if (logger.isTraceEnabled()) {
/* 108 */       logger.trace("[THYMELEAF][{}] Evaluating NOT EQUALS expression: \"{}\". Left is \"{}\", right is \"{}\". Result is \"{}\"", new Object[] {
/* 109 */             TemplateEngine.threadIndex(), expression.getStringRepresentation(), leftValue, rightValue, result
/*     */           });
/*     */     }
/* 112 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\NotEqualsExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */