/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GreaterOrEqualToExpression
/*     */   extends GreaterLesserExpression
/*     */ {
/*     */   private static final long serialVersionUID = 4318966518910979010L;
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(GreaterOrEqualToExpression.class);
/*     */ 
/*     */   
/*     */   public GreaterOrEqualToExpression(IStandardExpression left, IStandardExpression right) {
/*  54 */     super(left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringRepresentation() {
/*  60 */     return getStringRepresentation(">=");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object executeGreaterOrEqualTo(IExpressionContext context, GreaterOrEqualToExpression expression, StandardExpressionExecutionContext expContext) {
/*  72 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*  73 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  75 */     leftValue = LiteralValue.unwrap(leftValue);
/*  76 */     rightValue = LiteralValue.unwrap(rightValue);
/*     */     
/*  78 */     Boolean result = null;
/*     */     
/*  80 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  81 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*     */     
/*  83 */     if (leftNumberValue != null && rightNumberValue != null) {
/*  84 */       result = Boolean.valueOf((leftNumberValue.compareTo(rightNumberValue) != -1));
/*     */     }
/*  86 */     else if (leftValue != null && rightValue != null && leftValue
/*  87 */       .getClass().equals(rightValue.getClass()) && Comparable.class
/*  88 */       .isAssignableFrom(leftValue.getClass())) {
/*  89 */       result = Boolean.valueOf((((Comparable<Object>)leftValue).compareTo(rightValue) >= 0));
/*     */     } else {
/*  91 */       throw new TemplateProcessingException("Cannot execute GREATER OR EQUAL TO from Expression \"" + expression
/*     */           
/*  93 */           .getStringRepresentation() + "\". Left is \"" + leftValue + "\", right is \"" + rightValue + "\"");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  98 */     if (logger.isTraceEnabled()) {
/*  99 */       logger.trace("[THYMELEAF][{}] Evaluating GREATER OR EQUAL TO expression: \"{}\". Left is \"{}\", right is \"{}\". Result is \"{}\"", new Object[] {
/* 100 */             TemplateEngine.threadIndex(), expression.getStringRepresentation(), leftValue, rightValue, result
/*     */           });
/*     */     }
/* 103 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\GreaterOrEqualToExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */