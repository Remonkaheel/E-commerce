package org.thymeleaf.standard.expression;

public final class StandardConversionService extends AbstractStandardConversionService {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\StandardConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */