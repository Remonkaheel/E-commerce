/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OGNLExpressionObjectsWrapper
/*     */   extends HashMap<String, Object>
/*     */ {
/*     */   private final IExpressionObjects expressionObjects;
/*     */   
/*     */   OGNLExpressionObjectsWrapper(IExpressionObjects expressionObjects) {
/*  43 */     super(5);
/*  44 */     this.expressionObjects = expressionObjects;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  50 */     return super.size() + this.expressionObjects.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  55 */     return (this.expressionObjects.size() == 0 && super.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/*  61 */     if (this.expressionObjects.containsObject(key.toString())) {
/*  62 */       return this.expressionObjects.getObject(key.toString());
/*     */     }
/*  64 */     return super.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  70 */     return (this.expressionObjects.containsObject(key.toString()) || super.containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(String key, Object value) {
/*  75 */     if (this.expressionObjects.containsObject(key.toString())) {
/*  76 */       throw new IllegalArgumentException("Cannot put entry with key \"" + key + "\" into Expression Objects wrapper map: key matches the name of one of the expression objects");
/*     */     }
/*     */ 
/*     */     
/*  80 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ?> m) {
/*  86 */     super.putAll(m);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/*  91 */     if (this.expressionObjects.containsObject(key.toString())) {
/*  92 */       throw new IllegalArgumentException("Cannot remove entry with key \"" + key + "\" from Expression Objects wrapper map: key matches the name of one of the expression objects");
/*     */     }
/*     */ 
/*     */     
/*  96 */     return super.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 101 */     throw new UnsupportedOperationException("Cannot clear Expression Objects wrapper map");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 106 */     throw new UnsupportedOperationException("Cannot perform by-value search on Expression Objects wrapper map");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 111 */     throw new UnsupportedOperationException("Cannot clone Expression Objects wrapper map");
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 116 */     if (super.isEmpty()) {
/* 117 */       return this.expressionObjects.getObjectNames();
/*     */     }
/* 119 */     Set<String> keys = new LinkedHashSet<>(this.expressionObjects.getObjectNames());
/* 120 */     keys.addAll(super.keySet());
/* 121 */     return keys;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> values() {
/* 126 */     return super.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 131 */     throw new UnsupportedOperationException("Cannot retrieve a complete entry set for Expression Objects wrapper map. Get a key set instead");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 137 */     throw new UnsupportedOperationException("Cannot execute equals operation on Expression Objects wrapper map");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 143 */     throw new UnsupportedOperationException("Cannot execute hashCode operation on Expression Objects wrapper map");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return "{EXPRESSION OBJECTS WRAPPER MAP FOR KEYS: " + keySet() + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLExpressionObjectsWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */