/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RemainderExpression
/*    */   extends MultiplicationDivisionRemainderExpression
/*    */ {
/*    */   private static final long serialVersionUID = -8830009392616779821L;
/* 53 */   private static final Logger logger = LoggerFactory.getLogger(RemainderExpression.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RemainderExpression(IStandardExpression left, IStandardExpression right) {
/* 60 */     super(left, right);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getStringRepresentation() {
/* 67 */     return getStringRepresentation("%");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Object executeRemainder(IExpressionContext context, RemainderExpression expression, StandardExpressionExecutionContext expContext) {
/* 77 */     if (logger.isTraceEnabled()) {
/* 78 */       logger.trace("[THYMELEAF][{}] Evaluating remainder expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 81 */     Object leftValue = expression.getLeft().execute(context, expContext);
/* 82 */     Object rightValue = expression.getRight().execute(context, expContext);
/*    */     
/* 84 */     if (leftValue == null) {
/* 85 */       leftValue = "null";
/*    */     }
/* 87 */     if (rightValue == null) {
/* 88 */       rightValue = "null";
/*    */     }
/*    */     
/* 91 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/* 92 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/* 93 */     if (leftNumberValue != null && rightNumberValue != null)
/*    */     {
/* 95 */       return leftNumberValue.remainder(rightNumberValue);
/*    */     }
/*    */     
/* 98 */     throw new TemplateProcessingException("Cannot execute division: operands are \"" + 
/* 99 */         LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\RemainderExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */