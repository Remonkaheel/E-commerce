/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.thymeleaf.util.StringUtils;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FragmentSignature
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 6847640942405961705L;
/*    */   private static final char FRAGMENT_SIGNATURE_PARAMETERS_START = '(';
/*    */   private static final char FRAGMENT_SIGNATURE_PARAMETERS_END = ')';
/*    */   private final String fragmentName;
/*    */   private final List<String> parameterNames;
/*    */   
/*    */   public FragmentSignature(String fragmentName, List<String> parameterNames) {
/* 56 */     Validate.notEmpty(fragmentName, "Fragment name cannot be null or empty");
/* 57 */     this.fragmentName = fragmentName;
/* 58 */     this.parameterNames = parameterNames;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getFragmentName() {
/* 64 */     return this.fragmentName;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasParameters() {
/* 69 */     return (this.parameterNames != null && this.parameterNames.size() > 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getParameterNames() {
/* 74 */     return this.parameterNames;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStringRepresentation() {
/* 79 */     if (this.parameterNames == null || this.parameterNames.size() == 0) {
/* 80 */       return this.fragmentName;
/*    */     }
/* 82 */     return this.fragmentName + " " + '(' + 
/*    */       
/* 84 */       StringUtils.join(this.parameterNames, ',') + ')';
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return getStringRepresentation();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\FragmentSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */