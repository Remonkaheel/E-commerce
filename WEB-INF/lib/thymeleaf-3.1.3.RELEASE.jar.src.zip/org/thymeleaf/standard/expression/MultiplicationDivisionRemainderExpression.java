/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MultiplicationDivisionRemainderExpression
/*    */   extends BinaryOperationExpression
/*    */ {
/*    */   private static final long serialVersionUID = -1364531602981256885L;
/*    */   protected static final String MULTIPLICATION_OPERATOR = "*";
/*    */   protected static final String DIVISION_OPERATOR = "/";
/*    */   protected static final String DIVISION_OPERATOR_2 = "div";
/*    */   protected static final String REMAINDER_OPERATOR = "%";
/*    */   protected static final String REMAINDER_OPERATOR_2 = "mod";
/* 45 */   static final String[] OPERATORS = new String[] { "*", "/", "div", "%", "mod" };
/*    */   
/* 47 */   private static final boolean[] LENIENCIES = new boolean[] { false, false, false, false, false };
/*    */ 
/*    */   
/* 50 */   private static final Class<? extends BinaryOperationExpression>[] OPERATOR_CLASSES = new Class[] { MultiplicationExpression.class, DivisionExpression.class, DivisionExpression.class, RemainderExpression.class, RemainderExpression.class };
/*    */ 
/*    */   
/*    */   private static final Method LEFT_ALLOWED_METHOD;
/*    */ 
/*    */   
/*    */   private static final Method RIGHT_ALLOWED_METHOD;
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     try {
/* 62 */       LEFT_ALLOWED_METHOD = MultiplicationDivisionRemainderExpression.class.getDeclaredMethod("isLeftAllowed", new Class[] { IStandardExpression.class });
/* 63 */       RIGHT_ALLOWED_METHOD = MultiplicationDivisionRemainderExpression.class.getDeclaredMethod("isRightAllowed", new Class[] { IStandardExpression.class });
/* 64 */     } catch (NoSuchMethodException e) {
/* 65 */       throw new ExceptionInInitializerError(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected MultiplicationDivisionRemainderExpression(IStandardExpression left, IStandardExpression right) {
/* 72 */     super(left, right);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean isRightAllowed(IStandardExpression right) {
/* 79 */     return (right != null && (!(right instanceof Token) || right instanceof NumberTokenExpression) && !(right instanceof TextLiteralExpression));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean isLeftAllowed(IStandardExpression left) {
/* 85 */     return (left != null && (!(left instanceof Token) || left instanceof NumberTokenExpression) && !(left instanceof TextLiteralExpression));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ExpressionParsingState composeMultiplicationDivisionRemainderExpression(ExpressionParsingState state, int nodeIndex) {
/* 96 */     return composeBinaryOperationExpression(state, nodeIndex, OPERATORS, LENIENCIES, OPERATOR_CLASSES, LEFT_ALLOWED_METHOD, RIGHT_ALLOWED_METHOD);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\MultiplicationDivisionRemainderExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */