/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FragmentSignatureUtils
/*     */ {
/*     */   private static final char FRAGMENT_SIGNATURE_PARAMETERS_START = '(';
/*     */   private static final char FRAGMENT_SIGNATURE_PARAMETERS_END = ')';
/*     */   
/*     */   public static FragmentSignature parseFragmentSignature(IEngineConfiguration configuration, String input) {
/*  55 */     Validate.notNull(configuration, "Configuration cannot be null");
/*     */     
/*  57 */     Validate.notNull(input, "Input cannot be null");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     if (configuration != null) {
/*     */       
/*  64 */       FragmentSignature cachedFragmentSignature = ExpressionCache.getFragmentSignatureFromCache(configuration, input);
/*  65 */       if (cachedFragmentSignature != null) {
/*  66 */         return cachedFragmentSignature;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  71 */     FragmentSignature fragmentSignature = internalParseFragmentSignature(input.trim());
/*     */     
/*  73 */     if (fragmentSignature == null) {
/*  74 */       throw new TemplateProcessingException("Could not parse as fragment signature: \"" + input + "\"");
/*     */     }
/*     */     
/*  77 */     if (configuration != null) {
/*  78 */       ExpressionCache.putFragmentSignatureIntoCache(configuration, input, fragmentSignature);
/*     */     }
/*     */     
/*  81 */     return fragmentSignature;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FragmentSignature internalParseFragmentSignature(String input) {
/*     */     List<String> parameterNames;
/*  91 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/*  92 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  96 */     int parameterStart = input.lastIndexOf('(');
/*     */     
/*  98 */     int parameterEnd = input.lastIndexOf(')');
/*     */     
/* 100 */     if (parameterStart != -1 && parameterStart >= parameterEnd) {
/* 101 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 106 */     String fragmentName = (parameterStart == -1) ? input.trim() : input.substring(0, parameterStart).trim();
/*     */ 
/*     */ 
/*     */     
/* 110 */     String parameters = (parameterStart == -1) ? null : input.substring(parameterStart + 1, input.length() - 1);
/*     */ 
/*     */     
/* 113 */     if (parameters != null) {
/* 114 */       String[] parameterArray = StringUtils.split(parameters, ",");
/* 115 */       if (parameterArray.length == 0) {
/* 116 */         parameterNames = null;
/*     */       } else {
/* 118 */         parameterNames = new ArrayList<>(parameterArray.length + 2);
/* 119 */         for (String parameter : parameterArray) {
/* 120 */           parameterNames.add(parameter.trim());
/*     */         }
/*     */       } 
/*     */     } else {
/* 124 */       parameterNames = null;
/*     */     } 
/*     */     
/* 127 */     return new FragmentSignature(fragmentName, parameterNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> processParameters(FragmentSignature fragmentSignature, Map<String, Object> specifiedParameters, boolean parametersAreSynthetic) {
/* 158 */     Validate.notNull(fragmentSignature, "Fragment signature cannot be null");
/*     */     
/* 160 */     if (specifiedParameters == null || specifiedParameters.size() == 0) {
/*     */       
/* 162 */       if (fragmentSignature.hasParameters())
/*     */       {
/* 164 */         throw new TemplateProcessingException("Cannot resolve fragment. Signature \"" + fragmentSignature
/* 165 */             .getStringRepresentation() + "\" declares parameters, but fragment selection did not specify any parameters.");
/*     */       }
/*     */ 
/*     */       
/* 169 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 173 */     if (parametersAreSynthetic && !fragmentSignature.hasParameters()) {
/* 174 */       throw new TemplateProcessingException("Cannot resolve fragment. Signature \"" + fragmentSignature
/* 175 */           .getStringRepresentation() + "\" declares no parameters, but fragment selection did specify parameters in a synthetic manner (without names), which is not correct due to the fact parameters cannot be assigned names unless signature specifies these names.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (parametersAreSynthetic) {
/*     */ 
/*     */       
/* 184 */       List<String> signatureParameterNames = fragmentSignature.getParameterNames();
/*     */       
/* 186 */       if (signatureParameterNames.size() != specifiedParameters.size()) {
/* 187 */         throw new TemplateProcessingException("Cannot resolve fragment. Signature \"" + fragmentSignature
/* 188 */             .getStringRepresentation() + "\" declares " + signatureParameterNames
/* 189 */             .size() + " parameters, but fragment selection specifies " + specifiedParameters
/* 190 */             .size() + " parameters. Fragment selection does not correctly match.");
/*     */       }
/*     */       
/* 193 */       Map<String, Object> processedParameters = new HashMap<>(signatureParameterNames.size() + 1, 1.0F);
/* 194 */       int index = 0;
/* 195 */       for (String parameterName : signatureParameterNames) {
/* 196 */         String syntheticParameterName = getSyntheticParameterNameForIndex(index++);
/* 197 */         Object parameterValue = specifiedParameters.get(syntheticParameterName);
/* 198 */         processedParameters.put(parameterName, parameterValue);
/*     */       } 
/*     */       
/* 201 */       return processedParameters;
/*     */     } 
/*     */ 
/*     */     
/* 205 */     if (!fragmentSignature.hasParameters())
/*     */     {
/*     */       
/* 208 */       return specifiedParameters;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     List<String> parameterNames = fragmentSignature.getParameterNames();
/* 216 */     for (String parameterName : parameterNames) {
/* 217 */       if (!specifiedParameters.containsKey(parameterName)) {
/* 218 */         throw new TemplateProcessingException("Cannot resolve fragment. Signature \"" + fragmentSignature
/* 219 */             .getStringRepresentation() + "\" declares parameter \"" + parameterName + "\", which is not specified at the fragment selection.");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 225 */     return specifiedParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getSyntheticParameterNameForIndex(int i) {
/* 232 */     return "_arg" + i;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\FragmentSignatureUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */