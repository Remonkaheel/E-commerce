/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AndExpression
/*     */   extends BinaryOperationExpression
/*     */ {
/*     */   private static final long serialVersionUID = -6085038102412415337L;
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(AndExpression.class);
/*     */   
/*     */   private static final String OPERATOR = "and";
/*  53 */   static final String[] OPERATORS = new String[] { "and" };
/*  54 */   private static final boolean[] LENIENCIES = new boolean[] { false };
/*     */   
/*  56 */   private static final Class<? extends BinaryOperationExpression>[] OPERATOR_CLASSES = new Class[] { AndExpression.class };
/*     */   
/*     */   private static final Method LEFT_ALLOWED_METHOD;
/*     */   
/*     */   private static final Method RIGHT_ALLOWED_METHOD;
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  65 */       LEFT_ALLOWED_METHOD = AndExpression.class.getDeclaredMethod("isLeftAllowed", new Class[] { IStandardExpression.class });
/*  66 */       RIGHT_ALLOWED_METHOD = AndExpression.class.getDeclaredMethod("isRightAllowed", new Class[] { IStandardExpression.class });
/*  67 */     } catch (NoSuchMethodException e) {
/*  68 */       throw new ExceptionInInitializerError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AndExpression(IStandardExpression left, IStandardExpression right) {
/*  75 */     super(left, right);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringRepresentation() {
/*  81 */     return getStringRepresentation("and");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isRightAllowed(IStandardExpression right) {
/*  87 */     return (right != null && (!(right instanceof Token) || right instanceof BooleanTokenExpression));
/*     */   }
/*     */   
/*     */   static boolean isLeftAllowed(IStandardExpression left) {
/*  91 */     return (left != null && (!(left instanceof Token) || left instanceof BooleanTokenExpression));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ExpressionParsingState composeAndExpression(ExpressionParsingState state, int nodeIndex) {
/*  99 */     return composeBinaryOperationExpression(state, nodeIndex, OPERATORS, LENIENCIES, OPERATOR_CLASSES, LEFT_ALLOWED_METHOD, RIGHT_ALLOWED_METHOD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object executeAnd(IExpressionContext context, AndExpression expression, StandardExpressionExecutionContext expContext) {
/* 111 */     if (logger.isTraceEnabled()) {
/* 112 */       logger.trace("[THYMELEAF][{}] Evaluating AND expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 115 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*     */ 
/*     */     
/* 118 */     boolean leftBooleanValue = EvaluationUtils.evaluateAsBoolean(leftValue);
/* 119 */     if (!leftBooleanValue) {
/* 120 */       return Boolean.FALSE;
/*     */     }
/*     */     
/* 123 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/* 125 */     boolean rightBooleanValue = EvaluationUtils.evaluateAsBoolean(rightValue);
/* 126 */     return Boolean.valueOf(rightBooleanValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\AndExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */