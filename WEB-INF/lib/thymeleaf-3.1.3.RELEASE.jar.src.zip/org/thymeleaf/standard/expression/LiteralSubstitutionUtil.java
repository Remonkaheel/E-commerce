/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LiteralSubstitutionUtil
/*     */ {
/*     */   private static final char LITERAL_SUBSTITUTION_DELIMITER = '|';
/*     */   
/*     */   static String performLiteralSubstitution(String input) {
/*  64 */     if (input == null) {
/*  65 */       return null;
/*     */     }
/*     */     
/*  68 */     StringBuilder strBuilder = null;
/*     */     
/*  70 */     boolean inLiteralSubstitution = false;
/*  71 */     boolean inLiteralSubstitutionInsertion = false;
/*  72 */     int literalSubstitutionIndex = -1;
/*     */     
/*  74 */     int expLevel = 0;
/*  75 */     boolean inLiteral = false;
/*  76 */     boolean inNothing = true;
/*     */     
/*  78 */     int inputLen = input.length();
/*  79 */     for (int i = 0; i < inputLen; i++) {
/*     */       
/*  81 */       char c = input.charAt(i);
/*     */       
/*  83 */       if (c == '|' && !inLiteralSubstitution && inNothing) {
/*     */         
/*  85 */         if (strBuilder == null) {
/*  86 */           strBuilder = new StringBuilder(inputLen + 20);
/*  87 */           strBuilder.append(input, 0, i);
/*     */         } 
/*  89 */         inLiteralSubstitution = true;
/*  90 */         literalSubstitutionIndex = i;
/*     */       }
/*  92 */       else if (c == '|' && inLiteralSubstitution && inNothing) {
/*     */         
/*  94 */         if (i - literalSubstitutionIndex == 1) {
/*     */ 
/*     */ 
/*     */           
/*  98 */           strBuilder
/*  99 */             .append('|')
/* 100 */             .append('|');
/* 101 */         } else if (inLiteralSubstitutionInsertion) {
/* 102 */           strBuilder.append('\'');
/* 103 */           inLiteralSubstitutionInsertion = false;
/*     */         } 
/*     */         
/* 106 */         inLiteralSubstitution = false;
/* 107 */         literalSubstitutionIndex = -1;
/*     */       }
/* 109 */       else if (inNothing && (c == '$' || c == '*' || c == '#' || c == '@') && i + 1 < inputLen && input
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 114 */         .charAt(i + 1) == '{') {
/*     */ 
/*     */         
/* 117 */         if (inLiteralSubstitution && inLiteralSubstitutionInsertion) {
/* 118 */           strBuilder.append("' + ");
/* 119 */           inLiteralSubstitutionInsertion = false;
/* 120 */         } else if (inLiteralSubstitution && i > 0 && input.charAt(i - 1) == '}') {
/*     */           
/* 122 */           strBuilder.append(" + '' + ");
/*     */         } 
/*     */         
/* 125 */         if (strBuilder != null) {
/* 126 */           strBuilder.append(c);
/* 127 */           strBuilder.append('{');
/*     */         } 
/*     */         
/* 130 */         expLevel = 1;
/* 131 */         i++;
/* 132 */         inNothing = false;
/*     */       }
/* 134 */       else if (expLevel == 1 && c == '}') {
/*     */ 
/*     */         
/* 137 */         if (strBuilder != null) {
/* 138 */           strBuilder.append('}');
/*     */         }
/*     */         
/* 141 */         expLevel = 0;
/* 142 */         inNothing = true;
/*     */       }
/* 144 */       else if (expLevel > 0 && c == '{') {
/*     */ 
/*     */         
/* 147 */         if (strBuilder != null) {
/* 148 */           strBuilder.append('{');
/*     */         }
/* 150 */         expLevel++;
/*     */       }
/* 152 */       else if (expLevel > 1 && c == '}') {
/*     */ 
/*     */         
/* 155 */         if (strBuilder != null) {
/* 156 */           strBuilder.append('}');
/*     */         }
/* 158 */         expLevel--;
/*     */       }
/* 160 */       else if (expLevel > 0) {
/*     */ 
/*     */         
/* 163 */         if (strBuilder != null) {
/* 164 */           strBuilder.append(c);
/*     */         }
/*     */       }
/* 167 */       else if (inNothing && !inLiteralSubstitution && c == '\'' && 
/* 168 */         !TextLiteralExpression.isDelimiterEscaped(input, i)) {
/*     */ 
/*     */         
/* 171 */         inNothing = false;
/* 172 */         inLiteral = true;
/*     */         
/* 174 */         if (strBuilder != null) {
/* 175 */           strBuilder.append(c);
/*     */         }
/*     */       }
/* 178 */       else if (inLiteral && !inLiteralSubstitution && c == '\'' && 
/* 179 */         !TextLiteralExpression.isDelimiterEscaped(input, i)) {
/*     */         
/* 181 */         inLiteral = false;
/* 182 */         inNothing = true;
/*     */         
/* 184 */         if (strBuilder != null) {
/* 185 */           strBuilder.append(c);
/*     */         }
/*     */       }
/* 188 */       else if (inLiteralSubstitution && inNothing) {
/*     */ 
/*     */ 
/*     */         
/* 192 */         if (!inLiteralSubstitutionInsertion) {
/* 193 */           if (input.charAt(i - 1) != '|') {
/* 194 */             strBuilder.append(" + ");
/*     */           }
/* 196 */           strBuilder.append('\'');
/* 197 */           inLiteralSubstitutionInsertion = true;
/*     */         } 
/*     */         
/* 200 */         if (c == '\'') {
/* 201 */           strBuilder.append('\\');
/* 202 */         } else if (c == '\\') {
/* 203 */           strBuilder.append('\\');
/*     */         } 
/*     */         
/* 206 */         strBuilder.append(c);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 211 */       else if (strBuilder != null) {
/* 212 */         strBuilder.append(c);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 219 */     if (strBuilder == null) {
/* 220 */       return input;
/*     */     }
/*     */     
/* 223 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\LiteralSubstitutionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */