package org.thymeleaf.standard.expression;

public interface IStandardVariableExpression {
  String getExpression();
  
  boolean getUseSelectionAsRoot();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\IStandardVariableExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */