/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.PropertyAccessor;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.context.IContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OGNLContextPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*  54 */   private static final Logger LOGGER = LoggerFactory.getLogger(OGNLContextPropertyAccessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String RESTRICT_REQUEST_PARAMETERS = "%RESTRICT_REQUEST_PARAMETERS%";
/*     */ 
/*     */ 
/*     */   
/*     */   static final String REQUEST_PARAMETERS_RESTRICTED_VARIABLE_NAME = "param";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(Map ognlContext, Object target, Object name) throws OgnlException {
/*  69 */     if (!(target instanceof IContext)) {
/*  70 */       throw new IllegalStateException("Wrong target type. This property accessor is only usable for " + IContext.class
/*  71 */           .getName() + " implementations, and in this case the target object is " + (
/*  72 */           (target == null) ? "null" : ("of class " + target.getClass().getName())));
/*     */     }
/*     */     
/*  75 */     if ("param".equals(name) && ognlContext != null && ognlContext.containsKey("%RESTRICT_REQUEST_PARAMETERS%")) {
/*  76 */       throw new OgnlException("Access to variable \"" + name + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, direct access to request parameters is forbidden in preprocessing and unescaped expressions, in TEXT template mode, in fragment insertion specifications and in some specific attribute processors.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     String propertyName = (name == null) ? null : name.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     IContext context = (IContext)target;
/*  92 */     return context.getVariable(propertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 101 */     throw new UnsupportedOperationException("Cannot set values into VariablesMap instances from OGNL Expressions");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/* 113 */     context.setCurrentAccessor(IContext.class);
/* 114 */     context.setCurrentType(Object.class);
/*     */     
/* 116 */     return ".getVariable(" + index + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/* 127 */     throw new UnsupportedCompilationException("Setting expression for " + context
/* 128 */         .getCurrentObject() + " with index of " + index + " cannot be computed. IVariablesMap implementations are considered read-only by OGNL.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLContextPropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */