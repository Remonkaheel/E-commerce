/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import ognl.AbstractMemberAccess;
/*     */ import ognl.ClassResolver;
/*     */ import ognl.MemberAccess;
/*     */ import ognl.Ognl;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.standard.util.StandardExpressionUtils;
/*     */ import org.thymeleaf.util.ExpressionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OGNLVariableExpressionEvaluator
/*     */   implements IStandardVariableExpressionEvaluator
/*     */ {
/*  65 */   private static final Logger logger = LoggerFactory.getLogger(OGNLVariableExpressionEvaluator.class);
/*     */ 
/*     */   
/*     */   private static final String EXPRESSION_CACHE_TYPE_OGNL = "ognl";
/*     */ 
/*     */   
/*  71 */   private static Map<String, Object> CONTEXT_VARIABLES_MAP_NOEXPOBJECTS_RESTRICTIONS = Collections.singletonMap("%RESTRICT_REQUEST_PARAMETERS%", "%RESTRICT_REQUEST_PARAMETERS%");
/*     */ 
/*     */ 
/*     */   
/*  75 */   private static MemberAccess MEMBER_ACCESS = (MemberAccess)new ThymeleafACLMemberAccess();
/*  76 */   private static ThymeleafACLClassResolver CLASS_RESOLVER = new ThymeleafACLClassResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean applyOGNLShortcuts;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OGNLVariableExpressionEvaluator(boolean applyOGNLShortcuts) {
/*  87 */     this.applyOGNLShortcuts = applyOGNLShortcuts;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     OGNLContextPropertyAccessor accessor = new OGNLContextPropertyAccessor();
/*  93 */     OgnlRuntime.setPropertyAccessor(IContext.class, accessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object evaluate(IExpressionContext context, IStandardVariableExpression expression, StandardExpressionExecutionContext expContext) {
/* 104 */     return evaluate(context, expression, expContext, this.applyOGNLShortcuts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object evaluate(IExpressionContext context, IStandardVariableExpression expression, StandardExpressionExecutionContext expContext, boolean applyOGNLShortcuts) {
/*     */     try {
/*     */       Map<String, Object> contextVariablesMap;
/*     */       Object result;
/* 118 */       if (logger.isTraceEnabled()) {
/* 119 */         logger.trace("[THYMELEAF][{}] OGNL expression: evaluating expression \"{}\" on target", TemplateEngine.threadIndex(), expression.getExpression());
/*     */       }
/*     */       
/* 122 */       IEngineConfiguration configuration = context.getConfiguration();
/*     */       
/* 124 */       String exp = expression.getExpression();
/* 125 */       boolean useSelectionAsRoot = expression.getUseSelectionAsRoot();
/*     */       
/* 127 */       if (exp == null) {
/* 128 */         throw new TemplateProcessingException("Expression content is null, which is not allowed");
/*     */       }
/*     */ 
/*     */       
/* 132 */       ComputedOGNLExpression parsedExpression = obtainComputedOGNLExpression(configuration, expression, exp, expContext, applyOGNLShortcuts);
/*     */ 
/*     */       
/* 135 */       if (parsedExpression.mightNeedExpressionObjects) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         contextVariablesMap = new OGNLExpressionObjectsWrapper(context.getExpressionObjects());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 152 */         if (expContext.getRestrictVariableAccess()) {
/* 153 */           contextVariablesMap.put("%RESTRICT_REQUEST_PARAMETERS%", "%RESTRICT_REQUEST_PARAMETERS%");
/*     */         } else {
/* 155 */           contextVariablesMap.remove("%RESTRICT_REQUEST_PARAMETERS%");
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 160 */       else if (expContext.getRestrictVariableAccess()) {
/* 161 */         contextVariablesMap = CONTEXT_VARIABLES_MAP_NOEXPOBJECTS_RESTRICTIONS;
/*     */       } else {
/* 163 */         contextVariablesMap = Collections.EMPTY_MAP;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 171 */       ITemplateContext templateContext = (context instanceof ITemplateContext) ? (ITemplateContext)context : null;
/*     */       
/* 173 */       Object evaluationRoot = (useSelectionAsRoot && templateContext != null && templateContext.hasSelectionTarget()) ? templateContext.getSelectionTarget() : templateContext;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 178 */         result = executeExpression(configuration, parsedExpression.expression, contextVariablesMap, evaluationRoot);
/* 179 */       } catch (OGNLShortcutExpressionNotApplicableException notApplicable) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 184 */         invalidateComputedOGNLExpression(configuration, expression, exp);
/* 185 */         return evaluate(context, expression, expContext, false);
/*     */       } 
/*     */       
/* 188 */       if (!expContext.getPerformTypeConversion()) {
/* 189 */         return result;
/*     */       }
/*     */ 
/*     */       
/* 193 */       IStandardConversionService conversionService = StandardExpressions.getConversionService(configuration);
/*     */       
/* 195 */       return conversionService.convert(context, result, String.class);
/*     */     }
/* 197 */     catch (Exception e) {
/* 198 */       throw new TemplateProcessingException("Exception evaluating OGNL expression: \"" + expression
/* 199 */           .getExpression() + "\"", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ComputedOGNLExpression obtainComputedOGNLExpression(IEngineConfiguration configuration, IStandardVariableExpression expression, String exp, StandardExpressionExecutionContext expContext, boolean applyOGNLShortcuts) throws OgnlException {
/* 217 */     boolean doApplyOGNLShortcuts = (applyOGNLShortcuts && !expContext.getRestrictVariableAccess() && !expContext.getRestrictInstantiationAndStatic());
/*     */     
/* 219 */     if (expContext.getRestrictInstantiationAndStatic() && 
/* 220 */       StandardExpressionUtils.containsOGNLInstantiationOrStaticOrParam(exp)) {
/* 221 */       throw new TemplateProcessingException("Instantiation of new objects and access to static classes or parameters is forbidden in this context");
/*     */     }
/*     */ 
/*     */     
/* 225 */     if (expression instanceof VariableExpression) {
/*     */       
/* 227 */       VariableExpression vexpression = (VariableExpression)expression;
/*     */       
/* 229 */       Object cachedExpression = vexpression.getCachedExpression();
/* 230 */       if (cachedExpression != null && cachedExpression instanceof ComputedOGNLExpression) {
/* 231 */         return (ComputedOGNLExpression)cachedExpression;
/*     */       }
/* 233 */       cachedExpression = parseComputedOGNLExpression(configuration, exp, doApplyOGNLShortcuts);
/* 234 */       if (cachedExpression != null) {
/* 235 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 237 */       return (ComputedOGNLExpression)cachedExpression;
/*     */     } 
/*     */ 
/*     */     
/* 241 */     if (expression instanceof SelectionVariableExpression) {
/*     */       
/* 243 */       SelectionVariableExpression vexpression = (SelectionVariableExpression)expression;
/*     */       
/* 245 */       Object cachedExpression = vexpression.getCachedExpression();
/* 246 */       if (cachedExpression != null && cachedExpression instanceof ComputedOGNLExpression) {
/* 247 */         return (ComputedOGNLExpression)cachedExpression;
/*     */       }
/* 249 */       cachedExpression = parseComputedOGNLExpression(configuration, exp, doApplyOGNLShortcuts);
/* 250 */       if (cachedExpression != null) {
/* 251 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 253 */       return (ComputedOGNLExpression)cachedExpression;
/*     */     } 
/*     */ 
/*     */     
/* 257 */     return parseComputedOGNLExpression(configuration, exp, doApplyOGNLShortcuts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ComputedOGNLExpression parseComputedOGNLExpression(IEngineConfiguration configuration, String exp, boolean applyOGNLShortcuts) throws OgnlException {
/* 268 */     ComputedOGNLExpression parsedExpression = (ComputedOGNLExpression)ExpressionCache.getFromCache(configuration, exp, "ognl");
/* 269 */     if (parsedExpression != null) {
/* 270 */       return parsedExpression;
/*     */     }
/*     */     
/* 273 */     parsedExpression = parseExpression(exp, applyOGNLShortcuts);
/* 274 */     ExpressionCache.putIntoCache(configuration, exp, parsedExpression, "ognl");
/* 275 */     return parsedExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void invalidateComputedOGNLExpression(IEngineConfiguration configuration, IStandardVariableExpression expression, String exp) {
/* 283 */     if (expression instanceof VariableExpression) {
/* 284 */       VariableExpression vexpression = (VariableExpression)expression;
/* 285 */       vexpression.setCachedExpression(null);
/* 286 */     } else if (expression instanceof SelectionVariableExpression) {
/* 287 */       SelectionVariableExpression vexpression = (SelectionVariableExpression)expression;
/* 288 */       vexpression.setCachedExpression(null);
/*     */     } 
/* 290 */     ExpressionCache.removeFromCache(configuration, exp, "ognl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 299 */     return "OGNL";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ComputedOGNLExpression parseExpression(String expression, boolean applyOGNLShortcuts) throws OgnlException {
/* 313 */     boolean mightNeedExpressionObjects = StandardExpressionUtils.mightNeedExpressionObjects(expression);
/*     */     
/* 315 */     if (applyOGNLShortcuts) {
/* 316 */       String[] parsedExpression = OGNLShortcutExpression.parse(expression);
/* 317 */       if (parsedExpression != null) {
/* 318 */         return new ComputedOGNLExpression(new OGNLShortcutExpression(parsedExpression), mightNeedExpressionObjects);
/*     */       }
/*     */     } 
/*     */     
/* 322 */     return new ComputedOGNLExpression(Ognl.parseExpression(expression), mightNeedExpressionObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object executeExpression(IEngineConfiguration configuration, Object parsedExpression, Map<String, Object> context, Object root) throws Exception {
/* 333 */     if (parsedExpression instanceof OGNLShortcutExpression) {
/* 334 */       return ((OGNLShortcutExpression)parsedExpression).evaluate(configuration, context, root);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 339 */     OgnlContext ognlContext = new OgnlContext(MEMBER_ACCESS, CLASS_RESOLVER, null, context);
/* 340 */     return Ognl.getValue(parsedExpression, (Map)ognlContext, root);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ComputedOGNLExpression
/*     */   {
/*     */     final Object expression;
/*     */ 
/*     */     
/*     */     final boolean mightNeedExpressionObjects;
/*     */ 
/*     */     
/*     */     ComputedOGNLExpression(Object expression, boolean mightNeedExpressionObjects) {
/* 354 */       this.expression = expression;
/* 355 */       this.mightNeedExpressionObjects = mightNeedExpressionObjects;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ThymeleafACLClassResolver
/*     */     implements ClassResolver
/*     */   {
/* 368 */     private final ClassResolver classResolver = new OGNLVariableExpressionEvaluator.ThymeleafDefaultClassResolver();
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> classForName(String className, Map context) throws ClassNotFoundException {
/* 373 */       if (!ExpressionUtils.isTypeAllowed(className)) {
/* 374 */         throw new TemplateProcessingException(
/* 375 */             String.format("Access is forbidden for type '%s' in this expression context.", new Object[] { className }));
/*     */       }
/*     */ 
/*     */       
/* 379 */       return this.classResolver.classForName(className, context);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ThymeleafDefaultClassResolver
/*     */     implements ClassResolver
/*     */   {
/* 392 */     private final ConcurrentHashMap<String, Class> classes = new ConcurrentHashMap<>(101);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class classForName(String className, Map context) throws ClassNotFoundException {
/* 399 */       Class result = this.classes.get(className);
/* 400 */       if (result != null) {
/* 401 */         return result;
/*     */       }
/*     */       try {
/* 404 */         result = toClassForName(className);
/* 405 */       } catch (ClassNotFoundException e) {
/* 406 */         throw e;
/*     */       } 
/* 408 */       this.classes.putIfAbsent(className, result);
/* 409 */       return result;
/*     */     }
/*     */     
/*     */     private Class toClassForName(String className) throws ClassNotFoundException {
/* 413 */       return Class.forName(className);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ThymeleafACLMemberAccess
/*     */     extends AbstractMemberAccess
/*     */   {
/*     */     public boolean isAccessible(Map context, Object target, Member member, String propertyName) {
/* 427 */       int modifiers = member.getModifiers();
/* 428 */       if (!Modifier.isPublic(modifiers)) {
/* 429 */         return false;
/*     */       }
/* 431 */       if (member instanceof java.lang.reflect.Method && 
/* 432 */         !ExpressionUtils.isMemberAllowed(target, member.getName())) {
/* 433 */         throw new TemplateProcessingException(
/* 434 */             String.format("Accessing member '%s' is forbidden for type '%s' in this expression context.", new Object[] {
/*     */                 
/* 436 */                 member.getName(), target.getClass()
/*     */               }));
/*     */       }
/* 439 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLVariableExpressionEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */