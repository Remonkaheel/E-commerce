package org.thymeleaf.standard.expression;

import org.thymeleaf.context.IExpressionContext;

public interface IStandardConversionService {
  <T> T convert(IExpressionContext paramIExpressionContext, Object paramObject, Class<T> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\IStandardConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */