/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LiteralValue
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4769586410724418224L;
/*    */   private final String value;
/*    */   
/*    */   public LiteralValue(String value) {
/* 48 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 54 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public static Object unwrap(Object obj) {
/* 59 */     if (obj == null) {
/* 60 */       return null;
/*    */     }
/* 62 */     if (obj instanceof LiteralValue) {
/* 63 */       return ((LiteralValue)obj).getValue();
/*    */     }
/* 65 */     return obj;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\LiteralValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */