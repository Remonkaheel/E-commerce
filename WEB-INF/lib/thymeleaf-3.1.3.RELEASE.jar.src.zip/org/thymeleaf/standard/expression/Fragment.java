/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Fragment
/*     */ {
/*  46 */   public static final Fragment EMPTY_FRAGMENT = new Fragment();
/*     */ 
/*     */   
/*     */   private final TemplateModel templateModel;
/*     */   
/*     */   private final Map<String, Object> parameters;
/*     */   
/*     */   private final boolean syntheticParameters;
/*     */ 
/*     */   
/*     */   public Fragment(TemplateModel templateModel, Map<String, Object> parameters, boolean syntheticParameters) {
/*  57 */     Validate.notNull(templateModel, "Template model cannot be null");
/*  58 */     this.templateModel = templateModel;
/*  59 */     this.parameters = (parameters != null) ? Collections.<String, Object>unmodifiableMap(parameters) : null;
/*  60 */     this.syntheticParameters = (this.parameters != null && this.parameters.size() > 0 && syntheticParameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Fragment() {
/*  67 */     this.templateModel = null;
/*  68 */     this.parameters = null;
/*  69 */     this.syntheticParameters = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public TemplateModel getTemplateModel() {
/*  74 */     return this.templateModel;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getParameters() {
/*  78 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public boolean hasSyntheticParameters() {
/*  82 */     return this.syntheticParameters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(Writer writer) throws IOException {
/*  87 */     if (this.templateModel != null) {
/*  88 */       this.templateModel.write(writer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     FastStringWriter fastStringWriter = new FastStringWriter();
/*     */     try {
/*  97 */       write((Writer)fastStringWriter);
/*  98 */     } catch (IOException e) {
/*  99 */       throw new TemplateProcessingException("Exception while creating String representation of model entity", e);
/*     */     } 
/* 101 */     return fastStringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\Fragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */