/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.expression.Aggregates;
/*     */ import org.thymeleaf.expression.Arrays;
/*     */ import org.thymeleaf.expression.Bools;
/*     */ import org.thymeleaf.expression.Calendars;
/*     */ import org.thymeleaf.expression.Conversions;
/*     */ import org.thymeleaf.expression.Dates;
/*     */ import org.thymeleaf.expression.ExecutionInfo;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.expression.Ids;
/*     */ import org.thymeleaf.expression.Lists;
/*     */ import org.thymeleaf.expression.Maps;
/*     */ import org.thymeleaf.expression.Messages;
/*     */ import org.thymeleaf.expression.Numbers;
/*     */ import org.thymeleaf.expression.Objects;
/*     */ import org.thymeleaf.expression.Sets;
/*     */ import org.thymeleaf.expression.Strings;
/*     */ import org.thymeleaf.expression.Temporals;
/*     */ import org.thymeleaf.expression.Uris;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardExpressionObjectFactory
/*     */   implements IExpressionObjectFactory
/*     */ {
/*     */   public static final String CONTEXT_EXPRESSION_OBJECT_NAME = "ctx";
/*     */   public static final String ROOT_EXPRESSION_OBJECT_NAME = "root";
/*     */   public static final String VARIABLES_EXPRESSION_OBJECT_NAME = "vars";
/*     */   public static final String SELECTION_TARGET_EXPRESSION_OBJECT_NAME = "object";
/*     */   public static final String LOCALE_EXPRESSION_OBJECT_NAME = "locale";
/*     */   public static final String REQUEST_EXPRESSION_OBJECT_NAME = "request";
/*     */   public static final String RESPONSE_EXPRESSION_OBJECT_NAME = "response";
/*     */   public static final String SESSION_EXPRESSION_OBJECT_NAME = "session";
/*     */   public static final String SERVLET_CONTEXT_EXPRESSION_OBJECT_NAME = "servletContext";
/*     */   public static final String CONVERSIONS_EXPRESSION_OBJECT_NAME = "conversions";
/*     */   public static final String URIS_EXPRESSION_OBJECT_NAME = "uris";
/*     */   public static final String TEMPORALS_EXPRESSION_OBJECT_NAME = "temporals";
/*     */   public static final String CALENDARS_EXPRESSION_OBJECT_NAME = "calendars";
/*     */   public static final String DATES_EXPRESSION_OBJECT_NAME = "dates";
/*     */   public static final String BOOLS_EXPRESSION_OBJECT_NAME = "bools";
/*     */   public static final String NUMBERS_EXPRESSION_OBJECT_NAME = "numbers";
/*     */   public static final String OBJECTS_EXPRESSION_OBJECT_NAME = "objects";
/*     */   public static final String STRINGS_EXPRESSION_OBJECT_NAME = "strings";
/*     */   public static final String ARRAYS_EXPRESSION_OBJECT_NAME = "arrays";
/*     */   public static final String LISTS_EXPRESSION_OBJECT_NAME = "lists";
/*     */   public static final String SETS_EXPRESSION_OBJECT_NAME = "sets";
/*     */   public static final String MAPS_EXPRESSION_OBJECT_NAME = "maps";
/*     */   public static final String AGGREGATES_EXPRESSION_OBJECT_NAME = "aggregates";
/*     */   public static final String MESSAGES_EXPRESSION_OBJECT_NAME = "messages";
/*     */   public static final String IDS_EXPRESSION_OBJECT_NAME = "ids";
/*     */   public static final String EXECUTION_INFO_OBJECT_NAME = "execInfo";
/* 109 */   protected static final Set<String> ALL_EXPRESSION_OBJECT_NAMES = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(new String[] { 
/*     */             "ctx", "root", "vars", "object", "locale", "conversions", "uris", "temporals", "calendars", "dates", 
/*     */             "bools", "numbers", "objects", "strings", "arrays", "lists", "sets", "maps", "aggregates", "messages", 
/*     */             "ids", "execInfo", "request", "response", "session", "servletContext" })));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   private static final Uris URIS_EXPRESSION_OBJECT = new Uris();
/* 143 */   private static final Bools BOOLS_EXPRESSION_OBJECT = new Bools();
/* 144 */   private static final Objects OBJECTS_EXPRESSION_OBJECT = new Objects();
/* 145 */   private static final Arrays ARRAYS_EXPRESSION_OBJECT = new Arrays();
/* 146 */   private static final Lists LISTS_EXPRESSION_OBJECT = new Lists();
/* 147 */   private static final Sets SETS_EXPRESSION_OBJECT = new Sets();
/* 148 */   private static final Maps MAPS_EXPRESSION_OBJECT = new Maps();
/* 149 */   private static final Aggregates AGGREGATES_EXPRESSION_OBJECT = new Aggregates();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getAllExpressionObjectNames() {
/* 164 */     return ALL_EXPRESSION_OBJECT_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCacheable(String expressionObjectName) {
/* 171 */     return (expressionObjectName != null && !expressionObjectName.equals("object"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildObject(IExpressionContext context, String expressionObjectName) {
/* 180 */     if ("object".equals(expressionObjectName)) {
/* 181 */       if (context instanceof ITemplateContext) {
/* 182 */         ITemplateContext templateContext = (ITemplateContext)context;
/* 183 */         if (templateContext.hasSelectionTarget()) {
/* 184 */           return templateContext.getSelectionTarget();
/*     */         }
/*     */       } 
/* 187 */       return context;
/*     */     } 
/*     */     
/* 190 */     if ("root".equals(expressionObjectName)) {
/* 191 */       return context;
/*     */     }
/* 193 */     if ("vars".equals(expressionObjectName)) {
/* 194 */       return context;
/*     */     }
/* 196 */     if ("ctx".equals(expressionObjectName)) {
/* 197 */       return context;
/*     */     }
/* 199 */     if ("locale".equals(expressionObjectName)) {
/* 200 */       return context.getLocale();
/*     */     }
/* 202 */     if ("request".equals(expressionObjectName) || "session"
/* 203 */       .equals(expressionObjectName) || "servletContext"
/* 204 */       .equals(expressionObjectName) || "response"
/* 205 */       .equals(expressionObjectName)) {
/* 206 */       throw new IllegalArgumentException(
/* 207 */           String.format("The '%s','%s','%s' and '%s' expression utility objects are no longer available by default for template expressions and their use is not recommended. In cases where they are really needed, they should be manually added as context variables.", new Object[] { "request", "session", "servletContext", "response" }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     if ("conversions".equals(expressionObjectName)) {
/* 215 */       return new Conversions(context);
/*     */     }
/* 217 */     if ("uris".equals(expressionObjectName)) {
/* 218 */       return URIS_EXPRESSION_OBJECT;
/*     */     }
/* 220 */     if ("calendars".equals(expressionObjectName)) {
/* 221 */       return new Calendars(context.getLocale());
/*     */     }
/* 223 */     if ("temporals".equals(expressionObjectName)) {
/* 224 */       return new Temporals(context.getLocale());
/*     */     }
/* 226 */     if ("dates".equals(expressionObjectName)) {
/* 227 */       return new Dates(context.getLocale());
/*     */     }
/* 229 */     if ("bools".equals(expressionObjectName)) {
/* 230 */       return BOOLS_EXPRESSION_OBJECT;
/*     */     }
/* 232 */     if ("numbers".equals(expressionObjectName)) {
/* 233 */       return new Numbers(context.getLocale());
/*     */     }
/* 235 */     if ("objects".equals(expressionObjectName)) {
/* 236 */       return OBJECTS_EXPRESSION_OBJECT;
/*     */     }
/* 238 */     if ("strings".equals(expressionObjectName)) {
/* 239 */       return new Strings(context.getLocale());
/*     */     }
/* 241 */     if ("arrays".equals(expressionObjectName)) {
/* 242 */       return ARRAYS_EXPRESSION_OBJECT;
/*     */     }
/* 244 */     if ("lists".equals(expressionObjectName)) {
/* 245 */       return LISTS_EXPRESSION_OBJECT;
/*     */     }
/* 247 */     if ("sets".equals(expressionObjectName)) {
/* 248 */       return SETS_EXPRESSION_OBJECT;
/*     */     }
/* 250 */     if ("maps".equals(expressionObjectName)) {
/* 251 */       return MAPS_EXPRESSION_OBJECT;
/*     */     }
/* 253 */     if ("aggregates".equals(expressionObjectName)) {
/* 254 */       return AGGREGATES_EXPRESSION_OBJECT;
/*     */     }
/* 256 */     if ("messages".equals(expressionObjectName)) {
/* 257 */       if (context instanceof ITemplateContext) {
/* 258 */         return new Messages((ITemplateContext)context);
/*     */       }
/* 260 */       return null;
/*     */     } 
/* 262 */     if ("ids".equals(expressionObjectName)) {
/* 263 */       if (context instanceof ITemplateContext) {
/* 264 */         return new Ids((ITemplateContext)context);
/*     */       }
/* 266 */       return null;
/*     */     } 
/* 268 */     if ("execInfo".equals(expressionObjectName)) {
/* 269 */       if (context instanceof ITemplateContext) {
/* 270 */         return new ExecutionInfo((ITemplateContext)context);
/*     */       }
/* 272 */       return null;
/*     */     } 
/*     */     
/* 275 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\expression\StandardExpressionObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */