/*    */ package org.thymeleaf.standard.util;
/*    */ 
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.ElementTagStructureHandler;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardProcessorUtils
/*    */ {
/*    */   public static void replaceAttribute(IElementTagStructureHandler structureHandler, AttributeName oldAttributeName, AttributeDefinition attributeDefinition, String attributeName, String attributeValue) {
/* 49 */     if (structureHandler instanceof ElementTagStructureHandler) {
/* 50 */       ((ElementTagStructureHandler)structureHandler).replaceAttribute(oldAttributeName, attributeDefinition, attributeName, attributeValue, null);
/*    */     } else {
/* 52 */       structureHandler.replaceAttribute(oldAttributeName, attributeName, attributeValue);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setAttribute(IElementTagStructureHandler structureHandler, AttributeDefinition attributeDefinition, String attributeName, String attributeValue) {
/* 62 */     if (structureHandler instanceof ElementTagStructureHandler) {
/* 63 */       ((ElementTagStructureHandler)structureHandler).setAttribute(attributeDefinition, attributeName, attributeValue, null);
/*    */     } else {
/* 65 */       structureHandler.setAttribute(attributeName, attributeValue);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standar\\util\StandardProcessorUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */