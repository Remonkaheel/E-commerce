/*     */ package org.thymeleaf.standard.util;
/*     */ 
/*     */ import org.thymeleaf.util.ExpressionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardExpressionUtils
/*     */ {
/*  34 */   private static final char[] NEW_ARRAY = "wen".toCharArray();
/*  35 */   private static final int NEW_LEN = NEW_ARRAY.length;
/*  36 */   private static final char[] PARAM_ARRAY = "marap".toCharArray();
/*  37 */   private static final int PARAM_LEN = PARAM_ARRAY.length;
/*     */ 
/*     */   
/*     */   public static boolean mightNeedExpressionObjects(String expression) {
/*  41 */     return (expression.indexOf('#') >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean containsOGNLInstantiationOrStaticOrParam(String expression) {
/*  55 */     String exp = ExpressionUtils.normalize(expression);
/*     */     
/*  57 */     int explen = exp.length();
/*  58 */     int n = explen;
/*  59 */     int ni = 0;
/*  60 */     int pi = 0;
/*  61 */     int si = -1;
/*     */     
/*  63 */     while (n-- != 0) {
/*     */       
/*  65 */       char c = exp.charAt(n);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  70 */       if (ni < NEW_LEN && c == NEW_ARRAY[ni] && (ni > 0 || (n + 1 < explen && 
/*     */         
/*  72 */         Character.isWhitespace(exp.charAt(n + 1))))) {
/*  73 */         ni++;
/*  74 */         if (ni == NEW_LEN && (n == 0 || !isSafeIdentifierChar(exp.charAt(n - 1)))) {
/*  75 */           return true;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*  80 */       if (ni > 0) {
/*     */         
/*  82 */         n += ni;
/*  83 */         ni = 0;
/*  84 */         if (si < n)
/*     */         {
/*  86 */           si = -1;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*  91 */       ni = 0;
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (pi < PARAM_LEN && c == PARAM_ARRAY[pi] && (pi > 0 || (n + 1 < explen && 
/*     */         
/*  97 */         !isSafeIdentifierChar(exp.charAt(n + 1))))) {
/*  98 */         pi++;
/*  99 */         if (pi == PARAM_LEN && (n == 0 || !isSafeIdentifierChar(exp.charAt(n - 1)))) {
/* 100 */           return true;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 105 */       if (pi > 0) {
/*     */         
/* 107 */         n += pi;
/* 108 */         pi = 0;
/*     */         
/*     */         continue;
/*     */       } 
/* 112 */       pi = 0;
/*     */       
/* 114 */       if (c == '@') {
/* 115 */         if (si > n) {
/* 116 */           return true;
/*     */         }
/* 118 */         si = n; continue;
/* 119 */       }  if (si > n && !Character.isJavaIdentifierPart(c) && !Character.isWhitespace(c) && c != '.') {
/* 120 */         si = -1;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSafeIdentifierChar(char c) {
/* 131 */     return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_');
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standar\\util\StandardExpressionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */