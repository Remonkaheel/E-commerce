/*     */ package org.thymeleaf.standard;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.dialect.AbstractProcessorDialect;
/*     */ import org.thymeleaf.dialect.IExecutionAttributeDialect;
/*     */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.standard.expression.IStandardConversionService;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpressionEvaluator;
/*     */ import org.thymeleaf.standard.expression.OGNLVariableExpressionEvaluator;
/*     */ import org.thymeleaf.standard.expression.StandardConversionService;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionObjectFactory;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionParser;
/*     */ import org.thymeleaf.standard.processor.StandardActionTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAltTitleTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAssertTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAttrTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAttrappendTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAttrprependTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardBlockTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardCaseTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardClassappendTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardConditionalCommentProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardConditionalFixedValueTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardDOMEventAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardDefaultAttributesTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardEachTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardFragmentTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardHrefTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardIfTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardIncludeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineEnablementTemplateBoundariesProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineHTMLTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineTextualTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineXMLTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInliningCDATASectionProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInliningCommentProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInliningTextProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInsertTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardLangXmlLangTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardMethodTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardNonRemovableAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardObjectTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardRefAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardRemovableAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardRemoveTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardReplaceTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardSrcTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardStyleappendTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardSwitchTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardTextTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardTranslationDocTypeProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardUnlessTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardUtextTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardValueTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardWithTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlBaseTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlLangTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlNsTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlSpaceTagProcessor;
/*     */ import org.thymeleaf.standard.serializer.IStandardCSSSerializer;
/*     */ import org.thymeleaf.standard.serializer.IStandardJavaScriptSerializer;
/*     */ import org.thymeleaf.standard.serializer.StandardCSSSerializer;
/*     */ import org.thymeleaf.standard.serializer.StandardJavaScriptSerializer;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardDialect
/*     */   extends AbstractProcessorDialect
/*     */   implements IExecutionAttributeDialect, IExpressionObjectDialect
/*     */ {
/*     */   public static final String NAME = "Standard";
/*     */   public static final String PREFIX = "th";
/*     */   public static final int PROCESSOR_PRECEDENCE = 1000;
/* 127 */   protected IStandardVariableExpressionEvaluator variableExpressionEvaluator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   protected IStandardExpressionParser expressionParser = null;
/* 133 */   protected IStandardConversionService conversionService = null;
/* 134 */   protected IStandardJavaScriptSerializer javaScriptSerializer = null;
/* 135 */   protected IStandardCSSSerializer cssSerializer = null;
/*     */ 
/*     */   
/* 138 */   protected IExpressionObjectFactory expressionObjectFactory = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardDialect() {
/* 146 */     super("Standard", "th", 1000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StandardDialect(String name, String prefix, int processorPrecedence) {
/* 155 */     super(name, prefix, processorPrecedence);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardVariableExpressionEvaluator getVariableExpressionEvaluator() {
/* 177 */     if (this.variableExpressionEvaluator == null) {
/* 178 */       this.variableExpressionEvaluator = (IStandardVariableExpressionEvaluator)new OGNLVariableExpressionEvaluator(true);
/*     */     }
/* 180 */     return this.variableExpressionEvaluator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariableExpressionEvaluator(IStandardVariableExpressionEvaluator variableExpressionEvaluator) {
/* 206 */     Validate.notNull(variableExpressionEvaluator, "Standard Variable Expression Evaluator cannot be null");
/* 207 */     this.variableExpressionEvaluator = variableExpressionEvaluator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardExpressionParser getExpressionParser() {
/* 223 */     if (this.expressionParser == null) {
/* 224 */       this.expressionParser = (IStandardExpressionParser)new StandardExpressionParser();
/*     */     }
/* 226 */     return this.expressionParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionParser(IStandardExpressionParser expressionParser) {
/* 248 */     Validate.notNull(expressionParser, "Standard Expression Parser cannot be null");
/* 249 */     this.expressionParser = expressionParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardConversionService getConversionService() {
/* 266 */     if (this.conversionService == null) {
/* 267 */       this.conversionService = (IStandardConversionService)new StandardConversionService();
/*     */     }
/* 269 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConversionService(IStandardConversionService conversionService) {
/* 292 */     Validate.notNull(conversionService, "Standard Conversion Service cannot be null");
/* 293 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardJavaScriptSerializer getJavaScriptSerializer() {
/* 309 */     if (this.javaScriptSerializer == null) {
/* 310 */       this.javaScriptSerializer = (IStandardJavaScriptSerializer)new StandardJavaScriptSerializer(true);
/*     */     }
/* 312 */     return this.javaScriptSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaScriptSerializer(IStandardJavaScriptSerializer javaScriptSerializer) {
/* 334 */     Validate.notNull(javaScriptSerializer, "Standard JavaScript Serializer cannot be null");
/* 335 */     this.javaScriptSerializer = javaScriptSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardCSSSerializer getCSSSerializer() {
/* 351 */     if (this.cssSerializer == null) {
/* 352 */       this.cssSerializer = (IStandardCSSSerializer)new StandardCSSSerializer();
/*     */     }
/* 354 */     return this.cssSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCSSSerializer(IStandardCSSSerializer cssSerializer) {
/* 376 */     Validate.notNull(cssSerializer, "Standard CSS Serializer cannot be null");
/* 377 */     this.cssSerializer = cssSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getExecutionAttributes() {
/* 390 */     Map<String, Object> executionAttributes = new HashMap<>(5, 1.0F);
/* 391 */     executionAttributes.put("StandardVariableExpressionEvaluator", 
/* 392 */         getVariableExpressionEvaluator());
/* 393 */     executionAttributes.put("StandardExpressionParser", 
/* 394 */         getExpressionParser());
/* 395 */     executionAttributes.put("StandardConversionService", 
/* 396 */         getConversionService());
/* 397 */     executionAttributes.put("StandardJavaScriptSerializer", 
/* 398 */         getJavaScriptSerializer());
/* 399 */     executionAttributes.put("StandardCSSSerializer", 
/* 400 */         getCSSSerializer());
/*     */     
/* 402 */     return executionAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IExpressionObjectFactory getExpressionObjectFactory() {
/* 410 */     if (this.expressionObjectFactory == null) {
/* 411 */       this.expressionObjectFactory = (IExpressionObjectFactory)new StandardExpressionObjectFactory();
/*     */     }
/* 413 */     return this.expressionObjectFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<IProcessor> getProcessors(String dialectPrefix) {
/* 420 */     return createStandardProcessorsSet(dialectPrefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<IProcessor> createStandardProcessorsSet(String dialectPrefix) {
/* 444 */     Set<IProcessor> processors = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 460 */     processors.add(new StandardActionTagProcessor(dialectPrefix));
/* 461 */     processors.add(new StandardAltTitleTagProcessor(dialectPrefix));
/* 462 */     processors.add(new StandardAssertTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 463 */     processors.add(new StandardAttrTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 464 */     processors.add(new StandardAttrappendTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 465 */     processors.add(new StandardAttrprependTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 466 */     processors.add(new StandardCaseTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 467 */     processors.add(new StandardClassappendTagProcessor(dialectPrefix));
/* 468 */     for (String attrName : StandardConditionalFixedValueTagProcessor.ATTR_NAMES) {
/* 469 */       processors.add(new StandardConditionalFixedValueTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 471 */     for (String attrName : StandardDOMEventAttributeTagProcessor.ATTR_NAMES) {
/* 472 */       processors.add(new StandardDOMEventAttributeTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 474 */     processors.add(new StandardEachTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 475 */     processors.add(new StandardFragmentTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 476 */     processors.add(new StandardHrefTagProcessor(dialectPrefix));
/* 477 */     processors.add(new StandardIfTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 478 */     processors.add(new StandardIncludeTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 479 */     processors.add(new StandardInlineHTMLTagProcessor(dialectPrefix));
/* 480 */     processors.add(new StandardInsertTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 481 */     processors.add(new StandardLangXmlLangTagProcessor(dialectPrefix));
/* 482 */     processors.add(new StandardMethodTagProcessor(dialectPrefix));
/* 483 */     for (String attrName : StandardNonRemovableAttributeTagProcessor.ATTR_NAMES) {
/* 484 */       processors.add(new StandardNonRemovableAttributeTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 486 */     processors.add(new StandardObjectTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 487 */     for (String attrName : StandardRemovableAttributeTagProcessor.ATTR_NAMES) {
/* 488 */       processors.add(new StandardRemovableAttributeTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 490 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 491 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 492 */     processors.add(new StandardSrcTagProcessor(dialectPrefix));
/* 493 */     processors.add(new StandardStyleappendTagProcessor(dialectPrefix));
/* 494 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 495 */     processors.add(new StandardTextTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 496 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 497 */     processors.add(new StandardUtextTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 498 */     processors.add(new StandardValueTagProcessor(dialectPrefix));
/* 499 */     processors.add(new StandardWithTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 500 */     processors.add(new StandardXmlBaseTagProcessor(dialectPrefix));
/* 501 */     processors.add(new StandardXmlLangTagProcessor(dialectPrefix));
/* 502 */     processors.add(new StandardXmlSpaceTagProcessor(dialectPrefix));
/* 503 */     processors.add(new StandardXmlNsTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 504 */     processors.add(new StandardRefAttributeTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 505 */     processors.add(new StandardDefaultAttributesTagProcessor(TemplateMode.HTML, dialectPrefix));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 510 */     processors.add(new StandardBlockTagProcessor(TemplateMode.HTML, dialectPrefix, "block"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 521 */     processors.add(new StandardInliningTextProcessor(TemplateMode.HTML));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 529 */     processors.add(new StandardInliningCDATASectionProcessor(TemplateMode.HTML));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 534 */     processors.add(new StandardTranslationDocTypeProcessor());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 542 */     processors.add(new StandardInliningCommentProcessor(TemplateMode.HTML));
/* 543 */     processors.add(new StandardConditionalCommentProcessor());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 548 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.HTML));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 564 */     processors.add(new StandardAssertTagProcessor(TemplateMode.XML, dialectPrefix));
/* 565 */     processors.add(new StandardAttrTagProcessor(TemplateMode.XML, dialectPrefix));
/* 566 */     processors.add(new StandardAttrappendTagProcessor(TemplateMode.XML, dialectPrefix));
/* 567 */     processors.add(new StandardAttrprependTagProcessor(TemplateMode.XML, dialectPrefix));
/* 568 */     processors.add(new StandardCaseTagProcessor(TemplateMode.XML, dialectPrefix));
/* 569 */     processors.add(new StandardEachTagProcessor(TemplateMode.XML, dialectPrefix));
/* 570 */     processors.add(new StandardFragmentTagProcessor(TemplateMode.XML, dialectPrefix));
/* 571 */     processors.add(new StandardIfTagProcessor(TemplateMode.XML, dialectPrefix));
/* 572 */     processors.add(new StandardIncludeTagProcessor(TemplateMode.XML, dialectPrefix));
/* 573 */     processors.add(new StandardInlineXMLTagProcessor(dialectPrefix));
/* 574 */     processors.add(new StandardInsertTagProcessor(TemplateMode.XML, dialectPrefix));
/* 575 */     processors.add(new StandardObjectTagProcessor(TemplateMode.XML, dialectPrefix));
/* 576 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.XML, dialectPrefix));
/* 577 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.XML, dialectPrefix));
/* 578 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.XML, dialectPrefix));
/* 579 */     processors.add(new StandardTextTagProcessor(TemplateMode.XML, dialectPrefix));
/* 580 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.XML, dialectPrefix));
/* 581 */     processors.add(new StandardUtextTagProcessor(TemplateMode.XML, dialectPrefix));
/* 582 */     processors.add(new StandardWithTagProcessor(TemplateMode.XML, dialectPrefix));
/* 583 */     processors.add(new StandardXmlNsTagProcessor(TemplateMode.XML, dialectPrefix));
/* 584 */     processors.add(new StandardRefAttributeTagProcessor(TemplateMode.XML, dialectPrefix));
/* 585 */     processors.add(new StandardDefaultAttributesTagProcessor(TemplateMode.XML, dialectPrefix));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 590 */     processors.add(new StandardBlockTagProcessor(TemplateMode.XML, dialectPrefix, "block"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 601 */     processors.add(new StandardInliningTextProcessor(TemplateMode.XML));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 609 */     processors.add(new StandardInliningCDATASectionProcessor(TemplateMode.XML));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 617 */     processors.add(new StandardInliningCommentProcessor(TemplateMode.XML));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 622 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.XML));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 638 */     processors.add(new StandardAssertTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 639 */     processors.add(new StandardCaseTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 640 */     processors.add(new StandardEachTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */     
/* 642 */     processors.add(new StandardIfTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */     
/* 644 */     processors.add(new StandardInlineTextualTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 645 */     processors.add(new StandardInsertTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 646 */     processors.add(new StandardObjectTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 647 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 648 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 649 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 650 */     processors.add(new StandardTextTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 651 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 652 */     processors.add(new StandardUtextTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 653 */     processors.add(new StandardWithTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 658 */     processors.add(new StandardBlockTagProcessor(TemplateMode.TEXT, dialectPrefix, "block"));
/* 659 */     processors.add(new StandardBlockTagProcessor(TemplateMode.TEXT, null, ""));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 669 */     processors.add(new StandardInliningTextProcessor(TemplateMode.TEXT));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 674 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.TEXT));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 690 */     processors.add(new StandardAssertTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 691 */     processors.add(new StandardCaseTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 692 */     processors.add(new StandardEachTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */     
/* 694 */     processors.add(new StandardIfTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */     
/* 696 */     processors.add(new StandardInlineTextualTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 697 */     processors.add(new StandardInsertTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 698 */     processors.add(new StandardObjectTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 699 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 700 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 701 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 702 */     processors.add(new StandardTextTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 703 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 704 */     processors.add(new StandardUtextTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 705 */     processors.add(new StandardWithTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 710 */     processors.add(new StandardBlockTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix, "block"));
/* 711 */     processors.add(new StandardBlockTagProcessor(TemplateMode.JAVASCRIPT, null, ""));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 721 */     processors.add(new StandardInliningTextProcessor(TemplateMode.JAVASCRIPT));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 726 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.JAVASCRIPT));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 742 */     processors.add(new StandardAssertTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 743 */     processors.add(new StandardCaseTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 744 */     processors.add(new StandardEachTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */     
/* 746 */     processors.add(new StandardIfTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */     
/* 748 */     processors.add(new StandardInlineTextualTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 749 */     processors.add(new StandardInsertTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 750 */     processors.add(new StandardObjectTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 751 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 752 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 753 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 754 */     processors.add(new StandardTextTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 755 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 756 */     processors.add(new StandardUtextTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 757 */     processors.add(new StandardWithTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 762 */     processors.add(new StandardBlockTagProcessor(TemplateMode.CSS, dialectPrefix, "block"));
/* 763 */     processors.add(new StandardBlockTagProcessor(TemplateMode.CSS, null, ""));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 773 */     processors.add(new StandardInliningTextProcessor(TemplateMode.CSS));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 778 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.CSS));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 793 */     return processors;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\StandardDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */