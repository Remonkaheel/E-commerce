package org.thymeleaf.standard.inline;

public interface IInlinePreProcessorHandler {
  void handleText(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleStandaloneElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4);
  
  void handleStandaloneElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4);
  
  void handleOpenElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleOpenElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleAutoOpenElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleAutoOpenElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleCloseElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleCloseElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleAutoCloseElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleAutoCloseElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void handleAttribute(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\inline\IInlinePreProcessorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */