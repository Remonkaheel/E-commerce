/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum StandardInlineMode
/*    */ {
/* 39 */   NONE, HTML, XML, TEXT, JAVASCRIPT, CSS;
/*    */   
/*    */   static {
/* 42 */     LOGGER = LoggerFactory.getLogger(StandardInlineMode.class);
/*    */   }
/*    */   private static final Logger LOGGER;
/*    */   public static StandardInlineMode parse(String mode) {
/* 46 */     if (mode == null || mode.trim().length() == 0) {
/* 47 */       throw new IllegalArgumentException("Inline mode cannot be null or empty");
/*    */     }
/* 49 */     if ("NONE".equalsIgnoreCase(mode)) {
/* 50 */       return NONE;
/*    */     }
/* 52 */     if ("HTML".equalsIgnoreCase(mode)) {
/* 53 */       return HTML;
/*    */     }
/* 55 */     if ("XML".equalsIgnoreCase(mode)) {
/* 56 */       return XML;
/*    */     }
/* 58 */     if ("TEXT".equalsIgnoreCase(mode)) {
/* 59 */       return TEXT;
/*    */     }
/* 61 */     if ("JAVASCRIPT".equalsIgnoreCase(mode)) {
/* 62 */       return JAVASCRIPT;
/*    */     }
/* 64 */     if ("CSS".equalsIgnoreCase(mode)) {
/* 65 */       return CSS;
/*    */     }
/* 67 */     throw new IllegalArgumentException("Unrecognized inline mode: " + mode);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\inline\StandardInlineMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */