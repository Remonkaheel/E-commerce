/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.standard.serializer.IStandardCSSSerializer;
/*    */ import org.thymeleaf.standard.serializer.StandardSerializers;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.FastStringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardCSSInliner
/*    */   extends AbstractStandardInliner
/*    */ {
/*    */   private final IStandardCSSSerializer serializer;
/*    */   
/*    */   public StandardCSSInliner(IEngineConfiguration configuration) {
/* 42 */     super(configuration, TemplateMode.CSS);
/* 43 */     this.serializer = StandardSerializers.getCSSSerializer(configuration);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String produceEscapedOutput(Object input) {
/* 49 */     FastStringWriter fastStringWriter = new FastStringWriter((input instanceof String) ? (((String)input).length() * 2) : 20);
/* 50 */     this.serializer.serializeValue(input, (Writer)fastStringWriter);
/* 51 */     return fastStringWriter.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\inline\StandardCSSInliner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */