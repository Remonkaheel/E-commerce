/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardHTMLInliner
/*    */   extends AbstractStandardInliner
/*    */ {
/*    */   public StandardHTMLInliner(IEngineConfiguration configuration) {
/* 36 */     super(configuration, TemplateMode.HTML);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String produceEscapedOutput(Object input) {
/* 42 */     if (input == null) {
/* 43 */       return "";
/*    */     }
/* 45 */     return HtmlEscape.escapeHtml4Xml(input.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\inline\StandardHTMLInliner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */