/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.unbescape.xml.XmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardXMLInliner
/*    */   extends AbstractStandardInliner
/*    */ {
/*    */   public StandardXMLInliner(IEngineConfiguration configuration) {
/* 36 */     super(configuration, TemplateMode.XML);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String produceEscapedOutput(Object input) {
/* 42 */     if (input == null) {
/* 43 */       return "";
/*    */     }
/*    */ 
/*    */     
/* 47 */     return XmlEscape.escapeXml10(input.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\standard\inline\StandardXMLInliner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */