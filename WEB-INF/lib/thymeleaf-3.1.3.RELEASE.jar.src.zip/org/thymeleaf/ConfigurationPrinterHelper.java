/*     */ package org.thymeleaf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.dialect.IDialect;
/*     */ import org.thymeleaf.dialect.IExecutionAttributeDialect;
/*     */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*     */ import org.thymeleaf.dialect.IPostProcessorDialect;
/*     */ import org.thymeleaf.dialect.IPreProcessorDialect;
/*     */ import org.thymeleaf.dialect.IProcessorDialect;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.linkbuilder.ILinkBuilder;
/*     */ import org.thymeleaf.messageresolver.IMessageResolver;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.preprocessor.IPreProcessor;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
/*     */ import org.thymeleaf.processor.comment.ICommentProcessor;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeProcessor;
/*     */ import org.thymeleaf.processor.element.IElementModelProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagProcessor;
/*     */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*     */ import org.thymeleaf.processor.element.MatchingElementName;
/*     */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
/*     */ import org.thymeleaf.processor.text.ITextProcessor;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConfigurationPrinterHelper
/*     */ {
/*  67 */   public static final String CONFIGURATION_LOGGER_NAME = TemplateEngine.class.getName() + ".CONFIG";
/*     */   
/*  69 */   private static final Logger configLogger = LoggerFactory.getLogger(CONFIGURATION_LOGGER_NAME);
/*     */   
/*  71 */   private static String THYMELEAF_VERSION = Thymeleaf.getVersion();
/*  72 */   private static String THYMELEAF_BUILD_TIMESTAMP = Thymeleaf.getBuildTimestamp();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void printConfiguration(IEngineConfiguration configuration) {
/*  78 */     ConfigLogBuilder logBuilder = new ConfigLogBuilder();
/*     */     
/*  80 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  81 */     Set<ITemplateResolver> templateResolvers = configuration.getTemplateResolvers();
/*  82 */     Set<IMessageResolver> messageResolvers = configuration.getMessageResolvers();
/*  83 */     Set<ILinkBuilder> linkBuilders = configuration.getLinkBuilders();
/*     */     
/*  85 */     logBuilder.line("Initializing Thymeleaf Template engine configuration...");
/*  86 */     logBuilder.line("[THYMELEAF] TEMPLATE ENGINE CONFIGURATION:");
/*  87 */     if (!StringUtils.isEmptyOrWhitespace(THYMELEAF_VERSION)) {
/*  88 */       if (!StringUtils.isEmptyOrWhitespace(THYMELEAF_BUILD_TIMESTAMP)) {
/*  89 */         logBuilder.line("[THYMELEAF] * Thymeleaf version: {} (built {})", THYMELEAF_VERSION, THYMELEAF_BUILD_TIMESTAMP);
/*     */       } else {
/*  91 */         logBuilder.line("[THYMELEAF] * Thymeleaf version: {}", THYMELEAF_VERSION);
/*     */       } 
/*     */     }
/*  94 */     logBuilder.line("[THYMELEAF] * Cache Manager implementation: {}", (cacheManager == null) ? "[no caches]" : cacheManager.getClass().getName());
/*  95 */     logBuilder.line("[THYMELEAF] * Template resolvers:");
/*  96 */     for (ITemplateResolver templateResolver : templateResolvers) {
/*  97 */       if (templateResolver.getOrder() != null) {
/*  98 */         logBuilder.line("[THYMELEAF]     * [{}] {}", templateResolver.getOrder(), templateResolver.getName()); continue;
/*     */       } 
/* 100 */       logBuilder.line("[THYMELEAF]     * {}", templateResolver.getName());
/*     */     } 
/*     */     
/* 103 */     logBuilder.line("[THYMELEAF] * Message resolvers:");
/* 104 */     for (IMessageResolver messageResolver : messageResolvers) {
/* 105 */       if (messageResolver.getOrder() != null) {
/* 106 */         logBuilder.line("[THYMELEAF]     * [{}] {}", messageResolver.getOrder(), messageResolver.getName()); continue;
/*     */       } 
/* 108 */       logBuilder.line("[THYMELEAF]     * {}", messageResolver.getName());
/*     */     } 
/*     */     
/* 111 */     logBuilder.line("[THYMELEAF] * Link builders:");
/* 112 */     for (ILinkBuilder linkBuilder : linkBuilders) {
/* 113 */       if (linkBuilder.getOrder() != null) {
/* 114 */         logBuilder.line("[THYMELEAF]     * [{}] {}", linkBuilder.getOrder(), linkBuilder.getName()); continue;
/*     */       } 
/* 116 */       logBuilder.line("[THYMELEAF]     * {}", linkBuilder.getName());
/*     */     } 
/*     */ 
/*     */     
/* 120 */     Set<DialectConfiguration> dialectConfigurations = configuration.getDialectConfigurations();
/*     */     
/* 122 */     int dialectIndex = 1;
/* 123 */     Integer totalDialects = Integer.valueOf(dialectConfigurations.size());
/*     */     
/* 125 */     for (DialectConfiguration dialectConfiguration : dialectConfigurations) {
/*     */       
/* 127 */       IDialect dialect = dialectConfiguration.getDialect();
/*     */       
/* 129 */       if (totalDialects.intValue() > 1) {
/* 130 */         logBuilder.line("[THYMELEAF] * Dialect [{} of {}]: {} ({})", new Object[] { Integer.valueOf(dialectIndex), totalDialects, dialect.getName(), dialect.getClass().getName() });
/*     */       } else {
/* 132 */         logBuilder.line("[THYMELEAF] * Dialect: {} ({})", dialect.getName(), dialect.getClass().getName());
/*     */       } 
/*     */       
/* 135 */       String dialectPrefix = null;
/* 136 */       if (dialect instanceof IProcessorDialect) {
/* 137 */         dialectPrefix = dialectConfiguration.isPrefixSpecified() ? dialectConfiguration.getPrefix() : ((IProcessorDialect)dialect).getPrefix();
/* 138 */         logBuilder.line("[THYMELEAF]     * Prefix: \"{}\"", (dialectPrefix != null) ? dialectPrefix : "(none)");
/*     */       } 
/*     */       
/* 141 */       if (configLogger.isDebugEnabled()) {
/* 142 */         printDebugConfiguration(logBuilder, dialect, dialectPrefix);
/*     */       }
/*     */       
/* 145 */       dialectIndex++;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     logBuilder.end("[THYMELEAF] TEMPLATE ENGINE CONFIGURED OK");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (configLogger.isTraceEnabled()) {
/* 155 */       configLogger.trace(logBuilder.toString());
/* 156 */     } else if (configLogger.isDebugEnabled()) {
/* 157 */       configLogger.debug(logBuilder.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printDebugConfiguration(ConfigLogBuilder logBuilder, IDialect idialect, String dialectPrefix) {
/* 167 */     if (idialect instanceof IProcessorDialect) {
/*     */       
/* 169 */       IProcessorDialect dialect = (IProcessorDialect)idialect;
/*     */       
/* 171 */       Set<IProcessor> processors = dialect.getProcessors(dialectPrefix);
/* 172 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.HTML);
/* 173 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.XML);
/* 174 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.TEXT);
/* 175 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.JAVASCRIPT);
/* 176 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.CSS);
/* 177 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.RAW);
/*     */     } 
/*     */ 
/*     */     
/* 181 */     if (idialect instanceof IPreProcessorDialect) {
/*     */       
/* 183 */       IPreProcessorDialect dialect = (IPreProcessorDialect)idialect;
/*     */       
/* 185 */       Set<IPreProcessor> preProcessors = dialect.getPreProcessors();
/* 186 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.HTML);
/* 187 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.XML);
/* 188 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.TEXT);
/* 189 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.JAVASCRIPT);
/* 190 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.CSS);
/* 191 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.RAW);
/*     */     } 
/*     */ 
/*     */     
/* 195 */     if (idialect instanceof IPostProcessorDialect) {
/*     */       
/* 197 */       IPostProcessorDialect dialect = (IPostProcessorDialect)idialect;
/*     */       
/* 199 */       Set<IPostProcessor> postProcessors = dialect.getPostProcessors();
/* 200 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.HTML);
/* 201 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.XML);
/* 202 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.TEXT);
/* 203 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.JAVASCRIPT);
/* 204 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.CSS);
/* 205 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.RAW);
/*     */     } 
/*     */ 
/*     */     
/* 209 */     if (idialect instanceof IExpressionObjectDialect) {
/*     */       
/* 211 */       IExpressionObjectDialect dialect = (IExpressionObjectDialect)idialect;
/*     */       
/* 213 */       IExpressionObjectFactory expressionObjectFactory = dialect.getExpressionObjectFactory();
/* 214 */       if (expressionObjectFactory != null) {
/*     */         
/* 216 */         Set<String> expressionObjectNames = expressionObjectFactory.getAllExpressionObjectNames();
/* 217 */         if (expressionObjectNames != null && !expressionObjectNames.isEmpty()) {
/* 218 */           logBuilder.line("[THYMELEAF]     * Expression Objects:");
/* 219 */           for (String expressionObjectName : expressionObjectNames) {
/* 220 */             logBuilder.line("[THYMELEAF]         * #{}", new Object[] { expressionObjectName });
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 228 */     if (idialect instanceof IExecutionAttributeDialect) {
/*     */       
/* 230 */       IExecutionAttributeDialect dialect = (IExecutionAttributeDialect)idialect;
/*     */       
/* 232 */       Map<String, Object> executionAttributes = dialect.getExecutionAttributes();
/* 233 */       if (executionAttributes != null && !executionAttributes.isEmpty()) {
/* 234 */         logBuilder.line("[THYMELEAF]     * Execution Attributes:");
/* 235 */         for (Map.Entry<String, Object> executionAttributesEntry : executionAttributes.entrySet()) {
/* 236 */           String attrName = executionAttributesEntry.getKey();
/*     */           
/* 238 */           String attrValue = (executionAttributesEntry.getValue() == null) ? null : executionAttributesEntry.getValue().toString();
/* 239 */           logBuilder.line("[THYMELEAF]         * \"{}\": {}", new Object[] { attrName, attrValue });
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printProcessorsForTemplateMode(ConfigLogBuilder logBuilder, Set<IProcessor> processors, TemplateMode templateMode) {
/* 255 */     if (processors == null || processors.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 259 */     List<ICDATASectionProcessor> cdataSectionProcessors = new ArrayList<>();
/* 260 */     List<ICommentProcessor> commentProcessors = new ArrayList<>();
/* 261 */     List<IDocTypeProcessor> docTypeProcessors = new ArrayList<>();
/* 262 */     List<IElementTagProcessor> elementTagProcessors = new ArrayList<>();
/* 263 */     List<IElementModelProcessor> elementModelProcessors = new ArrayList<>();
/* 264 */     List<IProcessingInstructionProcessor> processingInstructionProcessors = new ArrayList<>();
/* 265 */     List<ITextProcessor> textProcessors = new ArrayList<>();
/* 266 */     List<IXMLDeclarationProcessor> xmlDeclarationProcessors = new ArrayList<>();
/*     */     
/* 268 */     boolean processorsForTemplateModeExist = false;
/* 269 */     for (IProcessor processor : processors) {
/*     */       
/* 271 */       if (!templateMode.equals(processor.getTemplateMode())) {
/*     */         continue;
/*     */       }
/* 274 */       processorsForTemplateModeExist = true;
/*     */       
/* 276 */       if (processor instanceof ICDATASectionProcessor) {
/* 277 */         cdataSectionProcessors.add((ICDATASectionProcessor)processor); continue;
/* 278 */       }  if (processor instanceof ICommentProcessor) {
/* 279 */         commentProcessors.add((ICommentProcessor)processor); continue;
/* 280 */       }  if (processor instanceof IDocTypeProcessor) {
/* 281 */         docTypeProcessors.add((IDocTypeProcessor)processor); continue;
/* 282 */       }  if (processor instanceof IElementTagProcessor) {
/* 283 */         elementTagProcessors.add((IElementTagProcessor)processor); continue;
/* 284 */       }  if (processor instanceof IElementModelProcessor) {
/* 285 */         elementModelProcessors.add((IElementModelProcessor)processor); continue;
/* 286 */       }  if (processor instanceof IProcessingInstructionProcessor) {
/* 287 */         processingInstructionProcessors.add((IProcessingInstructionProcessor)processor); continue;
/* 288 */       }  if (processor instanceof ITextProcessor) {
/* 289 */         textProcessors.add((ITextProcessor)processor); continue;
/* 290 */       }  if (processor instanceof IXMLDeclarationProcessor) {
/* 291 */         xmlDeclarationProcessors.add((IXMLDeclarationProcessor)processor);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 296 */     if (!processorsForTemplateModeExist) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 301 */     logBuilder.line("[THYMELEAF]     * Processors for Template Mode: {}", templateMode);
/*     */     
/* 303 */     Collections.sort(cdataSectionProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 304 */     Collections.sort(commentProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 305 */     Collections.sort(docTypeProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 306 */     Collections.sort(elementTagProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 307 */     Collections.sort(elementModelProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 308 */     Collections.sort(processingInstructionProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 309 */     Collections.sort(textProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 310 */     Collections.sort(xmlDeclarationProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/*     */     
/* 312 */     if (!elementTagProcessors.isEmpty()) {
/* 313 */       logBuilder.line("[THYMELEAF]         * Element Tag Processors by [matching element and attribute name] [precedence]:");
/* 314 */       for (IElementTagProcessor processor : elementTagProcessors) {
/* 315 */         MatchingElementName matchingElementName = processor.getMatchingElementName();
/* 316 */         MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/* 317 */         String elementName = (matchingElementName == null) ? "*" : matchingElementName.toString();
/* 318 */         String attributeName = (matchingAttributeName == null) ? "*" : matchingAttributeName.toString();
/* 319 */         logBuilder.line("[THYMELEAF]             * [{} {}] [{}]: {}", new Object[] { elementName, attributeName, 
/* 320 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 323 */     if (!elementModelProcessors.isEmpty()) {
/* 324 */       logBuilder.line("[THYMELEAF]         * Element Model Processors by [matching element and attribute name] [precedence]:");
/* 325 */       for (IElementModelProcessor processor : elementModelProcessors) {
/* 326 */         MatchingElementName matchingElementName = processor.getMatchingElementName();
/* 327 */         MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/* 328 */         String elementName = (matchingElementName == null) ? "*" : matchingElementName.toString();
/* 329 */         String attributeName = (matchingAttributeName == null) ? "*" : matchingAttributeName.toString();
/* 330 */         logBuilder.line("[THYMELEAF]             * [{} {}] [{}]: {}", new Object[] { elementName, attributeName, 
/* 331 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 334 */     if (!textProcessors.isEmpty()) {
/* 335 */       logBuilder.line("[THYMELEAF]         * Text Processors by [precedence]:");
/* 336 */       for (ITextProcessor processor : textProcessors) {
/* 337 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 338 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 341 */     if (!docTypeProcessors.isEmpty()) {
/* 342 */       logBuilder.line("[THYMELEAF]         * DOCTYPE Processors by [precedence]:");
/* 343 */       for (IDocTypeProcessor processor : docTypeProcessors) {
/* 344 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 345 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 348 */     if (!cdataSectionProcessors.isEmpty()) {
/* 349 */       logBuilder.line("[THYMELEAF]         * CDATA Section Processors by [precedence]:");
/* 350 */       for (ICDATASectionProcessor processor : cdataSectionProcessors) {
/* 351 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 352 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 355 */     if (!commentProcessors.isEmpty()) {
/* 356 */       logBuilder.line("[THYMELEAF]         * Comment Processors by [precedence]:");
/* 357 */       for (ICommentProcessor processor : commentProcessors) {
/* 358 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 359 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 362 */     if (!xmlDeclarationProcessors.isEmpty()) {
/* 363 */       logBuilder.line("[THYMELEAF]         * XML Declaration Processors by [precedence]:");
/* 364 */       for (IXMLDeclarationProcessor processor : xmlDeclarationProcessors) {
/* 365 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 366 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       } 
/*     */     } 
/* 369 */     if (!processingInstructionProcessors.isEmpty()) {
/* 370 */       logBuilder.line("[THYMELEAF]         * Processing Instruction Processors by [precedence]:");
/* 371 */       for (IProcessingInstructionProcessor processor : processingInstructionProcessors) {
/* 372 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 373 */               Integer.valueOf(processor.getPrecedence()), processor.getClass().getName()
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printPreProcessorsForTemplateMode(ConfigLogBuilder logBuilder, Set<IPreProcessor> preProcessors, TemplateMode templateMode) {
/* 384 */     if (preProcessors == null || preProcessors.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 388 */     List<IPreProcessor> preProcessorsForTemplateMode = new ArrayList<>();
/*     */     
/* 390 */     for (IPreProcessor preProcessor : preProcessors) {
/* 391 */       if (!templateMode.equals(preProcessor.getTemplateMode())) {
/*     */         continue;
/*     */       }
/* 394 */       preProcessorsForTemplateMode.add(preProcessor);
/*     */     } 
/*     */     
/* 397 */     if (preProcessorsForTemplateMode.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 402 */     Collections.sort(preProcessorsForTemplateMode, ProcessorComparators.PRE_PROCESSOR_COMPARATOR);
/*     */     
/* 404 */     logBuilder.line("[THYMELEAF]     * Pre-Processors for Template Mode: {} by [precedence]", templateMode);
/* 405 */     for (IPreProcessor preProcessor : preProcessorsForTemplateMode) {
/* 406 */       logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 407 */             Integer.valueOf(preProcessor.getPrecedence()), preProcessor.getClass().getName()
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printPostProcessorsForTemplateMode(ConfigLogBuilder logBuilder, Set<IPostProcessor> postProcessors, TemplateMode templateMode) {
/* 417 */     if (postProcessors == null || postProcessors.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 421 */     List<IPostProcessor> postProcessorsForTemplateMode = new ArrayList<>();
/*     */     
/* 423 */     for (IPostProcessor postProcessor : postProcessors) {
/* 424 */       if (!templateMode.equals(postProcessor.getTemplateMode())) {
/*     */         continue;
/*     */       }
/* 427 */       postProcessorsForTemplateMode.add(postProcessor);
/*     */     } 
/*     */     
/* 430 */     if (postProcessorsForTemplateMode.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 435 */     Collections.sort(postProcessorsForTemplateMode, ProcessorComparators.POST_PROCESSOR_COMPARATOR);
/*     */     
/* 437 */     logBuilder.line("[THYMELEAF]     * Post-Processors for Template Mode: {} by [precedence]", templateMode);
/* 438 */     for (IPostProcessor postProcessor : postProcessorsForTemplateMode) {
/* 439 */       logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 440 */             Integer.valueOf(postProcessor.getPrecedence()), postProcessor.getClass().getName()
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ConfigLogBuilder
/*     */   {
/*     */     private static final String PLACEHOLDER = "\\{\\}";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 456 */     private final StringBuilder strBuilder = new StringBuilder();
/*     */ 
/*     */     
/*     */     protected void end(String line) {
/* 460 */       this.strBuilder.append(line);
/*     */     }
/*     */     
/*     */     protected void line(String line) {
/* 464 */       this.strBuilder.append(line).append("\n");
/*     */     }
/*     */     
/*     */     protected void line(String line, Object p1) {
/* 468 */       this.strBuilder.append(replace(line, p1)).append("\n");
/*     */     }
/*     */     
/*     */     protected void line(String line, Object p1, Object p2) {
/* 472 */       this.strBuilder.append(replace(replace(line, p1), p2)).append("\n");
/*     */     }
/*     */     
/*     */     protected void line(String line, Object[] pArr) {
/* 476 */       String newLine = line;
/* 477 */       for (Object aPArr : pArr) {
/* 478 */         newLine = replace(newLine, aPArr);
/*     */       }
/* 480 */       this.strBuilder.append(newLine).append("\n");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 485 */       return this.strBuilder.toString();
/*     */     }
/*     */     
/*     */     private String replace(String str, Object replacement) {
/* 489 */       return str.replaceFirst("\\{\\}", (replacement == null) ? "" : param(replacement));
/*     */     }
/*     */     
/*     */     private String param(Object p) {
/* 493 */       if (p == null) {
/* 494 */         return null;
/*     */       }
/* 496 */       return p.toString().replaceAll("\\$", "\\.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\ConfigurationPrinterHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */