/*    */ package org.thymeleaf;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.thymeleaf.util.ClassLoaderUtils;
/*    */ import org.thymeleaf.util.VersionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Thymeleaf
/*    */ {
/*    */   private static final VersionUtils.VersionSpec VERSION_SPEC;
/*    */   
/*    */   static {
/* 45 */     String version = null;
/* 46 */     String buildTimestamp = null;
/*    */     try {
/* 48 */       Properties properties = new Properties();
/* 49 */       properties.load(ClassLoaderUtils.loadResourceAsStream("org/thymeleaf/thymeleaf.properties"));
/* 50 */       version = properties.getProperty("version");
/* 51 */       buildTimestamp = properties.getProperty("build.date");
/* 52 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */     
/* 56 */     VERSION_SPEC = VersionUtils.parseVersion(version, buildTimestamp);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getVersion() {
/* 67 */     return VERSION_SPEC.getVersion();
/*    */   }
/*    */   
/*    */   public static String getBuildTimestamp() {
/* 71 */     return VERSION_SPEC.getBuildTimestamp();
/*    */   }
/*    */   
/*    */   public static int getVersionMajor() {
/* 75 */     return VERSION_SPEC.getMajor();
/*    */   }
/*    */   
/*    */   public static int getVersionMinor() {
/* 79 */     return VERSION_SPEC.getMinor();
/*    */   }
/*    */   
/*    */   public static int getVersionPatch() {
/* 83 */     return VERSION_SPEC.getPatch();
/*    */   }
/*    */   
/*    */   public static String getVersionQualifier() {
/* 87 */     return VERSION_SPEC.getQualifier();
/*    */   }
/*    */   
/*    */   public static boolean isVersionStableRelease() {
/* 91 */     return VERSION_SPEC.isStableRelease();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\Thymeleaf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */