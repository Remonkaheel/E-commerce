package org.thymeleaf.postprocessor;

import org.thymeleaf.engine.ITemplateHandler;
import org.thymeleaf.templatemode.TemplateMode;

public interface IPostProcessor {
  TemplateMode getTemplateMode();
  
  int getPrecedence();
  
  Class<? extends ITemplateHandler> getHandlerClass();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\postprocessor\IPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */