package org.thymeleaf.model;

public interface IStandaloneElementTag extends IProcessableElementTag {
  boolean isMinimized();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IStandaloneElementTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */