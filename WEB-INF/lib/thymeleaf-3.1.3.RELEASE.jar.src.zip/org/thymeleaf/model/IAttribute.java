package org.thymeleaf.model;

import java.io.IOException;
import java.io.Writer;
import org.thymeleaf.engine.AttributeDefinition;

public interface IAttribute {
  String getAttributeCompleteName();
  
  AttributeDefinition getAttributeDefinition();
  
  String getOperator();
  
  String getValue();
  
  AttributeValueQuotes getValueQuotes();
  
  boolean hasLocation();
  
  String getTemplateName();
  
  int getLine();
  
  int getCol();
  
  void write(Writer paramWriter) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */