package org.thymeleaf.model;

public interface IComment extends ITemplateEvent, CharSequence {
  String getComment();
  
  String getContent();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IComment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */