package org.thymeleaf.model;

public interface IModelVisitor {
  void visit(ITemplateStart paramITemplateStart);
  
  void visit(ITemplateEnd paramITemplateEnd);
  
  void visit(IXMLDeclaration paramIXMLDeclaration);
  
  void visit(IDocType paramIDocType);
  
  void visit(ICDATASection paramICDATASection);
  
  void visit(IComment paramIComment);
  
  void visit(IText paramIText);
  
  void visit(IStandaloneElementTag paramIStandaloneElementTag);
  
  void visit(IOpenElementTag paramIOpenElementTag);
  
  void visit(ICloseElementTag paramICloseElementTag);
  
  void visit(IProcessingInstruction paramIProcessingInstruction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IModelVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */