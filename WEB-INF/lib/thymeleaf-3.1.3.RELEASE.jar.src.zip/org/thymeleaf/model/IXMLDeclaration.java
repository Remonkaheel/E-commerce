package org.thymeleaf.model;

public interface IXMLDeclaration extends ITemplateEvent {
  String getKeyword();
  
  String getVersion();
  
  String getEncoding();
  
  String getStandalone();
  
  String getXmlDeclaration();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IXMLDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */