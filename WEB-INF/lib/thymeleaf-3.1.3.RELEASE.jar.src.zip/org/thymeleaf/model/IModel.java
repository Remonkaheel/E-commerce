package org.thymeleaf.model;

import java.io.IOException;
import java.io.Writer;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.templatemode.TemplateMode;

public interface IModel {
  IEngineConfiguration getConfiguration();
  
  TemplateMode getTemplateMode();
  
  int size();
  
  ITemplateEvent get(int paramInt);
  
  void add(ITemplateEvent paramITemplateEvent);
  
  void insert(int paramInt, ITemplateEvent paramITemplateEvent);
  
  void replace(int paramInt, ITemplateEvent paramITemplateEvent);
  
  void addModel(IModel paramIModel);
  
  void insertModel(int paramInt, IModel paramIModel);
  
  void remove(int paramInt);
  
  void reset();
  
  IModel cloneModel();
  
  void accept(IModelVisitor paramIModelVisitor);
  
  void write(Writer paramWriter) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */