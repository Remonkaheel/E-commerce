package org.thymeleaf.model;

public interface IProcessingInstruction extends ITemplateEvent {
  String getTarget();
  
  String getContent();
  
  String getProcessingInstruction();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IProcessingInstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */