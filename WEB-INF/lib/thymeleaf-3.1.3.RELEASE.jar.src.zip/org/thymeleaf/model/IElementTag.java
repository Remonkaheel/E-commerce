package org.thymeleaf.model;

import org.thymeleaf.engine.ElementDefinition;
import org.thymeleaf.templatemode.TemplateMode;

public interface IElementTag extends ITemplateEvent {
  TemplateMode getTemplateMode();
  
  String getElementCompleteName();
  
  ElementDefinition getElementDefinition();
  
  boolean isSynthetic();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IElementTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */