package org.thymeleaf.model;

public interface IDocType extends ITemplateEvent {
  String getKeyword();
  
  String getElementName();
  
  String getType();
  
  String getPublicId();
  
  String getSystemId();
  
  String getInternalSubset();
  
  String getDocType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IDocType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */