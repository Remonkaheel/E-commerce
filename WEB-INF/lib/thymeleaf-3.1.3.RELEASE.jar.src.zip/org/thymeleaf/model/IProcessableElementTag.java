package org.thymeleaf.model;

import java.util.Map;
import org.thymeleaf.engine.AttributeName;

public interface IProcessableElementTag extends IElementTag {
  IAttribute[] getAllAttributes();
  
  Map<String, String> getAttributeMap();
  
  boolean hasAttribute(String paramString);
  
  boolean hasAttribute(String paramString1, String paramString2);
  
  boolean hasAttribute(AttributeName paramAttributeName);
  
  IAttribute getAttribute(String paramString);
  
  IAttribute getAttribute(String paramString1, String paramString2);
  
  IAttribute getAttribute(AttributeName paramAttributeName);
  
  String getAttributeValue(String paramString);
  
  String getAttributeValue(String paramString1, String paramString2);
  
  String getAttributeValue(AttributeName paramAttributeName);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IProcessableElementTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */