package org.thymeleaf.model;

import java.util.Map;
import org.thymeleaf.engine.AttributeName;
import org.thymeleaf.engine.TemplateData;

public interface IModelFactory {
  IModel createModel();
  
  IModel createModel(ITemplateEvent paramITemplateEvent);
  
  IModel parse(TemplateData paramTemplateData, String paramString);
  
  ICDATASection createCDATASection(CharSequence paramCharSequence);
  
  IComment createComment(CharSequence paramCharSequence);
  
  IDocType createHTML5DocType();
  
  IDocType createDocType(String paramString1, String paramString2);
  
  IDocType createDocType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
  
  IProcessingInstruction createProcessingInstruction(String paramString1, String paramString2);
  
  IText createText(CharSequence paramCharSequence);
  
  IXMLDeclaration createXMLDeclaration(String paramString1, String paramString2, String paramString3);
  
  IStandaloneElementTag createStandaloneElementTag(String paramString);
  
  IStandaloneElementTag createStandaloneElementTag(String paramString1, String paramString2, String paramString3);
  
  IStandaloneElementTag createStandaloneElementTag(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  IStandaloneElementTag createStandaloneElementTag(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2);
  
  IStandaloneElementTag createStandaloneElementTag(String paramString, Map<String, String> paramMap, AttributeValueQuotes paramAttributeValueQuotes, boolean paramBoolean1, boolean paramBoolean2);
  
  IOpenElementTag createOpenElementTag(String paramString);
  
  IOpenElementTag createOpenElementTag(String paramString1, String paramString2, String paramString3);
  
  IOpenElementTag createOpenElementTag(String paramString, boolean paramBoolean);
  
  IOpenElementTag createOpenElementTag(String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  IOpenElementTag createOpenElementTag(String paramString, Map<String, String> paramMap, AttributeValueQuotes paramAttributeValueQuotes, boolean paramBoolean);
  
  ICloseElementTag createCloseElementTag(String paramString);
  
  ICloseElementTag createCloseElementTag(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  <T extends IProcessableElementTag> T setAttribute(T paramT, String paramString1, String paramString2);
  
  <T extends IProcessableElementTag> T setAttribute(T paramT, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  <T extends IProcessableElementTag> T replaceAttribute(T paramT, AttributeName paramAttributeName, String paramString1, String paramString2);
  
  <T extends IProcessableElementTag> T replaceAttribute(T paramT, AttributeName paramAttributeName, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  <T extends IProcessableElementTag> T removeAttribute(T paramT, String paramString);
  
  <T extends IProcessableElementTag> T removeAttribute(T paramT, String paramString1, String paramString2);
  
  <T extends IProcessableElementTag> T removeAttribute(T paramT, AttributeName paramAttributeName);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\model\IModelFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */