/*     */ package org.thymeleaf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.dialect.IDialect;
/*     */ import org.thymeleaf.dialect.IExecutionAttributeDialect;
/*     */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*     */ import org.thymeleaf.dialect.IPostProcessorDialect;
/*     */ import org.thymeleaf.dialect.IPreProcessorDialect;
/*     */ import org.thymeleaf.dialect.IProcessorDialect;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.ElementDefinitions;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.engine.IElementDefinitionsAware;
/*     */ import org.thymeleaf.engine.ITemplateHandler;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.preprocessor.IPreProcessor;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
/*     */ import org.thymeleaf.processor.comment.ICommentProcessor;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeProcessor;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
/*     */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesProcessor;
/*     */ import org.thymeleaf.processor.text.ITextProcessor;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ import org.thymeleaf.util.ProcessorConfigurationUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DialectSetConfiguration
/*     */ {
/*     */   private final Set<DialectConfiguration> dialectConfigurations;
/*     */   private final Set<IDialect> dialects;
/*     */   private final boolean standardDialectPresent;
/*     */   private final String standardDialectPrefix;
/*     */   private final Map<String, Object> executionAttributes;
/*     */   private final AggregateExpressionObjectFactory expressionObjectFactory;
/*     */   private final ElementDefinitions elementDefinitions;
/*     */   private final AttributeDefinitions attributeDefinitions;
/*     */   private final EnumMap<TemplateMode, Set<ITemplateBoundariesProcessor>> templateBoundariesProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<ICDATASectionProcessor>> cdataSectionProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<ICommentProcessor>> commentProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<IDocTypeProcessor>> docTypeProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<IProcessingInstructionProcessor>> processingInstructionProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<ITextProcessor>> textProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<IXMLDeclarationProcessor>> xmlDeclarationProcessorsByTemplateMode;
/*     */   private final EnumMap<TemplateMode, Set<IPreProcessor>> preProcessors;
/*     */   private final EnumMap<TemplateMode, Set<IPostProcessor>> postProcessors;
/*     */   
/*     */   public static DialectSetConfiguration build(Set<DialectConfiguration> dialectConfigurations) {
/*  99 */     Validate.notNull(dialectConfigurations, "Dialect configuration set cannot be null");
/*     */ 
/*     */     
/* 102 */     Set<IDialect> dialects = new LinkedHashSet<>(dialectConfigurations.size());
/*     */ 
/*     */     
/* 105 */     boolean standardDialectPresent = false;
/* 106 */     String standardDialectPrefix = null;
/*     */ 
/*     */     
/* 109 */     Map<String, Object> executionAttributes = new LinkedHashMap<>(10, 1.0F);
/*     */ 
/*     */     
/* 112 */     AggregateExpressionObjectFactory aggregateExpressionObjectFactory = new AggregateExpressionObjectFactory();
/*     */ 
/*     */     
/* 115 */     EnumMap<TemplateMode, List<ITemplateBoundariesProcessor>> templateBoundariesProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 116 */     EnumMap<TemplateMode, List<ICDATASectionProcessor>> cdataSectionProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 117 */     EnumMap<TemplateMode, List<ICommentProcessor>> commentProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 118 */     EnumMap<TemplateMode, List<IDocTypeProcessor>> docTypeProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 119 */     EnumMap<TemplateMode, List<IElementProcessor>> elementProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 120 */     EnumMap<TemplateMode, List<IProcessingInstructionProcessor>> processingInstructionProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 121 */     EnumMap<TemplateMode, List<ITextProcessor>> textProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 122 */     EnumMap<TemplateMode, List<IXMLDeclarationProcessor>> xmlDeclarationProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/*     */ 
/*     */     
/* 125 */     EnumMap<TemplateMode, List<IPreProcessor>> preProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/* 126 */     EnumMap<TemplateMode, List<IPostProcessor>> postProcessorListsByTemplateMode = new EnumMap<>(TemplateMode.class);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     for (DialectConfiguration dialectConfiguration : dialectConfigurations) {
/*     */       
/* 133 */       IDialect dialect = dialectConfiguration.getDialect();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 139 */       if (dialect instanceof IProcessorDialect) {
/*     */         
/* 141 */         IProcessorDialect processorDialect = (IProcessorDialect)dialect;
/*     */ 
/*     */ 
/*     */         
/* 145 */         String dialectPrefix = dialectConfiguration.isPrefixSpecified() ? dialectConfiguration.getPrefix() : processorDialect.getPrefix();
/*     */         
/* 147 */         if (dialect instanceof org.thymeleaf.standard.StandardDialect) {
/* 148 */           standardDialectPresent = true;
/* 149 */           standardDialectPrefix = dialectPrefix;
/*     */         } 
/*     */         
/* 152 */         Set<IProcessor> dialectProcessors = processorDialect.getProcessors(dialectPrefix);
/* 153 */         if (dialectProcessors == null) {
/* 154 */           throw new ConfigurationException("Dialect should not return null processor set: " + dialect.getClass().getName());
/*     */         }
/*     */         
/* 157 */         for (IProcessor dialectProcessor : dialectProcessors) {
/*     */           
/* 159 */           if (dialectProcessor == null) {
/* 160 */             throw new ConfigurationException("Dialect should not return null processor in processor set: " + dialect.getClass().getName());
/*     */           }
/*     */ 
/*     */           
/* 164 */           TemplateMode templateMode = dialectProcessor.getTemplateMode();
/* 165 */           if (templateMode == null) {
/* 166 */             throw new ConfigurationException("Template mode cannot be null (processor: " + dialectProcessor.getClass().getName() + ")");
/*     */           }
/*     */           
/* 169 */           if (dialectProcessor instanceof IElementProcessor) {
/*     */             
/* 171 */             List<IElementProcessor> processorsForTemplateMode = elementProcessorListsByTemplateMode.get(templateMode);
/* 172 */             if (processorsForTemplateMode == null) {
/* 173 */               processorsForTemplateMode = new ArrayList<>(5);
/* 174 */               elementProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 176 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((IElementProcessor)dialectProcessor, processorDialect));
/* 177 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR);
/*     */             continue;
/*     */           } 
/* 180 */           if (dialectProcessor instanceof ITemplateBoundariesProcessor) {
/*     */             
/* 182 */             List<ITemplateBoundariesProcessor> processorsForTemplateMode = templateBoundariesProcessorListsByTemplateMode.get(templateMode);
/* 183 */             if (processorsForTemplateMode == null) {
/* 184 */               processorsForTemplateMode = new ArrayList<>(5);
/* 185 */               templateBoundariesProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 187 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((ITemplateBoundariesProcessor)dialectProcessor, processorDialect));
/* 188 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR); continue;
/*     */           } 
/* 190 */           if (dialectProcessor instanceof ICDATASectionProcessor) {
/*     */             
/* 192 */             List<ICDATASectionProcessor> processorsForTemplateMode = cdataSectionProcessorListsByTemplateMode.get(templateMode);
/* 193 */             if (processorsForTemplateMode == null) {
/* 194 */               processorsForTemplateMode = new ArrayList<>(5);
/* 195 */               cdataSectionProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 197 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((ICDATASectionProcessor)dialectProcessor, processorDialect));
/* 198 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR); continue;
/*     */           } 
/* 200 */           if (dialectProcessor instanceof ICommentProcessor) {
/*     */             
/* 202 */             List<ICommentProcessor> processorsForTemplateMode = commentProcessorListsByTemplateMode.get(templateMode);
/* 203 */             if (processorsForTemplateMode == null) {
/* 204 */               processorsForTemplateMode = new ArrayList<>(5);
/* 205 */               commentProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 207 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((ICommentProcessor)dialectProcessor, processorDialect));
/* 208 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR); continue;
/*     */           } 
/* 210 */           if (dialectProcessor instanceof IDocTypeProcessor) {
/*     */             
/* 212 */             List<IDocTypeProcessor> processorsForTemplateMode = docTypeProcessorListsByTemplateMode.get(templateMode);
/* 213 */             if (processorsForTemplateMode == null) {
/* 214 */               processorsForTemplateMode = new ArrayList<>(5);
/* 215 */               docTypeProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 217 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((IDocTypeProcessor)dialectProcessor, processorDialect));
/* 218 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR); continue;
/*     */           } 
/* 220 */           if (dialectProcessor instanceof IProcessingInstructionProcessor) {
/*     */             
/* 222 */             List<IProcessingInstructionProcessor> processorsForTemplateMode = processingInstructionProcessorListsByTemplateMode.get(templateMode);
/* 223 */             if (processorsForTemplateMode == null) {
/* 224 */               processorsForTemplateMode = new ArrayList<>(5);
/* 225 */               processingInstructionProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 227 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((IProcessingInstructionProcessor)dialectProcessor, processorDialect));
/* 228 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR); continue;
/*     */           } 
/* 230 */           if (dialectProcessor instanceof ITextProcessor) {
/*     */             
/* 232 */             List<ITextProcessor> processorsForTemplateMode = textProcessorListsByTemplateMode.get(templateMode);
/* 233 */             if (processorsForTemplateMode == null) {
/* 234 */               processorsForTemplateMode = new ArrayList<>(5);
/* 235 */               textProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 237 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((ITextProcessor)dialectProcessor, processorDialect));
/* 238 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR); continue;
/*     */           } 
/* 240 */           if (dialectProcessor instanceof IXMLDeclarationProcessor) {
/*     */             
/* 242 */             List<IXMLDeclarationProcessor> processorsForTemplateMode = xmlDeclarationProcessorListsByTemplateMode.get(templateMode);
/* 243 */             if (processorsForTemplateMode == null) {
/* 244 */               processorsForTemplateMode = new ArrayList<>(5);
/* 245 */               xmlDeclarationProcessorListsByTemplateMode.put(templateMode, processorsForTemplateMode);
/*     */             } 
/* 247 */             processorsForTemplateMode.add(ProcessorConfigurationUtils.wrap((IXMLDeclarationProcessor)dialectProcessor, processorDialect));
/* 248 */             Collections.sort(processorsForTemplateMode, ProcessorComparators.PROCESSOR_COMPARATOR);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 261 */       if (dialect instanceof IExecutionAttributeDialect) {
/*     */         
/* 263 */         Map<String, Object> dialectExecutionAttributes = ((IExecutionAttributeDialect)dialect).getExecutionAttributes();
/* 264 */         if (dialectExecutionAttributes != null) {
/* 265 */           for (Map.Entry<String, Object> entry : dialectExecutionAttributes.entrySet()) {
/* 266 */             String executionAttributeName = entry.getKey();
/* 267 */             if (executionAttributes.containsKey(executionAttributeName)) {
/* 268 */               throw new ConfigurationException("Conflicting execution attribute. Two or more dialects specify an execution attribute with the same name \"" + executionAttributeName + "\".");
/*     */             }
/*     */ 
/*     */             
/* 272 */             executionAttributes.put(entry.getKey(), entry.getValue());
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 282 */       if (dialect instanceof IExpressionObjectDialect) {
/*     */         
/* 284 */         IExpressionObjectFactory factory = ((IExpressionObjectDialect)dialect).getExpressionObjectFactory();
/* 285 */         if (factory != null) {
/* 286 */           aggregateExpressionObjectFactory.add(factory);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 295 */       if (dialect instanceof IPreProcessorDialect) {
/*     */         
/* 297 */         Set<IPreProcessor> dialectPreProcessors = ((IPreProcessorDialect)dialect).getPreProcessors();
/* 298 */         if (dialectPreProcessors != null)
/*     */         {
/* 300 */           for (IPreProcessor preProcessor : dialectPreProcessors) {
/*     */             
/* 302 */             if (preProcessor == null) {
/* 303 */               throw new ConfigurationException("Pre-Processor list for dialect " + dialect
/* 304 */                   .getClass().getName() + " includes a null entry, which is forbidden.");
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 309 */             TemplateMode templateMode = preProcessor.getTemplateMode();
/* 310 */             if (templateMode == null) {
/* 311 */               throw new ConfigurationException("Template mode cannot be null (pre-processor: " + preProcessor
/* 312 */                   .getClass().getName() + ", dialect" + dialect
/* 313 */                   .getClass().getName() + ")");
/*     */             }
/*     */ 
/*     */             
/* 317 */             Class<?> handlerClass = preProcessor.getHandlerClass();
/* 318 */             if (handlerClass == null) {
/* 319 */               throw new ConfigurationException("Pre-Processor " + preProcessor
/* 320 */                   .getClass().getName() + " for dialect " + preProcessor
/* 321 */                   .getClass().getName() + " returns a null handler class, which is forbidden.");
/*     */             }
/* 323 */             if (!ITemplateHandler.class.isAssignableFrom(handlerClass)) {
/* 324 */               throw new ConfigurationException("Handler class " + handlerClass
/* 325 */                   .getName() + " specified for pre-processor " + preProcessor
/* 326 */                   .getClass().getName() + " in dialect " + dialect
/* 327 */                   .getClass().getName() + " does not implement required interface " + ITemplateHandler.class
/* 328 */                   .getName());
/*     */             }
/*     */             
/*     */             try {
/* 332 */               handlerClass.getConstructor(new Class[0]);
/* 333 */             } catch (NoSuchMethodException e) {
/* 334 */               throw new ConfigurationException("Pre-Processor class " + handlerClass
/* 335 */                   .getName() + " specified for pre-processor " + preProcessor
/* 336 */                   .getClass().getName() + " in dialect " + dialect
/* 337 */                   .getClass().getName() + " does not implement required zero-argument constructor.", e);
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 342 */             List<IPreProcessor> preProcessorsForTemplateMode = preProcessorListsByTemplateMode.get(templateMode);
/* 343 */             if (preProcessorsForTemplateMode == null) {
/* 344 */               preProcessorsForTemplateMode = new ArrayList<>(5);
/* 345 */               preProcessorListsByTemplateMode.put(templateMode, preProcessorsForTemplateMode);
/*     */             } 
/* 347 */             preProcessorsForTemplateMode.add(preProcessor);
/* 348 */             Collections.sort(preProcessorsForTemplateMode, ProcessorComparators.PRE_PROCESSOR_COMPARATOR);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 360 */       if (dialect instanceof IPostProcessorDialect) {
/*     */         
/* 362 */         Set<IPostProcessor> dialectPostProcessors = ((IPostProcessorDialect)dialect).getPostProcessors();
/* 363 */         if (dialectPostProcessors != null)
/*     */         {
/* 365 */           for (IPostProcessor postProcessor : dialectPostProcessors) {
/*     */             
/* 367 */             if (postProcessor == null) {
/* 368 */               throw new ConfigurationException("Post-Processor list for dialect " + dialect
/* 369 */                   .getClass().getName() + " includes a null entry, which is forbidden.");
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 374 */             TemplateMode templateMode = postProcessor.getTemplateMode();
/* 375 */             if (templateMode == null) {
/* 376 */               throw new ConfigurationException("Template mode cannot be null (post-processor: " + postProcessor
/* 377 */                   .getClass().getName() + ", dialect" + dialect
/* 378 */                   .getClass().getName() + ")");
/*     */             }
/*     */ 
/*     */             
/* 382 */             Class<?> handlerClass = postProcessor.getHandlerClass();
/* 383 */             if (handlerClass == null) {
/* 384 */               throw new ConfigurationException("Post-Processor " + postProcessor
/* 385 */                   .getClass().getName() + " for dialect " + postProcessor
/* 386 */                   .getClass().getName() + " returns a null handler class, which is forbidden.");
/*     */             }
/* 388 */             if (!ITemplateHandler.class.isAssignableFrom(handlerClass)) {
/* 389 */               throw new ConfigurationException("Handler class " + handlerClass
/* 390 */                   .getName() + " specified for post-processor " + postProcessor
/* 391 */                   .getClass().getName() + " in dialect " + dialect
/* 392 */                   .getClass().getName() + " does not implement required interface " + ITemplateHandler.class
/* 393 */                   .getName());
/*     */             }
/*     */             
/*     */             try {
/* 397 */               handlerClass.getConstructor(new Class[0]);
/* 398 */             } catch (NoSuchMethodException e) {
/* 399 */               throw new ConfigurationException("Post-Processor class " + handlerClass
/* 400 */                   .getName() + " specified for post-processor " + postProcessor
/* 401 */                   .getClass().getName() + " in dialect " + dialect
/* 402 */                   .getClass().getName() + " does not implement required zero-argument constructor.", e);
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 407 */             List<IPostProcessor> postProcessorsForTemplateMode = postProcessorListsByTemplateMode.get(templateMode);
/* 408 */             if (postProcessorsForTemplateMode == null) {
/* 409 */               postProcessorsForTemplateMode = new ArrayList<>(5);
/* 410 */               postProcessorListsByTemplateMode.put(templateMode, postProcessorsForTemplateMode);
/*     */             } 
/* 412 */             postProcessorsForTemplateMode.add(postProcessor);
/* 413 */             Collections.sort(postProcessorsForTemplateMode, ProcessorComparators.POST_PROCESSOR_COMPARATOR);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 425 */       dialects.add(dialect);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     EnumMap<TemplateMode, Set<ITemplateBoundariesProcessor>> templateBoundariesProcessorsByTemplateMode = listMapToSetMap(templateBoundariesProcessorListsByTemplateMode);
/* 433 */     EnumMap<TemplateMode, Set<ICDATASectionProcessor>> cdataSectionProcessorsByTemplateMode = listMapToSetMap(cdataSectionProcessorListsByTemplateMode);
/* 434 */     EnumMap<TemplateMode, Set<ICommentProcessor>> commentProcessorsByTemplateMode = listMapToSetMap(commentProcessorListsByTemplateMode);
/* 435 */     EnumMap<TemplateMode, Set<IDocTypeProcessor>> docTypeProcessorsByTemplateMode = listMapToSetMap(docTypeProcessorListsByTemplateMode);
/* 436 */     EnumMap<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode = listMapToSetMap(elementProcessorListsByTemplateMode);
/* 437 */     EnumMap<TemplateMode, Set<IProcessingInstructionProcessor>> processingInstructionProcessorsByTemplateMode = listMapToSetMap(processingInstructionProcessorListsByTemplateMode);
/* 438 */     EnumMap<TemplateMode, Set<ITextProcessor>> textProcessorsByTemplateMode = listMapToSetMap(textProcessorListsByTemplateMode);
/* 439 */     EnumMap<TemplateMode, Set<IXMLDeclarationProcessor>> xmlDeclarationProcessorsByTemplateMode = listMapToSetMap(xmlDeclarationProcessorListsByTemplateMode);
/* 440 */     EnumMap<TemplateMode, Set<IPreProcessor>> preProcessorsByTemplateMode = listMapToSetMap(preProcessorListsByTemplateMode);
/* 441 */     EnumMap<TemplateMode, Set<IPostProcessor>> postProcessorsByTemplateMode = listMapToSetMap(postProcessorListsByTemplateMode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 447 */     ElementDefinitions elementDefinitions = new ElementDefinitions(elementProcessorsByTemplateMode);
/* 448 */     AttributeDefinitions attributeDefinitions = new AttributeDefinitions(elementProcessorsByTemplateMode);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 453 */     initializeDefinitionsForProcessors((EnumMap)templateBoundariesProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 454 */     initializeDefinitionsForProcessors((EnumMap)cdataSectionProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 455 */     initializeDefinitionsForProcessors((EnumMap)commentProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 456 */     initializeDefinitionsForProcessors((EnumMap)docTypeProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 457 */     initializeDefinitionsForProcessors((EnumMap)elementProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 458 */     initializeDefinitionsForProcessors((EnumMap)processingInstructionProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 459 */     initializeDefinitionsForProcessors((EnumMap)textProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 460 */     initializeDefinitionsForProcessors((EnumMap)xmlDeclarationProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 461 */     initializeDefinitionsForPreProcessors(preProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/* 462 */     initializeDefinitionsForPostProcessors(postProcessorsByTemplateMode, elementDefinitions, attributeDefinitions);
/*     */ 
/*     */     
/* 465 */     return new DialectSetConfiguration(new LinkedHashSet<>(dialectConfigurations), dialects, standardDialectPresent, standardDialectPrefix, executionAttributes, aggregateExpressionObjectFactory, elementDefinitions, attributeDefinitions, templateBoundariesProcessorsByTemplateMode, cdataSectionProcessorsByTemplateMode, commentProcessorsByTemplateMode, docTypeProcessorsByTemplateMode, elementProcessorsByTemplateMode, processingInstructionProcessorsByTemplateMode, textProcessorsByTemplateMode, xmlDeclarationProcessorsByTemplateMode, preProcessorsByTemplateMode, postProcessorsByTemplateMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> EnumMap<TemplateMode, Set<T>> listMapToSetMap(EnumMap<TemplateMode, List<T>> map) {
/* 481 */     EnumMap<TemplateMode, Set<T>> newMap = new EnumMap<>(TemplateMode.class);
/* 482 */     for (Map.Entry<TemplateMode, List<T>> entry : map.entrySet()) {
/* 483 */       newMap.put(entry.getKey(), new LinkedHashSet<>(entry.getValue()));
/*     */     }
/* 485 */     return newMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initializeDefinitionsForProcessors(EnumMap<TemplateMode, ? extends Set<? extends IProcessor>> processorsByTemplateMode, ElementDefinitions elementDefinitions, AttributeDefinitions attributeDefinitions) {
/* 495 */     for (Map.Entry<TemplateMode, ? extends Set<? extends IProcessor>> entry : processorsByTemplateMode.entrySet()) {
/* 496 */       Set<? extends IProcessor> processors = entry.getValue();
/* 497 */       for (IProcessor processor : processors) {
/* 498 */         if (processor instanceof IElementDefinitionsAware) {
/* 499 */           ((IElementDefinitionsAware)processor).setElementDefinitions(elementDefinitions);
/*     */         }
/* 501 */         if (processor instanceof IAttributeDefinitionsAware) {
/* 502 */           ((IAttributeDefinitionsAware)processor).setAttributeDefinitions(attributeDefinitions);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initializeDefinitionsForPreProcessors(EnumMap<TemplateMode, ? extends Set<IPreProcessor>> preProcessorsByTemplateMode, ElementDefinitions elementDefinitions, AttributeDefinitions attributeDefinitions) {
/* 514 */     for (Map.Entry<TemplateMode, ? extends Set<IPreProcessor>> entry : preProcessorsByTemplateMode.entrySet()) {
/* 515 */       Set<IPreProcessor> preProcessors = entry.getValue();
/* 516 */       for (IPreProcessor preProcessor : preProcessors) {
/* 517 */         if (preProcessor instanceof IElementDefinitionsAware) {
/* 518 */           ((IElementDefinitionsAware)preProcessor).setElementDefinitions(elementDefinitions);
/*     */         }
/* 520 */         if (preProcessor instanceof IAttributeDefinitionsAware) {
/* 521 */           ((IAttributeDefinitionsAware)preProcessor).setAttributeDefinitions(attributeDefinitions);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initializeDefinitionsForPostProcessors(EnumMap<TemplateMode, ? extends Set<IPostProcessor>> postProcessorsByTemplateMode, ElementDefinitions elementDefinitions, AttributeDefinitions attributeDefinitions) {
/* 533 */     for (Map.Entry<TemplateMode, ? extends Set<IPostProcessor>> entry : postProcessorsByTemplateMode.entrySet()) {
/* 534 */       Set<IPostProcessor> postProcessors = entry.getValue();
/* 535 */       for (IPostProcessor postProcessor : postProcessors) {
/* 536 */         if (postProcessor instanceof IElementDefinitionsAware) {
/* 537 */           ((IElementDefinitionsAware)postProcessor).setElementDefinitions(elementDefinitions);
/*     */         }
/* 539 */         if (postProcessor instanceof IAttributeDefinitionsAware) {
/* 540 */           ((IAttributeDefinitionsAware)postProcessor).setAttributeDefinitions(attributeDefinitions);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DialectSetConfiguration(Set<DialectConfiguration> dialectConfigurations, Set<IDialect> dialects, boolean standardDialectPresent, String standardDialectPrefix, Map<String, Object> executionAttributes, AggregateExpressionObjectFactory expressionObjectFactory, ElementDefinitions elementDefinitions, AttributeDefinitions attributeDefinitions, EnumMap<TemplateMode, Set<ITemplateBoundariesProcessor>> templateBoundariesProcessorsByTemplateMode, EnumMap<TemplateMode, Set<ICDATASectionProcessor>> cdataSectionProcessorsByTemplateMode, EnumMap<TemplateMode, Set<ICommentProcessor>> commentProcessorsByTemplateMode, EnumMap<TemplateMode, Set<IDocTypeProcessor>> docTypeProcessorsByTemplateMode, EnumMap<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode, EnumMap<TemplateMode, Set<IProcessingInstructionProcessor>> processingInstructionProcessorsByTemplateMode, EnumMap<TemplateMode, Set<ITextProcessor>> textProcessorsByTemplateMode, EnumMap<TemplateMode, Set<IXMLDeclarationProcessor>> xmlDeclarationProcessorsByTemplateMode, EnumMap<TemplateMode, Set<IPreProcessor>> preProcessors, EnumMap<TemplateMode, Set<IPostProcessor>> postProcessors) {
/* 571 */     this.dialectConfigurations = Collections.unmodifiableSet(dialectConfigurations);
/* 572 */     this.dialects = Collections.unmodifiableSet(dialects);
/* 573 */     this.standardDialectPresent = standardDialectPresent;
/* 574 */     this.standardDialectPrefix = standardDialectPrefix;
/* 575 */     this.executionAttributes = Collections.unmodifiableMap(executionAttributes);
/* 576 */     this.expressionObjectFactory = expressionObjectFactory;
/* 577 */     this.elementDefinitions = elementDefinitions;
/* 578 */     this.attributeDefinitions = attributeDefinitions;
/* 579 */     this.templateBoundariesProcessorsByTemplateMode = templateBoundariesProcessorsByTemplateMode;
/* 580 */     this.cdataSectionProcessorsByTemplateMode = cdataSectionProcessorsByTemplateMode;
/* 581 */     this.commentProcessorsByTemplateMode = commentProcessorsByTemplateMode;
/* 582 */     this.docTypeProcessorsByTemplateMode = docTypeProcessorsByTemplateMode;
/* 583 */     this.elementProcessorsByTemplateMode = elementProcessorsByTemplateMode;
/* 584 */     this.processingInstructionProcessorsByTemplateMode = processingInstructionProcessorsByTemplateMode;
/* 585 */     this.textProcessorsByTemplateMode = textProcessorsByTemplateMode;
/* 586 */     this.xmlDeclarationProcessorsByTemplateMode = xmlDeclarationProcessorsByTemplateMode;
/* 587 */     this.preProcessors = preProcessors;
/* 588 */     this.postProcessors = postProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<DialectConfiguration> getDialectConfigurations() {
/* 595 */     return this.dialectConfigurations;
/*     */   }
/*     */   
/*     */   public Set<IDialect> getDialects() {
/* 599 */     return this.dialects;
/*     */   }
/*     */   
/*     */   public boolean isStandardDialectPresent() {
/* 603 */     return this.standardDialectPresent;
/*     */   }
/*     */   
/*     */   public String getStandardDialectPrefix() {
/* 607 */     return this.standardDialectPrefix;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getExecutionAttributes() {
/* 611 */     return this.executionAttributes;
/*     */   }
/*     */   
/*     */   public Object getExecutionAttribute(String executionAttributeName) {
/* 615 */     return this.executionAttributes.get(executionAttributeName);
/*     */   }
/*     */   
/*     */   public boolean hasExecutionAttribute(String executionAttributeName) {
/* 619 */     return this.executionAttributes.containsKey(executionAttributeName);
/*     */   }
/*     */   
/*     */   public ElementDefinitions getElementDefinitions() {
/* 623 */     return this.elementDefinitions;
/*     */   }
/*     */   
/*     */   public AttributeDefinitions getAttributeDefinitions() {
/* 627 */     return this.attributeDefinitions;
/*     */   }
/*     */   
/*     */   public Set<ITemplateBoundariesProcessor> getTemplateBoundariesProcessors(TemplateMode templateMode) {
/* 631 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 632 */     Set<ITemplateBoundariesProcessor> processors = this.templateBoundariesProcessorsByTemplateMode.get(templateMode);
/* 633 */     if (processors == null) {
/* 634 */       return Collections.EMPTY_SET;
/*     */     }
/* 636 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<ICDATASectionProcessor> getCDATASectionProcessors(TemplateMode templateMode) {
/* 640 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 641 */     Set<ICDATASectionProcessor> processors = this.cdataSectionProcessorsByTemplateMode.get(templateMode);
/* 642 */     if (processors == null) {
/* 643 */       return Collections.EMPTY_SET;
/*     */     }
/* 645 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<ICommentProcessor> getCommentProcessors(TemplateMode templateMode) {
/* 649 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 650 */     Set<ICommentProcessor> processors = this.commentProcessorsByTemplateMode.get(templateMode);
/* 651 */     if (processors == null) {
/* 652 */       return Collections.EMPTY_SET;
/*     */     }
/* 654 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<IDocTypeProcessor> getDocTypeProcessors(TemplateMode templateMode) {
/* 658 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 659 */     Set<IDocTypeProcessor> processors = this.docTypeProcessorsByTemplateMode.get(templateMode);
/* 660 */     if (processors == null) {
/* 661 */       return Collections.EMPTY_SET;
/*     */     }
/* 663 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<IElementProcessor> getElementProcessors(TemplateMode templateMode) {
/* 667 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 668 */     Set<IElementProcessor> processors = this.elementProcessorsByTemplateMode.get(templateMode);
/* 669 */     if (processors == null) {
/* 670 */       return Collections.EMPTY_SET;
/*     */     }
/* 672 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<IProcessingInstructionProcessor> getProcessingInstructionProcessors(TemplateMode templateMode) {
/* 676 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 677 */     Set<IProcessingInstructionProcessor> processors = this.processingInstructionProcessorsByTemplateMode.get(templateMode);
/* 678 */     if (processors == null) {
/* 679 */       return Collections.EMPTY_SET;
/*     */     }
/* 681 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<ITextProcessor> getTextProcessors(TemplateMode templateMode) {
/* 685 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 686 */     Set<ITextProcessor> processors = this.textProcessorsByTemplateMode.get(templateMode);
/* 687 */     if (processors == null) {
/* 688 */       return Collections.EMPTY_SET;
/*     */     }
/* 690 */     return processors;
/*     */   }
/*     */   
/*     */   public Set<IXMLDeclarationProcessor> getXMLDeclarationProcessors(TemplateMode templateMode) {
/* 694 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 695 */     Set<IXMLDeclarationProcessor> processors = this.xmlDeclarationProcessorsByTemplateMode.get(templateMode);
/* 696 */     if (processors == null) {
/* 697 */       return Collections.EMPTY_SET;
/*     */     }
/* 699 */     return processors;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<IPreProcessor> getPreProcessors(TemplateMode templateMode) {
/* 704 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 705 */     Set<IPreProcessor> preProcessors = this.preProcessors.get(templateMode);
/* 706 */     if (preProcessors == null) {
/* 707 */       return Collections.EMPTY_SET;
/*     */     }
/* 709 */     return preProcessors;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<IPostProcessor> getPostProcessors(TemplateMode templateMode) {
/* 714 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 715 */     Set<IPostProcessor> postProcessors = this.postProcessors.get(templateMode);
/* 716 */     if (postProcessors == null) {
/* 717 */       return Collections.EMPTY_SET;
/*     */     }
/* 719 */     return postProcessors;
/*     */   }
/*     */ 
/*     */   
/*     */   public IExpressionObjectFactory getExpressionObjectFactory() {
/* 724 */     return this.expressionObjectFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class AggregateExpressionObjectFactory
/*     */     implements IExpressionObjectFactory
/*     */   {
/* 741 */     private IExpressionObjectFactory firstExpressionObjectFactory = null;
/* 742 */     private List<IExpressionObjectFactory> expressionObjectFactoryList = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void add(IExpressionObjectFactory expressionObjectFactory) {
/* 749 */       if (this.firstExpressionObjectFactory == null && this.expressionObjectFactoryList == null) {
/* 750 */         this.firstExpressionObjectFactory = expressionObjectFactory; return;
/*     */       } 
/* 752 */       if (this.expressionObjectFactoryList == null) {
/* 753 */         this.expressionObjectFactoryList = new ArrayList<>(2);
/* 754 */         this.expressionObjectFactoryList.add(this.firstExpressionObjectFactory);
/* 755 */         this.firstExpressionObjectFactory = null;
/*     */       } 
/* 757 */       this.expressionObjectFactoryList.add(expressionObjectFactory);
/*     */     }
/*     */     
/*     */     public Set<String> getAllExpressionObjectNames() {
/* 761 */       if (this.firstExpressionObjectFactory != null) {
/* 762 */         return this.firstExpressionObjectFactory.getAllExpressionObjectNames();
/*     */       }
/* 764 */       if (this.expressionObjectFactoryList == null) {
/* 765 */         return null;
/*     */       }
/* 767 */       Set<String> expressionObjectNames = new LinkedHashSet<>(30);
/* 768 */       int n = this.expressionObjectFactoryList.size();
/* 769 */       while (n-- != 0) {
/* 770 */         expressionObjectNames.addAll(((IExpressionObjectFactory)this.expressionObjectFactoryList.get(n)).getAllExpressionObjectNames());
/*     */       }
/* 772 */       return expressionObjectNames;
/*     */     }
/*     */     
/*     */     public Object buildObject(IExpressionContext context, String expressionObjectName) {
/* 776 */       if (this.firstExpressionObjectFactory != null) {
/* 777 */         return this.firstExpressionObjectFactory.buildObject(context, expressionObjectName);
/*     */       }
/* 779 */       if (this.expressionObjectFactoryList == null) {
/* 780 */         return null;
/*     */       }
/* 782 */       int n = this.expressionObjectFactoryList.size();
/* 783 */       while (n-- != 0) {
/* 784 */         if (((IExpressionObjectFactory)this.expressionObjectFactoryList.get(n)).getAllExpressionObjectNames().contains(expressionObjectName)) {
/* 785 */           return ((IExpressionObjectFactory)this.expressionObjectFactoryList.get(n)).buildObject(context, expressionObjectName);
/*     */         }
/*     */       } 
/* 788 */       return null;
/*     */     }
/*     */     
/*     */     public boolean isCacheable(String expressionObjectName) {
/* 792 */       if (this.firstExpressionObjectFactory != null) {
/* 793 */         return this.firstExpressionObjectFactory.isCacheable(expressionObjectName);
/*     */       }
/* 795 */       if (this.expressionObjectFactoryList == null) {
/* 796 */         return false;
/*     */       }
/* 798 */       int n = this.expressionObjectFactoryList.size();
/* 799 */       while (n-- != 0) {
/* 800 */         if (((IExpressionObjectFactory)this.expressionObjectFactoryList.get(n)).getAllExpressionObjectNames().contains(expressionObjectName)) {
/* 801 */           return ((IExpressionObjectFactory)this.expressionObjectFactoryList.get(n)).isCacheable(expressionObjectName);
/*     */         }
/*     */       } 
/* 804 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\DialectSetConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */