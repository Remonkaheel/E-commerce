package org.thymeleaf;

import java.io.OutputStream;
import java.io.Writer;
import java.nio.charset.Charset;

public interface IThrottledTemplateProcessor {
  String getProcessorIdentifier();
  
  TemplateSpec getTemplateSpec();
  
  boolean isFinished();
  
  int processAll(Writer paramWriter);
  
  int processAll(OutputStream paramOutputStream, Charset paramCharset);
  
  int process(int paramInt, Writer paramWriter);
  
  int process(int paramInt, OutputStream paramOutputStream, Charset paramCharset);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\IThrottledTemplateProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */