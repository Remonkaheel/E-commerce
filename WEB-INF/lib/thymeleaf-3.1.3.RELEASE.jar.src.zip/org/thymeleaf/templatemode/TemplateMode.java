/*    */ package org.thymeleaf.templatemode;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TemplateMode
/*    */ {
/* 36 */   HTML(true, false, false), XML(false, true, false),
/* 37 */   TEXT(false, false, true), JAVASCRIPT(false, false, true), CSS(false, false, true),
/* 38 */   RAW(false, false, false); private static Logger logger;
/*    */   private final boolean html;
/*    */   
/*    */   static {
/* 42 */     logger = LoggerFactory.getLogger(TemplateMode.class);
/*    */   }
/*    */ 
/*    */   
/*    */   private final boolean xml;
/*    */   private final boolean text;
/*    */   private final boolean caseSensitive;
/*    */   
/*    */   TemplateMode(boolean html, boolean xml, boolean text) {
/* 51 */     this.html = html;
/* 52 */     this.xml = xml;
/* 53 */     this.text = text;
/* 54 */     this.caseSensitive = !this.html;
/*    */   }
/*    */   
/*    */   public boolean isMarkup() {
/* 58 */     return (this.html || this.xml);
/*    */   }
/*    */   
/*    */   public boolean isText() {
/* 62 */     return this.text;
/*    */   }
/*    */   
/*    */   public boolean isCaseSensitive() {
/* 66 */     return this.caseSensitive;
/*    */   }
/*    */ 
/*    */   
/*    */   public static TemplateMode parse(String mode) {
/* 71 */     if (mode == null || mode.trim().length() == 0) {
/* 72 */       throw new IllegalArgumentException("Template mode cannot be null or empty");
/*    */     }
/* 74 */     if ("HTML".equalsIgnoreCase(mode)) {
/* 75 */       return HTML;
/*    */     }
/* 77 */     if ("XML".equalsIgnoreCase(mode)) {
/* 78 */       return XML;
/*    */     }
/* 80 */     if ("TEXT".equalsIgnoreCase(mode)) {
/* 81 */       return TEXT;
/*    */     }
/* 83 */     if ("JAVASCRIPT".equalsIgnoreCase(mode)) {
/* 84 */       return JAVASCRIPT;
/*    */     }
/* 86 */     if ("CSS".equalsIgnoreCase(mode)) {
/* 87 */       return CSS;
/*    */     }
/* 89 */     if ("RAW".equalsIgnoreCase(mode)) {
/* 90 */       return RAW;
/*    */     }
/* 92 */     logger.warn("[THYMELEAF][{}] Unknown Template Mode '{}'. Must be one of: 'HTML', 'XML', 'TEXT', 'JAVASCRIPT', 'CSS', 'RAW'. Using default Template Mode '{}'.", new Object[] {
/*    */ 
/*    */           
/* 95 */           TemplateEngine.threadIndex(), mode, HTML });
/* 96 */     return HTML;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templatemode\TemplateMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */