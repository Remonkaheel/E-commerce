package org.thymeleaf.templateresource;

import java.io.IOException;
import java.io.Reader;

public interface ITemplateResource {
  String getDescription();
  
  String getBaseName();
  
  boolean exists();
  
  Reader reader() throws IOException;
  
  ITemplateResource relative(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresource\ITemplateResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */