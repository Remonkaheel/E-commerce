/*     */ package org.thymeleaf.templateresource;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.thymeleaf.web.IWebApplication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebApplicationTemplateResource
/*     */   implements ITemplateResource
/*     */ {
/*     */   private final IWebApplication webApplication;
/*     */   private final String path;
/*     */   private final String characterEncoding;
/*     */   
/*     */   public WebApplicationTemplateResource(IWebApplication webApplication, String path, String characterEncoding) {
/*  62 */     Validate.notNull(webApplication, "Web Application object cannot be null");
/*  63 */     Validate.notEmpty(path, "Resource Path cannot be null or empty");
/*     */ 
/*     */     
/*  66 */     this.webApplication = webApplication;
/*  67 */     String cleanPath = TemplateResourceUtils.cleanPath(path);
/*  68 */     this.path = (cleanPath.charAt(0) != '/') ? ("/" + cleanPath) : cleanPath;
/*  69 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  77 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseName() {
/*  84 */     return TemplateResourceUtils.computeBaseName(this.path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader reader() throws IOException {
/*  92 */     InputStream inputStream = this.webApplication.getResourceAsStream(this.path);
/*  93 */     if (inputStream == null) {
/*  94 */       throw new FileNotFoundException(String.format("Web Application resource \"%s\" does not exist", new Object[] { this.path }));
/*     */     }
/*     */     
/*  97 */     if (!StringUtils.isEmptyOrWhitespace(this.characterEncoding)) {
/*  98 */       return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), this.characterEncoding));
/*     */     }
/*     */     
/* 101 */     return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITemplateResource relative(String relativeLocation) {
/* 110 */     Validate.notEmpty(relativeLocation, "Relative Path cannot be null or empty");
/*     */     
/* 112 */     String fullRelativeLocation = TemplateResourceUtils.computeRelativeLocation(this.path, relativeLocation);
/* 113 */     return new WebApplicationTemplateResource(this.webApplication, fullRelativeLocation, this.characterEncoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 121 */     return this.webApplication.resourceExists(this.path);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresource\WebApplicationTemplateResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */