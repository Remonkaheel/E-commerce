/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebExpressionContext
/*    */   extends AbstractExpressionContext
/*    */   implements IWebContext
/*    */ {
/*    */   private final IWebExchange webExchange;
/*    */   
/*    */   public WebExpressionContext(IEngineConfiguration configuration, IWebExchange webExchange) {
/* 52 */     super(configuration);
/* 53 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/* 54 */     this.webExchange = webExchange;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebExpressionContext(IEngineConfiguration configuration, IWebExchange webExchange, Locale locale) {
/* 61 */     super(configuration, locale);
/* 62 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/* 63 */     this.webExchange = webExchange;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebExpressionContext(IEngineConfiguration configuration, IWebExchange webExchange, Locale locale, Map<String, Object> variables) {
/* 71 */     super(configuration, locale, variables);
/* 72 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/* 73 */     this.webExchange = webExchange;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IWebExchange getExchange() {
/* 79 */     return this.webExchange;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\WebExpressionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */