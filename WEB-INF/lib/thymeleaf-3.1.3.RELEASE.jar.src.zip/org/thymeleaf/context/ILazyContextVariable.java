package org.thymeleaf.context;

public interface ILazyContextVariable<T> {
  T getValue();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\ILazyContextVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */