package org.thymeleaf.context;

import java.util.List;
import java.util.Map;
import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.IModelFactory;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.templatemode.TemplateMode;

public interface ITemplateContext extends IExpressionContext {
  TemplateData getTemplateData();
  
  TemplateMode getTemplateMode();
  
  List<TemplateData> getTemplateStack();
  
  List<IProcessableElementTag> getElementStack();
  
  Map<String, Object> getTemplateResolutionAttributes();
  
  IModelFactory getModelFactory();
  
  boolean hasSelectionTarget();
  
  Object getSelectionTarget();
  
  IInliner getInliner();
  
  String getMessage(Class<?> paramClass, String paramString, Object[] paramArrayOfObject, boolean paramBoolean);
  
  String buildLink(String paramString, Map<String, Object> paramMap);
  
  IdentifierSequences getIdentifierSequences();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\ITemplateContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */