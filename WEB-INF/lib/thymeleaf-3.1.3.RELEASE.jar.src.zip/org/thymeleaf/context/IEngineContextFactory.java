package org.thymeleaf.context;

import java.util.Map;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.engine.TemplateData;

public interface IEngineContextFactory {
  IEngineContext createEngineContext(IEngineConfiguration paramIEngineConfiguration, TemplateData paramTemplateData, Map<String, Object> paramMap, IContext paramIContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\IEngineContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */