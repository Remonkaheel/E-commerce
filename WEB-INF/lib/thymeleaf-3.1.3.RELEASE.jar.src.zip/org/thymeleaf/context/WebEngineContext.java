/*      */ package org.thymeleaf.context;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.thymeleaf.IEngineConfiguration;
/*      */ import org.thymeleaf.engine.TemplateData;
/*      */ import org.thymeleaf.inline.IInliner;
/*      */ import org.thymeleaf.inline.NoOpInliner;
/*      */ import org.thymeleaf.model.IProcessableElementTag;
/*      */ import org.thymeleaf.util.Validate;
/*      */ import org.thymeleaf.web.IWebApplication;
/*      */ import org.thymeleaf.web.IWebExchange;
/*      */ import org.thymeleaf.web.IWebRequest;
/*      */ import org.thymeleaf.web.IWebSession;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebEngineContext
/*      */   extends AbstractEngineContext
/*      */   implements IEngineContext, IWebContext
/*      */ {
/*      */   private static final String PARAM_VARIABLE_NAME = "param";
/*      */   private static final String SESSION_VARIABLE_NAME = "session";
/*      */   private static final String APPLICATION_VARIABLE_NAME = "application";
/*      */   private final IWebExchange webExchange;
/*      */   private final ExchangeAttributeMap exchangeAttributeMap;
/*      */   private final RequestParameterMap requestParameterMap;
/*      */   private final SessionAttributeMap sessionAttributeMap;
/*      */   private final ApplicationAttributeMap applicationAttributeMap;
/*      */   
/*      */   public WebEngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, IWebExchange webExchange, Locale locale, Map<String, Object> variables) {
/*  126 */     super(configuration, templateResolutionAttributes, locale);
/*      */     
/*  128 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/*      */     
/*  130 */     this.webExchange = webExchange;
/*      */     
/*  132 */     this.exchangeAttributeMap = new ExchangeAttributeMap(configuration, templateData, templateResolutionAttributes, this.webExchange, locale, variables);
/*      */     
/*  134 */     this.requestParameterMap = new RequestParameterMap(this.webExchange);
/*  135 */     this.applicationAttributeMap = new ApplicationAttributeMap(this.webExchange);
/*  136 */     this.sessionAttributeMap = new SessionAttributeMap(this.webExchange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IWebExchange getExchange() {
/*  143 */     return this.webExchange;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsVariable(String name) {
/*  148 */     if ("session".equals(name)) {
/*  149 */       return (this.sessionAttributeMap != null);
/*      */     }
/*  151 */     if ("param".equals(name)) {
/*  152 */       return true;
/*      */     }
/*  154 */     return ("application".equals(name) || this.exchangeAttributeMap.containsVariable(name));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getVariable(String key) {
/*  159 */     if ("session".equals(key)) {
/*  160 */       return this.sessionAttributeMap;
/*      */     }
/*  162 */     if ("param".equals(key)) {
/*  163 */       return this.requestParameterMap;
/*      */     }
/*  165 */     if ("application".equals(key)) {
/*  166 */       return this.applicationAttributeMap;
/*      */     }
/*  168 */     return this.exchangeAttributeMap.getVariable(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getVariableNames() {
/*  175 */     return this.exchangeAttributeMap.getVariableNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVariable(String name, Object value) {
/*  180 */     if ("session".equals(name) || "param"
/*  181 */       .equals(name) || "application"
/*  182 */       .equals(name)) {
/*  183 */       throw new IllegalArgumentException("Cannot set variable called '" + name + "' into web variables map: such name is a reserved word");
/*      */     }
/*      */     
/*  186 */     this.exchangeAttributeMap.setVariable(name, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVariables(Map<String, Object> variables) {
/*  191 */     if (variables == null || variables.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  195 */     for (String name : variables.keySet()) {
/*  196 */       if ("session".equals(name) || "param"
/*  197 */         .equals(name) || "application"
/*  198 */         .equals(name)) {
/*  199 */         throw new IllegalArgumentException("Cannot set variable called '" + name + "' into web variables map: such name is a reserved word");
/*      */       }
/*      */     } 
/*      */     
/*  203 */     this.exchangeAttributeMap.setVariables(variables);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeVariable(String name) {
/*  208 */     if ("session".equals(name) || "param"
/*  209 */       .equals(name) || "application"
/*  210 */       .equals(name)) {
/*  211 */       throw new IllegalArgumentException("Cannot remove variable called '" + name + "' in web variables map: such name is a reserved word");
/*      */     }
/*      */     
/*  214 */     this.exchangeAttributeMap.removeVariable(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isVariableLocal(String name) {
/*  219 */     return this.exchangeAttributeMap.isVariableLocal(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasSelectionTarget() {
/*  224 */     return this.exchangeAttributeMap.hasSelectionTarget();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getSelectionTarget() {
/*  229 */     return this.exchangeAttributeMap.getSelectionTarget();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSelectionTarget(Object selectionTarget) {
/*  234 */     this.exchangeAttributeMap.setSelectionTarget(selectionTarget);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IInliner getInliner() {
/*  241 */     return this.exchangeAttributeMap.getInliner();
/*      */   }
/*      */   
/*      */   public void setInliner(IInliner inliner) {
/*  245 */     this.exchangeAttributeMap.setInliner(inliner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateData getTemplateData() {
/*  252 */     return this.exchangeAttributeMap.getTemplateData();
/*      */   }
/*      */   
/*      */   public void setTemplateData(TemplateData templateData) {
/*  256 */     this.exchangeAttributeMap.setTemplateData(templateData);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<TemplateData> getTemplateStack() {
/*  261 */     return this.exchangeAttributeMap.getTemplateStack();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElementTag(IProcessableElementTag elementTag) {
/*  268 */     this.exchangeAttributeMap.setElementTag(elementTag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<IProcessableElementTag> getElementStack() {
/*  275 */     return this.exchangeAttributeMap.getElementStack();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<IProcessableElementTag> getElementStackAbove(int contextLevel) {
/*  280 */     return this.exchangeAttributeMap.getElementStackAbove(contextLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int level() {
/*  287 */     return this.exchangeAttributeMap.level();
/*      */   }
/*      */ 
/*      */   
/*      */   public void increaseLevel() {
/*  292 */     this.exchangeAttributeMap.increaseLevel();
/*      */   }
/*      */ 
/*      */   
/*      */   public void decreaseLevel() {
/*  297 */     this.exchangeAttributeMap.decreaseLevel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringRepresentationByLevel() {
/*  305 */     return this.exchangeAttributeMap.getStringRepresentationByLevel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  314 */     return this.exchangeAttributeMap.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object resolveLazy(Object variable) {
/*  324 */     if (variable != null && variable instanceof ILazyContextVariable) {
/*  325 */       return ((ILazyContextVariable)variable).getValue();
/*      */     }
/*  327 */     return variable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class SessionAttributeMap
/*      */     extends NoOpMapImpl
/*      */   {
/*      */     private final IWebExchange webExchange;
/*      */ 
/*      */ 
/*      */     
/*      */     SessionAttributeMap(IWebExchange webExchange) {
/*  341 */       this.webExchange = webExchange;
/*      */     }
/*      */     
/*      */     private IWebSession getSession() {
/*  345 */       return this.webExchange.getSession();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  351 */       IWebSession webSession = getSession();
/*  352 */       if (webSession == null) {
/*  353 */         return 0;
/*      */       }
/*  355 */       return webSession.getAttributeCount();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  360 */       IWebSession webSession = getSession();
/*  361 */       if (webSession == null) {
/*  362 */         return true;
/*      */       }
/*  364 */       return (webSession.getAttributeCount() == 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object key) {
/*  373 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsValue(Object value) {
/*  380 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*      */     }
/*      */ 
/*      */     
/*      */     public Object get(Object key) {
/*  385 */       IWebSession webSession = getSession();
/*  386 */       if (webSession == null) {
/*  387 */         return null;
/*      */       }
/*  389 */       return WebEngineContext.resolveLazy(webSession.getAttributeValue((key != null) ? key.toString() : null));
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<String> keySet() {
/*  394 */       IWebSession webSession = getSession();
/*  395 */       if (webSession == null) {
/*  396 */         return Collections.emptySet();
/*      */       }
/*  398 */       return webSession.getAllAttributeNames();
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Object> values() {
/*  403 */       IWebSession webSession = getSession();
/*  404 */       if (webSession == null) {
/*  405 */         return Collections.emptySet();
/*      */       }
/*  407 */       return webSession.getAttributeMap().values();
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/*  412 */       IWebSession webSession = getSession();
/*  413 */       if (webSession == null) {
/*  414 */         return Collections.emptySet();
/*      */       }
/*  416 */       return webSession.getAttributeMap().entrySet();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ApplicationAttributeMap
/*      */     extends NoOpMapImpl
/*      */   {
/*      */     private final IWebExchange webExchange;
/*      */ 
/*      */     
/*      */     private IWebApplication webApplication;
/*      */ 
/*      */ 
/*      */     
/*      */     ApplicationAttributeMap(IWebExchange webExchange) {
/*  433 */       this.webExchange = webExchange;
/*      */     }
/*      */     
/*      */     private IWebApplication getApplication() {
/*  437 */       if (this.webApplication == null) {
/*  438 */         this.webApplication = this.webExchange.getApplication();
/*      */       }
/*  440 */       return this.webApplication;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  446 */       return getApplication().getAttributeCount();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  451 */       return (getApplication().getAttributeCount() == 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object key) {
/*  460 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsValue(Object value) {
/*  467 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*      */     }
/*      */ 
/*      */     
/*      */     public Object get(Object key) {
/*  472 */       return WebEngineContext.resolveLazy(getApplication().getAttributeValue((key != null) ? key.toString() : null));
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<String> keySet() {
/*  477 */       return getApplication().getAllAttributeNames();
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Object> values() {
/*  482 */       return getApplication().getAttributeMap().values();
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/*  487 */       return getApplication().getAttributeMap().entrySet();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class RequestParameterMap
/*      */     extends NoOpMapImpl
/*      */   {
/*      */     private final IWebExchange webExchange;
/*      */ 
/*      */     
/*      */     private IWebRequest webRequest;
/*      */ 
/*      */ 
/*      */     
/*      */     RequestParameterMap(IWebExchange webExchange) {
/*  504 */       this.webExchange = webExchange;
/*      */     }
/*      */     
/*      */     private IWebRequest getRequest() {
/*  508 */       if (this.webRequest == null) {
/*  509 */         this.webRequest = this.webExchange.getRequest();
/*      */       }
/*  511 */       return this.webRequest;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  517 */       return getRequest().getParameterCount();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  522 */       return (getRequest().getParameterCount() == 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object key) {
/*  531 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsValue(Object value) {
/*  538 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*      */     }
/*      */ 
/*      */     
/*      */     public Object get(Object key) {
/*  543 */       String[] parameterValues = getRequest().getParameterValues((key != null) ? key.toString() : null);
/*  544 */       if (parameterValues == null) {
/*  545 */         return null;
/*      */       }
/*  547 */       return new WebEngineContext.RequestParameterValues(parameterValues);
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<String> keySet() {
/*  552 */       return getRequest().getAllParameterNames();
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Object> values() {
/*  557 */       return getRequest().getParameterMap().values();
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/*  562 */       return getRequest().getParameterMap().entrySet();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class ExchangeAttributeMap
/*      */     extends AbstractEngineContext
/*      */     implements IEngineContext
/*      */   {
/*      */     private static final int DEFAULT_ELEMENT_HIERARCHY_SIZE = 20;
/*      */     
/*      */     private static final int DEFAULT_LEVELS_SIZE = 10;
/*      */     
/*      */     private static final int DEFAULT_LEVELARRAYS_SIZE = 5;
/*      */     
/*      */     private final IWebExchange webExchange;
/*  578 */     private int level = 0;
/*  579 */     private int index = 0;
/*      */     
/*      */     private int[] levels;
/*      */     
/*      */     private String[][] names;
/*      */     private Object[][] oldValues;
/*      */     private Object[][] newValues;
/*      */     private int[] levelSizes;
/*      */     private SelectionTarget[] selectionTargets;
/*      */     private IInliner[] inliners;
/*      */     private TemplateData[] templateDatas;
/*      */     private IProcessableElementTag[] elementTags;
/*  591 */     private SelectionTarget lastSelectionTarget = null;
/*  592 */     private IInliner lastInliner = null;
/*  593 */     private TemplateData lastTemplateData = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<TemplateData> templateStack;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ExchangeAttributeMap(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, IWebExchange webExchange, Locale locale, Map<String, Object> variables) {
/*  607 */       super(configuration, templateResolutionAttributes, locale);
/*      */       
/*  609 */       this.webExchange = webExchange;
/*      */       
/*  611 */       this.levels = new int[10];
/*  612 */       this.names = new String[10][];
/*  613 */       this.oldValues = new Object[10][];
/*  614 */       this.newValues = new Object[10][];
/*  615 */       this.levelSizes = new int[10];
/*  616 */       this.selectionTargets = new SelectionTarget[10];
/*  617 */       this.inliners = new IInliner[10];
/*  618 */       this.templateDatas = new TemplateData[10];
/*      */       
/*  620 */       this.elementTags = new IProcessableElementTag[20];
/*      */       
/*  622 */       Arrays.fill(this.levels, 2147483647);
/*  623 */       Arrays.fill((Object[])this.names, (Object)null);
/*  624 */       Arrays.fill((Object[])this.oldValues, (Object)null);
/*  625 */       Arrays.fill((Object[])this.newValues, (Object)null);
/*  626 */       Arrays.fill(this.levelSizes, 0);
/*  627 */       Arrays.fill((Object[])this.selectionTargets, (Object)null);
/*  628 */       Arrays.fill((Object[])this.inliners, (Object)null);
/*  629 */       Arrays.fill((Object[])this.templateDatas, (Object)null);
/*      */       
/*  631 */       Arrays.fill((Object[])this.elementTags, (Object)null);
/*      */       
/*  633 */       this.levels[0] = 0;
/*  634 */       this.templateDatas[0] = templateData;
/*  635 */       this.lastTemplateData = templateData;
/*      */       
/*  637 */       this.templateStack = new ArrayList<>(10);
/*  638 */       this.templateStack.add(templateData);
/*      */       
/*  640 */       if (variables != null) {
/*  641 */         setVariables(variables);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsVariable(String name) {
/*  648 */       return this.webExchange.containsAttribute(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getVariable(String name) {
/*  653 */       return WebEngineContext.resolveLazy(this.webExchange.getAttributeValue(name));
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<String> getVariableNames() {
/*  658 */       return this.webExchange.getAllAttributeNames();
/*      */     }
/*      */ 
/*      */     
/*      */     private int searchNameInIndex(String name, int idx) {
/*  663 */       int n = this.levelSizes[idx];
/*  664 */       if (name == null) {
/*  665 */         while (n-- != 0) {
/*  666 */           if (this.names[idx][n] == null) {
/*  667 */             return n;
/*      */           }
/*      */         } 
/*  670 */         return -1;
/*      */       } 
/*  672 */       while (n-- != 0) {
/*  673 */         if (name.equals(this.names[idx][n])) {
/*  674 */           return n;
/*      */         }
/*      */       } 
/*  677 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setVariable(String name, Object value) {
/*  685 */       ensureLevelInitialized(true);
/*      */       
/*  687 */       if (this.level > 0) {
/*      */ 
/*      */         
/*  690 */         int levelIndex = searchNameInIndex(name, this.index);
/*  691 */         if (levelIndex >= 0) {
/*      */ 
/*      */           
/*  694 */           this.newValues[this.index][levelIndex] = value;
/*      */         }
/*      */         else {
/*      */           
/*  698 */           if ((this.names[this.index]).length == this.levelSizes[this.index]) {
/*      */             
/*  700 */             this.names[this.index] = Arrays.<String>copyOf(this.names[this.index], (this.names[this.index]).length + 5);
/*  701 */             this.newValues[this.index] = Arrays.copyOf(this.newValues[this.index], (this.newValues[this.index]).length + 5);
/*  702 */             this.oldValues[this.index] = Arrays.copyOf(this.oldValues[this.index], (this.oldValues[this.index]).length + 5);
/*      */           } 
/*      */           
/*  705 */           levelIndex = this.levelSizes[this.index];
/*      */           
/*  707 */           this.names[this.index][levelIndex] = name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  714 */           this.oldValues[this.index][levelIndex] = this.webExchange.getAttributeValue(name);
/*      */           
/*  716 */           this.newValues[this.index][levelIndex] = value;
/*      */           
/*  718 */           this.levelSizes[this.index] = this.levelSizes[this.index] + 1;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  725 */       this.webExchange.setAttributeValue(name, value);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setVariables(Map<String, Object> variables) {
/*  731 */       if (variables == null || variables.isEmpty()) {
/*      */         return;
/*      */       }
/*  734 */       for (Map.Entry<String, Object> entry : variables.entrySet()) {
/*  735 */         setVariable(entry.getKey(), entry.getValue());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeVariable(String name) {
/*  741 */       setVariable(name, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVariableLocal(String name) {
/*  749 */       if (this.level == 0)
/*      */       {
/*  751 */         return false;
/*      */       }
/*      */       
/*  754 */       int n = this.index + 1;
/*  755 */       while (n-- > 1) {
/*  756 */         int idx = searchNameInIndex(name, n);
/*  757 */         if (idx >= 0) {
/*  758 */           return (this.newValues[n][idx] != null);
/*      */         }
/*      */       } 
/*      */       
/*  762 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasSelectionTarget() {
/*  770 */       if (this.lastSelectionTarget != null) {
/*  771 */         return true;
/*      */       }
/*  773 */       int n = this.index + 1;
/*  774 */       while (n-- != 0) {
/*  775 */         if (this.selectionTargets[n] != null) {
/*  776 */           return true;
/*      */         }
/*      */       } 
/*  779 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getSelectionTarget() {
/*  784 */       if (this.lastSelectionTarget != null) {
/*  785 */         return this.lastSelectionTarget.selectionTarget;
/*      */       }
/*  787 */       int n = this.index + 1;
/*  788 */       while (n-- != 0) {
/*  789 */         if (this.selectionTargets[n] != null) {
/*  790 */           this.lastSelectionTarget = this.selectionTargets[n];
/*  791 */           return this.lastSelectionTarget.selectionTarget;
/*      */         } 
/*      */       } 
/*  794 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSelectionTarget(Object selectionTarget) {
/*  799 */       ensureLevelInitialized(false);
/*  800 */       this.lastSelectionTarget = new SelectionTarget(selectionTarget);
/*  801 */       this.selectionTargets[this.index] = this.lastSelectionTarget;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IInliner getInliner() {
/*  808 */       if (this.lastInliner != null) {
/*  809 */         if (this.lastInliner == NoOpInliner.INSTANCE) {
/*  810 */           return null;
/*      */         }
/*  812 */         return this.lastInliner;
/*      */       } 
/*  814 */       int n = this.index + 1;
/*  815 */       while (n-- != 0) {
/*  816 */         if (this.inliners[n] != null) {
/*  817 */           this.lastInliner = this.inliners[n];
/*  818 */           if (this.lastInliner == NoOpInliner.INSTANCE) {
/*  819 */             return null;
/*      */           }
/*  821 */           return this.lastInliner;
/*      */         } 
/*      */       } 
/*  824 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setInliner(IInliner inliner) {
/*  829 */       ensureLevelInitialized(false);
/*      */       
/*  831 */       this.lastInliner = (inliner == null) ? (IInliner)NoOpInliner.INSTANCE : inliner;
/*  832 */       this.inliners[this.index] = this.lastInliner;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TemplateData getTemplateData() {
/*  839 */       if (this.lastTemplateData != null) {
/*  840 */         return this.lastTemplateData;
/*      */       }
/*  842 */       int n = this.index + 1;
/*  843 */       while (n-- != 0) {
/*  844 */         if (this.templateDatas[n] != null) {
/*  845 */           this.lastTemplateData = this.templateDatas[n];
/*  846 */           return this.lastTemplateData;
/*      */         } 
/*      */       } 
/*  849 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setTemplateData(TemplateData templateData) {
/*  854 */       Validate.notNull(templateData, "Template Data cannot be null");
/*  855 */       ensureLevelInitialized(false);
/*  856 */       this.lastTemplateData = templateData;
/*  857 */       this.templateDatas[this.index] = this.lastTemplateData;
/*  858 */       this.templateStack.clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TemplateData> getTemplateStack() {
/*  865 */       if (!this.templateStack.isEmpty())
/*      */       {
/*  867 */         return Collections.unmodifiableList(new ArrayList<>(this.templateStack));
/*      */       }
/*  869 */       for (int i = 0; i <= this.index; i++) {
/*  870 */         if (this.templateDatas[i] != null) {
/*  871 */           this.templateStack.add(this.templateDatas[i]);
/*      */         }
/*      */       } 
/*      */       
/*  875 */       return Collections.unmodifiableList(new ArrayList<>(this.templateStack));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setElementTag(IProcessableElementTag elementTag) {
/*  882 */       if (this.elementTags.length <= this.level) {
/*  883 */         this.elementTags = Arrays.<IProcessableElementTag>copyOf(this.elementTags, Math.max(this.level, this.elementTags.length + 20));
/*      */       }
/*  885 */       this.elementTags[this.level] = elementTag;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<IProcessableElementTag> getElementStack() {
/*  892 */       List<IProcessableElementTag> elementStack = new ArrayList<>(this.level);
/*  893 */       for (int i = 0; i <= this.level && i < this.elementTags.length; i++) {
/*  894 */         if (this.elementTags[i] != null) {
/*  895 */           elementStack.add(this.elementTags[i]);
/*      */         }
/*      */       } 
/*      */       
/*  899 */       return Collections.unmodifiableList(elementStack);
/*      */     }
/*      */ 
/*      */     
/*      */     public List<IProcessableElementTag> getElementStackAbove(int contextLevel) {
/*  904 */       List<IProcessableElementTag> elementStack = new ArrayList<>(this.level);
/*  905 */       for (int i = contextLevel + 1; i <= this.level && i < this.elementTags.length; i++) {
/*  906 */         if (this.elementTags[i] != null) {
/*  907 */           elementStack.add(this.elementTags[i]);
/*      */         }
/*      */       } 
/*      */       
/*  911 */       return Collections.unmodifiableList(elementStack);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void ensureLevelInitialized(boolean initVariables) {
/*  920 */       if (this.levels[this.index] != this.level) {
/*      */ 
/*      */ 
/*      */         
/*  924 */         this.index++;
/*      */         
/*  926 */         if (this.levels.length == this.index) {
/*  927 */           this.levels = Arrays.copyOf(this.levels, this.levels.length + 10);
/*  928 */           Arrays.fill(this.levels, this.index, this.levels.length, 2147483647);
/*  929 */           this.names = Arrays.<String[]>copyOf(this.names, this.names.length + 10);
/*  930 */           this.newValues = Arrays.<Object[]>copyOf(this.newValues, this.newValues.length + 10);
/*  931 */           this.oldValues = Arrays.<Object[]>copyOf(this.oldValues, this.oldValues.length + 10);
/*  932 */           this.levelSizes = Arrays.copyOf(this.levelSizes, this.levelSizes.length + 10);
/*      */           
/*  934 */           this.selectionTargets = Arrays.<SelectionTarget>copyOf(this.selectionTargets, this.selectionTargets.length + 10);
/*  935 */           this.inliners = Arrays.<IInliner>copyOf(this.inliners, this.inliners.length + 10);
/*  936 */           this.templateDatas = Arrays.<TemplateData>copyOf(this.templateDatas, this.templateDatas.length + 10);
/*      */         } 
/*      */         
/*  939 */         this.levels[this.index] = this.level;
/*      */       } 
/*      */ 
/*      */       
/*  943 */       if (this.level > 0)
/*      */       {
/*      */         
/*  946 */         if (initVariables && this.names[this.index] == null) {
/*      */ 
/*      */           
/*  949 */           this.names[this.index] = new String[5];
/*  950 */           Arrays.fill((Object[])this.names[this.index], (Object)null);
/*      */           
/*  952 */           this.newValues[this.index] = new Object[5];
/*  953 */           Arrays.fill(this.newValues[this.index], (Object)null);
/*      */           
/*  955 */           this.oldValues[this.index] = new Object[5];
/*  956 */           Arrays.fill(this.oldValues[this.index], (Object)null);
/*      */           
/*  958 */           this.levelSizes[this.index] = 0;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int level() {
/*  970 */       return this.level;
/*      */     }
/*      */ 
/*      */     
/*      */     public void increaseLevel() {
/*  975 */       this.level++;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void decreaseLevel() {
/*  981 */       Validate.isTrue((this.level > 0), "Cannot decrease variable map level below 0");
/*      */       
/*  983 */       if (this.levels[this.index] == this.level) {
/*      */         
/*  985 */         this.levels[this.index] = Integer.MAX_VALUE;
/*      */         
/*  987 */         if (this.names[this.index] != null && this.levelSizes[this.index] > 0) {
/*      */ 
/*      */           
/*  990 */           int n = this.levelSizes[this.index];
/*  991 */           while (n-- != 0) {
/*  992 */             String name = this.names[this.index][n];
/*  993 */             Object newValue = this.newValues[this.index][n];
/*  994 */             Object oldValue = this.oldValues[this.index][n];
/*  995 */             Object currentValue = this.webExchange.getAttributeValue(name);
/*  996 */             if (newValue == currentValue)
/*      */             {
/*      */               
/*  999 */               this.webExchange.setAttributeValue(name, oldValue);
/*      */             }
/*      */           } 
/* 1002 */           this.levelSizes[this.index] = 0;
/*      */         } 
/*      */ 
/*      */         
/* 1006 */         this.selectionTargets[this.index] = null;
/* 1007 */         this.inliners[this.index] = null;
/* 1008 */         this.templateDatas[this.index] = null;
/* 1009 */         this.index--;
/*      */ 
/*      */         
/* 1012 */         this.lastSelectionTarget = null;
/* 1013 */         this.lastInliner = null;
/* 1014 */         this.lastTemplateData = null;
/* 1015 */         this.templateStack.clear();
/*      */       } 
/*      */ 
/*      */       
/* 1019 */       if (this.level < this.elementTags.length) {
/* 1020 */         this.elementTags[this.level] = null;
/*      */       }
/*      */       
/* 1023 */       this.level--;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getStringRepresentationByLevel() {
/* 1032 */       StringBuilder strBuilder = new StringBuilder();
/* 1033 */       strBuilder.append('{');
/* 1034 */       Map<String, Object> oldValuesSum = new LinkedHashMap<>();
/* 1035 */       int n = this.index + 1;
/* 1036 */       while (n-- != 1) {
/* 1037 */         Map<String, Object> levelVars = new LinkedHashMap<>();
/* 1038 */         if (this.names[n] != null && this.levelSizes[n] > 0)
/* 1039 */           for (int i = 0; i < this.levelSizes[n]; i++) {
/* 1040 */             String name = this.names[n][i];
/* 1041 */             Object newValue = this.newValues[n][i];
/* 1042 */             Object oldValue = this.oldValues[n][i];
/* 1043 */             if (newValue == oldValue) {
/*      */               continue;
/*      */             }
/*      */             
/* 1047 */             if (!oldValuesSum.containsKey(name)) {
/*      */ 
/*      */               
/* 1050 */               if (newValue != this.webExchange.getAttributeValue(name))
/*      */               {
/*      */                 continue;
/*      */               
/*      */               }
/*      */             }
/* 1056 */             else if (newValue != oldValuesSum.get(name)) {
/*      */               continue;
/*      */             } 
/*      */             
/* 1060 */             levelVars.put(name, newValue);
/* 1061 */             oldValuesSum.put(name, oldValue);
/*      */             continue;
/*      */           }  
/* 1064 */         if (!levelVars.isEmpty() || this.selectionTargets[n] != null || this.inliners[n] != null) {
/* 1065 */           if (strBuilder.length() > 1) {
/* 1066 */             strBuilder.append(',');
/*      */           }
/* 1068 */           strBuilder.append(this.levels[n]).append(":");
/* 1069 */           if (!levelVars.isEmpty() || n == 0) {
/* 1070 */             strBuilder.append(levelVars);
/*      */           }
/* 1072 */           if (this.selectionTargets[n] != null) {
/* 1073 */             strBuilder.append("<").append((this.selectionTargets[n]).selectionTarget).append(">");
/*      */           }
/* 1075 */           if (this.inliners[n] != null) {
/* 1076 */             strBuilder.append("[").append(this.inliners[n].getName()).append("]");
/*      */           }
/* 1078 */           if (this.templateDatas[n] != null) {
/* 1079 */             strBuilder.append("(").append(this.templateDatas[n].getTemplate()).append(")");
/*      */           }
/*      */         } 
/*      */       } 
/* 1083 */       Map<String, Object> requestAttributes = new LinkedHashMap<>();
/* 1084 */       Set<String> attrNames = this.webExchange.getAllAttributeNames();
/* 1085 */       for (String name : attrNames) {
/* 1086 */         if (oldValuesSum.containsKey(name)) {
/* 1087 */           Object oldValue = oldValuesSum.get(name);
/* 1088 */           if (oldValue != null) {
/* 1089 */             requestAttributes.put(name, oldValuesSum.get(name));
/*      */           }
/* 1091 */           oldValuesSum.remove(name); continue;
/*      */         } 
/* 1093 */         requestAttributes.put(name, this.webExchange.getAttributeValue(name));
/*      */       } 
/*      */       
/* 1096 */       for (Map.Entry<String, Object> oldValuesSumEntry : oldValuesSum.entrySet()) {
/* 1097 */         String name = oldValuesSumEntry.getKey();
/* 1098 */         if (!requestAttributes.containsKey(name)) {
/* 1099 */           Object oldValue = oldValuesSumEntry.getValue();
/* 1100 */           if (oldValue != null) {
/* 1101 */             requestAttributes.put(name, oldValue);
/*      */           }
/*      */         } 
/*      */       } 
/* 1105 */       if (strBuilder.length() > 1) {
/* 1106 */         strBuilder.append(',');
/*      */       }
/* 1108 */       strBuilder.append(this.levels[n]).append(":");
/* 1109 */       strBuilder.append(requestAttributes.toString());
/* 1110 */       if (this.selectionTargets[0] != null) {
/* 1111 */         strBuilder.append("<").append((this.selectionTargets[0]).selectionTarget).append(">");
/*      */       }
/* 1113 */       if (this.inliners[0] != null) {
/* 1114 */         strBuilder.append("[").append(this.inliners[0].getName()).append("]");
/*      */       }
/* 1116 */       if (this.templateDatas[0] != null) {
/* 1117 */         strBuilder.append("(").append(this.templateDatas[0].getTemplate()).append(")");
/*      */       }
/* 1119 */       strBuilder.append("}[");
/* 1120 */       strBuilder.append(this.level);
/* 1121 */       strBuilder.append(']');
/* 1122 */       return strBuilder.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1131 */       Map<String, Object> attributeMap = this.webExchange.getAttributeMap();
/* 1132 */       String textInliningStr = (getInliner() != null) ? ("[" + getInliner().getName() + "]") : "";
/* 1133 */       String templateDataStr = "(" + getTemplateData().getTemplate() + ")";
/* 1134 */       return attributeMap.toString() + (hasSelectionTarget() ? ("<" + getSelectionTarget() + ">") : "") + textInliningStr + templateDataStr;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final class SelectionTarget
/*      */     {
/*      */       final Object selectionTarget;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       SelectionTarget(Object selectionTarget) {
/* 1150 */         this.selectionTarget = selectionTarget;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static abstract class NoOpMapImpl
/*      */     implements Map<String, Object>
/*      */   {
/*      */     public int size() {
/* 1169 */       return 0;
/*      */     }
/*      */     
/*      */     public boolean isEmpty() {
/* 1173 */       return true;
/*      */     }
/*      */     
/*      */     public boolean containsKey(Object key) {
/* 1177 */       return false;
/*      */     }
/*      */     
/*      */     public boolean containsValue(Object value) {
/* 1181 */       return false;
/*      */     }
/*      */     
/*      */     public Object get(Object key) {
/* 1185 */       return null;
/*      */     }
/*      */     
/*      */     public Object put(String key, Object value) {
/* 1189 */       throw new UnsupportedOperationException("Cannot add new entry: map is immutable");
/*      */     }
/*      */     
/*      */     public Object remove(Object key) {
/* 1193 */       throw new UnsupportedOperationException("Cannot remove entry: map is immutable");
/*      */     }
/*      */     
/*      */     public void putAll(Map<? extends String, ? extends Object> m) {
/* 1197 */       throw new UnsupportedOperationException("Cannot add new entry: map is immutable");
/*      */     }
/*      */     
/*      */     public void clear() {
/* 1201 */       throw new UnsupportedOperationException("Cannot clear: map is immutable");
/*      */     }
/*      */     
/*      */     public Set<String> keySet() {
/* 1205 */       return Collections.emptySet();
/*      */     }
/*      */     
/*      */     public Collection<Object> values() {
/* 1209 */       return Collections.emptyList();
/*      */     }
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/* 1213 */       return Collections.emptySet();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static final class RequestParameterValues
/*      */     extends AbstractList<String>
/*      */   {
/*      */     private final String[] parameterValues;
/*      */     
/*      */     public final int length;
/*      */     
/*      */     RequestParameterValues(String[] parameterValues) {
/* 1226 */       this.parameterValues = parameterValues;
/* 1227 */       this.length = this.parameterValues.length;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1232 */       return this.length;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1237 */       return (Object[])this.parameterValues.clone();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] arr) {
/* 1242 */       if (arr.length < this.length) {
/* 1243 */         T[] copy = (T[])Array.newInstance(arr.getClass().getComponentType(), this.length);
/* 1244 */         System.arraycopy(this.parameterValues, 0, copy, 0, this.length);
/* 1245 */         return copy;
/*      */       } 
/* 1247 */       System.arraycopy(this.parameterValues, 0, arr, 0, this.length);
/* 1248 */       if (arr.length > this.length) {
/* 1249 */         arr[this.length] = null;
/*      */       }
/* 1251 */       return arr;
/*      */     }
/*      */ 
/*      */     
/*      */     public String get(int index) {
/* 1256 */       return this.parameterValues[index];
/*      */     }
/*      */ 
/*      */     
/*      */     public int indexOf(Object obj) {
/* 1261 */       String[] a = this.parameterValues;
/* 1262 */       if (obj == null) {
/* 1263 */         for (int i = 0; i < a.length; i++) {
/* 1264 */           if (a[i] == null) {
/* 1265 */             return i;
/*      */           }
/*      */         } 
/*      */       } else {
/* 1269 */         for (int i = 0; i < a.length; i++) {
/* 1270 */           if (obj.equals(a[i])) {
/* 1271 */             return i;
/*      */           }
/*      */         } 
/*      */       } 
/* 1275 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/* 1280 */       return (indexOf(obj) != -1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1290 */       if (this.length == 0) {
/* 1291 */         return "";
/*      */       }
/* 1293 */       if (this.length == 1) {
/* 1294 */         return this.parameterValues[0];
/*      */       }
/* 1296 */       return super.toString();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\WebEngineContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */