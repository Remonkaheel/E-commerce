/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebContext
/*    */   extends AbstractContext
/*    */   implements IWebContext
/*    */ {
/*    */   private final IWebExchange webExchange;
/*    */   
/*    */   public WebContext(IWebExchange webExchange) {
/* 53 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/* 54 */     this.webExchange = webExchange;
/*    */   }
/*    */   
/*    */   public WebContext(IWebExchange webExchange, Locale locale) {
/* 58 */     super(locale);
/* 59 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/* 60 */     this.webExchange = webExchange;
/*    */   }
/*    */ 
/*    */   
/*    */   public WebContext(IWebExchange webExchange, Locale locale, Map<String, Object> variables) {
/* 65 */     super(locale, variables);
/* 66 */     Validate.notNull(webExchange, "Web exchange cannot be null in web context");
/* 67 */     this.webExchange = webExchange;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IWebExchange getExchange() {
/* 73 */     return this.webExchange;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\WebContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */