package org.thymeleaf.context;

import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.expression.IExpressionObjects;

public interface IExpressionContext extends IContext {
  IEngineConfiguration getConfiguration();
  
  IExpressionObjects getExpressionObjects();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\IExpressionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */