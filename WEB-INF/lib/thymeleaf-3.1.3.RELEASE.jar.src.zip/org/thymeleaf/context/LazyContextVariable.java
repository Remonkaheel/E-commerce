/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LazyContextVariable<T>
/*    */   implements ILazyContextVariable<T>
/*    */ {
/*    */   private volatile boolean initialized = false;
/*    */   private T value;
/*    */   
/*    */   public final T getValue() {
/* 81 */     if (!this.initialized) {
/* 82 */       synchronized (this) {
/* 83 */         if (!this.initialized) {
/* 84 */           this.value = loadValue();
/* 85 */           this.initialized = true;
/*    */         } 
/*    */       } 
/*    */     }
/* 89 */     return this.value;
/*    */   }
/*    */   
/*    */   protected abstract T loadValue();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\LazyContextVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */