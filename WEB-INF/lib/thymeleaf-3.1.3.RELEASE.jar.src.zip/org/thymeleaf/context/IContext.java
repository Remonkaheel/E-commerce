package org.thymeleaf.context;

import java.util.Locale;
import java.util.Set;

public interface IContext {
  Locale getLocale();
  
  boolean containsVariable(String paramString);
  
  Set<String> getVariableNames();
  
  Object getVariable(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\IContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */