/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import org.thymeleaf.web.IWebExchange;
/*    */ import org.thymeleaf.web.servlet.IServletWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Contexts
/*    */ {
/*    */   public static boolean isEngineContext(IContext context) {
/* 34 */     return context instanceof IEngineContext;
/*    */   }
/*    */   
/*    */   public static IEngineContext asEngineContext(IContext context) {
/* 38 */     return (IEngineContext)context;
/*    */   }
/*    */   
/*    */   public static boolean isWebContext(IContext context) {
/* 42 */     return context instanceof IWebContext;
/*    */   }
/*    */   
/*    */   public static IWebContext asWebContext(IContext context) {
/* 46 */     return (IWebContext)context;
/*    */   }
/*    */   
/*    */   public static IWebExchange getWebExchange(IContext context) {
/* 50 */     return asWebContext(context).getExchange();
/*    */   }
/*    */   
/*    */   public static boolean isServletWebContext(IContext context) {
/* 54 */     return (isWebContext(context) && asWebContext(context).getExchange() instanceof IServletWebExchange);
/*    */   }
/*    */   
/*    */   public static IServletWebExchange getServletWebExchange(IContext context) {
/* 58 */     return (IServletWebExchange)asWebContext(context).getExchange();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\Contexts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */