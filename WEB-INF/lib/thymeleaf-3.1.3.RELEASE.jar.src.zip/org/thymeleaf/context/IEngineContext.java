package org.thymeleaf.context;

import java.util.List;
import java.util.Map;
import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.IProcessableElementTag;

public interface IEngineContext extends ITemplateContext {
  void setVariable(String paramString, Object paramObject);
  
  void setVariables(Map<String, Object> paramMap);
  
  void removeVariable(String paramString);
  
  void setSelectionTarget(Object paramObject);
  
  void setInliner(IInliner paramIInliner);
  
  void setTemplateData(TemplateData paramTemplateData);
  
  void setElementTag(IProcessableElementTag paramIProcessableElementTag);
  
  List<IProcessableElementTag> getElementStackAbove(int paramInt);
  
  boolean isVariableLocal(String paramString);
  
  void increaseLevel();
  
  void decreaseLevel();
  
  int level();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\context\IEngineContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */