/*     */ package org.thymeleaf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.context.IEngineContextFactory;
/*     */ import org.thymeleaf.dialect.IDialect;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.ElementDefinitions;
/*     */ import org.thymeleaf.engine.StandardModelFactory;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.linkbuilder.ILinkBuilder;
/*     */ import org.thymeleaf.messageresolver.IMessageResolver;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.preprocessor.IPreProcessor;
/*     */ import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
/*     */ import org.thymeleaf.processor.comment.ICommentProcessor;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeProcessor;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
/*     */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesProcessor;
/*     */ import org.thymeleaf.processor.text.ITextProcessor;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateparser.markup.decoupled.IDecoupledTemplateLogicResolver;
/*     */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EngineConfiguration
/*     */   implements IEngineConfiguration
/*     */ {
/*     */   private final DialectSetConfiguration dialectSetConfiguration;
/*     */   private final Set<ITemplateResolver> templateResolvers;
/*     */   private final Set<IMessageResolver> messageResolvers;
/*     */   private final Set<ILinkBuilder> linkBuilders;
/*     */   private final ICacheManager cacheManager;
/*     */   private final IEngineContextFactory engineContextFactory;
/*     */   private final IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver;
/*     */   private TemplateManager templateManager;
/*     */   private final ConcurrentHashMap<TemplateMode, IModelFactory> modelFactories;
/*     */   
/*     */   EngineConfiguration(Set<ITemplateResolver> templateResolvers, Set<IMessageResolver> messageResolvers, Set<ILinkBuilder> linkBuilders, Set<DialectConfiguration> dialectConfigurations, ICacheManager cacheManager, IEngineContextFactory engineContextFactory, IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver) {
/*  96 */     Validate.notNull(templateResolvers, "Template Resolver set cannot be null");
/*  97 */     Validate.isTrue((templateResolvers.size() > 0), "Template Resolver set cannot be empty");
/*  98 */     Validate.containsNoNulls(templateResolvers, "Template Resolver set cannot contain any nulls");
/*  99 */     Validate.notNull(messageResolvers, "Message Resolver set cannot be null");
/* 100 */     Validate.notNull(dialectConfigurations, "Dialect configuration set cannot be null");
/*     */     
/* 102 */     Validate.notNull(engineContextFactory, "Engine Context Factory cannot be null");
/* 103 */     Validate.notNull(decoupledTemplateLogicResolver, "Decoupled Template Logic Resolver cannot be null");
/*     */     
/* 105 */     List<ITemplateResolver> templateResolversList = new ArrayList<>(templateResolvers);
/* 106 */     Collections.sort(templateResolversList, TemplateResolverComparator.INSTANCE);
/* 107 */     this.templateResolvers = Collections.unmodifiableSet(new LinkedHashSet<>(templateResolversList));
/*     */     
/* 109 */     List<IMessageResolver> messageResolversList = new ArrayList<>(messageResolvers);
/* 110 */     Collections.sort(messageResolversList, MessageResolverComparator.INSTANCE);
/* 111 */     this.messageResolvers = Collections.unmodifiableSet(new LinkedHashSet<>(messageResolversList));
/*     */     
/* 113 */     List<ILinkBuilder> linkBuilderList = new ArrayList<>(linkBuilders);
/* 114 */     Collections.sort(linkBuilderList, LinkBuilderComparator.INSTANCE);
/* 115 */     this.linkBuilders = Collections.unmodifiableSet(new LinkedHashSet<>(linkBuilderList));
/*     */     
/* 117 */     this.cacheManager = cacheManager;
/*     */     
/* 119 */     this.engineContextFactory = engineContextFactory;
/*     */     
/* 121 */     this.decoupledTemplateLogicResolver = decoupledTemplateLogicResolver;
/*     */     
/* 123 */     this.dialectSetConfiguration = DialectSetConfiguration.build(dialectConfigurations);
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.modelFactories = new ConcurrentHashMap<>(6, 1.0F, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize() {
/* 137 */     this.templateManager = new TemplateManager(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<ITemplateResolver> getTemplateResolvers() {
/* 143 */     return this.templateResolvers;
/*     */   }
/*     */   
/*     */   public Set<IMessageResolver> getMessageResolvers() {
/* 147 */     return this.messageResolvers;
/*     */   }
/*     */   
/*     */   public Set<ILinkBuilder> getLinkBuilders() {
/* 151 */     return this.linkBuilders;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ICacheManager getCacheManager() {
/* 157 */     return this.cacheManager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IEngineContextFactory getEngineContextFactory() {
/* 163 */     return this.engineContextFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IDecoupledTemplateLogicResolver getDecoupledTemplateLogicResolver() {
/* 169 */     return this.decoupledTemplateLogicResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<DialectConfiguration> getDialectConfigurations() {
/* 176 */     return this.dialectSetConfiguration.getDialectConfigurations();
/*     */   }
/*     */   
/*     */   public Set<IDialect> getDialects() {
/* 180 */     return this.dialectSetConfiguration.getDialects();
/*     */   }
/*     */   
/*     */   public <T extends IDialect> Set<T> getDialectsOfType(Class<T> type) {
/* 184 */     Validate.notNull(type, "Type cannot be null");
/* 185 */     Set<T> filteredDialects = new LinkedHashSet<>();
/* 186 */     for (IDialect dialect : this.dialectSetConfiguration.getDialects()) {
/* 187 */       if (type.isInstance(dialect)) {
/* 188 */         filteredDialects.add((T)dialect);
/*     */       }
/*     */     } 
/* 191 */     return filteredDialects;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStandardDialectPresent() {
/* 196 */     return this.dialectSetConfiguration.isStandardDialectPresent();
/*     */   }
/*     */   
/*     */   public String getStandardDialectPrefix() {
/* 200 */     return this.dialectSetConfiguration.getStandardDialectPrefix();
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementDefinitions getElementDefinitions() {
/* 205 */     return this.dialectSetConfiguration.getElementDefinitions();
/*     */   }
/*     */ 
/*     */   
/*     */   public AttributeDefinitions getAttributeDefinitions() {
/* 210 */     return this.dialectSetConfiguration.getAttributeDefinitions();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<ITemplateBoundariesProcessor> getTemplateBoundariesProcessors(TemplateMode templateMode) {
/* 215 */     return this.dialectSetConfiguration.getTemplateBoundariesProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<ICDATASectionProcessor> getCDATASectionProcessors(TemplateMode templateMode) {
/* 219 */     return this.dialectSetConfiguration.getCDATASectionProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<ICommentProcessor> getCommentProcessors(TemplateMode templateMode) {
/* 223 */     return this.dialectSetConfiguration.getCommentProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<IDocTypeProcessor> getDocTypeProcessors(TemplateMode templateMode) {
/* 227 */     return this.dialectSetConfiguration.getDocTypeProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<IElementProcessor> getElementProcessors(TemplateMode templateMode) {
/* 231 */     return this.dialectSetConfiguration.getElementProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<ITextProcessor> getTextProcessors(TemplateMode templateMode) {
/* 235 */     return this.dialectSetConfiguration.getTextProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<IProcessingInstructionProcessor> getProcessingInstructionProcessors(TemplateMode templateMode) {
/* 239 */     return this.dialectSetConfiguration.getProcessingInstructionProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<IXMLDeclarationProcessor> getXMLDeclarationProcessors(TemplateMode templateMode) {
/* 243 */     return this.dialectSetConfiguration.getXMLDeclarationProcessors(templateMode);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<IPreProcessor> getPreProcessors(TemplateMode templateMode) {
/* 248 */     return this.dialectSetConfiguration.getPreProcessors(templateMode);
/*     */   }
/*     */   
/*     */   public Set<IPostProcessor> getPostProcessors(TemplateMode templateMode) {
/* 252 */     return this.dialectSetConfiguration.getPostProcessors(templateMode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getExecutionAttributes() {
/* 258 */     return this.dialectSetConfiguration.getExecutionAttributes();
/*     */   }
/*     */ 
/*     */   
/*     */   public IExpressionObjectFactory getExpressionObjectFactory() {
/* 263 */     return this.dialectSetConfiguration.getExpressionObjectFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public TemplateManager getTemplateManager() {
/* 268 */     return this.templateManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModelFactory getModelFactory(TemplateMode templateMode) {
/* 273 */     if (this.modelFactories.containsKey(templateMode)) {
/* 274 */       return this.modelFactories.get(templateMode);
/*     */     }
/*     */     
/* 277 */     StandardModelFactory standardModelFactory = new StandardModelFactory(this, templateMode);
/* 278 */     this.modelFactories.putIfAbsent(templateMode, standardModelFactory);
/* 279 */     return this.modelFactories.get(templateMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModelReshapeable(TemplateMode templateMode) {
/* 292 */     if (!this.dialectSetConfiguration.isStandardDialectPresent())
/*     */     {
/*     */       
/* 295 */       return false;
/*     */     }
/*     */     
/* 298 */     Set<ITextProcessor> textProcessors = this.dialectSetConfiguration.getTextProcessors(templateMode);
/*     */ 
/*     */ 
/*     */     
/* 302 */     if (textProcessors.size() > 1) {
/* 303 */       return false;
/*     */     }
/*     */     
/* 306 */     if (templateMode.isMarkup()) {
/*     */       
/* 308 */       Set<ICommentProcessor> commentProcessors = this.dialectSetConfiguration.getCommentProcessors(templateMode);
/*     */ 
/*     */ 
/*     */       
/* 312 */       if (commentProcessors.size() > ((templateMode == TemplateMode.HTML) ? 2 : 1)) {
/* 313 */         return false;
/*     */       }
/*     */       
/* 316 */       Set<ICDATASectionProcessor> cdataSectionProcessors = this.dialectSetConfiguration.getCDATASectionProcessors(templateMode);
/*     */       
/* 318 */       if (cdataSectionProcessors.size() > 1) {
/* 319 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 326 */     if (!this.dialectSetConfiguration.getPreProcessors(templateMode).isEmpty()) {
/* 327 */       return false;
/*     */     }
/* 329 */     return this.dialectSetConfiguration.getPostProcessors(templateMode).isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int nullSafeIntegerComparison(Integer o1, Integer o2) {
/* 347 */     return (o1 != null) ? ((o2 != null) ? o1.compareTo(o2) : -1) : ((o2 != null) ? 1 : 0);
/*     */   }
/*     */   
/*     */   private static final class TemplateResolverComparator
/*     */     implements Comparator<ITemplateResolver>
/*     */   {
/* 353 */     private static TemplateResolverComparator INSTANCE = new TemplateResolverComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(ITemplateResolver tr1, ITemplateResolver tr2) {
/* 360 */       return EngineConfiguration.nullSafeIntegerComparison(tr1.getOrder(), tr2.getOrder());
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class MessageResolverComparator
/*     */     implements Comparator<IMessageResolver>
/*     */   {
/* 367 */     private static MessageResolverComparator INSTANCE = new MessageResolverComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(IMessageResolver mr1, IMessageResolver mr2) {
/* 374 */       return EngineConfiguration.nullSafeIntegerComparison(mr1.getOrder(), mr2.getOrder());
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LinkBuilderComparator
/*     */     implements Comparator<ILinkBuilder>
/*     */   {
/* 381 */     private static LinkBuilderComparator INSTANCE = new LinkBuilderComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(ILinkBuilder mr1, ILinkBuilder mr2) {
/* 388 */       return EngineConfiguration.nullSafeIntegerComparison(mr1.getOrder(), mr2.getOrder());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\EngineConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */