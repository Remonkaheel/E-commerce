/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateOutputException
/*    */   extends TemplateProcessingException
/*    */ {
/*    */   private static final long serialVersionUID = -247484715700490790L;
/*    */   
/*    */   public TemplateOutputException(String message, String templateName, int line, int col, Throwable cause) {
/* 42 */     super(message, templateName, line, col, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\exceptions\TemplateOutputException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */