/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserInitializationException
/*    */   extends TemplateEngineException
/*    */ {
/*    */   private static final long serialVersionUID = -1642601374976564594L;
/*    */   
/*    */   public ParserInitializationException(String message, Throwable cause) {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ParserInitializationException(String message) {
/* 38 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\exceptions\ParserInitializationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */