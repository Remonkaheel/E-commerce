/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateInputException
/*    */   extends TemplateProcessingException
/*    */ {
/*    */   private static final long serialVersionUID = 1818006121265449639L;
/*    */   
/*    */   public TemplateInputException(String message) {
/* 36 */     super(message);
/*    */   }
/*    */   
/*    */   public TemplateInputException(String message, Throwable cause) {
/* 40 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public TemplateInputException(String message, String templateName, Throwable cause) {
/* 44 */     super(message, templateName, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TemplateInputException(String message, String templateName, int line, int col) {
/* 57 */     super(message, templateName, line, col);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TemplateInputException(String message, String templateName, int line, int col, Throwable cause) {
/* 71 */     super(message, templateName, line, col, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\exceptions\TemplateInputException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */