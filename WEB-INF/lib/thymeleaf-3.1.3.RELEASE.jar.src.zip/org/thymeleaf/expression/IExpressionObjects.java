package org.thymeleaf.expression;

import java.util.Set;

public interface IExpressionObjects {
  int size();
  
  boolean containsObject(String paramString);
  
  Set<String> getObjectNames();
  
  Object getObject(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\expression\IExpressionObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */