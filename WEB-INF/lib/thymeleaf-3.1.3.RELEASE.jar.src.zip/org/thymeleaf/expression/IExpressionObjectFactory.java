package org.thymeleaf.expression;

import java.util.Set;
import org.thymeleaf.context.IExpressionContext;

public interface IExpressionObjectFactory {
  Set<String> getAllExpressionObjectNames();
  
  Object buildObject(IExpressionContext paramIExpressionContext, String paramString);
  
  boolean isCacheable(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\expression\IExpressionObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */