/*    */ package org.thymeleaf.templateparser.markup;
/*    */ 
/*    */ import org.attoparser.config.ParseConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLTemplateParser
/*    */   extends AbstractMarkupTemplateParser
/*    */ {
/* 43 */   static final ParseConfiguration MARKUP_PARSING_CONFIGURATION = ParseConfiguration.htmlConfiguration(); static {
/* 44 */     MARKUP_PARSING_CONFIGURATION.setElementBalancing(ParseConfiguration.ElementBalancing.AUTO_CLOSE);
/* 45 */     MARKUP_PARSING_CONFIGURATION.setCaseSensitive(false);
/* 46 */     MARKUP_PARSING_CONFIGURATION.setNoUnmatchedCloseElementsRequired(false);
/* 47 */     MARKUP_PARSING_CONFIGURATION.setUniqueAttributesInElementRequired(true);
/* 48 */     MARKUP_PARSING_CONFIGURATION.setXmlWellFormedAttributeValuesRequired(false);
/* 49 */     MARKUP_PARSING_CONFIGURATION.setUniqueRootElementPresence(ParseConfiguration.UniqueRootElementPresence.NOT_VALIDATED);
/* 50 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setDoctypePresence(ParseConfiguration.PrologPresence.ALLOWED);
/* 51 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setRequireDoctypeKeywordsUpperCase(false);
/* 52 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setValidateProlog(false);
/* 53 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setXmlDeclarationPresence(ParseConfiguration.PrologPresence.ALLOWED);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HTMLTemplateParser(int bufferPoolSize, int bufferSize) {
/* 60 */     super(MARKUP_PARSING_CONFIGURATION, bufferPoolSize, bufferSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\markup\HTMLTemplateParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */