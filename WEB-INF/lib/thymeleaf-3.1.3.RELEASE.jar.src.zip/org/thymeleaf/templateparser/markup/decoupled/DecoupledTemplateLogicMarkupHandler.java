/*     */ package org.thymeleaf.templateparser.markup.decoupled;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.attoparser.AbstractChainedMarkupHandler;
/*     */ import org.attoparser.IMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ import org.attoparser.select.ParseSelection;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecoupledTemplateLogicMarkupHandler
/*     */   extends AbstractChainedMarkupHandler
/*     */ {
/*     */   private static final int INJECTION_LEVEL = 0;
/*  44 */   private static final char[] INNER_WHITE_SPACE = " ".toCharArray();
/*     */ 
/*     */   
/*     */   private final DecoupledTemplateLogic decoupledTemplateLogic;
/*     */   
/*     */   private final boolean injectAttributes;
/*     */   
/*     */   private ParseSelection parseSelection;
/*     */   
/*     */   private boolean lastWasInnerWhiteSpace = false;
/*     */ 
/*     */   
/*     */   public DecoupledTemplateLogicMarkupHandler(DecoupledTemplateLogic decoupledTemplateLogic, IMarkupHandler handler) {
/*  57 */     super(handler);
/*     */     
/*  59 */     Validate.notNull(decoupledTemplateLogic, "Decoupled Template Logic cannot be null");
/*     */     
/*  61 */     this.decoupledTemplateLogic = decoupledTemplateLogic;
/*  62 */     this.injectAttributes = this.decoupledTemplateLogic.hasInjectedAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParseSelection(ParseSelection selection) {
/*  71 */     this.parseSelection = selection;
/*  72 */     super.setParseSelection(selection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col) throws ParseException {
/*  84 */     if (this.injectAttributes) {
/*  85 */       processInjectedAttributes(line, col);
/*     */     }
/*     */     
/*  88 */     super.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/* 101 */     if (this.injectAttributes) {
/* 102 */       processInjectedAttributes(line, col);
/*     */     }
/*     */     
/* 105 */     super.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col) throws ParseException {
/* 118 */     this.lastWasInnerWhiteSpace = true;
/* 119 */     super.handleInnerWhiteSpace(buffer, offset, len, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol) throws ParseException {
/* 137 */     this.lastWasInnerWhiteSpace = false;
/* 138 */     super.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processInjectedAttributes(int line, int col) throws ParseException {
/* 154 */     if (!this.parseSelection.isMatchingAny(0)) {
/*     */       return;
/*     */     }
/*     */     
/* 158 */     String[] selectors = this.parseSelection.getCurrentSelection(0);
/*     */     
/* 160 */     if (selectors == null || selectors.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 164 */     for (String selector : selectors) {
/*     */ 
/*     */       
/* 167 */       List<DecoupledInjectedAttribute> injectedAttributesForSelector = this.decoupledTemplateLogic.getInjectedAttributesForSelector(selector);
/*     */       
/* 169 */       if (injectedAttributesForSelector != null)
/*     */       {
/*     */ 
/*     */         
/* 173 */         for (DecoupledInjectedAttribute injectedAttribute : injectedAttributesForSelector) {
/*     */           
/* 175 */           if (!this.lastWasInnerWhiteSpace) {
/* 176 */             super.handleInnerWhiteSpace(INNER_WHITE_SPACE, 0, 1, line, col);
/*     */           }
/*     */           
/* 179 */           super.handleAttribute(injectedAttribute.buffer, injectedAttribute.nameOffset, injectedAttribute.nameLen, line, col, injectedAttribute.operatorOffset, injectedAttribute.operatorLen, line, col, injectedAttribute.valueContentOffset, injectedAttribute.valueContentLen, injectedAttribute.valueOuterOffset, injectedAttribute.valueOuterLen, line, col);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 189 */           this.lastWasInnerWhiteSpace = false;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\DecoupledTemplateLogicMarkupHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */