package org.thymeleaf.templateparser.markup.decoupled;

import java.util.Set;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresource.ITemplateResource;

public interface IDecoupledTemplateLogicResolver {
  ITemplateResource resolveDecoupledTemplateLogic(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Set<String> paramSet, ITemplateResource paramITemplateResource, TemplateMode paramTemplateMode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\IDecoupledTemplateLogicResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */