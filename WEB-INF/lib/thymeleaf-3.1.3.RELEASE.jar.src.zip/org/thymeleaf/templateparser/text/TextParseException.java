/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextParseException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -104133072151159140L;
/*     */   private final Integer line;
/*     */   private final Integer col;
/*     */   
/*     */   public TextParseException() {
/*  45 */     this.line = null;
/*  46 */     this.col = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TextParseException(String message, Throwable throwable) {
/*  51 */     super(message(message, throwable), throwable);
/*     */     
/*  53 */     if (throwable != null && throwable instanceof TextParseException) {
/*  54 */       this.line = ((TextParseException)throwable).getLine();
/*  55 */       this.col = ((TextParseException)throwable).getCol();
/*     */     } else {
/*  57 */       this.line = null;
/*  58 */       this.col = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TextParseException(String message) {
/*  64 */     super(message);
/*  65 */     this.line = null;
/*  66 */     this.col = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TextParseException(Throwable throwable) {
/*  71 */     super(message(null, throwable), throwable);
/*     */     
/*  73 */     if (throwable != null && throwable instanceof TextParseException) {
/*  74 */       this.line = ((TextParseException)throwable).getLine();
/*  75 */       this.col = ((TextParseException)throwable).getCol();
/*     */     } else {
/*  77 */       this.line = null;
/*  78 */       this.col = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TextParseException(int line, int col) {
/*  85 */     super(messagePrefix(line, col));
/*  86 */     this.line = Integer.valueOf(line);
/*  87 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public TextParseException(String message, Throwable throwable, int line, int col) {
/*  91 */     super(messagePrefix(line, col) + " " + message, throwable);
/*  92 */     this.line = Integer.valueOf(line);
/*  93 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public TextParseException(String message, int line, int col) {
/*  97 */     super(messagePrefix(line, col) + " " + message);
/*  98 */     this.line = Integer.valueOf(line);
/*  99 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public TextParseException(Throwable throwable, int line, int col) {
/* 103 */     super(messagePrefix(line, col), throwable);
/* 104 */     this.line = Integer.valueOf(line);
/* 105 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String messagePrefix(int line, int col) {
/* 112 */     return "(Line = " + line + ", Column = " + col + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String message(String message, Throwable throwable) {
/* 119 */     if (throwable != null && throwable instanceof TextParseException) {
/*     */       
/* 121 */       TextParseException exception = (TextParseException)throwable;
/* 122 */       if (exception.getLine() != null && exception.getCol() != null) {
/* 123 */         return "(Line = " + exception.getLine() + ", Column = " + exception.getCol() + ")" + (
/* 124 */           (message != null) ? (" " + message) : throwable.getMessage());
/*     */       }
/*     */     } 
/*     */     
/* 128 */     if (message != null) {
/* 129 */       return message;
/*     */     }
/* 131 */     if (throwable != null) {
/* 132 */       return throwable.getMessage();
/*     */     }
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getLine() {
/* 143 */     return this.line;
/*     */   }
/*     */   
/*     */   public Integer getCol() {
/* 147 */     return this.col;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */