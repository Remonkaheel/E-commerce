package org.thymeleaf.templateparser.text;

public interface ITextHandler {
  void handleDocumentStart(long paramLong, int paramInt1, int paramInt2) throws TextParseException;
  
  void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2) throws TextParseException;
  
  void handleText(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleComment(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) throws TextParseException;
  
  void handleStandaloneElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleStandaloneElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleOpenElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleOpenElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleCloseElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleCloseElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws TextParseException;
  
  void handleAttribute(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14) throws TextParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\text\ITextHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */