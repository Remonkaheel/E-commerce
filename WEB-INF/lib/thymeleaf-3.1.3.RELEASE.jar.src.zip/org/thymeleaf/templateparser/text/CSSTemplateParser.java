/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CSSTemplateParser
/*    */   extends AbstractTextTemplateParser
/*    */ {
/*    */   public CSSTemplateParser(int bufferPoolSize, int bufferSize, boolean standardDialectPresent) {
/* 32 */     super(bufferPoolSize, bufferSize, true, standardDialectPresent);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\text\CSSTemplateParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */