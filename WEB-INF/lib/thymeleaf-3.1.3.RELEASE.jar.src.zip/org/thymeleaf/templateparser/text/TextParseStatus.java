package org.thymeleaf.templateparser.text;

final class TextParseStatus {
  int offset;
  
  int line;
  
  int col;
  
  boolean inStructure;
  
  boolean inCommentLine;
  
  char literalMarker;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParseStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */