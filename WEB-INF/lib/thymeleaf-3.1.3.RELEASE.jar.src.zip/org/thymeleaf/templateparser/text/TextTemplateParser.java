/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextTemplateParser
/*    */   extends AbstractTextTemplateParser
/*    */ {
/*    */   public TextTemplateParser(int bufferPoolSize, int bufferSize, boolean standardDialectPresent) {
/* 32 */     super(bufferPoolSize, bufferSize, false, standardDialectPresent);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\text\TextTemplateParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */