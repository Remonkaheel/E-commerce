/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TextParsingAttributeSequenceUtil
/*     */ {
/*     */   public static void parseAttributeSequence(char[] buffer, int offset, int len, int line, int col, ITextHandler handler) throws TextParseException {
/*  57 */     int maxi = offset + len;
/*     */     
/*  59 */     int[] locator = { line, col };
/*     */     
/*  61 */     int i = offset;
/*  62 */     int current = i;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     while (i < maxi) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       int wsEnd = TextParsingUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */       
/*  76 */       if (wsEnd == -1) {
/*     */         
/*  78 */         i = maxi;
/*     */         
/*     */         continue;
/*     */       } 
/*  82 */       if (wsEnd > current) {
/*     */         
/*  84 */         i = wsEnd;
/*  85 */         current = i;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       int currentArtifactLine = locator[0];
/*  96 */       int currentArtifactCol = locator[1];
/*     */ 
/*     */       
/*  99 */       int attributeNameEnd = TextParsingUtil.findNextOperatorCharWildcard(buffer, i, maxi, locator);
/*     */       
/* 101 */       if (attributeNameEnd == -1) {
/*     */ 
/*     */         
/* 104 */         handler.handleAttribute(buffer, current, maxi - current, currentArtifactLine, currentArtifactCol, 0, 0, locator[0], locator[1], 0, 0, 0, 0, locator[0], locator[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 113 */         i = maxi;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 118 */       if (attributeNameEnd <= current)
/*     */       {
/* 120 */         throw new TextParseException("Bad attribute name in sequence \"" + new String(buffer, offset, len) + "\": attribute names cannot start with an equals sign", currentArtifactLine, currentArtifactCol);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       int attributeNameOffset = current;
/* 127 */       int attributeNameLen = attributeNameEnd - current;
/* 128 */       int attributeNameLine = currentArtifactLine;
/* 129 */       int attributeNameCol = currentArtifactCol;
/* 130 */       i = attributeNameEnd;
/* 131 */       current = i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       currentArtifactLine = locator[0];
/* 141 */       currentArtifactCol = locator[1];
/*     */ 
/*     */       
/* 144 */       int operatorEnd = TextParsingUtil.findNextNonOperatorCharWildcard(buffer, i, maxi, locator);
/*     */       
/* 146 */       if (operatorEnd == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         boolean bool = false;
/* 152 */         for (int k = i; k < maxi; k++) {
/* 153 */           if (buffer[k] == '=') {
/* 154 */             bool = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 159 */         if (bool) {
/*     */ 
/*     */ 
/*     */           
/* 163 */           handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, current, maxi - current, currentArtifactLine, currentArtifactCol, 0, 0, 0, 0, locator[0], locator[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 175 */           handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, 0, 0, currentArtifactLine, currentArtifactCol, 0, 0, 0, 0, currentArtifactLine, currentArtifactCol);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         i = maxi;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 193 */       boolean equalsPresent = false;
/* 194 */       for (int j = current; j < operatorEnd; j++) {
/* 195 */         if (buffer[j] == '=') {
/* 196 */           equalsPresent = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 201 */       if (!equalsPresent) {
/*     */ 
/*     */ 
/*     */         
/* 205 */         handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, 0, 0, currentArtifactLine, currentArtifactCol, 0, 0, 0, 0, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         i = operatorEnd;
/* 215 */         current = i;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 221 */       int operatorOffset = current;
/* 222 */       int operatorLen = operatorEnd - current;
/* 223 */       int operatorLine = currentArtifactLine;
/* 224 */       int operatorCol = currentArtifactCol;
/* 225 */       i = operatorEnd;
/* 226 */       current = i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       currentArtifactLine = locator[0];
/* 236 */       currentArtifactCol = locator[1];
/*     */       
/* 238 */       boolean attributeEndsWithQuotes = (i < maxi && (buffer[current] == '"' || buffer[current] == '\''));
/*     */ 
/*     */ 
/*     */       
/* 242 */       int valueEnd = attributeEndsWithQuotes ? TextParsingUtil.findNextAnyCharAvoidQuotesWildcard(buffer, i, maxi, locator) : TextParsingUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, false, locator);
/*     */       
/* 244 */       if (valueEnd == -1) {
/*     */ 
/*     */         
/* 247 */         int k = current;
/* 248 */         int m = maxi - current;
/*     */         
/* 250 */         if (isValueSurroundedByCommas(buffer, current, maxi - current)) {
/* 251 */           k++;
/* 252 */           m -= 2;
/*     */         } 
/*     */         
/* 255 */         handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, operatorOffset, operatorLen, operatorLine, operatorCol, k, m, current, maxi - current, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 264 */         i = maxi;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 270 */       int valueOuterOffset = current;
/* 271 */       int valueOuterLen = valueEnd - current;
/* 272 */       int valueContentOffset = valueOuterOffset;
/* 273 */       int valueContentLen = valueOuterLen;
/*     */       
/* 275 */       if (isValueSurroundedByCommas(buffer, valueOuterOffset, valueOuterLen)) {
/* 276 */         valueContentOffset = valueOuterOffset + 1;
/* 277 */         valueContentLen = valueOuterLen - 2;
/*     */       } 
/*     */       
/* 280 */       handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 289 */       i = valueEnd;
/* 290 */       current = i;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isValueSurroundedByCommas(char[] buffer, int offset, int len) {
/* 300 */     return (len >= 2 && ((buffer[offset] == '"' && buffer[offset + len - 1] == '"') || (buffer[offset] == '\'' && buffer[offset + len - 1] == '\'')));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParsingAttributeSequenceUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */