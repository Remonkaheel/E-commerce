/*    */ package org.thymeleaf.templateparser.reader;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParserLevelCommentTextReader
/*    */   extends BlockAwareReader
/*    */ {
/* 32 */   private static final char[] PREFIX = "/*[-".toCharArray();
/* 33 */   private static final char[] SUFFIX = "-]*/".toCharArray();
/*    */ 
/*    */   
/*    */   public ParserLevelCommentTextReader(Reader reader) {
/* 37 */     super(reader, BlockAwareReader.BlockAction.DISCARD_ALL, PREFIX, SUFFIX);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\reader\ParserLevelCommentTextReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */