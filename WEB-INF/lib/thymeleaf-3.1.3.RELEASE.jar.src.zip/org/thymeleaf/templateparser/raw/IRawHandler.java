package org.thymeleaf.templateparser.raw;

public interface IRawHandler {
  void handleDocumentStart(long paramLong, int paramInt1, int paramInt2) throws RawParseException;
  
  void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2) throws RawParseException;
  
  void handleText(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws RawParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateparser\raw\IRawHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */