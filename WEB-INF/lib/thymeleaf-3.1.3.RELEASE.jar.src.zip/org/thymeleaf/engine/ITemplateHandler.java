package org.thymeleaf.engine;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.model.ICloseElementTag;
import org.thymeleaf.model.IComment;
import org.thymeleaf.model.IDocType;
import org.thymeleaf.model.IOpenElementTag;
import org.thymeleaf.model.IProcessingInstruction;
import org.thymeleaf.model.IStandaloneElementTag;
import org.thymeleaf.model.ITemplateEnd;
import org.thymeleaf.model.ITemplateStart;
import org.thymeleaf.model.IText;
import org.thymeleaf.model.IXMLDeclaration;

public interface ITemplateHandler {
  void setNext(ITemplateHandler paramITemplateHandler);
  
  void setContext(ITemplateContext paramITemplateContext);
  
  void handleTemplateStart(ITemplateStart paramITemplateStart);
  
  void handleTemplateEnd(ITemplateEnd paramITemplateEnd);
  
  void handleXMLDeclaration(IXMLDeclaration paramIXMLDeclaration);
  
  void handleDocType(IDocType paramIDocType);
  
  void handleCDATASection(ICDATASection paramICDATASection);
  
  void handleComment(IComment paramIComment);
  
  void handleText(IText paramIText);
  
  void handleStandaloneElement(IStandaloneElementTag paramIStandaloneElementTag);
  
  void handleOpenElement(IOpenElementTag paramIOpenElementTag);
  
  void handleCloseElement(ICloseElementTag paramICloseElementTag);
  
  void handleProcessingInstruction(IProcessingInstruction paramIProcessingInstruction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\ITemplateHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */