/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.exceptions.TemplateOutputException;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OutputTemplateHandler
/*     */   extends AbstractTemplateHandler
/*     */ {
/*     */   private final Writer writer;
/*     */   
/*     */   public OutputTemplateHandler(Writer writer) {
/*  58 */     if (writer == null) {
/*  59 */       throw new IllegalArgumentException("Writer cannot be null");
/*     */     }
/*  61 */     this.writer = writer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleText(IText text) {
/*     */     try {
/*  71 */       text.write(this.writer);
/*  72 */     } catch (Exception e) {
/*  73 */       throw new TemplateOutputException("An error happened during template rendering", text
/*     */           
/*  75 */           .getTemplateName(), text.getLine(), text.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/*  79 */     super.handleText(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleComment(IComment comment) {
/*     */     try {
/*  89 */       comment.write(this.writer);
/*  90 */     } catch (Exception e) {
/*  91 */       throw new TemplateOutputException("An error happened during template rendering", comment
/*     */           
/*  93 */           .getTemplateName(), comment.getLine(), comment.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/*  97 */     super.handleComment(comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleCDATASection(ICDATASection cdataSection) {
/*     */     try {
/* 106 */       cdataSection.write(this.writer);
/* 107 */     } catch (Exception e) {
/* 108 */       throw new TemplateOutputException("An error happened during template rendering", cdataSection
/*     */           
/* 110 */           .getTemplateName(), cdataSection.getLine(), cdataSection.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 114 */     super.handleCDATASection(cdataSection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleStandaloneElement(IStandaloneElementTag standaloneElementTag) {
/*     */     try {
/* 125 */       standaloneElementTag.write(this.writer);
/* 126 */     } catch (Exception e) {
/* 127 */       throw new TemplateOutputException("An error happened during template rendering", standaloneElementTag
/*     */           
/* 129 */           .getTemplateName(), standaloneElementTag.getLine(), standaloneElementTag.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 133 */     super.handleStandaloneElement(standaloneElementTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElement(IOpenElementTag openElementTag) {
/*     */     try {
/* 142 */       openElementTag.write(this.writer);
/* 143 */     } catch (Exception e) {
/* 144 */       throw new TemplateOutputException("An error happened during template rendering", openElementTag
/*     */           
/* 146 */           .getTemplateName(), openElementTag.getLine(), openElementTag.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 150 */     super.handleOpenElement(openElementTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleCloseElement(ICloseElementTag closeElementTag) {
/*     */     try {
/* 159 */       closeElementTag.write(this.writer);
/* 160 */     } catch (Exception e) {
/* 161 */       throw new TemplateOutputException("An error happened during template rendering", closeElementTag
/*     */           
/* 163 */           .getTemplateName(), closeElementTag.getLine(), closeElementTag.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 167 */     super.handleCloseElement(closeElementTag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleDocType(IDocType docType) {
/*     */     try {
/* 178 */       docType.write(this.writer);
/* 179 */     } catch (Exception e) {
/* 180 */       throw new TemplateOutputException("An error happened during template rendering", docType
/*     */           
/* 182 */           .getTemplateName(), docType.getLine(), docType.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 186 */     super.handleDocType(docType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleXMLDeclaration(IXMLDeclaration xmlDeclaration) {
/*     */     try {
/* 197 */       xmlDeclaration.write(this.writer);
/* 198 */     } catch (Exception e) {
/* 199 */       throw new TemplateOutputException("An error happened during template rendering", xmlDeclaration
/*     */           
/* 201 */           .getTemplateName(), xmlDeclaration.getLine(), xmlDeclaration.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 205 */     super.handleXMLDeclaration(xmlDeclaration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleProcessingInstruction(IProcessingInstruction processingInstruction) {
/*     */     try {
/* 218 */       processingInstruction.write(this.writer);
/* 219 */     } catch (Exception e) {
/* 220 */       throw new TemplateOutputException("An error happened during template rendering", processingInstruction
/*     */           
/* 222 */           .getTemplateName(), processingInstruction.getLine(), processingInstruction.getCol(), e);
/*     */     } 
/*     */ 
/*     */     
/* 226 */     super.handleProcessingInstruction(processingInstruction);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\OutputTemplateHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */