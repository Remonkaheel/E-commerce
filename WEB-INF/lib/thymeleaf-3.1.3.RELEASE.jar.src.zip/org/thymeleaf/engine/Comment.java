/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Comment
/*     */   extends AbstractTextualTemplateEvent
/*     */   implements IComment
/*     */ {
/*     */   private static final String COMMENT_PREFIX = "<!--";
/*     */   private static final String COMMENT_SUFFIX = "-->";
/*     */   final String prefix;
/*     */   final String suffix;
/*  44 */   private volatile String computedCommentStr = null;
/*     */ 
/*     */ 
/*     */   
/*     */   Comment(CharSequence content) {
/*  49 */     this("<!--", content, "-->");
/*     */   }
/*     */ 
/*     */   
/*     */   Comment(String prefix, CharSequence content, String suffix) {
/*  54 */     super(content);
/*  55 */     this.prefix = prefix;
/*  56 */     this.suffix = suffix;
/*     */   }
/*     */ 
/*     */   
/*     */   Comment(CharSequence content, String templateName, int line, int col) {
/*  61 */     this("<!--", content, "-->", templateName, line, col);
/*     */   }
/*     */ 
/*     */   
/*     */   Comment(String prefix, CharSequence content, String suffix, String templateName, int line, int col) {
/*  66 */     super(content, templateName, line, col);
/*  67 */     this.prefix = prefix;
/*  68 */     this.suffix = suffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComment() {
/*  77 */     String c = this.computedCommentStr;
/*  78 */     if (c == null) {
/*  79 */       this.computedCommentStr = c = this.prefix + getContentText() + this.suffix;
/*     */     }
/*  81 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContent() {
/*  86 */     return getContentText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/*  93 */     return this.prefix.length() + getContentLength() + this.suffix.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/*  98 */     if (index < this.prefix.length()) {
/*  99 */       return this.prefix.charAt(index);
/*     */     }
/* 101 */     int prefixedContentLen = this.prefix.length() + getContentLength();
/* 102 */     if (index >= prefixedContentLen) {
/* 103 */       return this.suffix.charAt(index - prefixedContentLen);
/*     */     }
/* 105 */     return charAtContent(index - this.prefix.length());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 111 */     if (start >= this.prefix.length() && end < this.prefix.length() + getContentLength()) {
/* 112 */       return contentSubSequence(start - this.prefix.length(), end - this.prefix.length());
/*     */     }
/* 114 */     return getComment().subSequence(start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(IModelVisitor visitor) {
/* 121 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(Writer writer) throws IOException {
/* 126 */     writer.write(this.prefix);
/* 127 */     writeContent(writer);
/* 128 */     writer.write(this.suffix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Comment asEngineComment(IComment comment) {
/* 136 */     if (comment instanceof Comment) {
/* 137 */       return (Comment)comment;
/*     */     }
/* 139 */     return new Comment(comment.getContent(), comment.getTemplateName(), comment.getLine(), comment.getCol());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beHandled(ITemplateHandler handler) {
/* 147 */     handler.handleComment(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     return getComment();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\Comment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */