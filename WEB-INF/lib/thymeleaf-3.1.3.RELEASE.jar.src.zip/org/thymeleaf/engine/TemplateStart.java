/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.thymeleaf.model.IModelVisitor;
/*    */ import org.thymeleaf.model.ITemplateStart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TemplateStart
/*    */   extends AbstractTemplateEvent
/*    */   implements ITemplateStart, IEngineTemplateEvent
/*    */ {
/* 36 */   static final TemplateStart TEMPLATE_START_INSTANCE = new TemplateStart();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(IModelVisitor visitor) {
/* 49 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(Writer writer) throws IOException {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TemplateStart asEngineTemplateStart(ITemplateStart templateStart) {
/* 62 */     return TEMPLATE_START_INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beHandled(ITemplateHandler handler) {
/* 70 */     handler.handleTemplateStart(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String toString() {
/* 78 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\TemplateStart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */