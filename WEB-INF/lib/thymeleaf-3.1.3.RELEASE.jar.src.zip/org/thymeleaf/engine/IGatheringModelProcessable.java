package org.thymeleaf.engine;

import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.model.ICloseElementTag;
import org.thymeleaf.model.IComment;
import org.thymeleaf.model.IDocType;
import org.thymeleaf.model.IOpenElementTag;
import org.thymeleaf.model.IProcessingInstruction;
import org.thymeleaf.model.IStandaloneElementTag;
import org.thymeleaf.model.IText;
import org.thymeleaf.model.IXMLDeclaration;

interface IGatheringModelProcessable extends IEngineProcessable {
  boolean isGatheringFinished();
  
  Model getInnerModel();
  
  void resetGatheredSkipFlags();
  
  ProcessorExecutionVars initializeProcessorExecutionVars();
  
  void gatherText(IText paramIText);
  
  void gatherComment(IComment paramIComment);
  
  void gatherCDATASection(ICDATASection paramICDATASection);
  
  void gatherStandaloneElement(IStandaloneElementTag paramIStandaloneElementTag);
  
  void gatherOpenElement(IOpenElementTag paramIOpenElementTag);
  
  void gatherCloseElement(ICloseElementTag paramICloseElementTag);
  
  void gatherUnmatchedCloseElement(ICloseElementTag paramICloseElementTag);
  
  void gatherDocType(IDocType paramIDocType);
  
  void gatherXMLDeclaration(IXMLDeclaration paramIXMLDeclaration);
  
  void gatherProcessingInstruction(IProcessingInstruction paramIProcessingInstruction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\IGatheringModelProcessable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */