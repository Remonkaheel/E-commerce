/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextElementName
/*    */   extends ElementName
/*    */ {
/*    */   final String completeNamespacedElementName;
/*    */   
/*    */   static TextElementName forName(String prefix, String elementName) {
/*    */     String completeNamespacedElementName, completeElementNames[];
/* 36 */     boolean hasPrefix = (prefix != null && prefix.length() > 0);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     if (hasPrefix) {
/*    */       
/* 43 */       completeNamespacedElementName = prefix + ":" + elementName;
/* 44 */       completeElementNames = new String[] { completeNamespacedElementName };
/*    */     }
/*    */     else {
/*    */       
/* 48 */       completeNamespacedElementName = elementName;
/* 49 */       completeElementNames = new String[] { elementName };
/*    */     } 
/*    */ 
/*    */     
/* 53 */     return new TextElementName(prefix, elementName, completeNamespacedElementName, completeElementNames);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private TextElementName(String prefix, String elementName, String completeNamespacedElementName, String[] completeElementNames) {
/* 65 */     super(prefix, elementName, completeElementNames);
/* 66 */     this.completeNamespacedElementName = completeNamespacedElementName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCompleteNamespacedElementName() {
/* 73 */     return this.completeNamespacedElementName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\TextElementName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */