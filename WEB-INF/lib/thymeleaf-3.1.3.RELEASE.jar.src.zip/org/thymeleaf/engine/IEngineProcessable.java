package org.thymeleaf.engine;

interface IEngineProcessable {
  boolean process();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\IEngineProcessable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */