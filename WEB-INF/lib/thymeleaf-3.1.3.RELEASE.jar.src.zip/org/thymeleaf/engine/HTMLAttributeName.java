/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLAttributeName
/*    */   extends AttributeName
/*    */ {
/*    */   final String completeNamespacedAttributeName;
/*    */   final String completeHTML5AttributeName;
/*    */   
/*    */   static HTMLAttributeName forName(String prefix, String attributeName) {
/*    */     String namePrefix, completeNamespacedAttributeName, completeHTML5AttributeName, completeAttributeNames[];
/* 37 */     boolean hasPrefix = (prefix != null && prefix.length() > 0);
/*    */ 
/*    */     
/* 40 */     String nameAttributeName = (attributeName == null || attributeName.length() == 0) ? null : attributeName.toLowerCase();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 47 */     if (hasPrefix) {
/*    */       
/* 49 */       namePrefix = prefix.toLowerCase();
/* 50 */       completeNamespacedAttributeName = namePrefix + ":" + nameAttributeName;
/* 51 */       completeHTML5AttributeName = "data-" + namePrefix + "-" + nameAttributeName;
/* 52 */       completeAttributeNames = new String[] { completeNamespacedAttributeName, completeHTML5AttributeName };
/*    */     }
/*    */     else {
/*    */       
/* 56 */       namePrefix = null;
/* 57 */       completeNamespacedAttributeName = nameAttributeName;
/* 58 */       completeHTML5AttributeName = nameAttributeName;
/* 59 */       completeAttributeNames = new String[] { nameAttributeName };
/*    */     } 
/*    */ 
/*    */     
/* 63 */     return new HTMLAttributeName(namePrefix, nameAttributeName, completeNamespacedAttributeName, completeHTML5AttributeName, completeAttributeNames);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private HTMLAttributeName(String prefix, String attributeName, String completeNamespacedAttributeName, String completeHTML5AttributeName, String[] completeAttributeNames) {
/* 76 */     super(prefix, attributeName, completeAttributeNames);
/*    */     
/* 78 */     this.completeNamespacedAttributeName = completeNamespacedAttributeName;
/* 79 */     this.completeHTML5AttributeName = completeHTML5AttributeName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCompleteNamespacedAttributeName() {
/* 85 */     return this.completeNamespacedAttributeName;
/*    */   }
/*    */   
/*    */   public String getCompleteHTML5AttributeName() {
/* 89 */     return this.completeHTML5AttributeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\HTMLAttributeName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */