/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.processor.element.IElementProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XMLElementDefinition
/*    */   extends ElementDefinition
/*    */ {
/*    */   XMLElementDefinition(XMLElementName name, Set<IElementProcessor> associatedProcessors) {
/* 37 */     super(name, associatedProcessors);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\XMLElementDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */