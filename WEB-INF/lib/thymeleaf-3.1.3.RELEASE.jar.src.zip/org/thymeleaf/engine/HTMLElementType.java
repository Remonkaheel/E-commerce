/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HTMLElementType
/*    */ {
/* 32 */   VOID(true), RAW_TEXT(false), ESCAPABLE_RAW_TEXT(false), FOREIGN(false), NORMAL(false);
/*    */   
/*    */   final boolean isVoid;
/*    */   
/*    */   HTMLElementType(boolean voidElement) {
/* 37 */     this.isVoid = voidElement;
/*    */   }
/*    */   
/*    */   public boolean isVoid() {
/* 41 */     return this.isVoid;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\HTMLElementType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */