/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DataDrivenTemplateIterator
/*     */   implements Iterator<Object>
/*     */ {
/*  53 */   private static final char[] SSE_HEAD_EVENT_NAME = "head".toCharArray();
/*  54 */   private static final char[] SSE_MESSAGE_EVENT_NAME = "message".toCharArray();
/*  55 */   private static final char[] SSE_TAIL_EVENT_NAME = "tail".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private final List<Object> values = new ArrayList(10);
/*  73 */   private IThrottledTemplateWriterControl writerControl = null;
/*  74 */   private ISSEThrottledTemplateWriterControl sseControl = null;
/*  75 */   private char[] sseEventsPrefix = null;
/*  76 */   private char[] sseEventsComposedMessageEventName = null;
/*  77 */   private long sseEventsID = 0L;
/*     */   
/*     */   private boolean inStep = false;
/*     */   
/*     */   private boolean feedingComplete = false;
/*     */   
/*     */   private boolean queried = false;
/*     */   
/*     */   public void setWriterControl(IThrottledTemplateWriterControl writerControl) {
/*  86 */     this.writerControl = writerControl;
/*  87 */     if (writerControl instanceof ISSEThrottledTemplateWriterControl) {
/*  88 */       this.sseControl = (ISSEThrottledTemplateWriterControl)this.writerControl;
/*     */     } else {
/*  90 */       this.sseControl = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSseEventsPrefix(String sseEventsPrefix) {
/*  96 */     this
/*  97 */       .sseEventsPrefix = (sseEventsPrefix == null || sseEventsPrefix.length() == 0) ? null : sseEventsPrefix.toCharArray();
/*  98 */     this.sseEventsComposedMessageEventName = composeToken(SSE_MESSAGE_EVENT_NAME);
/*     */   }
/*     */   
/*     */   public void setSseEventsFirstID(long sseEventsFirstID) {
/* 102 */     this.sseEventsID = sseEventsFirstID;
/*     */   }
/*     */   
/*     */   public void takeBackLastEventID() {
/* 106 */     if (this.sseEventsID > 0L) {
/* 107 */       this.sseEventsID--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 114 */     this.queried = true;
/* 115 */     return !this.values.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object next() {
/* 122 */     this.queried = true;
/*     */     
/* 124 */     if (this.values.isEmpty()) {
/* 125 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/* 128 */     Object value = this.values.get(0);
/* 129 */     this.values.remove(0);
/* 130 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startIteration() {
/* 136 */     this.inStep = true;
/* 137 */     if (this.sseControl != null) {
/* 138 */       char[] id = composeToken(Long.toString(this.sseEventsID).toCharArray());
/* 139 */       char[] event = this.sseEventsComposedMessageEventName;
/* 140 */       this.sseControl.startEvent(id, event);
/* 141 */       this.sseEventsID++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void finishIteration() {
/* 147 */     finishStep();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasBeenQueried() {
/* 166 */     return this.queried;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 172 */     throw new UnsupportedOperationException("remove() is not supported in Throttled Iterator");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPaused() {
/* 178 */     this.queried = true;
/* 179 */     return (this.values.isEmpty() && !this.feedingComplete);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueBufferExecution() {
/* 184 */     return !this.values.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void feedBuffer(List<Object> newElements) {
/* 189 */     this.values.addAll(newElements);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startHead() {
/* 195 */     this.inStep = true;
/* 196 */     if (this.sseControl != null) {
/* 197 */       char[] id = composeToken(Long.toString(this.sseEventsID).toCharArray());
/* 198 */       char[] event = composeToken(SSE_HEAD_EVENT_NAME);
/* 199 */       this.sseControl.startEvent(id, event);
/* 200 */       this.sseEventsID++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void feedingComplete() {
/* 205 */     this.feedingComplete = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startTail() {
/* 210 */     this.inStep = true;
/* 211 */     if (this.sseControl != null) {
/* 212 */       char[] id = composeToken(Long.toString(this.sseEventsID).toCharArray());
/* 213 */       char[] event = composeToken(SSE_TAIL_EVENT_NAME);
/* 214 */       this.sseControl.startEvent(id, event);
/* 215 */       this.sseEventsID++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void finishStep() {
/* 221 */     if (!this.inStep) {
/*     */       return;
/*     */     }
/* 224 */     this.inStep = false;
/* 225 */     if (this.sseControl != null) {
/*     */       try {
/* 227 */         this.sseControl.endEvent();
/* 228 */       } catch (IOException e) {
/* 229 */         throw new TemplateProcessingException("Cannot signal end of SSE event", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStepOutputFinished() {
/* 236 */     if (this.inStep) {
/* 237 */       return false;
/*     */     }
/* 239 */     if (this.writerControl != null) {
/*     */       try {
/* 241 */         return !this.writerControl.isOverflown();
/* 242 */       } catch (IOException e) {
/* 243 */         throw new TemplateProcessingException("Cannot signal end of SSE event", e);
/*     */       } 
/*     */     }
/*     */     
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] composeToken(char[] token) {
/* 253 */     if (this.sseEventsPrefix == null) {
/* 254 */       return token;
/*     */     }
/* 256 */     char[] result = new char[this.sseEventsPrefix.length + 1 + token.length];
/* 257 */     System.arraycopy(this.sseEventsPrefix, 0, result, 0, this.sseEventsPrefix.length);
/* 258 */     result[this.sseEventsPrefix.length] = '_';
/* 259 */     System.arraycopy(token, 0, result, this.sseEventsPrefix.length + 1, token.length);
/* 260 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\DataDrivenTemplateIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */