/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.model.IModel;
/*    */ import org.thymeleaf.processor.comment.ICommentStructureHandler;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CommentStructureHandler
/*    */   implements ICommentStructureHandler
/*    */ {
/*    */   boolean setContent;
/*    */   CharSequence setContentValue;
/*    */   boolean replaceWithModel;
/*    */   IModel replaceWithModelValue;
/*    */   boolean replaceWithModelProcessable;
/*    */   boolean removeComment;
/*    */   
/*    */   CommentStructureHandler() {
/* 55 */     reset();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setContent(CharSequence content) {
/* 61 */     reset();
/* 62 */     Validate.notNull(content, "Content cannot be null");
/* 63 */     this.setContent = true;
/* 64 */     this.setContentValue = content;
/*    */   }
/*    */ 
/*    */   
/*    */   public void replaceWith(IModel model, boolean processable) {
/* 69 */     reset();
/* 70 */     Validate.notNull(model, "Model cannot be null");
/* 71 */     this.replaceWithModel = true;
/* 72 */     this.replaceWithModelValue = model;
/* 73 */     this.replaceWithModelProcessable = processable;
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeComment() {
/* 78 */     reset();
/* 79 */     this.removeComment = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {
/* 87 */     this.setContent = false;
/* 88 */     this.setContentValue = null;
/*    */     
/* 90 */     this.replaceWithModel = false;
/* 91 */     this.replaceWithModelValue = null;
/* 92 */     this.replaceWithModelProcessable = false;
/*    */     
/* 94 */     this.removeComment = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\CommentStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */