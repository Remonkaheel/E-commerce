package org.thymeleaf.engine;

import java.io.IOException;

public interface ISSEThrottledTemplateWriterControl extends IThrottledTemplateWriterControl {
  void startEvent(char[] paramArrayOfchar1, char[] paramArrayOfchar2);
  
  void endEvent() throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\ISSEThrottledTemplateWriterControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */