/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.processor.element.IElementProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLElementDefinition
/*    */   extends ElementDefinition
/*    */ {
/*    */   final HTMLElementType type;
/*    */   
/*    */   HTMLElementDefinition(HTMLElementName name, HTMLElementType type, Set<IElementProcessor> associatedProcessors) {
/* 39 */     super(name, associatedProcessors);
/* 40 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public HTMLElementType getType() {
/* 45 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\HTMLElementDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */