package org.thymeleaf.engine;

import java.io.IOException;

public interface IThrottledTemplateWriterControl {
  boolean isOverflown() throws IOException;
  
  boolean isStopped() throws IOException;
  
  int getWrittenCount();
  
  int getMaxOverflowSize();
  
  int getOverflowGrowCount();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\IThrottledTemplateWriterControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */