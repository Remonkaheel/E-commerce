/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.processor.element.IElementProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLAttributeDefinition
/*    */   extends AttributeDefinition
/*    */ {
/*    */   final boolean booleanAttribute;
/*    */   
/*    */   HTMLAttributeDefinition(HTMLAttributeName name, boolean booleanAttribute, Set<IElementProcessor> associatedProcessors) {
/* 40 */     super(name, associatedProcessors);
/*    */     
/* 42 */     this.booleanAttribute = booleanAttribute;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isBooleanAttribute() {
/* 48 */     return this.booleanAttribute;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\HTMLAttributeDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */