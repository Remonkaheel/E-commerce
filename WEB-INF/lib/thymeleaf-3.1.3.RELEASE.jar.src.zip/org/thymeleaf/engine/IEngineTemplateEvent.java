package org.thymeleaf.engine;

import org.thymeleaf.model.ITemplateEvent;

interface IEngineTemplateEvent extends ITemplateEvent {
  void beHandled(ITemplateHandler paramITemplateHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\IEngineTemplateEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */