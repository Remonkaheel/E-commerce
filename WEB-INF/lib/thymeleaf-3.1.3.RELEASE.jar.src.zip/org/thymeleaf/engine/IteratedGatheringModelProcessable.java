/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class IteratedGatheringModelProcessable
/*     */   extends AbstractGatheringModelProcessable
/*     */ {
/*     */   private static final String DEFAULT_STATUS_VAR_SUFFIX = "Stat";
/*     */   private final IEngineContext context;
/*     */   private final TemplateMode templateMode;
/*     */   private final String iterVariableName;
/*     */   private final String iterStatusVariableName;
/*     */   private final IterationStatusVar iterStatusVariable;
/*     */   private final Iterator<?> iterator;
/*     */   private final Text precedingWhitespace;
/*     */   private IterationModels iterationModels;
/*     */   private DataDrivenTemplateIterator dataDrivenIterator;
/*     */   private int iter;
/*     */   private int iterOffset;
/*     */   private Model iterModel;
/*     */   
/*     */   enum IterationWhiteSpaceHandling
/*     */   {
/*  49 */     ZERO_ITER, SINGLE_ITER, MULTIPLE_ITER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IteratedGatheringModelProcessable(IEngineConfiguration configuration, ProcessorTemplateHandler processorTemplateHandler, IEngineContext context, TemplateModelController modelController, TemplateFlowController flowController, TemplateModelController.SkipBody gatheredSkipBody, boolean gatheredSkipCloseTag, ProcessorExecutionVars processorExecutionVars, String iterVariableName, String iterStatusVariableName, Object iteratedObject, Text precedingWhitespace) {
/*  78 */     super(configuration, processorTemplateHandler, context, modelController, flowController, gatheredSkipBody, gatheredSkipCloseTag, processorExecutionVars);
/*     */     
/*  80 */     this.context = context;
/*  81 */     this.templateMode = context.getTemplateMode();
/*     */     
/*  83 */     this.iterator = computeIteratedObjectIterator(iteratedObject);
/*     */     
/*  85 */     this.iterVariableName = iterVariableName;
/*     */     
/*  87 */     if (StringUtils.isEmptyOrWhitespace(iterStatusVariableName)) {
/*     */       
/*  89 */       this.iterStatusVariableName = iterVariableName + "Stat";
/*     */     } else {
/*  91 */       this.iterStatusVariableName = iterStatusVariableName;
/*     */     } 
/*     */     
/*  94 */     this.iterStatusVariable = new IterationStatusVar();
/*  95 */     this.iterStatusVariable.index = 0;
/*  96 */     this.iterStatusVariable.size = computeIteratedObjectSize(iteratedObject);
/*     */     
/*  98 */     this.precedingWhitespace = precedingWhitespace;
/*     */     
/* 100 */     if (this.iterator != null && this.iterator instanceof DataDrivenTemplateIterator) {
/* 101 */       this.dataDrivenIterator = (DataDrivenTemplateIterator)this.iterator;
/*     */     } else {
/* 103 */       this.dataDrivenIterator = null;
/*     */     } 
/*     */     
/* 106 */     this.iter = 0;
/* 107 */     this.iterOffset = 0;
/* 108 */     this.iterModel = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProcessorExecutionVars initializeProcessorExecutionVars() {
/* 118 */     return super.initializeProcessorExecutionVars().cloneVars();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process() {
/* 125 */     TemplateFlowController flowController = getFlowController();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     if (flowController != null && flowController.stopProcessing) {
/* 131 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     if (this.iterModel == null && 
/* 140 */       flowController != null && this.dataDrivenIterator != null && this.dataDrivenIterator.isPaused()) {
/* 141 */       flowController.stopProcessing = true;
/* 142 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (this.iterationModels == null) {
/*     */       IterationWhiteSpaceHandling iterationWhiteSpaceHandling;
/*     */ 
/*     */       
/* 155 */       if (this.dataDrivenIterator != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 168 */         if (this.iterator.hasNext()) {
/* 169 */           iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.SINGLE_ITER;
/* 170 */           this.iterStatusVariable.current = this.iterator.next();
/*     */         } else {
/* 172 */           iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.ZERO_ITER;
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 180 */       else if (this.iterator.hasNext()) {
/* 181 */         this.iterStatusVariable.current = this.iterator.next();
/* 182 */         if (this.iterator.hasNext()) {
/* 183 */           iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.MULTIPLE_ITER;
/*     */         } else {
/* 185 */           iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.SINGLE_ITER;
/*     */         } 
/*     */       } else {
/* 188 */         iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.ZERO_ITER;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 198 */       this.iterationModels = computeIterationModels(iterationWhiteSpaceHandling);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (this.iter == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 213 */       if (!this.iterationModels.isEmpty()) {
/*     */         
/* 215 */         boolean iterationIsNew = false;
/*     */         
/* 217 */         if (this.iterModel == null) {
/* 218 */           this.iterModel = this.iterationModels.modelFirst;
/* 219 */           iterationIsNew = true;
/*     */         } 
/*     */         
/* 222 */         if (!processIterationModel(flowController, iterationIsNew))
/*     */         {
/*     */ 
/*     */           
/* 226 */           return false;
/*     */         }
/*     */         
/* 229 */         this.iter++;
/* 230 */         this.iterOffset = 0;
/* 231 */         this.iterModel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 238 */         if (flowController != null && this.dataDrivenIterator != null && this.dataDrivenIterator.isPaused()) {
/* 239 */           flowController.stopProcessing = true;
/* 240 */           return false;
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 250 */         resetGatheredSkipFlagsAfterNoIterations();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     while (this.iterModel != null || this.iterator.hasNext()) {
/*     */       
/* 262 */       boolean iterationIsNew = false;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 267 */       if (this.iterModel == null && this.iterOffset == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 272 */         this.iterStatusVariable.index++;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         this.iterStatusVariable.current = this.iterator.next();
/*     */         
/* 279 */         iterationIsNew = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 286 */       if (this.iterModel == null) {
/* 287 */         this
/* 288 */           .iterModel = this.iterator.hasNext() ? this.iterationModels.modelMiddle : this.iterationModels.modelLast;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 294 */       if (!processIterationModel(flowController, iterationIsNew))
/*     */       {
/*     */ 
/*     */         
/* 298 */         return false;
/*     */       }
/*     */       
/* 301 */       this.iter++;
/* 302 */       this.iterOffset = 0;
/* 303 */       this.iterModel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 310 */       if (flowController != null && this.dataDrivenIterator != null && this.dataDrivenIterator.isPaused()) {
/* 311 */         flowController.stopProcessing = true;
/* 312 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 322 */     this.context.decreaseLevel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean processIterationModel(TemplateFlowController flowController, boolean iterationIsNew) {
/* 336 */     if (iterationIsNew) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 341 */       this.context.increaseLevel();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 346 */       this.context.setVariable(this.iterVariableName, this.iterStatusVariable.current);
/* 347 */       this.context.setVariable(this.iterStatusVariableName, this.iterStatusVariable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 353 */       prepareProcessing();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 358 */       if (this.dataDrivenIterator != null) {
/* 359 */         this.dataDrivenIterator.startIteration();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     this.iterOffset += this.iterModel.process(getProcessorTemplateHandler(), this.iterOffset, flowController);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 373 */     if (flowController != null && (this.iterOffset < this.iterModel.queueSize || flowController.stopProcessing)) {
/* 374 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 381 */     this.context.decreaseLevel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     if (this.dataDrivenIterator != null) {
/* 388 */       this.dataDrivenIterator.finishIteration();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Integer computeIteratedObjectSize(Object iteratedObject) {
/* 411 */     if (iteratedObject == null) {
/* 412 */       return Integer.valueOf(0);
/*     */     }
/* 414 */     if (iteratedObject instanceof Collection) {
/* 415 */       return Integer.valueOf(((Collection)iteratedObject).size());
/*     */     }
/* 417 */     if (iteratedObject instanceof Map) {
/* 418 */       return Integer.valueOf(((Map)iteratedObject).size());
/*     */     }
/* 420 */     if (iteratedObject.getClass().isArray()) {
/* 421 */       return Integer.valueOf(Array.getLength(iteratedObject));
/*     */     }
/* 423 */     if (iteratedObject instanceof Iterable) {
/* 424 */       return null;
/*     */     }
/* 426 */     if (iteratedObject instanceof Iterator) {
/* 427 */       return null;
/*     */     }
/* 429 */     return Integer.valueOf(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Iterator<?> computeIteratedObjectIterator(final Object iteratedObject) {
/* 439 */     if (iteratedObject == null) {
/* 440 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 442 */     if (iteratedObject instanceof Collection) {
/* 443 */       return ((Collection)iteratedObject).iterator();
/*     */     }
/* 445 */     if (iteratedObject instanceof Map) {
/* 446 */       return ((Map)iteratedObject).entrySet().iterator();
/*     */     }
/* 448 */     if (iteratedObject.getClass().isArray()) {
/* 449 */       return new Iterator()
/*     */         {
/* 451 */           protected final Object array = iteratedObject;
/* 452 */           protected final int length = Array.getLength(this.array);
/* 453 */           private int i = 0;
/*     */           
/*     */           public boolean hasNext() {
/* 456 */             return (this.i < this.length);
/*     */           }
/*     */           
/*     */           public Object next() {
/* 460 */             return Array.get(this.array, this.i++);
/*     */           }
/*     */           
/*     */           public void remove() {
/* 464 */             throw new UnsupportedOperationException("Cannot remove from an array iterator");
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 469 */     if (iteratedObject instanceof Iterable) {
/* 470 */       return ((Iterable)iteratedObject).iterator();
/*     */     }
/* 472 */     if (iteratedObject instanceof Iterator) {
/* 473 */       return (Iterator)iteratedObject;
/*     */     }
/* 475 */     if (iteratedObject instanceof Enumeration) {
/* 476 */       return new Iterator()
/*     */         {
/* 478 */           protected final Enumeration<?> enumeration = (Enumeration)iteratedObject;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/* 482 */             return this.enumeration.hasMoreElements();
/*     */           }
/*     */           
/*     */           public Object next() {
/* 486 */             return this.enumeration.nextElement();
/*     */           }
/*     */           
/*     */           public void remove() {
/* 490 */             throw new UnsupportedOperationException("Cannot remove from an Enumeration iterator");
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 495 */     if (iteratedObject instanceof Stream) {
/* 496 */       return ((Stream)iteratedObject).iterator();
/*     */     }
/* 498 */     return Collections.singletonList(iteratedObject).iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IterationModels computeIterationModels(IterationWhiteSpaceHandling iterationWhiteSpaceHandling) {
/* 517 */     if (iterationWhiteSpaceHandling == IterationWhiteSpaceHandling.ZERO_ITER) {
/* 518 */       return IterationModels.EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 525 */     Model innerModel = getInnerModel();
/* 526 */     int gatheredModelSize = innerModel.size();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 532 */     if (iterationWhiteSpaceHandling == IterationWhiteSpaceHandling.SINGLE_ITER) {
/* 533 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 540 */     if (!this.templateMode.isText()) {
/* 541 */       if (this.precedingWhitespace != null) {
/* 542 */         Model modelWithWhiteSpace = new Model(innerModel);
/* 543 */         modelWithWhiteSpace.insert(0, this.precedingWhitespace);
/* 544 */         return new IterationModels(innerModel, modelWithWhiteSpace, modelWithWhiteSpace);
/*     */       } 
/* 546 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 589 */     if (innerModel.size() <= 2)
/*     */     {
/* 591 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */     
/* 594 */     int firstBodyEventCutPoint = -1;
/* 595 */     int lastBodyEventCutPoint = -1;
/*     */     
/* 597 */     ITemplateEvent firstBodyEvent = innerModel.get(1);
/* 598 */     Text firstTextBodyEvent = null;
/* 599 */     if (innerModel.get(0) instanceof OpenElementTag && firstBodyEvent instanceof IText) {
/*     */       
/* 601 */       firstTextBodyEvent = Text.asEngineText((IText)firstBodyEvent);
/*     */       
/* 603 */       int firstTextEventLen = firstTextBodyEvent.length();
/* 604 */       int i = 0;
/*     */       
/* 606 */       while (i < firstTextEventLen && firstBodyEventCutPoint < 0) {
/* 607 */         char c = firstTextBodyEvent.charAt(i);
/* 608 */         if (c == '\n') {
/* 609 */           firstBodyEventCutPoint = i + 1; break;
/*     */         } 
/* 611 */         if (Character.isWhitespace(c)) {
/* 612 */           i++;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 622 */     ITemplateEvent lastBodyEvent = innerModel.get(gatheredModelSize - 2);
/* 623 */     Text lastTextBodyEvent = null;
/* 624 */     if (firstBodyEventCutPoint >= 0 && innerModel
/* 625 */       .get(gatheredModelSize - 1) instanceof CloseElementTag && lastBodyEvent instanceof IText) {
/*     */       
/* 627 */       lastTextBodyEvent = Text.asEngineText((IText)lastBodyEvent);
/*     */       
/* 629 */       int lastTextEventLen = lastTextBodyEvent.length();
/* 630 */       int i = lastTextEventLen - 1;
/*     */       
/* 632 */       while (i >= 0 && lastBodyEventCutPoint < 0) {
/* 633 */         char c = lastTextBodyEvent.charAt(i);
/* 634 */         if (c == '\n') {
/* 635 */           lastBodyEventCutPoint = i + 1; break;
/*     */         } 
/* 637 */         if (Character.isWhitespace(c)) {
/* 638 */           i--;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 652 */     if (firstBodyEventCutPoint < 0 || lastBodyEventCutPoint < 0)
/*     */     {
/* 654 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 662 */     if (firstBodyEvent == lastBodyEvent) {
/*     */ 
/*     */       
/* 665 */       Text textForFirst = new Text(firstTextBodyEvent.subSequence(0, lastBodyEventCutPoint));
/* 666 */       Text textForMiddle = new Text(firstTextBodyEvent.subSequence(firstBodyEventCutPoint, lastBodyEventCutPoint));
/* 667 */       Text textForLast = new Text(firstTextBodyEvent.subSequence(firstBodyEventCutPoint, firstTextBodyEvent.length()));
/*     */       
/* 669 */       Model model1 = new Model(innerModel);
/* 670 */       model1.replace(1, textForFirst);
/*     */       
/* 672 */       Model model2 = new Model(innerModel);
/* 673 */       model2.replace(1, textForMiddle);
/*     */       
/* 675 */       Model model3 = new Model(innerModel);
/* 676 */       model3.replace(1, textForLast);
/*     */       
/* 678 */       return new IterationModels(model1, model2, model3);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 684 */     Model modelFirst = new Model(innerModel);
/* 685 */     Model modelMiddle = new Model(innerModel);
/* 686 */     Model modelLast = new Model(innerModel);
/*     */     
/* 688 */     if (firstBodyEventCutPoint > 0) {
/* 689 */       Text headTextForMiddleAndMax = new Text(firstTextBodyEvent.subSequence(firstBodyEventCutPoint, firstTextBodyEvent.length()));
/* 690 */       modelMiddle.replace(1, headTextForMiddleAndMax);
/* 691 */       modelLast.replace(1, headTextForMiddleAndMax);
/*     */     } 
/*     */     
/* 694 */     if (lastBodyEventCutPoint < lastTextBodyEvent.length()) {
/* 695 */       Text tailTextForFirstAndMiddle = new Text(lastTextBodyEvent.subSequence(0, lastBodyEventCutPoint));
/* 696 */       modelFirst.replace(gatheredModelSize - 2, tailTextForFirstAndMiddle);
/* 697 */       modelMiddle.replace(gatheredModelSize - 2, tailTextForFirstAndMiddle);
/*     */     } 
/*     */     
/* 700 */     return new IterationModels(modelFirst, modelMiddle, modelLast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class IterationModels
/*     */   {
/* 710 */     static IterationModels EMPTY = new IterationModels(null, null, null);
/*     */     
/*     */     final Model modelFirst;
/*     */     
/*     */     final Model modelMiddle;
/*     */     final Model modelLast;
/*     */     final boolean empty;
/*     */     
/*     */     IterationModels(Model modelFirst, Model modelMiddle, Model modelLast) {
/* 719 */       this.modelFirst = modelFirst;
/* 720 */       this.modelMiddle = modelMiddle;
/* 721 */       this.modelLast = modelLast;
/* 722 */       this.empty = (this.modelFirst == null && this.modelMiddle == null && this.modelLast == null);
/*     */     }
/*     */     
/*     */     boolean isEmpty() {
/* 726 */       return this.empty;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\engine\IteratedGatheringModelProcessable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */