package org.thymeleaf.inline;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.model.IComment;
import org.thymeleaf.model.IText;

public interface IInliner {
  String getName();
  
  CharSequence inline(ITemplateContext paramITemplateContext, IText paramIText);
  
  CharSequence inline(ITemplateContext paramITemplateContext, ICDATASection paramICDATASection);
  
  CharSequence inline(ITemplateContext paramITemplateContext, IComment paramIComment);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\inline\IInliner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */