/*     */ package org.thymeleaf.web;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IWebRequest
/*     */ {
/*     */   String getMethod();
/*     */   
/*     */   default boolean isSecure() {
/*  37 */     String scheme = getScheme();
/*  38 */     return (scheme != null && scheme.equalsIgnoreCase("https"));
/*     */   }
/*     */ 
/*     */   
/*     */   String getScheme();
/*     */   
/*     */   String getServerName();
/*     */   
/*     */   Integer getServerPort();
/*     */   
/*     */   default String getRequestPath() {
/*  49 */     String applicationPath = getApplicationPath();
/*  50 */     String pathWithinApplication = getPathWithinApplication();
/*  51 */     return ((applicationPath == null) ? "" : applicationPath) + (
/*  52 */       (pathWithinApplication == null) ? "" : pathWithinApplication);
/*     */   } String getApplicationPath();
/*     */   String getPathWithinApplication();
/*     */   String getQueryString();
/*     */   default String getRequestURL() {
/*  57 */     String scheme = getScheme();
/*  58 */     String serverName = getServerName();
/*  59 */     Integer serverPort = getServerPort();
/*  60 */     String requestPath = getRequestPath();
/*  61 */     String queryString = getQueryString();
/*     */     
/*  63 */     if (scheme == null || serverName == null || serverPort == null) {
/*  64 */       throw new UnsupportedOperationException("Request scheme, server name or port are null in this environment. Cannot compute request URL");
/*     */     }
/*     */ 
/*     */     
/*  68 */     StringBuilder urlBuilder = new StringBuilder();
/*  69 */     urlBuilder.append(scheme).append("://").append(serverName);
/*  70 */     if ((!scheme.equals("http") || serverPort.intValue() != 80) && (
/*  71 */       !scheme.equals("https") || serverPort.intValue() != 443)) {
/*  72 */       urlBuilder.append(':').append(serverPort);
/*     */     }
/*  74 */     urlBuilder.append(requestPath);
/*  75 */     if (queryString != null) {
/*  76 */       urlBuilder.append('?').append(queryString);
/*     */     }
/*  78 */     return urlBuilder.toString();
/*     */   }
/*     */   boolean containsHeader(String paramString);
/*     */   int getHeaderCount();
/*     */   Set<String> getAllHeaderNames();
/*     */   
/*     */   Map<String, String[]> getHeaderMap();
/*     */   
/*     */   default String getHeaderValue(String name) {
/*  87 */     String[] headerValues = getHeaderValues(name);
/*  88 */     return (headerValues == null || headerValues.length == 0) ? null : headerValues[0];
/*     */   }
/*     */   String[] getHeaderValues(String paramString);
/*     */   boolean containsParameter(String paramString);
/*     */   int getParameterCount();
/*     */   Set<String> getAllParameterNames();
/*     */   Map<String, String[]> getParameterMap();
/*     */   
/*     */   default String getParameterValue(String name) {
/*  97 */     String[] parameterValues = getParameterValues(name);
/*  98 */     return (parameterValues == null || parameterValues.length == 0) ? null : parameterValues[0];
/*     */   }
/*     */   String[] getParameterValues(String paramString);
/*     */   boolean containsCookie(String paramString);
/*     */   int getCookieCount();
/*     */   Set<String> getAllCookieNames();
/*     */   
/*     */   Map<String, String[]> getCookieMap();
/*     */   
/*     */   default String getCookieValue(String name) {
/* 108 */     String[] cookieValues = getCookieValues(name);
/* 109 */     return (cookieValues == null || cookieValues.length == 0) ? null : cookieValues[0];
/*     */   }
/*     */   
/*     */   String[] getCookieValues(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\IWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */