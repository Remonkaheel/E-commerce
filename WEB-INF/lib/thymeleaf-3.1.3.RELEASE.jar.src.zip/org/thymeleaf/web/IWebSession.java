package org.thymeleaf.web;

import java.util.Map;
import java.util.Set;

public interface IWebSession {
  boolean exists();
  
  boolean containsAttribute(String paramString);
  
  int getAttributeCount();
  
  Set<String> getAllAttributeNames();
  
  Map<String, Object> getAttributeMap();
  
  Object getAttributeValue(String paramString);
  
  void setAttributeValue(String paramString, Object paramObject);
  
  void removeAttribute(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\IWebSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */