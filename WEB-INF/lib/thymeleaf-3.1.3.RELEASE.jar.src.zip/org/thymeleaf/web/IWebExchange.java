/*    */ package org.thymeleaf.web;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IWebExchange
/*    */ {
/*    */   IWebRequest getRequest();
/*    */   
/*    */   IWebSession getSession();
/*    */   
/*    */   IWebApplication getApplication();
/*    */   
/*    */   default boolean hasSession() {
/* 41 */     IWebSession webSession = getSession();
/* 42 */     return (webSession != null && webSession.exists());
/*    */   }
/*    */   
/*    */   Principal getPrincipal();
/*    */   
/*    */   Locale getLocale();
/*    */   
/*    */   String getContentType();
/*    */   
/*    */   String getCharacterEncoding();
/*    */   
/*    */   boolean containsAttribute(String paramString);
/*    */   
/*    */   int getAttributeCount();
/*    */   
/*    */   Set<String> getAllAttributeNames();
/*    */   
/*    */   Map<String, Object> getAttributeMap();
/*    */   
/*    */   Object getAttributeValue(String paramString);
/*    */   
/*    */   void setAttributeValue(String paramString, Object paramObject);
/*    */   
/*    */   void removeAttribute(String paramString);
/*    */   
/*    */   String transformURL(String paramString);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\IWebExchange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */