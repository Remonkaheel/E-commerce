/*     */ package org.thymeleaf.web.servlet;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Objects;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaxServletWebApplication
/*     */   implements IServletWebApplication
/*     */ {
/*     */   private final ServletContext servletContext;
/*     */   
/*     */   JavaxServletWebApplication(ServletContext servletContext) {
/*  50 */     Validate.notNull(servletContext, "Servlet context cannot be null");
/*  51 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public static JavaxServletWebApplication buildApplication(ServletContext servletContext) {
/*  56 */     return new JavaxServletWebApplication(servletContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IServletWebExchange buildExchange(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
/*  62 */     Validate.notNull(httpServletRequest, "Request cannot be null");
/*  63 */     Validate.notNull(httpServletResponse, "Response cannot be null");
/*  64 */     Validate.isTrue(servletContextMatches(httpServletRequest), "Cannot build an application for a request which servlet context does not match with the application that it is being built for.");
/*     */ 
/*     */ 
/*     */     
/*  68 */     JavaxServletWebRequest request = new JavaxServletWebRequest(httpServletRequest);
/*  69 */     JavaxServletWebSession session = new JavaxServletWebSession(httpServletRequest);
/*     */     
/*  71 */     return new JavaxServletWebExchange(request, session, this, httpServletResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getAttributeNames() {
/*  78 */     return this.servletContext.getAttributeNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAttributeValue(String name) {
/*  83 */     Validate.notNull(name, "Name cannot be null");
/*  84 */     return this.servletContext.getAttribute(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributeValue(String name, Object value) {
/*  89 */     Validate.notNull(name, "Name cannot be null");
/*  90 */     this.servletContext.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getResourceAsStream(String path) {
/*  96 */     Validate.notNull(path, "Path cannot be null");
/*  97 */     return this.servletContext.getResourceAsStream(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getResource(String path) throws MalformedURLException {
/* 102 */     Validate.notNull(path, "Path cannot be null");
/* 103 */     return this.servletContext.getResource(path);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getNativeServletContextObject() {
/* 109 */     return this.servletContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean servletContextMatches(HttpServletRequest httpServletRequest) {
/* 115 */     String servletContextPath = this.servletContext.getContextPath();
/* 116 */     String requestServletContextPath = httpServletRequest.getServletContext().getContextPath();
/* 117 */     return Objects.equals(servletContextPath, requestServletContextPath);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\JavaxServletWebApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */