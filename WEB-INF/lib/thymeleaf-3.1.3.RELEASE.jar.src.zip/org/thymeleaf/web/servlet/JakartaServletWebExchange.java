/*     */ package org.thymeleaf.web.servlet;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.security.Principal;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.thymeleaf.web.IWebApplication;
/*     */ import org.thymeleaf.web.IWebRequest;
/*     */ import org.thymeleaf.web.IWebSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JakartaServletWebExchange
/*     */   implements IServletWebExchange
/*     */ {
/*     */   private final JakartaServletWebRequest webRequest;
/*     */   private final JakartaServletWebSession webSession;
/*     */   private final JakartaServletWebApplication webApplication;
/*     */   private final HttpServletRequest httpServletRequest;
/*     */   private final HttpServletResponse httpServletResponse;
/*     */   
/*     */   JakartaServletWebExchange(JakartaServletWebRequest webRequest, JakartaServletWebSession webSession, JakartaServletWebApplication webApplication, HttpServletResponse httpServletResponse) {
/*  54 */     Validate.notNull(webRequest, "Web Request cannot be null");
/*     */     
/*  56 */     Validate.notNull(webApplication, "Web Application cannot be null");
/*  57 */     Validate.notNull(httpServletResponse, "Response cannot be null");
/*  58 */     this.webRequest = webRequest;
/*  59 */     this.webSession = webSession;
/*  60 */     this.webApplication = webApplication;
/*  61 */     this.httpServletRequest = (HttpServletRequest)this.webRequest.getNativeRequestObject();
/*  62 */     this.httpServletResponse = httpServletResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IServletWebRequest getRequest() {
/*  68 */     return this.webRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public IServletWebSession getSession() {
/*  73 */     return this.webSession;
/*     */   }
/*     */ 
/*     */   
/*     */   public IServletWebApplication getApplication() {
/*  78 */     return this.webApplication;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal getPrincipal() {
/*  84 */     return this.httpServletRequest.getUserPrincipal();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/*  90 */     return this.httpServletResponse.getLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  95 */     return this.httpServletResponse.getContentType();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharacterEncoding() {
/* 100 */     return this.httpServletResponse.getCharacterEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getAttributeNames() {
/* 106 */     return this.httpServletRequest.getAttributeNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAttributeValue(String name) {
/* 111 */     Validate.notNull(name, "Name cannot be null");
/* 112 */     return this.httpServletRequest.getAttribute(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributeValue(String name, Object value) {
/* 117 */     Validate.notNull(name, "Name cannot be null");
/* 118 */     this.httpServletRequest.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String transformURL(String url) {
/* 124 */     return this.httpServletResponse.encodeURL(url);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getNativeRequestObject() {
/* 130 */     return this.httpServletRequest;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getNativeResponseObject() {
/* 135 */     return this.httpServletResponse;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\JakartaServletWebExchange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */