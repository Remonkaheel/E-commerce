/*    */ package org.thymeleaf.web.servlet;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IServletWebSession
/*    */   extends IWebSession
/*    */ {
/*    */   Enumeration<String> getAttributeNames();
/*    */   
/*    */   default boolean containsAttribute(String name) {
/* 46 */     Validate.notNull(name, "Name cannot be null");
/*    */     
/* 48 */     return (getAttributeValue(name) != null);
/*    */   }
/*    */ 
/*    */   
/*    */   default int getAttributeCount() {
/* 53 */     int count = 0;
/* 54 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/* 55 */     while (attributeNamesEnum.hasMoreElements()) {
/* 56 */       attributeNamesEnum.nextElement();
/* 57 */       count++;
/*    */     } 
/* 59 */     return count;
/*    */   }
/*    */ 
/*    */   
/*    */   default Set<String> getAllAttributeNames() {
/* 64 */     Set<String> attributeNames = new LinkedHashSet<>(10);
/* 65 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/* 66 */     while (attributeNamesEnum.hasMoreElements()) {
/* 67 */       attributeNames.add(attributeNamesEnum.nextElement());
/*    */     }
/* 69 */     return Collections.unmodifiableSet(attributeNames);
/*    */   }
/*    */ 
/*    */   
/*    */   default Map<String, Object> getAttributeMap() {
/* 74 */     Map<String, Object> attributeMap = new LinkedHashMap<>(10);
/* 75 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/*    */     
/* 77 */     while (attributeNamesEnum.hasMoreElements()) {
/* 78 */       String attributeName = attributeNamesEnum.nextElement();
/* 79 */       attributeMap.put(attributeName, getAttributeValue(attributeName));
/*    */     } 
/* 81 */     return Collections.unmodifiableMap(attributeMap);
/*    */   }
/*    */ 
/*    */   
/*    */   default void removeAttribute(String name) {
/* 86 */     Validate.notNull(name, "Name cannot be null");
/* 87 */     setAttributeValue(name, null);
/*    */   }
/*    */   
/*    */   Object getNativeSessionObject();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\IServletWebSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */