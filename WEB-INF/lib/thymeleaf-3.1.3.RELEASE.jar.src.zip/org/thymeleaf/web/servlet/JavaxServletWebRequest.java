/*     */ package org.thymeleaf.web.servlet;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JavaxServletWebRequest
/*     */   implements IServletWebRequest
/*     */ {
/*     */   private final HttpServletRequest request;
/*     */   
/*     */   JavaxServletWebRequest(HttpServletRequest request) {
/*  50 */     Validate.notNull(request, "Request cannot be null");
/*  51 */     this.request = request;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethod() {
/*  57 */     return this.request.getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getScheme() {
/*  62 */     return this.request.getScheme();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerName() {
/*  67 */     return this.request.getServerName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getServerPort() {
/*  72 */     return Integer.valueOf(this.request.getServerPort());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextPath() {
/*  77 */     String contextPath = this.request.getContextPath();
/*     */     
/*  79 */     return (contextPath != null && contextPath.length() == 1 && contextPath.charAt(0) == '/') ? "" : contextPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRequestURI() {
/*  84 */     return this.request.getRequestURI();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getQueryString() {
/*  89 */     return this.request.getQueryString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getHeaderNames() {
/*  95 */     return this.request.getHeaderNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getHeaders(String name) {
/* 100 */     return this.request.getHeaders(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderValue(String name) {
/* 105 */     Validate.notNull(name, "Name cannot be null");
/* 106 */     return this.request.getHeader(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String[]> getParameterMap() {
/* 112 */     return this.request.getParameterMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParameterValue(String name) {
/* 117 */     Validate.notNull(name, "Name cannot be null");
/* 118 */     return this.request.getParameter(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 123 */     Validate.notNull(name, "Name cannot be null");
/* 124 */     return this.request.getParameterValues(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsCookie(String name) {
/* 130 */     Validate.notNull(name, "Name cannot be null");
/* 131 */     Cookie[] cookies = this.request.getCookies();
/* 132 */     if (cookies == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     for (int i = 0; i < cookies.length; i++) {
/* 136 */       if (name.equals(cookies[i].getName())) {
/* 137 */         return true;
/*     */       }
/*     */     } 
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCookieCount() {
/* 145 */     Cookie[] cookies = this.request.getCookies();
/* 146 */     return (cookies == null) ? 0 : cookies.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getAllCookieNames() {
/* 151 */     Cookie[] cookies = this.request.getCookies();
/* 152 */     if (cookies == null) {
/* 153 */       return Collections.emptySet();
/*     */     }
/* 155 */     Set<String> cookieNames = new LinkedHashSet<>(3);
/* 156 */     for (int i = 0; i < cookies.length; i++) {
/* 157 */       cookieNames.add(cookies[i].getName());
/*     */     }
/* 159 */     return Collections.unmodifiableSet(cookieNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String[]> getCookieMap() {
/* 164 */     Cookie[] cookies = this.request.getCookies();
/* 165 */     if (cookies == null) {
/* 166 */       return (Map)Collections.emptyMap();
/*     */     }
/* 168 */     Map<String, String[]> cookieMap = (Map)new LinkedHashMap<>(3);
/* 169 */     for (int i = 0; i < cookies.length; i++) {
/* 170 */       String cookieName = cookies[i].getName();
/* 171 */       String cookieValue = cookies[i].getValue();
/* 172 */       if (cookieMap.containsKey(cookieName)) {
/* 173 */         String[] currentCookieValues = cookieMap.get(cookieName);
/* 174 */         String[] newCookieValues = Arrays.<String>copyOf(currentCookieValues, currentCookieValues.length + 1);
/* 175 */         newCookieValues[currentCookieValues.length] = cookieValue;
/* 176 */         cookieMap.put(cookieName, newCookieValues);
/*     */       } else {
/* 178 */         cookieMap.put(cookieName, new String[] { cookieValue });
/*     */       } 
/*     */     } 
/* 181 */     return (Map)Collections.unmodifiableMap((Map)cookieMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getCookieValues(String name) {
/* 186 */     Validate.notNull(name, "Name cannot be null");
/* 187 */     Cookie[] cookies = this.request.getCookies();
/* 188 */     if (cookies == null) {
/* 189 */       return null;
/*     */     }
/* 191 */     String[] cookieValues = null;
/* 192 */     for (int i = 0; i < cookies.length; i++) {
/* 193 */       String cookieName = cookies[i].getName();
/* 194 */       if (name.equals(cookieName)) {
/* 195 */         String cookieValue = cookies[i].getValue();
/* 196 */         if (cookieValues != null) {
/* 197 */           String[] newCookieValues = Arrays.<String>copyOf(cookieValues, cookieValues.length + 1);
/* 198 */           newCookieValues[cookieValues.length] = cookieValue;
/* 199 */           cookieValues = newCookieValues;
/*     */         } else {
/* 201 */           cookieValues = new String[] { cookieValue };
/*     */         } 
/*     */       } 
/*     */     } 
/* 205 */     return cookieValues;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getNativeRequestObject() {
/* 211 */     return this.request;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\JavaxServletWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */