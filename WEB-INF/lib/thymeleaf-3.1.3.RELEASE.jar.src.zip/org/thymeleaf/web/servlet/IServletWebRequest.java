/*     */ package org.thymeleaf.web.servlet;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.thymeleaf.web.IWebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IServletWebRequest
/*     */   extends IWebRequest
/*     */ {
/*     */   String getContextPath();
/*     */   
/*     */   String getRequestURI();
/*     */   
/*     */   default String getApplicationPath() {
/*  47 */     return getContextPath();
/*     */   }
/*     */ 
/*     */   
/*     */   default String getPathWithinApplication() {
/*  52 */     String requestURI = getRequestURI();
/*  53 */     String applicationPath = getApplicationPath();
/*  54 */     if (requestURI == null) {
/*  55 */       return null;
/*     */     }
/*  57 */     if (applicationPath == null || applicationPath.length() == 0) {
/*  58 */       return requestURI;
/*     */     }
/*  60 */     return requestURI.substring(applicationPath.length());
/*     */   }
/*     */ 
/*     */   
/*     */   Enumeration<String> getHeaderNames();
/*     */   
/*     */   Enumeration<String> getHeaders(String paramString);
/*     */   
/*     */   default boolean containsHeader(String name) {
/*  69 */     Validate.notNull(name, "Name cannot be null");
/*     */     
/*  71 */     return (getHeaderValue(name) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   default int getHeaderCount() {
/*  76 */     int count = 0;
/*  77 */     Enumeration<String> headerNamesEnum = getHeaderNames();
/*  78 */     while (headerNamesEnum.hasMoreElements()) {
/*  79 */       headerNamesEnum.nextElement();
/*  80 */       count++;
/*     */     } 
/*  82 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   default Set<String> getAllHeaderNames() {
/*  87 */     Set<String> headerNames = new LinkedHashSet<>(10);
/*  88 */     Enumeration<String> headerNamesEnum = getHeaderNames();
/*  89 */     while (headerNamesEnum.hasMoreElements()) {
/*  90 */       headerNames.add(headerNamesEnum.nextElement());
/*     */     }
/*  92 */     return Collections.unmodifiableSet(headerNames);
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<String, String[]> getHeaderMap() {
/*  97 */     Map<String, String[]> headerMap = (Map)new LinkedHashMap<>(10);
/*  98 */     Enumeration<String> headerNamesEnum = getHeaderNames();
/*     */     
/* 100 */     while (headerNamesEnum.hasMoreElements()) {
/* 101 */       String headerName = headerNamesEnum.nextElement();
/* 102 */       headerMap.put(headerName, getHeaderValues(headerName));
/*     */     } 
/* 104 */     return (Map)Collections.unmodifiableMap((Map)headerMap);
/*     */   }
/*     */ 
/*     */   
/*     */   default String[] getHeaderValues(String name) {
/* 109 */     Validate.notNull(name, "Name cannot be null");
/* 110 */     Enumeration<String> headerValues = getHeaders(name);
/* 111 */     if (headerValues == null || !headerValues.hasMoreElements())
/*     */     {
/* 113 */       return null;
/*     */     }
/* 115 */     List<String> headerValueList = Collections.list(headerValues);
/* 116 */     return headerValueList.<String>toArray(new String[headerValueList.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean containsParameter(String name) {
/* 121 */     Validate.notNull(name, "Name cannot be null");
/*     */     
/* 123 */     return (getParameterValues(name) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   default int getParameterCount() {
/* 128 */     return getParameterMap().size();
/*     */   }
/*     */ 
/*     */   
/*     */   default Set<String> getAllParameterNames() {
/* 133 */     return getParameterMap().keySet();
/*     */   }
/*     */   
/*     */   Object getNativeRequestObject();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\IServletWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */