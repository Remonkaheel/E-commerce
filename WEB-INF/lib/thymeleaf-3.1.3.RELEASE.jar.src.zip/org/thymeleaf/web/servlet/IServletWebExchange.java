/*     */ package org.thymeleaf.web.servlet;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.thymeleaf.web.IWebApplication;
/*     */ import org.thymeleaf.web.IWebExchange;
/*     */ import org.thymeleaf.web.IWebRequest;
/*     */ import org.thymeleaf.web.IWebSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IServletWebExchange
/*     */   extends IWebExchange
/*     */ {
/*     */   default boolean containsAttribute(String name) {
/*  51 */     Validate.notNull(name, "Name cannot be null");
/*     */     
/*  53 */     return (getAttributeValue(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int getAttributeCount() {
/*  63 */     int count = 0;
/*  64 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/*  65 */     while (attributeNamesEnum.hasMoreElements()) {
/*  66 */       attributeNamesEnum.nextElement();
/*  67 */       count++;
/*     */     } 
/*  69 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Set<String> getAllAttributeNames() {
/*  79 */     Set<String> attributeNames = new LinkedHashSet<>(10);
/*  80 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/*  81 */     while (attributeNamesEnum.hasMoreElements()) {
/*  82 */       attributeNames.add(attributeNamesEnum.nextElement());
/*     */     }
/*  84 */     return Collections.unmodifiableSet(attributeNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Map<String, Object> getAttributeMap() {
/*  94 */     Map<String, Object> attributeMap = new LinkedHashMap<>(10);
/*  95 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/*     */     
/*  97 */     while (attributeNamesEnum.hasMoreElements()) {
/*  98 */       String attributeName = attributeNamesEnum.nextElement();
/*  99 */       attributeMap.put(attributeName, getAttributeValue(attributeName));
/*     */     } 
/* 101 */     return Collections.unmodifiableMap(attributeMap);
/*     */   }
/*     */ 
/*     */   
/*     */   default void removeAttribute(String name) {
/* 106 */     Validate.notNull(name, "Name cannot be null");
/* 107 */     setAttributeValue(name, null);
/*     */   }
/*     */   
/*     */   IServletWebRequest getRequest();
/*     */   
/*     */   IServletWebSession getSession();
/*     */   
/*     */   IServletWebApplication getApplication();
/*     */   
/*     */   Enumeration<String> getAttributeNames();
/*     */   
/*     */   Object getNativeRequestObject();
/*     */   
/*     */   Object getNativeResponseObject();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\IServletWebExchange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */