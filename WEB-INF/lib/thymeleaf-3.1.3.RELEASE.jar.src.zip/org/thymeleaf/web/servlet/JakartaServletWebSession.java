/*    */ package org.thymeleaf.web.servlet;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpSession;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JakartaServletWebSession
/*    */   implements IServletWebSession
/*    */ {
/*    */   private final HttpServletRequest request;
/*    */   private HttpSession session;
/*    */   
/*    */   JakartaServletWebSession(HttpServletRequest request) {
/* 46 */     Validate.notNull(request, "Request cannot be null");
/* 47 */     this.request = request;
/* 48 */     this.session = this.request.getSession(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean exists() {
/* 54 */     return (this.session != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<String> getAttributeNames() {
/* 59 */     if (this.session == null) {
/* 60 */       return Collections.emptyEnumeration();
/*    */     }
/* 62 */     return this.session.getAttributeNames();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getAttributeValue(String name) {
/* 67 */     Validate.notNull(name, "Name cannot be null");
/* 68 */     if (this.session == null) {
/* 69 */       return null;
/*    */     }
/* 71 */     return this.session.getAttribute(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAttributeValue(String name, Object value) {
/* 76 */     Validate.notNull(name, "Name cannot be null");
/* 77 */     if (this.session == null)
/*    */     {
/* 79 */       this.session = this.request.getSession(true);
/*    */     }
/* 81 */     this.session.setAttribute(name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getNativeSessionObject() {
/* 87 */     return this.session;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\JakartaServletWebSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */