/*    */ package org.thymeleaf.web.servlet;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebApplication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IServletWebApplication
/*    */   extends IWebApplication
/*    */ {
/*    */   Enumeration<String> getAttributeNames();
/*    */   
/*    */   default boolean containsAttribute(String name) {
/* 47 */     Validate.notNull(name, "Name cannot be null");
/*    */     
/* 49 */     return (getAttributeValue(name) != null);
/*    */   }
/*    */ 
/*    */   
/*    */   default int getAttributeCount() {
/* 54 */     int count = 0;
/* 55 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/* 56 */     while (attributeNamesEnum.hasMoreElements()) {
/* 57 */       attributeNamesEnum.nextElement();
/* 58 */       count++;
/*    */     } 
/* 60 */     return count;
/*    */   }
/*    */ 
/*    */   
/*    */   default Set<String> getAllAttributeNames() {
/* 65 */     Set<String> attributeNames = new LinkedHashSet<>(10);
/* 66 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/* 67 */     while (attributeNamesEnum.hasMoreElements()) {
/* 68 */       attributeNames.add(attributeNamesEnum.nextElement());
/*    */     }
/* 70 */     return Collections.unmodifiableSet(attributeNames);
/*    */   }
/*    */ 
/*    */   
/*    */   default Map<String, Object> getAttributeMap() {
/* 75 */     Map<String, Object> attributeMap = new LinkedHashMap<>(10);
/* 76 */     Enumeration<String> attributeNamesEnum = getAttributeNames();
/*    */     
/* 78 */     while (attributeNamesEnum.hasMoreElements()) {
/* 79 */       String attributeName = attributeNamesEnum.nextElement();
/* 80 */       attributeMap.put(attributeName, getAttributeValue(attributeName));
/*    */     } 
/* 82 */     return Collections.unmodifiableMap(attributeMap);
/*    */   }
/*    */ 
/*    */   
/*    */   default void removeAttribute(String name) {
/* 87 */     Validate.notNull(name, "Name cannot be null");
/* 88 */     setAttributeValue(name, null);
/*    */   }
/*    */ 
/*    */   
/*    */   URL getResource(String paramString) throws MalformedURLException;
/*    */   
/*    */   default boolean resourceExists(String path) {
/* 95 */     Validate.notNull(path, "Path cannot be null");
/*    */     try {
/* 97 */       return (getResource(path) != null);
/* 98 */     } catch (MalformedURLException e) {
/* 99 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   Object getNativeServletContextObject();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\web\servlet\IServletWebApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */