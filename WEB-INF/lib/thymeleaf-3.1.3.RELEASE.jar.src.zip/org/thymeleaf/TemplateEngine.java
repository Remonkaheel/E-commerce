/*      */ package org.thymeleaf;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.RoundingMode;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.thymeleaf.cache.ICacheManager;
/*      */ import org.thymeleaf.cache.StandardCacheManager;
/*      */ import org.thymeleaf.context.IContext;
/*      */ import org.thymeleaf.context.IEngineContextFactory;
/*      */ import org.thymeleaf.context.StandardEngineContextFactory;
/*      */ import org.thymeleaf.dialect.IDialect;
/*      */ import org.thymeleaf.engine.TemplateManager;
/*      */ import org.thymeleaf.engine.ThrottledTemplateProcessor;
/*      */ import org.thymeleaf.exceptions.TemplateEngineException;
/*      */ import org.thymeleaf.exceptions.TemplateOutputException;
/*      */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*      */ import org.thymeleaf.linkbuilder.ILinkBuilder;
/*      */ import org.thymeleaf.linkbuilder.StandardLinkBuilder;
/*      */ import org.thymeleaf.messageresolver.IMessageResolver;
/*      */ import org.thymeleaf.messageresolver.StandardMessageResolver;
/*      */ import org.thymeleaf.standard.StandardDialect;
/*      */ import org.thymeleaf.templateparser.markup.decoupled.IDecoupledTemplateLogicResolver;
/*      */ import org.thymeleaf.templateparser.markup.decoupled.StandardDecoupledTemplateLogicResolver;
/*      */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*      */ import org.thymeleaf.templateresolver.StringTemplateResolver;
/*      */ import org.thymeleaf.util.FastStringWriter;
/*      */ import org.thymeleaf.util.LoggingUtils;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TemplateEngine
/*      */   implements ITemplateEngine
/*      */ {
/*  242 */   public static final String TIMER_LOGGER_NAME = TemplateEngine.class.getName() + ".TIMER";
/*      */   
/*  244 */   private static final Logger logger = LoggerFactory.getLogger(TemplateEngine.class);
/*  245 */   private static final Logger timerLogger = LoggerFactory.getLogger(TIMER_LOGGER_NAME);
/*      */   
/*      */   private static final int NANOS_IN_SECOND = 1000000;
/*      */   
/*      */   private volatile boolean initialized = false;
/*      */   
/*  251 */   private final Set<DialectConfiguration> dialectConfigurations = new LinkedHashSet<>(3);
/*  252 */   private final Set<ITemplateResolver> templateResolvers = new LinkedHashSet<>(3);
/*  253 */   private final Set<IMessageResolver> messageResolvers = new LinkedHashSet<>(3);
/*  254 */   private final Set<ILinkBuilder> linkBuilders = new LinkedHashSet<>(3);
/*  255 */   private ICacheManager cacheManager = null;
/*  256 */   private IEngineContextFactory engineContextFactory = null;
/*  257 */   private IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver = null;
/*      */ 
/*      */   
/*  260 */   private IEngineConfiguration configuration = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateEngine() {
/*  278 */     setCacheManager((ICacheManager)new StandardCacheManager());
/*  279 */     setEngineContextFactory((IEngineContextFactory)new StandardEngineContextFactory());
/*  280 */     setMessageResolver((IMessageResolver)new StandardMessageResolver());
/*  281 */     setLinkBuilder((ILinkBuilder)new StandardLinkBuilder());
/*  282 */     setDecoupledTemplateLogicResolver((IDecoupledTemplateLogicResolver)new StandardDecoupledTemplateLogicResolver());
/*  283 */     setDialect((IDialect)new StandardDialect());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkNotInitialized() {
/*  289 */     if (this.initialized) {
/*  290 */       throw new IllegalStateException("Template engine has already been initialized (probably because it has already been executed or a fully-built Configuration object has been requested from it. At this state, no modifications on its configuration are allowed.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initialize() {
/*  324 */     if (!this.initialized)
/*      */     {
/*  326 */       synchronized (this) {
/*      */         
/*  328 */         if (!this.initialized) {
/*      */           
/*  330 */           logger.debug("[THYMELEAF] INITIALIZING TEMPLATE ENGINE");
/*      */ 
/*      */           
/*  333 */           initializeSpecific();
/*      */ 
/*      */           
/*  336 */           if (this.templateResolvers.isEmpty()) {
/*  337 */             this.templateResolvers.add(new StringTemplateResolver());
/*      */           }
/*      */ 
/*      */           
/*  341 */           this.configuration = new EngineConfiguration(this.templateResolvers, this.messageResolvers, this.linkBuilders, this.dialectConfigurations, this.cacheManager, this.engineContextFactory, this.decoupledTemplateLogicResolver);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  346 */           ((EngineConfiguration)this.configuration).initialize();
/*      */           
/*  348 */           this.initialized = true;
/*      */ 
/*      */           
/*  351 */           ConfigurationPrinterHelper.printConfiguration(this.configuration);
/*      */           
/*  353 */           logger.debug("[THYMELEAF] TEMPLATE ENGINE INITIALIZED");
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeSpecific() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isInitialized() {
/*  403 */     return this.initialized;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IEngineConfiguration getConfiguration() {
/*  410 */     if (!this.initialized) {
/*  411 */       initialize();
/*      */     }
/*  413 */     return this.configuration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Map<String, Set<IDialect>> getDialectsByPrefix() {
/*      */     Set<DialectConfiguration> dialectConfs;
/*  427 */     if (this.initialized) {
/*  428 */       dialectConfs = this.configuration.getDialectConfigurations();
/*      */     } else {
/*  430 */       dialectConfs = this.dialectConfigurations;
/*      */     } 
/*  432 */     Map<String, Set<IDialect>> dialectsByPrefix = new LinkedHashMap<>(3);
/*  433 */     for (DialectConfiguration dialectConfiguration : dialectConfs) {
/*  434 */       String prefix = dialectConfiguration.getPrefix();
/*  435 */       Set<IDialect> dialectsForPrefix = dialectsByPrefix.get(prefix);
/*  436 */       if (dialectsForPrefix == null) {
/*  437 */         dialectsForPrefix = new LinkedHashSet<>(2);
/*  438 */         dialectsByPrefix.put(prefix, dialectsForPrefix);
/*      */       } 
/*  440 */       dialectsForPrefix.add(dialectConfiguration.getDialect());
/*      */     } 
/*  442 */     return Collections.unmodifiableMap(dialectsByPrefix);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<IDialect> getDialects() {
/*  454 */     if (this.initialized) {
/*  455 */       return this.configuration.getDialects();
/*      */     }
/*  457 */     Set<IDialect> dialects = new LinkedHashSet<>(this.dialectConfigurations.size());
/*  458 */     for (DialectConfiguration dialectConfiguration : this.dialectConfigurations) {
/*  459 */       dialects.add(dialectConfiguration.getDialect());
/*      */     }
/*  461 */     return Collections.unmodifiableSet(dialects);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDialect(IDialect dialect) {
/*  482 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  483 */     checkNotInitialized();
/*  484 */     this.dialectConfigurations.clear();
/*  485 */     this.dialectConfigurations.add(new DialectConfiguration(dialect));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDialect(String prefix, IDialect dialect) {
/*  506 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  507 */     checkNotInitialized();
/*  508 */     this.dialectConfigurations.add(new DialectConfiguration(prefix, dialect));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDialect(IDialect dialect) {
/*  529 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  530 */     checkNotInitialized();
/*  531 */     this.dialectConfigurations.add(new DialectConfiguration(dialect));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDialectsByPrefix(Map<String, IDialect> dialects) {
/*  550 */     Validate.notNull(dialects, "Dialect map cannot be null");
/*  551 */     checkNotInitialized();
/*  552 */     this.dialectConfigurations.clear();
/*  553 */     for (Map.Entry<String, IDialect> dialectEntry : dialects.entrySet()) {
/*  554 */       addDialect(dialectEntry.getKey(), dialectEntry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDialects(Set<IDialect> dialects) {
/*  573 */     Validate.notNull(dialects, "Dialect set cannot be null");
/*  574 */     checkNotInitialized();
/*  575 */     this.dialectConfigurations.clear();
/*  576 */     for (IDialect dialect : dialects) {
/*  577 */       addDialect(dialect);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAdditionalDialects(Set<IDialect> additionalDialects) {
/*  600 */     Validate.notNull(additionalDialects, "Dialect set cannot be null");
/*  601 */     checkNotInitialized();
/*  602 */     for (IDialect dialect : additionalDialects) {
/*  603 */       addDialect(dialect);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDialects() {
/*  620 */     checkNotInitialized();
/*  621 */     this.dialectConfigurations.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<ITemplateResolver> getTemplateResolvers() {
/*  634 */     if (this.initialized) {
/*  635 */       return this.configuration.getTemplateResolvers();
/*      */     }
/*  637 */     return Collections.unmodifiableSet(this.templateResolvers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTemplateResolvers(Set<ITemplateResolver> templateResolvers) {
/*  648 */     Validate.notNull(templateResolvers, "Template Resolver set cannot be null");
/*  649 */     checkNotInitialized();
/*  650 */     this.templateResolvers.clear();
/*  651 */     for (ITemplateResolver templateResolver : templateResolvers) {
/*  652 */       addTemplateResolver(templateResolver);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTemplateResolver(ITemplateResolver templateResolver) {
/*  664 */     Validate.notNull(templateResolver, "Template Resolver cannot be null");
/*  665 */     checkNotInitialized();
/*  666 */     this.templateResolvers.add(templateResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTemplateResolver(ITemplateResolver templateResolver) {
/*  681 */     Validate.notNull(templateResolver, "Template Resolver cannot be null");
/*  682 */     checkNotInitialized();
/*  683 */     this.templateResolvers.clear();
/*  684 */     this.templateResolvers.add(templateResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ICacheManager getCacheManager() {
/*  701 */     if (this.initialized) {
/*  702 */       return this.configuration.getCacheManager();
/*      */     }
/*  704 */     return this.cacheManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheManager(ICacheManager cacheManager) {
/*  728 */     checkNotInitialized();
/*  729 */     this.cacheManager = cacheManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final IEngineContextFactory getEngineContextFactory() {
/*  747 */     if (this.initialized) {
/*  748 */       return this.configuration.getEngineContextFactory();
/*      */     }
/*  750 */     return this.engineContextFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEngineContextFactory(IEngineContextFactory engineContextFactory) {
/*  773 */     Validate.notNull(engineContextFactory, "Engine Context Factory cannot be set to null");
/*  774 */     checkNotInitialized();
/*  775 */     this.engineContextFactory = engineContextFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final IDecoupledTemplateLogicResolver getDecoupledTemplateLogicResolver() {
/*  793 */     if (this.initialized) {
/*  794 */       return this.configuration.getDecoupledTemplateLogicResolver();
/*      */     }
/*  796 */     return this.decoupledTemplateLogicResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDecoupledTemplateLogicResolver(IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver) {
/*  819 */     Validate.notNull(decoupledTemplateLogicResolver, "Decoupled Template Logic Resolver cannot be set to null");
/*  820 */     checkNotInitialized();
/*  821 */     this.decoupledTemplateLogicResolver = decoupledTemplateLogicResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<IMessageResolver> getMessageResolvers() {
/*  833 */     if (this.initialized) {
/*  834 */       return this.configuration.getMessageResolvers();
/*      */     }
/*  836 */     return Collections.unmodifiableSet(this.messageResolvers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMessageResolvers(Set<IMessageResolver> messageResolvers) {
/*  853 */     Validate.notNull(messageResolvers, "Message Resolver set cannot be null");
/*  854 */     checkNotInitialized();
/*  855 */     this.messageResolvers.clear();
/*  856 */     for (IMessageResolver messageResolver : messageResolvers) {
/*  857 */       addMessageResolver(messageResolver);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMessageResolver(IMessageResolver messageResolver) {
/*  876 */     Validate.notNull(messageResolver, "Message Resolver cannot be null");
/*  877 */     checkNotInitialized();
/*  878 */     this.messageResolvers.add(messageResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMessageResolver(IMessageResolver messageResolver) {
/*  899 */     Validate.notNull(messageResolver, "Message Resolver cannot be null");
/*  900 */     checkNotInitialized();
/*  901 */     this.messageResolvers.clear();
/*  902 */     this.messageResolvers.add(messageResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<ILinkBuilder> getLinkBuilders() {
/*  914 */     if (this.initialized) {
/*  915 */       return this.configuration.getLinkBuilders();
/*      */     }
/*  917 */     return Collections.unmodifiableSet(this.linkBuilders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinkBuilders(Set<ILinkBuilder> linkBuilders) {
/*  934 */     Validate.notNull(linkBuilders, "Link Builder set cannot be null");
/*  935 */     checkNotInitialized();
/*  936 */     this.linkBuilders.clear();
/*  937 */     for (ILinkBuilder linkBuilder : linkBuilders) {
/*  938 */       addLinkBuilder(linkBuilder);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLinkBuilder(ILinkBuilder linkBuilder) {
/*  957 */     Validate.notNull(linkBuilder, "Link Builder cannot be null");
/*  958 */     checkNotInitialized();
/*  959 */     this.linkBuilders.add(linkBuilder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinkBuilder(ILinkBuilder linkBuilder) {
/*  980 */     Validate.notNull(linkBuilder, "Link Builder cannot be null");
/*  981 */     checkNotInitialized();
/*  982 */     this.linkBuilders.clear();
/*  983 */     this.linkBuilders.add(linkBuilder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearTemplateCache() {
/* 1002 */     if (!this.initialized) {
/* 1003 */       initialize();
/*      */     }
/* 1005 */     this.configuration.getTemplateManager().clearCaches();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearTemplateCacheFor(String templateName) {
/* 1022 */     Validate.notNull(templateName, "Template name cannot be null");
/* 1023 */     if (!this.initialized) {
/* 1024 */       initialize();
/*      */     }
/* 1026 */     this.configuration.getTemplateManager().clearCachesFor(templateName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String threadIndex() {
/* 1046 */     return Thread.currentThread().getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String process(String template, IContext context) {
/* 1053 */     return process(new TemplateSpec(template, null, null, null, null), context);
/*      */   }
/*      */ 
/*      */   
/*      */   public final String process(String template, Set<String> templateSelectors, IContext context) {
/* 1058 */     return process(new TemplateSpec(template, templateSelectors, null, null, null), context);
/*      */   }
/*      */ 
/*      */   
/*      */   public final String process(TemplateSpec templateSpec, IContext context) {
/* 1063 */     FastStringWriter fastStringWriter = new FastStringWriter(100);
/* 1064 */     process(templateSpec, context, (Writer)fastStringWriter);
/* 1065 */     return fastStringWriter.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void process(String template, IContext context, Writer writer) {
/* 1072 */     process(new TemplateSpec(template, null, null, null, null), context, writer);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void process(String template, Set<String> templateSelectors, IContext context, Writer writer) {
/* 1077 */     process(new TemplateSpec(template, templateSelectors, null, null, null), context, writer);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void process(TemplateSpec templateSpec, IContext context, Writer writer) {
/* 1083 */     if (!this.initialized) {
/* 1084 */       initialize();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1089 */       Validate.notNull(templateSpec, "Template Specification cannot be null");
/* 1090 */       Validate.notNull(context, "Context cannot be null");
/* 1091 */       Validate.notNull(writer, "Writer cannot be null");
/*      */ 
/*      */ 
/*      */       
/* 1095 */       if (logger.isTraceEnabled()) {
/* 1096 */         logger.trace("[THYMELEAF][{}] STARTING PROCESS OF TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1097 */               threadIndex(), templateSpec, context.getLocale()
/*      */             });
/*      */       }
/* 1100 */       long startNanos = System.nanoTime();
/*      */       
/* 1102 */       TemplateManager templateManager = this.configuration.getTemplateManager();
/* 1103 */       templateManager.parseAndProcess(templateSpec, context, writer);
/*      */       
/* 1105 */       long endNanos = System.nanoTime();
/*      */       
/* 1107 */       if (logger.isTraceEnabled()) {
/* 1108 */         logger.trace("[THYMELEAF][{}] FINISHED PROCESS AND OUTPUT OF TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1109 */               threadIndex(), templateSpec, context.getLocale()
/*      */             });
/*      */       }
/* 1112 */       if (timerLogger.isTraceEnabled()) {
/* 1113 */         BigDecimal elapsed = BigDecimal.valueOf(endNanos - startNanos);
/* 1114 */         BigDecimal elapsedMs = elapsed.divide(BigDecimal.valueOf(1000000L), RoundingMode.HALF_UP);
/* 1115 */         timerLogger.trace("[THYMELEAF][{}][{}][{}][{}][{}] TEMPLATE \"{}\" WITH LOCALE {} PROCESSED IN {} nanoseconds (approx. {}ms)", new Object[] {
/*      */ 
/*      */               
/* 1118 */               threadIndex(), 
/* 1119 */               LoggingUtils.loggifyTemplateName(templateSpec.getTemplate()), context.getLocale(), elapsed, elapsedMs, templateSpec, context
/* 1120 */               .getLocale(), elapsed, elapsedMs
/*      */             });
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1127 */         writer.flush();
/* 1128 */       } catch (IOException e) {
/* 1129 */         throw new TemplateOutputException("An error happened while flushing output writer", templateSpec.getTemplate(), -1, -1, e);
/*      */       }
/*      */     
/* 1132 */     } catch (TemplateOutputException e) {
/*      */ 
/*      */       
/* 1135 */       logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), (Throwable)e);
/* 1136 */       throw e;
/*      */     }
/* 1138 */     catch (TemplateEngineException e) {
/*      */ 
/*      */       
/* 1141 */       logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), (Throwable)e);
/* 1142 */       throw e;
/*      */     }
/* 1144 */     catch (RuntimeException e) {
/*      */ 
/*      */       
/* 1147 */       logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1148 */       throw new TemplateProcessingException("Exception processing template", templateSpec.toString(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final IThrottledTemplateProcessor processThrottled(String template, IContext context) {
/* 1158 */     return processThrottled(new TemplateSpec(template, null, null, null, null), context);
/*      */   }
/*      */ 
/*      */   
/*      */   public final IThrottledTemplateProcessor processThrottled(String template, Set<String> templateSelectors, IContext context) {
/* 1163 */     return processThrottled(new TemplateSpec(template, templateSelectors, null, null, null), context);
/*      */   }
/*      */ 
/*      */   
/*      */   public final IThrottledTemplateProcessor processThrottled(TemplateSpec templateSpec, IContext context) {
/*      */     ThrottledTemplateProcessor throttledTemplateProcessor;
/* 1169 */     if (!this.initialized) {
/* 1170 */       initialize();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1176 */       Validate.notNull(templateSpec, "Template Specification cannot be null");
/* 1177 */       Validate.notNull(context, "Context cannot be null");
/*      */ 
/*      */ 
/*      */       
/* 1181 */       if (logger.isTraceEnabled()) {
/* 1182 */         logger.trace("[THYMELEAF][{}] STARTING PREPARATION OF THROTTLED TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1183 */               threadIndex(), templateSpec, context.getLocale()
/*      */             });
/*      */       }
/* 1186 */       long startNanos = System.nanoTime();
/*      */       
/* 1188 */       TemplateManager templateManager = this.configuration.getTemplateManager();
/* 1189 */       throttledTemplateProcessor = templateManager.parseAndProcessThrottled(templateSpec, context);
/*      */       
/* 1191 */       long endNanos = System.nanoTime();
/*      */       
/* 1193 */       if (logger.isTraceEnabled()) {
/* 1194 */         logger.trace("[THYMELEAF][{}] FINISHED PREPARATION OF THROTTLED TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1195 */               threadIndex(), templateSpec, context.getLocale()
/*      */             });
/*      */       }
/* 1198 */       if (timerLogger.isTraceEnabled()) {
/* 1199 */         BigDecimal elapsed = BigDecimal.valueOf(endNanos - startNanos);
/* 1200 */         BigDecimal elapsedMs = elapsed.divide(BigDecimal.valueOf(1000000L), RoundingMode.HALF_UP);
/* 1201 */         timerLogger.trace("[THYMELEAF][{}][{}][{}][{}][{}] TEMPLATE \"{}\" WITH LOCALE {} PREPARED FOR THROTTLED PROCESSING IN {} nanoseconds (approx. {}ms)", new Object[] {
/*      */ 
/*      */               
/* 1204 */               threadIndex(), 
/* 1205 */               LoggingUtils.loggifyTemplateName(templateSpec.getTemplate()), context.getLocale(), elapsed, elapsedMs, templateSpec, context
/* 1206 */               .getLocale(), elapsed, elapsedMs
/*      */             });
/*      */       } 
/* 1209 */     } catch (TemplateOutputException e) {
/*      */ 
/*      */       
/* 1212 */       logger.error(String.format("[THYMELEAF][%s] Exception preparing throttled template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), (Throwable)e);
/* 1213 */       throw e;
/*      */     }
/* 1215 */     catch (TemplateEngineException e) {
/*      */ 
/*      */       
/* 1218 */       logger.error(String.format("[THYMELEAF][%s] Exception preparing throttled template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), (Throwable)e);
/* 1219 */       throw e;
/*      */     }
/* 1221 */     catch (RuntimeException e) {
/*      */ 
/*      */       
/* 1224 */       logger.error(String.format("[THYMELEAF][%s] Exception preparing throttled template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1225 */       throw new TemplateProcessingException("Exception preparing throttled template", templateSpec.toString(), e);
/*      */     } 
/*      */ 
/*      */     
/* 1229 */     return (IThrottledTemplateProcessor)throttledTemplateProcessor;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\TemplateEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */