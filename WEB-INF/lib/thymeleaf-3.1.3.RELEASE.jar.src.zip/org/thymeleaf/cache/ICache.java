package org.thymeleaf.cache;

import java.util.Set;

public interface ICache<K, V> {
  void put(K paramK, V paramV);
  
  V get(K paramK);
  
  V get(K paramK, ICacheEntryValidityChecker<? super K, ? super V> paramICacheEntryValidityChecker);
  
  void clear();
  
  void clearKey(K paramK);
  
  Set<K> keySet();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\cache\ICache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */