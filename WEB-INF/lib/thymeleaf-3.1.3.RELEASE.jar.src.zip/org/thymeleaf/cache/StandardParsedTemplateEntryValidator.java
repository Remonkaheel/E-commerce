/*    */ package org.thymeleaf.cache;
/*    */ 
/*    */ import org.thymeleaf.engine.TemplateModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardParsedTemplateEntryValidator
/*    */   implements ICacheEntryValidityChecker<TemplateCacheKey, TemplateModel>
/*    */ {
/*    */   private static final long serialVersionUID = -185355204140990247L;
/*    */   
/*    */   public boolean checkIsValueStillValid(TemplateCacheKey key, TemplateModel value, long entryCreationTimestamp) {
/* 44 */     return value.getTemplateData().getValidity().isCacheStillValid();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\cache\StandardParsedTemplateEntryValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */