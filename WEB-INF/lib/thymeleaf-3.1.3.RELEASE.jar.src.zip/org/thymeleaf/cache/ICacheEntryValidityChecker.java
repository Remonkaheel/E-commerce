package org.thymeleaf.cache;

import java.io.Serializable;

public interface ICacheEntryValidityChecker<K, V> extends Serializable {
  boolean checkIsValueStillValid(K paramK, V paramV, long paramLong);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\cache\ICacheEntryValidityChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */