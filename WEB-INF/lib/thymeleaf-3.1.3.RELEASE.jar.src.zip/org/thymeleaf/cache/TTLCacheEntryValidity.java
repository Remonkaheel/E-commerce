/*    */ package org.thymeleaf.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TTLCacheEntryValidity
/*    */   implements ICacheEntryValidity
/*    */ {
/*    */   private final long cacheTTLMs;
/*    */   private final long creationTimeInMillis;
/*    */   
/*    */   public TTLCacheEntryValidity(long cacheTTLMs) {
/* 50 */     this.cacheTTLMs = cacheTTLMs;
/* 51 */     this.creationTimeInMillis = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getCacheTTLMs() {
/* 64 */     return this.cacheTTLMs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCacheable() {
/* 77 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCacheStillValid() {
/* 92 */     long currentTimeInMillis = System.currentTimeMillis();
/* 93 */     return (currentTimeInMillis < this.creationTimeInMillis + this.cacheTTLMs);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\cache\TTLCacheEntryValidity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */