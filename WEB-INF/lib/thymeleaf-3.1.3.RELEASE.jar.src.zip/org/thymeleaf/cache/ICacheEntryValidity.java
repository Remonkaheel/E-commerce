package org.thymeleaf.cache;

public interface ICacheEntryValidity {
  boolean isCacheable();
  
  boolean isCacheStillValid();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\cache\ICacheEntryValidity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */