package org.thymeleaf.cache;

import java.util.List;
import org.thymeleaf.engine.TemplateModel;

public interface ICacheManager {
  ICache<TemplateCacheKey, TemplateModel> getTemplateCache();
  
  ICache<ExpressionCacheKey, Object> getExpressionCache();
  
  <K, V> ICache<K, V> getSpecificCache(String paramString);
  
  List<String> getAllSpecificCacheNames();
  
  void clearAllCaches();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\cache\ICacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */