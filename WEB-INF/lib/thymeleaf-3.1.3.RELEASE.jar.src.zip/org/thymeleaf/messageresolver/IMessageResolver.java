package org.thymeleaf.messageresolver;

import org.thymeleaf.context.ITemplateContext;

public interface IMessageResolver {
  String getName();
  
  Integer getOrder();
  
  String resolveMessage(ITemplateContext paramITemplateContext, Class<?> paramClass, String paramString, Object[] paramArrayOfObject);
  
  String createAbsentMessageRepresentation(ITemplateContext paramITemplateContext, Class<?> paramClass, String paramString, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\messageresolver\IMessageResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */