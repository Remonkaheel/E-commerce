package org.thymeleaf.templateresolver;

import java.util.Map;
import org.thymeleaf.IEngineConfiguration;

public interface ITemplateResolver {
  String getName();
  
  Integer getOrder();
  
  TemplateResolution resolveTemplate(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Map<String, Object> paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresolver\ITemplateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */