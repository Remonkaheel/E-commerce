/*      */ package org.thymeleaf.templateresolver;
/*      */ 
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.thymeleaf.IEngineConfiguration;
/*      */ import org.thymeleaf.cache.AlwaysValidCacheEntryValidity;
/*      */ import org.thymeleaf.cache.ICacheEntryValidity;
/*      */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*      */ import org.thymeleaf.cache.TTLCacheEntryValidity;
/*      */ import org.thymeleaf.templatemode.TemplateMode;
/*      */ import org.thymeleaf.templateresource.ITemplateResource;
/*      */ import org.thymeleaf.util.ContentTypeUtils;
/*      */ import org.thymeleaf.util.PatternSpec;
/*      */ import org.thymeleaf.util.StringUtils;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractConfigurableTemplateResolver
/*      */   extends AbstractTemplateResolver
/*      */ {
/*   69 */   public static final TemplateMode DEFAULT_TEMPLATE_MODE = TemplateMode.HTML;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean DEFAULT_CACHEABLE = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   84 */   public static final Long DEFAULT_CACHE_TTL_MS = null;
/*      */ 
/*      */   
/*   87 */   private String prefix = null;
/*   88 */   private String suffix = null;
/*      */   private boolean forceSuffix = false;
/*   90 */   private String characterEncoding = null;
/*   91 */   private TemplateMode templateMode = DEFAULT_TEMPLATE_MODE;
/*      */   private boolean forceTemplateMode = false;
/*      */   private boolean cacheable = true;
/*   94 */   private Long cacheTTLMs = DEFAULT_CACHE_TTL_MS;
/*      */   
/*   96 */   private final HashMap<String, String> templateAliases = new HashMap<>(8);
/*      */   
/*   98 */   private final PatternSpec xmlTemplateModePatternSpec = new PatternSpec();
/*   99 */   private final PatternSpec htmlTemplateModePatternSpec = new PatternSpec();
/*  100 */   private final PatternSpec textTemplateModePatternSpec = new PatternSpec();
/*  101 */   private final PatternSpec javaScriptTemplateModePatternSpec = new PatternSpec();
/*  102 */   private final PatternSpec cssTemplateModePatternSpec = new PatternSpec();
/*  103 */   private final PatternSpec rawTemplateModePatternSpec = new PatternSpec();
/*      */   
/*  105 */   private final PatternSpec cacheablePatternSpec = new PatternSpec();
/*  106 */   private final PatternSpec nonCacheablePatternSpec = new PatternSpec();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getPrefix() {
/*  129 */     return this.prefix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setPrefix(String prefix) {
/*  142 */     this.prefix = prefix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getSuffix() {
/*  162 */     return this.suffix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSuffix(String suffix) {
/*  182 */     this.suffix = suffix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean getForceSuffix() {
/*  203 */     return this.forceSuffix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setForceSuffix(boolean forceSuffix) {
/*  224 */     this.forceSuffix = forceSuffix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getCharacterEncoding() {
/*  237 */     return this.characterEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCharacterEncoding(String characterEncoding) {
/*  249 */     this.characterEncoding = characterEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TemplateMode getTemplateMode() {
/*  274 */     return this.templateMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTemplateMode(TemplateMode templateMode) {
/*  298 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/*  299 */     this.templateMode = templateMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTemplateMode(String templateMode) {
/*  329 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/*  330 */     this.templateMode = TemplateMode.parse(templateMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean getForceTemplateMode() {
/*  352 */     return this.forceTemplateMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setForceTemplateMode(boolean forceTemplateMode) {
/*  374 */     this.forceTemplateMode = forceTemplateMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isCacheable() {
/*  392 */     return this.cacheable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCacheable(boolean cacheable) {
/*  409 */     this.cacheable = cacheable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Long getCacheTTLMs() {
/*  427 */     return this.cacheTTLMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCacheTTLMs(Long cacheTTLMs) {
/*  444 */     this.cacheTTLMs = cacheTTLMs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Map<String, String> getTemplateAliases() {
/*  463 */     return Collections.unmodifiableMap(this.templateAliases);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTemplateAliases(Map<String, String> templateAliases) {
/*  482 */     if (templateAliases != null) {
/*  483 */       this.templateAliases.putAll(templateAliases);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addTemplateAlias(String alias, String templateName) {
/*  497 */     Validate.notNull(alias, "Alias cannot be null");
/*  498 */     Validate.notNull(templateName, "Template name cannot be null");
/*  499 */     this.templateAliases.put(alias, templateName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void clearTemplateAliases() {
/*  509 */     this.templateAliases.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getXmlTemplateModePatternSpec() {
/*  525 */     return this.xmlTemplateModePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getXmlTemplateModePatterns() {
/*  540 */     return this.xmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setXmlTemplateModePatterns(Set<String> newXmlTemplateModePatterns) {
/*  555 */     this.xmlTemplateModePatternSpec.setPatterns(newXmlTemplateModePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getHtmlTemplateModePatternSpec() {
/*  571 */     return this.htmlTemplateModePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getHtmlTemplateModePatterns() {
/*  587 */     return this.htmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setHtmlTemplateModePatterns(Set<String> newHtmlTemplateModePatterns) {
/*  603 */     this.htmlTemplateModePatternSpec.setPatterns(newHtmlTemplateModePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getJavaScriptTemplateModePatternSpec() {
/*  619 */     return this.javaScriptTemplateModePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getJavaScriptTemplateModePatterns() {
/*  635 */     return this.javaScriptTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setJavaScriptTemplateModePatterns(Set<String> newJavaScriptTemplateModePatterns) {
/*  651 */     this.javaScriptTemplateModePatternSpec.setPatterns(newJavaScriptTemplateModePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getCSSTemplateModePatternSpec() {
/*  667 */     return this.cssTemplateModePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getCSSTemplateModePatterns() {
/*  683 */     return this.cssTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCSSTemplateModePatterns(Set<String> newCSSTemplateModePatterns) {
/*  699 */     this.cssTemplateModePatternSpec.setPatterns(newCSSTemplateModePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getRawTemplateModePatternSpec() {
/*  715 */     return this.rawTemplateModePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getRawTemplateModePatterns() {
/*  731 */     return this.rawTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setRawTemplateModePatterns(Set<String> newRawTemplateModePatterns) {
/*  747 */     this.rawTemplateModePatternSpec.setPatterns(newRawTemplateModePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getTextTemplateModePatternSpec() {
/*  763 */     return this.textTemplateModePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getTextTemplateModePatterns() {
/*  779 */     return this.textTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTextTemplateModePatterns(Set<String> newTextTemplateModePatterns) {
/*  795 */     this.textTemplateModePatternSpec.setPatterns(newTextTemplateModePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getCacheablePatternSpec() {
/*  816 */     return this.cacheablePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getCacheablePatterns() {
/*  837 */     return this.cacheablePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCacheablePatterns(Set<String> cacheablePatterns) {
/*  858 */     this.cacheablePatternSpec.setPatterns(cacheablePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PatternSpec getNonCacheablePatternSpec() {
/*  880 */     return this.nonCacheablePatternSpec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> getNonCacheablePatterns() {
/*  901 */     return this.nonCacheablePatternSpec.getPatterns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setNonCacheablePatterns(Set<String> nonCacheablePatterns) {
/*  922 */     this.nonCacheablePatternSpec.setPatterns(nonCacheablePatterns);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String computeResourceName(IEngineConfiguration configuration, String ownerTemplate, String template, String prefix, String suffix, boolean forceSuffix, Map<String, String> templateAliases, Map<String, Object> templateResolutionAttributes) {
/*  961 */     Validate.notNull(template, "Template name cannot be null");
/*      */     
/*  963 */     String unaliasedName = templateAliases.get(template);
/*  964 */     if (unaliasedName == null) {
/*  965 */       unaliasedName = template;
/*      */     }
/*      */     
/*  968 */     boolean hasPrefix = !StringUtils.isEmptyOrWhitespace(prefix);
/*  969 */     boolean hasSuffix = !StringUtils.isEmptyOrWhitespace(suffix);
/*      */ 
/*      */     
/*  972 */     boolean shouldApplySuffix = (hasSuffix && (forceSuffix || !ContentTypeUtils.hasRecognizedFileExtension(unaliasedName)));
/*      */     
/*  974 */     if (!hasPrefix && !shouldApplySuffix) {
/*  975 */       return unaliasedName;
/*      */     }
/*      */     
/*  978 */     if (!hasPrefix) {
/*  979 */       return unaliasedName + suffix;
/*      */     }
/*      */     
/*  982 */     if (!shouldApplySuffix) {
/*  983 */       return prefix + unaliasedName;
/*      */     }
/*      */ 
/*      */     
/*  987 */     return prefix + unaliasedName + suffix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TemplateMode computeTemplateMode(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 1000 */     if (this.xmlTemplateModePatternSpec.matches(template)) {
/* 1001 */       return TemplateMode.XML;
/*      */     }
/* 1003 */     if (this.htmlTemplateModePatternSpec.matches(template)) {
/* 1004 */       return TemplateMode.HTML;
/*      */     }
/* 1006 */     if (this.textTemplateModePatternSpec.matches(template)) {
/* 1007 */       return TemplateMode.TEXT;
/*      */     }
/* 1009 */     if (this.javaScriptTemplateModePatternSpec.matches(template)) {
/* 1010 */       return TemplateMode.JAVASCRIPT;
/*      */     }
/* 1012 */     if (this.cssTemplateModePatternSpec.matches(template)) {
/* 1013 */       return TemplateMode.CSS;
/*      */     }
/* 1015 */     if (this.rawTemplateModePatternSpec.matches(template)) {
/* 1016 */       return TemplateMode.RAW;
/*      */     }
/*      */     
/* 1019 */     if (!this.forceTemplateMode) {
/*      */ 
/*      */       
/* 1022 */       String templateResourceName = computeResourceName(configuration, ownerTemplate, template, this.prefix, this.suffix, this.forceSuffix, this.templateAliases, templateResolutionAttributes);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1028 */       TemplateMode autoResolvedTemplateMode = ContentTypeUtils.computeTemplateModeForTemplateName(templateResourceName);
/* 1029 */       if (autoResolvedTemplateMode != null) {
/* 1030 */         return autoResolvedTemplateMode;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1035 */     return getTemplateMode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 1045 */     if (this.cacheablePatternSpec.matches(template)) {
/* 1046 */       if (this.cacheTTLMs != null) {
/* 1047 */         return (ICacheEntryValidity)new TTLCacheEntryValidity(this.cacheTTLMs.longValue());
/*      */       }
/* 1049 */       return (ICacheEntryValidity)AlwaysValidCacheEntryValidity.INSTANCE;
/*      */     } 
/* 1051 */     if (this.nonCacheablePatternSpec.matches(template)) {
/* 1052 */       return (ICacheEntryValidity)NonCacheableCacheEntryValidity.INSTANCE;
/*      */     }
/*      */     
/* 1055 */     if (isCacheable()) {
/* 1056 */       if (this.cacheTTLMs != null) {
/* 1057 */         return (ICacheEntryValidity)new TTLCacheEntryValidity(this.cacheTTLMs.longValue());
/*      */       }
/* 1059 */       return (ICacheEntryValidity)AlwaysValidCacheEntryValidity.INSTANCE;
/*      */     } 
/* 1061 */     return (ICacheEntryValidity)NonCacheableCacheEntryValidity.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 1071 */     String resourceName = computeResourceName(configuration, ownerTemplate, template, this.prefix, this.suffix, this.forceSuffix, this.templateAliases, templateResolutionAttributes);
/* 1072 */     return computeTemplateResource(configuration, ownerTemplate, template, resourceName, this.characterEncoding, templateResolutionAttributes);
/*      */   }
/*      */   
/*      */   protected abstract ITemplateResource computeTemplateResource(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, String paramString3, String paramString4, Map<String, Object> paramMap);
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresolver\AbstractConfigurableTemplateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */