/*     */ package org.thymeleaf.templateresolver;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.cache.AlwaysValidCacheEntryValidity;
/*     */ import org.thymeleaf.cache.ICacheEntryValidity;
/*     */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*     */ import org.thymeleaf.cache.TTLCacheEntryValidity;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.templateresource.StringTemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringTemplateResolver
/*     */   extends AbstractTemplateResolver
/*     */ {
/*  69 */   public static final TemplateMode DEFAULT_TEMPLATE_MODE = TemplateMode.HTML;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean DEFAULT_CACHEABLE = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final Long DEFAULT_CACHE_TTL_MS = null;
/*     */ 
/*     */ 
/*     */   
/*  88 */   private TemplateMode templateMode = DEFAULT_TEMPLATE_MODE;
/*     */   private boolean cacheable = false;
/*  90 */   private Long cacheTTLMs = DEFAULT_CACHE_TTL_MS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TemplateMode getTemplateMode() {
/* 117 */     return this.templateMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTemplateMode(TemplateMode templateMode) {
/* 129 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/* 130 */     this.templateMode = templateMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTemplateMode(String templateMode) {
/* 148 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/* 149 */     this.templateMode = TemplateMode.parse(templateMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCacheable() {
/* 162 */     return this.cacheable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCacheable(boolean cacheable) {
/* 174 */     this.cacheable = cacheable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Long getCacheTTLMs() {
/* 192 */     return this.cacheTTLMs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCacheTTLMs(Long cacheTTLMs) {
/* 209 */     this.cacheTTLMs = cacheTTLMs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseDecoupledLogic(boolean useDecoupledLogic) {
/* 216 */     if (useDecoupledLogic) {
/* 217 */       throw new ConfigurationException("The 'useDecoupledLogic' flag is not allowed for String template resolution");
/*     */     }
/* 219 */     super.setUseDecoupledLogic(useDecoupledLogic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 227 */     return (ITemplateResource)new StringTemplateResource(template);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TemplateMode computeTemplateMode(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 233 */     return this.templateMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 240 */     if (isCacheable()) {
/* 241 */       if (this.cacheTTLMs != null) {
/* 242 */         return (ICacheEntryValidity)new TTLCacheEntryValidity(this.cacheTTLMs.longValue());
/*     */       }
/* 244 */       return (ICacheEntryValidity)AlwaysValidCacheEntryValidity.INSTANCE;
/*     */     } 
/* 246 */     return (ICacheEntryValidity)NonCacheableCacheEntryValidity.INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresolver\StringTemplateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */