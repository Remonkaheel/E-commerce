/*    */ package org.thymeleaf.templateresolver;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.cache.ICacheEntryValidity;
/*    */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*    */ import org.thymeleaf.templateresource.ITemplateResource;
/*    */ import org.thymeleaf.templateresource.UrlTemplateResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrlTemplateResolver
/*    */   extends AbstractConfigurableTemplateResolver
/*    */ {
/* 48 */   private static final Pattern JSESSIONID_PATTERN = Pattern.compile("(.*?);jsessionid(.*?)");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding, Map<String, Object> templateResolutionAttributes) {
/*    */     try {
/* 60 */       return (ITemplateResource)new UrlTemplateResource(resourceName, characterEncoding);
/* 61 */     } catch (MalformedURLException ignored) {
/* 62 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes) {
/* 77 */     if (JSESSIONID_PATTERN.matcher(template.toLowerCase()).matches()) {
/* 78 */       return (ICacheEntryValidity)NonCacheableCacheEntryValidity.INSTANCE;
/*    */     }
/* 80 */     return super.computeValidity(configuration, ownerTemplate, template, templateResolutionAttributes);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresolver\UrlTemplateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */