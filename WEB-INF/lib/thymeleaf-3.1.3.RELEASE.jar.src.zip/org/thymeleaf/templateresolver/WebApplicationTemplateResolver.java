/*    */ package org.thymeleaf.templateresolver;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.templateresource.ITemplateResource;
/*    */ import org.thymeleaf.templateresource.WebApplicationTemplateResource;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebApplication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebApplicationTemplateResolver
/*    */   extends AbstractConfigurableTemplateResolver
/*    */ {
/*    */   private final IWebApplication webApplication;
/*    */   
/*    */   public WebApplicationTemplateResolver(IWebApplication webApplication) {
/* 50 */     Validate.notNull(webApplication, "Web Application object cannot be null");
/* 51 */     this.webApplication = webApplication;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding, Map<String, Object> templateResolutionAttributes) {
/* 58 */     return (ITemplateResource)new WebApplicationTemplateResource(this.webApplication, resourceName, characterEncoding);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\templateresolver\WebApplicationTemplateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */