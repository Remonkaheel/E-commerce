/*    */ package org.thymeleaf.preprocessor;
/*    */ 
/*    */ import org.thymeleaf.engine.ITemplateHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PreProcessor
/*    */   implements IPreProcessor
/*    */ {
/*    */   private final TemplateMode templateMode;
/*    */   private final Class<? extends ITemplateHandler> handlerClass;
/*    */   private final int precedence;
/*    */   
/*    */   public PreProcessor(TemplateMode templateMode, Class<? extends ITemplateHandler> handlerClass, int precedence) {
/* 52 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 53 */     Validate.notNull(handlerClass, "Handler class cannot be null");
/*    */     
/* 55 */     this.templateMode = templateMode;
/* 56 */     this.handlerClass = handlerClass;
/* 57 */     this.precedence = precedence;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final TemplateMode getTemplateMode() {
/* 63 */     return this.templateMode;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getPrecedence() {
/* 68 */     return this.precedence;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Class<? extends ITemplateHandler> getHandlerClass() {
/* 73 */     return this.handlerClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\preprocessor\PreProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */