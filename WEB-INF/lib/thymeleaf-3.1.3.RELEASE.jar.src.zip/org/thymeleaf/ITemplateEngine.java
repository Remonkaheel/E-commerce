package org.thymeleaf;

import java.io.Writer;
import java.util.Set;
import org.thymeleaf.context.IContext;

public interface ITemplateEngine {
  IEngineConfiguration getConfiguration();
  
  String process(String paramString, IContext paramIContext);
  
  String process(String paramString, Set<String> paramSet, IContext paramIContext);
  
  String process(TemplateSpec paramTemplateSpec, IContext paramIContext);
  
  void process(String paramString, IContext paramIContext, Writer paramWriter);
  
  void process(String paramString, Set<String> paramSet, IContext paramIContext, Writer paramWriter);
  
  void process(TemplateSpec paramTemplateSpec, IContext paramIContext, Writer paramWriter);
  
  IThrottledTemplateProcessor processThrottled(String paramString, IContext paramIContext);
  
  IThrottledTemplateProcessor processThrottled(String paramString, Set<String> paramSet, IContext paramIContext);
  
  IThrottledTemplateProcessor processThrottled(TemplateSpec paramTemplateSpec, IContext paramIContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\ITemplateEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */