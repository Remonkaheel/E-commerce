package org.thymeleaf.dialect;

import org.thymeleaf.expression.IExpressionObjectFactory;

public interface IExpressionObjectDialect extends IDialect {
  IExpressionObjectFactory getExpressionObjectFactory();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\IExpressionObjectDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */