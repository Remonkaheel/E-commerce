package org.thymeleaf.dialect;

import java.util.Set;
import org.thymeleaf.postprocessor.IPostProcessor;

public interface IPostProcessorDialect extends IDialect {
  int getDialectPostProcessorPrecedence();
  
  Set<IPostProcessor> getPostProcessors();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\IPostProcessorDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */