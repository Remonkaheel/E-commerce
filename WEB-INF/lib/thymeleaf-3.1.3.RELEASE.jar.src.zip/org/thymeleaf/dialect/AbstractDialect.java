/*    */ package org.thymeleaf.dialect;
/*    */ 
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractDialect
/*    */   implements IDialect
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   protected AbstractDialect(String name) {
/* 47 */     Validate.notNull(name, "Dialect name cannot be null");
/* 48 */     this.name = name;
/*    */   }
/*    */   
/*    */   public final String getName() {
/* 52 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\AbstractDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */