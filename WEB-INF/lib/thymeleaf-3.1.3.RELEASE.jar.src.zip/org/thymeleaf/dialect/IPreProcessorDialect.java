package org.thymeleaf.dialect;

import java.util.Set;
import org.thymeleaf.preprocessor.IPreProcessor;

public interface IPreProcessorDialect extends IDialect {
  int getDialectPreProcessorPrecedence();
  
  Set<IPreProcessor> getPreProcessors();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\IPreProcessorDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */