package org.thymeleaf.dialect;

import java.util.Map;

public interface IExecutionAttributeDialect extends IDialect {
  Map<String, Object> getExecutionAttributes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\IExecutionAttributeDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */