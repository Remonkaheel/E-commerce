package org.thymeleaf.dialect;

public interface IDialect {
  String getName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\IDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */