package org.thymeleaf.dialect;

import java.util.Set;
import org.thymeleaf.processor.IProcessor;

public interface IProcessorDialect extends IDialect {
  String getPrefix();
  
  int getDialectProcessorPrecedence();
  
  Set<IProcessor> getProcessors(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\dialect\IProcessorDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */