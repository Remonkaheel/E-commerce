/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggingUtils
/*    */ {
/*    */   public static String loggifyTemplateName(String template) {
/* 36 */     if (template == null) {
/* 37 */       return null;
/*    */     }
/* 39 */     if (template.length() <= 120) {
/* 40 */       return template.replace('\n', ' ');
/*    */     }
/* 42 */     StringBuilder strBuilder = new StringBuilder();
/* 43 */     strBuilder.append(template.substring(0, 35).replace('\n', ' '));
/* 44 */     strBuilder.append("[...]");
/* 45 */     strBuilder.append(template.substring(template.length() - 80).replace('\n', ' '));
/* 46 */     return strBuilder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\LoggingUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */