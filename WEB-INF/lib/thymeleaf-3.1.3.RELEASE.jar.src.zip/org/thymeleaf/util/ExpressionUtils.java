/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.math.RoundingMode;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Currency;
/*     */ import java.util.Date;
/*     */ import java.util.Deque;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalDouble;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.OptionalLong;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicIntegerArray;
/*     */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicLongArray;
/*     */ import java.util.concurrent.atomic.AtomicLongFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicMarkableReference;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*     */ import java.util.concurrent.atomic.AtomicStampedReference;
/*     */ import java.util.concurrent.atomic.DoubleAccumulator;
/*     */ import java.util.concurrent.atomic.DoubleAdder;
/*     */ import java.util.concurrent.atomic.LongAccumulator;
/*     */ import java.util.concurrent.atomic.LongAdder;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExpressionUtils
/*     */ {
/*  78 */   private static final Set<String> BLOCKED_ALL_PURPOSES_PACKAGE_NAME_PREFIXES = new HashSet<>(
/*  79 */       Arrays.asList(new String[] { "java.", "javax.", "jakarta.", "jdk.", "org.ietf.jgss.", "org.omg.", "org.w3c.dom.", "org.xml.sax.", "com.sun.", "sun." }));
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static final Set<String> ALLOWED_ALL_PURPOSES_PACKAGE_NAME_PREFIXES = new HashSet<>(
/*  84 */       Arrays.asList(new String[] { "java.time." }));
/*     */   
/*  86 */   private static final Set<String> BLOCKED_TYPE_REFERENCE_PACKAGE_NAME_PREFIXES = new HashSet<>(
/*  87 */       Arrays.asList(new String[] { 
/*     */           "com.squareup.javapoet.", "net.bytebuddy.", "net.sf.cglib.", "javassist.", "javax0.geci.", "org.apache.bcel.", "org.aspectj.", "org.javassist.", "org.mockito.", "org.objectweb.asm.", 
/*     */           "org.objenesis.", "org.springframework.aot.", "org.springframework.asm.", "org.springframework.cglib.", "org.springframework.javapoet.", "org.springframework.objenesis.", "org.springframework.web.", "org.springframework.webflow.", "org.springframework.context.", "org.springframework.beans.", 
/*     */           "org.springframework.aspects.", "org.springframework.aop.", "org.springframework.expression.", "org.springframework.util." }));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Set<String> ALLOWED_JAVA_CLASS_NAMES;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static final Set<Class<?>> ALLOWED_JAVA_CLASSES = new HashSet<>(
/* 101 */       Arrays.asList(new Class[] { 
/*     */           Boolean.class, Byte.class, Character.class, Double.class, Enum.class, Float.class, Integer.class, Long.class, Math.class, Number.class, 
/*     */           Short.class, String.class, BigDecimal.class, BigInteger.class, RoundingMode.class, ArrayList.class, LinkedList.class, HashMap.class, LinkedHashMap.class, HashSet.class, 
/*     */           LinkedHashSet.class, Iterator.class, Enumeration.class, Deque.class, Locale.class, Properties.class, Date.class, Calendar.class, Optional.class, OptionalDouble.class, 
/*     */           OptionalInt.class, OptionalLong.class, UUID.class, Currency.class, AtomicBoolean.class, AtomicInteger.class, AtomicIntegerArray.class, AtomicIntegerFieldUpdater.class, AtomicLong.class, AtomicLongArray.class, 
/*     */           AtomicLongFieldUpdater.class, AtomicMarkableReference.class, AtomicReference.class, AtomicReferenceArray.class, AtomicReferenceFieldUpdater.class, AtomicStampedReference.class, DoubleAccumulator.class, DoubleAdder.class, LongAccumulator.class, LongAdder.class, 
/*     */           Date.class, Time.class, Timestamp.class }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Set<String> ALLOWED_JAVA_SUPERS_NAMES;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private static final Set<Class<?>> ALLOWED_JAVA_SUPERS = new HashSet<>(
/* 123 */       Arrays.asList(new Class[] { Collection.class, Iterable.class, Iterator.class, List.class, Map.class, Map.Entry.class, Set.class, Calendar.class, Stream.class }));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   private static final Set<String> BLOCKED_MEMBER_CALL_JAVA_SUPERS_NAMES = new HashSet<>(
/* 129 */       Arrays.asList(new String[] { 
/*     */           "java.lang.ClassLoader", "org.thymeleaf.standard.expression.IStandardVariableExpressionEvaluator", "org.thymeleaf.standard.expression.IStandardExpressionParser", "org.thymeleaf.standard.expression.IStandardConversionService", "org.thymeleaf.spring5.context.IThymeleafRequestContext", "org.thymeleaf.spring5.expression.IThymeleafEvaluationContext", "org.thymeleaf.spring6.context.IThymeleafRequestContext", "org.thymeleaf.spring6.expression.IThymeleafEvaluationContext", "org.springframework.web.servlet.support.RequestContext", "org.springframework.web.reactive.result.view.RequestContext", 
/*     */           "org.springframework.core.io.ResourceLoader" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Set<Class<?>> BLOCKED_MEMBER_CALL_JAVA_SUPERS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private static final Set<String> ALLOWED_CLASS_METHODS = new HashSet<>(
/* 147 */       Arrays.asList(new String[] { "getName", "isAssignableFrom", "isInstance", "isInterface", "isPrimitive", "isRecord", "isAnnotation", "isArray", "isEnum" }));
/*     */ 
/*     */ 
/*     */   
/* 151 */   private static final Set<String> BLOCKED_CLASS_METHODS = (Set<String>)Arrays.<Method>stream(Class.class.getDeclaredMethods()).map(Method::getName).collect(Collectors.toSet());
/*     */ 
/*     */   
/*     */   static {
/* 155 */     ALLOWED_JAVA_CLASS_NAMES = (Set<String>)ALLOWED_JAVA_CLASSES.stream().map(c -> c.getName()).collect(Collectors.toSet());
/* 156 */     ALLOWED_JAVA_SUPERS_NAMES = (Set<String>)ALLOWED_JAVA_SUPERS.stream().map(c -> c.getName()).collect(Collectors.toSet());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     BLOCKED_MEMBER_CALL_JAVA_SUPERS = (Set<Class<?>>)BLOCKED_MEMBER_CALL_JAVA_SUPERS_NAMES.stream().map(className -> { try { return Optional.of(Class.forName(className)); } catch (ClassNotFoundException e) { return Optional.ofNullable((Class)null); }  }).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String normalize(String expression) {
/* 169 */     if (expression == null) {
/* 170 */       return expression;
/*     */     }
/* 172 */     StringBuilder strBuilder = null;
/* 173 */     int expLen = expression.length();
/*     */     
/* 175 */     for (int i = 0; i < expLen; i++) {
/* 176 */       char c = expression.charAt(i);
/* 177 */       if (c != '\n' && (c < ' ' || (c >= '' && c <= ''))) {
/* 178 */         if (strBuilder == null) {
/* 179 */           strBuilder = new StringBuilder(expLen);
/* 180 */           strBuilder.append(expression, 0, i);
/*     */         } 
/* 182 */       } else if (strBuilder != null) {
/* 183 */         strBuilder.append(c);
/*     */       } 
/*     */     } 
/* 186 */     return (strBuilder == null) ? expression : strBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isJavaPackage(String typeName) {
/* 191 */     return (typeName.charAt(0) == 'j' && typeName.charAt(4) == '.' && typeName.charAt(1) == 'a' && typeName
/* 192 */       .charAt(2) == 'v' && typeName.charAt(3) == 'a');
/*     */   }
/*     */   
/*     */   static boolean isTypeBlockedForAllPurposes(String typeName) {
/* 196 */     char c0 = typeName.charAt(0);
/* 197 */     if (c0 != 'c' && c0 != 'j' && c0 != 'o' && c0 != 's') {
/* 198 */       return false;
/*     */     }
/* 200 */     if (c0 == 'c') {
/* 201 */       return typeName.startsWith("com.sun.");
/*     */     }
/* 203 */     if (isJavaPackage(typeName)) {
/* 204 */       return !typeName.startsWith("java.time.");
/*     */     }
/* 206 */     return BLOCKED_ALL_PURPOSES_PACKAGE_NAME_PREFIXES.stream().anyMatch(prefix -> typeName.startsWith(prefix));
/*     */   }
/*     */   
/*     */   static boolean isTypeBlockedForTypeReference(String typeName) {
/* 210 */     if (isTypeBlockedForAllPurposes(typeName)) {
/* 211 */       return true;
/*     */     }
/* 213 */     char c0 = typeName.charAt(0);
/* 214 */     if (c0 != 'c' && c0 != 'n' && c0 != 'j' && c0 != 'o') {
/* 215 */       return false;
/*     */     }
/* 217 */     if (c0 == 'c') {
/* 218 */       return typeName.startsWith("com.squareup.javapoet.");
/*     */     }
/* 220 */     return BLOCKED_TYPE_REFERENCE_PACKAGE_NAME_PREFIXES.stream().anyMatch(prefix -> typeName.startsWith(prefix));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTypeAllowed(String typeName) {
/* 227 */     Validate.notNull(typeName, "Type name cannot be null");
/*     */     
/* 229 */     String normalizedTypeName = normalize(typeName);
/*     */     
/* 231 */     if (!isTypeBlockedForTypeReference(normalizedTypeName)) {
/* 232 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 236 */     return (ALLOWED_JAVA_CLASS_NAMES.contains(normalizedTypeName) || ALLOWED_JAVA_SUPERS_NAMES.contains(normalizedTypeName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isTypeBlockedForMemberCalls(Class<?> type) {
/* 243 */     return BLOCKED_MEMBER_CALL_JAVA_SUPERS.stream().anyMatch(i -> i.isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isMemberAllowedForInstanceOfType(Class<?> type, String memberName) {
/* 249 */     Validate.notNull(type, "Type cannot be null");
/*     */     
/* 251 */     String typeName = type.getName();
/*     */     
/* 253 */     if (!isTypeBlockedForAllPurposes(typeName) && !isTypeBlockedForMemberCalls(type)) {
/* 254 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     if (type.isEnum() || type.isAnnotation()) {
/* 263 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     if (Proxy.isProxyClass(type)) {
/* 270 */       return true;
/*     */     }
/*     */     
/* 273 */     if (ALLOWED_JAVA_CLASSES.contains(type)) {
/* 274 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 278 */     return ALLOWED_JAVA_SUPERS.stream()
/* 279 */       .filter(i -> i.isAssignableFrom(type))
/* 280 */       .anyMatch(i -> Arrays.<Method>stream(i.getDeclaredMethods()).anyMatch(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMemberAllowed(Object target, String memberName) {
/* 288 */     Validate.notNull(memberName, "Member name cannot be null");
/*     */     
/* 290 */     if (target == null) {
/* 291 */       return true;
/*     */     }
/*     */     
/* 294 */     String normalizedMemberName = normalize(memberName);
/*     */ 
/*     */     
/* 297 */     if ("getClass".equals(normalizedMemberName) || "toString".equals(normalizedMemberName)) {
/* 298 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 303 */     if (target instanceof Class) {
/* 304 */       String targetTypeName = ((Class)target).getName();
/* 305 */       return (ALLOWED_CLASS_METHODS.contains(normalizedMemberName) || (
/* 306 */         !BLOCKED_CLASS_METHODS.contains(normalizedMemberName) && isTypeAllowed(targetTypeName)));
/*     */     } 
/*     */     
/* 309 */     return isMemberAllowedForInstanceOfType(target.getClass(), normalizedMemberName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\ExpressionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */