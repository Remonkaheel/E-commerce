/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContentTypeUtils
/*     */ {
/*  50 */   private static final String[] MIME_TYPES_HTML = new String[] { "text/html", "application/xhtml+xml" };
/*     */ 
/*     */ 
/*     */   
/*  54 */   private static final String[] MIME_TYPES_XML = new String[] { "application/xml", "text/xml" };
/*  55 */   private static final String[] MIME_TYPES_RSS = new String[] { "application/rss+xml" };
/*  56 */   private static final String[] MIME_TYPES_ATOM = new String[] { "application/atom+xml" };
/*  57 */   private static final String[] MIME_TYPES_JAVASCRIPT = new String[] { "application/javascript", "application/x-javascript", "application/ecmascript", "text/javascript", "text/ecmascript" };
/*     */ 
/*     */   
/*  60 */   private static final String[] MIME_TYPES_JSON = new String[] { "application/json" };
/*  61 */   private static final String[] MIME_TYPES_CSS = new String[] { "text/css" };
/*  62 */   private static final String[] MIME_TYPES_TEXT = new String[] { "text/plain" };
/*  63 */   private static final String[] MIME_TYPES_SSE = new String[] { "text/event-stream" };
/*     */   
/*  65 */   private static final String[] FILE_EXTENSIONS_HTML = new String[] { ".html", ".htm", ".xhtml" };
/*  66 */   private static final String[] FILE_EXTENSIONS_XML = new String[] { ".xml" };
/*  67 */   private static final String[] FILE_EXTENSIONS_RSS = new String[] { ".rss" };
/*  68 */   private static final String[] FILE_EXTENSIONS_ATOM = new String[] { ".atom" };
/*  69 */   private static final String[] FILE_EXTENSIONS_JAVASCRIPT = new String[] { ".js" };
/*  70 */   private static final String[] FILE_EXTENSIONS_JSON = new String[] { ".json" };
/*  71 */   private static final String[] FILE_EXTENSIONS_CSS = new String[] { ".css" };
/*  72 */   private static final String[] FILE_EXTENSIONS_TEXT = new String[] { ".txt" };
/*     */   
/*     */   private static final Map<String, String> NORMALIZED_MIME_TYPES;
/*     */   
/*     */   private static final Map<String, String> MIME_TYPE_BY_FILE_EXTENSION;
/*     */   
/*     */   private static final Map<String, TemplateMode> TEMPLATE_MODE_BY_MIME_TYPE;
/*     */ 
/*     */   
/*     */   static {
/*  82 */     Map<String, String> normalizedMimeTypes = new HashMap<>(20, 1.0F);
/*  83 */     for (String type : MIME_TYPES_HTML) {
/*  84 */       normalizedMimeTypes.put(type, MIME_TYPES_HTML[0]);
/*     */     }
/*  86 */     for (String type : MIME_TYPES_XML) {
/*  87 */       normalizedMimeTypes.put(type, MIME_TYPES_XML[0]);
/*     */     }
/*  89 */     for (String type : MIME_TYPES_RSS) {
/*  90 */       normalizedMimeTypes.put(type, MIME_TYPES_RSS[0]);
/*     */     }
/*  92 */     for (String type : MIME_TYPES_ATOM) {
/*  93 */       normalizedMimeTypes.put(type, MIME_TYPES_ATOM[0]);
/*     */     }
/*  95 */     for (String type : MIME_TYPES_JAVASCRIPT) {
/*  96 */       normalizedMimeTypes.put(type, MIME_TYPES_JAVASCRIPT[0]);
/*     */     }
/*  98 */     for (String type : MIME_TYPES_JSON) {
/*  99 */       normalizedMimeTypes.put(type, MIME_TYPES_JSON[0]);
/*     */     }
/* 101 */     for (String type : MIME_TYPES_CSS) {
/* 102 */       normalizedMimeTypes.put(type, MIME_TYPES_CSS[0]);
/*     */     }
/* 104 */     for (String type : MIME_TYPES_TEXT) {
/* 105 */       normalizedMimeTypes.put(type, MIME_TYPES_TEXT[0]);
/*     */     }
/* 107 */     for (String type : MIME_TYPES_SSE) {
/* 108 */       normalizedMimeTypes.put(type, MIME_TYPES_SSE[0]);
/*     */     }
/* 110 */     NORMALIZED_MIME_TYPES = Collections.unmodifiableMap(normalizedMimeTypes);
/*     */ 
/*     */     
/* 113 */     Map<String, String> mimeTypesByExtension = new HashMap<>(20, 1.0F);
/* 114 */     for (String type : FILE_EXTENSIONS_HTML) {
/* 115 */       mimeTypesByExtension.put(type, MIME_TYPES_HTML[0]);
/*     */     }
/* 117 */     for (String type : FILE_EXTENSIONS_XML) {
/* 118 */       mimeTypesByExtension.put(type, MIME_TYPES_XML[0]);
/*     */     }
/* 120 */     for (String type : FILE_EXTENSIONS_RSS) {
/* 121 */       mimeTypesByExtension.put(type, MIME_TYPES_RSS[0]);
/*     */     }
/* 123 */     for (String type : FILE_EXTENSIONS_ATOM) {
/* 124 */       mimeTypesByExtension.put(type, MIME_TYPES_ATOM[0]);
/*     */     }
/* 126 */     for (String type : FILE_EXTENSIONS_JAVASCRIPT) {
/* 127 */       mimeTypesByExtension.put(type, MIME_TYPES_JAVASCRIPT[0]);
/*     */     }
/* 129 */     for (String type : FILE_EXTENSIONS_JSON) {
/* 130 */       mimeTypesByExtension.put(type, MIME_TYPES_JSON[0]);
/*     */     }
/* 132 */     for (String type : FILE_EXTENSIONS_CSS) {
/* 133 */       mimeTypesByExtension.put(type, MIME_TYPES_CSS[0]);
/*     */     }
/* 135 */     for (String type : FILE_EXTENSIONS_TEXT) {
/* 136 */       mimeTypesByExtension.put(type, MIME_TYPES_TEXT[0]);
/*     */     }
/* 138 */     MIME_TYPE_BY_FILE_EXTENSION = Collections.unmodifiableMap(mimeTypesByExtension);
/*     */ 
/*     */     
/* 141 */     Map<String, TemplateMode> templateModeByMimeType = new HashMap<>(10, 1.0F);
/* 142 */     templateModeByMimeType.put(MIME_TYPES_HTML[0], TemplateMode.HTML);
/* 143 */     templateModeByMimeType.put(MIME_TYPES_XML[0], TemplateMode.XML);
/* 144 */     templateModeByMimeType.put(MIME_TYPES_RSS[0], TemplateMode.XML);
/* 145 */     templateModeByMimeType.put(MIME_TYPES_ATOM[0], TemplateMode.XML);
/* 146 */     templateModeByMimeType.put(MIME_TYPES_JAVASCRIPT[0], TemplateMode.JAVASCRIPT);
/* 147 */     templateModeByMimeType.put(MIME_TYPES_JSON[0], TemplateMode.JAVASCRIPT);
/* 148 */     templateModeByMimeType.put(MIME_TYPES_CSS[0], TemplateMode.CSS);
/* 149 */     templateModeByMimeType.put(MIME_TYPES_TEXT[0], TemplateMode.TEXT);
/* 150 */     TEMPLATE_MODE_BY_MIME_TYPE = Collections.unmodifiableMap(templateModeByMimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeHTML(String contentType) {
/* 156 */     return isContentType(contentType, MIME_TYPES_HTML[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeXML(String contentType) {
/* 161 */     return isContentType(contentType, MIME_TYPES_XML[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeRSS(String contentType) {
/* 166 */     return isContentType(contentType, MIME_TYPES_RSS[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeAtom(String contentType) {
/* 171 */     return isContentType(contentType, MIME_TYPES_ATOM[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeJavaScript(String contentType) {
/* 176 */     return isContentType(contentType, MIME_TYPES_JAVASCRIPT[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeJSON(String contentType) {
/* 181 */     return isContentType(contentType, MIME_TYPES_JSON[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeCSS(String contentType) {
/* 186 */     return isContentType(contentType, MIME_TYPES_CSS[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeText(String contentType) {
/* 191 */     return isContentType(contentType, MIME_TYPES_TEXT[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isContentTypeSSE(String contentType) {
/* 196 */     return isContentType(contentType, MIME_TYPES_SSE[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isContentType(String contentType, String matcher) {
/* 202 */     if (contentType == null || contentType.trim().length() == 0) {
/* 203 */       return false;
/*     */     }
/*     */     
/* 206 */     ContentType contentTypeObj = ContentType.parseContentType(contentType);
/* 207 */     if (contentTypeObj == null) {
/* 208 */       return false;
/*     */     }
/*     */     
/* 211 */     String normalisedMimeType = NORMALIZED_MIME_TYPES.get(contentTypeObj.getMimeType());
/* 212 */     if (normalisedMimeType == null) {
/* 213 */       return false;
/*     */     }
/*     */     
/* 216 */     return normalisedMimeType.equals(matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TemplateMode computeTemplateModeForContentType(String contentType) {
/* 223 */     if (contentType == null || contentType.trim().length() == 0) {
/* 224 */       return null;
/*     */     }
/*     */     
/* 227 */     ContentType contentTypeObj = ContentType.parseContentType(contentType);
/* 228 */     if (contentTypeObj == null) {
/* 229 */       return null;
/*     */     }
/*     */     
/* 232 */     String normalisedMimeType = NORMALIZED_MIME_TYPES.get(contentTypeObj.getMimeType());
/* 233 */     if (normalisedMimeType == null) {
/* 234 */       return null;
/*     */     }
/*     */     
/* 237 */     return TEMPLATE_MODE_BY_MIME_TYPE.get(normalisedMimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TemplateMode computeTemplateModeForTemplateName(String templateName) {
/* 244 */     String fileExtension = computeFileExtensionFromTemplateName(templateName);
/* 245 */     if (fileExtension == null) {
/* 246 */       return null;
/*     */     }
/*     */     
/* 249 */     String mimeType = MIME_TYPE_BY_FILE_EXTENSION.get(fileExtension);
/* 250 */     if (mimeType == null) {
/* 251 */       return null;
/*     */     }
/*     */     
/* 254 */     return TEMPLATE_MODE_BY_MIME_TYPE.get(mimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TemplateMode computeTemplateModeForRequestPath(String requestPath) {
/* 261 */     String fileExtension = computeFileExtensionFromRequestPath(requestPath);
/* 262 */     if (fileExtension == null) {
/* 263 */       return null;
/*     */     }
/*     */     
/* 266 */     String mimeType = MIME_TYPE_BY_FILE_EXTENSION.get(fileExtension);
/* 267 */     if (mimeType == null) {
/* 268 */       return null;
/*     */     }
/*     */     
/* 271 */     return TEMPLATE_MODE_BY_MIME_TYPE.get(mimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasRecognizedFileExtension(String templateName) {
/* 278 */     String fileExtension = computeFileExtensionFromTemplateName(templateName);
/* 279 */     if (fileExtension == null) {
/* 280 */       return false;
/*     */     }
/*     */     
/* 283 */     return MIME_TYPE_BY_FILE_EXTENSION.containsKey(fileExtension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String computeContentTypeForTemplateName(String templateName, Charset charset) {
/* 290 */     String fileExtension = computeFileExtensionFromTemplateName(templateName);
/* 291 */     if (fileExtension == null) {
/* 292 */       return null;
/*     */     }
/*     */     
/* 295 */     String mimeType = MIME_TYPE_BY_FILE_EXTENSION.get(fileExtension);
/* 296 */     if (mimeType == null) {
/* 297 */       return null;
/*     */     }
/*     */     
/* 300 */     ContentType contentType = ContentType.parseContentType(mimeType);
/* 301 */     if (contentType == null) {
/* 302 */       return null;
/*     */     }
/*     */     
/* 305 */     if (charset != null) {
/* 306 */       contentType.setCharset(charset);
/*     */     }
/*     */     
/* 309 */     return contentType.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String computeContentTypeForRequestPath(String requestPath, Charset charset) {
/* 316 */     String fileExtension = computeFileExtensionFromRequestPath(requestPath);
/* 317 */     if (fileExtension == null) {
/* 318 */       return null;
/*     */     }
/*     */     
/* 321 */     String mimeType = MIME_TYPE_BY_FILE_EXTENSION.get(fileExtension);
/* 322 */     if (mimeType == null) {
/* 323 */       return null;
/*     */     }
/*     */     
/* 326 */     ContentType contentType = ContentType.parseContentType(mimeType);
/* 327 */     if (contentType == null) {
/* 328 */       return null;
/*     */     }
/*     */     
/* 331 */     if (charset != null) {
/* 332 */       contentType.setCharset(charset);
/*     */     }
/*     */     
/* 335 */     return contentType.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Charset computeCharsetFromContentType(String contentType) {
/* 342 */     if (contentType == null || contentType.trim().length() == 0) {
/* 343 */       return null;
/*     */     }
/*     */     
/* 346 */     ContentType contentTypeObj = ContentType.parseContentType(contentType);
/* 347 */     if (contentTypeObj == null) {
/* 348 */       return null;
/*     */     }
/*     */     
/* 351 */     return contentTypeObj.getCharset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String computeFileExtensionFromTemplateName(String templateName) {
/* 358 */     if (templateName == null || templateName.trim().length() == 0) {
/* 359 */       return null;
/*     */     }
/*     */     
/* 362 */     int pointPos = templateName.lastIndexOf('.');
/* 363 */     if (pointPos < 0)
/*     */     {
/* 365 */       return null;
/*     */     }
/*     */     
/* 368 */     return templateName.substring(pointPos).toLowerCase(Locale.US).trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String computeFileExtensionFromRequestPath(String requestPath) {
/* 375 */     String path = requestPath;
/*     */     
/* 377 */     int questionMarkPos = path.indexOf('?');
/* 378 */     if (questionMarkPos != -1) {
/* 379 */       path = path.substring(0, questionMarkPos);
/*     */     }
/*     */     
/* 382 */     int hashPos = path.indexOf('#');
/* 383 */     if (hashPos != -1) {
/* 384 */       path = path.substring(0, hashPos);
/*     */     }
/*     */     
/* 387 */     int semicolonPos = path.indexOf(';');
/* 388 */     if (semicolonPos != -1) {
/* 389 */       path = path.substring(0, semicolonPos);
/*     */     }
/*     */     
/* 392 */     int slashPos = path.lastIndexOf('/');
/* 393 */     if (slashPos != -1) {
/* 394 */       path = path.substring(slashPos + 1);
/*     */     }
/*     */     
/* 397 */     int dotPos = path.lastIndexOf('.');
/* 398 */     if (dotPos != -1) {
/* 399 */       return path.substring(dotPos);
/*     */     }
/*     */     
/* 402 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String combineContentTypeAndCharset(String contentType, Charset charset) {
/* 409 */     if (charset == null) {
/* 410 */       return contentType;
/*     */     }
/*     */     
/* 413 */     if (contentType == null || contentType.trim().length() == 0) {
/* 414 */       return null;
/*     */     }
/*     */     
/* 417 */     ContentType contentTypeObj = ContentType.parseContentType(contentType);
/* 418 */     if (contentTypeObj == null) {
/* 419 */       return null;
/*     */     }
/*     */     
/* 422 */     contentTypeObj.setCharset(charset);
/*     */     
/* 424 */     return contentTypeObj.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ContentType
/*     */   {
/* 442 */     private final String PARAMETER_CHARSET = "charset";
/*     */     
/*     */     private final String mimeType;
/*     */     
/*     */     private final LinkedHashMap<String, String> parameters;
/*     */ 
/*     */     
/*     */     static ContentType parseContentType(String contentType) {
/* 450 */       if (contentType == null || contentType.trim().length() == 0) {
/* 451 */         return null;
/*     */       }
/*     */       
/* 454 */       String[] tokens = StringUtils.split(contentType, ";");
/* 455 */       String mimeType = tokens[0].toLowerCase(Locale.US).trim();
/*     */       
/* 457 */       if (tokens.length == 1) {
/* 458 */         return new ContentType(mimeType, new LinkedHashMap<>(2, 1.0F));
/*     */       }
/*     */       
/* 461 */       LinkedHashMap<String, String> parameters = new LinkedHashMap<>(2, 1.0F);
/* 462 */       for (int i = 1; i < tokens.length; i++) {
/* 463 */         String token = tokens[i].toLowerCase(Locale.US).trim();
/* 464 */         int equalPos = token.indexOf('=');
/* 465 */         if (equalPos != -1) {
/* 466 */           parameters.put(token.substring(0, equalPos).trim(), token.substring(equalPos + 1).trim());
/*     */         } else {
/* 468 */           parameters.put(token.trim(), "");
/*     */         } 
/*     */       } 
/*     */       
/* 472 */       return new ContentType(mimeType, parameters);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ContentType(String mimeType, LinkedHashMap<String, String> parameters) {
/* 479 */       this.mimeType = mimeType;
/* 480 */       this.parameters = parameters;
/*     */     }
/*     */     
/*     */     String getMimeType() {
/* 484 */       return this.mimeType;
/*     */     }
/*     */     
/*     */     LinkedHashMap<String, String> getParameters() {
/* 488 */       return this.parameters;
/*     */     }
/*     */     
/*     */     Charset getCharset() {
/* 492 */       String charsetStr = this.parameters.get("charset");
/* 493 */       if (charsetStr == null) {
/* 494 */         return null;
/*     */       }
/*     */       try {
/* 497 */         return Charset.forName(charsetStr);
/* 498 */       } catch (UnsupportedCharsetException e) {
/* 499 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     void setCharset(Charset charset) {
/* 504 */       if (charset != null) {
/* 505 */         this.parameters.put("charset", charset.name());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 511 */       StringBuilder strBuilder = new StringBuilder();
/* 512 */       strBuilder.append(this.mimeType);
/* 513 */       for (Map.Entry<String, String> parameterEntry : this.parameters.entrySet()) {
/* 514 */         strBuilder.append(';');
/* 515 */         strBuilder.append(parameterEntry.getKey());
/* 516 */         strBuilder.append('=');
/* 517 */         strBuilder.append(parameterEntry.getValue());
/*     */       } 
/* 519 */       return strBuilder.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\ContentTypeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */