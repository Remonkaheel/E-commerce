/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NumberPointType
/*    */ {
/* 35 */   POINT("POINT"),
/* 36 */   COMMA("COMMA"),
/* 37 */   WHITESPACE("WHITESPACE"),
/* 38 */   NONE("NONE"),
/* 39 */   DEFAULT("DEFAULT");
/*    */ 
/*    */ 
/*    */   
/*    */   private final String name;
/*    */ 
/*    */ 
/*    */   
/*    */   public static NumberPointType match(String name) {
/* 48 */     if ("NONE".equals(name)) {
/* 49 */       return NONE;
/*    */     }
/* 51 */     if ("DEFAULT".equals(name)) {
/* 52 */       return DEFAULT;
/*    */     }
/* 54 */     if ("POINT".equals(name)) {
/* 55 */       return POINT;
/*    */     }
/* 57 */     if ("COMMA".equals(name)) {
/* 58 */       return COMMA;
/*    */     }
/* 60 */     if ("WHITESPACE".equals(name)) {
/* 61 */       return WHITESPACE;
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   NumberPointType(String name) {
/* 70 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 74 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\NumberPointType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */