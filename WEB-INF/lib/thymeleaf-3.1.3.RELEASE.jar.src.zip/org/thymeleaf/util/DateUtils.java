/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateUtils
/*     */ {
/*  42 */   private static final Map<DateFormatKey, DateFormat> dateFormats = new ConcurrentHashMap<>(4, 0.9F, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private static final SimpleDateFormat ISO8601_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar create(Object year, Object month, Object day) {
/*  69 */     return create(year, month, day, null, null, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute) {
/*  85 */     return create(year, month, day, hour, minute, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second) {
/* 102 */     return create(year, month, day, hour, minute, second, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond) {
/* 120 */     return create(year, month, day, hour, minute, second, millisecond, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond, Object timeZone) {
/* 140 */     return create(year, month, day, hour, minute, second, millisecond, timeZone, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond, Object timeZone, Locale locale) {
/*     */     Calendar cal;
/* 164 */     BigDecimal nYear = (year == null) ? null : EvaluationUtils.evaluateAsNumber(year);
/*     */ 
/*     */     
/* 167 */     BigDecimal nMonth = (month == null) ? null : EvaluationUtils.evaluateAsNumber(month);
/*     */ 
/*     */     
/* 170 */     BigDecimal nDay = (day == null) ? null : EvaluationUtils.evaluateAsNumber(day);
/*     */ 
/*     */     
/* 173 */     BigDecimal nHour = (hour == null) ? null : EvaluationUtils.evaluateAsNumber(hour);
/*     */ 
/*     */     
/* 176 */     BigDecimal nMinute = (minute == null) ? null : EvaluationUtils.evaluateAsNumber(minute);
/*     */ 
/*     */     
/* 179 */     BigDecimal nSecond = (second == null) ? null : EvaluationUtils.evaluateAsNumber(second);
/*     */ 
/*     */     
/* 182 */     BigDecimal nMillisecond = (millisecond == null) ? null : EvaluationUtils.evaluateAsNumber(millisecond);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     TimeZone tzTimeZone = (timeZone != null) ? ((timeZone instanceof TimeZone) ? (TimeZone)timeZone : TimeZone.getTimeZone(timeZone.toString())) : null;
/*     */ 
/*     */     
/* 191 */     if (tzTimeZone != null && locale != null) {
/* 192 */       cal = Calendar.getInstance(tzTimeZone, locale);
/* 193 */     } else if (tzTimeZone != null) {
/* 194 */       cal = Calendar.getInstance(tzTimeZone);
/* 195 */     } else if (locale != null) {
/* 196 */       cal = Calendar.getInstance(locale);
/*     */     } else {
/* 198 */       cal = Calendar.getInstance();
/*     */     } 
/*     */     
/* 201 */     if (nYear == null || nMonth == null || nDay == null) {
/* 202 */       throw new IllegalArgumentException("Cannot create Calendar/Date object with null year (" + nYear + "), month (" + nMonth + ") or day (" + nDay + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 207 */     cal.set(1, nYear.intValue());
/* 208 */     cal.set(2, nMonth.intValue() - 1);
/* 209 */     cal.set(5, nDay.intValue());
/* 210 */     cal.set(11, 0);
/* 211 */     cal.set(12, 0);
/* 212 */     cal.set(13, 0);
/* 213 */     cal.set(14, 0);
/*     */     
/* 215 */     if (nHour != null && nMinute != null) {
/*     */       
/* 217 */       cal.set(11, nHour.intValue());
/* 218 */       cal.set(12, nMinute.intValue());
/*     */       
/* 220 */       if (nSecond != null)
/*     */       {
/* 222 */         cal.set(13, nSecond.intValue());
/*     */         
/* 224 */         if (nMillisecond != null)
/*     */         {
/* 226 */           cal.set(14, nMillisecond.intValue());
/*     */         
/*     */         }
/*     */       }
/* 230 */       else if (nMillisecond != null)
/*     */       {
/* 232 */         throw new IllegalArgumentException("Calendar/Date object cannot be correctly created from a null second but non-null millisecond.");
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 238 */       if (nHour != null || nMinute != null)
/*     */       {
/* 240 */         throw new IllegalArgumentException("Calendar/Date object can only be correctly created if hour (" + nHour + ") and minute (" + nMinute + ") are either both null or non-null.");
/*     */       }
/*     */ 
/*     */       
/* 244 */       if (nSecond != null || nMillisecond != null)
/*     */       {
/* 246 */         throw new IllegalArgumentException("Calendar/Date object cannot be correctly created from a null hour and minute but non-null second and/or millisecond.");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     return cal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar createNow() {
/* 264 */     return createNow(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar createNow(Object timeZone) {
/* 275 */     return createNow(timeZone, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar createNow(Object timeZone, Locale locale) {
/* 292 */     TimeZone tzTimeZone = (timeZone != null) ? ((timeZone instanceof TimeZone) ? (TimeZone)timeZone : TimeZone.getTimeZone(timeZone.toString())) : null;
/*     */     
/* 294 */     if (tzTimeZone != null && locale != null) {
/* 295 */       return Calendar.getInstance(tzTimeZone, locale);
/*     */     }
/* 297 */     if (tzTimeZone != null) {
/* 298 */       return Calendar.getInstance(tzTimeZone);
/*     */     }
/* 300 */     if (locale != null) {
/* 301 */       return Calendar.getInstance(locale);
/*     */     }
/* 303 */     return Calendar.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar createToday() {
/* 315 */     return createToday(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar createToday(Object timeZone) {
/* 327 */     return createToday(timeZone, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar createToday(Object timeZone, Locale locale) {
/* 340 */     Calendar cal = createNow(timeZone, locale);
/* 341 */     cal.set(14, 0);
/* 342 */     cal.set(13, 0);
/* 343 */     cal.set(12, 0);
/* 344 */     cal.set(11, 0);
/* 345 */     return cal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String format(Object target, Locale locale) {
/* 352 */     if (target == null) {
/* 353 */       return null;
/*     */     }
/* 355 */     return formatDate(target, locale);
/*     */   }
/*     */   
/*     */   public static String format(Object target, String pattern, Locale locale) {
/* 359 */     Validate.notEmpty(pattern, "Pattern cannot be null or empty");
/* 360 */     if (target == null) {
/* 361 */       return null;
/*     */     }
/* 363 */     return formatDate(target, pattern, locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer day(Object target) {
/* 368 */     if (target == null) {
/* 369 */       return null;
/*     */     }
/* 371 */     Calendar cal = normalizeDate(target);
/* 372 */     return Integer.valueOf(cal.get(5));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer month(Object target) {
/* 377 */     if (target == null) {
/* 378 */       return null;
/*     */     }
/* 380 */     Calendar cal = normalizeDate(target);
/* 381 */     return Integer.valueOf(cal.get(2) + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String monthName(Object target, Locale locale) {
/* 386 */     if (target == null) {
/* 387 */       return null;
/*     */     }
/* 389 */     return format(target, "MMMM", locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String monthNameShort(Object target, Locale locale) {
/* 394 */     if (target == null) {
/* 395 */       return null;
/*     */     }
/* 397 */     return format(target, "MMM", locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer year(Object target) {
/* 402 */     if (target == null) {
/* 403 */       return null;
/*     */     }
/* 405 */     Calendar cal = normalizeDate(target);
/* 406 */     return Integer.valueOf(cal.get(1));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer dayOfWeek(Object target) {
/* 411 */     if (target == null) {
/* 412 */       return null;
/*     */     }
/* 414 */     Calendar cal = normalizeDate(target);
/* 415 */     return Integer.valueOf(cal.get(7));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String dayOfWeekName(Object target, Locale locale) {
/* 420 */     if (target == null) {
/* 421 */       return null;
/*     */     }
/* 423 */     return format(target, "EEEE", locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String dayOfWeekNameShort(Object target, Locale locale) {
/* 428 */     if (target == null) {
/* 429 */       return null;
/*     */     }
/* 431 */     return format(target, "EEE", locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer hour(Object target) {
/* 436 */     if (target == null) {
/* 437 */       return null;
/*     */     }
/* 439 */     Calendar cal = normalizeDate(target);
/* 440 */     return Integer.valueOf(cal.get(11));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer minute(Object target) {
/* 445 */     if (target == null) {
/* 446 */       return null;
/*     */     }
/* 448 */     Calendar cal = normalizeDate(target);
/* 449 */     return Integer.valueOf(cal.get(12));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer second(Object target) {
/* 454 */     if (target == null) {
/* 455 */       return null;
/*     */     }
/* 457 */     Calendar cal = normalizeDate(target);
/* 458 */     return Integer.valueOf(cal.get(13));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer millisecond(Object target) {
/* 463 */     if (target == null) {
/* 464 */       return null;
/*     */     }
/* 466 */     Calendar cal = normalizeDate(target);
/* 467 */     return Integer.valueOf(cal.get(14));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Calendar normalizeDate(Object target) {
/* 476 */     if (target == null) {
/* 477 */       return null;
/*     */     }
/* 479 */     if (target instanceof Calendar)
/* 480 */       return (Calendar)target; 
/* 481 */     if (target instanceof Date) {
/* 482 */       Calendar cal = Calendar.getInstance();
/* 483 */       cal.setTimeInMillis(((Date)target).getTime());
/* 484 */       return cal;
/*     */     } 
/* 486 */     throw new IllegalArgumentException("Cannot normalize class \"" + target
/* 487 */         .getClass().getName() + "\" as a date");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String formatDate(Object target, Locale locale) {
/* 496 */     if (target == null) {
/* 497 */       return null;
/*     */     }
/* 499 */     return formatDate(target, null, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String formatDate(Object target, String pattern, Locale locale) {
/* 505 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 507 */     if (target == null) {
/* 508 */       return null;
/*     */     }
/*     */     
/* 511 */     DateFormatKey key = new DateFormatKey(target, pattern, locale);
/*     */     
/* 513 */     DateFormat dateFormat = dateFormats.get(key);
/* 514 */     if (dateFormat == null) {
/* 515 */       if (StringUtils.isEmptyOrWhitespace(pattern)) {
/* 516 */         dateFormat = DateFormat.getDateTimeInstance(1, 1, locale);
/*     */       } else {
/* 518 */         dateFormat = new SimpleDateFormat(pattern, locale);
/*     */       } 
/* 520 */       if (key.timeZone != null) {
/* 521 */         dateFormat.setTimeZone(key.timeZone);
/*     */       }
/* 523 */       dateFormats.put(key, dateFormat);
/*     */     } 
/*     */     
/* 526 */     if (target instanceof Calendar)
/* 527 */       synchronized (dateFormat) {
/* 528 */         return dateFormat.format(((Calendar)target).getTime());
/*     */       }  
/* 530 */     if (target instanceof Date) {
/* 531 */       synchronized (dateFormat) {
/* 532 */         return dateFormat.format((Date)target);
/*     */       } 
/*     */     }
/* 535 */     throw new IllegalArgumentException("Cannot format object of class \"" + target
/* 536 */         .getClass().getName() + "\" as a date");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatISO(Object target) {
/*     */     Date targetDate;
/*     */     String formatted;
/* 553 */     if (target == null) {
/* 554 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 558 */     if (target instanceof Calendar) {
/* 559 */       targetDate = ((Calendar)target).getTime();
/* 560 */     } else if (target instanceof Date) {
/* 561 */       targetDate = (Date)target;
/*     */     } else {
/* 563 */       throw new IllegalArgumentException("Cannot format object of class \"" + target
/* 564 */           .getClass().getName() + "\" as a date");
/*     */     } 
/*     */ 
/*     */     
/* 568 */     synchronized (ISO8601_DATE_FORMAT) {
/* 569 */       formatted = ISO8601_DATE_FORMAT.format(targetDate);
/*     */     } 
/*     */     
/* 572 */     StringBuilder strBuilder = new StringBuilder(formatted.length() + 1);
/* 573 */     strBuilder.append(formatted);
/* 574 */     strBuilder.insert(26, ':');
/*     */     
/* 576 */     return strBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DateFormatKey
/*     */   {
/*     */     final String format;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final TimeZone timeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final Locale locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DateFormatKey(Object target, String format, Locale locale) {
/* 602 */       Validate.notNull(locale, "Locale cannot be null");
/* 603 */       this.format = format;
/* 604 */       this.locale = locale;
/* 605 */       if (target != null && target instanceof Calendar) {
/* 606 */         this.timeZone = ((Calendar)target).getTimeZone();
/*     */       } else {
/* 608 */         this.timeZone = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 614 */       int prime = 31;
/* 615 */       int result = 1;
/* 616 */       result = 31 * result + ((this.format == null) ? 0 : this.format.hashCode());
/* 617 */       result = 31 * result + this.locale.hashCode();
/* 618 */       result = 31 * result + ((this.timeZone == null) ? 0 : this.timeZone.hashCode());
/* 619 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 624 */       if (this == obj) {
/* 625 */         return true;
/*     */       }
/* 627 */       if (obj == null) {
/* 628 */         return false;
/*     */       }
/* 630 */       if (getClass() != obj.getClass()) {
/* 631 */         return false;
/*     */       }
/* 633 */       DateFormatKey other = (DateFormatKey)obj;
/* 634 */       if (this.format == null) {
/* 635 */         if (other.format != null) {
/* 636 */           return false;
/*     */         }
/* 638 */       } else if (!this.format.equals(other.format)) {
/* 639 */         return false;
/*     */       } 
/* 641 */       if (this.timeZone == null) {
/* 642 */         if (other.timeZone != null) {
/* 643 */           return false;
/*     */         }
/* 645 */       } else if (!this.timeZone.equals(other.timeZone)) {
/* 646 */         return false;
/*     */       } 
/* 648 */       return this.locale.equals(other.locale);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\DateUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */