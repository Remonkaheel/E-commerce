/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PatternUtils
/*    */ {
/*    */   public static Pattern strPatternToPattern(String pattern) {
/* 41 */     String pat = pattern.replace(".", "\\.").replace("(", "\\(").replace(")", "\\)").replace("[", "\\[").replace("]", "\\]").replace("?", "\\?").replace("$", "\\$").replace("+", "\\+").replace("*", "(?:.*?)");
/* 42 */     return Pattern.compile('^' + pat + '$');
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\PatternUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */