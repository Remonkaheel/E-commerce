package org.thymeleaf.util;

import java.io.IOException;
import java.io.Writer;

public interface IWritableCharSequence extends CharSequence {
  void write(Writer paramWriter) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\IWritableCharSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */