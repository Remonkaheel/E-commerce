/*     */ package org.thymeleaf.util.temporal;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalArrayUtils
/*     */ {
/*     */   private final TemporalFormattingUtils temporalFormattingUtils;
/*     */   
/*     */   public TemporalArrayUtils(Locale locale, ZoneId defaultZoneId) {
/*  44 */     Validate.notNull(locale, "Locale cannot be null");
/*  45 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/*  46 */     this.temporalFormattingUtils = new TemporalFormattingUtils(locale, defaultZoneId);
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target) {
/*  50 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::format, String.class);
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target, Locale locale) {
/*  54 */     return arrayFormat(target, time -> this.temporalFormattingUtils.format(time, locale), String.class);
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target, String pattern) {
/*  58 */     return arrayFormat(target, time -> this.temporalFormattingUtils.format(time, pattern, null), String.class);
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target, String pattern, Locale locale) {
/*  62 */     return arrayFormat(target, time -> this.temporalFormattingUtils.format(time, pattern, locale, null), String.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayDay(Object[] target) {
/*  66 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::day, Integer.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMonth(Object[] target) {
/*  70 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::month, Integer.class);
/*     */   }
/*     */   
/*     */   public String[] arrayMonthName(Object[] target) {
/*  74 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::monthName, String.class);
/*     */   }
/*     */   
/*     */   public String[] arrayMonthNameShort(Object[] target) {
/*  78 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::monthNameShort, String.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayYear(Object[] target) {
/*  82 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::year, Integer.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayDayOfWeek(Object[] target) {
/*  86 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::dayOfWeek, Integer.class);
/*     */   }
/*     */   
/*     */   public String[] arrayDayOfWeekName(Object[] target) {
/*  90 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::dayOfWeekName, String.class);
/*     */   }
/*     */   
/*     */   public String[] arrayDayOfWeekNameShort(Object[] target) {
/*  94 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::dayOfWeekNameShort, String.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayHour(Object[] target) {
/*  98 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::hour, Integer.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMinute(Object[] target) {
/* 102 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::minute, Integer.class);
/*     */   }
/*     */   
/*     */   public Integer[] arraySecond(Object[] target) {
/* 106 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::second, Integer.class);
/*     */   }
/*     */   
/*     */   public Integer[] arrayNanosecond(Object[] target) {
/* 110 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::nanosecond, Integer.class);
/*     */   }
/*     */   
/*     */   public String[] arrayFormatISO(Object[] target) {
/* 114 */     Objects.requireNonNull(this.temporalFormattingUtils); return arrayFormat(target, this.temporalFormattingUtils::formatISO, String.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private <R> R[] arrayFormat(Object[] target, Function<Object, R> mapFunction, Class<R> returnType) {
/* 119 */     Validate.notNull(target, "Target cannot be null");
/* 120 */     return (R[])Stream.<Object>of(target)
/* 121 */       .map(time -> mapFunction.apply(time))
/* 122 */       .toArray(length -> (Object[])Array.newInstance(returnType, length));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\temporal\TemporalArrayUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */