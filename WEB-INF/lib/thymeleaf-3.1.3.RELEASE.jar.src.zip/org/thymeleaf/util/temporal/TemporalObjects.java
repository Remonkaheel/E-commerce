/*     */ package org.thymeleaf.util.temporal;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.Year;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.chrono.ChronoZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.time.format.TextStyle;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalObjects
/*     */ {
/*     */   public static DateTimeFormatter formatterFor(Object target, Locale locale) {
/*  57 */     Validate.notNull(target, "Target cannot be null");
/*  58 */     Validate.notNull(locale, "Locale cannot be null");
/*  59 */     if (target instanceof Instant)
/*  60 */       return (new DateTimeFormatterBuilder()).appendInstant().toFormatter(); 
/*  61 */     if (target instanceof LocalDate)
/*  62 */       return DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(locale); 
/*  63 */     if (target instanceof LocalDateTime)
/*  64 */       return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG, FormatStyle.MEDIUM).withLocale(locale); 
/*  65 */     if (target instanceof LocalTime)
/*  66 */       return DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM).withLocale(locale); 
/*  67 */     if (target instanceof OffsetDateTime)
/*  68 */       return (new DateTimeFormatterBuilder())
/*  69 */         .appendLocalized(FormatStyle.LONG, FormatStyle.MEDIUM)
/*  70 */         .appendLocalizedOffset(TextStyle.FULL)
/*  71 */         .toFormatter()
/*  72 */         .withLocale(locale); 
/*  73 */     if (target instanceof OffsetTime)
/*  74 */       return (new DateTimeFormatterBuilder())
/*  75 */         .appendValue(ChronoField.HOUR_OF_DAY)
/*  76 */         .appendLiteral(':')
/*  77 */         .appendValue(ChronoField.MINUTE_OF_HOUR)
/*  78 */         .appendLiteral(':')
/*  79 */         .appendValue(ChronoField.SECOND_OF_MINUTE)
/*  80 */         .appendLocalizedOffset(TextStyle.FULL)
/*  81 */         .toFormatter()
/*  82 */         .withLocale(locale); 
/*  83 */     if (target instanceof Year)
/*  84 */       return (new DateTimeFormatterBuilder())
/*  85 */         .appendValue(ChronoField.YEAR)
/*  86 */         .toFormatter(); 
/*  87 */     if (target instanceof YearMonth)
/*  88 */       return yearMonthFormatter(locale); 
/*  89 */     if (target instanceof ZonedDateTime) {
/*  90 */       return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG).withLocale(locale);
/*     */     }
/*  92 */     throw new IllegalArgumentException("Cannot format object of class \"" + target
/*  93 */         .getClass().getName() + "\" as a date");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChronoZonedDateTime zonedTime(Object target, ZoneId defaultZoneId) {
/* 104 */     Validate.notNull(target, "Target cannot be null");
/* 105 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/* 106 */     if (target instanceof Instant)
/* 107 */       return ZonedDateTime.ofInstant((Instant)target, defaultZoneId); 
/* 108 */     if (target instanceof LocalDate)
/* 109 */       return ZonedDateTime.of((LocalDate)target, LocalTime.MIDNIGHT, defaultZoneId); 
/* 110 */     if (target instanceof LocalDateTime)
/* 111 */       return ZonedDateTime.of((LocalDateTime)target, defaultZoneId); 
/* 112 */     if (target instanceof LocalTime)
/* 113 */       return ZonedDateTime.of(LocalDate.now(), (LocalTime)target, defaultZoneId); 
/* 114 */     if (target instanceof OffsetDateTime)
/* 115 */       return ((OffsetDateTime)target).toZonedDateTime(); 
/* 116 */     if (target instanceof OffsetTime) {
/* 117 */       LocalTime localTime = ((OffsetTime)target).toLocalTime();
/* 118 */       return ZonedDateTime.of(LocalDate.now(), localTime, defaultZoneId);
/* 119 */     }  if (target instanceof Year) {
/* 120 */       LocalDate localDate = ((Year)target).atDay(1);
/* 121 */       return ZonedDateTime.of(localDate, LocalTime.MIDNIGHT, defaultZoneId);
/* 122 */     }  if (target instanceof YearMonth) {
/* 123 */       LocalDate localDate = ((YearMonth)target).atDay(1);
/* 124 */       return ZonedDateTime.of(localDate, LocalTime.MIDNIGHT, defaultZoneId);
/* 125 */     }  if (target instanceof ZonedDateTime) {
/* 126 */       return (ChronoZonedDateTime)target;
/*     */     }
/* 128 */     throw new IllegalArgumentException("Cannot format object of class \"" + target
/* 129 */         .getClass().getName() + "\" as a date");
/*     */   }
/*     */ 
/*     */   
/*     */   public static TemporalAccessor temporal(Object target) {
/* 134 */     Validate.notNull(target, "Target cannot be null");
/* 135 */     if (target instanceof TemporalAccessor) {
/* 136 */       return (TemporalAccessor)target;
/*     */     }
/* 138 */     throw new IllegalArgumentException("Cannot normalize class \"" + target
/* 139 */         .getClass().getName() + "\" as a date");
/*     */   }
/*     */ 
/*     */   
/*     */   private static DateTimeFormatter yearMonthFormatter(Locale locale) {
/* 144 */     if (shouldDisplayYearBeforeMonth(locale)) {
/* 145 */       return (new DateTimeFormatterBuilder())
/* 146 */         .appendValue(ChronoField.YEAR)
/* 147 */         .appendLiteral(' ')
/* 148 */         .appendText(ChronoField.MONTH_OF_YEAR)
/* 149 */         .toFormatter()
/* 150 */         .withLocale(locale);
/*     */     }
/* 152 */     return (new DateTimeFormatterBuilder())
/* 153 */       .appendText(ChronoField.MONTH_OF_YEAR)
/* 154 */       .appendLiteral(' ')
/* 155 */       .appendValue(ChronoField.YEAR)
/* 156 */       .toFormatter()
/* 157 */       .withLocale(locale);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean shouldDisplayYearBeforeMonth(Locale locale) {
/* 163 */     String country = locale.getCountry();
/* 164 */     switch (country) {
/*     */       case "BT":
/*     */       case "CA":
/*     */       case "CN":
/*     */       case "KP":
/*     */       case "KR":
/*     */       case "TW":
/*     */       case "HU":
/*     */       case "IR":
/*     */       case "JP":
/*     */       case "LT":
/*     */       case "MN":
/* 176 */         return true;
/*     */     } 
/* 178 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\temporal\TemporalObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */