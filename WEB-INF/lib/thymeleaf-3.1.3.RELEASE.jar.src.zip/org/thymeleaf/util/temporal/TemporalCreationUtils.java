/*     */ package org.thymeleaf.util.temporal;
/*     */ 
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.util.TimeZone;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalCreationUtils
/*     */ {
/*     */   public Temporal create(Object year, Object month, Object day) {
/*  53 */     return LocalDate.of(integer(year), integer(month), integer(day));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal create(Object year, Object month, Object day, Object hour, Object minute) {
/*  63 */     return LocalDateTime.of(integer(year), integer(month), integer(day), integer(hour), integer(minute));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal create(Object year, Object month, Object day, Object hour, Object minute, Object second) {
/*  73 */     return LocalDateTime.of(integer(year), integer(month), integer(day), 
/*  74 */         integer(hour), integer(minute), integer(second));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object nanosecond) {
/*  84 */     return LocalDateTime.of(integer(year), integer(month), integer(day), 
/*  85 */         integer(hour), integer(minute), integer(second), integer(nanosecond));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createNow() {
/*  94 */     return LocalDateTime.now();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createNowForTimeZone(Object zoneId) {
/* 103 */     return ZonedDateTime.now(zoneId(zoneId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createToday() {
/* 112 */     return LocalDate.now();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createTodayForTimeZone(Object zoneId) {
/* 121 */     return ZonedDateTime.now(zoneId(zoneId))
/* 122 */       .withHour(0).withMinute(0).withSecond(0).withNano(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createDate(String isoDate) {
/* 131 */     return LocalDate.parse(isoDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createDateTime(String isoDate) {
/* 140 */     return LocalDateTime.parse(isoDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createDate(String isoDate, String pattern) {
/* 149 */     return LocalDate.parse(isoDate, DateTimeFormatter.ofPattern(pattern));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Temporal createDateTime(String isoDate, String pattern) {
/* 158 */     return LocalDateTime.parse(isoDate, DateTimeFormatter.ofPattern(pattern));
/*     */   }
/*     */   
/*     */   private int integer(Object number) {
/* 162 */     Validate.notNull(number, "Argument cannot be null");
/* 163 */     return EvaluationUtils.evaluateAsNumber(number).intValue();
/*     */   }
/*     */   
/*     */   private ZoneId zoneId(Object zoneId) {
/* 167 */     Validate.notNull(zoneId, "ZoneId cannot be null");
/* 168 */     if (zoneId instanceof ZoneId)
/* 169 */       return (ZoneId)zoneId; 
/* 170 */     if (zoneId instanceof TimeZone) {
/* 171 */       TimeZone timeZone = (TimeZone)zoneId;
/* 172 */       return timeZone.toZoneId();
/*     */     } 
/* 174 */     return ZoneId.of(zoneId.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\temporal\TemporalCreationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */