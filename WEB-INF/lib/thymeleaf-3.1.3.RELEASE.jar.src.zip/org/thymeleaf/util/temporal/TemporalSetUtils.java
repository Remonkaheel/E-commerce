/*     */ package org.thymeleaf.util.temporal;
/*     */ 
/*     */ import java.time.ZoneId;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalSetUtils
/*     */ {
/*     */   private final TemporalFormattingUtils temporalFormattingUtils;
/*     */   
/*     */   public TemporalSetUtils(Locale locale, ZoneId defaultZoneId) {
/*  46 */     Validate.notNull(locale, "Locale cannot be null");
/*  47 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/*  48 */     this.temporalFormattingUtils = new TemporalFormattingUtils(locale, defaultZoneId);
/*     */   }
/*     */   
/*     */   public Set<String> setFormat(Set<? extends Temporal> target) {
/*  52 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::format);
/*     */   }
/*     */   
/*     */   public <T extends Temporal> Set<String> setFormat(Set<T> target, Locale locale) {
/*  56 */     return setFormat(target, time -> this.temporalFormattingUtils.format(time, locale));
/*     */   }
/*     */   
/*     */   public <T extends Temporal> Set<String> setFormat(Set<T> target, String pattern) {
/*  60 */     return setFormat(target, time -> this.temporalFormattingUtils.format(time, pattern, null));
/*     */   }
/*     */   
/*     */   public <T extends Temporal> Set<String> setFormat(Set<T> target, String pattern, Locale locale) {
/*  64 */     return setFormat(target, time -> this.temporalFormattingUtils.format(time, pattern, locale, null));
/*     */   }
/*     */   
/*     */   public Set<Integer> setDay(Set<? extends Temporal> target) {
/*  68 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::day);
/*     */   }
/*     */   
/*     */   public Set<Integer> setMonth(Set<? extends Temporal> target) {
/*  72 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::month);
/*     */   }
/*     */   
/*     */   public Set<String> setMonthName(Set<? extends Temporal> target) {
/*  76 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::monthName);
/*     */   }
/*     */   
/*     */   public Set<String> setMonthNameShort(Set<? extends Temporal> target) {
/*  80 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::monthNameShort);
/*     */   }
/*     */   
/*     */   public Set<Integer> setYear(Set<? extends Temporal> target) {
/*  84 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::year);
/*     */   }
/*     */   
/*     */   public Set<Integer> setDayOfWeek(Set<? extends Temporal> target) {
/*  88 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::dayOfWeek);
/*     */   }
/*     */   
/*     */   public Set<String> setDayOfWeekName(Set<? extends Temporal> target) {
/*  92 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::dayOfWeekName);
/*     */   }
/*     */   
/*     */   public Set<String> setDayOfWeekNameShort(Set<? extends Temporal> target) {
/*  96 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::dayOfWeekNameShort);
/*     */   }
/*     */   
/*     */   public Set<Integer> setHour(Set<? extends Temporal> target) {
/* 100 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::hour);
/*     */   }
/*     */   
/*     */   public Set<Integer> setMinute(Set<? extends Temporal> target) {
/* 104 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::minute);
/*     */   }
/*     */   
/*     */   public Set<Integer> setSecond(Set<? extends Temporal> target) {
/* 108 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::second);
/*     */   }
/*     */   
/*     */   public Set<Integer> setNanosecond(Set<? extends Temporal> target) {
/* 112 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::nanosecond);
/*     */   }
/*     */   
/*     */   public Set<String> setFormatISO(Set<? extends Temporal> target) {
/* 116 */     Objects.requireNonNull(this.temporalFormattingUtils); return setFormat(target, this.temporalFormattingUtils::formatISO);
/*     */   }
/*     */ 
/*     */   
/*     */   private <R, T extends Temporal> Set<R> setFormat(Set<T> target, Function<T, R> mapFunction) {
/* 121 */     Validate.notNull(target, "Target cannot be null");
/* 122 */     return (Set<R>)target.stream()
/* 123 */       .map(time -> mapFunction.apply(time))
/* 124 */       .collect(Collectors.toSet());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\temporal\TemporalSetUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */