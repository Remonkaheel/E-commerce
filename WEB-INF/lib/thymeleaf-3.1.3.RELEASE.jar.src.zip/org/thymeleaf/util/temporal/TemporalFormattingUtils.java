/*     */ package org.thymeleaf.util.temporal;
/*     */ 
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalTime;
/*     */ import java.time.ZoneId;
/*     */ import java.time.chrono.ChronoZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalFormattingUtils
/*     */ {
/*  46 */   private static final DateTimeFormatter ISO8601_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZZZ");
/*     */   
/*     */   private final Locale locale;
/*     */   
/*     */   private final ZoneId defaultZoneId;
/*     */   
/*     */   public TemporalFormattingUtils(Locale locale, ZoneId defaultZoneId) {
/*  53 */     Validate.notNull(locale, "Locale cannot be null");
/*  54 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/*  55 */     this.locale = locale;
/*  56 */     this.defaultZoneId = defaultZoneId;
/*     */   }
/*     */   
/*     */   public String format(Object target) {
/*  60 */     return formatDate(target);
/*     */   }
/*     */   
/*     */   public String format(Object target, Locale locale) {
/*  64 */     Validate.notNull(locale, "Locale cannot be null");
/*  65 */     return formatDate(target, null, locale, null);
/*     */   }
/*     */   
/*     */   public String format(Object target, String pattern, ZoneId zoneId) {
/*  69 */     return format(target, pattern, null, zoneId);
/*     */   }
/*     */   
/*     */   public String format(Object target, String pattern, Locale locale, ZoneId zoneId) {
/*  73 */     Validate.notEmpty(pattern, "Pattern cannot be null or empty");
/*  74 */     return formatDate(target, pattern, locale, zoneId);
/*     */   }
/*     */   
/*     */   public Integer day(Object target) {
/*  78 */     if (target == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     TemporalAccessor time = TemporalObjects.temporal(target);
/*  82 */     return Integer.valueOf(time.get(ChronoField.DAY_OF_MONTH));
/*     */   }
/*     */   
/*     */   public Integer month(Object target) {
/*  86 */     if (target == null) {
/*  87 */       return null;
/*     */     }
/*  89 */     TemporalAccessor time = TemporalObjects.temporal(target);
/*  90 */     return Integer.valueOf(time.get(ChronoField.MONTH_OF_YEAR));
/*     */   }
/*     */   
/*     */   public String monthName(Object target) {
/*  94 */     return format(target, "MMMM", null);
/*     */   }
/*     */   
/*     */   public String monthNameShort(Object target) {
/*  98 */     return format(target, "MMM", null);
/*     */   }
/*     */   
/*     */   public Integer year(Object target) {
/* 102 */     if (target == null) {
/* 103 */       return null;
/*     */     }
/* 105 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 106 */     return Integer.valueOf(time.get(ChronoField.YEAR));
/*     */   }
/*     */   
/*     */   public Integer dayOfWeek(Object target) {
/* 110 */     if (target == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 114 */     return Integer.valueOf(time.get(ChronoField.DAY_OF_WEEK));
/*     */   }
/*     */   
/*     */   public String dayOfWeekName(Object target) {
/* 118 */     return format(target, "EEEE", null);
/*     */   }
/*     */   
/*     */   public String dayOfWeekNameShort(Object target) {
/* 122 */     return format(target, "EEE", null);
/*     */   }
/*     */   
/*     */   public Integer hour(Object target) {
/* 126 */     if (target == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 130 */     return Integer.valueOf(time.get(ChronoField.HOUR_OF_DAY));
/*     */   }
/*     */   
/*     */   public Integer minute(Object target) {
/* 134 */     if (target == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 138 */     return Integer.valueOf(time.get(ChronoField.MINUTE_OF_HOUR));
/*     */   }
/*     */   
/*     */   public Integer second(Object target) {
/* 142 */     if (target == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 146 */     return Integer.valueOf(time.get(ChronoField.SECOND_OF_MINUTE));
/*     */   }
/*     */   
/*     */   public Integer nanosecond(Object target) {
/* 150 */     if (target == null) {
/* 151 */       return null;
/*     */     }
/* 153 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 154 */     return Integer.valueOf(time.get(ChronoField.NANO_OF_SECOND));
/*     */   }
/*     */   
/*     */   public String formatISO(Object target) {
/* 158 */     if (target == null)
/* 159 */       return null; 
/* 160 */     if (target instanceof TemporalAccessor) {
/* 161 */       ChronoZonedDateTime time = TemporalObjects.zonedTime(target, this.defaultZoneId);
/* 162 */       return ISO8601_DATE_TIME_FORMATTER.withLocale(this.locale).format(time);
/*     */     } 
/* 164 */     throw new IllegalArgumentException("Cannot format object of class \"" + target
/* 165 */         .getClass().getName() + "\" as a date");
/*     */   }
/*     */ 
/*     */   
/*     */   private String formatDate(Object target) {
/* 170 */     return formatDate(target, null, null, null);
/*     */   }
/*     */   
/*     */   private String formatDate(Object target, String pattern, Locale localeOverride, ZoneId zoneId) {
/* 174 */     if (target == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     Locale formattingLocale = (localeOverride != null) ? localeOverride : this.locale;
/*     */     
/*     */     try {
/* 180 */       if (StringUtils.isEmptyOrWhitespace(pattern)) {
/* 181 */         DateTimeFormatter dateTimeFormatter = TemporalObjects.formatterFor(target, formattingLocale);
/* 182 */         return dateTimeFormatter.format(TemporalObjects.temporal(target));
/*     */       } 
/* 184 */       DateTimeFormatter formatter = computeFormatter(pattern, target.getClass(), formattingLocale, zoneId);
/* 185 */       return formatter.format(TemporalObjects.zonedTime(target, this.defaultZoneId));
/*     */     }
/* 187 */     catch (Exception e) {
/* 188 */       throw new TemplateProcessingException("Error formatting date for locale " + formattingLocale, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static DateTimeFormatter computeFormatter(String pattern, Class<?> targetClass, Locale locale, ZoneId zoneId) {
/*     */     FormatStyle formatStyle;
/* 196 */     switch (pattern) { case "SHORT":
/* 197 */         formatStyle = FormatStyle.SHORT; break;
/* 198 */       case "MEDIUM": formatStyle = FormatStyle.MEDIUM; break;
/* 199 */       case "LONG": formatStyle = FormatStyle.LONG; break;
/* 200 */       case "FULL": formatStyle = FormatStyle.FULL; break;
/* 201 */       default: formatStyle = null; break; }
/*     */     
/* 203 */     if (formatStyle != null) {
/* 204 */       if (LocalDate.class.isAssignableFrom(targetClass)) {
/* 205 */         return DateTimeFormatter.ofLocalizedDate(formatStyle).withLocale(locale);
/*     */       }
/* 207 */       if (LocalTime.class.isAssignableFrom(targetClass)) {
/* 208 */         return DateTimeFormatter.ofLocalizedTime(formatStyle).withLocale(locale);
/*     */       }
/* 210 */       return DateTimeFormatter.ofLocalizedDateTime(formatStyle).withLocale(locale);
/*     */     } 
/* 212 */     return DateTimeFormatter.ofPattern(pattern, locale).withZone(zoneId);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\temporal\TemporalFormattingUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */