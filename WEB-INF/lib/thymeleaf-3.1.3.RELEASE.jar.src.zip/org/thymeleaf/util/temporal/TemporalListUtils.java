/*     */ package org.thymeleaf.util.temporal;
/*     */ 
/*     */ import java.time.ZoneId;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalListUtils
/*     */ {
/*     */   private final TemporalFormattingUtils temporalFormattingUtils;
/*     */   
/*     */   public TemporalListUtils(Locale locale, ZoneId defaultZoneId) {
/*  46 */     Validate.notNull(locale, "Locale cannot be null");
/*  47 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/*  48 */     this.temporalFormattingUtils = new TemporalFormattingUtils(locale, defaultZoneId);
/*     */   }
/*     */   
/*     */   public List<String> listFormat(List<? extends Temporal> target) {
/*  52 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::format);
/*     */   }
/*     */   
/*     */   public <T extends Temporal> List<String> listFormat(List<T> target, Locale locale) {
/*  56 */     return listFormat(target, time -> this.temporalFormattingUtils.format(time, locale));
/*     */   }
/*     */   
/*     */   public <T extends Temporal> List<String> listFormat(List<T> target, String pattern) {
/*  60 */     return listFormat(target, time -> this.temporalFormattingUtils.format(time, pattern, null));
/*     */   }
/*     */   
/*     */   public <T extends Temporal> List<String> listFormat(List<T> target, String pattern, Locale locale) {
/*  64 */     return listFormat(target, time -> this.temporalFormattingUtils.format(time, pattern, locale, null));
/*     */   }
/*     */   
/*     */   public List<Integer> listDay(List<? extends Temporal> target) {
/*  68 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::day);
/*     */   }
/*     */   
/*     */   public List<Integer> listMonth(List<? extends Temporal> target) {
/*  72 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::month);
/*     */   }
/*     */   
/*     */   public List<String> listMonthName(List<? extends Temporal> target) {
/*  76 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::monthName);
/*     */   }
/*     */   
/*     */   public List<String> listMonthNameShort(List<? extends Temporal> target) {
/*  80 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::monthNameShort);
/*     */   }
/*     */   
/*     */   public List<Integer> listYear(List<? extends Temporal> target) {
/*  84 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::year);
/*     */   }
/*     */   
/*     */   public List<Integer> listDayOfWeek(List<? extends Temporal> target) {
/*  88 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::dayOfWeek);
/*     */   }
/*     */   
/*     */   public List<String> listDayOfWeekName(List<? extends Temporal> target) {
/*  92 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::dayOfWeekName);
/*     */   }
/*     */   
/*     */   public List<String> listDayOfWeekNameShort(List<? extends Temporal> target) {
/*  96 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::dayOfWeekNameShort);
/*     */   }
/*     */   
/*     */   public List<Integer> listHour(List<? extends Temporal> target) {
/* 100 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::hour);
/*     */   }
/*     */   
/*     */   public List<Integer> listMinute(List<? extends Temporal> target) {
/* 104 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::minute);
/*     */   }
/*     */   
/*     */   public List<Integer> listSecond(List<? extends Temporal> target) {
/* 108 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::second);
/*     */   }
/*     */   
/*     */   public List<Integer> listNanosecond(List<? extends Temporal> target) {
/* 112 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::nanosecond);
/*     */   }
/*     */   
/*     */   public List<String> listFormatISO(List<? extends Temporal> target) {
/* 116 */     Objects.requireNonNull(this.temporalFormattingUtils); return listFormat(target, this.temporalFormattingUtils::formatISO);
/*     */   }
/*     */ 
/*     */   
/*     */   private <R, T extends Temporal> List<R> listFormat(List<T> target, Function<T, R> mapFunction) {
/* 121 */     Validate.notNull(target, "Target cannot be null");
/* 122 */     return (List<R>)target.stream()
/* 123 */       .map(time -> mapFunction.apply(time))
/* 124 */       .collect(Collectors.toList());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\temporal\TemporalListUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */