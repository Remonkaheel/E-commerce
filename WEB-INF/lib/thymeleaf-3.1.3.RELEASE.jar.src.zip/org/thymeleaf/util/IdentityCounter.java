/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.IdentityHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IdentityCounter<T>
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6965348731301112911L;
/*    */   private final IdentityHashMap<T, Object> counted;
/*    */   
/*    */   public IdentityCounter(int expectedMaxSize) {
/* 49 */     this.counted = new IdentityHashMap<>(expectedMaxSize);
/*    */   }
/*    */   
/*    */   public void count(T object) {
/* 53 */     this.counted.put(object, null);
/*    */   }
/*    */   
/*    */   public boolean isAlreadyCounted(T object) {
/* 57 */     return this.counted.containsKey(object);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\IdentityCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */