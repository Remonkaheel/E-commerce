/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VersionUtils
/*     */ {
/*     */   public static VersionSpec parseVersion(String version) {
/*  37 */     return parseVersion(version, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static VersionSpec parseVersion(String version, String buildTimestamp) {
/*  43 */     if (version == null || version.trim().length() == 0)
/*     */     {
/*     */       
/*  46 */       return new VersionSpec(buildTimestamp); }  try {
/*     */       String numVer;
/*     */       Character qualifierSeparator;
/*     */       String qualifier;
/*     */       int major;
/*     */       Integer minor, patch;
/*  52 */       String ver = version.trim();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  58 */       int endOfNumericVersionIdx = findEndOfNumericVersion(ver);
/*  59 */       if (endOfNumericVersionIdx < 0) {
/*  60 */         numVer = ver;
/*  61 */         qualifierSeparator = null;
/*  62 */         qualifier = null;
/*     */       } else {
/*  64 */         numVer = ver.substring(0, endOfNumericVersionIdx);
/*  65 */         char c = ver.charAt(endOfNumericVersionIdx);
/*  66 */         if (Character.isLetter(c)) {
/*  67 */           qualifierSeparator = null;
/*  68 */           qualifier = ver.substring(endOfNumericVersionIdx);
/*     */         } else {
/*  70 */           qualifierSeparator = Character.valueOf(ver.charAt(endOfNumericVersionIdx));
/*  71 */           qualifier = ver.substring(endOfNumericVersionIdx + 1);
/*  72 */           if (qualifier == null || qualifier.trim().length() == 0)
/*     */           {
/*  74 */             return new VersionSpec(buildTimestamp);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       int separator1Idx = numVer.indexOf('.');
/*  85 */       if (separator1Idx < 0) {
/*  86 */         major = Integer.parseInt(numVer);
/*  87 */         minor = null;
/*  88 */         patch = null;
/*     */       } else {
/*  90 */         major = Integer.parseInt(numVer.substring(0, separator1Idx));
/*  91 */         int separator2Idx = numVer.indexOf('.', separator1Idx + 1);
/*  92 */         if (separator2Idx < 0) {
/*  93 */           minor = Integer.valueOf(numVer.substring(separator1Idx + 1));
/*  94 */           patch = null;
/*     */         } else {
/*  96 */           minor = Integer.valueOf(numVer.substring(separator1Idx + 1, separator2Idx));
/*  97 */           patch = Integer.valueOf(numVer.substring(separator2Idx + 1));
/*     */         } 
/*     */       } 
/*     */       
/* 101 */       return new VersionSpec(major, minor, patch, qualifierSeparator, qualifier, buildTimestamp);
/*     */     }
/* 103 */     catch (Exception e) {
/*     */       
/* 105 */       return new VersionSpec(buildTimestamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findEndOfNumericVersion(CharSequence sequence) {
/* 114 */     int seqLen = sequence.length();
/*     */     
/* 116 */     for (int i = 0; i < seqLen; i++) {
/* 117 */       char c = sequence.charAt(i);
/* 118 */       if (c != '.' && !Character.isDigit(c)) {
/* 119 */         if (i > 1 && sequence.charAt(i - 1) == '.') {
/* 120 */           return i - 1;
/*     */         }
/* 122 */         return i;
/*     */       } 
/*     */     } 
/* 125 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class VersionSpec
/*     */   {
/*     */     private static final String STABLE_RELEASE_QUALIFIER = "RELEASE";
/*     */ 
/*     */     
/*     */     private static final String UNKNOWN_VERSION = "UNKNOWN";
/*     */ 
/*     */     
/*     */     private boolean unknown;
/*     */ 
/*     */     
/*     */     private int major;
/*     */ 
/*     */     
/*     */     private int minor;
/*     */ 
/*     */     
/*     */     private int patch;
/*     */     
/*     */     private String qualifier;
/*     */     
/*     */     private String buildTimestamp;
/*     */     
/*     */     private String versionCore;
/*     */     
/*     */     private String version;
/*     */     
/*     */     private String fullVersion;
/*     */ 
/*     */     
/*     */     private VersionSpec(String buildTimestamp) {
/* 161 */       this.unknown = true;
/*     */       
/* 163 */       this.major = 0;
/* 164 */       this.minor = 0;
/* 165 */       this.patch = 0;
/* 166 */       this.qualifier = null;
/* 167 */       this.buildTimestamp = buildTimestamp;
/*     */       
/* 169 */       this.versionCore = "UNKNOWN";
/* 170 */       this.version = this.versionCore;
/*     */ 
/*     */       
/* 173 */       this
/*     */         
/* 175 */         .fullVersion = (this.buildTimestamp != null) ? String.format("%s (%s)", new Object[] { this.version, this.buildTimestamp }) : this.version;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private VersionSpec(int major, Integer minor, Integer patch, Character qualifierSeparator, String qualifier, String buildTimestamp) {
/* 187 */       Validate.isTrue((major >= 0), "Major version must be >= 0");
/* 188 */       Validate.isTrue((minor == null || minor.intValue() >= 0), "Minor version must be >= 0");
/* 189 */       Validate.isTrue((patch == null || patch.intValue() >= 0), "Patch version must be >= 0");
/* 190 */       Validate.isTrue((patch == null || minor != null), "Patch version present without minor");
/*     */       
/* 192 */       this.unknown = false;
/*     */       
/* 194 */       this.major = major;
/* 195 */       this.minor = (minor != null) ? minor.intValue() : 0;
/* 196 */       this.patch = (patch != null) ? patch.intValue() : 0;
/* 197 */       this.qualifier = qualifier;
/* 198 */       this.buildTimestamp = buildTimestamp;
/*     */       
/* 200 */       this
/*     */ 
/*     */ 
/*     */         
/* 204 */         .versionCore = (patch != null) ? String.format("%d.%d.%d", new Object[] { Integer.valueOf(major), minor, patch }) : ((minor != null) ? String.format("%d.%d", new Object[] { Integer.valueOf(major), minor }) : String.valueOf(major));
/*     */       
/* 206 */       this
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 211 */         .version = (qualifier == null) ? this.versionCore : ((qualifierSeparator != null) ? String.format("%s%c%s", new Object[] { this.versionCore, qualifierSeparator, qualifier }) : String.format("%s%s", new Object[] { this.versionCore, qualifier }));
/*     */ 
/*     */       
/* 214 */       this
/*     */         
/* 216 */         .fullVersion = (buildTimestamp != null) ? String.format("%s (%s)", new Object[] { this.version, this.buildTimestamp }) : this.version;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isUnknown() {
/* 221 */       return this.unknown;
/*     */     }
/*     */     
/*     */     public int getMajor() {
/* 225 */       return this.major;
/*     */     }
/*     */     
/*     */     public int getMinor() {
/* 229 */       return this.minor;
/*     */     }
/*     */     
/*     */     public int getPatch() {
/* 233 */       return this.patch;
/*     */     }
/*     */     
/*     */     public boolean hasQualifier() {
/* 237 */       return (this.qualifier != null);
/*     */     }
/*     */     
/*     */     public String getQualifier() {
/* 241 */       return this.qualifier;
/*     */     }
/*     */     
/*     */     public String getVersionCore() {
/* 245 */       return this.versionCore;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 249 */       return this.version;
/*     */     }
/*     */     
/*     */     public boolean hasBuildTimestamp() {
/* 253 */       return (this.buildTimestamp != null);
/*     */     }
/*     */     
/*     */     public String getBuildTimestamp() {
/* 257 */       return this.buildTimestamp;
/*     */     }
/*     */     
/*     */     public String getFullVersion() {
/* 261 */       return this.fullVersion;
/*     */     }
/*     */     
/*     */     public boolean isAtLeast(int major) {
/* 265 */       return isAtLeast(major, 0);
/*     */     }
/*     */     
/*     */     public boolean isAtLeast(int major, int minor) {
/* 269 */       return isAtLeast(major, minor, 0);
/*     */     }
/*     */     
/*     */     public boolean isAtLeast(int major, int minor, int patch) {
/* 273 */       return (this.major > major || (this.major == major && this.minor > minor) || (this.major == major && this.minor == minor && this.patch >= patch));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isStableRelease() {
/* 279 */       return ((!this.unknown && (this.qualifier == null || this.qualifier.length() == 0)) || "RELEASE"
/* 280 */         .equals(this.qualifier));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\VersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */