/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.standard.expression.LiteralValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EvaluationUtils
/*     */ {
/*     */   public static boolean evaluateAsBoolean(Object condition) {
/*  45 */     boolean result = true;
/*  46 */     if (condition == null) {
/*  47 */       result = false;
/*     */     }
/*  49 */     else if (condition instanceof Boolean) {
/*  50 */       result = ((Boolean)condition).booleanValue();
/*  51 */     } else if (condition instanceof Number) {
/*  52 */       if (condition instanceof BigDecimal) {
/*  53 */         result = (((BigDecimal)condition).compareTo(BigDecimal.ZERO) != 0);
/*  54 */       } else if (condition instanceof BigInteger) {
/*  55 */         result = !condition.equals(BigInteger.ZERO);
/*     */       } else {
/*  57 */         result = (((Number)condition).doubleValue() != 0.0D);
/*     */       } 
/*  59 */     } else if (condition instanceof Character) {
/*  60 */       result = (((Character)condition).charValue() != '\000');
/*  61 */     } else if (condition instanceof String) {
/*  62 */       String condStr = ((String)condition).trim().toLowerCase();
/*  63 */       result = (!"false".equals(condStr) && !"off".equals(condStr) && !"no".equals(condStr));
/*  64 */     } else if (condition instanceof LiteralValue) {
/*  65 */       String condStr = ((LiteralValue)condition).getValue().trim().toLowerCase();
/*  66 */       result = (!"false".equals(condStr) && !"off".equals(condStr) && !"no".equals(condStr));
/*     */     } else {
/*  68 */       result = true;
/*     */     } 
/*     */     
/*  71 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal evaluateAsNumber(Object object) {
/*  80 */     if (object == null) {
/*  81 */       return null;
/*     */     }
/*     */     
/*  84 */     if (object instanceof Number) {
/*  85 */       if (object instanceof BigDecimal)
/*  86 */         return (BigDecimal)object; 
/*  87 */       if (object instanceof BigInteger)
/*  88 */         return new BigDecimal((BigInteger)object); 
/*  89 */       if (object instanceof Byte)
/*  90 */         return new BigDecimal(((Byte)object).intValue()); 
/*  91 */       if (object instanceof Short)
/*  92 */         return new BigDecimal(((Short)object).intValue()); 
/*  93 */       if (object instanceof Integer)
/*  94 */         return new BigDecimal(((Integer)object).intValue()); 
/*  95 */       if (object instanceof Long)
/*  96 */         return new BigDecimal(((Long)object).longValue()); 
/*  97 */       if (object instanceof Float)
/*     */       {
/*  99 */         return new BigDecimal(((Float)object).doubleValue()); } 
/* 100 */       if (object instanceof Double)
/*     */       {
/* 102 */         return new BigDecimal(((Double)object).doubleValue());
/*     */       }
/* 104 */     } else if (object instanceof String && ((String)object).length() > 0) {
/* 105 */       char c0 = ((String)object).charAt(0);
/*     */ 
/*     */       
/* 108 */       if ((c0 >= '0' && c0 <= '9') || c0 == '+' || c0 == '-') {
/*     */         try {
/* 110 */           return new BigDecimal(((String)object).trim());
/* 111 */         } catch (NumberFormatException ignored) {
/* 112 */           return null;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Object> evaluateAsList(Object value) {
/* 126 */     if (value == null) {
/* 127 */       return Collections.emptyList();
/*     */     }
/* 129 */     List<Object> result = new ArrayList();
/* 130 */     if (value instanceof Iterable) {
/* 131 */       for (Object obj : value) {
/* 132 */         result.add(obj);
/*     */       }
/* 134 */     } else if (value instanceof Map) {
/* 135 */       for (Map.Entry<Object, Object> obj : (Iterable<Map.Entry<Object, Object>>)((Map)value).entrySet())
/*     */       {
/*     */ 
/*     */         
/* 139 */         result.add(new MapEntry<>(obj.getKey(), obj.getValue()));
/*     */       }
/* 141 */     } else if (value.getClass().isArray()) {
/* 142 */       if (value instanceof byte[]) {
/* 143 */         for (byte obj : (byte[])value) {
/* 144 */           result.add(Byte.valueOf(obj));
/*     */         }
/* 146 */       } else if (value instanceof short[]) {
/* 147 */         for (short obj : (short[])value) {
/* 148 */           result.add(Short.valueOf(obj));
/*     */         }
/* 150 */       } else if (value instanceof int[]) {
/* 151 */         for (int obj : (int[])value) {
/* 152 */           result.add(Integer.valueOf(obj));
/*     */         }
/* 154 */       } else if (value instanceof long[]) {
/* 155 */         for (long obj : (long[])value) {
/* 156 */           result.add(Long.valueOf(obj));
/*     */         }
/* 158 */       } else if (value instanceof float[]) {
/* 159 */         for (float obj : (float[])value) {
/* 160 */           result.add(Float.valueOf(obj));
/*     */         }
/* 162 */       } else if (value instanceof double[]) {
/* 163 */         for (double obj : (double[])value) {
/* 164 */           result.add(Double.valueOf(obj));
/*     */         }
/* 166 */       } else if (value instanceof boolean[]) {
/* 167 */         for (boolean obj : (boolean[])value) {
/* 168 */           result.add(Boolean.valueOf(obj));
/*     */         }
/* 170 */       } else if (value instanceof char[]) {
/* 171 */         for (char obj : (char[])value) {
/* 172 */           result.add(Character.valueOf(obj));
/*     */         }
/*     */       } else {
/* 175 */         Object[] objValue = (Object[])value;
/* 176 */         Collections.addAll(result, objValue);
/*     */       } 
/*     */     } else {
/* 179 */       result.add(value);
/*     */     } 
/*     */     
/* 182 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object[] evaluateAsArray(Object value) {
/* 191 */     List<Object> result = new ArrayList();
/* 192 */     if (value == null) {
/* 193 */       return new Object[] { null };
/*     */     }
/* 195 */     if (value instanceof Iterable) {
/* 196 */       for (Object obj : value) {
/* 197 */         result.add(obj);
/*     */       }
/* 199 */     } else if (value instanceof Map) {
/* 200 */       for (Object obj : ((Map)value).entrySet())
/* 201 */         result.add(obj); 
/*     */     } else {
/* 203 */       if (value.getClass().isArray()) {
/* 204 */         return (Object[])value;
/*     */       }
/* 206 */       result.add(value);
/*     */     } 
/* 208 */     return result.toArray(new Object[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MapEntry<K, V>
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     private final K entryKey;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final V entryValue;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MapEntry(K key, V value) {
/* 229 */       this.entryKey = key;
/* 230 */       this.entryValue = value;
/*     */     }
/*     */     
/*     */     public K getKey() {
/* 234 */       return this.entryKey;
/*     */     }
/*     */     
/*     */     public V getValue() {
/* 238 */       return this.entryValue;
/*     */     }
/*     */     
/*     */     public V setValue(V value) {
/* 242 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 247 */       return (new StringBuilder()).append(this.entryKey).append("=").append(this.entryValue).toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 252 */       if (this == o) {
/* 253 */         return true;
/*     */       }
/* 255 */       if (!(o instanceof Map.Entry)) {
/* 256 */         return false;
/*     */       }
/* 258 */       Map.Entry mapEntry = (Map.Entry)o;
/* 259 */       if ((this.entryKey != null) ? !this.entryKey.equals(mapEntry.getKey()) : (mapEntry.getKey() != null)) {
/* 260 */         return false;
/*     */       }
/* 262 */       if ((this.entryValue != null) ? !this.entryValue.equals(mapEntry.getValue()) : (mapEntry.getValue() != null)) {
/* 263 */         return false;
/*     */       }
/* 265 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 270 */       int result = (this.entryKey != null) ? this.entryKey.hashCode() : 0;
/* 271 */       result = 31 * result + ((this.entryValue != null) ? this.entryValue.hashCode() : 0);
/* 272 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\EvaluationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */