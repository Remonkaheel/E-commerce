/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.standard.serializer.IStandardCSSSerializer;
/*     */ import org.thymeleaf.standard.serializer.IStandardJavaScriptSerializer;
/*     */ import org.thymeleaf.standard.serializer.StandardSerializers;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ import org.unbescape.xml.XmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LazyEscapingCharSequence
/*     */   extends AbstractLazyCharSequence
/*     */ {
/*     */   private final IEngineConfiguration configuration;
/*     */   private final TemplateMode templateMode;
/*     */   private final Object input;
/*     */   
/*     */   public LazyEscapingCharSequence(IEngineConfiguration configuration, TemplateMode templateMode, Object input) {
/*  68 */     if (configuration == null) {
/*  69 */       throw new IllegalArgumentException("Engine Configuraion is null, which is forbidden");
/*     */     }
/*  71 */     if (templateMode == null) {
/*  72 */       throw new IllegalArgumentException("Template Mode is null, which is forbidden");
/*     */     }
/*     */     
/*  75 */     this.configuration = configuration;
/*  76 */     this.templateMode = templateMode;
/*  77 */     this.input = input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolveText() {
/*  86 */     Writer stringWriter = new FastStringWriter();
/*  87 */     produceEscapedOutput(stringWriter);
/*  88 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeUnresolved(Writer writer) throws IOException {
/*  94 */     produceEscapedOutput(writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void produceEscapedOutput(Writer writer) {
/*     */     try {
/*     */       IStandardJavaScriptSerializer javaScriptSerializer;
/*     */       IStandardCSSSerializer cssSerializer;
/* 117 */       switch (this.templateMode) {
/*     */ 
/*     */         
/*     */         case TEXT:
/*     */         case HTML:
/* 122 */           if (this.input != null) {
/* 123 */             HtmlEscape.escapeHtml4Xml(this.input.toString(), writer);
/*     */           }
/*     */           return;
/*     */         case XML:
/* 127 */           if (this.input != null)
/*     */           {
/*     */             
/* 130 */             XmlEscape.escapeXml10(this.input.toString(), writer);
/*     */           }
/*     */           return;
/*     */         case JAVASCRIPT:
/* 134 */           javaScriptSerializer = StandardSerializers.getJavaScriptSerializer(this.configuration);
/* 135 */           javaScriptSerializer.serializeValue(this.input, writer);
/*     */           return;
/*     */         case CSS:
/* 138 */           cssSerializer = StandardSerializers.getCSSSerializer(this.configuration);
/* 139 */           cssSerializer.serializeValue(this.input, writer);
/*     */           return;
/*     */         case RAW:
/* 142 */           if (this.input != null) {
/* 143 */             writer.write(this.input.toString());
/*     */           }
/*     */           return;
/*     */       } 
/* 147 */       throw new TemplateProcessingException("Unrecognized template mode " + this.templateMode + ". Cannot produce escaped output for this template mode.");
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 152 */     catch (IOException e) {
/* 153 */       throw new TemplateProcessingException("An error happened while trying to produce escaped output", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymelea\\util\LazyEscapingCharSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */