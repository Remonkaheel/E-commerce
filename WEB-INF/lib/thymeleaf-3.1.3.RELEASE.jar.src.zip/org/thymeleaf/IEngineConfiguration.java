package org.thymeleaf;

import java.util.Map;
import java.util.Set;
import org.thymeleaf.cache.ICacheManager;
import org.thymeleaf.context.IEngineContextFactory;
import org.thymeleaf.dialect.IDialect;
import org.thymeleaf.engine.AttributeDefinitions;
import org.thymeleaf.engine.ElementDefinitions;
import org.thymeleaf.engine.TemplateManager;
import org.thymeleaf.expression.IExpressionObjectFactory;
import org.thymeleaf.linkbuilder.ILinkBuilder;
import org.thymeleaf.messageresolver.IMessageResolver;
import org.thymeleaf.model.IModelFactory;
import org.thymeleaf.postprocessor.IPostProcessor;
import org.thymeleaf.preprocessor.IPreProcessor;
import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
import org.thymeleaf.processor.comment.ICommentProcessor;
import org.thymeleaf.processor.doctype.IDocTypeProcessor;
import org.thymeleaf.processor.element.IElementProcessor;
import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesProcessor;
import org.thymeleaf.processor.text.ITextProcessor;
import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateparser.markup.decoupled.IDecoupledTemplateLogicResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

public interface IEngineConfiguration {
  Set<ITemplateResolver> getTemplateResolvers();
  
  Set<IMessageResolver> getMessageResolvers();
  
  Set<ILinkBuilder> getLinkBuilders();
  
  ICacheManager getCacheManager();
  
  IEngineContextFactory getEngineContextFactory();
  
  IDecoupledTemplateLogicResolver getDecoupledTemplateLogicResolver();
  
  Set<DialectConfiguration> getDialectConfigurations();
  
  Set<IDialect> getDialects();
  
  <T extends IDialect> Set<T> getDialectsOfType(Class<T> paramClass);
  
  boolean isStandardDialectPresent();
  
  String getStandardDialectPrefix();
  
  ElementDefinitions getElementDefinitions();
  
  AttributeDefinitions getAttributeDefinitions();
  
  Set<ITemplateBoundariesProcessor> getTemplateBoundariesProcessors(TemplateMode paramTemplateMode);
  
  Set<ICDATASectionProcessor> getCDATASectionProcessors(TemplateMode paramTemplateMode);
  
  Set<ICommentProcessor> getCommentProcessors(TemplateMode paramTemplateMode);
  
  Set<IDocTypeProcessor> getDocTypeProcessors(TemplateMode paramTemplateMode);
  
  Set<IElementProcessor> getElementProcessors(TemplateMode paramTemplateMode);
  
  Set<ITextProcessor> getTextProcessors(TemplateMode paramTemplateMode);
  
  Set<IProcessingInstructionProcessor> getProcessingInstructionProcessors(TemplateMode paramTemplateMode);
  
  Set<IXMLDeclarationProcessor> getXMLDeclarationProcessors(TemplateMode paramTemplateMode);
  
  Set<IPreProcessor> getPreProcessors(TemplateMode paramTemplateMode);
  
  Set<IPostProcessor> getPostProcessors(TemplateMode paramTemplateMode);
  
  Map<String, Object> getExecutionAttributes();
  
  IExpressionObjectFactory getExpressionObjectFactory();
  
  TemplateManager getTemplateManager();
  
  IModelFactory getModelFactory(TemplateMode paramTemplateMode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\IEngineConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */