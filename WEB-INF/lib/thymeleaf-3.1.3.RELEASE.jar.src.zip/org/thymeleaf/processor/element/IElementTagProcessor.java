package org.thymeleaf.processor.element;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;

public interface IElementTagProcessor extends IElementProcessor {
  void process(ITemplateContext paramITemplateContext, IProcessableElementTag paramIProcessableElementTag, IElementTagStructureHandler paramIElementTagStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\element\IElementTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */