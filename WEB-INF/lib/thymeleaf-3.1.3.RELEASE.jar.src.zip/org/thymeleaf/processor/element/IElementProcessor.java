package org.thymeleaf.processor.element;

import org.thymeleaf.processor.IProcessor;

public interface IElementProcessor extends IProcessor {
  MatchingElementName getMatchingElementName();
  
  MatchingAttributeName getMatchingAttributeName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\element\IElementProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */