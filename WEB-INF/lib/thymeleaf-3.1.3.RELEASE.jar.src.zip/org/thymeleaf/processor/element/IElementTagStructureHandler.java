package org.thymeleaf.processor.element;

import org.thymeleaf.engine.AttributeName;
import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.AttributeValueQuotes;
import org.thymeleaf.model.IModel;

public interface IElementTagStructureHandler {
  void reset();
  
  void setLocalVariable(String paramString, Object paramObject);
  
  void removeLocalVariable(String paramString);
  
  void setAttribute(String paramString1, String paramString2);
  
  void setAttribute(String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  void replaceAttribute(AttributeName paramAttributeName, String paramString1, String paramString2);
  
  void replaceAttribute(AttributeName paramAttributeName, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  void removeAttribute(String paramString);
  
  void removeAttribute(String paramString1, String paramString2);
  
  void removeAttribute(AttributeName paramAttributeName);
  
  void setSelectionTarget(Object paramObject);
  
  void setInliner(IInliner paramIInliner);
  
  void setTemplateData(TemplateData paramTemplateData);
  
  void setBody(CharSequence paramCharSequence, boolean paramBoolean);
  
  void setBody(IModel paramIModel, boolean paramBoolean);
  
  void insertBefore(IModel paramIModel);
  
  void insertImmediatelyAfter(IModel paramIModel, boolean paramBoolean);
  
  void replaceWith(CharSequence paramCharSequence, boolean paramBoolean);
  
  void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  void removeElement();
  
  void removeTags();
  
  void removeBody();
  
  void removeAllButFirstChild();
  
  void iterateElement(String paramString1, String paramString2, Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\element\IElementTagStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */