package org.thymeleaf.processor.element;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IModel;

public interface IElementModelProcessor extends IElementProcessor {
  void process(ITemplateContext paramITemplateContext, IModel paramIModel, IElementModelStructureHandler paramIElementModelStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\element\IElementModelProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */