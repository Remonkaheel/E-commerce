package org.thymeleaf.processor.element;

import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;

public interface IElementModelStructureHandler {
  void reset();
  
  void setLocalVariable(String paramString, Object paramObject);
  
  void removeLocalVariable(String paramString);
  
  void setSelectionTarget(Object paramObject);
  
  void setInliner(IInliner paramIInliner);
  
  void setTemplateData(TemplateData paramTemplateData);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\element\IElementModelStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */