/*     */ package org.thymeleaf.processor.element;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeNames;
/*     */ import org.thymeleaf.engine.ElementNames;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.processor.AbstractProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractElementModelProcessor
/*     */   extends AbstractProcessor
/*     */   implements IElementModelProcessor
/*     */ {
/*     */   private final String dialectPrefix;
/*     */   private final MatchingElementName matchingElementName;
/*     */   private final MatchingAttributeName matchingAttributeName;
/*     */   
/*     */   public AbstractElementModelProcessor(TemplateMode templateMode, String dialectPrefix, String elementName, boolean prefixElementName, String attributeName, boolean prefixAttributeName, int precedence) {
/*  57 */     super(templateMode, precedence);
/*     */     
/*  59 */     this.dialectPrefix = dialectPrefix;
/*     */     
/*  61 */     this
/*     */ 
/*     */       
/*  64 */       .matchingElementName = (elementName == null) ? null : MatchingElementName.forElementName(templateMode, 
/*  65 */         ElementNames.forName(templateMode, prefixElementName ? this.dialectPrefix : null, elementName));
/*  66 */     this
/*     */ 
/*     */       
/*  69 */       .matchingAttributeName = (attributeName == null) ? null : MatchingAttributeName.forAttributeName(templateMode, 
/*  70 */         AttributeNames.forName(templateMode, prefixAttributeName ? this.dialectPrefix : null, attributeName));
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String getDialectPrefix() {
/*  75 */     return this.dialectPrefix;
/*     */   }
/*     */   
/*     */   public final MatchingElementName getMatchingElementName() {
/*  79 */     return this.matchingElementName;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MatchingAttributeName getMatchingAttributeName() {
/*  84 */     return this.matchingAttributeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void process(ITemplateContext context, IModel model, IElementModelStructureHandler structureHandler) {
/*  93 */     ITemplateEvent firstEvent = null;
/*     */     
/*     */     try {
/*  96 */       firstEvent = model.get(0);
/*     */       
/*  98 */       doProcess(context, model, structureHandler);
/*     */     }
/* 100 */     catch (TemplateProcessingException e) {
/*     */ 
/*     */ 
/*     */       
/* 104 */       if (firstEvent != null) {
/*     */         
/* 106 */         String modelTemplateName = firstEvent.getTemplateName();
/* 107 */         int modelLine = firstEvent.getLine();
/* 108 */         int modelCol = firstEvent.getCol();
/*     */         
/* 110 */         if (modelTemplateName != null && 
/* 111 */           !e.hasTemplateName()) {
/* 112 */           e.setTemplateName(modelTemplateName);
/*     */         }
/*     */         
/* 115 */         if (modelLine != -1 && modelCol != -1 && 
/* 116 */           !e.hasLineAndCol()) {
/* 117 */           e.setLineAndCol(modelLine, modelCol);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 123 */       throw e;
/*     */     }
/* 125 */     catch (Exception e) {
/*     */ 
/*     */ 
/*     */       
/* 129 */       String modelTemplateName = null;
/* 130 */       int modelLine = -1;
/* 131 */       int modelCol = -1;
/*     */       
/* 133 */       if (firstEvent != null) {
/*     */         
/* 135 */         modelTemplateName = firstEvent.getTemplateName();
/* 136 */         modelLine = firstEvent.getLine();
/* 137 */         modelCol = firstEvent.getCol();
/*     */       } 
/*     */       
/* 140 */       throw new TemplateProcessingException("Error during execution of processor '" + 
/* 141 */           getClass().getName() + "'", modelTemplateName, modelLine, modelCol, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IModel paramIModel, IElementModelStructureHandler paramIElementModelStructureHandler);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\element\AbstractElementModelProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */