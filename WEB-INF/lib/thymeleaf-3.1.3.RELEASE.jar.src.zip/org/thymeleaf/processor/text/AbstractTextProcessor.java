/*    */ package org.thymeleaf.processor.text;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IText;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractTextProcessor
/*    */   extends AbstractProcessor
/*    */   implements ITextProcessor
/*    */ {
/*    */   public AbstractTextProcessor(TemplateMode templateMode, int precedence) {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void process(ITemplateContext context, IText text, ITextStructureHandler structureHandler) {
/*    */     try {
/* 57 */       doProcess(context, text, structureHandler);
/*    */     }
/* 59 */     catch (TemplateProcessingException e) {
/* 60 */       if (text.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(text.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(text.getLine(), text.getCol());
/*    */         }
/*    */       } 
/* 68 */       throw e;
/* 69 */     } catch (Exception e) {
/* 70 */       throw new TemplateProcessingException("Error during execution of processor '" + 
/* 71 */           getClass().getName() + "'", text
/* 72 */           .getTemplateName(), text.getLine(), text.getCol(), e);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IText paramIText, ITextStructureHandler paramITextStructureHandler);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\text\AbstractTextProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */