package org.thymeleaf.processor.text;

import org.thymeleaf.model.IModel;

public interface ITextStructureHandler {
  void reset();
  
  void setText(CharSequence paramCharSequence);
  
  void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  void removeText();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\text\ITextStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */