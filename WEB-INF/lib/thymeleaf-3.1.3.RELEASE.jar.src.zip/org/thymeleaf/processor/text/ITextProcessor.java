package org.thymeleaf.processor.text;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IText;
import org.thymeleaf.processor.IProcessor;

public interface ITextProcessor extends IProcessor {
  void process(ITemplateContext paramITemplateContext, IText paramIText, ITextStructureHandler paramITextStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\text\ITextProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */