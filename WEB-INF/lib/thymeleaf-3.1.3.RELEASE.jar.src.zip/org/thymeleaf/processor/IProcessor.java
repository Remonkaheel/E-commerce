package org.thymeleaf.processor;

import org.thymeleaf.templatemode.TemplateMode;

public interface IProcessor {
  TemplateMode getTemplateMode();
  
  int getPrecedence();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\IProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */