package org.thymeleaf.processor.comment;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IComment;
import org.thymeleaf.processor.IProcessor;

public interface ICommentProcessor extends IProcessor {
  void process(ITemplateContext paramITemplateContext, IComment paramIComment, ICommentStructureHandler paramICommentStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\comment\ICommentProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */