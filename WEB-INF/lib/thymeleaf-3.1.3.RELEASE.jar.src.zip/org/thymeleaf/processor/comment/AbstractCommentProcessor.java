/*    */ package org.thymeleaf.processor.comment;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IComment;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractCommentProcessor
/*    */   extends AbstractProcessor
/*    */   implements ICommentProcessor
/*    */ {
/*    */   public AbstractCommentProcessor(TemplateMode templateMode, int precedence) {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void process(ITemplateContext context, IComment comment, ICommentStructureHandler structureHandler) {
/*    */     try {
/* 57 */       doProcess(context, comment, structureHandler);
/*    */     }
/* 59 */     catch (TemplateProcessingException e) {
/* 60 */       if (comment.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(comment.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(comment.getLine(), comment.getCol());
/*    */         }
/*    */       } 
/* 68 */       throw e;
/* 69 */     } catch (Exception e) {
/* 70 */       throw new TemplateProcessingException("Error during execution of processor '" + 
/* 71 */           getClass().getName() + "'", comment
/* 72 */           .getTemplateName(), comment.getLine(), comment.getCol(), e);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IComment paramIComment, ICommentStructureHandler paramICommentStructureHandler);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\comment\AbstractCommentProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */