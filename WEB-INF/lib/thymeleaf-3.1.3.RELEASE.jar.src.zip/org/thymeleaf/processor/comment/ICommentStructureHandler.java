package org.thymeleaf.processor.comment;

import org.thymeleaf.model.IModel;

public interface ICommentStructureHandler {
  void reset();
  
  void setContent(CharSequence paramCharSequence);
  
  void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  void removeComment();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\comment\ICommentStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */