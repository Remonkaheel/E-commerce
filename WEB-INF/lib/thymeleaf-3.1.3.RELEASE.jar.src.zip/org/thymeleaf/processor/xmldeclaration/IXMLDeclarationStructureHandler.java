package org.thymeleaf.processor.xmldeclaration;

import org.thymeleaf.model.IModel;

public interface IXMLDeclarationStructureHandler {
  void reset();
  
  void setXMLDeclaration(String paramString1, String paramString2, String paramString3, String paramString4);
  
  void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  void removeXMLDeclaration();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\xmldeclaration\IXMLDeclarationStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */