/*    */ package org.thymeleaf.processor.xmldeclaration;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IXMLDeclaration;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXMLDeclarationProcessor
/*    */   extends AbstractProcessor
/*    */   implements IXMLDeclarationProcessor
/*    */ {
/*    */   public AbstractXMLDeclarationProcessor(TemplateMode templateMode, int precedence) {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void process(ITemplateContext context, IXMLDeclaration xmlDeclaration, IXMLDeclarationStructureHandler structureHandler) {
/*    */     try {
/* 57 */       doProcess(context, xmlDeclaration, structureHandler);
/*    */     }
/* 59 */     catch (TemplateProcessingException e) {
/* 60 */       if (xmlDeclaration.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(xmlDeclaration.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(xmlDeclaration.getLine(), xmlDeclaration.getCol());
/*    */         }
/*    */       } 
/* 68 */       throw e;
/* 69 */     } catch (Exception e) {
/* 70 */       throw new TemplateProcessingException("Error during execution of processor '" + 
/* 71 */           getClass().getName() + "'", xmlDeclaration
/* 72 */           .getTemplateName(), xmlDeclaration.getLine(), xmlDeclaration.getCol(), e);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IXMLDeclaration paramIXMLDeclaration, IXMLDeclarationStructureHandler paramIXMLDeclarationStructureHandler);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\xmldeclaration\AbstractXMLDeclarationProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */