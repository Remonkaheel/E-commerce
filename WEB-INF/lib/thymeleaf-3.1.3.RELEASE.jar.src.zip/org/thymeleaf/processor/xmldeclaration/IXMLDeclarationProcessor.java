package org.thymeleaf.processor.xmldeclaration;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IXMLDeclaration;
import org.thymeleaf.processor.IProcessor;

public interface IXMLDeclarationProcessor extends IProcessor {
  void process(ITemplateContext paramITemplateContext, IXMLDeclaration paramIXMLDeclaration, IXMLDeclarationStructureHandler paramIXMLDeclarationStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\xmldeclaration\IXMLDeclarationProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */