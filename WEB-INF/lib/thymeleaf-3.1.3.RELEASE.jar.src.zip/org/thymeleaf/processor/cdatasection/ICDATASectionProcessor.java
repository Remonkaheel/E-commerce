package org.thymeleaf.processor.cdatasection;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.processor.IProcessor;

public interface ICDATASectionProcessor extends IProcessor {
  void process(ITemplateContext paramITemplateContext, ICDATASection paramICDATASection, ICDATASectionStructureHandler paramICDATASectionStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\cdatasection\ICDATASectionProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */