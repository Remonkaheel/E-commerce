package org.thymeleaf.processor.templateboundaries;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ITemplateEnd;
import org.thymeleaf.model.ITemplateStart;
import org.thymeleaf.processor.IProcessor;

public interface ITemplateBoundariesProcessor extends IProcessor {
  void processTemplateStart(ITemplateContext paramITemplateContext, ITemplateStart paramITemplateStart, ITemplateBoundariesStructureHandler paramITemplateBoundariesStructureHandler);
  
  void processTemplateEnd(ITemplateContext paramITemplateContext, ITemplateEnd paramITemplateEnd, ITemplateBoundariesStructureHandler paramITemplateBoundariesStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\templateboundaries\ITemplateBoundariesProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */