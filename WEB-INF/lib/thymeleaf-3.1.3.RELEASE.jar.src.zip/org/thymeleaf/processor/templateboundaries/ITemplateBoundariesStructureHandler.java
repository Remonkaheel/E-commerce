package org.thymeleaf.processor.templateboundaries;

import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.IModel;

public interface ITemplateBoundariesStructureHandler {
  void reset();
  
  void setLocalVariable(String paramString, Object paramObject);
  
  void removeLocalVariable(String paramString);
  
  void setSelectionTarget(Object paramObject);
  
  void setInliner(IInliner paramIInliner);
  
  void insert(String paramString, boolean paramBoolean);
  
  void insert(IModel paramIModel, boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\templateboundaries\ITemplateBoundariesStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */