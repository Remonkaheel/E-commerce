package org.thymeleaf.processor.doctype;

import org.thymeleaf.model.IModel;

public interface IDocTypeStructureHandler {
  void reset();
  
  void setDocType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
  
  void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  void removeDocType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\doctype\IDocTypeStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */