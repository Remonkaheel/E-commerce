package org.thymeleaf.processor.doctype;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IDocType;
import org.thymeleaf.processor.IProcessor;

public interface IDocTypeProcessor extends IProcessor {
  void process(ITemplateContext paramITemplateContext, IDocType paramIDocType, IDocTypeStructureHandler paramIDocTypeStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\doctype\IDocTypeProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */