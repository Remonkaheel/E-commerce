/*    */ package org.thymeleaf.processor.doctype;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IDocType;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDocTypeProcessor
/*    */   extends AbstractProcessor
/*    */   implements IDocTypeProcessor
/*    */ {
/*    */   public AbstractDocTypeProcessor(TemplateMode templateMode, int precedence) {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void process(ITemplateContext context, IDocType docType, IDocTypeStructureHandler structureHandler) {
/*    */     try {
/* 57 */       doProcess(context, docType, structureHandler);
/*    */     }
/* 59 */     catch (TemplateProcessingException e) {
/* 60 */       if (docType.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(docType.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(docType.getLine(), docType.getCol());
/*    */         }
/*    */       } 
/* 68 */       throw e;
/* 69 */     } catch (Exception e) {
/* 70 */       throw new TemplateProcessingException("Error during execution of processor '" + 
/* 71 */           getClass().getName() + "'", docType
/* 72 */           .getTemplateName(), docType.getLine(), docType.getCol(), e);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IDocType paramIDocType, IDocTypeStructureHandler paramIDocTypeStructureHandler);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\doctype\AbstractDocTypeProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */