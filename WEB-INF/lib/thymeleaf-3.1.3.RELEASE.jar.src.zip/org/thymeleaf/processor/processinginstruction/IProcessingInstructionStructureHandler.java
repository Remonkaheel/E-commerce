package org.thymeleaf.processor.processinginstruction;

import org.thymeleaf.model.IModel;

public interface IProcessingInstructionStructureHandler {
  void reset();
  
  void setProcessingInstruction(String paramString1, String paramString2);
  
  void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  void removeProcessingInstruction();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\processinginstruction\IProcessingInstructionStructureHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */