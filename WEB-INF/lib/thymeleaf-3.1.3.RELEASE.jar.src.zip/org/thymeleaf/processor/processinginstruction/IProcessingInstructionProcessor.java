package org.thymeleaf.processor.processinginstruction;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessingInstruction;
import org.thymeleaf.processor.IProcessor;

public interface IProcessingInstructionProcessor extends IProcessor {
  void process(ITemplateContext paramITemplateContext, IProcessingInstruction paramIProcessingInstruction, IProcessingInstructionStructureHandler paramIProcessingInstructionStructureHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\processinginstruction\IProcessingInstructionProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */