/*    */ package org.thymeleaf.processor.processinginstruction;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessingInstruction;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractProcessingInstructionProcessor
/*    */   extends AbstractProcessor
/*    */   implements IProcessingInstructionProcessor
/*    */ {
/*    */   public AbstractProcessingInstructionProcessor(TemplateMode templateMode, int precedence) {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void process(ITemplateContext context, IProcessingInstruction processingInstruction, IProcessingInstructionStructureHandler structureHandler) {
/*    */     try {
/* 57 */       doProcess(context, processingInstruction, structureHandler);
/*    */     }
/* 59 */     catch (TemplateProcessingException e) {
/* 60 */       if (processingInstruction.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(processingInstruction.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(processingInstruction.getLine(), processingInstruction.getCol());
/*    */         }
/*    */       } 
/* 68 */       throw e;
/* 69 */     } catch (Exception e) {
/* 70 */       throw new TemplateProcessingException("Error during execution of processor '" + 
/* 71 */           getClass().getName() + "'", processingInstruction
/* 72 */           .getTemplateName(), processingInstruction.getLine(), processingInstruction.getCol(), e);
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IProcessingInstruction paramIProcessingInstruction, IProcessingInstructionStructureHandler paramIProcessingInstructionStructureHandler);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-3.1.3.RELEASE.jar!\org\thymeleaf\processor\processinginstruction\AbstractProcessingInstructionProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */