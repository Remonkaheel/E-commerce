/*     */ package org.springframework.security.config.authentication;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.NamespaceHandlerResolver;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.ProviderManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationManagerBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ATT_ALIAS = "alias";
/*     */   private static final String ATT_REF = "ref";
/*     */   private static final String ATT_ERASE_CREDENTIALS = "erase-credentials";
/*     */   private static final String AUTHENTICATION_EVENT_PUBLISHER_BEAN_NAME = "defaultAuthenticationEventPublisher";
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*  64 */     String id = element.getAttribute("id");
/*  65 */     if (!StringUtils.hasText(id)) {
/*  66 */       if (pc.getRegistry().containsBeanDefinition("org.springframework.security.authenticationManager")) {
/*  67 */         pc.getReaderContext()
/*  68 */           .warning("Overriding globally registered AuthenticationManager", pc.extractSource(element));
/*     */       }
/*  70 */       id = "org.springframework.security.authenticationManager";
/*     */     } 
/*  72 */     pc.pushContainingComponent(new CompositeComponentDefinition(element.getTagName(), pc.extractSource(element)));
/*  73 */     BeanDefinitionBuilder providerManagerBldr = BeanDefinitionBuilder.rootBeanDefinition(ProviderManager.class);
/*  74 */     String alias = element.getAttribute("alias");
/*  75 */     ManagedList<BeanMetadataElement> managedList = new ManagedList();
/*  76 */     NamespaceHandlerResolver resolver = pc.getReaderContext().getNamespaceHandlerResolver();
/*  77 */     NodeList children = element.getChildNodes();
/*  78 */     for (int i = 0; i < children.getLength(); i++) {
/*  79 */       Node node = children.item(i);
/*  80 */       if (node instanceof Element) {
/*  81 */         managedList.add(extracted(element, pc, resolver, (Element)node));
/*     */       }
/*     */     } 
/*  84 */     if (managedList.isEmpty()) {
/*  85 */       managedList.add(new RootBeanDefinition(NullAuthenticationProvider.class));
/*     */     }
/*  87 */     providerManagerBldr.addConstructorArgValue(managedList);
/*  88 */     if ("false".equals(element.getAttribute("erase-credentials"))) {
/*  89 */       providerManagerBldr.addPropertyValue("eraseCredentialsAfterAuthentication", Boolean.valueOf(false));
/*     */     }
/*     */     
/*  92 */     if (!pc.getRegistry().containsBeanDefinition("defaultAuthenticationEventPublisher")) {
/*     */       
/*  94 */       RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(DefaultAuthenticationEventPublisher.class);
/*  95 */       pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)rootBeanDefinition, "defaultAuthenticationEventPublisher"));
/*     */     } 
/*     */     
/*  98 */     providerManagerBldr.addPropertyReference("authenticationEventPublisher", "defaultAuthenticationEventPublisher");
/*     */     
/* 100 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)providerManagerBldr.getBeanDefinition(), id));
/* 101 */     if (StringUtils.hasText(alias)) {
/* 102 */       pc.getRegistry().registerAlias(id, alias);
/* 103 */       pc.getReaderContext().fireAliasRegistered(id, alias, pc.extractSource(element));
/*     */     } 
/* 105 */     if (!"org.springframework.security.authenticationManager".equals(id) && 
/* 106 */       !pc.getRegistry().containsBeanDefinition("org.springframework.security.authenticationManager") && 
/* 107 */       !pc.getRegistry().isAlias("org.springframework.security.authenticationManager")) {
/* 108 */       pc.getRegistry().registerAlias(id, "org.springframework.security.authenticationManager");
/* 109 */       pc.getReaderContext().fireAliasRegistered(id, "org.springframework.security.authenticationManager", pc.extractSource(element));
/*     */     } 
/* 111 */     pc.popAndRegisterContainingComponent();
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanMetadataElement extracted(Element element, ParserContext pc, NamespaceHandlerResolver resolver, Element providerElement) {
/* 117 */     String ref = providerElement.getAttribute("ref");
/* 118 */     if (!StringUtils.hasText(ref)) {
/* 119 */       BeanDefinition provider = resolver.resolve(providerElement.getNamespaceURI()).parse(providerElement, pc);
/* 120 */       Assert.notNull(provider, () -> "Parser for " + providerElement.getNodeName() + " returned a null bean definition");
/*     */       
/* 122 */       String providerId = pc.getReaderContext().generateBeanName(provider);
/* 123 */       pc.registerBeanComponent(new BeanComponentDefinition(provider, providerId));
/* 124 */       return (BeanMetadataElement)new RuntimeBeanReference(providerId);
/*     */     } 
/* 126 */     if (providerElement.getAttributes().getLength() > 1) {
/* 127 */       pc.getReaderContext()
/* 128 */         .error("authentication-provider element cannot be used with other attributes when using 'ref' attribute", pc
/* 129 */           .extractSource(element));
/*     */     }
/* 131 */     NodeList providerChildren = providerElement.getChildNodes();
/* 132 */     for (int i = 0; i < providerChildren.getLength(); i++) {
/* 133 */       if (providerChildren.item(i) instanceof Element) {
/* 134 */         pc.getReaderContext()
/* 135 */           .error("authentication-provider element cannot have child elements when used with 'ref' attribute", pc
/* 136 */             .extractSource(element));
/*     */       }
/*     */     } 
/* 139 */     return (BeanMetadataElement)new RuntimeBeanReference(ref);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class NullAuthenticationProvider
/*     */     implements AuthenticationProvider
/*     */   {
/*     */     public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 152 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supports(Class<?> authentication) {
/* 157 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\AuthenticationManagerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */