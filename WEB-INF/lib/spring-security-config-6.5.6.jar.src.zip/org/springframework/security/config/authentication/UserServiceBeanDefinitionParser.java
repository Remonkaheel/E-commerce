/*     */ package org.springframework.security.config.authentication;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.PropertiesFactoryBean;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.provisioning.InMemoryUserDetailsManager;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserServiceBeanDefinitionParser
/*     */   extends AbstractUserDetailsServiceBeanDefinitionParser
/*     */ {
/*     */   static final String ATT_PASSWORD = "password";
/*     */   static final String ATT_NAME = "name";
/*     */   static final String ELT_USER = "user";
/*     */   static final String ATT_AUTHORITIES = "authorities";
/*     */   static final String ATT_PROPERTIES = "properties";
/*     */   static final String ATT_DISABLED = "disabled";
/*     */   static final String ATT_LOCKED = "locked";
/*     */   private SecureRandom random;
/*     */   
/*     */   protected String getBeanClassName(Element element) {
/*  57 */     return InMemoryUserDetailsManager.class.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
/*  63 */     String userProperties = element.getAttribute("properties");
/*  64 */     List<Element> userElts = DomUtils.getChildElementsByTagName(element, "user");
/*  65 */     if (StringUtils.hasText(userProperties)) {
/*  66 */       if (!CollectionUtils.isEmpty(userElts)) {
/*  67 */         throw new BeanDefinitionStoreException("Use of a properties file and user elements are mutually exclusive");
/*     */       }
/*     */       
/*  70 */       RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(PropertiesFactoryBean.class);
/*  71 */       rootBeanDefinition.getPropertyValues().addPropertyValue("location", userProperties);
/*  72 */       builder.addConstructorArgValue(rootBeanDefinition);
/*     */       return;
/*     */     } 
/*  75 */     if (CollectionUtils.isEmpty(userElts)) {
/*  76 */       throw new BeanDefinitionStoreException("You must supply user definitions, either with <user> child elements or a properties file (using the 'properties' attribute)");
/*     */     }
/*     */     
/*  79 */     ManagedList<BeanDefinition> users = new ManagedList();
/*  80 */     for (Element elt : userElts) {
/*  81 */       Element userElt = elt;
/*  82 */       String userName = userElt.getAttribute("name");
/*  83 */       String password = userElt.getAttribute("password");
/*  84 */       if (!StringUtils.hasLength(password)) {
/*  85 */         password = generateRandomPassword();
/*     */       }
/*  87 */       boolean locked = "true".equals(userElt.getAttribute("locked"));
/*  88 */       boolean disabled = "true".equals(userElt.getAttribute("disabled"));
/*  89 */       BeanDefinitionBuilder authorities = BeanDefinitionBuilder.rootBeanDefinition(AuthorityUtils.class);
/*  90 */       authorities.addConstructorArgValue(userElt.getAttribute("authorities"));
/*  91 */       authorities.setFactoryMethod("commaSeparatedStringToAuthorityList");
/*  92 */       BeanDefinitionBuilder user = BeanDefinitionBuilder.rootBeanDefinition(User.class);
/*  93 */       user.addConstructorArgValue(userName);
/*  94 */       user.addConstructorArgValue(password);
/*  95 */       user.addConstructorArgValue(Boolean.valueOf(!disabled));
/*  96 */       user.addConstructorArgValue(Boolean.valueOf(true));
/*  97 */       user.addConstructorArgValue(Boolean.valueOf(true));
/*  98 */       user.addConstructorArgValue(Boolean.valueOf(!locked));
/*  99 */       user.addConstructorArgValue(authorities.getBeanDefinition());
/* 100 */       users.add(user.getBeanDefinition());
/*     */     } 
/* 102 */     builder.addConstructorArgValue(users);
/*     */   }
/*     */   
/*     */   private String generateRandomPassword() {
/* 106 */     if (this.random == null) {
/*     */       try {
/* 108 */         this.random = SecureRandom.getInstance("SHA1PRNG");
/*     */       }
/* 110 */       catch (NoSuchAlgorithmException ex) {
/*     */         
/* 112 */         throw new RuntimeException("Failed find SHA1PRNG algorithm!");
/*     */       } 
/*     */     }
/* 115 */     return Long.toString(this.random.nextLong());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\UserServiceBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */