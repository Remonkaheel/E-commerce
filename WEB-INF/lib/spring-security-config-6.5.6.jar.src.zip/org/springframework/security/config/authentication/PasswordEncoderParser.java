/*    */ package org.springframework.security.config.authentication;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PasswordEncoderParser
/*    */ {
/*    */   static final String ATT_REF = "ref";
/*    */   public static final String ATT_HASH = "hash";
/*    */   static final String OPT_HASH_BCRYPT = "bcrypt";
/* 46 */   private static final Map<String, Class<?>> ENCODER_CLASSES = Collections.singletonMap("bcrypt", BCryptPasswordEncoder.class);
/*    */   
/*    */   private BeanMetadataElement passwordEncoder;
/*    */ 
/*    */   
/*    */   public PasswordEncoderParser(Element element, ParserContext parserContext) {
/* 52 */     parse(element, parserContext);
/*    */   }
/*    */   
/*    */   private void parse(Element element, ParserContext parserContext) {
/* 56 */     if (element == null) {
/* 57 */       if (parserContext.getRegistry().containsBeanDefinition("passwordEncoder")) {
/* 58 */         this.passwordEncoder = (BeanMetadataElement)parserContext.getRegistry().getBeanDefinition("passwordEncoder");
/*    */       }
/*    */       return;
/*    */     } 
/* 62 */     String hash = element.getAttribute("hash");
/* 63 */     String ref = element.getAttribute("ref");
/* 64 */     if (StringUtils.hasText(ref)) {
/* 65 */       this.passwordEncoder = (BeanMetadataElement)new RuntimeBeanReference(ref);
/*    */     } else {
/*    */       
/* 68 */       this.passwordEncoder = (BeanMetadataElement)createPasswordEncoderBeanDefinition(hash);
/* 69 */       ((RootBeanDefinition)this.passwordEncoder).setSource(parserContext.extractSource(element));
/*    */     } 
/*    */   }
/*    */   
/*    */   public static BeanDefinition createPasswordEncoderBeanDefinition(String hash) {
/* 74 */     Class<?> beanClass = ENCODER_CLASSES.get(hash);
/* 75 */     BeanDefinitionBuilder beanBldr = BeanDefinitionBuilder.rootBeanDefinition(beanClass);
/* 76 */     return (BeanDefinition)beanBldr.getBeanDefinition();
/*    */   }
/*    */   
/*    */   public BeanMetadataElement getPasswordEncoder() {
/* 80 */     return this.passwordEncoder;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\PasswordEncoderParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */