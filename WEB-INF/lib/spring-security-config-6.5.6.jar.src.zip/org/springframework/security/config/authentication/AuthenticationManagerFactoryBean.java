/*    */ package org.springframework.security.config.authentication;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.ObservationAuthenticationManager;
/*    */ import org.springframework.security.authentication.ProviderManager;
/*    */ import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationManagerFactoryBean
/*    */   implements FactoryBean<AuthenticationManager>, BeanFactoryAware
/*    */ {
/*    */   private BeanFactory bf;
/* 49 */   private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;
/*    */ 
/*    */   
/*    */   public static final String MISSING_BEAN_ERROR_MESSAGE = "Did you forget to add a global <authentication-manager> element to your configuration (with child <authentication-provider> elements)? Alternatively you can use the authentication-manager-ref attribute on your <http> and <global-method-security> elements.";
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthenticationManager getObject() throws Exception {
/*    */     try {
/* 58 */       return (AuthenticationManager)this.bf.getBean("org.springframework.security.authenticationManager");
/*    */     }
/* 60 */     catch (NoSuchBeanDefinitionException ex) {
/* 61 */       if (!"org.springframework.security.authenticationManager".equals(ex.getBeanName())) {
/* 62 */         throw ex;
/*    */       }
/* 64 */       UserDetailsService uds = (UserDetailsService)this.bf.getBeanProvider(UserDetailsService.class).getIfUnique();
/* 65 */       if (uds == null) {
/* 66 */         throw new NoSuchBeanDefinitionException("org.springframework.security.authenticationManager", "Did you forget to add a global <authentication-manager> element to your configuration (with child <authentication-provider> elements)? Alternatively you can use the authentication-manager-ref attribute on your <http> and <global-method-security> elements.");
/*    */       }
/* 68 */       DaoAuthenticationProvider provider = new DaoAuthenticationProvider(uds);
/* 69 */       PasswordEncoder passwordEncoder = (PasswordEncoder)this.bf.getBeanProvider(PasswordEncoder.class).getIfUnique();
/* 70 */       if (passwordEncoder != null) {
/* 71 */         provider.setPasswordEncoder(passwordEncoder);
/*    */       }
/* 73 */       provider.afterPropertiesSet();
/* 74 */       ProviderManager manager = new ProviderManager(Arrays.asList(new AuthenticationProvider[] { (AuthenticationProvider)provider }));
/* 75 */       if (this.observationRegistry.isNoop()) {
/* 76 */         return (AuthenticationManager)manager;
/*    */       }
/* 78 */       return (AuthenticationManager)new ObservationAuthenticationManager(this.observationRegistry, (AuthenticationManager)manager);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<? extends AuthenticationManager> getObjectType() {
/* 84 */     return (Class)ProviderManager.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSingleton() {
/* 89 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 94 */     this.bf = beanFactory;
/*    */   }
/*    */   
/*    */   public void setObservationRegistry(ObservationRegistry observationRegistry) {
/* 98 */     this.observationRegistry = observationRegistry;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\AuthenticationManagerFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */