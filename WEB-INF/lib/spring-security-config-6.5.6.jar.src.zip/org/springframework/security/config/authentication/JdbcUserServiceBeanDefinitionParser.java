/*    */ package org.springframework.security.config.authentication;
/*    */ 
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcUserServiceBeanDefinitionParser
/*    */   extends AbstractUserDetailsServiceBeanDefinitionParser
/*    */ {
/*    */   static final String ATT_DATA_SOURCE = "data-source-ref";
/*    */   static final String ATT_USERS_BY_USERNAME_QUERY = "users-by-username-query";
/*    */   static final String ATT_AUTHORITIES_BY_USERNAME_QUERY = "authorities-by-username-query";
/*    */   static final String ATT_GROUP_AUTHORITIES_QUERY = "group-authorities-by-username-query";
/*    */   static final String ATT_ROLE_PREFIX = "role-prefix";
/*    */   
/*    */   protected String getBeanClassName(Element element) {
/* 39 */     return "org.springframework.security.provisioning.JdbcUserDetailsManager";
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
/* 44 */     String dataSource = element.getAttribute("data-source-ref");
/* 45 */     if (StringUtils.hasText(dataSource)) {
/* 46 */       builder.addPropertyReference("dataSource", dataSource);
/*    */     } else {
/*    */       
/* 49 */       parserContext.getReaderContext()
/* 50 */         .error("data-source-ref is required for jdbc-user-service", parserContext
/* 51 */           .extractSource(element));
/*    */     } 
/* 53 */     String usersQuery = element.getAttribute("users-by-username-query");
/* 54 */     String authoritiesQuery = element.getAttribute("authorities-by-username-query");
/* 55 */     String groupAuthoritiesQuery = element.getAttribute("group-authorities-by-username-query");
/* 56 */     String rolePrefix = element.getAttribute("role-prefix");
/* 57 */     if (StringUtils.hasText(rolePrefix)) {
/* 58 */       builder.addPropertyValue("rolePrefix", rolePrefix);
/*    */     }
/* 60 */     if (StringUtils.hasText(usersQuery)) {
/* 61 */       builder.addPropertyValue("usersByUsernameQuery", usersQuery);
/*    */     }
/* 63 */     if (StringUtils.hasText(authoritiesQuery)) {
/* 64 */       builder.addPropertyValue("authoritiesByUsernameQuery", authoritiesQuery);
/*    */     }
/* 66 */     if (StringUtils.hasText(groupAuthoritiesQuery)) {
/* 67 */       builder.addPropertyValue("enableGroups", Boolean.TRUE);
/* 68 */       builder.addPropertyValue("groupAuthoritiesByUsernameQuery", groupAuthoritiesQuery);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\JdbcUserServiceBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */