/*    */ package org.springframework.security.config.authentication;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.authentication.CachingUserDetailsService;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractUserDetailsServiceBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   static final String CACHE_REF = "cache-ref";
/*    */   public static final String CACHING_SUFFIX = ".caching";
/*    */   
/*    */   protected abstract String getBeanClassName(Element paramElement);
/*    */   
/*    */   protected abstract void doParse(Element paramElement, ParserContext paramParserContext, BeanDefinitionBuilder paramBeanDefinitionBuilder);
/*    */   
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 49 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(getBeanClassName(element));
/* 50 */     doParse(element, parserContext, builder);
/* 51 */     RootBeanDefinition userService = (RootBeanDefinition)builder.getBeanDefinition();
/* 52 */     String beanId = resolveId(element, (AbstractBeanDefinition)userService, parserContext);
/* 53 */     parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)userService, beanId));
/* 54 */     String cacheRef = element.getAttribute("cache-ref");
/*    */     
/* 56 */     if (StringUtils.hasText(cacheRef)) {
/*    */       
/* 58 */       BeanDefinitionBuilder cachingUSBuilder = BeanDefinitionBuilder.rootBeanDefinition(CachingUserDetailsService.class);
/* 59 */       cachingUSBuilder.addConstructorArgReference(beanId);
/* 60 */       cachingUSBuilder.addPropertyValue("userCache", new RuntimeBeanReference(cacheRef));
/* 61 */       AbstractBeanDefinition abstractBeanDefinition = cachingUSBuilder.getBeanDefinition();
/* 62 */       parserContext
/* 63 */         .registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, beanId + ".caching"));
/*    */     } 
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private String resolveId(Element element, AbstractBeanDefinition definition, ParserContext pc) throws BeanDefinitionStoreException {
/* 70 */     String id = element.getAttribute("id");
/* 71 */     if (pc.isNested()) {
/*    */       
/* 73 */       if (!StringUtils.hasText(id)) {
/* 74 */         id = pc.getReaderContext().generateBeanName((BeanDefinition)definition);
/*    */       }
/* 76 */       BeanDefinition container = pc.getContainingBeanDefinition();
/* 77 */       container.getPropertyValues().add("userDetailsService", new RuntimeBeanReference(id));
/*    */     } 
/* 79 */     if (StringUtils.hasText(id)) {
/* 80 */       return id;
/*    */     }
/*    */     
/* 83 */     if (pc.getRegistry().containsBeanDefinition("org.springframework.security.userDetailsService")) {
/* 84 */       throw new BeanDefinitionStoreException("No id supplied and another bean is already registered as org.springframework.security.userDetailsService");
/*    */     }
/*    */     
/* 87 */     return "org.springframework.security.userDetailsService";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\AbstractUserDetailsServiceBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */