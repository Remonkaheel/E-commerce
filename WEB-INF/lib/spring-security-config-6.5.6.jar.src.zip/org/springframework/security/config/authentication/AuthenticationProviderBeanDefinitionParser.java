/*    */ package org.springframework.security.config.authentication;
/*    */ 
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationProviderBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   private static final String ATT_USER_DETAILS_REF = "user-service-ref";
/*    */   
/*    */   public BeanDefinition parse(Element element, ParserContext pc) {
/* 44 */     RootBeanDefinition authProvider = new RootBeanDefinition(DaoAuthenticationProvider.class);
/* 45 */     authProvider.setSource(pc.extractSource(element));
/* 46 */     Element passwordEncoderElt = DomUtils.getChildElementByTagName(element, "password-encoder");
/* 47 */     PasswordEncoderParser pep = new PasswordEncoderParser(passwordEncoderElt, pc);
/* 48 */     BeanMetadataElement passwordEncoder = pep.getPasswordEncoder();
/* 49 */     if (passwordEncoder != null) {
/* 50 */       authProvider.getPropertyValues().addPropertyValue("passwordEncoder", passwordEncoder);
/*    */     }
/* 52 */     Element userServiceElt = DomUtils.getChildElementByTagName(element, "user-service");
/* 53 */     if (userServiceElt == null) {
/* 54 */       userServiceElt = DomUtils.getChildElementByTagName(element, "jdbc-user-service");
/*    */     }
/* 56 */     if (userServiceElt == null) {
/* 57 */       userServiceElt = DomUtils.getChildElementByTagName(element, "ldap-user-service");
/*    */     }
/* 59 */     String ref = element.getAttribute("user-service-ref");
/* 60 */     if (StringUtils.hasText(ref)) {
/* 61 */       if (userServiceElt != null) {
/* 62 */         pc.getReaderContext()
/* 63 */           .error("The user-service-ref attribute cannot be used in combination with childelements 'user-service', 'jdbc-user-service' or 'ldap-user-service'", element);
/*    */       }
/*    */ 
/*    */       
/* 67 */       authProvider.getPropertyValues().add("userDetailsService", new RuntimeBeanReference(ref));
/*    */     }
/*    */     else {
/*    */       
/* 71 */       if (userServiceElt != null) {
/* 72 */         pc.getDelegate().parseCustomElement(userServiceElt, (BeanDefinition)authProvider);
/*    */       } else {
/*    */         
/* 75 */         pc.getReaderContext().error("A user-service is required", element);
/*    */       } 
/*    */       
/* 78 */       String cacheRef = userServiceElt.getAttribute("cache-ref");
/*    */       
/* 80 */       if (StringUtils.hasText(cacheRef)) {
/* 81 */         authProvider.getPropertyValues().addPropertyValue("userCache", new RuntimeBeanReference(cacheRef));
/*    */       }
/*    */     } 
/* 84 */     return (BeanDefinition)authProvider;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\authentication\AuthenticationProviderBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */