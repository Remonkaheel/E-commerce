/*    */ package org.springframework.security.config.aot.hint;
/*    */ 
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OAuth2LoginRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/* 34 */     hints.reflection()
/* 35 */       .registerTypeIfPresent(classLoader, "org.springframework.security.oauth2.jwt.JwtDecoder", new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\aot\hint\OAuth2LoginRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */