/*     */ package org.springframework.security.config.core.userdetails;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.util.InMemoryResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactiveUserDetailsServiceResourceFactoryBean
/*     */   implements ResourceLoaderAware, FactoryBean<MapReactiveUserDetailsService>
/*     */ {
/*  40 */   private UserDetailsResourceFactoryBean userDetails = new UserDetailsResourceFactoryBean();
/*     */ 
/*     */   
/*     */   public MapReactiveUserDetailsService getObject() throws Exception {
/*  44 */     Collection<UserDetails> users = this.userDetails.getObject();
/*  45 */     return new MapReactiveUserDetailsService(users);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getObjectType() {
/*  50 */     return MapReactiveUserDetailsService.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/*  55 */     this.userDetails.setResourceLoader(resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLocation(String resourceLocation) {
/*  65 */     this.userDetails.setResourceLocation(resourceLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResource(Resource resource) {
/*  74 */     this.userDetails.setResource(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReactiveUserDetailsServiceResourceFactoryBean fromResourceLocation(String resourceLocation) {
/*  86 */     ReactiveUserDetailsServiceResourceFactoryBean result = new ReactiveUserDetailsServiceResourceFactoryBean();
/*  87 */     result.setResourceLocation(resourceLocation);
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReactiveUserDetailsServiceResourceFactoryBean fromResource(Resource propertiesResource) {
/*  99 */     ReactiveUserDetailsServiceResourceFactoryBean result = new ReactiveUserDetailsServiceResourceFactoryBean();
/* 100 */     result.setResource(propertiesResource);
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReactiveUserDetailsServiceResourceFactoryBean fromString(String users) {
/* 112 */     ReactiveUserDetailsServiceResourceFactoryBean result = new ReactiveUserDetailsServiceResourceFactoryBean();
/* 113 */     result.setResource((Resource)new InMemoryResource(users));
/* 114 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\cor\\userdetails\ReactiveUserDetailsServiceResourceFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */