/*     */ package org.springframework.security.config.core.userdetails;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.util.InMemoryResource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserDetailsResourceFactoryBean
/*     */   implements ResourceLoaderAware, FactoryBean<Collection<UserDetails>>
/*     */ {
/*  54 */   private ResourceLoader resourceLoader = (ResourceLoader)new DefaultResourceLoader();
/*     */   
/*     */   private String resourceLocation;
/*     */   
/*     */   private Resource resource;
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/*  62 */     Assert.notNull(resourceLoader, "resourceLoader cannot be null");
/*  63 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<UserDetails> getObject() throws Exception {
/*  68 */     Properties userProperties = new Properties();
/*  69 */     Resource resource = getPropertiesResource();
/*  70 */     InputStream in = resource.getInputStream(); 
/*  71 */     try { userProperties.load(in);
/*  72 */       if (in != null) in.close();  } catch (Throwable throwable) { if (in != null)
/*  73 */         try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return (new UserDetailsMapFactoryBean(userProperties)).getObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getObjectType() {
/*  78 */     return Collection.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLocation(String resourceLocation) {
/*  88 */     this.resourceLocation = resourceLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResource(Resource resource) {
/*  97 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   private Resource getPropertiesResource() {
/* 101 */     Resource result = this.resource;
/* 102 */     if (result == null && this.resourceLocation != null) {
/* 103 */       result = this.resourceLoader.getResource(this.resourceLocation);
/*     */     }
/* 105 */     Assert.notNull(result, "resource cannot be null if resourceLocation is null");
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserDetailsResourceFactoryBean fromResourceLocation(String resourceLocation) {
/* 117 */     UserDetailsResourceFactoryBean result = new UserDetailsResourceFactoryBean();
/* 118 */     result.setResourceLocation(resourceLocation);
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserDetailsResourceFactoryBean fromResource(Resource propertiesResource) {
/* 130 */     UserDetailsResourceFactoryBean result = new UserDetailsResourceFactoryBean();
/* 131 */     result.setResource(propertiesResource);
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserDetailsResourceFactoryBean fromString(String users) {
/* 141 */     InMemoryResource resource = new InMemoryResource(users);
/* 142 */     return fromResource((Resource)resource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\cor\\userdetails\UserDetailsResourceFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */