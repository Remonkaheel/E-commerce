/*    */ package org.springframework.security.config.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GrantedAuthorityDefaults
/*    */ {
/*    */   private final String rolePrefix;
/*    */   
/*    */   public GrantedAuthorityDefaults(String rolePrefix) {
/* 32 */     this.rolePrefix = rolePrefix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRolePrefix() {
/* 40 */     return this.rolePrefix;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\core\GrantedAuthorityDefaults.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */