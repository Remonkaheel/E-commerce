/*    */ package org.springframework.security.config.core.userdetails;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.memory.UserAttribute;
/*    */ import org.springframework.security.core.userdetails.memory.UserAttributeEditor;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsMapFactoryBean
/*    */   implements FactoryBean<Collection<UserDetails>>
/*    */ {
/*    */   private final Map<String, String> userProperties;
/*    */   
/*    */   public UserDetailsMapFactoryBean(Map<String, String> userProperties) {
/* 56 */     Assert.notNull(userProperties, "userProperties cannot be null");
/* 57 */     this.userProperties = userProperties;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<UserDetails> getObject() {
/* 62 */     Collection<UserDetails> users = new ArrayList<>(this.userProperties.size());
/* 63 */     UserAttributeEditor editor = new UserAttributeEditor();
/* 64 */     this.userProperties.forEach((name, property) -> {
/*    */           editor.setAsText(property);
/*    */           
/*    */           UserAttribute attr = (UserAttribute)editor.getValue();
/*    */           Assert.state((attr != null), ());
/*    */           String password = attr.getPassword();
/*    */           boolean disabled = !attr.isEnabled();
/*    */           List<GrantedAuthority> authorities = attr.getAuthorities();
/*    */           users.add(User.withUsername(name).password(password).disabled(disabled).authorities(authorities).build());
/*    */         });
/* 74 */     return users;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 80 */     return Collection.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\cor\\userdetails\UserDetailsMapFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */