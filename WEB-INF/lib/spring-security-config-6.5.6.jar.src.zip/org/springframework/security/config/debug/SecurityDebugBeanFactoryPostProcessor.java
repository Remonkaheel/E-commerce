/*    */ package org.springframework.security.config.debug;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*    */ import org.springframework.security.web.debug.DebugFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityDebugBeanFactoryPostProcessor
/*    */   implements BeanDefinitionRegistryPostProcessor
/*    */ {
/* 37 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   
/*    */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 41 */     this.logger.warn("\n\n********************************************************************\n**********        Security debugging is enabled.       *************\n**********    This may include sensitive information.  *************\n**********      Do not use in a production system!     *************\n********************************************************************\n\n");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     if (registry.containsBeanDefinition("org.springframework.security.filterChainProxy")) {
/* 49 */       BeanDefinition fcpBeanDef = registry.getBeanDefinition("org.springframework.security.filterChainProxy");
/* 50 */       BeanDefinitionBuilder debugFilterBldr = BeanDefinitionBuilder.genericBeanDefinition(DebugFilter.class);
/* 51 */       debugFilterBldr.addConstructorArgValue(fcpBeanDef);
/*    */ 
/*    */ 
/*    */       
/* 55 */       registry.removeAlias("springSecurityFilterChain");
/* 56 */       registry.registerBeanDefinition("springSecurityFilterChain", (BeanDefinition)debugFilterBldr.getBeanDefinition());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\debug\SecurityDebugBeanFactoryPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */