/*    */ package org.springframework.security.config.ldap;
/*    */ 
/*    */ import org.springframework.ldap.core.support.BaseLdapPathContextSource;
/*    */ import org.springframework.security.ldap.authentication.AbstractLdapAuthenticator;
/*    */ import org.springframework.security.ldap.authentication.BindAuthenticator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LdapBindAuthenticationManagerFactory
/*    */   extends AbstractLdapAuthenticationManagerFactory<BindAuthenticator>
/*    */ {
/*    */   public LdapBindAuthenticationManagerFactory(BaseLdapPathContextSource contextSource) {
/* 33 */     super(contextSource);
/*    */   }
/*    */ 
/*    */   
/*    */   protected BindAuthenticator createDefaultLdapAuthenticator() {
/* 38 */     return new BindAuthenticator(getContextSource());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\LdapBindAuthenticationManagerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */