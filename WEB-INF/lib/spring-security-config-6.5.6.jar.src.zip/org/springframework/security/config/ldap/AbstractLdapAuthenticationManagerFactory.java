/*     */ package org.springframework.security.config.ldap;
/*     */ 
/*     */ import org.springframework.ldap.core.support.BaseLdapPathContextSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.ProviderManager;
/*     */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.ldap.authentication.AbstractLdapAuthenticator;
/*     */ import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
/*     */ import org.springframework.security.ldap.authentication.LdapAuthenticator;
/*     */ import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
/*     */ import org.springframework.security.ldap.search.LdapUserSearch;
/*     */ import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
/*     */ import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLdapAuthenticationManagerFactory<T extends AbstractLdapAuthenticator>
/*     */ {
/*     */   private BaseLdapPathContextSource contextSource;
/*     */   private String[] userDnPatterns;
/*     */   private LdapAuthoritiesPopulator ldapAuthoritiesPopulator;
/*     */   private GrantedAuthoritiesMapper authoritiesMapper;
/*     */   private UserDetailsContextMapper userDetailsContextMapper;
/*     */   private String userSearchFilter;
/*     */   private String userSearchBase;
/*     */   
/*     */   AbstractLdapAuthenticationManagerFactory(BaseLdapPathContextSource contextSource) {
/*  56 */     this.userSearchBase = "";
/*     */     this.contextSource = contextSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextSource(BaseLdapPathContextSource contextSource) {
/*  64 */     this.contextSource = contextSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BaseLdapPathContextSource getContextSource() {
/*  72 */     return this.contextSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLdapAuthoritiesPopulator(LdapAuthoritiesPopulator ldapAuthoritiesPopulator) {
/*  81 */     this.ldapAuthoritiesPopulator = ldapAuthoritiesPopulator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthoritiesMapper(GrantedAuthoritiesMapper authoritiesMapper) {
/*  92 */     this.authoritiesMapper = authoritiesMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsContextMapper(UserDetailsContextMapper userDetailsContextMapper) {
/* 101 */     this.userDetailsContextMapper = userDetailsContextMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDnPatterns(String... userDnPatterns) {
/* 114 */     this.userDnPatterns = userDnPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserSearchFilter(String userSearchFilter) {
/* 123 */     this.userSearchFilter = userSearchFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserSearchBase(String userSearchBase) {
/* 132 */     this.userSearchBase = userSearchBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuthenticationManager createAuthenticationManager() {
/* 141 */     LdapAuthenticationProvider ldapAuthenticationProvider = getProvider();
/* 142 */     return (AuthenticationManager)new ProviderManager(new AuthenticationProvider[] { (AuthenticationProvider)ldapAuthenticationProvider });
/*     */   }
/*     */   private LdapAuthenticationProvider getProvider() {
/*     */     LdapAuthenticationProvider provider;
/* 146 */     AbstractLdapAuthenticator authenticator = getAuthenticator();
/*     */     
/* 148 */     if (this.ldapAuthoritiesPopulator != null) {
/* 149 */       provider = new LdapAuthenticationProvider((LdapAuthenticator)authenticator, this.ldapAuthoritiesPopulator);
/*     */     } else {
/*     */       
/* 152 */       provider = new LdapAuthenticationProvider((LdapAuthenticator)authenticator);
/*     */     } 
/* 154 */     if (this.authoritiesMapper != null) {
/* 155 */       provider.setAuthoritiesMapper(this.authoritiesMapper);
/*     */     }
/* 157 */     if (this.userDetailsContextMapper != null) {
/* 158 */       provider.setUserDetailsContextMapper(this.userDetailsContextMapper);
/*     */     }
/* 160 */     return provider;
/*     */   }
/*     */   
/*     */   private AbstractLdapAuthenticator getAuthenticator() {
/* 164 */     AbstractLdapAuthenticator authenticator = (AbstractLdapAuthenticator)createDefaultLdapAuthenticator();
/* 165 */     if (this.userSearchFilter != null) {
/* 166 */       authenticator.setUserSearch((LdapUserSearch)new FilterBasedLdapUserSearch(this.userSearchBase, this.userSearchFilter, this.contextSource));
/*     */     }
/*     */     
/* 169 */     if (this.userDnPatterns != null && this.userDnPatterns.length > 0) {
/* 170 */       authenticator.setUserDnPatterns(this.userDnPatterns);
/*     */     }
/* 172 */     authenticator.afterPropertiesSet();
/* 173 */     return authenticator;
/*     */   }
/*     */   
/*     */   protected abstract T createDefaultLdapAuthenticator();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\AbstractLdapAuthenticationManagerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */