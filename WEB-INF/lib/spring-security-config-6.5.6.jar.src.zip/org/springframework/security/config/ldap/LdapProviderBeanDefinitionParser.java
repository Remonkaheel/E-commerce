/*     */ package org.springframework.security.config.ldap;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.config.authentication.PasswordEncoderParser;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LdapProviderBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*  41 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private static final String ATT_USER_DN_PATTERN = "user-dn-pattern";
/*     */   
/*     */   private static final String ATT_USER_PASSWORD = "password-attribute";
/*     */   
/*     */   private static final String ATT_HASH = "hash";
/*     */   
/*     */   private static final String DEF_USER_SEARCH_FILTER = "uid={0}";
/*     */   
/*     */   static final String PROVIDER_CLASS = "org.springframework.security.ldap.authentication.LdapAuthenticationProvider";
/*     */   
/*     */   static final String BIND_AUTH_CLASS = "org.springframework.security.ldap.authentication.BindAuthenticator";
/*     */   
/*     */   static final String PASSWD_AUTH_CLASS = "org.springframework.security.ldap.authentication.PasswordComparisonAuthenticator";
/*     */   
/*     */   public BeanDefinition parse(Element elt, ParserContext parserContext) {
/*     */     AbstractBeanDefinition abstractBeanDefinition;
/*  59 */     RuntimeBeanReference contextSource = LdapUserServiceBeanDefinitionParser.parseServerReference(elt, parserContext);
/*     */     
/*  61 */     RootBeanDefinition rootBeanDefinition = LdapUserServiceBeanDefinitionParser.parseSearchBean(elt, parserContext);
/*  62 */     String userDnPattern = elt.getAttribute("user-dn-pattern");
/*  63 */     String[] userDnPatternArray = new String[0];
/*  64 */     if (StringUtils.hasText(userDnPattern)) {
/*  65 */       userDnPatternArray = new String[] { userDnPattern };
/*     */     
/*     */     }
/*  68 */     else if (rootBeanDefinition == null) {
/*  69 */       this.logger.info("No search information or DN pattern specified. Using default search filter 'uid={0}'");
/*     */ 
/*     */       
/*  72 */       BeanDefinitionBuilder searchBeanBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.search.FilterBasedLdapUserSearch");
/*  73 */       searchBeanBuilder.getRawBeanDefinition().setSource(elt);
/*  74 */       searchBeanBuilder.addConstructorArgValue("");
/*  75 */       searchBeanBuilder.addConstructorArgValue("uid={0}");
/*  76 */       searchBeanBuilder.addConstructorArgValue(contextSource);
/*  77 */       abstractBeanDefinition = searchBeanBuilder.getBeanDefinition();
/*     */     } 
/*  79 */     BeanDefinitionBuilder authenticatorBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.authentication.BindAuthenticator");
/*  80 */     Element passwordCompareElt = DomUtils.getChildElementByTagName(elt, "password-compare");
/*  81 */     if (passwordCompareElt != null) {
/*  82 */       authenticatorBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.authentication.PasswordComparisonAuthenticator");
/*  83 */       String passwordAttribute = passwordCompareElt.getAttribute("password-attribute");
/*  84 */       if (StringUtils.hasText(passwordAttribute)) {
/*  85 */         authenticatorBuilder.addPropertyValue("passwordAttributeName", passwordAttribute);
/*     */       }
/*  87 */       Element passwordEncoderElement = DomUtils.getChildElementByTagName(passwordCompareElt, "password-encoder");
/*     */       
/*  89 */       String hash = passwordCompareElt.getAttribute("hash");
/*  90 */       if (passwordEncoderElement != null) {
/*  91 */         if (StringUtils.hasText(hash)) {
/*  92 */           parserContext.getReaderContext()
/*  93 */             .warning("Attribute 'hash' cannot be used with 'password-encoder' and will be ignored.", parserContext
/*  94 */               .extractSource(elt));
/*     */         }
/*  96 */         PasswordEncoderParser pep = new PasswordEncoderParser(passwordEncoderElement, parserContext);
/*  97 */         authenticatorBuilder.addPropertyValue("passwordEncoder", pep.getPasswordEncoder());
/*     */       }
/*  99 */       else if (StringUtils.hasText(hash)) {
/* 100 */         authenticatorBuilder.addPropertyValue("passwordEncoder", 
/* 101 */             PasswordEncoderParser.createPasswordEncoderBeanDefinition(hash));
/*     */       } 
/*     */     } 
/* 104 */     authenticatorBuilder.addConstructorArgValue(contextSource);
/* 105 */     authenticatorBuilder.addPropertyValue("userDnPatterns", userDnPatternArray);
/* 106 */     if (abstractBeanDefinition != null) {
/* 107 */       authenticatorBuilder.addPropertyValue("userSearch", abstractBeanDefinition);
/*     */     }
/* 109 */     BeanDefinitionBuilder ldapProvider = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.authentication.LdapAuthenticationProvider");
/* 110 */     ldapProvider.addConstructorArgValue(authenticatorBuilder.getBeanDefinition());
/* 111 */     ldapProvider
/* 112 */       .addConstructorArgValue(LdapUserServiceBeanDefinitionParser.parseAuthoritiesPopulator(elt, parserContext));
/* 113 */     ldapProvider.addPropertyValue("userDetailsContextMapper", 
/* 114 */         LdapUserServiceBeanDefinitionParser.parseUserDetailsClassOrUserMapperRef(elt, parserContext));
/* 115 */     return (BeanDefinition)ldapProvider.getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\LdapProviderBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */