/*     */ package org.springframework.security.config.ldap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
/*     */ import org.springframework.security.ldap.server.ApacheDSContainer;
/*     */ import org.springframework.security.ldap.server.UnboundIdContainer;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LdapServerBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String CONTEXT_SOURCE_CLASS = "org.springframework.security.ldap.DefaultSpringSecurityContextSource";
/*     */   private static final String ATT_URL = "url";
/*     */   private static final String ATT_PRINCIPAL = "manager-dn";
/*     */   private static final String ATT_PASSWORD = "manager-password";
/*     */   public static final String ATT_ROOT_SUFFIX = "root";
/*     */   private static final String OPT_DEFAULT_ROOT_SUFFIX = "dc=springframework,dc=org";
/*     */   public static final String ATT_LDIF_FILE = "ldif";
/*     */   private static final String OPT_DEFAULT_LDIF_FILE = "classpath*:*.ldif";
/*     */   public static final String ATT_PORT = "port";
/*     */   private static final String RANDOM_PORT = "0";
/*     */   private static final int DEFAULT_PORT = 33389;
/*     */   private static final String APACHEDS_CLASSNAME = "org.apache.directory.server.core.DefaultDirectoryService";
/*     */   private static final String UNBOUNID_CLASSNAME = "com.unboundid.ldap.listener.InMemoryDirectoryServer";
/*     */   private static final String APACHEDS_CONTAINER_CLASSNAME = "org.springframework.security.ldap.server.ApacheDSContainer";
/*     */   private static final String UNBOUNDID_CONTAINER_CLASSNAME = "org.springframework.security.ldap.server.UnboundIdContainer";
/*     */   private static final boolean unboundIdPresent;
/*     */   private static final boolean apacheDsPresent;
/*     */   
/*     */   static {
/*  94 */     ClassLoader classLoader = LdapServerBeanDefinitionParser.class.getClassLoader();
/*  95 */     unboundIdPresent = ClassUtils.isPresent("com.unboundid.ldap.listener.InMemoryDirectoryServer", classLoader);
/*  96 */     apacheDsPresent = ClassUtils.isPresent("org.apache.directory.server.core.DefaultDirectoryService", classLoader);
/*     */   }
/*     */   
/*     */   public BeanDefinition parse(Element elt, ParserContext parserContext) {
/*     */     RootBeanDefinition contextSource;
/* 101 */     String url = elt.getAttribute("url");
/*     */     
/* 103 */     if (!StringUtils.hasText(url)) {
/* 104 */       contextSource = createEmbeddedServer(elt, parserContext);
/*     */     } else {
/*     */       
/* 107 */       contextSource = new RootBeanDefinition();
/* 108 */       contextSource.setBeanClassName("org.springframework.security.ldap.DefaultSpringSecurityContextSource");
/* 109 */       contextSource.getConstructorArgumentValues().addIndexedArgumentValue(0, url);
/*     */     } 
/* 111 */     contextSource.setSource(parserContext.extractSource(elt));
/* 112 */     String managerDn = elt.getAttribute("manager-dn");
/* 113 */     String managerPassword = elt.getAttribute("manager-password");
/* 114 */     if (StringUtils.hasText(managerDn)) {
/* 115 */       if (!StringUtils.hasText(managerPassword)) {
/* 116 */         parserContext.getReaderContext()
/* 117 */           .error("You must specify the manager-password if you supply a " + managerDn, elt);
/*     */       }
/* 119 */       contextSource.getPropertyValues().addPropertyValue("userDn", managerDn);
/* 120 */       contextSource.getPropertyValues().addPropertyValue("password", managerPassword);
/*     */     } 
/* 122 */     String id = elt.getAttribute("id");
/* 123 */     String contextSourceId = StringUtils.hasText(id) ? id : "org.springframework.security.securityContextSource";
/* 124 */     parserContext.getRegistry().registerBeanDefinition(contextSourceId, (BeanDefinition)contextSource);
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RootBeanDefinition createEmbeddedServer(Element element, ParserContext parserContext) {
/* 138 */     Object source = parserContext.extractSource(element);
/* 139 */     String suffix = element.getAttribute("root");
/* 140 */     if (!StringUtils.hasText(suffix)) {
/* 141 */       suffix = "dc=springframework,dc=org";
/*     */     }
/* 143 */     BeanDefinitionBuilder contextSource = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.DefaultSpringSecurityContextSource");
/* 144 */     contextSource.addConstructorArgValue(suffix);
/* 145 */     contextSource.addPropertyValue("userDn", "uid=admin,ou=system");
/* 146 */     contextSource.addPropertyValue("password", "secret");
/*     */ 
/*     */     
/* 149 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(EmbeddedLdapServerConfigBean.class).getBeanDefinition();
/*     */     
/* 151 */     String embeddedLdapServerConfigBeanName = parserContext.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/* 152 */     parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, embeddedLdapServerConfigBeanName));
/*     */     
/* 154 */     contextSource.setFactoryMethodOnBean("createEmbeddedContextSource", embeddedLdapServerConfigBeanName);
/* 155 */     String mode = element.getAttribute("mode");
/* 156 */     RootBeanDefinition ldapContainer = getRootBeanDefinition(mode);
/* 157 */     ldapContainer.setSource(source);
/* 158 */     ldapContainer.getConstructorArgumentValues().addGenericArgumentValue(suffix);
/* 159 */     String ldifs = element.getAttribute("ldif");
/* 160 */     if (!StringUtils.hasText(ldifs)) {
/* 161 */       ldifs = "classpath*:*.ldif";
/*     */     }
/* 163 */     ldapContainer.getConstructorArgumentValues().addGenericArgumentValue(ldifs);
/* 164 */     ldapContainer.getPropertyValues().addPropertyValue("port", getPort(element));
/* 165 */     if (parserContext.getRegistry().containsBeanDefinition("org.springframework.security.apacheDirectoryServerContainer") || parserContext
/* 166 */       .getRegistry().containsBeanDefinition("org.springframework.security.unboundidServerContainer")) {
/* 167 */       parserContext.getReaderContext()
/* 168 */         .error("Only one embedded server bean is allowed per application context", element);
/*     */     }
/* 170 */     String beanId = resolveBeanId(mode);
/* 171 */     if (beanId != null) {
/* 172 */       parserContext.getRegistry().registerBeanDefinition(beanId, (BeanDefinition)ldapContainer);
/*     */     }
/* 174 */     return (RootBeanDefinition)contextSource.getBeanDefinition();
/*     */   }
/*     */   
/*     */   private RootBeanDefinition getRootBeanDefinition(String mode) {
/* 178 */     if (isApacheDsEnabled(mode)) {
/* 179 */       return new RootBeanDefinition("org.springframework.security.ldap.server.ApacheDSContainer", null, null);
/*     */     }
/* 181 */     if (isUnboundidEnabled(mode)) {
/* 182 */       return new RootBeanDefinition("org.springframework.security.ldap.server.UnboundIdContainer", null, null);
/*     */     }
/* 184 */     throw new IllegalStateException("Embedded LDAP server is not provided");
/*     */   }
/*     */   
/*     */   private String resolveBeanId(String mode) {
/* 188 */     if (isApacheDsEnabled(mode)) {
/* 189 */       return "org.springframework.security.apacheDirectoryServerContainer";
/*     */     }
/* 191 */     if (isUnboundidEnabled(mode)) {
/* 192 */       return "org.springframework.security.unboundidServerContainer";
/*     */     }
/* 194 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isApacheDsEnabled(String mode) {
/* 198 */     return ("apacheds".equals(mode) || apacheDsPresent);
/*     */   }
/*     */   
/*     */   private boolean isUnboundidEnabled(String mode) {
/* 202 */     return ("unboundid".equals(mode) || unboundIdPresent);
/*     */   }
/*     */   
/*     */   private String getPort(Element element) {
/* 206 */     String port = element.getAttribute("port");
/* 207 */     return StringUtils.hasText(port) ? port : getDefaultPort();
/*     */   }
/*     */   private String getDefaultPort() {
/*     */     try {
/* 211 */       ServerSocket serverSocket = new ServerSocket(33389); 
/* 212 */       try { String str = String.valueOf(serverSocket.getLocalPort());
/* 213 */         serverSocket.close(); return str; } catch (Throwable throwable) { try { serverSocket.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 214 */     } catch (IOException ex) {
/* 215 */       return "0";
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class EmbeddedLdapServerConfigBean
/*     */     implements ApplicationContextAware
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */     
/*     */     public void setApplicationContext(ApplicationContext applicationContext) {
/* 225 */       this.applicationContext = applicationContext;
/*     */     }
/*     */ 
/*     */     
/*     */     private DefaultSpringSecurityContextSource createEmbeddedContextSource(String suffix) {
/* 230 */       int port = getPort();
/* 231 */       String providerUrl = "ldap://127.0.0.1:" + port + "/" + suffix;
/* 232 */       return new DefaultSpringSecurityContextSource(providerUrl);
/*     */     }
/*     */     
/*     */     private int getPort() {
/* 236 */       if (LdapServerBeanDefinitionParser.apacheDsPresent) {
/* 237 */         ApacheDSContainer apacheDSContainer = (ApacheDSContainer)this.applicationContext.getBean(ApacheDSContainer.class);
/* 238 */         return apacheDSContainer.getLocalPort();
/*     */       } 
/* 240 */       if (LdapServerBeanDefinitionParser.unboundIdPresent) {
/* 241 */         UnboundIdContainer unboundIdContainer = (UnboundIdContainer)this.applicationContext.getBean(UnboundIdContainer.class);
/* 242 */         return unboundIdContainer.getPort();
/*     */       } 
/* 244 */       throw new IllegalStateException("Embedded LDAP server is not provided");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\LdapServerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */