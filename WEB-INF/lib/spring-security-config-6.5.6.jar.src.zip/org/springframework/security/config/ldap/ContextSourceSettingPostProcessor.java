/*    */ package org.springframework.security.config.ldap;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.ApplicationContextException;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextSourceSettingPostProcessor
/*    */   implements BeanFactoryPostProcessor, Ordered
/*    */ {
/*    */   private static final String REQUIRED_CONTEXT_SOURCE_CLASS_NAME = "org.springframework.ldap.core.support.BaseLdapPathContextSource";
/*    */   private boolean defaultNameRequired;
/*    */   
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory bf) throws BeansException {
/* 53 */     Class<?> contextSourceClass = getContextSourceClass();
/* 54 */     String[] sources = bf.getBeanNamesForType(contextSourceClass, false, false);
/* 55 */     if (sources.length == 0) {
/* 56 */       throw new ApplicationContextException("No BaseLdapPathContextSource instances found. Have you added an <ldap-server /> element to your application context? If you have declared an explicit bean, do not use lazy-init");
/*    */     }
/*    */ 
/*    */     
/* 60 */     if (!bf.containsBean("org.springframework.security.securityContextSource") && this.defaultNameRequired) {
/* 61 */       if (sources.length > 1) {
/* 62 */         throw new ApplicationContextException("More than one BaseLdapPathContextSource instance found. Please specify a specific server id using the 'server-ref' attribute when configuring your <ldap-authentication-provider> or <ldap-user-service>.");
/*    */       }
/*    */ 
/*    */       
/* 66 */       bf.registerAlias(sources[0], "org.springframework.security.securityContextSource");
/*    */     } 
/*    */   }
/*    */   
/*    */   private Class<?> getContextSourceClass() throws LinkageError {
/*    */     try {
/* 72 */       return ClassUtils.forName("org.springframework.ldap.core.support.BaseLdapPathContextSource", ClassUtils.getDefaultClassLoader());
/*    */     }
/* 74 */     catch (ClassNotFoundException ex) {
/* 75 */       throw new ApplicationContextException("Couldn't locate: org.springframework.ldap.core.support.BaseLdapPathContextSource.  If you are using LDAP with Spring Security, please ensure that you include the spring-ldap jar file in your application", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDefaultNameRequired(boolean defaultNameRequired) {
/* 82 */     this.defaultNameRequired = defaultNameRequired;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 87 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\ContextSourceSettingPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */