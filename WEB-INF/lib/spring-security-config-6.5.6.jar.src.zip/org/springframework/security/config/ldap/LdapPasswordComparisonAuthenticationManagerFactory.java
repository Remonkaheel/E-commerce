/*    */ package org.springframework.security.config.ldap;
/*    */ 
/*    */ import org.springframework.ldap.core.support.BaseLdapPathContextSource;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ import org.springframework.security.ldap.authentication.AbstractLdapAuthenticator;
/*    */ import org.springframework.security.ldap.authentication.PasswordComparisonAuthenticator;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LdapPasswordComparisonAuthenticationManagerFactory
/*    */   extends AbstractLdapAuthenticationManagerFactory<PasswordComparisonAuthenticator>
/*    */ {
/*    */   private PasswordEncoder passwordEncoder;
/*    */   private String passwordAttribute;
/*    */   
/*    */   public LdapPasswordComparisonAuthenticationManagerFactory(BaseLdapPathContextSource contextSource, PasswordEncoder passwordEncoder) {
/* 41 */     super(contextSource);
/* 42 */     setPasswordEncoder(passwordEncoder);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
/* 51 */     Assert.notNull(passwordEncoder, "passwordEncoder must not be null.");
/* 52 */     this.passwordEncoder = passwordEncoder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPasswordAttribute(String passwordAttribute) {
/* 62 */     this.passwordAttribute = passwordAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   protected PasswordComparisonAuthenticator createDefaultLdapAuthenticator() {
/* 67 */     PasswordComparisonAuthenticator ldapAuthenticator = new PasswordComparisonAuthenticator(getContextSource());
/* 68 */     if (this.passwordAttribute != null) {
/* 69 */       ldapAuthenticator.setPasswordAttributeName(this.passwordAttribute);
/*    */     }
/* 71 */     ldapAuthenticator.setPasswordEncoder(this.passwordEncoder);
/* 72 */     return ldapAuthenticator;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\LdapPasswordComparisonAuthenticationManagerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */