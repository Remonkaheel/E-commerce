/*     */ package org.springframework.security.config.ldap;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.config.authentication.AbstractUserDetailsServiceBeanDefinitionParser;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LdapUserServiceBeanDefinitionParser
/*     */   extends AbstractUserDetailsServiceBeanDefinitionParser
/*     */ {
/*     */   public static final String ATT_SERVER = "server-ref";
/*     */   public static final String ATT_USER_SEARCH_FILTER = "user-search-filter";
/*     */   public static final String ATT_USER_SEARCH_BASE = "user-search-base";
/*     */   public static final String DEF_USER_SEARCH_BASE = "";
/*     */   public static final String ATT_GROUP_SEARCH_FILTER = "group-search-filter";
/*     */   public static final String ATT_GROUP_SEARCH_BASE = "group-search-base";
/*     */   public static final String ATT_GROUP_ROLE_ATTRIBUTE = "group-role-attribute";
/*     */   public static final String DEF_GROUP_SEARCH_FILTER = "(uniqueMember={0})";
/*     */   public static final String DEF_GROUP_SEARCH_BASE = "";
/*     */   static final String ATT_ROLE_PREFIX = "role-prefix";
/*     */   static final String ATT_USER_CLASS = "user-details-class";
/*     */   static final String ATT_USER_CONTEXT_MAPPER_REF = "user-context-mapper-ref";
/*     */   static final String OPT_PERSON = "person";
/*     */   static final String OPT_INETORGPERSON = "inetOrgPerson";
/*     */   public static final String LDAP_SEARCH_CLASS = "org.springframework.security.ldap.search.FilterBasedLdapUserSearch";
/*     */   public static final String PERSON_MAPPER_CLASS = "org.springframework.security.ldap.userdetails.PersonContextMapper";
/*     */   public static final String INET_ORG_PERSON_MAPPER_CLASS = "org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper";
/*     */   public static final String LDAP_USER_MAPPER_CLASS = "org.springframework.security.ldap.userdetails.LdapUserDetailsMapper";
/*     */   public static final String LDAP_AUTHORITIES_POPULATOR_CLASS = "org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator";
/*     */   
/*     */   protected String getBeanClassName(Element element) {
/*  78 */     return "org.springframework.security.ldap.userdetails.LdapUserDetailsService";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doParse(Element elt, ParserContext parserContext, BeanDefinitionBuilder builder) {
/*  83 */     if (!StringUtils.hasText(elt.getAttribute("user-search-filter"))) {
/*  84 */       parserContext.getReaderContext().error("User search filter must be supplied", elt);
/*     */     }
/*  86 */     builder.addConstructorArgValue(parseSearchBean(elt, parserContext));
/*  87 */     builder.getRawBeanDefinition().setSource(parserContext.extractSource(elt));
/*  88 */     builder.addConstructorArgValue(parseAuthoritiesPopulator(elt, parserContext));
/*  89 */     builder.addPropertyValue("userDetailsMapper", parseUserDetailsClassOrUserMapperRef(elt, parserContext));
/*     */   }
/*     */   
/*     */   static RootBeanDefinition parseSearchBean(Element elt, ParserContext parserContext) {
/*  93 */     String userSearchFilter = elt.getAttribute("user-search-filter");
/*  94 */     String userSearchBase = elt.getAttribute("user-search-base");
/*  95 */     Object source = parserContext.extractSource(elt);
/*  96 */     if (StringUtils.hasText(userSearchBase)) {
/*  97 */       if (!StringUtils.hasText(userSearchFilter)) {
/*  98 */         parserContext.getReaderContext()
/*  99 */           .error("user-search-base cannot be used without a user-search-filter", source);
/*     */       }
/*     */     } else {
/*     */       
/* 103 */       userSearchBase = "";
/*     */     } 
/* 105 */     if (!StringUtils.hasText(userSearchFilter)) {
/* 106 */       return null;
/*     */     }
/* 108 */     BeanDefinitionBuilder searchBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.search.FilterBasedLdapUserSearch");
/* 109 */     searchBuilder.getRawBeanDefinition().setSource(source);
/* 110 */     searchBuilder.addConstructorArgValue(userSearchBase);
/* 111 */     searchBuilder.addConstructorArgValue(userSearchFilter);
/* 112 */     searchBuilder.addConstructorArgValue(parseServerReference(elt, parserContext));
/* 113 */     return (RootBeanDefinition)searchBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   static RuntimeBeanReference parseServerReference(Element elt, ParserContext parserContext) {
/* 117 */     String server = elt.getAttribute("server-ref");
/* 118 */     boolean requiresDefaultName = false;
/* 119 */     if (!StringUtils.hasText(server)) {
/* 120 */       server = "org.springframework.security.securityContextSource";
/* 121 */       requiresDefaultName = true;
/*     */     } 
/* 123 */     RuntimeBeanReference contextSource = new RuntimeBeanReference(server);
/* 124 */     contextSource.setSource(parserContext.extractSource(elt));
/* 125 */     registerPostProcessorIfNecessary(parserContext.getRegistry(), requiresDefaultName);
/* 126 */     return contextSource;
/*     */   }
/*     */   
/*     */   private static void registerPostProcessorIfNecessary(BeanDefinitionRegistry registry, boolean defaultNameRequired) {
/* 130 */     if (registry.containsBeanDefinition("org.springframework.security.contextSettingPostProcessor")) {
/* 131 */       if (defaultNameRequired) {
/* 132 */         BeanDefinition bd = registry.getBeanDefinition("org.springframework.security.contextSettingPostProcessor");
/* 133 */         bd.getPropertyValues().addPropertyValue("defaultNameRequired", Boolean.valueOf(defaultNameRequired));
/*     */       } 
/*     */       return;
/*     */     } 
/* 137 */     BeanDefinitionBuilder bdb = BeanDefinitionBuilder.rootBeanDefinition(ContextSourceSettingPostProcessor.class);
/* 138 */     bdb.addPropertyValue("defaultNameRequired", Boolean.valueOf(defaultNameRequired));
/* 139 */     registry.registerBeanDefinition("org.springframework.security.contextSettingPostProcessor", (BeanDefinition)bdb.getBeanDefinition());
/*     */   }
/*     */   
/*     */   static BeanMetadataElement parseUserDetailsClassOrUserMapperRef(Element elt, ParserContext parserContext) {
/* 143 */     String userDetailsClass = elt.getAttribute("user-details-class");
/* 144 */     String userMapperRef = elt.getAttribute("user-context-mapper-ref");
/* 145 */     if (StringUtils.hasText(userDetailsClass) && StringUtils.hasText(userMapperRef)) {
/* 146 */       parserContext.getReaderContext()
/* 147 */         .error("Attributes user-details-class and user-context-mapper-ref cannot be used together.", parserContext
/* 148 */           .extractSource(elt));
/*     */     }
/* 150 */     if (StringUtils.hasText(userMapperRef)) {
/* 151 */       return (BeanMetadataElement)new RuntimeBeanReference(userMapperRef);
/*     */     }
/* 153 */     RootBeanDefinition mapper = getMapper(userDetailsClass);
/* 154 */     mapper.setSource(parserContext.extractSource(elt));
/* 155 */     return (BeanMetadataElement)mapper;
/*     */   }
/*     */   
/*     */   private static RootBeanDefinition getMapper(String userDetailsClass) {
/* 159 */     if ("person".equals(userDetailsClass)) {
/* 160 */       return new RootBeanDefinition("org.springframework.security.ldap.userdetails.PersonContextMapper", null, null);
/*     */     }
/* 162 */     if ("inetOrgPerson".equals(userDetailsClass)) {
/* 163 */       return new RootBeanDefinition("org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper", null, null);
/*     */     }
/* 165 */     return new RootBeanDefinition("org.springframework.security.ldap.userdetails.LdapUserDetailsMapper", null, null);
/*     */   }
/*     */   
/*     */   static RootBeanDefinition parseAuthoritiesPopulator(Element elt, ParserContext parserContext) {
/* 169 */     String groupSearchFilter = elt.getAttribute("group-search-filter");
/* 170 */     String groupSearchBase = elt.getAttribute("group-search-base");
/* 171 */     String groupRoleAttribute = elt.getAttribute("group-role-attribute");
/* 172 */     String rolePrefix = elt.getAttribute("role-prefix");
/* 173 */     if (!StringUtils.hasText(groupSearchFilter)) {
/* 174 */       groupSearchFilter = "(uniqueMember={0})";
/*     */     }
/* 176 */     if (!StringUtils.hasText(groupSearchBase)) {
/* 177 */       groupSearchBase = "";
/*     */     }
/* 179 */     BeanDefinitionBuilder populator = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator");
/* 180 */     populator.getRawBeanDefinition().setSource(parserContext.extractSource(elt));
/* 181 */     populator.addConstructorArgValue(parseServerReference(elt, parserContext));
/* 182 */     populator.addConstructorArgValue(groupSearchBase);
/* 183 */     populator.addPropertyValue("groupSearchFilter", groupSearchFilter);
/* 184 */     populator.addPropertyValue("searchSubtree", Boolean.TRUE);
/* 185 */     if (StringUtils.hasText(rolePrefix)) {
/* 186 */       if ("none".equals(rolePrefix)) {
/* 187 */         rolePrefix = "";
/*     */       }
/* 189 */       populator.addPropertyValue("rolePrefix", rolePrefix);
/*     */     } 
/* 191 */     if (StringUtils.hasLength(groupRoleAttribute)) {
/* 192 */       populator.addPropertyValue("groupRoleAttribute", groupRoleAttribute);
/*     */     }
/* 194 */     return (RootBeanDefinition)populator.getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\LdapUserServiceBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */