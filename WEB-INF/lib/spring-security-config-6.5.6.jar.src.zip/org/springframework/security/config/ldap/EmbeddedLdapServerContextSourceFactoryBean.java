/*     */ package org.springframework.security.config.ldap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.Lifecycle;
/*     */ import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
/*     */ import org.springframework.security.ldap.server.EmbeddedLdapServerContainer;
/*     */ import org.springframework.security.ldap.server.UnboundIdContainer;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedLdapServerContextSourceFactoryBean
/*     */   implements FactoryBean<DefaultSpringSecurityContextSource>, DisposableBean, ApplicationContextAware
/*     */ {
/*     */   private static final String UNBOUNDID_CLASSNAME = "com.unboundid.ldap.listener.InMemoryDirectoryServer";
/*     */   private static final boolean unboundIdPresent;
/*     */   private static final int DEFAULT_PORT = 33389;
/*     */   private static final int RANDOM_PORT = 0;
/*     */   private Integer port;
/*  53 */   private String ldif = "classpath*:*.ldif";
/*     */   
/*  55 */   private String root = "dc=springframework,dc=org";
/*     */   
/*     */   private ApplicationContext context;
/*     */   
/*     */   private String managerDn;
/*     */   
/*     */   private String managerPassword;
/*     */   
/*     */   private EmbeddedLdapServerContainer container;
/*     */   
/*     */   static {
/*  66 */     ClassLoader classLoader = EmbeddedLdapServerContextSourceFactoryBean.class.getClassLoader();
/*  67 */     unboundIdPresent = ClassUtils.isPresent("com.unboundid.ldap.listener.InMemoryDirectoryServer", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EmbeddedLdapServerContextSourceFactoryBean fromEmbeddedLdapServer() {
/*  77 */     return new EmbeddedLdapServerContextSourceFactoryBean();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLdif(String ldif) {
/*  86 */     this.ldif = ldif;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPort(int port) {
/*  96 */     this.port = Integer.valueOf(port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoot(String root) {
/* 105 */     this.root = root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagerDn(String managerDn) {
/* 116 */     this.managerDn = managerDn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagerPassword(String managerPassword) {
/* 125 */     this.managerPassword = managerPassword;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultSpringSecurityContextSource getObject() throws Exception {
/* 130 */     if (!unboundIdPresent) {
/* 131 */       throw new IllegalStateException("Embedded LDAP server is not provided");
/*     */     }
/* 133 */     this.container = getContainer();
/* 134 */     this.port = Integer.valueOf(this.container.getPort());
/* 135 */     DefaultSpringSecurityContextSource contextSourceFromProviderUrl = new DefaultSpringSecurityContextSource("ldap://127.0.0.1:" + this.port + "/" + this.root);
/*     */     
/* 137 */     if (this.managerDn != null) {
/* 138 */       contextSourceFromProviderUrl.setUserDn(this.managerDn);
/* 139 */       if (this.managerPassword == null) {
/* 140 */         throw new IllegalStateException("managerPassword is required if managerDn is supplied");
/*     */       }
/* 142 */       contextSourceFromProviderUrl.setPassword(this.managerPassword);
/*     */     } 
/* 144 */     contextSourceFromProviderUrl.afterPropertiesSet();
/* 145 */     return contextSourceFromProviderUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getObjectType() {
/* 150 */     return DefaultSpringSecurityContextSource.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 155 */     if (this.container instanceof Lifecycle) {
/* 156 */       ((Lifecycle)this.container).stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 162 */     this.context = applicationContext;
/*     */   }
/*     */   
/*     */   private EmbeddedLdapServerContainer getContainer() {
/* 166 */     if (!unboundIdPresent) {
/* 167 */       throw new IllegalStateException("Embedded LDAP server is not provided");
/*     */     }
/* 169 */     UnboundIdContainer unboundIdContainer = new UnboundIdContainer(this.root, this.ldif);
/* 170 */     unboundIdContainer.setApplicationContext(this.context);
/* 171 */     unboundIdContainer.setPort(getEmbeddedServerPort());
/* 172 */     unboundIdContainer.afterPropertiesSet();
/* 173 */     return (EmbeddedLdapServerContainer)unboundIdContainer;
/*     */   }
/*     */   
/*     */   private int getEmbeddedServerPort() {
/* 177 */     if (this.port == null) {
/* 178 */       this.port = Integer.valueOf(getDefaultEmbeddedServerPort());
/*     */     }
/* 180 */     return this.port.intValue();
/*     */   }
/*     */   private int getDefaultEmbeddedServerPort() {
/*     */     try {
/* 184 */       ServerSocket serverSocket = new ServerSocket(33389); 
/* 185 */       try { int i = serverSocket.getLocalPort();
/* 186 */         serverSocket.close(); return i; } catch (Throwable throwable) { try { serverSocket.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 187 */     } catch (IOException ex) {
/* 188 */       return 0;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\ldap\EmbeddedLdapServerContextSourceFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */