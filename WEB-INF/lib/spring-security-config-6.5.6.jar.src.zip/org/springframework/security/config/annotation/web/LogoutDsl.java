/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000R\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\006\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\021\n\002\020\016\n\002\b\006\n\002\020!\n\002\030\002\n\002\b\026\n\002\020\002\n\002\b\007\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\016\020.\032\0020/2\006\0200\032\0020\030J\026\0201\032\0020/2\006\0200\032\0020\r2\006\0202\032\0020\fJ\037\020\016\032\0020/2\022\0203\032\n\022\006\b\001\022\0020\0200\017\"\0020\020¢\006\002\0204J\006\0205\032\0020/J\037\0206\032\024\022\n\022\b\022\004\022\0020908\022\004\022\0020/07H\000¢\006\002\b:J\006\020+\032\0020/R\036\020\003\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\005\020\006\"\004\b\007\020\bR\032\020\n\032\016\022\004\022\0020\f\022\004\022\0020\r0\013X\016¢\006\002\n\000R\032\020\016\032\f\022\006\b\001\022\0020\020\030\0010\017X\016¢\006\004\n\002\020\021R\016\020\022\032\0020\004X\016¢\006\002\n\000R\036\020\023\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\024\020\006\"\004\b\025\020\bR\024\020\026\032\b\022\004\022\0020\0300\027X\016¢\006\002\n\000R\034\020\031\032\004\030\0010\fX\016¢\006\016\n\000\032\004\b\032\020\033\"\004\b\034\020\035R\034\020\036\032\004\030\0010\rX\016¢\006\016\n\000\032\004\b\037\020 \"\004\b!\020\"R\034\020#\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b$\020%\"\004\b&\020'R\034\020(\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b)\020%\"\004\b*\020'R\036\020+\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b,\020\006\"\004\b-\020\b¨\006;"}, d2 = {"Lorg/springframework/security/config/annotation/web/LogoutDsl;", "", "()V", "clearAuthentication", "", "getClearAuthentication", "()Ljava/lang/Boolean;", "setClearAuthentication", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "defaultLogoutSuccessHandlerMappings", "Ljava/util/LinkedHashMap;", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "Lorg/springframework/security/web/authentication/logout/LogoutSuccessHandler;", "deleteCookies", "", "", "[Ljava/lang/String;", "disabled", "invalidateHttpSession", "getInvalidateHttpSession", "setInvalidateHttpSession", "logoutHandlers", "", "Lorg/springframework/security/web/authentication/logout/LogoutHandler;", "logoutRequestMatcher", "getLogoutRequestMatcher", "()Lorg/springframework/security/web/util/matcher/RequestMatcher;", "setLogoutRequestMatcher", "(Lorg/springframework/security/web/util/matcher/RequestMatcher;)V", "logoutSuccessHandler", "getLogoutSuccessHandler", "()Lorg/springframework/security/web/authentication/logout/LogoutSuccessHandler;", "setLogoutSuccessHandler", "(Lorg/springframework/security/web/authentication/logout/LogoutSuccessHandler;)V", "logoutSuccessUrl", "getLogoutSuccessUrl", "()Ljava/lang/String;", "setLogoutSuccessUrl", "(Ljava/lang/String;)V", "logoutUrl", "getLogoutUrl", "setLogoutUrl", "permitAll", "getPermitAll", "setPermitAll", "addLogoutHandler", "", "logoutHandler", "defaultLogoutSuccessHandlerFor", "preferredMatcher", "cookieNamesToClear", "([Ljava/lang/String;)V", "disable", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*     */ public final class LogoutDsl
/*     */ {
/*     */   @Nullable
/*     */   private Boolean clearAuthentication;
/*     */   @Nullable
/*     */   private Boolean invalidateHttpSession;
/*     */   @Nullable
/*     */   private String logoutUrl;
/*     */   @Nullable
/*     */   private RequestMatcher logoutRequestMatcher;
/*     */   @Nullable
/*     */   private String logoutSuccessUrl;
/*     */   @Nullable
/*     */   private LogoutSuccessHandler logoutSuccessHandler;
/*     */   @Nullable
/*     */   private Boolean permitAll;
/*     */   
/*     */   @Nullable
/*     */   public final Boolean getClearAuthentication() {
/*  47 */     return this.clearAuthentication; } public final void setClearAuthentication(@Nullable Boolean <set-?>) { this.clearAuthentication = <set-?>; } @Nullable
/*  48 */   public final Boolean getInvalidateHttpSession() { return this.invalidateHttpSession; } public final void setInvalidateHttpSession(@Nullable Boolean <set-?>) { this.invalidateHttpSession = <set-?>; } @Nullable
/*  49 */   public final String getLogoutUrl() { return this.logoutUrl; } public final void setLogoutUrl(@Nullable String <set-?>) { this.logoutUrl = <set-?>; } @Nullable
/*  50 */   public final RequestMatcher getLogoutRequestMatcher() { return this.logoutRequestMatcher; } public final void setLogoutRequestMatcher(@Nullable RequestMatcher <set-?>) { this.logoutRequestMatcher = <set-?>; } @Nullable
/*  51 */   public final String getLogoutSuccessUrl() { return this.logoutSuccessUrl; } public final void setLogoutSuccessUrl(@Nullable String <set-?>) { this.logoutSuccessUrl = <set-?>; } @Nullable
/*  52 */   public final LogoutSuccessHandler getLogoutSuccessHandler() { return this.logoutSuccessHandler; } public final void setLogoutSuccessHandler(@Nullable LogoutSuccessHandler <set-?>) { this.logoutSuccessHandler = <set-?>; } @Nullable
/*  53 */   public final Boolean getPermitAll() { return this.permitAll; } public final void setPermitAll(@Nullable Boolean <set-?>) { this.permitAll = <set-?>; }
/*     */    @NotNull
/*  55 */   private List<LogoutHandler> logoutHandlers = new ArrayList<>(); @Nullable
/*     */   private String[] deleteCookies; @NotNull
/*  57 */   private LinkedHashMap<RequestMatcher, LogoutSuccessHandler> defaultLogoutSuccessHandlerMappings = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disabled;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addLogoutHandler(@NotNull LogoutHandler logoutHandler) {
/*  68 */     Intrinsics.checkNotNullParameter(logoutHandler, "logoutHandler"); this.logoutHandlers.add(logoutHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void deleteCookies(@NotNull String... cookieNamesToClear) {
/*  77 */     Intrinsics.checkNotNullParameter(cookieNamesToClear, "cookieNamesToClear"); this.deleteCookies = cookieNamesToClear;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void defaultLogoutSuccessHandlerFor(@NotNull LogoutSuccessHandler logoutHandler, @NotNull RequestMatcher preferredMatcher) {
/*  89 */     Intrinsics.checkNotNullParameter(logoutHandler, "logoutHandler"); Intrinsics.checkNotNullParameter(preferredMatcher, "preferredMatcher"); this.defaultLogoutSuccessHandlerMappings.put(preferredMatcher, logoutHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void disable() {
/*  96 */     this.disabled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void permitAll() {
/* 103 */     this.permitAll = Boolean.valueOf(true);
/*     */   }
/*     */   
/*     */   @NotNull
/* 107 */   public final Function1<LogoutConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new LogoutDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "logout", "Lorg/springframework/security/config/annotation/web/configurers/LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nLogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LogoutDsl.kt\norg/springframework/security/config/annotation/web/LogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,128:1\n1#2:129\n216#3,2:130\n1863#4,2:132\n*S KotlinDebug\n*F\n+ 1 LogoutDsl.kt\norg/springframework/security/config/annotation/web/LogoutDsl$get$1\n*L\n116#1:130,2\n119#1:132,2\n*E\n"})
/* 108 */   static final class LogoutDsl$get$1 extends Lambda implements Function1<LogoutConfigurer<HttpSecurity>, Unit> { public final void invoke(LogoutConfigurer logout) { Intrinsics.checkNotNullParameter(logout, "logout"); if (LogoutDsl.this.getClearAuthentication() != null) { Boolean bool = LogoutDsl.this.getClearAuthentication(); LogoutDsl logoutDsl = LogoutDsl.this; boolean it = bool.booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 129 */         int $i$a$-also-LogoutDsl$get$1$1 = 0; Intrinsics.checkNotNull(logoutDsl.getClearAuthentication()); logout.clearAuthentication(logoutDsl.getClearAuthentication().booleanValue()); } else { LogoutDsl.this.getClearAuthentication(); }  if (LogoutDsl.this.getInvalidateHttpSession() != null) { Boolean bool = LogoutDsl.this.getInvalidateHttpSession(); LogoutDsl logoutDsl = LogoutDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-LogoutDsl$get$1$2 = 0; Intrinsics.checkNotNull(logoutDsl.getInvalidateHttpSession()); logout.invalidateHttpSession(logoutDsl.getInvalidateHttpSession().booleanValue()); } else { LogoutDsl.this.getInvalidateHttpSession(); }  if (LogoutDsl.this.getLogoutUrl() != null) { String str1 = LogoutDsl.this.getLogoutUrl(); LogoutDsl logoutDsl = LogoutDsl.this; String it = str1; int $i$a$-also-LogoutDsl$get$1$3 = 0; logout.logoutUrl(logoutDsl.getLogoutUrl()); } else { LogoutDsl.this.getLogoutUrl(); }  if (LogoutDsl.this.getLogoutRequestMatcher() != null) { RequestMatcher requestMatcher1 = LogoutDsl.this.getLogoutRequestMatcher(); LogoutDsl logoutDsl = LogoutDsl.this; RequestMatcher it = requestMatcher1; int $i$a$-also-LogoutDsl$get$1$4 = 0; logout.logoutRequestMatcher(logoutDsl.getLogoutRequestMatcher()); } else { LogoutDsl.this.getLogoutRequestMatcher(); }  if (LogoutDsl.this.getLogoutSuccessUrl() != null) { String str1 = LogoutDsl.this.getLogoutSuccessUrl(); LogoutDsl logoutDsl = LogoutDsl.this; String it = str1; int $i$a$-also-LogoutDsl$get$1$5 = 0; logout.logoutSuccessUrl(logoutDsl.getLogoutSuccessUrl()); } else { LogoutDsl.this.getLogoutSuccessUrl(); }  if (LogoutDsl.this.getLogoutSuccessHandler() != null) { LogoutSuccessHandler logoutSuccessHandler1 = LogoutDsl.this.getLogoutSuccessHandler(); LogoutDsl logoutDsl = LogoutDsl.this; LogoutSuccessHandler it = logoutSuccessHandler1; int $i$a$-also-LogoutDsl$get$1$6 = 0; logout.logoutSuccessHandler(logoutDsl.getLogoutSuccessHandler()); } else { LogoutDsl.this.getLogoutSuccessHandler(); }  if (LogoutDsl.this.deleteCookies != null) { String[] arrayOfString1 = LogoutDsl.this.deleteCookies; LogoutDsl logoutDsl = LogoutDsl.this; String[] it = arrayOfString1; int $i$a$-also-LogoutDsl$get$1$7 = 0; Intrinsics.checkNotNull(logoutDsl.deleteCookies); String[] arrayOfString2 = logoutDsl.deleteCookies; logout.deleteCookies(Arrays.<String>copyOf(arrayOfString2, arrayOfString2.length)); } else { LogoutDsl.this.deleteCookies; }  if (LogoutDsl.this.getPermitAll() != null) { Boolean bool = LogoutDsl.this.getPermitAll(); LogoutDsl logoutDsl = LogoutDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-LogoutDsl$get$1$8 = 0; Intrinsics.checkNotNull(logoutDsl.getPermitAll()); logout.permitAll(logoutDsl.getPermitAll().booleanValue()); } else { LogoutDsl.this.getPermitAll(); }
/* 130 */        Map map = LogoutDsl.this.defaultLogoutSuccessHandlerMappings; int $i$f$forEach = 0; Iterator<Map.Entry> iterator = map.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-LogoutDsl$get$1$9 = 0; RequestMatcher matcher = (RequestMatcher)entry1.getKey(); LogoutSuccessHandler handler = (LogoutSuccessHandler)entry1.getValue(); logout.defaultLogoutSuccessHandlerFor(handler, matcher); }
/*     */        Iterable<Map.Entry> $this$forEach$iv = (Iterable)LogoutDsl.this.logoutHandlers; $i$f$forEach = 0;
/* 132 */       iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); LogoutHandler logoutHandler = (LogoutHandler)element$iv; int $i$a$-forEach-LogoutDsl$get$1$10 = 0;
/*     */         logout.addLogoutHandler(logoutHandler); }
/*     */       
/*     */       if (LogoutDsl.this.disabled)
/*     */         logout.disable();  }
/*     */ 
/*     */     
/*     */     LogoutDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\LogoutDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */