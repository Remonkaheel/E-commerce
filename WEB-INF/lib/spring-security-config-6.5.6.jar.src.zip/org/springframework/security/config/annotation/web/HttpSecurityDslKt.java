/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 2, xi = 48, d1 = {"\000\032\n\000\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\032&\020\000\032\0020\001*\0020\0022\027\020\003\032\023\022\004\022\0020\005\022\004\022\0020\0010\004¢\006\002\b\006H\002¨\006\007"}, d2 = {"invoke", "", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "httpConfiguration", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/HttpSecurityDsl;", "Lkotlin/ExtensionFunctionType;", "spring-security-config"})
/*    */ public final class HttpSecurityDslKt
/*    */ {
/*    */   public static final void invoke(@NotNull HttpSecurity $this$invoke, @NotNull Function1<? super HttpSecurityDsl, Unit> httpConfiguration) {
/* 62 */     Intrinsics.checkNotNullParameter($this$invoke, "<this>"); Intrinsics.checkNotNullParameter(httpConfiguration, "httpConfiguration"); (new HttpSecurityDsl($this$invoke, httpConfiguration)).build$spring_security_config();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpSecurityDslKt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */