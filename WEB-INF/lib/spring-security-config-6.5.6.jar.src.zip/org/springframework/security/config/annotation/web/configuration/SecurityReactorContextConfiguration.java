/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.Hooks;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class SecurityReactorContextConfiguration
/*     */ {
/*  68 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   @Bean
/*     */   SecurityReactorContextSubscriberRegistrar securityReactorContextSubscriberRegistrar() {
/*  72 */     SecurityReactorContextSubscriberRegistrar registrar = new SecurityReactorContextSubscriberRegistrar();
/*  73 */     registrar.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/*  74 */     return registrar;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/*  79 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/*  80 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   static class SecurityReactorContextSubscriberRegistrar
/*     */     implements InitializingBean, DisposableBean
/*     */   {
/*     */     private static final String SECURITY_REACTOR_CONTEXT_OPERATOR_KEY = "org.springframework.security.SECURITY_REACTOR_CONTEXT_OPERATOR";
/*  87 */     private final Map<Object, Supplier<Object>> CONTEXT_ATTRIBUTE_VALUE_LOADERS = new HashMap<>();
/*     */ 
/*     */     
/*  90 */     private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */     
/*     */     SecurityReactorContextSubscriberRegistrar() {
/*  93 */       this.CONTEXT_ATTRIBUTE_VALUE_LOADERS.put(HttpServletRequest.class, SecurityReactorContextSubscriberRegistrar::getRequest);
/*     */       
/*  95 */       this.CONTEXT_ATTRIBUTE_VALUE_LOADERS.put(HttpServletResponse.class, SecurityReactorContextSubscriberRegistrar::getResponse);
/*     */       
/*  97 */       this.CONTEXT_ATTRIBUTE_VALUE_LOADERS.put(Authentication.class, this::getAuthentication);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void afterPropertiesSet() throws Exception {
/* 103 */       Function<? super Publisher<Object>, ? extends Publisher<Object>> lifter = Operators.liftPublisher((pub, sub) -> createSubscriberIfNecessary(sub));
/* 104 */       Objects.requireNonNull(lifter); Hooks.onLastOperator("org.springframework.security.SECURITY_REACTOR_CONTEXT_OPERATOR", lifter::apply);
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy() throws Exception {
/* 109 */       Hooks.resetOnLastOperator("org.springframework.security.SECURITY_REACTOR_CONTEXT_OPERATOR");
/*     */     }
/*     */     
/*     */     void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 113 */       Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 114 */       this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */     }
/*     */     
/*     */     <T> CoreSubscriber<T> createSubscriberIfNecessary(CoreSubscriber<T> delegate) {
/* 118 */       if (delegate.currentContext().hasKey("org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES"))
/*     */       {
/* 120 */         return delegate;
/*     */       }
/* 122 */       return new SecurityReactorContextConfiguration.SecurityReactorContextSubscriber<>(delegate, getContextAttributes());
/*     */     }
/*     */     
/*     */     private Map<Object, Object> getContextAttributes() {
/* 126 */       return new SecurityReactorContextConfiguration.LoadingMap<>(this.CONTEXT_ATTRIBUTE_VALUE_LOADERS);
/*     */     }
/*     */     
/*     */     private static HttpServletRequest getRequest() {
/* 130 */       RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 131 */       if (requestAttributes instanceof ServletRequestAttributes) {
/* 132 */         ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
/* 133 */         return servletRequestAttributes.getRequest();
/*     */       } 
/* 135 */       return null;
/*     */     }
/*     */     
/*     */     private static HttpServletResponse getResponse() {
/* 139 */       RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 140 */       if (requestAttributes instanceof ServletRequestAttributes) {
/* 141 */         ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
/* 142 */         return servletRequestAttributes.getResponse();
/*     */       } 
/* 144 */       return null;
/*     */     }
/*     */     
/*     */     private Authentication getAuthentication() {
/* 148 */       return this.securityContextHolderStrategy.getContext().getAuthentication();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class SecurityReactorContextSubscriber<T>
/*     */     implements CoreSubscriber<T>
/*     */   {
/*     */     static final String SECURITY_CONTEXT_ATTRIBUTES = "org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES";
/*     */     
/*     */     private final CoreSubscriber<T> delegate;
/*     */     private final Context context;
/*     */     
/*     */     SecurityReactorContextSubscriber(CoreSubscriber<T> delegate, Map<Object, Object> attributes) {
/* 162 */       this.delegate = delegate;
/* 163 */       Context context = getOrPutContext(attributes, this.delegate.currentContext());
/* 164 */       this.context = context;
/*     */     }
/*     */     
/*     */     private Context getOrPutContext(Map<Object, Object> attributes, Context currentContext) {
/* 168 */       if (currentContext.hasKey("org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES")) {
/* 169 */         return currentContext;
/*     */       }
/* 171 */       return currentContext.put("org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES", attributes);
/*     */     }
/*     */ 
/*     */     
/*     */     public Context currentContext() {
/* 176 */       return this.context;
/*     */     }
/*     */ 
/*     */     
/*     */     public void onSubscribe(Subscription s) {
/* 181 */       this.delegate.onSubscribe(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onNext(T t) {
/* 186 */       this.delegate.onNext(t);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onError(Throwable ex) {
/* 191 */       this.delegate.onError(ex);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onComplete() {
/* 196 */       this.delegate.onComplete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class LoadingMap<K, V>
/*     */     implements Map<K, V>
/*     */   {
/* 206 */     private final Map<K, V> loaded = new ConcurrentHashMap<>();
/*     */     
/*     */     private final Map<K, Supplier<V>> loaders;
/*     */     
/*     */     LoadingMap(Map<K, Supplier<V>> loaders) {
/* 211 */       this.loaders = Collections.unmodifiableMap(new HashMap<>(loaders));
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 216 */       return this.loaders.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 221 */       return this.loaders.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsKey(Object key) {
/* 226 */       return this.loaders.containsKey(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<K> keySet() {
/* 231 */       return this.loaders.keySet();
/*     */     }
/*     */ 
/*     */     
/*     */     public V get(Object key) {
/* 236 */       if (!this.loaders.containsKey(key)) {
/* 237 */         throw new IllegalArgumentException("This map only supports the following keys: " + 
/* 238 */             String.valueOf(this.loaders.keySet()));
/*     */       }
/* 240 */       return this.loaded.computeIfAbsent((K)key, k -> ((Supplier)this.loaders.get(k)).get());
/*     */     }
/*     */ 
/*     */     
/*     */     public V put(K key, V value) {
/* 245 */       if (!this.loaders.containsKey(key)) {
/* 246 */         throw new IllegalArgumentException("This map only supports the following keys: " + 
/* 247 */             String.valueOf(this.loaders.keySet()));
/*     */       }
/* 249 */       return this.loaded.put(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public V remove(Object key) {
/* 254 */       if (!this.loaders.containsKey(key)) {
/* 255 */         throw new IllegalArgumentException("This map only supports the following keys: " + 
/* 256 */             String.valueOf(this.loaders.keySet()));
/*     */       }
/* 258 */       return this.loaded.remove(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void putAll(Map<? extends K, ? extends V> m) {
/* 263 */       for (Map.Entry<? extends K, ? extends V> entry : m.entrySet()) {
/* 264 */         put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 270 */       this.loaded.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsValue(Object value) {
/* 275 */       return this.loaded.containsValue(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<V> values() {
/* 280 */       return this.loaded.values();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<K, V>> entrySet() {
/* 285 */       return this.loaded.entrySet();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 290 */       if (this == o) {
/* 291 */         return true;
/*     */       }
/* 293 */       if (o == null || getClass() != o.getClass()) {
/* 294 */         return false;
/*     */       }
/*     */       
/* 297 */       LoadingMap<?, ?> that = (LoadingMap<?, ?>)o;
/*     */       
/* 299 */       return this.loaded.equals(that.loaded);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 304 */       return this.loaded.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\SecurityReactorContextConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */