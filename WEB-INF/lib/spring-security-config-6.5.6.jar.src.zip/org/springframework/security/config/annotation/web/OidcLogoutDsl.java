/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OidcLogoutConfigurer;
/*    */ import org.springframework.security.config.annotation.web.oauth2.login.OidcBackChannelLogoutDsl;
/*    */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000>\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\003\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\003\032\0020\b2\027\020\025\032\023\022\004\022\0020\026\022\004\022\0020\b0\004¢\006\002\b\027J\037\020\030\032\024\022\n\022\b\022\004\022\0020\0070\006\022\004\022\0020\b0\004H\000¢\006\002\b\031R&\020\003\032\032\022\016\022\f0\005R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\034\020\017\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024¨\006\032"}, d2 = {"Lorg/springframework/security/config/annotation/web/OidcLogoutDsl;", "", "()V", "backChannel", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer$BackChannelLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "clientRegistrationRepository", "Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;", "getClientRegistrationRepository", "()Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;", "setClientRegistrationRepository", "(Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;)V", "oidcSessionRegistry", "Lorg/springframework/security/oauth2/client/oidc/session/OidcSessionRegistry;", "getOidcSessionRegistry", "()Lorg/springframework/security/oauth2/client/oidc/session/OidcSessionRegistry;", "setOidcSessionRegistry", "(Lorg/springframework/security/oauth2/client/oidc/session/OidcSessionRegistry;)V", "backChannelConfig", "Lorg/springframework/security/config/annotation/web/oauth2/login/OidcBackChannelLogoutDsl;", "Lkotlin/ExtensionFunctionType;", "get", "get$spring_security_config", "spring-security-config"})
/*    */ public final class OidcLogoutDsl
/*    */ {
/*    */   @Nullable
/*    */   private ClientRegistrationRepository clientRegistrationRepository;
/*    */   @Nullable
/*    */   private OidcSessionRegistry oidcSessionRegistry;
/*    */   @Nullable
/*    */   private Function1<? super OidcLogoutConfigurer<HttpSecurity>.BackChannelLogoutConfigurer, Unit> backChannel;
/*    */   
/*    */   @Nullable
/*    */   public final ClientRegistrationRepository getClientRegistrationRepository() {
/* 34 */     return this.clientRegistrationRepository; } public final void setClientRegistrationRepository(@Nullable ClientRegistrationRepository <set-?>) { this.clientRegistrationRepository = <set-?>; } @Nullable
/* 35 */   public final OidcSessionRegistry getOidcSessionRegistry() { return this.oidcSessionRegistry; } public final void setOidcSessionRegistry(@Nullable OidcSessionRegistry <set-?>) { this.oidcSessionRegistry = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void backChannel(@NotNull Function1 backChannelConfig) {
/* 66 */     Intrinsics.checkNotNullParameter(backChannelConfig, "backChannelConfig"); OidcBackChannelLogoutDsl oidcBackChannelLogoutDsl = new OidcBackChannelLogoutDsl(); backChannelConfig.invoke(oidcBackChannelLogoutDsl); this.backChannel = oidcBackChannelLogoutDsl.get$spring_security_config();
/*    */   }
/*    */   
/*    */   @NotNull
/* 70 */   public final Function1<OidcLogoutConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new OidcLogoutDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oidcLogout", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOidcLogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OidcLogoutDsl.kt\norg/springframework/security/config/annotation/web/OidcLogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,78:1\n1#2:79\n*E\n"})
/* 71 */   static final class OidcLogoutDsl$get$1 extends Lambda implements Function1<OidcLogoutConfigurer<HttpSecurity>, Unit> { public final void invoke(OidcLogoutConfigurer oidcLogout) { Intrinsics.checkNotNullParameter(oidcLogout, "oidcLogout"); if (OidcLogoutDsl.this.getClientRegistrationRepository() != null) { ClientRegistrationRepository clientRegistrationRepository1 = OidcLogoutDsl.this.getClientRegistrationRepository(); OidcLogoutDsl oidcLogoutDsl = OidcLogoutDsl.this; ClientRegistrationRepository it = clientRegistrationRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 79 */         int $i$a$-also-OidcLogoutDsl$get$1$1 = 0; oidcLogout.clientRegistrationRepository(oidcLogoutDsl.getClientRegistrationRepository()); } else { OidcLogoutDsl.this.getClientRegistrationRepository(); }  if (OidcLogoutDsl.this.getOidcSessionRegistry() != null) { OidcSessionRegistry oidcSessionRegistry1 = OidcLogoutDsl.this.getOidcSessionRegistry(); OidcLogoutDsl oidcLogoutDsl = OidcLogoutDsl.this; OidcSessionRegistry it = oidcSessionRegistry1; int $i$a$-also-OidcLogoutDsl$get$1$2 = 0; oidcLogout.oidcSessionRegistry(oidcLogoutDsl.getOidcSessionRegistry()); } else { OidcLogoutDsl.this.getOidcSessionRegistry(); }  if (OidcLogoutDsl.this.backChannel != null) { Function1 function11 = OidcLogoutDsl.this.backChannel; OidcLogoutDsl oidcLogoutDsl = OidcLogoutDsl.this; Function1 it = function11; int $i$a$-also-OidcLogoutDsl$get$1$3 = 0;
/*    */         oidcLogoutDsl.backChannel;
/*    */         oidcLogout.backChannel((oidcLogoutDsl.backChannel != null) ? oidcLogoutDsl.backChannel::invoke$lambda$3$lambda$2 : null); }
/*    */       else
/*    */       { OidcLogoutDsl.this.backChannel; }
/*    */        }
/*    */ 
/*    */     
/*    */     private static final void invoke$lambda$3$lambda$2(Function1 $tmp0, OidcLogoutConfigurer.BackChannelLogoutConfigurer t) {
/*    */       $tmp0.invoke(t);
/*    */     }
/*    */     
/*    */     OidcLogoutDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OidcLogoutDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */