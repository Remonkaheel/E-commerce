/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveMethodSecuritySelector
/*    */   implements ImportSelector
/*    */ {
/* 39 */   private static final boolean isDataPresent = ClassUtils.isPresent("org.springframework.security.data.aot.hint.AuthorizeReturnObjectDataHintsRegistrar", null);
/*    */ 
/*    */   
/* 42 */   private static final boolean isObservabilityPresent = ClassUtils.isPresent("io.micrometer.observation.ObservationRegistry", null);
/*    */   
/* 44 */   private final ImportSelector autoProxy = (ImportSelector)new AutoProxyRegistrarSelector();
/*    */ 
/*    */   
/*    */   public String[] selectImports(AnnotationMetadata importMetadata) {
/* 48 */     if (!importMetadata.hasAnnotation(EnableReactiveMethodSecurity.class.getName())) {
/* 49 */       return new String[0];
/*    */     }
/*    */ 
/*    */     
/* 53 */     EnableReactiveMethodSecurity annotation = (EnableReactiveMethodSecurity)importMetadata.getAnnotations().get(EnableReactiveMethodSecurity.class).synthesize();
/* 54 */     List<String> imports = new ArrayList<>(Arrays.asList(this.autoProxy.selectImports(importMetadata)));
/* 55 */     if (annotation.useAuthorizationManager()) {
/* 56 */       imports.add(ReactiveAuthorizationManagerMethodSecurityConfiguration.class.getName());
/*    */     } else {
/*    */       
/* 59 */       imports.add(ReactiveMethodSecurityConfiguration.class.getName());
/*    */     } 
/* 61 */     if (isDataPresent) {
/* 62 */       imports.add(AuthorizationProxyDataConfiguration.class.getName());
/*    */     }
/* 64 */     if (isObservabilityPresent) {
/* 65 */       imports.add(ReactiveMethodObservationConfiguration.class.getName());
/*    */     }
/* 67 */     imports.add(AuthorizationProxyConfiguration.class.getName());
/* 68 */     return imports.<String>toArray(new String[0]);
/*    */   }
/*    */   
/*    */   private static final class AutoProxyRegistrarSelector
/*    */     extends AdviceModeImportSelector<EnableReactiveMethodSecurity>
/*    */   {
/* 74 */     private static final String[] IMPORTS = new String[] { AutoProxyRegistrar.class.getName(), MethodSecurityAdvisorRegistrar.class
/* 75 */         .getName() };
/*    */ 
/*    */     
/*    */     protected String[] selectImports(@NonNull AdviceMode adviceMode) {
/* 79 */       if (adviceMode == AdviceMode.PROXY) {
/* 80 */         return IMPORTS;
/*    */       }
/* 82 */       throw new IllegalStateException("AdviceMode " + String.valueOf(adviceMode) + " is not supported");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\ReactiveMethodSecuritySelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */