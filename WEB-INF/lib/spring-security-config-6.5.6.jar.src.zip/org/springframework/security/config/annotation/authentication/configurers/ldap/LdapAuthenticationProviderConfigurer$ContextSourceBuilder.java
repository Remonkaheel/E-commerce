/*     */ package org.springframework.security.config.annotation.authentication.configurers.ldap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
/*     */ import org.springframework.security.ldap.server.ApacheDSContainer;
/*     */ import org.springframework.security.ldap.server.UnboundIdContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContextSourceBuilder
/*     */ {
/*     */   private static final String APACHEDS_CLASSNAME = "org.apache.directory.server.core.DefaultDirectoryService";
/*     */   private static final String UNBOUNDID_CLASSNAME = "com.unboundid.ldap.listener.InMemoryDirectoryServer";
/*     */   private static final int DEFAULT_PORT = 33389;
/*     */   private static final int RANDOM_PORT = 0;
/* 478 */   private String ldif = "classpath*:*.ldif";
/*     */   
/*     */   private String managerPassword;
/*     */   
/*     */   private String managerDn;
/*     */   
/*     */   private Integer port;
/*     */   
/* 486 */   private String root = "dc=springframework,dc=org";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder ldif(String ldif) {
/* 497 */     this.ldif = ldif;
/* 498 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder managerDn(String managerDn) {
/* 510 */     this.managerDn = managerDn;
/* 511 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder managerPassword(String managerPassword) {
/* 521 */     this.managerPassword = managerPassword;
/* 522 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder port(int port) {
/* 535 */     this.port = Integer.valueOf(port);
/* 536 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder root(String root) {
/* 546 */     this.root = root;
/* 547 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder url(String url) {
/* 557 */     this.url = url;
/* 558 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> and() {
/* 568 */     return LdapAuthenticationProviderConfigurer.this;
/*     */   }
/*     */   
/*     */   private DefaultSpringSecurityContextSource build() throws Exception {
/* 572 */     if (this.url == null) {
/* 573 */       startEmbeddedLdapServer();
/*     */     }
/* 575 */     DefaultSpringSecurityContextSource contextSource = new DefaultSpringSecurityContextSource(getProviderUrl());
/* 576 */     if (this.managerDn != null) {
/* 577 */       contextSource.setUserDn(this.managerDn);
/* 578 */       if (this.managerPassword == null) {
/* 579 */         throw new IllegalStateException("managerPassword is required if managerDn is supplied");
/*     */       }
/* 581 */       contextSource.setPassword(this.managerPassword);
/*     */     } 
/* 583 */     contextSource = (DefaultSpringSecurityContextSource)LdapAuthenticationProviderConfigurer.access$000(LdapAuthenticationProviderConfigurer.this, contextSource);
/* 584 */     return contextSource;
/*     */   }
/*     */   
/*     */   private void startEmbeddedLdapServer() throws Exception {
/* 588 */     if (LdapAuthenticationProviderConfigurer.apacheDsPresent) {
/* 589 */       ApacheDSContainer apacheDsContainer = new ApacheDSContainer(this.root, this.ldif);
/* 590 */       apacheDsContainer.setPort(getPort());
/* 591 */       LdapAuthenticationProviderConfigurer.access$100(LdapAuthenticationProviderConfigurer.this, apacheDsContainer);
/* 592 */       this.port = Integer.valueOf(apacheDsContainer.getLocalPort());
/*     */     }
/* 594 */     else if (LdapAuthenticationProviderConfigurer.unboundIdPresent) {
/* 595 */       UnboundIdContainer unboundIdContainer = new UnboundIdContainer(this.root, this.ldif);
/* 596 */       unboundIdContainer.setPort(getPort());
/* 597 */       LdapAuthenticationProviderConfigurer.access$200(LdapAuthenticationProviderConfigurer.this, unboundIdContainer);
/* 598 */       this.port = Integer.valueOf(unboundIdContainer.getPort());
/*     */     } else {
/*     */       
/* 601 */       throw new IllegalStateException("Embedded LDAP server is not provided");
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getPort() {
/* 606 */     if (this.port == null) {
/* 607 */       this.port = Integer.valueOf(getDefaultPort());
/*     */     }
/* 609 */     return this.port.intValue();
/*     */   }
/*     */   private int getDefaultPort() {
/*     */     try {
/* 613 */       ServerSocket serverSocket = new ServerSocket(33389); 
/* 614 */       try { int i = serverSocket.getLocalPort();
/* 615 */         serverSocket.close(); return i; } catch (Throwable throwable) { try { serverSocket.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 616 */     } catch (IOException ex) {
/* 617 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getProviderUrl() {
/* 622 */     if (this.url == null) {
/* 623 */       return "ldap://127.0.0.1:" + getPort() + "/" + this.root;
/*     */     }
/* 625 */     return this.url;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurers\ldap\LdapAuthenticationProviderConfigurer$ContextSourceBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */