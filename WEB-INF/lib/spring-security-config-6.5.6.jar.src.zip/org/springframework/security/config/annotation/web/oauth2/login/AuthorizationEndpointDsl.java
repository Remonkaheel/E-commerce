/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
/*    */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
/*    */ import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2LoginSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\034\032\030\022\016\022\f0\036R\b\022\004\022\0020 0\037\022\004\022\0020!0\035H\000¢\006\002\b\"R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\"\020\t\032\n\022\004\022\0020\013\030\0010\nX\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\034\020\020\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R\034\020\026\032\004\030\0010\027X\016¢\006\016\n\000\032\004\b\030\020\031\"\004\b\032\020\033¨\006#"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/login/AuthorizationEndpointDsl;", "", "()V", "authorizationRedirectStrategy", "Lorg/springframework/security/web/RedirectStrategy;", "getAuthorizationRedirectStrategy", "()Lorg/springframework/security/web/RedirectStrategy;", "setAuthorizationRedirectStrategy", "(Lorg/springframework/security/web/RedirectStrategy;)V", "authorizationRequestRepository", "Lorg/springframework/security/oauth2/client/web/AuthorizationRequestRepository;", "Lorg/springframework/security/oauth2/core/endpoint/OAuth2AuthorizationRequest;", "getAuthorizationRequestRepository", "()Lorg/springframework/security/oauth2/client/web/AuthorizationRequestRepository;", "setAuthorizationRequestRepository", "(Lorg/springframework/security/oauth2/client/web/AuthorizationRequestRepository;)V", "authorizationRequestResolver", "Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizationRequestResolver;", "getAuthorizationRequestResolver", "()Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizationRequestResolver;", "setAuthorizationRequestResolver", "(Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizationRequestResolver;)V", "baseUri", "", "getBaseUri", "()Ljava/lang/String;", "setBaseUri", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$AuthorizationEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class AuthorizationEndpointDsl
/*    */ {
/*    */   @Nullable
/*    */   private String baseUri;
/*    */   @Nullable
/*    */   private OAuth2AuthorizationRequestResolver authorizationRequestResolver;
/*    */   @Nullable
/*    */   private AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository;
/*    */   @Nullable
/*    */   private RedirectStrategy authorizationRedirectStrategy;
/*    */   
/*    */   @Nullable
/*    */   public final String getBaseUri() {
/* 39 */     return this.baseUri; } public final void setBaseUri(@Nullable String <set-?>) { this.baseUri = <set-?>; } @Nullable
/* 40 */   public final OAuth2AuthorizationRequestResolver getAuthorizationRequestResolver() { return this.authorizationRequestResolver; } public final void setAuthorizationRequestResolver(@Nullable OAuth2AuthorizationRequestResolver <set-?>) { this.authorizationRequestResolver = <set-?>; } @Nullable
/* 41 */   public final AuthorizationRequestRepository<OAuth2AuthorizationRequest> getAuthorizationRequestRepository() { return this.authorizationRequestRepository; } public final void setAuthorizationRequestRepository(@Nullable AuthorizationRequestRepository<OAuth2AuthorizationRequest> <set-?>) { this.authorizationRequestRepository = <set-?>; } @Nullable
/* 42 */   public final RedirectStrategy getAuthorizationRedirectStrategy() { return this.authorizationRedirectStrategy; } public final void setAuthorizationRedirectStrategy(@Nullable RedirectStrategy <set-?>) { this.authorizationRedirectStrategy = <set-?>; }
/*    */   
/*    */   @NotNull
/* 45 */   public final Function1<OAuth2LoginConfigurer<HttpSecurity>.AuthorizationEndpointConfig, Unit> get$spring_security_config() { return new AuthorizationEndpointDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "authorizationEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$AuthorizationEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nAuthorizationEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AuthorizationEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/AuthorizationEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,53:1\n1#2:54\n*E\n"})
/* 46 */   static final class AuthorizationEndpointDsl$get$1 extends Lambda implements Function1<OAuth2LoginConfigurer<HttpSecurity>.AuthorizationEndpointConfig, Unit> { public final void invoke(OAuth2LoginConfigurer.AuthorizationEndpointConfig authorizationEndpoint) { Intrinsics.checkNotNullParameter(authorizationEndpoint, "authorizationEndpoint"); if (AuthorizationEndpointDsl.this.getBaseUri() != null) { String str1 = AuthorizationEndpointDsl.this.getBaseUri(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 54 */         int $i$a$-also-AuthorizationEndpointDsl$get$1$1 = 0; authorizationEndpoint.baseUri(authorizationEndpointDsl.getBaseUri()); } else { AuthorizationEndpointDsl.this.getBaseUri(); }  if (AuthorizationEndpointDsl.this.getAuthorizationRequestResolver() != null) { OAuth2AuthorizationRequestResolver oAuth2AuthorizationRequestResolver1 = AuthorizationEndpointDsl.this.getAuthorizationRequestResolver(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; OAuth2AuthorizationRequestResolver it = oAuth2AuthorizationRequestResolver1; int $i$a$-also-AuthorizationEndpointDsl$get$1$2 = 0; authorizationEndpoint.authorizationRequestResolver(authorizationEndpointDsl.getAuthorizationRequestResolver()); } else { AuthorizationEndpointDsl.this.getAuthorizationRequestResolver(); }  if (AuthorizationEndpointDsl.this.getAuthorizationRequestRepository() != null) { AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository1 = AuthorizationEndpointDsl.this.getAuthorizationRequestRepository(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; AuthorizationRequestRepository<OAuth2AuthorizationRequest> it = authorizationRequestRepository1; int $i$a$-also-AuthorizationEndpointDsl$get$1$3 = 0; authorizationEndpoint.authorizationRequestRepository(authorizationEndpointDsl.getAuthorizationRequestRepository()); } else { AuthorizationEndpointDsl.this.getAuthorizationRequestRepository(); }  if (AuthorizationEndpointDsl.this.getAuthorizationRedirectStrategy() != null) { RedirectStrategy redirectStrategy1 = AuthorizationEndpointDsl.this.getAuthorizationRedirectStrategy(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; RedirectStrategy it = redirectStrategy1; int $i$a$-also-AuthorizationEndpointDsl$get$1$4 = 0;
/*    */         authorizationEndpoint.authorizationRedirectStrategy(authorizationEndpointDsl.getAuthorizationRedirectStrategy()); }
/*    */       else
/*    */       { AuthorizationEndpointDsl.this.getAuthorizationRedirectStrategy(); }
/*    */        }
/*    */ 
/*    */     
/*    */     AuthorizationEndpointDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\AuthorizationEndpointDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */