/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.RequestCacheConfigurer;
/*    */ import org.springframework.security.web.savedrequest.RequestCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "requestCacheConfig", "Lorg/springframework/security/config/annotation/web/configurers/RequestCacheConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ final class RequestCacheDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<RequestCacheConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(RequestCacheConfigurer requestCacheConfig) {
/* 37 */     Intrinsics.checkNotNullParameter(requestCacheConfig, "requestCacheConfig"); RequestCache requestCache1 = RequestCacheDsl.this.getRequestCache(); RequestCacheDsl requestCacheDsl = RequestCacheDsl.this; RequestCache it = requestCache1; int $i$a$-also-RequestCacheDsl$get$1$1 = 0;
/* 38 */     requestCacheConfig.requestCache(requestCacheDsl.getRequestCache());
/*    */     RequestCacheDsl.this.getRequestCache();
/*    */   }
/*    */   
/*    */   RequestCacheDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RequestCacheDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */