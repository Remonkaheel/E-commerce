/*    */ package org.springframework.security.config.annotation.web.saml2;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*    */ import org.springframework.security.saml2.provider.service.authentication.logout.Saml2LogoutResponseValidator;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutResponseResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Saml2SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000<\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\025\032\030\022\016\022\f0\027R\b\022\004\022\0020\0310\030\022\004\022\0020\0320\026H\000¢\006\002\b\033R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\032\020\017\032\0020\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024¨\006\034"}, d2 = {"Lorg/springframework/security/config/annotation/web/saml2/LogoutResponseDsl;", "", "()V", "logoutResponseResolver", "Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutResponseResolver;", "getLogoutResponseResolver", "()Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutResponseResolver;", "setLogoutResponseResolver", "(Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutResponseResolver;)V", "logoutResponseValidator", "Lorg/springframework/security/saml2/provider/service/authentication/logout/Saml2LogoutResponseValidator;", "getLogoutResponseValidator", "()Lorg/springframework/security/saml2/provider/service/authentication/logout/Saml2LogoutResponseValidator;", "setLogoutResponseValidator", "(Lorg/springframework/security/saml2/provider/service/authentication/logout/Saml2LogoutResponseValidator;)V", "logoutUrl", "", "getLogoutUrl", "()Ljava/lang/String;", "setLogoutUrl", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutResponseConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class LogoutResponseDsl
/*    */ {
/*    */   @NotNull
/* 36 */   private String logoutUrl = "/logout/saml2/slo"; @Nullable private Saml2LogoutResponseValidator logoutResponseValidator; @Nullable private Saml2LogoutResponseResolver logoutResponseResolver; @NotNull public final String getLogoutUrl() { return this.logoutUrl; } public final void setLogoutUrl(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.logoutUrl = <set-?>; } @Nullable
/* 37 */   public final Saml2LogoutResponseValidator getLogoutResponseValidator() { return this.logoutResponseValidator; } public final void setLogoutResponseValidator(@Nullable Saml2LogoutResponseValidator <set-?>) { this.logoutResponseValidator = <set-?>; } @Nullable
/* 38 */   public final Saml2LogoutResponseResolver getLogoutResponseResolver() { return this.logoutResponseResolver; } public final void setLogoutResponseResolver(@Nullable Saml2LogoutResponseResolver <set-?>) { this.logoutResponseResolver = <set-?>; }
/*    */   
/*    */   @NotNull
/* 41 */   public final Function1<Saml2LogoutConfigurer<HttpSecurity>.LogoutResponseConfigurer, Unit> get$spring_security_config() { return new LogoutResponseDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "logoutResponse", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutResponseConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nLogoutResponseDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LogoutResponseDsl.kt\norg/springframework/security/config/annotation/web/saml2/LogoutResponseDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,48:1\n1#2:49\n*E\n"})
/* 42 */   static final class LogoutResponseDsl$get$1 extends Lambda implements Function1<Saml2LogoutConfigurer<HttpSecurity>.LogoutResponseConfigurer, Unit> { public final void invoke(Saml2LogoutConfigurer.LogoutResponseConfigurer logoutResponse) { Intrinsics.checkNotNullParameter(logoutResponse, "logoutResponse"); String str1 = LogoutResponseDsl.this.getLogoutUrl(); LogoutResponseDsl logoutResponseDsl = LogoutResponseDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 49 */       int $i$a$-also-LogoutResponseDsl$get$1$1 = 0; logoutResponse.logoutUrl(logoutResponseDsl.getLogoutUrl()); if (LogoutResponseDsl.this.getLogoutResponseValidator() != null) { Saml2LogoutResponseValidator saml2LogoutResponseValidator1 = LogoutResponseDsl.this.getLogoutResponseValidator(); LogoutResponseDsl logoutResponseDsl1 = LogoutResponseDsl.this; Saml2LogoutResponseValidator saml2LogoutResponseValidator2 = saml2LogoutResponseValidator1; int $i$a$-also-LogoutResponseDsl$get$1$2 = 0; logoutResponse.logoutResponseValidator(logoutResponseDsl1.getLogoutResponseValidator()); } else { LogoutResponseDsl.this.getLogoutResponseValidator(); }  if (LogoutResponseDsl.this.getLogoutResponseResolver() != null) { Saml2LogoutResponseResolver saml2LogoutResponseResolver1 = LogoutResponseDsl.this.getLogoutResponseResolver(); LogoutResponseDsl logoutResponseDsl1 = LogoutResponseDsl.this; Saml2LogoutResponseResolver saml2LogoutResponseResolver2 = saml2LogoutResponseResolver1; int $i$a$-also-LogoutResponseDsl$get$1$3 = 0;
/*    */         logoutResponse.logoutResponseResolver(logoutResponseDsl1.getLogoutResponseResolver()); }
/*    */       else
/*    */       { LogoutResponseDsl.this.getLogoutResponseResolver(); }
/*    */        }
/*    */ 
/*    */     
/*    */     LogoutResponseDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\saml2\LogoutResponseDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */