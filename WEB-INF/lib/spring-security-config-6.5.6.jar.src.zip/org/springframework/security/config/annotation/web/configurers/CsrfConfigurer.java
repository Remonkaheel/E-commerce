/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.AbstractRequestMatcherRegistry;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.access.AccessDeniedHandler;
/*     */ import org.springframework.security.web.access.AccessDeniedHandlerImpl;
/*     */ import org.springframework.security.web.access.CompositeAccessDeniedHandler;
/*     */ import org.springframework.security.web.access.DelegatingAccessDeniedHandler;
/*     */ import org.springframework.security.web.access.ObservationMarkingAccessDeniedHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.csrf.CsrfAuthenticationStrategy;
/*     */ import org.springframework.security.web.csrf.CsrfFilter;
/*     */ import org.springframework.security.web.csrf.CsrfLogoutHandler;
/*     */ import org.springframework.security.web.csrf.CsrfTokenRepository;
/*     */ import org.springframework.security.web.csrf.CsrfTokenRequestHandler;
/*     */ import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
/*     */ import org.springframework.security.web.csrf.MissingCsrfTokenException;
/*     */ import org.springframework.security.web.session.InvalidSessionAccessDeniedHandler;
/*     */ import org.springframework.security.web.session.InvalidSessionStrategy;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CsrfConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<CsrfConfigurer<H>, H>
/*     */ {
/*  85 */   private CsrfTokenRepository csrfTokenRepository = (CsrfTokenRepository)new HttpSessionCsrfTokenRepository();
/*     */   
/*  87 */   private RequestMatcher requireCsrfProtectionMatcher = CsrfFilter.DEFAULT_CSRF_MATCHER;
/*     */   
/*  89 */   private List<RequestMatcher> ignoredCsrfProtectionMatchers = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private SessionAuthenticationStrategy sessionAuthenticationStrategy;
/*     */ 
/*     */   
/*     */   private CsrfTokenRequestHandler requestHandler;
/*     */ 
/*     */   
/*     */   private final ApplicationContext context;
/*     */ 
/*     */   
/*     */   public CsrfConfigurer(ApplicationContext context) {
/* 102 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfConfigurer<H> csrfTokenRepository(CsrfTokenRepository csrfTokenRepository) {
/* 112 */     Assert.notNull(csrfTokenRepository, "csrfTokenRepository cannot be null");
/* 113 */     this.csrfTokenRepository = csrfTokenRepository;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfConfigurer<H> requireCsrfProtectionMatcher(RequestMatcher requireCsrfProtectionMatcher) {
/* 125 */     Assert.notNull(requireCsrfProtectionMatcher, "requireCsrfProtectionMatcher cannot be null");
/* 126 */     this.requireCsrfProtectionMatcher = requireCsrfProtectionMatcher;
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfConfigurer<H> csrfTokenRequestHandler(CsrfTokenRequestHandler requestHandler) {
/* 138 */     this.requestHandler = requestHandler;
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfConfigurer<H> ignoringRequestMatchers(RequestMatcher... requestMatchers) {
/* 168 */     return ((IgnoreCsrfProtectionRegistry)(new IgnoreCsrfProtectionRegistry(this.context)).requestMatchers(requestMatchers)).and();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfConfigurer<H> ignoringRequestMatchers(String... patterns) {
/* 197 */     return ((IgnoreCsrfProtectionRegistry)(new IgnoreCsrfProtectionRegistry(this.context)).requestMatchers(patterns)).and();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsrfConfigurer<H> sessionAuthenticationStrategy(SessionAuthenticationStrategy sessionAuthenticationStrategy) {
/* 212 */     Assert.notNull(sessionAuthenticationStrategy, "sessionAuthenticationStrategy cannot be null");
/* 213 */     this.sessionAuthenticationStrategy = sessionAuthenticationStrategy;
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/*     */     CompositeAccessDeniedHandler compositeAccessDeniedHandler;
/* 220 */     CsrfFilter filter = new CsrfFilter(this.csrfTokenRepository);
/* 221 */     RequestMatcher requireCsrfProtectionMatcher = getRequireCsrfProtectionMatcher();
/* 222 */     if (requireCsrfProtectionMatcher != null) {
/* 223 */       filter.setRequireCsrfProtectionMatcher(requireCsrfProtectionMatcher);
/*     */     }
/* 225 */     AccessDeniedHandler accessDeniedHandler = createAccessDeniedHandler(http);
/* 226 */     ObservationRegistry registry = getObservationRegistry();
/* 227 */     if (!registry.isNoop()) {
/* 228 */       ObservationMarkingAccessDeniedHandler observable = new ObservationMarkingAccessDeniedHandler(registry);
/* 229 */       compositeAccessDeniedHandler = new CompositeAccessDeniedHandler(new AccessDeniedHandler[] { (AccessDeniedHandler)observable, accessDeniedHandler });
/*     */     } 
/* 231 */     if (compositeAccessDeniedHandler != null) {
/* 232 */       filter.setAccessDeniedHandler((AccessDeniedHandler)compositeAccessDeniedHandler);
/*     */     }
/* 234 */     LogoutConfigurer<H> logoutConfigurer = (LogoutConfigurer<H>)http.getConfigurer(LogoutConfigurer.class);
/* 235 */     if (logoutConfigurer != null) {
/* 236 */       logoutConfigurer.addLogoutHandler((LogoutHandler)new CsrfLogoutHandler(this.csrfTokenRepository));
/*     */     }
/* 238 */     SessionManagementConfigurer<H> sessionConfigurer = (SessionManagementConfigurer<H>)http.getConfigurer(SessionManagementConfigurer.class);
/* 239 */     if (sessionConfigurer != null) {
/* 240 */       sessionConfigurer.addSessionAuthenticationStrategy(getSessionAuthenticationStrategy());
/*     */     }
/* 242 */     if (this.requestHandler != null) {
/* 243 */       filter.setRequestHandler(this.requestHandler);
/*     */     }
/* 245 */     filter = (CsrfFilter)postProcess(filter);
/* 246 */     http.addFilter((Filter)filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestMatcher getRequireCsrfProtectionMatcher() {
/* 255 */     if (this.ignoredCsrfProtectionMatchers.isEmpty()) {
/* 256 */       return this.requireCsrfProtectionMatcher;
/*     */     }
/* 258 */     return (RequestMatcher)new AndRequestMatcher(new RequestMatcher[] { this.requireCsrfProtectionMatcher, (RequestMatcher)new NegatedRequestMatcher((RequestMatcher)new OrRequestMatcher(this.ignoredCsrfProtectionMatchers)) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AccessDeniedHandler getDefaultAccessDeniedHandler(H http) {
/*     */     AccessDeniedHandlerImpl accessDeniedHandlerImpl;
/* 271 */     ExceptionHandlingConfigurer<H> exceptionConfig = (ExceptionHandlingConfigurer<H>)http.getConfigurer(ExceptionHandlingConfigurer.class);
/* 272 */     AccessDeniedHandler handler = null;
/* 273 */     if (exceptionConfig != null) {
/* 274 */       handler = exceptionConfig.getAccessDeniedHandler(http);
/*     */     }
/* 276 */     if (handler == null) {
/* 277 */       accessDeniedHandlerImpl = new AccessDeniedHandlerImpl();
/*     */     }
/* 279 */     return (AccessDeniedHandler)accessDeniedHandlerImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InvalidSessionStrategy getInvalidSessionStrategy(H http) {
/* 291 */     SessionManagementConfigurer<H> sessionManagement = (SessionManagementConfigurer<H>)http.getConfigurer(SessionManagementConfigurer.class);
/* 292 */     if (sessionManagement == null) {
/* 293 */       return null;
/*     */     }
/* 295 */     return sessionManagement.getInvalidSessionStrategy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AccessDeniedHandler createAccessDeniedHandler(H http) {
/* 311 */     InvalidSessionStrategy invalidSessionStrategy = getInvalidSessionStrategy(http);
/* 312 */     AccessDeniedHandler defaultAccessDeniedHandler = getDefaultAccessDeniedHandler(http);
/* 313 */     if (invalidSessionStrategy == null) {
/* 314 */       return defaultAccessDeniedHandler;
/*     */     }
/* 316 */     InvalidSessionAccessDeniedHandler invalidSessionDeniedHandler = new InvalidSessionAccessDeniedHandler(invalidSessionStrategy);
/*     */     
/* 318 */     LinkedHashMap<Class<? extends AccessDeniedException>, AccessDeniedHandler> handlers = new LinkedHashMap<>();
/* 319 */     handlers.put(MissingCsrfTokenException.class, invalidSessionDeniedHandler);
/* 320 */     return (AccessDeniedHandler)new DelegatingAccessDeniedHandler(handlers, defaultAccessDeniedHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SessionAuthenticationStrategy getSessionAuthenticationStrategy() {
/* 330 */     if (this.sessionAuthenticationStrategy != null) {
/* 331 */       return this.sessionAuthenticationStrategy;
/*     */     }
/* 333 */     CsrfAuthenticationStrategy csrfAuthenticationStrategy = new CsrfAuthenticationStrategy(this.csrfTokenRepository);
/*     */     
/* 335 */     if (this.requestHandler != null) {
/* 336 */       csrfAuthenticationStrategy.setRequestHandler(this.requestHandler);
/*     */     }
/* 338 */     return (SessionAuthenticationStrategy)csrfAuthenticationStrategy;
/*     */   }
/*     */   
/*     */   private ObservationRegistry getObservationRegistry() {
/* 342 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 343 */     String[] names = context.getBeanNamesForType(ObservationRegistry.class);
/* 344 */     if (names.length == 1) {
/* 345 */       return (ObservationRegistry)context.getBean(ObservationRegistry.class);
/*     */     }
/*     */     
/* 348 */     return ObservationRegistry.NOOP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class IgnoreCsrfProtectionRegistry
/*     */     extends AbstractRequestMatcherRegistry<IgnoreCsrfProtectionRegistry>
/*     */   {
/*     */     IgnoreCsrfProtectionRegistry(ApplicationContext context) {
/* 363 */       setApplicationContext(context);
/*     */     }
/*     */     
/*     */     CsrfConfigurer<H> and() {
/* 367 */       return CsrfConfigurer.this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected IgnoreCsrfProtectionRegistry chainRequestMatchers(List<RequestMatcher> requestMatchers) {
/* 372 */       CsrfConfigurer.this.ignoredCsrfProtectionMatchers.addAll(requestMatchers);
/* 373 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\CsrfConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */