/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.PortMapperConfigurer;
/*    */ import org.springframework.security.web.PortMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0006\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020!\n\002\030\002\n\002\020\b\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\005\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\r\032\024\022\n\022\b\022\004\022\0020\0200\017\022\004\022\0020\0210\016H\000¢\006\002\b\022J\026\020\023\032\0020\0212\006\020\024\032\0020\0062\006\020\025\032\0020\006R \020\003\032\024\022\020\022\016\022\004\022\0020\006\022\004\022\0020\0060\0050\004X\004¢\006\002\n\000R\034\020\007\032\004\030\0010\bX\016¢\006\016\n\000\032\004\b\t\020\n\"\004\b\013\020\f¨\006\026"}, d2 = {"Lorg/springframework/security/config/annotation/web/PortMapperDsl;", "", "()V", "mappings", "", "Lkotlin/Pair;", "", "portMapper", "Lorg/springframework/security/web/PortMapper;", "getPortMapper", "()Lorg/springframework/security/web/PortMapper;", "setPortMapper", "(Lorg/springframework/security/web/PortMapper;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/PortMapperConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "map", "fromPort", "toPort", "spring-security-config"})
/*    */ public final class PortMapperDsl
/*    */ {
/*    */   @NotNull
/* 33 */   private final List<Pair<Integer, Integer>> mappings = new ArrayList<>(); @Nullable
/*    */   private PortMapper portMapper; @Nullable
/* 35 */   public final PortMapper getPortMapper() { return this.portMapper; } public final void setPortMapper(@Nullable PortMapper <set-?>) { this.portMapper = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void map(int fromPort, int toPort) {
/* 44 */     this.mappings.add(new Pair(Integer.valueOf(fromPort), Integer.valueOf(toPort)));
/*    */   }
/*    */   
/*    */   @NotNull
/* 48 */   public final Function1<PortMapperConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new PortMapperDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "portMapperConfig", "Lorg/springframework/security/config/annotation/web/configurers/PortMapperConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nPortMapperDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PortMapperDsl.kt\norg/springframework/security/config/annotation/web/PortMapperDsl$get$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,58:1\n1863#2,2:59\n*S KotlinDebug\n*F\n+ 1 PortMapperDsl.kt\norg/springframework/security/config/annotation/web/PortMapperDsl$get$1\n*L\n52#1:59,2\n*E\n"})
/* 49 */   static final class PortMapperDsl$get$1 extends Lambda implements Function1<PortMapperConfigurer<HttpSecurity>, Unit> { public final void invoke(PortMapperConfigurer portMapperConfig) { Intrinsics.checkNotNullParameter(portMapperConfig, "portMapperConfig"); PortMapper portMapper1 = PortMapperDsl.this.getPortMapper(); PortMapperDsl portMapperDsl = PortMapperDsl.this; PortMapper it = portMapper1; int $i$a$-also-PortMapperDsl$get$1$1 = 0;
/* 50 */       portMapperConfig.portMapper(portMapperDsl.getPortMapper());
/*    */       PortMapperDsl.this.getPortMapper();
/* 52 */       Iterable $this$forEach$iv = PortMapperDsl.this.mappings; int $i$f$forEach = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 59 */       Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); Pair pair = (Pair)element$iv; int $i$a$-forEach-PortMapperDsl$get$1$2 = 0;
/*    */         portMapperConfig.http(((Number)pair.getFirst()).intValue()).mapsTo(((Number)pair.getSecond()).intValue()); }
/*    */        }
/*    */ 
/*    */     
/*    */     PortMapperDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\PortMapperDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */