/*    */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*    */ 
/*    */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OidcLogoutAuthenticationToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = -1568528983223505540L;
/*    */   private final String logoutToken;
/*    */   private final ClientRegistration clientRegistration;
/*    */   
/*    */   OidcLogoutAuthenticationToken(String logoutToken, ClientRegistration clientRegistration) {
/* 48 */     super(AuthorityUtils.NO_AUTHORITIES);
/* 49 */     this.logoutToken = logoutToken;
/* 50 */     this.clientRegistration = clientRegistration;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCredentials() {
/* 58 */     return this.logoutToken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPrincipal() {
/* 66 */     return this.logoutToken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getLogoutToken() {
/* 74 */     return this.logoutToken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ClientRegistration getClientRegistration() {
/* 82 */     return this.clientRegistration;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcLogoutAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */