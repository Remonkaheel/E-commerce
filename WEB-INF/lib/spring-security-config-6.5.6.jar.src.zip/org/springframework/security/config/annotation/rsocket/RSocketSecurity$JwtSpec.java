/*     */ package org.springframework.security.config.annotation.rsocket;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*     */ import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtReactiveAuthenticationManager;
/*     */ import org.springframework.security.rsocket.authentication.AuthenticationPayloadExchangeConverter;
/*     */ import org.springframework.security.rsocket.authentication.AuthenticationPayloadInterceptor;
/*     */ import org.springframework.security.rsocket.authentication.BearerPayloadExchangeConverter;
/*     */ import org.springframework.security.rsocket.authentication.PayloadExchangeAuthenticationConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JwtSpec
/*     */ {
/*     */   private ReactiveAuthenticationManager authenticationManager;
/*     */   
/*     */   public JwtSpec authenticationManager(ReactiveAuthenticationManager authenticationManager) {
/* 322 */     this.authenticationManager = authenticationManager;
/* 323 */     return this;
/*     */   }
/*     */   
/*     */   private ReactiveAuthenticationManager getAuthenticationManager() {
/* 327 */     if (this.authenticationManager != null) {
/* 328 */       return this.authenticationManager;
/*     */     }
/* 330 */     ReactiveJwtDecoder jwtDecoder = RSocketSecurity.this.<ReactiveJwtDecoder>getBeanOrNull(ReactiveJwtDecoder.class);
/* 331 */     if (jwtDecoder != null) {
/* 332 */       this.authenticationManager = (ReactiveAuthenticationManager)new JwtReactiveAuthenticationManager(jwtDecoder);
/* 333 */       return this.authenticationManager;
/*     */     } 
/* 335 */     return RSocketSecurity.this.authenticationManager;
/*     */   }
/*     */   
/*     */   protected List<AuthenticationPayloadInterceptor> build() {
/* 339 */     ReactiveAuthenticationManager manager = getAuthenticationManager();
/* 340 */     AuthenticationPayloadInterceptor legacy = new AuthenticationPayloadInterceptor(manager);
/* 341 */     legacy.setAuthenticationConverter((PayloadExchangeAuthenticationConverter)new BearerPayloadExchangeConverter());
/* 342 */     legacy.setOrder(PayloadInterceptorOrder.AUTHENTICATION.getOrder());
/* 343 */     AuthenticationPayloadInterceptor standard = new AuthenticationPayloadInterceptor(manager);
/* 344 */     standard.setAuthenticationConverter((PayloadExchangeAuthenticationConverter)new AuthenticationPayloadExchangeConverter());
/* 345 */     standard.setOrder(PayloadInterceptorOrder.AUTHENTICATION.getOrder());
/* 346 */     return Arrays.asList(new AuthenticationPayloadInterceptor[] { standard, legacy });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\RSocketSecurity$JwtSpec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */