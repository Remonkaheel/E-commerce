/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.ProviderManager;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.web.access.intercept.AuthorizationFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultResourcesFilter;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
/*     */ import org.springframework.security.web.csrf.CsrfToken;
/*     */ import org.springframework.security.web.webauthn.api.PublicKeyCredentialRpEntity;
/*     */ import org.springframework.security.web.webauthn.authentication.PublicKeyCredentialRequestOptionsFilter;
/*     */ import org.springframework.security.web.webauthn.authentication.WebAuthnAuthenticationFilter;
/*     */ import org.springframework.security.web.webauthn.authentication.WebAuthnAuthenticationProvider;
/*     */ import org.springframework.security.web.webauthn.management.MapPublicKeyCredentialUserEntityRepository;
/*     */ import org.springframework.security.web.webauthn.management.MapUserCredentialRepository;
/*     */ import org.springframework.security.web.webauthn.management.PublicKeyCredentialUserEntityRepository;
/*     */ import org.springframework.security.web.webauthn.management.UserCredentialRepository;
/*     */ import org.springframework.security.web.webauthn.management.WebAuthnRelyingPartyOperations;
/*     */ import org.springframework.security.web.webauthn.management.Webauthn4JRelyingPartyOperations;
/*     */ import org.springframework.security.web.webauthn.registration.DefaultWebAuthnRegistrationPageGeneratingFilter;
/*     */ import org.springframework.security.web.webauthn.registration.PublicKeyCredentialCreationOptionsFilter;
/*     */ import org.springframework.security.web.webauthn.registration.PublicKeyCredentialCreationOptionsRepository;
/*     */ import org.springframework.security.web.webauthn.registration.WebAuthnRegistrationFilter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAuthnConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<WebAuthnConfigurer<H>, H>
/*     */ {
/*     */   private String rpId;
/*     */   private String rpName;
/*  65 */   private Set<String> allowedOrigins = new HashSet<>();
/*     */ 
/*     */   
/*     */   private boolean disableDefaultRegistrationPage = false;
/*     */ 
/*     */   
/*     */   private PublicKeyCredentialCreationOptionsRepository creationOptionsRepository;
/*     */ 
/*     */   
/*     */   private HttpMessageConverter<Object> converter;
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> rpId(String rpId) {
/*  79 */     Assert.hasText(rpId, "rpId be null or empty");
/*  80 */     this.rpId = rpId;
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> rpName(String rpName) {
/*  90 */     Assert.hasText(rpName, "rpName can't be null or empty");
/*  91 */     this.rpName = rpName;
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> allowedOrigins(String... allowedOrigins) {
/* 102 */     return allowedOrigins(Set.of(allowedOrigins));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> allowedOrigins(Set<String> allowedOrigins) {
/* 112 */     Assert.notNull(allowedOrigins, "allowedOrigins can't be null");
/* 113 */     this.allowedOrigins = allowedOrigins;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> disableDefaultRegistrationPage(boolean disable) {
/* 125 */     this.disableDefaultRegistrationPage = disable;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> messageConverter(HttpMessageConverter<Object> converter) {
/* 136 */     Assert.notNull(converter, "converter can't be null");
/* 137 */     this.converter = converter;
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebAuthnConfigurer<H> creationOptionsRepository(PublicKeyCredentialCreationOptionsRepository creationOptionsRepository) {
/* 148 */     Assert.notNull(creationOptionsRepository, "creationOptionsRepository can't be null");
/* 149 */     this.creationOptionsRepository = creationOptionsRepository;
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(H http) throws Exception {
/* 156 */     UserDetailsService userDetailsService = (UserDetailsService)getSharedOrBean(http, UserDetailsService.class).orElseThrow(() -> new IllegalStateException("Missing UserDetailsService Bean"));
/*     */ 
/*     */     
/* 159 */     PublicKeyCredentialUserEntityRepository userEntities = getSharedOrBean(http, PublicKeyCredentialUserEntityRepository.class).orElse(userEntityRepository());
/*     */     
/* 161 */     UserCredentialRepository userCredentials = (UserCredentialRepository)getSharedOrBean(http, UserCredentialRepository.class).orElse(userCredentialRepository());
/* 162 */     WebAuthnRelyingPartyOperations rpOperations = webAuthnRelyingPartyOperations(userEntities, userCredentials);
/* 163 */     PublicKeyCredentialCreationOptionsRepository creationOptionsRepository = creationOptionsRepository();
/* 164 */     WebAuthnAuthenticationFilter webAuthnAuthnFilter = new WebAuthnAuthenticationFilter();
/* 165 */     webAuthnAuthnFilter.setAuthenticationManager((AuthenticationManager)new ProviderManager(new AuthenticationProvider[] { (AuthenticationProvider)new WebAuthnAuthenticationProvider(rpOperations, userDetailsService) }));
/*     */     
/* 167 */     WebAuthnRegistrationFilter webAuthnRegistrationFilter = new WebAuthnRegistrationFilter(userCredentials, rpOperations);
/*     */     
/* 169 */     PublicKeyCredentialCreationOptionsFilter creationOptionsFilter = new PublicKeyCredentialCreationOptionsFilter(rpOperations);
/*     */     
/* 171 */     if (creationOptionsRepository != null) {
/* 172 */       webAuthnRegistrationFilter.setCreationOptionsRepository(creationOptionsRepository);
/* 173 */       creationOptionsFilter.setCreationOptionsRepository(creationOptionsRepository);
/*     */     } 
/* 175 */     if (this.converter != null) {
/* 176 */       webAuthnRegistrationFilter.setConverter(this.converter);
/* 177 */       creationOptionsFilter.setConverter(this.converter);
/*     */     } 
/* 179 */     http.addFilterBefore((Filter)webAuthnAuthnFilter, BasicAuthenticationFilter.class);
/* 180 */     http.addFilterAfter((Filter)webAuthnRegistrationFilter, AuthorizationFilter.class);
/* 181 */     http.addFilterBefore((Filter)creationOptionsFilter, AuthorizationFilter.class);
/* 182 */     http.addFilterBefore((Filter)new PublicKeyCredentialRequestOptionsFilter(rpOperations), AuthorizationFilter.class);
/*     */ 
/*     */     
/* 185 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/* 186 */     boolean isLoginPageEnabled = (loginPageGeneratingFilter != null && loginPageGeneratingFilter.isEnabled());
/* 187 */     if (isLoginPageEnabled) {
/* 188 */       loginPageGeneratingFilter.setPasskeysEnabled(true);
/* 189 */       loginPageGeneratingFilter.setResolveHeaders(request -> {
/*     */             CsrfToken csrfToken = (CsrfToken)request.getAttribute(CsrfToken.class.getName());
/*     */             
/*     */             return Map.of(csrfToken.getHeaderName(), csrfToken.getToken());
/*     */           });
/*     */     } 
/* 195 */     if (!this.disableDefaultRegistrationPage) {
/* 196 */       http.addFilterAfter((Filter)new DefaultWebAuthnRegistrationPageGeneratingFilter(userEntities, userCredentials), AuthorizationFilter.class);
/*     */       
/* 198 */       if (!isLoginPageEnabled) {
/* 199 */         http.addFilter((Filter)DefaultResourcesFilter.css());
/*     */       }
/*     */     } 
/*     */     
/* 203 */     if (isLoginPageEnabled || !this.disableDefaultRegistrationPage) {
/* 204 */       http.addFilter((Filter)DefaultResourcesFilter.webauthn());
/*     */     }
/*     */   }
/*     */   
/*     */   private PublicKeyCredentialCreationOptionsRepository creationOptionsRepository() {
/* 209 */     if (this.creationOptionsRepository != null) {
/* 210 */       return this.creationOptionsRepository;
/*     */     }
/* 212 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 213 */     return (PublicKeyCredentialCreationOptionsRepository)context.getBeanProvider(PublicKeyCredentialCreationOptionsRepository.class).getIfUnique();
/*     */   }
/*     */   
/*     */   private <C> Optional<C> getSharedOrBean(H http, Class<C> type) {
/* 217 */     C shared = (C)http.getSharedObject(type);
/* 218 */     return Optional.<C>ofNullable(shared).or(() -> getBeanOrNull(type));
/*     */   }
/*     */   
/*     */   private <T> Optional<T> getBeanOrNull(Class<T> type) {
/* 222 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 223 */     if (context == null) {
/* 224 */       return Optional.empty();
/*     */     }
/*     */     try {
/* 227 */       return Optional.of((T)context.getBean(type));
/*     */     }
/* 229 */     catch (NoSuchBeanDefinitionException ex) {
/* 230 */       return Optional.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   private MapUserCredentialRepository userCredentialRepository() {
/* 235 */     return new MapUserCredentialRepository();
/*     */   }
/*     */   
/*     */   private PublicKeyCredentialUserEntityRepository userEntityRepository() {
/* 239 */     return (PublicKeyCredentialUserEntityRepository)new MapPublicKeyCredentialUserEntityRepository();
/*     */   }
/*     */ 
/*     */   
/*     */   private WebAuthnRelyingPartyOperations webAuthnRelyingPartyOperations(PublicKeyCredentialUserEntityRepository userEntities, UserCredentialRepository userCredentials) {
/* 244 */     Optional<WebAuthnRelyingPartyOperations> webauthnOperationsBean = getBeanOrNull(WebAuthnRelyingPartyOperations.class);
/*     */     
/* 246 */     return webauthnOperationsBean.orElseGet(() -> new Webauthn4JRelyingPartyOperations(userEntities, userCredentials, PublicKeyCredentialRpEntity.builder().id(this.rpId).name(this.rpName).build(), this.allowedOrigins));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\WebAuthnConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */