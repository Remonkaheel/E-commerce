/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*     */ import org.springframework.security.config.http.SessionCreationPolicy;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.session.InvalidSessionStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "sessionManagement", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nSessionManagementDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SessionManagementDsl.kt\norg/springframework/security/config/annotation/web/SessionManagementDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,127:1\n1#2:128\n*E\n"})
/*     */ final class SessionManagementDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<SessionManagementConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(SessionManagementConfigurer sessionManagement) {
/* 113 */     Intrinsics.checkNotNullParameter(sessionManagement, "sessionManagement"); if (SessionManagementDsl.this.getInvalidSessionUrl() != null) { String str1 = SessionManagementDsl.this.getInvalidSessionUrl(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; String it = str1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       int $i$a$-also-SessionManagementDsl$get$1$1 = 0; sessionManagement.invalidSessionUrl(sessionManagementDsl.getInvalidSessionUrl()); } else { SessionManagementDsl.this.getInvalidSessionUrl(); }  if (SessionManagementDsl.this.getRequireExplicitAuthenticationStrategy() != null) { Boolean bool = SessionManagementDsl.this.getRequireExplicitAuthenticationStrategy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-SessionManagementDsl$get$1$2 = 0; Intrinsics.checkNotNull(sessionManagementDsl.getRequireExplicitAuthenticationStrategy()); sessionManagement.requireExplicitAuthenticationStrategy(sessionManagementDsl.getRequireExplicitAuthenticationStrategy().booleanValue()); } else { SessionManagementDsl.this.getRequireExplicitAuthenticationStrategy(); }  if (SessionManagementDsl.this.getInvalidSessionStrategy() != null) { InvalidSessionStrategy invalidSessionStrategy1 = SessionManagementDsl.this.getInvalidSessionStrategy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; InvalidSessionStrategy it = invalidSessionStrategy1; int $i$a$-also-SessionManagementDsl$get$1$3 = 0; sessionManagement.invalidSessionStrategy(sessionManagementDsl.getInvalidSessionStrategy()); } else { SessionManagementDsl.this.getInvalidSessionStrategy(); }  if (SessionManagementDsl.this.getSessionAuthenticationErrorUrl() != null) { String str1 = SessionManagementDsl.this.getSessionAuthenticationErrorUrl(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; String it = str1; int $i$a$-also-SessionManagementDsl$get$1$4 = 0; sessionManagement.sessionAuthenticationErrorUrl(sessionManagementDsl.getSessionAuthenticationErrorUrl()); } else { SessionManagementDsl.this.getSessionAuthenticationErrorUrl(); }  if (SessionManagementDsl.this.getSessionAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = SessionManagementDsl.this.getSessionAuthenticationFailureHandler(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; AuthenticationFailureHandler it = authenticationFailureHandler1; int $i$a$-also-SessionManagementDsl$get$1$5 = 0; sessionManagement.sessionAuthenticationFailureHandler(sessionManagementDsl.getSessionAuthenticationFailureHandler()); } else { SessionManagementDsl.this.getSessionAuthenticationFailureHandler(); }  if (SessionManagementDsl.this.getEnableSessionUrlRewriting() != null) { Boolean bool = SessionManagementDsl.this.getEnableSessionUrlRewriting(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-SessionManagementDsl$get$1$6 = 0; Intrinsics.checkNotNull(sessionManagementDsl.getEnableSessionUrlRewriting()); sessionManagement.enableSessionUrlRewriting(sessionManagementDsl.getEnableSessionUrlRewriting().booleanValue()); } else { SessionManagementDsl.this.getEnableSessionUrlRewriting(); }  if (SessionManagementDsl.this.getSessionCreationPolicy() != null) { SessionCreationPolicy sessionCreationPolicy1 = SessionManagementDsl.this.getSessionCreationPolicy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; SessionCreationPolicy it = sessionCreationPolicy1; int $i$a$-also-SessionManagementDsl$get$1$7 = 0; sessionManagement.sessionCreationPolicy(sessionManagementDsl.getSessionCreationPolicy()); } else { SessionManagementDsl.this.getSessionCreationPolicy(); }  if (SessionManagementDsl.this.getSessionAuthenticationStrategy() != null) { SessionAuthenticationStrategy sessionAuthenticationStrategy1 = SessionManagementDsl.this.getSessionAuthenticationStrategy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; SessionAuthenticationStrategy it = sessionAuthenticationStrategy1; int $i$a$-also-SessionManagementDsl$get$1$8 = 0; sessionManagement.sessionAuthenticationStrategy(sessionManagementDsl.getSessionAuthenticationStrategy()); } else { SessionManagementDsl.this.getSessionAuthenticationStrategy(); }  if (SessionManagementDsl.access$getSessionFixation$p(SessionManagementDsl.this) != null) { Function1 function11 = SessionManagementDsl.access$getSessionFixation$p(SessionManagementDsl.this); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; Function1 it = function11; int $i$a$-also-SessionManagementDsl$get$1$9 = 0; SessionManagementDsl.access$getSessionFixation$p(sessionManagementDsl); sessionManagement.sessionFixation((SessionManagementDsl.access$getSessionFixation$p(sessionManagementDsl) != null) ? SessionManagementDsl.access$getSessionFixation$p(sessionManagementDsl)::invoke$lambda$9$lambda$8 : null); } else { SessionManagementDsl.access$getSessionFixation$p(SessionManagementDsl.this); }  if (SessionManagementDsl.access$getSessionConcurrency$p(SessionManagementDsl.this) != null) { Function1 function11 = SessionManagementDsl.access$getSessionConcurrency$p(SessionManagementDsl.this); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; Function1 it = function11; int $i$a$-also-SessionManagementDsl$get$1$10 = 0;
/*     */       SessionManagementDsl.access$getSessionConcurrency$p(sessionManagementDsl);
/*     */       sessionManagement.sessionConcurrency((SessionManagementDsl.access$getSessionConcurrency$p(sessionManagementDsl) != null) ? SessionManagementDsl.access$getSessionConcurrency$p(sessionManagementDsl)::invoke$lambda$11$lambda$10 : null); }
/*     */     else
/*     */     { SessionManagementDsl.access$getSessionConcurrency$p(SessionManagementDsl.this); }
/*     */   
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$9$lambda$8(Function1 $tmp0, SessionManagementConfigurer.SessionFixationConfigurer t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$11$lambda$10(Function1 $tmp0, SessionManagementConfigurer.ConcurrencyControlConfigurer t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   SessionManagementDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\SessionManagementDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */