/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.AdviceMode;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.context.annotation.Role;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.AfterInvocationProvider;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.annotation.Jsr250MethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.annotation.Jsr250Voter;
/*     */ import org.springframework.security.access.annotation.SecuredAnnotationSecurityMetadataSource;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedAnnotationAttributeFactory;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedPostInvocationAdvice;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedPreInvocationAdvice;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.access.intercept.AfterInvocationManager;
/*     */ import org.springframework.security.access.intercept.AfterInvocationProviderManager;
/*     */ import org.springframework.security.access.intercept.RunAsManager;
/*     */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityInterceptor;
/*     */ import org.springframework.security.access.intercept.aspectj.AspectJMethodSecurityInterceptor;
/*     */ import org.springframework.security.access.method.DelegatingMethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.prepost.PostInvocationAdviceProvider;
/*     */ import org.springframework.security.access.prepost.PostInvocationAuthorizationAdvice;
/*     */ import org.springframework.security.access.prepost.PreInvocationAuthorizationAdvice;
/*     */ import org.springframework.security.access.prepost.PreInvocationAuthorizationAdviceVoter;
/*     */ import org.springframework.security.access.prepost.PrePostAnnotationSecurityMetadataSource;
/*     */ import org.springframework.security.access.prepost.PrePostInvocationAttributeFactory;
/*     */ import org.springframework.security.access.vote.AffirmativeBased;
/*     */ import org.springframework.security.access.vote.AuthenticatedVoter;
/*     */ import org.springframework.security.access.vote.RoleVoter;
/*     */ import org.springframework.security.authentication.AuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @Role(2)
/*     */ public class GlobalMethodSecurityConfiguration
/*     */   implements ImportAware, SmartInitializingSingleton, BeanFactoryAware
/*     */ {
/*  98 */   private static final Log logger = LogFactory.getLog(GlobalMethodSecurityConfiguration.class);
/*     */   
/* 100 */   private ObjectPostProcessor<Object> objectPostProcessor = new ObjectPostProcessor<Object>()
/*     */     {
/*     */       public <T> T postProcess(T object)
/*     */       {
/* 104 */         throw new IllegalStateException(ObjectPostProcessor.class.getName() + " is a required bean. Ensure you have used @" + ObjectPostProcessor.class.getName());
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/* 113 */   private DefaultMethodSecurityExpressionHandler defaultMethodExpressionHandler = new DefaultMethodSecurityExpressionHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuthenticationManagerBuilder auth;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableAuthenticationRegistry;
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationAttributes enableMethodSecurity;
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanFactory context;
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodSecurityExpressionHandler expressionHandler;
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodSecurityInterceptor methodSecurityInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public MethodInterceptor methodSecurityInterceptor(MethodSecurityMetadataSource methodSecurityMetadataSource) {
/* 150 */     this
/* 151 */       .methodSecurityInterceptor = isAspectJ() ? (MethodSecurityInterceptor)new AspectJMethodSecurityInterceptor() : new MethodSecurityInterceptor();
/* 152 */     this.methodSecurityInterceptor.setAccessDecisionManager(accessDecisionManager());
/* 153 */     this.methodSecurityInterceptor.setAfterInvocationManager(afterInvocationManager());
/* 154 */     this.methodSecurityInterceptor.setSecurityMetadataSource(methodSecurityMetadataSource);
/* 155 */     this.methodSecurityInterceptor.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 156 */     RunAsManager runAsManager = runAsManager();
/* 157 */     if (runAsManager != null) {
/* 158 */       this.methodSecurityInterceptor.setRunAsManager(runAsManager);
/*     */     }
/* 160 */     return (MethodInterceptor)this.methodSecurityInterceptor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/*     */     try {
/* 166 */       initializeMethodSecurityInterceptor();
/*     */     }
/* 168 */     catch (Exception ex) {
/* 169 */       throw new RuntimeException(ex);
/*     */     } 
/* 171 */     PermissionEvaluator permissionEvaluator = getBeanOrNull(PermissionEvaluator.class);
/* 172 */     if (permissionEvaluator != null) {
/* 173 */       this.defaultMethodExpressionHandler.setPermissionEvaluator(permissionEvaluator);
/*     */     }
/* 175 */     RoleHierarchy roleHierarchy = getBeanOrNull(RoleHierarchy.class);
/* 176 */     if (roleHierarchy != null) {
/* 177 */       this.defaultMethodExpressionHandler.setRoleHierarchy(roleHierarchy);
/*     */     }
/* 179 */     AuthenticationTrustResolver trustResolver = getBeanOrNull(AuthenticationTrustResolver.class);
/* 180 */     if (trustResolver != null) {
/* 181 */       this.defaultMethodExpressionHandler.setTrustResolver(trustResolver);
/*     */     }
/* 183 */     GrantedAuthorityDefaults grantedAuthorityDefaults = getBeanOrNull(GrantedAuthorityDefaults.class);
/* 184 */     if (grantedAuthorityDefaults != null) {
/* 185 */       this.defaultMethodExpressionHandler.setDefaultRolePrefix(grantedAuthorityDefaults.getRolePrefix());
/*     */     }
/*     */     
/* 188 */     this.defaultMethodExpressionHandler = (DefaultMethodSecurityExpressionHandler)this.objectPostProcessor.postProcess(this.defaultMethodExpressionHandler);
/*     */   }
/*     */   
/*     */   private <T> T getBeanOrNull(Class<T> type) {
/* 192 */     return (T)this.context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */   
/*     */   private void initializeMethodSecurityInterceptor() throws Exception {
/* 196 */     if (this.methodSecurityInterceptor == null) {
/*     */       return;
/*     */     }
/* 199 */     this.methodSecurityInterceptor.setAuthenticationManager(authenticationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AfterInvocationManager afterInvocationManager() {
/* 215 */     if (prePostEnabled()) {
/* 216 */       AfterInvocationProviderManager invocationProviderManager = new AfterInvocationProviderManager();
/*     */       
/* 218 */       ExpressionBasedPostInvocationAdvice postAdvice = new ExpressionBasedPostInvocationAdvice(getExpressionHandler());
/* 219 */       PostInvocationAdviceProvider postInvocationAdviceProvider = new PostInvocationAdviceProvider((PostInvocationAuthorizationAdvice)postAdvice);
/* 220 */       List<AfterInvocationProvider> afterInvocationProviders = new ArrayList<>();
/* 221 */       afterInvocationProviders.add(postInvocationAdviceProvider);
/* 222 */       invocationProviderManager.setProviders(afterInvocationProviders);
/* 223 */       return (AfterInvocationManager)invocationProviderManager;
/*     */     } 
/* 225 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RunAsManager runAsManager() {
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AccessDecisionManager accessDecisionManager() {
/* 250 */     List<AccessDecisionVoter<?>> decisionVoters = new ArrayList<>();
/* 251 */     if (prePostEnabled()) {
/* 252 */       ExpressionBasedPreInvocationAdvice expressionAdvice = new ExpressionBasedPreInvocationAdvice();
/* 253 */       expressionAdvice.setExpressionHandler(getExpressionHandler());
/* 254 */       decisionVoters.add(new PreInvocationAuthorizationAdviceVoter((PreInvocationAuthorizationAdvice)expressionAdvice));
/*     */     } 
/* 256 */     if (jsr250Enabled()) {
/* 257 */       decisionVoters.add(new Jsr250Voter());
/*     */     }
/* 259 */     RoleVoter roleVoter = new RoleVoter();
/* 260 */     GrantedAuthorityDefaults grantedAuthorityDefaults = getBeanOrNull(GrantedAuthorityDefaults.class);
/* 261 */     if (grantedAuthorityDefaults != null) {
/* 262 */       roleVoter.setRolePrefix(grantedAuthorityDefaults.getRolePrefix());
/*     */     }
/* 264 */     decisionVoters.add(roleVoter);
/* 265 */     decisionVoters.add(new AuthenticatedVoter());
/* 266 */     return (AccessDecisionManager)new AffirmativeBased(decisionVoters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodSecurityExpressionHandler createExpressionHandler() {
/* 282 */     return (MethodSecurityExpressionHandler)this.defaultMethodExpressionHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MethodSecurityExpressionHandler getExpressionHandler() {
/* 291 */     if (this.expressionHandler == null) {
/* 292 */       this.expressionHandler = createExpressionHandler();
/*     */     }
/* 294 */     return this.expressionHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodSecurityMetadataSource customMethodSecurityMetadataSource() {
/* 304 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AuthenticationManager authenticationManager() throws Exception {
/* 316 */     if (this.authenticationManager == null) {
/*     */       
/* 318 */       DefaultAuthenticationEventPublisher eventPublisher = (DefaultAuthenticationEventPublisher)this.objectPostProcessor.postProcess(new DefaultAuthenticationEventPublisher());
/* 319 */       this.auth = new AuthenticationManagerBuilder(this.objectPostProcessor);
/* 320 */       this.auth.authenticationEventPublisher((AuthenticationEventPublisher)eventPublisher);
/* 321 */       configure(this.auth);
/* 322 */       this
/* 323 */         .authenticationManager = this.disableAuthenticationRegistry ? getAuthenticationConfiguration().getAuthenticationManager() : (AuthenticationManager)this.auth.build();
/*     */     } 
/* 325 */     return this.authenticationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configure(AuthenticationManagerBuilder auth) throws Exception {
/* 337 */     this.disableAuthenticationRegistry = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   public MethodSecurityMetadataSource methodSecurityMetadataSource() {
/* 350 */     List<MethodSecurityMetadataSource> sources = new ArrayList<>();
/*     */     
/* 352 */     ExpressionBasedAnnotationAttributeFactory attributeFactory = new ExpressionBasedAnnotationAttributeFactory(getExpressionHandler());
/* 353 */     MethodSecurityMetadataSource customMethodSecurityMetadataSource = customMethodSecurityMetadataSource();
/* 354 */     if (customMethodSecurityMetadataSource != null) {
/* 355 */       sources.add(customMethodSecurityMetadataSource);
/*     */     }
/* 357 */     boolean hasCustom = (customMethodSecurityMetadataSource != null);
/* 358 */     boolean isPrePostEnabled = prePostEnabled();
/* 359 */     boolean isSecuredEnabled = securedEnabled();
/* 360 */     boolean isJsr250Enabled = jsr250Enabled();
/* 361 */     Assert.state((isPrePostEnabled || isSecuredEnabled || isJsr250Enabled || hasCustom), "In the composition of all global method configuration, no annotation support was actually activated");
/*     */ 
/*     */     
/* 364 */     if (isPrePostEnabled) {
/* 365 */       sources.add(new PrePostAnnotationSecurityMetadataSource((PrePostInvocationAttributeFactory)attributeFactory));
/*     */     }
/* 367 */     if (isSecuredEnabled) {
/* 368 */       sources.add(new SecuredAnnotationSecurityMetadataSource());
/*     */     }
/* 370 */     if (isJsr250Enabled) {
/* 371 */       GrantedAuthorityDefaults grantedAuthorityDefaults = getBeanOrNull(GrantedAuthorityDefaults.class);
/*     */       
/* 373 */       Jsr250MethodSecurityMetadataSource jsr250MethodSecurityMetadataSource = (Jsr250MethodSecurityMetadataSource)this.context.getBean(Jsr250MethodSecurityMetadataSource.class);
/* 374 */       if (grantedAuthorityDefaults != null) {
/* 375 */         jsr250MethodSecurityMetadataSource.setDefaultRolePrefix(grantedAuthorityDefaults.getRolePrefix());
/*     */       }
/* 377 */       sources.add(jsr250MethodSecurityMetadataSource);
/*     */     } 
/* 379 */     return (MethodSecurityMetadataSource)new DelegatingMethodSecurityMetadataSource(sources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public PreInvocationAuthorizationAdvice preInvocationAuthorizationAdvice() {
/* 389 */     ExpressionBasedPreInvocationAdvice preInvocationAdvice = new ExpressionBasedPreInvocationAdvice();
/* 390 */     preInvocationAdvice.setExpressionHandler(getExpressionHandler());
/* 391 */     return (PreInvocationAuthorizationAdvice)preInvocationAdvice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setImportMetadata(AnnotationMetadata importMetadata) {
/* 401 */     Map<String, Object> annotationAttributes = importMetadata.getAnnotationAttributes(EnableGlobalMethodSecurity.class.getName());
/* 402 */     this.enableMethodSecurity = AnnotationAttributes.fromMap(annotationAttributes);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setObjectPostProcessor(ObjectPostProcessor<Object> objectPostProcessor) {
/* 407 */     this.objectPostProcessor = objectPostProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   @Autowired(required = false)
/*     */   public void setObjectPostProcessor(ObjectPostProcessor<Object> objectPostProcessor) {
/* 417 */     this.objectPostProcessor = (ObjectPostProcessor<Object>)objectPostProcessor;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setMethodSecurityExpressionHandler(List<MethodSecurityExpressionHandler> handlers) {
/* 422 */     if (handlers.size() != 1) {
/* 423 */       logger.debug("Not autowiring MethodSecurityExpressionHandler since size != 1. Got " + String.valueOf(handlers));
/*     */       return;
/*     */     } 
/* 426 */     this.expressionHandler = handlers.get(0);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 431 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 432 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 437 */     this.context = beanFactory;
/*     */   }
/*     */   
/*     */   private AuthenticationConfiguration getAuthenticationConfiguration() {
/* 441 */     return (AuthenticationConfiguration)this.context.getBean(AuthenticationConfiguration.class);
/*     */   }
/*     */   
/*     */   private boolean prePostEnabled() {
/* 445 */     return enableMethodSecurity().getBoolean("prePostEnabled");
/*     */   }
/*     */   
/*     */   private boolean securedEnabled() {
/* 449 */     return enableMethodSecurity().getBoolean("securedEnabled");
/*     */   }
/*     */   
/*     */   private boolean jsr250Enabled() {
/* 453 */     return enableMethodSecurity().getBoolean("jsr250Enabled");
/*     */   }
/*     */   
/*     */   private boolean isAspectJ() {
/* 457 */     return (enableMethodSecurity().getEnum("mode") == AdviceMode.ASPECTJ);
/*     */   }
/*     */   
/*     */   private AnnotationAttributes enableMethodSecurity() {
/* 461 */     if (this.enableMethodSecurity == null) {
/*     */       
/* 463 */       EnableGlobalMethodSecurity methodSecurityAnnotation = (EnableGlobalMethodSecurity)AnnotationUtils.findAnnotation(getClass(), EnableGlobalMethodSecurity.class);
/*     */       
/* 465 */       Assert.notNull(methodSecurityAnnotation, () -> EnableGlobalMethodSecurity.class.getName() + " is required");
/* 466 */       Map<String, Object> methodSecurityAttrs = AnnotationUtils.getAnnotationAttributes(methodSecurityAnnotation);
/* 467 */       this.enableMethodSecurity = AnnotationAttributes.fromMap(methodSecurityAttrs);
/*     */     } 
/* 469 */     return this.enableMethodSecurity;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\GlobalMethodSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */