/*    */ package org.springframework.security.config.annotation.web.configuration;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.authentication.ObservationAuthenticationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ObjectPostProcessor<AuthenticationManager>
/*    */ {
/*    */   public AuthenticationManager postProcess(AuthenticationManager object) {
/* 67 */     ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 68 */     boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ObservationConfiguration.all)).shouldObserveAuthentications());
/* 69 */     return active ? (AuthenticationManager)new ObservationAuthenticationManager(r, object) : object;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\ObservationConfiguration$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */