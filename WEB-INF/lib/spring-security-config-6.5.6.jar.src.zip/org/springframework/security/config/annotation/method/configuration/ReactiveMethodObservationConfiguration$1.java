/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.security.authorization.ObservationReactiveAuthorizationManager;
/*    */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocation>>
/*    */ {
/*    */   public ReactiveAuthorizationManager postProcess(ReactiveAuthorizationManager object) {
/* 50 */     ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 51 */     boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ReactiveMethodObservationConfiguration.all)).shouldObserveAuthorizations());
/* 52 */     return active ? (ReactiveAuthorizationManager)new ObservationReactiveAuthorizationManager(r, object) : object;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\ReactiveMethodObservationConfiguration$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */