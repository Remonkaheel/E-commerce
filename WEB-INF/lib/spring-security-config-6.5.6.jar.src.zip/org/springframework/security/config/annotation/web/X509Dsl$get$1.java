/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.X509Configurer;
/*    */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;
/*    */ import org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter;
/*    */ import org.springframework.security.web.authentication.preauth.x509.X509PrincipalExtractor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "x509", "Lorg/springframework/security/config/annotation/web/configurers/X509Configurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nX509Dsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 X509Dsl.kt\norg/springframework/security/config/annotation/web/X509Dsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,68:1\n1#2:69\n*E\n"})
/*    */ final class X509Dsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<X509Configurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(X509Configurer x509) {
/* 59 */     Intrinsics.checkNotNullParameter(x509, "x509"); if (X509Dsl.this.getX509AuthenticationFilter() != null) { X509AuthenticationFilter x509AuthenticationFilter1 = X509Dsl.this.getX509AuthenticationFilter(); X509Dsl x509Dsl = X509Dsl.this; X509AuthenticationFilter it = x509AuthenticationFilter1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 69 */       int $i$a$-also-X509Dsl$get$1$1 = 0; x509.x509AuthenticationFilter(x509Dsl.getX509AuthenticationFilter()); } else { X509Dsl.this.getX509AuthenticationFilter(); }  if (X509Dsl.this.getX509PrincipalExtractor() != null) { X509PrincipalExtractor x509PrincipalExtractor1 = X509Dsl.this.getX509PrincipalExtractor(); X509Dsl x509Dsl = X509Dsl.this; X509PrincipalExtractor it = x509PrincipalExtractor1; int $i$a$-also-X509Dsl$get$1$2 = 0; x509.x509PrincipalExtractor(x509Dsl.getX509PrincipalExtractor()); } else { X509Dsl.this.getX509PrincipalExtractor(); }  if (X509Dsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> authenticationDetailsSource1 = X509Dsl.this.getAuthenticationDetailsSource(); X509Dsl x509Dsl = X509Dsl.this; AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> it = authenticationDetailsSource1; int $i$a$-also-X509Dsl$get$1$3 = 0; x509.authenticationDetailsSource(x509Dsl.getAuthenticationDetailsSource()); } else { X509Dsl.this.getAuthenticationDetailsSource(); }  if (X509Dsl.this.getUserDetailsService() != null) { UserDetailsService userDetailsService1 = X509Dsl.this.getUserDetailsService(); X509Dsl x509Dsl = X509Dsl.this; UserDetailsService it = userDetailsService1; int $i$a$-also-X509Dsl$get$1$4 = 0; x509.userDetailsService(x509Dsl.getUserDetailsService()); } else { X509Dsl.this.getUserDetailsService(); }  if (X509Dsl.this.getAuthenticationUserDetailsService() != null) { AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService1 = X509Dsl.this.getAuthenticationUserDetailsService(); X509Dsl x509Dsl = X509Dsl.this; AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> it = authenticationUserDetailsService1; int $i$a$-also-X509Dsl$get$1$5 = 0; x509.authenticationUserDetailsService(x509Dsl.getAuthenticationUserDetailsService()); } else { X509Dsl.this.getAuthenticationUserDetailsService(); }  if (X509Dsl.this.getSubjectPrincipalRegex() != null) { String str1 = X509Dsl.this.getSubjectPrincipalRegex(); X509Dsl x509Dsl = X509Dsl.this; String it = str1; int $i$a$-also-X509Dsl$get$1$6 = 0;
/*    */       x509.subjectPrincipalRegex(x509Dsl.getSubjectPrincipalRegex()); }
/*    */     else
/*    */     { X509Dsl.this.getSubjectPrincipalRegex(); }
/*    */   
/*    */   }
/*    */   
/*    */   X509Dsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\X509Dsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */