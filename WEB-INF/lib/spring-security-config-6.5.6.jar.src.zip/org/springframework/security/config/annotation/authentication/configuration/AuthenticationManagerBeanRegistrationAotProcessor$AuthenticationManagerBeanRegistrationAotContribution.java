/*    */ package org.springframework.security.config.annotation.authentication.configuration;
/*    */ 
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.ProxyHints;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AuthenticationManagerBeanRegistrationAotContribution
/*    */   implements BeanRegistrationAotContribution
/*    */ {
/*    */   public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 56 */     ProxyHints proxyHints = generationContext.getRuntimeHints().proxies();
/* 57 */     proxyHints.registerJdkProxy(AopProxyUtils.completeJdkProxyInterfaces(new Class[] { AuthenticationManager.class }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configuration\AuthenticationManagerBeanRegistrationAotProcessor$AuthenticationManagerBeanRegistrationAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */