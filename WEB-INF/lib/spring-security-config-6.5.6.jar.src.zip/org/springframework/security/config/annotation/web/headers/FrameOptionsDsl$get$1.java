/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "frameOptions", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$FrameOptionsConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ final class FrameOptionsDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HeadersConfigurer<HttpSecurity>.FrameOptionsConfig, Unit>
/*    */ {
/*    */   public final void invoke(HeadersConfigurer.FrameOptionsConfig frameOptions) {
/* 48 */     Intrinsics.checkNotNullParameter(frameOptions, "frameOptions"); Boolean bool = FrameOptionsDsl.this.getSameOrigin(); FrameOptionsDsl frameOptionsDsl = FrameOptionsDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-FrameOptionsDsl$get$1$1 = 0;
/* 49 */     Intrinsics.checkNotNull(frameOptionsDsl.getSameOrigin()); if (frameOptionsDsl.getSameOrigin().booleanValue()) {
/* 50 */       frameOptions.sameOrigin();
/*    */     }
/*    */     FrameOptionsDsl.this.getSameOrigin();
/* 53 */     bool = FrameOptionsDsl.this.getDeny(); frameOptionsDsl = FrameOptionsDsl.this; it = bool.booleanValue(); int $i$a$-also-FrameOptionsDsl$get$1$2 = 0;
/* 54 */     Intrinsics.checkNotNull(frameOptionsDsl.getDeny()); if (frameOptionsDsl.getDeny().booleanValue()) {
/* 55 */       frameOptions.deny();
/*    */     }
/*    */     FrameOptionsDsl.this.getDeny();
/* 58 */     if (FrameOptionsDsl.access$getDisabled$p(FrameOptionsDsl.this))
/* 59 */       frameOptions.disable(); 
/*    */   }
/*    */   
/*    */   FrameOptionsDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\FrameOptionsDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */