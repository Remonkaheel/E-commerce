/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HttpsRedirectConfigurer;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\021\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\013\032\024\022\n\022\b\022\004\022\0020\0160\r\022\004\022\0020\0170\fH\000¢\006\002\b\020R&\020\003\032\f\022\006\b\001\022\0020\005\030\0010\004X\016¢\006\020\n\002\020\n\032\004\b\006\020\007\"\004\b\b\020\t¨\006\021"}, d2 = {"Lorg/springframework/security/config/annotation/web/HttpsRedirectDsl;", "", "()V", "requestMatchers", "", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "getRequestMatchers", "()[Lorg/springframework/security/web/util/matcher/RequestMatcher;", "setRequestMatchers", "([Lorg/springframework/security/web/util/matcher/RequestMatcher;)V", "[Lorg/springframework/security/web/util/matcher/RequestMatcher;", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HttpsRedirectConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class HttpsRedirectDsl
/*    */ {
/*    */   @Nullable
/*    */   private RequestMatcher[] requestMatchers;
/*    */   
/*    */   @Nullable
/*    */   public final RequestMatcher[] getRequestMatchers() {
/* 34 */     return this.requestMatchers; } public final void setRequestMatchers(@Nullable RequestMatcher[] <set-?>) { this.requestMatchers = <set-?>; }
/*    */   
/*    */   @NotNull
/* 37 */   public final Function1<HttpsRedirectConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new HttpsRedirectDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "https", "Lorg/springframework/security/config/annotation/web/configurers/HttpsRedirectConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nHttpsRedirectDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpsRedirectDsl.kt\norg/springframework/security/config/annotation/web/HttpsRedirectDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,42:1\n1#2:43\n*E\n"})
/* 38 */   static final class HttpsRedirectDsl$get$1 extends Lambda implements Function1<HttpsRedirectConfigurer<HttpSecurity>, Unit> { public final void invoke(HttpsRedirectConfigurer https) { Intrinsics.checkNotNullParameter(https, "https"); if (HttpsRedirectDsl.this.getRequestMatchers() != null) { RequestMatcher[] arrayOfRequestMatcher1 = HttpsRedirectDsl.this.getRequestMatchers(); HttpsRedirectDsl httpsRedirectDsl = HttpsRedirectDsl.this; RequestMatcher[] it = arrayOfRequestMatcher1;
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 43 */         int $i$a$-also-HttpsRedirectDsl$get$1$1 = 0;
/*    */         Intrinsics.checkNotNull(httpsRedirectDsl.getRequestMatchers());
/*    */         RequestMatcher[] arrayOfRequestMatcher2 = httpsRedirectDsl.getRequestMatchers();
/*    */         https.requestMatchers(Arrays.<RequestMatcher>copyOf(arrayOfRequestMatcher2, arrayOfRequestMatcher2.length)); }
/*    */       else
/*    */       { HttpsRedirectDsl.this.getRequestMatchers(); }
/*    */        }
/*    */ 
/*    */     
/*    */     HttpsRedirectDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpsRedirectDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */