/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
/*    */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*    */ import org.springframework.security.web.csrf.CsrfTokenRepository;
/*    */ import org.springframework.security.web.csrf.CsrfTokenRequestHandler;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "csrf", "Lorg/springframework/security/config/annotation/web/configurers/CsrfConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nCsrfDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CsrfDsl.kt\norg/springframework/security/config/annotation/web/CsrfDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,93:1\n1#2:94\n*E\n"})
/*    */ final class CsrfDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<CsrfConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(CsrfConfigurer csrf) {
/* 81 */     Intrinsics.checkNotNullParameter(csrf, "csrf"); if (CsrfDsl.this.getCsrfTokenRepository() != null) { CsrfTokenRepository csrfTokenRepository1 = CsrfDsl.this.getCsrfTokenRepository(); CsrfDsl csrfDsl = CsrfDsl.this; CsrfTokenRepository it = csrfTokenRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 94 */       int $i$a$-also-CsrfDsl$get$1$1 = 0; csrf.csrfTokenRepository(csrfDsl.getCsrfTokenRepository()); } else { CsrfDsl.this.getCsrfTokenRepository(); }  if (CsrfDsl.this.getRequireCsrfProtectionMatcher() != null) { RequestMatcher requestMatcher1 = CsrfDsl.this.getRequireCsrfProtectionMatcher(); CsrfDsl csrfDsl = CsrfDsl.this; RequestMatcher it = requestMatcher1; int $i$a$-also-CsrfDsl$get$1$2 = 0; csrf.requireCsrfProtectionMatcher(csrfDsl.getRequireCsrfProtectionMatcher()); } else { CsrfDsl.this.getRequireCsrfProtectionMatcher(); }  if (CsrfDsl.this.getSessionAuthenticationStrategy() != null) { SessionAuthenticationStrategy sessionAuthenticationStrategy1 = CsrfDsl.this.getSessionAuthenticationStrategy(); CsrfDsl csrfDsl = CsrfDsl.this; SessionAuthenticationStrategy it = sessionAuthenticationStrategy1; int $i$a$-also-CsrfDsl$get$1$3 = 0; csrf.sessionAuthenticationStrategy(csrfDsl.getSessionAuthenticationStrategy()); } else { CsrfDsl.this.getSessionAuthenticationStrategy(); }  if (CsrfDsl.this.getCsrfTokenRequestHandler() != null) { CsrfTokenRequestHandler csrfTokenRequestHandler1 = CsrfDsl.this.getCsrfTokenRequestHandler(); CsrfDsl csrfDsl = CsrfDsl.this; CsrfTokenRequestHandler it = csrfTokenRequestHandler1; int $i$a$-also-CsrfDsl$get$1$4 = 0; csrf.csrfTokenRequestHandler(csrfDsl.getCsrfTokenRequestHandler()); } else { CsrfDsl.this.getCsrfTokenRequestHandler(); }  if (CsrfDsl.access$getIgnoringRequestMatchers$p(CsrfDsl.this) != null) { RequestMatcher[] arrayOfRequestMatcher1 = CsrfDsl.access$getIgnoringRequestMatchers$p(CsrfDsl.this); CsrfDsl csrfDsl = CsrfDsl.this; RequestMatcher[] it = arrayOfRequestMatcher1; int $i$a$-also-CsrfDsl$get$1$5 = 0; Intrinsics.checkNotNull(CsrfDsl.access$getIgnoringRequestMatchers$p(csrfDsl)); RequestMatcher[] arrayOfRequestMatcher2 = CsrfDsl.access$getIgnoringRequestMatchers$p(csrfDsl); csrf.ignoringRequestMatchers(Arrays.<RequestMatcher>copyOf(arrayOfRequestMatcher2, arrayOfRequestMatcher2.length)); } else { CsrfDsl.access$getIgnoringRequestMatchers$p(CsrfDsl.this); }  if (CsrfDsl.access$getIgnoringRequestMatchersPatterns$p(CsrfDsl.this) != null) { String[] arrayOfString1 = CsrfDsl.access$getIgnoringRequestMatchersPatterns$p(CsrfDsl.this); CsrfDsl csrfDsl = CsrfDsl.this; String[] it = arrayOfString1; int $i$a$-also-CsrfDsl$get$1$6 = 0;
/*    */       Intrinsics.checkNotNull(CsrfDsl.access$getIgnoringRequestMatchersPatterns$p(csrfDsl));
/*    */       String[] arrayOfString2 = CsrfDsl.access$getIgnoringRequestMatchersPatterns$p(csrfDsl);
/*    */       csrf.ignoringRequestMatchers(Arrays.<String>copyOf(arrayOfString2, arrayOfString2.length)); }
/*    */     else
/*    */     { CsrfDsl.access$getIgnoringRequestMatchersPatterns$p(CsrfDsl.this); }
/*    */     
/*    */     if (CsrfDsl.access$getDisabled$p(CsrfDsl.this))
/*    */       csrf.disable(); 
/*    */   }
/*    */   
/*    */   CsrfDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\CsrfDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */