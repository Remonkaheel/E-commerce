/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.authorization.method.AuthorizationAdvisor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodSecurityAdvisorRegistrar
/*     */   implements ImportBeanDefinitionRegistrar
/*     */ {
/*     */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/*  42 */     registerAsAdvisor("preFilterAuthorization", registry);
/*  43 */     registerAsAdvisor("preAuthorizeAuthorization", registry);
/*  44 */     registerAsAdvisor("postFilterAuthorization", registry);
/*  45 */     registerAsAdvisor("postAuthorizeAuthorization", registry);
/*  46 */     registerAsAdvisor("securedAuthorization", registry);
/*  47 */     registerAsAdvisor("jsr250Authorization", registry);
/*  48 */     registerAsAdvisor("authorizeReturnObject", registry);
/*     */   }
/*     */   
/*     */   private void registerAsAdvisor(String prefix, BeanDefinitionRegistry registry) {
/*  52 */     String advisorName = prefix + "Advisor";
/*  53 */     if (registry.containsBeanDefinition(advisorName)) {
/*     */       return;
/*     */     }
/*  56 */     String interceptorName = prefix + "MethodInterceptor";
/*  57 */     if (!registry.containsBeanDefinition(interceptorName)) {
/*     */       return;
/*     */     }
/*  60 */     BeanDefinition definition = registry.getBeanDefinition(interceptorName);
/*  61 */     if (!(definition instanceof RootBeanDefinition)) {
/*     */       return;
/*     */     }
/*  64 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(AdvisorWrapper.class);
/*  65 */     builder.setFactoryMethod("of");
/*  66 */     builder.setRole(2);
/*  67 */     builder.addConstructorArgReference(interceptorName);
/*  68 */     RootBeanDefinition advisor = (RootBeanDefinition)builder.getBeanDefinition();
/*  69 */     advisor.setTargetType(Advisor.class);
/*  70 */     registry.registerBeanDefinition(advisorName, (BeanDefinition)advisor);
/*     */   }
/*     */   
/*     */   public static final class AdvisorWrapper
/*     */     implements PointcutAdvisor, MethodInterceptor, Ordered, AopInfrastructureBean
/*     */   {
/*     */     private final AuthorizationAdvisor advisor;
/*     */     
/*     */     private AdvisorWrapper(AuthorizationAdvisor advisor) {
/*  79 */       this.advisor = advisor;
/*     */     }
/*     */     
/*     */     public static AdvisorWrapper of(AuthorizationAdvisor advisor) {
/*  83 */       return new AdvisorWrapper(advisor);
/*     */     }
/*     */ 
/*     */     
/*     */     public Advice getAdvice() {
/*  88 */       return this.advisor.getAdvice();
/*     */     }
/*     */ 
/*     */     
/*     */     public Pointcut getPointcut() {
/*  93 */       return this.advisor.getPointcut();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/*  98 */       return this.advisor.getOrder();
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(@NotNull MethodInvocation invocation) throws Throwable {
/* 104 */       return this.advisor.invoke(invocation);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\MethodSecurityAdvisorRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */