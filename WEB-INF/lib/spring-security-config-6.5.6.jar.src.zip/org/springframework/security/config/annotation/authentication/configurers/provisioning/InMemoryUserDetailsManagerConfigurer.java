/*    */ package org.springframework.security.config.annotation.authentication.configurers.provisioning;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*    */ import org.springframework.security.provisioning.InMemoryUserDetailsManager;
/*    */ import org.springframework.security.provisioning.UserDetailsManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryUserDetailsManagerConfigurer<B extends ProviderManagerBuilder<B>>
/*    */   extends UserDetailsManagerConfigurer<B, InMemoryUserDetailsManagerConfigurer<B>>
/*    */ {
/*    */   public InMemoryUserDetailsManagerConfigurer() {
/* 41 */     super((UserDetailsManager)new InMemoryUserDetailsManager(new ArrayList()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurers\provisioning\InMemoryUserDetailsManagerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */