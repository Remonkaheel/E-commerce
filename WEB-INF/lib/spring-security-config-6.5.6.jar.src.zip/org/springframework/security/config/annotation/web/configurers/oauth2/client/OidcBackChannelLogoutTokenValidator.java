/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.security.oauth2.client.oidc.authentication.logout.LogoutTokenClaimAccessor;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.oauth2.core.OAuth2Token;
/*     */ import org.springframework.security.oauth2.core.OAuth2TokenValidator;
/*     */ import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
/*     */ import org.springframework.security.oauth2.jwt.Jwt;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OidcBackChannelLogoutTokenValidator
/*     */   implements OAuth2TokenValidator<Jwt>
/*     */ {
/*     */   private static final String LOGOUT_VALIDATION_URL = "https://openid.net/specs/openid-connect-backchannel-1_0.html#Validation";
/*     */   private static final String BACK_CHANNEL_LOGOUT_EVENT = "http://schemas.openid.net/event/backchannel-logout";
/*     */   private final String audience;
/*     */   private final String issuer;
/*     */   
/*     */   OidcBackChannelLogoutTokenValidator(ClientRegistration clientRegistration) {
/*  60 */     this.audience = clientRegistration.getClientId();
/*  61 */     String issuer = clientRegistration.getProviderDetails().getIssuerUri();
/*  62 */     Assert.hasText(issuer, "Provider issuer cannot be null");
/*  63 */     this.issuer = issuer;
/*     */   }
/*     */ 
/*     */   
/*     */   public OAuth2TokenValidatorResult validate(Jwt jwt) {
/*  68 */     Collection<OAuth2Error> errors = new ArrayList<>();
/*     */     
/*  70 */     Objects.requireNonNull(jwt); LogoutTokenClaimAccessor logoutClaims = jwt::getClaims;
/*  71 */     Map<String, Object> events = logoutClaims.getEvents();
/*  72 */     if (events == null) {
/*  73 */       errors.add(invalidLogoutToken("events claim must not be null"));
/*     */     }
/*  75 */     else if (events.get("http://schemas.openid.net/event/backchannel-logout") == null) {
/*  76 */       errors.add(invalidLogoutToken("events claim map must contain \"http://schemas.openid.net/event/backchannel-logout\" key"));
/*     */     } 
/*     */     
/*  79 */     String issuer = logoutClaims.getIssuer().toExternalForm();
/*  80 */     if (issuer == null) {
/*  81 */       errors.add(invalidLogoutToken("iss claim must not be null"));
/*     */     }
/*  83 */     else if (!this.issuer.equals(issuer)) {
/*  84 */       errors.add(invalidLogoutToken("iss claim value must match `ClientRegistration#getProviderDetails#getIssuerUri`"));
/*     */     } 
/*     */ 
/*     */     
/*  88 */     List<String> audience = logoutClaims.getAudience();
/*  89 */     if (audience == null) {
/*  90 */       errors.add(invalidLogoutToken("aud claim must not be null"));
/*     */     }
/*  92 */     else if (!audience.contains(this.audience)) {
/*  93 */       errors.add(invalidLogoutToken("aud claim value must include `ClientRegistration#getClientId`"));
/*     */     } 
/*     */     
/*  96 */     Instant issuedAt = logoutClaims.getIssuedAt();
/*  97 */     if (issuedAt == null) {
/*  98 */       errors.add(invalidLogoutToken("iat claim must not be null"));
/*     */     }
/*     */     
/* 101 */     String jwtId = logoutClaims.getId();
/* 102 */     if (jwtId == null) {
/* 103 */       errors.add(invalidLogoutToken("jti claim must not be null"));
/*     */     }
/*     */     
/* 106 */     if (logoutClaims.getSubject() == null && logoutClaims.getSessionId() == null) {
/* 107 */       errors.add(invalidLogoutToken("sub and sid claims must not both be null"));
/*     */     }
/*     */     
/* 110 */     if (logoutClaims.getClaim("nonce") != null) {
/* 111 */       errors.add(invalidLogoutToken("nonce claim must not be present"));
/*     */     }
/*     */     
/* 114 */     return OAuth2TokenValidatorResult.failure(errors);
/*     */   }
/*     */   
/*     */   private static OAuth2Error invalidLogoutToken(String description) {
/* 118 */     return new OAuth2Error("invalid_token", description, "https://openid.net/specs/openid-connect-backchannel-1_0.html#Validation");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcBackChannelLogoutTokenValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */