/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.oidc.session.InMemoryOidcSessionRegistry;
/*     */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.AuthenticatedPrincipalOAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OAuth2ClientConfigurerUtils
/*     */ {
/*     */   static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> ClientRegistrationRepository getClientRegistrationRepository(B builder) {
/*  48 */     ClientRegistrationRepository clientRegistrationRepository = (ClientRegistrationRepository)builder.getSharedObject(ClientRegistrationRepository.class);
/*  49 */     if (clientRegistrationRepository == null) {
/*  50 */       clientRegistrationRepository = getClientRegistrationRepositoryBean(builder);
/*  51 */       builder.setSharedObject(ClientRegistrationRepository.class, clientRegistrationRepository);
/*     */     } 
/*  53 */     return clientRegistrationRepository;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> ClientRegistrationRepository getClientRegistrationRepositoryBean(B builder) {
/*  58 */     return (ClientRegistrationRepository)((ApplicationContext)builder.getSharedObject(ApplicationContext.class)).getBean(ClientRegistrationRepository.class);
/*     */   }
/*     */ 
/*     */   
/*     */   static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> OAuth2AuthorizedClientRepository getAuthorizedClientRepository(B builder) {
/*     */     AuthenticatedPrincipalOAuth2AuthorizedClientRepository authenticatedPrincipalOAuth2AuthorizedClientRepository;
/*  64 */     OAuth2AuthorizedClientRepository authorizedClientRepository = (OAuth2AuthorizedClientRepository)builder.getSharedObject(OAuth2AuthorizedClientRepository.class);
/*  65 */     if (authorizedClientRepository == null) {
/*  66 */       authorizedClientRepository = getAuthorizedClientRepositoryBean(builder);
/*  67 */       if (authorizedClientRepository == null)
/*     */       {
/*  69 */         authenticatedPrincipalOAuth2AuthorizedClientRepository = new AuthenticatedPrincipalOAuth2AuthorizedClientRepository(getAuthorizedClientService(builder));
/*     */       }
/*  71 */       builder.setSharedObject(OAuth2AuthorizedClientRepository.class, authenticatedPrincipalOAuth2AuthorizedClientRepository);
/*     */     } 
/*  73 */     return (OAuth2AuthorizedClientRepository)authenticatedPrincipalOAuth2AuthorizedClientRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> OAuth2AuthorizedClientRepository getAuthorizedClientRepositoryBean(B builder) {
/*  79 */     Map<String, OAuth2AuthorizedClientRepository> authorizedClientRepositoryMap = BeanFactoryUtils.beansOfTypeIncludingAncestors((ListableBeanFactory)builder.getSharedObject(ApplicationContext.class), OAuth2AuthorizedClientRepository.class);
/*     */     
/*  81 */     if (authorizedClientRepositoryMap.size() > 1) {
/*  82 */       throw new NoUniqueBeanDefinitionException(OAuth2AuthorizedClientRepository.class, authorizedClientRepositoryMap
/*  83 */           .size(), "Expected single matching bean of type '" + OAuth2AuthorizedClientRepository.class
/*  84 */           .getName() + "' but found " + authorizedClientRepositoryMap
/*  85 */           .size() + ": " + 
/*  86 */           StringUtils.collectionToCommaDelimitedString(authorizedClientRepositoryMap.keySet()));
/*     */     }
/*  88 */     return !authorizedClientRepositoryMap.isEmpty() ? authorizedClientRepositoryMap.values().iterator().next() : 
/*  89 */       null;
/*     */   }
/*     */   
/*     */   private static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> OAuth2AuthorizedClientService getAuthorizedClientService(B builder) {
/*     */     InMemoryOAuth2AuthorizedClientService inMemoryOAuth2AuthorizedClientService;
/*  94 */     OAuth2AuthorizedClientService authorizedClientService = getAuthorizedClientServiceBean(builder);
/*  95 */     if (authorizedClientService == null)
/*     */     {
/*  97 */       inMemoryOAuth2AuthorizedClientService = new InMemoryOAuth2AuthorizedClientService(getClientRegistrationRepository(builder));
/*     */     }
/*  99 */     return (OAuth2AuthorizedClientService)inMemoryOAuth2AuthorizedClientService;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> OAuth2AuthorizedClientService getAuthorizedClientServiceBean(B builder) {
/* 105 */     Map<String, OAuth2AuthorizedClientService> authorizedClientServiceMap = BeanFactoryUtils.beansOfTypeIncludingAncestors((ListableBeanFactory)builder.getSharedObject(ApplicationContext.class), OAuth2AuthorizedClientService.class);
/*     */     
/* 107 */     if (authorizedClientServiceMap.size() > 1) {
/* 108 */       throw new NoUniqueBeanDefinitionException(OAuth2AuthorizedClientService.class, authorizedClientServiceMap
/* 109 */           .size(), "Expected single matching bean of type '" + OAuth2AuthorizedClientService.class
/* 110 */           .getName() + "' but found " + authorizedClientServiceMap
/* 111 */           .size() + ": " + 
/* 112 */           StringUtils.collectionToCommaDelimitedString(authorizedClientServiceMap.keySet()));
/*     */     }
/* 114 */     return !authorizedClientServiceMap.isEmpty() ? authorizedClientServiceMap.values().iterator().next() : null;
/*     */   }
/*     */   static <B extends org.springframework.security.config.annotation.web.HttpSecurityBuilder<B>> OidcSessionRegistry getOidcSessionRegistry(B builder) {
/*     */     InMemoryOidcSessionRegistry inMemoryOidcSessionRegistry;
/* 118 */     OidcSessionRegistry sessionRegistry = (OidcSessionRegistry)builder.getSharedObject(OidcSessionRegistry.class);
/* 119 */     if (sessionRegistry != null) {
/* 120 */       return sessionRegistry;
/*     */     }
/* 122 */     ApplicationContext context = (ApplicationContext)builder.getSharedObject(ApplicationContext.class);
/* 123 */     if ((context.getBeanNamesForType(OidcSessionRegistry.class)).length == 1) {
/* 124 */       sessionRegistry = (OidcSessionRegistry)context.getBean(OidcSessionRegistry.class);
/*     */     } else {
/*     */       
/* 127 */       inMemoryOidcSessionRegistry = new InMemoryOidcSessionRegistry();
/*     */     } 
/* 129 */     builder.setSharedObject(OidcSessionRegistry.class, inMemoryOidcSessionRegistry);
/* 130 */     return (OidcSessionRegistry)inMemoryOidcSessionRegistry;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OAuth2ClientConfigurerUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */