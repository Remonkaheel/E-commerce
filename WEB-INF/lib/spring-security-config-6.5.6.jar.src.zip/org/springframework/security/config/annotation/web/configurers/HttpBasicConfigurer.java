/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.DelegatingAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.HttpStatusEntryPoint;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.HeaderContentNegotiationStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpBasicConfigurer<B extends HttpSecurityBuilder<B>>
/*     */   extends AbstractHttpConfigurer<HttpBasicConfigurer<B>, B>
/*     */ {
/*  86 */   private static final RequestHeaderRequestMatcher X_REQUESTED_WITH = new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest");
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_REALM = "Realm";
/*     */   
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   
/*     */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource;
/*     */   
/*  95 */   private BasicAuthenticationEntryPoint basicAuthEntryPoint = new BasicAuthenticationEntryPoint();
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityContextRepository securityContextRepository;
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBasicConfigurer() {
/* 104 */     realmName("Realm");
/* 105 */     LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> entryPoints = new LinkedHashMap<>();
/* 106 */     entryPoints.put(X_REQUESTED_WITH, new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
/* 107 */     DelegatingAuthenticationEntryPoint defaultEntryPoint = new DelegatingAuthenticationEntryPoint(entryPoints);
/* 108 */     defaultEntryPoint.setDefaultEntryPoint((AuthenticationEntryPoint)this.basicAuthEntryPoint);
/* 109 */     this.authenticationEntryPoint = (AuthenticationEntryPoint)defaultEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBasicConfigurer<B> realmName(String realmName) {
/* 120 */     this.basicAuthEntryPoint.setRealmName(realmName);
/* 121 */     this.basicAuthEntryPoint.afterPropertiesSet();
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBasicConfigurer<B> authenticationEntryPoint(AuthenticationEntryPoint authenticationEntryPoint) {
/* 133 */     this.authenticationEntryPoint = authenticationEntryPoint;
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBasicConfigurer<B> authenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 146 */     this.authenticationDetailsSource = authenticationDetailsSource;
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBasicConfigurer<B> securityContextRepository(SecurityContextRepository securityContextRepository) {
/* 159 */     this.securityContextRepository = securityContextRepository;
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(B http) {
/* 165 */     registerDefaults(http);
/*     */   }
/*     */   private void registerDefaults(B http) {
/*     */     HeaderContentNegotiationStrategy headerContentNegotiationStrategy;
/* 169 */     ContentNegotiationStrategy contentNegotiationStrategy = (ContentNegotiationStrategy)http.getSharedObject(ContentNegotiationStrategy.class);
/* 170 */     if (contentNegotiationStrategy == null) {
/* 171 */       headerContentNegotiationStrategy = new HeaderContentNegotiationStrategy();
/*     */     }
/* 173 */     MediaTypeRequestMatcher restMatcher = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.APPLICATION_ATOM_XML, MediaType.APPLICATION_FORM_URLENCODED, MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_XML });
/*     */ 
/*     */ 
/*     */     
/* 177 */     restMatcher.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 178 */     MediaTypeRequestMatcher allMatcher = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.ALL });
/* 179 */     allMatcher.setUseEquals(true);
/* 180 */     NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.TEXT_HTML }));
/*     */     
/* 182 */     AndRequestMatcher andRequestMatcher = new AndRequestMatcher(Arrays.asList(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)restMatcher }));
/*     */     
/* 184 */     OrRequestMatcher orRequestMatcher = new OrRequestMatcher(Arrays.asList(new RequestMatcher[] { (RequestMatcher)X_REQUESTED_WITH, (RequestMatcher)andRequestMatcher, (RequestMatcher)allMatcher }));
/* 185 */     registerDefaultEntryPoint(http, (RequestMatcher)orRequestMatcher);
/* 186 */     registerDefaultLogoutSuccessHandler(http, (RequestMatcher)orRequestMatcher);
/*     */   }
/*     */   
/*     */   private void registerDefaultEntryPoint(B http, RequestMatcher preferredMatcher) {
/* 190 */     ExceptionHandlingConfigurer<B> exceptionHandling = (ExceptionHandlingConfigurer<B>)http.getConfigurer(ExceptionHandlingConfigurer.class);
/* 191 */     if (exceptionHandling == null) {
/*     */       return;
/*     */     }
/* 194 */     exceptionHandling.defaultAuthenticationEntryPointFor((AuthenticationEntryPoint)postProcess(this.authenticationEntryPoint), preferredMatcher);
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerDefaultLogoutSuccessHandler(B http, RequestMatcher preferredMatcher) {
/* 199 */     LogoutConfigurer<B> logout = (LogoutConfigurer<B>)http.getConfigurer(LogoutConfigurer.class);
/* 200 */     if (logout == null) {
/*     */       return;
/*     */     }
/* 203 */     LogoutConfigurer<B> handler = logout.defaultLogoutSuccessHandlerFor((LogoutSuccessHandler)
/* 204 */         postProcess(new HttpStatusReturningLogoutSuccessHandler(HttpStatus.NO_CONTENT)), preferredMatcher);
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(B http) {
/* 209 */     AuthenticationManager authenticationManager = (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/* 210 */     BasicAuthenticationFilter basicAuthenticationFilter = new BasicAuthenticationFilter(authenticationManager, this.authenticationEntryPoint);
/*     */     
/* 212 */     if (this.authenticationDetailsSource != null) {
/* 213 */       basicAuthenticationFilter.setAuthenticationDetailsSource(this.authenticationDetailsSource);
/*     */     }
/* 215 */     if (this.securityContextRepository != null) {
/* 216 */       basicAuthenticationFilter.setSecurityContextRepository(this.securityContextRepository);
/*     */     }
/* 218 */     RememberMeServices rememberMeServices = (RememberMeServices)http.getSharedObject(RememberMeServices.class);
/* 219 */     if (rememberMeServices != null) {
/* 220 */       basicAuthenticationFilter.setRememberMeServices(rememberMeServices);
/*     */     }
/* 222 */     basicAuthenticationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 223 */     basicAuthenticationFilter = (BasicAuthenticationFilter)postProcess(basicAuthenticationFilter);
/* 224 */     http.addFilter((Filter)basicAuthenticationFilter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\HttpBasicConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */