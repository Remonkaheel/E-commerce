/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
/*    */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*    */ import org.springframework.security.web.csrf.CsrfTokenRepository;
/*    */ import org.springframework.security.web.csrf.CsrfTokenRequestHandler;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000T\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\013\n\000\n\002\020\021\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\007\n\002\030\002\n\002\b\005\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020#\032\0020$J\037\020%\032\024\022\n\022\b\022\004\022\0020(0'\022\004\022\0020$0&H\000¢\006\002\b)J\037\020\021\032\0020$2\022\020*\032\n\022\006\b\001\022\0020\0260\022\"\0020\026¢\006\002\020+J\037\020\021\032\0020$2\022\020,\032\n\022\006\b\001\022\0020\0230\022\"\0020\023¢\006\002\020-R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\016\020\017\032\0020\020X\016¢\006\002\n\000R\032\020\021\032\f\022\006\b\001\022\0020\023\030\0010\022X\016¢\006\004\n\002\020\024R\032\020\025\032\f\022\006\b\001\022\0020\026\030\0010\022X\016¢\006\004\n\002\020\027R\034\020\030\032\004\030\0010\023X\016¢\006\016\n\000\032\004\b\031\020\032\"\004\b\033\020\034R\034\020\035\032\004\030\0010\036X\016¢\006\016\n\000\032\004\b\037\020 \"\004\b!\020\"¨\006."}, d2 = {"Lorg/springframework/security/config/annotation/web/CsrfDsl;", "", "()V", "csrfTokenRepository", "Lorg/springframework/security/web/csrf/CsrfTokenRepository;", "getCsrfTokenRepository", "()Lorg/springframework/security/web/csrf/CsrfTokenRepository;", "setCsrfTokenRepository", "(Lorg/springframework/security/web/csrf/CsrfTokenRepository;)V", "csrfTokenRequestHandler", "Lorg/springframework/security/web/csrf/CsrfTokenRequestHandler;", "getCsrfTokenRequestHandler", "()Lorg/springframework/security/web/csrf/CsrfTokenRequestHandler;", "setCsrfTokenRequestHandler", "(Lorg/springframework/security/web/csrf/CsrfTokenRequestHandler;)V", "disabled", "", "ignoringRequestMatchers", "", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "[Lorg/springframework/security/web/util/matcher/RequestMatcher;", "ignoringRequestMatchersPatterns", "", "[Ljava/lang/String;", "requireCsrfProtectionMatcher", "getRequireCsrfProtectionMatcher", "()Lorg/springframework/security/web/util/matcher/RequestMatcher;", "setRequireCsrfProtectionMatcher", "(Lorg/springframework/security/web/util/matcher/RequestMatcher;)V", "sessionAuthenticationStrategy", "Lorg/springframework/security/web/authentication/session/SessionAuthenticationStrategy;", "getSessionAuthenticationStrategy", "()Lorg/springframework/security/web/authentication/session/SessionAuthenticationStrategy;", "setSessionAuthenticationStrategy", "(Lorg/springframework/security/web/authentication/session/SessionAuthenticationStrategy;)V", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/CsrfConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "patterns", "([Ljava/lang/String;)V", "requestMatchers", "([Lorg/springframework/security/web/util/matcher/RequestMatcher;)V", "spring-security-config"})
/*    */ public final class CsrfDsl
/*    */ {
/*    */   @Nullable
/*    */   private CsrfTokenRepository csrfTokenRepository;
/*    */   @Nullable
/*    */   private RequestMatcher requireCsrfProtectionMatcher;
/*    */   @Nullable
/*    */   private SessionAuthenticationStrategy sessionAuthenticationStrategy;
/*    */   @Nullable
/*    */   private CsrfTokenRequestHandler csrfTokenRequestHandler;
/*    */   @Nullable
/*    */   private RequestMatcher[] ignoringRequestMatchers;
/*    */   @Nullable
/*    */   private String[] ignoringRequestMatchersPatterns;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final CsrfTokenRepository getCsrfTokenRepository() {
/* 42 */     return this.csrfTokenRepository; } public final void setCsrfTokenRepository(@Nullable CsrfTokenRepository <set-?>) { this.csrfTokenRepository = <set-?>; } @Nullable
/* 43 */   public final RequestMatcher getRequireCsrfProtectionMatcher() { return this.requireCsrfProtectionMatcher; } public final void setRequireCsrfProtectionMatcher(@Nullable RequestMatcher <set-?>) { this.requireCsrfProtectionMatcher = <set-?>; } @Nullable
/* 44 */   public final SessionAuthenticationStrategy getSessionAuthenticationStrategy() { return this.sessionAuthenticationStrategy; } public final void setSessionAuthenticationStrategy(@Nullable SessionAuthenticationStrategy <set-?>) { this.sessionAuthenticationStrategy = <set-?>; } @Nullable
/* 45 */   public final CsrfTokenRequestHandler getCsrfTokenRequestHandler() { return this.csrfTokenRequestHandler; } public final void setCsrfTokenRequestHandler(@Nullable CsrfTokenRequestHandler <set-?>) { this.csrfTokenRequestHandler = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void ignoringRequestMatchers(@NotNull RequestMatcher... requestMatchers) {
/* 59 */     Intrinsics.checkNotNullParameter(requestMatchers, "requestMatchers"); this.ignoringRequestMatchers = requestMatchers;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void ignoringRequestMatchers(@NotNull String... patterns) {
/* 69 */     Intrinsics.checkNotNullParameter(patterns, "patterns"); this.ignoringRequestMatchersPatterns = patterns;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 76 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 80 */   public final Function1<CsrfConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new CsrfDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "csrf", "Lorg/springframework/security/config/annotation/web/configurers/CsrfConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nCsrfDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CsrfDsl.kt\norg/springframework/security/config/annotation/web/CsrfDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,93:1\n1#2:94\n*E\n"})
/* 81 */   static final class CsrfDsl$get$1 extends Lambda implements Function1<CsrfConfigurer<HttpSecurity>, Unit> { public final void invoke(CsrfConfigurer csrf) { Intrinsics.checkNotNullParameter(csrf, "csrf"); if (CsrfDsl.this.getCsrfTokenRepository() != null) { CsrfTokenRepository csrfTokenRepository1 = CsrfDsl.this.getCsrfTokenRepository(); CsrfDsl csrfDsl = CsrfDsl.this; CsrfTokenRepository it = csrfTokenRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 94 */         int $i$a$-also-CsrfDsl$get$1$1 = 0; csrf.csrfTokenRepository(csrfDsl.getCsrfTokenRepository()); } else { CsrfDsl.this.getCsrfTokenRepository(); }  if (CsrfDsl.this.getRequireCsrfProtectionMatcher() != null) { RequestMatcher requestMatcher1 = CsrfDsl.this.getRequireCsrfProtectionMatcher(); CsrfDsl csrfDsl = CsrfDsl.this; RequestMatcher it = requestMatcher1; int $i$a$-also-CsrfDsl$get$1$2 = 0; csrf.requireCsrfProtectionMatcher(csrfDsl.getRequireCsrfProtectionMatcher()); } else { CsrfDsl.this.getRequireCsrfProtectionMatcher(); }  if (CsrfDsl.this.getSessionAuthenticationStrategy() != null) { SessionAuthenticationStrategy sessionAuthenticationStrategy1 = CsrfDsl.this.getSessionAuthenticationStrategy(); CsrfDsl csrfDsl = CsrfDsl.this; SessionAuthenticationStrategy it = sessionAuthenticationStrategy1; int $i$a$-also-CsrfDsl$get$1$3 = 0; csrf.sessionAuthenticationStrategy(csrfDsl.getSessionAuthenticationStrategy()); } else { CsrfDsl.this.getSessionAuthenticationStrategy(); }  if (CsrfDsl.this.getCsrfTokenRequestHandler() != null) { CsrfTokenRequestHandler csrfTokenRequestHandler1 = CsrfDsl.this.getCsrfTokenRequestHandler(); CsrfDsl csrfDsl = CsrfDsl.this; CsrfTokenRequestHandler it = csrfTokenRequestHandler1; int $i$a$-also-CsrfDsl$get$1$4 = 0; csrf.csrfTokenRequestHandler(csrfDsl.getCsrfTokenRequestHandler()); } else { CsrfDsl.this.getCsrfTokenRequestHandler(); }  if (CsrfDsl.this.ignoringRequestMatchers != null) { RequestMatcher[] arrayOfRequestMatcher1 = CsrfDsl.this.ignoringRequestMatchers; CsrfDsl csrfDsl = CsrfDsl.this; RequestMatcher[] it = arrayOfRequestMatcher1; int $i$a$-also-CsrfDsl$get$1$5 = 0; Intrinsics.checkNotNull(csrfDsl.ignoringRequestMatchers); RequestMatcher[] arrayOfRequestMatcher2 = csrfDsl.ignoringRequestMatchers; csrf.ignoringRequestMatchers(Arrays.<RequestMatcher>copyOf(arrayOfRequestMatcher2, arrayOfRequestMatcher2.length)); } else { CsrfDsl.this.ignoringRequestMatchers; }  if (CsrfDsl.this.ignoringRequestMatchersPatterns != null) { String[] arrayOfString1 = CsrfDsl.this.ignoringRequestMatchersPatterns; CsrfDsl csrfDsl = CsrfDsl.this; String[] it = arrayOfString1; int $i$a$-also-CsrfDsl$get$1$6 = 0;
/*    */         Intrinsics.checkNotNull(csrfDsl.ignoringRequestMatchersPatterns);
/*    */         String[] arrayOfString2 = csrfDsl.ignoringRequestMatchersPatterns;
/*    */         csrf.ignoringRequestMatchers(Arrays.<String>copyOf(arrayOfString2, arrayOfString2.length)); }
/*    */       else
/*    */       { CsrfDsl.this.ignoringRequestMatchersPatterns; }
/*    */       
/*    */       if (CsrfDsl.this.disabled)
/*    */         csrf.disable();  }
/*    */ 
/*    */     
/*    */     CsrfDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\CsrfDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */