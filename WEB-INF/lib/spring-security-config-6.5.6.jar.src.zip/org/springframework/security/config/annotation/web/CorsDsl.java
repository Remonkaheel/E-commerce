/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.CorsConfigurer;
/*    */ import org.springframework.web.cors.CorsConfigurationSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\013\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\013\032\0020\fJ\037\020\r\032\024\022\n\022\b\022\004\022\0020\0200\017\022\004\022\0020\f0\016H\000¢\006\002\b\021R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\016\020\t\032\0020\nX\016¢\006\002\n\000¨\006\022"}, d2 = {"Lorg/springframework/security/config/annotation/web/CorsDsl;", "", "()V", "configurationSource", "Lorg/springframework/web/cors/CorsConfigurationSource;", "getConfigurationSource", "()Lorg/springframework/web/cors/CorsConfigurationSource;", "setConfigurationSource", "(Lorg/springframework/web/cors/CorsConfigurationSource;)V", "disabled", "", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/CorsConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class CorsDsl
/*    */ {
/*    */   @Nullable
/*    */   private CorsConfigurationSource configurationSource;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final CorsConfigurationSource getConfigurationSource() {
/* 32 */     return this.configurationSource; } public final void setConfigurationSource(@Nullable CorsConfigurationSource <set-?>) { this.configurationSource = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 40 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 44 */   public final Function1<CorsConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new CorsDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "cors", "Lorg/springframework/security/config/annotation/web/configurers/CorsConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nCorsDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CorsDsl.kt\norg/springframework/security/config/annotation/web/CorsDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,52:1\n1#2:53\n*E\n"})
/* 45 */   static final class CorsDsl$get$1 extends Lambda implements Function1<CorsConfigurer<HttpSecurity>, Unit> { public final void invoke(CorsConfigurer cors) { Intrinsics.checkNotNullParameter(cors, "cors"); if (CorsDsl.this.getConfigurationSource() != null) { CorsConfigurationSource corsConfigurationSource1 = CorsDsl.this.getConfigurationSource(); CorsDsl corsDsl = CorsDsl.this; CorsConfigurationSource it = corsConfigurationSource1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 53 */         int $i$a$-also-CorsDsl$get$1$1 = 0;
/*    */         cors.configurationSource(corsDsl.getConfigurationSource()); }
/*    */       else
/*    */       { CorsDsl.this.getConfigurationSource(); }
/*    */       
/*    */       if (CorsDsl.this.disabled)
/*    */         cors.disable();  }
/*    */ 
/*    */     
/*    */     CorsDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\CorsDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */