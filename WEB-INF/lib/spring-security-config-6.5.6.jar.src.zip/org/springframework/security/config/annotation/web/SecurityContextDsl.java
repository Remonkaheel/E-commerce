/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.SecurityContextConfigurer;
/*    */ import org.springframework.security.web.context.SecurityContextRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\020\032\024\022\n\022\b\022\004\022\0020\0230\022\022\004\022\0020\0240\021H\000¢\006\002\b\025R\036\020\003\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017¨\006\026"}, d2 = {"Lorg/springframework/security/config/annotation/web/SecurityContextDsl;", "", "()V", "requireExplicitSave", "", "getRequireExplicitSave", "()Ljava/lang/Boolean;", "setRequireExplicitSave", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "securityContextRepository", "Lorg/springframework/security/web/context/SecurityContextRepository;", "getSecurityContextRepository", "()Lorg/springframework/security/web/context/SecurityContextRepository;", "setSecurityContextRepository", "(Lorg/springframework/security/web/context/SecurityContextRepository;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/SecurityContextConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class SecurityContextDsl
/*    */ {
/*    */   @Nullable
/*    */   private SecurityContextRepository securityContextRepository;
/*    */   @Nullable
/*    */   private Boolean requireExplicitSave;
/*    */   
/*    */   @Nullable
/*    */   public final SecurityContextRepository getSecurityContextRepository() {
/* 33 */     return this.securityContextRepository; } public final void setSecurityContextRepository(@Nullable SecurityContextRepository <set-?>) { this.securityContextRepository = <set-?>; } @Nullable
/* 34 */   public final Boolean getRequireExplicitSave() { return this.requireExplicitSave; } public final void setRequireExplicitSave(@Nullable Boolean <set-?>) { this.requireExplicitSave = <set-?>; }
/*    */   
/*    */   @NotNull
/* 37 */   public final Function1<SecurityContextConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new SecurityContextDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "securityContext", "Lorg/springframework/security/config/annotation/web/configurers/SecurityContextConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nSecurityContextDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SecurityContextDsl.kt\norg/springframework/security/config/annotation/web/SecurityContextDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,43:1\n1#2:44\n*E\n"})
/* 38 */   static final class SecurityContextDsl$get$1 extends Lambda implements Function1<SecurityContextConfigurer<HttpSecurity>, Unit> { public final void invoke(SecurityContextConfigurer securityContext) { Intrinsics.checkNotNullParameter(securityContext, "securityContext"); if (SecurityContextDsl.this.getSecurityContextRepository() != null) { SecurityContextRepository securityContextRepository1 = SecurityContextDsl.this.getSecurityContextRepository(), it = securityContextRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 44 */         int $i$a$-also-SecurityContextDsl$get$1$1 = 0; securityContext.securityContextRepository(it); } else { SecurityContextDsl.this.getSecurityContextRepository(); }  if (SecurityContextDsl.this.getRequireExplicitSave() != null) { Boolean bool = SecurityContextDsl.this.getRequireExplicitSave(); boolean it = bool.booleanValue(); int $i$a$-also-SecurityContextDsl$get$1$2 = 0;
/*    */         securityContext.requireExplicitSave(it); }
/*    */       else
/*    */       { SecurityContextDsl.this.getRequireExplicitSave(); }
/*    */        }
/*    */ 
/*    */     
/*    */     SecurityContextDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\SecurityContextDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */