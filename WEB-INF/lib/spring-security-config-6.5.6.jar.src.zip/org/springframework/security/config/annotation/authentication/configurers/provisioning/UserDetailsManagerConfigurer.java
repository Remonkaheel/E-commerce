/*     */ package org.springframework.security.config.annotation.authentication.configurers.provisioning;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.userdetails.UserDetailsServiceConfigurer;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.provisioning.UserDetailsManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserDetailsManagerConfigurer<B extends ProviderManagerBuilder<B>, C extends UserDetailsManagerConfigurer<B, C>>
/*     */   extends UserDetailsServiceConfigurer<B, C, UserDetailsManager>
/*     */ {
/*  44 */   private final List<UserDetailsBuilder> userBuilders = new ArrayList<>();
/*     */   
/*  46 */   private final List<UserDetails> users = new ArrayList<>();
/*     */   
/*     */   protected UserDetailsManagerConfigurer(UserDetailsManager userDetailsManager) {
/*  49 */     super((UserDetailsService)userDetailsManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initUserDetailsService() throws Exception {
/*  58 */     for (UserDetailsBuilder userBuilder : this.userBuilders) {
/*  59 */       ((UserDetailsManager)getUserDetailsService()).createUser(userBuilder.build());
/*     */     }
/*  61 */     for (UserDetails userDetails : this.users) {
/*  62 */       ((UserDetailsManager)getUserDetailsService()).createUser(userDetails);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final C withUser(UserDetails userDetails) {
/*  74 */     this.users.add(userDetails);
/*  75 */     return (C)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final C withUser(User.UserBuilder userBuilder) {
/*  86 */     this.users.add(userBuilder.build());
/*  87 */     return (C)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UserDetailsBuilder withUser(String username) {
/*  98 */     UserDetailsBuilder userBuilder = new UserDetailsBuilder((C)this);
/*  99 */     userBuilder.username(username);
/* 100 */     this.userBuilders.add(userBuilder);
/* 101 */     return userBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class UserDetailsBuilder
/*     */   {
/*     */     private User.UserBuilder user;
/*     */ 
/*     */ 
/*     */     
/*     */     private final C builder;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserDetailsBuilder(C builder) {
/* 119 */       this.builder = builder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public C and() {
/* 128 */       return this.builder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private UserDetailsBuilder username(String username) {
/* 138 */       this.user = User.withUsername(username);
/* 139 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder password(String password) {
/* 149 */       this.user.password(password);
/* 150 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder roles(String... roles) {
/* 178 */       this.user.roles(roles);
/* 179 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder authorities(GrantedAuthority... authorities) {
/* 191 */       this.user.authorities(authorities);
/* 192 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder authorities(List<? extends GrantedAuthority> authorities) {
/* 204 */       this.user.authorities(authorities);
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder authorities(String... authorities) {
/* 217 */       this.user.authorities(authorities);
/* 218 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder accountExpired(boolean accountExpired) {
/* 228 */       this.user.accountExpired(accountExpired);
/* 229 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder accountLocked(boolean accountLocked) {
/* 239 */       this.user.accountLocked(accountLocked);
/* 240 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder credentialsExpired(boolean credentialsExpired) {
/* 250 */       this.user.credentialsExpired(credentialsExpired);
/* 251 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserDetailsBuilder disabled(boolean disabled) {
/* 261 */       this.user.disabled(disabled);
/* 262 */       return this;
/*     */     }
/*     */     
/*     */     UserDetails build() {
/* 266 */       return this.user.build();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurers\provisioning\UserDetailsManagerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */