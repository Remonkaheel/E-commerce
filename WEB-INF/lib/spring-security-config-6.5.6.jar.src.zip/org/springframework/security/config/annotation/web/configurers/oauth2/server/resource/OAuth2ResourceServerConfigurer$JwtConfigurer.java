/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.server.resource;
/*     */ 
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.oauth2.jwt.Jwt;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JwtConfigurer
/*     */ {
/*     */   private final ApplicationContext context;
/*     */   private AuthenticationManager authenticationManager;
/*     */   private JwtDecoder decoder;
/*     */   private Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter;
/*     */   
/*     */   JwtConfigurer(ApplicationContext context) {
/* 403 */     this.context = context;
/*     */   }
/*     */   
/*     */   public JwtConfigurer authenticationManager(AuthenticationManager authenticationManager) {
/* 407 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 408 */     this.authenticationManager = authenticationManager;
/* 409 */     return this;
/*     */   }
/*     */   
/*     */   public JwtConfigurer decoder(JwtDecoder decoder) {
/* 413 */     this.decoder = decoder;
/* 414 */     return this;
/*     */   }
/*     */   
/*     */   public JwtConfigurer jwkSetUri(String uri) {
/* 418 */     this.decoder = (JwtDecoder)NimbusJwtDecoder.withJwkSetUri(uri).build();
/* 419 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JwtConfigurer jwtAuthenticationConverter(Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter) {
/* 424 */     this.jwtAuthenticationConverter = jwtAuthenticationConverter;
/* 425 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public OAuth2ResourceServerConfigurer<H> and() {
/* 436 */     return OAuth2ResourceServerConfigurer.this;
/*     */   }
/*     */   
/*     */   Converter<Jwt, ? extends AbstractAuthenticationToken> getJwtAuthenticationConverter() {
/* 440 */     if (this.jwtAuthenticationConverter == null) {
/* 441 */       if ((this.context.getBeanNamesForType(JwtAuthenticationConverter.class)).length > 0) {
/* 442 */         this.jwtAuthenticationConverter = (Converter<Jwt, ? extends AbstractAuthenticationToken>)this.context.getBean(JwtAuthenticationConverter.class);
/*     */       } else {
/*     */         
/* 445 */         this.jwtAuthenticationConverter = (Converter<Jwt, ? extends AbstractAuthenticationToken>)new JwtAuthenticationConverter();
/*     */       } 
/*     */     }
/* 448 */     return this.jwtAuthenticationConverter;
/*     */   }
/*     */   
/*     */   JwtDecoder getJwtDecoder() {
/* 452 */     if (this.decoder == null) {
/* 453 */       return (JwtDecoder)this.context.getBean(JwtDecoder.class);
/*     */     }
/* 455 */     return this.decoder;
/*     */   }
/*     */   
/*     */   AuthenticationProvider getAuthenticationProvider() {
/* 459 */     if (this.authenticationManager != null) {
/* 460 */       return null;
/*     */     }
/* 462 */     JwtDecoder decoder = getJwtDecoder();
/* 463 */     Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter = getJwtAuthenticationConverter();
/* 464 */     JwtAuthenticationProvider provider = new JwtAuthenticationProvider(decoder);
/* 465 */     provider.setJwtAuthenticationConverter(jwtAuthenticationConverter);
/* 466 */     return (AuthenticationProvider)OAuth2ResourceServerConfigurer.access$000(OAuth2ResourceServerConfigurer.this, provider);
/*     */   }
/*     */   
/*     */   AuthenticationManager getAuthenticationManager(H http) {
/* 470 */     if (this.authenticationManager != null) {
/* 471 */       return this.authenticationManager;
/*     */     }
/* 473 */     return (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\server\resource\OAuth2ResourceServerConfigurer$JwtConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */