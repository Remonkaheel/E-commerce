/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.AnonymousConfigurer;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000L\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020 \n\002\030\002\n\002\b\005\n\002\020\013\n\000\n\002\020\016\n\002\b\n\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020#\032\0020$J\037\020%\032\024\022\n\022\b\022\004\022\0020(0'\022\004\022\0020$0&H\000¢\006\002\b)R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\"\020\017\032\n\022\004\022\0020\021\030\0010\020X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R\016\020\026\032\0020\027X\016¢\006\002\n\000R\034\020\030\032\004\030\0010\031X\016¢\006\016\n\000\032\004\b\032\020\033\"\004\b\034\020\035R\034\020\036\032\004\030\0010\001X\016¢\006\016\n\000\032\004\b\037\020 \"\004\b!\020\"¨\006*"}, d2 = {"Lorg/springframework/security/config/annotation/web/AnonymousDsl;", "", "()V", "authenticationFilter", "Lorg/springframework/security/web/authentication/AnonymousAuthenticationFilter;", "getAuthenticationFilter", "()Lorg/springframework/security/web/authentication/AnonymousAuthenticationFilter;", "setAuthenticationFilter", "(Lorg/springframework/security/web/authentication/AnonymousAuthenticationFilter;)V", "authenticationProvider", "Lorg/springframework/security/authentication/AuthenticationProvider;", "getAuthenticationProvider", "()Lorg/springframework/security/authentication/AuthenticationProvider;", "setAuthenticationProvider", "(Lorg/springframework/security/authentication/AuthenticationProvider;)V", "authorities", "", "Lorg/springframework/security/core/GrantedAuthority;", "getAuthorities", "()Ljava/util/List;", "setAuthorities", "(Ljava/util/List;)V", "disabled", "", "key", "", "getKey", "()Ljava/lang/String;", "setKey", "(Ljava/lang/String;)V", "principal", "getPrincipal", "()Ljava/lang/Object;", "setPrincipal", "(Ljava/lang/Object;)V", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/AnonymousConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class AnonymousDsl
/*    */ {
/*    */   @Nullable
/*    */   private String key;
/*    */   @Nullable
/*    */   private Object principal;
/*    */   @Nullable
/*    */   private List<? extends GrantedAuthority> authorities;
/*    */   @Nullable
/*    */   private AuthenticationProvider authenticationProvider;
/*    */   @Nullable
/*    */   private AnonymousAuthenticationFilter authenticationFilter;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final String getKey() {
/* 42 */     return this.key; } public final void setKey(@Nullable String <set-?>) { this.key = <set-?>; } @Nullable
/* 43 */   public final Object getPrincipal() { return this.principal; } public final void setPrincipal(@Nullable Object <set-?>) { this.principal = <set-?>; } @Nullable
/* 44 */   public final List<GrantedAuthority> getAuthorities() { return (List)this.authorities; } public final void setAuthorities(@Nullable List<? extends GrantedAuthority> <set-?>) { this.authorities = <set-?>; } @Nullable
/* 45 */   public final AuthenticationProvider getAuthenticationProvider() { return this.authenticationProvider; } public final void setAuthenticationProvider(@Nullable AuthenticationProvider <set-?>) { this.authenticationProvider = <set-?>; } @Nullable
/* 46 */   public final AnonymousAuthenticationFilter getAuthenticationFilter() { return this.authenticationFilter; } public final void setAuthenticationFilter(@Nullable AnonymousAuthenticationFilter <set-?>) { this.authenticationFilter = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 54 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 58 */   public final Function1<AnonymousConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new AnonymousDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "anonymous", "Lorg/springframework/security/config/annotation/web/configurers/AnonymousConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nAnonymousDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnonymousDsl.kt\norg/springframework/security/config/annotation/web/AnonymousDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n1#2:71\n*E\n"})
/* 59 */   static final class AnonymousDsl$get$1 extends Lambda implements Function1<AnonymousConfigurer<HttpSecurity>, Unit> { public final void invoke(AnonymousConfigurer anonymous) { Intrinsics.checkNotNullParameter(anonymous, "anonymous"); if (AnonymousDsl.this.getKey() != null) { String str1 = AnonymousDsl.this.getKey(); AnonymousDsl anonymousDsl = AnonymousDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 71 */         int $i$a$-also-AnonymousDsl$get$1$1 = 0; anonymous.key(anonymousDsl.getKey()); } else { AnonymousDsl.this.getKey(); }  if (AnonymousDsl.this.getPrincipal() != null) { Object object1 = AnonymousDsl.this.getPrincipal(); AnonymousDsl anonymousDsl = AnonymousDsl.this; Object it = object1; int $i$a$-also-AnonymousDsl$get$1$2 = 0; anonymous.principal(anonymousDsl.getPrincipal()); } else { AnonymousDsl.this.getPrincipal(); }  if (AnonymousDsl.this.getAuthorities() != null) { List<GrantedAuthority> list1 = AnonymousDsl.this.getAuthorities(); AnonymousDsl anonymousDsl = AnonymousDsl.this; List<GrantedAuthority> it = list1; int $i$a$-also-AnonymousDsl$get$1$3 = 0; anonymous.authorities(anonymousDsl.getAuthorities()); } else { AnonymousDsl.this.getAuthorities(); }  if (AnonymousDsl.this.getAuthenticationProvider() != null) { AuthenticationProvider authenticationProvider1 = AnonymousDsl.this.getAuthenticationProvider(); AnonymousDsl anonymousDsl = AnonymousDsl.this; AuthenticationProvider it = authenticationProvider1; int $i$a$-also-AnonymousDsl$get$1$4 = 0; anonymous.authenticationProvider(anonymousDsl.getAuthenticationProvider()); } else { AnonymousDsl.this.getAuthenticationProvider(); }  if (AnonymousDsl.this.getAuthenticationFilter() != null) { AnonymousAuthenticationFilter anonymousAuthenticationFilter1 = AnonymousDsl.this.getAuthenticationFilter(); AnonymousDsl anonymousDsl = AnonymousDsl.this; AnonymousAuthenticationFilter it = anonymousAuthenticationFilter1; int $i$a$-also-AnonymousDsl$get$1$5 = 0;
/*    */         anonymous.authenticationFilter(anonymousDsl.getAuthenticationFilter()); }
/*    */       else
/*    */       { AnonymousDsl.this.getAuthenticationFilter(); }
/*    */       
/*    */       if (AnonymousDsl.this.disabled)
/*    */         anonymous.disable();  }
/*    */ 
/*    */     
/*    */     AnonymousDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AnonymousDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */