/*     */ package org.springframework.security.config.annotation.web.configurers.saml2;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.opensaml.core.Version;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractAuthenticationFilterConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
/*     */ import org.springframework.security.saml2.provider.service.authentication.AbstractSaml2AuthenticationRequest;
/*     */ import org.springframework.security.saml2.provider.service.authentication.OpenSaml4AuthenticationProvider;
/*     */ import org.springframework.security.saml2.provider.service.authentication.OpenSaml5AuthenticationProvider;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.HttpSessionSaml2AuthenticationRequestRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.OpenSaml4AuthenticationTokenConverter;
/*     */ import org.springframework.security.saml2.provider.service.web.OpenSaml5AuthenticationTokenConverter;
/*     */ import org.springframework.security.saml2.provider.service.web.OpenSamlAuthenticationTokenConverter;
/*     */ import org.springframework.security.saml2.provider.service.web.Saml2AuthenticationRequestRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.Saml2AuthenticationTokenConverter;
/*     */ import org.springframework.security.saml2.provider.service.web.Saml2WebSsoAuthenticationRequestFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.OpenSaml4AuthenticationRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.OpenSaml5AuthenticationRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.Saml2AuthenticationRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.Saml2WebSsoAuthenticationFilter;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.PortResolver;
/*     */ import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.DelegatingAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.ParameterRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatchers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Saml2LoginConfigurer<B extends HttpSecurityBuilder<B>>
/*     */   extends AbstractAuthenticationFilterConfigurer<B, Saml2LoginConfigurer<B>, Saml2WebSsoAuthenticationFilter>
/*     */ {
/* 123 */   private static final boolean USE_OPENSAML_5 = Version.getVersion().startsWith("5");
/*     */   
/*     */   private String loginPage;
/*     */   
/* 127 */   private String authenticationRequestUri = "/saml2/authenticate";
/*     */   
/* 129 */   private String[] authenticationRequestParams = new String[] { "registrationId={registrationId}" };
/*     */ 
/*     */   
/*     */   private RequestMatcher authenticationRequestMatcher;
/*     */ 
/*     */   
/*     */   private Saml2AuthenticationRequestResolver authenticationRequestResolver;
/*     */ 
/*     */   
/*     */   private RequestMatcher loginProcessingUrl;
/*     */ 
/*     */   
/*     */   private RelyingPartyRegistrationRepository relyingPartyRegistrationRepository;
/*     */ 
/*     */   
/*     */   private AuthenticationConverter authenticationConverter;
/*     */ 
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */ 
/*     */   
/*     */   private Saml2WebSsoAuthenticationFilter saml2WebSsoAuthenticationFilter;
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> authenticationConverter(AuthenticationConverter authenticationConverter) {
/* 154 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 155 */     this.authenticationConverter = authenticationConverter;
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> authenticationManager(AuthenticationManager authenticationManager) {
/* 170 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 171 */     this.authenticationManager = authenticationManager;
/* 172 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> relyingPartyRegistrationRepository(RelyingPartyRegistrationRepository repo) {
/* 183 */     this.relyingPartyRegistrationRepository = repo;
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> loginPage(String loginPage) {
/* 189 */     Assert.hasText(loginPage, "loginPage cannot be empty");
/* 190 */     this.loginPage = loginPage;
/* 191 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> authenticationRequestResolver(Saml2AuthenticationRequestResolver authenticationRequestResolver) {
/* 203 */     Assert.notNull(authenticationRequestResolver, "authenticationRequestResolver cannot be null");
/* 204 */     this.authenticationRequestResolver = authenticationRequestResolver;
/* 205 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Saml2LoginConfigurer<B> authenticationRequestUri(String authenticationRequestUri) {
/* 218 */     return authenticationRequestUriQuery(authenticationRequestUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> authenticationRequestUriQuery(String authenticationRequestUriQuery) {
/* 232 */     Assert.state(authenticationRequestUriQuery.contains("{registrationId}"), "authenticationRequestUri must contain {registrationId} path variable or query value");
/*     */     
/* 234 */     String[] parts = authenticationRequestUriQuery.split("[?&]");
/* 235 */     this.authenticationRequestUri = parts[0];
/* 236 */     this.authenticationRequestParams = new String[parts.length - 1];
/* 237 */     System.arraycopy(parts, 1, this.authenticationRequestParams, 0, parts.length - 1);
/* 238 */     this
/* 239 */       .authenticationRequestMatcher = new PathQueryRequestMatcher(RequestMatcherFactory.matcher(this.authenticationRequestUri), this.authenticationRequestParams);
/* 240 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LoginConfigurer<B> loginProcessingUrl(String loginProcessingUrl) {
/* 255 */     Assert.hasText(loginProcessingUrl, "loginProcessingUrl cannot be empty");
/* 256 */     this.loginProcessingUrl = RequestMatcherFactory.matcher(loginProcessingUrl);
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected RequestMatcher createLoginProcessingUrlMatcher(String loginProcessingUrl) {
/* 262 */     return RequestMatcherFactory.matcher(loginProcessingUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(B http) throws Exception {
/* 280 */     registerDefaultCsrfOverride(http);
/* 281 */     relyingPartyRegistrationRepository(http);
/* 282 */     this.saml2WebSsoAuthenticationFilter = new Saml2WebSsoAuthenticationFilter(getAuthenticationConverter(http));
/* 283 */     this.saml2WebSsoAuthenticationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 284 */     this.saml2WebSsoAuthenticationFilter.setRequiresAuthenticationRequestMatcher(getLoginProcessingEndpoint());
/* 285 */     setAuthenticationRequestRepository(http, this.saml2WebSsoAuthenticationFilter);
/* 286 */     setAuthenticationFilter((AbstractAuthenticationProcessingFilter)this.saml2WebSsoAuthenticationFilter);
/* 287 */     if (StringUtils.hasText(this.loginPage)) {
/*     */       
/* 289 */       super.loginPage(this.loginPage);
/* 290 */       super.init((HttpSecurityBuilder)http);
/*     */     } else {
/*     */       
/* 293 */       Map<String, String> providerUrlMap = getIdentityProviderUrlMap(this.authenticationRequestUri, this.authenticationRequestParams, this.relyingPartyRegistrationRepository);
/*     */       
/* 295 */       boolean singleProvider = (providerUrlMap.size() == 1);
/* 296 */       if (singleProvider) {
/*     */ 
/*     */         
/* 299 */         updateAuthenticationDefaults();
/* 300 */         updateAccessDefaults((HttpSecurityBuilder)http);
/* 301 */         String loginUrl = (String)((Map.Entry)providerUrlMap.entrySet().iterator().next()).getKey();
/* 302 */         registerAuthenticationEntryPoint((HttpSecurityBuilder)http, getLoginEntryPoint(http, loginUrl));
/*     */       } else {
/*     */         
/* 305 */         super.init((HttpSecurityBuilder)http);
/*     */       } 
/*     */     } 
/* 308 */     initDefaultLoginFilter(http);
/* 309 */     if (this.authenticationManager == null) {
/* 310 */       registerDefaultAuthenticationProvider(http);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(B http) throws Exception {
/* 323 */     Saml2WebSsoAuthenticationRequestFilter filter = getAuthenticationRequestFilter(http);
/* 324 */     filter.setAuthenticationRequestRepository(getAuthenticationRequestRepository(http));
/* 325 */     http.addFilter((Filter)postProcess(filter));
/* 326 */     super.configure((HttpSecurityBuilder)http);
/* 327 */     if (this.authenticationManager != null) {
/* 328 */       this.saml2WebSsoAuthenticationFilter.setAuthenticationManager(this.authenticationManager);
/*     */     }
/*     */   }
/*     */   
/*     */   RelyingPartyRegistrationRepository relyingPartyRegistrationRepository(B http) {
/* 333 */     if (this.relyingPartyRegistrationRepository == null) {
/* 334 */       this.relyingPartyRegistrationRepository = getSharedOrBean(http, RelyingPartyRegistrationRepository.class);
/*     */     }
/* 336 */     return this.relyingPartyRegistrationRepository;
/*     */   }
/*     */   
/*     */   private AuthenticationEntryPoint getLoginEntryPoint(B http, String providerLoginPage) {
/* 340 */     RequestMatcher loginPageMatcher = RequestMatcherFactory.matcher(getLoginPage());
/* 341 */     RequestMatcher faviconMatcher = RequestMatcherFactory.matcher("/favicon.ico");
/* 342 */     RequestMatcher defaultEntryPointMatcher = getAuthenticationEntryPointMatcher((HttpSecurityBuilder)http);
/* 343 */     AndRequestMatcher andRequestMatcher = new AndRequestMatcher(new RequestMatcher[] { (RequestMatcher)new OrRequestMatcher(new RequestMatcher[] { loginPageMatcher, faviconMatcher }), defaultEntryPointMatcher });
/*     */     
/* 345 */     NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
/*     */     
/* 347 */     LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> entryPoints = new LinkedHashMap<>();
/* 348 */     LoginUrlAuthenticationEntryPoint loginUrlEntryPoint = new LoginUrlAuthenticationEntryPoint(providerLoginPage);
/* 349 */     PortResolver portResolver = getBeanOrNull(http, PortResolver.class);
/* 350 */     if (portResolver != null) {
/* 351 */       loginUrlEntryPoint.setPortResolver(portResolver);
/*     */     }
/* 353 */     entryPoints.put(new AndRequestMatcher(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)new NegatedRequestMatcher((RequestMatcher)andRequestMatcher) }, ), loginUrlEntryPoint);
/*     */     
/* 355 */     DelegatingAuthenticationEntryPoint loginEntryPoint = new DelegatingAuthenticationEntryPoint(entryPoints);
/* 356 */     loginEntryPoint.setDefaultEntryPoint(getAuthenticationEntryPoint());
/* 357 */     return (AuthenticationEntryPoint)loginEntryPoint;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setAuthenticationRequestRepository(B http, Saml2WebSsoAuthenticationFilter saml2WebSsoAuthenticationFilter) {
/* 362 */     saml2WebSsoAuthenticationFilter.setAuthenticationRequestRepository(getAuthenticationRequestRepository(http));
/*     */   }
/*     */   
/*     */   private Saml2WebSsoAuthenticationRequestFilter getAuthenticationRequestFilter(B http) {
/* 366 */     Saml2AuthenticationRequestResolver authenticationRequestResolver = getAuthenticationRequestResolver(http);
/* 367 */     return new Saml2WebSsoAuthenticationRequestFilter(authenticationRequestResolver);
/*     */   }
/*     */   
/*     */   private Saml2AuthenticationRequestResolver getAuthenticationRequestResolver(B http) {
/* 371 */     if (this.authenticationRequestResolver != null) {
/* 372 */       return this.authenticationRequestResolver;
/*     */     }
/* 374 */     Saml2AuthenticationRequestResolver bean = getBeanOrNull(http, Saml2AuthenticationRequestResolver.class);
/* 375 */     if (bean != null) {
/* 376 */       return bean;
/*     */     }
/* 378 */     if (USE_OPENSAML_5) {
/*     */       
/* 380 */       OpenSaml5AuthenticationRequestResolver openSaml5AuthenticationRequestResolver = new OpenSaml5AuthenticationRequestResolver(relyingPartyRegistrationRepository(http));
/* 381 */       openSaml5AuthenticationRequestResolver.setRequestMatcher(getAuthenticationRequestMatcher());
/* 382 */       return (Saml2AuthenticationRequestResolver)openSaml5AuthenticationRequestResolver;
/*     */     } 
/*     */ 
/*     */     
/* 386 */     OpenSaml4AuthenticationRequestResolver openSamlAuthenticationRequestResolver = new OpenSaml4AuthenticationRequestResolver(relyingPartyRegistrationRepository(http));
/* 387 */     openSamlAuthenticationRequestResolver.setRequestMatcher(getAuthenticationRequestMatcher());
/* 388 */     return (Saml2AuthenticationRequestResolver)openSamlAuthenticationRequestResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   private RequestMatcher getAuthenticationRequestMatcher() {
/* 393 */     if (this.authenticationRequestMatcher == null) {
/* 394 */       this.authenticationRequestMatcher = RequestMatchers.anyOf(new RequestMatcher[] {
/*     */             
/* 396 */             RequestMatcherFactory.matcher("/saml2/authenticate/{registrationId}"), new PathQueryRequestMatcher(
/* 397 */               RequestMatcherFactory.matcher(this.authenticationRequestUri), this.authenticationRequestParams)
/*     */           });
/*     */     }
/* 400 */     return this.authenticationRequestMatcher;
/*     */   }
/*     */   
/*     */   private RequestMatcher getLoginProcessingEndpoint() {
/* 404 */     if (this.loginProcessingUrl == null) {
/* 405 */       this.loginProcessingUrl = RequestMatchers.anyOf(new RequestMatcher[] {
/* 406 */             RequestMatcherFactory.matcher("/login/saml2/sso/{registrationId}"), 
/* 407 */             RequestMatcherFactory.matcher("/login/saml2/sso")
/*     */           });
/*     */     }
/* 410 */     return this.loginProcessingUrl;
/*     */   }
/*     */   
/*     */   private AuthenticationConverter getAuthenticationConverter(B http) {
/* 414 */     if (this.authenticationConverter != null) {
/* 415 */       return this.authenticationConverter;
/*     */     }
/* 417 */     AuthenticationConverter authenticationConverterBean = (AuthenticationConverter)getBeanOrNull(http, Saml2AuthenticationTokenConverter.class);
/*     */     
/* 419 */     if (authenticationConverterBean == null) {
/* 420 */       authenticationConverterBean = (AuthenticationConverter)getBeanOrNull(http, OpenSamlAuthenticationTokenConverter.class);
/*     */     }
/* 422 */     if (authenticationConverterBean != null) {
/* 423 */       return authenticationConverterBean;
/*     */     }
/* 425 */     if (USE_OPENSAML_5) {
/* 426 */       authenticationConverterBean = (AuthenticationConverter)getBeanOrNull(http, OpenSaml5AuthenticationTokenConverter.class);
/* 427 */       if (authenticationConverterBean != null) {
/* 428 */         return authenticationConverterBean;
/*     */       }
/* 430 */       OpenSaml5AuthenticationTokenConverter openSaml5AuthenticationTokenConverter = new OpenSaml5AuthenticationTokenConverter(this.relyingPartyRegistrationRepository);
/*     */       
/* 432 */       openSaml5AuthenticationTokenConverter.setAuthenticationRequestRepository(getAuthenticationRequestRepository(http));
/* 433 */       openSaml5AuthenticationTokenConverter.setRequestMatcher(getLoginProcessingEndpoint());
/* 434 */       return (AuthenticationConverter)openSaml5AuthenticationTokenConverter;
/*     */     } 
/* 436 */     authenticationConverterBean = (AuthenticationConverter)getBeanOrNull(http, OpenSaml4AuthenticationTokenConverter.class);
/* 437 */     if (authenticationConverterBean != null) {
/* 438 */       return authenticationConverterBean;
/*     */     }
/* 440 */     OpenSaml4AuthenticationTokenConverter converter = new OpenSaml4AuthenticationTokenConverter(this.relyingPartyRegistrationRepository);
/*     */     
/* 442 */     converter.setAuthenticationRequestRepository(getAuthenticationRequestRepository(http));
/* 443 */     converter.setRequestMatcher(getLoginProcessingEndpoint());
/* 444 */     return (AuthenticationConverter)converter;
/*     */   }
/*     */   
/*     */   private void registerDefaultAuthenticationProvider(B http) {
/* 448 */     if (USE_OPENSAML_5) {
/* 449 */       OpenSaml5AuthenticationProvider provider = getBeanOrNull(http, OpenSaml5AuthenticationProvider.class);
/* 450 */       if (provider == null) {
/* 451 */         http.authenticationProvider((AuthenticationProvider)postProcess(new OpenSaml5AuthenticationProvider()));
/*     */       }
/*     */     } else {
/*     */       
/* 455 */       OpenSaml4AuthenticationProvider provider = getBeanOrNull(http, OpenSaml4AuthenticationProvider.class);
/* 456 */       if (provider == null) {
/* 457 */         http.authenticationProvider((AuthenticationProvider)postProcess(new OpenSaml4AuthenticationProvider()));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerDefaultCsrfOverride(B http) {
/* 463 */     CsrfConfigurer<B> csrf = (CsrfConfigurer<B>)http.getConfigurer(CsrfConfigurer.class);
/* 464 */     if (csrf == null) {
/*     */       return;
/*     */     }
/* 467 */     csrf.ignoringRequestMatchers(new RequestMatcher[] { getLoginProcessingEndpoint() });
/*     */   }
/*     */ 
/*     */   
/*     */   private void initDefaultLoginFilter(B http) {
/* 472 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/* 473 */     if (loginPageGeneratingFilter == null || isCustomLoginPage()) {
/*     */       return;
/*     */     }
/* 476 */     loginPageGeneratingFilter.setSaml2LoginEnabled(true);
/* 477 */     loginPageGeneratingFilter
/* 478 */       .setSaml2AuthenticationUrlToProviderName(getIdentityProviderUrlMap(this.authenticationRequestUri, this.authenticationRequestParams, this.relyingPartyRegistrationRepository));
/*     */     
/* 480 */     loginPageGeneratingFilter.setLoginPageUrl(getLoginPage());
/* 481 */     loginPageGeneratingFilter.setFailureUrl(getFailureUrl());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> getIdentityProviderUrlMap(String authRequestPrefixUrl, String[] authRequestQueryParams, RelyingPartyRegistrationRepository idpRepo) {
/* 487 */     Map<String, String> idps = new LinkedHashMap<>();
/* 488 */     if (idpRepo instanceof Iterable) {
/* 489 */       Iterable<RelyingPartyRegistration> repo = (Iterable<RelyingPartyRegistration>)idpRepo;
/* 490 */       StringBuilder authRequestQuery = new StringBuilder("?");
/* 491 */       for (String authRequestQueryParam : authRequestQueryParams) {
/* 492 */         authRequestQuery.append(authRequestQueryParam + "&");
/*     */       }
/* 494 */       authRequestQuery.deleteCharAt(authRequestQuery.length() - 1);
/* 495 */       String authenticationRequestUriQuery = authRequestPrefixUrl + authRequestPrefixUrl;
/* 496 */       repo.forEach(p -> idps.put(authenticationRequestUriQuery.replace("{registrationId}", p.getRegistrationId()), p.getRegistrationId()));
/*     */     } 
/*     */ 
/*     */     
/* 500 */     return idps;
/*     */   }
/*     */ 
/*     */   
/*     */   private Saml2AuthenticationRequestRepository<AbstractSaml2AuthenticationRequest> getAuthenticationRequestRepository(B http) {
/* 505 */     Saml2AuthenticationRequestRepository<AbstractSaml2AuthenticationRequest> repository = getBeanOrNull(http, (Class)Saml2AuthenticationRequestRepository.class);
/*     */     
/* 507 */     if (repository == null) {
/* 508 */       return (Saml2AuthenticationRequestRepository<AbstractSaml2AuthenticationRequest>)new HttpSessionSaml2AuthenticationRequestRepository();
/*     */     }
/* 510 */     return repository;
/*     */   }
/*     */   
/*     */   private <C> C getSharedOrBean(B http, Class<C> clazz) {
/* 514 */     C shared = (C)http.getSharedObject(clazz);
/* 515 */     if (shared != null) {
/* 516 */       return shared;
/*     */     }
/* 518 */     return getBeanOrNull(http, clazz);
/*     */   }
/*     */   
/*     */   private <C> C getBeanOrNull(B http, Class<C> clazz) {
/* 522 */     ApplicationContext context = (ApplicationContext)http.getSharedObject(ApplicationContext.class);
/* 523 */     if (context == null) {
/* 524 */       return null;
/*     */     }
/* 526 */     return (C)context.getBeanProvider(clazz).getIfUnique();
/*     */   }
/*     */   
/*     */   private <C> void setSharedObject(B http, Class<C> clazz, C object) {
/* 530 */     if (http.getSharedObject(clazz) == null)
/* 531 */       http.setSharedObject(clazz, object); 
/*     */   }
/*     */   
/*     */   static class PathQueryRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     private final RequestMatcher matcher;
/*     */     
/*     */     PathQueryRequestMatcher(RequestMatcher pathMatcher, String... params) {
/* 540 */       List<RequestMatcher> matchers = new ArrayList<>();
/* 541 */       matchers.add(pathMatcher);
/* 542 */       for (String param : params) {
/* 543 */         String[] parts = param.split("=");
/* 544 */         if (parts.length == 1) {
/* 545 */           matchers.add(new ParameterRequestMatcher(parts[0]));
/*     */         } else {
/*     */           
/* 548 */           matchers.add(new ParameterRequestMatcher(parts[0], parts[1]));
/*     */         } 
/*     */       } 
/* 551 */       this.matcher = (RequestMatcher)new AndRequestMatcher(matchers);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 556 */       return matcher(request).isMatch();
/*     */     }
/*     */ 
/*     */     
/*     */     public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/* 561 */       return this.matcher.matcher(request);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\saml2\Saml2LoginConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */