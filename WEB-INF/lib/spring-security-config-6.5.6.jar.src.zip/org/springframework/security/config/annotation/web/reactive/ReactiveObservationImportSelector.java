/*    */ package org.springframework.security.config.annotation.web.reactive;
/*    */ 
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveObservationImportSelector
/*    */   implements ImportSelector
/*    */ {
/*    */   private static final boolean observabilityPresent;
/*    */   
/*    */   static {
/* 37 */     ClassLoader classLoader = ReactiveObservationImportSelector.class.getClassLoader();
/* 38 */     observabilityPresent = ClassUtils.isPresent("io.micrometer.observation.ObservationRegistry", classLoader);
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 43 */     if (!observabilityPresent) {
/* 44 */       return new String[0];
/*    */     }
/* 46 */     return new String[] { ReactiveObservationConfiguration.class.getName() };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ReactiveObservationImportSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */