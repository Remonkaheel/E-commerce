/*    */ package org.springframework.security.config.annotation.web.configurers;
/*    */ 
/*    */ import jakarta.servlet.Filter;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.security.config.annotation.SecurityBuilder;
/*    */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*    */ import org.springframework.security.web.authentication.ui.DefaultLogoutPageGeneratingFilter;
/*    */ import org.springframework.security.web.authentication.ui.DefaultResourcesFilter;
/*    */ import org.springframework.security.web.csrf.CsrfToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultLoginPageConfigurer<H extends HttpSecurityBuilder<H>>
/*    */   extends AbstractHttpConfigurer<DefaultLoginPageConfigurer<H>, H>
/*    */ {
/* 65 */   private DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = new DefaultLoginPageGeneratingFilter();
/*    */   
/* 67 */   private DefaultLogoutPageGeneratingFilter logoutPageGeneratingFilter = new DefaultLogoutPageGeneratingFilter();
/*    */ 
/*    */   
/*    */   public void init(H http) {
/* 71 */     this.loginPageGeneratingFilter.setResolveHiddenInputs(this::hiddenInputs);
/* 72 */     this.logoutPageGeneratingFilter.setResolveHiddenInputs(this::hiddenInputs);
/* 73 */     http.setSharedObject(DefaultLoginPageGeneratingFilter.class, this.loginPageGeneratingFilter);
/*    */   }
/*    */   
/*    */   private Map<String, String> hiddenInputs(HttpServletRequest request) {
/* 77 */     CsrfToken token = (CsrfToken)request.getAttribute(CsrfToken.class.getName());
/* 78 */     return (token != null) ? Collections.<String, String>singletonMap(token.getParameterName(), token.getToken()) : 
/* 79 */       Collections.<String, String>emptyMap();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void configure(H http) {
/* 85 */     AuthenticationEntryPoint authenticationEntryPoint = null;
/* 86 */     ExceptionHandlingConfigurer<?> exceptionConf = (ExceptionHandlingConfigurer)http.getConfigurer(ExceptionHandlingConfigurer.class);
/* 87 */     if (exceptionConf != null) {
/* 88 */       authenticationEntryPoint = exceptionConf.getAuthenticationEntryPoint();
/*    */     }
/* 90 */     if (this.loginPageGeneratingFilter.isEnabled() && authenticationEntryPoint == null) {
/* 91 */       this.loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)postProcess(this.loginPageGeneratingFilter);
/* 92 */       http.addFilter((Filter)this.loginPageGeneratingFilter);
/* 93 */       http.addFilter((Filter)DefaultResourcesFilter.css());
/* 94 */       LogoutConfigurer<H> logoutConfigurer = (LogoutConfigurer<H>)http.getConfigurer(LogoutConfigurer.class);
/* 95 */       if (logoutConfigurer != null)
/* 96 */         http.addFilter((Filter)this.logoutPageGeneratingFilter); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\DefaultLoginPageConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */