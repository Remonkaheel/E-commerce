/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.context.annotation.Role;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.authorization.AuthoritiesAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.method.AuthorizationManagerBeforeMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.SecuredAuthorizationManager;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(value = "_securedMethodSecurityConfiguration", proxyBeanMethods = false)
/*     */ @Role(2)
/*     */ final class SecuredMethodSecurityConfiguration
/*     */   implements ImportAware, AopInfrastructureBean
/*     */ {
/*  56 */   private static final Pointcut pointcut = AuthorizationManagerBeforeMethodInterceptor.secured().getPointcut();
/*     */   
/*  58 */   private final SecuredAuthorizationManager authorizationManager = new SecuredAuthorizationManager();
/*     */ 
/*     */   
/*     */   private final AuthorizationManagerBeforeMethodInterceptor methodInterceptor;
/*     */ 
/*     */   
/*     */   SecuredMethodSecurityConfiguration(ObjectProvider<ObjectPostProcessor<AuthorizationManager<MethodInvocation>>> postProcessors) {
/*  65 */     ObjectPostProcessor<AuthorizationManager<MethodInvocation>> postProcessor = (ObjectPostProcessor<AuthorizationManager<MethodInvocation>>)postProcessors.getIfUnique(ObjectPostProcessor::identity);
/*  66 */     AuthorizationManager<MethodInvocation> manager = (AuthorizationManager<MethodInvocation>)postProcessor.postProcess(this.authorizationManager);
/*  67 */     this.methodInterceptor = AuthorizationManagerBeforeMethodInterceptor.secured(manager);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor securedAuthorizationMethodInterceptor(ObjectProvider<SecuredMethodSecurityConfiguration> securedMethodSecurityConfiguration) {
/*  74 */     Supplier<AuthorizationManagerBeforeMethodInterceptor> supplier = () -> {
/*     */         SecuredMethodSecurityConfiguration configuration = (SecuredMethodSecurityConfiguration)securedMethodSecurityConfiguration.getObject();
/*     */         return configuration.methodInterceptor;
/*     */       };
/*  78 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(pointcut, supplier);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/*  83 */     EnableMethodSecurity annotation = (EnableMethodSecurity)importMetadata.getAnnotations().get(EnableMethodSecurity.class).synthesize();
/*  84 */     this.methodInterceptor.setOrder(this.methodInterceptor.getOrder() + annotation.offset());
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/*  89 */     AuthoritiesAuthorizationManager authoritiesAuthorizationManager = new AuthoritiesAuthorizationManager();
/*  90 */     authoritiesAuthorizationManager.setRoleHierarchy(roleHierarchy);
/*  91 */     this.authorizationManager.setAuthoritiesAuthorizationManager((AuthorizationManager)authoritiesAuthorizationManager);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/*  96 */     this.methodInterceptor.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setEventPublisher(AuthorizationEventPublisher eventPublisher) {
/* 101 */     this.methodInterceptor.setAuthorizationEventPublisher(eventPublisher);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\SecuredMethodSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */