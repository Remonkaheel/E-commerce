/*    */ package org.springframework.security.config.annotation.web.saml2;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*    */ import org.springframework.security.saml2.provider.service.authentication.logout.Saml2LogoutRequestValidator;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestRepository;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "logoutRequest", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutRequestConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nLogoutRequestDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LogoutRequestDsl.kt\norg/springframework/security/config/annotation/web/saml2/LogoutRequestDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,54:1\n1#2:55\n*E\n"})
/*    */ final class LogoutRequestDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<Saml2LogoutConfigurer<HttpSecurity>.LogoutRequestConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(Saml2LogoutConfigurer.LogoutRequestConfigurer logoutRequest) {
/* 47 */     Intrinsics.checkNotNullParameter(logoutRequest, "logoutRequest"); String str1 = LogoutRequestDsl.this.getLogoutUrl(); LogoutRequestDsl logoutRequestDsl = LogoutRequestDsl.this; String str2 = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     int $i$a$-also-LogoutRequestDsl$get$1$1 = 0; logoutRequest.logoutUrl(logoutRequestDsl.getLogoutUrl()); if (LogoutRequestDsl.this.getLogoutRequestValidator() != null) { Saml2LogoutRequestValidator saml2LogoutRequestValidator1 = LogoutRequestDsl.this.getLogoutRequestValidator(); LogoutRequestDsl logoutRequestDsl1 = LogoutRequestDsl.this; Saml2LogoutRequestValidator saml2LogoutRequestValidator2 = saml2LogoutRequestValidator1; int $i$a$-also-LogoutRequestDsl$get$1$2 = 0; logoutRequest.logoutRequestValidator(logoutRequestDsl1.getLogoutRequestValidator()); } else { LogoutRequestDsl.this.getLogoutRequestValidator(); }  if (LogoutRequestDsl.this.getLogoutRequestResolver() != null) { Saml2LogoutRequestResolver saml2LogoutRequestResolver1 = LogoutRequestDsl.this.getLogoutRequestResolver(); LogoutRequestDsl logoutRequestDsl1 = LogoutRequestDsl.this; Saml2LogoutRequestResolver saml2LogoutRequestResolver2 = saml2LogoutRequestResolver1; int $i$a$-also-LogoutRequestDsl$get$1$3 = 0; logoutRequest.logoutRequestResolver(logoutRequestDsl1.getLogoutRequestResolver()); } else { LogoutRequestDsl.this.getLogoutRequestResolver(); }  Saml2LogoutRequestRepository saml2LogoutRequestRepository1 = LogoutRequestDsl.this.getLogoutRequestRepository(); logoutRequestDsl = LogoutRequestDsl.this; Saml2LogoutRequestRepository it = saml2LogoutRequestRepository1; int $i$a$-also-LogoutRequestDsl$get$1$4 = 0;
/*    */     logoutRequest.logoutRequestRepository(logoutRequestDsl.getLogoutRequestRepository());
/*    */   }
/*    */   
/*    */   LogoutRequestDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\saml2\LogoutRequestDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */