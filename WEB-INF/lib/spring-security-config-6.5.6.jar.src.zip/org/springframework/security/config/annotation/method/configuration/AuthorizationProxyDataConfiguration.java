/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.aop.framework.AopInfrastructureBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.security.aot.hint.SecurityHintsRegistrar;
/*    */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*    */ import org.springframework.security.data.aot.hint.AuthorizeReturnObjectDataHintsRegistrar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ final class AuthorizationProxyDataConfiguration
/*    */   implements AopInfrastructureBean
/*    */ {
/*    */   @Bean
/*    */   @Role(2)
/*    */   static SecurityHintsRegistrar authorizeReturnObjectDataHintsRegistrar(AuthorizationProxyFactory proxyFactory) {
/* 34 */     return (SecurityHintsRegistrar)new AuthorizeReturnObjectDataHintsRegistrar(proxyFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\AuthorizationProxyDataConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */