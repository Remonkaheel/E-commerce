/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*     */ import org.springframework.security.config.http.SessionCreationPolicy;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.session.InvalidSessionStrategy;
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000j\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\013\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\0206\032\024\022\n\022\b\022\004\022\0020,0+\022\004\022\0020-0)H\000¢\006\002\b7J\037\020(\032\0020-2\027\0208\032\023\022\004\022\00209\022\004\022\0020-0)¢\006\002\b:J\037\0204\032\0020-2\027\020;\032\023\022\004\022\0020<\022\004\022\0020-0)¢\006\002\b:R\036\020\003\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\034\020\020\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R\036\020\026\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\027\020\006\"\004\b\030\020\bR\034\020\031\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\032\020\023\"\004\b\033\020\025R\034\020\034\032\004\030\0010\035X\016¢\006\016\n\000\032\004\b\036\020\037\"\004\b \020!R\034\020\"\032\004\030\0010#X\016¢\006\016\n\000\032\004\b$\020%\"\004\b&\020'R&\020(\032\032\022\016\022\f0*R\b\022\004\022\0020,0+\022\004\022\0020-\030\0010)X\016¢\006\002\n\000R\034\020.\032\004\030\0010/X\016¢\006\016\n\000\032\004\b0\0201\"\004\b2\0203R&\0204\032\032\022\016\022\f05R\b\022\004\022\0020,0+\022\004\022\0020-\030\0010)X\016¢\006\002\n\000¨\006="}, d2 = {"Lorg/springframework/security/config/annotation/web/SessionManagementDsl;", "", "()V", "enableSessionUrlRewriting", "", "getEnableSessionUrlRewriting", "()Ljava/lang/Boolean;", "setEnableSessionUrlRewriting", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "invalidSessionStrategy", "Lorg/springframework/security/web/session/InvalidSessionStrategy;", "getInvalidSessionStrategy", "()Lorg/springframework/security/web/session/InvalidSessionStrategy;", "setInvalidSessionStrategy", "(Lorg/springframework/security/web/session/InvalidSessionStrategy;)V", "invalidSessionUrl", "", "getInvalidSessionUrl", "()Ljava/lang/String;", "setInvalidSessionUrl", "(Ljava/lang/String;)V", "requireExplicitAuthenticationStrategy", "getRequireExplicitAuthenticationStrategy", "setRequireExplicitAuthenticationStrategy", "sessionAuthenticationErrorUrl", "getSessionAuthenticationErrorUrl", "setSessionAuthenticationErrorUrl", "sessionAuthenticationFailureHandler", "Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "getSessionAuthenticationFailureHandler", "()Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "setSessionAuthenticationFailureHandler", "(Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;)V", "sessionAuthenticationStrategy", "Lorg/springframework/security/web/authentication/session/SessionAuthenticationStrategy;", "getSessionAuthenticationStrategy", "()Lorg/springframework/security/web/authentication/session/SessionAuthenticationStrategy;", "setSessionAuthenticationStrategy", "(Lorg/springframework/security/web/authentication/session/SessionAuthenticationStrategy;)V", "sessionConcurrency", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$ConcurrencyControlConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "sessionCreationPolicy", "Lorg/springframework/security/config/http/SessionCreationPolicy;", "getSessionCreationPolicy", "()Lorg/springframework/security/config/http/SessionCreationPolicy;", "setSessionCreationPolicy", "(Lorg/springframework/security/config/http/SessionCreationPolicy;)V", "sessionFixation", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$SessionFixationConfigurer;", "get", "get$spring_security_config", "sessionConcurrencyConfig", "Lorg/springframework/security/config/annotation/web/session/SessionConcurrencyDsl;", "Lkotlin/ExtensionFunctionType;", "sessionFixationConfig", "Lorg/springframework/security/config/annotation/web/session/SessionFixationDsl;", "spring-security-config"})
/*     */ public final class SessionManagementDsl {
/*     */   @Nullable
/*     */   private String invalidSessionUrl;
/*     */   @Nullable
/*     */   private InvalidSessionStrategy invalidSessionStrategy;
/*     */   @Nullable
/*     */   private String sessionAuthenticationErrorUrl;
/*     */   @Nullable
/*     */   private AuthenticationFailureHandler sessionAuthenticationFailureHandler;
/*     */   @Nullable
/*     */   private Boolean enableSessionUrlRewriting;
/*     */   @Nullable
/*     */   private Boolean requireExplicitAuthenticationStrategy;
/*     */   @Nullable
/*     */   private SessionCreationPolicy sessionCreationPolicy;
/*     */   @Nullable
/*     */   private SessionAuthenticationStrategy sessionAuthenticationStrategy;
/*     */   @Nullable
/*     */   private Function1<? super SessionManagementConfigurer<HttpSecurity>.SessionFixationConfigurer, Unit> sessionFixation;
/*     */   @Nullable
/*     */   private Function1<? super SessionManagementConfigurer<HttpSecurity>.ConcurrencyControlConfigurer, Unit> sessionConcurrency;
/*     */   
/*     */   @Nullable
/*  37 */   public final String getInvalidSessionUrl() { return this.invalidSessionUrl; } public final void setInvalidSessionUrl(@Nullable String <set-?>) { this.invalidSessionUrl = <set-?>; } @Nullable
/*  38 */   public final InvalidSessionStrategy getInvalidSessionStrategy() { return this.invalidSessionStrategy; } public final void setInvalidSessionStrategy(@Nullable InvalidSessionStrategy <set-?>) { this.invalidSessionStrategy = <set-?>; } @Nullable
/*  39 */   public final String getSessionAuthenticationErrorUrl() { return this.sessionAuthenticationErrorUrl; } public final void setSessionAuthenticationErrorUrl(@Nullable String <set-?>) { this.sessionAuthenticationErrorUrl = <set-?>; } @Nullable
/*  40 */   public final AuthenticationFailureHandler getSessionAuthenticationFailureHandler() { return this.sessionAuthenticationFailureHandler; } public final void setSessionAuthenticationFailureHandler(@Nullable AuthenticationFailureHandler <set-?>) { this.sessionAuthenticationFailureHandler = <set-?>; } @Nullable
/*  41 */   public final Boolean getEnableSessionUrlRewriting() { return this.enableSessionUrlRewriting; } public final void setEnableSessionUrlRewriting(@Nullable Boolean <set-?>) { this.enableSessionUrlRewriting = <set-?>; } @Nullable
/*  42 */   public final Boolean getRequireExplicitAuthenticationStrategy() { return this.requireExplicitAuthenticationStrategy; } public final void setRequireExplicitAuthenticationStrategy(@Nullable Boolean <set-?>) { this.requireExplicitAuthenticationStrategy = <set-?>; } @Nullable
/*  43 */   public final SessionCreationPolicy getSessionCreationPolicy() { return this.sessionCreationPolicy; } public final void setSessionCreationPolicy(@Nullable SessionCreationPolicy <set-?>) { this.sessionCreationPolicy = <set-?>; } @Nullable
/*  44 */   public final SessionAuthenticationStrategy getSessionAuthenticationStrategy() { return this.sessionAuthenticationStrategy; } public final void setSessionAuthenticationStrategy(@Nullable SessionAuthenticationStrategy <set-?>) { this.sessionAuthenticationStrategy = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void sessionFixation(@NotNull Function1 sessionFixationConfig) {
/*  75 */     Intrinsics.checkNotNullParameter(sessionFixationConfig, "sessionFixationConfig"); SessionFixationDsl sessionFixationDsl = new SessionFixationDsl(); sessionFixationConfig.invoke(sessionFixationDsl); this.sessionFixation = sessionFixationDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void sessionConcurrency(@NotNull Function1 sessionConcurrencyConfig) {
/* 108 */     Intrinsics.checkNotNullParameter(sessionConcurrencyConfig, "sessionConcurrencyConfig"); SessionConcurrencyDsl sessionConcurrencyDsl = new SessionConcurrencyDsl(); sessionConcurrencyConfig.invoke(sessionConcurrencyDsl); this.sessionConcurrency = sessionConcurrencyDsl.get$spring_security_config();
/*     */   }
/*     */   
/*     */   @NotNull
/* 112 */   public final Function1<SessionManagementConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new SessionManagementDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "sessionManagement", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nSessionManagementDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SessionManagementDsl.kt\norg/springframework/security/config/annotation/web/SessionManagementDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,127:1\n1#2:128\n*E\n"})
/* 113 */   static final class SessionManagementDsl$get$1 extends Lambda implements Function1<SessionManagementConfigurer<HttpSecurity>, Unit> { public final void invoke(SessionManagementConfigurer sessionManagement) { Intrinsics.checkNotNullParameter(sessionManagement, "sessionManagement"); if (SessionManagementDsl.this.getInvalidSessionUrl() != null) { String str1 = SessionManagementDsl.this.getInvalidSessionUrl(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; String it = str1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 128 */         int $i$a$-also-SessionManagementDsl$get$1$1 = 0; sessionManagement.invalidSessionUrl(sessionManagementDsl.getInvalidSessionUrl()); } else { SessionManagementDsl.this.getInvalidSessionUrl(); }  if (SessionManagementDsl.this.getRequireExplicitAuthenticationStrategy() != null) { Boolean bool = SessionManagementDsl.this.getRequireExplicitAuthenticationStrategy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-SessionManagementDsl$get$1$2 = 0; Intrinsics.checkNotNull(sessionManagementDsl.getRequireExplicitAuthenticationStrategy()); sessionManagement.requireExplicitAuthenticationStrategy(sessionManagementDsl.getRequireExplicitAuthenticationStrategy().booleanValue()); } else { SessionManagementDsl.this.getRequireExplicitAuthenticationStrategy(); }  if (SessionManagementDsl.this.getInvalidSessionStrategy() != null) { InvalidSessionStrategy invalidSessionStrategy1 = SessionManagementDsl.this.getInvalidSessionStrategy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; InvalidSessionStrategy it = invalidSessionStrategy1; int $i$a$-also-SessionManagementDsl$get$1$3 = 0; sessionManagement.invalidSessionStrategy(sessionManagementDsl.getInvalidSessionStrategy()); } else { SessionManagementDsl.this.getInvalidSessionStrategy(); }  if (SessionManagementDsl.this.getSessionAuthenticationErrorUrl() != null) { String str1 = SessionManagementDsl.this.getSessionAuthenticationErrorUrl(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; String it = str1; int $i$a$-also-SessionManagementDsl$get$1$4 = 0; sessionManagement.sessionAuthenticationErrorUrl(sessionManagementDsl.getSessionAuthenticationErrorUrl()); } else { SessionManagementDsl.this.getSessionAuthenticationErrorUrl(); }  if (SessionManagementDsl.this.getSessionAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = SessionManagementDsl.this.getSessionAuthenticationFailureHandler(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; AuthenticationFailureHandler it = authenticationFailureHandler1; int $i$a$-also-SessionManagementDsl$get$1$5 = 0; sessionManagement.sessionAuthenticationFailureHandler(sessionManagementDsl.getSessionAuthenticationFailureHandler()); } else { SessionManagementDsl.this.getSessionAuthenticationFailureHandler(); }  if (SessionManagementDsl.this.getEnableSessionUrlRewriting() != null) { Boolean bool = SessionManagementDsl.this.getEnableSessionUrlRewriting(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-SessionManagementDsl$get$1$6 = 0; Intrinsics.checkNotNull(sessionManagementDsl.getEnableSessionUrlRewriting()); sessionManagement.enableSessionUrlRewriting(sessionManagementDsl.getEnableSessionUrlRewriting().booleanValue()); } else { SessionManagementDsl.this.getEnableSessionUrlRewriting(); }  if (SessionManagementDsl.this.getSessionCreationPolicy() != null) { SessionCreationPolicy sessionCreationPolicy1 = SessionManagementDsl.this.getSessionCreationPolicy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; SessionCreationPolicy it = sessionCreationPolicy1; int $i$a$-also-SessionManagementDsl$get$1$7 = 0; sessionManagement.sessionCreationPolicy(sessionManagementDsl.getSessionCreationPolicy()); } else { SessionManagementDsl.this.getSessionCreationPolicy(); }  if (SessionManagementDsl.this.getSessionAuthenticationStrategy() != null) { SessionAuthenticationStrategy sessionAuthenticationStrategy1 = SessionManagementDsl.this.getSessionAuthenticationStrategy(); SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; SessionAuthenticationStrategy it = sessionAuthenticationStrategy1; int $i$a$-also-SessionManagementDsl$get$1$8 = 0; sessionManagement.sessionAuthenticationStrategy(sessionManagementDsl.getSessionAuthenticationStrategy()); } else { SessionManagementDsl.this.getSessionAuthenticationStrategy(); }  if (SessionManagementDsl.this.sessionFixation != null) { Function1 function11 = SessionManagementDsl.this.sessionFixation; SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; Function1 it = function11; int $i$a$-also-SessionManagementDsl$get$1$9 = 0; sessionManagementDsl.sessionFixation; sessionManagement.sessionFixation((sessionManagementDsl.sessionFixation != null) ? sessionManagementDsl.sessionFixation::invoke$lambda$9$lambda$8 : null); } else { SessionManagementDsl.this.sessionFixation; }  if (SessionManagementDsl.this.sessionConcurrency != null) { Function1 function11 = SessionManagementDsl.this.sessionConcurrency; SessionManagementDsl sessionManagementDsl = SessionManagementDsl.this; Function1 it = function11; int $i$a$-also-SessionManagementDsl$get$1$10 = 0;
/*     */         sessionManagementDsl.sessionConcurrency;
/*     */         sessionManagement.sessionConcurrency((sessionManagementDsl.sessionConcurrency != null) ? sessionManagementDsl.sessionConcurrency::invoke$lambda$11$lambda$10 : null); }
/*     */       else
/*     */       { SessionManagementDsl.this.sessionConcurrency; }
/*     */        }
/*     */ 
/*     */     
/*     */     private static final void invoke$lambda$9$lambda$8(Function1 $tmp0, SessionManagementConfigurer.SessionFixationConfigurer t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$11$lambda$10(Function1 $tmp0, SessionManagementConfigurer.ConcurrencyControlConfigurer t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     SessionManagementDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\SessionManagementDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */