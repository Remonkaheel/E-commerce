/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.header.writers.CrossOriginEmbedderPolicyHeaderWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "crossOriginEmbedderPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CrossOriginEmbedderPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ final class CrossOriginEmbedderPolicyDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HeadersConfigurer<HttpSecurity>.CrossOriginEmbedderPolicyConfig, Unit>
/*    */ {
/*    */   public final void invoke(HeadersConfigurer.CrossOriginEmbedderPolicyConfig crossOriginEmbedderPolicy) {
/* 38 */     Intrinsics.checkNotNullParameter(crossOriginEmbedderPolicy, "crossOriginEmbedderPolicy"); CrossOriginEmbedderPolicyHeaderWriter.CrossOriginEmbedderPolicy crossOriginEmbedderPolicy1 = CrossOriginEmbedderPolicyDsl.this.getPolicy(); CrossOriginEmbedderPolicyDsl crossOriginEmbedderPolicyDsl = CrossOriginEmbedderPolicyDsl.this; CrossOriginEmbedderPolicyHeaderWriter.CrossOriginEmbedderPolicy it = crossOriginEmbedderPolicy1; int $i$a$-also-CrossOriginEmbedderPolicyDsl$get$1$1 = 0;
/* 39 */     crossOriginEmbedderPolicy.policy(crossOriginEmbedderPolicyDsl.getPolicy());
/*    */     CrossOriginEmbedderPolicyDsl.this.getPolicy();
/*    */   }
/*    */   
/*    */   CrossOriginEmbedderPolicyDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\CrossOriginEmbedderPolicyDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */