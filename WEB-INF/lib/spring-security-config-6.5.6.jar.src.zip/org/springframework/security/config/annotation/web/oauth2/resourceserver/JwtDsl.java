/*    */ package org.springframework.security.config.annotation.web.oauth2.resourceserver;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*    */ import org.springframework.security.oauth2.jwt.Jwt;
/*    */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2ResourceServerSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\013\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\n\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020 \032\030\022\016\022\f0\"R\b\022\004\022\0020$0#\022\004\022\0020%0!H\000¢\006\002\b&R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000R\034\020\007\032\004\030\0010\bX\016¢\006\016\n\000\032\004\b\t\020\n\"\004\b\013\020\fR(\020\016\032\004\030\0010\0042\b\020\r\032\004\030\0010\0048F@FX\016¢\006\f\032\004\b\017\020\020\"\004\b\021\020\022R*\020\023\032\022\022\004\022\0020\025\022\006\b\001\022\0020\026\030\0010\024X\016¢\006\016\n\000\032\004\b\027\020\030\"\004\b\031\020\032R(\020\033\032\004\030\0010\0062\b\020\r\032\004\030\0010\0068F@FX\016¢\006\f\032\004\b\034\020\035\"\004\b\036\020\037¨\006'"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/resourceserver/JwtDsl;", "", "()V", "_jwkSetUri", "", "_jwtDecoder", "Lorg/springframework/security/oauth2/jwt/JwtDecoder;", "authenticationManager", "Lorg/springframework/security/authentication/AuthenticationManager;", "getAuthenticationManager", "()Lorg/springframework/security/authentication/AuthenticationManager;", "setAuthenticationManager", "(Lorg/springframework/security/authentication/AuthenticationManager;)V", "value", "jwkSetUri", "getJwkSetUri", "()Ljava/lang/String;", "setJwkSetUri", "(Ljava/lang/String;)V", "jwtAuthenticationConverter", "Lorg/springframework/core/convert/converter/Converter;", "Lorg/springframework/security/oauth2/jwt/Jwt;", "Lorg/springframework/security/authentication/AbstractAuthenticationToken;", "getJwtAuthenticationConverter", "()Lorg/springframework/core/convert/converter/Converter;", "setJwtAuthenticationConverter", "(Lorg/springframework/core/convert/converter/Converter;)V", "jwtDecoder", "getJwtDecoder", "()Lorg/springframework/security/oauth2/jwt/JwtDecoder;", "setJwtDecoder", "(Lorg/springframework/security/oauth2/jwt/JwtDecoder;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$JwtConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class JwtDsl
/*    */ {
/*    */   @Nullable
/*    */   private JwtDecoder _jwtDecoder;
/*    */   @Nullable
/*    */   private String _jwkSetUri;
/*    */   @Nullable
/*    */   private AuthenticationManager authenticationManager;
/*    */   @Nullable
/*    */   private Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter;
/*    */   
/*    */   @Nullable
/*    */   public final AuthenticationManager getAuthenticationManager() {
/* 46 */     return this.authenticationManager; } public final void setAuthenticationManager(@Nullable AuthenticationManager <set-?>) { this.authenticationManager = <set-?>; }
/*    */   @Nullable
/* 48 */   public final Converter<Jwt, ? extends AbstractAuthenticationToken> getJwtAuthenticationConverter() { return this.jwtAuthenticationConverter; } public final void setJwtAuthenticationConverter(@Nullable Converter<Jwt, ? extends AbstractAuthenticationToken> <set-?>) { this.jwtAuthenticationConverter = <set-?>; } @Nullable
/*    */   public final JwtDecoder getJwtDecoder() {
/* 50 */     return this._jwtDecoder;
/*    */   } public final void setJwtDecoder(@Nullable JwtDecoder value) {
/* 52 */     this._jwtDecoder = value;
/* 53 */     this._jwkSetUri = null;
/*    */   } @Nullable
/*    */   public final String getJwkSetUri() {
/* 56 */     return this._jwkSetUri;
/*    */   } public final void setJwkSetUri(@Nullable String value) {
/* 58 */     this._jwkSetUri = value;
/* 59 */     this._jwtDecoder = null;
/*    */   }
/*    */   
/*    */   @NotNull
/* 63 */   public final Function1<OAuth2ResourceServerConfigurer<HttpSecurity>.JwtConfigurer, Unit> get$spring_security_config() { return new JwtDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "jwt", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$JwtConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nJwtDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JwtDsl.kt\norg/springframework/security/config/annotation/web/oauth2/resourceserver/JwtDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,71:1\n1#2:72\n*E\n"})
/* 64 */   static final class JwtDsl$get$1 extends Lambda implements Function1<OAuth2ResourceServerConfigurer<HttpSecurity>.JwtConfigurer, Unit> { public final void invoke(OAuth2ResourceServerConfigurer.JwtConfigurer jwt) { Intrinsics.checkNotNullParameter(jwt, "jwt"); if (JwtDsl.this.getJwtAuthenticationConverter() != null) { Converter<Jwt, ? extends AbstractAuthenticationToken> converter1 = JwtDsl.this.getJwtAuthenticationConverter(); JwtDsl jwtDsl = JwtDsl.this; Converter<Jwt, ? extends AbstractAuthenticationToken> it = converter1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 72 */         int $i$a$-also-JwtDsl$get$1$1 = 0; jwt.jwtAuthenticationConverter(jwtDsl.getJwtAuthenticationConverter()); } else { JwtDsl.this.getJwtAuthenticationConverter(); }  if (JwtDsl.this.getJwtDecoder() != null) { JwtDecoder jwtDecoder1 = JwtDsl.this.getJwtDecoder(); JwtDsl jwtDsl = JwtDsl.this; JwtDecoder it = jwtDecoder1; int $i$a$-also-JwtDsl$get$1$2 = 0; jwt.decoder(jwtDsl.getJwtDecoder()); } else { JwtDsl.this.getJwtDecoder(); }  if (JwtDsl.this.getJwkSetUri() != null) { String str1 = JwtDsl.this.getJwkSetUri(); JwtDsl jwtDsl = JwtDsl.this; String it = str1; int $i$a$-also-JwtDsl$get$1$3 = 0; jwt.jwkSetUri(jwtDsl.getJwkSetUri()); } else { JwtDsl.this.getJwkSetUri(); }  if (JwtDsl.this.getAuthenticationManager() != null) { AuthenticationManager authenticationManager1 = JwtDsl.this.getAuthenticationManager(); JwtDsl jwtDsl = JwtDsl.this; AuthenticationManager it = authenticationManager1; int $i$a$-also-JwtDsl$get$1$4 = 0;
/*    */         jwt.authenticationManager(jwtDsl.getAuthenticationManager()); }
/*    */       else
/*    */       { JwtDsl.this.getAuthenticationManager(); }
/*    */        }
/*    */ 
/*    */     
/*    */     JwtDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\resourceserver\JwtDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */