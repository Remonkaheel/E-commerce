/*    */ package org.springframework.security.config.annotation.web.configuration;
/*    */ 
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringWebMvcImportSelector
/*    */   implements ImportSelector
/*    */ {
/*    */   private static final boolean webMvcPresent;
/*    */   
/*    */   static {
/* 36 */     ClassLoader classLoader = SpringWebMvcImportSelector.class.getClassLoader();
/* 37 */     webMvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.DispatcherServlet", classLoader);
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 42 */     if (!webMvcPresent) {
/* 43 */       return new String[0];
/*    */     }
/* 45 */     return new String[] { "org.springframework.security.config.annotation.web.configuration.WebMvcSecurityConfiguration" };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\SpringWebMvcImportSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */