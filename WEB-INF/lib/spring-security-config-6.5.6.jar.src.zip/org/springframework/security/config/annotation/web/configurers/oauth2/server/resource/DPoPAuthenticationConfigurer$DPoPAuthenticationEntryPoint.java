/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.server.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2AccessToken;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DPoPAuthenticationEntryPoint
/*     */   implements AuthenticationEntryPoint
/*     */ {
/*     */   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authenticationException) {
/* 201 */     Map<String, String> parameters = new LinkedHashMap<>();
/* 202 */     if (authenticationException instanceof OAuth2AuthenticationException) { OAuth2AuthenticationException oauth2AuthenticationException = (OAuth2AuthenticationException)authenticationException;
/* 203 */       OAuth2Error error = oauth2AuthenticationException.getError();
/* 204 */       parameters.put("error", error.getErrorCode());
/* 205 */       if (StringUtils.hasText(error.getDescription())) {
/* 206 */         parameters.put("error_description", error.getDescription());
/*     */       }
/* 208 */       if (StringUtils.hasText(error.getUri())) {
/* 209 */         parameters.put("error_uri", error.getUri());
/*     */       } }
/*     */     
/* 212 */     parameters.put("algs", "RS256 RS384 RS512 PS256 PS384 PS512 ES256 ES384 ES512");
/*     */ 
/*     */ 
/*     */     
/* 216 */     String wwwAuthenticate = toWWWAuthenticateHeader(parameters);
/* 217 */     response.addHeader("WWW-Authenticate", wwwAuthenticate);
/* 218 */     response.setStatus(HttpStatus.UNAUTHORIZED.value());
/*     */   }
/*     */   
/*     */   private static String toWWWAuthenticateHeader(Map<String, String> parameters) {
/* 222 */     StringBuilder wwwAuthenticate = new StringBuilder();
/* 223 */     wwwAuthenticate.append(OAuth2AccessToken.TokenType.DPOP.getValue());
/* 224 */     if (!parameters.isEmpty()) {
/* 225 */       wwwAuthenticate.append(" ");
/* 226 */       int i = 0;
/* 227 */       for (Map.Entry<String, String> entry : parameters.entrySet()) {
/* 228 */         wwwAuthenticate.append(entry.getKey()).append("=\"").append(entry.getValue()).append("\"");
/* 229 */         if (i++ != parameters.size() - 1) {
/* 230 */           wwwAuthenticate.append(", ");
/*     */         }
/*     */       } 
/*     */     } 
/* 234 */     return wwwAuthenticate.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\server\resource\DPoPAuthenticationConfigurer$DPoPAuthenticationEntryPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */