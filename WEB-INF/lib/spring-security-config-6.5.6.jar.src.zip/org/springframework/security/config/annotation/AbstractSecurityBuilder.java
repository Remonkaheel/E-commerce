/*    */ package org.springframework.security.config.annotation;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSecurityBuilder<O>
/*    */   implements SecurityBuilder<O>
/*    */ {
/* 31 */   private AtomicBoolean building = new AtomicBoolean();
/*    */   
/*    */   private O object;
/*    */ 
/*    */   
/*    */   public final O build() throws Exception {
/* 37 */     if (this.building.compareAndSet(false, true)) {
/* 38 */       this.object = doBuild();
/* 39 */       return this.object;
/*    */     } 
/* 41 */     throw new AlreadyBuiltException("This object has already been built");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final O getObject() {
/* 50 */     if (!this.building.get()) {
/* 51 */       throw new IllegalStateException("This object has not been built");
/*    */     }
/* 53 */     return this.object;
/*    */   }
/*    */   
/*    */   protected abstract O doBuild() throws Exception;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\AbstractSecurityBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */