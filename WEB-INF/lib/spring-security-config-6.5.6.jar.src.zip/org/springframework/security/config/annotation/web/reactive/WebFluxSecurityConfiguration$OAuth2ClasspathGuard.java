/*     */ package org.springframework.security.config.annotation.web.reactive;
/*     */ 
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.config.web.server.ServerHttpSecurity;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OAuth2ClasspathGuard
/*     */ {
/*     */   static void configure(ApplicationContext context, ServerHttpSecurity http) {
/* 139 */     http.oauth2Login();
/* 140 */     http.oauth2Client();
/*     */   }
/*     */   
/*     */   static boolean shouldConfigure(ApplicationContext context) {
/* 144 */     ClassLoader loader = context.getClassLoader();
/*     */     
/* 146 */     Class<?> reactiveClientRegistrationRepositoryClass = ClassUtils.resolveClassName("org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository", loader);
/* 147 */     return ((context.getBeanNamesForType(reactiveClientRegistrationRepositoryClass)).length == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\WebFluxSecurityConfiguration$OAuth2ClasspathGuard.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */