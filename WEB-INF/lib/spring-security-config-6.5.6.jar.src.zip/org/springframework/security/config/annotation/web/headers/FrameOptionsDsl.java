/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\n\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\016\032\0020\017J#\020\020\032\030\022\016\022\f0\022R\b\022\004\022\0020\0240\023\022\004\022\0020\0170\021H\000¢\006\002\b\025R\036\020\003\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\005\020\006\"\004\b\007\020\bR\016\020\n\032\0020\004X\016¢\006\002\n\000R\036\020\013\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\f\020\006\"\004\b\r\020\b¨\006\026"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/FrameOptionsDsl;", "", "()V", "deny", "", "getDeny", "()Ljava/lang/Boolean;", "setDeny", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "disabled", "sameOrigin", "getSameOrigin", "setSameOrigin", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$FrameOptionsConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class FrameOptionsDsl
/*    */ {
/*    */   @Nullable
/*    */   private Boolean sameOrigin;
/*    */   @Nullable
/*    */   private Boolean deny;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final Boolean getSameOrigin() {
/* 34 */     return this.sameOrigin; } public final void setSameOrigin(@Nullable Boolean <set-?>) { this.sameOrigin = <set-?>; } @Nullable
/* 35 */   public final Boolean getDeny() { return this.deny; } public final void setDeny(@Nullable Boolean <set-?>) { this.deny = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 43 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 47 */   public final Function1<HeadersConfigurer<HttpSecurity>.FrameOptionsConfig, Unit> get$spring_security_config() { return new FrameOptionsDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "frameOptions", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$FrameOptionsConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 48 */   static final class FrameOptionsDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.FrameOptionsConfig, Unit> { public final void invoke(HeadersConfigurer.FrameOptionsConfig frameOptions) { Intrinsics.checkNotNullParameter(frameOptions, "frameOptions"); Boolean bool = FrameOptionsDsl.this.getSameOrigin(); FrameOptionsDsl frameOptionsDsl = FrameOptionsDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-FrameOptionsDsl$get$1$1 = 0;
/* 49 */       Intrinsics.checkNotNull(frameOptionsDsl.getSameOrigin()); if (frameOptionsDsl.getSameOrigin().booleanValue()) {
/* 50 */         frameOptions.sameOrigin();
/*    */       }
/*    */       FrameOptionsDsl.this.getSameOrigin();
/* 53 */       bool = FrameOptionsDsl.this.getDeny(); frameOptionsDsl = FrameOptionsDsl.this; it = bool.booleanValue(); int $i$a$-also-FrameOptionsDsl$get$1$2 = 0;
/* 54 */       Intrinsics.checkNotNull(frameOptionsDsl.getDeny()); if (frameOptionsDsl.getDeny().booleanValue()) {
/* 55 */         frameOptions.deny();
/*    */       }
/*    */       FrameOptionsDsl.this.getDeny();
/* 58 */       if (FrameOptionsDsl.this.disabled)
/* 59 */         frameOptions.disable();  }
/*    */ 
/*    */     
/*    */     FrameOptionsDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\FrameOptionsDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */