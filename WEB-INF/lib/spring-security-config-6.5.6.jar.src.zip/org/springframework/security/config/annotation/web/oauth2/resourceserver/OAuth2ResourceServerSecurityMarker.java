package org.springframework.security.config.annotation.web.oauth2.resourceserver;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.DslMarker;
import kotlin.Metadata;

@Retention(RetentionPolicy.RUNTIME)
@Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000\n\n\002\030\002\n\002\020\033\n\000\b\002\030\0002\0020\001B\000¨\006\002"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/resourceserver/OAuth2ResourceServerSecurityMarker;", "", "spring-security-config"})
@DslMarker
public @interface OAuth2ResourceServerSecurityMarker {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\resourceserver\OAuth2ResourceServerSecurityMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */