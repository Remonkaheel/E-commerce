/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import org.springframework.security.authentication.AnonymousAuthenticationProvider;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnonymousConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<AnonymousConfigurer<H>, H>
/*     */ {
/*     */   private String key;
/*     */   private AuthenticationProvider authenticationProvider;
/*     */   private AnonymousAuthenticationFilter authenticationFilter;
/*  52 */   private Object principal = "anonymousUser";
/*     */   
/*  54 */   private List<GrantedAuthority> authorities = AuthorityUtils.createAuthorityList(new String[] { "ROLE_ANONYMOUS" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String computedKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousConfigurer<H> key(String key) {
/*  74 */     this.key = key;
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousConfigurer<H> principal(Object principal) {
/*  85 */     this.principal = principal;
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousConfigurer<H> authorities(List<GrantedAuthority> authorities) {
/*  99 */     this.authorities = authorities;
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousConfigurer<H> authorities(String... authorities) {
/* 113 */     return authorities(AuthorityUtils.createAuthorityList(authorities));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousConfigurer<H> authenticationProvider(AuthenticationProvider authenticationProvider) {
/* 126 */     this.authenticationProvider = authenticationProvider;
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousConfigurer<H> authenticationFilter(AnonymousAuthenticationFilter authenticationFilter) {
/* 140 */     this.authenticationFilter = authenticationFilter;
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 146 */     if (this.authenticationProvider == null) {
/* 147 */       this.authenticationProvider = (AuthenticationProvider)new AnonymousAuthenticationProvider(getKey());
/*     */     }
/* 149 */     this.authenticationProvider = (AuthenticationProvider)postProcess(this.authenticationProvider);
/* 150 */     http.authenticationProvider(this.authenticationProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 155 */     if (this.authenticationFilter == null) {
/* 156 */       this.authenticationFilter = new AnonymousAuthenticationFilter(getKey(), this.principal, this.authorities);
/*     */     }
/* 158 */     this.authenticationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 159 */     this.authenticationFilter.afterPropertiesSet();
/* 160 */     http.addFilter((Filter)this.authenticationFilter);
/*     */   }
/*     */   
/*     */   private String getKey() {
/* 164 */     if (this.computedKey != null) {
/* 165 */       return this.computedKey;
/*     */     }
/* 167 */     if (this.key == null) {
/* 168 */       this.computedKey = UUID.randomUUID().toString();
/*     */     } else {
/*     */       
/* 171 */       this.computedKey = this.key;
/*     */     } 
/* 173 */     return this.computedKey;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AnonymousConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */