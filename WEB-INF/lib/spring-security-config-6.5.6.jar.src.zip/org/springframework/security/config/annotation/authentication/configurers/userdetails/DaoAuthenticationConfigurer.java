/*    */ package org.springframework.security.config.annotation.authentication.configurers.userdetails;
/*    */ 
/*    */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DaoAuthenticationConfigurer<B extends ProviderManagerBuilder<B>, U extends UserDetailsService>
/*    */   extends AbstractDaoAuthenticationConfigurer<B, DaoAuthenticationConfigurer<B, U>, U>
/*    */ {
/*    */   public DaoAuthenticationConfigurer(U userDetailsService) {
/* 39 */     super(userDetailsService);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurer\\userdetails\DaoAuthenticationConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */