/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Fallback;
/*     */ import org.springframework.context.annotation.Role;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.method.AuthorizationAdvisor;
/*     */ import org.springframework.security.authorization.method.AuthorizationManagerAfterReactiveMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.AuthorizationManagerBeforeReactiveMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.MethodInvocationResult;
/*     */ import org.springframework.security.authorization.method.PostAuthorizeReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.method.PostFilterAuthorizationReactiveMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.PreAuthorizeReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.method.PreFilterAuthorizationReactiveMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.PrePostTemplateDefaults;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(value = "_reactiveMethodSecurityConfiguration", proxyBeanMethods = false)
/*     */ final class ReactiveAuthorizationManagerMethodSecurityConfiguration
/*     */   implements AopInfrastructureBean, ApplicationContextAware
/*     */ {
/*  60 */   private static final Pointcut preFilterPointcut = (new PreFilterAuthorizationReactiveMethodInterceptor())
/*  61 */     .getPointcut();
/*     */ 
/*     */   
/*  64 */   private static final Pointcut preAuthorizePointcut = AuthorizationManagerBeforeReactiveMethodInterceptor.preAuthorize()
/*  65 */     .getPointcut();
/*     */ 
/*     */   
/*  68 */   private static final Pointcut postAuthorizePointcut = AuthorizationManagerAfterReactiveMethodInterceptor.postAuthorize()
/*  69 */     .getPointcut();
/*     */   
/*  71 */   private static final Pointcut postFilterPointcut = (new PostFilterAuthorizationReactiveMethodInterceptor())
/*  72 */     .getPointcut();
/*     */   
/*  74 */   private PreFilterAuthorizationReactiveMethodInterceptor preFilterMethodInterceptor = new PreFilterAuthorizationReactiveMethodInterceptor();
/*     */   
/*  76 */   private PreAuthorizeReactiveAuthorizationManager preAuthorizeAuthorizationManager = new PreAuthorizeReactiveAuthorizationManager();
/*     */   
/*  78 */   private PostAuthorizeReactiveAuthorizationManager postAuthorizeAuthorizationManager = new PostAuthorizeReactiveAuthorizationManager();
/*     */   
/*  80 */   private PostFilterAuthorizationReactiveMethodInterceptor postFilterMethodInterceptor = new PostFilterAuthorizationReactiveMethodInterceptor();
/*     */ 
/*     */   
/*     */   private final AuthorizationManagerBeforeReactiveMethodInterceptor preAuthorizeMethodInterceptor;
/*     */ 
/*     */   
/*     */   private final AuthorizationManagerAfterReactiveMethodInterceptor postAuthorizeMethodInterceptor;
/*     */ 
/*     */   
/*     */   ReactiveAuthorizationManagerMethodSecurityConfiguration(ObjectProvider<MethodSecurityExpressionHandler> expressionHandlers, ObjectProvider<ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocation>>> preAuthorizePostProcessor, ObjectProvider<ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocationResult>>> postAuthorizePostProcessor) {
/*  90 */     MethodSecurityExpressionHandler expressionHandler = (MethodSecurityExpressionHandler)expressionHandlers.getIfUnique();
/*  91 */     if (expressionHandler != null) {
/*  92 */       this.preFilterMethodInterceptor = new PreFilterAuthorizationReactiveMethodInterceptor(expressionHandler);
/*  93 */       this.preAuthorizeAuthorizationManager = new PreAuthorizeReactiveAuthorizationManager(expressionHandler);
/*  94 */       this.postFilterMethodInterceptor = new PostFilterAuthorizationReactiveMethodInterceptor(expressionHandler);
/*  95 */       this.postAuthorizeAuthorizationManager = new PostAuthorizeReactiveAuthorizationManager(expressionHandler);
/*     */     } 
/*     */ 
/*     */     
/*  99 */     ReactiveAuthorizationManager<MethodInvocation> preAuthorize = (ReactiveAuthorizationManager<MethodInvocation>)((ObjectPostProcessor)preAuthorizePostProcessor.getIfUnique(ObjectPostProcessor::identity)).postProcess(this.preAuthorizeAuthorizationManager);
/* 100 */     this
/* 101 */       .preAuthorizeMethodInterceptor = AuthorizationManagerBeforeReactiveMethodInterceptor.preAuthorize(preAuthorize);
/*     */ 
/*     */     
/* 104 */     ReactiveAuthorizationManager<MethodInvocationResult> postAuthorize = (ReactiveAuthorizationManager<MethodInvocationResult>)((ObjectPostProcessor)postAuthorizePostProcessor.getIfAvailable(ObjectPostProcessor::identity)).postProcess(this.postAuthorizeAuthorizationManager);
/* 105 */     this
/* 106 */       .postAuthorizeMethodInterceptor = AuthorizationManagerAfterReactiveMethodInterceptor.postAuthorize(postAuthorize);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) throws BeansException {
/* 111 */     this.preAuthorizeAuthorizationManager.setApplicationContext(context);
/* 112 */     this.postAuthorizeAuthorizationManager.setApplicationContext(context);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setTemplateDefaults(PrePostTemplateDefaults templateDefaults) {
/* 117 */     this.preFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/* 118 */     this.preAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 119 */     this.postAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 120 */     this.postFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/* 125 */     this.preFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/* 126 */     this.preAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 127 */     this.postAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 128 */     this.postFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor preFilterAuthorizationMethodInterceptor(ObjectProvider<ReactiveAuthorizationManagerMethodSecurityConfiguration> _reactiveMethodSecurityConfiguration) {
/* 135 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(preFilterPointcut, () -> ((ReactiveAuthorizationManagerMethodSecurityConfiguration)_reactiveMethodSecurityConfiguration.getObject()).preFilterMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor preAuthorizeAuthorizationMethodInterceptor(ObjectProvider<ReactiveAuthorizationManagerMethodSecurityConfiguration> _reactiveMethodSecurityConfiguration) {
/* 143 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(preAuthorizePointcut, () -> ((ReactiveAuthorizationManagerMethodSecurityConfiguration)_reactiveMethodSecurityConfiguration.getObject()).preAuthorizeMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor postFilterAuthorizationMethodInterceptor(ObjectProvider<ReactiveAuthorizationManagerMethodSecurityConfiguration> _reactiveMethodSecurityConfiguration) {
/* 151 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(postFilterPointcut, () -> ((ReactiveAuthorizationManagerMethodSecurityConfiguration)_reactiveMethodSecurityConfiguration.getObject()).postFilterMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor postAuthorizeAuthorizationMethodInterceptor(ObjectProvider<ReactiveAuthorizationManagerMethodSecurityConfiguration> _reactiveMethodSecurityConfiguration) {
/* 159 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(postAuthorizePointcut, () -> ((ReactiveAuthorizationManagerMethodSecurityConfiguration)_reactiveMethodSecurityConfiguration.getObject()).postAuthorizeMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   @Fallback
/*     */   static DefaultMethodSecurityExpressionHandler methodSecurityExpressionHandler(@Autowired(required = false) GrantedAuthorityDefaults grantedAuthorityDefaults) {
/* 168 */     DefaultMethodSecurityExpressionHandler handler = new DefaultMethodSecurityExpressionHandler();
/* 169 */     if (grantedAuthorityDefaults != null) {
/* 170 */       handler.setDefaultRolePrefix(grantedAuthorityDefaults.getRolePrefix());
/*     */     }
/* 172 */     return handler;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\ReactiveAuthorizationManagerMethodSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */