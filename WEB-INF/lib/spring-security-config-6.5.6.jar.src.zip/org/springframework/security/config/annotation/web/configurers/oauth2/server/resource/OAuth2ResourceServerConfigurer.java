/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.server.resource;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExceptionHandlingConfigurer;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.jwt.Jwt;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.OpaqueTokenAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenAuthenticationConverter;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.SpringOpaqueTokenIntrospector;
/*     */ import org.springframework.security.oauth2.server.resource.web.BearerTokenAuthenticationEntryPoint;
/*     */ import org.springframework.security.oauth2.server.resource.web.BearerTokenResolver;
/*     */ import org.springframework.security.oauth2.server.resource.web.DefaultBearerTokenResolver;
/*     */ import org.springframework.security.oauth2.server.resource.web.access.BearerTokenAccessDeniedHandler;
/*     */ import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.access.AccessDeniedHandler;
/*     */ import org.springframework.security.web.access.AccessDeniedHandlerImpl;
/*     */ import org.springframework.security.web.access.DelegatingAccessDeniedHandler;
/*     */ import org.springframework.security.web.csrf.CsrfException;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.HeaderContentNegotiationStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OAuth2ResourceServerConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<OAuth2ResourceServerConfigurer<H>, H>
/*     */ {
/*     */   private static final boolean dPoPAuthenticationAvailable;
/*     */   
/*     */   static {
/* 154 */     ClassLoader classLoader = OAuth2ResourceServerConfigurer.class.getClassLoader();
/*     */     
/* 156 */     dPoPAuthenticationAvailable = ClassUtils.isPresent("org.springframework.security.oauth2.jwt.DPoPProofJwtDecoderFactory", classLoader);
/*     */   }
/*     */   
/* 159 */   private static final RequestHeaderRequestMatcher X_REQUESTED_WITH = new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest");
/*     */ 
/*     */   
/*     */   private final ApplicationContext context;
/*     */   
/*     */   private AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver;
/*     */   
/*     */   private BearerTokenResolver bearerTokenResolver;
/*     */   
/*     */   private JwtConfigurer jwtConfigurer;
/*     */   
/*     */   private OpaqueTokenConfigurer opaqueTokenConfigurer;
/*     */   
/* 172 */   private AccessDeniedHandler accessDeniedHandler = (AccessDeniedHandler)new DelegatingAccessDeniedHandler(new LinkedHashMap<>(
/* 173 */         Map.of(CsrfException.class, new AccessDeniedHandlerImpl())), (AccessDeniedHandler)new BearerTokenAccessDeniedHandler());
/*     */ 
/*     */   
/* 176 */   private AuthenticationEntryPoint authenticationEntryPoint = (AuthenticationEntryPoint)new BearerTokenAuthenticationEntryPoint();
/*     */   
/* 178 */   private BearerTokenRequestMatcher requestMatcher = new BearerTokenRequestMatcher();
/*     */   
/*     */   public OAuth2ResourceServerConfigurer(ApplicationContext context) {
/* 181 */     Assert.notNull(context, "context cannot be null");
/* 182 */     this.context = context;
/*     */   }
/*     */   
/*     */   public OAuth2ResourceServerConfigurer<H> accessDeniedHandler(AccessDeniedHandler accessDeniedHandler) {
/* 186 */     Assert.notNull(accessDeniedHandler, "accessDeniedHandler cannot be null");
/* 187 */     this.accessDeniedHandler = accessDeniedHandler;
/* 188 */     return this;
/*     */   }
/*     */   
/*     */   public OAuth2ResourceServerConfigurer<H> authenticationEntryPoint(AuthenticationEntryPoint entryPoint) {
/* 192 */     Assert.notNull(entryPoint, "entryPoint cannot be null");
/* 193 */     this.authenticationEntryPoint = entryPoint;
/* 194 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public OAuth2ResourceServerConfigurer<H> authenticationManagerResolver(AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver) {
/* 199 */     Assert.notNull(authenticationManagerResolver, "authenticationManagerResolver cannot be null");
/* 200 */     this.authenticationManagerResolver = authenticationManagerResolver;
/* 201 */     return this;
/*     */   }
/*     */   
/*     */   public OAuth2ResourceServerConfigurer<H> bearerTokenResolver(BearerTokenResolver bearerTokenResolver) {
/* 205 */     Assert.notNull(bearerTokenResolver, "bearerTokenResolver cannot be null");
/* 206 */     this.bearerTokenResolver = bearerTokenResolver;
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public JwtConfigurer jwt() {
/* 218 */     if (this.jwtConfigurer == null) {
/* 219 */       this.jwtConfigurer = new JwtConfigurer(this.context);
/*     */     }
/* 221 */     return this.jwtConfigurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuth2ResourceServerConfigurer<H> jwt(Customizer<JwtConfigurer> jwtCustomizer) {
/* 231 */     if (this.jwtConfigurer == null) {
/* 232 */       this.jwtConfigurer = new JwtConfigurer(this.context);
/*     */     }
/* 234 */     jwtCustomizer.customize(this.jwtConfigurer);
/* 235 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public OpaqueTokenConfigurer opaqueToken() {
/* 247 */     if (this.opaqueTokenConfigurer == null) {
/* 248 */       this.opaqueTokenConfigurer = new OpaqueTokenConfigurer(this.context);
/*     */     }
/* 250 */     return this.opaqueTokenConfigurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuth2ResourceServerConfigurer<H> opaqueToken(Customizer<OpaqueTokenConfigurer> opaqueTokenCustomizer) {
/* 260 */     if (this.opaqueTokenConfigurer == null) {
/* 261 */       this.opaqueTokenConfigurer = new OpaqueTokenConfigurer(this.context);
/*     */     }
/* 263 */     opaqueTokenCustomizer.customize(this.opaqueTokenConfigurer);
/* 264 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 269 */     validateConfiguration();
/* 270 */     registerDefaultAccessDeniedHandler(http);
/* 271 */     registerDefaultEntryPoint(http);
/* 272 */     registerDefaultCsrfOverride(http);
/* 273 */     AuthenticationProvider authenticationProvider = getAuthenticationProvider();
/* 274 */     if (authenticationProvider != null) {
/* 275 */       http.authenticationProvider(authenticationProvider);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 281 */     BearerTokenResolver bearerTokenResolver = getBearerTokenResolver();
/* 282 */     this.requestMatcher.setBearerTokenResolver(bearerTokenResolver);
/* 283 */     AuthenticationManagerResolver<HttpServletRequest> resolver = this.authenticationManagerResolver;
/* 284 */     if (resolver == null) {
/* 285 */       AuthenticationManager authenticationManager = getAuthenticationManager(http);
/* 286 */       resolver = (request -> authenticationManager);
/*     */     } 
/*     */     
/* 289 */     BearerTokenAuthenticationFilter filter = new BearerTokenAuthenticationFilter(resolver);
/* 290 */     filter.setBearerTokenResolver(bearerTokenResolver);
/* 291 */     filter.setAuthenticationEntryPoint(this.authenticationEntryPoint);
/* 292 */     filter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 293 */     filter = (BearerTokenAuthenticationFilter)postProcess(filter);
/* 294 */     http.addFilter((Filter)filter);
/* 295 */     if (dPoPAuthenticationAvailable) {
/* 296 */       DPoPAuthenticationConfigurer<H> dPoPAuthenticationConfigurer = new DPoPAuthenticationConfigurer<>();
/* 297 */       dPoPAuthenticationConfigurer.configure(http);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateConfiguration() {
/* 302 */     if (this.authenticationManagerResolver == null) {
/* 303 */       Assert.state((this.jwtConfigurer != null || this.opaqueTokenConfigurer != null), "Jwt and Opaque Token are the only supported formats for bearer tokens in Spring Security and neither was found. Make sure to configure JWT via http.oauth2ResourceServer().jwt() or Opaque Tokens via http.oauth2ResourceServer().opaqueToken().");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 308 */       Assert.state((this.jwtConfigurer == null || this.opaqueTokenConfigurer == null), "Spring Security only supports JWTs or Opaque Tokens, not both at the same time.");
/*     */     }
/*     */     else {
/*     */       
/* 312 */       Assert.state((this.jwtConfigurer == null && this.opaqueTokenConfigurer == null), "If an authenticationManagerResolver() is configured, then it takes precedence over any jwt() or opaqueToken() configuration.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerDefaultAccessDeniedHandler(H http) {
/* 319 */     ExceptionHandlingConfigurer<H> exceptionHandling = (ExceptionHandlingConfigurer<H>)http.getConfigurer(ExceptionHandlingConfigurer.class);
/* 320 */     if (exceptionHandling != null) {
/* 321 */       exceptionHandling.defaultAccessDeniedHandlerFor(this.accessDeniedHandler, this.requestMatcher);
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerDefaultEntryPoint(H http) {
/* 326 */     ExceptionHandlingConfigurer<H> exceptionHandling = (ExceptionHandlingConfigurer<H>)http.getConfigurer(ExceptionHandlingConfigurer.class);
/* 327 */     if (exceptionHandling != null) {
/*     */       HeaderContentNegotiationStrategy headerContentNegotiationStrategy;
/* 329 */       ContentNegotiationStrategy contentNegotiationStrategy = (ContentNegotiationStrategy)http.getSharedObject(ContentNegotiationStrategy.class);
/* 330 */       if (contentNegotiationStrategy == null) {
/* 331 */         headerContentNegotiationStrategy = new HeaderContentNegotiationStrategy();
/*     */       }
/* 333 */       MediaTypeRequestMatcher restMatcher = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.APPLICATION_ATOM_XML, MediaType.APPLICATION_FORM_URLENCODED, MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA, MediaType.TEXT_XML });
/*     */ 
/*     */ 
/*     */       
/* 337 */       restMatcher.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 338 */       MediaTypeRequestMatcher allMatcher = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.ALL });
/* 339 */       allMatcher.setUseEquals(true);
/* 340 */       NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.TEXT_HTML }));
/*     */       
/* 342 */       AndRequestMatcher andRequestMatcher = new AndRequestMatcher(Arrays.asList(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)restMatcher }));
/*     */       
/* 344 */       OrRequestMatcher orRequestMatcher = new OrRequestMatcher(Arrays.asList(new RequestMatcher[] { this.requestMatcher, (RequestMatcher)X_REQUESTED_WITH, (RequestMatcher)andRequestMatcher, (RequestMatcher)allMatcher }));
/* 345 */       exceptionHandling.defaultAuthenticationEntryPointFor(this.authenticationEntryPoint, (RequestMatcher)orRequestMatcher);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerDefaultCsrfOverride(H http) {
/* 350 */     CsrfConfigurer<H> csrf = (CsrfConfigurer<H>)http.getConfigurer(CsrfConfigurer.class);
/* 351 */     if (csrf != null) {
/* 352 */       csrf.ignoringRequestMatchers(new RequestMatcher[] { this.requestMatcher });
/*     */     }
/*     */   }
/*     */   
/*     */   AuthenticationProvider getAuthenticationProvider() {
/* 357 */     if (this.jwtConfigurer != null) {
/* 358 */       return this.jwtConfigurer.getAuthenticationProvider();
/*     */     }
/* 360 */     if (this.opaqueTokenConfigurer != null) {
/* 361 */       return this.opaqueTokenConfigurer.getAuthenticationProvider();
/*     */     }
/* 363 */     return null;
/*     */   }
/*     */   
/*     */   AuthenticationManager getAuthenticationManager(H http) {
/* 367 */     if (this.jwtConfigurer != null) {
/* 368 */       return this.jwtConfigurer.getAuthenticationManager(http);
/*     */     }
/* 370 */     if (this.opaqueTokenConfigurer != null) {
/* 371 */       return this.opaqueTokenConfigurer.getAuthenticationManager(http);
/*     */     }
/* 373 */     return (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/*     */   }
/*     */   
/*     */   AuthenticationManagerResolver<HttpServletRequest> getAuthenticationManagerResolver() {
/* 377 */     return this.authenticationManagerResolver;
/*     */   }
/*     */   
/*     */   BearerTokenResolver getBearerTokenResolver() {
/* 381 */     if (this.bearerTokenResolver == null) {
/* 382 */       if ((this.context.getBeanNamesForType(BearerTokenResolver.class)).length > 0) {
/* 383 */         this.bearerTokenResolver = (BearerTokenResolver)this.context.getBean(BearerTokenResolver.class);
/*     */       } else {
/*     */         
/* 386 */         this.bearerTokenResolver = (BearerTokenResolver)new DefaultBearerTokenResolver();
/*     */       } 
/*     */     }
/* 389 */     return this.bearerTokenResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public class JwtConfigurer
/*     */   {
/*     */     private final ApplicationContext context;
/*     */     
/*     */     private AuthenticationManager authenticationManager;
/*     */     
/*     */     private JwtDecoder decoder;
/*     */     private Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter;
/*     */     
/*     */     JwtConfigurer(ApplicationContext context) {
/* 403 */       this.context = context;
/*     */     }
/*     */     
/*     */     public JwtConfigurer authenticationManager(AuthenticationManager authenticationManager) {
/* 407 */       Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 408 */       this.authenticationManager = authenticationManager;
/* 409 */       return this;
/*     */     }
/*     */     
/*     */     public JwtConfigurer decoder(JwtDecoder decoder) {
/* 413 */       this.decoder = decoder;
/* 414 */       return this;
/*     */     }
/*     */     
/*     */     public JwtConfigurer jwkSetUri(String uri) {
/* 418 */       this.decoder = (JwtDecoder)NimbusJwtDecoder.withJwkSetUri(uri).build();
/* 419 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public JwtConfigurer jwtAuthenticationConverter(Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter) {
/* 424 */       this.jwtAuthenticationConverter = jwtAuthenticationConverter;
/* 425 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public OAuth2ResourceServerConfigurer<H> and() {
/* 436 */       return OAuth2ResourceServerConfigurer.this;
/*     */     }
/*     */     
/*     */     Converter<Jwt, ? extends AbstractAuthenticationToken> getJwtAuthenticationConverter() {
/* 440 */       if (this.jwtAuthenticationConverter == null) {
/* 441 */         if ((this.context.getBeanNamesForType(JwtAuthenticationConverter.class)).length > 0) {
/* 442 */           this.jwtAuthenticationConverter = (Converter<Jwt, ? extends AbstractAuthenticationToken>)this.context.getBean(JwtAuthenticationConverter.class);
/*     */         } else {
/*     */           
/* 445 */           this.jwtAuthenticationConverter = (Converter<Jwt, ? extends AbstractAuthenticationToken>)new JwtAuthenticationConverter();
/*     */         } 
/*     */       }
/* 448 */       return this.jwtAuthenticationConverter;
/*     */     }
/*     */     
/*     */     JwtDecoder getJwtDecoder() {
/* 452 */       if (this.decoder == null) {
/* 453 */         return (JwtDecoder)this.context.getBean(JwtDecoder.class);
/*     */       }
/* 455 */       return this.decoder;
/*     */     }
/*     */     
/*     */     AuthenticationProvider getAuthenticationProvider() {
/* 459 */       if (this.authenticationManager != null) {
/* 460 */         return null;
/*     */       }
/* 462 */       JwtDecoder decoder = getJwtDecoder();
/* 463 */       Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter = getJwtAuthenticationConverter();
/* 464 */       JwtAuthenticationProvider provider = new JwtAuthenticationProvider(decoder);
/* 465 */       provider.setJwtAuthenticationConverter(jwtAuthenticationConverter);
/* 466 */       return (AuthenticationProvider)OAuth2ResourceServerConfigurer.this.postProcess(provider);
/*     */     }
/*     */     
/*     */     AuthenticationManager getAuthenticationManager(H http) {
/* 470 */       if (this.authenticationManager != null) {
/* 471 */         return this.authenticationManager;
/*     */       }
/* 473 */       return (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class OpaqueTokenConfigurer
/*     */   {
/*     */     private final ApplicationContext context;
/*     */     
/*     */     private AuthenticationManager authenticationManager;
/*     */     
/*     */     private String introspectionUri;
/*     */     
/*     */     private String clientId;
/*     */     
/*     */     private String clientSecret;
/*     */     
/*     */     private Supplier<OpaqueTokenIntrospector> introspector;
/*     */     
/*     */     private OpaqueTokenAuthenticationConverter authenticationConverter;
/*     */     
/*     */     OpaqueTokenConfigurer(ApplicationContext context) {
/* 495 */       this.context = context;
/*     */     }
/*     */     
/*     */     public OpaqueTokenConfigurer authenticationManager(AuthenticationManager authenticationManager) {
/* 499 */       Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 500 */       this.authenticationManager = authenticationManager;
/* 501 */       return this;
/*     */     }
/*     */     
/*     */     public OpaqueTokenConfigurer introspectionUri(String introspectionUri) {
/* 505 */       Assert.notNull(introspectionUri, "introspectionUri cannot be null");
/* 506 */       this.introspectionUri = introspectionUri;
/* 507 */       this.introspector = (() -> new SpringOpaqueTokenIntrospector(this.introspectionUri, this.clientId, this.clientSecret));
/*     */       
/* 509 */       return this;
/*     */     }
/*     */     
/*     */     public OpaqueTokenConfigurer introspectionClientCredentials(String clientId, String clientSecret) {
/* 513 */       Assert.notNull(clientId, "clientId cannot be null");
/* 514 */       Assert.notNull(clientSecret, "clientSecret cannot be null");
/* 515 */       this.clientId = clientId;
/* 516 */       this.clientSecret = clientSecret;
/* 517 */       this.introspector = (() -> new SpringOpaqueTokenIntrospector(this.introspectionUri, this.clientId, this.clientSecret));
/*     */       
/* 519 */       return this;
/*     */     }
/*     */     
/*     */     public OpaqueTokenConfigurer introspector(OpaqueTokenIntrospector introspector) {
/* 523 */       Assert.notNull(introspector, "introspector cannot be null");
/* 524 */       this.introspector = (() -> introspector);
/* 525 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public OpaqueTokenConfigurer authenticationConverter(OpaqueTokenAuthenticationConverter authenticationConverter) {
/* 530 */       Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 531 */       this.authenticationConverter = authenticationConverter;
/* 532 */       return this;
/*     */     }
/*     */     
/*     */     OpaqueTokenIntrospector getIntrospector() {
/* 536 */       if (this.introspector != null) {
/* 537 */         return this.introspector.get();
/*     */       }
/* 539 */       return (OpaqueTokenIntrospector)this.context.getBean(OpaqueTokenIntrospector.class);
/*     */     }
/*     */     
/*     */     OpaqueTokenAuthenticationConverter getAuthenticationConverter() {
/* 543 */       if (this.authenticationConverter != null) {
/* 544 */         return this.authenticationConverter;
/*     */       }
/* 546 */       if ((this.context.getBeanNamesForType(OpaqueTokenAuthenticationConverter.class)).length > 0) {
/* 547 */         return (OpaqueTokenAuthenticationConverter)this.context.getBean(OpaqueTokenAuthenticationConverter.class);
/*     */       }
/* 549 */       return null;
/*     */     }
/*     */     
/*     */     AuthenticationProvider getAuthenticationProvider() {
/* 553 */       if (this.authenticationManager != null) {
/* 554 */         return null;
/*     */       }
/* 556 */       OpaqueTokenIntrospector introspector = getIntrospector();
/* 557 */       OpaqueTokenAuthenticationProvider opaqueTokenAuthenticationProvider = new OpaqueTokenAuthenticationProvider(introspector);
/*     */       
/* 559 */       OpaqueTokenAuthenticationConverter authenticationConverter = getAuthenticationConverter();
/* 560 */       if (authenticationConverter != null) {
/* 561 */         opaqueTokenAuthenticationProvider.setAuthenticationConverter(authenticationConverter);
/*     */       }
/* 563 */       return (AuthenticationProvider)opaqueTokenAuthenticationProvider;
/*     */     }
/*     */     
/*     */     AuthenticationManager getAuthenticationManager(H http) {
/* 567 */       if (this.authenticationManager != null) {
/* 568 */         return this.authenticationManager;
/*     */       }
/* 570 */       return (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class BearerTokenRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     private BearerTokenResolver bearerTokenResolver;
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/*     */       try {
/* 582 */         return (this.bearerTokenResolver.resolve(request) != null);
/*     */       }
/* 584 */       catch (OAuth2AuthenticationException ex) {
/* 585 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     void setBearerTokenResolver(BearerTokenResolver tokenResolver) {
/* 590 */       Assert.notNull(tokenResolver, "resolver cannot be null");
/* 591 */       this.bearerTokenResolver = tokenResolver;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\server\resource\OAuth2ResourceServerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */