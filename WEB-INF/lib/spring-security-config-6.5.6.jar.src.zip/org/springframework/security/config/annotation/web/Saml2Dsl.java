/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LoginConfigurer;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000X\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\020\013\n\002\b\020\n\002\030\002\n\002\b\005\n\002\020\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\026\0203\032\002042\006\0203\032\0020\0202\006\0205\032\0020\035J\037\0206\032\024\022\n\022\b\022\004\022\0020908\022\004\022\0020407H\000¢\006\002\b:J\006\020'\032\00204R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\034\020\017\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024R\034\020\025\032\004\030\0010\026X\016¢\006\016\n\000\032\004\b\027\020\030\"\004\b\031\020\032R\034\020\033\032\020\022\004\022\0020\020\022\004\022\0020\035\030\0010\034X\016¢\006\002\n\000R\034\020\036\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\037\020\022\"\004\b \020\024R\034\020!\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\"\020\022\"\004\b#\020\024R\034\020$\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b%\020\022\"\004\b&\020\024R\036\020'\032\004\030\0010\035X\016¢\006\020\n\002\020,\032\004\b(\020)\"\004\b*\020+R\034\020-\032\004\030\0010.X\016¢\006\016\n\000\032\004\b/\0200\"\004\b1\0202¨\006;"}, d2 = {"Lorg/springframework/security/config/annotation/web/Saml2Dsl;", "", "()V", "authenticationFailureHandler", "Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "getAuthenticationFailureHandler", "()Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "setAuthenticationFailureHandler", "(Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;)V", "authenticationManager", "Lorg/springframework/security/authentication/AuthenticationManager;", "getAuthenticationManager", "()Lorg/springframework/security/authentication/AuthenticationManager;", "setAuthenticationManager", "(Lorg/springframework/security/authentication/AuthenticationManager;)V", "authenticationRequestUriQuery", "", "getAuthenticationRequestUriQuery", "()Ljava/lang/String;", "setAuthenticationRequestUriQuery", "(Ljava/lang/String;)V", "authenticationSuccessHandler", "Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "getAuthenticationSuccessHandler", "()Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "setAuthenticationSuccessHandler", "(Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;)V", "defaultSuccessUrlOption", "Lkotlin/Pair;", "", "failureUrl", "getFailureUrl", "setFailureUrl", "loginPage", "getLoginPage", "setLoginPage", "loginProcessingUrl", "getLoginProcessingUrl", "setLoginProcessingUrl", "permitAll", "getPermitAll", "()Ljava/lang/Boolean;", "setPermitAll", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "relyingPartyRegistrationRepository", "Lorg/springframework/security/saml2/provider/service/registration/RelyingPartyRegistrationRepository;", "getRelyingPartyRegistrationRepository", "()Lorg/springframework/security/saml2/provider/service/registration/RelyingPartyRegistrationRepository;", "setRelyingPartyRegistrationRepository", "(Lorg/springframework/security/saml2/provider/service/registration/RelyingPartyRegistrationRepository;)V", "defaultSuccessUrl", "", "alwaysUse", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*     */ public final class Saml2Dsl
/*     */ {
/*     */   @Nullable
/*     */   private RelyingPartyRegistrationRepository relyingPartyRegistrationRepository;
/*     */   @Nullable
/*     */   private String loginPage;
/*     */   @Nullable
/*     */   private String authenticationRequestUriQuery;
/*     */   @Nullable
/*     */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*     */   @Nullable
/*     */   private AuthenticationFailureHandler authenticationFailureHandler;
/*     */   @Nullable
/*     */   private String failureUrl;
/*     */   @Nullable
/*     */   private String loginProcessingUrl;
/*     */   @Nullable
/*     */   private Boolean permitAll;
/*     */   @Nullable
/*     */   private AuthenticationManager authenticationManager;
/*     */   @Nullable
/*     */   private Pair<String, Boolean> defaultSuccessUrlOption;
/*     */   
/*     */   @Nullable
/*     */   public final RelyingPartyRegistrationRepository getRelyingPartyRegistrationRepository() {
/*  49 */     return this.relyingPartyRegistrationRepository; } public final void setRelyingPartyRegistrationRepository(@Nullable RelyingPartyRegistrationRepository <set-?>) { this.relyingPartyRegistrationRepository = <set-?>; } @Nullable
/*  50 */   public final String getLoginPage() { return this.loginPage; } public final void setLoginPage(@Nullable String <set-?>) { this.loginPage = <set-?>; } @Nullable
/*  51 */   public final String getAuthenticationRequestUriQuery() { return this.authenticationRequestUriQuery; } public final void setAuthenticationRequestUriQuery(@Nullable String <set-?>) { this.authenticationRequestUriQuery = <set-?>; } @Nullable
/*  52 */   public final AuthenticationSuccessHandler getAuthenticationSuccessHandler() { return this.authenticationSuccessHandler; } public final void setAuthenticationSuccessHandler(@Nullable AuthenticationSuccessHandler <set-?>) { this.authenticationSuccessHandler = <set-?>; } @Nullable
/*  53 */   public final AuthenticationFailureHandler getAuthenticationFailureHandler() { return this.authenticationFailureHandler; } public final void setAuthenticationFailureHandler(@Nullable AuthenticationFailureHandler <set-?>) { this.authenticationFailureHandler = <set-?>; } @Nullable
/*  54 */   public final String getFailureUrl() { return this.failureUrl; } public final void setFailureUrl(@Nullable String <set-?>) { this.failureUrl = <set-?>; } @Nullable
/*  55 */   public final String getLoginProcessingUrl() { return this.loginProcessingUrl; } public final void setLoginProcessingUrl(@Nullable String <set-?>) { this.loginProcessingUrl = <set-?>; } @Nullable
/*  56 */   public final Boolean getPermitAll() { return this.permitAll; } public final void setPermitAll(@Nullable Boolean <set-?>) { this.permitAll = <set-?>; } @Nullable
/*  57 */   public final AuthenticationManager getAuthenticationManager() { return this.authenticationManager; } public final void setAuthenticationManager(@Nullable AuthenticationManager <set-?>) { this.authenticationManager = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void permitAll() {
/*  66 */     this.permitAll = Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void defaultSuccessUrl(@NotNull String defaultSuccessUrl, boolean alwaysUse) {
/*  79 */     Intrinsics.checkNotNullParameter(defaultSuccessUrl, "defaultSuccessUrl"); this.defaultSuccessUrlOption = new Pair(defaultSuccessUrl, Boolean.valueOf(alwaysUse));
/*     */   }
/*     */   
/*     */   @NotNull
/*  83 */   public final Function1<Saml2LoginConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new Saml2Dsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "saml2Login", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nSaml2Dsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Saml2Dsl.kt\norg/springframework/security/config/annotation/web/Saml2Dsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,101:1\n1#2:102\n*E\n"})
/*  84 */   static final class Saml2Dsl$get$1 extends Lambda implements Function1<Saml2LoginConfigurer<HttpSecurity>, Unit> { public final void invoke(Saml2LoginConfigurer saml2Login) { Intrinsics.checkNotNullParameter(saml2Login, "saml2Login"); if (Saml2Dsl.this.getRelyingPartyRegistrationRepository() != null) { RelyingPartyRegistrationRepository relyingPartyRegistrationRepository1 = Saml2Dsl.this.getRelyingPartyRegistrationRepository(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; RelyingPartyRegistrationRepository relyingPartyRegistrationRepository2 = relyingPartyRegistrationRepository1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 102 */         int $i$a$-also-Saml2Dsl$get$1$1 = 0; saml2Login.relyingPartyRegistrationRepository(saml2Dsl1.getRelyingPartyRegistrationRepository()); } else { Saml2Dsl.this.getRelyingPartyRegistrationRepository(); }  if (Saml2Dsl.this.getLoginPage() != null) { String str2 = Saml2Dsl.this.getLoginPage(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; String str3 = str2; int $i$a$-also-Saml2Dsl$get$1$2 = 0; saml2Login.loginPage(saml2Dsl1.getLoginPage()); } else { Saml2Dsl.this.getLoginPage(); }  if (Saml2Dsl.this.getFailureUrl() != null) { String str2 = Saml2Dsl.this.getFailureUrl(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; String str3 = str2; int $i$a$-also-Saml2Dsl$get$1$3 = 0; saml2Login.failureUrl(saml2Dsl1.getFailureUrl()); } else { Saml2Dsl.this.getFailureUrl(); }  if (Saml2Dsl.this.getLoginProcessingUrl() != null) { String str2 = Saml2Dsl.this.getLoginProcessingUrl(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; String str3 = str2; int $i$a$-also-Saml2Dsl$get$1$4 = 0; saml2Login.loginProcessingUrl(saml2Dsl1.getLoginProcessingUrl()); } else { Saml2Dsl.this.getLoginProcessingUrl(); }  if (Saml2Dsl.this.getPermitAll() != null) { Boolean bool = Saml2Dsl.this.getPermitAll(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-Saml2Dsl$get$1$5 = 0; Intrinsics.checkNotNull(saml2Dsl1.getPermitAll()); saml2Login.permitAll(saml2Dsl1.getPermitAll().booleanValue()); } else { Saml2Dsl.this.getPermitAll(); }  Pair pair1 = Saml2Dsl.this.defaultSuccessUrlOption; Saml2Dsl saml2Dsl = Saml2Dsl.this; Pair pair2 = pair1; int $i$a$-also-Saml2Dsl$get$1$6 = 0; Intrinsics.checkNotNull(saml2Dsl.defaultSuccessUrlOption); Intrinsics.checkNotNull(saml2Dsl.defaultSuccessUrlOption); saml2Login.defaultSuccessUrl((String)saml2Dsl.defaultSuccessUrlOption.getFirst(), ((Boolean)saml2Dsl.defaultSuccessUrlOption.getSecond()).booleanValue()); Saml2Dsl.this.defaultSuccessUrlOption; String str1 = Saml2Dsl.this.getAuthenticationRequestUriQuery(); saml2Dsl = Saml2Dsl.this; String it = str1; int $i$a$-also-Saml2Dsl$get$1$7 = 0; saml2Login.authenticationRequestUriQuery(saml2Dsl.getAuthenticationRequestUriQuery()); Saml2Dsl.this.getAuthenticationRequestUriQuery(); if (Saml2Dsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = Saml2Dsl.this.getAuthenticationSuccessHandler(); saml2Dsl = Saml2Dsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-Saml2Dsl$get$1$8 = 0; saml2Login.successHandler(saml2Dsl.getAuthenticationSuccessHandler()); } else { Saml2Dsl.this.getAuthenticationSuccessHandler(); }  if (Saml2Dsl.this.getAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = Saml2Dsl.this.getAuthenticationFailureHandler(); saml2Dsl = Saml2Dsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-Saml2Dsl$get$1$9 = 0; saml2Login.failureHandler(saml2Dsl.getAuthenticationFailureHandler()); } else { Saml2Dsl.this.getAuthenticationFailureHandler(); }  if (Saml2Dsl.this.getAuthenticationManager() != null) { AuthenticationManager authenticationManager1 = Saml2Dsl.this.getAuthenticationManager(); saml2Dsl = Saml2Dsl.this; AuthenticationManager authenticationManager2 = authenticationManager1; int $i$a$-also-Saml2Dsl$get$1$10 = 0;
/*     */         saml2Login.authenticationManager(saml2Dsl.getAuthenticationManager()); }
/*     */       else
/*     */       { Saml2Dsl.this.getAuthenticationManager(); }
/*     */        }
/*     */ 
/*     */     
/*     */     Saml2Dsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\Saml2Dsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */