/*    */ package org.springframework.security.config.annotation.authentication.configuration;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.config.annotation.SecurityBuilder;
/*    */ import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147478547)
/*    */ class InitializeAuthenticationProviderBeanManagerConfigurer
/*    */   extends GlobalAuthenticationConfigurerAdapter
/*    */ {
/*    */   static final int DEFAULT_ORDER = 2147478547;
/*    */   private final ApplicationContext context;
/*    */   
/*    */   InitializeAuthenticationProviderBeanManagerConfigurer(ApplicationContext context) {
/* 48 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(AuthenticationManagerBuilder auth) throws Exception {
/* 53 */     auth.apply(new InitializeAuthenticationProviderManagerConfigurer());
/*    */   }
/*    */   
/*    */   class InitializeAuthenticationProviderManagerConfigurer
/*    */     extends GlobalAuthenticationConfigurerAdapter {
/* 58 */     private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */     
/*    */     public void configure(AuthenticationManagerBuilder auth) {
/* 62 */       if (auth.isConfigured()) {
/*    */         return;
/*    */       }
/*    */       
/* 66 */       String[] beanNames = InitializeAuthenticationProviderBeanManagerConfigurer.this.context.getBeanNamesForType(AuthenticationProvider.class);
/* 67 */       if (beanNames.length == 0) {
/*    */         return;
/*    */       }
/* 70 */       if (beanNames.length > 1) {
/* 71 */         this.logger.info(LogMessage.format("Found %s AuthenticationProvider beans, with names %s. Global Authentication Manager will not be configured with AuthenticationProviders. Consider publishing a single AuthenticationProvider bean, or wiring your Providers directly using the DSL.", 
/*    */ 
/*    */               
/* 74 */               Integer.valueOf(beanNames.length), Arrays.toString((Object[])beanNames)));
/*    */         
/*    */         return;
/*    */       } 
/* 78 */       AuthenticationProvider authenticationProvider = (AuthenticationProvider)InitializeAuthenticationProviderBeanManagerConfigurer.this.context.getBean(beanNames[0], AuthenticationProvider.class);
/* 79 */       auth.authenticationProvider(authenticationProvider);
/* 80 */       this.logger.info(LogMessage.format("Global AuthenticationManager configured with AuthenticationProvider bean with name %s", beanNames[0]));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configuration\InitializeAuthenticationProviderBeanManagerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */