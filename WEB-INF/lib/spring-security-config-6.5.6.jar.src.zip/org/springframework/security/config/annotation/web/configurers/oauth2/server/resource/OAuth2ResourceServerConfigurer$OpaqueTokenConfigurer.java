/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.server.resource;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.OpaqueTokenAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenAuthenticationConverter;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.SpringOpaqueTokenIntrospector;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpaqueTokenConfigurer
/*     */ {
/*     */   private final ApplicationContext context;
/*     */   private AuthenticationManager authenticationManager;
/*     */   private String introspectionUri;
/*     */   private String clientId;
/*     */   private String clientSecret;
/*     */   private Supplier<OpaqueTokenIntrospector> introspector;
/*     */   private OpaqueTokenAuthenticationConverter authenticationConverter;
/*     */   
/*     */   OpaqueTokenConfigurer(ApplicationContext context) {
/* 495 */     this.context = context;
/*     */   }
/*     */   
/*     */   public OpaqueTokenConfigurer authenticationManager(AuthenticationManager authenticationManager) {
/* 499 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 500 */     this.authenticationManager = authenticationManager;
/* 501 */     return this;
/*     */   }
/*     */   
/*     */   public OpaqueTokenConfigurer introspectionUri(String introspectionUri) {
/* 505 */     Assert.notNull(introspectionUri, "introspectionUri cannot be null");
/* 506 */     this.introspectionUri = introspectionUri;
/* 507 */     this.introspector = (() -> new SpringOpaqueTokenIntrospector(this.introspectionUri, this.clientId, this.clientSecret));
/*     */     
/* 509 */     return this;
/*     */   }
/*     */   
/*     */   public OpaqueTokenConfigurer introspectionClientCredentials(String clientId, String clientSecret) {
/* 513 */     Assert.notNull(clientId, "clientId cannot be null");
/* 514 */     Assert.notNull(clientSecret, "clientSecret cannot be null");
/* 515 */     this.clientId = clientId;
/* 516 */     this.clientSecret = clientSecret;
/* 517 */     this.introspector = (() -> new SpringOpaqueTokenIntrospector(this.introspectionUri, this.clientId, this.clientSecret));
/*     */     
/* 519 */     return this;
/*     */   }
/*     */   
/*     */   public OpaqueTokenConfigurer introspector(OpaqueTokenIntrospector introspector) {
/* 523 */     Assert.notNull(introspector, "introspector cannot be null");
/* 524 */     this.introspector = (() -> introspector);
/* 525 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public OpaqueTokenConfigurer authenticationConverter(OpaqueTokenAuthenticationConverter authenticationConverter) {
/* 530 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 531 */     this.authenticationConverter = authenticationConverter;
/* 532 */     return this;
/*     */   }
/*     */   
/*     */   OpaqueTokenIntrospector getIntrospector() {
/* 536 */     if (this.introspector != null) {
/* 537 */       return this.introspector.get();
/*     */     }
/* 539 */     return (OpaqueTokenIntrospector)this.context.getBean(OpaqueTokenIntrospector.class);
/*     */   }
/*     */   
/*     */   OpaqueTokenAuthenticationConverter getAuthenticationConverter() {
/* 543 */     if (this.authenticationConverter != null) {
/* 544 */       return this.authenticationConverter;
/*     */     }
/* 546 */     if ((this.context.getBeanNamesForType(OpaqueTokenAuthenticationConverter.class)).length > 0) {
/* 547 */       return (OpaqueTokenAuthenticationConverter)this.context.getBean(OpaqueTokenAuthenticationConverter.class);
/*     */     }
/* 549 */     return null;
/*     */   }
/*     */   
/*     */   AuthenticationProvider getAuthenticationProvider() {
/* 553 */     if (this.authenticationManager != null) {
/* 554 */       return null;
/*     */     }
/* 556 */     OpaqueTokenIntrospector introspector = getIntrospector();
/* 557 */     OpaqueTokenAuthenticationProvider opaqueTokenAuthenticationProvider = new OpaqueTokenAuthenticationProvider(introspector);
/*     */     
/* 559 */     OpaqueTokenAuthenticationConverter authenticationConverter = getAuthenticationConverter();
/* 560 */     if (authenticationConverter != null) {
/* 561 */       opaqueTokenAuthenticationProvider.setAuthenticationConverter(authenticationConverter);
/*     */     }
/* 563 */     return (AuthenticationProvider)opaqueTokenAuthenticationProvider;
/*     */   }
/*     */   
/*     */   AuthenticationManager getAuthenticationManager(H http) {
/* 567 */     if (this.authenticationManager != null) {
/* 568 */       return this.authenticationManager;
/*     */     }
/* 570 */     return (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\server\resource\OAuth2ResourceServerConfigurer$OpaqueTokenConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */