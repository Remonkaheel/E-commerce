/*    */ package org.springframework.security.config.annotation.web.configurers;
/*    */ 
/*    */ import jakarta.servlet.Filter;
/*    */ import org.springframework.security.config.annotation.SecurityBuilder;
/*    */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*    */ import org.springframework.security.web.PortMapper;
/*    */ import org.springframework.security.web.transport.HttpsRedirectFilter;
/*    */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpsRedirectConfigurer<H extends HttpSecurityBuilder<H>>
/*    */   extends AbstractHttpConfigurer<HeadersConfigurer<H>, H>
/*    */ {
/*    */   private RequestMatcher requestMatcher;
/*    */   
/*    */   public HttpsRedirectConfigurer<H> requestMatchers(RequestMatcher... matchers) {
/* 59 */     this.requestMatcher = (RequestMatcher)new OrRequestMatcher(matchers);
/* 60 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void configure(H http) throws Exception {
/* 65 */     HttpsRedirectFilter filter = new HttpsRedirectFilter();
/* 66 */     if (this.requestMatcher != null) {
/* 67 */       filter.setRequestMatcher(this.requestMatcher);
/*    */     }
/* 69 */     PortMapper mapper = (PortMapper)http.getSharedObject(PortMapper.class);
/* 70 */     if (mapper != null) {
/* 71 */       filter.setPortMapper(mapper);
/*    */     }
/* 73 */     http.addFilter((Filter)filter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\HttpsRedirectConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */