/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServletApiConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<ServletApiConfigurer<H>, H>
/*     */ {
/*  65 */   private SecurityContextHolderAwareRequestFilter securityContextRequestFilter = new SecurityContextHolderAwareRequestFilter();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletApiConfigurer<H> rolePrefix(String rolePrefix) {
/*  75 */     this.securityContextRequestFilter.setRolePrefix(rolePrefix);
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/*  82 */     this.securityContextRequestFilter.setAuthenticationManager((AuthenticationManager)http.getSharedObject(AuthenticationManager.class));
/*  83 */     ExceptionHandlingConfigurer<H> exceptionConf = (ExceptionHandlingConfigurer<H>)http.getConfigurer(ExceptionHandlingConfigurer.class);
/*     */     
/*  85 */     AuthenticationEntryPoint authenticationEntryPoint = (exceptionConf != null) ? exceptionConf.getAuthenticationEntryPoint(http) : null;
/*  86 */     this.securityContextRequestFilter.setAuthenticationEntryPoint(authenticationEntryPoint);
/*  87 */     LogoutConfigurer<H> logoutConf = (LogoutConfigurer<H>)http.getConfigurer(LogoutConfigurer.class);
/*  88 */     List<LogoutHandler> logoutHandlers = (logoutConf != null) ? logoutConf.getLogoutHandlers() : null;
/*  89 */     this.securityContextRequestFilter.setLogoutHandlers(logoutHandlers);
/*  90 */     AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)http.getSharedObject(AuthenticationTrustResolver.class);
/*  91 */     if (trustResolver != null) {
/*  92 */       this.securityContextRequestFilter.setTrustResolver(trustResolver);
/*     */     }
/*  94 */     ApplicationContext context = (ApplicationContext)http.getSharedObject(ApplicationContext.class);
/*  95 */     if (context != null) {
/*  96 */       context.getBeanProvider(GrantedAuthorityDefaults.class)
/*  97 */         .ifUnique(grantedAuthorityDefaults -> this.securityContextRequestFilter.setRolePrefix(grantedAuthorityDefaults.getRolePrefix()));
/*     */       
/*  99 */       this.securityContextRequestFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/*     */     } 
/* 101 */     this.securityContextRequestFilter = (SecurityContextHolderAwareRequestFilter)postProcess(this.securityContextRequestFilter);
/* 102 */     http.addFilter((Filter)this.securityContextRequestFilter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\ServletApiConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */