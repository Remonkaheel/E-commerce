/*    */ package org.springframework.security.config.annotation.web.configuration;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OAuth2ImportSelector
/*    */   implements ImportSelector
/*    */ {
/*    */   public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 48 */     Set<String> imports = new LinkedHashSet<>();
/* 49 */     ClassLoader classLoader = getClass().getClassLoader();
/*    */     
/* 51 */     boolean oauth2ClientPresent = ClassUtils.isPresent("org.springframework.security.oauth2.client.registration.ClientRegistration", classLoader);
/*    */     
/* 53 */     boolean webfluxPresent = ClassUtils.isPresent("org.springframework.web.reactive.function.client.ExchangeFilterFunction", classLoader);
/*    */     
/* 55 */     boolean oauth2ResourceServerPresent = ClassUtils.isPresent("org.springframework.security.oauth2.server.resource.BearerTokenError", classLoader);
/* 56 */     if (oauth2ClientPresent) {
/* 57 */       imports.add("org.springframework.security.config.annotation.web.configuration.OAuth2ClientConfiguration");
/*    */     }
/* 59 */     if (webfluxPresent && oauth2ClientPresent) {
/* 60 */       imports.add("org.springframework.security.config.annotation.web.configuration.SecurityReactorContextConfiguration");
/*    */     }
/*    */     
/* 63 */     if (webfluxPresent && oauth2ResourceServerPresent) {
/* 64 */       imports.add("org.springframework.security.config.annotation.web.configuration.SecurityReactorContextConfiguration");
/*    */     }
/*    */     
/* 67 */     return StringUtils.toStringArray(imports);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\OAuth2ImportSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */