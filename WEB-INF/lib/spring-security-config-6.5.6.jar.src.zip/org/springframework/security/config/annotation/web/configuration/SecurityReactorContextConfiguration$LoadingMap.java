/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LoadingMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/* 206 */   private final Map<K, V> loaded = new ConcurrentHashMap<>();
/*     */   
/*     */   private final Map<K, Supplier<V>> loaders;
/*     */   
/*     */   LoadingMap(Map<K, Supplier<V>> loaders) {
/* 211 */     this.loaders = Collections.unmodifiableMap(new HashMap<>(loaders));
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 216 */     return this.loaders.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 221 */     return this.loaders.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 226 */     return this.loaders.containsKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 231 */     return this.loaders.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 236 */     if (!this.loaders.containsKey(key)) {
/* 237 */       throw new IllegalArgumentException("This map only supports the following keys: " + 
/* 238 */           String.valueOf(this.loaders.keySet()));
/*     */     }
/* 240 */     return this.loaded.computeIfAbsent((K)key, k -> ((Supplier)this.loaders.get(k)).get());
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 245 */     if (!this.loaders.containsKey(key)) {
/* 246 */       throw new IllegalArgumentException("This map only supports the following keys: " + 
/* 247 */           String.valueOf(this.loaders.keySet()));
/*     */     }
/* 249 */     return this.loaded.put(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 254 */     if (!this.loaders.containsKey(key)) {
/* 255 */       throw new IllegalArgumentException("This map only supports the following keys: " + 
/* 256 */           String.valueOf(this.loaders.keySet()));
/*     */     }
/* 258 */     return this.loaded.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/* 263 */     for (Map.Entry<? extends K, ? extends V> entry : m.entrySet()) {
/* 264 */       put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 270 */     this.loaded.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 275 */     return this.loaded.containsValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 280 */     return this.loaded.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 285 */     return this.loaded.entrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 290 */     if (this == o) {
/* 291 */       return true;
/*     */     }
/* 293 */     if (o == null || getClass() != o.getClass()) {
/* 294 */       return false;
/*     */     }
/*     */     
/* 297 */     LoadingMap<?, ?> that = (LoadingMap<?, ?>)o;
/*     */     
/* 299 */     return this.loaded.equals(that.loaded);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 304 */     return this.loaded.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\SecurityReactorContextConfiguration$LoadingMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */