/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.ExceptionHandlingConfigurer;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ import org.springframework.security.web.access.AccessDeniedHandler;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000N\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\020\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\026\020\033\032\0020\0342\006\020\035\032\0020\0042\006\020\036\032\0020\027J\026\020\037\032\0020\0342\006\020 \032\0020\0202\006\020\036\032\0020\027J\006\020!\032\0020\034J\037\020\"\032\024\022\n\022\b\022\004\022\0020%0$\022\004\022\0020\0340#H\000¢\006\002\b&R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\034\020\017\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024R\032\020\025\032\016\022\004\022\0020\027\022\004\022\0020\0040\026X\016¢\006\002\n\000R\032\020\030\032\016\022\004\022\0020\027\022\004\022\0020\0200\026X\016¢\006\002\n\000R\016\020\031\032\0020\032X\016¢\006\002\n\000¨\006'"}, d2 = {"Lorg/springframework/security/config/annotation/web/ExceptionHandlingDsl;", "", "()V", "accessDeniedHandler", "Lorg/springframework/security/web/access/AccessDeniedHandler;", "getAccessDeniedHandler", "()Lorg/springframework/security/web/access/AccessDeniedHandler;", "setAccessDeniedHandler", "(Lorg/springframework/security/web/access/AccessDeniedHandler;)V", "accessDeniedPage", "", "getAccessDeniedPage", "()Ljava/lang/String;", "setAccessDeniedPage", "(Ljava/lang/String;)V", "authenticationEntryPoint", "Lorg/springframework/security/web/AuthenticationEntryPoint;", "getAuthenticationEntryPoint", "()Lorg/springframework/security/web/AuthenticationEntryPoint;", "setAuthenticationEntryPoint", "(Lorg/springframework/security/web/AuthenticationEntryPoint;)V", "defaultDeniedHandlerMappings", "Ljava/util/LinkedHashMap;", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "defaultEntryPointMappings", "disabled", "", "defaultAccessDeniedHandlerFor", "", "deniedHandler", "preferredMatcher", "defaultAuthenticationEntryPointFor", "entryPoint", "disable", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/ExceptionHandlingConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class ExceptionHandlingDsl
/*    */ {
/*    */   @Nullable
/*    */   private String accessDeniedPage;
/*    */   @Nullable
/*    */   private AccessDeniedHandler accessDeniedHandler;
/*    */   @Nullable
/*    */   private AuthenticationEntryPoint authenticationEntryPoint;
/*    */   
/*    */   @Nullable
/*    */   public final String getAccessDeniedPage() {
/* 38 */     return this.accessDeniedPage; } public final void setAccessDeniedPage(@Nullable String <set-?>) { this.accessDeniedPage = <set-?>; } @Nullable
/* 39 */   public final AccessDeniedHandler getAccessDeniedHandler() { return this.accessDeniedHandler; } public final void setAccessDeniedHandler(@Nullable AccessDeniedHandler <set-?>) { this.accessDeniedHandler = <set-?>; } @Nullable
/* 40 */   public final AuthenticationEntryPoint getAuthenticationEntryPoint() { return this.authenticationEntryPoint; } public final void setAuthenticationEntryPoint(@Nullable AuthenticationEntryPoint <set-?>) { this.authenticationEntryPoint = <set-?>; }
/*    */    @NotNull
/* 42 */   private LinkedHashMap<RequestMatcher, AccessDeniedHandler> defaultDeniedHandlerMappings = new LinkedHashMap<>(); @NotNull
/* 43 */   private LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> defaultEntryPointMappings = new LinkedHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean disabled;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void defaultAccessDeniedHandlerFor(@NotNull AccessDeniedHandler deniedHandler, @NotNull RequestMatcher preferredMatcher) {
/* 55 */     Intrinsics.checkNotNullParameter(deniedHandler, "deniedHandler"); Intrinsics.checkNotNullParameter(preferredMatcher, "preferredMatcher"); this.defaultDeniedHandlerMappings.put(preferredMatcher, deniedHandler);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void defaultAuthenticationEntryPointFor(@NotNull AuthenticationEntryPoint entryPoint, @NotNull RequestMatcher preferredMatcher) {
/* 67 */     Intrinsics.checkNotNullParameter(entryPoint, "entryPoint"); Intrinsics.checkNotNullParameter(preferredMatcher, "preferredMatcher"); this.defaultEntryPointMappings.put(preferredMatcher, entryPoint);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 74 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 78 */   public final Function1<ExceptionHandlingConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new ExceptionHandlingDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "exceptionHandling", "Lorg/springframework/security/config/annotation/web/configurers/ExceptionHandlingConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nExceptionHandlingDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ExceptionHandlingDsl.kt\norg/springframework/security/config/annotation/web/ExceptionHandlingDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,94:1\n1#2:95\n216#3,2:96\n216#3,2:98\n*S KotlinDebug\n*F\n+ 1 ExceptionHandlingDsl.kt\norg/springframework/security/config/annotation/web/ExceptionHandlingDsl$get$1\n*L\n82#1:96,2\n85#1:98,2\n*E\n"})
/* 79 */   static final class ExceptionHandlingDsl$get$1 extends Lambda implements Function1<ExceptionHandlingConfigurer<HttpSecurity>, Unit> { public final void invoke(ExceptionHandlingConfigurer exceptionHandling) { Intrinsics.checkNotNullParameter(exceptionHandling, "exceptionHandling"); if (ExceptionHandlingDsl.this.getAccessDeniedPage() != null) { String str1 = ExceptionHandlingDsl.this.getAccessDeniedPage(); ExceptionHandlingDsl exceptionHandlingDsl = ExceptionHandlingDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 95 */         int $i$a$-also-ExceptionHandlingDsl$get$1$1 = 0; exceptionHandling.accessDeniedPage(exceptionHandlingDsl.getAccessDeniedPage()); } else { ExceptionHandlingDsl.this.getAccessDeniedPage(); }  if (ExceptionHandlingDsl.this.getAccessDeniedHandler() != null) { AccessDeniedHandler accessDeniedHandler1 = ExceptionHandlingDsl.this.getAccessDeniedHandler(); ExceptionHandlingDsl exceptionHandlingDsl = ExceptionHandlingDsl.this; AccessDeniedHandler it = accessDeniedHandler1; int $i$a$-also-ExceptionHandlingDsl$get$1$2 = 0; exceptionHandling.accessDeniedHandler(exceptionHandlingDsl.getAccessDeniedHandler()); } else { ExceptionHandlingDsl.this.getAccessDeniedHandler(); }  if (ExceptionHandlingDsl.this.getAuthenticationEntryPoint() != null) { AuthenticationEntryPoint authenticationEntryPoint1 = ExceptionHandlingDsl.this.getAuthenticationEntryPoint(); ExceptionHandlingDsl exceptionHandlingDsl = ExceptionHandlingDsl.this; AuthenticationEntryPoint it = authenticationEntryPoint1; int $i$a$-also-ExceptionHandlingDsl$get$1$3 = 0; exceptionHandling.authenticationEntryPoint(exceptionHandlingDsl.getAuthenticationEntryPoint()); } else { ExceptionHandlingDsl.this.getAuthenticationEntryPoint(); }
/* 96 */        Map $this$forEach$iv = ExceptionHandlingDsl.this.defaultDeniedHandlerMappings; int $i$f$forEach = 0; Iterator<Map.Entry> iterator = $this$forEach$iv.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-ExceptionHandlingDsl$get$1$4 = 0; RequestMatcher matcher = (RequestMatcher)entry1.getKey(); AccessDeniedHandler handler = (AccessDeniedHandler)entry1.getValue(); exceptionHandling.defaultAccessDeniedHandlerFor(handler, matcher); }
/*    */        $this$forEach$iv = ExceptionHandlingDsl.this.defaultEntryPointMappings; $i$f$forEach = 0;
/* 98 */       iterator = $this$forEach$iv.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-ExceptionHandlingDsl$get$1$5 = 0;
/*    */         RequestMatcher matcher = (RequestMatcher)entry1.getKey();
/*    */         AuthenticationEntryPoint entryPoint = (AuthenticationEntryPoint)entry1.getValue();
/*    */         exceptionHandling.defaultAuthenticationEntryPointFor(entryPoint, matcher); }
/*    */       
/*    */       if (ExceptionHandlingDsl.this.disabled)
/*    */         exceptionHandling.disable();  }
/*    */ 
/*    */     
/*    */     ExceptionHandlingDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\ExceptionHandlingDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */