/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.http.HttpMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\021\n\002\020\013\n\000\n\002\020\000\n\000\n\002\020\b\n\002\b\002\b\b\030\0002\0020\001B5\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\n\b\002\020\006\032\004\030\0010\003\022\n\b\002\020\007\032\004\030\0010\b\022\006\020\t\032\0020\003¢\006\002\020\nJ\t\020\023\032\0020\003HÆ\003J\t\020\024\032\0020\005HÆ\003J\013\020\025\032\004\030\0010\003HÆ\003J\013\020\026\032\004\030\0010\bHÆ\003J\t\020\027\032\0020\003HÆ\003J?\020\030\032\0020\0002\b\b\002\020\002\032\0020\0032\b\b\002\020\004\032\0020\0052\n\b\002\020\006\032\004\030\0010\0032\n\b\002\020\007\032\004\030\0010\b2\b\b\002\020\t\032\0020\003HÆ\001J\023\020\031\032\0020\0322\b\020\033\032\004\030\0010\034HÖ\003J\t\020\035\032\0020\036HÖ\001J\t\020\037\032\0020\003HÖ\001R\023\020\007\032\004\030\0010\b¢\006\b\n\000\032\004\b\013\020\fR\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\r\020\016R\021\020\004\032\0020\005¢\006\b\n\000\032\004\b\017\020\020R\024\020\t\032\0020\003X\004¢\006\b\n\000\032\004\b\021\020\016R\023\020\006\032\004\030\0010\003¢\006\b\n\000\032\004\b\022\020\016¨\006 "}, d2 = {"Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternAuthorizationRule;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationRule;", "pattern", "", "patternType", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "servletPath", "httpMethod", "Lorg/springframework/http/HttpMethod;", "rule", "(Ljava/lang/String;Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;Ljava/lang/String;Lorg/springframework/http/HttpMethod;Ljava/lang/String;)V", "getHttpMethod", "()Lorg/springframework/http/HttpMethod;", "getPattern", "()Ljava/lang/String;", "getPatternType", "()Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "getRule", "getServletPath", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "", "hashCode", "", "toString", "spring-security-config"})
/*    */ public final class PatternAuthorizationRule
/*    */   extends AbstractRequestMatcherDsl.AuthorizationRule
/*    */ {
/*    */   @NotNull
/*    */   private final String pattern;
/*    */   @NotNull
/*    */   private final AbstractRequestMatcherDsl.PatternType patternType;
/*    */   @Nullable
/*    */   private final String servletPath;
/*    */   @Nullable
/*    */   private final HttpMethod httpMethod;
/*    */   @NotNull
/*    */   private final String rule;
/*    */   
/*    */   @NotNull
/*    */   public final String getPattern() {
/* 44 */     return this.pattern; } @NotNull
/* 45 */   public final AbstractRequestMatcherDsl.PatternType getPatternType() { return this.patternType; } @Nullable
/* 46 */   public final String getServletPath() { return this.servletPath; } @Nullable
/* 47 */   public final HttpMethod getHttpMethod() { return this.httpMethod; }
/* 48 */   public PatternAuthorizationRule(@NotNull String pattern, @NotNull AbstractRequestMatcherDsl.PatternType patternType, @Nullable String servletPath, @Nullable HttpMethod httpMethod, @NotNull String rule) { super(rule); this.pattern = pattern; this.patternType = patternType; this.servletPath = servletPath; this.httpMethod = httpMethod; this.rule = rule; } @NotNull public String getRule() { return this.rule; }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public final String component1() {
/*    */     return this.pattern;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final AbstractRequestMatcherDsl.PatternType component2() {
/*    */     return this.patternType;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final String component3() {
/*    */     return this.servletPath;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final HttpMethod component4() {
/*    */     return this.httpMethod;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final String component5() {
/*    */     return this.rule;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final PatternAuthorizationRule copy(@NotNull String pattern, @NotNull AbstractRequestMatcherDsl.PatternType patternType, @Nullable String servletPath, @Nullable HttpMethod httpMethod, @NotNull String rule) {
/*    */     Intrinsics.checkNotNullParameter(pattern, "pattern");
/*    */     Intrinsics.checkNotNullParameter(patternType, "patternType");
/*    */     Intrinsics.checkNotNullParameter(rule, "rule");
/*    */     return new PatternAuthorizationRule(pattern, patternType, servletPath, httpMethod, rule);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString() {
/*    */     return "PatternAuthorizationRule(pattern=" + this.pattern + ", patternType=" + this.patternType + ", servletPath=" + this.servletPath + ", httpMethod=" + this.httpMethod + ", rule=" + this.rule + ")";
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     result = this.pattern.hashCode();
/*    */     result = result * 31 + this.patternType.hashCode();
/*    */     result = result * 31 + ((this.servletPath == null) ? 0 : this.servletPath.hashCode());
/*    */     result = result * 31 + ((this.httpMethod == null) ? 0 : this.httpMethod.hashCode());
/*    */     return result * 31 + this.rule.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/*    */     if (this == other)
/*    */       return true; 
/*    */     if (!(other instanceof PatternAuthorizationRule))
/*    */       return false; 
/*    */     PatternAuthorizationRule patternAuthorizationRule = (PatternAuthorizationRule)other;
/*    */     return !Intrinsics.areEqual(this.pattern, patternAuthorizationRule.pattern) ? false : ((this.patternType != patternAuthorizationRule.patternType) ? false : (!Intrinsics.areEqual(this.servletPath, patternAuthorizationRule.servletPath) ? false : (!Intrinsics.areEqual(this.httpMethod, patternAuthorizationRule.httpMethod) ? false : (!!Intrinsics.areEqual(this.rule, patternAuthorizationRule.rule)))));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherDsl$PatternAuthorizationRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */