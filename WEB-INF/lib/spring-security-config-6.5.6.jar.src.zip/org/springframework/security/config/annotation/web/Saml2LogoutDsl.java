/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*    */ import org.springframework.security.config.annotation.web.saml2.LogoutRequestDsl;
/*    */ import org.springframework.security.config.annotation.web.saml2.LogoutResponseDsl;
/*    */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\007\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\027\032\024\022\n\022\b\022\004\022\0020\0070\006\022\004\022\0020\b0\004H\000¢\006\002\b\030J\037\020\003\032\0020\b2\027\020\031\032\023\022\004\022\0020\032\022\004\022\0020\b0\004¢\006\002\b\033J\037\020\t\032\0020\b2\027\020\034\032\023\022\004\022\0020\035\022\004\022\0020\b0\004¢\006\002\b\033R&\020\003\032\032\022\016\022\f0\005R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020\t\032\032\022\016\022\f0\nR\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R\034\020\013\032\004\030\0010\fX\016¢\006\016\n\000\032\004\b\r\020\016\"\004\b\017\020\020R\034\020\021\032\004\030\0010\022X\016¢\006\016\n\000\032\004\b\023\020\024\"\004\b\025\020\026¨\006\036"}, d2 = {"Lorg/springframework/security/config/annotation/web/Saml2LogoutDsl;", "", "()V", "logoutRequest", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutRequestConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "logoutResponse", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutResponseConfigurer;", "logoutUrl", "", "getLogoutUrl", "()Ljava/lang/String;", "setLogoutUrl", "(Ljava/lang/String;)V", "relyingPartyRegistrationRepository", "Lorg/springframework/security/saml2/provider/service/registration/RelyingPartyRegistrationRepository;", "getRelyingPartyRegistrationRepository", "()Lorg/springframework/security/saml2/provider/service/registration/RelyingPartyRegistrationRepository;", "setRelyingPartyRegistrationRepository", "(Lorg/springframework/security/saml2/provider/service/registration/RelyingPartyRegistrationRepository;)V", "get", "get$spring_security_config", "logoutRequestConfig", "Lorg/springframework/security/config/annotation/web/saml2/LogoutRequestDsl;", "Lkotlin/ExtensionFunctionType;", "logoutResponseConfig", "Lorg/springframework/security/config/annotation/web/saml2/LogoutResponseDsl;", "spring-security-config"})
/*    */ public final class Saml2LogoutDsl
/*    */ {
/*    */   @Nullable
/*    */   private RelyingPartyRegistrationRepository relyingPartyRegistrationRepository;
/*    */   @Nullable
/*    */   private String logoutUrl;
/*    */   @Nullable
/*    */   private Function1<? super Saml2LogoutConfigurer<HttpSecurity>.LogoutRequestConfigurer, Unit> logoutRequest;
/*    */   @Nullable
/*    */   private Function1<? super Saml2LogoutConfigurer<HttpSecurity>.LogoutResponseConfigurer, Unit> logoutResponse;
/*    */   
/*    */   @Nullable
/*    */   public final RelyingPartyRegistrationRepository getRelyingPartyRegistrationRepository() {
/* 37 */     return this.relyingPartyRegistrationRepository; } public final void setRelyingPartyRegistrationRepository(@Nullable RelyingPartyRegistrationRepository <set-?>) { this.relyingPartyRegistrationRepository = <set-?>; } @Nullable
/* 38 */   public final String getLogoutUrl() { return this.logoutUrl; } public final void setLogoutUrl(@Nullable String <set-?>) { this.logoutUrl = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void logoutRequest(@NotNull Function1 logoutRequestConfig) {
/* 49 */     Intrinsics.checkNotNullParameter(logoutRequestConfig, "logoutRequestConfig"); LogoutRequestDsl logoutRequestDsl = new LogoutRequestDsl(); logoutRequestConfig.invoke(logoutRequestDsl); this.logoutRequest = logoutRequestDsl.get$spring_security_config();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void logoutResponse(@NotNull Function1 logoutResponseConfig) {
/* 58 */     Intrinsics.checkNotNullParameter(logoutResponseConfig, "logoutResponseConfig"); LogoutResponseDsl logoutResponseDsl = new LogoutResponseDsl(); logoutResponseConfig.invoke(logoutResponseDsl); this.logoutResponse = logoutResponseDsl.get$spring_security_config();
/*    */   }
/*    */   
/*    */   @NotNull
/* 62 */   public final Function1<Saml2LogoutConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new Saml2LogoutDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "saml2Logout", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nSaml2LogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Saml2LogoutDsl.kt\norg/springframework/security/config/annotation/web/Saml2LogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n1#2:71\n*E\n"})
/* 63 */   static final class Saml2LogoutDsl$get$1 extends Lambda implements Function1<Saml2LogoutConfigurer<HttpSecurity>, Unit> { public final void invoke(Saml2LogoutConfigurer saml2Logout) { Intrinsics.checkNotNullParameter(saml2Logout, "saml2Logout"); if (Saml2LogoutDsl.this.getRelyingPartyRegistrationRepository() != null) { RelyingPartyRegistrationRepository relyingPartyRegistrationRepository1 = Saml2LogoutDsl.this.getRelyingPartyRegistrationRepository(); Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; RelyingPartyRegistrationRepository it = relyingPartyRegistrationRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 71 */         int $i$a$-also-Saml2LogoutDsl$get$1$1 = 0; saml2Logout.relyingPartyRegistrationRepository(saml2LogoutDsl.getRelyingPartyRegistrationRepository()); } else { Saml2LogoutDsl.this.getRelyingPartyRegistrationRepository(); }  if (Saml2LogoutDsl.this.getLogoutUrl() != null) { String str1 = Saml2LogoutDsl.this.getLogoutUrl(); Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; String it = str1; int $i$a$-also-Saml2LogoutDsl$get$1$2 = 0; saml2Logout.logoutUrl(saml2LogoutDsl.getLogoutUrl()); } else { Saml2LogoutDsl.this.getLogoutUrl(); }  if (Saml2LogoutDsl.this.logoutRequest != null) { Function1 function11 = Saml2LogoutDsl.this.logoutRequest; Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; Function1 it = function11; int $i$a$-also-Saml2LogoutDsl$get$1$3 = 0; saml2LogoutDsl.logoutRequest; saml2Logout.logoutRequest((saml2LogoutDsl.logoutRequest != null) ? saml2LogoutDsl.logoutRequest::invoke$lambda$3$lambda$2 : null); } else { Saml2LogoutDsl.this.logoutRequest; }  if (Saml2LogoutDsl.this.logoutResponse != null) { Function1 function11 = Saml2LogoutDsl.this.logoutResponse; Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; Function1 it = function11; int $i$a$-also-Saml2LogoutDsl$get$1$4 = 0;
/*    */         saml2LogoutDsl.logoutResponse;
/*    */         saml2Logout.logoutResponse((saml2LogoutDsl.logoutResponse != null) ? saml2LogoutDsl.logoutResponse::invoke$lambda$5$lambda$4 : null); }
/*    */       else
/*    */       { Saml2LogoutDsl.this.logoutResponse; }
/*    */        }
/*    */ 
/*    */     
/*    */     private static final void invoke$lambda$3$lambda$2(Function1 $tmp0, Saml2LogoutConfigurer.LogoutRequestConfigurer t) {
/*    */       $tmp0.invoke(t);
/*    */     }
/*    */     
/*    */     private static final void invoke$lambda$5$lambda$4(Function1 $tmp0, Saml2LogoutConfigurer.LogoutResponseConfigurer t) {
/*    */       $tmp0.invoke(t);
/*    */     }
/*    */     
/*    */     Saml2LogoutDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\Saml2LogoutDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */