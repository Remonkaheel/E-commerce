/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.authentication.OAuth2AuthorizationCodeAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.AuthenticatedPrincipalOAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
/*     */ import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizationRequestResolver;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationCodeGrantFilter;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OAuth2ClientConfigurer<B extends HttpSecurityBuilder<B>>
/*     */   extends AbstractHttpConfigurer<OAuth2ClientConfigurer<B>, B>
/*     */ {
/* 100 */   private AuthorizationCodeGrantConfigurer authorizationCodeGrantConfigurer = new AuthorizationCodeGrantConfigurer();
/*     */ 
/*     */ 
/*     */   
/*     */   private ClientRegistrationRepository clientRegistrationRepository;
/*     */ 
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientRepository authorizedClientRepository;
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuth2ClientConfigurer<B> clientRegistrationRepository(ClientRegistrationRepository clientRegistrationRepository) {
/* 113 */     Assert.notNull(clientRegistrationRepository, "clientRegistrationRepository cannot be null");
/* 114 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(ClientRegistrationRepository.class, clientRegistrationRepository);
/* 115 */     this.clientRegistrationRepository = clientRegistrationRepository;
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuth2ClientConfigurer<B> authorizedClientRepository(OAuth2AuthorizedClientRepository authorizedClientRepository) {
/* 126 */     Assert.notNull(authorizedClientRepository, "authorizedClientRepository cannot be null");
/* 127 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(OAuth2AuthorizedClientRepository.class, authorizedClientRepository);
/* 128 */     this.authorizedClientRepository = authorizedClientRepository;
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuth2ClientConfigurer<B> authorizedClientService(OAuth2AuthorizedClientService authorizedClientService) {
/* 138 */     Assert.notNull(authorizedClientService, "authorizedClientService cannot be null");
/* 139 */     authorizedClientRepository((OAuth2AuthorizedClientRepository)new AuthenticatedPrincipalOAuth2AuthorizedClientRepository(authorizedClientService));
/*     */     
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public AuthorizationCodeGrantConfigurer authorizationCodeGrant() {
/* 153 */     return this.authorizationCodeGrantConfigurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuth2ClientConfigurer<B> authorizationCodeGrant(Customizer<AuthorizationCodeGrantConfigurer> authorizationCodeGrantCustomizer) {
/* 164 */     authorizationCodeGrantCustomizer.customize(this.authorizationCodeGrantConfigurer);
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(B builder) {
/* 170 */     this.authorizationCodeGrantConfigurer.init(builder);
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(B builder) {
/* 175 */     this.authorizationCodeGrantConfigurer.configure(builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class AuthorizationCodeGrantConfigurer
/*     */   {
/*     */     private OAuth2AuthorizationRequestResolver authorizationRequestResolver;
/*     */ 
/*     */ 
/*     */     
/*     */     private AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository;
/*     */ 
/*     */ 
/*     */     
/*     */     private RedirectStrategy authorizationRedirectStrategy;
/*     */ 
/*     */ 
/*     */     
/*     */     private OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizationCodeGrantConfigurer authorizationRequestResolver(OAuth2AuthorizationRequestResolver authorizationRequestResolver) {
/* 202 */       Assert.notNull(authorizationRequestResolver, "authorizationRequestResolver cannot be null");
/* 203 */       this.authorizationRequestResolver = authorizationRequestResolver;
/* 204 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizationCodeGrantConfigurer authorizationRequestRepository(AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository) {
/* 215 */       Assert.notNull(authorizationRequestRepository, "authorizationRequestRepository cannot be null");
/* 216 */       this.authorizationRequestRepository = authorizationRequestRepository;
/* 217 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizationCodeGrantConfigurer authorizationRedirectStrategy(RedirectStrategy authorizationRedirectStrategy) {
/* 227 */       this.authorizationRedirectStrategy = authorizationRedirectStrategy;
/* 228 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizationCodeGrantConfigurer accessTokenResponseClient(OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient) {
/* 240 */       Assert.notNull(accessTokenResponseClient, "accessTokenResponseClient cannot be null");
/* 241 */       this.accessTokenResponseClient = accessTokenResponseClient;
/* 242 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public OAuth2ClientConfigurer<B> and() {
/* 253 */       return OAuth2ClientConfigurer.this;
/*     */     }
/*     */ 
/*     */     
/*     */     private void init(B builder) {
/* 258 */       OAuth2AuthorizationCodeAuthenticationProvider authorizationCodeAuthenticationProvider = new OAuth2AuthorizationCodeAuthenticationProvider(getAccessTokenResponseClient());
/* 259 */       builder.authenticationProvider((AuthenticationProvider)OAuth2ClientConfigurer.this.postProcess(authorizationCodeAuthenticationProvider));
/*     */     }
/*     */     
/*     */     private void configure(B builder) {
/* 263 */       OAuth2AuthorizationRequestRedirectFilter authorizationRequestRedirectFilter = createAuthorizationRequestRedirectFilter(builder);
/*     */       
/* 265 */       builder.addFilter((Filter)OAuth2ClientConfigurer.this.postProcess(authorizationRequestRedirectFilter));
/* 266 */       OAuth2AuthorizationCodeGrantFilter authorizationCodeGrantFilter = createAuthorizationCodeGrantFilter(builder);
/*     */       
/* 268 */       builder.addFilter((Filter)OAuth2ClientConfigurer.this.postProcess(authorizationCodeGrantFilter));
/*     */     }
/*     */     
/*     */     private OAuth2AuthorizationRequestRedirectFilter createAuthorizationRequestRedirectFilter(B builder) {
/* 272 */       OAuth2AuthorizationRequestResolver resolver = getAuthorizationRequestResolver();
/* 273 */       OAuth2AuthorizationRequestRedirectFilter authorizationRequestRedirectFilter = new OAuth2AuthorizationRequestRedirectFilter(resolver);
/*     */       
/* 275 */       if (this.authorizationRequestRepository != null) {
/* 276 */         authorizationRequestRedirectFilter
/* 277 */           .setAuthorizationRequestRepository(this.authorizationRequestRepository);
/*     */       }
/* 279 */       if (this.authorizationRedirectStrategy != null) {
/* 280 */         authorizationRequestRedirectFilter.setAuthorizationRedirectStrategy(this.authorizationRedirectStrategy);
/*     */       }
/* 282 */       RequestCache requestCache = (RequestCache)builder.getSharedObject(RequestCache.class);
/* 283 */       if (requestCache != null) {
/* 284 */         authorizationRequestRedirectFilter.setRequestCache(requestCache);
/*     */       }
/* 286 */       return authorizationRequestRedirectFilter;
/*     */     }
/*     */     
/*     */     private OAuth2AuthorizationRequestResolver getAuthorizationRequestResolver() {
/* 290 */       if (this.authorizationRequestResolver != null) {
/* 291 */         return this.authorizationRequestResolver;
/*     */       }
/* 293 */       ClientRegistrationRepository clientRegistrationRepository = getClientRegistrationRepository((B)OAuth2ClientConfigurer.this.getBuilder());
/* 294 */       ResolvableType resolvableType = ResolvableType.forClass(OAuth2AuthorizationRequestResolver.class);
/* 295 */       OAuth2AuthorizationRequestResolver bean = getBeanOrNull(resolvableType);
/* 296 */       return (bean != null) ? bean : (OAuth2AuthorizationRequestResolver)new DefaultOAuth2AuthorizationRequestResolver(clientRegistrationRepository, "/oauth2/authorization");
/*     */     }
/*     */ 
/*     */     
/*     */     private OAuth2AuthorizationCodeGrantFilter createAuthorizationCodeGrantFilter(B builder) {
/* 301 */       AuthenticationManager authenticationManager = (AuthenticationManager)builder.getSharedObject(AuthenticationManager.class);
/*     */       
/* 303 */       OAuth2AuthorizationCodeGrantFilter authorizationCodeGrantFilter = new OAuth2AuthorizationCodeGrantFilter(getClientRegistrationRepository(builder), getAuthorizedClientRepository(builder), authenticationManager);
/*     */       
/* 305 */       if (this.authorizationRequestRepository != null) {
/* 306 */         authorizationCodeGrantFilter.setAuthorizationRequestRepository(this.authorizationRequestRepository);
/*     */       }
/* 308 */       authorizationCodeGrantFilter.setSecurityContextHolderStrategy(OAuth2ClientConfigurer.this.getSecurityContextHolderStrategy());
/* 309 */       RequestCache requestCache = (RequestCache)builder.getSharedObject(RequestCache.class);
/* 310 */       if (requestCache != null) {
/* 311 */         authorizationCodeGrantFilter.setRequestCache(requestCache);
/*     */       }
/* 313 */       return authorizationCodeGrantFilter;
/*     */     }
/*     */     
/*     */     private OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> getAccessTokenResponseClient() {
/* 317 */       if (this.accessTokenResponseClient != null) {
/* 318 */         return this.accessTokenResponseClient;
/*     */       }
/* 320 */       ResolvableType resolvableType = ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2AuthorizationCodeGrantRequest.class });
/*     */       
/* 322 */       OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> bean = getBeanOrNull(resolvableType);
/* 323 */       return (bean != null) ? bean : (OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest>)new DefaultAuthorizationCodeTokenResponseClient();
/*     */     }
/*     */     
/*     */     private ClientRegistrationRepository getClientRegistrationRepository(B builder) {
/* 327 */       return (OAuth2ClientConfigurer.this.clientRegistrationRepository != null) ? 
/* 328 */         OAuth2ClientConfigurer.this.clientRegistrationRepository : 
/* 329 */         OAuth2ClientConfigurerUtils.<B>getClientRegistrationRepository(builder);
/*     */     }
/*     */     
/*     */     private OAuth2AuthorizedClientRepository getAuthorizedClientRepository(B builder) {
/* 333 */       return (OAuth2ClientConfigurer.this.authorizedClientRepository != null) ? 
/* 334 */         OAuth2ClientConfigurer.this.authorizedClientRepository : 
/* 335 */         OAuth2ClientConfigurerUtils.<B>getAuthorizedClientRepository(builder);
/*     */     }
/*     */ 
/*     */     
/*     */     private <T> T getBeanOrNull(ResolvableType type) {
/* 340 */       ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)OAuth2ClientConfigurer.this.getBuilder()).getSharedObject(ApplicationContext.class);
/* 341 */       if (context == null) {
/* 342 */         return null;
/*     */       }
/* 344 */       return (T)context.getBeanProvider(type).getIfUnique();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OAuth2ClientConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */