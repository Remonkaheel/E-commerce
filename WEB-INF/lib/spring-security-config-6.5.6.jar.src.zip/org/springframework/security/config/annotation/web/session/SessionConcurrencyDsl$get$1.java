/*    */ package org.springframework.security.config.annotation.web.session;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*    */ import org.springframework.security.core.session.SessionRegistry;
/*    */ import org.springframework.security.web.authentication.session.SessionLimit;
/*    */ import org.springframework.security.web.session.SessionInformationExpiredStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "sessionConcurrencyControl", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$ConcurrencyControlConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ final class SessionConcurrencyDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<SessionManagementConfigurer<HttpSecurity>.ConcurrencyControlConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(SessionManagementConfigurer.ConcurrencyControlConfigurer sessionConcurrencyControl) {
/* 58 */     Intrinsics.checkNotNullParameter(sessionConcurrencyControl, "sessionConcurrencyControl"); Integer integer = SessionConcurrencyDsl.this.getMaximumSessions(); SessionConcurrencyDsl sessionConcurrencyDsl = SessionConcurrencyDsl.this; int i = integer.intValue(), $i$a$-also-SessionConcurrencyDsl$get$1$1 = 0;
/* 59 */     Intrinsics.checkNotNull(sessionConcurrencyDsl.getMaximumSessions()); sessionConcurrencyControl.maximumSessions(sessionConcurrencyDsl.getMaximumSessions().intValue());
/*    */     SessionConcurrencyDsl.this.getMaximumSessions();
/* 61 */     SessionLimit sessionLimit1 = SessionConcurrencyDsl.access$getSessionLimit$p(SessionConcurrencyDsl.this); sessionConcurrencyDsl = SessionConcurrencyDsl.this; SessionLimit sessionLimit2 = sessionLimit1; int $i$a$-also-SessionConcurrencyDsl$get$1$2 = 0;
/* 62 */     Intrinsics.checkNotNull(SessionConcurrencyDsl.access$getSessionLimit$p(sessionConcurrencyDsl)); sessionConcurrencyControl.maximumSessions(SessionConcurrencyDsl.access$getSessionLimit$p(sessionConcurrencyDsl));
/*    */     SessionConcurrencyDsl.access$getSessionLimit$p(SessionConcurrencyDsl.this);
/* 64 */     String str1 = SessionConcurrencyDsl.this.getExpiredUrl(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; String str2 = str1; int $i$a$-also-SessionConcurrencyDsl$get$1$3 = 0;
/* 65 */     sessionConcurrencyControl.expiredUrl(sessionConcurrencyDsl.getExpiredUrl());
/*    */     SessionConcurrencyDsl.this.getExpiredUrl();
/* 67 */     SessionInformationExpiredStrategy sessionInformationExpiredStrategy1 = SessionConcurrencyDsl.this.getExpiredSessionStrategy(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; SessionInformationExpiredStrategy sessionInformationExpiredStrategy2 = sessionInformationExpiredStrategy1; int $i$a$-also-SessionConcurrencyDsl$get$1$4 = 0;
/* 68 */     sessionConcurrencyControl.expiredSessionStrategy(sessionConcurrencyDsl.getExpiredSessionStrategy());
/*    */     SessionConcurrencyDsl.this.getExpiredSessionStrategy();
/* 70 */     Boolean bool = SessionConcurrencyDsl.this.getMaxSessionsPreventsLogin(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-SessionConcurrencyDsl$get$1$5 = 0;
/* 71 */     Intrinsics.checkNotNull(sessionConcurrencyDsl.getMaxSessionsPreventsLogin()); sessionConcurrencyControl.maxSessionsPreventsLogin(sessionConcurrencyDsl.getMaxSessionsPreventsLogin().booleanValue());
/*    */     SessionConcurrencyDsl.this.getMaxSessionsPreventsLogin();
/* 73 */     SessionRegistry sessionRegistry1 = SessionConcurrencyDsl.this.getSessionRegistry(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; SessionRegistry it = sessionRegistry1; int $i$a$-also-SessionConcurrencyDsl$get$1$6 = 0;
/* 74 */     sessionConcurrencyControl.sessionRegistry(sessionConcurrencyDsl.getSessionRegistry());
/*    */     SessionConcurrencyDsl.this.getSessionRegistry();
/*    */   }
/*    */   
/*    */   SessionConcurrencyDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\session\SessionConcurrencyDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */