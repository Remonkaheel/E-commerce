/*     */ package org.springframework.security.config.annotation.web.configurers.saml2;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.function.Function;
/*     */ import org.opensaml.core.Version;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
/*     */ import org.springframework.security.saml2.provider.service.metadata.OpenSaml4MetadataResolver;
/*     */ import org.springframework.security.saml2.provider.service.metadata.OpenSaml5MetadataResolver;
/*     */ import org.springframework.security.saml2.provider.service.metadata.Saml2MetadataResolver;
/*     */ import org.springframework.security.saml2.provider.service.metadata.Saml2MetadataResponseResolver;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.Saml2MetadataFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.metadata.RequestMatcherMetadataResponseResolver;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Saml2MetadataConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<Saml2LogoutConfigurer<H>, H>
/*     */ {
/*  79 */   private static final boolean USE_OPENSAML_5 = Version.getVersion().startsWith("5");
/*     */   
/*     */   private final ApplicationContext context;
/*     */   
/*     */   private Function<RelyingPartyRegistrationRepository, Saml2MetadataResponseResolver> metadataResponseResolver;
/*     */   
/*     */   public Saml2MetadataConfigurer(ApplicationContext context) {
/*  86 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2MetadataConfigurer<H> metadataUrl(String metadataUrl) {
/* 109 */     Assert.hasText(metadataUrl, "metadataUrl cannot be empty");
/* 110 */     this.metadataResponseResolver = (registrations -> {
/*     */         if (USE_OPENSAML_5) {
/*     */           RequestMatcherMetadataResponseResolver requestMatcherMetadataResponseResolver = new RequestMatcherMetadataResponseResolver(registrations, (Saml2MetadataResolver)new OpenSaml5MetadataResolver());
/*     */           
/*     */           requestMatcherMetadataResponseResolver.setRequestMatcher(RequestMatcherFactory.matcher(metadataUrl));
/*     */           
/*     */           return (Saml2MetadataResponseResolver)requestMatcherMetadataResponseResolver;
/*     */         } 
/*     */         RequestMatcherMetadataResponseResolver metadata = new RequestMatcherMetadataResponseResolver(registrations, (Saml2MetadataResolver)new OpenSaml4MetadataResolver());
/*     */         metadata.setRequestMatcher(RequestMatcherFactory.matcher(metadataUrl));
/*     */         return (Saml2MetadataResponseResolver)metadata;
/*     */       });
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2MetadataConfigurer<H> metadataResponseResolver(Saml2MetadataResponseResolver metadataResponseResolver) {
/* 132 */     Assert.notNull(metadataResponseResolver, "metadataResponseResolver cannot be null");
/* 133 */     this.metadataResponseResolver = (registrations -> metadataResponseResolver);
/* 134 */     return this;
/*     */   }
/*     */   
/*     */   public H and() {
/* 138 */     return (H)getBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) throws Exception {
/* 143 */     Saml2MetadataResponseResolver metadataResponseResolver = createMetadataResponseResolver(http);
/* 144 */     http.addFilterBefore((Filter)new Saml2MetadataFilter(metadataResponseResolver), BasicAuthenticationFilter.class);
/*     */   }
/*     */   
/*     */   private Saml2MetadataResponseResolver createMetadataResponseResolver(H http) {
/* 148 */     if (this.metadataResponseResolver != null) {
/* 149 */       RelyingPartyRegistrationRepository relyingPartyRegistrationRepository = getRelyingPartyRegistrationRepository(http);
/* 150 */       return this.metadataResponseResolver.apply(relyingPartyRegistrationRepository);
/*     */     } 
/* 152 */     Saml2MetadataResponseResolver metadataResponseResolver = getBeanOrNull(Saml2MetadataResponseResolver.class);
/* 153 */     if (metadataResponseResolver != null) {
/* 154 */       return metadataResponseResolver;
/*     */     }
/* 156 */     RelyingPartyRegistrationRepository registrations = getRelyingPartyRegistrationRepository(http);
/* 157 */     if (USE_OPENSAML_5) {
/* 158 */       return (Saml2MetadataResponseResolver)new RequestMatcherMetadataResponseResolver(registrations, (Saml2MetadataResolver)new OpenSaml5MetadataResolver());
/*     */     }
/* 160 */     return (Saml2MetadataResponseResolver)new RequestMatcherMetadataResponseResolver(registrations, (Saml2MetadataResolver)new OpenSaml4MetadataResolver());
/*     */   }
/*     */   
/*     */   private RelyingPartyRegistrationRepository getRelyingPartyRegistrationRepository(H http) {
/* 164 */     Saml2LoginConfigurer<H> login = (Saml2LoginConfigurer<H>)http.getConfigurer(Saml2LoginConfigurer.class);
/* 165 */     if (login != null) {
/* 166 */       return login.relyingPartyRegistrationRepository(http);
/*     */     }
/*     */     
/* 169 */     return getBeanOrNull(RelyingPartyRegistrationRepository.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private <C> C getBeanOrNull(Class<C> clazz) {
/* 174 */     if (this.context == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     return (C)this.context.getBeanProvider(clazz).getIfAvailable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\saml2\Saml2MetadataConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */