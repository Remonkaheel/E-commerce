/*     */ package org.springframework.security.config.annotation.web.reactive;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.crypto.RsaKeyConversionServicePostProcessor;
/*     */ import org.springframework.security.config.web.server.ServerHttpSecurity;
/*     */ import org.springframework.security.web.reactive.result.view.CsrfRequestDataValueProcessor;
/*     */ import org.springframework.security.web.server.SecurityWebFilterChain;
/*     */ import org.springframework.security.web.server.WebFilterChainProxy;
/*     */ import org.springframework.security.web.server.firewall.ServerExchangeRejectedHandler;
/*     */ import org.springframework.security.web.server.firewall.ServerWebExchangeFirewall;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class WebFluxSecurityConfiguration
/*     */ {
/*     */   @Autowired
/*     */   ApplicationContext context;
/*  63 */   private ObjectPostProcessor<WebFilterChainProxy.WebFilterChainDecorator> postProcessor = ObjectPostProcessor.identity();
/*     */   
/*     */   private List<SecurityWebFilterChain> securityWebFilterChains;
/*  66 */   private static final boolean isOAuth2Present = ClassUtils.isPresent("org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository", WebFluxSecurityConfiguration.class
/*  67 */       .getClassLoader());
/*     */   public static final String REACTIVE_CLIENT_REGISTRATION_REPOSITORY_CLASSNAME = "org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository";
/*     */   private static final String SPRING_SECURITY_WEBFILTERCHAINFILTER_BEAN_NAME = "org.springframework.security.config.annotation.web.reactive.WebFluxSecurityConfiguration.WebFilterChainFilter";
/*     */   private static final String BEAN_NAME_PREFIX = "org.springframework.security.config.annotation.web.reactive.WebFluxSecurityConfiguration.";
/*     */   public static final int WEB_FILTER_CHAIN_FILTER_ORDER = -100;
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityWebFilterChains(List<SecurityWebFilterChain> securityWebFilterChains) {
/*  75 */     this.securityWebFilterChains = securityWebFilterChains;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setFilterChainPostProcessor(ObjectPostProcessor<WebFilterChainProxy.WebFilterChainDecorator> postProcessor) {
/*  80 */     this.postProcessor = postProcessor;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean({"org.springframework.security.config.annotation.web.reactive.WebFluxSecurityConfiguration.WebFilterChainFilter"})
/*     */   @Order(-100)
/*     */   WebFilterChainProxy springSecurityWebFilterChainFilter(ObjectProvider<ServerWebExchangeFirewall> firewall, ObjectProvider<ServerExchangeRejectedHandler> rejectedHandler) {
/*  87 */     WebFilterChainProxy proxy = new WebFilterChainProxy(getSecurityWebFilterChains());
/*  88 */     WebFilterChainProxy.WebFilterChainDecorator decorator = (WebFilterChainProxy.WebFilterChainDecorator)this.postProcessor.postProcess(new WebFilterChainProxy.DefaultWebFilterChainDecorator());
/*  89 */     proxy.setFilterChainDecorator(decorator);
/*  90 */     Objects.requireNonNull(proxy); firewall.ifUnique(proxy::setFirewall);
/*  91 */     Objects.requireNonNull(proxy); rejectedHandler.ifUnique(proxy::setExchangeRejectedHandler);
/*  92 */     return proxy;
/*     */   }
/*     */   
/*     */   @Bean(name = {"requestDataValueProcessor"})
/*     */   CsrfRequestDataValueProcessor requestDataValueProcessor() {
/*  97 */     return new CsrfRequestDataValueProcessor();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   static BeanFactoryPostProcessor conversionServicePostProcessor() {
/* 102 */     return (BeanFactoryPostProcessor)new RsaKeyConversionServicePostProcessor();
/*     */   }
/*     */   
/*     */   private List<SecurityWebFilterChain> getSecurityWebFilterChains() {
/* 106 */     List<SecurityWebFilterChain> result = this.securityWebFilterChains;
/* 107 */     if (ObjectUtils.isEmpty(result)) {
/* 108 */       return Arrays.asList(new SecurityWebFilterChain[] { springSecurityFilterChain() });
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */   
/*     */   private SecurityWebFilterChain springSecurityFilterChain() {
/* 114 */     ServerHttpSecurity http = (ServerHttpSecurity)this.context.getBean(ServerHttpSecurity.class);
/* 115 */     return springSecurityFilterChain(http);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
/* 124 */     http.authorizeExchange().anyExchange().authenticated();
/* 125 */     if (isOAuth2Present && OAuth2ClasspathGuard.shouldConfigure(this.context)) {
/* 126 */       OAuth2ClasspathGuard.configure(this.context, http);
/*     */     } else {
/*     */       
/* 129 */       http.httpBasic();
/* 130 */       http.formLogin();
/*     */     } 
/* 132 */     SecurityWebFilterChain result = http.build();
/* 133 */     return result;
/*     */   }
/*     */   
/*     */   private static class OAuth2ClasspathGuard
/*     */   {
/*     */     static void configure(ApplicationContext context, ServerHttpSecurity http) {
/* 139 */       http.oauth2Login();
/* 140 */       http.oauth2Client();
/*     */     }
/*     */     
/*     */     static boolean shouldConfigure(ApplicationContext context) {
/* 144 */       ClassLoader loader = context.getClassLoader();
/*     */       
/* 146 */       Class<?> reactiveClientRegistrationRepositoryClass = ClassUtils.resolveClassName("org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository", loader);
/* 147 */       return ((context.getBeanNamesForType(reactiveClientRegistrationRepositoryClass)).length == 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\WebFluxSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */