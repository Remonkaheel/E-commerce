/*    */ package org.springframework.security.config.annotation.rsocket;
/*    */ 
/*    */ import io.rsocket.plugins.SocketAcceptorInterceptor;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.Customizer;
/*    */ import org.springframework.security.rsocket.api.PayloadExchange;
/*    */ import org.springframework.security.rsocket.core.PayloadSocketAcceptorInterceptor;
/*    */ import org.springframework.security.rsocket.core.SecuritySocketAcceptorInterceptor;
/*    */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcher;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class SecuritySocketAcceptorInterceptorConfiguration
/*    */ {
/*    */   @Bean
/*    */   SecuritySocketAcceptorInterceptor securitySocketAcceptorInterceptor(ObjectProvider<PayloadSocketAcceptorInterceptor> rsocketInterceptor, ObjectProvider<RSocketSecurity> rsocketSecurity) {
/* 40 */     PayloadSocketAcceptorInterceptor delegate = (PayloadSocketAcceptorInterceptor)rsocketInterceptor.getIfAvailable(() -> defaultInterceptor(rsocketSecurity));
/* 41 */     return new SecuritySocketAcceptorInterceptor((SocketAcceptorInterceptor)delegate);
/*    */   }
/*    */   
/*    */   private PayloadSocketAcceptorInterceptor defaultInterceptor(ObjectProvider<RSocketSecurity> rsocketSecurity) {
/* 45 */     RSocketSecurity rsocket = (RSocketSecurity)rsocketSecurity.getIfAvailable();
/* 46 */     if (rsocket == null) {
/* 47 */       throw new NoSuchBeanDefinitionException("No RSocketSecurity defined");
/*    */     }
/*    */     
/* 50 */     rsocket.basicAuthentication(Customizer.withDefaults())
/* 51 */       .simpleAuthentication(Customizer.withDefaults())
/* 52 */       .authorizePayload(authz -> authz.setup().authenticated().anyRequest().authenticated().matcher(()).permitAll());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     return rsocket.build();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\SecuritySocketAcceptorInterceptorConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */