/*    */ package org.springframework.security.config.annotation.rsocket;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*    */ import org.springframework.security.authentication.UserDetailsRepositoryReactiveAuthenticationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ class RSocketSecurityConfiguration
/*    */ {
/*    */   private static final String BEAN_NAME_PREFIX = "org.springframework.security.config.annotation.rsocket.RSocketSecurityConfiguration.";
/*    */   private static final String RSOCKET_SECURITY_BEAN_NAME = "org.springframework.security.config.annotation.rsocket.RSocketSecurityConfiguration.rsocketSecurity";
/*    */   private ReactiveAuthenticationManager authenticationManager;
/*    */   private ReactiveUserDetailsService reactiveUserDetailsService;
/*    */   private PasswordEncoder passwordEncoder;
/* 49 */   private ObjectPostProcessor<ReactiveAuthenticationManager> postProcessor = ObjectPostProcessor.identity();
/*    */   
/*    */   @Autowired(required = false)
/*    */   void setAuthenticationManager(ReactiveAuthenticationManager authenticationManager) {
/* 53 */     this.authenticationManager = authenticationManager;
/*    */   }
/*    */   
/*    */   @Autowired(required = false)
/*    */   void setUserDetailsService(ReactiveUserDetailsService userDetailsService) {
/* 58 */     this.reactiveUserDetailsService = userDetailsService;
/*    */   }
/*    */   
/*    */   @Autowired(required = false)
/*    */   void setPasswordEncoder(PasswordEncoder passwordEncoder) {
/* 63 */     this.passwordEncoder = passwordEncoder;
/*    */   }
/*    */ 
/*    */   
/*    */   @Autowired(required = false)
/*    */   void setAuthenticationManagerPostProcessor(Map<String, ObjectPostProcessor<ReactiveAuthenticationManager>> postProcessors) {
/* 69 */     if (postProcessors.size() == 1) {
/* 70 */       this.postProcessor = postProcessors.values().iterator().next();
/*    */     }
/* 72 */     this.postProcessor = postProcessors.get("rSocketAuthenticationManagerPostProcessor");
/*    */   }
/*    */   
/*    */   @Bean(name = {"org.springframework.security.config.annotation.rsocket.RSocketSecurityConfiguration.rsocketSecurity"})
/*    */   @Scope("prototype")
/*    */   RSocketSecurity rsocketSecurity(ApplicationContext context) {
/* 78 */     RSocketSecurity security = (new RSocketSecurity()).authenticationManager(authenticationManager());
/* 79 */     security.setApplicationContext(context);
/* 80 */     return security;
/*    */   }
/*    */   
/*    */   private ReactiveAuthenticationManager authenticationManager() {
/* 84 */     if (this.authenticationManager != null) {
/* 85 */       return this.authenticationManager;
/*    */     }
/* 87 */     if (this.reactiveUserDetailsService != null) {
/* 88 */       UserDetailsRepositoryReactiveAuthenticationManager manager = new UserDetailsRepositoryReactiveAuthenticationManager(this.reactiveUserDetailsService);
/*    */       
/* 90 */       if (this.passwordEncoder != null) {
/* 91 */         manager.setPasswordEncoder(this.passwordEncoder);
/*    */       }
/* 93 */       return (ReactiveAuthenticationManager)this.postProcessor.postProcess(manager);
/*    */     } 
/* 95 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\RSocketSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */