/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.debug.DebugFilter;
/*     */ import org.springframework.security.web.firewall.HttpFirewall;
/*     */ import org.springframework.security.web.firewall.RequestRejectedHandler;
/*     */ import org.springframework.web.filter.CompositeFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class CompositeFilterChainProxy
/*     */   extends FilterChainProxy
/*     */ {
/*     */   private final Filter doFilterDelegate;
/*     */   private final FilterChainProxy springSecurityFilterChain;
/*     */   
/*     */   CompositeFilterChainProxy(List<? extends Filter> filters) {
/* 228 */     this.doFilterDelegate = createDoFilterDelegate(filters);
/* 229 */     this.springSecurityFilterChain = findFilterChainProxy(filters);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 234 */     this.springSecurityFilterChain.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 240 */     this.doFilterDelegate.doFilter(request, response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Filter> getFilters(String url) {
/* 245 */     return this.springSecurityFilterChain.getFilters(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<SecurityFilterChain> getFilterChains() {
/* 250 */     return this.springSecurityFilterChain.getFilterChains();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 255 */     this.springSecurityFilterChain.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFilterChainValidator(FilterChainProxy.FilterChainValidator filterChainValidator) {
/* 260 */     this.springSecurityFilterChain.setFilterChainValidator(filterChainValidator);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFilterChainDecorator(FilterChainProxy.FilterChainDecorator filterChainDecorator) {
/* 265 */     this.springSecurityFilterChain.setFilterChainDecorator(filterChainDecorator);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFirewall(HttpFirewall firewall) {
/* 270 */     this.springSecurityFilterChain.setFirewall(firewall);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRequestRejectedHandler(RequestRejectedHandler requestRejectedHandler) {
/* 275 */     this.springSecurityFilterChain.setRequestRejectedHandler(requestRejectedHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<? extends Filter> getFilters(HttpServletRequest request) {
/* 285 */     List<SecurityFilterChain> filterChains = this.springSecurityFilterChain.getFilterChains();
/* 286 */     for (SecurityFilterChain chain : filterChains) {
/* 287 */       if (chain.matches(request)) {
/* 288 */         return chain.getFilters();
/*     */       }
/*     */     } 
/* 291 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter createDoFilterDelegate(List<? extends Filter> filters) {
/* 300 */     CompositeFilter delegate = new CompositeFilter();
/* 301 */     delegate.setFilters(filters);
/* 302 */     return (Filter)delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FilterChainProxy findFilterChainProxy(List<? extends Filter> filters) {
/* 312 */     for (Filter filter : filters) {
/* 313 */       if (filter instanceof FilterChainProxy) { FilterChainProxy fcp = (FilterChainProxy)filter;
/* 314 */         return fcp; }
/*     */       
/* 316 */       if (filter instanceof DebugFilter) { DebugFilter debugFilter = (DebugFilter)filter;
/* 317 */         return debugFilter.getFilterChainProxy(); }
/*     */     
/*     */     } 
/* 320 */     throw new IllegalStateException("Couldn't find FilterChainProxy in " + String.valueOf(filters));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\WebMvcSecurityConfiguration$CompositeFilterChainProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */