/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2MetadataConfigurer;
/*    */ import org.springframework.security.saml2.provider.service.metadata.Saml2MetadataResponseResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\017\032\024\022\n\022\b\022\004\022\0020\0220\021\022\004\022\0020\0230\020H\000¢\006\002\b\024R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016¨\006\025"}, d2 = {"Lorg/springframework/security/config/annotation/web/Saml2MetadataDsl;", "", "()V", "metadataResponseResolver", "Lorg/springframework/security/saml2/provider/service/metadata/Saml2MetadataResponseResolver;", "getMetadataResponseResolver", "()Lorg/springframework/security/saml2/provider/service/metadata/Saml2MetadataResponseResolver;", "setMetadataResponseResolver", "(Lorg/springframework/security/saml2/provider/service/metadata/Saml2MetadataResponseResolver;)V", "metadataUrl", "", "getMetadataUrl", "()Ljava/lang/String;", "setMetadataUrl", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2MetadataConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class Saml2MetadataDsl
/*    */ {
/*    */   @Nullable
/*    */   private String metadataUrl;
/*    */   @Nullable
/*    */   private Saml2MetadataResponseResolver metadataResponseResolver;
/*    */   
/*    */   @Nullable
/*    */   public final String getMetadataUrl() {
/* 43 */     return this.metadataUrl; } public final void setMetadataUrl(@Nullable String <set-?>) { this.metadataUrl = <set-?>; } @Nullable
/* 44 */   public final Saml2MetadataResponseResolver getMetadataResponseResolver() { return this.metadataResponseResolver; } public final void setMetadataResponseResolver(@Nullable Saml2MetadataResponseResolver <set-?>) { this.metadataResponseResolver = <set-?>; }
/*    */   
/*    */   @NotNull
/* 47 */   public final Function1<Saml2MetadataConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new Saml2MetadataDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "saml2Metadata", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2MetadataConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nSaml2MetadataDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Saml2MetadataDsl.kt\norg/springframework/security/config/annotation/web/Saml2MetadataDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,53:1\n1#2:54\n*E\n"})
/* 48 */   static final class Saml2MetadataDsl$get$1 extends Lambda implements Function1<Saml2MetadataConfigurer<HttpSecurity>, Unit> { public final void invoke(Saml2MetadataConfigurer saml2Metadata) { Intrinsics.checkNotNullParameter(saml2Metadata, "saml2Metadata"); if (Saml2MetadataDsl.this.getMetadataResponseResolver() != null) { Saml2MetadataResponseResolver saml2MetadataResponseResolver1 = Saml2MetadataDsl.this.getMetadataResponseResolver(); Saml2MetadataDsl saml2MetadataDsl = Saml2MetadataDsl.this; Saml2MetadataResponseResolver it = saml2MetadataResponseResolver1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 54 */         int $i$a$-also-Saml2MetadataDsl$get$1$1 = 0; saml2Metadata.metadataResponseResolver(saml2MetadataDsl.getMetadataResponseResolver()); } else { Saml2MetadataDsl.this.getMetadataResponseResolver(); }  if (Saml2MetadataDsl.this.getMetadataUrl() != null) { String str1 = Saml2MetadataDsl.this.getMetadataUrl(); Saml2MetadataDsl saml2MetadataDsl = Saml2MetadataDsl.this; String it = str1; int $i$a$-also-Saml2MetadataDsl$get$1$2 = 0;
/*    */         saml2Metadata.metadataUrl(saml2MetadataDsl.getMetadataUrl()); }
/*    */       else
/*    */       { Saml2MetadataDsl.this.getMetadataUrl(); }
/*    */        }
/*    */ 
/*    */     
/*    */     Saml2MetadataDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\Saml2MetadataDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */