/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.access.hierarchicalroles.NullRoleHierarchy;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationManagers;
/*     */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*     */ import org.springframework.security.authorization.SpringAuthorizationEventPublisher;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.AbstractRequestMatcherRegistry;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.access.intercept.AuthorizationFilter;
/*     */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*     */ import org.springframework.security.web.access.intercept.RequestMatcherDelegatingAuthorizationManager;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizeHttpRequestsConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<AuthorizeHttpRequestsConfigurer<H>, H>
/*     */ {
/*     */   private final AuthorizationManagerRequestMatcherRegistry registry;
/*     */   private final AuthorizationEventPublisher publisher;
/*     */   private final Supplier<RoleHierarchy> roleHierarchy;
/*  67 */   private String rolePrefix = "ROLE_";
/*     */ 
/*     */   
/*  70 */   private ObjectPostProcessor<AuthorizationManager<HttpServletRequest>> postProcessor = ObjectPostProcessor.identity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizeHttpRequestsConfigurer(ApplicationContext context) {
/*  77 */     this.registry = new AuthorizationManagerRequestMatcherRegistry(context);
/*  78 */     if ((context.getBeanNamesForType(AuthorizationEventPublisher.class)).length > 0) {
/*  79 */       this.publisher = (AuthorizationEventPublisher)context.getBean(AuthorizationEventPublisher.class);
/*     */     } else {
/*     */       
/*  82 */       this.publisher = (AuthorizationEventPublisher)new SpringAuthorizationEventPublisher((ApplicationEventPublisher)context);
/*     */     } 
/*  84 */     this.roleHierarchy = (Supplier<RoleHierarchy>)SingletonSupplier.of(() -> ((context.getBeanNamesForType(RoleHierarchy.class)).length > 0) ? (RoleHierarchy)context.getBean(RoleHierarchy.class) : (RoleHierarchy)new NullRoleHierarchy());
/*     */     
/*  86 */     String[] grantedAuthorityDefaultsBeanNames = context.getBeanNamesForType(GrantedAuthorityDefaults.class);
/*  87 */     if (grantedAuthorityDefaultsBeanNames.length > 0) {
/*  88 */       GrantedAuthorityDefaults grantedAuthorityDefaults = (GrantedAuthorityDefaults)context.getBean(GrantedAuthorityDefaults.class);
/*  89 */       this.rolePrefix = grantedAuthorityDefaults.getRolePrefix();
/*     */     } 
/*  91 */     ResolvableType type = ResolvableType.forClassWithGenerics(ObjectPostProcessor.class, new ResolvableType[] {
/*  92 */           ResolvableType.forClassWithGenerics(AuthorizationManager.class, new Class[] { HttpServletRequest.class })
/*     */         });
/*  94 */     ObjectProvider<ObjectPostProcessor<AuthorizationManager<HttpServletRequest>>> provider = context.getBeanProvider(type);
/*  95 */     provider.ifUnique(postProcessor -> this.postProcessor = postProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManagerRequestMatcherRegistry getRegistry() {
/* 105 */     return this.registry;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 110 */     AuthorizationManager<HttpServletRequest> authorizationManager = this.registry.createAuthorizationManager();
/* 111 */     AuthorizationFilter authorizationFilter = new AuthorizationFilter(authorizationManager);
/* 112 */     authorizationFilter.setAuthorizationEventPublisher(this.publisher);
/* 113 */     authorizationFilter.setShouldFilterAllDispatcherTypes(this.registry.shouldFilterAllDispatcherTypes);
/* 114 */     authorizationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 115 */     http.addFilter((Filter)postProcess(authorizationFilter));
/*     */   }
/*     */ 
/*     */   
/*     */   private AuthorizationManagerRequestMatcherRegistry addMapping(List<? extends RequestMatcher> matchers, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 120 */     for (RequestMatcher matcher : matchers) {
/* 121 */       this.registry.addMapping(matcher, manager);
/*     */     }
/* 123 */     return this.registry;
/*     */   }
/*     */ 
/*     */   
/*     */   AuthorizationManagerRequestMatcherRegistry addFirst(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 128 */     this.registry.addFirst(matcher, manager);
/* 129 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class AuthorizationManagerRequestMatcherRegistry
/*     */     extends AbstractRequestMatcherRegistry<AuthorizedUrl>
/*     */   {
/* 141 */     private final RequestMatcherDelegatingAuthorizationManager.Builder managerBuilder = RequestMatcherDelegatingAuthorizationManager.builder();
/*     */     
/*     */     private List<RequestMatcher> unmappedMatchers;
/*     */     
/*     */     private int mappingCount;
/*     */     
/*     */     private boolean shouldFilterAllDispatcherTypes = true;
/*     */     
/*     */     private AuthorizationManagerRequestMatcherRegistry(ApplicationContext context) {
/* 150 */       setApplicationContext(context);
/*     */     }
/*     */     
/*     */     private void addMapping(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 154 */       this.unmappedMatchers = null;
/* 155 */       this.managerBuilder.add(matcher, manager);
/* 156 */       this.mappingCount++;
/*     */     }
/*     */     
/*     */     private void addFirst(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 160 */       this.unmappedMatchers = null;
/* 161 */       this.managerBuilder.mappings(m -> m.add(0, new RequestMatcherEntry(matcher, manager)));
/* 162 */       this.mappingCount++;
/*     */     }
/*     */     
/*     */     private AuthorizationManager<HttpServletRequest> createAuthorizationManager() {
/* 166 */       Assert.state((this.unmappedMatchers == null), () -> "An incomplete mapping was found for " + String.valueOf(this.unmappedMatchers) + ". Try completing it with something like requestUrls().<something>.hasRole('USER')");
/*     */ 
/*     */       
/* 169 */       Assert.state((this.mappingCount > 0), "At least one mapping is required (for example, authorizeHttpRequests().anyRequest().authenticated())");
/*     */       
/* 171 */       AuthorizationManager<HttpServletRequest> manager = (AuthorizationManager<HttpServletRequest>)AuthorizeHttpRequestsConfigurer.this.postProcess(this.managerBuilder
/* 172 */           .build());
/* 173 */       return (AuthorizationManager<HttpServletRequest>)AuthorizeHttpRequestsConfigurer.this.postProcessor.postProcess(manager);
/*     */     }
/*     */ 
/*     */     
/*     */     protected AuthorizeHttpRequestsConfigurer<H>.AuthorizedUrl chainRequestMatchers(List<RequestMatcher> requestMatchers) {
/* 178 */       this.unmappedMatchers = requestMatchers;
/* 179 */       return new AuthorizeHttpRequestsConfigurer.AuthorizedUrl(requestMatchers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizationManagerRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 190 */       AuthorizeHttpRequestsConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 191 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.4", forRemoval = true)
/*     */     public AuthorizationManagerRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 200 */       AuthorizeHttpRequestsConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 201 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public AuthorizationManagerRequestMatcherRegistry shouldFilterAllDispatcherTypes(boolean shouldFilter) {
/* 230 */       this.shouldFilterAllDispatcherTypes = shouldFilter;
/* 231 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public H and() {
/* 242 */       return (H)AuthorizeHttpRequestsConfigurer.this.and();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class AuthorizedUrl
/*     */   {
/*     */     private final List<? extends RequestMatcher> matchers;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean not;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AuthorizedUrl(List<? extends RequestMatcher> matchers) {
/* 265 */       this.matchers = matchers;
/*     */     }
/*     */     
/*     */     protected List<? extends RequestMatcher> getMatchers() {
/* 269 */       return this.matchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizedUrl not() {
/* 278 */       this.not = true;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry permitAll() {
/* 288 */       return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.permitAll());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry denyAll() {
/* 297 */       return access((AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.denyAll());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry hasRole(String role) {
/* 308 */       return access((AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(
/* 309 */             AuthorityAuthorizationManager.hasAnyRole(AuthorizeHttpRequestsConfigurer.this.rolePrefix, new String[] { role })));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry hasAnyRole(String... roles) {
/* 321 */       return access((AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(
/* 322 */             AuthorityAuthorizationManager.hasAnyRole(AuthorizeHttpRequestsConfigurer.this.rolePrefix, roles)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry hasAuthority(String authority) {
/* 332 */       return access((AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(AuthorityAuthorizationManager.hasAuthority(authority)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry hasAnyAuthority(String... authorities) {
/* 343 */       return access((AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(AuthorityAuthorizationManager.hasAnyAuthority(authorities)));
/*     */     }
/*     */ 
/*     */     
/*     */     private AuthorityAuthorizationManager<RequestAuthorizationContext> withRoleHierarchy(AuthorityAuthorizationManager<RequestAuthorizationContext> manager) {
/* 348 */       manager.setRoleHierarchy(AuthorizeHttpRequestsConfigurer.this.roleHierarchy.get());
/* 349 */       return manager;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry authenticated() {
/* 358 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry fullyAuthenticated() {
/* 370 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry rememberMe() {
/* 381 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.rememberMe());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry anonymous() {
/* 391 */       return access((AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.anonymous());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizedUrlVariable hasVariable(String variable) {
/* 406 */       return new AuthorizedUrlVariable(variable);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry access(AuthorizationManager<RequestAuthorizationContext> manager) {
/* 417 */       Assert.notNull(manager, "manager cannot be null");
/* 418 */       return this.not ? 
/* 419 */         AuthorizeHttpRequestsConfigurer.this.addMapping(this.matchers, AuthorizationManagers.not(manager)) : 
/* 420 */         AuthorizeHttpRequestsConfigurer.this.addMapping(this.matchers, manager);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final class AuthorizedUrlVariable
/*     */     {
/*     */       private final String variable;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private AuthorizedUrlVariable(String variable) {
/* 435 */         this.variable = variable;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry equalTo(Function<Authentication, String> function)
/*     */       {
/* 450 */         return AuthorizeHttpRequestsConfigurer.AuthorizedUrl.this.access((auth, requestContext) -> { String value = (String)requestContext.getVariables().get(this.variable); return new AuthorizationDecision(((String)function.apply(auth.get())).equals(value)); }); } } } public final class AuthorizedUrlVariable { public AuthorizeHttpRequestsConfigurer<H>.AuthorizationManagerRequestMatcherRegistry equalTo(Function<Authentication, String> function) { return AuthorizeHttpRequestsConfigurer.AuthorizedUrl.this.access((auth, requestContext) -> {
/*     */             String value = (String)requestContext.getVariables().get(this.variable);
/*     */             return new AuthorizationDecision(((String)function.apply(auth.get())).equals(value));
/*     */           }); }
/*     */ 
/*     */     
/*     */     private final String variable;
/*     */     
/*     */     private AuthorizedUrlVariable(String variable) {
/*     */       this.variable = variable;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AuthorizeHttpRequestsConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */