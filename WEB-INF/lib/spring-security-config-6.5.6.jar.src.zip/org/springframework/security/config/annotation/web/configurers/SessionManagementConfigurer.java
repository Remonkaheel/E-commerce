/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.GenericApplicationListenerAdapter;
/*     */ import org.springframework.context.event.SmartApplicationListener;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.http.SessionCreationPolicy;
/*     */ import org.springframework.security.context.DelegatingApplicationListener;
/*     */ import org.springframework.security.core.session.SessionRegistry;
/*     */ import org.springframework.security.core.session.SessionRegistryImpl;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.session.ChangeSessionIdAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.session.CompositeSessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.session.ConcurrentSessionControlAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
/*     */ import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.session.SessionFixationProtectionStrategy;
/*     */ import org.springframework.security.web.authentication.session.SessionLimit;
/*     */ import org.springframework.security.web.context.DelegatingSecurityContextRepository;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.NullSecurityContextRepository;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.savedrequest.NullRequestCache;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.security.web.session.ConcurrentSessionFilter;
/*     */ import org.springframework.security.web.session.DisableEncodeUrlFilter;
/*     */ import org.springframework.security.web.session.ForceEagerSessionCreationFilter;
/*     */ import org.springframework.security.web.session.InvalidSessionStrategy;
/*     */ import org.springframework.security.web.session.SessionInformationExpiredStrategy;
/*     */ import org.springframework.security.web.session.SessionManagementFilter;
/*     */ import org.springframework.security.web.session.SimpleRedirectInvalidSessionStrategy;
/*     */ import org.springframework.security.web.session.SimpleRedirectSessionInformationExpiredStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SessionManagementConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<SessionManagementConfigurer<H>, H>
/*     */ {
/* 111 */   private final SessionAuthenticationStrategy DEFAULT_SESSION_FIXATION_STRATEGY = createDefaultSessionFixationProtectionStrategy();
/*     */   
/* 113 */   private SessionAuthenticationStrategy sessionFixationAuthenticationStrategy = this.DEFAULT_SESSION_FIXATION_STRATEGY;
/*     */   
/*     */   private SessionAuthenticationStrategy sessionAuthenticationStrategy;
/*     */   
/*     */   private SessionAuthenticationStrategy providedSessionAuthenticationStrategy;
/*     */   
/*     */   private InvalidSessionStrategy invalidSessionStrategy;
/*     */   
/*     */   private SessionInformationExpiredStrategy expiredSessionStrategy;
/*     */   
/* 123 */   private List<SessionAuthenticationStrategy> sessionAuthenticationStrategies = new ArrayList<>();
/*     */   
/*     */   private SessionRegistry sessionRegistry;
/*     */   
/*     */   private SessionLimit sessionLimit;
/*     */   
/*     */   private String expiredUrl;
/*     */   
/*     */   private boolean maxSessionsPreventsLogin;
/*     */   
/*     */   private SessionCreationPolicy sessionPolicy;
/*     */   
/*     */   private boolean enableSessionUrlRewriting;
/*     */   
/*     */   private String invalidSessionUrl;
/*     */   
/*     */   private String sessionAuthenticationErrorUrl;
/*     */   
/*     */   private AuthenticationFailureHandler sessionAuthenticationFailureHandler;
/*     */   
/* 143 */   private Set<String> propertiesThatRequireImplicitAuthentication = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean requireExplicitAuthenticationStrategy;
/*     */ 
/*     */ 
/*     */   
/* 151 */   private SecurityContextRepository sessionManagementSecurityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> invalidSessionUrl(String invalidSessionUrl) {
/* 169 */     this.invalidSessionUrl = invalidSessionUrl;
/* 170 */     this.propertiesThatRequireImplicitAuthentication.add("invalidSessionUrl = " + invalidSessionUrl);
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> requireExplicitAuthenticationStrategy(boolean requireExplicitAuthenticationStrategy) {
/* 183 */     this.requireExplicitAuthenticationStrategy = Boolean.valueOf(requireExplicitAuthenticationStrategy);
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> invalidSessionStrategy(InvalidSessionStrategy invalidSessionStrategy) {
/* 196 */     Assert.notNull(invalidSessionStrategy, "invalidSessionStrategy");
/* 197 */     this.invalidSessionStrategy = invalidSessionStrategy;
/* 198 */     this.propertiesThatRequireImplicitAuthentication.add("invalidSessionStrategy = " + String.valueOf(invalidSessionStrategy));
/* 199 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> sessionAuthenticationErrorUrl(String sessionAuthenticationErrorUrl) {
/* 212 */     this.sessionAuthenticationErrorUrl = sessionAuthenticationErrorUrl;
/* 213 */     this.propertiesThatRequireImplicitAuthentication
/* 214 */       .add("sessionAuthenticationErrorUrl = " + sessionAuthenticationErrorUrl);
/* 215 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> sessionAuthenticationFailureHandler(AuthenticationFailureHandler sessionAuthenticationFailureHandler) {
/* 229 */     this.sessionAuthenticationFailureHandler = sessionAuthenticationFailureHandler;
/* 230 */     this.propertiesThatRequireImplicitAuthentication
/* 231 */       .add("sessionAuthenticationFailureHandler = " + String.valueOf(sessionAuthenticationFailureHandler));
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> enableSessionUrlRewriting(boolean enableSessionUrlRewriting) {
/* 252 */     this.enableSessionUrlRewriting = enableSessionUrlRewriting;
/* 253 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> sessionCreationPolicy(SessionCreationPolicy sessionCreationPolicy) {
/* 265 */     Assert.notNull(sessionCreationPolicy, "sessionCreationPolicy cannot be null");
/* 266 */     this.sessionPolicy = sessionCreationPolicy;
/* 267 */     this.propertiesThatRequireImplicitAuthentication.add("sessionCreationPolicy = " + String.valueOf(sessionCreationPolicy));
/* 268 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> sessionAuthenticationStrategy(SessionAuthenticationStrategy sessionAuthenticationStrategy) {
/* 288 */     this.providedSessionAuthenticationStrategy = sessionAuthenticationStrategy;
/* 289 */     this.propertiesThatRequireImplicitAuthentication
/* 290 */       .add("sessionAuthenticationStrategy = " + String.valueOf(sessionAuthenticationStrategy));
/* 291 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> addSessionAuthenticationStrategy(SessionAuthenticationStrategy sessionAuthenticationStrategy) {
/* 302 */     this.sessionAuthenticationStrategies.add(sessionAuthenticationStrategy);
/* 303 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionFixationConfigurer sessionFixation() {
/* 311 */     return new SessionFixationConfigurer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> sessionFixation(Customizer<SessionFixationConfigurer> sessionFixationCustomizer) {
/* 322 */     sessionFixationCustomizer.customize(new SessionFixationConfigurer());
/* 323 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrencyControlConfigurer maximumSessions(int maximumSessions) {
/* 333 */     this.sessionLimit = SessionLimit.of(maximumSessions);
/* 334 */     this.propertiesThatRequireImplicitAuthentication.add("maximumSessions = " + maximumSessions);
/* 335 */     return new ConcurrencyControlConfigurer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionManagementConfigurer<H> sessionConcurrency(Customizer<ConcurrencyControlConfigurer> sessionConcurrencyCustomizer) {
/* 347 */     sessionConcurrencyCustomizer.customize(new ConcurrencyControlConfigurer());
/* 348 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSessionFixationAuthenticationStrategy(SessionAuthenticationStrategy sessionFixationAuthenticationStrategy) {
/* 358 */     this.sessionFixationAuthenticationStrategy = (SessionAuthenticationStrategy)postProcess(sessionFixationAuthenticationStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 363 */     SecurityContextRepository securityContextRepository = (SecurityContextRepository)http.getSharedObject(SecurityContextRepository.class);
/* 364 */     boolean stateless = isStateless();
/* 365 */     if (securityContextRepository == null) {
/* 366 */       if (stateless) {
/* 367 */         http.setSharedObject(SecurityContextRepository.class, new RequestAttributeSecurityContextRepository());
/* 368 */         this.sessionManagementSecurityContextRepository = (SecurityContextRepository)new NullSecurityContextRepository();
/*     */       } else {
/*     */         
/* 371 */         HttpSessionSecurityContextRepository httpSecurityRepository = new HttpSessionSecurityContextRepository();
/* 372 */         httpSecurityRepository.setDisableUrlRewriting(!this.enableSessionUrlRewriting);
/* 373 */         httpSecurityRepository.setAllowSessionCreation(isAllowSessionCreation());
/* 374 */         AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)http.getSharedObject(AuthenticationTrustResolver.class);
/* 375 */         if (trustResolver != null) {
/* 376 */           httpSecurityRepository.setTrustResolver(trustResolver);
/*     */         }
/* 378 */         this.sessionManagementSecurityContextRepository = (SecurityContextRepository)httpSecurityRepository;
/* 379 */         DelegatingSecurityContextRepository defaultRepository = new DelegatingSecurityContextRepository(new SecurityContextRepository[] { (SecurityContextRepository)httpSecurityRepository, (SecurityContextRepository)new RequestAttributeSecurityContextRepository() });
/*     */         
/* 381 */         http.setSharedObject(SecurityContextRepository.class, defaultRepository);
/*     */       } 
/*     */     } else {
/*     */       
/* 385 */       this.sessionManagementSecurityContextRepository = securityContextRepository;
/*     */     } 
/* 387 */     RequestCache requestCache = (RequestCache)http.getSharedObject(RequestCache.class);
/* 388 */     if (requestCache == null && 
/* 389 */       stateless) {
/* 390 */       http.setSharedObject(RequestCache.class, new NullRequestCache());
/*     */     }
/*     */     
/* 393 */     http.setSharedObject(SessionAuthenticationStrategy.class, getSessionAuthenticationStrategy(http));
/* 394 */     http.setSharedObject(InvalidSessionStrategy.class, getInvalidSessionStrategy());
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 399 */     SessionManagementFilter sessionManagementFilter = createSessionManagementFilter(http);
/* 400 */     if (sessionManagementFilter != null) {
/* 401 */       http.addFilter((Filter)sessionManagementFilter);
/*     */     }
/* 403 */     if (isConcurrentSessionControlEnabled()) {
/* 404 */       ConcurrentSessionFilter concurrentSessionFilter = createConcurrencyFilter(http);
/*     */       
/* 406 */       concurrentSessionFilter = (ConcurrentSessionFilter)postProcess(concurrentSessionFilter);
/* 407 */       http.addFilter((Filter)concurrentSessionFilter);
/*     */     } 
/* 409 */     if (!this.enableSessionUrlRewriting) {
/* 410 */       http.addFilter((Filter)new DisableEncodeUrlFilter());
/*     */     }
/* 412 */     if (this.sessionPolicy == SessionCreationPolicy.ALWAYS) {
/* 413 */       http.addFilter((Filter)new ForceEagerSessionCreationFilter());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean shouldRequireExplicitAuthenticationStrategy() {
/* 419 */     boolean defaultRequireExplicitAuthenticationStrategy = this.propertiesThatRequireImplicitAuthentication.isEmpty();
/* 420 */     if (this.requireExplicitAuthenticationStrategy == null)
/*     */     {
/* 422 */       return defaultRequireExplicitAuthenticationStrategy;
/*     */     }
/* 424 */     if (this.requireExplicitAuthenticationStrategy.booleanValue() && !defaultRequireExplicitAuthenticationStrategy)
/*     */     {
/* 426 */       throw new IllegalStateException("Invalid configuration that explicitly sets requireExplicitAuthenticationStrategy to " + this.requireExplicitAuthenticationStrategy + " but implicitly requires it due to the following properties being set: " + String.valueOf(this.propertiesThatRequireImplicitAuthentication));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     return this.requireExplicitAuthenticationStrategy.booleanValue();
/*     */   }
/*     */   
/*     */   private SessionManagementFilter createSessionManagementFilter(H http) {
/* 436 */     if (shouldRequireExplicitAuthenticationStrategy()) {
/* 437 */       return null;
/*     */     }
/* 439 */     SecurityContextRepository securityContextRepository = this.sessionManagementSecurityContextRepository;
/*     */     
/* 441 */     SessionManagementFilter sessionManagementFilter = new SessionManagementFilter(securityContextRepository, getSessionAuthenticationStrategy(http));
/* 442 */     if (this.sessionAuthenticationErrorUrl != null) {
/* 443 */       sessionManagementFilter.setAuthenticationFailureHandler((AuthenticationFailureHandler)new SimpleUrlAuthenticationFailureHandler(this.sessionAuthenticationErrorUrl));
/*     */     }
/*     */     
/* 446 */     InvalidSessionStrategy strategy = getInvalidSessionStrategy();
/* 447 */     if (strategy != null) {
/* 448 */       sessionManagementFilter.setInvalidSessionStrategy(strategy);
/*     */     }
/* 450 */     AuthenticationFailureHandler failureHandler = getSessionAuthenticationFailureHandler();
/* 451 */     if (failureHandler != null) {
/* 452 */       sessionManagementFilter.setAuthenticationFailureHandler(failureHandler);
/*     */     }
/* 454 */     AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)http.getSharedObject(AuthenticationTrustResolver.class);
/* 455 */     if (trustResolver != null) {
/* 456 */       sessionManagementFilter.setTrustResolver(trustResolver);
/*     */     }
/* 458 */     sessionManagementFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 459 */     return (SessionManagementFilter)postProcess(sessionManagementFilter);
/*     */   }
/*     */   
/*     */   private ConcurrentSessionFilter createConcurrencyFilter(H http) {
/* 463 */     SessionInformationExpiredStrategy expireStrategy = getExpiredSessionStrategy();
/* 464 */     SessionRegistry sessionRegistry = getSessionRegistry(http);
/*     */ 
/*     */     
/* 467 */     ConcurrentSessionFilter concurrentSessionFilter = (expireStrategy != null) ? new ConcurrentSessionFilter(sessionRegistry, expireStrategy) : new ConcurrentSessionFilter(sessionRegistry);
/* 468 */     LogoutConfigurer<H> logoutConfigurer = (LogoutConfigurer<H>)http.getConfigurer(LogoutConfigurer.class);
/* 469 */     if (logoutConfigurer != null) {
/* 470 */       List<LogoutHandler> logoutHandlers = logoutConfigurer.getLogoutHandlers();
/* 471 */       if (!CollectionUtils.isEmpty(logoutHandlers)) {
/* 472 */         concurrentSessionFilter.setLogoutHandlers(logoutHandlers);
/*     */       }
/*     */     } 
/* 475 */     concurrentSessionFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 476 */     return concurrentSessionFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InvalidSessionStrategy getInvalidSessionStrategy() {
/* 486 */     if (this.invalidSessionStrategy != null) {
/* 487 */       return this.invalidSessionStrategy;
/*     */     }
/* 489 */     if (this.invalidSessionUrl == null) {
/* 490 */       return null;
/*     */     }
/* 492 */     this.invalidSessionStrategy = (InvalidSessionStrategy)new SimpleRedirectInvalidSessionStrategy(this.invalidSessionUrl);
/* 493 */     return this.invalidSessionStrategy;
/*     */   }
/*     */   
/*     */   SessionInformationExpiredStrategy getExpiredSessionStrategy() {
/* 497 */     if (this.expiredSessionStrategy != null) {
/* 498 */       return this.expiredSessionStrategy;
/*     */     }
/* 500 */     if (this.expiredUrl == null) {
/* 501 */       return null;
/*     */     }
/* 503 */     this.expiredSessionStrategy = (SessionInformationExpiredStrategy)new SimpleRedirectSessionInformationExpiredStrategy(this.expiredUrl);
/* 504 */     return this.expiredSessionStrategy;
/*     */   }
/*     */   
/*     */   AuthenticationFailureHandler getSessionAuthenticationFailureHandler() {
/* 508 */     if (this.sessionAuthenticationFailureHandler != null) {
/* 509 */       return this.sessionAuthenticationFailureHandler;
/*     */     }
/* 511 */     if (this.sessionAuthenticationErrorUrl == null) {
/* 512 */       return null;
/*     */     }
/* 514 */     this.sessionAuthenticationFailureHandler = (AuthenticationFailureHandler)new SimpleUrlAuthenticationFailureHandler(this.sessionAuthenticationErrorUrl);
/*     */     
/* 516 */     return this.sessionAuthenticationFailureHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SessionCreationPolicy getSessionCreationPolicy() {
/* 524 */     if (this.sessionPolicy != null) {
/* 525 */       return this.sessionPolicy;
/*     */     }
/* 527 */     SessionCreationPolicy sessionPolicy = (SessionCreationPolicy)((HttpSecurityBuilder)getBuilder()).getSharedObject(SessionCreationPolicy.class);
/* 528 */     return (sessionPolicy != null) ? sessionPolicy : SessionCreationPolicy.IF_REQUIRED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAllowSessionCreation() {
/* 537 */     SessionCreationPolicy sessionPolicy = getSessionCreationPolicy();
/* 538 */     return (SessionCreationPolicy.ALWAYS == sessionPolicy || SessionCreationPolicy.IF_REQUIRED == sessionPolicy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isStateless() {
/* 546 */     SessionCreationPolicy sessionPolicy = getSessionCreationPolicy();
/* 547 */     return (SessionCreationPolicy.STATELESS == sessionPolicy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SessionAuthenticationStrategy getSessionAuthenticationStrategy(H http) {
/*     */     SessionAuthenticationStrategy defaultSessionAuthenticationStrategy;
/* 557 */     if (this.sessionAuthenticationStrategy != null) {
/* 558 */       return this.sessionAuthenticationStrategy;
/*     */     }
/* 560 */     List<SessionAuthenticationStrategy> delegateStrategies = this.sessionAuthenticationStrategies;
/*     */     
/* 562 */     if (this.providedSessionAuthenticationStrategy == null) {
/*     */ 
/*     */       
/* 565 */       defaultSessionAuthenticationStrategy = (SessionAuthenticationStrategy)postProcess(this.sessionFixationAuthenticationStrategy);
/*     */     } else {
/*     */       
/* 568 */       defaultSessionAuthenticationStrategy = this.providedSessionAuthenticationStrategy;
/*     */     } 
/* 570 */     if (isConcurrentSessionControlEnabled()) {
/* 571 */       SessionRegistry sessionRegistry = getSessionRegistry(http);
/* 572 */       ConcurrentSessionControlAuthenticationStrategy concurrentSessionControlStrategy = new ConcurrentSessionControlAuthenticationStrategy(sessionRegistry);
/*     */       
/* 574 */       concurrentSessionControlStrategy.setMaximumSessions(this.sessionLimit);
/* 575 */       concurrentSessionControlStrategy.setExceptionIfMaximumExceeded(this.maxSessionsPreventsLogin);
/* 576 */       concurrentSessionControlStrategy = (ConcurrentSessionControlAuthenticationStrategy)postProcess(concurrentSessionControlStrategy);
/* 577 */       RegisterSessionAuthenticationStrategy registerSessionStrategy = new RegisterSessionAuthenticationStrategy(sessionRegistry);
/*     */       
/* 579 */       registerSessionStrategy = (RegisterSessionAuthenticationStrategy)postProcess(registerSessionStrategy);
/*     */       
/* 581 */       delegateStrategies.addAll(Arrays.asList(new SessionAuthenticationStrategy[] { (SessionAuthenticationStrategy)concurrentSessionControlStrategy, defaultSessionAuthenticationStrategy, (SessionAuthenticationStrategy)registerSessionStrategy }));
/*     */     }
/*     */     else {
/*     */       
/* 585 */       delegateStrategies.add(defaultSessionAuthenticationStrategy);
/*     */     } 
/* 587 */     this.sessionAuthenticationStrategy = (SessionAuthenticationStrategy)postProcess(new CompositeSessionAuthenticationStrategy(delegateStrategies));
/*     */     
/* 589 */     return this.sessionAuthenticationStrategy;
/*     */   }
/*     */   
/*     */   private SessionRegistry getSessionRegistry(H http) {
/* 593 */     if (this.sessionRegistry == null) {
/* 594 */       this.sessionRegistry = getBeanOrNull(SessionRegistry.class);
/*     */     }
/* 596 */     if (this.sessionRegistry == null) {
/* 597 */       SessionRegistryImpl sessionRegistry = new SessionRegistryImpl();
/* 598 */       registerDelegateApplicationListener(http, (ApplicationListener<?>)sessionRegistry);
/* 599 */       this.sessionRegistry = (SessionRegistry)sessionRegistry;
/*     */     } 
/* 601 */     return this.sessionRegistry;
/*     */   }
/*     */   
/*     */   private void registerDelegateApplicationListener(H http, ApplicationListener<?> delegate) {
/* 605 */     DelegatingApplicationListener delegating = getBeanOrNull(DelegatingApplicationListener.class);
/* 606 */     if (delegating == null) {
/*     */       return;
/*     */     }
/* 609 */     GenericApplicationListenerAdapter genericApplicationListenerAdapter = new GenericApplicationListenerAdapter(delegate);
/* 610 */     delegating.addListener((SmartApplicationListener)genericApplicationListenerAdapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isConcurrentSessionControlEnabled() {
/* 618 */     return (this.sessionLimit != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SessionAuthenticationStrategy createDefaultSessionFixationProtectionStrategy() {
/* 626 */     return (SessionAuthenticationStrategy)new ChangeSessionIdAuthenticationStrategy();
/*     */   }
/*     */   
/*     */   private <T> T getBeanOrNull(Class<T> type) {
/* 630 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 631 */     if (context == null) {
/* 632 */       return null;
/*     */     }
/*     */     
/* 635 */     return (T)context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class SessionFixationConfigurer
/*     */   {
/*     */     public SessionManagementConfigurer<H> newSession() {
/* 651 */       SessionFixationProtectionStrategy sessionFixationProtectionStrategy = new SessionFixationProtectionStrategy();
/* 652 */       sessionFixationProtectionStrategy.setMigrateSessionAttributes(false);
/* 653 */       SessionManagementConfigurer.this.setSessionFixationAuthenticationStrategy((SessionAuthenticationStrategy)sessionFixationProtectionStrategy);
/* 654 */       return SessionManagementConfigurer.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SessionManagementConfigurer<H> migrateSession() {
/* 663 */       SessionManagementConfigurer.this.setSessionFixationAuthenticationStrategy((SessionAuthenticationStrategy)new SessionFixationProtectionStrategy());
/* 664 */       return SessionManagementConfigurer.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SessionManagementConfigurer<H> changeSessionId() {
/* 675 */       SessionManagementConfigurer.this.setSessionFixationAuthenticationStrategy((SessionAuthenticationStrategy)new ChangeSessionIdAuthenticationStrategy());
/* 676 */       return SessionManagementConfigurer.this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SessionManagementConfigurer<H> none() {
/* 687 */       SessionManagementConfigurer.this.setSessionFixationAuthenticationStrategy((SessionAuthenticationStrategy)new NullAuthenticatedSessionStrategy());
/* 688 */       return SessionManagementConfigurer.this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class ConcurrencyControlConfigurer
/*     */   {
/*     */     public ConcurrencyControlConfigurer maximumSessions(int maximumSessions) {
/* 710 */       SessionManagementConfigurer.this.sessionLimit = SessionLimit.of(maximumSessions);
/* 711 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrencyControlConfigurer maximumSessions(SessionLimit sessionLimit) {
/* 722 */       SessionManagementConfigurer.this.sessionLimit = sessionLimit;
/* 723 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrencyControlConfigurer expiredUrl(String expiredUrl) {
/* 734 */       SessionManagementConfigurer.this.expiredUrl = expiredUrl;
/* 735 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrencyControlConfigurer expiredSessionStrategy(SessionInformationExpiredStrategy expiredSessionStrategy) {
/* 746 */       SessionManagementConfigurer.this.expiredSessionStrategy = expiredSessionStrategy;
/* 747 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrencyControlConfigurer maxSessionsPreventsLogin(boolean maxSessionsPreventsLogin) {
/* 763 */       SessionManagementConfigurer.this.maxSessionsPreventsLogin = maxSessionsPreventsLogin;
/* 764 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConcurrencyControlConfigurer sessionRegistry(SessionRegistry sessionRegistry) {
/* 774 */       SessionManagementConfigurer.this.sessionRegistry = sessionRegistry;
/* 775 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public SessionManagementConfigurer<H> and() {
/* 786 */       return SessionManagementConfigurer.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\SessionManagementConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */