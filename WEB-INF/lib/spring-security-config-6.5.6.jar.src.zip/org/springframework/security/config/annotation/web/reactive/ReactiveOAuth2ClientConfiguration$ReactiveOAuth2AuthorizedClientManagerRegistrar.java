/*     */ package org.springframework.security.config.annotation.web.reactive;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.context.annotation.AnnotationBeanNameGenerator;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.oauth2.client.AuthorizationCodeReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.ClientCredentialsReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.DelegatingReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.JwtBearerReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.PasswordReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.RefreshTokenReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.TokenExchangeReactiveOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.endpoint.JwtBearerGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2PasswordGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2RefreshTokenGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.ReactiveOAuth2AccessTokenResponseClient;
/*     */ import org.springframework.security.oauth2.client.endpoint.TokenExchangeGrantRequest;
/*     */ import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.DefaultReactiveOAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.web.server.AuthenticatedPrincipalServerOAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ReactiveOAuth2AuthorizedClientManagerRegistrar
/*     */   implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware
/*     */ {
/*     */   static final String BEAN_NAME = "authorizedClientManagerRegistrar";
/*     */   static final String FACTORY_METHOD_NAME = "getAuthorizedClientManager";
/* 136 */   private static final Set<Class<?>> KNOWN_AUTHORIZED_CLIENT_PROVIDERS = Set.of(AuthorizationCodeReactiveOAuth2AuthorizedClientProvider.class, RefreshTokenReactiveOAuth2AuthorizedClientProvider.class, ClientCredentialsReactiveOAuth2AuthorizedClientProvider.class, PasswordReactiveOAuth2AuthorizedClientProvider.class, JwtBearerReactiveOAuth2AuthorizedClientProvider.class, TokenExchangeReactiveOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private final AnnotationBeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */   
/*     */   private ListableBeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 152 */     if ((getBeanNamesForType((Class)ReactiveOAuth2AuthorizedClientManager.class)).length != 0 || (
/* 153 */       getBeanNamesForType((Class)ReactiveClientRegistrationRepository.class)).length != 1 || ((
/* 154 */       getBeanNamesForType((Class)ServerOAuth2AuthorizedClientRepository.class)).length != 1 && (
/* 155 */       getBeanNamesForType((Class)ReactiveOAuth2AuthorizedClientService.class)).length != 1)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(ReactiveOAuth2AuthorizedClientManager.class).setFactoryMethodOnBean("getAuthorizedClientManager", "authorizedClientManagerRegistrar").getBeanDefinition();
/*     */     
/* 164 */     registry.registerBeanDefinition(this.beanNameGenerator.generateBeanName((BeanDefinition)abstractBeanDefinition, registry), (BeanDefinition)abstractBeanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 170 */     this.beanFactory = (ListableBeanFactory)beanFactory;
/*     */   }
/*     */   
/*     */   ReactiveOAuth2AuthorizedClientManager getAuthorizedClientManagerIfAvailable() {
/* 174 */     if ((getBeanNamesForType((Class)ReactiveClientRegistrationRepository.class)).length != 1 || ((
/* 175 */       getBeanNamesForType((Class)ServerOAuth2AuthorizedClientRepository.class)).length != 1 && (
/* 176 */       getBeanNamesForType((Class)ReactiveOAuth2AuthorizedClientService.class)).length != 1)) {
/* 177 */       return null;
/*     */     }
/* 179 */     return getAuthorizedClientManager();
/*     */   }
/*     */   ReactiveOAuth2AuthorizedClientManager getAuthorizedClientManager() {
/*     */     AuthenticatedPrincipalServerOAuth2AuthorizedClientRepository authenticatedPrincipalServerOAuth2AuthorizedClientRepository;
/*     */     DelegatingReactiveOAuth2AuthorizedClientProvider delegatingReactiveOAuth2AuthorizedClientProvider;
/* 184 */     ReactiveClientRegistrationRepository clientRegistrationRepository = (ReactiveClientRegistrationRepository)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, ReactiveClientRegistrationRepository.class, true, true);
/*     */ 
/*     */     
/*     */     try {
/* 188 */       ServerOAuth2AuthorizedClientRepository authorizedClientRepository = (ServerOAuth2AuthorizedClientRepository)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, ServerOAuth2AuthorizedClientRepository.class, true, true);
/*     */     
/*     */     }
/* 191 */     catch (NoSuchBeanDefinitionException ex) {
/*     */       
/* 193 */       ReactiveOAuth2AuthorizedClientService authorizedClientService = (ReactiveOAuth2AuthorizedClientService)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, ReactiveOAuth2AuthorizedClientService.class, true, true);
/*     */       
/* 195 */       authenticatedPrincipalServerOAuth2AuthorizedClientRepository = new AuthenticatedPrincipalServerOAuth2AuthorizedClientRepository(authorizedClientService);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviderBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(this.beanFactory, ReactiveOAuth2AuthorizedClientProvider.class, true, true).values();
/*     */ 
/*     */     
/* 205 */     if (hasDelegatingAuthorizedClientProvider(authorizedClientProviderBeans)) {
/* 206 */       ReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = authorizedClientProviderBeans.iterator().next();
/*     */     } else {
/*     */       
/* 209 */       List<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders = new ArrayList<>();
/* 210 */       authorizedClientProviders
/* 211 */         .add(getAuthorizationCodeAuthorizedClientProvider(authorizedClientProviderBeans));
/* 212 */       authorizedClientProviders.add(getRefreshTokenAuthorizedClientProvider(authorizedClientProviderBeans));
/* 213 */       authorizedClientProviders
/* 214 */         .add(getClientCredentialsAuthorizedClientProvider(authorizedClientProviderBeans));
/* 215 */       authorizedClientProviders.add(getPasswordAuthorizedClientProvider(authorizedClientProviderBeans));
/*     */       
/* 217 */       ReactiveOAuth2AuthorizedClientProvider jwtBearerAuthorizedClientProvider = getJwtBearerAuthorizedClientProvider(authorizedClientProviderBeans);
/*     */       
/* 219 */       if (jwtBearerAuthorizedClientProvider != null) {
/* 220 */         authorizedClientProviders.add(jwtBearerAuthorizedClientProvider);
/*     */       }
/*     */       
/* 223 */       ReactiveOAuth2AuthorizedClientProvider tokenExchangeAuthorizedClientProvider = getTokenExchangeAuthorizedClientProvider(authorizedClientProviderBeans);
/*     */       
/* 225 */       if (tokenExchangeAuthorizedClientProvider != null) {
/* 226 */         authorizedClientProviders.add(tokenExchangeAuthorizedClientProvider);
/*     */       }
/*     */       
/* 229 */       authorizedClientProviders.addAll(getAdditionalAuthorizedClientProviders(authorizedClientProviderBeans));
/* 230 */       delegatingReactiveOAuth2AuthorizedClientProvider = new DelegatingReactiveOAuth2AuthorizedClientProvider(authorizedClientProviders);
/*     */     } 
/*     */ 
/*     */     
/* 234 */     DefaultReactiveOAuth2AuthorizedClientManager authorizedClientManager = new DefaultReactiveOAuth2AuthorizedClientManager(clientRegistrationRepository, (ServerOAuth2AuthorizedClientRepository)authenticatedPrincipalServerOAuth2AuthorizedClientRepository);
/*     */     
/* 236 */     authorizedClientManager.setAuthorizedClientProvider((ReactiveOAuth2AuthorizedClientProvider)delegatingReactiveOAuth2AuthorizedClientProvider);
/*     */     
/* 238 */     Consumer<DefaultReactiveOAuth2AuthorizedClientManager> authorizedClientManagerConsumer = getBeanOfType(
/* 239 */         ResolvableType.forClassWithGenerics(Consumer.class, new Class[] { DefaultReactiveOAuth2AuthorizedClientManager.class }));
/*     */     
/* 241 */     if (authorizedClientManagerConsumer != null) {
/* 242 */       authorizedClientManagerConsumer.accept(authorizedClientManager);
/*     */     }
/*     */     
/* 245 */     return (ReactiveOAuth2AuthorizedClientManager)authorizedClientManager;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasDelegatingAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 250 */     if (authorizedClientProviders.size() != 1) {
/* 251 */       return false;
/*     */     }
/* 253 */     return authorizedClientProviders.iterator()
/* 254 */       .next() instanceof DelegatingReactiveOAuth2AuthorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientProvider getAuthorizationCodeAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 259 */     AuthorizationCodeReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, AuthorizationCodeReactiveOAuth2AuthorizedClientProvider.class);
/*     */     
/* 261 */     if (authorizedClientProvider == null) {
/* 262 */       authorizedClientProvider = new AuthorizationCodeReactiveOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 265 */     return (ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientProvider getRefreshTokenAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 270 */     RefreshTokenReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, RefreshTokenReactiveOAuth2AuthorizedClientProvider.class);
/*     */     
/* 272 */     if (authorizedClientProvider == null) {
/* 273 */       authorizedClientProvider = new RefreshTokenReactiveOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 276 */     ReactiveOAuth2AccessTokenResponseClient<OAuth2RefreshTokenGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 277 */         ResolvableType.forClassWithGenerics(ReactiveOAuth2AccessTokenResponseClient.class, new Class[] { OAuth2RefreshTokenGrantRequest.class }));
/*     */     
/* 279 */     if (accessTokenResponseClient != null) {
/* 280 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 283 */     return (ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientProvider getClientCredentialsAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 288 */     ClientCredentialsReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, ClientCredentialsReactiveOAuth2AuthorizedClientProvider.class);
/*     */     
/* 290 */     if (authorizedClientProvider == null) {
/* 291 */       authorizedClientProvider = new ClientCredentialsReactiveOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 294 */     ReactiveOAuth2AccessTokenResponseClient<OAuth2ClientCredentialsGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 295 */         ResolvableType.forClassWithGenerics(ReactiveOAuth2AccessTokenResponseClient.class, new Class[] { OAuth2ClientCredentialsGrantRequest.class }));
/*     */     
/* 297 */     if (accessTokenResponseClient != null) {
/* 298 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 301 */     return (ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientProvider getPasswordAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 306 */     PasswordReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, PasswordReactiveOAuth2AuthorizedClientProvider.class);
/*     */     
/* 308 */     if (authorizedClientProvider == null) {
/* 309 */       authorizedClientProvider = new PasswordReactiveOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 312 */     ReactiveOAuth2AccessTokenResponseClient<OAuth2PasswordGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 313 */         ResolvableType.forClassWithGenerics(ReactiveOAuth2AccessTokenResponseClient.class, new Class[] { OAuth2PasswordGrantRequest.class }));
/*     */     
/* 315 */     if (accessTokenResponseClient != null) {
/* 316 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 319 */     return (ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientProvider getJwtBearerAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 324 */     JwtBearerReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, JwtBearerReactiveOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */     
/* 327 */     ReactiveOAuth2AccessTokenResponseClient<JwtBearerGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 328 */         ResolvableType.forClassWithGenerics(ReactiveOAuth2AccessTokenResponseClient.class, new Class[] { JwtBearerGrantRequest.class }));
/*     */     
/* 330 */     if (accessTokenResponseClient != null) {
/* 331 */       if (authorizedClientProvider == null) {
/* 332 */         authorizedClientProvider = new JwtBearerReactiveOAuth2AuthorizedClientProvider();
/*     */       }
/*     */       
/* 335 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     } 
/*     */     
/* 338 */     return (ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientProvider getTokenExchangeAuthorizedClientProvider(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 343 */     TokenExchangeReactiveOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, TokenExchangeReactiveOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */     
/* 346 */     ReactiveOAuth2AccessTokenResponseClient<TokenExchangeGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 347 */         ResolvableType.forClassWithGenerics(ReactiveOAuth2AccessTokenResponseClient.class, new Class[] { TokenExchangeGrantRequest.class }));
/*     */     
/* 349 */     if (accessTokenResponseClient != null) {
/* 350 */       if (authorizedClientProvider == null) {
/* 351 */         authorizedClientProvider = new TokenExchangeReactiveOAuth2AuthorizedClientProvider();
/*     */       }
/*     */       
/* 354 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     } 
/*     */     
/* 357 */     return (ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ReactiveOAuth2AuthorizedClientProvider> getAdditionalAuthorizedClientProviders(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 362 */     List<ReactiveOAuth2AuthorizedClientProvider> additionalAuthorizedClientProviders = new ArrayList<>(authorizedClientProviders);
/*     */     
/* 364 */     additionalAuthorizedClientProviders
/* 365 */       .removeIf(provider -> KNOWN_AUTHORIZED_CLIENT_PROVIDERS.contains(provider.getClass()));
/* 366 */     return additionalAuthorizedClientProviders;
/*     */   }
/*     */   
/*     */   private <T extends ReactiveOAuth2AuthorizedClientProvider> T getAuthorizedClientProviderByType(Collection<ReactiveOAuth2AuthorizedClientProvider> authorizedClientProviders, Class<T> providerClass) {
/*     */     ReactiveOAuth2AuthorizedClientProvider reactiveOAuth2AuthorizedClientProvider;
/* 371 */     T authorizedClientProvider = null;
/* 372 */     for (ReactiveOAuth2AuthorizedClientProvider current : authorizedClientProviders) {
/* 373 */       if (providerClass.isInstance(current)) {
/* 374 */         assertAuthorizedClientProviderIsNull((ReactiveOAuth2AuthorizedClientProvider)authorizedClientProvider);
/* 375 */         reactiveOAuth2AuthorizedClientProvider = (ReactiveOAuth2AuthorizedClientProvider)providerClass.cast(current);
/*     */       } 
/*     */     } 
/* 378 */     return (T)reactiveOAuth2AuthorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void assertAuthorizedClientProviderIsNull(ReactiveOAuth2AuthorizedClientProvider authorizedClientProvider) {
/* 383 */     if (authorizedClientProvider != null)
/*     */     {
/* 385 */       throw new BeanInitializationException(String.format("Unable to create a %s bean. Expected one bean of type %s, but found multiple. Please consider defining only a single bean of this type, or define a %s bean yourself.", new Object[] { ReactiveOAuth2AuthorizedClientManager.class
/*     */ 
/*     */               
/* 388 */               .getName(), authorizedClientProvider
/* 389 */               .getClass().getName(), ReactiveOAuth2AuthorizedClientManager.class
/* 390 */               .getName() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> String[] getBeanNamesForType(Class<T> beanClass) {
/* 396 */     return BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.beanFactory, beanClass, true, true);
/*     */   }
/*     */   
/*     */   private <T> T getBeanOfType(ResolvableType resolvableType) {
/* 400 */     ObjectProvider<T> objectProvider = this.beanFactory.getBeanProvider(resolvableType, true);
/* 401 */     return (T)objectProvider.getIfAvailable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ReactiveOAuth2ClientConfiguration$ReactiveOAuth2AuthorizedClientManagerRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */