/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.LinkedHashMap;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.access.AccessDeniedHandler;
/*     */ import org.springframework.security.web.access.AccessDeniedHandlerImpl;
/*     */ import org.springframework.security.web.access.ExceptionTranslationFilter;
/*     */ import org.springframework.security.web.access.RequestMatcherDelegatingAccessDeniedHandler;
/*     */ import org.springframework.security.web.authentication.DelegatingAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
/*     */ import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExceptionHandlingConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<ExceptionHandlingConfigurer<H>, H>
/*     */ {
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   private AccessDeniedHandler accessDeniedHandler;
/*  73 */   private LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> defaultEntryPointMappings = new LinkedHashMap<>();
/*     */   
/*  75 */   private LinkedHashMap<RequestMatcher, AccessDeniedHandler> defaultDeniedHandlerMappings = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingConfigurer<H> accessDeniedPage(String accessDeniedUrl) {
/*  93 */     AccessDeniedHandlerImpl accessDeniedHandler = new AccessDeniedHandlerImpl();
/*  94 */     accessDeniedHandler.setErrorPage(accessDeniedUrl);
/*  95 */     return accessDeniedHandler((AccessDeniedHandler)accessDeniedHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingConfigurer<H> accessDeniedHandler(AccessDeniedHandler accessDeniedHandler) {
/* 104 */     this.accessDeniedHandler = accessDeniedHandler;
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingConfigurer<H> defaultAccessDeniedHandlerFor(AccessDeniedHandler deniedHandler, RequestMatcher preferredMatcher) {
/* 123 */     this.defaultDeniedHandlerMappings.put(preferredMatcher, deniedHandler);
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingConfigurer<H> authenticationEntryPoint(AuthenticationEntryPoint authenticationEntryPoint) {
/* 145 */     this.authenticationEntryPoint = authenticationEntryPoint;
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingConfigurer<H> defaultAuthenticationEntryPointFor(AuthenticationEntryPoint entryPoint, RequestMatcher preferredMatcher) {
/* 163 */     this.defaultEntryPointMappings.put(preferredMatcher, entryPoint);
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AuthenticationEntryPoint getAuthenticationEntryPoint() {
/* 172 */     return this.authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AccessDeniedHandler getAccessDeniedHandler() {
/* 180 */     return this.accessDeniedHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 185 */     AuthenticationEntryPoint entryPoint = getAuthenticationEntryPoint(http);
/*     */     
/* 187 */     ExceptionTranslationFilter exceptionTranslationFilter = new ExceptionTranslationFilter(entryPoint, getRequestCache(http));
/* 188 */     AccessDeniedHandler deniedHandler = getAccessDeniedHandler(http);
/* 189 */     exceptionTranslationFilter.setAccessDeniedHandler(deniedHandler);
/* 190 */     exceptionTranslationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 191 */     exceptionTranslationFilter = (ExceptionTranslationFilter)postProcess(exceptionTranslationFilter);
/* 192 */     http.addFilter((Filter)exceptionTranslationFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AccessDeniedHandler getAccessDeniedHandler(H http) {
/* 203 */     AccessDeniedHandler deniedHandler = this.accessDeniedHandler;
/* 204 */     if (deniedHandler == null) {
/* 205 */       deniedHandler = createDefaultDeniedHandler(http);
/*     */     }
/* 207 */     return deniedHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AuthenticationEntryPoint getAuthenticationEntryPoint(H http) {
/* 218 */     AuthenticationEntryPoint entryPoint = this.authenticationEntryPoint;
/* 219 */     if (entryPoint == null) {
/* 220 */       entryPoint = createDefaultEntryPoint(http);
/*     */     }
/* 222 */     return entryPoint;
/*     */   }
/*     */   
/*     */   private AccessDeniedHandler createDefaultDeniedHandler(H http) {
/* 226 */     if (this.defaultDeniedHandlerMappings.isEmpty()) {
/* 227 */       return (AccessDeniedHandler)new AccessDeniedHandlerImpl();
/*     */     }
/* 229 */     if (this.defaultDeniedHandlerMappings.size() == 1) {
/* 230 */       return this.defaultDeniedHandlerMappings.values().iterator().next();
/*     */     }
/* 232 */     return (AccessDeniedHandler)new RequestMatcherDelegatingAccessDeniedHandler(this.defaultDeniedHandlerMappings, (AccessDeniedHandler)new AccessDeniedHandlerImpl());
/*     */   }
/*     */ 
/*     */   
/*     */   private AuthenticationEntryPoint createDefaultEntryPoint(H http) {
/* 237 */     if (this.defaultEntryPointMappings.isEmpty()) {
/* 238 */       return (AuthenticationEntryPoint)new Http403ForbiddenEntryPoint();
/*     */     }
/* 240 */     if (this.defaultEntryPointMappings.size() == 1) {
/* 241 */       return this.defaultEntryPointMappings.values().iterator().next();
/*     */     }
/* 243 */     DelegatingAuthenticationEntryPoint entryPoint = new DelegatingAuthenticationEntryPoint(this.defaultEntryPointMappings);
/*     */     
/* 245 */     entryPoint.setDefaultEntryPoint(this.defaultEntryPointMappings.values().iterator().next());
/* 246 */     return (AuthenticationEntryPoint)entryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestCache getRequestCache(H http) {
/* 258 */     RequestCache result = (RequestCache)http.getSharedObject(RequestCache.class);
/* 259 */     if (result != null) {
/* 260 */       return result;
/*     */     }
/* 262 */     return (RequestCache)new HttpSessionRequestCache();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\ExceptionHandlingConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */