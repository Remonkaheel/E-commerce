/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.server.resource;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2AccessToken;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.DPoPAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.DPoPAuthenticationToken;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.AuthenticationEntryPointFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DPoPAuthenticationConfigurer<B extends HttpSecurityBuilder<B>>
/*     */   extends AbstractHttpConfigurer<DPoPAuthenticationConfigurer<B>, B>
/*     */ {
/*     */   private RequestMatcher requestMatcher;
/*     */   private AuthenticationConverter authenticationConverter;
/*     */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*     */   private AuthenticationFailureHandler authenticationFailureHandler;
/*     */   
/*     */   public void configure(B http) {
/*  82 */     AuthenticationManager authenticationManager = (AuthenticationManager)http.getSharedObject(AuthenticationManager.class);
/*  83 */     http.authenticationProvider((AuthenticationProvider)new DPoPAuthenticationProvider(getTokenAuthenticationManager(http)));
/*     */     
/*  85 */     AuthenticationFilter authenticationFilter = new AuthenticationFilter(authenticationManager, getAuthenticationConverter());
/*  86 */     authenticationFilter.setRequestMatcher(getRequestMatcher());
/*  87 */     authenticationFilter.setSuccessHandler(getAuthenticationSuccessHandler());
/*  88 */     authenticationFilter.setFailureHandler(getAuthenticationFailureHandler());
/*  89 */     authenticationFilter.setSecurityContextRepository((SecurityContextRepository)new RequestAttributeSecurityContextRepository());
/*  90 */     authenticationFilter = (AuthenticationFilter)postProcess(authenticationFilter);
/*  91 */     http.addFilter((Filter)authenticationFilter);
/*     */   }
/*     */ 
/*     */   
/*     */   private AuthenticationManager getTokenAuthenticationManager(B http) {
/*  96 */     OAuth2ResourceServerConfigurer<B> resourceServerConfigurer = (OAuth2ResourceServerConfigurer<B>)http.getConfigurer(OAuth2ResourceServerConfigurer.class);
/*     */     
/*  98 */     AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver = resourceServerConfigurer.getAuthenticationManagerResolver();
/*  99 */     if (authenticationManagerResolver == null) {
/* 100 */       return resourceServerConfigurer.getAuthenticationManager(http);
/*     */     }
/* 102 */     return authentication -> {
/*     */         RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/*     */         ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
/*     */         AuthenticationManager authenticationManager = authenticationManagerResolver.resolve(servletRequestAttributes.getRequest());
/*     */         return authenticationManager.authenticate(authentication);
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private RequestMatcher getRequestMatcher() {
/* 112 */     if (this.requestMatcher == null) {
/* 113 */       this.requestMatcher = new DPoPRequestMatcher();
/*     */     }
/* 115 */     return this.requestMatcher;
/*     */   }
/*     */   
/*     */   private AuthenticationConverter getAuthenticationConverter() {
/* 119 */     if (this.authenticationConverter == null) {
/* 120 */       this.authenticationConverter = new DPoPAuthenticationConverter();
/*     */     }
/* 122 */     return this.authenticationConverter;
/*     */   }
/*     */   
/*     */   private AuthenticationSuccessHandler getAuthenticationSuccessHandler() {
/* 126 */     if (this.authenticationSuccessHandler == null) {
/* 127 */       this.authenticationSuccessHandler = ((request, response, authentication) -> {
/*     */         
/*     */         });
/*     */     }
/* 131 */     return this.authenticationSuccessHandler;
/*     */   }
/*     */   
/*     */   private AuthenticationFailureHandler getAuthenticationFailureHandler() {
/* 135 */     if (this.authenticationFailureHandler == null) {
/* 136 */       this.authenticationFailureHandler = (AuthenticationFailureHandler)new AuthenticationEntryPointFailureHandler(new DPoPAuthenticationEntryPoint());
/*     */     }
/*     */     
/* 139 */     return this.authenticationFailureHandler;
/*     */   }
/*     */   
/*     */   private static final class DPoPRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 146 */       String authorization = request.getHeader("Authorization");
/* 147 */       if (!StringUtils.hasText(authorization)) {
/* 148 */         return false;
/*     */       }
/* 150 */       return StringUtils.startsWithIgnoreCase(authorization, OAuth2AccessToken.TokenType.DPOP.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class DPoPAuthenticationConverter
/*     */     implements AuthenticationConverter
/*     */   {
/* 157 */     private static final Pattern AUTHORIZATION_PATTERN = Pattern.compile("^DPoP (?<token>[a-zA-Z0-9-._~+/]+=*)$", 2);
/*     */ 
/*     */ 
/*     */     
/*     */     public Authentication convert(HttpServletRequest request) {
/* 162 */       List<String> authorizationList = Collections.list(request.getHeaders("Authorization"));
/* 163 */       if (CollectionUtils.isEmpty(authorizationList)) {
/* 164 */         return null;
/*     */       }
/* 166 */       if (authorizationList.size() != 1) {
/* 167 */         OAuth2Error error = new OAuth2Error("invalid_request", "Found multiple Authorization headers.", null);
/*     */         
/* 169 */         throw new OAuth2AuthenticationException(error);
/*     */       } 
/* 171 */       String authorization = authorizationList.get(0);
/* 172 */       if (!StringUtils.startsWithIgnoreCase(authorization, OAuth2AccessToken.TokenType.DPOP.getValue())) {
/* 173 */         return null;
/*     */       }
/* 175 */       Matcher matcher = AUTHORIZATION_PATTERN.matcher(authorization);
/* 176 */       if (!matcher.matches()) {
/* 177 */         OAuth2Error error = new OAuth2Error("invalid_token", "DPoP access token is malformed.", null);
/*     */         
/* 179 */         throw new OAuth2AuthenticationException(error);
/*     */       } 
/* 181 */       String accessToken = matcher.group("token");
/*     */       
/* 183 */       List<String> dPoPProofList = Collections.list(request.getHeaders(OAuth2AccessToken.TokenType.DPOP.getValue()));
/* 184 */       if (CollectionUtils.isEmpty(dPoPProofList) || dPoPProofList.size() != 1) {
/* 185 */         OAuth2Error error = new OAuth2Error("invalid_request", "DPoP proof is missing or invalid.", null);
/*     */         
/* 187 */         throw new OAuth2AuthenticationException(error);
/*     */       } 
/* 189 */       String dPoPProof = dPoPProofList.get(0);
/* 190 */       return (Authentication)new DPoPAuthenticationToken(accessToken, dPoPProof, request.getMethod(), request
/* 191 */           .getRequestURL().toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DPoPAuthenticationEntryPoint
/*     */     implements AuthenticationEntryPoint
/*     */   {
/*     */     public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authenticationException) {
/* 201 */       Map<String, String> parameters = new LinkedHashMap<>();
/* 202 */       if (authenticationException instanceof OAuth2AuthenticationException) { OAuth2AuthenticationException oauth2AuthenticationException = (OAuth2AuthenticationException)authenticationException;
/* 203 */         OAuth2Error error = oauth2AuthenticationException.getError();
/* 204 */         parameters.put("error", error.getErrorCode());
/* 205 */         if (StringUtils.hasText(error.getDescription())) {
/* 206 */           parameters.put("error_description", error.getDescription());
/*     */         }
/* 208 */         if (StringUtils.hasText(error.getUri())) {
/* 209 */           parameters.put("error_uri", error.getUri());
/*     */         } }
/*     */       
/* 212 */       parameters.put("algs", "RS256 RS384 RS512 PS256 PS384 PS512 ES256 ES384 ES512");
/*     */ 
/*     */ 
/*     */       
/* 216 */       String wwwAuthenticate = toWWWAuthenticateHeader(parameters);
/* 217 */       response.addHeader("WWW-Authenticate", wwwAuthenticate);
/* 218 */       response.setStatus(HttpStatus.UNAUTHORIZED.value());
/*     */     }
/*     */     
/*     */     private static String toWWWAuthenticateHeader(Map<String, String> parameters) {
/* 222 */       StringBuilder wwwAuthenticate = new StringBuilder();
/* 223 */       wwwAuthenticate.append(OAuth2AccessToken.TokenType.DPOP.getValue());
/* 224 */       if (!parameters.isEmpty()) {
/* 225 */         wwwAuthenticate.append(" ");
/* 226 */         int i = 0;
/* 227 */         for (Map.Entry<String, String> entry : parameters.entrySet()) {
/* 228 */           wwwAuthenticate.append(entry.getKey()).append("=\"").append(entry.getValue()).append("\"");
/* 229 */           if (i++ != parameters.size() - 1) {
/* 230 */             wwwAuthenticate.append(", ");
/*     */           }
/*     */         } 
/*     */       } 
/* 234 */       return wwwAuthenticate.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\server\resource\DPoPAuthenticationConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */