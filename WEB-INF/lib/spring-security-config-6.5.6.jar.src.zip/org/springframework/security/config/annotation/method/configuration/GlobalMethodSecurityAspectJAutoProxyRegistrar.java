/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class GlobalMethodSecurityAspectJAutoProxyRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 51 */     BeanDefinition interceptor = registry.getBeanDefinition("methodSecurityInterceptor");
/* 52 */     BeanDefinitionBuilder aspect = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.access.intercept.aspectj.aspect.AnnotationSecurityAspect");
/*    */     
/* 54 */     aspect.setFactoryMethod("aspectOf");
/* 55 */     aspect.setRole(2);
/* 56 */     aspect.addPropertyValue("securityInterceptor", interceptor);
/* 57 */     registry.registerBeanDefinition("annotationSecurityAspect$0", (BeanDefinition)aspect.getBeanDefinition());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\GlobalMethodSecurityAspectJAutoProxyRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */