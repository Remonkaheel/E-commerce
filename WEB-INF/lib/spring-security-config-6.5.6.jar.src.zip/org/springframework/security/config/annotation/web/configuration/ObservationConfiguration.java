/*    */ package org.springframework.security.config.annotation.web.configuration;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.authentication.ObservationAuthenticationManager;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.ObservationAuthorizationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ import org.springframework.security.web.FilterChainProxy;
/*    */ import org.springframework.security.web.ObservationFilterChainDecorator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ class ObservationConfiguration
/*    */ {
/* 40 */   private static final SecurityObservationSettings all = SecurityObservationSettings.withDefaults()
/* 41 */     .shouldObserveRequests(true)
/* 42 */     .shouldObserveAuthentications(true)
/* 43 */     .shouldObserveAuthorizations(true)
/* 44 */     .build();
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<AuthorizationManager<HttpServletRequest>> webAuthorizationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 50 */     return new ObjectPostProcessor<AuthorizationManager<HttpServletRequest>>()
/*    */       {
/*    */         public AuthorizationManager postProcess(AuthorizationManager object) {
/* 53 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 54 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ObservationConfiguration.all)).shouldObserveAuthorizations());
/* 55 */           return active ? (AuthorizationManager)new ObservationAuthorizationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<AuthenticationManager> authenticationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 64 */     return new ObjectPostProcessor<AuthenticationManager>()
/*    */       {
/*    */         public AuthenticationManager postProcess(AuthenticationManager object) {
/* 67 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 68 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ObservationConfiguration.all)).shouldObserveAuthentications());
/* 69 */           return active ? (AuthenticationManager)new ObservationAuthenticationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<FilterChainProxy.FilterChainDecorator> filterChainDecoratorPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 78 */     return new ObjectPostProcessor<FilterChainProxy.FilterChainDecorator>()
/*    */       {
/*    */         public FilterChainProxy.FilterChainDecorator postProcess(FilterChainProxy.FilterChainDecorator object) {
/* 81 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 82 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ObservationConfiguration.all)).shouldObserveRequests());
/* 83 */           return active ? (FilterChainProxy.FilterChainDecorator)new ObservationFilterChainDecorator(r) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\ObservationConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */