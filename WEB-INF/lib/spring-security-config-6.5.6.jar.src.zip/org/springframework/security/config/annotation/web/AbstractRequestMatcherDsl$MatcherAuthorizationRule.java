/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\t\n\002\020\013\n\000\n\002\020\000\n\000\n\002\020\b\n\002\b\002\b\b\030\0002\0020\001B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\t\020\013\032\0020\003HÆ\003J\t\020\f\032\0020\005HÆ\003J\035\020\r\032\0020\0002\b\b\002\020\002\032\0020\0032\b\b\002\020\004\032\0020\005HÆ\001J\023\020\016\032\0020\0172\b\020\020\032\004\030\0010\021HÖ\003J\t\020\022\032\0020\023HÖ\001J\t\020\024\032\0020\005HÖ\001R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\007\020\bR\024\020\004\032\0020\005X\004¢\006\b\n\000\032\004\b\t\020\n¨\006\025"}, d2 = {"Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$MatcherAuthorizationRule;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationRule;", "matcher", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "rule", "", "(Lorg/springframework/security/web/util/matcher/RequestMatcher;Ljava/lang/String;)V", "getMatcher", "()Lorg/springframework/security/web/util/matcher/RequestMatcher;", "getRule", "()Ljava/lang/String;", "component1", "component2", "copy", "equals", "", "other", "", "hashCode", "", "toString", "spring-security-config"})
/*    */ public final class MatcherAuthorizationRule
/*    */   extends AbstractRequestMatcherDsl.AuthorizationRule
/*    */ {
/*    */   @NotNull
/*    */   private final RequestMatcher matcher;
/*    */   @NotNull
/*    */   private final String rule;
/*    */   
/*    */   @NotNull
/*    */   public final RequestMatcher getMatcher() {
/* 38 */     return this.matcher;
/* 39 */   } public MatcherAuthorizationRule(@NotNull RequestMatcher matcher, @NotNull String rule) { super(rule); this.matcher = matcher; this.rule = rule; } @NotNull public String getRule() { return this.rule; }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public final RequestMatcher component1() {
/*    */     return this.matcher;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final String component2() {
/*    */     return this.rule;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final MatcherAuthorizationRule copy(@NotNull RequestMatcher matcher, @NotNull String rule) {
/*    */     Intrinsics.checkNotNullParameter(matcher, "matcher");
/*    */     Intrinsics.checkNotNullParameter(rule, "rule");
/*    */     return new MatcherAuthorizationRule(matcher, rule);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString() {
/*    */     return "MatcherAuthorizationRule(matcher=" + this.matcher + ", rule=" + this.rule + ")";
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     result = this.matcher.hashCode();
/*    */     return result * 31 + this.rule.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/*    */     if (this == other)
/*    */       return true; 
/*    */     if (!(other instanceof MatcherAuthorizationRule))
/*    */       return false; 
/*    */     MatcherAuthorizationRule matcherAuthorizationRule = (MatcherAuthorizationRule)other;
/*    */     return !Intrinsics.areEqual(this.matcher, matcherAuthorizationRule.matcher) ? false : (!!Intrinsics.areEqual(this.rule, matcherAuthorizationRule.rule));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherDsl$MatcherAuthorizationRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */