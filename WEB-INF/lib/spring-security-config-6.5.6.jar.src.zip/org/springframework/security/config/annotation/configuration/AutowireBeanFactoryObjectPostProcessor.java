/*     */ package org.springframework.security.config.annotation.configuration;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.core.NativeDetector;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AutowireBeanFactoryObjectPostProcessor
/*     */   implements ObjectPostProcessor<Object>, DisposableBean, SmartInitializingSingleton
/*     */ {
/*  47 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final AutowireCapableBeanFactory autowireBeanFactory;
/*     */   
/*  51 */   private final List<DisposableBean> disposableBeans = new ArrayList<>();
/*     */   
/*  53 */   private final List<SmartInitializingSingleton> smartSingletons = new ArrayList<>();
/*     */   
/*     */   AutowireBeanFactoryObjectPostProcessor(AutowireCapableBeanFactory autowireBeanFactory) {
/*  56 */     Assert.notNull(autowireBeanFactory, "autowireBeanFactory cannot be null");
/*  57 */     this.autowireBeanFactory = autowireBeanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T postProcess(T object) {
/*  62 */     if (object == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     T result = null;
/*     */     try {
/*  67 */       result = initializeBeanIfNeeded(object);
/*     */     }
/*  69 */     catch (RuntimeException ex) {
/*  70 */       Class<?> type = object.getClass();
/*  71 */       throw new RuntimeException("Could not postProcess " + String.valueOf(object) + " of type " + String.valueOf(type), ex);
/*     */     } 
/*  73 */     this.autowireBeanFactory.autowireBean(object);
/*  74 */     if (result instanceof DisposableBean) {
/*  75 */       this.disposableBeans.add((DisposableBean)result);
/*     */     }
/*  77 */     if (result instanceof SmartInitializingSingleton) {
/*  78 */       this.smartSingletons.add((SmartInitializingSingleton)result);
/*     */     }
/*  80 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T initializeBeanIfNeeded(T object) {
/*  97 */     if (!NativeDetector.inNativeImage() || !AopUtils.isCglibProxy(object)) {
/*  98 */       return (T)this.autowireBeanFactory.initializeBean(object, object.toString());
/*     */     }
/* 100 */     ObjectProvider<?> provider = this.autowireBeanFactory.getBeanProvider(object.getClass());
/* 101 */     Object bean = provider.getIfUnique();
/* 102 */     if (bean == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       String msg = "Failed to resolve an unique bean (single or primary) of type [%s] from the BeanFactory.\nBecause the object is a CGLIB Proxy, a raw bean cannot be initialized during runtime in a native image.\n".formatted(new Object[] { object.getClass() });
/* 108 */       throw new IllegalStateException(msg);
/*     */     } 
/* 110 */     return (T)bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 115 */     for (SmartInitializingSingleton singleton : this.smartSingletons) {
/* 116 */       singleton.afterSingletonsInstantiated();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 122 */     for (DisposableBean disposable : this.disposableBeans) {
/*     */       try {
/* 124 */         disposable.destroy();
/*     */       }
/* 126 */       catch (Exception ex) {
/* 127 */         this.logger.error(ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\configuration\AutowireBeanFactoryObjectPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */