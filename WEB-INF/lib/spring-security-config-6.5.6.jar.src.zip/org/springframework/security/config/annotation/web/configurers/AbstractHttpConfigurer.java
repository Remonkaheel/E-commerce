/*    */ package org.springframework.security.config.annotation.web.configurers;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*    */ import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
/*    */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*    */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractHttpConfigurer<T extends AbstractHttpConfigurer<T, B>, B extends HttpSecurityBuilder<B>>
/*    */   extends SecurityConfigurerAdapter<DefaultSecurityFilterChain, B>
/*    */ {
/*    */   private SecurityContextHolderStrategy securityContextHolderStrategy;
/*    */   
/*    */   public B disable() {
/* 48 */     ((HttpSecurityBuilder)getBuilder()).removeConfigurer(getClass());
/* 49 */     return (B)getBuilder();
/*    */   }
/*    */ 
/*    */   
/*    */   public T withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 54 */     addObjectPostProcessor(objectPostProcessor);
/* 55 */     return (T)this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(since = "6.4", forRemoval = true)
/*    */   public T withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 65 */     addObjectPostProcessor(objectPostProcessor);
/* 66 */     return (T)this;
/*    */   }
/*    */   
/*    */   protected SecurityContextHolderStrategy getSecurityContextHolderStrategy() {
/* 70 */     if (this.securityContextHolderStrategy != null) {
/* 71 */       return this.securityContextHolderStrategy;
/*    */     }
/* 73 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 74 */     this
/* 75 */       .securityContextHolderStrategy = (SecurityContextHolderStrategy)context.getBeanProvider(SecurityContextHolderStrategy.class).getIfUnique(SecurityContextHolder::getContextHolderStrategy);
/* 76 */     return this.securityContextHolderStrategy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AbstractHttpConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */