/*    */ package org.springframework.security.config.annotation.web.session;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "sessionFixation", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$SessionFixationConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ final class SessionFixationDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<SessionManagementConfigurer<HttpSecurity>.SessionFixationConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(SessionManagementConfigurer.SessionFixationConfigurer sessionFixation) {
/* 70 */     Intrinsics.checkNotNullParameter(sessionFixation, "sessionFixation"); SessionFixationStrategy sessionFixationStrategy1 = SessionFixationDsl.access$getStrategy$p(SessionFixationDsl.this); SessionFixationDsl sessionFixationDsl = SessionFixationDsl.this; SessionFixationStrategy it = sessionFixationStrategy1; int $i$a$-also-SessionFixationDsl$get$1$1 = 0;
/* 71 */     SessionFixationDsl.access$getStrategy$p(sessionFixationDsl); switch ((SessionFixationDsl.access$getStrategy$p(sessionFixationDsl) == null) ? -1 : WhenMappings.$EnumSwitchMapping$0[SessionFixationDsl.access$getStrategy$p(sessionFixationDsl).ordinal()]) { case true:
/* 72 */         sessionFixation.newSession(); break;
/* 73 */       case true: sessionFixation.migrateSession(); break;
/* 74 */       case true: sessionFixation.changeSessionId(); break;
/* 75 */       case true: sessionFixation.none();
/*    */         break;
/*    */       case true:
/*    */         break; }
/*    */     
/*    */     SessionFixationDsl.access$getStrategy$p(SessionFixationDsl.this);
/*    */   }
/*    */   
/*    */   SessionFixationDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\session\SessionFixationDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */