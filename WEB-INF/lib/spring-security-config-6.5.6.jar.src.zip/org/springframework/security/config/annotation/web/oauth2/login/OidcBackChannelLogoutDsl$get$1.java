/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OidcLogoutConfigurer;
/*    */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "backChannel", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer$BackChannelLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nOidcBackChannelLogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OidcBackChannelLogoutDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/OidcBackChannelLogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1#2:56\n*E\n"})
/*    */ final class OidcBackChannelLogoutDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OidcLogoutConfigurer<HttpSecurity>.BackChannelLogoutConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(OidcLogoutConfigurer.BackChannelLogoutConfigurer backChannel) {
/* 50 */     Intrinsics.checkNotNullParameter(backChannel, "backChannel"); if (OidcBackChannelLogoutDsl.this.getLogoutHandler() != null) { LogoutHandler logoutHandler1 = OidcBackChannelLogoutDsl.this.getLogoutHandler(); OidcBackChannelLogoutDsl oidcBackChannelLogoutDsl = OidcBackChannelLogoutDsl.this; LogoutHandler it = logoutHandler1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       int $i$a$-also-OidcBackChannelLogoutDsl$get$1$1 = 0; backChannel.logoutHandler(oidcBackChannelLogoutDsl.getLogoutHandler()); } else { OidcBackChannelLogoutDsl.this.getLogoutHandler(); }  if (OidcBackChannelLogoutDsl.this.getLogoutUri() != null) { String str1 = OidcBackChannelLogoutDsl.this.getLogoutUri(); OidcBackChannelLogoutDsl oidcBackChannelLogoutDsl = OidcBackChannelLogoutDsl.this; String it = str1; int $i$a$-also-OidcBackChannelLogoutDsl$get$1$2 = 0;
/*    */       backChannel.logoutUri(oidcBackChannelLogoutDsl.getLogoutUri()); }
/*    */     else
/*    */     { OidcBackChannelLogoutDsl.this.getLogoutUri(); }
/*    */   
/*    */   }
/*    */   
/*    */   OidcBackChannelLogoutDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\OidcBackChannelLogoutDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */