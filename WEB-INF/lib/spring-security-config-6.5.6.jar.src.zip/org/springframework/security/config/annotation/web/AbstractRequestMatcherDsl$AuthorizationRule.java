/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\020\000\n\000\n\002\020\016\n\002\b\004\b$\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004R\024\020\002\032\0020\003X\004¢\006\b\n\000\032\004\b\005\020\006¨\006\007"}, d2 = {"Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationRule;", "", "rule", "", "(Ljava/lang/String;)V", "getRule", "()Ljava/lang/String;", "spring-security-config"})
/*    */ public abstract class AuthorizationRule
/*    */ {
/*    */   @NotNull
/*    */   private final String rule;
/*    */   
/*    */   public AuthorizationRule(@NotNull String rule) {
/* 56 */     this.rule = rule; } @NotNull public String getRule() { return this.rule; }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherDsl$AuthorizationRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */