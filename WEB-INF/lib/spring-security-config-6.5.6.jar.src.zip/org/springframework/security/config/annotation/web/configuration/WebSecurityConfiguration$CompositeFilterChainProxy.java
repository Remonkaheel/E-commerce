/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.debug.DebugFilter;
/*     */ import org.springframework.security.web.firewall.HttpFirewall;
/*     */ import org.springframework.security.web.firewall.RequestRejectedHandler;
/*     */ import org.springframework.web.filter.CompositeFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CompositeFilterChainProxy
/*     */   extends FilterChainProxy
/*     */ {
/*     */   private final Filter doFilterDelegate;
/*     */   private final FilterChainProxy springSecurityFilterChain;
/*     */   
/*     */   CompositeFilterChainProxy(List<? extends Filter> filters) {
/* 307 */     this.doFilterDelegate = createDoFilterDelegate(filters);
/* 308 */     this.springSecurityFilterChain = findFilterChainProxy(filters);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 313 */     this.springSecurityFilterChain.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 319 */     this.doFilterDelegate.doFilter(request, response, chain);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Filter> getFilters(String url) {
/* 324 */     return this.springSecurityFilterChain.getFilters(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<SecurityFilterChain> getFilterChains() {
/* 329 */     return this.springSecurityFilterChain.getFilterChains();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 334 */     this.springSecurityFilterChain.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFilterChainValidator(FilterChainProxy.FilterChainValidator filterChainValidator) {
/* 339 */     this.springSecurityFilterChain.setFilterChainValidator(filterChainValidator);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFilterChainDecorator(FilterChainProxy.FilterChainDecorator filterChainDecorator) {
/* 344 */     this.springSecurityFilterChain.setFilterChainDecorator(filterChainDecorator);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFirewall(HttpFirewall firewall) {
/* 349 */     this.springSecurityFilterChain.setFirewall(firewall);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRequestRejectedHandler(RequestRejectedHandler requestRejectedHandler) {
/* 354 */     this.springSecurityFilterChain.setRequestRejectedHandler(requestRejectedHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<? extends Filter> getFilters(HttpServletRequest request) {
/* 364 */     List<SecurityFilterChain> filterChains = this.springSecurityFilterChain.getFilterChains();
/* 365 */     for (SecurityFilterChain chain : filterChains) {
/* 366 */       if (chain.matches(request)) {
/* 367 */         return chain.getFilters();
/*     */       }
/*     */     } 
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter createDoFilterDelegate(List<? extends Filter> filters) {
/* 379 */     CompositeFilter delegate = new CompositeFilter();
/* 380 */     delegate.setFilters(filters);
/* 381 */     return (Filter)delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FilterChainProxy findFilterChainProxy(List<? extends Filter> filters) {
/* 391 */     for (Filter filter : filters) {
/* 392 */       if (filter instanceof FilterChainProxy) { FilterChainProxy fcp = (FilterChainProxy)filter;
/* 393 */         return fcp; }
/*     */       
/* 395 */       if (filter instanceof DebugFilter) { DebugFilter debugFilter = (DebugFilter)filter;
/* 396 */         return debugFilter.getFilterChainProxy(); }
/*     */     
/*     */     } 
/* 399 */     throw new IllegalStateException("Couldn't find FilterChainProxy in " + String.valueOf(filters));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\WebSecurityConfiguration$CompositeFilterChainProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */