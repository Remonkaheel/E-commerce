/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.header.writers.CrossOriginResourcePolicyHeaderWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\t\032\030\022\016\022\f0\013R\b\022\004\022\0020\r0\f\022\004\022\0020\0160\nH\000¢\006\002\b\017R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\b¨\006\020"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/CrossOriginResourcePolicyDsl;", "", "()V", "policy", "Lorg/springframework/security/web/header/writers/CrossOriginResourcePolicyHeaderWriter$CrossOriginResourcePolicy;", "getPolicy", "()Lorg/springframework/security/web/header/writers/CrossOriginResourcePolicyHeaderWriter$CrossOriginResourcePolicy;", "setPolicy", "(Lorg/springframework/security/web/header/writers/CrossOriginResourcePolicyHeaderWriter$CrossOriginResourcePolicy;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CrossOriginResourcePolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class CrossOriginResourcePolicyDsl
/*    */ {
/*    */   @Nullable
/*    */   private CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy policy;
/*    */   
/*    */   @Nullable
/*    */   public final CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy getPolicy() {
/* 34 */     return this.policy; } public final void setPolicy(@Nullable CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy <set-?>) { this.policy = <set-?>; }
/*    */   
/*    */   @NotNull
/* 37 */   public final Function1<HeadersConfigurer<HttpSecurity>.CrossOriginResourcePolicyConfig, Unit> get$spring_security_config() { return new CrossOriginResourcePolicyDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "crossOriginResourcePolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CrossOriginResourcePolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 38 */   static final class CrossOriginResourcePolicyDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.CrossOriginResourcePolicyConfig, Unit> { public final void invoke(HeadersConfigurer.CrossOriginResourcePolicyConfig crossOriginResourcePolicy) { Intrinsics.checkNotNullParameter(crossOriginResourcePolicy, "crossOriginResourcePolicy"); CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy crossOriginResourcePolicy1 = CrossOriginResourcePolicyDsl.this.getPolicy(); CrossOriginResourcePolicyDsl crossOriginResourcePolicyDsl = CrossOriginResourcePolicyDsl.this; CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy it = crossOriginResourcePolicy1; int $i$a$-also-CrossOriginResourcePolicyDsl$get$1$1 = 0;
/* 39 */       crossOriginResourcePolicy.policy(crossOriginResourcePolicyDsl.getPolicy());
/*    */       CrossOriginResourcePolicyDsl.this.getPolicy(); }
/*    */ 
/*    */     
/*    */     CrossOriginResourcePolicyDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\CrossOriginResourcePolicyDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */