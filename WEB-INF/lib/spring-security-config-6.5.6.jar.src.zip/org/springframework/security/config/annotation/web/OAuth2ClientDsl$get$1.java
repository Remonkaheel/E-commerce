/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2ClientConfigurer;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oauth2Client", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nOAuth2ClientDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OAuth2ClientDsl.kt\norg/springframework/security/config/annotation/web/OAuth2ClientDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,102:1\n1#2:103\n*E\n"})
/*     */ final class OAuth2ClientDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<OAuth2ClientConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(OAuth2ClientConfigurer oauth2Client) {
/*  95 */     Intrinsics.checkNotNullParameter(oauth2Client, "oauth2Client"); if (OAuth2ClientDsl.this.getClientRegistrationRepository() != null) { ClientRegistrationRepository clientRegistrationRepository1 = OAuth2ClientDsl.this.getClientRegistrationRepository(); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; ClientRegistrationRepository it = clientRegistrationRepository1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       int $i$a$-also-OAuth2ClientDsl$get$1$1 = 0; oauth2Client.clientRegistrationRepository(oAuth2ClientDsl.getClientRegistrationRepository()); } else { OAuth2ClientDsl.this.getClientRegistrationRepository(); }  if (OAuth2ClientDsl.this.getAuthorizedClientRepository() != null) { OAuth2AuthorizedClientRepository oAuth2AuthorizedClientRepository1 = OAuth2ClientDsl.this.getAuthorizedClientRepository(); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; OAuth2AuthorizedClientRepository it = oAuth2AuthorizedClientRepository1; int $i$a$-also-OAuth2ClientDsl$get$1$2 = 0; oauth2Client.authorizedClientRepository(oAuth2ClientDsl.getAuthorizedClientRepository()); } else { OAuth2ClientDsl.this.getAuthorizedClientRepository(); }  if (OAuth2ClientDsl.this.getAuthorizedClientService() != null) { OAuth2AuthorizedClientService oAuth2AuthorizedClientService1 = OAuth2ClientDsl.this.getAuthorizedClientService(); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; OAuth2AuthorizedClientService it = oAuth2AuthorizedClientService1; int $i$a$-also-OAuth2ClientDsl$get$1$3 = 0; oauth2Client.authorizedClientService(oAuth2ClientDsl.getAuthorizedClientService()); } else { OAuth2ClientDsl.this.getAuthorizedClientService(); }  if (OAuth2ClientDsl.access$getAuthorizationCodeGrant$p(OAuth2ClientDsl.this) != null) { Function1 function11 = OAuth2ClientDsl.access$getAuthorizationCodeGrant$p(OAuth2ClientDsl.this); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; Function1 it = function11; int $i$a$-also-OAuth2ClientDsl$get$1$4 = 0;
/*     */       OAuth2ClientDsl.access$getAuthorizationCodeGrant$p(oAuth2ClientDsl);
/*     */       oauth2Client.authorizationCodeGrant((OAuth2ClientDsl.access$getAuthorizationCodeGrant$p(oAuth2ClientDsl) != null) ? OAuth2ClientDsl.access$getAuthorizationCodeGrant$p(oAuth2ClientDsl)::invoke$lambda$4$lambda$3 : null); }
/*     */     else
/*     */     { OAuth2ClientDsl.access$getAuthorizationCodeGrant$p(OAuth2ClientDsl.this); }
/*     */   
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$4$lambda$3(Function1 $tmp0, OAuth2ClientConfigurer.AuthorizationCodeGrantConfigurer t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   OAuth2ClientDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OAuth2ClientDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */