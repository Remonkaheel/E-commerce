/*     */ package org.springframework.security.config.annotation.web.builders;
/*     */ 
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.AbstractConfiguredSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.AbstractRequestMatcherRegistry;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.access.AuthorizationManagerWebInvocationPrivilegeEvaluator;
/*     */ import org.springframework.security.web.access.DefaultWebInvocationPrivilegeEvaluator;
/*     */ import org.springframework.security.web.access.RequestMatcherDelegatingWebInvocationPrivilegeEvaluator;
/*     */ import org.springframework.security.web.access.WebInvocationPrivilegeEvaluator;
/*     */ import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;
/*     */ import org.springframework.security.web.access.intercept.AuthorizationFilter;
/*     */ import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
/*     */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*     */ import org.springframework.security.web.access.intercept.RequestMatcherDelegatingAuthorizationManager;
/*     */ import org.springframework.security.web.debug.DebugFilter;
/*     */ import org.springframework.security.web.firewall.CompositeRequestRejectedHandler;
/*     */ import org.springframework.security.web.firewall.HttpFirewall;
/*     */ import org.springframework.security.web.firewall.HttpStatusRequestRejectedHandler;
/*     */ import org.springframework.security.web.firewall.ObservationMarkingRequestRejectedHandler;
/*     */ import org.springframework.security.web.firewall.RequestRejectedHandler;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebSecurity
/*     */   extends AbstractConfiguredSecurityBuilder<Filter, WebSecurity>
/*     */   implements SecurityBuilder<Filter>, ApplicationContextAware, ServletContextAware
/*     */ {
/* 101 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 103 */   private final List<RequestMatcher> ignoredRequests = new ArrayList<>();
/*     */   
/* 105 */   private final List<SecurityBuilder<? extends SecurityFilterChain>> securityFilterChainBuilders = new ArrayList<>();
/*     */   
/*     */   private IgnoredRequestConfigurer ignoredRequestRegistry;
/*     */   
/*     */   private HttpFirewall httpFirewall;
/*     */   
/*     */   private RequestRejectedHandler requestRejectedHandler;
/*     */   
/*     */   private boolean debugEnabled;
/*     */   
/*     */   private WebInvocationPrivilegeEvaluator privilegeEvaluator;
/*     */   
/* 117 */   private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;
/*     */ 
/*     */   
/* 120 */   private ObjectPostProcessor<FilterChainProxy.FilterChainDecorator> filterChainDecoratorPostProcessor = ObjectPostProcessor.identity();
/*     */   
/*     */   private AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer privilegeEvaluatorRequestTransformer;
/*     */   
/* 124 */   private DefaultWebSecurityExpressionHandler defaultWebSecurityExpressionHandler = new DefaultWebSecurityExpressionHandler();
/*     */   
/* 126 */   private SecurityExpressionHandler<FilterInvocation> expressionHandler = (SecurityExpressionHandler<FilterInvocation>)this.defaultWebSecurityExpressionHandler;
/*     */ 
/*     */   
/*     */   private Runnable postBuildAction = () -> {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*     */   private ServletContext servletContext;
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity(ObjectPostProcessor<Object> objectPostProcessor) {
/* 139 */     super(objectPostProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public WebSecurity(ObjectPostProcessor<Object> objectPostProcessor) {
/* 147 */     super(objectPostProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IgnoredRequestConfigurer ignoring() {
/* 191 */     return this.ignoredRequestRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity httpFirewall(HttpFirewall httpFirewall) {
/* 201 */     this.httpFirewall = httpFirewall;
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity debug(boolean debugEnabled) {
/* 213 */     this.debugEnabled = debugEnabled;
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity addSecurityFilterChainBuilder(SecurityBuilder<? extends SecurityFilterChain> securityFilterChainBuilder) {
/* 232 */     this.securityFilterChainBuilders.add(securityFilterChainBuilder);
/* 233 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity privilegeEvaluator(WebInvocationPrivilegeEvaluator privilegeEvaluator) {
/* 244 */     this.privilegeEvaluator = privilegeEvaluator;
/* 245 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity expressionHandler(SecurityExpressionHandler<FilterInvocation> expressionHandler) {
/* 255 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/* 256 */     this.expressionHandler = expressionHandler;
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityExpressionHandler<FilterInvocation> getExpressionHandler() {
/* 265 */     return this.expressionHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebInvocationPrivilegeEvaluator getPrivilegeEvaluator() {
/* 273 */     return this.privilegeEvaluator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity postBuildAction(Runnable postBuildAction) {
/* 282 */     this.postBuildAction = postBuildAction;
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSecurity requestRejectedHandler(RequestRejectedHandler requestRejectedHandler) {
/* 294 */     Assert.notNull(requestRejectedHandler, "requestRejectedHandler cannot be null");
/* 295 */     this.requestRejectedHandler = requestRejectedHandler;
/* 296 */     return this;
/*     */   }
/*     */   
/*     */   protected Filter performBuild() throws Exception {
/*     */     DebugFilter debugFilter;
/* 301 */     Assert.state(!this.securityFilterChainBuilders.isEmpty(), () -> "At least one SecurityBuilder<? extends SecurityFilterChain> needs to be specified. Typically this is done by exposing a SecurityFilterChain bean. More advanced users can invoke " + WebSecurity.class.getSimpleName() + ".addSecurityFilterChainBuilder directly");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     int chainSize = this.ignoredRequests.size() + this.securityFilterChainBuilders.size();
/* 307 */     List<SecurityFilterChain> securityFilterChains = new ArrayList<>(chainSize);
/*     */     
/* 309 */     RequestMatcherDelegatingAuthorizationManager.Builder builder = RequestMatcherDelegatingAuthorizationManager.builder();
/* 310 */     boolean mappings = false;
/* 311 */     for (RequestMatcher ignoredRequest : this.ignoredRequests) {
/* 312 */       this.logger.warn("You are asking Spring Security to ignore " + String.valueOf(ignoredRequest) + ". This is not recommended -- please use permitAll via HttpSecurity#authorizeHttpRequests instead.");
/*     */       
/* 314 */       DefaultSecurityFilterChain defaultSecurityFilterChain = new DefaultSecurityFilterChain(ignoredRequest, new Filter[0]);
/* 315 */       securityFilterChains.add(defaultSecurityFilterChain);
/* 316 */       builder.add(ignoredRequest, (AuthorizationManager)SingleResultAuthorizationManager.permitAll());
/* 317 */       mappings = true;
/*     */     } 
/* 319 */     for (SecurityBuilder<? extends SecurityFilterChain> securityFilterChainBuilder : this.securityFilterChainBuilders) {
/* 320 */       SecurityFilterChain securityFilterChain = (SecurityFilterChain)securityFilterChainBuilder.build();
/* 321 */       securityFilterChains.add(securityFilterChain);
/* 322 */       mappings = (addAuthorizationManager(securityFilterChain, builder) || mappings);
/*     */     } 
/* 324 */     if (this.privilegeEvaluator == null) {
/*     */       
/* 326 */       AuthorizationManager<HttpServletRequest> authorizationManager = mappings ? (AuthorizationManager<HttpServletRequest>)builder.build() : (AuthorizationManager<HttpServletRequest>)SingleResultAuthorizationManager.permitAll();
/* 327 */       AuthorizationManagerWebInvocationPrivilegeEvaluator privilegeEvaluator = new AuthorizationManagerWebInvocationPrivilegeEvaluator(authorizationManager);
/*     */       
/* 329 */       privilegeEvaluator.setServletContext(this.servletContext);
/* 330 */       if (this.privilegeEvaluatorRequestTransformer != null) {
/* 331 */         privilegeEvaluator.setRequestTransformer(this.privilegeEvaluatorRequestTransformer);
/*     */       }
/* 333 */       this
/* 334 */         .privilegeEvaluator = (WebInvocationPrivilegeEvaluator)new RequestMatcherDelegatingWebInvocationPrivilegeEvaluator(List.of(new RequestMatcherEntry(AnyRequestMatcher.INSTANCE, List.of(privilegeEvaluator))));
/*     */     } 
/* 336 */     FilterChainProxy filterChainProxy = new FilterChainProxy(securityFilterChains);
/* 337 */     if (this.httpFirewall != null) {
/* 338 */       filterChainProxy.setFirewall(this.httpFirewall);
/*     */     }
/* 340 */     if (this.requestRejectedHandler != null) {
/* 341 */       filterChainProxy.setRequestRejectedHandler(this.requestRejectedHandler);
/*     */     }
/* 343 */     else if (!this.observationRegistry.isNoop()) {
/* 344 */       CompositeRequestRejectedHandler requestRejectedHandler = new CompositeRequestRejectedHandler(new RequestRejectedHandler[] { (RequestRejectedHandler)new ObservationMarkingRequestRejectedHandler(this.observationRegistry), (RequestRejectedHandler)new HttpStatusRequestRejectedHandler() });
/*     */ 
/*     */       
/* 347 */       filterChainProxy.setRequestRejectedHandler((RequestRejectedHandler)requestRejectedHandler);
/*     */     } 
/* 349 */     filterChainProxy.setFilterChainValidator(new WebSecurityFilterChainValidator());
/* 350 */     filterChainProxy.setFilterChainDecorator(getFilterChainDecorator());
/* 351 */     filterChainProxy.afterPropertiesSet();
/*     */     
/* 353 */     FilterChainProxy filterChainProxy1 = filterChainProxy;
/* 354 */     if (this.debugEnabled) {
/* 355 */       this.logger.warn("\n\n********************************************************************\n**********        Security debugging is enabled.       *************\n**********    This may include sensitive information.  *************\n**********      Do not use in a production system!     *************\n********************************************************************\n\n");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 360 */       debugFilter = new DebugFilter(filterChainProxy);
/*     */     } 
/*     */     
/* 363 */     this.postBuildAction.run();
/* 364 */     return (Filter)debugFilter;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean addAuthorizationManager(SecurityFilterChain securityFilterChain, RequestMatcherDelegatingAuthorizationManager.Builder builder) {
/* 369 */     boolean mappings = false;
/* 370 */     for (Iterator<Filter> iterator = securityFilterChain.getFilters().iterator(); iterator.hasNext(); ) { Filter filter = iterator.next();
/* 371 */       if (filter instanceof FilterSecurityInterceptor) { FilterSecurityInterceptor securityInterceptor = (FilterSecurityInterceptor)filter;
/* 372 */         DefaultWebInvocationPrivilegeEvaluator privilegeEvaluator = new DefaultWebInvocationPrivilegeEvaluator((AbstractSecurityInterceptor)securityInterceptor);
/*     */         
/* 374 */         privilegeEvaluator.setServletContext(this.servletContext);
/* 375 */         AuthorizationManager<RequestAuthorizationContext> authorizationManager = (authentication, context) -> {
/*     */             HttpServletRequest request = context.getRequest();
/*     */             
/*     */             boolean result = privilegeEvaluator.isAllowed(request.getContextPath(), request.getRequestURI(), request.getMethod(), authentication.get());
/*     */             return new AuthorizationDecision(result);
/*     */           };
/* 381 */         Objects.requireNonNull(securityFilterChain); builder.add(securityFilterChain::matches, authorizationManager);
/* 382 */         mappings = true;
/*     */         continue; }
/*     */       
/* 385 */       if (filter instanceof AuthorizationFilter) { AuthorizationFilter authorization = (AuthorizationFilter)filter;
/* 386 */         AuthorizationManager<HttpServletRequest> authorizationManager = authorization.getAuthorizationManager();
/* 387 */         Objects.requireNonNull(securityFilterChain); builder.add(securityFilterChain::matches, (authentication, context) -> (AuthorizationDecision)authorizationManager.authorize(authentication, context.getRequest()));
/*     */ 
/*     */         
/* 390 */         mappings = true; }
/*     */        }
/*     */     
/* 393 */     return mappings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 398 */     this.defaultWebSecurityExpressionHandler.setApplicationContext(applicationContext);
/*     */     try {
/* 400 */       this.defaultWebSecurityExpressionHandler.setRoleHierarchy((RoleHierarchy)applicationContext.getBean(RoleHierarchy.class));
/*     */     }
/* 402 */     catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     
/*     */     try {
/* 405 */       this.defaultWebSecurityExpressionHandler
/* 406 */         .setPermissionEvaluator((PermissionEvaluator)applicationContext.getBean(PermissionEvaluator.class));
/*     */     }
/* 408 */     catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     
/* 410 */     this.ignoredRequestRegistry = new IgnoredRequestConfigurer(applicationContext);
/*     */     try {
/* 412 */       this.httpFirewall = (HttpFirewall)applicationContext.getBean(HttpFirewall.class);
/*     */     }
/* 414 */     catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     
/*     */     try {
/* 417 */       this.requestRejectedHandler = (RequestRejectedHandler)applicationContext.getBean(RequestRejectedHandler.class);
/*     */     }
/* 419 */     catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     
/*     */     try {
/* 422 */       this.observationRegistry = (ObservationRegistry)applicationContext.getBean(ObservationRegistry.class);
/*     */     }
/* 424 */     catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     
/* 426 */     ResolvableType type = ResolvableType.forClassWithGenerics(ObjectPostProcessor.class, new Class[] { FilterChainProxy.FilterChainDecorator.class });
/*     */ 
/*     */     
/* 429 */     ObjectProvider<ObjectPostProcessor<FilterChainProxy.FilterChainDecorator>> postProcessor = applicationContext.getBeanProvider(type);
/* 430 */     this.filterChainDecoratorPostProcessor = (ObjectPostProcessor<FilterChainProxy.FilterChainDecorator>)postProcessor.getIfUnique(ObjectPostProcessor::identity);
/* 431 */     Class<AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer> requestTransformerClass = AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer.class;
/* 432 */     this
/* 433 */       .privilegeEvaluatorRequestTransformer = (AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer)applicationContext.getBeanProvider(requestTransformerClass).getIfUnique();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServletContext(ServletContext servletContext) {
/* 438 */     this.servletContext = servletContext;
/*     */   }
/*     */   
/*     */   FilterChainProxy.FilterChainDecorator getFilterChainDecorator() {
/* 442 */     return (FilterChainProxy.FilterChainDecorator)this.filterChainDecoratorPostProcessor.postProcess(new FilterChainProxy.VirtualFilterChainDecorator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class IgnoredRequestConfigurer
/*     */     extends AbstractRequestMatcherRegistry<IgnoredRequestConfigurer>
/*     */   {
/*     */     IgnoredRequestConfigurer(ApplicationContext context) {
/* 455 */       setApplicationContext(context);
/*     */     }
/*     */ 
/*     */     
/*     */     protected IgnoredRequestConfigurer chainRequestMatchers(List<RequestMatcher> requestMatchers) {
/* 460 */       WebSecurity.this.ignoredRequests.addAll(requestMatchers);
/* 461 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WebSecurity and() {
/* 468 */       return WebSecurity.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\builders\WebSecurity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */