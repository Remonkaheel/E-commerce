/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\t\032\030\022\016\022\f0\013R\b\022\004\022\0020\r0\f\022\004\022\0020\0160\nH\000¢\006\002\b\017R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\b¨\006\020"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/PermissionsPolicyDsl;", "", "()V", "policy", "", "getPolicy", "()Ljava/lang/String;", "setPolicy", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$PermissionsPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class PermissionsPolicyDsl
/*    */ {
/*    */   @Nullable
/*    */   private String policy;
/*    */   
/*    */   @Nullable
/*    */   public final String getPolicy() {
/* 32 */     return this.policy; } public final void setPolicy(@Nullable String <set-?>) { this.policy = <set-?>; }
/*    */   
/*    */   @NotNull
/* 35 */   public final Function1<HeadersConfigurer<HttpSecurity>.PermissionsPolicyConfig, Unit> get$spring_security_config() { return new PermissionsPolicyDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "permissionsPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$PermissionsPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 36 */   static final class PermissionsPolicyDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.PermissionsPolicyConfig, Unit> { public final void invoke(HeadersConfigurer.PermissionsPolicyConfig permissionsPolicy) { Intrinsics.checkNotNullParameter(permissionsPolicy, "permissionsPolicy"); String str1 = PermissionsPolicyDsl.this.getPolicy(); PermissionsPolicyDsl permissionsPolicyDsl = PermissionsPolicyDsl.this; String it = str1; int $i$a$-also-PermissionsPolicyDsl$get$1$1 = 0;
/* 37 */       permissionsPolicy.policy(permissionsPolicyDsl.getPolicy());
/*    */       PermissionsPolicyDsl.this.getPolicy(); }
/*    */ 
/*    */     
/*    */     PermissionsPolicyDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\PermissionsPolicyDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */