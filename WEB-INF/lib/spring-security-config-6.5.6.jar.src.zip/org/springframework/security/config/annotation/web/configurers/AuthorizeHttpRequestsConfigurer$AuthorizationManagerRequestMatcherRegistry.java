/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.web.AbstractRequestMatcherRegistry;
/*     */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*     */ import org.springframework.security.web.access.intercept.RequestMatcherDelegatingAuthorizationManager;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcherEntry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationManagerRequestMatcherRegistry
/*     */   extends AbstractRequestMatcherRegistry<AuthorizeHttpRequestsConfigurer<H>.AuthorizedUrl>
/*     */ {
/* 141 */   private final RequestMatcherDelegatingAuthorizationManager.Builder managerBuilder = RequestMatcherDelegatingAuthorizationManager.builder();
/*     */   
/*     */   private List<RequestMatcher> unmappedMatchers;
/*     */   
/*     */   private int mappingCount;
/*     */   
/*     */   private boolean shouldFilterAllDispatcherTypes = true;
/*     */   
/*     */   private AuthorizationManagerRequestMatcherRegistry(ApplicationContext context) {
/* 150 */     setApplicationContext(context);
/*     */   }
/*     */   
/*     */   private void addMapping(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 154 */     this.unmappedMatchers = null;
/* 155 */     this.managerBuilder.add(matcher, manager);
/* 156 */     this.mappingCount++;
/*     */   }
/*     */   
/*     */   private void addFirst(RequestMatcher matcher, AuthorizationManager<RequestAuthorizationContext> manager) {
/* 160 */     this.unmappedMatchers = null;
/* 161 */     this.managerBuilder.mappings(m -> m.add(0, new RequestMatcherEntry(matcher, manager)));
/* 162 */     this.mappingCount++;
/*     */   }
/*     */   
/*     */   private AuthorizationManager<HttpServletRequest> createAuthorizationManager() {
/* 166 */     Assert.state((this.unmappedMatchers == null), () -> "An incomplete mapping was found for " + String.valueOf(this.unmappedMatchers) + ". Try completing it with something like requestUrls().<something>.hasRole('USER')");
/*     */ 
/*     */     
/* 169 */     Assert.state((this.mappingCount > 0), "At least one mapping is required (for example, authorizeHttpRequests().anyRequest().authenticated())");
/*     */     
/* 171 */     AuthorizationManager<HttpServletRequest> manager = (AuthorizationManager<HttpServletRequest>)AuthorizeHttpRequestsConfigurer.access$000(AuthorizeHttpRequestsConfigurer.this, this.managerBuilder
/* 172 */         .build());
/* 173 */     return (AuthorizationManager<HttpServletRequest>)AuthorizeHttpRequestsConfigurer.this.postProcessor.postProcess(manager);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AuthorizeHttpRequestsConfigurer<H>.AuthorizedUrl chainRequestMatchers(List<RequestMatcher> requestMatchers) {
/* 178 */     this.unmappedMatchers = requestMatchers;
/* 179 */     return new AuthorizeHttpRequestsConfigurer.AuthorizedUrl(AuthorizeHttpRequestsConfigurer.this, requestMatchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManagerRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 190 */     AuthorizeHttpRequestsConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 191 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public AuthorizationManagerRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 200 */     AuthorizeHttpRequestsConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 201 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public AuthorizationManagerRequestMatcherRegistry shouldFilterAllDispatcherTypes(boolean shouldFilter) {
/* 230 */     this.shouldFilterAllDispatcherTypes = shouldFilter;
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public H and() {
/* 242 */     return (H)AuthorizeHttpRequestsConfigurer.this.and();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AuthorizeHttpRequestsConfigurer$AuthorizationManagerRequestMatcherRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */