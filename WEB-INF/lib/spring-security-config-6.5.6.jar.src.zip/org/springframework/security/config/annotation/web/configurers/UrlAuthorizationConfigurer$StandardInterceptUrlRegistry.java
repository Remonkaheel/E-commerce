/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class StandardInterceptUrlRegistry
/*     */   extends AbstractInterceptUrlConfigurer<UrlAuthorizationConfigurer<H>, H>.AbstractInterceptUrlRegistry<UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry, UrlAuthorizationConfigurer<H>.AuthorizedUrl>
/*     */ {
/*     */   private StandardInterceptUrlRegistry(ApplicationContext context) {
/* 211 */     setApplicationContext(context);
/*     */   }
/*     */ 
/*     */   
/*     */   public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(String... patterns) {
/* 216 */     return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(patterns);
/*     */   }
/*     */ 
/*     */   
/*     */   public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(HttpMethod method, String... patterns) {
/* 221 */     return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(method, patterns);
/*     */   }
/*     */ 
/*     */   
/*     */   public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(HttpMethod method) {
/* 226 */     return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(method);
/*     */   }
/*     */ 
/*     */   
/*     */   public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(RequestMatcher... requestMatchers) {
/* 231 */     return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(requestMatchers);
/*     */   }
/*     */ 
/*     */   
/*     */   protected UrlAuthorizationConfigurer<H>.AuthorizedUrl chainRequestMatchersInternal(List<RequestMatcher> requestMatchers) {
/* 236 */     return new UrlAuthorizationConfigurer.AuthorizedUrl(UrlAuthorizationConfigurer.this, requestMatchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardInterceptUrlRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 246 */     UrlAuthorizationConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 247 */     return this;
/*     */   }
/*     */   
/*     */   public H and() {
/* 251 */     return (H)UrlAuthorizationConfigurer.this.and();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\UrlAuthorizationConfigurer$StandardInterceptUrlRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */