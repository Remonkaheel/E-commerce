/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.http.HttpEntity;
/*    */ import org.springframework.http.ResponseEntity;
/*    */ import org.springframework.security.authorization.method.AuthorizationAdvisorProxyFactory;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.servlet.ModelAndView;
/*    */ import org.springframework.web.servlet.View;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration
/*    */ class AuthorizationProxyWebConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Role(2)
/*    */   AuthorizationAdvisorProxyFactory.TargetVisitor webTargetVisitor() {
/* 38 */     return new WebTargetVisitor();
/*    */   }
/*    */   
/*    */   static class WebTargetVisitor
/*    */     implements AuthorizationAdvisorProxyFactory.TargetVisitor, Ordered
/*    */   {
/*    */     private static final int DEFAULT_ORDER = 100;
/*    */     
/*    */     public Object visit(AuthorizationAdvisorProxyFactory proxyFactory, Object target) {
/* 47 */       if (target instanceof ResponseEntity) { ResponseEntity<?> entity = (ResponseEntity)target;
/* 48 */         return new ResponseEntity(proxyFactory.proxy(entity.getBody()), (MultiValueMap)entity.getHeaders(), entity
/* 49 */             .getStatusCode()); }
/*    */       
/* 51 */       if (target instanceof HttpEntity) { HttpEntity<?> entity = (HttpEntity)target;
/* 52 */         return new HttpEntity(proxyFactory.proxy(entity.getBody()), (MultiValueMap)entity.getHeaders()); }
/*    */       
/* 54 */       if (target instanceof ModelAndView) { ModelAndView mav = (ModelAndView)target;
/* 55 */         View view = mav.getView();
/* 56 */         String viewName = mav.getViewName();
/* 57 */         Map<String, Object> model = (Map<String, Object>)proxyFactory.proxy(mav.getModel());
/*    */         
/* 59 */         ModelAndView proxied = (view != null) ? new ModelAndView(view, model) : new ModelAndView(viewName, model);
/* 60 */         proxied.setStatus(mav.getStatus());
/* 61 */         return proxied; }
/*    */       
/* 63 */       return null;
/*    */     }
/*    */ 
/*    */     
/*    */     public int getOrder() {
/* 68 */       return 100;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\AuthorizationProxyWebConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */