/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.DependsOn;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityConfigurer;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.builders.WebSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer;
/*     */ import org.springframework.security.config.crypto.RsaKeyConversionServicePostProcessor;
/*     */ import org.springframework.security.context.DelegatingApplicationListener;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.access.WebInvocationPrivilegeEvaluator;
/*     */ import org.springframework.security.web.debug.DebugFilter;
/*     */ import org.springframework.security.web.firewall.HttpFirewall;
/*     */ import org.springframework.security.web.firewall.RequestRejectedHandler;
/*     */ import org.springframework.web.filter.CompositeFilter;
/*     */ import org.springframework.web.filter.ServletRequestPathFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ public class WebSecurityConfiguration
/*     */   implements ImportAware
/*     */ {
/*     */   private WebSecurity webSecurity;
/*     */   private Boolean debugEnabled;
/*  94 */   private List<SecurityFilterChain> securityFilterChains = Collections.emptyList();
/*     */   
/*  96 */   private List<WebSecurityCustomizer> webSecurityCustomizers = Collections.emptyList();
/*     */   
/*     */   @Bean
/*     */   public static DelegatingApplicationListener delegatingApplicationListener() {
/* 100 */     return new DelegatingApplicationListener();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @DependsOn({"springSecurityFilterChain"})
/*     */   public SecurityExpressionHandler<FilterInvocation> webSecurityExpressionHandler() {
/* 106 */     return this.webSecurity.getExpressionHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean(name = {"springSecurityFilterChain"})
/*     */   public Filter springSecurityFilterChain(ObjectProvider<HttpSecurity> provider) throws Exception {
/* 116 */     boolean hasFilterChain = !this.securityFilterChains.isEmpty();
/* 117 */     if (!hasFilterChain) {
/* 118 */       this.webSecurity.addSecurityFilterChainBuilder(() -> {
/*     */             HttpSecurity httpSecurity = (HttpSecurity)provider.getObject();
/*     */             httpSecurity.authorizeHttpRequests(());
/*     */             httpSecurity.formLogin(Customizer.withDefaults());
/*     */             httpSecurity.httpBasic(Customizer.withDefaults());
/*     */             return (SecurityFilterChain)httpSecurity.build();
/*     */           });
/*     */     }
/* 126 */     for (SecurityFilterChain securityFilterChain : this.securityFilterChains) {
/* 127 */       this.webSecurity.addSecurityFilterChainBuilder(() -> securityFilterChain);
/*     */     }
/* 129 */     for (WebSecurityCustomizer customizer : this.webSecurityCustomizers) {
/* 130 */       customizer.customize(this.webSecurity);
/*     */     }
/* 132 */     return (Filter)this.webSecurity.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @DependsOn({"springSecurityFilterChain"})
/*     */   public WebInvocationPrivilegeEvaluator privilegeEvaluator() {
/* 143 */     return this.webSecurity.getPrivilegeEvaluator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setFilterChainProxySecurityConfigurer(ObjectPostProcessor<Object> objectPostProcessor, ConfigurableListableBeanFactory beanFactory) throws Exception {
/* 159 */     this.webSecurity = (WebSecurity)objectPostProcessor.postProcess(new WebSecurity(objectPostProcessor));
/* 160 */     if (this.debugEnabled != null) {
/* 161 */       this.webSecurity.debug(this.debugEnabled.booleanValue());
/*     */     }
/*     */ 
/*     */     
/* 165 */     List<SecurityConfigurer<Filter, WebSecurity>> webSecurityConfigurers = (new AutowiredWebSecurityConfigurersIgnoreParents(beanFactory)).getWebSecurityConfigurers();
/* 166 */     webSecurityConfigurers.sort((Comparator<? super SecurityConfigurer<Filter, WebSecurity>>)AnnotationAwareOrderComparator.INSTANCE);
/* 167 */     Integer previousOrder = null;
/* 168 */     Object<Filter, WebSecurity> previousConfig = null;
/* 169 */     for (SecurityConfigurer<Filter, WebSecurity> config : webSecurityConfigurers) {
/* 170 */       Integer order = Integer.valueOf(AnnotationAwareOrderComparator.lookupOrder(config));
/* 171 */       if (previousOrder != null && previousOrder.equals(order)) {
/* 172 */         throw new IllegalStateException("@Order on WebSecurityConfigurers must be unique. Order of " + order + " was already used on " + String.valueOf(previousConfig) + ", so it cannot be used on " + String.valueOf(config) + " too.");
/*     */       }
/*     */       
/* 175 */       previousOrder = order;
/* 176 */       previousConfig = (Object<Filter, WebSecurity>)config;
/*     */     } 
/* 178 */     for (SecurityConfigurer<Filter, WebSecurity> webSecurityConfigurer : webSecurityConfigurers) {
/* 179 */       this.webSecurity.apply(webSecurityConfigurer);
/*     */     }
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setFilterChains(List<SecurityFilterChain> securityFilterChains) {
/* 185 */     this.securityFilterChains = securityFilterChains;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setWebSecurityCustomizers(List<WebSecurityCustomizer> webSecurityCustomizers) {
/* 190 */     this.webSecurityCustomizers = webSecurityCustomizers;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public static BeanFactoryPostProcessor conversionServicePostProcessor() {
/* 195 */     return (BeanFactoryPostProcessor)new RsaKeyConversionServicePostProcessor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/* 201 */     Map<String, Object> enableWebSecurityAttrMap = importMetadata.getAnnotationAttributes(EnableWebSecurity.class.getName());
/* 202 */     AnnotationAttributes enableWebSecurityAttrs = AnnotationAttributes.fromMap(enableWebSecurityAttrMap);
/* 203 */     this.debugEnabled = Boolean.valueOf(enableWebSecurityAttrs.getBoolean("debug"));
/* 204 */     if (this.webSecurity != null) {
/* 205 */       this.webSecurity.debug(this.debugEnabled.booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   static BeanDefinitionRegistryPostProcessor springSecurityPathPatternParserBeanDefinitionRegistryPostProcessor() {
/* 222 */     return new BeanDefinitionRegistryPostProcessor()
/*     */       {
/*     */         public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 230 */           BeanDefinition filterChainProxy = registry.getBeanDefinition("springSecurityFilterChain");
/*     */           
/* 232 */           if (filterChainProxy.getResolvableType().isInstance(WebSecurityConfiguration.CompositeFilterChainProxy.class)) {
/*     */             return;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 238 */           BeanDefinitionBuilder pppCacheFilterBldr = BeanDefinitionBuilder.rootBeanDefinition(ServletRequestPathFilter.class).setRole(2);
/*     */           
/* 240 */           ManagedList<BeanMetadataElement> filters = new ManagedList();
/* 241 */           filters.add(pppCacheFilterBldr.getBeanDefinition());
/* 242 */           filters.add(filterChainProxy);
/*     */ 
/*     */           
/* 245 */           BeanDefinitionBuilder compositeSpringSecurityFilterChainBldr = BeanDefinitionBuilder.rootBeanDefinition(WebSecurityConfiguration.CompositeFilterChainProxy.class).addConstructorArgValue(filters);
/*     */           
/* 247 */           registry.removeBeanDefinition("springSecurityFilterChain");
/* 248 */           registry.registerBeanDefinition("springSecurityFilterChain", (BeanDefinition)compositeSpringSecurityFilterChainBldr
/* 249 */               .getBeanDefinition());
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AnnotationAwareOrderComparator
/*     */     extends OrderComparator
/*     */   {
/* 264 */     private static final AnnotationAwareOrderComparator INSTANCE = new AnnotationAwareOrderComparator();
/*     */ 
/*     */     
/*     */     protected int getOrder(Object obj) {
/* 268 */       return lookupOrder(obj);
/*     */     }
/*     */     
/*     */     private static int lookupOrder(Object obj) {
/* 272 */       if (obj instanceof Ordered) {
/* 273 */         return ((Ordered)obj).getOrder();
/*     */       }
/* 275 */       if (obj != null) {
/* 276 */         Class<?> clazz = (obj instanceof Class) ? (Class)obj : obj.getClass();
/* 277 */         Order order = (Order)AnnotationUtils.findAnnotation(clazz, Order.class);
/* 278 */         if (order != null) {
/* 279 */           return order.value();
/*     */         }
/*     */       } 
/* 282 */       return Integer.MAX_VALUE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CompositeFilterChainProxy
/*     */     extends FilterChainProxy
/*     */   {
/*     */     private final Filter doFilterDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final FilterChainProxy springSecurityFilterChain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CompositeFilterChainProxy(List<? extends Filter> filters) {
/* 307 */       this.doFilterDelegate = createDoFilterDelegate(filters);
/* 308 */       this.springSecurityFilterChain = findFilterChainProxy(filters);
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterPropertiesSet() {
/* 313 */       this.springSecurityFilterChain.afterPropertiesSet();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 319 */       this.doFilterDelegate.doFilter(request, response, chain);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Filter> getFilters(String url) {
/* 324 */       return this.springSecurityFilterChain.getFilters(url);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<SecurityFilterChain> getFilterChains() {
/* 329 */       return this.springSecurityFilterChain.getFilterChains();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 334 */       this.springSecurityFilterChain.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFilterChainValidator(FilterChainProxy.FilterChainValidator filterChainValidator) {
/* 339 */       this.springSecurityFilterChain.setFilterChainValidator(filterChainValidator);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFilterChainDecorator(FilterChainProxy.FilterChainDecorator filterChainDecorator) {
/* 344 */       this.springSecurityFilterChain.setFilterChainDecorator(filterChainDecorator);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFirewall(HttpFirewall firewall) {
/* 349 */       this.springSecurityFilterChain.setFirewall(firewall);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setRequestRejectedHandler(RequestRejectedHandler requestRejectedHandler) {
/* 354 */       this.springSecurityFilterChain.setRequestRejectedHandler(requestRejectedHandler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<? extends Filter> getFilters(HttpServletRequest request) {
/* 364 */       List<SecurityFilterChain> filterChains = this.springSecurityFilterChain.getFilterChains();
/* 365 */       for (SecurityFilterChain chain : filterChains) {
/* 366 */         if (chain.matches(request)) {
/* 367 */           return chain.getFilters();
/*     */         }
/*     */       } 
/* 370 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Filter createDoFilterDelegate(List<? extends Filter> filters) {
/* 379 */       CompositeFilter delegate = new CompositeFilter();
/* 380 */       delegate.setFilters(filters);
/* 381 */       return (Filter)delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static FilterChainProxy findFilterChainProxy(List<? extends Filter> filters) {
/* 391 */       for (Filter filter : filters) {
/* 392 */         if (filter instanceof FilterChainProxy) { FilterChainProxy fcp = (FilterChainProxy)filter;
/* 393 */           return fcp; }
/*     */         
/* 395 */         if (filter instanceof DebugFilter) { DebugFilter debugFilter = (DebugFilter)filter;
/* 396 */           return debugFilter.getFilterChainProxy(); }
/*     */       
/*     */       } 
/* 399 */       throw new IllegalStateException("Couldn't find FilterChainProxy in " + String.valueOf(filters));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\WebSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */