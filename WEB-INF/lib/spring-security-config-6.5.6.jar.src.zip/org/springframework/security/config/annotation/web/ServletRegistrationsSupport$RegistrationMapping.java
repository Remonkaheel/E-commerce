/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import jakarta.servlet.ServletRegistration;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RegistrationMapping
/*    */   extends Record
/*    */ {
/*    */   private final ServletRegistration registration;
/*    */   private final String mapping;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #59	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #59	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #59	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   RegistrationMapping(ServletRegistration registration, String mapping) {
/* 59 */     this.registration = registration; this.mapping = mapping; } public ServletRegistration registration() { return this.registration; } public String mapping() { return this.mapping; }
/*    */   
/*    */   boolean isDispatcherServlet() {
/* 62 */     Class<?> dispatcherServlet = ClassUtils.resolveClassName("org.springframework.web.servlet.DispatcherServlet", null);
/*    */     try {
/* 64 */       Class<?> clazz = Class.forName(this.registration.getClassName());
/* 65 */       return dispatcherServlet.isAssignableFrom(clazz);
/*    */     }
/* 67 */     catch (ClassNotFoundException ex) {
/* 68 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   boolean isDefault() {
/* 73 */     return "/".equals(this.mapping);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\ServletRegistrationsSupport$RegistrationMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */