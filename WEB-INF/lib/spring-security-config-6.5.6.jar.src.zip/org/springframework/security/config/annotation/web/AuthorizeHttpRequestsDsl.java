/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.access.hierarchicalroles.NullRoleHierarchy;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.web.access.IpAddressAuthorizationManager;
/*     */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020!\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\t\n\002\020\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\021\n\002\b\f\n\002\030\002\n\002\b\002\030\0002\0020\001B\007\b\026¢\006\002\020\002B\017\b\026\022\006\020\003\032\0020\004¢\006\002\020\005J$\020%\032\0020&2\006\020'\032\0020\0072\006\020(\032\0020\0072\f\020)\032\b\022\004\022\0020\0170\016J\034\020%\032\0020&2\006\020'\032\0020\0072\f\020)\032\b\022\004\022\0020\0170\016J,\020%\032\0020&2\006\020*\032\0020+2\006\020'\032\0020\0072\006\020(\032\0020\0072\f\020)\032\b\022\004\022\0020\0170\016J$\020%\032\0020&2\006\020*\032\0020+2\006\020'\032\0020\0072\f\020)\032\b\022\004\022\0020\0170\016J\036\020%\032\0020&2\b\b\002\020,\032\0020-2\f\020)\032\b\022\004\022\0020\0170\016J#\020.\032\030\022\016\022\f00R\b\022\004\022\0020201\022\004\022\0020&0/H\000¢\006\002\b3J%\0204\032\b\022\004\022\0020\0170\0162\022\0205\032\n\022\006\b\001\022\0020\00706\"\0020\007¢\006\002\0207J%\0208\032\b\022\004\022\0020\0170\0162\022\0209\032\n\022\006\b\001\022\0020\00706\"\0020\007¢\006\002\0207J\024\020:\032\b\022\004\022\0020\0170\0162\006\020;\032\0020\007J\024\020<\032\b\022\004\022\0020\0170\0162\006\020=\032\0020\007J\024\020>\032\b\022\004\022\0020\0170\0162\006\020?\032\0020\007J\020\020@\032\0020\0342\006\020\003\032\0020\004H\002J\020\020A\032\0020\0072\006\020\003\032\0020\004H\002J\034\020B\032\b\022\004\022\0020\0170C2\f\020D\032\b\022\004\022\0020\0170CH\002R\016\020\006\032\0020\007XD¢\006\002\n\000R\016\020\b\032\0020\007XD¢\006\002\n\000R\016\020\t\032\0020\nX\004¢\006\002\n\000R\016\020\013\032\0020\fX\004¢\006\002\n\000R\027\020\r\032\b\022\004\022\0020\0170\016¢\006\b\n\000\032\004\b\020\020\021R\024\020\022\032\b\022\004\022\0020\0240\023X\004¢\006\002\n\000R\027\020\025\032\b\022\004\022\0020\0170\016¢\006\b\n\000\032\004\b\026\020\021R\027\020\027\032\b\022\004\022\0020\0170\016¢\006\b\n\000\032\004\b\030\020\021R\027\020\031\032\b\022\004\022\0020\0170\016¢\006\b\n\000\032\004\b\032\020\021R\016\020\033\032\0020\034X\004¢\006\002\n\000R\016\020\035\032\0020\007X\004¢\006\002\n\000R(\020\036\032\004\030\0010\n8\006@\006X\016¢\006\026\n\002\020$\022\004\b\037\020\002\032\004\b \020!\"\004\b\"\020#¨\006E"}, d2 = {"Lorg/springframework/security/config/annotation/web/AuthorizeHttpRequestsDsl;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl;", "()V", "context", "Lorg/springframework/context/ApplicationContext;", "(Lorg/springframework/context/ApplicationContext;)V", "HANDLER_MAPPING_INTROSPECTOR", "", "HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME", "MVC_PRESENT", "", "PATTERN_TYPE", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "authenticated", "Lorg/springframework/security/authorization/AuthorizationManager;", "Lorg/springframework/security/web/access/intercept/RequestAuthorizationContext;", "getAuthenticated", "()Lorg/springframework/security/authorization/AuthorizationManager;", "authorizationRules", "", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationManagerRule;", "denyAll", "getDenyAll", "fullyAuthenticated", "getFullyAuthenticated", "permitAll", "getPermitAll", "roleHierarchy", "Lorg/springframework/security/access/hierarchicalroles/RoleHierarchy;", "rolePrefix", "shouldFilterAllDispatcherTypes", "getShouldFilterAllDispatcherTypes$annotations", "getShouldFilterAllDispatcherTypes", "()Ljava/lang/Boolean;", "setShouldFilterAllDispatcherTypes", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "authorize", "", "pattern", "servletPath", "access", "method", "Lorg/springframework/http/HttpMethod;", "matches", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/AuthorizeHttpRequestsConfigurer$AuthorizationManagerRequestMatcherRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/AuthorizeHttpRequestsConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "hasAnyAuthority", "authorities", "", "([Ljava/lang/String;)Lorg/springframework/security/authorization/AuthorizationManager;", "hasAnyRole", "roles", "hasAuthority", "authority", "hasIpAddress", "ipAddress", "hasRole", "role", "resolveRoleHierarchy", "resolveRolePrefix", "withRoleHierarchy", "Lorg/springframework/security/authorization/AuthorityAuthorizationManager;", "manager", "spring-security-config"})
/*     */ public final class AuthorizeHttpRequestsDsl
/*     */   extends AbstractRequestMatcherDsl
/*     */ {
/*     */   @Nullable
/*     */   private Boolean shouldFilterAllDispatcherTypes;
/*     */   
/*     */   @Nullable
/*     */   public final Boolean getShouldFilterAllDispatcherTypes() {
/*  66 */     return this.shouldFilterAllDispatcherTypes; } public final void setShouldFilterAllDispatcherTypes(@Nullable Boolean <set-?>) { this.shouldFilterAllDispatcherTypes = <set-?>; }
/*     */    @NotNull
/*  68 */   private final List<AbstractRequestMatcherDsl.AuthorizationManagerRule> authorizationRules = new ArrayList<>(); @NotNull
/*     */   private final String rolePrefix; @NotNull
/*     */   private final RoleHierarchy roleHierarchy;
/*     */   @NotNull
/*  72 */   private final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector"; @NotNull
/*  73 */   private final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*  74 */   private final boolean MVC_PRESENT = ClassUtils.isPresent(
/*  75 */       this.HANDLER_MAPPING_INTROSPECTOR, 
/*  76 */       AuthorizeHttpRequestsDsl.class.getClassLoader()); @NotNull
/*  77 */   private final AbstractRequestMatcherDsl.PatternType PATTERN_TYPE = this.MVC_PRESENT ? AbstractRequestMatcherDsl.PatternType.MVC : AbstractRequestMatcherDsl.PatternType.ANT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull RequestMatcher matches, @NotNull AuthorizationManager<RequestAuthorizationContext> access) {
/*  88 */     Intrinsics.checkNotNullParameter(matches, "matches"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(new AbstractRequestMatcherDsl.MatcherAuthorizationManagerRule(matches, access));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull String pattern, @NotNull AuthorizationManager access) {
/* 108 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(
/* 109 */         new AbstractRequestMatcherDsl.PatternAuthorizationManagerRule(
/* 110 */           pattern, 
/* 111 */           this.PATTERN_TYPE, null, null, 
/* 112 */           access, 12, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull HttpMethod method, @NotNull String pattern, @NotNull AuthorizationManager access) {
/* 136 */     Intrinsics.checkNotNullParameter(method, "method"); Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(
/* 137 */         new AbstractRequestMatcherDsl.PatternAuthorizationManagerRule(
/* 138 */           pattern, 
/* 139 */           this.PATTERN_TYPE, null, 
/* 140 */           method, 
/* 141 */           access, 4, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull String pattern, @NotNull String servletPath, @NotNull AuthorizationManager access) {
/* 166 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(servletPath, "servletPath"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(
/* 167 */         new AbstractRequestMatcherDsl.PatternAuthorizationManagerRule(
/* 168 */           pattern, 
/* 169 */           this.PATTERN_TYPE, 
/* 170 */           servletPath, null, 
/* 171 */           access, 8, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull HttpMethod method, @NotNull String pattern, @NotNull String servletPath, @NotNull AuthorizationManager<RequestAuthorizationContext> access) {
/* 198 */     Intrinsics.checkNotNullParameter(method, "method"); Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(servletPath, "servletPath"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(
/* 199 */         new AbstractRequestMatcherDsl.PatternAuthorizationManagerRule(
/* 200 */           pattern, 
/* 201 */           this.PATTERN_TYPE, 
/* 202 */           servletPath, 
/* 203 */           method, 
/* 204 */           access));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> hasAuthority(@NotNull String authority) {
/* 216 */     Intrinsics.checkNotNullParameter(authority, "authority"); AuthorityAuthorizationManager<RequestAuthorizationContext> manager = AuthorityAuthorizationManager.hasAuthority(authority);
/* 217 */     Intrinsics.checkNotNullExpressionValue(manager, "manager"); return (AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> hasAnyAuthority(@NotNull String... authorities) {
/* 227 */     Intrinsics.checkNotNullParameter(authorities, "authorities"); AuthorityAuthorizationManager<RequestAuthorizationContext> manager = AuthorityAuthorizationManager.hasAnyAuthority(Arrays.<String>copyOf(authorities, authorities.length));
/* 228 */     Intrinsics.checkNotNullExpressionValue(manager, "manager"); return (AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> hasRole(@NotNull String role) {
/* 238 */     Intrinsics.checkNotNullParameter(role, "role"); String[] arrayOfString = new String[1]; arrayOfString[0] = role; AuthorityAuthorizationManager<RequestAuthorizationContext> manager = AuthorityAuthorizationManager.hasAnyRole(this.rolePrefix, arrayOfString);
/* 239 */     Intrinsics.checkNotNullExpressionValue(manager, "manager"); return (AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> hasAnyRole(@NotNull String... roles) {
/* 249 */     Intrinsics.checkNotNullParameter(roles, "roles"); AuthorityAuthorizationManager<RequestAuthorizationContext> manager = AuthorityAuthorizationManager.hasAnyRole(this.rolePrefix, Arrays.<String>copyOf(roles, roles.length));
/* 250 */     Intrinsics.checkNotNullExpressionValue(manager, "manager"); return (AuthorizationManager<RequestAuthorizationContext>)withRoleHierarchy(manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> hasIpAddress(@NotNull String ipAddress) {
/* 258 */     Intrinsics.checkNotNullParameter(ipAddress, "ipAddress"); Intrinsics.checkNotNullExpressionValue(IpAddressAuthorizationManager.hasIpAddress(ipAddress), "hasIpAddress(ipAddress)"); return (AuthorizationManager<RequestAuthorizationContext>)IpAddressAuthorizationManager.hasIpAddress(ipAddress);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> getPermitAll() {
/* 263 */     return this.permitAll; } @NotNull
/* 264 */   private final AuthorizationManager<RequestAuthorizationContext> permitAll = AuthorizeHttpRequestsDsl::permitAll$lambda$0; private static final AuthorizationDecision permitAll$lambda$0(Supplier paramSupplier, RequestAuthorizationContext paramRequestAuthorizationContext) { Intrinsics.checkNotNullParameter(paramSupplier, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(paramRequestAuthorizationContext, "<anonymous parameter 1>"); return new AuthorizationDecision(true); }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> getDenyAll() {
/* 269 */     return this.denyAll; } @NotNull
/* 270 */   private final AuthorizationManager<RequestAuthorizationContext> denyAll = AuthorizeHttpRequestsDsl::denyAll$lambda$1; @NotNull private final AuthorizationManager<RequestAuthorizationContext> authenticated; private static final AuthorizationDecision denyAll$lambda$1(Supplier paramSupplier, RequestAuthorizationContext paramRequestAuthorizationContext) { Intrinsics.checkNotNullParameter(paramSupplier, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(paramRequestAuthorizationContext, "<anonymous parameter 1>"); return new AuthorizationDecision(false); }
/*     */    @NotNull
/*     */   private final AuthorizationManager<RequestAuthorizationContext> fullyAuthenticated;
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> getAuthenticated() {
/* 275 */     return this.authenticated;
/* 276 */   } public AuthorizeHttpRequestsDsl() { Intrinsics.checkNotNullExpressionValue(AuthenticatedAuthorizationManager.authenticated(), "authenticated()"); this.authenticated = (AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     Intrinsics.checkNotNullExpressionValue(AuthenticatedAuthorizationManager.fullyAuthenticated(), "fullyAuthenticated()"); this.fullyAuthenticated = (AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     this.rolePrefix = "ROLE_";
/* 313 */     this.roleHierarchy = (RoleHierarchy)new NullRoleHierarchy(); } public AuthorizeHttpRequestsDsl(@NotNull ApplicationContext context) { Intrinsics.checkNotNullExpressionValue(AuthenticatedAuthorizationManager.authenticated(), "authenticated()");
/*     */     this.authenticated = (AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.authenticated();
/*     */     Intrinsics.checkNotNullExpressionValue(AuthenticatedAuthorizationManager.fullyAuthenticated(), "fullyAuthenticated()");
/*     */     this.fullyAuthenticated = (AuthorizationManager<RequestAuthorizationContext>)AuthenticatedAuthorizationManager.fullyAuthenticated();
/* 317 */     String rolePrefix = resolveRolePrefix(context);
/* 318 */     this.rolePrefix = rolePrefix;
/* 319 */     RoleHierarchy roleHierarchy = resolveRoleHierarchy(context);
/* 320 */     this.roleHierarchy = roleHierarchy; }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final AuthorizationManager<RequestAuthorizationContext> getFullyAuthenticated() {
/*     */     return this.fullyAuthenticated;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final Function1<AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizationManagerRequestMatcherRegistry, Unit> get$spring_security_config() {
/*     */     return new AuthorizeHttpRequestsDsl$get$1();
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "requests", "Lorg/springframework/security/config/annotation/web/configurers/AuthorizeHttpRequestsConfigurer$AuthorizationManagerRequestMatcherRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/AuthorizeHttpRequestsConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */   @SourceDebugExtension({"SMAP\nAuthorizeHttpRequestsDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AuthorizeHttpRequestsDsl.kt\norg/springframework/security/config/annotation/web/AuthorizeHttpRequestsDsl$get$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,344:1\n1863#2,2:345\n*S KotlinDebug\n*F\n+ 1 AuthorizeHttpRequestsDsl.kt\norg/springframework/security/config/annotation/web/AuthorizeHttpRequestsDsl$get$1\n*L\n287#1:345,2\n*E\n"})
/*     */   static final class AuthorizeHttpRequestsDsl$get$1
/*     */     extends Lambda
/*     */     implements Function1<AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizationManagerRequestMatcherRegistry, Unit>
/*     */   {
/*     */     public final void invoke(AuthorizeHttpRequestsConfigurer.AuthorizationManagerRequestMatcherRegistry requests) {
/*     */       Intrinsics.checkNotNullParameter(requests, "requests");
/*     */       List list = AuthorizeHttpRequestsDsl.this.authorizationRules;
/*     */       AuthorizeHttpRequestsDsl authorizeHttpRequestsDsl = AuthorizeHttpRequestsDsl.this;
/*     */       int $i$f$forEach = 0;
/* 345 */       Iterator iterator = list.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); AbstractRequestMatcherDsl.AuthorizationManagerRule rule = (AbstractRequestMatcherDsl.AuthorizationManagerRule)element$iv; int $i$a$-forEach-AuthorizeHttpRequestsDsl$get$1$1 = 0;
/*     */         AbstractRequestMatcherDsl.AuthorizationManagerRule authorizationManagerRule1 = rule; }
/*     */       
/*     */       Boolean bool = AuthorizeHttpRequestsDsl.this.getShouldFilterAllDispatcherTypes();
/*     */       boolean shouldFilter = bool.booleanValue();
/*     */       int $i$a$-also-AuthorizeHttpRequestsDsl$get$1$2 = 0;
/*     */       requests.shouldFilterAllDispatcherTypes(shouldFilter);
/*     */       AuthorizeHttpRequestsDsl.this.getShouldFilterAllDispatcherTypes();
/*     */     }
/*     */     
/*     */     AuthorizeHttpRequestsDsl$get$1() {
/*     */       super(1);
/*     */     }
/*     */   }
/*     */   
/*     */   private final String resolveRolePrefix(ApplicationContext context) {
/*     */     Intrinsics.checkNotNullExpressionValue(context.getBeanNamesForType(GrantedAuthorityDefaults.class), "context.getBeanNamesForT…rityDefaults::class.java)");
/*     */     String[] beanNames = context.getBeanNamesForType(GrantedAuthorityDefaults.class);
/*     */     if (!((beanNames.length == 0) ? 1 : 0)) {
/*     */       Intrinsics.checkNotNullExpressionValue(((GrantedAuthorityDefaults)context.getBean(GrantedAuthorityDefaults.class)).getRolePrefix(), "context.getBean(GrantedA…s::class.java).rolePrefix");
/*     */       return ((GrantedAuthorityDefaults)context.getBean(GrantedAuthorityDefaults.class)).getRolePrefix();
/*     */     } 
/*     */     return "ROLE_";
/*     */   }
/*     */   
/*     */   private final RoleHierarchy resolveRoleHierarchy(ApplicationContext context) {
/*     */     Intrinsics.checkNotNullExpressionValue(context.getBeanNamesForType(RoleHierarchy.class), "context.getBeanNamesForT…oleHierarchy::class.java)");
/*     */     String[] beanNames = context.getBeanNamesForType(RoleHierarchy.class);
/*     */     if (!((beanNames.length == 0) ? 1 : 0)) {
/*     */       Intrinsics.checkNotNullExpressionValue(context.getBean(RoleHierarchy.class), "context.getBean(RoleHierarchy::class.java)");
/*     */       return (RoleHierarchy)context.getBean(RoleHierarchy.class);
/*     */     } 
/*     */     return (RoleHierarchy)new NullRoleHierarchy();
/*     */   }
/*     */   
/*     */   private final AuthorityAuthorizationManager<RequestAuthorizationContext> withRoleHierarchy(AuthorityAuthorizationManager<RequestAuthorizationContext> manager) {
/*     */     manager.setRoleHierarchy(this.roleHierarchy);
/*     */     return manager;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AuthorizeHttpRequestsDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */