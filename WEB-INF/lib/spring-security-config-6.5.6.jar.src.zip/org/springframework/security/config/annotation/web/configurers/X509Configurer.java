/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UserDetailsByNameServiceWrapper;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;
/*     */ import org.springframework.security.web.authentication.preauth.x509.SubjectDnX509PrincipalExtractor;
/*     */ import org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.preauth.x509.X509PrincipalExtractor;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class X509Configurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<X509Configurer<H>, H>
/*     */ {
/*     */   private X509AuthenticationFilter x509AuthenticationFilter;
/*     */   private X509PrincipalExtractor x509PrincipalExtractor;
/*     */   private AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService;
/*     */   private AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> authenticationDetailsSource;
/*     */   
/*     */   public X509Configurer<H> x509AuthenticationFilter(X509AuthenticationFilter x509AuthenticationFilter) {
/* 106 */     this.x509AuthenticationFilter = x509AuthenticationFilter;
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Configurer<H> x509PrincipalExtractor(X509PrincipalExtractor x509PrincipalExtractor) {
/* 116 */     this.x509PrincipalExtractor = x509PrincipalExtractor;
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Configurer<H> authenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> authenticationDetailsSource) {
/* 127 */     this.authenticationDetailsSource = authenticationDetailsSource;
/* 128 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Configurer<H> userDetailsService(UserDetailsService userDetailsService) {
/* 139 */     UserDetailsByNameServiceWrapper<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService = new UserDetailsByNameServiceWrapper();
/* 140 */     authenticationUserDetailsService.setUserDetailsService(userDetailsService);
/* 141 */     return authenticationUserDetailsService((AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken>)authenticationUserDetailsService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Configurer<H> authenticationUserDetailsService(AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService) {
/* 153 */     this.authenticationUserDetailsService = authenticationUserDetailsService;
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Configurer<H> subjectPrincipalRegex(String subjectPrincipalRegex) {
/* 166 */     SubjectDnX509PrincipalExtractor principalExtractor = new SubjectDnX509PrincipalExtractor();
/* 167 */     principalExtractor.setSubjectDnRegex(subjectPrincipalRegex);
/* 168 */     this.x509PrincipalExtractor = (X509PrincipalExtractor)principalExtractor;
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 174 */     PreAuthenticatedAuthenticationProvider authenticationProvider = new PreAuthenticatedAuthenticationProvider();
/* 175 */     authenticationProvider.setPreAuthenticatedUserDetailsService(getAuthenticationUserDetailsService(http));
/* 176 */     http.authenticationProvider((AuthenticationProvider)authenticationProvider)
/* 177 */       .setSharedObject(AuthenticationEntryPoint.class, new Http403ForbiddenEntryPoint());
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 182 */     X509AuthenticationFilter filter = getFilter((AuthenticationManager)http.getSharedObject(AuthenticationManager.class), http);
/* 183 */     http.addFilter((Filter)filter);
/*     */   }
/*     */   
/*     */   private X509AuthenticationFilter getFilter(AuthenticationManager authenticationManager, H http) {
/* 187 */     if (this.x509AuthenticationFilter == null) {
/* 188 */       this.x509AuthenticationFilter = new X509AuthenticationFilter();
/* 189 */       this.x509AuthenticationFilter.setAuthenticationManager(authenticationManager);
/* 190 */       if (this.x509PrincipalExtractor != null) {
/* 191 */         this.x509AuthenticationFilter.setPrincipalExtractor(this.x509PrincipalExtractor);
/*     */       }
/* 193 */       if (this.authenticationDetailsSource != null) {
/* 194 */         this.x509AuthenticationFilter.setAuthenticationDetailsSource(this.authenticationDetailsSource);
/*     */       }
/* 196 */       this.x509AuthenticationFilter.setSecurityContextRepository((SecurityContextRepository)new RequestAttributeSecurityContextRepository());
/* 197 */       this.x509AuthenticationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 198 */       this.x509AuthenticationFilter = (X509AuthenticationFilter)postProcess(this.x509AuthenticationFilter);
/*     */     } 
/*     */     
/* 201 */     return this.x509AuthenticationFilter;
/*     */   }
/*     */ 
/*     */   
/*     */   private AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> getAuthenticationUserDetailsService(H http) {
/* 206 */     if (this.authenticationUserDetailsService == null) {
/* 207 */       userDetailsService(getSharedOrBean(http, UserDetailsService.class));
/*     */     }
/* 209 */     return this.authenticationUserDetailsService;
/*     */   }
/*     */   
/*     */   private <C> C getSharedOrBean(H http, Class<C> type) {
/* 213 */     C shared = (C)http.getSharedObject(type);
/* 214 */     if (shared != null) {
/* 215 */       return shared;
/*     */     }
/* 217 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 218 */     if (context == null) {
/* 219 */       return null;
/*     */     }
/* 221 */     return (C)context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\X509Configurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */