/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HttpBasicConfigurer;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "httpBasic", "Lorg/springframework/security/config/annotation/web/configurers/HttpBasicConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nHttpBasicDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpBasicDsl.kt\norg/springframework/security/config/annotation/web/HttpBasicDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,64:1\n1#2:65\n*E\n"})
/*    */ final class HttpBasicDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HttpBasicConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(HttpBasicConfigurer httpBasic) {
/* 55 */     Intrinsics.checkNotNullParameter(httpBasic, "httpBasic"); if (HttpBasicDsl.this.getRealmName() != null) { String str1 = HttpBasicDsl.this.getRealmName(); HttpBasicDsl httpBasicDsl = HttpBasicDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 65 */       int $i$a$-also-HttpBasicDsl$get$1$1 = 0; httpBasic.realmName(httpBasicDsl.getRealmName()); } else { HttpBasicDsl.this.getRealmName(); }  if (HttpBasicDsl.this.getAuthenticationEntryPoint() != null) { AuthenticationEntryPoint authenticationEntryPoint1 = HttpBasicDsl.this.getAuthenticationEntryPoint(); HttpBasicDsl httpBasicDsl = HttpBasicDsl.this; AuthenticationEntryPoint it = authenticationEntryPoint1; int $i$a$-also-HttpBasicDsl$get$1$2 = 0; httpBasic.authenticationEntryPoint(httpBasicDsl.getAuthenticationEntryPoint()); } else { HttpBasicDsl.this.getAuthenticationEntryPoint(); }  if (HttpBasicDsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource1 = HttpBasicDsl.this.getAuthenticationDetailsSource(); HttpBasicDsl httpBasicDsl = HttpBasicDsl.this; AuthenticationDetailsSource<HttpServletRequest, ?> it = authenticationDetailsSource1; int $i$a$-also-HttpBasicDsl$get$1$3 = 0;
/*    */       httpBasic.authenticationDetailsSource(httpBasicDsl.getAuthenticationDetailsSource()); }
/*    */     else
/*    */     { HttpBasicDsl.this.getAuthenticationDetailsSource(); }
/*    */     
/*    */     if (HttpBasicDsl.access$getDisabled$p(HttpBasicDsl.this))
/*    */       httpBasic.disable(); 
/*    */   }
/*    */   
/*    */   HttpBasicDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpBasicDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */