/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000>\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\021\n\002\020\013\n\000\n\002\020\000\n\000\n\002\020\b\n\002\b\002\b\b\030\0002\0020\001B;\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005\022\n\b\002\020\006\032\004\030\0010\003\022\n\b\002\020\007\032\004\030\0010\b\022\f\020\t\032\b\022\004\022\0020\0130\n¢\006\002\020\fJ\t\020\026\032\0020\003HÆ\003J\t\020\027\032\0020\005HÆ\003J\013\020\030\032\004\030\0010\003HÆ\003J\013\020\031\032\004\030\0010\bHÆ\003J\017\020\032\032\b\022\004\022\0020\0130\nHÆ\003JE\020\033\032\0020\0002\b\b\002\020\002\032\0020\0032\b\b\002\020\004\032\0020\0052\n\b\002\020\006\032\004\030\0010\0032\n\b\002\020\007\032\004\030\0010\b2\016\b\002\020\t\032\b\022\004\022\0020\0130\nHÆ\001J\023\020\034\032\0020\0352\b\020\036\032\004\030\0010\037HÖ\003J\t\020 \032\0020!HÖ\001J\t\020\"\032\0020\003HÖ\001R\023\020\007\032\004\030\0010\b¢\006\b\n\000\032\004\b\r\020\016R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\017\020\020R\021\020\004\032\0020\005¢\006\b\n\000\032\004\b\021\020\022R\032\020\t\032\b\022\004\022\0020\0130\nX\004¢\006\b\n\000\032\004\b\023\020\024R\023\020\006\032\004\030\0010\003¢\006\b\n\000\032\004\b\025\020\020¨\006#"}, d2 = {"Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternAuthorizationManagerRule;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationManagerRule;", "pattern", "", "patternType", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "servletPath", "httpMethod", "Lorg/springframework/http/HttpMethod;", "rule", "Lorg/springframework/security/authorization/AuthorizationManager;", "Lorg/springframework/security/web/access/intercept/RequestAuthorizationContext;", "(Ljava/lang/String;Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;Ljava/lang/String;Lorg/springframework/http/HttpMethod;Lorg/springframework/security/authorization/AuthorizationManager;)V", "getHttpMethod", "()Lorg/springframework/http/HttpMethod;", "getPattern", "()Ljava/lang/String;", "getPatternType", "()Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "getRule", "()Lorg/springframework/security/authorization/AuthorizationManager;", "getServletPath", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "", "hashCode", "", "toString", "spring-security-config"})
/*    */ public final class PatternAuthorizationManagerRule
/*    */   extends AbstractRequestMatcherDsl.AuthorizationManagerRule
/*    */ {
/*    */   @NotNull
/*    */   private final String pattern;
/*    */   @NotNull
/*    */   private final AbstractRequestMatcherDsl.PatternType patternType;
/*    */   @Nullable
/*    */   private final String servletPath;
/*    */   @Nullable
/*    */   private final HttpMethod httpMethod;
/*    */   @NotNull
/*    */   private final AuthorizationManager<RequestAuthorizationContext> rule;
/*    */   
/*    */   @NotNull
/*    */   public final String getPattern() {
/* 50 */     return this.pattern; } @NotNull
/* 51 */   public final AbstractRequestMatcherDsl.PatternType getPatternType() { return this.patternType; } @Nullable
/* 52 */   public final String getServletPath() { return this.servletPath; } @Nullable
/* 53 */   public final HttpMethod getHttpMethod() { return this.httpMethod; }
/* 54 */   public PatternAuthorizationManagerRule(@NotNull String pattern, @NotNull AbstractRequestMatcherDsl.PatternType patternType, @Nullable String servletPath, @Nullable HttpMethod httpMethod, @NotNull AuthorizationManager<RequestAuthorizationContext> rule) { super(rule); this.pattern = pattern; this.patternType = patternType; this.servletPath = servletPath; this.httpMethod = httpMethod; this.rule = rule; } @NotNull public AuthorizationManager<RequestAuthorizationContext> getRule() { return this.rule; }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public final String component1() {
/*    */     return this.pattern;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final AbstractRequestMatcherDsl.PatternType component2() {
/*    */     return this.patternType;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final String component3() {
/*    */     return this.servletPath;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final HttpMethod component4() {
/*    */     return this.httpMethod;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final AuthorizationManager<RequestAuthorizationContext> component5() {
/*    */     return this.rule;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final PatternAuthorizationManagerRule copy(@NotNull String pattern, @NotNull AbstractRequestMatcherDsl.PatternType patternType, @Nullable String servletPath, @Nullable HttpMethod httpMethod, @NotNull AuthorizationManager<RequestAuthorizationContext> rule) {
/*    */     Intrinsics.checkNotNullParameter(pattern, "pattern");
/*    */     Intrinsics.checkNotNullParameter(patternType, "patternType");
/*    */     Intrinsics.checkNotNullParameter(rule, "rule");
/*    */     return new PatternAuthorizationManagerRule(pattern, patternType, servletPath, httpMethod, rule);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString() {
/*    */     return "PatternAuthorizationManagerRule(pattern=" + this.pattern + ", patternType=" + this.patternType + ", servletPath=" + this.servletPath + ", httpMethod=" + this.httpMethod + ", rule=" + this.rule + ")";
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     result = this.pattern.hashCode();
/*    */     result = result * 31 + this.patternType.hashCode();
/*    */     result = result * 31 + ((this.servletPath == null) ? 0 : this.servletPath.hashCode());
/*    */     result = result * 31 + ((this.httpMethod == null) ? 0 : this.httpMethod.hashCode());
/*    */     return result * 31 + this.rule.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/*    */     if (this == other)
/*    */       return true; 
/*    */     if (!(other instanceof PatternAuthorizationManagerRule))
/*    */       return false; 
/*    */     PatternAuthorizationManagerRule patternAuthorizationManagerRule = (PatternAuthorizationManagerRule)other;
/*    */     return !Intrinsics.areEqual(this.pattern, patternAuthorizationManagerRule.pattern) ? false : ((this.patternType != patternAuthorizationManagerRule.patternType) ? false : (!Intrinsics.areEqual(this.servletPath, patternAuthorizationManagerRule.servletPath) ? false : (!Intrinsics.areEqual(this.httpMethod, patternAuthorizationManagerRule.httpMethod) ? false : (!!Intrinsics.areEqual(this.rule, patternAuthorizationManagerRule.rule)))));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherDsl$PatternAuthorizationManagerRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */