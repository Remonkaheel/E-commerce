/*    */ package org.springframework.security.config.annotation.authentication.configuration;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.ProxyHints;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AuthenticationManagerBeanRegistrationAotProcessor
/*    */   implements BeanRegistrationAotProcessor
/*    */ {
/*    */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 43 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 44 */     Set<Class<?>> allInterfacesForClass = ClassUtils.getAllInterfacesForClassAsSet(beanClass);
/* 45 */     if (allInterfacesForClass.contains(AuthenticationManager.class)) {
/* 46 */       return new AuthenticationManagerBeanRegistrationAotContribution();
/*    */     }
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private static class AuthenticationManagerBeanRegistrationAotContribution
/*    */     implements BeanRegistrationAotContribution
/*    */   {
/*    */     public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 56 */       ProxyHints proxyHints = generationContext.getRuntimeHints().proxies();
/* 57 */       proxyHints.registerJdkProxy(AopProxyUtils.completeJdkProxyInterfaces(new Class[] { AuthenticationManager.class }));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configuration\AuthenticationManagerBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */