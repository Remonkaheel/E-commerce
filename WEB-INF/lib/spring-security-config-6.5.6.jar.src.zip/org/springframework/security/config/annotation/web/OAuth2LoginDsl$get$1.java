/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oauth2Login", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nOAuth2LoginDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OAuth2LoginDsl.kt\norg/springframework/security/config/annotation/web/OAuth2LoginDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,245:1\n1#2:246\n*E\n"})
/*     */ final class OAuth2LoginDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<OAuth2LoginConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(OAuth2LoginConfigurer oauth2Login) {
/* 224 */     Intrinsics.checkNotNullParameter(oauth2Login, "oauth2Login"); if (OAuth2LoginDsl.this.getClientRegistrationRepository() != null) { ClientRegistrationRepository clientRegistrationRepository1 = OAuth2LoginDsl.this.getClientRegistrationRepository(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; ClientRegistrationRepository clientRegistrationRepository2 = clientRegistrationRepository1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       int $i$a$-also-OAuth2LoginDsl$get$1$1 = 0; oauth2Login.clientRegistrationRepository(oAuth2LoginDsl1.getClientRegistrationRepository()); } else { OAuth2LoginDsl.this.getClientRegistrationRepository(); }  if (OAuth2LoginDsl.this.getAuthorizedClientRepository() != null) { OAuth2AuthorizedClientRepository oAuth2AuthorizedClientRepository1 = OAuth2LoginDsl.this.getAuthorizedClientRepository(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; OAuth2AuthorizedClientRepository oAuth2AuthorizedClientRepository2 = oAuth2AuthorizedClientRepository1; int $i$a$-also-OAuth2LoginDsl$get$1$2 = 0; oauth2Login.authorizedClientRepository(oAuth2LoginDsl1.getAuthorizedClientRepository()); } else { OAuth2LoginDsl.this.getAuthorizedClientRepository(); }  if (OAuth2LoginDsl.this.getAuthorizedClientService() != null) { OAuth2AuthorizedClientService oAuth2AuthorizedClientService1 = OAuth2LoginDsl.this.getAuthorizedClientService(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; OAuth2AuthorizedClientService oAuth2AuthorizedClientService2 = oAuth2AuthorizedClientService1; int $i$a$-also-OAuth2LoginDsl$get$1$3 = 0; oauth2Login.authorizedClientService(oAuth2LoginDsl1.getAuthorizedClientService()); } else { OAuth2LoginDsl.this.getAuthorizedClientService(); }  if (OAuth2LoginDsl.this.getLoginPage() != null) { String str1 = OAuth2LoginDsl.this.getLoginPage(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; String str2 = str1; int $i$a$-also-OAuth2LoginDsl$get$1$4 = 0; oauth2Login.loginPage(oAuth2LoginDsl1.getLoginPage()); } else { OAuth2LoginDsl.this.getLoginPage(); }  if (OAuth2LoginDsl.this.getFailureUrl() != null) { String str1 = OAuth2LoginDsl.this.getFailureUrl(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; String str2 = str1; int $i$a$-also-OAuth2LoginDsl$get$1$5 = 0; oauth2Login.failureUrl(oAuth2LoginDsl1.getFailureUrl()); } else { OAuth2LoginDsl.this.getFailureUrl(); }  if (OAuth2LoginDsl.this.getLoginProcessingUrl() != null) { String str1 = OAuth2LoginDsl.this.getLoginProcessingUrl(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; String str2 = str1; int $i$a$-also-OAuth2LoginDsl$get$1$6 = 0; oauth2Login.loginProcessingUrl(oAuth2LoginDsl1.getLoginProcessingUrl()); } else { OAuth2LoginDsl.this.getLoginProcessingUrl(); }  if (OAuth2LoginDsl.this.getPermitAll() != null) { Boolean bool = OAuth2LoginDsl.this.getPermitAll(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-OAuth2LoginDsl$get$1$7 = 0; Intrinsics.checkNotNull(oAuth2LoginDsl1.getPermitAll()); oauth2Login.permitAll(oAuth2LoginDsl1.getPermitAll().booleanValue()); } else { OAuth2LoginDsl.this.getPermitAll(); }  Pair pair1 = OAuth2LoginDsl.access$getDefaultSuccessUrlOption$p(OAuth2LoginDsl.this); OAuth2LoginDsl oAuth2LoginDsl = OAuth2LoginDsl.this; Pair it = pair1; int $i$a$-also-OAuth2LoginDsl$get$1$8 = 0; Intrinsics.checkNotNull(OAuth2LoginDsl.access$getDefaultSuccessUrlOption$p(oAuth2LoginDsl)); Intrinsics.checkNotNull(OAuth2LoginDsl.access$getDefaultSuccessUrlOption$p(oAuth2LoginDsl)); oauth2Login.defaultSuccessUrl((String)OAuth2LoginDsl.access$getDefaultSuccessUrlOption$p(oAuth2LoginDsl).getFirst(), ((Boolean)OAuth2LoginDsl.access$getDefaultSuccessUrlOption$p(oAuth2LoginDsl).getSecond()).booleanValue()); OAuth2LoginDsl.access$getDefaultSuccessUrlOption$p(OAuth2LoginDsl.this); if (OAuth2LoginDsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = OAuth2LoginDsl.this.getAuthenticationSuccessHandler(); oAuth2LoginDsl = OAuth2LoginDsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-OAuth2LoginDsl$get$1$9 = 0; oauth2Login.successHandler(oAuth2LoginDsl.getAuthenticationSuccessHandler()); } else { OAuth2LoginDsl.this.getAuthenticationSuccessHandler(); }  if (OAuth2LoginDsl.this.getAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = OAuth2LoginDsl.this.getAuthenticationFailureHandler(); oAuth2LoginDsl = OAuth2LoginDsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-OAuth2LoginDsl$get$1$10 = 0; oauth2Login.failureHandler(oAuth2LoginDsl.getAuthenticationFailureHandler()); } else { OAuth2LoginDsl.this.getAuthenticationFailureHandler(); }  if (OAuth2LoginDsl.access$getAuthorizationEndpoint$p(OAuth2LoginDsl.this) != null) { Function1 function11 = OAuth2LoginDsl.access$getAuthorizationEndpoint$p(OAuth2LoginDsl.this); oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$11 = 0; OAuth2LoginDsl.access$getAuthorizationEndpoint$p(oAuth2LoginDsl); oauth2Login.authorizationEndpoint((OAuth2LoginDsl.access$getAuthorizationEndpoint$p(oAuth2LoginDsl) != null) ? OAuth2LoginDsl.access$getAuthorizationEndpoint$p(oAuth2LoginDsl)::invoke$lambda$11$lambda$10 : null); } else { OAuth2LoginDsl.access$getAuthorizationEndpoint$p(OAuth2LoginDsl.this); }  if (OAuth2LoginDsl.access$getTokenEndpoint$p(OAuth2LoginDsl.this) != null) { Function1 function11 = OAuth2LoginDsl.access$getTokenEndpoint$p(OAuth2LoginDsl.this); oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$12 = 0; OAuth2LoginDsl.access$getTokenEndpoint$p(oAuth2LoginDsl); oauth2Login.tokenEndpoint((OAuth2LoginDsl.access$getTokenEndpoint$p(oAuth2LoginDsl) != null) ? OAuth2LoginDsl.access$getTokenEndpoint$p(oAuth2LoginDsl)::invoke$lambda$13$lambda$12 : null); } else { OAuth2LoginDsl.access$getTokenEndpoint$p(OAuth2LoginDsl.this); }  if (OAuth2LoginDsl.access$getRedirectionEndpoint$p(OAuth2LoginDsl.this) != null) { Function1 function11 = OAuth2LoginDsl.access$getRedirectionEndpoint$p(OAuth2LoginDsl.this); oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$13 = 0; OAuth2LoginDsl.access$getRedirectionEndpoint$p(oAuth2LoginDsl); oauth2Login.redirectionEndpoint((OAuth2LoginDsl.access$getRedirectionEndpoint$p(oAuth2LoginDsl) != null) ? OAuth2LoginDsl.access$getRedirectionEndpoint$p(oAuth2LoginDsl)::invoke$lambda$15$lambda$14 : null); } else { OAuth2LoginDsl.access$getRedirectionEndpoint$p(OAuth2LoginDsl.this); }  if (OAuth2LoginDsl.access$getUserInfoEndpoint$p(OAuth2LoginDsl.this) != null) { Function1 function11 = OAuth2LoginDsl.access$getUserInfoEndpoint$p(OAuth2LoginDsl.this); oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$14 = 0; OAuth2LoginDsl.access$getUserInfoEndpoint$p(oAuth2LoginDsl); oauth2Login.userInfoEndpoint((OAuth2LoginDsl.access$getUserInfoEndpoint$p(oAuth2LoginDsl) != null) ? OAuth2LoginDsl.access$getUserInfoEndpoint$p(oAuth2LoginDsl)::invoke$lambda$17$lambda$16 : null); } else { OAuth2LoginDsl.access$getUserInfoEndpoint$p(OAuth2LoginDsl.this); }  if (OAuth2LoginDsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource1 = OAuth2LoginDsl.this.getAuthenticationDetailsSource(); oAuth2LoginDsl = OAuth2LoginDsl.this; AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource2 = authenticationDetailsSource1; int $i$a$-also-OAuth2LoginDsl$get$1$15 = 0; oauth2Login.authenticationDetailsSource(oAuth2LoginDsl.getAuthenticationDetailsSource()); } else { OAuth2LoginDsl.this.getAuthenticationDetailsSource(); }  if (OAuth2LoginDsl.this.getOidcSessionRegistry() != null) { OidcSessionRegistry oidcSessionRegistry1 = OAuth2LoginDsl.this.getOidcSessionRegistry(); oAuth2LoginDsl = OAuth2LoginDsl.this; OidcSessionRegistry oidcSessionRegistry2 = oidcSessionRegistry1; int $i$a$-also-OAuth2LoginDsl$get$1$16 = 0;
/*     */       oauth2Login.oidcSessionRegistry(oAuth2LoginDsl.getOidcSessionRegistry()); }
/*     */     else
/*     */     { OAuth2LoginDsl.this.getOidcSessionRegistry(); }
/*     */   
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$11$lambda$10(Function1 $tmp0, OAuth2LoginConfigurer.AuthorizationEndpointConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$13$lambda$12(Function1 $tmp0, OAuth2LoginConfigurer.TokenEndpointConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$15$lambda$14(Function1 $tmp0, OAuth2LoginConfigurer.RedirectionEndpointConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$17$lambda$16(Function1 $tmp0, OAuth2LoginConfigurer.UserInfoEndpointConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   OAuth2LoginDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OAuth2LoginDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */