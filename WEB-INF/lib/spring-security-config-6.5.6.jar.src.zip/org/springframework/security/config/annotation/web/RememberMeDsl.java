/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.RememberMeConfigurer;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*    */ import org.springframework.security.web.authentication.RememberMeServices;
/*    */ import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000X\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\016\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\b\n\002\b\t\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020;\032\024\022\n\022\b\022\004\022\0020>0=\022\004\022\0020?0<H\000¢\006\002\b@R\036\020\003\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\034\020\020\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R\034\020\026\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\027\020\023\"\004\b\030\020\025R\034\020\031\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\032\020\023\"\004\b\033\020\025R\034\020\034\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\035\020\023\"\004\b\036\020\025R\034\020\037\032\004\030\0010 X\016¢\006\016\n\000\032\004\b!\020\"\"\004\b#\020$R\034\020%\032\004\030\0010&X\016¢\006\016\n\000\032\004\b'\020(\"\004\b)\020*R\036\020+\032\004\030\0010,X\016¢\006\020\n\002\0201\032\004\b-\020.\"\004\b/\0200R\036\0202\032\004\030\0010\004X\016¢\006\020\n\002\020\t\032\004\b3\020\006\"\004\b4\020\bR\034\0205\032\004\030\00106X\016¢\006\016\n\000\032\004\b7\0208\"\004\b9\020:¨\006A"}, d2 = {"Lorg/springframework/security/config/annotation/web/RememberMeDsl;", "", "()V", "alwaysRemember", "", "getAlwaysRemember", "()Ljava/lang/Boolean;", "setAlwaysRemember", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "authenticationSuccessHandler", "Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "getAuthenticationSuccessHandler", "()Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "setAuthenticationSuccessHandler", "(Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;)V", "key", "", "getKey", "()Ljava/lang/String;", "setKey", "(Ljava/lang/String;)V", "rememberMeCookieDomain", "getRememberMeCookieDomain", "setRememberMeCookieDomain", "rememberMeCookieName", "getRememberMeCookieName", "setRememberMeCookieName", "rememberMeParameter", "getRememberMeParameter", "setRememberMeParameter", "rememberMeServices", "Lorg/springframework/security/web/authentication/RememberMeServices;", "getRememberMeServices", "()Lorg/springframework/security/web/authentication/RememberMeServices;", "setRememberMeServices", "(Lorg/springframework/security/web/authentication/RememberMeServices;)V", "tokenRepository", "Lorg/springframework/security/web/authentication/rememberme/PersistentTokenRepository;", "getTokenRepository", "()Lorg/springframework/security/web/authentication/rememberme/PersistentTokenRepository;", "setTokenRepository", "(Lorg/springframework/security/web/authentication/rememberme/PersistentTokenRepository;)V", "tokenValiditySeconds", "", "getTokenValiditySeconds", "()Ljava/lang/Integer;", "setTokenValiditySeconds", "(Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "useSecureCookie", "getUseSecureCookie", "setUseSecureCookie", "userDetailsService", "Lorg/springframework/security/core/userdetails/UserDetailsService;", "getUserDetailsService", "()Lorg/springframework/security/core/userdetails/UserDetailsService;", "setUserDetailsService", "(Lorg/springframework/security/core/userdetails/UserDetailsService;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/RememberMeConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class RememberMeDsl
/*    */ {
/*    */   @Nullable
/*    */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*    */   @Nullable
/*    */   private String key;
/*    */   @Nullable
/*    */   private RememberMeServices rememberMeServices;
/*    */   @Nullable
/*    */   private String rememberMeParameter;
/*    */   @Nullable
/*    */   private String rememberMeCookieName;
/*    */   @Nullable
/*    */   private String rememberMeCookieDomain;
/*    */   @Nullable
/*    */   private PersistentTokenRepository tokenRepository;
/*    */   @Nullable
/*    */   private UserDetailsService userDetailsService;
/*    */   @Nullable
/*    */   private Integer tokenValiditySeconds;
/*    */   @Nullable
/*    */   private Boolean useSecureCookie;
/*    */   @Nullable
/*    */   private Boolean alwaysRemember;
/*    */   
/*    */   @Nullable
/*    */   public final AuthenticationSuccessHandler getAuthenticationSuccessHandler() {
/* 52 */     return this.authenticationSuccessHandler; } public final void setAuthenticationSuccessHandler(@Nullable AuthenticationSuccessHandler <set-?>) { this.authenticationSuccessHandler = <set-?>; } @Nullable
/* 53 */   public final String getKey() { return this.key; } public final void setKey(@Nullable String <set-?>) { this.key = <set-?>; } @Nullable
/* 54 */   public final RememberMeServices getRememberMeServices() { return this.rememberMeServices; } public final void setRememberMeServices(@Nullable RememberMeServices <set-?>) { this.rememberMeServices = <set-?>; } @Nullable
/* 55 */   public final String getRememberMeParameter() { return this.rememberMeParameter; } public final void setRememberMeParameter(@Nullable String <set-?>) { this.rememberMeParameter = <set-?>; } @Nullable
/* 56 */   public final String getRememberMeCookieName() { return this.rememberMeCookieName; } public final void setRememberMeCookieName(@Nullable String <set-?>) { this.rememberMeCookieName = <set-?>; } @Nullable
/* 57 */   public final String getRememberMeCookieDomain() { return this.rememberMeCookieDomain; } public final void setRememberMeCookieDomain(@Nullable String <set-?>) { this.rememberMeCookieDomain = <set-?>; } @Nullable
/* 58 */   public final PersistentTokenRepository getTokenRepository() { return this.tokenRepository; } public final void setTokenRepository(@Nullable PersistentTokenRepository <set-?>) { this.tokenRepository = <set-?>; } @Nullable
/* 59 */   public final UserDetailsService getUserDetailsService() { return this.userDetailsService; } public final void setUserDetailsService(@Nullable UserDetailsService <set-?>) { this.userDetailsService = <set-?>; } @Nullable
/* 60 */   public final Integer getTokenValiditySeconds() { return this.tokenValiditySeconds; } public final void setTokenValiditySeconds(@Nullable Integer <set-?>) { this.tokenValiditySeconds = <set-?>; } @Nullable
/* 61 */   public final Boolean getUseSecureCookie() { return this.useSecureCookie; } public final void setUseSecureCookie(@Nullable Boolean <set-?>) { this.useSecureCookie = <set-?>; } @Nullable
/* 62 */   public final Boolean getAlwaysRemember() { return this.alwaysRemember; } public final void setAlwaysRemember(@Nullable Boolean <set-?>) { this.alwaysRemember = <set-?>; }
/*    */   
/*    */   @NotNull
/* 65 */   public final Function1<RememberMeConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new RememberMeDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "rememberMe", "Lorg/springframework/security/config/annotation/web/configurers/RememberMeConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nRememberMeDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RememberMeDsl.kt\norg/springframework/security/config/annotation/web/RememberMeDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,80:1\n1#2:81\n*E\n"})
/* 66 */   static final class RememberMeDsl$get$1 extends Lambda implements Function1<RememberMeConfigurer<HttpSecurity>, Unit> { public final void invoke(RememberMeConfigurer rememberMe) { Intrinsics.checkNotNullParameter(rememberMe, "rememberMe"); if (RememberMeDsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = RememberMeDsl.this.getAuthenticationSuccessHandler(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; AuthenticationSuccessHandler it = authenticationSuccessHandler1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 81 */         int $i$a$-also-RememberMeDsl$get$1$1 = 0; rememberMe.authenticationSuccessHandler(rememberMeDsl.getAuthenticationSuccessHandler()); } else { RememberMeDsl.this.getAuthenticationSuccessHandler(); }  if (RememberMeDsl.this.getKey() != null) { String str1 = RememberMeDsl.this.getKey(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$2 = 0; rememberMe.key(rememberMeDsl.getKey()); } else { RememberMeDsl.this.getKey(); }  if (RememberMeDsl.this.getRememberMeServices() != null) { RememberMeServices rememberMeServices1 = RememberMeDsl.this.getRememberMeServices(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; RememberMeServices it = rememberMeServices1; int $i$a$-also-RememberMeDsl$get$1$3 = 0; rememberMe.rememberMeServices(rememberMeDsl.getRememberMeServices()); } else { RememberMeDsl.this.getRememberMeServices(); }  if (RememberMeDsl.this.getRememberMeParameter() != null) { String str1 = RememberMeDsl.this.getRememberMeParameter(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$4 = 0; rememberMe.rememberMeParameter(rememberMeDsl.getRememberMeParameter()); } else { RememberMeDsl.this.getRememberMeParameter(); }  if (RememberMeDsl.this.getRememberMeCookieName() != null) { String str1 = RememberMeDsl.this.getRememberMeCookieName(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$5 = 0; rememberMe.rememberMeCookieName(rememberMeDsl.getRememberMeCookieName()); } else { RememberMeDsl.this.getRememberMeCookieName(); }  if (RememberMeDsl.this.getRememberMeCookieDomain() != null) { String str1 = RememberMeDsl.this.getRememberMeCookieDomain(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$6 = 0; rememberMe.rememberMeCookieDomain(rememberMeDsl.getRememberMeCookieDomain()); } else { RememberMeDsl.this.getRememberMeCookieDomain(); }  if (RememberMeDsl.this.getTokenRepository() != null) { PersistentTokenRepository persistentTokenRepository1 = RememberMeDsl.this.getTokenRepository(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; PersistentTokenRepository it = persistentTokenRepository1; int $i$a$-also-RememberMeDsl$get$1$7 = 0; rememberMe.tokenRepository(rememberMeDsl.getTokenRepository()); } else { RememberMeDsl.this.getTokenRepository(); }  if (RememberMeDsl.this.getUserDetailsService() != null) { UserDetailsService userDetailsService1 = RememberMeDsl.this.getUserDetailsService(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; UserDetailsService it = userDetailsService1; int $i$a$-also-RememberMeDsl$get$1$8 = 0; rememberMe.userDetailsService(rememberMeDsl.getUserDetailsService()); } else { RememberMeDsl.this.getUserDetailsService(); }  if (RememberMeDsl.this.getTokenValiditySeconds() != null) { Integer integer = RememberMeDsl.this.getTokenValiditySeconds(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; int it = integer.intValue(); int $i$a$-also-RememberMeDsl$get$1$9 = 0; Intrinsics.checkNotNull(rememberMeDsl.getTokenValiditySeconds()); rememberMe.tokenValiditySeconds(rememberMeDsl.getTokenValiditySeconds().intValue()); } else { RememberMeDsl.this.getTokenValiditySeconds(); }  if (RememberMeDsl.this.getUseSecureCookie() != null) { Boolean bool = RememberMeDsl.this.getUseSecureCookie(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-RememberMeDsl$get$1$10 = 0; Intrinsics.checkNotNull(rememberMeDsl.getUseSecureCookie()); rememberMe.useSecureCookie(rememberMeDsl.getUseSecureCookie().booleanValue()); } else { RememberMeDsl.this.getUseSecureCookie(); }  if (RememberMeDsl.this.getAlwaysRemember() != null) { Boolean bool = RememberMeDsl.this.getAlwaysRemember(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-RememberMeDsl$get$1$11 = 0;
/*    */         Intrinsics.checkNotNull(rememberMeDsl.getAlwaysRemember());
/*    */         rememberMe.alwaysRemember(rememberMeDsl.getAlwaysRemember().booleanValue()); }
/*    */       else
/*    */       { RememberMeDsl.this.getAlwaysRemember(); }
/*    */        }
/*    */ 
/*    */     
/*    */     RememberMeDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RememberMeDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */