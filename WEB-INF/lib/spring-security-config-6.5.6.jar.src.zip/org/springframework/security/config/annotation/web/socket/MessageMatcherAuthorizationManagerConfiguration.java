/*    */ package org.springframework.security.config.annotation.web.socket;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.messaging.simp.annotation.support.SimpAnnotationMethodMessageHandler;
/*    */ import org.springframework.security.messaging.access.intercept.MessageMatcherDelegatingAuthorizationManager;
/*    */ import org.springframework.security.messaging.util.matcher.MessageMatcherFactory;
/*    */ import org.springframework.util.AntPathMatcher;
/*    */ import org.springframework.util.PathMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MessageMatcherAuthorizationManagerConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Scope("prototype")
/*    */   MessageMatcherDelegatingAuthorizationManager.Builder messageAuthorizationManagerBuilder(ApplicationContext context) {
/* 33 */     MessageMatcherFactory.setApplicationContext(context);
/* 34 */     if (MessageMatcherFactory.usesPathPatterns()) {
/* 35 */       return MessageMatcherDelegatingAuthorizationManager.builder();
/*    */     }
/* 37 */     return MessageMatcherDelegatingAuthorizationManager.builder()
/* 38 */       .simpDestPathMatcher(() -> ((context.getBeanNamesForType(SimpAnnotationMethodMessageHandler.class)).length > 0) ? ((SimpAnnotationMethodMessageHandler)context.getBean(SimpAnnotationMethodMessageHandler.class)).getPathMatcher() : (PathMatcher)new AntPathMatcher());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\socket\MessageMatcherAuthorizationManagerConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */