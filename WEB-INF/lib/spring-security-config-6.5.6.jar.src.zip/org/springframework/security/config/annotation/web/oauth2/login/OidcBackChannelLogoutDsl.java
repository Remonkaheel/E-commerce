/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OidcLogoutConfigurer;
/*    */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2LoginSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\002\b\f\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\022\032\030\022\016\022\f0\024R\b\022\004\022\0020\0260\025\022\004\022\0020\0270\023H\000¢\006\002\b\030R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000R(\020\b\032\004\030\0010\0042\b\020\007\032\004\030\0010\0048F@FX\016¢\006\f\032\004\b\t\020\n\"\004\b\013\020\fR(\020\r\032\004\030\0010\0062\b\020\007\032\004\030\0010\0068F@FX\016¢\006\f\032\004\b\016\020\017\"\004\b\020\020\021¨\006\031"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/login/OidcBackChannelLogoutDsl;", "", "()V", "_logoutHandler", "Lorg/springframework/security/web/authentication/logout/LogoutHandler;", "_logoutUri", "", "value", "logoutHandler", "getLogoutHandler", "()Lorg/springframework/security/web/authentication/logout/LogoutHandler;", "setLogoutHandler", "(Lorg/springframework/security/web/authentication/logout/LogoutHandler;)V", "logoutUri", "getLogoutUri", "()Ljava/lang/String;", "setLogoutUri", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer$BackChannelLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class OidcBackChannelLogoutDsl
/*    */ {
/*    */   @Nullable
/*    */   private String _logoutUri;
/*    */   @Nullable
/*    */   private LogoutHandler _logoutHandler;
/*    */   
/*    */   @Nullable
/*    */   public final LogoutHandler getLogoutHandler() {
/* 36 */     return this._logoutHandler;
/*    */   } public final void setLogoutHandler(@Nullable LogoutHandler value) {
/* 38 */     this._logoutHandler = value;
/* 39 */     this._logoutUri = null;
/*    */   } @Nullable
/*    */   public final String getLogoutUri() {
/* 42 */     return this._logoutUri;
/*    */   } public final void setLogoutUri(@Nullable String value) {
/* 44 */     this._logoutUri = value;
/* 45 */     this._logoutHandler = null;
/*    */   }
/*    */   
/*    */   @NotNull
/* 49 */   public final Function1<OidcLogoutConfigurer<HttpSecurity>.BackChannelLogoutConfigurer, Unit> get$spring_security_config() { return new OidcBackChannelLogoutDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "backChannel", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer$BackChannelLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOidcBackChannelLogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OidcBackChannelLogoutDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/OidcBackChannelLogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1#2:56\n*E\n"})
/* 50 */   static final class OidcBackChannelLogoutDsl$get$1 extends Lambda implements Function1<OidcLogoutConfigurer<HttpSecurity>.BackChannelLogoutConfigurer, Unit> { public final void invoke(OidcLogoutConfigurer.BackChannelLogoutConfigurer backChannel) { Intrinsics.checkNotNullParameter(backChannel, "backChannel"); if (OidcBackChannelLogoutDsl.this.getLogoutHandler() != null) { LogoutHandler logoutHandler1 = OidcBackChannelLogoutDsl.this.getLogoutHandler(); OidcBackChannelLogoutDsl oidcBackChannelLogoutDsl = OidcBackChannelLogoutDsl.this; LogoutHandler it = logoutHandler1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 56 */         int $i$a$-also-OidcBackChannelLogoutDsl$get$1$1 = 0; backChannel.logoutHandler(oidcBackChannelLogoutDsl.getLogoutHandler()); } else { OidcBackChannelLogoutDsl.this.getLogoutHandler(); }  if (OidcBackChannelLogoutDsl.this.getLogoutUri() != null) { String str1 = OidcBackChannelLogoutDsl.this.getLogoutUri(); OidcBackChannelLogoutDsl oidcBackChannelLogoutDsl = OidcBackChannelLogoutDsl.this; String it = str1; int $i$a$-also-OidcBackChannelLogoutDsl$get$1$2 = 0;
/*    */         backChannel.logoutUri(oidcBackChannelLogoutDsl.getLogoutUri()); }
/*    */       else
/*    */       { OidcBackChannelLogoutDsl.this.getLogoutUri(); }
/*    */        }
/*    */ 
/*    */     
/*    */     OidcBackChannelLogoutDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\OidcBackChannelLogoutDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */