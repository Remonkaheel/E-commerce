/*     */ package org.springframework.security.config.annotation.authentication.configuration;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordChecker;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
/*     */ import org.springframework.security.core.userdetails.UserDetailsPasswordService;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InitializeUserDetailsManagerConfigurer
/*     */   extends GlobalAuthenticationConfigurerAdapter
/*     */ {
/*  65 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(AuthenticationManagerBuilder auth) throws Exception {
/*  70 */     String[] beanNames = InitializeUserDetailsBeanManagerConfigurer.this.context.getBeanNamesForType(UserDetailsService.class);
/*  71 */     if (auth.isConfigured()) {
/*  72 */       if (beanNames.length > 0) {
/*  73 */         this.logger.warn("Global AuthenticationManager configured with an AuthenticationProvider bean. UserDetailsService beans will not be used by Spring Security for automatically configuring username/password login. Consider removing the AuthenticationProvider bean. Alternatively, consider using the UserDetailsService in a manually instantiated DaoAuthenticationProvider. If the current configuration is intentional, to turn off this warning, increase the logging level of 'org.springframework.security.config.annotation.authentication.configuration.InitializeUserDetailsBeanManagerConfigurer' to ERROR");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  83 */     if (beanNames.length == 0) {
/*     */       return;
/*     */     }
/*  86 */     if (beanNames.length > 1) {
/*  87 */       this.logger.warn(LogMessage.format("Found %s UserDetailsService beans, with names %s. Global Authentication Manager will not use a UserDetailsService for username/password login. Consider publishing a single UserDetailsService bean.", 
/*     */             
/*  89 */             Integer.valueOf(beanNames.length), 
/*  90 */             Arrays.toString((Object[])beanNames)));
/*     */       
/*     */       return;
/*     */     } 
/*  94 */     UserDetailsService userDetailsService = (UserDetailsService)InitializeUserDetailsBeanManagerConfigurer.this.context.getBean(beanNames[0], UserDetailsService.class);
/*  95 */     PasswordEncoder passwordEncoder = getBeanOrNull(PasswordEncoder.class);
/*  96 */     UserDetailsPasswordService passwordManager = getBeanOrNull(UserDetailsPasswordService.class);
/*  97 */     CompromisedPasswordChecker passwordChecker = getBeanOrNull(CompromisedPasswordChecker.class);
/*  98 */     DaoAuthenticationProvider provider = new DaoAuthenticationProvider(userDetailsService);
/*  99 */     if (passwordEncoder != null) {
/* 100 */       provider.setPasswordEncoder(passwordEncoder);
/*     */     }
/* 102 */     if (passwordManager != null) {
/* 103 */       provider.setUserDetailsPasswordService(passwordManager);
/*     */     }
/* 105 */     if (passwordChecker != null) {
/* 106 */       provider.setCompromisedPasswordChecker(passwordChecker);
/*     */     }
/* 108 */     provider.afterPropertiesSet();
/* 109 */     auth.authenticationProvider((AuthenticationProvider)provider);
/* 110 */     this.logger.info(LogMessage.format("Global AuthenticationManager configured with UserDetailsService bean with name %s", beanNames[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T getBeanOrNull(Class<T> type) {
/* 119 */     return (T)InitializeUserDetailsBeanManagerConfigurer.this.context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configuration\InitializeUserDetailsBeanManagerConfigurer$InitializeUserDetailsManagerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */