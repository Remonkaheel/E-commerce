/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "contentSecurityPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ContentSecurityPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ final class ContentSecurityPolicyDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HeadersConfigurer<HttpSecurity>.ContentSecurityPolicyConfig, Unit>
/*    */ {
/*    */   public final void invoke(HeadersConfigurer.ContentSecurityPolicyConfig contentSecurityPolicy) {
/* 38 */     Intrinsics.checkNotNullParameter(contentSecurityPolicy, "contentSecurityPolicy"); String str1 = ContentSecurityPolicyDsl.this.getPolicyDirectives(); ContentSecurityPolicyDsl contentSecurityPolicyDsl = ContentSecurityPolicyDsl.this; String str2 = str1; int $i$a$-also-ContentSecurityPolicyDsl$get$1$1 = 0;
/* 39 */     contentSecurityPolicy.policyDirectives(contentSecurityPolicyDsl.getPolicyDirectives());
/*    */     ContentSecurityPolicyDsl.this.getPolicyDirectives();
/* 41 */     Boolean bool = ContentSecurityPolicyDsl.this.getReportOnly(); contentSecurityPolicyDsl = ContentSecurityPolicyDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-ContentSecurityPolicyDsl$get$1$2 = 0;
/* 42 */     Intrinsics.checkNotNull(contentSecurityPolicyDsl.getReportOnly()); if (contentSecurityPolicyDsl.getReportOnly().booleanValue())
/* 43 */       contentSecurityPolicy.reportOnly(); 
/*    */     ContentSecurityPolicyDsl.this.getReportOnly();
/*    */   }
/*    */   
/*    */   ContentSecurityPolicyDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\ContentSecurityPolicyDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */