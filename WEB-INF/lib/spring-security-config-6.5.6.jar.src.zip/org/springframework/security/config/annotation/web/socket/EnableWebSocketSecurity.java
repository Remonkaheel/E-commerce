package org.springframework.security.config.annotation.web.socket;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Import;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
@Import({WebSocketMessageBrokerSecurityConfiguration.class, WebSocketObservationImportSelector.class})
public @interface EnableWebSocketSecurity {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\socket\EnableWebSocketSecurity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */