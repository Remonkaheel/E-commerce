/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodSecurityAspectJAutoProxyRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 49 */     registerBeanDefinition("preFilterAuthorizationMethodInterceptor", "org.springframework.security.authorization.method.aspectj.PreFilterAspect", "preFilterAspect$0", registry);
/*    */ 
/*    */     
/* 52 */     registerBeanDefinition("postFilterAuthorizationMethodInterceptor", "org.springframework.security.authorization.method.aspectj.PostFilterAspect", "postFilterAspect$0", registry);
/*    */ 
/*    */     
/* 55 */     registerBeanDefinition("preAuthorizeAuthorizationMethodInterceptor", "org.springframework.security.authorization.method.aspectj.PreAuthorizeAspect", "preAuthorizeAspect$0", registry);
/*    */ 
/*    */     
/* 58 */     registerBeanDefinition("postAuthorizeAuthorizationMethodInterceptor", "org.springframework.security.authorization.method.aspectj.PostAuthorizeAspect", "postAuthorizeAspect$0", registry);
/*    */ 
/*    */     
/* 61 */     registerBeanDefinition("securedAuthorizationMethodInterceptor", "org.springframework.security.authorization.method.aspectj.SecuredAspect", "securedAspect$0", registry);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void registerBeanDefinition(String beanName, String aspectClassName, String aspectBeanName, BeanDefinitionRegistry registry) {
/* 67 */     if (!registry.containsBeanDefinition(beanName)) {
/*    */       return;
/*    */     }
/* 70 */     BeanDefinition interceptor = registry.getBeanDefinition(beanName);
/* 71 */     BeanDefinitionBuilder aspect = BeanDefinitionBuilder.rootBeanDefinition(aspectClassName);
/* 72 */     aspect.setFactoryMethod("aspectOf");
/* 73 */     aspect.setRole(2);
/* 74 */     aspect.addPropertyValue("securityInterceptor", interceptor);
/* 75 */     registry.registerBeanDefinition(aspectBeanName, (BeanDefinition)aspect.getBeanDefinition());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\MethodSecurityAspectJAutoProxyRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */