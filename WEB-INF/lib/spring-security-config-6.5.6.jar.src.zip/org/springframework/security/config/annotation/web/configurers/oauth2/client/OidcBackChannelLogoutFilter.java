/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.oauth2.core.http.converter.OAuth2ErrorHttpMessageConverter;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OidcBackChannelLogoutFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*  53 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final AuthenticationConverter authenticationConverter;
/*     */   
/*     */   private final AuthenticationManager authenticationManager;
/*     */   
/*  59 */   private final OAuth2ErrorHttpMessageConverter errorHttpMessageConverter = new OAuth2ErrorHttpMessageConverter();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final LogoutHandler logoutHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OidcBackChannelLogoutFilter(AuthenticationConverter authenticationConverter, AuthenticationManager authenticationManager, LogoutHandler logoutHandler) {
/*  72 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/*  73 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/*  74 */     Assert.notNull(logoutHandler, "logoutHandler cannot be null");
/*  75 */     this.authenticationConverter = authenticationConverter;
/*  76 */     this.authenticationManager = authenticationManager;
/*  77 */     this.logoutHandler = logoutHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
/*     */     Authentication token, authentication;
/*     */     try {
/*  88 */       token = this.authenticationConverter.convert(request);
/*     */     }
/*  90 */     catch (AuthenticationServiceException ex) {
/*  91 */       this.logger.debug("Failed to process OIDC Back-Channel Logout", (Throwable)ex);
/*  92 */       throw ex;
/*     */     }
/*  94 */     catch (AuthenticationException ex) {
/*  95 */       handleAuthenticationFailure(response, (Exception)ex);
/*     */       return;
/*     */     } 
/*  98 */     if (token == null) {
/*  99 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 104 */       authentication = this.authenticationManager.authenticate(token);
/*     */     }
/* 106 */     catch (AuthenticationServiceException ex) {
/* 107 */       this.logger.debug("Failed to process OIDC Back-Channel Logout", (Throwable)ex);
/* 108 */       throw ex;
/*     */     }
/* 110 */     catch (AuthenticationException ex) {
/* 111 */       handleAuthenticationFailure(response, (Exception)ex);
/*     */       return;
/*     */     } 
/* 114 */     this.logoutHandler.logout(request, response, authentication);
/*     */   }
/*     */   
/*     */   private void handleAuthenticationFailure(HttpServletResponse response, Exception ex) throws IOException {
/* 118 */     this.logger.debug("Failed to process OIDC Back-Channel Logout", ex);
/* 119 */     response.setStatus(400);
/* 120 */     this.errorHttpMessageConverter.write(oauth2Error(ex), null, (HttpOutputMessage)new ServletServerHttpResponse(response));
/*     */   }
/*     */   
/*     */   private OAuth2Error oauth2Error(Exception ex) {
/* 124 */     if (ex instanceof OAuth2AuthenticationException) { OAuth2AuthenticationException oauth2 = (OAuth2AuthenticationException)ex;
/* 125 */       return oauth2.getError(); }
/*     */     
/* 127 */     return new OAuth2Error("invalid_request", ex.getMessage(), "https://openid.net/specs/openid-connect-backchannel-1_0.html#Validation");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcBackChannelLogoutFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */