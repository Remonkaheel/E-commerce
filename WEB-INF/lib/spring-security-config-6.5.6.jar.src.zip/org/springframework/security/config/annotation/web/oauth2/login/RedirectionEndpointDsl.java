/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2LoginSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\t\032\030\022\016\022\f0\013R\b\022\004\022\0020\r0\f\022\004\022\0020\0160\nH\000¢\006\002\b\017R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\b¨\006\020"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/login/RedirectionEndpointDsl;", "", "()V", "baseUri", "", "getBaseUri", "()Ljava/lang/String;", "setBaseUri", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$RedirectionEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class RedirectionEndpointDsl
/*    */ {
/*    */   @Nullable
/*    */   private String baseUri;
/*    */   
/*    */   @Nullable
/*    */   public final String getBaseUri() {
/* 32 */     return this.baseUri; } public final void setBaseUri(@Nullable String <set-?>) { this.baseUri = <set-?>; }
/*    */   
/*    */   @NotNull
/* 35 */   public final Function1<OAuth2LoginConfigurer<HttpSecurity>.RedirectionEndpointConfig, Unit> get$spring_security_config() { return new RedirectionEndpointDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "redirectionEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$RedirectionEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nRedirectionEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RedirectionEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/RedirectionEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,40:1\n1#2:41\n*E\n"})
/* 36 */   static final class RedirectionEndpointDsl$get$1 extends Lambda implements Function1<OAuth2LoginConfigurer<HttpSecurity>.RedirectionEndpointConfig, Unit> { public final void invoke(OAuth2LoginConfigurer.RedirectionEndpointConfig redirectionEndpoint) { Intrinsics.checkNotNullParameter(redirectionEndpoint, "redirectionEndpoint"); if (RedirectionEndpointDsl.this.getBaseUri() != null) { String str1 = RedirectionEndpointDsl.this.getBaseUri(); RedirectionEndpointDsl redirectionEndpointDsl = RedirectionEndpointDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 41 */         int $i$a$-also-RedirectionEndpointDsl$get$1$1 = 0;
/*    */         redirectionEndpoint.baseUri(redirectionEndpointDsl.getBaseUri()); }
/*    */       else
/*    */       { RedirectionEndpointDsl.this.getBaseUri(); }
/*    */        }
/*    */ 
/*    */     
/*    */     RedirectionEndpointDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\RedirectionEndpointDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */