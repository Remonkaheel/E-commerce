/*    */ package org.springframework.security.config.annotation.web.configurers;
/*    */ 
/*    */ import jakarta.servlet.Filter;
/*    */ import org.springframework.security.config.annotation.SecurityBuilder;
/*    */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*    */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*    */ import org.springframework.security.web.RequestMatcherRedirectFilter;
/*    */ import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PasswordManagementConfigurer<B extends HttpSecurityBuilder<B>>
/*    */   extends AbstractHttpConfigurer<PasswordManagementConfigurer<B>, B>
/*    */ {
/*    */   private static final String WELL_KNOWN_CHANGE_PASSWORD_PATTERN = "/.well-known/change-password";
/*    */   private static final String DEFAULT_CHANGE_PASSWORD_PAGE = "/change-password";
/* 38 */   private String changePasswordPage = "/change-password";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PasswordManagementConfigurer<B> changePasswordPage(String changePasswordPage) {
/* 47 */     Assert.hasText(changePasswordPage, "changePasswordPage cannot be empty");
/* 48 */     this.changePasswordPage = changePasswordPage;
/* 49 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void configure(B http) throws Exception {
/* 58 */     RequestMatcherRedirectFilter changePasswordFilter = new RequestMatcherRedirectFilter(RequestMatcherFactory.matcher("/.well-known/change-password"), this.changePasswordPage);
/* 59 */     http.addFilterBefore((Filter)postProcess(changePasswordFilter), UsernamePasswordAuthenticationFilter.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\PasswordManagementConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */