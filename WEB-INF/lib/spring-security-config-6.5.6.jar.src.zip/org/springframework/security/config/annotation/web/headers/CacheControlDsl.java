/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\005\032\0020\006J#\020\007\032\030\022\016\022\f0\tR\b\022\004\022\0020\0130\n\022\004\022\0020\0060\bH\000¢\006\002\b\fR\016\020\003\032\0020\004X\016¢\006\002\n\000¨\006\r"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/CacheControlDsl;", "", "()V", "disabled", "", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CacheControlConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class CacheControlDsl
/*    */ {
/*    */   private boolean disabled;
/*    */   
/*    */   public final void disable() {
/* 37 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 41 */   public final Function1<HeadersConfigurer<HttpSecurity>.CacheControlConfig, Unit> get$spring_security_config() { return new CacheControlDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "cacheControl", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CacheControlConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 42 */   static final class CacheControlDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.CacheControlConfig, Unit> { public final void invoke(HeadersConfigurer.CacheControlConfig cacheControl) { Intrinsics.checkNotNullParameter(cacheControl, "cacheControl"); if (CacheControlDsl.this.disabled)
/* 43 */         cacheControl.disable();  }
/*    */ 
/*    */     
/*    */     CacheControlDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\CacheControlDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */