/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.FormLoginConfigurer;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "login", "Lorg/springframework/security/config/annotation/web/configurers/FormLoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nFormLoginDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FormLoginDsl.kt\norg/springframework/security/config/annotation/web/FormLoginDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,110:1\n1#2:111\n*E\n"})
/*     */ final class FormLoginDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<FormLoginConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(FormLoginConfigurer login) {
/*  92 */     Intrinsics.checkNotNullParameter(login, "login"); if (FormLoginDsl.this.getLoginPage() != null) { String str1 = FormLoginDsl.this.getLoginPage(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; String str2 = str1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       int $i$a$-also-FormLoginDsl$get$1$1 = 0; login.loginPage(formLoginDsl1.getLoginPage()); } else { FormLoginDsl.this.getLoginPage(); }  if (FormLoginDsl.this.getFailureUrl() != null) { String str1 = FormLoginDsl.this.getFailureUrl(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$2 = 0; login.failureUrl(formLoginDsl1.getFailureUrl()); } else { FormLoginDsl.this.getFailureUrl(); }  if (FormLoginDsl.this.getLoginProcessingUrl() != null) { String str1 = FormLoginDsl.this.getLoginProcessingUrl(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$3 = 0; login.loginProcessingUrl(formLoginDsl1.getLoginProcessingUrl()); } else { FormLoginDsl.this.getLoginProcessingUrl(); }  if (FormLoginDsl.this.getPermitAll() != null) { Boolean bool = FormLoginDsl.this.getPermitAll(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-FormLoginDsl$get$1$4 = 0; Intrinsics.checkNotNull(formLoginDsl1.getPermitAll()); login.permitAll(formLoginDsl1.getPermitAll().booleanValue()); } else { FormLoginDsl.this.getPermitAll(); }  Pair pair1 = FormLoginDsl.access$getDefaultSuccessUrlOption$p(FormLoginDsl.this); FormLoginDsl formLoginDsl = FormLoginDsl.this; Pair it = pair1; int $i$a$-also-FormLoginDsl$get$1$5 = 0; Intrinsics.checkNotNull(FormLoginDsl.access$getDefaultSuccessUrlOption$p(formLoginDsl)); Intrinsics.checkNotNull(FormLoginDsl.access$getDefaultSuccessUrlOption$p(formLoginDsl)); login.defaultSuccessUrl((String)FormLoginDsl.access$getDefaultSuccessUrlOption$p(formLoginDsl).getFirst(), ((Boolean)FormLoginDsl.access$getDefaultSuccessUrlOption$p(formLoginDsl).getSecond()).booleanValue()); FormLoginDsl.access$getDefaultSuccessUrlOption$p(FormLoginDsl.this); if (FormLoginDsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = FormLoginDsl.this.getAuthenticationSuccessHandler(); formLoginDsl = FormLoginDsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-FormLoginDsl$get$1$6 = 0; login.successHandler(formLoginDsl.getAuthenticationSuccessHandler()); } else { FormLoginDsl.this.getAuthenticationSuccessHandler(); }  if (FormLoginDsl.this.getAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = FormLoginDsl.this.getAuthenticationFailureHandler(); formLoginDsl = FormLoginDsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-FormLoginDsl$get$1$7 = 0; login.failureHandler(formLoginDsl.getAuthenticationFailureHandler()); } else { FormLoginDsl.this.getAuthenticationFailureHandler(); }  if (FormLoginDsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource1 = FormLoginDsl.this.getAuthenticationDetailsSource(); formLoginDsl = FormLoginDsl.this; AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource2 = authenticationDetailsSource1; int $i$a$-also-FormLoginDsl$get$1$8 = 0; login.authenticationDetailsSource(formLoginDsl.getAuthenticationDetailsSource()); } else { FormLoginDsl.this.getAuthenticationDetailsSource(); }  if (FormLoginDsl.this.getUsernameParameter() != null) { String str1 = FormLoginDsl.this.getUsernameParameter(); formLoginDsl = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$9 = 0; login.usernameParameter(formLoginDsl.getUsernameParameter()); } else { FormLoginDsl.this.getUsernameParameter(); }  if (FormLoginDsl.this.getPasswordParameter() != null) { String str1 = FormLoginDsl.this.getPasswordParameter(); formLoginDsl = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$10 = 0;
/*     */       login.passwordParameter(formLoginDsl.getPasswordParameter()); }
/*     */     else
/*     */     { FormLoginDsl.this.getPasswordParameter(); }
/*     */     
/*     */     if (FormLoginDsl.access$getDisabled$p(FormLoginDsl.this))
/*     */       login.disable(); 
/*     */   }
/*     */   
/*     */   FormLoginDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\FormLoginDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */