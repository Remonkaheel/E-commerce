/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.DispatcherType;
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.ServletRegistration;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.web.servlet.util.matcher.MvcRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.DispatcherTypeRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RegexRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRequestMatcherRegistry<C>
/*     */ {
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector";
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*     */   private static final boolean mvcPresent;
/*  74 */   private static final RequestMatcher ANY_REQUEST = AnyRequestMatcher.INSTANCE;
/*     */   
/*     */   private ApplicationContext context;
/*     */   
/*     */   private boolean anyRequestConfigured = false;
/*     */   
/*     */   static {
/*  81 */     mvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.handler.HandlerMappingIntrospector", AbstractRequestMatcherRegistry.class
/*  82 */         .getClassLoader());
/*     */   }
/*     */   
/*  85 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   protected final void setApplicationContext(ApplicationContext context) {
/*  88 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ApplicationContext getApplicationContext() {
/*  96 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C anyRequest() {
/* 104 */     Assert.state(!this.anyRequestConfigured, "Can't configure anyRequest after itself");
/* 105 */     C configurer = requestMatchers(new RequestMatcher[] { ANY_REQUEST });
/* 106 */     this.anyRequestConfigured = true;
/* 107 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final List<MvcRequestMatcher> createMvcMatchers(HttpMethod method, String... mvcPatterns) {
/* 117 */     Assert.state(!this.anyRequestConfigured, "Can't configure mvcMatchers after anyRequest");
/* 118 */     ResolvableType type = ResolvableType.forClassWithGenerics(ObjectPostProcessor.class, new Class[] { Object.class });
/* 119 */     ObjectProvider<ObjectPostProcessor<Object>> postProcessors = this.context.getBeanProvider(type);
/* 120 */     ObjectPostProcessor<Object> opp = (ObjectPostProcessor<Object>)postProcessors.getObject();
/* 121 */     if (!this.context.containsBean("mvcHandlerMappingIntrospector")) {
/* 122 */       throw new NoSuchBeanDefinitionException("A Bean named mvcHandlerMappingIntrospector of type " + HandlerMappingIntrospector.class
/* 123 */           .getName() + " is required to use MvcRequestMatcher. Please ensure Spring Security & Spring MVC are configured in a shared ApplicationContext.");
/*     */     }
/*     */     
/* 126 */     HandlerMappingIntrospector introspector = (HandlerMappingIntrospector)this.context.getBean("mvcHandlerMappingIntrospector", HandlerMappingIntrospector.class);
/*     */     
/* 128 */     List<MvcRequestMatcher> matchers = new ArrayList<>(mvcPatterns.length);
/* 129 */     for (String mvcPattern : mvcPatterns) {
/* 130 */       MvcRequestMatcher matcher = new MvcRequestMatcher(introspector, mvcPattern);
/* 131 */       opp.postProcess(matcher);
/* 132 */       if (method != null) {
/* 133 */         matcher.setMethod(method);
/*     */       }
/* 135 */       matchers.add(matcher);
/*     */     } 
/* 137 */     return matchers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C dispatcherTypeMatchers(@Nullable HttpMethod method, DispatcherType... dispatcherTypes) {
/* 150 */     Assert.state(!this.anyRequestConfigured, "Can't configure dispatcherTypeMatchers after anyRequest");
/* 151 */     List<RequestMatcher> matchers = new ArrayList<>();
/* 152 */     for (DispatcherType dispatcherType : dispatcherTypes) {
/* 153 */       matchers.add(new DispatcherTypeRequestMatcher(dispatcherType, method));
/*     */     }
/* 155 */     return chainRequestMatchers(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C dispatcherTypeMatchers(DispatcherType... dispatcherTypes) {
/* 166 */     Assert.state(!this.anyRequestConfigured, "Can't configure dispatcherTypeMatchers after anyRequest");
/* 167 */     return dispatcherTypeMatchers(null, dispatcherTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C requestMatchers(RequestMatcher... requestMatchers) {
/* 177 */     Assert.state(!this.anyRequestConfigured, "Can't configure requestMatchers after anyRequest");
/* 178 */     return chainRequestMatchers(Arrays.asList(requestMatchers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C requestMatchers(HttpMethod method, String... patterns) {
/* 202 */     if (anyPathsDontStartWithLeadingSlash(patterns)) {
/* 203 */       this.logger.warn("One of the patterns in " + Arrays.toString((Object[])patterns) + " is missing a leading slash. This is discouraged; please include the leading slash in all your request matcher patterns. In future versions of Spring Security, leaving out the leading slash will result in an exception.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (!mvcPresent) {
/* 209 */       return requestMatchers(RequestMatchers.antMatchersAsArray(method, patterns));
/*     */     }
/* 211 */     if (!(this.context instanceof WebApplicationContext)) {
/* 212 */       return requestMatchers(RequestMatchers.antMatchersAsArray(method, patterns));
/*     */     }
/* 214 */     WebApplicationContext context = (WebApplicationContext)this.context;
/* 215 */     ServletContext servletContext = context.getServletContext();
/* 216 */     if (servletContext == null) {
/* 217 */       return requestMatchers(RequestMatchers.antMatchersAsArray(method, patterns));
/*     */     }
/* 219 */     List<RequestMatcher> matchers = new ArrayList<>();
/* 220 */     for (String pattern : patterns) {
/* 221 */       if (RequestMatcherFactory.usesPathPatterns()) {
/* 222 */         matchers.add(RequestMatcherFactory.matcher(method, pattern));
/*     */       } else {
/*     */         
/* 225 */         AntPathRequestMatcher ant = new AntPathRequestMatcher(pattern, (method != null) ? method.name() : null);
/* 226 */         MvcRequestMatcher mvc = createMvcMatchers(method, new String[] { pattern }).get(0);
/* 227 */         matchers.add(new DeferredRequestMatcher(c -> resolve(ant, mvc, c), new RequestMatcher[] { (RequestMatcher)mvc, (RequestMatcher)ant }));
/*     */       } 
/*     */     } 
/* 230 */     return requestMatchers(matchers.<RequestMatcher>toArray(new RequestMatcher[0]));
/*     */   }
/*     */   
/*     */   private boolean anyPathsDontStartWithLeadingSlash(String... patterns) {
/* 234 */     for (String pattern : patterns) {
/* 235 */       if (!pattern.startsWith("/")) {
/* 236 */         return true;
/*     */       }
/*     */     } 
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   private RequestMatcher resolve(AntPathRequestMatcher ant, MvcRequestMatcher mvc, ServletContext servletContext) {
/* 243 */     ServletRegistrationsSupport registrations = new ServletRegistrationsSupport(servletContext);
/* 244 */     Collection<ServletRegistrationsSupport.RegistrationMapping> mappings = registrations.mappings();
/* 245 */     if (mappings.isEmpty()) {
/* 246 */       return new DispatcherServletDelegatingRequestMatcher(ant, mvc, new MockMvcRequestMatcher());
/*     */     }
/* 248 */     Collection<ServletRegistrationsSupport.RegistrationMapping> dispatcherServletMappings = registrations.dispatcherServletMappings();
/* 249 */     if (dispatcherServletMappings.isEmpty()) {
/* 250 */       return new DispatcherServletDelegatingRequestMatcher(ant, mvc, new MockMvcRequestMatcher());
/*     */     }
/* 252 */     if (dispatcherServletMappings.size() > 1) {
/* 253 */       String errorMessage = computeErrorMessage(servletContext.getServletRegistrations().values());
/* 254 */       throw new IllegalArgumentException(errorMessage);
/*     */     } 
/* 256 */     ServletRegistrationsSupport.RegistrationMapping dispatcherServlet = dispatcherServletMappings.iterator().next();
/* 257 */     if (mappings.size() > 1 && !dispatcherServlet.isDefault()) {
/* 258 */       String errorMessage = computeErrorMessage(servletContext.getServletRegistrations().values());
/* 259 */       throw new IllegalArgumentException(errorMessage);
/*     */     } 
/* 261 */     if (dispatcherServlet.isDefault()) {
/* 262 */       if (mappings.size() == 1) {
/* 263 */         return (RequestMatcher)mvc;
/*     */       }
/* 265 */       return new DispatcherServletDelegatingRequestMatcher(ant, mvc);
/*     */     } 
/* 267 */     return (RequestMatcher)mvc;
/*     */   }
/*     */   
/*     */   private static String computeErrorMessage(Collection<? extends ServletRegistration> registrations) {
/* 271 */     String template = "This method cannot decide whether these patterns are Spring MVC patterns or not. This is because there is more than one mappable servlet in your servlet context: %s.\n\nTo address this, please create one PathPatternRequestMatcher.Builder#servletPath for each servlet that has authorized endpoints and use them to construct request matchers manually.\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     Map<String, Collection<String>> mappings = new LinkedHashMap<>();
/* 279 */     for (ServletRegistration registration : registrations) {
/* 280 */       mappings.put(registration.getClassName(), registration.getMappings());
/*     */     }
/* 282 */     return String.format(template, new Object[] { mappings });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C requestMatchers(String... patterns) {
/* 304 */     return requestMatchers(null, patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C requestMatchers(HttpMethod method) {
/* 326 */     return requestMatchers(method, new String[] { "/**" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract C chainRequestMatchers(List<RequestMatcher> paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class RequestMatchers
/*     */   {
/*     */     static List<RequestMatcher> antMatchers(HttpMethod httpMethod, String... antPatterns) {
/* 358 */       return Arrays.asList(antMatchersAsArray(httpMethod, antPatterns));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static List<RequestMatcher> antMatchers(String... antPatterns) {
/* 369 */       return antMatchers(null, antPatterns);
/*     */     }
/*     */     
/*     */     static RequestMatcher[] antMatchersAsArray(HttpMethod httpMethod, String... antPatterns) {
/* 373 */       String method = (httpMethod != null) ? httpMethod.toString() : null;
/* 374 */       RequestMatcher[] matchers = new RequestMatcher[antPatterns.length];
/* 375 */       for (int index = 0; index < antPatterns.length; index++) {
/* 376 */         matchers[index] = (RequestMatcher)new AntPathRequestMatcher(antPatterns[index], method);
/*     */       }
/* 378 */       return matchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static List<RequestMatcher> regexMatchers(HttpMethod httpMethod, String... regexPatterns) {
/* 390 */       String method = (httpMethod != null) ? httpMethod.toString() : null;
/* 391 */       List<RequestMatcher> matchers = new ArrayList<>();
/* 392 */       for (String pattern : regexPatterns) {
/* 393 */         matchers.add(new RegexRequestMatcher(pattern, method));
/*     */       }
/* 395 */       return matchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static List<RequestMatcher> regexMatchers(String... regexPatterns) {
/* 406 */       return regexMatchers(null, regexPatterns);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class DeferredRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     final Function<ServletContext, RequestMatcher> requestMatcherFactory;
/* 415 */     final AtomicReference<String> description = new AtomicReference<>();
/*     */     
/* 417 */     final Map<ServletContext, RequestMatcher> requestMatchers = new ConcurrentHashMap<>();
/*     */     
/*     */     DeferredRequestMatcher(Function<ServletContext, RequestMatcher> resolver, RequestMatcher... candidates) {
/* 420 */       this.requestMatcherFactory = (sc -> (RequestMatcher)this.requestMatchers.computeIfAbsent(sc, resolver));
/* 421 */       this.description.set("Deferred " + Arrays.toString((Object[])candidates));
/*     */     }
/*     */     
/*     */     RequestMatcher requestMatcher(ServletContext servletContext) {
/* 425 */       return this.requestMatcherFactory.apply(servletContext);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 430 */       return ((RequestMatcher)this.requestMatcherFactory.apply(request.getServletContext())).matches(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/* 435 */       return ((RequestMatcher)this.requestMatcherFactory.apply(request.getServletContext())).matcher(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 440 */       return this.description.get();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class MockMvcRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 449 */       return (request.getAttribute("org.springframework.test.web.servlet.MockMvc.MVC_RESULT_ATTRIBUTE") != null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class DispatcherServletRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     public boolean matches(HttpServletRequest request) {
/* 458 */       String name = request.getHttpServletMapping().getServletName();
/* 459 */       ServletRegistration registration = request.getServletContext().getServletRegistration(name);
/* 460 */       Assert.notNull(registration, () -> AbstractRequestMatcherRegistry.computeErrorMessage(request.getServletContext().getServletRegistrations().values()));
/*     */       
/*     */       try {
/* 463 */         Class<?> clazz = Class.forName(registration.getClassName());
/* 464 */         return DispatcherServlet.class.isAssignableFrom(clazz);
/*     */       }
/* 466 */       catch (ClassNotFoundException ex) {
/* 467 */         return false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class DispatcherServletDelegatingRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     private final AntPathRequestMatcher ant;
/*     */     
/*     */     private final MvcRequestMatcher mvc;
/*     */     private final RequestMatcher dispatcherServlet;
/*     */     
/*     */     DispatcherServletDelegatingRequestMatcher(AntPathRequestMatcher ant, MvcRequestMatcher mvc) {
/* 482 */       this(ant, mvc, (RequestMatcher)new OrRequestMatcher(new RequestMatcher[] { new AbstractRequestMatcherRegistry.MockMvcRequestMatcher(), new AbstractRequestMatcherRegistry.DispatcherServletRequestMatcher() }));
/*     */     }
/*     */ 
/*     */     
/*     */     DispatcherServletDelegatingRequestMatcher(AntPathRequestMatcher ant, MvcRequestMatcher mvc, RequestMatcher dispatcherServlet) {
/* 487 */       this.ant = ant;
/* 488 */       this.mvc = mvc;
/* 489 */       this.dispatcherServlet = dispatcherServlet;
/*     */     }
/*     */     
/*     */     RequestMatcher requestMatcher(HttpServletRequest request) {
/* 493 */       if (this.dispatcherServlet.matches(request)) {
/* 494 */         return (RequestMatcher)this.mvc;
/*     */       }
/* 496 */       return (RequestMatcher)this.ant;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 501 */       return requestMatcher(request).matches(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public RequestMatcher.MatchResult matcher(HttpServletRequest request) {
/* 506 */       return requestMatcher(request).matcher(request);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 511 */       return "DispatcherServletDelegating [ant = " + String.valueOf(this.ant) + ", mvc = " + String.valueOf(this.mvc) + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */