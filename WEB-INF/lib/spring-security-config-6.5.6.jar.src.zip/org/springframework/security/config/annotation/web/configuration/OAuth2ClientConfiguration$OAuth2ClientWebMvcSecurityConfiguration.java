/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.web.method.annotation.OAuth2AuthorizedClientArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class OAuth2ClientWebMvcSecurityConfiguration
/*     */   implements WebMvcConfigurer
/*     */ {
/*     */   private final OAuth2AuthorizedClientManager authorizedClientManager;
/*     */   private final ObjectProvider<SecurityContextHolderStrategy> securityContextHolderStrategy;
/*     */   private final OAuth2ClientConfiguration.OAuth2AuthorizedClientManagerRegistrar authorizedClientManagerRegistrar;
/*     */   
/*     */   OAuth2ClientWebMvcSecurityConfiguration(ObjectProvider<OAuth2AuthorizedClientManager> authorizedClientManager, ObjectProvider<SecurityContextHolderStrategy> securityContextHolderStrategy, OAuth2ClientConfiguration.OAuth2AuthorizedClientManagerRegistrar authorizedClientManagerRegistrar) {
/* 131 */     this.authorizedClientManager = (OAuth2AuthorizedClientManager)authorizedClientManager.getIfUnique();
/* 132 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/* 133 */     this.authorizedClientManagerRegistrar = authorizedClientManagerRegistrar;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 138 */     OAuth2AuthorizedClientManager authorizedClientManager = getAuthorizedClientManager();
/* 139 */     if (authorizedClientManager != null) {
/* 140 */       OAuth2AuthorizedClientArgumentResolver resolver = new OAuth2AuthorizedClientArgumentResolver(authorizedClientManager);
/*     */       
/* 142 */       Objects.requireNonNull(resolver); this.securityContextHolderStrategy.ifAvailable(resolver::setSecurityContextHolderStrategy);
/* 143 */       argumentResolvers.add(resolver);
/*     */     } 
/*     */   }
/*     */   
/*     */   private OAuth2AuthorizedClientManager getAuthorizedClientManager() {
/* 148 */     if (this.authorizedClientManager != null) {
/* 149 */       return this.authorizedClientManager;
/*     */     }
/* 151 */     return this.authorizedClientManagerRegistrar.getAuthorizedClientManagerIfAvailable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\OAuth2ClientConfiguration$OAuth2ClientWebMvcSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */