/*    */ package org.springframework.security.config.annotation.web.reactive;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.security.authentication.ObservationReactiveAuthenticationManager;
/*    */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*    */ import org.springframework.security.authorization.ObservationReactiveAuthorizationManager;
/*    */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ import org.springframework.security.web.server.ObservationWebFilterChainDecorator;
/*    */ import org.springframework.security.web.server.WebFilterChainProxy;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ class ReactiveObservationConfiguration
/*    */ {
/* 40 */   private static final SecurityObservationSettings all = SecurityObservationSettings.withDefaults()
/* 41 */     .shouldObserveRequests(true)
/* 42 */     .shouldObserveAuthentications(true)
/* 43 */     .shouldObserveAuthorizations(true)
/* 44 */     .build();
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<ReactiveAuthorizationManager<ServerWebExchange>> webAuthorizationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 50 */     return new ObjectPostProcessor<ReactiveAuthorizationManager<ServerWebExchange>>()
/*    */       {
/*    */         public ReactiveAuthorizationManager postProcess(ReactiveAuthorizationManager object) {
/* 53 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 54 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ReactiveObservationConfiguration.all)).shouldObserveAuthorizations());
/* 55 */           return active ? (ReactiveAuthorizationManager)new ObservationReactiveAuthorizationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<ReactiveAuthenticationManager> reactiveAuthenticationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 64 */     return new ObjectPostProcessor<ReactiveAuthenticationManager>()
/*    */       {
/*    */         public ReactiveAuthenticationManager postProcess(ReactiveAuthenticationManager object) {
/* 67 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 68 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ReactiveObservationConfiguration.all)).shouldObserveAuthentications());
/* 69 */           return active ? (ReactiveAuthenticationManager)new ObservationReactiveAuthenticationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<WebFilterChainProxy.WebFilterChainDecorator> filterChainDecoratorPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 78 */     return new ObjectPostProcessor<WebFilterChainProxy.WebFilterChainDecorator>()
/*    */       {
/*    */         public WebFilterChainProxy.WebFilterChainDecorator postProcess(WebFilterChainProxy.WebFilterChainDecorator object) {
/* 81 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 82 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ReactiveObservationConfiguration.all)).shouldObserveRequests());
/* 83 */           return active ? (WebFilterChainProxy.WebFilterChainDecorator)new ObservationWebFilterChainDecorator(r) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ReactiveObservationConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */