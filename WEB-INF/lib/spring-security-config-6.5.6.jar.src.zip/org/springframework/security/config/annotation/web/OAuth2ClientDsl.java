/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2ClientConfigurer;
/*     */ import org.springframework.security.config.annotation.web.oauth2.client.AuthorizationCodeGrantDsl;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000F\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\003\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\003\032\0020\b2\027\020\033\032\023\022\004\022\0020\034\022\004\022\0020\b0\004¢\006\002\b\035J\037\020\036\032\024\022\n\022\b\022\004\022\0020\0070\006\022\004\022\0020\b0\004H\000¢\006\002\b\037R&\020\003\032\032\022\016\022\f0\005R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\034\020\017\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024R\034\020\025\032\004\030\0010\026X\016¢\006\016\n\000\032\004\b\027\020\030\"\004\b\031\020\032¨\006 "}, d2 = {"Lorg/springframework/security/config/annotation/web/OAuth2ClientDsl;", "", "()V", "authorizationCodeGrant", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer$AuthorizationCodeGrantConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "authorizedClientRepository", "Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizedClientRepository;", "getAuthorizedClientRepository", "()Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizedClientRepository;", "setAuthorizedClientRepository", "(Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizedClientRepository;)V", "authorizedClientService", "Lorg/springframework/security/oauth2/client/OAuth2AuthorizedClientService;", "getAuthorizedClientService", "()Lorg/springframework/security/oauth2/client/OAuth2AuthorizedClientService;", "setAuthorizedClientService", "(Lorg/springframework/security/oauth2/client/OAuth2AuthorizedClientService;)V", "clientRegistrationRepository", "Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;", "getClientRegistrationRepository", "()Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;", "setClientRegistrationRepository", "(Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;)V", "authorizationCodeGrantConfig", "Lorg/springframework/security/config/annotation/web/oauth2/client/AuthorizationCodeGrantDsl;", "Lkotlin/ExtensionFunctionType;", "get", "get$spring_security_config", "spring-security-config"})
/*     */ public final class OAuth2ClientDsl
/*     */ {
/*     */   @Nullable
/*     */   private ClientRegistrationRepository clientRegistrationRepository;
/*     */   @Nullable
/*     */   private OAuth2AuthorizedClientRepository authorizedClientRepository;
/*     */   @Nullable
/*     */   private OAuth2AuthorizedClientService authorizedClientService;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2ClientConfigurer<HttpSecurity>.AuthorizationCodeGrantConfigurer, Unit> authorizationCodeGrant;
/*     */   
/*     */   @Nullable
/*     */   public final ClientRegistrationRepository getClientRegistrationRepository() {
/*  55 */     return this.clientRegistrationRepository; } public final void setClientRegistrationRepository(@Nullable ClientRegistrationRepository <set-?>) { this.clientRegistrationRepository = <set-?>; } @Nullable
/*  56 */   public final OAuth2AuthorizedClientRepository getAuthorizedClientRepository() { return this.authorizedClientRepository; } public final void setAuthorizedClientRepository(@Nullable OAuth2AuthorizedClientRepository <set-?>) { this.authorizedClientRepository = <set-?>; } @Nullable
/*  57 */   public final OAuth2AuthorizedClientService getAuthorizedClientService() { return this.authorizedClientService; } public final void setAuthorizedClientService(@Nullable OAuth2AuthorizedClientService <set-?>) { this.authorizedClientService = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorizationCodeGrant(@NotNull Function1 authorizationCodeGrantConfig) {
/*  90 */     Intrinsics.checkNotNullParameter(authorizationCodeGrantConfig, "authorizationCodeGrantConfig"); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = new AuthorizationCodeGrantDsl(); authorizationCodeGrantConfig.invoke(authorizationCodeGrantDsl); this.authorizationCodeGrant = authorizationCodeGrantDsl.get$spring_security_config();
/*     */   }
/*     */   
/*     */   @NotNull
/*  94 */   public final Function1<OAuth2ClientConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new OAuth2ClientDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oauth2Client", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOAuth2ClientDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OAuth2ClientDsl.kt\norg/springframework/security/config/annotation/web/OAuth2ClientDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,102:1\n1#2:103\n*E\n"})
/*  95 */   static final class OAuth2ClientDsl$get$1 extends Lambda implements Function1<OAuth2ClientConfigurer<HttpSecurity>, Unit> { public final void invoke(OAuth2ClientConfigurer oauth2Client) { Intrinsics.checkNotNullParameter(oauth2Client, "oauth2Client"); if (OAuth2ClientDsl.this.getClientRegistrationRepository() != null) { ClientRegistrationRepository clientRegistrationRepository1 = OAuth2ClientDsl.this.getClientRegistrationRepository(); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; ClientRegistrationRepository it = clientRegistrationRepository1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 103 */         int $i$a$-also-OAuth2ClientDsl$get$1$1 = 0; oauth2Client.clientRegistrationRepository(oAuth2ClientDsl.getClientRegistrationRepository()); } else { OAuth2ClientDsl.this.getClientRegistrationRepository(); }  if (OAuth2ClientDsl.this.getAuthorizedClientRepository() != null) { OAuth2AuthorizedClientRepository oAuth2AuthorizedClientRepository1 = OAuth2ClientDsl.this.getAuthorizedClientRepository(); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; OAuth2AuthorizedClientRepository it = oAuth2AuthorizedClientRepository1; int $i$a$-also-OAuth2ClientDsl$get$1$2 = 0; oauth2Client.authorizedClientRepository(oAuth2ClientDsl.getAuthorizedClientRepository()); } else { OAuth2ClientDsl.this.getAuthorizedClientRepository(); }  if (OAuth2ClientDsl.this.getAuthorizedClientService() != null) { OAuth2AuthorizedClientService oAuth2AuthorizedClientService1 = OAuth2ClientDsl.this.getAuthorizedClientService(); OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; OAuth2AuthorizedClientService it = oAuth2AuthorizedClientService1; int $i$a$-also-OAuth2ClientDsl$get$1$3 = 0; oauth2Client.authorizedClientService(oAuth2ClientDsl.getAuthorizedClientService()); } else { OAuth2ClientDsl.this.getAuthorizedClientService(); }  if (OAuth2ClientDsl.this.authorizationCodeGrant != null) { Function1 function11 = OAuth2ClientDsl.this.authorizationCodeGrant; OAuth2ClientDsl oAuth2ClientDsl = OAuth2ClientDsl.this; Function1 it = function11; int $i$a$-also-OAuth2ClientDsl$get$1$4 = 0;
/*     */         oAuth2ClientDsl.authorizationCodeGrant;
/*     */         oauth2Client.authorizationCodeGrant((oAuth2ClientDsl.authorizationCodeGrant != null) ? oAuth2ClientDsl.authorizationCodeGrant::invoke$lambda$4$lambda$3 : null); }
/*     */       else
/*     */       { OAuth2ClientDsl.this.authorizationCodeGrant; }
/*     */        }
/*     */ 
/*     */     
/*     */     private static final void invoke$lambda$4$lambda$3(Function1 $tmp0, OAuth2ClientConfigurer.AuthorizationCodeGrantConfigurer t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     OAuth2ClientDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OAuth2ClientDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */