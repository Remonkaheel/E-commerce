/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.ott.OneTimeTokenService;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.ott.OneTimeTokenLoginConfigurer;
/*    */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*    */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*    */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*    */ import org.springframework.security.web.authentication.ott.GenerateOneTimeTokenRequestResolver;
/*    */ import org.springframework.security.web.authentication.ott.OneTimeTokenGenerationSuccessHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oneTimeTokenLoginConfigurer", "Lorg/springframework/security/config/annotation/web/configurers/ott/OneTimeTokenLoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nOneTimeTokenLoginDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OneTimeTokenLoginDsl.kt\norg/springframework/security/config/annotation/web/OneTimeTokenLoginDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,92:1\n1#2:93\n*E\n"})
/*    */ final class OneTimeTokenLoginDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OneTimeTokenLoginConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(OneTimeTokenLoginConfigurer oneTimeTokenLoginConfigurer) {
/* 62 */     Intrinsics.checkNotNullParameter(oneTimeTokenLoginConfigurer, "oneTimeTokenLoginConfigurer"); if (OneTimeTokenLoginDsl.this.getTokenService() != null) { OneTimeTokenService oneTimeTokenService1 = OneTimeTokenLoginDsl.this.getTokenService(); OneTimeTokenLoginDsl oneTimeTokenLoginDsl1 = OneTimeTokenLoginDsl.this; OneTimeTokenService oneTimeTokenService2 = oneTimeTokenService1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 93 */       int $i$a$-also-OneTimeTokenLoginDsl$get$1$1 = 0; oneTimeTokenLoginConfigurer.tokenService(oneTimeTokenLoginDsl1.getTokenService()); } else { OneTimeTokenLoginDsl.this.getTokenService(); }  if (OneTimeTokenLoginDsl.this.getAuthenticationConverter() != null) { AuthenticationConverter authenticationConverter1 = OneTimeTokenLoginDsl.this.getAuthenticationConverter(); OneTimeTokenLoginDsl oneTimeTokenLoginDsl1 = OneTimeTokenLoginDsl.this; AuthenticationConverter authenticationConverter2 = authenticationConverter1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$2 = 0; oneTimeTokenLoginConfigurer.authenticationConverter(oneTimeTokenLoginDsl1.getAuthenticationConverter()); } else { OneTimeTokenLoginDsl.this.getAuthenticationConverter(); }  AuthenticationFailureHandler authenticationFailureHandler1 = OneTimeTokenLoginDsl.this.getAuthenticationFailureHandler(); OneTimeTokenLoginDsl oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$3 = 0; oneTimeTokenLoginConfigurer.failureHandler(oneTimeTokenLoginDsl.getAuthenticationFailureHandler()); OneTimeTokenLoginDsl.this.getAuthenticationFailureHandler(); AuthenticationSuccessHandler authenticationSuccessHandler1 = OneTimeTokenLoginDsl.this.getAuthenticationSuccessHandler(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$4 = 0; oneTimeTokenLoginConfigurer.successHandler(oneTimeTokenLoginDsl.getAuthenticationSuccessHandler()); OneTimeTokenLoginDsl.this.getAuthenticationSuccessHandler(); GenerateOneTimeTokenRequestResolver generateOneTimeTokenRequestResolver1 = OneTimeTokenLoginDsl.this.getGenerateRequestResolver(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; GenerateOneTimeTokenRequestResolver generateOneTimeTokenRequestResolver2 = generateOneTimeTokenRequestResolver1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$5 = 0; oneTimeTokenLoginConfigurer.generateRequestResolver(oneTimeTokenLoginDsl.getGenerateRequestResolver()); OneTimeTokenLoginDsl.this.getGenerateRequestResolver(); if (OneTimeTokenLoginDsl.this.getDefaultSubmitPageUrl() != null) { String str1 = OneTimeTokenLoginDsl.this.getDefaultSubmitPageUrl(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; String str2 = str1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$6 = 0; oneTimeTokenLoginConfigurer.defaultSubmitPageUrl(oneTimeTokenLoginDsl.getDefaultSubmitPageUrl()); } else { OneTimeTokenLoginDsl.this.getDefaultSubmitPageUrl(); }  if (OneTimeTokenLoginDsl.this.getShowDefaultSubmitPage() != null) { Boolean bool = OneTimeTokenLoginDsl.this.getShowDefaultSubmitPage(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-OneTimeTokenLoginDsl$get$1$7 = 0; Intrinsics.checkNotNull(oneTimeTokenLoginDsl.getShowDefaultSubmitPage()); oneTimeTokenLoginConfigurer.showDefaultSubmitPage(oneTimeTokenLoginDsl.getShowDefaultSubmitPage().booleanValue()); } else { OneTimeTokenLoginDsl.this.getShowDefaultSubmitPage(); }  if (OneTimeTokenLoginDsl.this.getLoginProcessingUrl() != null) { String str1 = OneTimeTokenLoginDsl.this.getLoginProcessingUrl(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; String str2 = str1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$8 = 0; oneTimeTokenLoginConfigurer.loginProcessingUrl(oneTimeTokenLoginDsl.getLoginProcessingUrl()); } else { OneTimeTokenLoginDsl.this.getLoginProcessingUrl(); }  if (OneTimeTokenLoginDsl.this.getTokenGeneratingUrl() != null) { String str1 = OneTimeTokenLoginDsl.this.getTokenGeneratingUrl(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; String str2 = str1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$9 = 0; oneTimeTokenLoginConfigurer.tokenGeneratingUrl(oneTimeTokenLoginDsl.getTokenGeneratingUrl()); } else { OneTimeTokenLoginDsl.this.getTokenGeneratingUrl(); }  OneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler1 = OneTimeTokenLoginDsl.this.getOneTimeTokenGenerationSuccessHandler(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; OneTimeTokenGenerationSuccessHandler it = oneTimeTokenGenerationSuccessHandler1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$10 = 0; oneTimeTokenLoginConfigurer.tokenGenerationSuccessHandler(oneTimeTokenLoginDsl.getOneTimeTokenGenerationSuccessHandler()); OneTimeTokenLoginDsl.this.getOneTimeTokenGenerationSuccessHandler(); if (OneTimeTokenLoginDsl.this.getAuthenticationProvider() != null) { AuthenticationProvider authenticationProvider1 = OneTimeTokenLoginDsl.this.getAuthenticationProvider(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; AuthenticationProvider authenticationProvider2 = authenticationProvider1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$11 = 0;
/*    */       oneTimeTokenLoginConfigurer.authenticationProvider(oneTimeTokenLoginDsl.getAuthenticationProvider()); }
/*    */     else
/*    */     { OneTimeTokenLoginDsl.this.getAuthenticationProvider(); }
/*    */   
/*    */   }
/*    */   
/*    */   OneTimeTokenLoginDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OneTimeTokenLoginDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */