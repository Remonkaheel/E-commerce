/*     */ package org.springframework.security.config.annotation.web.configurers.ott;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationProvider;
/*     */ import org.springframework.security.authentication.ott.OneTimeTokenService;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractAuthenticationFilterConfigurer;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.ott.GenerateOneTimeTokenFilter;
/*     */ import org.springframework.security.web.authentication.ott.GenerateOneTimeTokenRequestResolver;
/*     */ import org.springframework.security.web.authentication.ott.OneTimeTokenAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.ott.OneTimeTokenGenerationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultOneTimeTokenSubmitPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultResourcesFilter;
/*     */ import org.springframework.security.web.csrf.CsrfToken;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OneTimeTokenLoginConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractAuthenticationFilterConfigurer<H, OneTimeTokenLoginConfigurer<H>, OneTimeTokenAuthenticationFilter>
/*     */ {
/*     */   private final ApplicationContext context;
/*     */   private OneTimeTokenService oneTimeTokenService;
/* 110 */   private String defaultSubmitPageUrl = "/login/ott";
/*     */   
/*     */   private boolean submitPageEnabled = true;
/*     */   
/* 114 */   private String loginProcessingUrl = "/login/ott";
/*     */   
/* 116 */   private String tokenGeneratingUrl = "/ott/generate";
/*     */   
/*     */   private OneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler;
/*     */   
/*     */   private AuthenticationProvider authenticationProvider;
/*     */   
/*     */   private GenerateOneTimeTokenRequestResolver requestResolver;
/*     */   
/*     */   public OneTimeTokenLoginConfigurer(ApplicationContext context) {
/* 125 */     super((AbstractAuthenticationProcessingFilter)new OneTimeTokenAuthenticationFilter(), "/login/ott");
/* 126 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) throws Exception {
/* 131 */     super.init((HttpSecurityBuilder)http);
/* 132 */     AuthenticationProvider authenticationProvider = getAuthenticationProvider();
/* 133 */     http.authenticationProvider((AuthenticationProvider)postProcess(authenticationProvider));
/* 134 */     intiDefaultLoginFilter(http);
/*     */   }
/*     */ 
/*     */   
/*     */   private void intiDefaultLoginFilter(H http) {
/* 139 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/* 140 */     if (loginPageGeneratingFilter == null || isCustomLoginPage()) {
/*     */       return;
/*     */     }
/* 143 */     loginPageGeneratingFilter.setOneTimeTokenEnabled(true);
/* 144 */     loginPageGeneratingFilter.setOneTimeTokenGenerationUrl(this.tokenGeneratingUrl);
/*     */     
/* 146 */     if (!StringUtils.hasText(loginPageGeneratingFilter.getLoginPageUrl())) {
/* 147 */       loginPageGeneratingFilter.setLoginPageUrl("/login");
/* 148 */       loginPageGeneratingFilter.setFailureUrl("/login?error");
/*     */       
/* 150 */       loginPageGeneratingFilter
/* 151 */         .setLogoutSuccessUrl("/login?logout");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) throws Exception {
/* 157 */     super.configure((HttpSecurityBuilder)http);
/* 158 */     configureSubmitPage(http);
/* 159 */     configureOttGenerateFilter(http);
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureOttGenerateFilter(H http) {
/* 164 */     GenerateOneTimeTokenFilter generateFilter = new GenerateOneTimeTokenFilter(getOneTimeTokenService(), getOneTimeTokenGenerationSuccessHandler());
/* 165 */     generateFilter.setRequestMatcher(RequestMatcherFactory.matcher(HttpMethod.POST, this.tokenGeneratingUrl));
/* 166 */     generateFilter.setRequestResolver(getGenerateRequestResolver());
/* 167 */     http.addFilter((Filter)postProcess(generateFilter));
/* 168 */     http.addFilter((Filter)DefaultResourcesFilter.css());
/*     */   }
/*     */   
/*     */   private OneTimeTokenGenerationSuccessHandler getOneTimeTokenGenerationSuccessHandler() {
/* 172 */     if (this.oneTimeTokenGenerationSuccessHandler == null) {
/* 173 */       this
/*     */         
/* 175 */         .oneTimeTokenGenerationSuccessHandler = (OneTimeTokenGenerationSuccessHandler)this.context.getBeanProvider(OneTimeTokenGenerationSuccessHandler.class).getIfUnique();
/*     */     }
/* 177 */     if (this.oneTimeTokenGenerationSuccessHandler == null) {
/* 178 */       throw new IllegalStateException("A OneTimeTokenGenerationSuccessHandler is required to enable oneTimeTokenLogin().\nPlease provide it as a bean or pass it to the oneTimeTokenLogin() DSL.\n");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 183 */     return this.oneTimeTokenGenerationSuccessHandler;
/*     */   }
/*     */   
/*     */   private void configureSubmitPage(H http) {
/* 187 */     if (!this.submitPageEnabled) {
/*     */       return;
/*     */     }
/* 190 */     DefaultOneTimeTokenSubmitPageGeneratingFilter submitPage = new DefaultOneTimeTokenSubmitPageGeneratingFilter();
/* 191 */     submitPage.setResolveHiddenInputs(this::hiddenInputs);
/* 192 */     submitPage.setRequestMatcher(RequestMatcherFactory.matcher(HttpMethod.GET, this.defaultSubmitPageUrl));
/* 193 */     submitPage.setLoginProcessingUrl(getLoginProcessingUrl());
/* 194 */     http.addFilter((Filter)postProcess(submitPage));
/*     */   }
/*     */   
/*     */   private AuthenticationProvider getAuthenticationProvider() {
/* 198 */     if (this.authenticationProvider != null) {
/* 199 */       return this.authenticationProvider;
/*     */     }
/* 201 */     UserDetailsService userDetailsService = (UserDetailsService)this.context.getBean(UserDetailsService.class);
/* 202 */     this.authenticationProvider = (AuthenticationProvider)new OneTimeTokenAuthenticationProvider(getOneTimeTokenService(), userDetailsService);
/*     */     
/* 204 */     return this.authenticationProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   protected RequestMatcher createLoginProcessingUrlMatcher(String loginProcessingUrl) {
/* 209 */     return RequestMatcherFactory.matcher(HttpMethod.POST, loginProcessingUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> authenticationProvider(AuthenticationProvider authenticationProvider) {
/* 217 */     Assert.notNull(authenticationProvider, "authenticationProvider cannot be null");
/* 218 */     this.authenticationProvider = authenticationProvider;
/* 219 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> tokenGeneratingUrl(String tokenGeneratingUrl) {
/* 228 */     Assert.hasText(tokenGeneratingUrl, "tokenGeneratingUrl cannot be null or empty");
/* 229 */     this.tokenGeneratingUrl = tokenGeneratingUrl;
/* 230 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> tokenGenerationSuccessHandler(OneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler) {
/* 239 */     Assert.notNull(oneTimeTokenGenerationSuccessHandler, "oneTimeTokenGenerationSuccessHandler cannot be null");
/* 240 */     this.oneTimeTokenGenerationSuccessHandler = oneTimeTokenGenerationSuccessHandler;
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> loginProcessingUrl(String loginProcessingUrl) {
/* 252 */     Assert.hasText(loginProcessingUrl, "loginProcessingUrl cannot be null or empty");
/* 253 */     super.loginProcessingUrl(loginProcessingUrl);
/* 254 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> loginPage(String loginPage) {
/* 265 */     return (OneTimeTokenLoginConfigurer<H>)super.loginPage(loginPage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> showDefaultSubmitPage(boolean show) {
/* 275 */     this.submitPageEnabled = show;
/* 276 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> defaultSubmitPageUrl(String submitPageUrl) {
/* 287 */     Assert.hasText(submitPageUrl, "submitPageUrl cannot be null or empty");
/* 288 */     this.defaultSubmitPageUrl = submitPageUrl;
/* 289 */     showDefaultSubmitPage(true);
/* 290 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> tokenService(OneTimeTokenService oneTimeTokenService) {
/* 299 */     Assert.notNull(oneTimeTokenService, "oneTimeTokenService cannot be null");
/* 300 */     this.oneTimeTokenService = oneTimeTokenService;
/* 301 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> authenticationConverter(AuthenticationConverter authenticationConverter) {
/* 311 */     Assert.notNull(authenticationConverter, "authenticationConverter cannot be null");
/* 312 */     ((OneTimeTokenAuthenticationFilter)getAuthenticationFilter()).setAuthenticationConverter(authenticationConverter);
/* 313 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.5")
/*     */   public OneTimeTokenLoginConfigurer<H> authenticationFailureHandler(AuthenticationFailureHandler authenticationFailureHandler) {
/* 327 */     Assert.notNull(authenticationFailureHandler, "authenticationFailureHandler cannot be null");
/* 328 */     failureHandler(authenticationFailureHandler);
/* 329 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.5")
/*     */   public OneTimeTokenLoginConfigurer<H> authenticationSuccessHandler(AuthenticationSuccessHandler authenticationSuccessHandler) {
/* 342 */     Assert.notNull(authenticationSuccessHandler, "authenticationSuccessHandler cannot be null");
/* 343 */     successHandler(authenticationSuccessHandler);
/* 344 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OneTimeTokenLoginConfigurer<H> generateRequestResolver(GenerateOneTimeTokenRequestResolver requestResolver) {
/* 355 */     Assert.notNull(requestResolver, "requestResolver cannot be null");
/* 356 */     this.requestResolver = requestResolver;
/* 357 */     return this;
/*     */   }
/*     */   
/*     */   private GenerateOneTimeTokenRequestResolver getGenerateRequestResolver() {
/* 361 */     if (this.requestResolver != null) {
/* 362 */       return this.requestResolver;
/*     */     }
/* 364 */     this
/* 365 */       .requestResolver = (GenerateOneTimeTokenRequestResolver)this.context.getBeanProvider(GenerateOneTimeTokenRequestResolver.class).getIfUnique(org.springframework.security.web.authentication.ott.DefaultGenerateOneTimeTokenRequestResolver::new);
/* 366 */     return this.requestResolver;
/*     */   }
/*     */   
/*     */   private OneTimeTokenService getOneTimeTokenService() {
/* 370 */     if (this.oneTimeTokenService != null) {
/* 371 */       return this.oneTimeTokenService;
/*     */     }
/* 373 */     this
/* 374 */       .oneTimeTokenService = (OneTimeTokenService)this.context.getBeanProvider(OneTimeTokenService.class).getIfUnique(org.springframework.security.authentication.ott.InMemoryOneTimeTokenService::new);
/* 375 */     return this.oneTimeTokenService;
/*     */   }
/*     */   
/*     */   private Map<String, String> hiddenInputs(HttpServletRequest request) {
/* 379 */     CsrfToken token = (CsrfToken)request.getAttribute(CsrfToken.class.getName());
/* 380 */     return (token != null) ? Collections.<String, String>singletonMap(token.getParameterName(), token.getToken()) : 
/* 381 */       Collections.<String, String>emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ApplicationContext getContext() {
/* 389 */     return this.context;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\ott\OneTimeTokenLoginConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */