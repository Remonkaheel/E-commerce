/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.ChannelSecurityConfigurer;
/*     */ import org.springframework.security.web.access.channel.ChannelProcessor;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(message = "since 6.5 use redirectToHttps instead")
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000V\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020 \n\002\030\002\n\002\b\005\n\002\020!\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\006\n\002\030\002\n\000\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\031\032\030\022\016\022\f0\033R\b\022\004\022\0020\0350\034\022\004\022\0020\0360\032H\000¢\006\002\b\037J\030\020 \032\0020\0362\006\020!\032\0020\0042\b\b\002\020\"\032\0020\004J \020 \032\0020\0362\006\020!\032\0020\0042\006\020#\032\0020\0042\b\b\002\020\"\032\0020\004J\032\020 \032\0020\0362\b\b\002\020$\032\0020%2\b\b\002\020\"\032\0020\004R\016\020\003\032\0020\004XD¢\006\002\n\000R\016\020\005\032\0020\004XD¢\006\002\n\000R\016\020\006\032\0020\007X\004¢\006\002\n\000R\016\020\b\032\0020\tX\004¢\006\002\n\000R\"\020\n\032\n\022\004\022\0020\f\030\0010\013X\016¢\006\016\n\000\032\004\b\r\020\016\"\004\b\017\020\020R\024\020\021\032\b\022\004\022\0020\0230\022X\004¢\006\002\n\000R\024\020\024\032\0020\004XD¢\006\b\n\000\032\004\b\025\020\026R\024\020\027\032\0020\004XD¢\006\b\n\000\032\004\b\030\020\026¨\006&"}, d2 = {"Lorg/springframework/security/config/annotation/web/RequiresChannelDsl;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl;", "()V", "HANDLER_MAPPING_INTROSPECTOR", "", "HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME", "MVC_PRESENT", "", "PATTERN_TYPE", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "channelProcessors", "", "Lorg/springframework/security/web/access/channel/ChannelProcessor;", "getChannelProcessors", "()Ljava/util/List;", "setChannelProcessors", "(Ljava/util/List;)V", "channelSecurityRules", "", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationRule;", "requiresInsecure", "getRequiresInsecure", "()Ljava/lang/String;", "requiresSecure", "getRequiresSecure", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/ChannelSecurityConfigurer$ChannelRequestMatcherRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/ChannelSecurityConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "secure", "pattern", "attribute", "servletPath", "matches", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "spring-security-config"})
/*     */ public final class RequiresChannelDsl
/*     */   extends AbstractRequestMatcherDsl
/*     */ {
/*     */   @NotNull
/*  40 */   private final List<AbstractRequestMatcherDsl.AuthorizationRule> channelSecurityRules = new ArrayList<>();
/*     */   @NotNull
/*  42 */   private final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector"; @NotNull
/*  43 */   private final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*  44 */   private final boolean MVC_PRESENT = ClassUtils.isPresent(
/*  45 */       this.HANDLER_MAPPING_INTROSPECTOR, 
/*  46 */       RequiresChannelDsl.class.getClassLoader()); @NotNull
/*  47 */   private final AbstractRequestMatcherDsl.PatternType PATTERN_TYPE = this.MVC_PRESENT ? AbstractRequestMatcherDsl.PatternType.MVC : AbstractRequestMatcherDsl.PatternType.ANT; @Nullable
/*     */   private List<? extends ChannelProcessor> channelProcessors; @Nullable
/*  49 */   public final List<ChannelProcessor> getChannelProcessors() { return (List)this.channelProcessors; } public final void setChannelProcessors(@Nullable List<? extends ChannelProcessor> <set-?>) { this.channelProcessors = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void secure(@NotNull RequestMatcher matches, @NotNull String attribute) {
/*  60 */     Intrinsics.checkNotNullParameter(matches, "matches"); Intrinsics.checkNotNullParameter(attribute, "attribute"); this.channelSecurityRules.add(new AbstractRequestMatcherDsl.MatcherAuthorizationRule(matches, attribute));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void secure(@NotNull String pattern, @NotNull String attribute) {
/*  79 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(attribute, "attribute"); this.channelSecurityRules.add(new AbstractRequestMatcherDsl.PatternAuthorizationRule(pattern, 
/*  80 */           this.PATTERN_TYPE, null, null, 
/*  81 */           attribute, 12, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void secure(@NotNull String pattern, @NotNull String servletPath, @NotNull String attribute) {
/* 102 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(servletPath, "servletPath"); Intrinsics.checkNotNullParameter(attribute, "attribute"); this.channelSecurityRules.add(new AbstractRequestMatcherDsl.PatternAuthorizationRule(pattern, 
/* 103 */           this.PATTERN_TYPE, 
/* 104 */           servletPath, null, 
/* 105 */           attribute, 8, null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 111 */   private final String requiresSecure = "REQUIRES_SECURE_CHANNEL"; @NotNull public final String getRequiresSecure() { return this.requiresSecure; }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 116 */   private final String requiresInsecure = "REQUIRES_INSECURE_CHANNEL"; @NotNull public final String getRequiresInsecure() { return this.requiresInsecure; }
/*     */   
/*     */   @NotNull
/* 119 */   public final Function1<ChannelSecurityConfigurer<HttpSecurity>.ChannelRequestMatcherRegistry, Unit> get$spring_security_config() { return new RequiresChannelDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "channelSecurity", "Lorg/springframework/security/config/annotation/web/configurers/ChannelSecurityConfigurer$ChannelRequestMatcherRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/ChannelSecurityConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nRequiresChannelDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RequiresChannelDsl.kt\norg/springframework/security/config/annotation/web/RequiresChannelDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,142:1\n1#2:143\n1863#3,2:144\n*S KotlinDebug\n*F\n+ 1 RequiresChannelDsl.kt\norg/springframework/security/config/annotation/web/RequiresChannelDsl$get$1\n*L\n121#1:144,2\n*E\n"})
/* 120 */   static final class RequiresChannelDsl$get$1 extends Lambda implements Function1<ChannelSecurityConfigurer<HttpSecurity>.ChannelRequestMatcherRegistry, Unit> { public final void invoke(ChannelSecurityConfigurer.ChannelRequestMatcherRegistry channelSecurity) { Intrinsics.checkNotNullParameter(channelSecurity, "channelSecurity"); if (RequiresChannelDsl.this.getChannelProcessors() != null) { List<ChannelProcessor> list1 = RequiresChannelDsl.this.getChannelProcessors(); RequiresChannelDsl requiresChannelDsl1 = RequiresChannelDsl.this; List<ChannelProcessor> it = list1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 143 */         int $i$a$-also-RequiresChannelDsl$get$1$1 = 0; channelSecurity.channelProcessors(requiresChannelDsl1.getChannelProcessors()); } else { RequiresChannelDsl.this.getChannelProcessors(); }
/* 144 */        List list = RequiresChannelDsl.this.channelSecurityRules; RequiresChannelDsl requiresChannelDsl = RequiresChannelDsl.this; int $i$f$forEach = 0; Iterator iterator = list.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); AbstractRequestMatcherDsl.AuthorizationRule rule = (AbstractRequestMatcherDsl.AuthorizationRule)element$iv; int $i$a$-forEach-RequiresChannelDsl$get$1$2 = 0;
/*     */         AbstractRequestMatcherDsl.AuthorizationRule authorizationRule1 = rule; }
/*     */        }
/*     */ 
/*     */     
/*     */     RequiresChannelDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RequiresChannelDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */