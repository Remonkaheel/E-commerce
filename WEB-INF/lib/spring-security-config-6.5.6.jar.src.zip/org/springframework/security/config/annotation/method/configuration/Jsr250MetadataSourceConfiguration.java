/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.security.access.annotation.Jsr250MethodSecurityMetadataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ @Deprecated
/*    */ class Jsr250MetadataSourceConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Role(2)
/*    */   Jsr250MethodSecurityMetadataSource jsr250MethodSecurityMetadataSource() {
/* 33 */     return new Jsr250MethodSecurityMetadataSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\Jsr250MetadataSourceConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */