/*     */ package org.springframework.security.config.annotation.web.reactive;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Scope;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*     */ import org.springframework.security.authentication.UserDetailsRepositoryReactiveAuthenticationManager;
/*     */ import org.springframework.security.authentication.password.ReactiveCompromisedPasswordChecker;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.web.server.ServerHttpSecurity;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.userdetails.ReactiveUserDetailsPasswordService;
/*     */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.security.web.reactive.result.method.annotation.AuthenticationPrincipalArgumentResolver;
/*     */ import org.springframework.security.web.reactive.result.method.annotation.CurrentSecurityContextArgumentResolver;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*     */ import org.springframework.web.reactive.result.method.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.reactive.result.method.annotation.ArgumentResolverConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class ServerHttpSecurityConfiguration
/*     */ {
/*     */   private static final String BEAN_NAME_PREFIX = "org.springframework.security.config.annotation.web.reactive.HttpSecurityConfiguration.";
/*     */   private static final String HTTPSECURITY_BEAN_NAME = "org.springframework.security.config.annotation.web.reactive.HttpSecurityConfiguration.httpSecurity";
/*  58 */   private ReactiveAdapterRegistry adapterRegistry = new ReactiveAdapterRegistry();
/*     */   
/*     */   private ReactiveAuthenticationManager authenticationManager;
/*     */   
/*     */   private ReactiveUserDetailsService reactiveUserDetailsService;
/*     */   
/*     */   private PasswordEncoder passwordEncoder;
/*     */   
/*     */   private ReactiveUserDetailsPasswordService userDetailsPasswordService;
/*     */   
/*     */   private ReactiveCompromisedPasswordChecker compromisedPasswordChecker;
/*     */   
/*  70 */   private ObjectPostProcessor<ReactiveAuthenticationManager> postProcessor = ObjectPostProcessor.identity();
/*     */   
/*     */   @Autowired(required = false)
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setAdapterRegistry(ReactiveAdapterRegistry adapterRegistry) {
/*  77 */     this.adapterRegistry = adapterRegistry;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setAuthenticationManager(ReactiveAuthenticationManager authenticationManager) {
/*  82 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setReactiveUserDetailsService(ReactiveUserDetailsService reactiveUserDetailsService) {
/*  87 */     this.reactiveUserDetailsService = reactiveUserDetailsService;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setPasswordEncoder(PasswordEncoder passwordEncoder) {
/*  92 */     this.passwordEncoder = passwordEncoder;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setUserDetailsPasswordService(ReactiveUserDetailsPasswordService userDetailsPasswordService) {
/*  97 */     this.userDetailsPasswordService = userDetailsPasswordService;
/*     */   }
/*     */ 
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setAuthenticationManagerPostProcessor(Map<String, ObjectPostProcessor<ReactiveAuthenticationManager>> postProcessors) {
/* 103 */     if (postProcessors.size() == 1) {
/* 104 */       this.postProcessor = postProcessors.values().iterator().next();
/*     */     }
/* 106 */     this.postProcessor = postProcessors.get("reactiveAuthenticationManagerPostProcessor");
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setCompromisedPasswordChecker(ReactiveCompromisedPasswordChecker compromisedPasswordChecker) {
/* 111 */     this.compromisedPasswordChecker = compromisedPasswordChecker;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   static WebFluxConfigurer authenticationPrincipalArgumentResolverConfigurer(final ObjectProvider<AuthenticationPrincipalArgumentResolver> authenticationPrincipalArgumentResolver, final ObjectProvider<CurrentSecurityContextArgumentResolver> currentSecurityContextArgumentResolvers) {
/* 118 */     return new WebFluxConfigurer()
/*     */       {
/*     */         public void configureArgumentResolvers(ArgumentResolverConfigurer configurer)
/*     */         {
/* 122 */           configurer.addCustomResolver(new HandlerMethodArgumentResolver[] { (HandlerMethodArgumentResolver)this.val$authenticationPrincipalArgumentResolver.getObject(), (HandlerMethodArgumentResolver)this.val$currentSecurityContextArgumentResolvers
/* 123 */                 .getObject() });
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   AuthenticationPrincipalArgumentResolver authenticationPrincipalArgumentResolver(ObjectProvider<AnnotationTemplateExpressionDefaults> templateDefaults) {
/* 132 */     AuthenticationPrincipalArgumentResolver resolver = new AuthenticationPrincipalArgumentResolver(this.adapterRegistry);
/*     */     
/* 134 */     if (this.beanFactory != null) {
/* 135 */       resolver.setBeanResolver((BeanResolver)new BeanFactoryResolver(this.beanFactory));
/*     */     }
/* 137 */     Objects.requireNonNull(resolver); templateDefaults.ifAvailable(resolver::setTemplateDefaults);
/* 138 */     return resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   CurrentSecurityContextArgumentResolver reactiveCurrentSecurityContextArgumentResolver(ObjectProvider<AnnotationTemplateExpressionDefaults> templateDefaults) {
/* 144 */     CurrentSecurityContextArgumentResolver resolver = new CurrentSecurityContextArgumentResolver(this.adapterRegistry);
/*     */     
/* 146 */     if (this.beanFactory != null) {
/* 147 */       resolver.setBeanResolver((BeanResolver)new BeanFactoryResolver(this.beanFactory));
/*     */     }
/* 149 */     Objects.requireNonNull(resolver); templateDefaults.ifAvailable(resolver::setTemplateDefaults);
/* 150 */     return resolver;
/*     */   }
/*     */   
/*     */   @Bean({"org.springframework.security.config.annotation.web.reactive.HttpSecurityConfiguration.httpSecurity"})
/*     */   @Scope("prototype")
/*     */   ServerHttpSecurity httpSecurity() {
/* 156 */     ContextAwareServerHttpSecurity http = new ContextAwareServerHttpSecurity();
/*     */     
/* 158 */     return http.authenticationManager(authenticationManager())
/* 159 */       .headers().and()
/* 160 */       .logout().and();
/*     */   }
/*     */ 
/*     */   
/*     */   private ReactiveAuthenticationManager authenticationManager() {
/* 165 */     if (this.authenticationManager != null) {
/* 166 */       return this.authenticationManager;
/*     */     }
/* 168 */     if (this.reactiveUserDetailsService != null) {
/* 169 */       UserDetailsRepositoryReactiveAuthenticationManager manager = new UserDetailsRepositoryReactiveAuthenticationManager(this.reactiveUserDetailsService);
/*     */       
/* 171 */       if (this.passwordEncoder != null) {
/* 172 */         manager.setPasswordEncoder(this.passwordEncoder);
/*     */       }
/* 174 */       manager.setUserDetailsPasswordService(this.userDetailsPasswordService);
/* 175 */       manager.setCompromisedPasswordChecker(this.compromisedPasswordChecker);
/* 176 */       return (ReactiveAuthenticationManager)this.postProcessor.postProcess(manager);
/*     */     } 
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   private static class ContextAwareServerHttpSecurity
/*     */     extends ServerHttpSecurity
/*     */     implements ApplicationContextAware {
/*     */     public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 185 */       super.setApplicationContext(applicationContext);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ServerHttpSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */