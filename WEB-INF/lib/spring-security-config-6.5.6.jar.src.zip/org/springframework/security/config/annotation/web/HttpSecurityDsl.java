/*      */ package org.springframework.security.config.annotation.web;
/*      */ 
/*      */ import jakarta.servlet.Filter;
/*      */ import java.util.Arrays;
/*      */ import kotlin.Deprecated;
/*      */ import kotlin.Metadata;
/*      */ import kotlin.Unit;
/*      */ import kotlin.jvm.functions.Function1;
/*      */ import kotlin.jvm.internal.Intrinsics;
/*      */ import kotlin.jvm.internal.Lambda;
/*      */ import kotlin.jvm.internal.SourceDebugExtension;
/*      */ import org.jetbrains.annotations.NotNull;
/*      */ import org.jetbrains.annotations.Nullable;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.security.authentication.AuthenticationManager;
/*      */ import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
/*      */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*      */ import org.springframework.security.config.annotation.web.configurers.AnonymousConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.ChannelSecurityConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.CorsConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.ExceptionHandlingConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.FormLoginConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.HttpBasicConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.HttpsRedirectConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.PasswordManagementConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.PortMapperConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.RememberMeConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.RequestCacheConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.SecurityContextConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.WebAuthnConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.X509Configurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2ClientConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OidcLogoutConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.ott.OneTimeTokenLoginConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LoginConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2MetadataConfigurer;
/*      */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*      */ 
/*      */ 
/*      */ @SecurityMarker
/*      */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000À\002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\021\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\b\007\030\0002\0020\001B&\022\006\020\002\032\0020\003\022\027\020\004\032\023\022\004\022\0020\000\022\004\022\0020\0060\005¢\006\002\b\007¢\006\002\020\bJ\035\020\025\032\0020\006\"\n\b\000\020\026\030\001*\0020\0272\006\020\030\032\0020\027H\bJ \020\025\032\0020\0062\006\020\030\032\0020\0272\016\020\031\032\n\022\006\b\001\022\0020\0270\032H\007J\035\020\033\032\0020\006\"\n\b\000\020\026\030\001*\0020\0272\006\020\030\032\0020\027H\bJ \020\033\032\0020\0062\006\020\030\032\0020\0272\016\020\034\032\n\022\006\b\001\022\0020\0270\032H\007J\035\020\035\032\0020\006\"\n\b\000\020\026\030\001*\0020\0272\006\020\030\032\0020\027H\bJ \020\035\032\0020\0062\006\020\030\032\0020\0272\016\020\036\032\n\022\006\b\001\022\0020\0270\032H\007J\037\020\037\032\0020\0062\027\020 \032\023\022\004\022\0020!\022\004\022\0020\0060\005¢\006\002\b\007JD\020\"\032\002H#\"\024\b\000\020#*\016\022\004\022\0020%\022\004\022\0020\0030$2\006\020&\032\002H#2\031\b\002\020'\032\023\022\004\022\002H#\022\004\022\0020\0060\005¢\006\002\b\007¢\006\002\020(J\037\020)\032\0020\0062\027\020*\032\023\022\004\022\0020+\022\004\022\0020\0060\005¢\006\002\b\007J!\020,\032\0020\0062\027\020-\032\023\022\004\022\0020.\022\004\022\0020\0060\005¢\006\002\b\007H\007J\r\020/\032\0020\006H\000¢\006\002\b0J\037\0201\032\0020\0062\027\0202\032\023\022\004\022\00203\022\004\022\0020\0060\005¢\006\002\b\007J\037\0204\032\0020\0062\027\0205\032\023\022\004\022\00206\022\004\022\0020\0060\005¢\006\002\b\007J\037\0207\032\0020\0062\027\0208\032\023\022\004\022\00209\022\004\022\0020\0060\005¢\006\002\b\007J\037\020:\032\0020\0062\027\020;\032\023\022\004\022\0020<\022\004\022\0020\0060\005¢\006\002\b\007J\037\020=\032\0020\0062\027\020>\032\023\022\004\022\0020?\022\004\022\0020\0060\005¢\006\002\b\007J\037\020@\032\0020\0062\027\020A\032\023\022\004\022\0020B\022\004\022\0020\0060\005¢\006\002\b\007J\037\020C\032\0020\0062\027\020D\032\023\022\004\022\0020E\022\004\022\0020\0060\005¢\006\002\b\007J\037\020F\032\0020\0062\027\020G\032\023\022\004\022\0020H\022\004\022\0020\0060\005¢\006\002\b\007J\037\020I\032\0020\0062\027\020J\032\023\022\004\022\0020K\022\004\022\0020\0060\005¢\006\002\b\007J\037\020L\032\0020\0062\027\020M\032\023\022\004\022\0020N\022\004\022\0020\0060\005¢\006\002\b\007J\037\020O\032\0020\0062\027\020P\032\023\022\004\022\0020Q\022\004\022\0020\0060\005¢\006\002\b\007J\037\020R\032\0020\0062\027\020S\032\023\022\004\022\0020T\022\004\022\0020\0060\005¢\006\002\b\007J\037\020U\032\0020\0062\027\020V\032\023\022\004\022\0020W\022\004\022\0020\0060\005¢\006\002\b\007J\037\020X\032\0020\0062\027\020Y\032\023\022\004\022\0020Z\022\004\022\0020\0060\005¢\006\002\b\007J\037\020[\032\0020\0062\027\020\\\032\023\022\004\022\0020]\022\004\022\0020\0060\005¢\006\002\b\007J\037\020^\032\0020\0062\027\020_\032\023\022\004\022\0020`\022\004\022\0020\0060\005¢\006\002\b\007J\037\020a\032\0020\0062\027\020b\032\023\022\004\022\0020c\022\004\022\0020\0060\005¢\006\002\b\007J!\020d\032\0020\0062\027\020e\032\023\022\004\022\0020f\022\004\022\0020\0060\005¢\006\002\b\007H\007J\037\020g\032\0020\0062\027\020h\032\023\022\004\022\0020i\022\004\022\0020\0060\005¢\006\002\b\007J\037\020j\032\0020\0062\027\020k\032\023\022\004\022\0020l\022\004\022\0020\0060\005¢\006\002\b\007J\037\020m\032\0020\0062\027\020n\032\023\022\004\022\0020o\022\004\022\0020\0060\005¢\006\002\b\007J\037\020p\032\0020\0062\027\020q\032\023\022\004\022\0020r\022\004\022\0020\0060\005¢\006\002\b\007J\037\020s\032\0020\0062\022\020t\032\n\022\006\b\001\022\0020\n0u\"\0020\n¢\006\002\020vJ\037\020s\032\0020\0062\022\020w\032\n\022\006\b\001\022\0020x0u\"\0020x¢\006\002\020yJ\037\020z\032\0020\0062\027\020{\032\023\022\004\022\0020|\022\004\022\0020\0060\005¢\006\002\b\007J\037\020}\032\0020\0062\027\020~\032\023\022\004\022\0020\022\004\022\0020\0060\005¢\006\002\b\007JH\020\001\032\004\030\0010\003\"\024\b\000\020#*\016\022\004\022\0020%\022\004\022\0020\0030$2\006\020&\032\002H#2\031\b\002\020'\032\023\022\004\022\002H#\022\004\022\0020\0060\005¢\006\002\b\007¢\006\003\020\001J\"\020\001\032\0020\0062\031\020\001\032\024\022\005\022\0030\001\022\004\022\0020\0060\005¢\006\002\b\007R\016\020\t\032\0020\nXD¢\006\002\n\000R\034\020\013\032\004\030\0010\fX\016¢\006\016\n\000\032\004\b\r\020\016\"\004\b\017\020\020R\021\020\021\032\0020\022¢\006\b\n\000\032\004\b\023\020\024R\016\020\002\032\0020\003X\004¢\006\002\n\000R\037\020\004\032\023\022\004\022\0020\000\022\004\022\0020\0060\005¢\006\002\b\007X\004¢\006\002\n\000¨\006\001"}, d2 = {"Lorg/springframework/security/config/annotation/web/HttpSecurityDsl;", "", "http", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "init", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "(Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;Lkotlin/jvm/functions/Function1;)V", "HANDLER_MAPPING_INTROSPECTOR", "", "authenticationManager", "Lorg/springframework/security/authentication/AuthenticationManager;", "getAuthenticationManager", "()Lorg/springframework/security/authentication/AuthenticationManager;", "setAuthenticationManager", "(Lorg/springframework/security/authentication/AuthenticationManager;)V", "context", "Lorg/springframework/context/ApplicationContext;", "getContext", "()Lorg/springframework/context/ApplicationContext;", "addFilterAfter", "T", "Ljakarta/servlet/Filter;", "filter", "afterFilter", "Ljava/lang/Class;", "addFilterAt", "atFilter", "addFilterBefore", "beforeFilter", "anonymous", "anonymousConfiguration", "Lorg/springframework/security/config/annotation/web/AnonymousDsl;", "apply", "C", "Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;", "Lorg/springframework/security/web/DefaultSecurityFilterChain;", "configurer", "configuration", "(Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;Lkotlin/jvm/functions/Function1;)Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;", "authorizeHttpRequests", "authorizeHttpRequestsConfiguration", "Lorg/springframework/security/config/annotation/web/AuthorizeHttpRequestsDsl;", "authorizeRequests", "authorizeRequestsConfiguration", "Lorg/springframework/security/config/annotation/web/AuthorizeRequestsDsl;", "build", "build$spring_security_config", "cors", "corsConfiguration", "Lorg/springframework/security/config/annotation/web/CorsDsl;", "csrf", "csrfConfiguration", "Lorg/springframework/security/config/annotation/web/CsrfDsl;", "exceptionHandling", "exceptionHandlingConfiguration", "Lorg/springframework/security/config/annotation/web/ExceptionHandlingDsl;", "formLogin", "formLoginConfiguration", "Lorg/springframework/security/config/annotation/web/FormLoginDsl;", "headers", "headersConfiguration", "Lorg/springframework/security/config/annotation/web/HeadersDsl;", "httpBasic", "httpBasicConfiguration", "Lorg/springframework/security/config/annotation/web/HttpBasicDsl;", "logout", "logoutConfiguration", "Lorg/springframework/security/config/annotation/web/LogoutDsl;", "oauth2Client", "oauth2ClientConfiguration", "Lorg/springframework/security/config/annotation/web/OAuth2ClientDsl;", "oauth2Login", "oauth2LoginConfiguration", "Lorg/springframework/security/config/annotation/web/OAuth2LoginDsl;", "oauth2ResourceServer", "oauth2ResourceServerConfiguration", "Lorg/springframework/security/config/annotation/web/OAuth2ResourceServerDsl;", "oidcLogout", "oidcLogoutConfiguration", "Lorg/springframework/security/config/annotation/web/OidcLogoutDsl;", "oneTimeTokenLogin", "oneTimeTokenLoginConfiguration", "Lorg/springframework/security/config/annotation/web/OneTimeTokenLoginDsl;", "passwordManagement", "passwordManagementConfiguration", "Lorg/springframework/security/config/annotation/web/PasswordManagementDsl;", "portMapper", "portMapperConfiguration", "Lorg/springframework/security/config/annotation/web/PortMapperDsl;", "redirectToHttps", "httpsRedirectConfiguration", "Lorg/springframework/security/config/annotation/web/HttpsRedirectDsl;", "rememberMe", "rememberMeConfiguration", "Lorg/springframework/security/config/annotation/web/RememberMeDsl;", "requestCache", "requestCacheConfiguration", "Lorg/springframework/security/config/annotation/web/RequestCacheDsl;", "requiresChannel", "requiresChannelConfiguration", "Lorg/springframework/security/config/annotation/web/RequiresChannelDsl;", "saml2Login", "saml2LoginConfiguration", "Lorg/springframework/security/config/annotation/web/Saml2Dsl;", "saml2Logout", "saml2LogoutConfiguration", "Lorg/springframework/security/config/annotation/web/Saml2LogoutDsl;", "saml2Metadata", "saml2MetadataConfiguration", "Lorg/springframework/security/config/annotation/web/Saml2MetadataDsl;", "securityContext", "securityContextConfiguration", "Lorg/springframework/security/config/annotation/web/SecurityContextDsl;", "securityMatcher", "pattern", "", "([Ljava/lang/String;)V", "requestMatcher", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "([Lorg/springframework/security/web/util/matcher/RequestMatcher;)V", "sessionManagement", "sessionManagementConfiguration", "Lorg/springframework/security/config/annotation/web/SessionManagementDsl;", "webAuthn", "webAuthnConfiguration", "Lorg/springframework/security/config/annotation/web/WebAuthnDsl;", "with", "(Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;Lkotlin/jvm/functions/Function1;)Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "x509", "x509Configuration", "Lorg/springframework/security/config/annotation/web/X509Dsl;", "spring-security-config"})
/*      */ @SourceDebugExtension({"SMAP\nHttpSecurityDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpSecurityDsl.kt\norg/springframework/security/config/annotation/web/HttpSecurityDsl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1316:1\n1#2:1317\n*E\n"})
/*      */ public final class HttpSecurityDsl
/*      */ {
/*      */   @NotNull
/*      */   private final HttpSecurity http;
/*      */   @NotNull
/*      */   private final Function1<HttpSecurityDsl, Unit> init;
/*      */   @NotNull
/*      */   private final String HANDLER_MAPPING_INTROSPECTOR;
/*      */   @Nullable
/*      */   private AuthenticationManager authenticationManager;
/*      */   @NotNull
/*      */   private final ApplicationContext context;
/*      */   
/*      */   @Nullable
/*      */   public final AuthenticationManager getAuthenticationManager() {
/*      */     return this.authenticationManager;
/*      */   }
/*      */   
/*      */   public final void setAuthenticationManager(@Nullable AuthenticationManager <set-?>) {
/*      */     this.authenticationManager = <set-?>;
/*      */   }
/*      */   
/*      */   public HttpSecurityDsl(@NotNull HttpSecurity http, @NotNull Function1<HttpSecurityDsl, Unit> init) {
/*   75 */     this.http = http; this.init = init;
/*   76 */     this.HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*      */ 
/*      */     
/*   79 */     Intrinsics.checkNotNullExpressionValue(this.http.getSharedObject(ApplicationContext.class), "http.getSharedObject(App…ationContext::class.java)"); this.context = (ApplicationContext)this.http.getSharedObject(ApplicationContext.class); } @NotNull public final ApplicationContext getContext() { return this.context; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\030\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\020\000\032\0020\001\"\024\b\000\020\002*\016\022\004\022\0020\004\022\004\022\0020\0050\003*\002H\002H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "C", "Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;", "Lorg/springframework/security/web/DefaultSecurityFilterChain;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke", "(Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;)V"})
/*      */   static final class HttpSecurityDsl$apply$1
/*      */     extends Lambda
/*      */     implements Function1<C, Unit>
/*      */   {
/*      */     public static final HttpSecurityDsl$apply$1 INSTANCE = new HttpSecurityDsl$apply$1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     HttpSecurityDsl$apply$1() {
/*      */       super(1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void invoke(SecurityConfigurerAdapter $this$null)
/*      */     {
/*  108 */       Intrinsics.checkNotNullParameter($this$null, "$this$null"); } } @NotNull
/*      */   public final <C extends SecurityConfigurerAdapter<org.springframework.security.web.DefaultSecurityFilterChain, HttpSecurity>> C apply(@NotNull SecurityConfigurerAdapter configurer, @NotNull Function1 configuration) {
/*  110 */     Intrinsics.checkNotNullParameter(configurer, "configurer"); Intrinsics.checkNotNullParameter(configuration, "configuration"); SecurityConfigurerAdapter securityConfigurerAdapter = this.http.apply(configurer); configuration.invoke(securityConfigurerAdapter); Intrinsics.checkNotNullExpressionValue(securityConfigurerAdapter, "this.http.apply(configurer).apply(configuration)"); return (C)securityConfigurerAdapter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\030\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\020\000\032\0020\001\"\024\b\000\020\002*\016\022\004\022\0020\004\022\004\022\0020\0050\003*\002H\002H\n¢\006\004\b\006\020\007"}, d2 = {"<anonymous>", "", "C", "Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;", "Lorg/springframework/security/web/DefaultSecurityFilterChain;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke", "(Lorg/springframework/security/config/annotation/SecurityConfigurerAdapter;)V"})
/*      */   static final class HttpSecurityDsl$with$1
/*      */     extends Lambda
/*      */     implements Function1<C, Unit>
/*      */   {
/*      */     public static final HttpSecurityDsl$with$1 INSTANCE = new HttpSecurityDsl$with$1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     HttpSecurityDsl$with$1() {
/*      */       super(1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void invoke(SecurityConfigurerAdapter $this$null) {
/*  141 */       Intrinsics.checkNotNullParameter($this$null, "$this$null");
/*      */     } } @Nullable
/*  143 */   public final <C extends SecurityConfigurerAdapter<org.springframework.security.web.DefaultSecurityFilterChain, HttpSecurity>> HttpSecurity with(@NotNull SecurityConfigurerAdapter configurer, @NotNull Function1 configuration) { Intrinsics.checkNotNullParameter(configurer, "configurer"); Intrinsics.checkNotNullParameter(configuration, "configuration"); return (HttpSecurity)this.http.with(configurer, configuration::with$lambda$0); } private static final void with$lambda$0(Function1 $tmp0, SecurityConfigurerAdapter t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void securityMatcher(@NotNull String... pattern)
/*      */   {
/*  176 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); this.http.securityMatchers(pattern::securityMatcher$lambda$1); } private static final void securityMatcher$lambda$1(String[] $pattern, HttpSecurity.RequestMatcherConfigurer it) {
/*  177 */     it.requestMatchers(Arrays.<String>copyOf($pattern, $pattern.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void securityMatcher(@NotNull RequestMatcher... requestMatcher)
/*      */   {
/*  209 */     Intrinsics.checkNotNullParameter(requestMatcher, "requestMatcher"); this.http.securityMatchers(requestMatcher::securityMatcher$lambda$2); } private static final void securityMatcher$lambda$2(RequestMatcher[] $requestMatcher, HttpSecurity.RequestMatcherConfigurer it) {
/*  210 */     it.requestMatchers(Arrays.<RequestMatcher>copyOf($requestMatcher, $requestMatcher.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void formLogin(@NotNull Function1 formLoginConfiguration)
/*      */   {
/*  241 */     Intrinsics.checkNotNullParameter(formLoginConfiguration, "formLoginConfiguration"); FormLoginDsl formLoginDsl = new FormLoginDsl(); formLoginConfiguration.invoke(formLoginDsl); Function1<FormLoginConfigurer<HttpSecurity>, Unit> loginCustomizer = formLoginDsl.get$spring_security_config();
/*  242 */     this.http.formLogin(loginCustomizer::formLogin$lambda$3); } private static final void formLogin$lambda$3(Function1 $tmp0, FormLoginConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(message = "Since 6.4. Use authorizeHttpRequests instead")
/*      */   public final void authorizeRequests(@NotNull Function1 authorizeRequestsConfiguration)
/*      */   {
/*  274 */     Intrinsics.checkNotNullParameter(authorizeRequestsConfiguration, "authorizeRequestsConfiguration"); AuthorizeRequestsDsl authorizeRequestsDsl = new AuthorizeRequestsDsl(); authorizeRequestsConfiguration.invoke(authorizeRequestsDsl); Function1<ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry, Unit> authorizeRequestsCustomizer = authorizeRequestsDsl.get$spring_security_config();
/*  275 */     this.http.authorizeRequests(authorizeRequestsCustomizer::authorizeRequests$lambda$4); } private static final void authorizeRequests$lambda$4(Function1 $tmp0, ExpressionUrlAuthorizationConfigurer.ExpressionInterceptUrlRegistry t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void authorizeHttpRequests(@NotNull Function1 authorizeHttpRequestsConfiguration)
/*      */   {
/*  308 */     Intrinsics.checkNotNullParameter(authorizeHttpRequestsConfiguration, "authorizeHttpRequestsConfiguration"); AuthorizeHttpRequestsDsl authorizeHttpRequestsDsl = new AuthorizeHttpRequestsDsl(this.context); authorizeHttpRequestsConfiguration.invoke(authorizeHttpRequestsDsl); Function1<AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizationManagerRequestMatcherRegistry, Unit> authorizeHttpRequestsCustomizer = authorizeHttpRequestsDsl.get$spring_security_config();
/*  309 */     this.http.authorizeHttpRequests(authorizeHttpRequestsCustomizer::authorizeHttpRequests$lambda$5); } private static final void authorizeHttpRequests$lambda$5(Function1 $tmp0, AuthorizeHttpRequestsConfigurer.AuthorizationManagerRequestMatcherRegistry t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void httpBasic(@NotNull Function1 httpBasicConfiguration)
/*      */   {
/*  339 */     Intrinsics.checkNotNullParameter(httpBasicConfiguration, "httpBasicConfiguration"); HttpBasicDsl httpBasicDsl = new HttpBasicDsl(); httpBasicConfiguration.invoke(httpBasicDsl); Function1<HttpBasicConfigurer<HttpSecurity>, Unit> httpBasicCustomizer = httpBasicDsl.get$spring_security_config();
/*  340 */     this.http.httpBasic(httpBasicCustomizer::httpBasic$lambda$6); } private static final void httpBasic$lambda$6(Function1 $tmp0, HttpBasicConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void passwordManagement(@NotNull Function1 passwordManagementConfiguration)
/*      */   {
/*  371 */     Intrinsics.checkNotNullParameter(passwordManagementConfiguration, "passwordManagementConfiguration"); PasswordManagementDsl passwordManagementDsl = new PasswordManagementDsl(); passwordManagementConfiguration.invoke(passwordManagementDsl); Function1<PasswordManagementConfigurer<HttpSecurity>, Unit> passwordManagementCustomizer = passwordManagementDsl.get$spring_security_config();
/*  372 */     this.http.passwordManagement(passwordManagementCustomizer::passwordManagement$lambda$7); } private static final void passwordManagement$lambda$7(Function1 $tmp0, PasswordManagementConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void headers(@NotNull Function1 headersConfiguration)
/*      */   {
/*  404 */     Intrinsics.checkNotNullParameter(headersConfiguration, "headersConfiguration"); HeadersDsl headersDsl = new HeadersDsl(); headersConfiguration.invoke(headersDsl); Function1<HeadersConfigurer<HttpSecurity>, Unit> headersCustomizer = headersDsl.get$spring_security_config();
/*  405 */     this.http.headers(headersCustomizer::headers$lambda$8); } private static final void headers$lambda$8(Function1 $tmp0, HeadersConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void cors(@NotNull Function1 corsConfiguration)
/*      */   {
/*  435 */     Intrinsics.checkNotNullParameter(corsConfiguration, "corsConfiguration"); CorsDsl corsDsl = new CorsDsl(); corsConfiguration.invoke(corsDsl); Function1<CorsConfigurer<HttpSecurity>, Unit> corsCustomizer = corsDsl.get$spring_security_config();
/*  436 */     this.http.cors(corsCustomizer::cors$lambda$9); } private static final void cors$lambda$9(Function1 $tmp0, CorsConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void sessionManagement(@NotNull Function1 sessionManagementConfiguration)
/*      */   {
/*  469 */     Intrinsics.checkNotNullParameter(sessionManagementConfiguration, "sessionManagementConfiguration"); SessionManagementDsl sessionManagementDsl = new SessionManagementDsl(); sessionManagementConfiguration.invoke(sessionManagementDsl); Function1<SessionManagementConfigurer<HttpSecurity>, Unit> sessionManagementCustomizer = sessionManagementDsl.get$spring_security_config();
/*  470 */     this.http.sessionManagement(sessionManagementCustomizer::sessionManagement$lambda$10); } private static final void sessionManagement$lambda$10(Function1 $tmp0, SessionManagementConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void portMapper(@NotNull Function1 portMapperConfiguration)
/*      */   {
/*  500 */     Intrinsics.checkNotNullParameter(portMapperConfiguration, "portMapperConfiguration"); PortMapperDsl portMapperDsl = new PortMapperDsl(); portMapperConfiguration.invoke(portMapperDsl); Function1<PortMapperConfigurer<HttpSecurity>, Unit> portMapperCustomizer = portMapperDsl.get$spring_security_config();
/*  501 */     this.http.portMapper(portMapperCustomizer::portMapper$lambda$11); } private static final void portMapper$lambda$11(Function1 $tmp0, PortMapperConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(message = "since 6.5 use redirectToHttps instead")
/*      */   public final void requiresChannel(@NotNull Function1 requiresChannelConfiguration)
/*      */   {
/*  534 */     Intrinsics.checkNotNullParameter(requiresChannelConfiguration, "requiresChannelConfiguration"); RequiresChannelDsl requiresChannelDsl = new RequiresChannelDsl(); requiresChannelConfiguration.invoke(requiresChannelDsl); Function1<ChannelSecurityConfigurer<HttpSecurity>.ChannelRequestMatcherRegistry, Unit> requiresChannelCustomizer = requiresChannelDsl.get$spring_security_config();
/*  535 */     this.http.requiresChannel(requiresChannelCustomizer::requiresChannel$lambda$12); } private static final void requiresChannel$lambda$12(Function1 $tmp0, ChannelSecurityConfigurer.ChannelRequestMatcherRegistry t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void redirectToHttps(@NotNull Function1 httpsRedirectConfiguration)
/*      */   {
/*  567 */     Intrinsics.checkNotNullParameter(httpsRedirectConfiguration, "httpsRedirectConfiguration"); HttpsRedirectDsl httpsRedirectDsl = new HttpsRedirectDsl(); httpsRedirectConfiguration.invoke(httpsRedirectDsl); Function1<HttpsRedirectConfigurer<HttpSecurity>, Unit> httpsRedirectCustomizer = httpsRedirectDsl.get$spring_security_config();
/*  568 */     this.http.redirectToHttps(httpsRedirectCustomizer::redirectToHttps$lambda$13); } private static final void redirectToHttps$lambda$13(Function1 $tmp0, HttpsRedirectConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void x509(@NotNull Function1 x509Configuration)
/*      */   {
/*  596 */     Intrinsics.checkNotNullParameter(x509Configuration, "x509Configuration"); X509Dsl x509Dsl = new X509Dsl(); x509Configuration.invoke(x509Dsl); Function1<X509Configurer<HttpSecurity>, Unit> x509Customizer = x509Dsl.get$spring_security_config();
/*  597 */     this.http.x509(x509Customizer::x509$lambda$14); } private static final void x509$lambda$14(Function1 $tmp0, X509Configurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void requestCache(@NotNull Function1 requestCacheConfiguration)
/*      */   {
/*  626 */     Intrinsics.checkNotNullParameter(requestCacheConfiguration, "requestCacheConfiguration"); RequestCacheDsl requestCacheDsl = new RequestCacheDsl(); requestCacheConfiguration.invoke(requestCacheDsl); Function1<RequestCacheConfigurer<HttpSecurity>, Unit> requestCacheCustomizer = requestCacheDsl.get$spring_security_config();
/*  627 */     this.http.requestCache(requestCacheCustomizer::requestCache$lambda$15); } private static final void requestCache$lambda$15(Function1 $tmp0, RequestCacheConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void exceptionHandling(@NotNull Function1 exceptionHandlingConfiguration)
/*      */   {
/*  657 */     Intrinsics.checkNotNullParameter(exceptionHandlingConfiguration, "exceptionHandlingConfiguration"); ExceptionHandlingDsl exceptionHandlingDsl = new ExceptionHandlingDsl(); exceptionHandlingConfiguration.invoke(exceptionHandlingDsl); Function1<ExceptionHandlingConfigurer<HttpSecurity>, Unit> exceptionHandlingCustomizer = exceptionHandlingDsl.get$spring_security_config();
/*  658 */     this.http.exceptionHandling(exceptionHandlingCustomizer::exceptionHandling$lambda$16); } private static final void exceptionHandling$lambda$16(Function1 $tmp0, ExceptionHandlingConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void csrf(@NotNull Function1 csrfConfiguration)
/*      */   {
/*  685 */     Intrinsics.checkNotNullParameter(csrfConfiguration, "csrfConfiguration"); CsrfDsl csrfDsl = new CsrfDsl(); csrfConfiguration.invoke(csrfDsl); Function1<CsrfConfigurer<HttpSecurity>, Unit> csrfCustomizer = csrfDsl.get$spring_security_config();
/*  686 */     this.http.csrf(csrfCustomizer::csrf$lambda$17); } private static final void csrf$lambda$17(Function1 $tmp0, CsrfConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void logout(@NotNull Function1 logoutConfiguration)
/*      */   {
/*  715 */     Intrinsics.checkNotNullParameter(logoutConfiguration, "logoutConfiguration"); LogoutDsl logoutDsl = new LogoutDsl(); logoutConfiguration.invoke(logoutDsl); Function1<LogoutConfigurer<HttpSecurity>, Unit> logoutCustomizer = logoutDsl.get$spring_security_config();
/*  716 */     this.http.logout(logoutCustomizer::logout$lambda$18); } private static final void logout$lambda$18(Function1 $tmp0, LogoutConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void saml2Login(@NotNull Function1 saml2LoginConfiguration)
/*      */   {
/*  749 */     Intrinsics.checkNotNullParameter(saml2LoginConfiguration, "saml2LoginConfiguration"); Saml2Dsl saml2Dsl = new Saml2Dsl(); saml2LoginConfiguration.invoke(saml2Dsl); Function1<Saml2LoginConfigurer<HttpSecurity>, Unit> saml2LoginCustomizer = saml2Dsl.get$spring_security_config();
/*  750 */     this.http.saml2Login(saml2LoginCustomizer::saml2Login$lambda$19); } private static final void saml2Login$lambda$19(Function1 $tmp0, Saml2LoginConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void saml2Logout(@NotNull Function1 saml2LogoutConfiguration)
/*      */   {
/*  812 */     Intrinsics.checkNotNullParameter(saml2LogoutConfiguration, "saml2LogoutConfiguration"); Saml2LogoutDsl saml2LogoutDsl = new Saml2LogoutDsl(); saml2LogoutConfiguration.invoke(saml2LogoutDsl); Function1<Saml2LogoutConfigurer<HttpSecurity>, Unit> saml2LogoutCustomizer = saml2LogoutDsl.get$spring_security_config();
/*  813 */     this.http.saml2Logout(saml2LogoutCustomizer::saml2Logout$lambda$20); } private static final void saml2Logout$lambda$20(Function1 $tmp0, Saml2LogoutConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void saml2Metadata(@NotNull Function1 saml2MetadataConfiguration)
/*      */   {
/*  849 */     Intrinsics.checkNotNullParameter(saml2MetadataConfiguration, "saml2MetadataConfiguration"); Saml2MetadataDsl saml2MetadataDsl = new Saml2MetadataDsl(); saml2MetadataConfiguration.invoke(saml2MetadataDsl); Function1<Saml2MetadataConfigurer<HttpSecurity>, Unit> saml2MetadataCustomizer = saml2MetadataDsl.get$spring_security_config();
/*  850 */     this.http.saml2Metadata(saml2MetadataCustomizer::saml2Metadata$lambda$21); } private static final void saml2Metadata$lambda$21(Function1 $tmp0, Saml2MetadataConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void anonymous(@NotNull Function1 anonymousConfiguration)
/*      */   {
/*  880 */     Intrinsics.checkNotNullParameter(anonymousConfiguration, "anonymousConfiguration"); AnonymousDsl anonymousDsl = new AnonymousDsl(); anonymousConfiguration.invoke(anonymousDsl); Function1<AnonymousConfigurer<HttpSecurity>, Unit> anonymousCustomizer = anonymousDsl.get$spring_security_config();
/*  881 */     this.http.anonymous(anonymousCustomizer::anonymous$lambda$22); } private static final void anonymous$lambda$22(Function1 $tmp0, AnonymousConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void oauth2Login(@NotNull Function1 oauth2LoginConfiguration)
/*      */   {
/*  913 */     Intrinsics.checkNotNullParameter(oauth2LoginConfiguration, "oauth2LoginConfiguration"); OAuth2LoginDsl oAuth2LoginDsl = new OAuth2LoginDsl(); oauth2LoginConfiguration.invoke(oAuth2LoginDsl); Function1<OAuth2LoginConfigurer<HttpSecurity>, Unit> oauth2LoginCustomizer = oAuth2LoginDsl.get$spring_security_config();
/*  914 */     this.http.oauth2Login(oauth2LoginCustomizer::oauth2Login$lambda$23); } private static final void oauth2Login$lambda$23(Function1 $tmp0, OAuth2LoginConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void oauth2Client(@NotNull Function1 oauth2ClientConfiguration)
/*      */   {
/*  942 */     Intrinsics.checkNotNullParameter(oauth2ClientConfiguration, "oauth2ClientConfiguration"); OAuth2ClientDsl oAuth2ClientDsl = new OAuth2ClientDsl(); oauth2ClientConfiguration.invoke(oAuth2ClientDsl); Function1<OAuth2ClientConfigurer<HttpSecurity>, Unit> oauth2ClientCustomizer = oAuth2ClientDsl.get$spring_security_config();
/*  943 */     this.http.oauth2Client(oauth2ClientCustomizer::oauth2Client$lambda$24); } private static final void oauth2Client$lambda$24(Function1 $tmp0, OAuth2ClientConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void oauth2ResourceServer(@NotNull Function1 oauth2ResourceServerConfiguration)
/*      */   {
/*  973 */     Intrinsics.checkNotNullParameter(oauth2ResourceServerConfiguration, "oauth2ResourceServerConfiguration"); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = new OAuth2ResourceServerDsl(); oauth2ResourceServerConfiguration.invoke(oAuth2ResourceServerDsl); Function1<OAuth2ResourceServerConfigurer<HttpSecurity>, Unit> oauth2ResourceServerCustomizer = oAuth2ResourceServerDsl.get$spring_security_config();
/*  974 */     this.http.oauth2ResourceServer(oauth2ResourceServerCustomizer::oauth2ResourceServer$lambda$25); } private static final void oauth2ResourceServer$lambda$25(Function1 $tmp0, OAuth2ResourceServerConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void oidcLogout(@NotNull Function1 oidcLogoutConfiguration)
/*      */   {
/* 1005 */     Intrinsics.checkNotNullParameter(oidcLogoutConfiguration, "oidcLogoutConfiguration"); OidcLogoutDsl oidcLogoutDsl = new OidcLogoutDsl(); oidcLogoutConfiguration.invoke(oidcLogoutDsl); Function1<OidcLogoutConfigurer<HttpSecurity>, Unit> oidcLogoutCustomizer = oidcLogoutDsl.get$spring_security_config();
/* 1006 */     this.http.oidcLogout(oidcLogoutCustomizer::oidcLogout$lambda$26); } private static final void oidcLogout$lambda$26(Function1 $tmp0, OidcLogoutConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void oneTimeTokenLogin(@NotNull Function1 oneTimeTokenLoginConfiguration)
/*      */   {
/* 1035 */     Intrinsics.checkNotNullParameter(oneTimeTokenLoginConfiguration, "oneTimeTokenLoginConfiguration"); OneTimeTokenLoginDsl oneTimeTokenLoginDsl = new OneTimeTokenLoginDsl(); oneTimeTokenLoginConfiguration.invoke(oneTimeTokenLoginDsl); Function1<OneTimeTokenLoginConfigurer<HttpSecurity>, Unit> oneTimeTokenLoginCustomizer = oneTimeTokenLoginDsl.get$spring_security_config();
/* 1036 */     this.http.oneTimeTokenLogin(oneTimeTokenLoginCustomizer::oneTimeTokenLogin$lambda$27); } private static final void oneTimeTokenLogin$lambda$27(Function1 $tmp0, OneTimeTokenLoginConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void rememberMe(@NotNull Function1 rememberMeConfiguration)
/*      */   {
/* 1065 */     Intrinsics.checkNotNullParameter(rememberMeConfiguration, "rememberMeConfiguration"); RememberMeDsl rememberMeDsl = new RememberMeDsl(); rememberMeConfiguration.invoke(rememberMeDsl); Function1<RememberMeConfigurer<HttpSecurity>, Unit> rememberMeCustomizer = rememberMeDsl.get$spring_security_config();
/* 1066 */     this.http.rememberMe(rememberMeCustomizer::rememberMe$lambda$28); } private static final void rememberMe$lambda$28(Function1 $tmp0, RememberMeConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void webAuthn(@NotNull Function1 webAuthnConfiguration)
/*      */   {
/* 1096 */     Intrinsics.checkNotNullParameter(webAuthnConfiguration, "webAuthnConfiguration"); WebAuthnDsl webAuthnDsl = new WebAuthnDsl(); webAuthnConfiguration.invoke(webAuthnDsl); Function1<WebAuthnConfigurer<HttpSecurity>, Unit> webAuthnCustomizer = webAuthnDsl.get$spring_security_config();
/* 1097 */     this.http.webAuthn(webAuthnCustomizer::webAuthn$lambda$29); } private static final void webAuthn$lambda$29(Function1 $tmp0, WebAuthnConfigurer t) { $tmp0.invoke(t); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(message = "Use 'addFilterAt<T>(filter)' instead.")
/*      */   public final void addFilterAt(@NotNull Filter filter, @NotNull Class atFilter) {
/* 1126 */     Intrinsics.checkNotNullParameter(filter, "filter"); Intrinsics.checkNotNullParameter(atFilter, "atFilter"); this.http.addFilterAt(filter, atFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(message = "Use 'addFilterAfter<T>(filter)' instead.")
/*      */   public final void addFilterAfter(@NotNull Filter filter, @NotNull Class afterFilter) {
/* 1185 */     Intrinsics.checkNotNullParameter(filter, "filter"); Intrinsics.checkNotNullParameter(afterFilter, "afterFilter"); this.http.addFilterAfter(filter, afterFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(message = "Use 'addFilterBefore<T>(filter)' instead.")
/*      */   public final void addFilterBefore(@NotNull Filter filter, @NotNull Class beforeFilter) {
/* 1244 */     Intrinsics.checkNotNullParameter(filter, "filter"); Intrinsics.checkNotNullParameter(beforeFilter, "beforeFilter"); this.http.addFilterBefore(filter, beforeFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void build$spring_security_config() {
/* 1281 */     this.init.invoke(this);
/* 1282 */     if (this.authenticationManager != null) { AuthenticationManager authenticationManager1 = this.authenticationManager, it = authenticationManager1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1317 */       int $i$a$-also-HttpSecurityDsl$build$1 = 0;
/*      */       this.http.authenticationManager(this.authenticationManager); }
/*      */     else
/*      */     {  }
/*      */   
/*      */   }
/*      */   
/*      */   public final void securityContext(@NotNull Function1 securityContextConfiguration) {
/*      */     Intrinsics.checkNotNullParameter(securityContextConfiguration, "securityContextConfiguration");
/*      */     SecurityContextDsl securityContextDsl = new SecurityContextDsl();
/*      */     securityContextConfiguration.invoke(securityContextDsl);
/*      */     Function1<SecurityContextConfigurer<HttpSecurity>, Unit> securityContextCustomizer = securityContextDsl.get$spring_security_config();
/*      */     this.http.securityContext(securityContextCustomizer::securityContext$lambda$31);
/*      */   }
/*      */   
/*      */   private static final void securityContext$lambda$31(Function1 $tmp0, SecurityContextConfigurer t) {
/*      */     $tmp0.invoke(t);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpSecurityDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */