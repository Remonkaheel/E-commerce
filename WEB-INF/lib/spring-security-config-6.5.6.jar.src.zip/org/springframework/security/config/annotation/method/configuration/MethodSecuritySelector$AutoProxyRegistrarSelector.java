/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ import org.springframework.lang.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AutoProxyRegistrarSelector
/*    */   extends AdviceModeImportSelector<EnableMethodSecurity>
/*    */ {
/* 84 */   private static final String[] IMPORTS = new String[] { AutoProxyRegistrar.class.getName(), MethodSecurityAdvisorRegistrar.class
/* 85 */       .getName() };
/*    */   
/* 87 */   private static final String[] ASPECTJ_IMPORTS = new String[] { MethodSecurityAspectJAutoProxyRegistrar.class
/* 88 */       .getName() };
/*    */ 
/*    */   
/*    */   protected String[] selectImports(@NonNull AdviceMode adviceMode) {
/* 92 */     if (adviceMode == AdviceMode.PROXY) {
/* 93 */       return IMPORTS;
/*    */     }
/* 95 */     if (adviceMode == AdviceMode.ASPECTJ) {
/* 96 */       return ASPECTJ_IMPORTS;
/*    */     }
/* 98 */     throw new IllegalStateException("AdviceMode '" + String.valueOf(adviceMode) + "' is not supported");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\MethodSecuritySelector$AutoProxyRegistrarSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */