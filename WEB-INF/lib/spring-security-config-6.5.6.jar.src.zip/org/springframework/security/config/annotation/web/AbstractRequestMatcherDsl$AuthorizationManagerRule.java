/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000\026\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\030\002\n\002\b\004\b$\030\0002\0020\001B\023\022\f\020\002\032\b\022\004\022\0020\0040\003¢\006\002\020\005R\032\020\002\032\b\022\004\022\0020\0040\003X\004¢\006\b\n\000\032\004\b\006\020\007¨\006\b"}, d2 = {"Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationManagerRule;", "", "rule", "Lorg/springframework/security/authorization/AuthorizationManager;", "Lorg/springframework/security/web/access/intercept/RequestAuthorizationContext;", "(Lorg/springframework/security/authorization/AuthorizationManager;)V", "getRule", "()Lorg/springframework/security/authorization/AuthorizationManager;", "spring-security-config"})
/*    */ public abstract class AuthorizationManagerRule
/*    */ {
/*    */   @NotNull
/*    */   private final AuthorizationManager<RequestAuthorizationContext> rule;
/*    */   
/*    */   public AuthorizationManagerRule(@NotNull AuthorizationManager<RequestAuthorizationContext> rule) {
/* 58 */     this.rule = rule; } @NotNull public AuthorizationManager<RequestAuthorizationContext> getRule() { return this.rule; }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherDsl$AuthorizationManagerRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */