/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.DefaultRedirectStrategy;
/*     */ import org.springframework.security.web.PortMapper;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.access.channel.ChannelDecisionManager;
/*     */ import org.springframework.security.web.access.channel.ChannelDecisionManagerImpl;
/*     */ import org.springframework.security.web.access.channel.ChannelEntryPoint;
/*     */ import org.springframework.security.web.access.channel.ChannelProcessingFilter;
/*     */ import org.springframework.security.web.access.channel.ChannelProcessor;
/*     */ import org.springframework.security.web.access.channel.InsecureChannelProcessor;
/*     */ import org.springframework.security.web.access.channel.RetryWithHttpEntryPoint;
/*     */ import org.springframework.security.web.access.channel.RetryWithHttpsEntryPoint;
/*     */ import org.springframework.security.web.access.channel.SecureChannelProcessor;
/*     */ import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ChannelSecurityConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<ChannelSecurityConfigurer<H>, H>
/*     */ {
/*  87 */   private ChannelProcessingFilter channelFilter = new ChannelProcessingFilter();
/*     */   
/*  89 */   private LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap = new LinkedHashMap<>();
/*     */   
/*     */   private List<ChannelProcessor> channelProcessors;
/*     */   
/*  93 */   private RedirectStrategy redirectStrategy = (RedirectStrategy)new DefaultRedirectStrategy();
/*     */ 
/*     */ 
/*     */   
/*     */   private final ChannelRequestMatcherRegistry REGISTRY;
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelSecurityConfigurer(ApplicationContext context) {
/* 102 */     this.REGISTRY = new ChannelRequestMatcherRegistry(context);
/*     */   }
/*     */   
/*     */   public ChannelRequestMatcherRegistry getRegistry() {
/* 106 */     return this.REGISTRY;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 111 */     ChannelDecisionManagerImpl channelDecisionManager = new ChannelDecisionManagerImpl();
/* 112 */     channelDecisionManager.setChannelProcessors(getChannelProcessors(http));
/* 113 */     channelDecisionManager = (ChannelDecisionManagerImpl)postProcess(channelDecisionManager);
/* 114 */     this.channelFilter.setChannelDecisionManager((ChannelDecisionManager)channelDecisionManager);
/* 115 */     DefaultFilterInvocationSecurityMetadataSource filterInvocationSecurityMetadataSource = new DefaultFilterInvocationSecurityMetadataSource(this.requestMap);
/*     */     
/* 117 */     this.channelFilter.setSecurityMetadataSource((FilterInvocationSecurityMetadataSource)filterInvocationSecurityMetadataSource);
/* 118 */     this.channelFilter = (ChannelProcessingFilter)postProcess(this.channelFilter);
/* 119 */     http.addFilter((Filter)this.channelFilter);
/*     */   }
/*     */   
/*     */   private List<ChannelProcessor> getChannelProcessors(H http) {
/* 123 */     if (this.channelProcessors != null) {
/* 124 */       return this.channelProcessors;
/*     */     }
/* 126 */     InsecureChannelProcessor insecureChannelProcessor = new InsecureChannelProcessor();
/* 127 */     SecureChannelProcessor secureChannelProcessor = new SecureChannelProcessor();
/* 128 */     PortMapper portMapper = (PortMapper)http.getSharedObject(PortMapper.class);
/* 129 */     if (portMapper != null) {
/* 130 */       RetryWithHttpEntryPoint httpEntryPoint = new RetryWithHttpEntryPoint();
/* 131 */       httpEntryPoint.setPortMapper(portMapper);
/* 132 */       httpEntryPoint.setRedirectStrategy(this.redirectStrategy);
/* 133 */       insecureChannelProcessor.setEntryPoint((ChannelEntryPoint)httpEntryPoint);
/* 134 */       RetryWithHttpsEntryPoint httpsEntryPoint = new RetryWithHttpsEntryPoint();
/* 135 */       httpsEntryPoint.setPortMapper(portMapper);
/* 136 */       httpsEntryPoint.setRedirectStrategy(this.redirectStrategy);
/* 137 */       secureChannelProcessor.setEntryPoint((ChannelEntryPoint)httpsEntryPoint);
/*     */     } 
/* 139 */     insecureChannelProcessor = (InsecureChannelProcessor)postProcess(insecureChannelProcessor);
/* 140 */     secureChannelProcessor = (SecureChannelProcessor)postProcess(secureChannelProcessor);
/* 141 */     return Arrays.asList(new ChannelProcessor[] { (ChannelProcessor)insecureChannelProcessor, (ChannelProcessor)secureChannelProcessor });
/*     */   }
/*     */   
/*     */   private ChannelRequestMatcherRegistry addAttribute(String attribute, List<? extends RequestMatcher> matchers) {
/* 145 */     for (RequestMatcher matcher : matchers) {
/* 146 */       Collection<ConfigAttribute> attrs = Arrays.asList(new ConfigAttribute[] { (ConfigAttribute)new SecurityConfig(attribute) });
/* 147 */       this.requestMap.put(matcher, attrs);
/*     */     } 
/* 149 */     return this.REGISTRY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final class ChannelRequestMatcherRegistry
/*     */     extends AbstractConfigAttributeRequestMatcherRegistry<RequiresChannelUrl>
/*     */   {
/*     */     private ChannelRequestMatcherRegistry(ApplicationContext context) {
/* 160 */       setApplicationContext(context);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ChannelSecurityConfigurer<H>.RequiresChannelUrl chainRequestMatchersInternal(List<RequestMatcher> requestMatchers) {
/* 165 */       return new ChannelSecurityConfigurer.RequiresChannelUrl(requestMatchers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 174 */       ChannelSecurityConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 175 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.4", forRemoval = true)
/*     */     public ChannelRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 184 */       ChannelSecurityConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 185 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelRequestMatcherRegistry channelProcessors(List<ChannelProcessor> channelProcessors) {
/* 195 */       ChannelSecurityConfigurer.this.channelProcessors = channelProcessors;
/* 196 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ChannelRequestMatcherRegistry redirectStrategy(RedirectStrategy redirectStrategy) {
/* 206 */       ChannelSecurityConfigurer.this.redirectStrategy = redirectStrategy;
/* 207 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public H and() {
/* 219 */       return (H)ChannelSecurityConfigurer.this.and();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public class RequiresChannelUrl
/*     */   {
/*     */     protected List<? extends RequestMatcher> requestMatchers;
/*     */ 
/*     */ 
/*     */     
/*     */     RequiresChannelUrl(List<? extends RequestMatcher> requestMatchers) {
/* 233 */       this.requestMatchers = requestMatchers;
/*     */     }
/*     */     
/*     */     public ChannelSecurityConfigurer<H>.ChannelRequestMatcherRegistry requiresSecure() {
/* 237 */       return requires("REQUIRES_SECURE_CHANNEL");
/*     */     }
/*     */     
/*     */     public ChannelSecurityConfigurer<H>.ChannelRequestMatcherRegistry requiresInsecure() {
/* 241 */       return requires("REQUIRES_INSECURE_CHANNEL");
/*     */     }
/*     */     
/*     */     public ChannelSecurityConfigurer<H>.ChannelRequestMatcherRegistry requires(String attribute) {
/* 245 */       return ChannelSecurityConfigurer.this.addAttribute(attribute, this.requestMatchers);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\ChannelSecurityConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */