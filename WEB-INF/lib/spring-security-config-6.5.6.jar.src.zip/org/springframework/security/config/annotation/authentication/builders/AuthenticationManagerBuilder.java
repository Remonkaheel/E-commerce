/*     */ package org.springframework.security.config.annotation.authentication.builders;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.authentication.AuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.ProviderManager;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.AbstractConfiguredSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
/*     */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.ldap.LdapAuthenticationProviderConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.userdetails.DaoAuthenticationConfigurer;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationManagerBuilder
/*     */   extends AbstractConfiguredSecurityBuilder<AuthenticationManager, AuthenticationManagerBuilder>
/*     */   implements ProviderManagerBuilder<AuthenticationManagerBuilder>
/*     */ {
/*  56 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private AuthenticationManager parentAuthenticationManager;
/*     */   
/*  60 */   private List<AuthenticationProvider> authenticationProviders = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private UserDetailsService defaultUserDetailsService;
/*     */ 
/*     */   
/*     */   private Boolean eraseCredentials;
/*     */ 
/*     */   
/*     */   private AuthenticationEventPublisher eventPublisher;
/*     */ 
/*     */   
/*     */   public AuthenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor) {
/*  73 */     super(objectPostProcessor, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public AuthenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor) {
/*  82 */     super(objectPostProcessor, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationManagerBuilder parentAuthenticationManager(AuthenticationManager authenticationManager) {
/*  96 */     if (authenticationManager instanceof ProviderManager) {
/*  97 */       eraseCredentials(((ProviderManager)authenticationManager).isEraseCredentialsAfterAuthentication());
/*     */     }
/*  99 */     this.parentAuthenticationManager = authenticationManager;
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationManagerBuilder authenticationEventPublisher(AuthenticationEventPublisher eventPublisher) {
/* 109 */     Assert.notNull(eventPublisher, "AuthenticationEventPublisher cannot be null");
/* 110 */     this.eventPublisher = eventPublisher;
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationManagerBuilder eraseCredentials(boolean eraseCredentials) {
/* 120 */     this.eraseCredentials = Boolean.valueOf(eraseCredentials);
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder> inMemoryAuthentication() throws Exception {
/* 141 */     return apply(new InMemoryUserDetailsManagerConfigurer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder> jdbcAuthentication() throws Exception {
/* 169 */     return apply(new JdbcUserDetailsManagerConfigurer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends UserDetailsService> DaoAuthenticationConfigurer<AuthenticationManagerBuilder, T> userDetailsService(T userDetailsService) throws Exception {
/* 190 */     this.defaultUserDetailsService = (UserDetailsService)userDetailsService;
/* 191 */     return apply(new DaoAuthenticationConfigurer((UserDetailsService)userDetailsService));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<AuthenticationManagerBuilder> ldapAuthentication() throws Exception {
/* 207 */     return (LdapAuthenticationProviderConfigurer<AuthenticationManagerBuilder>)apply((SecurityConfigurerAdapter)new LdapAuthenticationProviderConfigurer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthenticationManagerBuilder authenticationProvider(AuthenticationProvider authenticationProvider) {
/* 227 */     this.authenticationProviders.add(authenticationProvider);
/* 228 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProviderManager performBuild() throws Exception {
/* 233 */     if (!isConfigured()) {
/* 234 */       this.logger.debug("No authenticationProviders and no parentAuthenticationManager defined. Returning null.");
/* 235 */       return null;
/*     */     } 
/* 237 */     ProviderManager providerManager = new ProviderManager(this.authenticationProviders, this.parentAuthenticationManager);
/*     */     
/* 239 */     if (this.eraseCredentials != null) {
/* 240 */       providerManager.setEraseCredentialsAfterAuthentication(this.eraseCredentials.booleanValue());
/*     */     }
/* 242 */     if (this.eventPublisher != null) {
/* 243 */       providerManager.setAuthenticationEventPublisher(this.eventPublisher);
/*     */     }
/* 245 */     providerManager = (ProviderManager)postProcess(providerManager);
/* 246 */     return providerManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConfigured() {
/* 265 */     return (!this.authenticationProviders.isEmpty() || this.parentAuthenticationManager != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserDetailsService getDefaultUserDetailsService() {
/* 275 */     return this.defaultUserDetailsService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <C extends org.springframework.security.config.annotation.authentication.configurers.userdetails.UserDetailsAwareConfigurer<AuthenticationManagerBuilder, ? extends UserDetailsService>> C apply(C configurer) throws Exception {
/* 288 */     this.defaultUserDetailsService = configurer.getUserDetailsService();
/* 289 */     return (C)apply((SecurityConfigurerAdapter)configurer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\builders\AuthenticationManagerBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */