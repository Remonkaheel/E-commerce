package org.springframework.security.config.annotation.web;

import jakarta.servlet.Filter;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.SecurityBuilder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.DefaultSecurityFilterChain;

public interface HttpSecurityBuilder<H extends HttpSecurityBuilder<H>> extends SecurityBuilder<DefaultSecurityFilterChain> {
  <C extends org.springframework.security.config.annotation.SecurityConfigurer<DefaultSecurityFilterChain, H>> C getConfigurer(Class<C> paramClass);
  
  <C extends org.springframework.security.config.annotation.SecurityConfigurer<DefaultSecurityFilterChain, H>> C removeConfigurer(Class<C> paramClass);
  
  <C> void setSharedObject(Class<C> paramClass, C paramC);
  
  <C> C getSharedObject(Class<C> paramClass);
  
  H authenticationProvider(AuthenticationProvider paramAuthenticationProvider);
  
  H userDetailsService(UserDetailsService paramUserDetailsService) throws Exception;
  
  H addFilterAfter(Filter paramFilter, Class<? extends Filter> paramClass);
  
  H addFilterBefore(Filter paramFilter, Class<? extends Filter> paramClass);
  
  H addFilter(Filter paramFilter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpSecurityBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */