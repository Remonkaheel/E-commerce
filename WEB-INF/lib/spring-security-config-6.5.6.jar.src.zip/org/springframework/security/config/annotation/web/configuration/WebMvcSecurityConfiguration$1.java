/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.security.web.access.HandlerMappingIntrospectorRequestTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements BeanDefinitionRegistryPostProcessor
/*     */ {
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */   
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 133 */     if (!registry.containsBeanDefinition("mvcHandlerMappingIntrospector")) {
/*     */       return;
/*     */     }
/*     */     
/* 137 */     String hmiRequestTransformerBeanName = "mvcHandlerMappingIntrospectorRequestTransformer";
/* 138 */     if (!registry.containsBeanDefinition("pathPatternRequestTransformer") && 
/* 139 */       !registry.containsBeanDefinition(hmiRequestTransformerBeanName) && 
/* 140 */       !registry.containsBeanDefinition(hmiRequestTransformerBeanName)) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(HandlerMappingIntrospectorRequestTransformer.class).addConstructorArgReference("mvcHandlerMappingIntrospector").getBeanDefinition();
/* 145 */       registry.registerBeanDefinition(hmiRequestTransformerBeanName, (BeanDefinition)abstractBeanDefinition);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 150 */     BeanDefinition filterChainProxy = registry.getBeanDefinition("springSecurityFilterChain");
/*     */     
/* 152 */     if (!filterChainProxy.getResolvableType().isInstance(WebMvcSecurityConfiguration.CompositeFilterChainProxy.class)) {
/*     */ 
/*     */       
/* 155 */       BeanDefinitionBuilder hmiCacheFilterBldr = BeanDefinitionBuilder.rootBeanDefinition(WebMvcSecurityConfiguration.HandlerMappingIntrospectorCacheFilterFactoryBean.class).setRole(2);
/*     */       
/* 157 */       ManagedList<BeanMetadataElement> filters = new ManagedList();
/* 158 */       filters.add(hmiCacheFilterBldr.getBeanDefinition());
/* 159 */       filters.add(filterChainProxy);
/*     */ 
/*     */       
/* 162 */       BeanDefinitionBuilder compositeSpringSecurityFilterChainBldr = BeanDefinitionBuilder.rootBeanDefinition(WebMvcSecurityConfiguration.CompositeFilterChainProxy.class).addConstructorArgValue(filters);
/*     */       
/* 164 */       registry.removeBeanDefinition("springSecurityFilterChain");
/* 165 */       registry.registerBeanDefinition("springSecurityFilterChain", (BeanDefinition)compositeSpringSecurityFilterChainBldr
/* 166 */           .getBeanDefinition());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\WebMvcSecurityConfiguration$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */