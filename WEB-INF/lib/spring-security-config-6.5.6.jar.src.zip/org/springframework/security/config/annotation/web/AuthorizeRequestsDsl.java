/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.ArraysKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000^\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\006\n\002\020!\n\002\030\002\n\002\b\t\n\002\020\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\021\n\002\b\b\030\0002\0020\001B\005¢\006\002\020\002J\026\020\032\032\0020\0332\006\020\034\032\0020\0042\006\020\035\032\0020\004J\036\020\032\032\0020\0332\006\020\034\032\0020\0042\006\020\036\032\0020\0042\006\020\035\032\0020\004J\036\020\032\032\0020\0332\006\020\037\032\0020 2\006\020\034\032\0020\0042\006\020\035\032\0020\004J&\020\032\032\0020\0332\006\020\037\032\0020 2\006\020\034\032\0020\0042\006\020\036\032\0020\0042\006\020\035\032\0020\004J\030\020\032\032\0020\0332\b\b\002\020!\032\0020\"2\006\020\035\032\0020\004J#\020#\032\030\022\016\022\f0%R\b\022\004\022\0020'0&\022\004\022\0020\0330$H\000¢\006\002\b(J\037\020)\032\0020\0042\022\020*\032\n\022\006\b\001\022\0020\0040+\"\0020\004¢\006\002\020,J\037\020-\032\0020\0042\022\020.\032\n\022\006\b\001\022\0020\0040+\"\0020\004¢\006\002\020,J\016\020/\032\0020\0042\006\0200\032\0020\004J\016\0201\032\0020\0042\006\0202\032\0020\004R\016\020\003\032\0020\004XD¢\006\002\n\000R\016\020\005\032\0020\004XD¢\006\002\n\000R\016\020\006\032\0020\007X\004¢\006\002\n\000R\016\020\b\032\0020\tX\004¢\006\002\n\000R\024\020\n\032\0020\004XD¢\006\b\n\000\032\004\b\013\020\fR\024\020\r\032\0020\004XD¢\006\b\n\000\032\004\b\016\020\fR\024\020\017\032\b\022\004\022\0020\0210\020X\004¢\006\002\n\000R\024\020\022\032\0020\004XD¢\006\b\n\000\032\004\b\023\020\fR\024\020\024\032\0020\004XD¢\006\b\n\000\032\004\b\025\020\fR\024\020\026\032\0020\004XD¢\006\b\n\000\032\004\b\027\020\fR\024\020\030\032\0020\004XD¢\006\b\n\000\032\004\b\031\020\f¨\0063"}, d2 = {"Lorg/springframework/security/config/annotation/web/AuthorizeRequestsDsl;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl;", "()V", "HANDLER_MAPPING_INTROSPECTOR", "", "HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME", "MVC_PRESENT", "", "PATTERN_TYPE", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$PatternType;", "anonymous", "getAnonymous", "()Ljava/lang/String;", "authenticated", "getAuthenticated", "authorizationRules", "", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationRule;", "denyAll", "getDenyAll", "fullyAuthenticated", "getFullyAuthenticated", "permitAll", "getPermitAll", "rememberMe", "getRememberMe", "authorize", "", "pattern", "access", "servletPath", "method", "Lorg/springframework/http/HttpMethod;", "matches", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/ExpressionUrlAuthorizationConfigurer$ExpressionInterceptUrlRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/ExpressionUrlAuthorizationConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "hasAnyAuthority", "authorities", "", "([Ljava/lang/String;)Ljava/lang/String;", "hasAnyRole", "roles", "hasAuthority", "authority", "hasRole", "role", "spring-security-config"})
/*     */ public final class AuthorizeRequestsDsl
/*     */   extends AbstractRequestMatcherDsl
/*     */ {
/*     */   @NotNull
/*  35 */   private final List<AbstractRequestMatcherDsl.AuthorizationRule> authorizationRules = new ArrayList<>();
/*     */   @NotNull
/*  37 */   private final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector"; @NotNull
/*  38 */   private final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*  39 */   private final boolean MVC_PRESENT = ClassUtils.isPresent(
/*  40 */       this.HANDLER_MAPPING_INTROSPECTOR, 
/*  41 */       AuthorizeRequestsDsl.class.getClassLoader()); @NotNull
/*  42 */   private final AbstractRequestMatcherDsl.PatternType PATTERN_TYPE = this.MVC_PRESENT ? AbstractRequestMatcherDsl.PatternType.MVC : AbstractRequestMatcherDsl.PatternType.ANT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull RequestMatcher matches, @NotNull String access) {
/*  53 */     Intrinsics.checkNotNullParameter(matches, "matches"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(new AbstractRequestMatcherDsl.MatcherAuthorizationRule(matches, access));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull String pattern, @NotNull String access) {
/*  72 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(new AbstractRequestMatcherDsl.PatternAuthorizationRule(pattern, 
/*  73 */           this.PATTERN_TYPE, null, null, 
/*  74 */           access, 12, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull HttpMethod method, @NotNull String pattern, @NotNull String access) {
/*  94 */     Intrinsics.checkNotNullParameter(method, "method"); Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(new AbstractRequestMatcherDsl.PatternAuthorizationRule(pattern, 
/*  95 */           this.PATTERN_TYPE, null, 
/*  96 */           method, 
/*  97 */           access, 4, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull String pattern, @NotNull String servletPath, @NotNull String access) {
/* 118 */     Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(servletPath, "servletPath"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(new AbstractRequestMatcherDsl.PatternAuthorizationRule(pattern, 
/* 119 */           this.PATTERN_TYPE, 
/* 120 */           servletPath, null, 
/* 121 */           access, 8, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorize(@NotNull HttpMethod method, @NotNull String pattern, @NotNull String servletPath, @NotNull String access) {
/* 143 */     Intrinsics.checkNotNullParameter(method, "method"); Intrinsics.checkNotNullParameter(pattern, "pattern"); Intrinsics.checkNotNullParameter(servletPath, "servletPath"); Intrinsics.checkNotNullParameter(access, "access"); this.authorizationRules.add(new AbstractRequestMatcherDsl.PatternAuthorizationRule(pattern, 
/* 144 */           this.PATTERN_TYPE, 
/* 145 */           servletPath, 
/* 146 */           method, 
/* 147 */           access));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final String hasAuthority(@NotNull String authority) {
/* 157 */     Intrinsics.checkNotNullParameter(authority, "authority"); return "hasAuthority('" + authority + "')";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final String hasAnyAuthority(@NotNull String... authorities) {
/* 167 */     Intrinsics.checkNotNullParameter(authorities, "authorities"); String anyAuthorities = ArraysKt.joinToString$default((Object[])authorities, "','", null, null, 0, null, null, 62, null);
/* 168 */     return "hasAnyAuthority('" + anyAuthorities + "')";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final String hasRole(@NotNull String role) {
/* 178 */     Intrinsics.checkNotNullParameter(role, "role"); return "hasRole('" + role + "')";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final String hasAnyRole(@NotNull String... roles) {
/* 188 */     Intrinsics.checkNotNullParameter(roles, "roles"); String anyRoles = ArraysKt.joinToString$default((Object[])roles, "','", null, null, 0, null, null, 62, null);
/* 189 */     return "hasAnyRole('" + anyRoles + "')";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 195 */   private final String permitAll = "permitAll"; @NotNull public final String getPermitAll() { return this.permitAll; }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 200 */   private final String anonymous = "anonymous"; @NotNull public final String getAnonymous() { return this.anonymous; }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 205 */   private final String rememberMe = "rememberMe"; @NotNull public final String getRememberMe() { return this.rememberMe; }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 210 */   private final String denyAll = "denyAll"; @NotNull public final String getDenyAll() { return this.denyAll; }
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 215 */   private final String authenticated = "authenticated"; @NotNull public final String getAuthenticated() { return this.authenticated; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/* 221 */   private final String fullyAuthenticated = "fullyAuthenticated"; @NotNull public final String getFullyAuthenticated() { return this.fullyAuthenticated; }
/*     */   
/*     */   @NotNull
/* 224 */   public final Function1<ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry, Unit> get$spring_security_config() { return new AuthorizeRequestsDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "requests", "Lorg/springframework/security/config/annotation/web/configurers/ExpressionUrlAuthorizationConfigurer$ExpressionInterceptUrlRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/ExpressionUrlAuthorizationConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nAuthorizeRequestsDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AuthorizeRequestsDsl.kt\norg/springframework/security/config/annotation/web/AuthorizeRequestsDsl$get$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,247:1\n1863#2,2:248\n*S KotlinDebug\n*F\n+ 1 AuthorizeRequestsDsl.kt\norg/springframework/security/config/annotation/web/AuthorizeRequestsDsl$get$1\n*L\n225#1:248,2\n*E\n"})
/* 225 */   static final class AuthorizeRequestsDsl$get$1 extends Lambda implements Function1<ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry, Unit> { public final void invoke(ExpressionUrlAuthorizationConfigurer.ExpressionInterceptUrlRegistry requests) { Intrinsics.checkNotNullParameter(requests, "requests"); List list = AuthorizeRequestsDsl.this.authorizationRules; AuthorizeRequestsDsl authorizeRequestsDsl = AuthorizeRequestsDsl.this; int $i$f$forEach = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       Iterator iterator = list.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); AbstractRequestMatcherDsl.AuthorizationRule rule = (AbstractRequestMatcherDsl.AuthorizationRule)element$iv; int $i$a$-forEach-AuthorizeRequestsDsl$get$1$1 = 0;
/*     */         AbstractRequestMatcherDsl.AuthorizationRule authorizationRule1 = rule; }
/*     */        }
/*     */ 
/*     */     
/*     */     AuthorizeRequestsDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AuthorizeRequestsDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */