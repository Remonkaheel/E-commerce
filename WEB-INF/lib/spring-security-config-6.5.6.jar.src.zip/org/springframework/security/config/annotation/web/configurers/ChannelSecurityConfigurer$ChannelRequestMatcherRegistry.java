/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.web.RedirectStrategy;
/*     */ import org.springframework.security.web.access.channel.ChannelProcessor;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ChannelRequestMatcherRegistry
/*     */   extends AbstractConfigAttributeRequestMatcherRegistry<ChannelSecurityConfigurer<H>.RequiresChannelUrl>
/*     */ {
/*     */   private ChannelRequestMatcherRegistry(ApplicationContext context) {
/* 160 */     setApplicationContext(context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ChannelSecurityConfigurer<H>.RequiresChannelUrl chainRequestMatchersInternal(List<RequestMatcher> requestMatchers) {
/* 165 */     return new ChannelSecurityConfigurer.RequiresChannelUrl(ChannelSecurityConfigurer.this, requestMatchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 174 */     ChannelSecurityConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public ChannelRequestMatcherRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 184 */     ChannelSecurityConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelRequestMatcherRegistry channelProcessors(List<ChannelProcessor> channelProcessors) {
/* 195 */     ChannelSecurityConfigurer.this.channelProcessors = channelProcessors;
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelRequestMatcherRegistry redirectStrategy(RedirectStrategy redirectStrategy) {
/* 206 */     ChannelSecurityConfigurer.this.redirectStrategy = redirectStrategy;
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public H and() {
/* 219 */     return (H)ChannelSecurityConfigurer.this.and();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\ChannelSecurityConfigurer$ChannelRequestMatcherRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */