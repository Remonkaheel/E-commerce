package org.springframework.security.config.annotation.web.servlet.configuration;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.authentication.configuration.EnableGlobalAuthentication;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
@Import({WebMvcSecurityConfiguration.class})
@EnableGlobalAuthentication
@Deprecated
public @interface EnableWebMvcSecurity {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\servlet\configuration\EnableWebMvcSecurity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */