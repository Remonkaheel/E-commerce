/*    */ package org.springframework.security.config.annotation.web.saml2;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*    */ import org.springframework.security.saml2.provider.service.authentication.logout.Saml2LogoutResponseValidator;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutResponseResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "logoutResponse", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutResponseConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nLogoutResponseDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LogoutResponseDsl.kt\norg/springframework/security/config/annotation/web/saml2/LogoutResponseDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,48:1\n1#2:49\n*E\n"})
/*    */ final class LogoutResponseDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<Saml2LogoutConfigurer<HttpSecurity>.LogoutResponseConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(Saml2LogoutConfigurer.LogoutResponseConfigurer logoutResponse) {
/* 42 */     Intrinsics.checkNotNullParameter(logoutResponse, "logoutResponse"); String str1 = LogoutResponseDsl.this.getLogoutUrl(); LogoutResponseDsl logoutResponseDsl = LogoutResponseDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     int $i$a$-also-LogoutResponseDsl$get$1$1 = 0; logoutResponse.logoutUrl(logoutResponseDsl.getLogoutUrl()); if (LogoutResponseDsl.this.getLogoutResponseValidator() != null) { Saml2LogoutResponseValidator saml2LogoutResponseValidator1 = LogoutResponseDsl.this.getLogoutResponseValidator(); LogoutResponseDsl logoutResponseDsl1 = LogoutResponseDsl.this; Saml2LogoutResponseValidator saml2LogoutResponseValidator2 = saml2LogoutResponseValidator1; int $i$a$-also-LogoutResponseDsl$get$1$2 = 0; logoutResponse.logoutResponseValidator(logoutResponseDsl1.getLogoutResponseValidator()); } else { LogoutResponseDsl.this.getLogoutResponseValidator(); }  if (LogoutResponseDsl.this.getLogoutResponseResolver() != null) { Saml2LogoutResponseResolver saml2LogoutResponseResolver1 = LogoutResponseDsl.this.getLogoutResponseResolver(); LogoutResponseDsl logoutResponseDsl1 = LogoutResponseDsl.this; Saml2LogoutResponseResolver saml2LogoutResponseResolver2 = saml2LogoutResponseResolver1; int $i$a$-also-LogoutResponseDsl$get$1$3 = 0;
/*    */       logoutResponse.logoutResponseResolver(logoutResponseDsl1.getLogoutResponseResolver()); }
/*    */     else
/*    */     { LogoutResponseDsl.this.getLogoutResponseResolver(); }
/*    */   
/*    */   }
/*    */   
/*    */   LogoutResponseDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\saml2\LogoutResponseDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */