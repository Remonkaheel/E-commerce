/*     */ package org.springframework.security.config.annotation.rsocket;
/*     */ 
/*     */ import org.springframework.messaging.rsocket.annotation.support.RSocketMessageHandler;
/*     */ import org.springframework.security.authorization.AuthenticatedReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.rsocket.authorization.AuthorizationPayloadInterceptor;
/*     */ import org.springframework.security.rsocket.authorization.PayloadExchangeMatcherReactiveAuthorizationManager;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeAuthorizationContext;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcher;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcherEntry;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatchers;
/*     */ import org.springframework.security.rsocket.util.matcher.RoutePayloadExchangeMatcher;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizePayloadsSpec
/*     */ {
/* 354 */   private PayloadExchangeMatcherReactiveAuthorizationManager.Builder authzBuilder = PayloadExchangeMatcherReactiveAuthorizationManager.builder();
/*     */   
/*     */   public Access setup() {
/* 357 */     return matcher(PayloadExchangeMatchers.setup());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Access anyRequest() {
/* 367 */     return matcher(PayloadExchangeMatchers.anyRequest());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Access anyExchange() {
/* 375 */     return matcher(PayloadExchangeMatchers.anyExchange());
/*     */   }
/*     */   
/*     */   protected AuthorizationPayloadInterceptor build() {
/* 379 */     AuthorizationPayloadInterceptor result = new AuthorizationPayloadInterceptor((ReactiveAuthorizationManager)this.authzBuilder.build());
/* 380 */     result.setOrder(PayloadInterceptorOrder.AUTHORIZATION.getOrder());
/* 381 */     return result;
/*     */   }
/*     */   
/*     */   public Access route(String pattern) {
/* 385 */     RSocketMessageHandler handler = RSocketSecurity.this.<RSocketMessageHandler>getBean(RSocketMessageHandler.class);
/*     */     
/* 387 */     RoutePayloadExchangeMatcher routePayloadExchangeMatcher = new RoutePayloadExchangeMatcher(handler.getMetadataExtractor(), handler.getRouteMatcher(), pattern);
/* 388 */     return matcher((PayloadExchangeMatcher)routePayloadExchangeMatcher);
/*     */   }
/*     */   
/*     */   public Access matcher(PayloadExchangeMatcher matcher) {
/* 392 */     return new Access(matcher);
/*     */   }
/*     */   
/*     */   public final class Access
/*     */   {
/*     */     private final PayloadExchangeMatcher matcher;
/*     */     
/*     */     private Access(PayloadExchangeMatcher matcher) {
/* 400 */       this.matcher = matcher;
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec authenticated() {
/* 404 */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthenticatedReactiveAuthorizationManager.authenticated());
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasAuthority(String authority) {
/* 408 */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAuthority(authority));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasRole(String role) {
/* 412 */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasRole(role));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasAnyRole(String... roles) {
/* 416 */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyRole(roles));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec permitAll() {
/* 420 */       return access((a, ctx) -> Mono.just(new AuthorizationDecision(true)));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasAnyAuthority(String... authorities) {
/* 424 */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyAuthority(authorities));
/*     */     }
/*     */ 
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec access(ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext> authorization) {
/* 429 */       RSocketSecurity.AuthorizePayloadsSpec.this.authzBuilder
/* 430 */         .add(new PayloadExchangeMatcherEntry(this.matcher, authorization));
/* 431 */       return RSocketSecurity.AuthorizePayloadsSpec.this;
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec denyAll() {
/* 435 */       return access((a, ctx) -> Mono.just(new AuthorizationDecision(false)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\RSocketSecurity$AuthorizePayloadsSpec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */