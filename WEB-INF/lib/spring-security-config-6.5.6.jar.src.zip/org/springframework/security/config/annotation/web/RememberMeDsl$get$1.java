/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.RememberMeConfigurer;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*    */ import org.springframework.security.web.authentication.RememberMeServices;
/*    */ import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "rememberMe", "Lorg/springframework/security/config/annotation/web/configurers/RememberMeConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nRememberMeDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RememberMeDsl.kt\norg/springframework/security/config/annotation/web/RememberMeDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,80:1\n1#2:81\n*E\n"})
/*    */ final class RememberMeDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<RememberMeConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(RememberMeConfigurer rememberMe) {
/* 66 */     Intrinsics.checkNotNullParameter(rememberMe, "rememberMe"); if (RememberMeDsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = RememberMeDsl.this.getAuthenticationSuccessHandler(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; AuthenticationSuccessHandler it = authenticationSuccessHandler1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 81 */       int $i$a$-also-RememberMeDsl$get$1$1 = 0; rememberMe.authenticationSuccessHandler(rememberMeDsl.getAuthenticationSuccessHandler()); } else { RememberMeDsl.this.getAuthenticationSuccessHandler(); }  if (RememberMeDsl.this.getKey() != null) { String str1 = RememberMeDsl.this.getKey(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$2 = 0; rememberMe.key(rememberMeDsl.getKey()); } else { RememberMeDsl.this.getKey(); }  if (RememberMeDsl.this.getRememberMeServices() != null) { RememberMeServices rememberMeServices1 = RememberMeDsl.this.getRememberMeServices(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; RememberMeServices it = rememberMeServices1; int $i$a$-also-RememberMeDsl$get$1$3 = 0; rememberMe.rememberMeServices(rememberMeDsl.getRememberMeServices()); } else { RememberMeDsl.this.getRememberMeServices(); }  if (RememberMeDsl.this.getRememberMeParameter() != null) { String str1 = RememberMeDsl.this.getRememberMeParameter(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$4 = 0; rememberMe.rememberMeParameter(rememberMeDsl.getRememberMeParameter()); } else { RememberMeDsl.this.getRememberMeParameter(); }  if (RememberMeDsl.this.getRememberMeCookieName() != null) { String str1 = RememberMeDsl.this.getRememberMeCookieName(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$5 = 0; rememberMe.rememberMeCookieName(rememberMeDsl.getRememberMeCookieName()); } else { RememberMeDsl.this.getRememberMeCookieName(); }  if (RememberMeDsl.this.getRememberMeCookieDomain() != null) { String str1 = RememberMeDsl.this.getRememberMeCookieDomain(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; String it = str1; int $i$a$-also-RememberMeDsl$get$1$6 = 0; rememberMe.rememberMeCookieDomain(rememberMeDsl.getRememberMeCookieDomain()); } else { RememberMeDsl.this.getRememberMeCookieDomain(); }  if (RememberMeDsl.this.getTokenRepository() != null) { PersistentTokenRepository persistentTokenRepository1 = RememberMeDsl.this.getTokenRepository(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; PersistentTokenRepository it = persistentTokenRepository1; int $i$a$-also-RememberMeDsl$get$1$7 = 0; rememberMe.tokenRepository(rememberMeDsl.getTokenRepository()); } else { RememberMeDsl.this.getTokenRepository(); }  if (RememberMeDsl.this.getUserDetailsService() != null) { UserDetailsService userDetailsService1 = RememberMeDsl.this.getUserDetailsService(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; UserDetailsService it = userDetailsService1; int $i$a$-also-RememberMeDsl$get$1$8 = 0; rememberMe.userDetailsService(rememberMeDsl.getUserDetailsService()); } else { RememberMeDsl.this.getUserDetailsService(); }  if (RememberMeDsl.this.getTokenValiditySeconds() != null) { Integer integer = RememberMeDsl.this.getTokenValiditySeconds(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; int it = integer.intValue(); int $i$a$-also-RememberMeDsl$get$1$9 = 0; Intrinsics.checkNotNull(rememberMeDsl.getTokenValiditySeconds()); rememberMe.tokenValiditySeconds(rememberMeDsl.getTokenValiditySeconds().intValue()); } else { RememberMeDsl.this.getTokenValiditySeconds(); }  if (RememberMeDsl.this.getUseSecureCookie() != null) { Boolean bool = RememberMeDsl.this.getUseSecureCookie(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-RememberMeDsl$get$1$10 = 0; Intrinsics.checkNotNull(rememberMeDsl.getUseSecureCookie()); rememberMe.useSecureCookie(rememberMeDsl.getUseSecureCookie().booleanValue()); } else { RememberMeDsl.this.getUseSecureCookie(); }  if (RememberMeDsl.this.getAlwaysRemember() != null) { Boolean bool = RememberMeDsl.this.getAlwaysRemember(); RememberMeDsl rememberMeDsl = RememberMeDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-RememberMeDsl$get$1$11 = 0;
/*    */       Intrinsics.checkNotNull(rememberMeDsl.getAlwaysRemember());
/*    */       rememberMe.alwaysRemember(rememberMeDsl.getAlwaysRemember().booleanValue()); }
/*    */     else
/*    */     { RememberMeDsl.this.getAlwaysRemember(); }
/*    */   
/*    */   }
/*    */   
/*    */   RememberMeDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RememberMeDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */