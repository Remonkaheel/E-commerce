/*     */ package org.springframework.security.config.annotation.authentication.configurers.provisioning;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.jdbc.datasource.init.DataSourceInitializer;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*     */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*     */ import org.springframework.security.core.userdetails.UserCache;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.provisioning.JdbcUserDetailsManager;
/*     */ import org.springframework.security.provisioning.UserDetailsManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcUserDetailsManagerConfigurer<B extends ProviderManagerBuilder<B>>
/*     */   extends UserDetailsManagerConfigurer<B, JdbcUserDetailsManagerConfigurer<B>>
/*     */ {
/*     */   private DataSource dataSource;
/*  52 */   private List<Resource> initScripts = new ArrayList<>();
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer(JdbcUserDetailsManager manager) {
/*  55 */     super((UserDetailsManager)manager);
/*     */   }
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer() {
/*  59 */     this(new JdbcUserDetailsManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> dataSource(DataSource dataSource) {
/*  69 */     this.dataSource = dataSource;
/*  70 */     getUserDetailsService().setDataSource(dataSource);
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> usersByUsernameQuery(String query) {
/*  86 */     getUserDetailsService().setUsersByUsernameQuery(query);
/*  87 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> authoritiesByUsernameQuery(String query) {
/* 103 */     getUserDetailsService().setAuthoritiesByUsernameQuery(query);
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> groupAuthoritiesByUsername(String query) {
/* 124 */     JdbcUserDetailsManager userDetailsService = getUserDetailsService();
/* 125 */     userDetailsService.setEnableGroups(true);
/* 126 */     userDetailsService.setGroupAuthoritiesByUsernameQuery(query);
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> rolePrefix(String rolePrefix) {
/* 138 */     getUserDetailsService().setRolePrefix(rolePrefix);
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> userCache(UserCache userCache) {
/* 148 */     getUserDetailsService().setUserCache(userCache);
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initUserDetailsService() throws Exception {
/* 154 */     if (!this.initScripts.isEmpty()) {
/* 155 */       getDataSourceInit().afterPropertiesSet();
/*     */     }
/* 157 */     super.initUserDetailsService();
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManager getUserDetailsService() {
/* 162 */     return (JdbcUserDetailsManager)super.getUserDetailsService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManagerConfigurer<B> withDefaultSchema() {
/* 171 */     this.initScripts.add(new ClassPathResource("org/springframework/security/core/userdetails/jdbc/users.ddl"));
/* 172 */     return this;
/*     */   }
/*     */   
/*     */   protected DatabasePopulator getDatabasePopulator() {
/* 176 */     ResourceDatabasePopulator dbp = new ResourceDatabasePopulator();
/* 177 */     dbp.setScripts(this.initScripts.<Resource>toArray(new Resource[0]));
/* 178 */     return (DatabasePopulator)dbp;
/*     */   }
/*     */   
/*     */   private DataSourceInitializer getDataSourceInit() {
/* 182 */     DataSourceInitializer dsi = new DataSourceInitializer();
/* 183 */     dsi.setDatabasePopulator(getDatabasePopulator());
/* 184 */     dsi.setDataSource(this.dataSource);
/* 185 */     return dsi;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurers\provisioning\JdbcUserDetailsManagerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */