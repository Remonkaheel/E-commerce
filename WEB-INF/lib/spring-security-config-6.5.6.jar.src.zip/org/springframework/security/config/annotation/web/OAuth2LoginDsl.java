/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*     */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000\001\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\020\016\n\002\020\013\n\002\b\f\n\002\030\002\n\002\b\013\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\026\032\0020\0332\027\020O\032\023\022\004\022\0020P\022\004\022\0020\0330\027¢\006\002\bQJ\026\020R\032\0020\0332\006\020R\032\002002\006\020S\032\00201J\037\020T\032\024\022\n\022\b\022\004\022\0020\0320\031\022\004\022\0020\0330\027H\000¢\006\002\bUJ\006\020C\032\0020\033J\037\020I\032\0020\0332\027\020V\032\023\022\004\022\0020W\022\004\022\0020\0330\027¢\006\002\bQJ\037\020K\032\0020\0332\027\020X\032\023\022\004\022\0020Y\022\004\022\0020\0330\027¢\006\002\bQJ\037\020M\032\0020\0332\027\020Z\032\023\022\004\022\0020[\022\004\022\0020\0330\027¢\006\002\bQR&\020\003\032\016\022\004\022\0020\005\022\002\b\003\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\034\020\020\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R&\020\026\032\032\022\016\022\f0\030R\b\022\004\022\0020\0320\031\022\004\022\0020\033\030\0010\027X\016¢\006\002\n\000R\034\020\034\032\004\030\0010\035X\016¢\006\016\n\000\032\004\b\036\020\037\"\004\b \020!R\034\020\"\032\004\030\0010#X\016¢\006\016\n\000\032\004\b$\020%\"\004\b&\020'R\034\020(\032\004\030\0010)X\016¢\006\016\n\000\032\004\b*\020+\"\004\b,\020-R\034\020.\032\020\022\004\022\00200\022\004\022\00201\030\0010/X\016¢\006\002\n\000R\034\0202\032\004\030\00100X\016¢\006\016\n\000\032\004\b3\0204\"\004\b5\0206R\034\0207\032\004\030\00100X\016¢\006\016\n\000\032\004\b8\0204\"\004\b9\0206R\034\020:\032\004\030\00100X\016¢\006\016\n\000\032\004\b;\0204\"\004\b<\0206R\034\020=\032\004\030\0010>X\016¢\006\016\n\000\032\004\b?\020@\"\004\bA\020BR\036\020C\032\004\030\00101X\016¢\006\020\n\002\020H\032\004\bD\020E\"\004\bF\020GR&\020I\032\032\022\016\022\f0JR\b\022\004\022\0020\0320\031\022\004\022\0020\033\030\0010\027X\016¢\006\002\n\000R&\020K\032\032\022\016\022\f0LR\b\022\004\022\0020\0320\031\022\004\022\0020\033\030\0010\027X\016¢\006\002\n\000R&\020M\032\032\022\016\022\f0NR\b\022\004\022\0020\0320\031\022\004\022\0020\033\030\0010\027X\016¢\006\002\n\000¨\006\\"}, d2 = {"Lorg/springframework/security/config/annotation/web/OAuth2LoginDsl;", "", "()V", "authenticationDetailsSource", "Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "Ljakarta/servlet/http/HttpServletRequest;", "getAuthenticationDetailsSource", "()Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "setAuthenticationDetailsSource", "(Lorg/springframework/security/authentication/AuthenticationDetailsSource;)V", "authenticationFailureHandler", "Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "getAuthenticationFailureHandler", "()Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "setAuthenticationFailureHandler", "(Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;)V", "authenticationSuccessHandler", "Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "getAuthenticationSuccessHandler", "()Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "setAuthenticationSuccessHandler", "(Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;)V", "authorizationEndpoint", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$AuthorizationEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "authorizedClientRepository", "Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizedClientRepository;", "getAuthorizedClientRepository", "()Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizedClientRepository;", "setAuthorizedClientRepository", "(Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizedClientRepository;)V", "authorizedClientService", "Lorg/springframework/security/oauth2/client/OAuth2AuthorizedClientService;", "getAuthorizedClientService", "()Lorg/springframework/security/oauth2/client/OAuth2AuthorizedClientService;", "setAuthorizedClientService", "(Lorg/springframework/security/oauth2/client/OAuth2AuthorizedClientService;)V", "clientRegistrationRepository", "Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;", "getClientRegistrationRepository", "()Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;", "setClientRegistrationRepository", "(Lorg/springframework/security/oauth2/client/registration/ClientRegistrationRepository;)V", "defaultSuccessUrlOption", "Lkotlin/Pair;", "", "", "failureUrl", "getFailureUrl", "()Ljava/lang/String;", "setFailureUrl", "(Ljava/lang/String;)V", "loginPage", "getLoginPage", "setLoginPage", "loginProcessingUrl", "getLoginProcessingUrl", "setLoginProcessingUrl", "oidcSessionRegistry", "Lorg/springframework/security/oauth2/client/oidc/session/OidcSessionRegistry;", "getOidcSessionRegistry", "()Lorg/springframework/security/oauth2/client/oidc/session/OidcSessionRegistry;", "setOidcSessionRegistry", "(Lorg/springframework/security/oauth2/client/oidc/session/OidcSessionRegistry;)V", "permitAll", "getPermitAll", "()Ljava/lang/Boolean;", "setPermitAll", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "redirectionEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$RedirectionEndpointConfig;", "tokenEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$TokenEndpointConfig;", "userInfoEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$UserInfoEndpointConfig;", "authorizationEndpointConfig", "Lorg/springframework/security/config/annotation/web/oauth2/login/AuthorizationEndpointDsl;", "Lkotlin/ExtensionFunctionType;", "defaultSuccessUrl", "alwaysUse", "get", "get$spring_security_config", "redirectionEndpointConfig", "Lorg/springframework/security/config/annotation/web/oauth2/login/RedirectionEndpointDsl;", "tokenEndpointConfig", "Lorg/springframework/security/config/annotation/web/oauth2/login/TokenEndpointDsl;", "userInfoEndpointConfig", "Lorg/springframework/security/config/annotation/web/oauth2/login/UserInfoEndpointDsl;", "spring-security-config"})
/*     */ public final class OAuth2LoginDsl {
/*     */   @Nullable
/*     */   private ClientRegistrationRepository clientRegistrationRepository;
/*     */   @Nullable
/*     */   private OAuth2AuthorizedClientRepository authorizedClientRepository;
/*     */   @Nullable
/*     */   private OAuth2AuthorizedClientService authorizedClientService;
/*     */   @Nullable
/*     */   private String loginPage;
/*     */   @Nullable
/*     */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*     */   @Nullable
/*     */   private AuthenticationFailureHandler authenticationFailureHandler;
/*     */   @Nullable
/*     */   private String failureUrl;
/*     */   @Nullable
/*     */   private String loginProcessingUrl;
/*     */   @Nullable
/*     */   private Boolean permitAll;
/*     */   @Nullable
/*     */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource;
/*     */   @Nullable
/*     */   private OidcSessionRegistry oidcSessionRegistry;
/*     */   @Nullable
/*     */   private Pair<String, Boolean> defaultSuccessUrlOption;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2LoginConfigurer<HttpSecurity>.AuthorizationEndpointConfig, Unit> authorizationEndpoint;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2LoginConfigurer<HttpSecurity>.TokenEndpointConfig, Unit> tokenEndpoint;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2LoginConfigurer<HttpSecurity>.RedirectionEndpointConfig, Unit> redirectionEndpoint;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2LoginConfigurer<HttpSecurity>.UserInfoEndpointConfig, Unit> userInfoEndpoint;
/*     */   
/*     */   @Nullable
/*  55 */   public final ClientRegistrationRepository getClientRegistrationRepository() { return this.clientRegistrationRepository; } public final void setClientRegistrationRepository(@Nullable ClientRegistrationRepository <set-?>) { this.clientRegistrationRepository = <set-?>; } @Nullable
/*  56 */   public final OAuth2AuthorizedClientRepository getAuthorizedClientRepository() { return this.authorizedClientRepository; } public final void setAuthorizedClientRepository(@Nullable OAuth2AuthorizedClientRepository <set-?>) { this.authorizedClientRepository = <set-?>; } @Nullable
/*  57 */   public final OAuth2AuthorizedClientService getAuthorizedClientService() { return this.authorizedClientService; } public final void setAuthorizedClientService(@Nullable OAuth2AuthorizedClientService <set-?>) { this.authorizedClientService = <set-?>; } @Nullable
/*  58 */   public final String getLoginPage() { return this.loginPage; } public final void setLoginPage(@Nullable String <set-?>) { this.loginPage = <set-?>; } @Nullable
/*  59 */   public final AuthenticationSuccessHandler getAuthenticationSuccessHandler() { return this.authenticationSuccessHandler; } public final void setAuthenticationSuccessHandler(@Nullable AuthenticationSuccessHandler <set-?>) { this.authenticationSuccessHandler = <set-?>; } @Nullable
/*  60 */   public final AuthenticationFailureHandler getAuthenticationFailureHandler() { return this.authenticationFailureHandler; } public final void setAuthenticationFailureHandler(@Nullable AuthenticationFailureHandler <set-?>) { this.authenticationFailureHandler = <set-?>; } @Nullable
/*  61 */   public final String getFailureUrl() { return this.failureUrl; } public final void setFailureUrl(@Nullable String <set-?>) { this.failureUrl = <set-?>; } @Nullable
/*  62 */   public final String getLoginProcessingUrl() { return this.loginProcessingUrl; } public final void setLoginProcessingUrl(@Nullable String <set-?>) { this.loginProcessingUrl = <set-?>; } @Nullable
/*  63 */   public final Boolean getPermitAll() { return this.permitAll; } public final void setPermitAll(@Nullable Boolean <set-?>) { this.permitAll = <set-?>; } @Nullable
/*  64 */   public final AuthenticationDetailsSource<HttpServletRequest, ?> getAuthenticationDetailsSource() { return this.authenticationDetailsSource; } public final void setAuthenticationDetailsSource(@Nullable AuthenticationDetailsSource<HttpServletRequest, ?> <set-?>) { this.authenticationDetailsSource = <set-?>; } @Nullable
/*  65 */   public final OidcSessionRegistry getOidcSessionRegistry() { return this.oidcSessionRegistry; } public final void setOidcSessionRegistry(@Nullable OidcSessionRegistry <set-?>) { this.oidcSessionRegistry = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void permitAll() {
/*  78 */     this.permitAll = Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void defaultSuccessUrl(@NotNull String defaultSuccessUrl, boolean alwaysUse) {
/*  91 */     Intrinsics.checkNotNullParameter(defaultSuccessUrl, "defaultSuccessUrl"); this.defaultSuccessUrlOption = new Pair(defaultSuccessUrl, Boolean.valueOf(alwaysUse));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void authorizationEndpoint(@NotNull Function1 authorizationEndpointConfig) {
/* 123 */     Intrinsics.checkNotNullParameter(authorizationEndpointConfig, "authorizationEndpointConfig"); AuthorizationEndpointDsl authorizationEndpointDsl = new AuthorizationEndpointDsl(); authorizationEndpointConfig.invoke(authorizationEndpointDsl); this.authorizationEndpoint = authorizationEndpointDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void tokenEndpoint(@NotNull Function1 tokenEndpointConfig) {
/* 155 */     Intrinsics.checkNotNullParameter(tokenEndpointConfig, "tokenEndpointConfig"); TokenEndpointDsl tokenEndpointDsl = new TokenEndpointDsl(); tokenEndpointConfig.invoke(tokenEndpointDsl); this.tokenEndpoint = tokenEndpointDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void redirectionEndpoint(@NotNull Function1 redirectionEndpointConfig) {
/* 187 */     Intrinsics.checkNotNullParameter(redirectionEndpointConfig, "redirectionEndpointConfig"); RedirectionEndpointDsl redirectionEndpointDsl = new RedirectionEndpointDsl(); redirectionEndpointConfig.invoke(redirectionEndpointDsl); this.redirectionEndpoint = redirectionEndpointDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void userInfoEndpoint(@NotNull Function1 userInfoEndpointConfig) {
/* 219 */     Intrinsics.checkNotNullParameter(userInfoEndpointConfig, "userInfoEndpointConfig"); UserInfoEndpointDsl userInfoEndpointDsl = new UserInfoEndpointDsl(); userInfoEndpointConfig.invoke(userInfoEndpointDsl); this.userInfoEndpoint = userInfoEndpointDsl.get$spring_security_config();
/*     */   }
/*     */   
/*     */   @NotNull
/* 223 */   public final Function1<OAuth2LoginConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new OAuth2LoginDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oauth2Login", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOAuth2LoginDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OAuth2LoginDsl.kt\norg/springframework/security/config/annotation/web/OAuth2LoginDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,245:1\n1#2:246\n*E\n"})
/* 224 */   static final class OAuth2LoginDsl$get$1 extends Lambda implements Function1<OAuth2LoginConfigurer<HttpSecurity>, Unit> { public final void invoke(OAuth2LoginConfigurer oauth2Login) { Intrinsics.checkNotNullParameter(oauth2Login, "oauth2Login"); if (OAuth2LoginDsl.this.getClientRegistrationRepository() != null) { ClientRegistrationRepository clientRegistrationRepository1 = OAuth2LoginDsl.this.getClientRegistrationRepository(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; ClientRegistrationRepository clientRegistrationRepository2 = clientRegistrationRepository1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 246 */         int $i$a$-also-OAuth2LoginDsl$get$1$1 = 0; oauth2Login.clientRegistrationRepository(oAuth2LoginDsl1.getClientRegistrationRepository()); } else { OAuth2LoginDsl.this.getClientRegistrationRepository(); }  if (OAuth2LoginDsl.this.getAuthorizedClientRepository() != null) { OAuth2AuthorizedClientRepository oAuth2AuthorizedClientRepository1 = OAuth2LoginDsl.this.getAuthorizedClientRepository(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; OAuth2AuthorizedClientRepository oAuth2AuthorizedClientRepository2 = oAuth2AuthorizedClientRepository1; int $i$a$-also-OAuth2LoginDsl$get$1$2 = 0; oauth2Login.authorizedClientRepository(oAuth2LoginDsl1.getAuthorizedClientRepository()); } else { OAuth2LoginDsl.this.getAuthorizedClientRepository(); }  if (OAuth2LoginDsl.this.getAuthorizedClientService() != null) { OAuth2AuthorizedClientService oAuth2AuthorizedClientService1 = OAuth2LoginDsl.this.getAuthorizedClientService(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; OAuth2AuthorizedClientService oAuth2AuthorizedClientService2 = oAuth2AuthorizedClientService1; int $i$a$-also-OAuth2LoginDsl$get$1$3 = 0; oauth2Login.authorizedClientService(oAuth2LoginDsl1.getAuthorizedClientService()); } else { OAuth2LoginDsl.this.getAuthorizedClientService(); }  if (OAuth2LoginDsl.this.getLoginPage() != null) { String str1 = OAuth2LoginDsl.this.getLoginPage(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; String str2 = str1; int $i$a$-also-OAuth2LoginDsl$get$1$4 = 0; oauth2Login.loginPage(oAuth2LoginDsl1.getLoginPage()); } else { OAuth2LoginDsl.this.getLoginPage(); }  if (OAuth2LoginDsl.this.getFailureUrl() != null) { String str1 = OAuth2LoginDsl.this.getFailureUrl(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; String str2 = str1; int $i$a$-also-OAuth2LoginDsl$get$1$5 = 0; oauth2Login.failureUrl(oAuth2LoginDsl1.getFailureUrl()); } else { OAuth2LoginDsl.this.getFailureUrl(); }  if (OAuth2LoginDsl.this.getLoginProcessingUrl() != null) { String str1 = OAuth2LoginDsl.this.getLoginProcessingUrl(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; String str2 = str1; int $i$a$-also-OAuth2LoginDsl$get$1$6 = 0; oauth2Login.loginProcessingUrl(oAuth2LoginDsl1.getLoginProcessingUrl()); } else { OAuth2LoginDsl.this.getLoginProcessingUrl(); }  if (OAuth2LoginDsl.this.getPermitAll() != null) { Boolean bool = OAuth2LoginDsl.this.getPermitAll(); OAuth2LoginDsl oAuth2LoginDsl1 = OAuth2LoginDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-OAuth2LoginDsl$get$1$7 = 0; Intrinsics.checkNotNull(oAuth2LoginDsl1.getPermitAll()); oauth2Login.permitAll(oAuth2LoginDsl1.getPermitAll().booleanValue()); } else { OAuth2LoginDsl.this.getPermitAll(); }  Pair pair1 = OAuth2LoginDsl.this.defaultSuccessUrlOption; OAuth2LoginDsl oAuth2LoginDsl = OAuth2LoginDsl.this; Pair it = pair1; int $i$a$-also-OAuth2LoginDsl$get$1$8 = 0; Intrinsics.checkNotNull(oAuth2LoginDsl.defaultSuccessUrlOption); Intrinsics.checkNotNull(oAuth2LoginDsl.defaultSuccessUrlOption); oauth2Login.defaultSuccessUrl((String)oAuth2LoginDsl.defaultSuccessUrlOption.getFirst(), ((Boolean)oAuth2LoginDsl.defaultSuccessUrlOption.getSecond()).booleanValue()); OAuth2LoginDsl.this.defaultSuccessUrlOption; if (OAuth2LoginDsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = OAuth2LoginDsl.this.getAuthenticationSuccessHandler(); oAuth2LoginDsl = OAuth2LoginDsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-OAuth2LoginDsl$get$1$9 = 0; oauth2Login.successHandler(oAuth2LoginDsl.getAuthenticationSuccessHandler()); } else { OAuth2LoginDsl.this.getAuthenticationSuccessHandler(); }  if (OAuth2LoginDsl.this.getAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = OAuth2LoginDsl.this.getAuthenticationFailureHandler(); oAuth2LoginDsl = OAuth2LoginDsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-OAuth2LoginDsl$get$1$10 = 0; oauth2Login.failureHandler(oAuth2LoginDsl.getAuthenticationFailureHandler()); } else { OAuth2LoginDsl.this.getAuthenticationFailureHandler(); }  if (OAuth2LoginDsl.this.authorizationEndpoint != null) { Function1 function11 = OAuth2LoginDsl.this.authorizationEndpoint; oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$11 = 0; oAuth2LoginDsl.authorizationEndpoint; oauth2Login.authorizationEndpoint((oAuth2LoginDsl.authorizationEndpoint != null) ? oAuth2LoginDsl.authorizationEndpoint::invoke$lambda$11$lambda$10 : null); } else { OAuth2LoginDsl.this.authorizationEndpoint; }  if (OAuth2LoginDsl.this.tokenEndpoint != null) { Function1 function11 = OAuth2LoginDsl.this.tokenEndpoint; oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$12 = 0; oAuth2LoginDsl.tokenEndpoint; oauth2Login.tokenEndpoint((oAuth2LoginDsl.tokenEndpoint != null) ? oAuth2LoginDsl.tokenEndpoint::invoke$lambda$13$lambda$12 : null); } else { OAuth2LoginDsl.this.tokenEndpoint; }  if (OAuth2LoginDsl.this.redirectionEndpoint != null) { Function1 function11 = OAuth2LoginDsl.this.redirectionEndpoint; oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$13 = 0; oAuth2LoginDsl.redirectionEndpoint; oauth2Login.redirectionEndpoint((oAuth2LoginDsl.redirectionEndpoint != null) ? oAuth2LoginDsl.redirectionEndpoint::invoke$lambda$15$lambda$14 : null); } else { OAuth2LoginDsl.this.redirectionEndpoint; }  if (OAuth2LoginDsl.this.userInfoEndpoint != null) { Function1 function11 = OAuth2LoginDsl.this.userInfoEndpoint; oAuth2LoginDsl = OAuth2LoginDsl.this; Function1 function12 = function11; int $i$a$-also-OAuth2LoginDsl$get$1$14 = 0; oAuth2LoginDsl.userInfoEndpoint; oauth2Login.userInfoEndpoint((oAuth2LoginDsl.userInfoEndpoint != null) ? oAuth2LoginDsl.userInfoEndpoint::invoke$lambda$17$lambda$16 : null); } else { OAuth2LoginDsl.this.userInfoEndpoint; }  if (OAuth2LoginDsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource1 = OAuth2LoginDsl.this.getAuthenticationDetailsSource(); oAuth2LoginDsl = OAuth2LoginDsl.this; AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource2 = authenticationDetailsSource1; int $i$a$-also-OAuth2LoginDsl$get$1$15 = 0; oauth2Login.authenticationDetailsSource(oAuth2LoginDsl.getAuthenticationDetailsSource()); } else { OAuth2LoginDsl.this.getAuthenticationDetailsSource(); }  if (OAuth2LoginDsl.this.getOidcSessionRegistry() != null) { OidcSessionRegistry oidcSessionRegistry1 = OAuth2LoginDsl.this.getOidcSessionRegistry(); oAuth2LoginDsl = OAuth2LoginDsl.this; OidcSessionRegistry oidcSessionRegistry2 = oidcSessionRegistry1; int $i$a$-also-OAuth2LoginDsl$get$1$16 = 0;
/*     */         oauth2Login.oidcSessionRegistry(oAuth2LoginDsl.getOidcSessionRegistry()); }
/*     */       else
/*     */       { OAuth2LoginDsl.this.getOidcSessionRegistry(); }
/*     */        }
/*     */ 
/*     */     
/*     */     private static final void invoke$lambda$11$lambda$10(Function1 $tmp0, OAuth2LoginConfigurer.AuthorizationEndpointConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$13$lambda$12(Function1 $tmp0, OAuth2LoginConfigurer.TokenEndpointConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$15$lambda$14(Function1 $tmp0, OAuth2LoginConfigurer.RedirectionEndpointConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$17$lambda$16(Function1 $tmp0, OAuth2LoginConfigurer.UserInfoEndpointConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     OAuth2LoginDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OAuth2LoginDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */