/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\n\002\020\013\n\002\b\006\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\020\032\030\022\016\022\f0\022R\b\022\004\022\0020\0240\023\022\004\022\0020\0250\021H\000¢\006\002\b\026R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\036\020\t\032\004\030\0010\nX\016¢\006\020\n\002\020\017\032\004\b\013\020\f\"\004\b\r\020\016¨\006\027"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/ContentSecurityPolicyDsl;", "", "()V", "policyDirectives", "", "getPolicyDirectives", "()Ljava/lang/String;", "setPolicyDirectives", "(Ljava/lang/String;)V", "reportOnly", "", "getReportOnly", "()Ljava/lang/Boolean;", "setReportOnly", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ContentSecurityPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class ContentSecurityPolicyDsl
/*    */ {
/*    */   @Nullable
/*    */   private String policyDirectives;
/*    */   @Nullable
/*    */   private Boolean reportOnly;
/*    */   
/*    */   @Nullable
/*    */   public final String getPolicyDirectives() {
/* 33 */     return this.policyDirectives; } public final void setPolicyDirectives(@Nullable String <set-?>) { this.policyDirectives = <set-?>; } @Nullable
/* 34 */   public final Boolean getReportOnly() { return this.reportOnly; } public final void setReportOnly(@Nullable Boolean <set-?>) { this.reportOnly = <set-?>; }
/*    */   
/*    */   @NotNull
/* 37 */   public final Function1<HeadersConfigurer<HttpSecurity>.ContentSecurityPolicyConfig, Unit> get$spring_security_config() { return new ContentSecurityPolicyDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "contentSecurityPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ContentSecurityPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 38 */   static final class ContentSecurityPolicyDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.ContentSecurityPolicyConfig, Unit> { public final void invoke(HeadersConfigurer.ContentSecurityPolicyConfig contentSecurityPolicy) { Intrinsics.checkNotNullParameter(contentSecurityPolicy, "contentSecurityPolicy"); String str1 = ContentSecurityPolicyDsl.this.getPolicyDirectives(); ContentSecurityPolicyDsl contentSecurityPolicyDsl = ContentSecurityPolicyDsl.this; String str2 = str1; int $i$a$-also-ContentSecurityPolicyDsl$get$1$1 = 0;
/* 39 */       contentSecurityPolicy.policyDirectives(contentSecurityPolicyDsl.getPolicyDirectives());
/*    */       ContentSecurityPolicyDsl.this.getPolicyDirectives();
/* 41 */       Boolean bool = ContentSecurityPolicyDsl.this.getReportOnly(); contentSecurityPolicyDsl = ContentSecurityPolicyDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-ContentSecurityPolicyDsl$get$1$2 = 0;
/* 42 */       Intrinsics.checkNotNull(contentSecurityPolicyDsl.getReportOnly()); if (contentSecurityPolicyDsl.getReportOnly().booleanValue())
/* 43 */         contentSecurityPolicy.reportOnly(); 
/*    */       ContentSecurityPolicyDsl.this.getReportOnly(); }
/*    */ 
/*    */     
/*    */     ContentSecurityPolicyDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\ContentSecurityPolicyDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */