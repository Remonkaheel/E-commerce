/*    */ package org.springframework.security.config.annotation.web.session;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SessionSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\005\032\0020\006J#\020\007\032\030\022\016\022\f0\tR\b\022\004\022\0020\0130\n\022\004\022\0020\0060\bH\000¢\006\002\b\fJ\006\020\r\032\0020\006J\006\020\016\032\0020\006J\006\020\017\032\0020\006R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000¨\006\020"}, d2 = {"Lorg/springframework/security/config/annotation/web/session/SessionFixationDsl;", "", "()V", "strategy", "Lorg/springframework/security/config/annotation/web/session/SessionFixationStrategy;", "changeSessionId", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$SessionFixationConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "migrateSession", "newSession", "none", "spring-security-config"})
/*    */ public final class SessionFixationDsl
/*    */ {
/*    */   @Nullable
/*    */   private SessionFixationStrategy strategy;
/*    */   
/*    */   public final void newSession() {
/* 40 */     this.strategy = SessionFixationStrategy.NEW;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void migrateSession() {
/* 48 */     this.strategy = SessionFixationStrategy.MIGRATE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void changeSessionId() {
/* 58 */     this.strategy = SessionFixationStrategy.CHANGE_ID;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void none() {
/* 65 */     this.strategy = SessionFixationStrategy.NONE;
/*    */   }
/*    */   
/*    */   @NotNull
/* 69 */   public final Function1<SessionManagementConfigurer<HttpSecurity>.SessionFixationConfigurer, Unit> get$spring_security_config() { return new SessionFixationDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "sessionFixation", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$SessionFixationConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 70 */   static final class SessionFixationDsl$get$1 extends Lambda implements Function1<SessionManagementConfigurer<HttpSecurity>.SessionFixationConfigurer, Unit> { public final void invoke(SessionManagementConfigurer.SessionFixationConfigurer sessionFixation) { Intrinsics.checkNotNullParameter(sessionFixation, "sessionFixation"); SessionFixationStrategy sessionFixationStrategy1 = SessionFixationDsl.this.strategy; SessionFixationDsl sessionFixationDsl = SessionFixationDsl.this; SessionFixationStrategy it = sessionFixationStrategy1; int $i$a$-also-SessionFixationDsl$get$1$1 = 0;
/* 71 */       sessionFixationDsl.strategy; switch ((sessionFixationDsl.strategy == null) ? -1 : WhenMappings.$EnumSwitchMapping$0[sessionFixationDsl.strategy.ordinal()]) { case true:
/* 72 */           sessionFixation.newSession(); break;
/* 73 */         case true: sessionFixation.migrateSession(); break;
/* 74 */         case true: sessionFixation.changeSessionId(); break;
/* 75 */         case true: sessionFixation.none();
/*    */           break;
/*    */         case true:
/*    */           break; }
/*    */       
/*    */       SessionFixationDsl.this.strategy; }
/*    */ 
/*    */     
/*    */     SessionFixationDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\session\SessionFixationDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */