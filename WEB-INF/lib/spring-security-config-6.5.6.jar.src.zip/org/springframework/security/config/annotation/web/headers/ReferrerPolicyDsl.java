/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\t\032\030\022\016\022\f0\013R\b\022\004\022\0020\r0\f\022\004\022\0020\0160\nH\000¢\006\002\b\017R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\b¨\006\020"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/ReferrerPolicyDsl;", "", "()V", "policy", "Lorg/springframework/security/web/header/writers/ReferrerPolicyHeaderWriter$ReferrerPolicy;", "getPolicy", "()Lorg/springframework/security/web/header/writers/ReferrerPolicyHeaderWriter$ReferrerPolicy;", "setPolicy", "(Lorg/springframework/security/web/header/writers/ReferrerPolicyHeaderWriter$ReferrerPolicy;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ReferrerPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class ReferrerPolicyDsl
/*    */ {
/*    */   @Nullable
/*    */   private ReferrerPolicyHeaderWriter.ReferrerPolicy policy;
/*    */   
/*    */   @Nullable
/*    */   public final ReferrerPolicyHeaderWriter.ReferrerPolicy getPolicy() {
/* 33 */     return this.policy; } public final void setPolicy(@Nullable ReferrerPolicyHeaderWriter.ReferrerPolicy <set-?>) { this.policy = <set-?>; }
/*    */   
/*    */   @NotNull
/* 36 */   public final Function1<HeadersConfigurer<HttpSecurity>.ReferrerPolicyConfig, Unit> get$spring_security_config() { return new ReferrerPolicyDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "referrerPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ReferrerPolicyConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 37 */   static final class ReferrerPolicyDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.ReferrerPolicyConfig, Unit> { public final void invoke(HeadersConfigurer.ReferrerPolicyConfig referrerPolicy) { Intrinsics.checkNotNullParameter(referrerPolicy, "referrerPolicy"); ReferrerPolicyHeaderWriter.ReferrerPolicy referrerPolicy1 = ReferrerPolicyDsl.this.getPolicy(); ReferrerPolicyDsl referrerPolicyDsl = ReferrerPolicyDsl.this; ReferrerPolicyHeaderWriter.ReferrerPolicy it = referrerPolicy1; int $i$a$-also-ReferrerPolicyDsl$get$1$1 = 0;
/* 38 */       referrerPolicy.policy(referrerPolicyDsl.getPolicy());
/*    */       ReferrerPolicyDsl.this.getPolicy(); }
/*    */ 
/*    */     
/*    */     ReferrerPolicyDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\ReferrerPolicyDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */