/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.web.authentication.logout.CookieClearingLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.DelegatingLogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutFilter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessEventPublishingLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LogoutConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<LogoutConfigurer<H>, H>
/*     */ {
/*  75 */   private List<LogoutHandler> logoutHandlers = new ArrayList<>();
/*     */   
/*  77 */   private SecurityContextLogoutHandler contextLogoutHandler = new SecurityContextLogoutHandler();
/*     */   
/*  79 */   private String logoutSuccessUrl = "/login?logout";
/*     */   
/*     */   private LogoutSuccessHandler logoutSuccessHandler;
/*     */   
/*  83 */   private String logoutUrl = "/logout";
/*     */   
/*     */   private RequestMatcher logoutRequestMatcher;
/*     */   
/*     */   private boolean permitAll;
/*     */   
/*     */   private boolean customLogoutSuccess;
/*     */   
/*  91 */   private LinkedHashMap<RequestMatcher, LogoutSuccessHandler> defaultLogoutSuccessHandlerMappings = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> addLogoutHandler(LogoutHandler logoutHandler) {
/* 108 */     Assert.notNull(logoutHandler, "logoutHandler cannot be null");
/* 109 */     this.logoutHandlers.add(logoutHandler);
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> clearAuthentication(boolean clearAuthentication) {
/* 121 */     this.contextLogoutHandler.setClearAuthentication(clearAuthentication);
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> invalidateHttpSession(boolean invalidateHttpSession) {
/* 133 */     this.contextLogoutHandler.setInvalidateHttpSession(invalidateHttpSession);
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> logoutUrl(String logoutUrl) {
/* 156 */     this.logoutRequestMatcher = null;
/* 157 */     this.logoutUrl = logoutUrl;
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> logoutRequestMatcher(RequestMatcher logoutRequestMatcher) {
/* 170 */     this.logoutRequestMatcher = logoutRequestMatcher;
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> logoutSuccessUrl(String logoutSuccessUrl) {
/* 182 */     this.customLogoutSuccess = true;
/* 183 */     this.logoutSuccessUrl = logoutSuccessUrl;
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> permitAll() {
/* 192 */     return permitAll(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> deleteCookies(String... cookieNamesToClear) {
/* 203 */     return addLogoutHandler((LogoutHandler)new CookieClearingLogoutHandler(cookieNamesToClear));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> logoutSuccessHandler(LogoutSuccessHandler logoutSuccessHandler) {
/* 214 */     this.logoutSuccessUrl = null;
/* 215 */     this.customLogoutSuccess = true;
/* 216 */     this.logoutSuccessHandler = logoutSuccessHandler;
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> defaultLogoutSuccessHandlerFor(LogoutSuccessHandler handler, RequestMatcher preferredMatcher) {
/* 234 */     Assert.notNull(handler, "handler cannot be null");
/* 235 */     Assert.notNull(preferredMatcher, "preferredMatcher cannot be null");
/* 236 */     this.defaultLogoutSuccessHandlerMappings.put(preferredMatcher, handler);
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutConfigurer<H> permitAll(boolean permitAll) {
/* 247 */     this.permitAll = permitAll;
/* 248 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogoutSuccessHandler getLogoutSuccessHandler() {
/* 257 */     LogoutSuccessHandler handler = this.logoutSuccessHandler;
/* 258 */     if (handler == null) {
/* 259 */       handler = createDefaultSuccessHandler();
/* 260 */       this.logoutSuccessHandler = handler;
/*     */     } 
/* 262 */     return handler;
/*     */   }
/*     */   
/*     */   private LogoutSuccessHandler createDefaultSuccessHandler() {
/* 266 */     SimpleUrlLogoutSuccessHandler urlLogoutHandler = new SimpleUrlLogoutSuccessHandler();
/* 267 */     urlLogoutHandler.setDefaultTargetUrl(this.logoutSuccessUrl);
/* 268 */     if (this.defaultLogoutSuccessHandlerMappings.isEmpty()) {
/* 269 */       return (LogoutSuccessHandler)urlLogoutHandler;
/*     */     }
/* 271 */     DelegatingLogoutSuccessHandler successHandler = new DelegatingLogoutSuccessHandler(this.defaultLogoutSuccessHandlerMappings);
/*     */     
/* 273 */     successHandler.setDefaultLogoutSuccessHandler((LogoutSuccessHandler)urlLogoutHandler);
/* 274 */     return (LogoutSuccessHandler)successHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 279 */     if (this.permitAll) {
/* 280 */       PermitAllSupport.permitAll((HttpSecurityBuilder<? extends HttpSecurityBuilder<?>>)http, new String[] { this.logoutSuccessUrl });
/* 281 */       PermitAllSupport.permitAll((HttpSecurityBuilder<? extends HttpSecurityBuilder<?>>)http, new RequestMatcher[] { getLogoutRequestMatcher(http) });
/*     */     } 
/*     */     
/* 284 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/* 285 */     if (loginPageGeneratingFilter != null && !isCustomLogoutSuccess()) {
/* 286 */       loginPageGeneratingFilter.setLogoutSuccessUrl(getLogoutSuccessUrl());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) throws Exception {
/* 292 */     LogoutFilter logoutFilter = createLogoutFilter(http);
/* 293 */     http.addFilter((Filter)logoutFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isCustomLogoutSuccess() {
/* 303 */     return this.customLogoutSuccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLogoutSuccessUrl() {
/* 312 */     return this.logoutSuccessUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LogoutHandler> getLogoutHandlers() {
/* 320 */     return this.logoutHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LogoutFilter createLogoutFilter(H http) {
/* 331 */     this.contextLogoutHandler.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 332 */     this.contextLogoutHandler.setSecurityContextRepository(getSecurityContextRepository(http));
/* 333 */     this.logoutHandlers.add(this.contextLogoutHandler);
/* 334 */     this.logoutHandlers.add((LogoutHandler)postProcess(new LogoutSuccessEventPublishingLogoutHandler()));
/* 335 */     LogoutHandler[] handlers = this.logoutHandlers.<LogoutHandler>toArray(new LogoutHandler[0]);
/* 336 */     LogoutFilter result = new LogoutFilter(getLogoutSuccessHandler(), handlers);
/* 337 */     result.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 338 */     result.setLogoutRequestMatcher(getLogoutRequestMatcher(http));
/* 339 */     result = (LogoutFilter)postProcess(result);
/* 340 */     return result;
/*     */   }
/*     */   private SecurityContextRepository getSecurityContextRepository(H http) {
/*     */     HttpSessionSecurityContextRepository httpSessionSecurityContextRepository;
/* 344 */     SecurityContextRepository securityContextRepository = (SecurityContextRepository)http.getSharedObject(SecurityContextRepository.class);
/* 345 */     if (securityContextRepository == null) {
/* 346 */       httpSessionSecurityContextRepository = new HttpSessionSecurityContextRepository();
/*     */     }
/* 348 */     return (SecurityContextRepository)httpSessionSecurityContextRepository;
/*     */   }
/*     */   
/*     */   private RequestMatcher getLogoutRequestMatcher(H http) {
/* 352 */     if (this.logoutRequestMatcher != null) {
/* 353 */       return this.logoutRequestMatcher;
/*     */     }
/* 355 */     this.logoutRequestMatcher = createLogoutRequestMatcher(http);
/* 356 */     return this.logoutRequestMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   private RequestMatcher createLogoutRequestMatcher(H http) {
/* 361 */     RequestMatcher post = createLogoutRequestMatcher("POST");
/* 362 */     if (http.getConfigurer(CsrfConfigurer.class) != null) {
/* 363 */       return post;
/*     */     }
/* 365 */     RequestMatcher get = createLogoutRequestMatcher("GET");
/* 366 */     RequestMatcher put = createLogoutRequestMatcher("PUT");
/* 367 */     RequestMatcher delete = createLogoutRequestMatcher("DELETE");
/* 368 */     return (RequestMatcher)new OrRequestMatcher(new RequestMatcher[] { get, post, put, delete });
/*     */   }
/*     */   
/*     */   private RequestMatcher createLogoutRequestMatcher(String httpMethod) {
/* 372 */     return RequestMatcherFactory.matcher(HttpMethod.valueOf(httpMethod), this.logoutUrl);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\LogoutConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */