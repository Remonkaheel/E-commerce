/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.access.HandlerMappingIntrospectorRequestTransformer;
/*     */ import org.springframework.security.web.bind.support.AuthenticationPrincipalArgumentResolver;
/*     */ import org.springframework.security.web.debug.DebugFilter;
/*     */ import org.springframework.security.web.firewall.HttpFirewall;
/*     */ import org.springframework.security.web.firewall.RequestRejectedHandler;
/*     */ import org.springframework.security.web.method.annotation.AuthenticationPrincipalArgumentResolver;
/*     */ import org.springframework.security.web.method.annotation.CsrfTokenArgumentResolver;
/*     */ import org.springframework.security.web.method.annotation.CurrentSecurityContextArgumentResolver;
/*     */ import org.springframework.security.web.servlet.support.csrf.CsrfRequestDataValueProcessor;
/*     */ import org.springframework.web.filter.CompositeFilter;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*     */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WebMvcSecurityConfiguration
/*     */   implements WebMvcConfigurer, ApplicationContextAware
/*     */ {
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector";
/*     */   private static final String PATH_PATTERN_REQUEST_TRANSFORMER_BEAN_NAME = "pathPatternRequestTransformer";
/*     */   private BeanResolver beanResolver;
/*  86 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */   
/*     */   private AnnotationTemplateExpressionDefaults templateDefaults;
/*     */ 
/*     */   
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/*  93 */     AuthenticationPrincipalArgumentResolver authenticationPrincipalResolver = new AuthenticationPrincipalArgumentResolver();
/*  94 */     authenticationPrincipalResolver.setBeanResolver(this.beanResolver);
/*  95 */     authenticationPrincipalResolver.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/*  96 */     authenticationPrincipalResolver.setTemplateDefaults(this.templateDefaults);
/*  97 */     argumentResolvers.add(authenticationPrincipalResolver);
/*  98 */     argumentResolvers
/*  99 */       .add(new AuthenticationPrincipalArgumentResolver());
/* 100 */     CurrentSecurityContextArgumentResolver currentSecurityContextArgumentResolver = new CurrentSecurityContextArgumentResolver();
/* 101 */     currentSecurityContextArgumentResolver.setBeanResolver(this.beanResolver);
/* 102 */     currentSecurityContextArgumentResolver.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 103 */     currentSecurityContextArgumentResolver.setTemplateDefaults(this.templateDefaults);
/* 104 */     argumentResolvers.add(currentSecurityContextArgumentResolver);
/* 105 */     argumentResolvers.add(new CsrfTokenArgumentResolver());
/*     */   }
/*     */   
/*     */   @Bean
/*     */   RequestDataValueProcessor requestDataValueProcessor() {
/* 110 */     return (RequestDataValueProcessor)new CsrfRequestDataValueProcessor();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 115 */     this.beanResolver = (BeanResolver)new BeanFactoryResolver((BeanFactory)applicationContext.getAutowireCapableBeanFactory());
/* 116 */     if ((applicationContext.getBeanNamesForType(SecurityContextHolderStrategy.class)).length == 1) {
/* 117 */       this.securityContextHolderStrategy = (SecurityContextHolderStrategy)applicationContext.getBean(SecurityContextHolderStrategy.class);
/*     */     }
/* 119 */     if ((applicationContext.getBeanNamesForType(AnnotationTemplateExpressionDefaults.class)).length == 1) {
/* 120 */       this.templateDefaults = (AnnotationTemplateExpressionDefaults)applicationContext.getBean(AnnotationTemplateExpressionDefaults.class);
/*     */     }
/*     */   }
/*     */   
/*     */   @Bean
/*     */   static BeanDefinitionRegistryPostProcessor springSecurityHandlerMappingIntrospectorBeanDefinitionRegistryPostProcessor() {
/* 126 */     return new BeanDefinitionRegistryPostProcessor()
/*     */       {
/*     */         public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */ 
/*     */         
/*     */         public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 133 */           if (!registry.containsBeanDefinition("mvcHandlerMappingIntrospector")) {
/*     */             return;
/*     */           }
/*     */           
/* 137 */           String hmiRequestTransformerBeanName = "mvcHandlerMappingIntrospectorRequestTransformer";
/* 138 */           if (!registry.containsBeanDefinition("pathPatternRequestTransformer") && 
/* 139 */             !registry.containsBeanDefinition(hmiRequestTransformerBeanName) && 
/* 140 */             !registry.containsBeanDefinition(hmiRequestTransformerBeanName)) {
/*     */ 
/*     */ 
/*     */             
/* 144 */             AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(HandlerMappingIntrospectorRequestTransformer.class).addConstructorArgReference("mvcHandlerMappingIntrospector").getBeanDefinition();
/* 145 */             registry.registerBeanDefinition(hmiRequestTransformerBeanName, (BeanDefinition)abstractBeanDefinition);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 150 */           BeanDefinition filterChainProxy = registry.getBeanDefinition("springSecurityFilterChain");
/*     */           
/* 152 */           if (!filterChainProxy.getResolvableType().isInstance(WebMvcSecurityConfiguration.CompositeFilterChainProxy.class)) {
/*     */ 
/*     */             
/* 155 */             BeanDefinitionBuilder hmiCacheFilterBldr = BeanDefinitionBuilder.rootBeanDefinition(WebMvcSecurityConfiguration.HandlerMappingIntrospectorCacheFilterFactoryBean.class).setRole(2);
/*     */             
/* 157 */             ManagedList<BeanMetadataElement> filters = new ManagedList();
/* 158 */             filters.add(hmiCacheFilterBldr.getBeanDefinition());
/* 159 */             filters.add(filterChainProxy);
/*     */ 
/*     */             
/* 162 */             BeanDefinitionBuilder compositeSpringSecurityFilterChainBldr = BeanDefinitionBuilder.rootBeanDefinition(WebMvcSecurityConfiguration.CompositeFilterChainProxy.class).addConstructorArgValue(filters);
/*     */             
/* 164 */             registry.removeBeanDefinition("springSecurityFilterChain");
/* 165 */             registry.registerBeanDefinition("springSecurityFilterChain", (BeanDefinition)compositeSpringSecurityFilterChainBldr
/* 166 */                 .getBeanDefinition());
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static class HandlerMappingIntrospectorCacheFilterFactoryBean
/*     */     implements ApplicationContextAware, FactoryBean<Filter>
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setApplicationContext(ApplicationContext applicationContext) {
/* 187 */       this.applicationContext = applicationContext;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Filter getObject() throws Exception {
/* 193 */       HandlerMappingIntrospector handlerMappingIntrospector = (HandlerMappingIntrospector)this.applicationContext.getBean("mvcHandlerMappingIntrospector", HandlerMappingIntrospector.class);
/* 194 */       return handlerMappingIntrospector.createCacheFilter();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 199 */       return Filter.class;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static class CompositeFilterChainProxy
/*     */     extends FilterChainProxy
/*     */   {
/*     */     private final Filter doFilterDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final FilterChainProxy springSecurityFilterChain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CompositeFilterChainProxy(List<? extends Filter> filters) {
/* 228 */       this.doFilterDelegate = createDoFilterDelegate(filters);
/* 229 */       this.springSecurityFilterChain = findFilterChainProxy(filters);
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterPropertiesSet() {
/* 234 */       this.springSecurityFilterChain.afterPropertiesSet();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 240 */       this.doFilterDelegate.doFilter(request, response, chain);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Filter> getFilters(String url) {
/* 245 */       return this.springSecurityFilterChain.getFilters(url);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<SecurityFilterChain> getFilterChains() {
/* 250 */       return this.springSecurityFilterChain.getFilterChains();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 255 */       this.springSecurityFilterChain.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFilterChainValidator(FilterChainProxy.FilterChainValidator filterChainValidator) {
/* 260 */       this.springSecurityFilterChain.setFilterChainValidator(filterChainValidator);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFilterChainDecorator(FilterChainProxy.FilterChainDecorator filterChainDecorator) {
/* 265 */       this.springSecurityFilterChain.setFilterChainDecorator(filterChainDecorator);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFirewall(HttpFirewall firewall) {
/* 270 */       this.springSecurityFilterChain.setFirewall(firewall);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setRequestRejectedHandler(RequestRejectedHandler requestRejectedHandler) {
/* 275 */       this.springSecurityFilterChain.setRequestRejectedHandler(requestRejectedHandler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<? extends Filter> getFilters(HttpServletRequest request) {
/* 285 */       List<SecurityFilterChain> filterChains = this.springSecurityFilterChain.getFilterChains();
/* 286 */       for (SecurityFilterChain chain : filterChains) {
/* 287 */         if (chain.matches(request)) {
/* 288 */           return chain.getFilters();
/*     */         }
/*     */       } 
/* 291 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Filter createDoFilterDelegate(List<? extends Filter> filters) {
/* 300 */       CompositeFilter delegate = new CompositeFilter();
/* 301 */       delegate.setFilters(filters);
/* 302 */       return (Filter)delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static FilterChainProxy findFilterChainProxy(List<? extends Filter> filters) {
/* 312 */       for (Filter filter : filters) {
/* 313 */         if (filter instanceof FilterChainProxy) { FilterChainProxy fcp = (FilterChainProxy)filter;
/* 314 */           return fcp; }
/*     */         
/* 316 */         if (filter instanceof DebugFilter) { DebugFilter debugFilter = (DebugFilter)filter;
/* 317 */           return debugFilter.getFilterChainProxy(); }
/*     */       
/*     */       } 
/* 320 */       throw new IllegalStateException("Couldn't find FilterChainProxy in " + String.valueOf(filters));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\WebMvcSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */