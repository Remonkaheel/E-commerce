/*    */ package org.springframework.security.config.annotation.web.configuration;
/*    */ 
/*    */ import jakarta.servlet.Filter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.security.config.annotation.SecurityConfigurer;
/*    */ import org.springframework.security.config.annotation.web.WebSecurityConfigurer;
/*    */ import org.springframework.security.config.annotation.web.builders.WebSecurity;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AutowiredWebSecurityConfigurersIgnoreParents
/*    */ {
/*    */   private final ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   AutowiredWebSecurityConfigurersIgnoreParents(ConfigurableListableBeanFactory beanFactory) {
/* 44 */     Assert.notNull(beanFactory, "beanFactory cannot be null");
/* 45 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<SecurityConfigurer<Filter, WebSecurity>> getWebSecurityConfigurers() {
/* 50 */     List<SecurityConfigurer<Filter, WebSecurity>> webSecurityConfigurers = new ArrayList<>();
/* 51 */     Map<String, WebSecurityConfigurer> beansOfType = this.beanFactory.getBeansOfType(WebSecurityConfigurer.class);
/* 52 */     for (Map.Entry<String, WebSecurityConfigurer> entry : beansOfType.entrySet()) {
/* 53 */       webSecurityConfigurers.add((SecurityConfigurer<Filter, WebSecurity>)entry.getValue());
/*    */     }
/* 55 */     return webSecurityConfigurers;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\AutowiredWebSecurityConfigurersIgnoreParents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */