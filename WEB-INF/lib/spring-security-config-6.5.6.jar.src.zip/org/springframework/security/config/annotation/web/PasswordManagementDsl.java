/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.PasswordManagementConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020\t\032\024\022\n\022\b\022\004\022\0020\f0\013\022\004\022\0020\r0\nH\000¢\006\002\b\016R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\b¨\006\017"}, d2 = {"Lorg/springframework/security/config/annotation/web/PasswordManagementDsl;", "", "()V", "changePasswordPage", "", "getChangePasswordPage", "()Ljava/lang/String;", "setChangePasswordPage", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/PasswordManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class PasswordManagementDsl
/*    */ {
/*    */   @Nullable
/*    */   private String changePasswordPage;
/*    */   
/*    */   @Nullable
/*    */   public final String getChangePasswordPage() {
/* 32 */     return this.changePasswordPage; } public final void setChangePasswordPage(@Nullable String <set-?>) { this.changePasswordPage = <set-?>; }
/*    */   
/*    */   @NotNull
/* 35 */   public final Function1<PasswordManagementConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new PasswordManagementDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "passwordManagement", "Lorg/springframework/security/config/annotation/web/configurers/PasswordManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nPasswordManagementDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PasswordManagementDsl.kt\norg/springframework/security/config/annotation/web/PasswordManagementDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,40:1\n1#2:41\n*E\n"})
/* 36 */   static final class PasswordManagementDsl$get$1 extends Lambda implements Function1<PasswordManagementConfigurer<HttpSecurity>, Unit> { public final void invoke(PasswordManagementConfigurer passwordManagement) { Intrinsics.checkNotNullParameter(passwordManagement, "passwordManagement"); if (PasswordManagementDsl.this.getChangePasswordPage() != null) { String str1 = PasswordManagementDsl.this.getChangePasswordPage(); PasswordManagementDsl passwordManagementDsl = PasswordManagementDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 41 */         int $i$a$-also-PasswordManagementDsl$get$1$1 = 0;
/*    */         passwordManagement.changePasswordPage(passwordManagementDsl.getChangePasswordPage()); }
/*    */       else
/*    */       { PasswordManagementDsl.this.getChangePasswordPage(); }
/*    */        }
/*    */ 
/*    */     
/*    */     PasswordManagementDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\PasswordManagementDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */