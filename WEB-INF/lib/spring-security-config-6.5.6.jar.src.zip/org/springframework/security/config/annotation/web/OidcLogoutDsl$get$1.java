/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OidcLogoutConfigurer;
/*    */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oidcLogout", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OidcLogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nOidcLogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OidcLogoutDsl.kt\norg/springframework/security/config/annotation/web/OidcLogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,78:1\n1#2:79\n*E\n"})
/*    */ final class OidcLogoutDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OidcLogoutConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(OidcLogoutConfigurer oidcLogout) {
/* 71 */     Intrinsics.checkNotNullParameter(oidcLogout, "oidcLogout"); if (OidcLogoutDsl.this.getClientRegistrationRepository() != null) { ClientRegistrationRepository clientRegistrationRepository1 = OidcLogoutDsl.this.getClientRegistrationRepository(); OidcLogoutDsl oidcLogoutDsl = OidcLogoutDsl.this; ClientRegistrationRepository it = clientRegistrationRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 79 */       int $i$a$-also-OidcLogoutDsl$get$1$1 = 0; oidcLogout.clientRegistrationRepository(oidcLogoutDsl.getClientRegistrationRepository()); } else { OidcLogoutDsl.this.getClientRegistrationRepository(); }  if (OidcLogoutDsl.this.getOidcSessionRegistry() != null) { OidcSessionRegistry oidcSessionRegistry1 = OidcLogoutDsl.this.getOidcSessionRegistry(); OidcLogoutDsl oidcLogoutDsl = OidcLogoutDsl.this; OidcSessionRegistry it = oidcSessionRegistry1; int $i$a$-also-OidcLogoutDsl$get$1$2 = 0; oidcLogout.oidcSessionRegistry(oidcLogoutDsl.getOidcSessionRegistry()); } else { OidcLogoutDsl.this.getOidcSessionRegistry(); }  if (OidcLogoutDsl.access$getBackChannel$p(OidcLogoutDsl.this) != null) { Function1 function11 = OidcLogoutDsl.access$getBackChannel$p(OidcLogoutDsl.this); OidcLogoutDsl oidcLogoutDsl = OidcLogoutDsl.this; Function1 it = function11; int $i$a$-also-OidcLogoutDsl$get$1$3 = 0;
/*    */       OidcLogoutDsl.access$getBackChannel$p(oidcLogoutDsl);
/*    */       oidcLogout.backChannel((OidcLogoutDsl.access$getBackChannel$p(oidcLogoutDsl) != null) ? OidcLogoutDsl.access$getBackChannel$p(oidcLogoutDsl)::invoke$lambda$3$lambda$2 : null); }
/*    */     else
/*    */     { OidcLogoutDsl.access$getBackChannel$p(OidcLogoutDsl.this); }
/*    */   
/*    */   }
/*    */   
/*    */   private static final void invoke$lambda$3$lambda$2(Function1 $tmp0, OidcLogoutConfigurer.BackChannelLogoutConfigurer t) {
/*    */     $tmp0.invoke(t);
/*    */   }
/*    */   
/*    */   OidcLogoutDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OidcLogoutDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */