/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityMetadataSourceAdvisor;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class MethodSecurityMetadataSourceAdvisorRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
/* 48 */     BeanDefinitionBuilder advisor = BeanDefinitionBuilder.rootBeanDefinition(MethodSecurityMetadataSourceAdvisor.class);
/* 49 */     advisor.setRole(2);
/* 50 */     advisor.addConstructorArgValue("methodSecurityInterceptor");
/* 51 */     advisor.addConstructorArgReference("methodSecurityMetadataSource");
/* 52 */     advisor.addConstructorArgValue("methodSecurityMetadataSource");
/*    */     
/* 54 */     MultiValueMap<String, Object> attributes = importingClassMetadata.getAllAnnotationAttributes(EnableGlobalMethodSecurity.class.getName());
/* 55 */     Integer order = (Integer)attributes.getFirst("order");
/* 56 */     if (order != null) {
/* 57 */       advisor.addPropertyValue("order", order);
/*    */     }
/* 59 */     registry.registerBeanDefinition("metaDataSourceAdvisor", (BeanDefinition)advisor.getBeanDefinition());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\MethodSecurityMetadataSourceAdvisorRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */