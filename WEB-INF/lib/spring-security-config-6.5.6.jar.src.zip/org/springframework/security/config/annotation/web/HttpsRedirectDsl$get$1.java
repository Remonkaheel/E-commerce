/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HttpsRedirectConfigurer;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "https", "Lorg/springframework/security/config/annotation/web/configurers/HttpsRedirectConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nHttpsRedirectDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpsRedirectDsl.kt\norg/springframework/security/config/annotation/web/HttpsRedirectDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,42:1\n1#2:43\n*E\n"})
/*    */ final class HttpsRedirectDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HttpsRedirectConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(HttpsRedirectConfigurer https) {
/* 38 */     Intrinsics.checkNotNullParameter(https, "https"); if (HttpsRedirectDsl.this.getRequestMatchers() != null) { RequestMatcher[] arrayOfRequestMatcher1 = HttpsRedirectDsl.this.getRequestMatchers(); HttpsRedirectDsl httpsRedirectDsl = HttpsRedirectDsl.this; RequestMatcher[] it = arrayOfRequestMatcher1;
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 43 */       int $i$a$-also-HttpsRedirectDsl$get$1$1 = 0;
/*    */       Intrinsics.checkNotNull(httpsRedirectDsl.getRequestMatchers());
/*    */       RequestMatcher[] arrayOfRequestMatcher2 = httpsRedirectDsl.getRequestMatchers();
/*    */       https.requestMatchers(Arrays.<RequestMatcher>copyOf(arrayOfRequestMatcher2, arrayOfRequestMatcher2.length)); }
/*    */     else
/*    */     { HttpsRedirectDsl.this.getRequestMatchers(); }
/*    */   
/*    */   }
/*    */   
/*    */   HttpsRedirectDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpsRedirectDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */