/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.access.vote.AuthenticatedVoter;
/*     */ import org.springframework.security.access.vote.RoleVoter;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class UrlAuthorizationConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractInterceptUrlConfigurer<UrlAuthorizationConfigurer<H>, H>
/*     */ {
/*     */   private final StandardInterceptUrlRegistry registry;
/*     */   
/*     */   public UrlAuthorizationConfigurer(ApplicationContext context) {
/*  97 */     this.registry = new StandardInterceptUrlRegistry(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardInterceptUrlRegistry getRegistry() {
/* 106 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlAuthorizationConfigurer<H> withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 116 */     addObjectPostProcessor(objectPostProcessor);
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public UrlAuthorizationConfigurer<H> withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 124 */     addObjectPostProcessor(objectPostProcessor);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<AccessDecisionVoter<?>> getDecisionVoters(H http) {
/* 136 */     List<AccessDecisionVoter<?>> decisionVoters = new ArrayList<>();
/* 137 */     decisionVoters.add(new RoleVoter());
/* 138 */     decisionVoters.add(new AuthenticatedVoter());
/* 139 */     return decisionVoters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FilterInvocationSecurityMetadataSource createMetadataSource(H http) {
/* 149 */     return (FilterInvocationSecurityMetadataSource)new DefaultFilterInvocationSecurityMetadataSource(this.registry.createRequestMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StandardInterceptUrlRegistry addMapping(Iterable<? extends RequestMatcher> requestMatchers, Collection<ConfigAttribute> configAttributes) {
/* 163 */     for (RequestMatcher requestMatcher : requestMatchers) {
/* 164 */       this.registry.addMapping(new AbstractConfigAttributeRequestMatcherRegistry.UrlMapping(requestMatcher, configAttributes));
/*     */     }
/*     */     
/* 167 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String hasRole(String role) {
/* 177 */     Assert.isTrue(!role.startsWith("ROLE_"), () -> role + " should not start with ROLE_ since ROLE_ is automatically prepended when using hasRole. Consider using hasAuthority or access instead.");
/*     */     
/* 179 */     return "ROLE_" + role;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] hasAnyRole(String... roles) {
/* 190 */     for (int i = 0; i < roles.length; i++) {
/* 191 */       roles[i] = "ROLE_" + roles[i];
/*     */     }
/* 193 */     return roles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] hasAnyAuthority(String... authorities) {
/* 203 */     return authorities;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final class StandardInterceptUrlRegistry
/*     */     extends AbstractInterceptUrlConfigurer<UrlAuthorizationConfigurer<H>, H>.AbstractInterceptUrlRegistry<StandardInterceptUrlRegistry, AuthorizedUrl>
/*     */   {
/*     */     private StandardInterceptUrlRegistry(ApplicationContext context) {
/* 211 */       setApplicationContext(context);
/*     */     }
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(String... patterns) {
/* 216 */       return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(patterns);
/*     */     }
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(HttpMethod method, String... patterns) {
/* 221 */       return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(method, patterns);
/*     */     }
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(HttpMethod method) {
/* 226 */       return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(method);
/*     */     }
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.AuthorizedUrl requestMatchers(RequestMatcher... requestMatchers) {
/* 231 */       return (UrlAuthorizationConfigurer.AuthorizedUrl)super.requestMatchers(requestMatchers);
/*     */     }
/*     */ 
/*     */     
/*     */     protected UrlAuthorizationConfigurer<H>.AuthorizedUrl chainRequestMatchersInternal(List<RequestMatcher> requestMatchers) {
/* 236 */       return new UrlAuthorizationConfigurer.AuthorizedUrl(requestMatchers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StandardInterceptUrlRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 246 */       UrlAuthorizationConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 247 */       return this;
/*     */     }
/*     */     
/*     */     public H and() {
/* 251 */       return (H)UrlAuthorizationConfigurer.this.and();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class AuthorizedUrl
/*     */   {
/*     */     private final List<? extends RequestMatcher> requestMatchers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AuthorizedUrl(List<? extends RequestMatcher> requestMatchers) {
/* 273 */       Assert.notEmpty(requestMatchers, "requestMatchers must contain at least one value");
/* 274 */       this.requestMatchers = requestMatchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry hasRole(String role) {
/* 284 */       return access(new String[] { UrlAuthorizationConfigurer.hasRole(role) });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry hasAnyRole(String... roles) {
/* 295 */       return access(UrlAuthorizationConfigurer.hasAnyRole(roles));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry hasAuthority(String authority) {
/* 304 */       return access(new String[] { authority });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry hasAnyAuthority(String... authorities) {
/* 314 */       return access(UrlAuthorizationConfigurer.hasAnyAuthority(authorities));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry anonymous() {
/* 322 */       return hasRole("ANONYMOUS");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UrlAuthorizationConfigurer<H>.StandardInterceptUrlRegistry access(String... attributes) {
/* 331 */       UrlAuthorizationConfigurer.this.addMapping(this.requestMatchers, SecurityConfig.createList(attributes));
/* 332 */       return UrlAuthorizationConfigurer.this.registry;
/*     */     }
/*     */     
/*     */     protected List<? extends RequestMatcher> getMatchers() {
/* 336 */       return this.requestMatchers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\UrlAuthorizationConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */