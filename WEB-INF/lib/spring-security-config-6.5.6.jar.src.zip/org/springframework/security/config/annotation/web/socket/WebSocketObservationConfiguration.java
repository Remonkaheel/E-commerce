/*    */ package org.springframework.security.config.annotation.web.socket;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.messaging.Message;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.ObservationAuthorizationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ class WebSocketObservationConfiguration
/*    */ {
/* 36 */   private static final SecurityObservationSettings all = SecurityObservationSettings.withDefaults()
/* 37 */     .shouldObserveRequests(true)
/* 38 */     .shouldObserveAuthentications(true)
/* 39 */     .shouldObserveAuthorizations(true)
/* 40 */     .build();
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<AuthorizationManager<Message<?>>> webSocketAuthorizationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 46 */     return new ObjectPostProcessor<AuthorizationManager<Message<?>>>()
/*    */       {
/*    */         public AuthorizationManager postProcess(AuthorizationManager object) {
/* 49 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 50 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> WebSocketObservationConfiguration.all)).shouldObserveAuthorizations());
/* 51 */           return active ? (AuthorizationManager)new ObservationAuthorizationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\socket\WebSocketObservationConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */