/*    */ package org.springframework.security.config.annotation.web.configurers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.security.access.SecurityConfig;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*    */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PermitAllSupport
/*    */ {
/*    */   static void permitAll(HttpSecurityBuilder<? extends HttpSecurityBuilder<?>> http, String... urls) {
/* 40 */     for (String url : urls) {
/* 41 */       if (url != null) {
/* 42 */         permitAll(http, new RequestMatcher[] { new ExactUrlRequestMatcher(url) });
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void permitAll(HttpSecurityBuilder<? extends HttpSecurityBuilder<?>> http, RequestMatcher... requestMatchers) {
/* 51 */     ExpressionUrlAuthorizationConfigurer<?> configurer = (ExpressionUrlAuthorizationConfigurer)http.getConfigurer(ExpressionUrlAuthorizationConfigurer.class);
/* 52 */     AuthorizeHttpRequestsConfigurer<?> httpConfigurer = (AuthorizeHttpRequestsConfigurer)http.getConfigurer(AuthorizeHttpRequestsConfigurer.class);
/*    */     
/* 54 */     int i = ((configurer == null) ? 1 : 0) ^ ((httpConfigurer == null) ? 1 : 0);
/* 55 */     Assert.state(i, "permitAll only works with either HttpSecurity.authorizeRequests() or HttpSecurity.authorizeHttpRequests(). Please define one or the other but not both.");
/*    */ 
/*    */ 
/*    */     
/* 59 */     for (RequestMatcher matcher : requestMatchers) {
/* 60 */       if (matcher != null)
/* 61 */         if (configurer != null) {
/* 62 */           configurer.getRegistry()
/* 63 */             .addMapping(0, new AbstractConfigAttributeRequestMatcherRegistry.UrlMapping(matcher, 
/* 64 */                 SecurityConfig.createList(new String[] { "permitAll" })));
/*    */         } else {
/*    */           
/* 67 */           httpConfigurer.addFirst(matcher, (AuthorizationManager<RequestAuthorizationContext>)SingleResultAuthorizationManager.permitAll());
/*    */         }  
/*    */     } 
/*    */   }
/*    */   
/*    */   private static final class ExactUrlRequestMatcher
/*    */     implements RequestMatcher
/*    */   {
/*    */     private String processUrl;
/*    */     
/*    */     private ExactUrlRequestMatcher(String processUrl) {
/* 78 */       this.processUrl = processUrl;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean matches(HttpServletRequest request) {
/* 83 */       String uri = request.getRequestURI();
/* 84 */       String query = request.getQueryString();
/* 85 */       if (query != null) {
/* 86 */         uri = uri + "?" + uri;
/*    */       }
/* 88 */       if ("".equals(request.getContextPath())) {
/* 89 */         return uri.equals(this.processUrl);
/*    */       }
/* 91 */       return uri.equals(request.getContextPath() + request.getContextPath());
/*    */     }
/*    */ 
/*    */     
/*    */     public String toString() {
/* 96 */       StringBuilder sb = new StringBuilder();
/* 97 */       sb.append("ExactUrl [processUrl='").append(this.processUrl).append("']");
/* 98 */       return sb.toString();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\PermitAllSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */