/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.ExceptionHandlingConfigurer;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ import org.springframework.security.web.access.AccessDeniedHandler;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "exceptionHandling", "Lorg/springframework/security/config/annotation/web/configurers/ExceptionHandlingConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nExceptionHandlingDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ExceptionHandlingDsl.kt\norg/springframework/security/config/annotation/web/ExceptionHandlingDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,94:1\n1#2:95\n216#3,2:96\n216#3,2:98\n*S KotlinDebug\n*F\n+ 1 ExceptionHandlingDsl.kt\norg/springframework/security/config/annotation/web/ExceptionHandlingDsl$get$1\n*L\n82#1:96,2\n85#1:98,2\n*E\n"})
/*    */ final class ExceptionHandlingDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<ExceptionHandlingConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(ExceptionHandlingConfigurer exceptionHandling) {
/* 79 */     Intrinsics.checkNotNullParameter(exceptionHandling, "exceptionHandling"); if (ExceptionHandlingDsl.this.getAccessDeniedPage() != null) { String str1 = ExceptionHandlingDsl.this.getAccessDeniedPage(); ExceptionHandlingDsl exceptionHandlingDsl = ExceptionHandlingDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 95 */       int $i$a$-also-ExceptionHandlingDsl$get$1$1 = 0; exceptionHandling.accessDeniedPage(exceptionHandlingDsl.getAccessDeniedPage()); } else { ExceptionHandlingDsl.this.getAccessDeniedPage(); }  if (ExceptionHandlingDsl.this.getAccessDeniedHandler() != null) { AccessDeniedHandler accessDeniedHandler1 = ExceptionHandlingDsl.this.getAccessDeniedHandler(); ExceptionHandlingDsl exceptionHandlingDsl = ExceptionHandlingDsl.this; AccessDeniedHandler it = accessDeniedHandler1; int $i$a$-also-ExceptionHandlingDsl$get$1$2 = 0; exceptionHandling.accessDeniedHandler(exceptionHandlingDsl.getAccessDeniedHandler()); } else { ExceptionHandlingDsl.this.getAccessDeniedHandler(); }  if (ExceptionHandlingDsl.this.getAuthenticationEntryPoint() != null) { AuthenticationEntryPoint authenticationEntryPoint1 = ExceptionHandlingDsl.this.getAuthenticationEntryPoint(); ExceptionHandlingDsl exceptionHandlingDsl = ExceptionHandlingDsl.this; AuthenticationEntryPoint it = authenticationEntryPoint1; int $i$a$-also-ExceptionHandlingDsl$get$1$3 = 0; exceptionHandling.authenticationEntryPoint(exceptionHandlingDsl.getAuthenticationEntryPoint()); } else { ExceptionHandlingDsl.this.getAuthenticationEntryPoint(); }
/* 96 */      Map $this$forEach$iv = ExceptionHandlingDsl.access$getDefaultDeniedHandlerMappings$p(ExceptionHandlingDsl.this); int $i$f$forEach = 0; Iterator<Map.Entry> iterator = $this$forEach$iv.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-ExceptionHandlingDsl$get$1$4 = 0; RequestMatcher matcher = (RequestMatcher)entry1.getKey(); AccessDeniedHandler handler = (AccessDeniedHandler)entry1.getValue(); exceptionHandling.defaultAccessDeniedHandlerFor(handler, matcher); }
/*    */      $this$forEach$iv = ExceptionHandlingDsl.access$getDefaultEntryPointMappings$p(ExceptionHandlingDsl.this); $i$f$forEach = 0;
/* 98 */     iterator = $this$forEach$iv.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-ExceptionHandlingDsl$get$1$5 = 0;
/*    */       RequestMatcher matcher = (RequestMatcher)entry1.getKey();
/*    */       AuthenticationEntryPoint entryPoint = (AuthenticationEntryPoint)entry1.getValue();
/*    */       exceptionHandling.defaultAuthenticationEntryPointFor(entryPoint, matcher); }
/*    */     
/*    */     if (ExceptionHandlingDsl.access$getDisabled$p(ExceptionHandlingDsl.this))
/*    */       exceptionHandling.disable(); 
/*    */   }
/*    */   
/*    */   ExceptionHandlingDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\ExceptionHandlingDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */