/*    */ package org.springframework.security.config.annotation.rsocket;
/*    */ 
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveObservationImportSelector
/*    */   implements ImportSelector
/*    */ {
/*    */   private static final boolean observabilityPresent;
/*    */   
/*    */   static {
/* 38 */     ClassLoader classLoader = ReactiveObservationImportSelector.class.getClassLoader();
/* 39 */     observabilityPresent = ClassUtils.isPresent("io.micrometer.observation.ObservationRegistry", classLoader);
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 44 */     if (!observabilityPresent) {
/* 45 */       return new String[0];
/*    */     }
/* 47 */     return new String[] { ReactiveObservationConfiguration.class.getName() };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\ReactiveObservationImportSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */