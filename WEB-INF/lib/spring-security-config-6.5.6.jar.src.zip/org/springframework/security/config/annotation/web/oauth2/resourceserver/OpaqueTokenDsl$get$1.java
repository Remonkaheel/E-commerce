/*    */ package org.springframework.security.config.annotation.web.oauth2.resourceserver;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenAuthenticationConverter;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "opaqueToken", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$OpaqueTokenConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nOpaqueTokenDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OpaqueTokenDsl.kt\norg/springframework/security/config/annotation/web/oauth2/resourceserver/OpaqueTokenDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,81:1\n1#2:82\n*E\n"})
/*    */ final class OpaqueTokenDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OAuth2ResourceServerConfigurer<HttpSecurity>.OpaqueTokenConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(OAuth2ResourceServerConfigurer.OpaqueTokenConfigurer opaqueToken) {
/* 73 */     Intrinsics.checkNotNullParameter(opaqueToken, "opaqueToken"); if (OpaqueTokenDsl.this.getIntrospectionUri() != null) { String str1 = OpaqueTokenDsl.this.getIntrospectionUri(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 82 */       int $i$a$-also-OpaqueTokenDsl$get$1$1 = 0; opaqueToken.introspectionUri(opaqueTokenDsl.getIntrospectionUri()); } else { OpaqueTokenDsl.this.getIntrospectionUri(); }  if (OpaqueTokenDsl.this.getIntrospector() != null) { OpaqueTokenIntrospector opaqueTokenIntrospector1 = OpaqueTokenDsl.this.getIntrospector(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; OpaqueTokenIntrospector it = opaqueTokenIntrospector1; int $i$a$-also-OpaqueTokenDsl$get$1$2 = 0; opaqueToken.introspector(opaqueTokenDsl.getIntrospector()); } else { OpaqueTokenDsl.this.getIntrospector(); }  if (OpaqueTokenDsl.this.getAuthenticationConverter() != null) { OpaqueTokenAuthenticationConverter opaqueTokenAuthenticationConverter1 = OpaqueTokenDsl.this.getAuthenticationConverter(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; OpaqueTokenAuthenticationConverter it = opaqueTokenAuthenticationConverter1; int $i$a$-also-OpaqueTokenDsl$get$1$3 = 0; opaqueToken.authenticationConverter(opaqueTokenDsl.getAuthenticationConverter()); } else { OpaqueTokenDsl.this.getAuthenticationConverter(); }  if (OpaqueTokenDsl.access$getClientCredentials$p(OpaqueTokenDsl.this) != null) { Pair pair1 = OpaqueTokenDsl.access$getClientCredentials$p(OpaqueTokenDsl.this); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; Pair it = pair1; int $i$a$-also-OpaqueTokenDsl$get$1$4 = 0; Intrinsics.checkNotNull(OpaqueTokenDsl.access$getClientCredentials$p(opaqueTokenDsl)); Intrinsics.checkNotNull(OpaqueTokenDsl.access$getClientCredentials$p(opaqueTokenDsl)); opaqueToken.introspectionClientCredentials((String)OpaqueTokenDsl.access$getClientCredentials$p(opaqueTokenDsl).getFirst(), (String)OpaqueTokenDsl.access$getClientCredentials$p(opaqueTokenDsl).getSecond()); } else { OpaqueTokenDsl.access$getClientCredentials$p(OpaqueTokenDsl.this); }  if (OpaqueTokenDsl.this.getAuthenticationManager() != null) { AuthenticationManager authenticationManager1 = OpaqueTokenDsl.this.getAuthenticationManager(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; AuthenticationManager it = authenticationManager1; int $i$a$-also-OpaqueTokenDsl$get$1$5 = 0;
/*    */       opaqueToken.authenticationManager(opaqueTokenDsl.getAuthenticationManager()); }
/*    */     else
/*    */     { OpaqueTokenDsl.this.getAuthenticationManager(); }
/*    */   
/*    */   }
/*    */   
/*    */   OpaqueTokenDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\resourceserver\OpaqueTokenDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */