/*    */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import jakarta.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*    */ import org.springframework.security.oauth2.client.oidc.authentication.event.OidcUserRefreshedEvent;
/*    */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*    */ import org.springframework.security.web.context.SecurityContextRepository;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.request.RequestAttributes;
/*    */ import org.springframework.web.context.request.RequestContextHolder;
/*    */ import org.springframework.web.context.request.ServletRequestAttributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OidcUserRefreshedEventListener
/*    */   implements ApplicationListener<OidcUserRefreshedEvent>
/*    */ {
/* 45 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*    */   
/* 47 */   private SecurityContextRepository securityContextRepository = (SecurityContextRepository)new HttpSessionSecurityContextRepository();
/*    */   
/*    */   public void onApplicationEvent(OidcUserRefreshedEvent event) {
/*    */     ServletRequestAttributes servletRequestAttributes;
/* 51 */     SecurityContext securityContext = this.securityContextHolderStrategy.createEmptyContext();
/* 52 */     securityContext.setAuthentication(event.getAuthentication());
/* 53 */     this.securityContextHolderStrategy.setContext(securityContext);
/*    */     
/* 55 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 56 */     if (requestAttributes instanceof ServletRequestAttributes) { servletRequestAttributes = (ServletRequestAttributes)requestAttributes; }
/*    */     else
/*    */     { return; }
/*    */     
/* 60 */     HttpServletRequest request = servletRequestAttributes.getRequest();
/* 61 */     HttpServletResponse response = servletRequestAttributes.getResponse();
/* 62 */     this.securityContextRepository.saveContext(securityContext, request, response);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 72 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 73 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setSecurityContextRepository(SecurityContextRepository securityContextRepository) {
/* 82 */     Assert.notNull(securityContextRepository, "securityContextRepository cannot be null");
/* 83 */     this.securityContextRepository = securityContextRepository;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcUserRefreshedEventListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */