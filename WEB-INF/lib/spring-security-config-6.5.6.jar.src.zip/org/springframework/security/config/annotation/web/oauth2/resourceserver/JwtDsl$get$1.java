/*    */ package org.springframework.security.config.annotation.web.oauth2.resourceserver;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*    */ import org.springframework.security.oauth2.jwt.Jwt;
/*    */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "jwt", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$JwtConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nJwtDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JwtDsl.kt\norg/springframework/security/config/annotation/web/oauth2/resourceserver/JwtDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,71:1\n1#2:72\n*E\n"})
/*    */ final class JwtDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OAuth2ResourceServerConfigurer<HttpSecurity>.JwtConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(OAuth2ResourceServerConfigurer.JwtConfigurer jwt) {
/* 64 */     Intrinsics.checkNotNullParameter(jwt, "jwt"); if (JwtDsl.this.getJwtAuthenticationConverter() != null) { Converter<Jwt, ? extends AbstractAuthenticationToken> converter1 = JwtDsl.this.getJwtAuthenticationConverter(); JwtDsl jwtDsl = JwtDsl.this; Converter<Jwt, ? extends AbstractAuthenticationToken> it = converter1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 72 */       int $i$a$-also-JwtDsl$get$1$1 = 0; jwt.jwtAuthenticationConverter(jwtDsl.getJwtAuthenticationConverter()); } else { JwtDsl.this.getJwtAuthenticationConverter(); }  if (JwtDsl.this.getJwtDecoder() != null) { JwtDecoder jwtDecoder1 = JwtDsl.this.getJwtDecoder(); JwtDsl jwtDsl = JwtDsl.this; JwtDecoder it = jwtDecoder1; int $i$a$-also-JwtDsl$get$1$2 = 0; jwt.decoder(jwtDsl.getJwtDecoder()); } else { JwtDsl.this.getJwtDecoder(); }  if (JwtDsl.this.getJwkSetUri() != null) { String str1 = JwtDsl.this.getJwkSetUri(); JwtDsl jwtDsl = JwtDsl.this; String it = str1; int $i$a$-also-JwtDsl$get$1$3 = 0; jwt.jwkSetUri(jwtDsl.getJwkSetUri()); } else { JwtDsl.this.getJwkSetUri(); }  if (JwtDsl.this.getAuthenticationManager() != null) { AuthenticationManager authenticationManager1 = JwtDsl.this.getAuthenticationManager(); JwtDsl jwtDsl = JwtDsl.this; AuthenticationManager it = authenticationManager1; int $i$a$-also-JwtDsl$get$1$4 = 0;
/*    */       jwt.authenticationManager(jwtDsl.getAuthenticationManager()); }
/*    */     else
/*    */     { JwtDsl.this.getAuthenticationManager(); }
/*    */   
/*    */   }
/*    */   
/*    */   JwtDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\resourceserver\JwtDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */