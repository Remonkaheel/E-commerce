/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.ForwardAuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.ForwardAuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormLoginConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractAuthenticationFilterConfigurer<H, FormLoginConfigurer<H>, UsernamePasswordAuthenticationFilter>
/*     */ {
/*     */   public FormLoginConfigurer() {
/*  80 */     super(new UsernamePasswordAuthenticationFilter(), null);
/*  81 */     usernameParameter("username");
/*  82 */     passwordParameter("password");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormLoginConfigurer<H> loginPage(String loginPage) {
/* 183 */     return super.loginPage(loginPage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormLoginConfigurer<H> usernameParameter(String usernameParameter) {
/* 194 */     getAuthenticationFilter().setUsernameParameter(usernameParameter);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormLoginConfigurer<H> passwordParameter(String passwordParameter) {
/* 206 */     getAuthenticationFilter().setPasswordParameter(passwordParameter);
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormLoginConfigurer<H> failureForwardUrl(String forwardUrl) {
/* 216 */     failureHandler((AuthenticationFailureHandler)new ForwardAuthenticationFailureHandler(forwardUrl));
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormLoginConfigurer<H> successForwardUrl(String forwardUrl) {
/* 226 */     successHandler((AuthenticationSuccessHandler)new ForwardAuthenticationSuccessHandler(forwardUrl));
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) throws Exception {
/* 232 */     super.init(http);
/* 233 */     initDefaultLoginFilter(http);
/*     */   }
/*     */ 
/*     */   
/*     */   protected RequestMatcher createLoginProcessingUrlMatcher(String loginProcessingUrl) {
/* 238 */     return RequestMatcherFactory.matcher(HttpMethod.POST, loginProcessingUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getUsernameParameter() {
/* 246 */     return getAuthenticationFilter().getUsernameParameter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPasswordParameter() {
/* 254 */     return getAuthenticationFilter().getPasswordParameter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initDefaultLoginFilter(H http) {
/* 264 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/* 265 */     if (loginPageGeneratingFilter != null && !isCustomLoginPage()) {
/* 266 */       loginPageGeneratingFilter.setFormLoginEnabled(true);
/* 267 */       loginPageGeneratingFilter.setUsernameParameter(getUsernameParameter());
/* 268 */       loginPageGeneratingFilter.setPasswordParameter(getPasswordParameter());
/* 269 */       loginPageGeneratingFilter.setLoginPageUrl(getLoginPage());
/* 270 */       loginPageGeneratingFilter.setFailureUrl(getFailureUrl());
/* 271 */       loginPageGeneratingFilter.setAuthenticationUrl(getLoginProcessingUrl());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\FormLoginConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */