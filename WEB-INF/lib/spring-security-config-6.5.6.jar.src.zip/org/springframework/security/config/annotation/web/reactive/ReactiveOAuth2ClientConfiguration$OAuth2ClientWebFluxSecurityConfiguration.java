/*     */ package org.springframework.security.config.annotation.web.reactive;
/*     */ 
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.web.reactive.result.method.annotation.OAuth2AuthorizedClientArgumentResolver;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*     */ import org.springframework.web.reactive.result.method.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.reactive.result.method.annotation.ArgumentResolverConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class OAuth2ClientWebFluxSecurityConfiguration
/*     */   implements WebFluxConfigurer
/*     */ {
/*     */   private final ReactiveOAuth2AuthorizedClientManager authorizedClientManager;
/*     */   private final ReactiveOAuth2ClientConfiguration.ReactiveOAuth2AuthorizedClientManagerRegistrar authorizedClientManagerRegistrar;
/*     */   
/*     */   OAuth2ClientWebFluxSecurityConfiguration(ObjectProvider<ReactiveOAuth2AuthorizedClientManager> authorizedClientManager, ReactiveOAuth2ClientConfiguration.ReactiveOAuth2AuthorizedClientManagerRegistrar authorizedClientManagerRegistrar) {
/* 102 */     this.authorizedClientManager = (ReactiveOAuth2AuthorizedClientManager)authorizedClientManager.getIfUnique();
/* 103 */     this.authorizedClientManagerRegistrar = authorizedClientManagerRegistrar;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureArgumentResolvers(ArgumentResolverConfigurer configurer) {
/* 108 */     ReactiveOAuth2AuthorizedClientManager authorizedClientManager = getAuthorizedClientManager();
/* 109 */     if (authorizedClientManager != null) {
/* 110 */       configurer.addCustomResolver(new HandlerMethodArgumentResolver[] { (HandlerMethodArgumentResolver)new OAuth2AuthorizedClientArgumentResolver(authorizedClientManager) });
/*     */     }
/*     */   }
/*     */   
/*     */   private ReactiveOAuth2AuthorizedClientManager getAuthorizedClientManager() {
/* 115 */     if (this.authorizedClientManager != null) {
/* 116 */       return this.authorizedClientManager;
/*     */     }
/* 118 */     return this.authorizedClientManagerRegistrar.getAuthorizedClientManagerIfAvailable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ReactiveOAuth2ClientConfiguration$OAuth2ClientWebFluxSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */