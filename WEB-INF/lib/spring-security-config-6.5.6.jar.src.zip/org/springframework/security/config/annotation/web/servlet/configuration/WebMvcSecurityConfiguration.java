/*    */ package org.springframework.security.config.annotation.web.servlet.configuration;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
/*    */ import org.springframework.security.web.bind.support.AuthenticationPrincipalArgumentResolver;
/*    */ import org.springframework.security.web.method.annotation.AuthenticationPrincipalArgumentResolver;
/*    */ import org.springframework.security.web.servlet.support.csrf.CsrfRequestDataValueProcessor;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
/*    */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @EnableWebSecurity
/*    */ public class WebMvcSecurityConfiguration
/*    */   implements WebMvcConfigurer
/*    */ {
/*    */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 52 */     argumentResolvers.add(new AuthenticationPrincipalArgumentResolver());
/* 53 */     argumentResolvers
/* 54 */       .add(new AuthenticationPrincipalArgumentResolver());
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public RequestDataValueProcessor requestDataValueProcessor() {
/* 59 */     return (RequestDataValueProcessor)new CsrfRequestDataValueProcessor();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\servlet\configuration\WebMvcSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */