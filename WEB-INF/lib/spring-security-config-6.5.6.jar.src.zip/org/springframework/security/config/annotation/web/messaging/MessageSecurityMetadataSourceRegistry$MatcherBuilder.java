package org.springframework.security.config.annotation.web.messaging;

import org.springframework.security.messaging.util.matcher.MessageMatcher;

interface MatcherBuilder {
  MessageMatcher<?> build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\messaging\MessageSecurityMetadataSourceRegistry$MatcherBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */