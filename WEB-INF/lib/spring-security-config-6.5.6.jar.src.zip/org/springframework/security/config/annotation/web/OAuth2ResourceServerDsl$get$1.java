/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*     */ import org.springframework.security.oauth2.server.resource.web.BearerTokenResolver;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.access.AccessDeniedHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oauth2ResourceServer", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nOAuth2ResourceServerDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OAuth2ResourceServerDsl.kt\norg/springframework/security/config/annotation/web/OAuth2ResourceServerDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,123:1\n1#2:124\n*E\n"})
/*     */ final class OAuth2ResourceServerDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<OAuth2ResourceServerConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(OAuth2ResourceServerConfigurer oauth2ResourceServer) {
/* 114 */     Intrinsics.checkNotNullParameter(oauth2ResourceServer, "oauth2ResourceServer"); if (OAuth2ResourceServerDsl.this.getAccessDeniedHandler() != null) { AccessDeniedHandler accessDeniedHandler1 = OAuth2ResourceServerDsl.this.getAccessDeniedHandler(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; AccessDeniedHandler it = accessDeniedHandler1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 124 */       int $i$a$-also-OAuth2ResourceServerDsl$get$1$1 = 0; oauth2ResourceServer.accessDeniedHandler(oAuth2ResourceServerDsl.getAccessDeniedHandler()); } else { OAuth2ResourceServerDsl.this.getAccessDeniedHandler(); }  if (OAuth2ResourceServerDsl.this.getAuthenticationEntryPoint() != null) { AuthenticationEntryPoint authenticationEntryPoint1 = OAuth2ResourceServerDsl.this.getAuthenticationEntryPoint(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; AuthenticationEntryPoint it = authenticationEntryPoint1; int $i$a$-also-OAuth2ResourceServerDsl$get$1$2 = 0; oauth2ResourceServer.authenticationEntryPoint(oAuth2ResourceServerDsl.getAuthenticationEntryPoint()); } else { OAuth2ResourceServerDsl.this.getAuthenticationEntryPoint(); }  if (OAuth2ResourceServerDsl.this.getBearerTokenResolver() != null) { BearerTokenResolver bearerTokenResolver1 = OAuth2ResourceServerDsl.this.getBearerTokenResolver(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; BearerTokenResolver it = bearerTokenResolver1; int $i$a$-also-OAuth2ResourceServerDsl$get$1$3 = 0; oauth2ResourceServer.bearerTokenResolver(oAuth2ResourceServerDsl.getBearerTokenResolver()); } else { OAuth2ResourceServerDsl.this.getBearerTokenResolver(); }  if (OAuth2ResourceServerDsl.this.getAuthenticationManagerResolver() != null) { AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver1 = OAuth2ResourceServerDsl.this.getAuthenticationManagerResolver(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; AuthenticationManagerResolver<HttpServletRequest> it = authenticationManagerResolver1; int $i$a$-also-OAuth2ResourceServerDsl$get$1$4 = 0; oauth2ResourceServer.authenticationManagerResolver(oAuth2ResourceServerDsl.getAuthenticationManagerResolver()); } else { OAuth2ResourceServerDsl.this.getAuthenticationManagerResolver(); }  if (OAuth2ResourceServerDsl.access$getJwt$p(OAuth2ResourceServerDsl.this) != null) { Function1 function11 = OAuth2ResourceServerDsl.access$getJwt$p(OAuth2ResourceServerDsl.this); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; Function1 it = function11; int $i$a$-also-OAuth2ResourceServerDsl$get$1$5 = 0; OAuth2ResourceServerDsl.access$getJwt$p(oAuth2ResourceServerDsl); oauth2ResourceServer.jwt((OAuth2ResourceServerDsl.access$getJwt$p(oAuth2ResourceServerDsl) != null) ? OAuth2ResourceServerDsl.access$getJwt$p(oAuth2ResourceServerDsl)::invoke$lambda$5$lambda$4 : null); } else { OAuth2ResourceServerDsl.access$getJwt$p(OAuth2ResourceServerDsl.this); }  if (OAuth2ResourceServerDsl.access$getOpaqueToken$p(OAuth2ResourceServerDsl.this) != null) { Function1 function11 = OAuth2ResourceServerDsl.access$getOpaqueToken$p(OAuth2ResourceServerDsl.this); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; Function1 it = function11; int $i$a$-also-OAuth2ResourceServerDsl$get$1$6 = 0;
/*     */       OAuth2ResourceServerDsl.access$getOpaqueToken$p(oAuth2ResourceServerDsl);
/*     */       oauth2ResourceServer.opaqueToken((OAuth2ResourceServerDsl.access$getOpaqueToken$p(oAuth2ResourceServerDsl) != null) ? OAuth2ResourceServerDsl.access$getOpaqueToken$p(oAuth2ResourceServerDsl)::invoke$lambda$7$lambda$6 : null); }
/*     */     else
/*     */     { OAuth2ResourceServerDsl.access$getOpaqueToken$p(OAuth2ResourceServerDsl.this); }
/*     */   
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$5$lambda$4(Function1 $tmp0, OAuth2ResourceServerConfigurer.JwtConfigurer t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$7$lambda$6(Function1 $tmp0, OAuth2ResourceServerConfigurer.OpaqueTokenConfigurer t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   OAuth2ResourceServerDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OAuth2ResourceServerDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */