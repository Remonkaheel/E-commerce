/*    */ package org.springframework.security.config.annotation.web.configuration;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.ObservationAuthorizationManager;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ObjectPostProcessor<AuthorizationManager<HttpServletRequest>>
/*    */ {
/*    */   public AuthorizationManager postProcess(AuthorizationManager object) {
/* 53 */     ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 54 */     boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ObservationConfiguration.all)).shouldObserveAuthorizations());
/* 55 */     return active ? (AuthorizationManager)new ObservationAuthorizationManager(r, object) : object;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\ObservationConfiguration$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */