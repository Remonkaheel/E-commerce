/*     */ package org.springframework.security.config.annotation.authentication.configuration;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactoryBean;
/*     */ import org.springframework.aop.target.LazyInitTargetSource;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.userdetails.DaoAuthenticationConfigurer;
/*     */ import org.springframework.security.config.annotation.configuration.ObjectPostProcessorConfiguration;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.crypto.factory.PasswordEncoderFactories;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @Import({ObjectPostProcessorConfiguration.class})
/*     */ public class AuthenticationConfiguration
/*     */ {
/*  67 */   private AtomicBoolean buildingAuthenticationManager = new AtomicBoolean();
/*     */   
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/*     */   private boolean authenticationManagerInitialized;
/*     */   
/*  75 */   private List<GlobalAuthenticationConfigurerAdapter> globalAuthConfigurers = Collections.emptyList();
/*     */   
/*     */   private ObjectPostProcessor<Object> objectPostProcessor;
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public AuthenticationManagerBuilder authenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor, ApplicationContext context) {
/*  82 */     LazyPasswordEncoder defaultPasswordEncoder = new LazyPasswordEncoder(context);
/*  83 */     AuthenticationEventPublisher authenticationEventPublisher = getAuthenticationEventPublisher(context);
/*  84 */     DefaultPasswordEncoderAuthenticationManagerBuilder result = new DefaultPasswordEncoderAuthenticationManagerBuilder(objectPostProcessor, defaultPasswordEncoder);
/*     */     
/*  86 */     if (authenticationEventPublisher != null) {
/*  87 */       result.authenticationEventPublisher(authenticationEventPublisher);
/*     */     }
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public static GlobalAuthenticationConfigurerAdapter enableGlobalAuthenticationAutowiredConfigurer(ApplicationContext context) {
/*  95 */     return new EnableGlobalAuthenticationAutowiredConfigurer(context);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public static InitializeUserDetailsBeanManagerConfigurer initializeUserDetailsBeanManagerConfigurer(ApplicationContext context) {
/* 101 */     return new InitializeUserDetailsBeanManagerConfigurer(context);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public static InitializeAuthenticationProviderBeanManagerConfigurer initializeAuthenticationProviderBeanManagerConfigurer(ApplicationContext context) {
/* 107 */     return new InitializeAuthenticationProviderBeanManagerConfigurer(context);
/*     */   }
/*     */   
/*     */   public AuthenticationManager getAuthenticationManager() throws Exception {
/* 111 */     if (this.authenticationManagerInitialized) {
/* 112 */       return this.authenticationManager;
/*     */     }
/* 114 */     AuthenticationManagerBuilder authBuilder = (AuthenticationManagerBuilder)this.applicationContext.getBean(AuthenticationManagerBuilder.class);
/* 115 */     if (this.buildingAuthenticationManager.getAndSet(true)) {
/* 116 */       return new AuthenticationManagerDelegator(authBuilder);
/*     */     }
/* 118 */     for (GlobalAuthenticationConfigurerAdapter config : this.globalAuthConfigurers) {
/* 119 */       authBuilder.apply(config);
/*     */     }
/* 121 */     this.authenticationManager = (AuthenticationManager)authBuilder.build();
/* 122 */     if (this.authenticationManager == null) {
/* 123 */       this.authenticationManager = getAuthenticationManagerBean();
/*     */     }
/* 125 */     this.authenticationManagerInitialized = true;
/* 126 */     return this.authenticationManager;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setGlobalAuthenticationConfigurers(List<GlobalAuthenticationConfigurerAdapter> configurers) {
/* 131 */     configurers.sort((Comparator<? super GlobalAuthenticationConfigurerAdapter>)AnnotationAwareOrderComparator.INSTANCE);
/* 132 */     this.globalAuthConfigurers = configurers;
/*     */   }
/*     */   
/*     */   @Autowired
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 137 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   @Autowired
/*     */   public void setObjectPostProcessor(ObjectPostProcessor<Object> objectPostProcessor) {
/* 142 */     this.objectPostProcessor = objectPostProcessor;
/*     */   }
/*     */   
/*     */   private AuthenticationEventPublisher getAuthenticationEventPublisher(ApplicationContext context) {
/* 146 */     if ((context.getBeanNamesForType(AuthenticationEventPublisher.class)).length > 0) {
/* 147 */       return (AuthenticationEventPublisher)context.getBean(AuthenticationEventPublisher.class);
/*     */     }
/* 149 */     return (AuthenticationEventPublisher)this.objectPostProcessor.postProcess(new DefaultAuthenticationEventPublisher());
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T lazyBean(Class<T> interfaceName) {
/* 154 */     LazyInitTargetSource lazyTargetSource = new LazyInitTargetSource();
/* 155 */     String[] beanNamesForType = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.applicationContext, interfaceName);
/*     */     
/* 157 */     if (beanNamesForType.length == 0) {
/* 158 */       return null;
/*     */     }
/* 160 */     String beanName = getBeanName(interfaceName, beanNamesForType);
/* 161 */     lazyTargetSource.setTargetBeanName(beanName);
/* 162 */     lazyTargetSource.setBeanFactory((BeanFactory)this.applicationContext);
/* 163 */     ProxyFactoryBean proxyFactory = new ProxyFactoryBean();
/* 164 */     proxyFactory = (ProxyFactoryBean)this.objectPostProcessor.postProcess(proxyFactory);
/* 165 */     proxyFactory.setTargetSource((TargetSource)lazyTargetSource);
/* 166 */     return (T)proxyFactory.getObject();
/*     */   }
/*     */   
/*     */   private <T> String getBeanName(Class<T> interfaceName, String[] beanNamesForType) {
/* 170 */     if (beanNamesForType.length == 1) {
/* 171 */       return beanNamesForType[0];
/*     */     }
/* 173 */     List<String> primaryBeanNames = getPrimaryBeanNames(beanNamesForType);
/* 174 */     Assert.isTrue((primaryBeanNames.size() != 0), () -> "Found " + beanNamesForType.length + " beans for type " + String.valueOf(interfaceName) + ", but none marked as primary");
/*     */     
/* 176 */     Assert.isTrue((primaryBeanNames.size() == 1), () -> "Found " + primaryBeanNames.size() + " beans for type " + String.valueOf(interfaceName) + " marked as primary");
/*     */     
/* 178 */     return primaryBeanNames.get(0);
/*     */   }
/*     */   
/*     */   private List<String> getPrimaryBeanNames(String[] beanNamesForType) {
/* 182 */     List<String> list = new ArrayList<>();
/* 183 */     if (!(this.applicationContext instanceof ConfigurableApplicationContext)) {
/* 184 */       return Collections.emptyList();
/*     */     }
/* 186 */     for (String beanName : beanNamesForType) {
/* 187 */       if (((ConfigurableApplicationContext)this.applicationContext).getBeanFactory()
/* 188 */         .getBeanDefinition(beanName)
/* 189 */         .isPrimary()) {
/* 190 */         list.add(beanName);
/*     */       }
/*     */     } 
/* 193 */     return list;
/*     */   }
/*     */   
/*     */   private AuthenticationManager getAuthenticationManagerBean() {
/* 197 */     return lazyBean(AuthenticationManager.class);
/*     */   }
/*     */   
/*     */   private static class EnableGlobalAuthenticationAutowiredConfigurer
/*     */     extends GlobalAuthenticationConfigurerAdapter
/*     */   {
/*     */     private final ApplicationContext context;
/* 204 */     private static final Log logger = LogFactory.getLog(EnableGlobalAuthenticationAutowiredConfigurer.class);
/*     */     
/*     */     EnableGlobalAuthenticationAutowiredConfigurer(ApplicationContext context) {
/* 207 */       this.context = context;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void init(AuthenticationManagerBuilder auth) {
/* 213 */       Map<String, Object> beansWithAnnotation = this.context.getBeansWithAnnotation(EnableGlobalAuthentication.class);
/* 214 */       if (logger.isTraceEnabled()) {
/* 215 */         logger.trace(LogMessage.format("Eagerly initializing %s", beansWithAnnotation));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AuthenticationManagerDelegator
/*     */     implements AuthenticationManager
/*     */   {
/*     */     private AuthenticationManagerBuilder delegateBuilder;
/*     */ 
/*     */ 
/*     */     
/*     */     private AuthenticationManager delegate;
/*     */ 
/*     */ 
/*     */     
/* 234 */     private final Object delegateMonitor = new Object();
/*     */     
/*     */     AuthenticationManagerDelegator(AuthenticationManagerBuilder delegateBuilder) {
/* 237 */       Assert.notNull(delegateBuilder, "delegateBuilder cannot be null");
/* 238 */       this.delegateBuilder = delegateBuilder;
/*     */     }
/*     */ 
/*     */     
/*     */     public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 243 */       if (this.delegate != null) {
/* 244 */         return this.delegate.authenticate(authentication);
/*     */       }
/* 246 */       synchronized (this.delegateMonitor) {
/* 247 */         if (this.delegate == null) {
/* 248 */           this.delegate = (AuthenticationManager)this.delegateBuilder.getObject();
/* 249 */           this.delegateBuilder = null;
/*     */         } 
/*     */       } 
/* 252 */       return this.delegate.authenticate(authentication);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 257 */       return "AuthenticationManagerDelegator [delegate=" + String.valueOf(this.delegate) + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultPasswordEncoderAuthenticationManagerBuilder
/*     */     extends AuthenticationManagerBuilder
/*     */   {
/*     */     private PasswordEncoder defaultPasswordEncoder;
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultPasswordEncoderAuthenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor, PasswordEncoder defaultPasswordEncoder) {
/* 272 */       super(objectPostProcessor);
/* 273 */       this.defaultPasswordEncoder = defaultPasswordEncoder;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder> inMemoryAuthentication() throws Exception {
/* 279 */       return (InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder>)super.inMemoryAuthentication().passwordEncoder(this.defaultPasswordEncoder);
/*     */     }
/*     */ 
/*     */     
/*     */     public JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder> jdbcAuthentication() throws Exception {
/* 284 */       return (JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder>)super.jdbcAuthentication().passwordEncoder(this.defaultPasswordEncoder);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T extends UserDetailsService> DaoAuthenticationConfigurer<AuthenticationManagerBuilder, T> userDetailsService(T userDetailsService) throws Exception {
/* 290 */       return (DaoAuthenticationConfigurer<AuthenticationManagerBuilder, T>)super.userDetailsService((UserDetailsService)userDetailsService).passwordEncoder(this.defaultPasswordEncoder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class LazyPasswordEncoder
/*     */     implements PasswordEncoder
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */     private PasswordEncoder passwordEncoder;
/*     */     
/*     */     LazyPasswordEncoder(ApplicationContext applicationContext) {
/* 302 */       this.applicationContext = applicationContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public String encode(CharSequence rawPassword) {
/* 307 */       return getPasswordEncoder().encode(rawPassword);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 312 */       return getPasswordEncoder().matches(rawPassword, encodedPassword);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean upgradeEncoding(String encodedPassword) {
/* 317 */       return getPasswordEncoder().upgradeEncoding(encodedPassword);
/*     */     }
/*     */     
/*     */     private PasswordEncoder getPasswordEncoder() {
/* 321 */       if (this.passwordEncoder != null) {
/* 322 */         return this.passwordEncoder;
/*     */       }
/* 324 */       this
/* 325 */         .passwordEncoder = (PasswordEncoder)this.applicationContext.getBeanProvider(PasswordEncoder.class).getIfUnique(PasswordEncoderFactories::createDelegatingPasswordEncoder);
/* 326 */       return this.passwordEncoder;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 331 */       return getPasswordEncoder().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configuration\AuthenticationConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */