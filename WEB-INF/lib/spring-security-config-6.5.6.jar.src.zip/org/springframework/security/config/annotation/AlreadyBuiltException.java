/*    */ package org.springframework.security.config.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlreadyBuiltException
/*    */   extends IllegalStateException
/*    */ {
/*    */   private static final long serialVersionUID = -5891004752785553015L;
/*    */   
/*    */   public AlreadyBuiltException(String message) {
/* 28 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\AlreadyBuiltException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */