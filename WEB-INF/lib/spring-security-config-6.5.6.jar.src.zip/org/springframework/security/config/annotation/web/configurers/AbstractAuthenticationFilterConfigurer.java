/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.PortMapper;
/*     */ import org.springframework.security.web.PortResolver;
/*     */ import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.HeaderContentNegotiationStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAuthenticationFilterConfigurer<B extends HttpSecurityBuilder<B>, T extends AbstractAuthenticationFilterConfigurer<B, T, F>, F extends AbstractAuthenticationProcessingFilter>
/*     */   extends AbstractHttpConfigurer<T, B>
/*     */ {
/*     */   private F authFilter;
/*     */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource;
/*  70 */   private SavedRequestAwareAuthenticationSuccessHandler defaultSuccessHandler = new SavedRequestAwareAuthenticationSuccessHandler();
/*     */   
/*  72 */   private AuthenticationSuccessHandler successHandler = (AuthenticationSuccessHandler)this.defaultSuccessHandler;
/*     */ 
/*     */   
/*     */   private LoginUrlAuthenticationEntryPoint authenticationEntryPoint;
/*     */ 
/*     */   
/*     */   private boolean customLoginPage;
/*     */   
/*     */   private String loginPage;
/*     */   
/*     */   private String loginProcessingUrl;
/*     */   
/*     */   private AuthenticationFailureHandler failureHandler;
/*     */   
/*     */   private boolean permitAll;
/*     */   
/*     */   private String failureUrl;
/*     */ 
/*     */   
/*     */   protected AbstractAuthenticationFilterConfigurer() {
/*  92 */     setLoginPage("/login");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractAuthenticationFilterConfigurer(F authenticationFilter, String defaultLoginProcessingUrl) {
/* 103 */     this();
/* 104 */     this.authFilter = authenticationFilter;
/* 105 */     if (defaultLoginProcessingUrl != null) {
/* 106 */       loginProcessingUrl(defaultLoginProcessingUrl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T defaultSuccessUrl(String defaultSuccessUrl) {
/* 118 */     return defaultSuccessUrl(defaultSuccessUrl, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T defaultSuccessUrl(String defaultSuccessUrl, boolean alwaysUse) {
/* 132 */     SavedRequestAwareAuthenticationSuccessHandler handler = new SavedRequestAwareAuthenticationSuccessHandler();
/* 133 */     handler.setDefaultTargetUrl(defaultSuccessUrl);
/* 134 */     handler.setAlwaysUseDefaultTargetUrl(alwaysUse);
/* 135 */     this.defaultSuccessHandler = handler;
/* 136 */     return successHandler((AuthenticationSuccessHandler)handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T loginProcessingUrl(String loginProcessingUrl) {
/* 145 */     this.loginProcessingUrl = loginProcessingUrl;
/* 146 */     this.authFilter.setRequiresAuthenticationRequestMatcher(createLoginProcessingUrlMatcher(loginProcessingUrl));
/* 147 */     return getSelf();
/*     */   }
/*     */   
/*     */   public T securityContextRepository(SecurityContextRepository securityContextRepository) {
/* 151 */     this.authFilter.setSecurityContextRepository(securityContextRepository);
/* 152 */     return getSelf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T authenticationDetailsSource(AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource) {
/* 171 */     this.authenticationDetailsSource = authenticationDetailsSource;
/* 172 */     return getSelf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T successHandler(AuthenticationSuccessHandler successHandler) {
/* 183 */     this.successHandler = successHandler;
/* 184 */     return getSelf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T permitAll() {
/* 192 */     return permitAll(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T permitAll(boolean permitAll) {
/* 203 */     this.permitAll = permitAll;
/* 204 */     return getSelf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T failureUrl(String authenticationFailureUrl) {
/* 216 */     T result = failureHandler((AuthenticationFailureHandler)new SimpleUrlAuthenticationFailureHandler(authenticationFailureUrl));
/* 217 */     this.failureUrl = authenticationFailureUrl;
/* 218 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T failureHandler(AuthenticationFailureHandler authenticationFailureHandler) {
/* 230 */     this.failureUrl = null;
/* 231 */     this.failureHandler = authenticationFailureHandler;
/* 232 */     return getSelf();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(B http) throws Exception {
/* 237 */     updateAuthenticationDefaults();
/* 238 */     updateAccessDefaults(http);
/* 239 */     registerDefaultAuthenticationEntryPoint(http);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void registerDefaultAuthenticationEntryPoint(B http) {
/* 244 */     registerAuthenticationEntryPoint(http, (AuthenticationEntryPoint)this.authenticationEntryPoint);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void registerAuthenticationEntryPoint(B http, AuthenticationEntryPoint authenticationEntryPoint) {
/* 249 */     ExceptionHandlingConfigurer<B> exceptionHandling = (ExceptionHandlingConfigurer<B>)http.getConfigurer(ExceptionHandlingConfigurer.class);
/* 250 */     if (exceptionHandling == null) {
/*     */       return;
/*     */     }
/* 253 */     exceptionHandling.defaultAuthenticationEntryPointFor((AuthenticationEntryPoint)postProcess(authenticationEntryPoint), 
/* 254 */         getAuthenticationEntryPointMatcher(http));
/*     */   }
/*     */   protected final RequestMatcher getAuthenticationEntryPointMatcher(B http) {
/*     */     HeaderContentNegotiationStrategy headerContentNegotiationStrategy;
/* 258 */     ContentNegotiationStrategy contentNegotiationStrategy = (ContentNegotiationStrategy)http.getSharedObject(ContentNegotiationStrategy.class);
/* 259 */     if (contentNegotiationStrategy == null) {
/* 260 */       headerContentNegotiationStrategy = new HeaderContentNegotiationStrategy();
/*     */     }
/* 262 */     MediaTypeRequestMatcher mediaMatcher = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.APPLICATION_XHTML_XML, new MediaType("image", "*"), MediaType.TEXT_HTML, MediaType.TEXT_PLAIN });
/*     */ 
/*     */     
/* 265 */     mediaMatcher.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 266 */     NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
/*     */     
/* 268 */     return (RequestMatcher)new AndRequestMatcher(Arrays.asList(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)mediaMatcher }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(B http) throws Exception {
/* 273 */     PortMapper portMapper = (PortMapper)http.getSharedObject(PortMapper.class);
/* 274 */     if (portMapper != null) {
/* 275 */       this.authenticationEntryPoint.setPortMapper(portMapper);
/*     */     }
/* 277 */     PortResolver portResolver = getBeanOrNull(http, PortResolver.class);
/* 278 */     if (portResolver != null) {
/* 279 */       this.authenticationEntryPoint.setPortResolver(portResolver);
/*     */     }
/* 281 */     RequestCache requestCache = (RequestCache)http.getSharedObject(RequestCache.class);
/* 282 */     if (requestCache != null) {
/* 283 */       this.defaultSuccessHandler.setRequestCache(requestCache);
/*     */     }
/* 285 */     this.authFilter.setAuthenticationManager((AuthenticationManager)http.getSharedObject(AuthenticationManager.class));
/* 286 */     this.authFilter.setAuthenticationSuccessHandler(this.successHandler);
/* 287 */     this.authFilter.setAuthenticationFailureHandler(this.failureHandler);
/* 288 */     if (this.authenticationDetailsSource != null) {
/* 289 */       this.authFilter.setAuthenticationDetailsSource(this.authenticationDetailsSource);
/*     */     }
/*     */     
/* 292 */     SessionAuthenticationStrategy sessionAuthenticationStrategy = (SessionAuthenticationStrategy)http.getSharedObject(SessionAuthenticationStrategy.class);
/* 293 */     if (sessionAuthenticationStrategy != null) {
/* 294 */       this.authFilter.setSessionAuthenticationStrategy(sessionAuthenticationStrategy);
/*     */     }
/* 296 */     RememberMeServices rememberMeServices = (RememberMeServices)http.getSharedObject(RememberMeServices.class);
/* 297 */     if (rememberMeServices != null) {
/* 298 */       this.authFilter.setRememberMeServices(rememberMeServices);
/*     */     }
/* 300 */     SecurityContextConfigurer securityContextConfigurer = (SecurityContextConfigurer)http.getConfigurer(SecurityContextConfigurer.class);
/* 301 */     if (securityContextConfigurer != null && securityContextConfigurer.isRequireExplicitSave()) {
/*     */       
/* 303 */       SecurityContextRepository securityContextRepository = securityContextConfigurer.getSecurityContextRepository();
/* 304 */       this.authFilter.setSecurityContextRepository(securityContextRepository);
/*     */     } 
/* 306 */     this.authFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 307 */     AbstractAuthenticationProcessingFilter abstractAuthenticationProcessingFilter = (AbstractAuthenticationProcessingFilter)postProcess(this.authFilter);
/* 308 */     http.addFilter((Filter)abstractAuthenticationProcessingFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T loginPage(String loginPage) {
/* 325 */     setLoginPage(loginPage);
/* 326 */     updateAuthenticationDefaults();
/* 327 */     this.customLoginPage = true;
/* 328 */     return getSelf();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCustomLoginPage() {
/* 335 */     return this.customLoginPage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final F getAuthenticationFilter() {
/* 343 */     return this.authFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setAuthenticationFilter(F authFilter) {
/* 351 */     this.authFilter = authFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getLoginPage() {
/* 359 */     return this.loginPage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AuthenticationEntryPoint getAuthenticationEntryPoint() {
/* 367 */     return (AuthenticationEntryPoint)this.authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getLoginProcessingUrl() {
/* 376 */     return this.loginProcessingUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getFailureUrl() {
/* 384 */     return this.failureUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void updateAuthenticationDefaults() {
/* 391 */     if (this.loginProcessingUrl == null) {
/* 392 */       loginProcessingUrl(this.loginPage);
/*     */     }
/* 394 */     if (this.failureHandler == null) {
/* 395 */       failureUrl(this.loginPage + "?error");
/*     */     }
/* 397 */     LogoutConfigurer<B> logoutConfigurer = (LogoutConfigurer<B>)((HttpSecurityBuilder)getBuilder()).getConfigurer(LogoutConfigurer.class);
/* 398 */     if (logoutConfigurer != null && !logoutConfigurer.isCustomLogoutSuccess()) {
/* 399 */       logoutConfigurer.logoutSuccessUrl(this.loginPage + "?logout");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void updateAccessDefaults(B http) {
/* 407 */     if (this.permitAll) {
/* 408 */       PermitAllSupport.permitAll((HttpSecurityBuilder<? extends HttpSecurityBuilder<?>>)http, new String[] { this.loginPage, this.loginProcessingUrl, this.failureUrl });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setLoginPage(String loginPage) {
/* 417 */     this.loginPage = loginPage;
/* 418 */     this.authenticationEntryPoint = new LoginUrlAuthenticationEntryPoint(loginPage);
/*     */   }
/*     */   
/*     */   private <C> C getBeanOrNull(B http, Class<C> clazz) {
/* 422 */     ApplicationContext context = (ApplicationContext)http.getSharedObject(ApplicationContext.class);
/* 423 */     if (context == null) {
/* 424 */       return null;
/*     */     }
/* 426 */     return (C)context.getBeanProvider(clazz).getIfUnique();
/*     */   }
/*     */ 
/*     */   
/*     */   private T getSelf() {
/* 431 */     return (T)this;
/*     */   }
/*     */   
/*     */   protected abstract RequestMatcher createLoginProcessingUrlMatcher(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AbstractAuthenticationFilterConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */