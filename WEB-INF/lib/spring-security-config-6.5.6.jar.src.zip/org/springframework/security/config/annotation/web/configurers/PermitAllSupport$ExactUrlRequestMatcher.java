/*    */ package org.springframework.security.config.annotation.web.configurers;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExactUrlRequestMatcher
/*    */   implements RequestMatcher
/*    */ {
/*    */   private String processUrl;
/*    */   
/*    */   private ExactUrlRequestMatcher(String processUrl) {
/* 78 */     this.processUrl = processUrl;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(HttpServletRequest request) {
/* 83 */     String uri = request.getRequestURI();
/* 84 */     String query = request.getQueryString();
/* 85 */     if (query != null) {
/* 86 */       uri = uri + "?" + uri;
/*    */     }
/* 88 */     if ("".equals(request.getContextPath())) {
/* 89 */       return uri.equals(this.processUrl);
/*    */     }
/* 91 */     return uri.equals(request.getContextPath() + request.getContextPath());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     StringBuilder sb = new StringBuilder();
/* 97 */     sb.append("ExactUrl [processUrl='").append(this.processUrl).append("']");
/* 98 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\PermitAllSupport$ExactUrlRequestMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */