/*     */ package org.springframework.security.config.annotation.web.reactive;
/*     */ 
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*     */ import org.springframework.web.reactive.result.method.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.reactive.result.method.annotation.ArgumentResolverConfigurer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements WebFluxConfigurer
/*     */ {
/*     */   public void configureArgumentResolvers(ArgumentResolverConfigurer configurer) {
/* 122 */     configurer.addCustomResolver(new HandlerMethodArgumentResolver[] { (HandlerMethodArgumentResolver)this.val$authenticationPrincipalArgumentResolver.getObject(), (HandlerMethodArgumentResolver)this.val$currentSecurityContextArgumentResolvers
/* 123 */           .getObject() });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ServerHttpSecurityConfiguration$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */