/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.annotation.AnnotationBeanNameGenerator;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.oauth2.client.AuthorizationCodeOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.ClientCredentialsOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.DelegatingOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.JwtBearerOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.PasswordOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.RefreshTokenOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.TokenExchangeOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.endpoint.JwtBearerGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2PasswordGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2RefreshTokenGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.TokenExchangeGrantRequest;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OAuth2AuthorizedClientManagerRegistrar
/*     */   implements ApplicationEventPublisherAware, BeanDefinitionRegistryPostProcessor, BeanFactoryAware
/*     */ {
/*     */   static final String BEAN_NAME = "authorizedClientManagerRegistrar";
/*     */   static final String FACTORY_METHOD_NAME = "getAuthorizedClientManager";
/* 172 */   private static final Set<Class<?>> KNOWN_AUTHORIZED_CLIENT_PROVIDERS = Set.of(AuthorizationCodeOAuth2AuthorizedClientProvider.class, RefreshTokenOAuth2AuthorizedClientProvider.class, ClientCredentialsOAuth2AuthorizedClientProvider.class, PasswordOAuth2AuthorizedClientProvider.class, JwtBearerOAuth2AuthorizedClientProvider.class, TokenExchangeOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   private final AnnotationBeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */   
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*     */   
/*     */   private ListableBeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 190 */     if ((getBeanNamesForType((Class)OAuth2AuthorizedClientManager.class)).length != 0 || (
/* 191 */       getBeanNamesForType((Class)ClientRegistrationRepository.class)).length != 1 || (
/* 192 */       getBeanNamesForType((Class)OAuth2AuthorizedClientRepository.class)).length != 1) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(OAuth2AuthorizedClientManager.class).setFactoryMethodOnBean("getAuthorizedClientManager", "authorizedClientManagerRegistrar").getBeanDefinition();
/*     */     
/* 201 */     registry.registerBeanDefinition(this.beanNameGenerator.generateBeanName((BeanDefinition)abstractBeanDefinition, registry), (BeanDefinition)abstractBeanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 211 */     this.beanFactory = (ListableBeanFactory)beanFactory;
/*     */   }
/*     */   
/*     */   OAuth2AuthorizedClientManager getAuthorizedClientManagerIfAvailable() {
/* 215 */     if ((getBeanNamesForType((Class)ClientRegistrationRepository.class)).length != 1 || (
/* 216 */       getBeanNamesForType((Class)OAuth2AuthorizedClientRepository.class)).length != 1) {
/* 217 */       return null;
/*     */     }
/* 219 */     return getAuthorizedClientManager();
/*     */   }
/*     */   
/*     */   OAuth2AuthorizedClientManager getAuthorizedClientManager() {
/*     */     DelegatingOAuth2AuthorizedClientProvider delegatingOAuth2AuthorizedClientProvider;
/* 224 */     ClientRegistrationRepository clientRegistrationRepository = (ClientRegistrationRepository)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, ClientRegistrationRepository.class, true, true);
/*     */ 
/*     */     
/* 227 */     OAuth2AuthorizedClientRepository authorizedClientRepository = (OAuth2AuthorizedClientRepository)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, OAuth2AuthorizedClientRepository.class, true, true);
/*     */ 
/*     */ 
/*     */     
/* 231 */     Collection<OAuth2AuthorizedClientProvider> authorizedClientProviderBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(this.beanFactory, OAuth2AuthorizedClientProvider.class, true, true).values();
/*     */ 
/*     */     
/* 234 */     if (hasDelegatingAuthorizedClientProvider(authorizedClientProviderBeans)) {
/* 235 */       OAuth2AuthorizedClientProvider authorizedClientProvider = authorizedClientProviderBeans.iterator().next();
/*     */     } else {
/*     */       
/* 238 */       List<OAuth2AuthorizedClientProvider> authorizedClientProviders = new ArrayList<>();
/* 239 */       authorizedClientProviders
/* 240 */         .add(getAuthorizationCodeAuthorizedClientProvider(authorizedClientProviderBeans));
/* 241 */       authorizedClientProviders.add(getRefreshTokenAuthorizedClientProvider(authorizedClientProviderBeans));
/* 242 */       authorizedClientProviders
/* 243 */         .add(getClientCredentialsAuthorizedClientProvider(authorizedClientProviderBeans));
/* 244 */       authorizedClientProviders.add(getPasswordAuthorizedClientProvider(authorizedClientProviderBeans));
/*     */       
/* 246 */       OAuth2AuthorizedClientProvider jwtBearerAuthorizedClientProvider = getJwtBearerAuthorizedClientProvider(authorizedClientProviderBeans);
/*     */       
/* 248 */       if (jwtBearerAuthorizedClientProvider != null) {
/* 249 */         authorizedClientProviders.add(jwtBearerAuthorizedClientProvider);
/*     */       }
/*     */       
/* 252 */       OAuth2AuthorizedClientProvider tokenExchangeAuthorizedClientProvider = getTokenExchangeAuthorizedClientProvider(authorizedClientProviderBeans);
/*     */       
/* 254 */       if (tokenExchangeAuthorizedClientProvider != null) {
/* 255 */         authorizedClientProviders.add(tokenExchangeAuthorizedClientProvider);
/*     */       }
/*     */       
/* 258 */       authorizedClientProviders.addAll(getAdditionalAuthorizedClientProviders(authorizedClientProviderBeans));
/* 259 */       delegatingOAuth2AuthorizedClientProvider = new DelegatingOAuth2AuthorizedClientProvider(authorizedClientProviders);
/*     */     } 
/*     */     
/* 262 */     DefaultOAuth2AuthorizedClientManager authorizedClientManager = new DefaultOAuth2AuthorizedClientManager(clientRegistrationRepository, authorizedClientRepository);
/*     */     
/* 264 */     authorizedClientManager.setAuthorizedClientProvider((OAuth2AuthorizedClientProvider)delegatingOAuth2AuthorizedClientProvider);
/*     */     
/* 266 */     Consumer<DefaultOAuth2AuthorizedClientManager> authorizedClientManagerConsumer = getBeanOfType(
/* 267 */         ResolvableType.forClassWithGenerics(Consumer.class, new Class[] { DefaultOAuth2AuthorizedClientManager.class }));
/* 268 */     if (authorizedClientManagerConsumer != null) {
/* 269 */       authorizedClientManagerConsumer.accept(authorizedClientManager);
/*     */     }
/*     */     
/* 272 */     return (OAuth2AuthorizedClientManager)authorizedClientManager;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasDelegatingAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 277 */     if (authorizedClientProviders.size() != 1) {
/* 278 */       return false;
/*     */     }
/* 280 */     return authorizedClientProviders.iterator().next() instanceof DelegatingOAuth2AuthorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getAuthorizationCodeAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 285 */     AuthorizationCodeOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, AuthorizationCodeOAuth2AuthorizedClientProvider.class);
/*     */     
/* 287 */     if (authorizedClientProvider == null) {
/* 288 */       authorizedClientProvider = new AuthorizationCodeOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 291 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getRefreshTokenAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 296 */     RefreshTokenOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, RefreshTokenOAuth2AuthorizedClientProvider.class);
/*     */     
/* 298 */     if (authorizedClientProvider == null) {
/* 299 */       authorizedClientProvider = new RefreshTokenOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 302 */     OAuth2AccessTokenResponseClient<OAuth2RefreshTokenGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 303 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2RefreshTokenGrantRequest.class }));
/*     */     
/* 305 */     if (accessTokenResponseClient != null) {
/* 306 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 309 */     if (this.applicationEventPublisher != null) {
/* 310 */       authorizedClientProvider.setApplicationEventPublisher(this.applicationEventPublisher);
/*     */     }
/*     */     
/* 313 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getClientCredentialsAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 318 */     ClientCredentialsOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, ClientCredentialsOAuth2AuthorizedClientProvider.class);
/*     */     
/* 320 */     if (authorizedClientProvider == null) {
/* 321 */       authorizedClientProvider = new ClientCredentialsOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 324 */     OAuth2AccessTokenResponseClient<OAuth2ClientCredentialsGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 325 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2ClientCredentialsGrantRequest.class }));
/*     */     
/* 327 */     if (accessTokenResponseClient != null) {
/* 328 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 331 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getPasswordAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 336 */     PasswordOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, PasswordOAuth2AuthorizedClientProvider.class);
/*     */     
/* 338 */     if (authorizedClientProvider == null) {
/* 339 */       authorizedClientProvider = new PasswordOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 342 */     OAuth2AccessTokenResponseClient<OAuth2PasswordGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 343 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2PasswordGrantRequest.class }));
/*     */     
/* 345 */     if (accessTokenResponseClient != null) {
/* 346 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 349 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getJwtBearerAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 354 */     JwtBearerOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, JwtBearerOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */     
/* 357 */     OAuth2AccessTokenResponseClient<JwtBearerGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 358 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { JwtBearerGrantRequest.class }));
/*     */     
/* 360 */     if (accessTokenResponseClient != null) {
/* 361 */       if (authorizedClientProvider == null) {
/* 362 */         authorizedClientProvider = new JwtBearerOAuth2AuthorizedClientProvider();
/*     */       }
/*     */       
/* 365 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     } 
/*     */     
/* 368 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getTokenExchangeAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 373 */     TokenExchangeOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, TokenExchangeOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */     
/* 376 */     OAuth2AccessTokenResponseClient<TokenExchangeGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 377 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { TokenExchangeGrantRequest.class }));
/*     */     
/* 379 */     if (accessTokenResponseClient != null) {
/* 380 */       if (authorizedClientProvider == null) {
/* 381 */         authorizedClientProvider = new TokenExchangeOAuth2AuthorizedClientProvider();
/*     */       }
/*     */       
/* 384 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     } 
/*     */     
/* 387 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<OAuth2AuthorizedClientProvider> getAdditionalAuthorizedClientProviders(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 392 */     List<OAuth2AuthorizedClientProvider> additionalAuthorizedClientProviders = new ArrayList<>(authorizedClientProviders);
/*     */     
/* 394 */     additionalAuthorizedClientProviders
/* 395 */       .removeIf(provider -> KNOWN_AUTHORIZED_CLIENT_PROVIDERS.contains(provider.getClass()));
/* 396 */     return additionalAuthorizedClientProviders;
/*     */   }
/*     */   
/*     */   private <T extends OAuth2AuthorizedClientProvider> T getAuthorizedClientProviderByType(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders, Class<T> providerClass) {
/*     */     OAuth2AuthorizedClientProvider oAuth2AuthorizedClientProvider;
/* 401 */     T authorizedClientProvider = null;
/* 402 */     for (OAuth2AuthorizedClientProvider current : authorizedClientProviders) {
/* 403 */       if (providerClass.isInstance(current)) {
/* 404 */         assertAuthorizedClientProviderIsNull((OAuth2AuthorizedClientProvider)authorizedClientProvider);
/* 405 */         oAuth2AuthorizedClientProvider = (OAuth2AuthorizedClientProvider)providerClass.cast(current);
/*     */       } 
/*     */     } 
/* 408 */     return (T)oAuth2AuthorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void assertAuthorizedClientProviderIsNull(OAuth2AuthorizedClientProvider authorizedClientProvider) {
/* 413 */     if (authorizedClientProvider != null)
/*     */     {
/* 415 */       throw new BeanInitializationException(String.format("Unable to create an %s bean. Expected one bean of type %s, but found multiple. Please consider defining only a single bean of this type, or define an %s bean yourself.", new Object[] { OAuth2AuthorizedClientManager.class
/*     */ 
/*     */               
/* 418 */               .getName(), authorizedClientProvider
/* 419 */               .getClass().getName(), OAuth2AuthorizedClientManager.class
/* 420 */               .getName() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> String[] getBeanNamesForType(Class<T> beanClass) {
/* 426 */     return BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.beanFactory, beanClass, true, true);
/*     */   }
/*     */   
/*     */   private <T> T getBeanOfType(ResolvableType resolvableType) {
/* 430 */     ObjectProvider<T> objectProvider = this.beanFactory.getBeanProvider(resolvableType, true);
/* 431 */     return (T)objectProvider.getIfAvailable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 436 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\OAuth2ClientConfiguration$OAuth2AuthorizedClientManagerRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */