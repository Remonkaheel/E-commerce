/*     */ package org.springframework.security.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConfiguredSecurityBuilder<O, B extends SecurityBuilder<O>>
/*     */   extends AbstractSecurityBuilder<O>
/*     */ {
/*  59 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  61 */   private final LinkedHashMap<Class<? extends SecurityConfigurer<O, B>>, List<SecurityConfigurer<O, B>>> configurers = new LinkedHashMap<>();
/*     */   
/*  63 */   private List<SecurityConfigurer<O, B>> configurersAddedInInitializing = new ArrayList<>();
/*     */   
/*  65 */   private final Map<Class<?>, Object> sharedObjects = new HashMap<>();
/*     */   
/*     */   private final boolean allowConfigurersOfSameType;
/*     */   
/*  69 */   private BuildState buildState = BuildState.UNBUILT;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectPostProcessor<Object> objectPostProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractConfiguredSecurityBuilder(ObjectPostProcessor<Object> objectPostProcessor) {
/*  80 */     this(objectPostProcessor, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   protected AbstractConfiguredSecurityBuilder(ObjectPostProcessor<Object> objectPostProcessor) {
/*  89 */     this(objectPostProcessor, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractConfiguredSecurityBuilder(ObjectPostProcessor<Object> objectPostProcessor, boolean allowConfigurersOfSameType) {
/* 102 */     Assert.notNull(objectPostProcessor, "objectPostProcessor cannot be null");
/* 103 */     this.objectPostProcessor = objectPostProcessor;
/* 104 */     this.allowConfigurersOfSameType = allowConfigurersOfSameType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   protected AbstractConfiguredSecurityBuilder(ObjectPostProcessor<Object> objectPostProcessor, boolean allowConfigurersOfSameType) {
/* 114 */     Assert.notNull(objectPostProcessor, "objectPostProcessor cannot be null");
/* 115 */     this.objectPostProcessor = objectPostProcessor;
/* 116 */     this.allowConfigurersOfSameType = allowConfigurersOfSameType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public O getOrBuild() {
/* 126 */     if (!isUnbuilt()) {
/* 127 */       return getObject();
/*     */     }
/*     */     try {
/* 130 */       return build();
/*     */     }
/* 132 */     catch (Exception ex) {
/* 133 */       this.logger.debug("Failed to perform build. Returning null", ex);
/* 134 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public <C extends SecurityConfigurerAdapter<O, B>> C apply(C configurer) throws Exception {
/* 150 */     configurer.addObjectPostProcessor(this.objectPostProcessor);
/* 151 */     configurer.setBuilder(this);
/* 152 */     add((SecurityConfigurer<O, B>)configurer);
/* 153 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends SecurityConfigurer<O, B>> C apply(C configurer) throws Exception {
/* 165 */     add(configurer);
/* 166 */     return configurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends SecurityConfigurerAdapter<O, B>> B with(C configurer, Customizer<C> customizer) throws Exception {
/* 179 */     configurer.addObjectPostProcessor(this.objectPostProcessor);
/* 180 */     configurer.setBuilder(this);
/* 181 */     add((SecurityConfigurer<O, B>)configurer);
/* 182 */     customizer.customize(configurer);
/* 183 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C> void setSharedObject(Class<C> sharedType, C object) {
/* 193 */     this.sharedObjects.put(sharedType, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C> C getSharedObject(Class<C> sharedType) {
/* 203 */     return (C)this.sharedObjects.get(sharedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Class<?>, Object> getSharedObjects() {
/* 211 */     return Collections.unmodifiableMap(this.sharedObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <C extends SecurityConfigurer<O, B>> void add(C configurer) {
/* 221 */     Assert.notNull(configurer, "configurer cannot be null");
/*     */     
/* 223 */     Class<? extends SecurityConfigurer<O, B>> clazz = (Class)configurer.getClass();
/* 224 */     synchronized (this.configurers) {
/* 225 */       if (this.buildState.isConfigured()) {
/* 226 */         throw new IllegalStateException("Cannot apply " + String.valueOf(configurer) + " to already built object");
/*     */       }
/* 228 */       List<SecurityConfigurer<O, B>> configs = null;
/* 229 */       if (this.allowConfigurersOfSameType) {
/* 230 */         configs = this.configurers.get(clazz);
/*     */       }
/* 232 */       configs = (configs != null) ? configs : new ArrayList<>(1);
/* 233 */       configs.add((SecurityConfigurer<O, B>)configurer);
/* 234 */       this.configurers.put(clazz, configs);
/* 235 */       if (this.buildState.isInitializing()) {
/* 236 */         this.configurersAddedInInitializing.add((SecurityConfigurer<O, B>)configurer);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends SecurityConfigurer<O, B>> List<C> getConfigurers(Class<C> clazz) {
/* 249 */     List<C> configs = (List<C>)this.configurers.get(clazz);
/* 250 */     if (configs == null) {
/* 251 */       return new ArrayList<>();
/*     */     }
/* 253 */     return new ArrayList<>(configs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends SecurityConfigurer<O, B>> List<C> removeConfigurers(Class<C> clazz) {
/* 264 */     List<C> configs = (List<C>)this.configurers.remove(clazz);
/* 265 */     if (configs == null) {
/* 266 */       return new ArrayList<>();
/*     */     }
/* 268 */     removeFromConfigurersAddedInInitializing(clazz);
/* 269 */     return new ArrayList<>(configs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends SecurityConfigurer<O, B>> C getConfigurer(Class<C> clazz) {
/* 280 */     List<SecurityConfigurer<O, B>> configs = this.configurers.get(clazz);
/* 281 */     if (configs == null) {
/* 282 */       return null;
/*     */     }
/* 284 */     Assert.state((configs.size() == 1), () -> "Only one configurer expected for type " + String.valueOf(clazz) + ", but got " + String.valueOf(configs));
/*     */     
/* 286 */     return (C)configs.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends SecurityConfigurer<O, B>> C removeConfigurer(Class<C> clazz) {
/* 297 */     List<SecurityConfigurer<O, B>> configs = this.configurers.remove(clazz);
/* 298 */     if (configs == null) {
/* 299 */       return null;
/*     */     }
/* 301 */     removeFromConfigurersAddedInInitializing(clazz);
/* 302 */     Assert.state((configs.size() == 1), () -> "Only one configurer expected for type " + String.valueOf(clazz) + ", but got " + String.valueOf(configs));
/*     */     
/* 304 */     return (C)configs.get(0);
/*     */   }
/*     */   
/*     */   private <C extends SecurityConfigurer<O, B>> void removeFromConfigurersAddedInInitializing(Class<C> clazz) {
/* 308 */     Objects.requireNonNull(clazz); this.configurersAddedInInitializing.removeIf(clazz::isInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B objectPostProcessor(ObjectPostProcessor<Object> objectPostProcessor) {
/* 318 */     Assert.notNull(objectPostProcessor, "objectPostProcessor cannot be null");
/* 319 */     this.objectPostProcessor = objectPostProcessor;
/* 320 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <P> P postProcess(P object) {
/* 330 */     return (P)this.objectPostProcessor.postProcess(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final O doBuild() throws Exception {
/* 347 */     synchronized (this.configurers) {
/* 348 */       this.buildState = BuildState.INITIALIZING;
/* 349 */       beforeInit();
/* 350 */       init();
/* 351 */       this.buildState = BuildState.CONFIGURING;
/* 352 */       beforeConfigure();
/* 353 */       configure();
/* 354 */       this.buildState = BuildState.BUILDING;
/* 355 */       O result = performBuild();
/* 356 */       this.buildState = BuildState.BUILT;
/* 357 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beforeInit() throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beforeConfigure() throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws Exception {
/* 386 */     Collection<SecurityConfigurer<O, B>> configurers = getConfigurers();
/* 387 */     for (SecurityConfigurer<O, B> configurer : configurers) {
/* 388 */       configurer.init((B)this);
/*     */     }
/* 390 */     while (!this.configurersAddedInInitializing.isEmpty()) {
/* 391 */       List<SecurityConfigurer<O, B>> toInit = this.configurersAddedInInitializing;
/* 392 */       this.configurersAddedInInitializing = new ArrayList<>();
/* 393 */       for (SecurityConfigurer<O, B> configurer : toInit) {
/* 394 */         configurer.init((B)this);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void configure() throws Exception {
/* 401 */     Collection<SecurityConfigurer<O, B>> configurers = getConfigurers();
/* 402 */     for (SecurityConfigurer<O, B> configurer : configurers) {
/* 403 */       configurer.configure((B)this);
/*     */     }
/*     */   }
/*     */   
/*     */   private Collection<SecurityConfigurer<O, B>> getConfigurers() {
/* 408 */     List<SecurityConfigurer<O, B>> result = new ArrayList<>();
/* 409 */     for (List<SecurityConfigurer<O, B>> configs : this.configurers.values()) {
/* 410 */       result.addAll(configs);
/*     */     }
/* 412 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUnbuilt() {
/* 420 */     synchronized (this.configurers) {
/* 421 */       return (this.buildState == BuildState.UNBUILT);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract O performBuild() throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum BuildState
/*     */   {
/* 436 */     UNBUILT(0),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     INITIALIZING(1),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 450 */     CONFIGURING(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 457 */     BUILDING(3),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 462 */     BUILT(4);
/*     */     
/*     */     private final int order;
/*     */     
/*     */     BuildState(int order) {
/* 467 */       this.order = order;
/*     */     }
/*     */     
/*     */     public boolean isInitializing() {
/* 471 */       return (INITIALIZING.order == this.order);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isConfigured() {
/* 479 */       return (this.order >= CONFIGURING.order);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\AbstractConfiguredSecurityBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */