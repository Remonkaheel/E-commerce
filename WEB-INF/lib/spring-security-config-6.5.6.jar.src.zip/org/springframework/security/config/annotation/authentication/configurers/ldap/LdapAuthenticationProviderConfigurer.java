/*     */ package org.springframework.security.config.annotation.authentication.configurers.ldap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ServerSocket;
/*     */ import org.springframework.ldap.core.ContextSource;
/*     */ import org.springframework.ldap.core.support.BaseLdapPathContextSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
/*     */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*     */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.core.authority.mapping.SimpleAuthorityMapper;
/*     */ import org.springframework.security.crypto.password.NoOpPasswordEncoder;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
/*     */ import org.springframework.security.ldap.authentication.AbstractLdapAuthenticator;
/*     */ import org.springframework.security.ldap.authentication.BindAuthenticator;
/*     */ import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
/*     */ import org.springframework.security.ldap.authentication.LdapAuthenticator;
/*     */ import org.springframework.security.ldap.authentication.PasswordComparisonAuthenticator;
/*     */ import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
/*     */ import org.springframework.security.ldap.search.LdapUserSearch;
/*     */ import org.springframework.security.ldap.server.ApacheDSContainer;
/*     */ import org.springframework.security.ldap.server.UnboundIdContainer;
/*     */ import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
/*     */ import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
/*     */ import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LdapAuthenticationProviderConfigurer<B extends ProviderManagerBuilder<B>>
/*     */   extends SecurityConfigurerAdapter<AuthenticationManager, B>
/*     */ {
/*     */   private static final String APACHEDS_CLASSNAME = "org.apache.directory.server.core.DefaultDirectoryService";
/*     */   private static final String UNBOUNDID_CLASSNAME = "com.unboundid.ldap.listener.InMemoryDirectoryServer";
/*     */   private static final boolean apacheDsPresent;
/*     */   private static final boolean unboundIdPresent;
/*  71 */   private String groupRoleAttribute = "cn";
/*     */   
/*  73 */   private String groupSearchBase = "";
/*     */   
/*     */   private boolean groupSearchSubtree = false;
/*     */   
/*  77 */   private String groupSearchFilter = "(uniqueMember={0})";
/*     */   
/*  79 */   private String rolePrefix = "ROLE_";
/*     */   
/*  81 */   private String userSearchBase = "";
/*     */   
/*  83 */   private String userSearchFilter = null;
/*     */   
/*     */   private String[] userDnPatterns;
/*     */   
/*     */   private BaseLdapPathContextSource contextSource;
/*     */   
/*  89 */   private ContextSourceBuilder contextSourceBuilder = new ContextSourceBuilder();
/*     */   
/*     */   private UserDetailsContextMapper userDetailsContextMapper;
/*     */   
/*     */   private PasswordEncoder passwordEncoder;
/*     */   
/*     */   private String passwordAttribute;
/*     */   
/*     */   private LdapAuthoritiesPopulator ldapAuthoritiesPopulator;
/*     */   
/*     */   private GrantedAuthoritiesMapper authoritiesMapper;
/*     */   
/*     */   static {
/* 102 */     ClassLoader classLoader = LdapAuthenticationProviderConfigurer.class.getClassLoader();
/* 103 */     apacheDsPresent = ClassUtils.isPresent("org.apache.directory.server.core.DefaultDirectoryService", classLoader);
/* 104 */     unboundIdPresent = ClassUtils.isPresent("com.unboundid.ldap.listener.InMemoryDirectoryServer", classLoader);
/*     */   }
/*     */   
/*     */   private LdapAuthenticationProvider build() throws Exception {
/* 108 */     BaseLdapPathContextSource contextSource = getContextSource();
/* 109 */     LdapAuthenticator ldapAuthenticator = createLdapAuthenticator(contextSource);
/* 110 */     LdapAuthoritiesPopulator authoritiesPopulator = getLdapAuthoritiesPopulator();
/* 111 */     LdapAuthenticationProvider ldapAuthenticationProvider = new LdapAuthenticationProvider(ldapAuthenticator, authoritiesPopulator);
/*     */     
/* 113 */     ldapAuthenticationProvider.setAuthoritiesMapper(getAuthoritiesMapper());
/* 114 */     if (this.userDetailsContextMapper != null) {
/* 115 */       ldapAuthenticationProvider.setUserDetailsContextMapper(this.userDetailsContextMapper);
/*     */     }
/* 117 */     return ldapAuthenticationProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> ldapAuthoritiesPopulator(LdapAuthoritiesPopulator ldapAuthoritiesPopulator) {
/* 128 */     this.ldapAuthoritiesPopulator = ldapAuthoritiesPopulator;
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 138 */     addObjectPostProcessor(objectPostProcessor);
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public LdapAuthenticationProviderConfigurer<B> withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 148 */     addObjectPostProcessor(objectPostProcessor);
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LdapAuthoritiesPopulator getLdapAuthoritiesPopulator() {
/* 158 */     if (this.ldapAuthoritiesPopulator != null) {
/* 159 */       return this.ldapAuthoritiesPopulator;
/*     */     }
/* 161 */     DefaultLdapAuthoritiesPopulator defaultAuthoritiesPopulator = new DefaultLdapAuthoritiesPopulator((ContextSource)this.contextSource, this.groupSearchBase);
/*     */     
/* 163 */     defaultAuthoritiesPopulator.setGroupRoleAttribute(this.groupRoleAttribute);
/* 164 */     defaultAuthoritiesPopulator.setGroupSearchFilter(this.groupSearchFilter);
/* 165 */     defaultAuthoritiesPopulator.setSearchSubtree(this.groupSearchSubtree);
/* 166 */     defaultAuthoritiesPopulator.setRolePrefix(this.rolePrefix);
/* 167 */     this.ldapAuthoritiesPopulator = (LdapAuthoritiesPopulator)postProcess(defaultAuthoritiesPopulator);
/* 168 */     return (LdapAuthoritiesPopulator)defaultAuthoritiesPopulator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> authoritiesMapper(GrantedAuthoritiesMapper grantedAuthoritiesMapper) {
/* 181 */     this.authoritiesMapper = grantedAuthoritiesMapper;
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GrantedAuthoritiesMapper getAuthoritiesMapper() throws Exception {
/* 192 */     if (this.authoritiesMapper != null) {
/* 193 */       return this.authoritiesMapper;
/*     */     }
/* 195 */     SimpleAuthorityMapper simpleAuthorityMapper = new SimpleAuthorityMapper();
/* 196 */     simpleAuthorityMapper.setPrefix(this.rolePrefix);
/* 197 */     simpleAuthorityMapper.afterPropertiesSet();
/* 198 */     this.authoritiesMapper = (GrantedAuthoritiesMapper)simpleAuthorityMapper;
/* 199 */     return (GrantedAuthoritiesMapper)simpleAuthorityMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LdapAuthenticator createLdapAuthenticator(BaseLdapPathContextSource contextSource) {
/* 209 */     AbstractLdapAuthenticator ldapAuthenticator = (this.passwordEncoder != null) ? (AbstractLdapAuthenticator)createPasswordCompareAuthenticator(contextSource) : (AbstractLdapAuthenticator)createBindAuthenticator(contextSource);
/* 210 */     LdapUserSearch userSearch = createUserSearch();
/* 211 */     if (userSearch != null) {
/* 212 */       ldapAuthenticator.setUserSearch(userSearch);
/*     */     }
/* 214 */     if (this.userDnPatterns != null && this.userDnPatterns.length > 0) {
/* 215 */       ldapAuthenticator.setUserDnPatterns(this.userDnPatterns);
/*     */     }
/* 217 */     return (LdapAuthenticator)postProcess(ldapAuthenticator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PasswordComparisonAuthenticator createPasswordCompareAuthenticator(BaseLdapPathContextSource contextSource) {
/* 227 */     PasswordComparisonAuthenticator ldapAuthenticator = new PasswordComparisonAuthenticator(contextSource);
/* 228 */     if (this.passwordAttribute != null) {
/* 229 */       ldapAuthenticator.setPasswordAttributeName(this.passwordAttribute);
/*     */     }
/* 231 */     ldapAuthenticator.setPasswordEncoder(this.passwordEncoder);
/* 232 */     return ldapAuthenticator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BindAuthenticator createBindAuthenticator(BaseLdapPathContextSource contextSource) {
/* 241 */     return new BindAuthenticator(contextSource);
/*     */   }
/*     */   
/*     */   private LdapUserSearch createUserSearch() {
/* 245 */     if (this.userSearchFilter == null) {
/* 246 */       return null;
/*     */     }
/* 248 */     return (LdapUserSearch)new FilterBasedLdapUserSearch(this.userSearchBase, this.userSearchFilter, this.contextSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> contextSource(BaseLdapPathContextSource contextSource) {
/* 259 */     this.contextSource = contextSource;
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextSourceBuilder contextSource() {
/* 269 */     return this.contextSourceBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> passwordEncoder(PasswordEncoder passwordEncoder) {
/* 281 */     Assert.notNull(passwordEncoder, "passwordEncoder must not be null.");
/* 282 */     this.passwordEncoder = passwordEncoder;
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> userDnPatterns(String... userDnPatterns) {
/* 297 */     this.userDnPatterns = userDnPatterns;
/* 298 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> userDetailsContextMapper(UserDetailsContextMapper userDetailsContextMapper) {
/* 314 */     this.userDetailsContextMapper = userDetailsContextMapper;
/* 315 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> groupRoleAttribute(String groupRoleAttribute) {
/* 324 */     this.groupRoleAttribute = groupRoleAttribute;
/* 325 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> groupSearchBase(String groupSearchBase) {
/* 334 */     this.groupSearchBase = groupSearchBase;
/* 335 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> groupSearchSubtree(boolean groupSearchSubtree) {
/* 346 */     this.groupSearchSubtree = groupSearchSubtree;
/* 347 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> groupSearchFilter(String groupSearchFilter) {
/* 357 */     this.groupSearchFilter = groupSearchFilter;
/* 358 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> rolePrefix(String rolePrefix) {
/* 369 */     this.rolePrefix = rolePrefix;
/* 370 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> userSearchBase(String userSearchBase) {
/* 380 */     this.userSearchBase = userSearchBase;
/* 381 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LdapAuthenticationProviderConfigurer<B> userSearchFilter(String userSearchFilter) {
/* 391 */     this.userSearchFilter = userSearchFilter;
/* 392 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(B builder) throws Exception {
/* 397 */     LdapAuthenticationProvider provider = (LdapAuthenticationProvider)postProcess(build());
/* 398 */     builder.authenticationProvider((AuthenticationProvider)provider);
/*     */   }
/*     */   
/*     */   private BaseLdapPathContextSource getContextSource() throws Exception {
/* 402 */     if (this.contextSource == null) {
/* 403 */       this.contextSource = (BaseLdapPathContextSource)this.contextSourceBuilder.build();
/*     */     }
/* 405 */     return this.contextSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PasswordCompareConfigurer passwordCompare() {
/* 412 */     return (new PasswordCompareConfigurer()).passwordAttribute("password")
/* 413 */       .passwordEncoder(NoOpPasswordEncoder.getInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class PasswordCompareConfigurer
/*     */   {
/*     */     public PasswordCompareConfigurer passwordEncoder(PasswordEncoder passwordEncoder) {
/* 430 */       LdapAuthenticationProviderConfigurer.this.passwordEncoder = passwordEncoder;
/* 431 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PasswordCompareConfigurer passwordAttribute(String passwordAttribute) {
/* 442 */       LdapAuthenticationProviderConfigurer.this.passwordAttribute = passwordAttribute;
/* 443 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LdapAuthenticationProviderConfigurer<B> and() {
/* 452 */       return LdapAuthenticationProviderConfigurer.this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class ContextSourceBuilder
/*     */   {
/*     */     private static final String APACHEDS_CLASSNAME = "org.apache.directory.server.core.DefaultDirectoryService";
/*     */ 
/*     */ 
/*     */     
/*     */     private static final String UNBOUNDID_CLASSNAME = "com.unboundid.ldap.listener.InMemoryDirectoryServer";
/*     */ 
/*     */ 
/*     */     
/*     */     private static final int DEFAULT_PORT = 33389;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final int RANDOM_PORT = 0;
/*     */ 
/*     */ 
/*     */     
/* 478 */     private String ldif = "classpath*:*.ldif";
/*     */     
/*     */     private String managerPassword;
/*     */     
/*     */     private String managerDn;
/*     */     
/*     */     private Integer port;
/*     */     
/* 486 */     private String root = "dc=springframework,dc=org";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextSourceBuilder ldif(String ldif) {
/* 497 */       this.ldif = ldif;
/* 498 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextSourceBuilder managerDn(String managerDn) {
/* 510 */       this.managerDn = managerDn;
/* 511 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextSourceBuilder managerPassword(String managerPassword) {
/* 521 */       this.managerPassword = managerPassword;
/* 522 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextSourceBuilder port(int port) {
/* 535 */       this.port = Integer.valueOf(port);
/* 536 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextSourceBuilder root(String root) {
/* 546 */       this.root = root;
/* 547 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContextSourceBuilder url(String url) {
/* 557 */       this.url = url;
/* 558 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LdapAuthenticationProviderConfigurer<B> and() {
/* 568 */       return LdapAuthenticationProviderConfigurer.this;
/*     */     }
/*     */     
/*     */     private DefaultSpringSecurityContextSource build() throws Exception {
/* 572 */       if (this.url == null) {
/* 573 */         startEmbeddedLdapServer();
/*     */       }
/* 575 */       DefaultSpringSecurityContextSource contextSource = new DefaultSpringSecurityContextSource(getProviderUrl());
/* 576 */       if (this.managerDn != null) {
/* 577 */         contextSource.setUserDn(this.managerDn);
/* 578 */         if (this.managerPassword == null) {
/* 579 */           throw new IllegalStateException("managerPassword is required if managerDn is supplied");
/*     */         }
/* 581 */         contextSource.setPassword(this.managerPassword);
/*     */       } 
/* 583 */       contextSource = (DefaultSpringSecurityContextSource)LdapAuthenticationProviderConfigurer.this.postProcess(contextSource);
/* 584 */       return contextSource;
/*     */     }
/*     */     
/*     */     private void startEmbeddedLdapServer() throws Exception {
/* 588 */       if (LdapAuthenticationProviderConfigurer.apacheDsPresent) {
/* 589 */         ApacheDSContainer apacheDsContainer = new ApacheDSContainer(this.root, this.ldif);
/* 590 */         apacheDsContainer.setPort(getPort());
/* 591 */         LdapAuthenticationProviderConfigurer.this.postProcess(apacheDsContainer);
/* 592 */         this.port = Integer.valueOf(apacheDsContainer.getLocalPort());
/*     */       }
/* 594 */       else if (LdapAuthenticationProviderConfigurer.unboundIdPresent) {
/* 595 */         UnboundIdContainer unboundIdContainer = new UnboundIdContainer(this.root, this.ldif);
/* 596 */         unboundIdContainer.setPort(getPort());
/* 597 */         LdapAuthenticationProviderConfigurer.this.postProcess(unboundIdContainer);
/* 598 */         this.port = Integer.valueOf(unboundIdContainer.getPort());
/*     */       } else {
/*     */         
/* 601 */         throw new IllegalStateException("Embedded LDAP server is not provided");
/*     */       } 
/*     */     }
/*     */     
/*     */     private int getPort() {
/* 606 */       if (this.port == null) {
/* 607 */         this.port = Integer.valueOf(getDefaultPort());
/*     */       }
/* 609 */       return this.port.intValue();
/*     */     }
/*     */     private int getDefaultPort() {
/*     */       try {
/* 613 */         ServerSocket serverSocket = new ServerSocket(33389); 
/* 614 */         try { int i = serverSocket.getLocalPort();
/* 615 */           serverSocket.close(); return i; } catch (Throwable throwable) { try { serverSocket.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 616 */       } catch (IOException ex) {
/* 617 */         return 0;
/*     */       } 
/*     */     }
/*     */     
/*     */     private String getProviderUrl() {
/* 622 */       if (this.url == null) {
/* 623 */         return "ldap://127.0.0.1:" + getPort() + "/" + this.root;
/*     */       }
/* 625 */       return this.url;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurers\ldap\LdapAuthenticationProviderConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */