/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "headers", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nHeadersDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HeadersDsl.kt\norg/springframework/security/config/annotation/web/HeadersDsl$get$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,312:1\n1863#2,2:313\n*S KotlinDebug\n*F\n+ 1 HeadersDsl.kt\norg/springframework/security/config/annotation/web/HeadersDsl$get$1\n*L\n303#1:313,2\n*E\n"})
/*     */ final class HeadersDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<HeadersConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(HeadersConfigurer headers) {
/* 259 */     Intrinsics.checkNotNullParameter(headers, "headers"); Boolean bool = HeadersDsl.this.getDefaultsDisabled(); HeadersDsl headersDsl = HeadersDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-HeadersDsl$get$1$1 = 0;
/* 260 */     Intrinsics.checkNotNull(headersDsl.getDefaultsDisabled()); if (headersDsl.getDefaultsDisabled().booleanValue()) {
/* 261 */       headers.defaultsDisabled();
/*     */     }
/*     */     HeadersDsl.this.getDefaultsDisabled();
/* 264 */     Function1 function12 = HeadersDsl.access$getContentTypeOptions$p(HeadersDsl.this); headersDsl = HeadersDsl.this; Function1 function13 = function12; int $i$a$-also-HeadersDsl$get$1$2 = 0;
/* 265 */     HeadersDsl.access$getContentTypeOptions$p(headersDsl); headers.contentTypeOptions((HeadersDsl.access$getContentTypeOptions$p(headersDsl) != null) ? HeadersDsl.access$getContentTypeOptions$p(headersDsl)::invoke$lambda$2$lambda$1 : null);
/*     */     HeadersDsl.access$getContentTypeOptions$p(HeadersDsl.this);
/* 267 */     function12 = HeadersDsl.access$getXssProtection$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$3 = 0;
/* 268 */     HeadersDsl.access$getXssProtection$p(headersDsl); headers.xssProtection((HeadersDsl.access$getXssProtection$p(headersDsl) != null) ? HeadersDsl.access$getXssProtection$p(headersDsl)::invoke$lambda$4$lambda$3 : null);
/*     */     HeadersDsl.access$getXssProtection$p(HeadersDsl.this);
/* 270 */     function12 = HeadersDsl.access$getCacheControl$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$4 = 0;
/* 271 */     HeadersDsl.access$getCacheControl$p(headersDsl); headers.cacheControl((HeadersDsl.access$getCacheControl$p(headersDsl) != null) ? HeadersDsl.access$getCacheControl$p(headersDsl)::invoke$lambda$6$lambda$5 : null);
/*     */     HeadersDsl.access$getCacheControl$p(HeadersDsl.this);
/* 273 */     function12 = HeadersDsl.access$getHsts$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$5 = 0;
/* 274 */     HeadersDsl.access$getHsts$p(headersDsl); headers.httpStrictTransportSecurity((HeadersDsl.access$getHsts$p(headersDsl) != null) ? HeadersDsl.access$getHsts$p(headersDsl)::invoke$lambda$8$lambda$7 : null);
/*     */     HeadersDsl.access$getHsts$p(HeadersDsl.this);
/* 276 */     function12 = HeadersDsl.access$getFrameOptions$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$6 = 0;
/* 277 */     HeadersDsl.access$getFrameOptions$p(headersDsl); headers.frameOptions((HeadersDsl.access$getFrameOptions$p(headersDsl) != null) ? HeadersDsl.access$getFrameOptions$p(headersDsl)::invoke$lambda$10$lambda$9 : null);
/*     */     HeadersDsl.access$getFrameOptions$p(HeadersDsl.this);
/* 279 */     function12 = HeadersDsl.access$getHpkp$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$7 = 0;
/* 280 */     HeadersDsl.access$getHpkp$p(headersDsl); headers.httpPublicKeyPinning((HeadersDsl.access$getHpkp$p(headersDsl) != null) ? HeadersDsl.access$getHpkp$p(headersDsl)::invoke$lambda$12$lambda$11 : null);
/*     */     HeadersDsl.access$getHpkp$p(HeadersDsl.this);
/* 282 */     function12 = HeadersDsl.access$getContentSecurityPolicy$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$8 = 0;
/* 283 */     HeadersDsl.access$getContentSecurityPolicy$p(headersDsl); headers.contentSecurityPolicy((HeadersDsl.access$getContentSecurityPolicy$p(headersDsl) != null) ? HeadersDsl.access$getContentSecurityPolicy$p(headersDsl)::invoke$lambda$14$lambda$13 : null);
/*     */     HeadersDsl.access$getContentSecurityPolicy$p(HeadersDsl.this);
/* 285 */     function12 = HeadersDsl.access$getReferrerPolicy$p(HeadersDsl.this); headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$9 = 0;
/* 286 */     HeadersDsl.access$getReferrerPolicy$p(headersDsl); headers.referrerPolicy((HeadersDsl.access$getReferrerPolicy$p(headersDsl) != null) ? HeadersDsl.access$getReferrerPolicy$p(headersDsl)::invoke$lambda$16$lambda$15 : null);
/*     */     HeadersDsl.access$getReferrerPolicy$p(HeadersDsl.this);
/* 288 */     String str1 = HeadersDsl.access$getFeaturePolicyDirectives$p(HeadersDsl.this); headersDsl = HeadersDsl.this; String str2 = str1; int $i$a$-also-HeadersDsl$get$1$10 = 0;
/* 289 */     headers.featurePolicy(HeadersDsl.access$getFeaturePolicyDirectives$p(headersDsl));
/*     */     HeadersDsl.access$getFeaturePolicyDirectives$p(HeadersDsl.this);
/* 291 */     Function1 function11 = HeadersDsl.access$getPermissionsPolicy$p(HeadersDsl.this); headersDsl = HeadersDsl.this; Function1 it = function11; int $i$a$-also-HeadersDsl$get$1$11 = 0;
/* 292 */     HeadersDsl.access$getPermissionsPolicy$p(headersDsl); headers.permissionsPolicy((HeadersDsl.access$getPermissionsPolicy$p(headersDsl) != null) ? HeadersDsl.access$getPermissionsPolicy$p(headersDsl)::invoke$lambda$19$lambda$18 : null);
/*     */     HeadersDsl.access$getPermissionsPolicy$p(HeadersDsl.this);
/* 294 */     function11 = HeadersDsl.access$getCrossOriginOpenerPolicy$p(HeadersDsl.this); headersDsl = HeadersDsl.this; it = function11; int $i$a$-also-HeadersDsl$get$1$12 = 0;
/* 295 */     HeadersDsl.access$getCrossOriginOpenerPolicy$p(headersDsl); headers.crossOriginOpenerPolicy((HeadersDsl.access$getCrossOriginOpenerPolicy$p(headersDsl) != null) ? HeadersDsl.access$getCrossOriginOpenerPolicy$p(headersDsl)::invoke$lambda$21$lambda$20 : null);
/*     */     HeadersDsl.access$getCrossOriginOpenerPolicy$p(HeadersDsl.this);
/* 297 */     function11 = HeadersDsl.access$getCrossOriginEmbedderPolicy$p(HeadersDsl.this); headersDsl = HeadersDsl.this; it = function11; int $i$a$-also-HeadersDsl$get$1$13 = 0;
/* 298 */     HeadersDsl.access$getCrossOriginEmbedderPolicy$p(headersDsl); headers.crossOriginEmbedderPolicy((HeadersDsl.access$getCrossOriginEmbedderPolicy$p(headersDsl) != null) ? HeadersDsl.access$getCrossOriginEmbedderPolicy$p(headersDsl)::invoke$lambda$23$lambda$22 : null);
/*     */     HeadersDsl.access$getCrossOriginEmbedderPolicy$p(HeadersDsl.this);
/* 300 */     function11 = HeadersDsl.access$getCrossOriginResourcePolicy$p(HeadersDsl.this); headersDsl = HeadersDsl.this; it = function11; int $i$a$-also-HeadersDsl$get$1$14 = 0;
/* 301 */     HeadersDsl.access$getCrossOriginResourcePolicy$p(headersDsl); headers.crossOriginResourcePolicy((HeadersDsl.access$getCrossOriginResourcePolicy$p(headersDsl) != null) ? HeadersDsl.access$getCrossOriginResourcePolicy$p(headersDsl)::invoke$lambda$25$lambda$24 : null);
/*     */     HeadersDsl.access$getCrossOriginResourcePolicy$p(HeadersDsl.this);
/* 303 */     Iterable $this$forEach$iv = HeadersDsl.access$getHeaderWriters$p(HeadersDsl.this); int $i$f$forEach = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); HeaderWriter headerWriter = (HeaderWriter)element$iv; int $i$a$-forEach-HeadersDsl$get$1$15 = 0;
/*     */       headers.addHeaderWriter(headerWriter); }
/*     */     
/*     */     if (HeadersDsl.access$getDisabled$p(HeadersDsl.this))
/*     */       headers.disable(); 
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$2$lambda$1(Function1 $tmp0, HeadersConfigurer.ContentTypeOptionsConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$4$lambda$3(Function1 $tmp0, HeadersConfigurer.XXssConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$6$lambda$5(Function1 $tmp0, HeadersConfigurer.CacheControlConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$8$lambda$7(Function1 $tmp0, HeadersConfigurer.HstsConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$10$lambda$9(Function1 $tmp0, HeadersConfigurer.FrameOptionsConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$12$lambda$11(Function1 $tmp0, HeadersConfigurer.HpkpConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$14$lambda$13(Function1 $tmp0, HeadersConfigurer.ContentSecurityPolicyConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$16$lambda$15(Function1 $tmp0, HeadersConfigurer.ReferrerPolicyConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$19$lambda$18(Function1 $tmp0, HeadersConfigurer.PermissionsPolicyConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$21$lambda$20(Function1 $tmp0, HeadersConfigurer.CrossOriginOpenerPolicyConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$23$lambda$22(Function1 $tmp0, HeadersConfigurer.CrossOriginEmbedderPolicyConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   private static final void invoke$lambda$25$lambda$24(Function1 $tmp0, HeadersConfigurer.CrossOriginResourcePolicyConfig t) {
/*     */     $tmp0.invoke(t);
/*     */   }
/*     */   
/*     */   HeadersDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HeadersDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */