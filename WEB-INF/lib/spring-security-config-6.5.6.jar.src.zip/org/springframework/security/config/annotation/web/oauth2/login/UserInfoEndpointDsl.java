/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*    */ import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
/*    */ import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
/*    */ import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
/*    */ import org.springframework.security.oauth2.core.oidc.user.OidcUser;
/*    */ import org.springframework.security.oauth2.core.user.OAuth2User;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2LoginSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\026\032\030\022\016\022\f0\030R\b\022\004\022\0020\0320\031\022\004\022\0020\0330\027H\000¢\006\002\b\034R(\020\003\032\020\022\004\022\0020\005\022\004\022\0020\006\030\0010\004X\016¢\006\016\n\000\032\004\b\007\020\b\"\004\b\t\020\nR\034\020\013\032\004\030\0010\fX\016¢\006\016\n\000\032\004\b\r\020\016\"\004\b\017\020\020R(\020\021\032\020\022\004\022\0020\022\022\004\022\0020\023\030\0010\004X\016¢\006\016\n\000\032\004\b\024\020\b\"\004\b\025\020\n¨\006\035"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/login/UserInfoEndpointDsl;", "", "()V", "oidcUserService", "Lorg/springframework/security/oauth2/client/userinfo/OAuth2UserService;", "Lorg/springframework/security/oauth2/client/oidc/userinfo/OidcUserRequest;", "Lorg/springframework/security/oauth2/core/oidc/user/OidcUser;", "getOidcUserService", "()Lorg/springframework/security/oauth2/client/userinfo/OAuth2UserService;", "setOidcUserService", "(Lorg/springframework/security/oauth2/client/userinfo/OAuth2UserService;)V", "userAuthoritiesMapper", "Lorg/springframework/security/core/authority/mapping/GrantedAuthoritiesMapper;", "getUserAuthoritiesMapper", "()Lorg/springframework/security/core/authority/mapping/GrantedAuthoritiesMapper;", "setUserAuthoritiesMapper", "(Lorg/springframework/security/core/authority/mapping/GrantedAuthoritiesMapper;)V", "userService", "Lorg/springframework/security/oauth2/client/userinfo/OAuth2UserRequest;", "Lorg/springframework/security/oauth2/core/user/OAuth2User;", "getUserService", "setUserService", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$UserInfoEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class UserInfoEndpointDsl
/*    */ {
/*    */   @Nullable
/*    */   private OAuth2UserService<OAuth2UserRequest, OAuth2User> userService;
/*    */   @Nullable
/*    */   private OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService;
/*    */   @Nullable
/*    */   private GrantedAuthoritiesMapper userAuthoritiesMapper;
/*    */   
/*    */   @Nullable
/*    */   public final OAuth2UserService<OAuth2UserRequest, OAuth2User> getUserService() {
/* 42 */     return this.userService; } public final void setUserService(@Nullable OAuth2UserService<OAuth2UserRequest, OAuth2User> <set-?>) { this.userService = <set-?>; } @Nullable
/* 43 */   public final OAuth2UserService<OidcUserRequest, OidcUser> getOidcUserService() { return this.oidcUserService; } public final void setOidcUserService(@Nullable OAuth2UserService<OidcUserRequest, OidcUser> <set-?>) { this.oidcUserService = <set-?>; } @Nullable
/* 44 */   public final GrantedAuthoritiesMapper getUserAuthoritiesMapper() { return this.userAuthoritiesMapper; } public final void setUserAuthoritiesMapper(@Nullable GrantedAuthoritiesMapper <set-?>) { this.userAuthoritiesMapper = <set-?>; }
/*    */   
/*    */   @NotNull
/* 47 */   public final Function1<OAuth2LoginConfigurer<HttpSecurity>.UserInfoEndpointConfig, Unit> get$spring_security_config() { return new UserInfoEndpointDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "userInfoEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$UserInfoEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nUserInfoEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UserInfoEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/UserInfoEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,54:1\n1#2:55\n*E\n"})
/* 48 */   static final class UserInfoEndpointDsl$get$1 extends Lambda implements Function1<OAuth2LoginConfigurer<HttpSecurity>.UserInfoEndpointConfig, Unit> { public final void invoke(OAuth2LoginConfigurer.UserInfoEndpointConfig userInfoEndpoint) { Intrinsics.checkNotNullParameter(userInfoEndpoint, "userInfoEndpoint"); if (UserInfoEndpointDsl.this.getUserService() != null) { OAuth2UserService<OAuth2UserRequest, OAuth2User> oAuth2UserService1 = UserInfoEndpointDsl.this.getUserService(); UserInfoEndpointDsl userInfoEndpointDsl = UserInfoEndpointDsl.this; OAuth2UserService<OAuth2UserRequest, OAuth2User> it = oAuth2UserService1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 55 */         int $i$a$-also-UserInfoEndpointDsl$get$1$1 = 0; userInfoEndpoint.userService(userInfoEndpointDsl.getUserService()); } else { UserInfoEndpointDsl.this.getUserService(); }  if (UserInfoEndpointDsl.this.getOidcUserService() != null) { OAuth2UserService<OidcUserRequest, OidcUser> oAuth2UserService1 = UserInfoEndpointDsl.this.getOidcUserService(); UserInfoEndpointDsl userInfoEndpointDsl = UserInfoEndpointDsl.this; OAuth2UserService<OidcUserRequest, OidcUser> it = oAuth2UserService1; int $i$a$-also-UserInfoEndpointDsl$get$1$2 = 0; userInfoEndpoint.oidcUserService(userInfoEndpointDsl.getOidcUserService()); } else { UserInfoEndpointDsl.this.getOidcUserService(); }  if (UserInfoEndpointDsl.this.getUserAuthoritiesMapper() != null) { GrantedAuthoritiesMapper grantedAuthoritiesMapper1 = UserInfoEndpointDsl.this.getUserAuthoritiesMapper(); UserInfoEndpointDsl userInfoEndpointDsl = UserInfoEndpointDsl.this; GrantedAuthoritiesMapper it = grantedAuthoritiesMapper1; int $i$a$-also-UserInfoEndpointDsl$get$1$3 = 0;
/*    */         userInfoEndpoint.userAuthoritiesMapper(userInfoEndpointDsl.getUserAuthoritiesMapper()); }
/*    */       else
/*    */       { UserInfoEndpointDsl.this.getUserAuthoritiesMapper(); }
/*    */        }
/*    */ 
/*    */     
/*    */     UserInfoEndpointDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\UserInfoEndpointDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */