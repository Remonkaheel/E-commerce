/*     */ package org.springframework.security.config.annotation.web.socket;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.messaging.Message;
/*     */ import org.springframework.messaging.handler.invocation.HandlerMethodArgumentResolver;
/*     */ import org.springframework.messaging.simp.annotation.support.SimpAnnotationMethodMessageHandler;
/*     */ import org.springframework.messaging.simp.config.ChannelRegistration;
/*     */ import org.springframework.messaging.support.ChannelInterceptor;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.access.vote.AffirmativeBased;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.configuration.ObjectPostProcessorConfiguration;
/*     */ import org.springframework.security.config.annotation.web.messaging.MessageSecurityMetadataSourceRegistry;
/*     */ import org.springframework.security.messaging.access.expression.DefaultMessageSecurityExpressionHandler;
/*     */ import org.springframework.security.messaging.access.expression.MessageExpressionVoter;
/*     */ import org.springframework.security.messaging.access.intercept.ChannelSecurityInterceptor;
/*     */ import org.springframework.security.messaging.access.intercept.MessageSecurityMetadataSource;
/*     */ import org.springframework.security.messaging.context.AuthenticationPrincipalArgumentResolver;
/*     */ import org.springframework.security.messaging.context.SecurityContextChannelInterceptor;
/*     */ import org.springframework.security.messaging.web.csrf.CsrfChannelInterceptor;
/*     */ import org.springframework.security.messaging.web.socket.server.CsrfTokenHandshakeInterceptor;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
/*     */ import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
/*     */ import org.springframework.web.socket.server.HandshakeInterceptor;
/*     */ import org.springframework.web.socket.server.support.WebSocketHttpRequestHandler;
/*     */ import org.springframework.web.socket.sockjs.SockJsService;
/*     */ import org.springframework.web.socket.sockjs.support.SockJsHttpRequestHandler;
/*     */ import org.springframework.web.socket.sockjs.transport.TransportHandlingSockJsService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483548)
/*     */ @Import({ObjectPostProcessorConfiguration.class})
/*     */ @Deprecated
/*     */ public abstract class AbstractSecurityWebSocketMessageBrokerConfigurer
/*     */   implements WebSocketMessageBrokerConfigurer, SmartInitializingSingleton
/*     */ {
/*  93 */   private final WebSocketMessageSecurityMetadataSourceRegistry inboundRegistry = new WebSocketMessageSecurityMetadataSourceRegistry();
/*     */   
/*  95 */   private SecurityExpressionHandler<Message<Object>> defaultExpressionHandler = (SecurityExpressionHandler<Message<Object>>)new DefaultMessageSecurityExpressionHandler();
/*     */ 
/*     */   
/*     */   private SecurityExpressionHandler<Message<Object>> expressionHandler;
/*     */   
/*     */   private ApplicationContext context;
/*     */ 
/*     */   
/*     */   public void registerStompEndpoints(StompEndpointRegistry registry) {}
/*     */ 
/*     */   
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/* 107 */     argumentResolvers.add(new AuthenticationPrincipalArgumentResolver());
/*     */   }
/*     */ 
/*     */   
/*     */   public final void configureClientInboundChannel(ChannelRegistration registration) {
/* 112 */     ChannelSecurityInterceptor inboundChannelSecurity = (ChannelSecurityInterceptor)this.context.getBean(ChannelSecurityInterceptor.class);
/* 113 */     registration.interceptors(new ChannelInterceptor[] { (ChannelInterceptor)this.context.getBean(SecurityContextChannelInterceptor.class) });
/* 114 */     if (!sameOriginDisabled()) {
/* 115 */       registration.interceptors(new ChannelInterceptor[] { (ChannelInterceptor)this.context.getBean(CsrfChannelInterceptor.class) });
/*     */     }
/* 117 */     if (this.inboundRegistry.containsMapping()) {
/* 118 */       registration.interceptors(new ChannelInterceptor[] { (ChannelInterceptor)inboundChannelSecurity });
/*     */     }
/* 120 */     customizeClientInboundChannel(registration);
/*     */   }
/*     */   
/*     */   private PathMatcher getDefaultPathMatcher() {
/*     */     try {
/* 125 */       return ((SimpAnnotationMethodMessageHandler)this.context.getBean(SimpAnnotationMethodMessageHandler.class)).getPathMatcher();
/*     */     }
/* 127 */     catch (NoSuchBeanDefinitionException ex) {
/* 128 */       return (PathMatcher)new AntPathMatcher();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sameOriginDisabled() {
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customizeClientInboundChannel(ChannelRegistration registration) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public CsrfChannelInterceptor csrfChannelInterceptor() {
/* 157 */     return new CsrfChannelInterceptor();
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   public ChannelSecurityInterceptor inboundChannelSecurity(MessageSecurityMetadataSource messageSecurityMetadataSource) {
/* 163 */     ChannelSecurityInterceptor channelSecurityInterceptor = new ChannelSecurityInterceptor(messageSecurityMetadataSource);
/*     */     
/* 165 */     MessageExpressionVoter<Object> voter = new MessageExpressionVoter();
/* 166 */     voter.setExpressionHandler(getMessageExpressionHandler());
/* 167 */     List<AccessDecisionVoter<?>> voters = new ArrayList<>();
/* 168 */     voters.add(voter);
/* 169 */     AffirmativeBased manager = new AffirmativeBased(voters);
/* 170 */     channelSecurityInterceptor.setAccessDecisionManager((AccessDecisionManager)manager);
/* 171 */     return channelSecurityInterceptor;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public SecurityContextChannelInterceptor securityContextChannelInterceptor() {
/* 176 */     return new SecurityContextChannelInterceptor();
/*     */   }
/*     */   
/*     */   @Bean
/*     */   public MessageSecurityMetadataSource inboundMessageSecurityMetadataSource() {
/* 181 */     this.inboundRegistry.expressionHandler(getMessageExpressionHandler());
/* 182 */     configureInbound(this.inboundRegistry);
/* 183 */     return this.inboundRegistry.createMetadataSource();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureInbound(MessageSecurityMetadataSourceRegistry messages) {}
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   public void setApplicationContext(ApplicationContext context) {
/* 194 */     this.context = context;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setMessageExpessionHandler(List<SecurityExpressionHandler<Message<Object>>> expressionHandlers) {
/* 199 */     setMessageExpressionHandler(expressionHandlers);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setMessageExpressionHandler(List<SecurityExpressionHandler<Message<Object>>> expressionHandlers) {
/* 204 */     if (expressionHandlers.size() == 1) {
/* 205 */       this.expressionHandler = expressionHandlers.get(0);
/*     */     }
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   public void setObjectPostProcessor(ObjectPostProcessor<Object> objectPostProcessor) {
/* 211 */     this.defaultExpressionHandler = (SecurityExpressionHandler<Message<Object>>)objectPostProcessor.postProcess(this.defaultExpressionHandler);
/*     */   }
/*     */   
/*     */   private SecurityExpressionHandler<Message<Object>> getMessageExpressionHandler() {
/* 215 */     if (this.expressionHandler == null) {
/* 216 */       return this.defaultExpressionHandler;
/*     */     }
/* 218 */     return this.expressionHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 223 */     if (sameOriginDisabled()) {
/*     */       return;
/*     */     }
/* 226 */     String beanName = "stompWebSocketHandlerMapping";
/* 227 */     SimpleUrlHandlerMapping mapping = (SimpleUrlHandlerMapping)this.context.getBean(beanName, SimpleUrlHandlerMapping.class);
/* 228 */     Map<String, Object> mappings = mapping.getHandlerMap();
/* 229 */     for (Object object : mappings.values()) {
/* 230 */       if (object instanceof SockJsHttpRequestHandler) {
/* 231 */         setHandshakeInterceptors((SockJsHttpRequestHandler)object); continue;
/*     */       } 
/* 233 */       if (object instanceof WebSocketHttpRequestHandler) {
/* 234 */         setHandshakeInterceptors((WebSocketHttpRequestHandler)object);
/*     */         continue;
/*     */       } 
/* 237 */       throw new IllegalStateException("Bean " + beanName + " is expected to contain mappings to either a SockJsHttpRequestHandler or a WebSocketHttpRequestHandler but got " + String.valueOf(object));
/*     */     } 
/*     */ 
/*     */     
/* 241 */     if (this.inboundRegistry.containsMapping() && !this.inboundRegistry.isSimpDestPathMatcherConfigured()) {
/* 242 */       PathMatcher pathMatcher = getDefaultPathMatcher();
/* 243 */       this.inboundRegistry.simpDestPathMatcher(pathMatcher);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setHandshakeInterceptors(SockJsHttpRequestHandler handler) {
/* 248 */     SockJsService sockJsService = handler.getSockJsService();
/* 249 */     Assert.state(sockJsService instanceof TransportHandlingSockJsService, () -> "sockJsService must be instance of TransportHandlingSockJsService got " + String.valueOf(sockJsService));
/*     */     
/* 251 */     TransportHandlingSockJsService transportHandlingSockJsService = (TransportHandlingSockJsService)sockJsService;
/* 252 */     List<HandshakeInterceptor> handshakeInterceptors = transportHandlingSockJsService.getHandshakeInterceptors();
/* 253 */     List<HandshakeInterceptor> interceptorsToSet = new ArrayList<>(handshakeInterceptors.size() + 1);
/* 254 */     interceptorsToSet.add(new CsrfTokenHandshakeInterceptor());
/* 255 */     interceptorsToSet.addAll(handshakeInterceptors);
/* 256 */     transportHandlingSockJsService.setHandshakeInterceptors(interceptorsToSet);
/*     */   }
/*     */   
/*     */   private void setHandshakeInterceptors(WebSocketHttpRequestHandler handler) {
/* 260 */     List<HandshakeInterceptor> handshakeInterceptors = handler.getHandshakeInterceptors();
/* 261 */     List<HandshakeInterceptor> interceptorsToSet = new ArrayList<>(handshakeInterceptors.size() + 1);
/* 262 */     interceptorsToSet.add(new CsrfTokenHandshakeInterceptor());
/* 263 */     interceptorsToSet.addAll(handshakeInterceptors);
/* 264 */     handler.setHandshakeInterceptors(interceptorsToSet);
/*     */   }
/*     */   
/*     */   private static class WebSocketMessageSecurityMetadataSourceRegistry
/*     */     extends MessageSecurityMetadataSourceRegistry
/*     */   {
/*     */     public MessageSecurityMetadataSource createMetadataSource() {
/* 271 */       return super.createMetadataSource();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean containsMapping() {
/* 276 */       return super.containsMapping();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isSimpDestPathMatcherConfigured() {
/* 281 */       return super.isSimpDestPathMatcherConfigured();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\socket\AbstractSecurityWebSocketMessageBrokerConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */