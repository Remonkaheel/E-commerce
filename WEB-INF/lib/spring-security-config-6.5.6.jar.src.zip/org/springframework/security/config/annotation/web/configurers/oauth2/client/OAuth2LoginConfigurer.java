/*      */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*      */ 
/*      */ import jakarta.servlet.Filter;
/*      */ import jakarta.servlet.http.HttpServletRequest;
/*      */ import jakarta.servlet.http.HttpServletResponse;
/*      */ import jakarta.servlet.http.HttpSession;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationEvent;
/*      */ import org.springframework.context.ApplicationEventPublisher;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.event.GenericApplicationListenerAdapter;
/*      */ import org.springframework.context.event.SmartApplicationListener;
/*      */ import org.springframework.core.ResolvableType;
/*      */ import org.springframework.security.authentication.AuthenticationProvider;
/*      */ import org.springframework.security.config.Customizer;
/*      */ import org.springframework.security.config.annotation.SecurityBuilder;
/*      */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*      */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*      */ import org.springframework.security.config.annotation.web.configurers.AbstractAuthenticationFilterConfigurer;
/*      */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*      */ import org.springframework.security.context.DelegatingApplicationListener;
/*      */ import org.springframework.security.core.Authentication;
/*      */ import org.springframework.security.core.AuthenticationException;
/*      */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*      */ import org.springframework.security.core.session.AbstractSessionEvent;
/*      */ import org.springframework.security.core.session.SessionDestroyedEvent;
/*      */ import org.springframework.security.core.session.SessionIdChangedEvent;
/*      */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
/*      */ import org.springframework.security.oauth2.client.authentication.OAuth2LoginAuthenticationProvider;
/*      */ import org.springframework.security.oauth2.client.authentication.OAuth2LoginAuthenticationToken;
/*      */ import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
/*      */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*      */ import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
/*      */ import org.springframework.security.oauth2.client.oidc.authentication.OidcAuthorizationCodeAuthenticationProvider;
/*      */ import org.springframework.security.oauth2.client.oidc.authentication.OidcAuthorizedClientRefreshedEventListener;
/*      */ import org.springframework.security.oauth2.client.oidc.session.InMemoryOidcSessionRegistry;
/*      */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionInformation;
/*      */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*      */ import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
/*      */ import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
/*      */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*      */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*      */ import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
/*      */ import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
/*      */ import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
/*      */ import org.springframework.security.oauth2.client.web.AuthenticatedPrincipalOAuth2AuthorizedClientRepository;
/*      */ import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
/*      */ import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizationRequestResolver;
/*      */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter;
/*      */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
/*      */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*      */ import org.springframework.security.oauth2.client.web.OAuth2LoginAuthenticationFilter;
/*      */ import org.springframework.security.oauth2.core.AuthorizationGrantType;
/*      */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*      */ import org.springframework.security.oauth2.core.OAuth2Error;
/*      */ import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
/*      */ import org.springframework.security.oauth2.core.oidc.user.OidcUser;
/*      */ import org.springframework.security.oauth2.core.user.OAuth2User;
/*      */ import org.springframework.security.oauth2.jwt.JwtDecoderFactory;
/*      */ import org.springframework.security.web.AuthenticationEntryPoint;
/*      */ import org.springframework.security.web.PortResolver;
/*      */ import org.springframework.security.web.RedirectStrategy;
/*      */ import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
/*      */ import org.springframework.security.web.authentication.DelegatingAuthenticationEntryPoint;
/*      */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*      */ import org.springframework.security.web.authentication.session.SessionAuthenticationException;
/*      */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*      */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*      */ import org.springframework.security.web.context.SecurityContextRepository;
/*      */ import org.springframework.security.web.csrf.CsrfToken;
/*      */ import org.springframework.security.web.savedrequest.RequestCache;
/*      */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*      */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*      */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*      */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*      */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*      */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class OAuth2LoginConfigurer<B extends HttpSecurityBuilder<B>>
/*      */   extends AbstractAuthenticationFilterConfigurer<B, OAuth2LoginConfigurer<B>, OAuth2LoginAuthenticationFilter>
/*      */ {
/*  168 */   private final AuthorizationEndpointConfig authorizationEndpointConfig = new AuthorizationEndpointConfig();
/*      */   
/*  170 */   private final TokenEndpointConfig tokenEndpointConfig = new TokenEndpointConfig();
/*      */   
/*  172 */   private final RedirectionEndpointConfig redirectionEndpointConfig = new RedirectionEndpointConfig();
/*      */   
/*  174 */   private final UserInfoEndpointConfig userInfoEndpointConfig = new UserInfoEndpointConfig();
/*      */   
/*      */   private String loginPage;
/*      */   
/*  178 */   private String loginProcessingUrl = "/login/oauth2/code/*";
/*      */ 
/*      */ 
/*      */   
/*      */   private ClientRegistrationRepository clientRegistrationRepository;
/*      */ 
/*      */   
/*      */   private OAuth2AuthorizedClientRepository authorizedClientRepository;
/*      */ 
/*      */   
/*      */   private SecurityContextRepository securityContextRepository;
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> clientRegistrationRepository(ClientRegistrationRepository clientRegistrationRepository) {
/*  193 */     Assert.notNull(clientRegistrationRepository, "clientRegistrationRepository cannot be null");
/*  194 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(ClientRegistrationRepository.class, clientRegistrationRepository);
/*  195 */     this.clientRegistrationRepository = clientRegistrationRepository;
/*  196 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> authorizedClientRepository(OAuth2AuthorizedClientRepository authorizedClientRepository) {
/*  207 */     Assert.notNull(authorizedClientRepository, "authorizedClientRepository cannot be null");
/*  208 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(OAuth2AuthorizedClientRepository.class, authorizedClientRepository);
/*  209 */     this.authorizedClientRepository = authorizedClientRepository;
/*  210 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> authorizedClientService(OAuth2AuthorizedClientService authorizedClientService) {
/*  219 */     Assert.notNull(authorizedClientService, "authorizedClientService cannot be null");
/*  220 */     authorizedClientRepository((OAuth2AuthorizedClientRepository)new AuthenticatedPrincipalOAuth2AuthorizedClientRepository(authorizedClientService));
/*      */     
/*  222 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> loginPage(String loginPage) {
/*  227 */     Assert.hasText(loginPage, "loginPage cannot be empty");
/*  228 */     this.loginPage = loginPage;
/*  229 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> loginProcessingUrl(String loginProcessingUrl) {
/*  234 */     Assert.hasText(loginProcessingUrl, "loginProcessingUrl cannot be empty");
/*  235 */     this.loginProcessingUrl = loginProcessingUrl;
/*  236 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> securityContextRepository(SecurityContextRepository securityContextRepository) {
/*  246 */     this.securityContextRepository = securityContextRepository;
/*  247 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> oidcSessionRegistry(OidcSessionRegistry oidcSessionRegistry) {
/*  257 */     Assert.notNull(oidcSessionRegistry, "oidcSessionRegistry cannot be null");
/*  258 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(OidcSessionRegistry.class, oidcSessionRegistry);
/*  259 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public AuthorizationEndpointConfig authorizationEndpoint() {
/*  271 */     return this.authorizationEndpointConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> authorizationEndpoint(Customizer<AuthorizationEndpointConfig> authorizationEndpointCustomizer) {
/*  282 */     authorizationEndpointCustomizer.customize(this.authorizationEndpointConfig);
/*  283 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public TokenEndpointConfig tokenEndpoint() {
/*  298 */     return this.tokenEndpointConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> tokenEndpoint(Customizer<TokenEndpointConfig> tokenEndpointCustomizer) {
/*  309 */     tokenEndpointCustomizer.customize(this.tokenEndpointConfig);
/*  310 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public RedirectionEndpointConfig redirectionEndpoint() {
/*  322 */     return this.redirectionEndpointConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> redirectionEndpoint(Customizer<RedirectionEndpointConfig> redirectionEndpointCustomizer) {
/*  333 */     redirectionEndpointCustomizer.customize(this.redirectionEndpointConfig);
/*  334 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public UserInfoEndpointConfig userInfoEndpoint() {
/*  349 */     return this.userInfoEndpointConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OAuth2LoginConfigurer<B> userInfoEndpoint(Customizer<UserInfoEndpointConfig> userInfoEndpointCustomizer) {
/*  359 */     userInfoEndpointCustomizer.customize(this.userInfoEndpointConfig);
/*  360 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(B http) throws Exception {
/*  366 */     OAuth2LoginAuthenticationFilter authenticationFilter = new OAuth2LoginAuthenticationFilter(getClientRegistrationRepository(), getAuthorizedClientRepository(), this.loginProcessingUrl);
/*  367 */     RequestMatcher processUri = RequestMatcherFactory.matcher(this.loginProcessingUrl);
/*  368 */     authenticationFilter.setRequiresAuthenticationRequestMatcher(processUri);
/*  369 */     authenticationFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/*  370 */     if (this.securityContextRepository != null) {
/*  371 */       authenticationFilter.setSecurityContextRepository(this.securityContextRepository);
/*      */     }
/*  373 */     setAuthenticationFilter((AbstractAuthenticationProcessingFilter)authenticationFilter);
/*  374 */     super.loginProcessingUrl(this.loginProcessingUrl);
/*  375 */     if (this.loginPage != null) {
/*      */       
/*  377 */       super.loginPage(this.loginPage);
/*  378 */       super.init((HttpSecurityBuilder)http);
/*      */     } else {
/*      */       
/*  381 */       Map<String, String> loginUrlToClientName = getLoginLinks();
/*  382 */       if (loginUrlToClientName.size() == 1) {
/*      */ 
/*      */         
/*  385 */         updateAuthenticationDefaults();
/*  386 */         updateAccessDefaults((HttpSecurityBuilder)http);
/*  387 */         String providerLoginPage = loginUrlToClientName.keySet().iterator().next();
/*  388 */         registerAuthenticationEntryPoint((HttpSecurityBuilder)http, getLoginEntryPoint(http, providerLoginPage));
/*      */       } else {
/*      */         
/*  391 */         super.init((HttpSecurityBuilder)http);
/*      */       } 
/*      */     } 
/*  394 */     OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient = getAccessTokenResponseClient();
/*  395 */     OAuth2UserService<OAuth2UserRequest, OAuth2User> oauth2UserService = getOAuth2UserService();
/*  396 */     OAuth2LoginAuthenticationProvider oauth2LoginAuthenticationProvider = new OAuth2LoginAuthenticationProvider(accessTokenResponseClient, oauth2UserService);
/*      */     
/*  398 */     GrantedAuthoritiesMapper userAuthoritiesMapper = getGrantedAuthoritiesMapper();
/*  399 */     if (userAuthoritiesMapper != null) {
/*  400 */       oauth2LoginAuthenticationProvider.setAuthoritiesMapper(userAuthoritiesMapper);
/*      */     }
/*  402 */     http.authenticationProvider((AuthenticationProvider)postProcess(oauth2LoginAuthenticationProvider));
/*      */     
/*  404 */     boolean oidcAuthenticationProviderEnabled = ClassUtils.isPresent("org.springframework.security.oauth2.jwt.JwtDecoder", getClass().getClassLoader());
/*  405 */     if (oidcAuthenticationProviderEnabled) {
/*  406 */       OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService = getOidcUserService();
/*  407 */       OidcAuthorizationCodeAuthenticationProvider oidcAuthorizationCodeAuthenticationProvider = new OidcAuthorizationCodeAuthenticationProvider(accessTokenResponseClient, oidcUserService);
/*      */       
/*  409 */       OidcAuthorizedClientRefreshedEventListener oidcAuthorizedClientRefreshedEventListener = new OidcAuthorizedClientRefreshedEventListener();
/*  410 */       oidcAuthorizedClientRefreshedEventListener.setUserService(oidcUserService);
/*  411 */       oidcAuthorizedClientRefreshedEventListener
/*  412 */         .setApplicationEventPublisher((ApplicationEventPublisher)http.getSharedObject(ApplicationContext.class));
/*      */       
/*  414 */       JwtDecoderFactory<ClientRegistration> jwtDecoderFactory = getJwtDecoderFactoryBean();
/*  415 */       if (jwtDecoderFactory != null) {
/*  416 */         oidcAuthorizationCodeAuthenticationProvider.setJwtDecoderFactory(jwtDecoderFactory);
/*  417 */         oidcAuthorizedClientRefreshedEventListener.setJwtDecoderFactory(jwtDecoderFactory);
/*      */       } 
/*  419 */       if (userAuthoritiesMapper != null) {
/*  420 */         oidcAuthorizationCodeAuthenticationProvider.setAuthoritiesMapper(userAuthoritiesMapper);
/*  421 */         oidcAuthorizedClientRefreshedEventListener.setAuthoritiesMapper(userAuthoritiesMapper);
/*      */       } 
/*  423 */       http.authenticationProvider((AuthenticationProvider)postProcess(oidcAuthorizationCodeAuthenticationProvider));
/*      */       
/*  425 */       registerDelegateApplicationListener((ApplicationListener)postProcess(oidcAuthorizedClientRefreshedEventListener));
/*  426 */       configureOidcUserRefreshedEventListener(http);
/*      */     } else {
/*      */       
/*  429 */       http.authenticationProvider(new OidcAuthenticationRequestChecker());
/*      */     } 
/*  431 */     initDefaultLoginFilter(http);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void configure(B http) throws Exception {
/*  437 */     OAuth2AuthorizationRequestRedirectFilter authorizationRequestFilter = new OAuth2AuthorizationRequestRedirectFilter(getAuthorizationRequestResolver());
/*  438 */     if (this.authorizationEndpointConfig.authorizationRequestRepository != null) {
/*  439 */       authorizationRequestFilter
/*  440 */         .setAuthorizationRequestRepository(this.authorizationEndpointConfig.authorizationRequestRepository);
/*      */     }
/*  442 */     if (this.authorizationEndpointConfig.authorizationRedirectStrategy != null) {
/*  443 */       authorizationRequestFilter
/*  444 */         .setAuthorizationRedirectStrategy(this.authorizationEndpointConfig.authorizationRedirectStrategy);
/*      */     }
/*  446 */     RequestCache requestCache = (RequestCache)http.getSharedObject(RequestCache.class);
/*  447 */     if (requestCache != null) {
/*  448 */       authorizationRequestFilter.setRequestCache(requestCache);
/*      */     }
/*  450 */     http.addFilter((Filter)postProcess(authorizationRequestFilter));
/*  451 */     OAuth2LoginAuthenticationFilter authenticationFilter = (OAuth2LoginAuthenticationFilter)getAuthenticationFilter();
/*  452 */     if (this.redirectionEndpointConfig.authorizationResponseBaseUri != null) {
/*  453 */       authenticationFilter.setRequiresAuthenticationRequestMatcher(
/*  454 */           RequestMatcherFactory.matcher(this.redirectionEndpointConfig.authorizationResponseBaseUri));
/*      */     }
/*  456 */     if (this.authorizationEndpointConfig.authorizationRequestRepository != null) {
/*  457 */       authenticationFilter
/*  458 */         .setAuthorizationRequestRepository(this.authorizationEndpointConfig.authorizationRequestRepository);
/*      */     }
/*  460 */     configureOidcSessionRegistry(http);
/*  461 */     super.configure((HttpSecurityBuilder)http);
/*      */   }
/*      */ 
/*      */   
/*      */   protected RequestMatcher createLoginProcessingUrlMatcher(String loginProcessingUrl) {
/*  466 */     return RequestMatcherFactory.matcher(loginProcessingUrl);
/*      */   }
/*      */   
/*      */   private OAuth2AuthorizationRequestResolver getAuthorizationRequestResolver() {
/*  470 */     if (this.authorizationEndpointConfig.authorizationRequestResolver != null) {
/*  471 */       return this.authorizationEndpointConfig.authorizationRequestResolver;
/*      */     }
/*  473 */     ClientRegistrationRepository clientRegistrationRepository = getClientRegistrationRepository();
/*  474 */     ResolvableType resolvableType = ResolvableType.forClass(OAuth2AuthorizationRequestResolver.class);
/*  475 */     OAuth2AuthorizationRequestResolver bean = getBeanOrNull(resolvableType);
/*  476 */     if (bean != null) {
/*  477 */       return bean;
/*      */     }
/*  479 */     String authorizationRequestBaseUri = this.authorizationEndpointConfig.authorizationRequestBaseUri;
/*  480 */     if (authorizationRequestBaseUri == null) {
/*  481 */       authorizationRequestBaseUri = "/oauth2/authorization";
/*      */     }
/*  483 */     return (OAuth2AuthorizationRequestResolver)new DefaultOAuth2AuthorizationRequestResolver(clientRegistrationRepository, authorizationRequestBaseUri);
/*      */   }
/*      */   
/*      */   private ClientRegistrationRepository getClientRegistrationRepository() {
/*  487 */     return (this.clientRegistrationRepository != null) ? this.clientRegistrationRepository : 
/*  488 */       OAuth2ClientConfigurerUtils.<HttpSecurityBuilder>getClientRegistrationRepository((HttpSecurityBuilder)getBuilder());
/*      */   }
/*      */   
/*      */   private OAuth2AuthorizedClientRepository getAuthorizedClientRepository() {
/*  492 */     return (this.authorizedClientRepository != null) ? this.authorizedClientRepository : 
/*  493 */       OAuth2ClientConfigurerUtils.<HttpSecurityBuilder>getAuthorizedClientRepository((HttpSecurityBuilder)getBuilder());
/*      */   }
/*      */ 
/*      */   
/*      */   private JwtDecoderFactory<ClientRegistration> getJwtDecoderFactoryBean() {
/*  498 */     ResolvableType type = ResolvableType.forClassWithGenerics(JwtDecoderFactory.class, new Class[] { ClientRegistration.class });
/*  499 */     String[] names = ((ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class)).getBeanNamesForType(type);
/*  500 */     if (names.length > 1) {
/*  501 */       throw new NoUniqueBeanDefinitionException(type, names);
/*      */     }
/*  503 */     return (JwtDecoderFactory<ClientRegistration>)((ApplicationContext)((HttpSecurityBuilder)getBuilder())
/*  504 */       .getSharedObject(ApplicationContext.class))
/*  505 */       .getBeanProvider(type)
/*  506 */       .getIfUnique();
/*      */   }
/*      */ 
/*      */   
/*      */   private GrantedAuthoritiesMapper getGrantedAuthoritiesMapper() {
/*  511 */     GrantedAuthoritiesMapper grantedAuthoritiesMapper = (GrantedAuthoritiesMapper)((HttpSecurityBuilder)getBuilder()).getSharedObject(GrantedAuthoritiesMapper.class);
/*  512 */     if (grantedAuthoritiesMapper == null) {
/*  513 */       grantedAuthoritiesMapper = getGrantedAuthoritiesMapperBean();
/*  514 */       if (grantedAuthoritiesMapper != null) {
/*  515 */         ((HttpSecurityBuilder)getBuilder()).setSharedObject(GrantedAuthoritiesMapper.class, grantedAuthoritiesMapper);
/*      */       }
/*      */     } 
/*  518 */     return grantedAuthoritiesMapper;
/*      */   }
/*      */ 
/*      */   
/*      */   private GrantedAuthoritiesMapper getGrantedAuthoritiesMapperBean() {
/*  523 */     Map<String, GrantedAuthoritiesMapper> grantedAuthoritiesMapperMap = BeanFactoryUtils.beansOfTypeIncludingAncestors((ListableBeanFactory)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class), GrantedAuthoritiesMapper.class);
/*      */     
/*  525 */     return !grantedAuthoritiesMapperMap.isEmpty() ? grantedAuthoritiesMapperMap.values().iterator().next() : null;
/*      */   }
/*      */   
/*      */   private OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> getAccessTokenResponseClient() {
/*  529 */     if (this.tokenEndpointConfig.accessTokenResponseClient != null) {
/*  530 */       return this.tokenEndpointConfig.accessTokenResponseClient;
/*      */     }
/*  532 */     ResolvableType resolvableType = ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2AuthorizationCodeGrantRequest.class });
/*      */     
/*  534 */     OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> bean = getBeanOrNull(resolvableType);
/*  535 */     return (bean != null) ? bean : (OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest>)new DefaultAuthorizationCodeTokenResponseClient();
/*      */   }
/*      */   
/*      */   private OAuth2UserService<OidcUserRequest, OidcUser> getOidcUserService() {
/*  539 */     if (this.userInfoEndpointConfig.oidcUserService != null) {
/*  540 */       return this.userInfoEndpointConfig.oidcUserService;
/*      */     }
/*  542 */     ResolvableType type = ResolvableType.forClassWithGenerics(OAuth2UserService.class, new Class[] { OidcUserRequest.class, OidcUser.class });
/*      */     
/*  544 */     OAuth2UserService<OidcUserRequest, OidcUser> bean = getBeanOrNull(type);
/*  545 */     return (bean != null) ? bean : (OAuth2UserService<OidcUserRequest, OidcUser>)new OidcUserService();
/*      */   }
/*      */   
/*      */   private OAuth2UserService<OAuth2UserRequest, OAuth2User> getOAuth2UserService() {
/*  549 */     if (this.userInfoEndpointConfig.userService != null) {
/*  550 */       return this.userInfoEndpointConfig.userService;
/*      */     }
/*  552 */     ResolvableType type = ResolvableType.forClassWithGenerics(OAuth2UserService.class, new Class[] { OAuth2UserRequest.class, OAuth2User.class });
/*      */     
/*  554 */     OAuth2UserService<OAuth2UserRequest, OAuth2User> bean = getBeanOrNull(type);
/*  555 */     return (bean != null) ? bean : (OAuth2UserService<OAuth2UserRequest, OAuth2User>)new DefaultOAuth2UserService();
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> T getBeanOrNull(ResolvableType type) {
/*  560 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/*  561 */     if (context == null) {
/*  562 */       return null;
/*      */     }
/*  564 */     return (T)context.getBeanProvider(type).getIfUnique();
/*      */   }
/*      */ 
/*      */   
/*      */   private void initDefaultLoginFilter(B http) {
/*  569 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/*  570 */     if (loginPageGeneratingFilter == null || isCustomLoginPage()) {
/*      */       return;
/*      */     }
/*  573 */     loginPageGeneratingFilter.setOauth2LoginEnabled(true);
/*  574 */     loginPageGeneratingFilter.setOauth2AuthenticationUrlToClientName(getLoginLinks());
/*  575 */     loginPageGeneratingFilter.setLoginPageUrl(getLoginPage());
/*  576 */     loginPageGeneratingFilter.setFailureUrl(getFailureUrl());
/*      */   }
/*      */ 
/*      */   
/*      */   private Map<String, String> getLoginLinks() {
/*  581 */     Iterable<ClientRegistration> clientRegistrations = null;
/*  582 */     ClientRegistrationRepository clientRegistrationRepository = getClientRegistrationRepository();
/*  583 */     ResolvableType type = ResolvableType.forInstance(clientRegistrationRepository).as(Iterable.class);
/*  584 */     if (type != ResolvableType.NONE && ClientRegistration.class.isAssignableFrom(type.resolveGenerics()[0])) {
/*  585 */       clientRegistrations = (Iterable<ClientRegistration>)clientRegistrationRepository;
/*      */     }
/*  587 */     if (clientRegistrations == null) {
/*  588 */       return Collections.emptyMap();
/*      */     }
/*      */ 
/*      */     
/*  592 */     String authorizationRequestBaseUri = (this.authorizationEndpointConfig.authorizationRequestBaseUri != null) ? this.authorizationEndpointConfig.authorizationRequestBaseUri : "/oauth2/authorization";
/*  593 */     Map<String, String> loginUrlToClientName = new HashMap<>();
/*  594 */     clientRegistrations.forEach(registration -> {
/*      */           if (AuthorizationGrantType.AUTHORIZATION_CODE.equals(registration.getAuthorizationGrantType())) {
/*      */             String authorizationRequestUri = authorizationRequestBaseUri + "/" + authorizationRequestBaseUri;
/*      */             loginUrlToClientName.put(authorizationRequestUri, registration.getClientName());
/*      */           } 
/*      */         });
/*  600 */     return loginUrlToClientName;
/*      */   }
/*      */   
/*      */   private AuthenticationEntryPoint getLoginEntryPoint(B http, String providerLoginPage) {
/*  604 */     RequestMatcher loginPageMatcher = RequestMatcherFactory.matcher(getLoginPage());
/*  605 */     RequestMatcher faviconMatcher = RequestMatcherFactory.matcher("/favicon.ico");
/*  606 */     RequestMatcher defaultEntryPointMatcher = getAuthenticationEntryPointMatcher((HttpSecurityBuilder)http);
/*  607 */     AndRequestMatcher andRequestMatcher = new AndRequestMatcher(new RequestMatcher[] { (RequestMatcher)new OrRequestMatcher(new RequestMatcher[] { loginPageMatcher, faviconMatcher }), defaultEntryPointMatcher });
/*      */     
/*  609 */     NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
/*      */     
/*  611 */     RequestMatcher formLoginNotEnabled = getFormLoginNotEnabledRequestMatcher(http);
/*  612 */     LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> entryPoints = new LinkedHashMap<>();
/*  613 */     LoginUrlAuthenticationEntryPoint loginUrlEntryPoint = new LoginUrlAuthenticationEntryPoint(providerLoginPage);
/*  614 */     PortResolver portResolver = getBeanOrNull(ResolvableType.forClass(PortResolver.class));
/*  615 */     if (portResolver != null) {
/*  616 */       loginUrlEntryPoint.setPortResolver(portResolver);
/*      */     }
/*  618 */     entryPoints.put(new AndRequestMatcher(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)new NegatedRequestMatcher((RequestMatcher)andRequestMatcher), formLoginNotEnabled }, ), loginUrlEntryPoint);
/*      */     
/*  620 */     DelegatingAuthenticationEntryPoint loginEntryPoint = new DelegatingAuthenticationEntryPoint(entryPoints);
/*  621 */     loginEntryPoint.setDefaultEntryPoint(getAuthenticationEntryPoint());
/*  622 */     return (AuthenticationEntryPoint)loginEntryPoint;
/*      */   }
/*      */ 
/*      */   
/*      */   private RequestMatcher getFormLoginNotEnabledRequestMatcher(B http) {
/*  627 */     DefaultLoginPageGeneratingFilter defaultLoginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/*      */     
/*  629 */     Field formLoginEnabledField = (defaultLoginPageGeneratingFilter != null) ? ReflectionUtils.findField(DefaultLoginPageGeneratingFilter.class, "formLoginEnabled") : null;
/*  630 */     if (formLoginEnabledField != null) {
/*  631 */       ReflectionUtils.makeAccessible(formLoginEnabledField);
/*  632 */       return request -> Boolean.FALSE.equals(ReflectionUtils.getField(formLoginEnabledField, defaultLoginPageGeneratingFilter));
/*      */     } 
/*      */     
/*  635 */     return AnyRequestMatcher.INSTANCE;
/*      */   }
/*      */   
/*      */   private void configureOidcSessionRegistry(B http) {
/*  639 */     if (http.getConfigurer(OidcLogoutConfigurer.class) == null && http
/*  640 */       .getSharedObject(OidcSessionRegistry.class) == null) {
/*      */       return;
/*      */     }
/*  643 */     OidcSessionRegistry sessionRegistry = OAuth2ClientConfigurerUtils.getOidcSessionRegistry(http);
/*  644 */     SessionManagementConfigurer<B> sessionConfigurer = (SessionManagementConfigurer<B>)http.getConfigurer(SessionManagementConfigurer.class);
/*  645 */     if (sessionConfigurer != null) {
/*  646 */       OidcSessionRegistryAuthenticationStrategy sessionAuthenticationStrategy = new OidcSessionRegistryAuthenticationStrategy();
/*  647 */       sessionAuthenticationStrategy.setSessionRegistry(sessionRegistry);
/*  648 */       sessionConfigurer.addSessionAuthenticationStrategy(sessionAuthenticationStrategy);
/*      */     } 
/*  650 */     OidcClientSessionEventListener listener = new OidcClientSessionEventListener();
/*  651 */     listener.setSessionRegistry(sessionRegistry);
/*  652 */     registerDelegateApplicationListener(listener);
/*      */   }
/*      */   
/*      */   private void configureOidcUserRefreshedEventListener(B http) {
/*  656 */     OidcUserRefreshedEventListener oidcUserRefreshedEventListener = new OidcUserRefreshedEventListener();
/*  657 */     oidcUserRefreshedEventListener.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/*  658 */     SecurityContextRepository securityContextRepository = (SecurityContextRepository)http.getSharedObject(SecurityContextRepository.class);
/*  659 */     if (securityContextRepository != null) {
/*  660 */       oidcUserRefreshedEventListener.setSecurityContextRepository(securityContextRepository);
/*      */     }
/*  662 */     registerDelegateApplicationListener(oidcUserRefreshedEventListener);
/*      */   }
/*      */   
/*      */   private void registerDelegateApplicationListener(ApplicationListener<?> delegate) {
/*  666 */     DelegatingApplicationListener delegating = getBeanOrNull(
/*  667 */         ResolvableType.forType(DelegatingApplicationListener.class));
/*  668 */     if (delegating == null) {
/*      */       return;
/*      */     }
/*  671 */     GenericApplicationListenerAdapter genericApplicationListenerAdapter = new GenericApplicationListenerAdapter(delegate);
/*  672 */     delegating.addListener((SmartApplicationListener)genericApplicationListenerAdapter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class AuthorizationEndpointConfig
/*      */   {
/*      */     private String authorizationRequestBaseUri;
/*      */ 
/*      */ 
/*      */     
/*      */     private OAuth2AuthorizationRequestResolver authorizationRequestResolver;
/*      */ 
/*      */ 
/*      */     
/*      */     private AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository;
/*      */ 
/*      */ 
/*      */     
/*      */     private RedirectStrategy authorizationRedirectStrategy;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AuthorizationEndpointConfig baseUri(String authorizationRequestBaseUri) {
/*  698 */       Assert.hasText(authorizationRequestBaseUri, "authorizationRequestBaseUri cannot be empty");
/*  699 */       this.authorizationRequestBaseUri = authorizationRequestBaseUri;
/*  700 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AuthorizationEndpointConfig authorizationRequestResolver(OAuth2AuthorizationRequestResolver authorizationRequestResolver) {
/*  712 */       Assert.notNull(authorizationRequestResolver, "authorizationRequestResolver cannot be null");
/*  713 */       this.authorizationRequestResolver = authorizationRequestResolver;
/*  714 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AuthorizationEndpointConfig authorizationRequestRepository(AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository) {
/*  725 */       Assert.notNull(authorizationRequestRepository, "authorizationRequestRepository cannot be null");
/*  726 */       this.authorizationRequestRepository = authorizationRequestRepository;
/*  727 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AuthorizationEndpointConfig authorizationRedirectStrategy(RedirectStrategy authorizationRedirectStrategy) {
/*  737 */       this.authorizationRedirectStrategy = authorizationRedirectStrategy;
/*  738 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public OAuth2LoginConfigurer<B> and() {
/*  749 */       return OAuth2LoginConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class TokenEndpointConfig
/*      */   {
/*      */     private OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TokenEndpointConfig accessTokenResponseClient(OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient) {
/*  773 */       Assert.notNull(accessTokenResponseClient, "accessTokenResponseClient cannot be null");
/*  774 */       this.accessTokenResponseClient = accessTokenResponseClient;
/*  775 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public OAuth2LoginConfigurer<B> and() {
/*  789 */       return OAuth2LoginConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class RedirectionEndpointConfig
/*      */   {
/*      */     private String authorizationResponseBaseUri;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RedirectionEndpointConfig baseUri(String authorizationResponseBaseUri) {
/*  811 */       Assert.hasText(authorizationResponseBaseUri, "authorizationResponseBaseUri cannot be empty");
/*  812 */       this.authorizationResponseBaseUri = authorizationResponseBaseUri;
/*  813 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public OAuth2LoginConfigurer<B> and() {
/*  824 */       return OAuth2LoginConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class UserInfoEndpointConfig
/*      */   {
/*      */     private OAuth2UserService<OAuth2UserRequest, OAuth2User> userService;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserInfoEndpointConfig userService(OAuth2UserService<OAuth2UserRequest, OAuth2User> userService) {
/*  849 */       Assert.notNull(userService, "userService cannot be null");
/*  850 */       this.userService = userService;
/*  851 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserInfoEndpointConfig oidcUserService(OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService) {
/*  862 */       Assert.notNull(oidcUserService, "oidcUserService cannot be null");
/*  863 */       this.oidcUserService = oidcUserService;
/*  864 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserInfoEndpointConfig userAuthoritiesMapper(GrantedAuthoritiesMapper userAuthoritiesMapper) {
/*  875 */       Assert.notNull(userAuthoritiesMapper, "userAuthoritiesMapper cannot be null");
/*  876 */       ((HttpSecurityBuilder)OAuth2LoginConfigurer.this.getBuilder())
/*  877 */         .setSharedObject(GrantedAuthoritiesMapper.class, userAuthoritiesMapper);
/*  878 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public OAuth2LoginConfigurer<B> and() {
/*  889 */       return OAuth2LoginConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class OidcAuthenticationRequestChecker
/*      */     implements AuthenticationProvider
/*      */   {
/*      */     public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/*  898 */       OAuth2LoginAuthenticationToken authorizationCodeAuthentication = (OAuth2LoginAuthenticationToken)authentication;
/*      */       
/*  900 */       OAuth2AuthorizationRequest authorizationRequest = authorizationCodeAuthentication.getAuthorizationExchange().getAuthorizationRequest();
/*  901 */       if (authorizationRequest.getScopes().contains("openid")) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  906 */         OAuth2Error oauth2Error = new OAuth2Error("oidc_provider_not_configured", "An OpenID Connect Authentication Provider has not been configured. Check to ensure you include the dependency 'spring-security-oauth2-jose'.", null);
/*      */ 
/*      */ 
/*      */         
/*  910 */         throw new OAuth2AuthenticationException(oauth2Error, oauth2Error.toString());
/*      */       } 
/*  912 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean supports(Class<?> authentication) {
/*  917 */       return OAuth2LoginAuthenticationToken.class.isAssignableFrom(authentication);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class OidcClientSessionEventListener
/*      */     implements ApplicationListener<AbstractSessionEvent>
/*      */   {
/*  924 */     private final Log logger = LogFactory.getLog(OidcClientSessionEventListener.class);
/*      */     
/*  926 */     private OidcSessionRegistry sessionRegistry = (OidcSessionRegistry)new InMemoryOidcSessionRegistry();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onApplicationEvent(AbstractSessionEvent event) {
/*  933 */       if (event instanceof SessionDestroyedEvent) { SessionDestroyedEvent destroyed = (SessionDestroyedEvent)event;
/*  934 */         this.logger.debug("Received SessionDestroyedEvent");
/*  935 */         this.sessionRegistry.removeSessionInformation(destroyed.getId());
/*      */         return; }
/*      */       
/*  938 */       if (event instanceof SessionIdChangedEvent) { SessionIdChangedEvent changed = (SessionIdChangedEvent)event;
/*  939 */         this.logger.debug("Received SessionIdChangedEvent");
/*      */         
/*  941 */         OidcSessionInformation information = this.sessionRegistry.removeSessionInformation(changed.getOldSessionId());
/*  942 */         if (information == null) {
/*  943 */           this.logger
/*  944 */             .debug("Failed to register new session id since old session id was not found in registry");
/*      */           return;
/*      */         } 
/*  947 */         this.sessionRegistry.saveSessionInformation(information.withSessionId(changed.getNewSessionId())); }
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setSessionRegistry(OidcSessionRegistry sessionRegistry) {
/*  957 */       Assert.notNull(sessionRegistry, "sessionRegistry cannot be null");
/*  958 */       this.sessionRegistry = sessionRegistry;
/*      */     } }
/*      */   
/*      */   private static final class OidcSessionRegistryAuthenticationStrategy implements SessionAuthenticationStrategy {
/*      */     private final Log logger;
/*      */     
/*      */     private OidcSessionRegistryAuthenticationStrategy() {
/*  965 */       this.logger = LogFactory.getLog(getClass());
/*      */       
/*  967 */       this.sessionRegistry = (OidcSessionRegistry)new InMemoryOidcSessionRegistry();
/*      */     }
/*      */ 
/*      */     
/*      */     private OidcSessionRegistry sessionRegistry;
/*      */     
/*      */     public void onAuthentication(Authentication authentication, HttpServletRequest request, HttpServletResponse response) throws SessionAuthenticationException {
/*      */       OidcUser user;
/*  975 */       HttpSession session = request.getSession(false);
/*  976 */       if (session == null) {
/*      */         return;
/*      */       }
/*  979 */       Object object = authentication.getPrincipal(); if (object instanceof OidcUser) { user = (OidcUser)object; }
/*      */       else
/*      */       { return; }
/*  982 */        String sessionId = session.getId();
/*  983 */       CsrfToken csrfToken = (CsrfToken)request.getAttribute(CsrfToken.class.getName());
/*      */       
/*  985 */       Map<String, String> headers = (csrfToken != null) ? Map.<String, String>of(csrfToken.getHeaderName(), csrfToken.getToken()) : Collections.<String, String>emptyMap();
/*  986 */       OidcSessionInformation registration = new OidcSessionInformation(sessionId, headers, user);
/*  987 */       if (this.logger.isTraceEnabled()) {
/*  988 */         this.logger
/*  989 */           .trace(String.format("Linking a provider [%s] session to this client's session", new Object[] { user.getIssuer() }));
/*      */       }
/*  991 */       this.sessionRegistry.saveSessionInformation(registration);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setSessionRegistry(OidcSessionRegistry sessionRegistry) {
/* 1000 */       Assert.notNull(sessionRegistry, "sessionRegistry cannot be null");
/* 1001 */       this.sessionRegistry = sessionRegistry;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OAuth2LoginConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */