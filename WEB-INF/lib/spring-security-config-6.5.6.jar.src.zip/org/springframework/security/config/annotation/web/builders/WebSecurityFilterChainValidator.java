/*     */ package org.springframework.security.config.annotation.web.builders;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.UnreachableFilterChainException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebSecurityFilterChainValidator
/*     */   implements FilterChainProxy.FilterChainValidator
/*     */ {
/*  42 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   public void validate(FilterChainProxy filterChainProxy) {
/*  46 */     List<SecurityFilterChain> chains = filterChainProxy.getFilterChains();
/*  47 */     checkForAnyRequestRequestMatcher(chains);
/*  48 */     checkForDuplicateMatchers(chains);
/*  49 */     checkAuthorizationFilters(chains);
/*     */   }
/*     */   
/*     */   private void checkForAnyRequestRequestMatcher(List<SecurityFilterChain> chains) {
/*  53 */     DefaultSecurityFilterChain anyRequestFilterChain = null;
/*  54 */     for (SecurityFilterChain chain : chains) {
/*  55 */       if (anyRequestFilterChain != null) {
/*  56 */         String message = "A filter chain that matches any request [" + String.valueOf(anyRequestFilterChain) + "] has already been configured, which means that this filter chain [" + String.valueOf(chain) + "] will never get invoked. Please use `HttpSecurity#securityMatcher` to ensure that there is only one filter chain configured for 'any request' and that the 'any request' filter chain is published last.";
/*     */ 
/*     */         
/*  59 */         throw new UnreachableFilterChainException(message, anyRequestFilterChain, chain);
/*     */       } 
/*  61 */       if (chain instanceof DefaultSecurityFilterChain) { DefaultSecurityFilterChain defaultChain = (DefaultSecurityFilterChain)chain;
/*  62 */         if (defaultChain.getRequestMatcher() instanceof org.springframework.security.web.util.matcher.AnyRequestMatcher) {
/*  63 */           anyRequestFilterChain = defaultChain;
/*     */         } }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkForDuplicateMatchers(List<SecurityFilterChain> chains) {
/*  70 */     DefaultSecurityFilterChain filterChain = null;
/*  71 */     for (SecurityFilterChain chain : chains) {
/*  72 */       if (filterChain != null && 
/*  73 */         chain instanceof DefaultSecurityFilterChain) { DefaultSecurityFilterChain defaultChain = (DefaultSecurityFilterChain)chain;
/*  74 */         if (defaultChain.getRequestMatcher().equals(filterChain.getRequestMatcher())) {
/*  75 */           throw new UnreachableFilterChainException("The FilterChainProxy contains two filter chains using the matcher " + 
/*     */               
/*  77 */               String.valueOf(defaultChain.getRequestMatcher()), filterChain, defaultChain);
/*     */         } }
/*     */ 
/*     */ 
/*     */       
/*  82 */       if (chain instanceof DefaultSecurityFilterChain) { DefaultSecurityFilterChain defaultChain = (DefaultSecurityFilterChain)chain;
/*  83 */         filterChain = defaultChain; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkAuthorizationFilters(List<SecurityFilterChain> chains) {
/*  89 */     Filter authorizationFilter = null;
/*  90 */     Filter filterSecurityInterceptor = null;
/*  91 */     for (SecurityFilterChain chain : chains) {
/*  92 */       for (Filter filter : chain.getFilters()) {
/*  93 */         if (filter instanceof org.springframework.security.web.access.intercept.AuthorizationFilter) {
/*  94 */           authorizationFilter = filter;
/*     */         }
/*  96 */         if (filter instanceof org.springframework.security.web.access.intercept.FilterSecurityInterceptor) {
/*  97 */           filterSecurityInterceptor = filter;
/*     */         }
/*     */       } 
/* 100 */       if (authorizationFilter != null && filterSecurityInterceptor != null) {
/* 101 */         this.logger.warn("It is not recommended to use authorizeRequests in the configuration. Please only use authorizeHttpRequests");
/*     */       }
/*     */       
/* 104 */       if (filterSecurityInterceptor != null) {
/* 105 */         this.logger.warn("Usage of authorizeRequests is deprecated. Please use authorizeHttpRequests in the configuration");
/*     */       }
/*     */       
/* 108 */       authorizationFilter = null;
/* 109 */       filterSecurityInterceptor = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\builders\WebSecurityFilterChainValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */