/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2LoginSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\n\032\030\022\016\022\f0\fR\b\022\004\022\0020\0160\r\022\004\022\0020\0170\013H\000¢\006\002\b\020R\"\020\003\032\n\022\004\022\0020\005\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\t¨\006\021"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/login/TokenEndpointDsl;", "", "()V", "accessTokenResponseClient", "Lorg/springframework/security/oauth2/client/endpoint/OAuth2AccessTokenResponseClient;", "Lorg/springframework/security/oauth2/client/endpoint/OAuth2AuthorizationCodeGrantRequest;", "getAccessTokenResponseClient", "()Lorg/springframework/security/oauth2/client/endpoint/OAuth2AccessTokenResponseClient;", "setAccessTokenResponseClient", "(Lorg/springframework/security/oauth2/client/endpoint/OAuth2AccessTokenResponseClient;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$TokenEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class TokenEndpointDsl
/*    */ {
/*    */   @Nullable
/*    */   private OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient;
/*    */   
/*    */   @Nullable
/*    */   public final OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> getAccessTokenResponseClient() {
/* 35 */     return this.accessTokenResponseClient; } public final void setAccessTokenResponseClient(@Nullable OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> <set-?>) { this.accessTokenResponseClient = <set-?>; }
/*    */   
/*    */   @NotNull
/* 38 */   public final Function1<OAuth2LoginConfigurer<HttpSecurity>.TokenEndpointConfig, Unit> get$spring_security_config() { return new TokenEndpointDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "tokenEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$TokenEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nTokenEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TokenEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/TokenEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,43:1\n1#2:44\n*E\n"})
/* 39 */   static final class TokenEndpointDsl$get$1 extends Lambda implements Function1<OAuth2LoginConfigurer<HttpSecurity>.TokenEndpointConfig, Unit> { public final void invoke(OAuth2LoginConfigurer.TokenEndpointConfig tokenEndpoint) { Intrinsics.checkNotNullParameter(tokenEndpoint, "tokenEndpoint"); if (TokenEndpointDsl.this.getAccessTokenResponseClient() != null) { OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> oAuth2AccessTokenResponseClient1 = TokenEndpointDsl.this.getAccessTokenResponseClient(); TokenEndpointDsl tokenEndpointDsl = TokenEndpointDsl.this; OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> it = oAuth2AccessTokenResponseClient1;
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 44 */         int $i$a$-also-TokenEndpointDsl$get$1$1 = 0;
/*    */         tokenEndpoint.accessTokenResponseClient(tokenEndpointDsl.getAccessTokenResponseClient()); }
/*    */       else
/*    */       { TokenEndpointDsl.this.getAccessTokenResponseClient(); }
/*    */        }
/*    */ 
/*    */     
/*    */     TokenEndpointDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\TokenEndpointDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */