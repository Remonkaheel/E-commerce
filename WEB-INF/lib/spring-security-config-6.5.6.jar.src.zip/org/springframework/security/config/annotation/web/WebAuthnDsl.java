/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Set;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.http.converter.HttpMessageConverter;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.WebAuthnConfigurer;
/*    */ import org.springframework.security.web.webauthn.registration.PublicKeyCredentialCreationOptionsRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000D\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\"\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\r\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020%\032\024\022\n\022\b\022\004\022\0020(0'\022\004\022\0020)0&H\000¢\006\002\b*R\"\020\003\032\n\022\004\022\0020\005\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\036\020\020\032\004\030\0010\021X\016¢\006\020\n\002\020\026\032\004\b\022\020\023\"\004\b\024\020\025R\"\020\027\032\n\022\004\022\0020\001\030\0010\030X\016¢\006\016\n\000\032\004\b\031\020\032\"\004\b\033\020\034R\034\020\035\032\004\030\0010\005X\016¢\006\016\n\000\032\004\b\036\020\037\"\004\b \020!R\034\020\"\032\004\030\0010\005X\016¢\006\016\n\000\032\004\b#\020\037\"\004\b$\020!¨\006+"}, d2 = {"Lorg/springframework/security/config/annotation/web/WebAuthnDsl;", "", "()V", "allowedOrigins", "", "", "getAllowedOrigins", "()Ljava/util/Set;", "setAllowedOrigins", "(Ljava/util/Set;)V", "creationOptionsRepository", "Lorg/springframework/security/web/webauthn/registration/PublicKeyCredentialCreationOptionsRepository;", "getCreationOptionsRepository", "()Lorg/springframework/security/web/webauthn/registration/PublicKeyCredentialCreationOptionsRepository;", "setCreationOptionsRepository", "(Lorg/springframework/security/web/webauthn/registration/PublicKeyCredentialCreationOptionsRepository;)V", "disableDefaultRegistrationPage", "", "getDisableDefaultRegistrationPage", "()Ljava/lang/Boolean;", "setDisableDefaultRegistrationPage", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "messageConverter", "Lorg/springframework/http/converter/HttpMessageConverter;", "getMessageConverter", "()Lorg/springframework/http/converter/HttpMessageConverter;", "setMessageConverter", "(Lorg/springframework/http/converter/HttpMessageConverter;)V", "rpId", "getRpId", "()Ljava/lang/String;", "setRpId", "(Ljava/lang/String;)V", "rpName", "getRpName", "setRpName", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/WebAuthnConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class WebAuthnDsl
/*    */ {
/*    */   @Nullable
/*    */   private String rpName;
/*    */   @Nullable
/*    */   private String rpId;
/*    */   @Nullable
/*    */   private Set<String> allowedOrigins;
/*    */   
/*    */   @Nullable
/*    */   public final String getRpName() {
/* 36 */     return this.rpName; } public final void setRpName(@Nullable String <set-?>) { this.rpName = <set-?>; } @Nullable
/* 37 */   public final String getRpId() { return this.rpId; } public final void setRpId(@Nullable String <set-?>) { this.rpId = <set-?>; } @Nullable
/* 38 */   public final Set<String> getAllowedOrigins() { return this.allowedOrigins; } public final void setAllowedOrigins(@Nullable Set<String> <set-?>) { this.allowedOrigins = <set-?>; } @Nullable
/* 39 */   private Boolean disableDefaultRegistrationPage = Boolean.valueOf(false); @Nullable private PublicKeyCredentialCreationOptionsRepository creationOptionsRepository; @Nullable private HttpMessageConverter<Object> messageConverter; @Nullable public final Boolean getDisableDefaultRegistrationPage() { return this.disableDefaultRegistrationPage; } public final void setDisableDefaultRegistrationPage(@Nullable Boolean <set-?>) { this.disableDefaultRegistrationPage = <set-?>; } @Nullable
/* 40 */   public final PublicKeyCredentialCreationOptionsRepository getCreationOptionsRepository() { return this.creationOptionsRepository; } public final void setCreationOptionsRepository(@Nullable PublicKeyCredentialCreationOptionsRepository <set-?>) { this.creationOptionsRepository = <set-?>; } @Nullable
/* 41 */   public final HttpMessageConverter<Object> getMessageConverter() { return this.messageConverter; } public final void setMessageConverter(@Nullable HttpMessageConverter<Object> <set-?>) { this.messageConverter = <set-?>; }
/*    */   
/*    */   @NotNull
/* 44 */   public final Function1<WebAuthnConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new WebAuthnDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "webAuthn", "Lorg/springframework/security/config/annotation/web/configurers/WebAuthnConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nWebAuthnDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WebAuthnDsl.kt\norg/springframework/security/config/annotation/web/WebAuthnDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,54:1\n1#2:55\n*E\n"})
/* 45 */   static final class WebAuthnDsl$get$1 extends Lambda implements Function1<WebAuthnConfigurer<HttpSecurity>, Unit> { public final void invoke(WebAuthnConfigurer webAuthn) { Intrinsics.checkNotNullParameter(webAuthn, "webAuthn"); if (WebAuthnDsl.this.getRpName() != null) { String str1 = WebAuthnDsl.this.getRpName(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 55 */         int $i$a$-also-WebAuthnDsl$get$1$1 = 0; webAuthn.rpName(webAuthnDsl.getRpName()); } else { WebAuthnDsl.this.getRpName(); }  if (WebAuthnDsl.this.getRpId() != null) { String str1 = WebAuthnDsl.this.getRpId(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; String it = str1; int $i$a$-also-WebAuthnDsl$get$1$2 = 0; webAuthn.rpId(webAuthnDsl.getRpId()); } else { WebAuthnDsl.this.getRpId(); }  if (WebAuthnDsl.this.getAllowedOrigins() != null) { Set<String> set1 = WebAuthnDsl.this.getAllowedOrigins(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; Set<String> it = set1; int $i$a$-also-WebAuthnDsl$get$1$3 = 0; webAuthn.allowedOrigins(webAuthnDsl.getAllowedOrigins()); } else { WebAuthnDsl.this.getAllowedOrigins(); }  if (WebAuthnDsl.this.getDisableDefaultRegistrationPage() != null) { Boolean bool = WebAuthnDsl.this.getDisableDefaultRegistrationPage(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-WebAuthnDsl$get$1$4 = 0; Intrinsics.checkNotNull(webAuthnDsl.getDisableDefaultRegistrationPage()); webAuthn.disableDefaultRegistrationPage(webAuthnDsl.getDisableDefaultRegistrationPage().booleanValue()); } else { WebAuthnDsl.this.getDisableDefaultRegistrationPage(); }  if (WebAuthnDsl.this.getCreationOptionsRepository() != null) { PublicKeyCredentialCreationOptionsRepository publicKeyCredentialCreationOptionsRepository1 = WebAuthnDsl.this.getCreationOptionsRepository(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; PublicKeyCredentialCreationOptionsRepository it = publicKeyCredentialCreationOptionsRepository1; int $i$a$-also-WebAuthnDsl$get$1$5 = 0; webAuthn.creationOptionsRepository(webAuthnDsl.getCreationOptionsRepository()); } else { WebAuthnDsl.this.getCreationOptionsRepository(); }  if (WebAuthnDsl.this.getMessageConverter() != null) { HttpMessageConverter<Object> httpMessageConverter1 = WebAuthnDsl.this.getMessageConverter(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; HttpMessageConverter<Object> it = httpMessageConverter1; int $i$a$-also-WebAuthnDsl$get$1$6 = 0;
/*    */         webAuthn.messageConverter(webAuthnDsl.getMessageConverter()); }
/*    */       else
/*    */       { WebAuthnDsl.this.getMessageConverter(); }
/*    */        }
/*    */ 
/*    */     
/*    */     WebAuthnDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\WebAuthnDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */