/*    */ package org.springframework.security.config.annotation.web.reactive;
/*    */ 
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReactiveOAuth2ClientImportSelector
/*    */   implements ImportSelector
/*    */ {
/* 39 */   private static final boolean oauth2ClientPresent = ClassUtils.isPresent("org.springframework.security.oauth2.client.registration.ClientRegistration", ReactiveOAuth2ClientImportSelector.class
/*    */       
/* 41 */       .getClassLoader());
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 46 */     if (!oauth2ClientPresent) {
/* 47 */       return new String[0];
/*    */     }
/* 49 */     return new String[] { "org.springframework.security.config.annotation.web.reactive.ReactiveOAuth2ClientConfiguration" };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\reactive\ReactiveOAuth2ClientImportSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */