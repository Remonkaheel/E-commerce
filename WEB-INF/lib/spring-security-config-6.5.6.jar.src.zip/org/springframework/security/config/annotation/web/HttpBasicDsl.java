/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HttpBasicConfigurer;
/*    */ import org.springframework.security.web.AuthenticationEntryPoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000D\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\013\n\000\n\002\020\016\n\002\b\005\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\030\032\0020\031J\037\020\032\032\024\022\n\022\b\022\004\022\0020\0350\034\022\004\022\0020\0310\033H\000¢\006\002\b\036R&\020\003\032\016\022\004\022\0020\005\022\002\b\003\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\016\020\020\032\0020\021X\016¢\006\002\n\000R\034\020\022\032\004\030\0010\023X\016¢\006\016\n\000\032\004\b\024\020\025\"\004\b\026\020\027¨\006\037"}, d2 = {"Lorg/springframework/security/config/annotation/web/HttpBasicDsl;", "", "()V", "authenticationDetailsSource", "Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "Ljakarta/servlet/http/HttpServletRequest;", "getAuthenticationDetailsSource", "()Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "setAuthenticationDetailsSource", "(Lorg/springframework/security/authentication/AuthenticationDetailsSource;)V", "authenticationEntryPoint", "Lorg/springframework/security/web/AuthenticationEntryPoint;", "getAuthenticationEntryPoint", "()Lorg/springframework/security/web/AuthenticationEntryPoint;", "setAuthenticationEntryPoint", "(Lorg/springframework/security/web/AuthenticationEntryPoint;)V", "disabled", "", "realmName", "", "getRealmName", "()Ljava/lang/String;", "setRealmName", "(Ljava/lang/String;)V", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HttpBasicConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class HttpBasicDsl
/*    */ {
/*    */   @Nullable
/*    */   private String realmName;
/*    */   @Nullable
/*    */   private AuthenticationEntryPoint authenticationEntryPoint;
/*    */   @Nullable
/*    */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final String getRealmName() {
/* 40 */     return this.realmName; } public final void setRealmName(@Nullable String <set-?>) { this.realmName = <set-?>; } @Nullable
/* 41 */   public final AuthenticationEntryPoint getAuthenticationEntryPoint() { return this.authenticationEntryPoint; } public final void setAuthenticationEntryPoint(@Nullable AuthenticationEntryPoint <set-?>) { this.authenticationEntryPoint = <set-?>; } @Nullable
/* 42 */   public final AuthenticationDetailsSource<HttpServletRequest, ?> getAuthenticationDetailsSource() { return this.authenticationDetailsSource; } public final void setAuthenticationDetailsSource(@Nullable AuthenticationDetailsSource<HttpServletRequest, ?> <set-?>) { this.authenticationDetailsSource = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 50 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 54 */   public final Function1<HttpBasicConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new HttpBasicDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "httpBasic", "Lorg/springframework/security/config/annotation/web/configurers/HttpBasicConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nHttpBasicDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpBasicDsl.kt\norg/springframework/security/config/annotation/web/HttpBasicDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,64:1\n1#2:65\n*E\n"})
/* 55 */   static final class HttpBasicDsl$get$1 extends Lambda implements Function1<HttpBasicConfigurer<HttpSecurity>, Unit> { public final void invoke(HttpBasicConfigurer httpBasic) { Intrinsics.checkNotNullParameter(httpBasic, "httpBasic"); if (HttpBasicDsl.this.getRealmName() != null) { String str1 = HttpBasicDsl.this.getRealmName(); HttpBasicDsl httpBasicDsl = HttpBasicDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 65 */         int $i$a$-also-HttpBasicDsl$get$1$1 = 0; httpBasic.realmName(httpBasicDsl.getRealmName()); } else { HttpBasicDsl.this.getRealmName(); }  if (HttpBasicDsl.this.getAuthenticationEntryPoint() != null) { AuthenticationEntryPoint authenticationEntryPoint1 = HttpBasicDsl.this.getAuthenticationEntryPoint(); HttpBasicDsl httpBasicDsl = HttpBasicDsl.this; AuthenticationEntryPoint it = authenticationEntryPoint1; int $i$a$-also-HttpBasicDsl$get$1$2 = 0; httpBasic.authenticationEntryPoint(httpBasicDsl.getAuthenticationEntryPoint()); } else { HttpBasicDsl.this.getAuthenticationEntryPoint(); }  if (HttpBasicDsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource1 = HttpBasicDsl.this.getAuthenticationDetailsSource(); HttpBasicDsl httpBasicDsl = HttpBasicDsl.this; AuthenticationDetailsSource<HttpServletRequest, ?> it = authenticationDetailsSource1; int $i$a$-also-HttpBasicDsl$get$1$3 = 0;
/*    */         httpBasic.authenticationDetailsSource(httpBasicDsl.getAuthenticationDetailsSource()); }
/*    */       else
/*    */       { HttpBasicDsl.this.getAuthenticationDetailsSource(); }
/*    */       
/*    */       if (HttpBasicDsl.this.disabled)
/*    */         httpBasic.disable();  }
/*    */ 
/*    */     
/*    */     HttpBasicDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HttpBasicDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */