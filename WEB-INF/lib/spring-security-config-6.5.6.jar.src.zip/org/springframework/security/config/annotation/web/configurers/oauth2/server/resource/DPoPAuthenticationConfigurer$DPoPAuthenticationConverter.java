/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.server.resource;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.oauth2.core.OAuth2AccessToken;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.DPoPAuthenticationToken;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DPoPAuthenticationConverter
/*     */   implements AuthenticationConverter
/*     */ {
/* 157 */   private static final Pattern AUTHORIZATION_PATTERN = Pattern.compile("^DPoP (?<token>[a-zA-Z0-9-._~+/]+=*)$", 2);
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication convert(HttpServletRequest request) {
/* 162 */     List<String> authorizationList = Collections.list(request.getHeaders("Authorization"));
/* 163 */     if (CollectionUtils.isEmpty(authorizationList)) {
/* 164 */       return null;
/*     */     }
/* 166 */     if (authorizationList.size() != 1) {
/* 167 */       OAuth2Error error = new OAuth2Error("invalid_request", "Found multiple Authorization headers.", null);
/*     */       
/* 169 */       throw new OAuth2AuthenticationException(error);
/*     */     } 
/* 171 */     String authorization = authorizationList.get(0);
/* 172 */     if (!StringUtils.startsWithIgnoreCase(authorization, OAuth2AccessToken.TokenType.DPOP.getValue())) {
/* 173 */       return null;
/*     */     }
/* 175 */     Matcher matcher = AUTHORIZATION_PATTERN.matcher(authorization);
/* 176 */     if (!matcher.matches()) {
/* 177 */       OAuth2Error error = new OAuth2Error("invalid_token", "DPoP access token is malformed.", null);
/*     */       
/* 179 */       throw new OAuth2AuthenticationException(error);
/*     */     } 
/* 181 */     String accessToken = matcher.group("token");
/*     */     
/* 183 */     List<String> dPoPProofList = Collections.list(request.getHeaders(OAuth2AccessToken.TokenType.DPOP.getValue()));
/* 184 */     if (CollectionUtils.isEmpty(dPoPProofList) || dPoPProofList.size() != 1) {
/* 185 */       OAuth2Error error = new OAuth2Error("invalid_request", "DPoP proof is missing or invalid.", null);
/*     */       
/* 187 */       throw new OAuth2AuthenticationException(error);
/*     */     } 
/* 189 */     String dPoPProof = dPoPProofList.get(0);
/* 190 */     return (Authentication)new DPoPAuthenticationToken(accessToken, dPoPProof, request.getMethod(), request
/* 191 */         .getRequestURL().toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\server\resource\DPoPAuthenticationConfigurer$DPoPAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */