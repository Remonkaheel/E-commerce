/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.context.annotation.Role;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.aot.hint.PrePostAuthorizeHintsRegistrar;
/*     */ import org.springframework.security.aot.hint.SecurityHintsRegistrar;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.method.AuthorizationAdvisor;
/*     */ import org.springframework.security.authorization.method.AuthorizationManagerAfterMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.AuthorizationManagerBeforeMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.MethodInvocationResult;
/*     */ import org.springframework.security.authorization.method.PostAuthorizeAuthorizationManager;
/*     */ import org.springframework.security.authorization.method.PostFilterAuthorizationMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.PreAuthorizeAuthorizationManager;
/*     */ import org.springframework.security.authorization.method.PreFilterAuthorizationMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.PrePostTemplateDefaults;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(value = "_prePostMethodSecurityConfiguration", proxyBeanMethods = false)
/*     */ @Role(2)
/*     */ final class PrePostMethodSecurityConfiguration
/*     */   implements ImportAware, ApplicationContextAware, AopInfrastructureBean
/*     */ {
/*  67 */   private static final Pointcut preFilterPointcut = (new PreFilterAuthorizationMethodInterceptor()).getPointcut();
/*     */   
/*  69 */   private static final Pointcut preAuthorizePointcut = AuthorizationManagerBeforeMethodInterceptor.preAuthorize()
/*  70 */     .getPointcut();
/*     */   
/*  72 */   private static final Pointcut postAuthorizePointcut = AuthorizationManagerAfterMethodInterceptor.postAuthorize()
/*  73 */     .getPointcut();
/*     */   
/*  75 */   private static final Pointcut postFilterPointcut = (new PostFilterAuthorizationMethodInterceptor()).getPointcut();
/*     */   
/*  77 */   private final PreAuthorizeAuthorizationManager preAuthorizeAuthorizationManager = new PreAuthorizeAuthorizationManager();
/*     */   
/*  79 */   private final PostAuthorizeAuthorizationManager postAuthorizeAuthorizationManager = new PostAuthorizeAuthorizationManager();
/*     */   
/*  81 */   private final PreFilterAuthorizationMethodInterceptor preFilterMethodInterceptor = new PreFilterAuthorizationMethodInterceptor();
/*     */   
/*     */   private final AuthorizationManagerBeforeMethodInterceptor preAuthorizeMethodInterceptor;
/*     */   
/*     */   private final AuthorizationManagerAfterMethodInterceptor postAuthorizeMethodInterceptor;
/*     */   
/*  87 */   private final PostFilterAuthorizationMethodInterceptor postFilterMethodInterceptor = new PostFilterAuthorizationMethodInterceptor();
/*     */   
/*  89 */   private final DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
/*     */ 
/*     */ 
/*     */   
/*     */   PrePostMethodSecurityConfiguration(ObjectProvider<ObjectPostProcessor<AuthorizationManager<MethodInvocation>>> preAuthorizeProcessor, ObjectProvider<ObjectPostProcessor<AuthorizationManager<MethodInvocationResult>>> postAuthorizeProcessor) {
/*  94 */     this.preFilterMethodInterceptor.setExpressionHandler((MethodSecurityExpressionHandler)this.expressionHandler);
/*  95 */     this.preAuthorizeAuthorizationManager.setExpressionHandler((MethodSecurityExpressionHandler)this.expressionHandler);
/*  96 */     this.postAuthorizeAuthorizationManager.setExpressionHandler((MethodSecurityExpressionHandler)this.expressionHandler);
/*  97 */     this.postFilterMethodInterceptor.setExpressionHandler((MethodSecurityExpressionHandler)this.expressionHandler);
/*     */ 
/*     */     
/* 100 */     AuthorizationManager<MethodInvocation> preAuthorize = (AuthorizationManager<MethodInvocation>)((ObjectPostProcessor)preAuthorizeProcessor.getIfUnique(ObjectPostProcessor::identity)).postProcess(this.preAuthorizeAuthorizationManager);
/* 101 */     this.preAuthorizeMethodInterceptor = AuthorizationManagerBeforeMethodInterceptor.preAuthorize(preAuthorize);
/*     */ 
/*     */     
/* 104 */     AuthorizationManager<MethodInvocationResult> postAuthorize = (AuthorizationManager<MethodInvocationResult>)((ObjectPostProcessor)postAuthorizeProcessor.getIfUnique(ObjectPostProcessor::identity)).postProcess(this.postAuthorizeAuthorizationManager);
/* 105 */     this.postAuthorizeMethodInterceptor = AuthorizationManagerAfterMethodInterceptor.postAuthorize(postAuthorize);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) throws BeansException {
/* 110 */     this.expressionHandler.setApplicationContext(context);
/* 111 */     this.preAuthorizeAuthorizationManager.setApplicationContext(context);
/* 112 */     this.postAuthorizeAuthorizationManager.setApplicationContext(context);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setGrantedAuthorityDefaults(GrantedAuthorityDefaults grantedAuthorityDefaults) {
/* 117 */     this.expressionHandler.setDefaultRolePrefix(grantedAuthorityDefaults.getRolePrefix());
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 122 */     this.expressionHandler.setRoleHierarchy(roleHierarchy);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/* 127 */     this.preFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/* 128 */     this.preAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 129 */     this.postAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 130 */     this.postFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setTemplateDefaults(PrePostTemplateDefaults templateDefaults) {
/* 135 */     this.preFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/* 136 */     this.preAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 137 */     this.postAuthorizeAuthorizationManager.setTemplateDefaults(templateDefaults);
/* 138 */     this.postFilterMethodInterceptor.setTemplateDefaults(templateDefaults);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/* 143 */     this.preFilterMethodInterceptor.setExpressionHandler(expressionHandler);
/* 144 */     this.preAuthorizeAuthorizationManager.setExpressionHandler(expressionHandler);
/* 145 */     this.postAuthorizeAuthorizationManager.setExpressionHandler(expressionHandler);
/* 146 */     this.postFilterMethodInterceptor.setExpressionHandler(expressionHandler);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 151 */     this.preFilterMethodInterceptor.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/* 152 */     this.preAuthorizeMethodInterceptor.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/* 153 */     this.postAuthorizeMethodInterceptor.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/* 154 */     this.postFilterMethodInterceptor.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setAuthorizationEventPublisher(AuthorizationEventPublisher publisher) {
/* 159 */     this.preAuthorizeMethodInterceptor.setAuthorizationEventPublisher(publisher);
/* 160 */     this.postAuthorizeMethodInterceptor.setAuthorizationEventPublisher(publisher);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor preFilterAuthorizationMethodInterceptor(ObjectProvider<PrePostMethodSecurityConfiguration> _prePostMethodSecurityConfiguration) {
/* 167 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(preFilterPointcut, () -> ((PrePostMethodSecurityConfiguration)_prePostMethodSecurityConfiguration.getObject()).preFilterMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor preAuthorizeAuthorizationMethodInterceptor(ObjectProvider<PrePostMethodSecurityConfiguration> _prePostMethodSecurityConfiguration) {
/* 175 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(preAuthorizePointcut, () -> ((PrePostMethodSecurityConfiguration)_prePostMethodSecurityConfiguration.getObject()).preAuthorizeMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor postAuthorizeAuthorizationMethodInterceptor(ObjectProvider<PrePostMethodSecurityConfiguration> _prePostMethodSecurityConfiguration) {
/* 183 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(postAuthorizePointcut, () -> ((PrePostMethodSecurityConfiguration)_prePostMethodSecurityConfiguration.getObject()).postAuthorizeMethodInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodInterceptor postFilterAuthorizationMethodInterceptor(ObjectProvider<PrePostMethodSecurityConfiguration> _prePostMethodSecurityConfiguration) {
/* 191 */     return (MethodInterceptor)new DeferringMethodInterceptor<>(postFilterPointcut, () -> ((PrePostMethodSecurityConfiguration)_prePostMethodSecurityConfiguration.getObject()).postFilterMethodInterceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static SecurityHintsRegistrar prePostAuthorizeExpressionHintsRegistrar() {
/* 198 */     return (SecurityHintsRegistrar)new PrePostAuthorizeHintsRegistrar();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/* 203 */     EnableMethodSecurity annotation = (EnableMethodSecurity)importMetadata.getAnnotations().get(EnableMethodSecurity.class).synthesize();
/* 204 */     this.preFilterMethodInterceptor.setOrder(this.preFilterMethodInterceptor.getOrder() + annotation.offset());
/* 205 */     this.preAuthorizeMethodInterceptor
/* 206 */       .setOrder(this.preAuthorizeMethodInterceptor.getOrder() + annotation.offset());
/* 207 */     this.postAuthorizeMethodInterceptor
/* 208 */       .setOrder(this.postAuthorizeMethodInterceptor.getOrder() + annotation.offset());
/* 209 */     this.postFilterMethodInterceptor.setOrder(this.postFilterMethodInterceptor.getOrder() + annotation.offset());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\PrePostMethodSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */