/*     */ package org.springframework.security.config.annotation.web.messaging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.messaging.Message;
/*     */ import org.springframework.messaging.simp.SimpMessageType;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.messaging.access.expression.DefaultMessageSecurityExpressionHandler;
/*     */ import org.springframework.security.messaging.access.expression.ExpressionBasedMessageSecurityMetadataSourceFactory;
/*     */ import org.springframework.security.messaging.access.intercept.MessageSecurityMetadataSource;
/*     */ import org.springframework.security.messaging.util.matcher.MessageMatcher;
/*     */ import org.springframework.security.messaging.util.matcher.SimpDestinationMessageMatcher;
/*     */ import org.springframework.security.messaging.util.matcher.SimpMessageTypeMatcher;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MessageSecurityMetadataSourceRegistry
/*     */ {
/*     */   private static final String permitAll = "permitAll";
/*     */   private static final String denyAll = "denyAll";
/*     */   private static final String anonymous = "anonymous";
/*     */   private static final String authenticated = "authenticated";
/*     */   private static final String fullyAuthenticated = "fullyAuthenticated";
/*     */   private static final String rememberMe = "rememberMe";
/*  64 */   private SecurityExpressionHandler<Message<Object>> expressionHandler = (SecurityExpressionHandler<Message<Object>>)new DefaultMessageSecurityExpressionHandler();
/*     */   
/*  66 */   private final LinkedHashMap<MatcherBuilder, String> matcherToExpression = new LinkedHashMap<>();
/*     */   
/*  68 */   private DelegatingPathMatcher pathMatcher = new DelegatingPathMatcher();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean defaultPathMatcher = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint anyMessage() {
/*  77 */     return matchers((MessageMatcher<?>[])new MessageMatcher[] { MessageMatcher.ANY_MESSAGE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint nullDestMatcher() {
/*  87 */     return matchers((MessageMatcher<?>[])new MessageMatcher[] { SimpDestinationMessageMatcher.NULL_DESTINATION_MATCHER });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint simpTypeMatchers(SimpMessageType... typesToMatch) {
/*  96 */     MessageMatcher[] arrayOfMessageMatcher = new MessageMatcher[typesToMatch.length];
/*  97 */     for (int i = 0; i < typesToMatch.length; i++) {
/*  98 */       SimpMessageType typeToMatch = typesToMatch[i];
/*  99 */       arrayOfMessageMatcher[i] = (MessageMatcher)new SimpMessageTypeMatcher(typeToMatch);
/*     */     } 
/* 101 */     return matchers((MessageMatcher<?>[])arrayOfMessageMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint simpDestMatchers(String... patterns) {
/* 116 */     return simpDestMatchers(null, patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint simpMessageDestMatchers(String... patterns) {
/* 131 */     return simpDestMatchers(SimpMessageType.MESSAGE, patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint simpSubscribeDestMatchers(String... patterns) {
/* 146 */     return simpDestMatchers(SimpMessageType.SUBSCRIBE, patterns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Constraint simpDestMatchers(SimpMessageType type, String... patterns) {
/* 162 */     List<MatcherBuilder> matchers = new ArrayList<>(patterns.length);
/* 163 */     for (String pattern : patterns) {
/* 164 */       matchers.add(new PathMatcherMessageMatcherBuilder(pattern, type));
/*     */     }
/* 166 */     return new Constraint(matchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageSecurityMetadataSourceRegistry simpDestPathMatcher(PathMatcher pathMatcher) {
/* 178 */     Assert.notNull(pathMatcher, "pathMatcher cannot be null");
/* 179 */     this.pathMatcher.setPathMatcher(pathMatcher);
/* 180 */     this.defaultPathMatcher = false;
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSimpDestPathMatcherConfigured() {
/* 191 */     return !this.defaultPathMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constraint matchers(MessageMatcher<?>... matchers) {
/* 201 */     List<MatcherBuilder> builders = new ArrayList<>(matchers.length);
/* 202 */     for (MessageMatcher<?> matcher : matchers) {
/* 203 */       builders.add(new PreBuiltMatcherBuilder(matcher));
/*     */     }
/* 205 */     return new Constraint(builders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageSecurityMetadataSourceRegistry expressionHandler(SecurityExpressionHandler<Message<Object>> expressionHandler) {
/* 218 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/* 219 */     this.expressionHandler = expressionHandler;
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MessageSecurityMetadataSource createMetadataSource() {
/* 233 */     LinkedHashMap<MessageMatcher<?>, String> matcherToExpression = new LinkedHashMap<>();
/* 234 */     for (Map.Entry<MatcherBuilder, String> entry : this.matcherToExpression.entrySet()) {
/* 235 */       matcherToExpression.put(((MatcherBuilder)entry.getKey()).build(), entry.getValue());
/*     */     }
/* 237 */     return 
/* 238 */       ExpressionBasedMessageSecurityMetadataSourceFactory.createExpressionMessageMetadataSource(matcherToExpression, this.expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean containsMapping() {
/* 251 */     return !this.matcherToExpression.isEmpty();
/*     */   }
/*     */   
/*     */   private static String hasAnyRole(String... authorities) {
/* 255 */     String anyAuthorities = StringUtils.arrayToDelimitedString((Object[])authorities, "','ROLE_");
/* 256 */     return "hasAnyRole('ROLE_" + anyAuthorities + "')";
/*     */   }
/*     */   
/*     */   private static String hasRole(String role) {
/* 260 */     Assert.notNull(role, "role cannot be null");
/* 261 */     if (role.startsWith("ROLE_")) {
/* 262 */       throw new IllegalArgumentException("role should not start with 'ROLE_' since it is automatically inserted. Got '" + role + "'");
/*     */     }
/*     */     
/* 265 */     return "hasRole('ROLE_" + role + "')";
/*     */   }
/*     */   
/*     */   private static String hasAuthority(String authority) {
/* 269 */     return "hasAuthority('" + authority + "')";
/*     */   }
/*     */   
/*     */   private static String hasAnyAuthority(String... authorities) {
/* 273 */     String anyAuthorities = StringUtils.arrayToDelimitedString((Object[])authorities, "','");
/* 274 */     return "hasAnyAuthority('" + anyAuthorities + "')";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class Constraint
/*     */   {
/*     */     private final List<? extends MessageSecurityMetadataSourceRegistry.MatcherBuilder> messageMatchers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Constraint(List<? extends MessageSecurityMetadataSourceRegistry.MatcherBuilder> messageMatchers) {
/* 291 */       Assert.notEmpty(messageMatchers, "messageMatchers cannot be null or empty");
/* 292 */       this.messageMatchers = messageMatchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry hasRole(String role) {
/* 305 */       return access(MessageSecurityMetadataSourceRegistry.hasRole(role));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry hasAnyRole(String... roles) {
/* 318 */       return access(MessageSecurityMetadataSourceRegistry.hasAnyRole(roles));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry hasAuthority(String authority) {
/* 328 */       return access(MessageSecurityMetadataSourceRegistry.hasAuthority(authority));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry hasAnyAuthority(String... authorities) {
/* 340 */       return access(MessageSecurityMetadataSourceRegistry.hasAnyAuthority(authorities));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry permitAll() {
/* 349 */       return access("permitAll");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry anonymous() {
/* 358 */       return access("anonymous");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry rememberMe() {
/* 368 */       return access("rememberMe");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry denyAll() {
/* 377 */       return access("denyAll");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry authenticated() {
/* 386 */       return access("authenticated");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry fullyAuthenticated() {
/* 397 */       return access("fullyAuthenticated");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MessageSecurityMetadataSourceRegistry access(String attribute) {
/* 408 */       for (MessageSecurityMetadataSourceRegistry.MatcherBuilder messageMatcher : this.messageMatchers) {
/* 409 */         MessageSecurityMetadataSourceRegistry.this.matcherToExpression.put(messageMatcher, attribute);
/*     */       }
/* 411 */       return MessageSecurityMetadataSourceRegistry.this;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class PreBuiltMatcherBuilder
/*     */     implements MatcherBuilder
/*     */   {
/*     */     private MessageMatcher<?> matcher;
/*     */     
/*     */     private PreBuiltMatcherBuilder(MessageMatcher<?> matcher) {
/* 421 */       this.matcher = matcher;
/*     */     }
/*     */ 
/*     */     
/*     */     public MessageMatcher<?> build() {
/* 426 */       return this.matcher;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class PathMatcherMessageMatcherBuilder
/*     */     implements MatcherBuilder
/*     */   {
/*     */     private final String pattern;
/*     */     private final SimpMessageType type;
/*     */     
/*     */     private PathMatcherMessageMatcherBuilder(String pattern, SimpMessageType type) {
/* 438 */       this.pattern = pattern;
/* 439 */       this.type = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public MessageMatcher<?> build() {
/* 444 */       if (this.type == null) {
/* 445 */         return (MessageMatcher<?>)new SimpDestinationMessageMatcher(this.pattern, MessageSecurityMetadataSourceRegistry.this.pathMatcher);
/*     */       }
/*     */       
/* 448 */       if (SimpMessageType.MESSAGE == this.type) {
/* 449 */         return (MessageMatcher<?>)SimpDestinationMessageMatcher.createMessageMatcher(this.pattern, MessageSecurityMetadataSourceRegistry.this.pathMatcher);
/*     */       }
/*     */       
/* 452 */       if (SimpMessageType.SUBSCRIBE == this.type) {
/* 453 */         return (MessageMatcher<?>)SimpDestinationMessageMatcher.createSubscribeMatcher(this.pattern, MessageSecurityMetadataSourceRegistry.this.pathMatcher);
/*     */       }
/*     */       
/* 456 */       throw new IllegalStateException(String.valueOf(this.type) + " is not supported since it does not have a destination");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DelegatingPathMatcher
/*     */     implements PathMatcher
/*     */   {
/* 469 */     private PathMatcher delegate = (PathMatcher)new AntPathMatcher();
/*     */ 
/*     */     
/*     */     public boolean isPattern(String path) {
/* 473 */       return this.delegate.isPattern(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean match(String pattern, String path) {
/* 478 */       return this.delegate.match(pattern, path);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matchStart(String pattern, String path) {
/* 483 */       return this.delegate.matchStart(pattern, path);
/*     */     }
/*     */ 
/*     */     
/*     */     public String extractPathWithinPattern(String pattern, String path) {
/* 488 */       return this.delegate.extractPathWithinPattern(pattern, path);
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, String> extractUriTemplateVariables(String pattern, String path) {
/* 493 */       return this.delegate.extractUriTemplateVariables(pattern, path);
/*     */     }
/*     */ 
/*     */     
/*     */     public Comparator<String> getPatternComparator(String path) {
/* 498 */       return this.delegate.getPatternComparator(path);
/*     */     }
/*     */ 
/*     */     
/*     */     public String combine(String pattern1, String pattern2) {
/* 503 */       return this.delegate.combine(pattern1, pattern2);
/*     */     }
/*     */     
/*     */     void setPathMatcher(PathMatcher pathMatcher) {
/* 507 */       this.delegate = pathMatcher;
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface MatcherBuilder {
/*     */     MessageMatcher<?> build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\messaging\MessageSecurityMetadataSourceRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */