/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.security.authorization.method.AuthorizationAdvisor;
/*    */ import org.springframework.util.function.SingletonSupplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DeferringMethodInterceptor<M extends AuthorizationAdvisor>
/*    */   implements AuthorizationAdvisor
/*    */ {
/*    */   private final Pointcut pointcut;
/*    */   private final Supplier<M> delegate;
/*    */   
/*    */   DeferringMethodInterceptor(Pointcut pointcut, Supplier<M> delegate) {
/* 37 */     this.pointcut = pointcut;
/* 38 */     this.delegate = (Supplier<M>)SingletonSupplier.of(delegate);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(@NotNull MethodInvocation invocation) throws Throwable {
/* 44 */     return ((AuthorizationAdvisor)this.delegate.get()).invoke(invocation);
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointcut getPointcut() {
/* 49 */     return this.pointcut;
/*    */   }
/*    */ 
/*    */   
/*    */   public Advice getAdvice() {
/* 54 */     return (Advice)this;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 59 */     return ((AuthorizationAdvisor)this.delegate.get()).getOrder();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPerInstance() {
/* 64 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\DeferringMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */