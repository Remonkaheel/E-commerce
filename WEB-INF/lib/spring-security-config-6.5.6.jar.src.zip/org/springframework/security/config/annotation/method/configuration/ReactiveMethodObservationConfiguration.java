/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.security.authorization.ObservationReactiveAuthorizationManager;
/*    */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*    */ import org.springframework.security.authorization.method.MethodInvocationResult;
/*    */ import org.springframework.security.config.ObjectPostProcessor;
/*    */ import org.springframework.security.config.observation.SecurityObservationSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ class ReactiveMethodObservationConfiguration
/*    */ {
/* 37 */   private static final SecurityObservationSettings all = SecurityObservationSettings.withDefaults()
/* 38 */     .shouldObserveRequests(true)
/* 39 */     .shouldObserveAuthentications(true)
/* 40 */     .shouldObserveAuthorizations(true)
/* 41 */     .build();
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocation>> methodAuthorizationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 47 */     return new ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocation>>()
/*    */       {
/*    */         public ReactiveAuthorizationManager postProcess(ReactiveAuthorizationManager object) {
/* 50 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 51 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ReactiveMethodObservationConfiguration.all)).shouldObserveAuthorizations());
/* 52 */           return active ? (ReactiveAuthorizationManager)new ObservationReactiveAuthorizationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocationResult>> methodResultAuthorizationManagerPostProcessor(final ObjectProvider<ObservationRegistry> registry, final ObjectProvider<SecurityObservationSettings> predicate) {
/* 61 */     return new ObjectPostProcessor<ReactiveAuthorizationManager<MethodInvocationResult>>()
/*    */       {
/*    */         public ReactiveAuthorizationManager postProcess(ReactiveAuthorizationManager object) {
/* 64 */           ObservationRegistry r = (ObservationRegistry)registry.getIfUnique(() -> ObservationRegistry.NOOP);
/* 65 */           boolean active = (!r.isNoop() && ((SecurityObservationSettings)predicate.getIfUnique(() -> ReactiveMethodObservationConfiguration.all)).shouldObserveAuthorizations());
/* 66 */           return active ? (ReactiveAuthorizationManager)new ObservationReactiveAuthorizationManager(r, object) : object;
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\ReactiveMethodObservationConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */