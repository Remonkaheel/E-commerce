/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
/*    */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
/*    */ import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "authorizationEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$AuthorizationEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nAuthorizationEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AuthorizationEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/AuthorizationEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,53:1\n1#2:54\n*E\n"})
/*    */ final class AuthorizationEndpointDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OAuth2LoginConfigurer<HttpSecurity>.AuthorizationEndpointConfig, Unit>
/*    */ {
/*    */   public final void invoke(OAuth2LoginConfigurer.AuthorizationEndpointConfig authorizationEndpoint) {
/* 46 */     Intrinsics.checkNotNullParameter(authorizationEndpoint, "authorizationEndpoint"); if (AuthorizationEndpointDsl.this.getBaseUri() != null) { String str1 = AuthorizationEndpointDsl.this.getBaseUri(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 54 */       int $i$a$-also-AuthorizationEndpointDsl$get$1$1 = 0; authorizationEndpoint.baseUri(authorizationEndpointDsl.getBaseUri()); } else { AuthorizationEndpointDsl.this.getBaseUri(); }  if (AuthorizationEndpointDsl.this.getAuthorizationRequestResolver() != null) { OAuth2AuthorizationRequestResolver oAuth2AuthorizationRequestResolver1 = AuthorizationEndpointDsl.this.getAuthorizationRequestResolver(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; OAuth2AuthorizationRequestResolver it = oAuth2AuthorizationRequestResolver1; int $i$a$-also-AuthorizationEndpointDsl$get$1$2 = 0; authorizationEndpoint.authorizationRequestResolver(authorizationEndpointDsl.getAuthorizationRequestResolver()); } else { AuthorizationEndpointDsl.this.getAuthorizationRequestResolver(); }  if (AuthorizationEndpointDsl.this.getAuthorizationRequestRepository() != null) { AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository1 = AuthorizationEndpointDsl.this.getAuthorizationRequestRepository(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; AuthorizationRequestRepository<OAuth2AuthorizationRequest> it = authorizationRequestRepository1; int $i$a$-also-AuthorizationEndpointDsl$get$1$3 = 0; authorizationEndpoint.authorizationRequestRepository(authorizationEndpointDsl.getAuthorizationRequestRepository()); } else { AuthorizationEndpointDsl.this.getAuthorizationRequestRepository(); }  if (AuthorizationEndpointDsl.this.getAuthorizationRedirectStrategy() != null) { RedirectStrategy redirectStrategy1 = AuthorizationEndpointDsl.this.getAuthorizationRedirectStrategy(); AuthorizationEndpointDsl authorizationEndpointDsl = AuthorizationEndpointDsl.this; RedirectStrategy it = redirectStrategy1; int $i$a$-also-AuthorizationEndpointDsl$get$1$4 = 0;
/*    */       authorizationEndpoint.authorizationRedirectStrategy(authorizationEndpointDsl.getAuthorizationRedirectStrategy()); }
/*    */     else
/*    */     { AuthorizationEndpointDsl.this.getAuthorizationRedirectStrategy(); }
/*    */   
/*    */   }
/*    */   
/*    */   AuthorizationEndpointDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\AuthorizationEndpointDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */