/*     */ package org.springframework.security.config.annotation.rsocket;
/*     */ 
/*     */ import org.springframework.security.authorization.AuthenticatedReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeAuthorizationContext;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcher;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcherEntry;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Access
/*     */ {
/*     */   private final PayloadExchangeMatcher matcher;
/*     */   
/*     */   private Access(PayloadExchangeMatcher matcher) {
/* 400 */     this.matcher = matcher;
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec authenticated() {
/* 404 */     return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthenticatedReactiveAuthorizationManager.authenticated());
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec hasAuthority(String authority) {
/* 408 */     return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAuthority(authority));
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec hasRole(String role) {
/* 412 */     return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasRole(role));
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec hasAnyRole(String... roles) {
/* 416 */     return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyRole(roles));
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec permitAll() {
/* 420 */     return access((a, ctx) -> Mono.just(new AuthorizationDecision(true)));
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec hasAnyAuthority(String... authorities) {
/* 424 */     return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyAuthority(authorities));
/*     */   }
/*     */ 
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec access(ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext> authorization) {
/* 429 */     RSocketSecurity.AuthorizePayloadsSpec.this.authzBuilder
/* 430 */       .add(new PayloadExchangeMatcherEntry(this.matcher, authorization));
/* 431 */     return RSocketSecurity.AuthorizePayloadsSpec.this;
/*     */   }
/*     */   
/*     */   public RSocketSecurity.AuthorizePayloadsSpec denyAll() {
/* 435 */     return access((a, ctx) -> Mono.just(new AuthorizationDecision(false)));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\RSocketSecurity$AuthorizePayloadsSpec$Access.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */