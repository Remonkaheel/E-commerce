package org.springframework.security.config.annotation;

import org.springframework.security.config.ObjectPostProcessor;

@Deprecated
public interface ObjectPostProcessor<T> extends ObjectPostProcessor<T> {
  <O extends T> O postProcess(O paramO);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\ObjectPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */