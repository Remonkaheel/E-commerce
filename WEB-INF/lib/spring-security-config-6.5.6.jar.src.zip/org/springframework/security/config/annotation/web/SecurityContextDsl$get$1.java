/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.SecurityContextConfigurer;
/*    */ import org.springframework.security.web.context.SecurityContextRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "securityContext", "Lorg/springframework/security/config/annotation/web/configurers/SecurityContextConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nSecurityContextDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SecurityContextDsl.kt\norg/springframework/security/config/annotation/web/SecurityContextDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,43:1\n1#2:44\n*E\n"})
/*    */ final class SecurityContextDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<SecurityContextConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(SecurityContextConfigurer securityContext) {
/* 38 */     Intrinsics.checkNotNullParameter(securityContext, "securityContext"); if (SecurityContextDsl.this.getSecurityContextRepository() != null) { SecurityContextRepository securityContextRepository1 = SecurityContextDsl.this.getSecurityContextRepository(), it = securityContextRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 44 */       int $i$a$-also-SecurityContextDsl$get$1$1 = 0; securityContext.securityContextRepository(it); } else { SecurityContextDsl.this.getSecurityContextRepository(); }  if (SecurityContextDsl.this.getRequireExplicitSave() != null) { Boolean bool = SecurityContextDsl.this.getRequireExplicitSave(); boolean it = bool.booleanValue(); int $i$a$-also-SecurityContextDsl$get$1$2 = 0;
/*    */       securityContext.requireExplicitSave(it); }
/*    */     else
/*    */     { SecurityContextDsl.this.getRequireExplicitSave(); }
/*    */   
/*    */   }
/*    */   
/*    */   SecurityContextDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\SecurityContextDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */