/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionInformation;
/*     */ import org.springframework.security.oauth2.client.oidc.session.OidcSessionRegistry;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.oauth2.core.http.converter.OAuth2ErrorHttpMessageConverter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.client.RestClientException;
/*     */ import org.springframework.web.client.RestOperations;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OidcBackChannelLogoutHandler
/*     */   implements LogoutHandler
/*     */ {
/*  62 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final OidcSessionRegistry sessionRegistry;
/*     */   
/*  66 */   private RestOperations restOperations = (RestOperations)new RestTemplate();
/*     */   
/*  68 */   private String logoutUri = "{baseUrl}/logout/connect/back-channel/{registrationId}";
/*     */   
/*  70 */   private String sessionCookieName = "JSESSIONID";
/*     */   
/*  72 */   private final OAuth2ErrorHttpMessageConverter errorHttpMessageConverter = new OAuth2ErrorHttpMessageConverter();
/*     */   
/*     */   public OidcBackChannelLogoutHandler(OidcSessionRegistry sessionRegistry) {
/*  75 */     this.sessionRegistry = sessionRegistry;
/*     */   }
/*     */   
/*     */   public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/*     */     OidcBackChannelLogoutAuthentication token;
/*  80 */     if (authentication instanceof OidcBackChannelLogoutAuthentication) { token = (OidcBackChannelLogoutAuthentication)authentication; }
/*  81 */     else { if (this.logger.isDebugEnabled()) {
/*  82 */         String message = "Did not perform OIDC Back-Channel Logout since authentication [%s] was of the wrong type";
/*  83 */         this.logger.debug(String.format(message, new Object[] { authentication.getClass().getSimpleName() }));
/*     */       } 
/*     */       return; }
/*     */     
/*  87 */     Iterable<OidcSessionInformation> sessions = this.sessionRegistry.removeSessionInformation(token.getPrincipal());
/*  88 */     Collection<String> errors = new ArrayList<>();
/*  89 */     int totalCount = 0;
/*  90 */     int invalidatedCount = 0;
/*  91 */     for (OidcSessionInformation session : sessions) {
/*  92 */       totalCount++;
/*     */       try {
/*  94 */         eachLogout(request, token, session);
/*  95 */         invalidatedCount++;
/*     */       }
/*  97 */       catch (RestClientException ex) {
/*  98 */         this.logger.debug("Failed to invalidate session", (Throwable)ex);
/*  99 */         errors.add(ex.getMessage());
/* 100 */         this.sessionRegistry.saveSessionInformation(session);
/*     */       } 
/*     */     } 
/* 103 */     if (this.logger.isTraceEnabled()) {
/* 104 */       this.logger.trace(String.format("Invalidated %d out of %d sessions", new Object[] { Integer.valueOf(invalidatedCount), Integer.valueOf(totalCount) }));
/*     */     }
/* 106 */     if (!errors.isEmpty()) {
/* 107 */       handleLogoutFailure(response, oauth2Error(errors));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void eachLogout(HttpServletRequest request, OidcBackChannelLogoutAuthentication token, OidcSessionInformation session) {
/* 113 */     HttpHeaders headers = new HttpHeaders();
/* 114 */     headers.add("Cookie", this.sessionCookieName + "=" + this.sessionCookieName);
/* 115 */     for (Map.Entry<String, String> credential : (Iterable<Map.Entry<String, String>>)session.getAuthorities().entrySet()) {
/* 116 */       headers.add(credential.getKey(), credential.getValue());
/*     */     }
/* 118 */     headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
/* 119 */     String logout = computeLogoutEndpoint(request, token);
/* 120 */     LinkedMultiValueMap linkedMultiValueMap = new LinkedMultiValueMap();
/* 121 */     linkedMultiValueMap.add("logout_token", token.getPrincipal().getTokenValue());
/* 122 */     linkedMultiValueMap.add("_spring_security_internal_logout", "true");
/* 123 */     HttpEntity<?> entity = new HttpEntity(linkedMultiValueMap, (MultiValueMap)headers);
/* 124 */     this.restOperations.postForEntity(logout, entity, Object.class, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String computeLogoutEndpoint(HttpServletRequest request, OidcBackChannelLogoutAuthentication token) {
/* 134 */     UriComponents uriComponents = UriComponentsBuilder.fromUriString(UrlUtils.buildFullRequestUrl(request)).replacePath(request.getContextPath()).replaceQuery(null).fragment(null).build();
/*     */     
/* 136 */     Map<String, String> uriVariables = new HashMap<>();
/* 137 */     String scheme = uriComponents.getScheme();
/* 138 */     uriVariables.put("baseScheme", (scheme != null) ? scheme : "");
/* 139 */     uriVariables.put("baseUrl", uriComponents.toUriString());
/*     */     
/* 141 */     String host = uriComponents.getHost();
/* 142 */     uriVariables.put("baseHost", (host != null) ? host : "");
/*     */     
/* 144 */     String path = uriComponents.getPath();
/* 145 */     uriVariables.put("basePath", (path != null) ? path : "");
/*     */     
/* 147 */     int port = uriComponents.getPort();
/* 148 */     uriVariables.put("basePort", (port == -1) ? "" : (":" + port));
/*     */     
/* 150 */     String registrationId = token.getClientRegistration().getRegistrationId();
/* 151 */     uriVariables.put("registrationId", registrationId);
/*     */     
/* 153 */     return UriComponentsBuilder.fromUriString(this.logoutUri)
/* 154 */       .buildAndExpand(uriVariables)
/* 155 */       .toUriString();
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2Error oauth2Error(Collection<String> errors) {
/* 160 */     return new OAuth2Error("partial_logout", "not all sessions were terminated: " + String.valueOf(errors), "https://openid.net/specs/openid-connect-backchannel-1_0.html#Validation");
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleLogoutFailure(HttpServletResponse response, OAuth2Error error) {
/* 165 */     response.setStatus(400);
/*     */     try {
/* 167 */       this.errorHttpMessageConverter.write(error, null, (HttpOutputMessage)new ServletServerHttpResponse(response));
/*     */     }
/* 169 */     catch (IOException ex) {
/* 170 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogoutUri(String logoutUri) {
/* 181 */     Assert.hasText(logoutUri, "logoutUri cannot be empty");
/* 182 */     this.logoutUri = logoutUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionCookieName(String sessionCookieName) {
/* 193 */     Assert.hasText(sessionCookieName, "clientSessionCookieName cannot be empty");
/* 194 */     this.sessionCookieName = sessionCookieName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcBackChannelLogoutHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */