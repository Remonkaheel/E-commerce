/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import jakarta.servlet.ServletContext;
/*    */ import jakarta.servlet.ServletRegistration;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ServletRegistrationsSupport
/*    */ {
/*    */   private final Collection<RegistrationMapping> registrations;
/*    */   
/*    */   ServletRegistrationsSupport(ServletContext servletContext) {
/* 33 */     Map<String, ? extends ServletRegistration> registrations = servletContext.getServletRegistrations();
/* 34 */     Collection<RegistrationMapping> mappings = new ArrayList<>();
/* 35 */     for (Map.Entry<String, ? extends ServletRegistration> entry : registrations.entrySet()) {
/* 36 */       if (!((ServletRegistration)entry.getValue()).getMappings().isEmpty()) {
/* 37 */         for (String mapping : ((ServletRegistration)entry.getValue()).getMappings()) {
/* 38 */           mappings.add(new RegistrationMapping(entry.getValue(), mapping));
/*    */         }
/*    */       }
/*    */     } 
/* 42 */     this.registrations = mappings;
/*    */   }
/*    */   
/*    */   Collection<RegistrationMapping> dispatcherServletMappings() {
/* 46 */     Collection<RegistrationMapping> mappings = new ArrayList<>();
/* 47 */     for (RegistrationMapping registration : this.registrations) {
/* 48 */       if (registration.isDispatcherServlet()) {
/* 49 */         mappings.add(registration);
/*    */       }
/*    */     } 
/* 52 */     return mappings;
/*    */   }
/*    */   
/*    */   Collection<RegistrationMapping> mappings() {
/* 56 */     return this.registrations;
/*    */   }
/*    */   static final class RegistrationMapping extends Record { private final ServletRegistration registration; private final String mapping;
/* 59 */     RegistrationMapping(ServletRegistration registration, String mapping) { this.registration = registration; this.mapping = mapping; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #59	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 59 */       //   0	7	0	this	Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping; } public ServletRegistration registration() { return this.registration; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #59	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #59	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lorg/springframework/security/config/annotation/web/ServletRegistrationsSupport$RegistrationMapping;
/* 59 */       //   0	8	1	o	Ljava/lang/Object; } public String mapping() { return this.mapping; }
/*    */     
/*    */     boolean isDispatcherServlet() {
/* 62 */       Class<?> dispatcherServlet = ClassUtils.resolveClassName("org.springframework.web.servlet.DispatcherServlet", null);
/*    */       try {
/* 64 */         Class<?> clazz = Class.forName(this.registration.getClassName());
/* 65 */         return dispatcherServlet.isAssignableFrom(clazz);
/*    */       }
/* 67 */       catch (ClassNotFoundException ex) {
/* 68 */         return false;
/*    */       } 
/*    */     }
/*    */     
/*    */     boolean isDefault() {
/* 73 */       return "/".equals(this.mapping);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\ServletRegistrationsSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */