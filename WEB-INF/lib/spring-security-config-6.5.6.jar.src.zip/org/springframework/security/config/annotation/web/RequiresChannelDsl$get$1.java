/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.ChannelSecurityConfigurer;
/*     */ import org.springframework.security.web.access.channel.ChannelProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "channelSecurity", "Lorg/springframework/security/config/annotation/web/configurers/ChannelSecurityConfigurer$ChannelRequestMatcherRegistry;", "Lorg/springframework/security/config/annotation/web/configurers/ChannelSecurityConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nRequiresChannelDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RequiresChannelDsl.kt\norg/springframework/security/config/annotation/web/RequiresChannelDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,142:1\n1#2:143\n1863#3,2:144\n*S KotlinDebug\n*F\n+ 1 RequiresChannelDsl.kt\norg/springframework/security/config/annotation/web/RequiresChannelDsl$get$1\n*L\n121#1:144,2\n*E\n"})
/*     */ final class RequiresChannelDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<ChannelSecurityConfigurer<HttpSecurity>.ChannelRequestMatcherRegistry, Unit>
/*     */ {
/*     */   public final void invoke(ChannelSecurityConfigurer.ChannelRequestMatcherRegistry channelSecurity) {
/* 120 */     Intrinsics.checkNotNullParameter(channelSecurity, "channelSecurity"); if (RequiresChannelDsl.this.getChannelProcessors() != null) { List<ChannelProcessor> list1 = RequiresChannelDsl.this.getChannelProcessors(); RequiresChannelDsl requiresChannelDsl1 = RequiresChannelDsl.this; List<ChannelProcessor> it = list1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       int $i$a$-also-RequiresChannelDsl$get$1$1 = 0; channelSecurity.channelProcessors(requiresChannelDsl1.getChannelProcessors()); } else { RequiresChannelDsl.this.getChannelProcessors(); }
/* 144 */      List list = RequiresChannelDsl.access$getChannelSecurityRules$p(RequiresChannelDsl.this); RequiresChannelDsl requiresChannelDsl = RequiresChannelDsl.this; int $i$f$forEach = 0; Iterator iterator = list.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); AbstractRequestMatcherDsl.AuthorizationRule rule = (AbstractRequestMatcherDsl.AuthorizationRule)element$iv; int $i$a$-forEach-RequiresChannelDsl$get$1$2 = 0;
/*     */       AbstractRequestMatcherDsl.AuthorizationRule authorizationRule1 = rule; }
/*     */   
/*     */   }
/*     */   
/*     */   RequiresChannelDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RequiresChannelDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */