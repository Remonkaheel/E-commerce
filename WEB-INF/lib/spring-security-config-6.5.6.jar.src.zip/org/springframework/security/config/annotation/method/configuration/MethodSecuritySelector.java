/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MethodSecuritySelector
/*    */   implements ImportSelector
/*    */ {
/* 42 */   private static final boolean isDataPresent = ClassUtils.isPresent("org.springframework.security.data.aot.hint.AuthorizeReturnObjectDataHintsRegistrar", null);
/*    */ 
/*    */   
/* 45 */   private static final boolean isWebPresent = ClassUtils.isPresent("org.springframework.web.servlet.DispatcherServlet", null);
/*    */ 
/*    */   
/* 48 */   private static final boolean isObservabilityPresent = ClassUtils.isPresent("io.micrometer.observation.ObservationRegistry", null);
/*    */   
/* 50 */   private final ImportSelector autoProxy = (ImportSelector)new AutoProxyRegistrarSelector();
/*    */ 
/*    */   
/*    */   public String[] selectImports(@NonNull AnnotationMetadata importMetadata) {
/* 54 */     if (!importMetadata.hasAnnotation(EnableMethodSecurity.class.getName()) && 
/* 55 */       !importMetadata.hasMetaAnnotation(EnableMethodSecurity.class.getName())) {
/* 56 */       return new String[0];
/*    */     }
/* 58 */     EnableMethodSecurity annotation = (EnableMethodSecurity)importMetadata.getAnnotations().get(EnableMethodSecurity.class).synthesize();
/* 59 */     List<String> imports = new ArrayList<>(Arrays.asList(this.autoProxy.selectImports(importMetadata)));
/* 60 */     if (annotation.prePostEnabled()) {
/* 61 */       imports.add(PrePostMethodSecurityConfiguration.class.getName());
/*    */     }
/* 63 */     if (annotation.securedEnabled()) {
/* 64 */       imports.add(SecuredMethodSecurityConfiguration.class.getName());
/*    */     }
/* 66 */     if (annotation.jsr250Enabled()) {
/* 67 */       imports.add(Jsr250MethodSecurityConfiguration.class.getName());
/*    */     }
/* 69 */     imports.add(AuthorizationProxyConfiguration.class.getName());
/* 70 */     if (isDataPresent) {
/* 71 */       imports.add(AuthorizationProxyDataConfiguration.class.getName());
/*    */     }
/* 73 */     if (isWebPresent) {
/* 74 */       imports.add(AuthorizationProxyWebConfiguration.class.getName());
/*    */     }
/* 76 */     if (isObservabilityPresent) {
/* 77 */       imports.add(MethodObservationConfiguration.class.getName());
/*    */     }
/* 79 */     return imports.<String>toArray(new String[0]);
/*    */   }
/*    */   
/*    */   private static final class AutoProxyRegistrarSelector
/*    */     extends AdviceModeImportSelector<EnableMethodSecurity> {
/* 84 */     private static final String[] IMPORTS = new String[] { AutoProxyRegistrar.class.getName(), MethodSecurityAdvisorRegistrar.class
/* 85 */         .getName() };
/*    */     
/* 87 */     private static final String[] ASPECTJ_IMPORTS = new String[] { MethodSecurityAspectJAutoProxyRegistrar.class
/* 88 */         .getName() };
/*    */ 
/*    */     
/*    */     protected String[] selectImports(@NonNull AdviceMode adviceMode) {
/* 92 */       if (adviceMode == AdviceMode.PROXY) {
/* 93 */         return IMPORTS;
/*    */       }
/* 95 */       if (adviceMode == AdviceMode.ASPECTJ) {
/* 96 */         return ASPECTJ_IMPORTS;
/*    */       }
/* 98 */       throw new IllegalStateException("AdviceMode '" + String.valueOf(adviceMode) + "' is not supported");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\MethodSecuritySelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */