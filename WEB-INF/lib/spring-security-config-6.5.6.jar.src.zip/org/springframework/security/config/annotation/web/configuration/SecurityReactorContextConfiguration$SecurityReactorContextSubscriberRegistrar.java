/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.publisher.Hooks;
/*     */ import reactor.core.publisher.Operators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SecurityReactorContextSubscriberRegistrar
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   private static final String SECURITY_REACTOR_CONTEXT_OPERATOR_KEY = "org.springframework.security.SECURITY_REACTOR_CONTEXT_OPERATOR";
/*  87 */   private final Map<Object, Supplier<Object>> CONTEXT_ATTRIBUTE_VALUE_LOADERS = new HashMap<>();
/*     */ 
/*     */   
/*  90 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   SecurityReactorContextSubscriberRegistrar() {
/*  93 */     this.CONTEXT_ATTRIBUTE_VALUE_LOADERS.put(HttpServletRequest.class, SecurityReactorContextSubscriberRegistrar::getRequest);
/*     */     
/*  95 */     this.CONTEXT_ATTRIBUTE_VALUE_LOADERS.put(HttpServletResponse.class, SecurityReactorContextSubscriberRegistrar::getResponse);
/*     */     
/*  97 */     this.CONTEXT_ATTRIBUTE_VALUE_LOADERS.put(Authentication.class, this::getAuthentication);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 103 */     Function<? super Publisher<Object>, ? extends Publisher<Object>> lifter = Operators.liftPublisher((pub, sub) -> createSubscriberIfNecessary(sub));
/* 104 */     Objects.requireNonNull(lifter); Hooks.onLastOperator("org.springframework.security.SECURITY_REACTOR_CONTEXT_OPERATOR", lifter::apply);
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/* 109 */     Hooks.resetOnLastOperator("org.springframework.security.SECURITY_REACTOR_CONTEXT_OPERATOR");
/*     */   }
/*     */   
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 113 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 114 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   <T> CoreSubscriber<T> createSubscriberIfNecessary(CoreSubscriber<T> delegate) {
/* 118 */     if (delegate.currentContext().hasKey("org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES"))
/*     */     {
/* 120 */       return delegate;
/*     */     }
/* 122 */     return new SecurityReactorContextConfiguration.SecurityReactorContextSubscriber<>(delegate, getContextAttributes());
/*     */   }
/*     */   
/*     */   private Map<Object, Object> getContextAttributes() {
/* 126 */     return new SecurityReactorContextConfiguration.LoadingMap<>(this.CONTEXT_ATTRIBUTE_VALUE_LOADERS);
/*     */   }
/*     */   
/*     */   private static HttpServletRequest getRequest() {
/* 130 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 131 */     if (requestAttributes instanceof ServletRequestAttributes) {
/* 132 */       ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
/* 133 */       return servletRequestAttributes.getRequest();
/*     */     } 
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   private static HttpServletResponse getResponse() {
/* 139 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 140 */     if (requestAttributes instanceof ServletRequestAttributes) {
/* 141 */       ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
/* 142 */       return servletRequestAttributes.getResponse();
/*     */     } 
/* 144 */     return null;
/*     */   }
/*     */   
/*     */   private Authentication getAuthentication() {
/* 148 */     return this.securityContextHolderStrategy.getContext().getAuthentication();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\SecurityReactorContextConfiguration$SecurityReactorContextSubscriberRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */