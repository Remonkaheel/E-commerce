/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import java.util.Map;
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Deprecated(message = "as of 5.8 with no replacement")
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000B\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\007\n\002\020\t\n\002\b\006\n\002\020$\n\002\020\016\n\002\b\r\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020!\032\0020\"J#\020#\032\030\022\016\022\f0%R\b\022\004\022\0020'0&\022\004\022\0020\"0$H\000¢\006\002\b(R\016\020\003\032\0020\004X\016¢\006\002\n\000R\036\020\005\032\004\030\0010\004X\016¢\006\020\n\002\020\n\032\004\b\006\020\007\"\004\b\b\020\tR\036\020\013\032\004\030\0010\fX\016¢\006\020\n\002\020\021\032\004\b\r\020\016\"\004\b\017\020\020R(\020\022\032\020\022\004\022\0020\024\022\004\022\0020\024\030\0010\023X\016¢\006\016\n\000\032\004\b\025\020\026\"\004\b\027\020\030R\036\020\031\032\004\030\0010\004X\016¢\006\020\n\002\020\n\032\004\b\032\020\007\"\004\b\033\020\tR\034\020\034\032\004\030\0010\024X\016¢\006\016\n\000\032\004\b\035\020\036\"\004\b\037\020 ¨\006)"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/HttpPublicKeyPinningDsl;", "", "()V", "disabled", "", "includeSubDomains", "getIncludeSubDomains", "()Ljava/lang/Boolean;", "setIncludeSubDomains", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "maxAgeInSeconds", "", "getMaxAgeInSeconds", "()Ljava/lang/Long;", "setMaxAgeInSeconds", "(Ljava/lang/Long;)V", "Ljava/lang/Long;", "pins", "", "", "getPins", "()Ljava/util/Map;", "setPins", "(Ljava/util/Map;)V", "reportOnly", "getReportOnly", "setReportOnly", "reportUri", "getReportUri", "()Ljava/lang/String;", "setReportUri", "(Ljava/lang/String;)V", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HpkpConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class HttpPublicKeyPinningDsl
/*    */ {
/*    */   @Nullable
/*    */   private Map<String, String> pins;
/*    */   @Nullable
/*    */   private Long maxAgeInSeconds;
/*    */   @Nullable
/*    */   private Boolean includeSubDomains;
/*    */   @Nullable
/*    */   private Boolean reportOnly;
/*    */   @Nullable
/*    */   private String reportUri;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final Map<String, String> getPins() {
/* 41 */     return this.pins; } public final void setPins(@Nullable Map<String, String> <set-?>) { this.pins = <set-?>; } @Nullable
/* 42 */   public final Long getMaxAgeInSeconds() { return this.maxAgeInSeconds; } public final void setMaxAgeInSeconds(@Nullable Long <set-?>) { this.maxAgeInSeconds = <set-?>; } @Nullable
/* 43 */   public final Boolean getIncludeSubDomains() { return this.includeSubDomains; } public final void setIncludeSubDomains(@Nullable Boolean <set-?>) { this.includeSubDomains = <set-?>; } @Nullable
/* 44 */   public final Boolean getReportOnly() { return this.reportOnly; } public final void setReportOnly(@Nullable Boolean <set-?>) { this.reportOnly = <set-?>; } @Nullable
/* 45 */   public final String getReportUri() { return this.reportUri; } public final void setReportUri(@Nullable String <set-?>) { this.reportUri = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 53 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 57 */   public final Function1<HeadersConfigurer<HttpSecurity>.HpkpConfig, Unit> get$spring_security_config() { return new HttpPublicKeyPinningDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "hpkp", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HpkpConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 58 */   static final class HttpPublicKeyPinningDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.HpkpConfig, Unit> { public final void invoke(HeadersConfigurer.HpkpConfig hpkp) { Intrinsics.checkNotNullParameter(hpkp, "hpkp"); Map<String, String> map1 = HttpPublicKeyPinningDsl.this.getPins(); HttpPublicKeyPinningDsl httpPublicKeyPinningDsl = HttpPublicKeyPinningDsl.this; Map<String, String> map2 = map1; int $i$a$-also-HttpPublicKeyPinningDsl$get$1$1 = 0;
/* 59 */       hpkp.withPins(httpPublicKeyPinningDsl.getPins());
/*    */       HttpPublicKeyPinningDsl.this.getPins();
/* 61 */       Long long_ = HttpPublicKeyPinningDsl.this.getMaxAgeInSeconds(); httpPublicKeyPinningDsl = HttpPublicKeyPinningDsl.this; long l = long_.longValue(); int $i$a$-also-HttpPublicKeyPinningDsl$get$1$2 = 0;
/* 62 */       Intrinsics.checkNotNull(httpPublicKeyPinningDsl.getMaxAgeInSeconds()); hpkp.maxAgeInSeconds(httpPublicKeyPinningDsl.getMaxAgeInSeconds().longValue());
/*    */       HttpPublicKeyPinningDsl.this.getMaxAgeInSeconds();
/* 64 */       Boolean bool = HttpPublicKeyPinningDsl.this.getIncludeSubDomains(); httpPublicKeyPinningDsl = HttpPublicKeyPinningDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-HttpPublicKeyPinningDsl$get$1$3 = 0;
/* 65 */       Intrinsics.checkNotNull(httpPublicKeyPinningDsl.getIncludeSubDomains()); hpkp.includeSubDomains(httpPublicKeyPinningDsl.getIncludeSubDomains().booleanValue());
/*    */       HttpPublicKeyPinningDsl.this.getIncludeSubDomains();
/* 67 */       bool = HttpPublicKeyPinningDsl.this.getReportOnly(); httpPublicKeyPinningDsl = HttpPublicKeyPinningDsl.this; bool1 = bool.booleanValue(); int $i$a$-also-HttpPublicKeyPinningDsl$get$1$4 = 0;
/* 68 */       Intrinsics.checkNotNull(httpPublicKeyPinningDsl.getReportOnly()); hpkp.reportOnly(httpPublicKeyPinningDsl.getReportOnly().booleanValue());
/*    */       HttpPublicKeyPinningDsl.this.getReportOnly();
/* 70 */       String str1 = HttpPublicKeyPinningDsl.this.getReportUri(); httpPublicKeyPinningDsl = HttpPublicKeyPinningDsl.this; String it = str1; int $i$a$-also-HttpPublicKeyPinningDsl$get$1$5 = 0;
/* 71 */       hpkp.reportUri(httpPublicKeyPinningDsl.getReportUri());
/*    */       HttpPublicKeyPinningDsl.this.getReportUri();
/* 73 */       if (HttpPublicKeyPinningDsl.this.disabled)
/* 74 */         hpkp.disable();  }
/*    */ 
/*    */     
/*    */     HttpPublicKeyPinningDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\HttpPublicKeyPinningDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */