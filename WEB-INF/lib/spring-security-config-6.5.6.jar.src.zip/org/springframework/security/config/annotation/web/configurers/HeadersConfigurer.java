/*      */ package org.springframework.security.config.annotation.web.configurers;
/*      */ 
/*      */ import jakarta.servlet.Filter;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.springframework.security.config.Customizer;
/*      */ import org.springframework.security.config.annotation.SecurityBuilder;
/*      */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*      */ import org.springframework.security.web.header.HeaderWriter;
/*      */ import org.springframework.security.web.header.HeaderWriterFilter;
/*      */ import org.springframework.security.web.header.writers.CacheControlHeadersWriter;
/*      */ import org.springframework.security.web.header.writers.ContentSecurityPolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.CrossOriginEmbedderPolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.CrossOriginOpenerPolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.CrossOriginResourcePolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.FeaturePolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.HpkpHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.HstsHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.PermissionsPolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.XContentTypeOptionsHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
/*      */ import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
/*      */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*      */ import org.springframework.util.Assert;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HeadersConfigurer<H extends HttpSecurityBuilder<H>>
/*      */   extends AbstractHttpConfigurer<HeadersConfigurer<H>, H>
/*      */ {
/*   83 */   private List<HeaderWriter> headerWriters = new ArrayList<>();
/*      */   
/*   85 */   private final ContentTypeOptionsConfig contentTypeOptions = new ContentTypeOptionsConfig();
/*      */   
/*   87 */   private final XXssConfig xssProtection = new XXssConfig();
/*      */   
/*   89 */   private final CacheControlConfig cacheControl = new CacheControlConfig();
/*      */   
/*   91 */   private final HstsConfig hsts = new HstsConfig();
/*      */   
/*   93 */   private final FrameOptionsConfig frameOptions = new FrameOptionsConfig();
/*      */   
/*   95 */   private final HpkpConfig hpkp = new HpkpConfig();
/*      */   
/*   97 */   private final ContentSecurityPolicyConfig contentSecurityPolicy = new ContentSecurityPolicyConfig();
/*      */   
/*   99 */   private final ReferrerPolicyConfig referrerPolicy = new ReferrerPolicyConfig();
/*      */   
/*  101 */   private final FeaturePolicyConfig featurePolicy = new FeaturePolicyConfig();
/*      */   
/*  103 */   private final PermissionsPolicyConfig permissionsPolicy = new PermissionsPolicyConfig();
/*      */   
/*  105 */   private final CrossOriginOpenerPolicyConfig crossOriginOpenerPolicy = new CrossOriginOpenerPolicyConfig();
/*      */   
/*  107 */   private final CrossOriginEmbedderPolicyConfig crossOriginEmbedderPolicy = new CrossOriginEmbedderPolicyConfig();
/*      */   
/*  109 */   private final CrossOriginResourcePolicyConfig crossOriginResourcePolicy = new CrossOriginResourcePolicyConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> addHeaderWriter(HeaderWriter headerWriter) {
/*  125 */     Assert.notNull(headerWriter, "headerWriter cannot be null");
/*  126 */     this.headerWriters.add(headerWriter);
/*  127 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public ContentTypeOptionsConfig contentTypeOptions() {
/*  147 */     return this.contentTypeOptions.enable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> contentTypeOptions(Customizer<ContentTypeOptionsConfig> contentTypeOptionsCustomizer) {
/*  163 */     contentTypeOptionsCustomizer.customize(this.contentTypeOptions.enable());
/*  164 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public XXssConfig xssProtection() {
/*  184 */     return this.xssProtection.enable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> xssProtection(Customizer<XXssConfig> xssCustomizer) {
/*  200 */     xssCustomizer.customize(this.xssProtection.enable());
/*  201 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public CacheControlConfig cacheControl() {
/*  221 */     return this.cacheControl.enable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> cacheControl(Customizer<CacheControlConfig> cacheControlCustomizer) {
/*  237 */     cacheControlCustomizer.customize(this.cacheControl.enable());
/*  238 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public HstsConfig httpStrictTransportSecurity() {
/*  251 */     return this.hsts.enable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> httpStrictTransportSecurity(Customizer<HstsConfig> hstsCustomizer) {
/*  263 */     hstsCustomizer.customize(this.hsts.enable());
/*  264 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public FrameOptionsConfig frameOptions() {
/*  278 */     return this.frameOptions.enable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> frameOptions(Customizer<FrameOptionsConfig> frameOptionsCustomizer) {
/*  288 */     frameOptionsCustomizer.customize(this.frameOptions.enable());
/*  289 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public HpkpConfig httpPublicKeyPinning() {
/*  304 */     return this.hpkp.enable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public HeadersConfigurer<H> httpPublicKeyPinning(Customizer<HpkpConfig> hpkpCustomizer) {
/*  319 */     hpkpCustomizer.customize(this.hpkp.enable());
/*  320 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public ContentSecurityPolicyConfig contentSecurityPolicy(String policyDirectives) {
/*  352 */     this.contentSecurityPolicy.writer = new ContentSecurityPolicyHeaderWriter(policyDirectives);
/*  353 */     return this.contentSecurityPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> contentSecurityPolicy(Customizer<ContentSecurityPolicyConfig> contentSecurityCustomizer) {
/*  383 */     this.contentSecurityPolicy.writer = new ContentSecurityPolicyHeaderWriter();
/*  384 */     contentSecurityCustomizer.customize(this.contentSecurityPolicy);
/*  385 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> defaultsDisabled() {
/*  399 */     this.contentTypeOptions.disable();
/*  400 */     this.xssProtection.disable();
/*  401 */     this.cacheControl.disable();
/*  402 */     this.hsts.disable();
/*  403 */     this.frameOptions.disable();
/*  404 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void configure(H http) {
/*  409 */     HeaderWriterFilter headersFilter = createHeaderWriterFilter();
/*  410 */     http.addFilter((Filter)headersFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HeaderWriterFilter createHeaderWriterFilter() {
/*  418 */     List<HeaderWriter> writers = getHeaderWriters();
/*  419 */     if (writers.isEmpty()) {
/*  420 */       throw new IllegalStateException("Headers security is enabled, but no headers will be added. Either add headers or disable headers security");
/*      */     }
/*      */     
/*  423 */     HeaderWriterFilter headersFilter = new HeaderWriterFilter(writers);
/*  424 */     headersFilter = (HeaderWriterFilter)postProcess(headersFilter);
/*  425 */     return headersFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<HeaderWriter> getHeaderWriters() {
/*  433 */     List<HeaderWriter> writers = new ArrayList<>();
/*  434 */     addIfNotNull(writers, this.contentTypeOptions.writer);
/*  435 */     addIfNotNull(writers, this.xssProtection.writer);
/*  436 */     addIfNotNull(writers, this.cacheControl.writer);
/*  437 */     addIfNotNull(writers, this.hsts.writer);
/*  438 */     addIfNotNull(writers, this.frameOptions.writer);
/*  439 */     addIfNotNull(writers, this.hpkp.writer);
/*  440 */     addIfNotNull(writers, this.contentSecurityPolicy.writer);
/*  441 */     addIfNotNull(writers, this.referrerPolicy.writer);
/*  442 */     addIfNotNull(writers, this.featurePolicy.writer);
/*  443 */     addIfNotNull(writers, this.permissionsPolicy.writer);
/*  444 */     addIfNotNull(writers, this.crossOriginOpenerPolicy.writer);
/*  445 */     addIfNotNull(writers, this.crossOriginEmbedderPolicy.writer);
/*  446 */     addIfNotNull(writers, this.crossOriginResourcePolicy.writer);
/*  447 */     writers.addAll(this.headerWriters);
/*  448 */     return writers;
/*      */   }
/*      */   
/*      */   private <T> void addIfNotNull(List<T> values, T value) {
/*  452 */     if (value != null) {
/*  453 */       values.add(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public ReferrerPolicyConfig referrerPolicy() {
/*  489 */     this.referrerPolicy.writer = new ReferrerPolicyHeaderWriter();
/*  490 */     return this.referrerPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public ReferrerPolicyConfig referrerPolicy(ReferrerPolicyHeaderWriter.ReferrerPolicy policy) {
/*  518 */     this.referrerPolicy.writer = new ReferrerPolicyHeaderWriter(policy);
/*  519 */     return this.referrerPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> referrerPolicy(Customizer<ReferrerPolicyConfig> referrerPolicyCustomizer) {
/*  541 */     this.referrerPolicy.writer = new ReferrerPolicyHeaderWriter();
/*  542 */     referrerPolicyCustomizer.customize(this.referrerPolicy);
/*  543 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public FeaturePolicyConfig featurePolicy(String policyDirectives) {
/*  567 */     this.featurePolicy.writer = new FeaturePolicyHeaderWriter(policyDirectives);
/*  568 */     return this.featurePolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public PermissionsPolicyConfig permissionsPolicy() {
/*  596 */     this.permissionsPolicy.writer = new PermissionsPolicyHeaderWriter();
/*  597 */     return this.permissionsPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.4", forRemoval = true)
/*      */   public PermissionsPolicyConfig permissionsPolicy(Customizer<PermissionsPolicyConfig> permissionsPolicyCustomizer) {
/*  619 */     this.permissionsPolicy.writer = new PermissionsPolicyHeaderWriter();
/*  620 */     permissionsPolicyCustomizer.customize(this.permissionsPolicy);
/*  621 */     return this.permissionsPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> permissionsPolicyHeader(Customizer<PermissionsPolicyConfig> permissionsPolicyCustomizer) {
/*  641 */     this.permissionsPolicy.writer = new PermissionsPolicyHeaderWriter();
/*  642 */     permissionsPolicyCustomizer.customize(this.permissionsPolicy);
/*  643 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public CrossOriginOpenerPolicyConfig crossOriginOpenerPolicy() {
/*  662 */     this.crossOriginOpenerPolicy.writer = new CrossOriginOpenerPolicyHeaderWriter();
/*  663 */     return this.crossOriginOpenerPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> crossOriginOpenerPolicy(Customizer<CrossOriginOpenerPolicyConfig> crossOriginOpenerPolicyCustomizer) {
/*  685 */     this.crossOriginOpenerPolicy.writer = new CrossOriginOpenerPolicyHeaderWriter();
/*  686 */     crossOriginOpenerPolicyCustomizer.customize(this.crossOriginOpenerPolicy);
/*  687 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public CrossOriginEmbedderPolicyConfig crossOriginEmbedderPolicy() {
/*  706 */     this.crossOriginEmbedderPolicy.writer = new CrossOriginEmbedderPolicyHeaderWriter();
/*  707 */     return this.crossOriginEmbedderPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> crossOriginEmbedderPolicy(Customizer<CrossOriginEmbedderPolicyConfig> crossOriginEmbedderPolicyCustomizer) {
/*  729 */     this.crossOriginEmbedderPolicy.writer = new CrossOriginEmbedderPolicyHeaderWriter();
/*  730 */     crossOriginEmbedderPolicyCustomizer.customize(this.crossOriginEmbedderPolicy);
/*  731 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.1", forRemoval = true)
/*      */   public CrossOriginResourcePolicyConfig crossOriginResourcePolicy() {
/*  750 */     this.crossOriginResourcePolicy.writer = new CrossOriginResourcePolicyHeaderWriter();
/*  751 */     return this.crossOriginResourcePolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeadersConfigurer<H> crossOriginResourcePolicy(Customizer<CrossOriginResourcePolicyConfig> crossOriginResourcePolicyCustomizer) {
/*  773 */     this.crossOriginResourcePolicy.writer = new CrossOriginResourcePolicyHeaderWriter();
/*  774 */     crossOriginResourcePolicyCustomizer.customize(this.crossOriginResourcePolicy);
/*  775 */     return this;
/*      */   }
/*      */   
/*      */   public final class ContentTypeOptionsConfig
/*      */   {
/*      */     private XContentTypeOptionsHeaderWriter writer;
/*      */     
/*      */     private ContentTypeOptionsConfig() {
/*  783 */       enable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> disable() {
/*  791 */       this.writer = null;
/*  792 */       return and();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/*  803 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ContentTypeOptionsConfig enable() {
/*  811 */       if (this.writer == null) {
/*  812 */         this.writer = new XContentTypeOptionsHeaderWriter();
/*      */       }
/*  814 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final class XXssConfig
/*      */   {
/*      */     private XXssProtectionHeaderWriter writer;
/*      */     
/*      */     private XXssConfig() {
/*  824 */       enable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public XXssConfig headerValue(XXssProtectionHeaderWriter.HeaderValue headerValue) {
/*  857 */       this.writer.setHeaderValue(headerValue);
/*  858 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> disable() {
/*  866 */       this.writer = null;
/*  867 */       return and();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/*  882 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private XXssConfig enable() {
/*  890 */       if (this.writer == null) {
/*  891 */         this.writer = new XXssProtectionHeaderWriter();
/*      */       }
/*  893 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final class CacheControlConfig
/*      */   {
/*      */     private CacheControlHeadersWriter writer;
/*      */     
/*      */     private CacheControlConfig() {
/*  903 */       enable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> disable() {
/*  911 */       this.writer = null;
/*  912 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/*  927 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private CacheControlConfig enable() {
/*  935 */       if (this.writer == null) {
/*  936 */         this.writer = new CacheControlHeadersWriter();
/*      */       }
/*  938 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final class HstsConfig
/*      */   {
/*      */     private HstsHeaderWriter writer;
/*      */     
/*      */     private HstsConfig() {
/*  948 */       enable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HstsConfig maxAgeInSeconds(long maxAgeInSeconds) {
/*  968 */       this.writer.setMaxAgeInSeconds(maxAgeInSeconds);
/*  969 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HstsConfig requestMatcher(RequestMatcher requestMatcher) {
/*  981 */       this.writer.setRequestMatcher(requestMatcher);
/*  982 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HstsConfig includeSubDomains(boolean includeSubDomains) {
/*  997 */       this.writer.setIncludeSubDomains(includeSubDomains);
/*  998 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HstsConfig preload(boolean preload) {
/* 1014 */       this.writer.setPreload(preload);
/* 1015 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> disable() {
/* 1023 */       this.writer = null;
/* 1024 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1036 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private HstsConfig enable() {
/* 1044 */       if (this.writer == null) {
/* 1045 */         this.writer = new HstsHeaderWriter();
/*      */       }
/* 1047 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final class FrameOptionsConfig
/*      */   {
/*      */     private XFrameOptionsHeaderWriter writer;
/*      */     
/*      */     private FrameOptionsConfig() {
/* 1057 */       enable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> deny() {
/* 1065 */       this.writer = new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.DENY);
/* 1066 */       return and();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> sameOrigin() {
/* 1079 */       this.writer = new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN);
/* 1080 */       return and();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> disable() {
/* 1088 */       this.writer = null;
/* 1089 */       return and();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1103 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private FrameOptionsConfig enable() {
/* 1111 */       if (this.writer == null) {
/* 1112 */         this.writer = new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.DENY);
/*      */       }
/* 1114 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final class HpkpConfig
/*      */   {
/*      */     private HpkpHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig withPins(Map<String, String> pins) {
/* 1148 */       this.writer.setPins(pins);
/* 1149 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig addSha256Pins(String... pins) {
/* 1168 */       this.writer.addSha256Pins(pins);
/* 1169 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig maxAgeInSeconds(long maxAgeInSeconds) {
/* 1189 */       this.writer.setMaxAgeInSeconds(maxAgeInSeconds);
/* 1190 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig includeSubDomains(boolean includeSubDomains) {
/* 1206 */       this.writer.setIncludeSubDomains(includeSubDomains);
/* 1207 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig reportOnly(boolean reportOnly) {
/* 1223 */       this.writer.setReportOnly(reportOnly);
/* 1224 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig reportUri(URI reportUri) {
/* 1239 */       this.writer.setReportUri(reportUri);
/* 1240 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HpkpConfig reportUri(String reportUri) {
/* 1256 */       this.writer.setReportUri(reportUri);
/* 1257 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> disable() {
/* 1265 */       this.writer = null;
/* 1266 */       return and();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> and() {
/* 1275 */       return HeadersConfigurer.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private HpkpConfig enable() {
/* 1284 */       if (this.writer == null) {
/* 1285 */         this.writer = new HpkpHeaderWriter();
/*      */       }
/* 1287 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class ContentSecurityPolicyConfig
/*      */   {
/*      */     private ContentSecurityPolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ContentSecurityPolicyConfig policyDirectives(String policyDirectives) {
/* 1306 */       this.writer.setPolicyDirectives(policyDirectives);
/* 1307 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ContentSecurityPolicyConfig reportOnly() {
/* 1316 */       this.writer.setReportOnly(true);
/* 1317 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1329 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class ReferrerPolicyConfig
/*      */   {
/*      */     private ReferrerPolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ReferrerPolicyConfig policy(ReferrerPolicyHeaderWriter.ReferrerPolicy policy) {
/* 1348 */       this.writer.setPolicy(policy);
/* 1349 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1361 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class FeaturePolicyConfig
/*      */   {
/*      */     private FeaturePolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeadersConfigurer<H> and() {
/* 1379 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class PermissionsPolicyConfig
/*      */   {
/*      */     private PermissionsPolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public PermissionsPolicyConfig policy(String policy) {
/* 1398 */       this.writer.setPolicy(policy);
/* 1399 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1411 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class CrossOriginOpenerPolicyConfig
/*      */   {
/*      */     private CrossOriginOpenerPolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CrossOriginOpenerPolicyConfig policy(CrossOriginOpenerPolicyHeaderWriter.CrossOriginOpenerPolicy openerPolicy) {
/* 1431 */       this.writer.setPolicy(openerPolicy);
/* 1432 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1444 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class CrossOriginEmbedderPolicyConfig
/*      */   {
/*      */     private CrossOriginEmbedderPolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CrossOriginEmbedderPolicyConfig policy(CrossOriginEmbedderPolicyHeaderWriter.CrossOriginEmbedderPolicy embedderPolicy) {
/* 1465 */       this.writer.setPolicy(embedderPolicy);
/* 1466 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1478 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final class CrossOriginResourcePolicyConfig
/*      */   {
/*      */     private CrossOriginResourcePolicyHeaderWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CrossOriginResourcePolicyConfig policy(CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy resourcePolicy) {
/* 1499 */       this.writer.setPolicy(resourcePolicy);
/* 1500 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated(since = "6.1", forRemoval = true)
/*      */     public HeadersConfigurer<H> and() {
/* 1512 */       return HeadersConfigurer.this;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\HeadersConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */