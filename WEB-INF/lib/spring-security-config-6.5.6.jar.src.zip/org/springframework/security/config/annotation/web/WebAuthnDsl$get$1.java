/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.Set;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.http.converter.HttpMessageConverter;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.WebAuthnConfigurer;
/*    */ import org.springframework.security.web.webauthn.registration.PublicKeyCredentialCreationOptionsRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "webAuthn", "Lorg/springframework/security/config/annotation/web/configurers/WebAuthnConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nWebAuthnDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WebAuthnDsl.kt\norg/springframework/security/config/annotation/web/WebAuthnDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,54:1\n1#2:55\n*E\n"})
/*    */ final class WebAuthnDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<WebAuthnConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(WebAuthnConfigurer webAuthn) {
/* 45 */     Intrinsics.checkNotNullParameter(webAuthn, "webAuthn"); if (WebAuthnDsl.this.getRpName() != null) { String str1 = WebAuthnDsl.this.getRpName(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       int $i$a$-also-WebAuthnDsl$get$1$1 = 0; webAuthn.rpName(webAuthnDsl.getRpName()); } else { WebAuthnDsl.this.getRpName(); }  if (WebAuthnDsl.this.getRpId() != null) { String str1 = WebAuthnDsl.this.getRpId(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; String it = str1; int $i$a$-also-WebAuthnDsl$get$1$2 = 0; webAuthn.rpId(webAuthnDsl.getRpId()); } else { WebAuthnDsl.this.getRpId(); }  if (WebAuthnDsl.this.getAllowedOrigins() != null) { Set<String> set1 = WebAuthnDsl.this.getAllowedOrigins(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; Set<String> it = set1; int $i$a$-also-WebAuthnDsl$get$1$3 = 0; webAuthn.allowedOrigins(webAuthnDsl.getAllowedOrigins()); } else { WebAuthnDsl.this.getAllowedOrigins(); }  if (WebAuthnDsl.this.getDisableDefaultRegistrationPage() != null) { Boolean bool = WebAuthnDsl.this.getDisableDefaultRegistrationPage(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-WebAuthnDsl$get$1$4 = 0; Intrinsics.checkNotNull(webAuthnDsl.getDisableDefaultRegistrationPage()); webAuthn.disableDefaultRegistrationPage(webAuthnDsl.getDisableDefaultRegistrationPage().booleanValue()); } else { WebAuthnDsl.this.getDisableDefaultRegistrationPage(); }  if (WebAuthnDsl.this.getCreationOptionsRepository() != null) { PublicKeyCredentialCreationOptionsRepository publicKeyCredentialCreationOptionsRepository1 = WebAuthnDsl.this.getCreationOptionsRepository(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; PublicKeyCredentialCreationOptionsRepository it = publicKeyCredentialCreationOptionsRepository1; int $i$a$-also-WebAuthnDsl$get$1$5 = 0; webAuthn.creationOptionsRepository(webAuthnDsl.getCreationOptionsRepository()); } else { WebAuthnDsl.this.getCreationOptionsRepository(); }  if (WebAuthnDsl.this.getMessageConverter() != null) { HttpMessageConverter<Object> httpMessageConverter1 = WebAuthnDsl.this.getMessageConverter(); WebAuthnDsl webAuthnDsl = WebAuthnDsl.this; HttpMessageConverter<Object> it = httpMessageConverter1; int $i$a$-also-WebAuthnDsl$get$1$6 = 0;
/*    */       webAuthn.messageConverter(webAuthnDsl.getMessageConverter()); }
/*    */     else
/*    */     { WebAuthnDsl.this.getMessageConverter(); }
/*    */   
/*    */   }
/*    */   
/*    */   WebAuthnDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\WebAuthnDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */