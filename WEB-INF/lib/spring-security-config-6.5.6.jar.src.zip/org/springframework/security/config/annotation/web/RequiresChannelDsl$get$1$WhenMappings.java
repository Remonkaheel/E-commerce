package org.springframework.security.config.annotation.web;

import kotlin.Metadata;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RequiresChannelDsl$get$1$WhenMappings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */