/*    */ package org.springframework.security.config.annotation.web.saml2;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*    */ import org.springframework.security.saml2.provider.service.authentication.logout.Saml2LogoutRequestValidator;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.HttpSessionLogoutRequestRepository;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestRepository;
/*    */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Saml2SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000D\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\033\032\030\022\016\022\f0\035R\b\022\004\022\0020\0370\036\022\004\022\0020 0\034H\000¢\006\002\b!R\032\020\003\032\0020\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\034\020\017\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024R\032\020\025\032\0020\026X\016¢\006\016\n\000\032\004\b\027\020\030\"\004\b\031\020\032¨\006\""}, d2 = {"Lorg/springframework/security/config/annotation/web/saml2/LogoutRequestDsl;", "", "()V", "logoutRequestRepository", "Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutRequestRepository;", "getLogoutRequestRepository", "()Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutRequestRepository;", "setLogoutRequestRepository", "(Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutRequestRepository;)V", "logoutRequestResolver", "Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutRequestResolver;", "getLogoutRequestResolver", "()Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutRequestResolver;", "setLogoutRequestResolver", "(Lorg/springframework/security/saml2/provider/service/web/authentication/logout/Saml2LogoutRequestResolver;)V", "logoutRequestValidator", "Lorg/springframework/security/saml2/provider/service/authentication/logout/Saml2LogoutRequestValidator;", "getLogoutRequestValidator", "()Lorg/springframework/security/saml2/provider/service/authentication/logout/Saml2LogoutRequestValidator;", "setLogoutRequestValidator", "(Lorg/springframework/security/saml2/provider/service/authentication/logout/Saml2LogoutRequestValidator;)V", "logoutUrl", "", "getLogoutUrl", "()Ljava/lang/String;", "setLogoutUrl", "(Ljava/lang/String;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutRequestConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class LogoutRequestDsl
/*    */ {
/*    */   @NotNull
/* 40 */   private String logoutUrl = "/logout/saml2/slo"; @Nullable private Saml2LogoutRequestValidator logoutRequestValidator; @Nullable private Saml2LogoutRequestResolver logoutRequestResolver; @NotNull public final String getLogoutUrl() { return this.logoutUrl; } public final void setLogoutUrl(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.logoutUrl = <set-?>; } @Nullable
/* 41 */   public final Saml2LogoutRequestValidator getLogoutRequestValidator() { return this.logoutRequestValidator; } public final void setLogoutRequestValidator(@Nullable Saml2LogoutRequestValidator <set-?>) { this.logoutRequestValidator = <set-?>; } @Nullable
/* 42 */   public final Saml2LogoutRequestResolver getLogoutRequestResolver() { return this.logoutRequestResolver; } public final void setLogoutRequestResolver(@Nullable Saml2LogoutRequestResolver <set-?>) { this.logoutRequestResolver = <set-?>; } @NotNull
/* 43 */   private Saml2LogoutRequestRepository logoutRequestRepository = (Saml2LogoutRequestRepository)new HttpSessionLogoutRequestRepository(); @NotNull public final Saml2LogoutRequestRepository getLogoutRequestRepository() { return this.logoutRequestRepository; } public final void setLogoutRequestRepository(@NotNull Saml2LogoutRequestRepository <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.logoutRequestRepository = <set-?>; }
/*    */   
/*    */   @NotNull
/* 46 */   public final Function1<Saml2LogoutConfigurer<HttpSecurity>.LogoutRequestConfigurer, Unit> get$spring_security_config() { return new LogoutRequestDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "logoutRequest", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer$LogoutRequestConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nLogoutRequestDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LogoutRequestDsl.kt\norg/springframework/security/config/annotation/web/saml2/LogoutRequestDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,54:1\n1#2:55\n*E\n"})
/* 47 */   static final class LogoutRequestDsl$get$1 extends Lambda implements Function1<Saml2LogoutConfigurer<HttpSecurity>.LogoutRequestConfigurer, Unit> { public final void invoke(Saml2LogoutConfigurer.LogoutRequestConfigurer logoutRequest) { Intrinsics.checkNotNullParameter(logoutRequest, "logoutRequest"); String str1 = LogoutRequestDsl.this.getLogoutUrl(); LogoutRequestDsl logoutRequestDsl = LogoutRequestDsl.this; String str2 = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       int $i$a$-also-LogoutRequestDsl$get$1$1 = 0; logoutRequest.logoutUrl(logoutRequestDsl.getLogoutUrl()); if (LogoutRequestDsl.this.getLogoutRequestValidator() != null) { Saml2LogoutRequestValidator saml2LogoutRequestValidator1 = LogoutRequestDsl.this.getLogoutRequestValidator(); LogoutRequestDsl logoutRequestDsl1 = LogoutRequestDsl.this; Saml2LogoutRequestValidator saml2LogoutRequestValidator2 = saml2LogoutRequestValidator1; int $i$a$-also-LogoutRequestDsl$get$1$2 = 0; logoutRequest.logoutRequestValidator(logoutRequestDsl1.getLogoutRequestValidator()); } else { LogoutRequestDsl.this.getLogoutRequestValidator(); }  if (LogoutRequestDsl.this.getLogoutRequestResolver() != null) { Saml2LogoutRequestResolver saml2LogoutRequestResolver1 = LogoutRequestDsl.this.getLogoutRequestResolver(); LogoutRequestDsl logoutRequestDsl1 = LogoutRequestDsl.this; Saml2LogoutRequestResolver saml2LogoutRequestResolver2 = saml2LogoutRequestResolver1; int $i$a$-also-LogoutRequestDsl$get$1$3 = 0; logoutRequest.logoutRequestResolver(logoutRequestDsl1.getLogoutRequestResolver()); } else { LogoutRequestDsl.this.getLogoutRequestResolver(); }  Saml2LogoutRequestRepository saml2LogoutRequestRepository1 = LogoutRequestDsl.this.getLogoutRequestRepository(); logoutRequestDsl = LogoutRequestDsl.this; Saml2LogoutRequestRepository it = saml2LogoutRequestRepository1; int $i$a$-also-LogoutRequestDsl$get$1$4 = 0;
/*    */       logoutRequest.logoutRequestRepository(logoutRequestDsl.getLogoutRequestRepository()); }
/*    */ 
/*    */     
/*    */     LogoutRequestDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\saml2\LogoutRequestDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */