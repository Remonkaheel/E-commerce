/*     */ package org.springframework.security.config.annotation.web.configurers.saml2;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.opensaml.core.Version;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml4LogoutRequestValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml4LogoutResponseValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml5LogoutRequestValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml5LogoutResponseValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.Saml2LogoutRequestValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.Saml2LogoutResponseValidator;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.HttpSessionLogoutRequestRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml4LogoutRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml4LogoutRequestValidatorParametersResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml4LogoutResponseResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml5LogoutRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml5LogoutRequestValidatorParametersResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml5LogoutResponseResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestValidatorParametersResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutResponseFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutResponseResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2RelyingPartyInitiatedLogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutFilter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessEventPublishingLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
/*     */ import org.springframework.security.web.csrf.CsrfFilter;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.ParameterRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Saml2LogoutConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<Saml2LogoutConfigurer<H>, H>
/*     */ {
/* 118 */   private static final boolean USE_OPENSAML_5 = Version.getVersion().startsWith("5");
/*     */   
/*     */   private ApplicationContext context;
/*     */   
/*     */   private RelyingPartyRegistrationRepository relyingPartyRegistrationRepository;
/*     */   
/* 124 */   private String logoutUrl = "/logout";
/*     */   
/* 126 */   private List<LogoutHandler> logoutHandlers = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private LogoutSuccessHandler logoutSuccessHandler;
/*     */ 
/*     */   
/*     */   private LogoutRequestConfigurer logoutRequestConfigurer;
/*     */ 
/*     */   
/*     */   private LogoutResponseConfigurer logoutResponseConfigurer;
/*     */ 
/*     */   
/*     */   public Saml2LogoutConfigurer(ApplicationContext context) {
/* 139 */     this.context = context;
/* 140 */     this.logoutHandlers.add(new SecurityContextLogoutHandler());
/* 141 */     this.logoutHandlers.add(new LogoutSuccessEventPublishingLogoutHandler());
/* 142 */     SimpleUrlLogoutSuccessHandler logoutSuccessHandler = new SimpleUrlLogoutSuccessHandler();
/* 143 */     logoutSuccessHandler.setDefaultTargetUrl("/login?logout");
/* 144 */     this.logoutSuccessHandler = (LogoutSuccessHandler)logoutSuccessHandler;
/* 145 */     this.logoutRequestConfigurer = new LogoutRequestConfigurer();
/* 146 */     this.logoutResponseConfigurer = new LogoutResponseConfigurer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LogoutConfigurer<H> logoutUrl(String logoutUrl) {
/* 162 */     this.logoutUrl = logoutUrl;
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LogoutConfigurer<H> relyingPartyRegistrationRepository(RelyingPartyRegistrationRepository repo) {
/* 174 */     this.relyingPartyRegistrationRepository = repo;
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public LogoutRequestConfigurer logoutRequest() {
/* 189 */     return this.logoutRequestConfigurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LogoutConfigurer<H> logoutRequest(Customizer<LogoutRequestConfigurer> logoutRequestConfigurerCustomizer) {
/* 200 */     logoutRequestConfigurerCustomizer.customize(this.logoutRequestConfigurer);
/* 201 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public LogoutResponseConfigurer logoutResponse() {
/* 215 */     return this.logoutResponseConfigurer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Saml2LogoutConfigurer<H> logoutResponse(Customizer<LogoutResponseConfigurer> logoutResponseConfigurerCustomizer) {
/* 226 */     logoutResponseConfigurerCustomizer.customize(this.logoutResponseConfigurer);
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(H http) throws Exception {
/* 235 */     LogoutConfigurer<H> logout = (LogoutConfigurer<H>)http.getConfigurer(LogoutConfigurer.class);
/* 236 */     if (logout != null) {
/* 237 */       this.logoutHandlers = logout.getLogoutHandlers();
/* 238 */       this.logoutSuccessHandler = logout.getLogoutSuccessHandler();
/*     */     } 
/* 240 */     RelyingPartyRegistrationRepository registrations = getRelyingPartyRegistrationRepository(http);
/* 241 */     http.addFilterBefore((Filter)createLogoutRequestProcessingFilter(registrations), CsrfFilter.class);
/* 242 */     http.addFilterBefore((Filter)createLogoutResponseProcessingFilter(registrations), CsrfFilter.class);
/* 243 */     http.addFilterBefore((Filter)createRelyingPartyLogoutFilter(registrations), LogoutFilter.class);
/*     */   }
/*     */   
/*     */   private RelyingPartyRegistrationRepository getRelyingPartyRegistrationRepository(H http) {
/* 247 */     if (this.relyingPartyRegistrationRepository != null) {
/* 248 */       return this.relyingPartyRegistrationRepository;
/*     */     }
/* 250 */     Saml2LoginConfigurer<H> login = (Saml2LoginConfigurer<H>)http.getConfigurer(Saml2LoginConfigurer.class);
/* 251 */     if (login != null) {
/* 252 */       this.relyingPartyRegistrationRepository = login.relyingPartyRegistrationRepository(http);
/*     */     } else {
/*     */       
/* 255 */       this.relyingPartyRegistrationRepository = getBeanOrNull(RelyingPartyRegistrationRepository.class);
/*     */     } 
/* 257 */     return this.relyingPartyRegistrationRepository;
/*     */   }
/*     */ 
/*     */   
/*     */   private Saml2LogoutRequestFilter createLogoutRequestProcessingFilter(RelyingPartyRegistrationRepository registrations) {
/* 262 */     LogoutHandler[] logoutHandlers = this.logoutHandlers.<LogoutHandler>toArray(new LogoutHandler[0]);
/* 263 */     Saml2LogoutResponseResolver logoutResponseResolver = createSaml2LogoutResponseResolver(registrations);
/*     */ 
/*     */     
/* 266 */     Saml2LogoutRequestFilter filter = new Saml2LogoutRequestFilter(createSaml2LogoutResponseParametersResolver(registrations), this.logoutRequestConfigurer.logoutRequestValidator(), logoutResponseResolver, logoutHandlers);
/* 267 */     filter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 268 */     return (Saml2LogoutRequestFilter)postProcess(filter);
/*     */   }
/*     */ 
/*     */   
/*     */   private Saml2LogoutRequestValidatorParametersResolver createSaml2LogoutResponseParametersResolver(RelyingPartyRegistrationRepository registrations) {
/* 273 */     RequestMatcher requestMatcher = createLogoutRequestMatcher();
/* 274 */     if (USE_OPENSAML_5) {
/* 275 */       OpenSaml5LogoutRequestValidatorParametersResolver openSaml5LogoutRequestValidatorParametersResolver = new OpenSaml5LogoutRequestValidatorParametersResolver(registrations);
/*     */       
/* 277 */       openSaml5LogoutRequestValidatorParametersResolver.setRequestMatcher(requestMatcher);
/* 278 */       return (Saml2LogoutRequestValidatorParametersResolver)openSaml5LogoutRequestValidatorParametersResolver;
/*     */     } 
/* 280 */     OpenSaml4LogoutRequestValidatorParametersResolver parameters = new OpenSaml4LogoutRequestValidatorParametersResolver(registrations);
/*     */     
/* 282 */     parameters.setRequestMatcher(requestMatcher);
/* 283 */     return (Saml2LogoutRequestValidatorParametersResolver)parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Saml2LogoutResponseFilter createLogoutResponseProcessingFilter(RelyingPartyRegistrationRepository registrations) {
/* 289 */     Saml2LogoutResponseFilter logoutResponseFilter = new Saml2LogoutResponseFilter(registrations, this.logoutResponseConfigurer.logoutResponseValidator(), this.logoutSuccessHandler);
/* 290 */     logoutResponseFilter.setLogoutRequestMatcher(createLogoutResponseMatcher());
/* 291 */     logoutResponseFilter.setLogoutRequestRepository(this.logoutRequestConfigurer.logoutRequestRepository);
/* 292 */     return (Saml2LogoutResponseFilter)postProcess(logoutResponseFilter);
/*     */   }
/*     */ 
/*     */   
/*     */   private Saml2RelyingPartyInitiatedLogoutFilter createRelyingPartyLogoutFilter(RelyingPartyRegistrationRepository registrations) {
/* 297 */     LogoutHandler[] logoutHandlers = this.logoutHandlers.<LogoutHandler>toArray(new LogoutHandler[0]);
/* 298 */     Saml2RelyingPartyInitiatedLogoutSuccessHandler logoutRequestSuccessHandler = createSaml2LogoutRequestSuccessHandler(registrations);
/*     */     
/* 300 */     logoutRequestSuccessHandler.setLogoutRequestRepository(this.logoutRequestConfigurer.logoutRequestRepository);
/* 301 */     Saml2RelyingPartyInitiatedLogoutFilter logoutFilter = new Saml2RelyingPartyInitiatedLogoutFilter((LogoutSuccessHandler)logoutRequestSuccessHandler, logoutHandlers);
/*     */     
/* 303 */     logoutFilter.setLogoutRequestMatcher(createLogoutMatcher());
/* 304 */     return (Saml2RelyingPartyInitiatedLogoutFilter)postProcess(logoutFilter);
/*     */   }
/*     */   
/*     */   private RequestMatcher createLogoutMatcher() {
/* 308 */     RequestMatcher logout = RequestMatcherFactory.matcher(HttpMethod.POST, this.logoutUrl);
/* 309 */     RequestMatcher saml2 = new Saml2RequestMatcher(getSecurityContextHolderStrategy());
/* 310 */     return (RequestMatcher)new AndRequestMatcher(new RequestMatcher[] { logout, saml2 });
/*     */   }
/*     */   
/*     */   private RequestMatcher createLogoutRequestMatcher() {
/* 314 */     RequestMatcher logout = RequestMatcherFactory.matcher(this.logoutRequestConfigurer.logoutUrl);
/* 315 */     ParameterRequestMatcher parameterRequestMatcher = new ParameterRequestMatcher("SAMLRequest");
/* 316 */     return (RequestMatcher)new AndRequestMatcher(new RequestMatcher[] { logout, (RequestMatcher)parameterRequestMatcher });
/*     */   }
/*     */   
/*     */   private RequestMatcher createLogoutResponseMatcher() {
/* 320 */     RequestMatcher logout = RequestMatcherFactory.matcher(this.logoutResponseConfigurer.logoutUrl);
/* 321 */     ParameterRequestMatcher parameterRequestMatcher = new ParameterRequestMatcher("SAMLResponse");
/* 322 */     return (RequestMatcher)new AndRequestMatcher(new RequestMatcher[] { logout, (RequestMatcher)parameterRequestMatcher });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Saml2RelyingPartyInitiatedLogoutSuccessHandler createSaml2LogoutRequestSuccessHandler(RelyingPartyRegistrationRepository registrations) {
/* 328 */     Saml2LogoutRequestResolver logoutRequestResolver = this.logoutRequestConfigurer.logoutRequestResolver(registrations);
/* 329 */     return new Saml2RelyingPartyInitiatedLogoutSuccessHandler(logoutRequestResolver);
/*     */   }
/*     */ 
/*     */   
/*     */   private Saml2LogoutResponseResolver createSaml2LogoutResponseResolver(RelyingPartyRegistrationRepository registrations) {
/* 334 */     return this.logoutResponseConfigurer.logoutResponseResolver(registrations);
/*     */   }
/*     */   
/*     */   private <C> C getBeanOrNull(Class<C> clazz) {
/* 338 */     if (this.context == null) {
/* 339 */       return null;
/*     */     }
/* 341 */     return (C)this.context.getBeanProvider(clazz).getIfAvailable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class LogoutRequestConfigurer
/*     */   {
/* 349 */     private String logoutUrl = "/logout/saml2/slo";
/*     */     
/*     */     private Saml2LogoutRequestValidator logoutRequestValidator;
/*     */     
/*     */     private Saml2LogoutRequestResolver logoutRequestResolver;
/*     */     
/* 355 */     private Saml2LogoutRequestRepository logoutRequestRepository = (Saml2LogoutRequestRepository)new HttpSessionLogoutRequestRepository();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutRequestConfigurer logoutUrl(String logoutUrl) {
/* 371 */       this.logoutUrl = logoutUrl;
/* 372 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutRequestConfigurer logoutRequestValidator(Saml2LogoutRequestValidator authenticator) {
/* 382 */       this.logoutRequestValidator = authenticator;
/* 383 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutRequestConfigurer logoutRequestResolver(Saml2LogoutRequestResolver logoutRequestResolver) {
/* 393 */       this.logoutRequestResolver = logoutRequestResolver;
/* 394 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutRequestConfigurer logoutRequestRepository(Saml2LogoutRequestRepository logoutRequestRepository) {
/* 403 */       this.logoutRequestRepository = logoutRequestRepository;
/* 404 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public Saml2LogoutConfigurer<H> and() {
/* 416 */       return Saml2LogoutConfigurer.this;
/*     */     }
/*     */     
/*     */     private Saml2LogoutRequestValidator logoutRequestValidator() {
/* 420 */       if (this.logoutRequestValidator != null) {
/* 421 */         return this.logoutRequestValidator;
/*     */       }
/* 423 */       if (Saml2LogoutConfigurer.USE_OPENSAML_5) {
/* 424 */         return (Saml2LogoutRequestValidator)new OpenSaml5LogoutRequestValidator();
/*     */       }
/* 426 */       return (Saml2LogoutRequestValidator)new OpenSaml4LogoutRequestValidator();
/*     */     }
/*     */     
/*     */     private Saml2LogoutRequestResolver logoutRequestResolver(RelyingPartyRegistrationRepository registrations) {
/* 430 */       if (this.logoutRequestResolver != null) {
/* 431 */         return this.logoutRequestResolver;
/*     */       }
/* 433 */       if (Saml2LogoutConfigurer.USE_OPENSAML_5) {
/* 434 */         return (Saml2LogoutRequestResolver)new OpenSaml5LogoutRequestResolver(registrations);
/*     */       }
/* 436 */       return (Saml2LogoutRequestResolver)new OpenSaml4LogoutRequestResolver(registrations);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final class LogoutResponseConfigurer
/*     */   {
/* 443 */     private String logoutUrl = "/logout/saml2/slo";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Saml2LogoutResponseValidator logoutResponseValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Saml2LogoutResponseResolver logoutResponseResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutResponseConfigurer logoutUrl(String logoutUrl) {
/* 463 */       this.logoutUrl = logoutUrl;
/* 464 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutResponseConfigurer logoutResponseValidator(Saml2LogoutResponseValidator authenticator) {
/* 474 */       this.logoutResponseValidator = authenticator;
/* 475 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogoutResponseConfigurer logoutResponseResolver(Saml2LogoutResponseResolver logoutResponseResolver) {
/* 485 */       this.logoutResponseResolver = logoutResponseResolver;
/* 486 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.1", forRemoval = true)
/*     */     public Saml2LogoutConfigurer<H> and() {
/* 498 */       return Saml2LogoutConfigurer.this;
/*     */     }
/*     */     
/*     */     private Saml2LogoutResponseValidator logoutResponseValidator() {
/* 502 */       if (this.logoutResponseValidator != null) {
/* 503 */         return this.logoutResponseValidator;
/*     */       }
/* 505 */       if (Saml2LogoutConfigurer.USE_OPENSAML_5) {
/* 506 */         return (Saml2LogoutResponseValidator)new OpenSaml5LogoutResponseValidator();
/*     */       }
/* 508 */       return (Saml2LogoutResponseValidator)new OpenSaml4LogoutResponseValidator();
/*     */     }
/*     */     
/*     */     private Saml2LogoutResponseResolver logoutResponseResolver(RelyingPartyRegistrationRepository registrations) {
/* 512 */       if (this.logoutResponseResolver != null) {
/* 513 */         return this.logoutResponseResolver;
/*     */       }
/* 515 */       if (Saml2LogoutConfigurer.USE_OPENSAML_5) {
/* 516 */         return (Saml2LogoutResponseResolver)new OpenSaml5LogoutResponseResolver(registrations);
/*     */       }
/* 518 */       return (Saml2LogoutResponseResolver)new OpenSaml4LogoutResponseResolver(registrations);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Saml2RequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     private final SecurityContextHolderStrategy securityContextHolderStrategy;
/*     */     
/*     */     Saml2RequestMatcher(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 528 */       this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 533 */       Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 534 */       if (authentication == null) {
/* 535 */         return false;
/*     */       }
/* 537 */       return authentication.getPrincipal() instanceof org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Saml2RelyingPartyInitiatedLogoutFilter
/*     */     extends LogoutFilter
/*     */   {
/*     */     Saml2RelyingPartyInitiatedLogoutFilter(LogoutSuccessHandler logoutSuccessHandler, LogoutHandler... handlers) {
/* 545 */       super(logoutSuccessHandler, handlers);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\saml2\Saml2LogoutConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */