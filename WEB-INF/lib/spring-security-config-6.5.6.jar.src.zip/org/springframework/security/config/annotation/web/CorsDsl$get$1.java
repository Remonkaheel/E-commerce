/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.CorsConfigurer;
/*    */ import org.springframework.web.cors.CorsConfigurationSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "cors", "Lorg/springframework/security/config/annotation/web/configurers/CorsConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nCorsDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CorsDsl.kt\norg/springframework/security/config/annotation/web/CorsDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,52:1\n1#2:53\n*E\n"})
/*    */ final class CorsDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<CorsConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(CorsConfigurer cors) {
/* 45 */     Intrinsics.checkNotNullParameter(cors, "cors"); if (CorsDsl.this.getConfigurationSource() != null) { CorsConfigurationSource corsConfigurationSource1 = CorsDsl.this.getConfigurationSource(); CorsDsl corsDsl = CorsDsl.this; CorsConfigurationSource it = corsConfigurationSource1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 53 */       int $i$a$-also-CorsDsl$get$1$1 = 0;
/*    */       cors.configurationSource(corsDsl.getConfigurationSource()); }
/*    */     else
/*    */     { CorsDsl.this.getConfigurationSource(); }
/*    */     
/*    */     if (CorsDsl.access$getDisabled$p(CorsDsl.this))
/*    */       cors.disable(); 
/*    */   }
/*    */   
/*    */   CorsDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\CorsDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */