/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.UUID;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.RememberMeAuthenticationProvider;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.RememberMeServices;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.rememberme.AbstractRememberMeServices;
/*     */ import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
/*     */ import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
/*     */ import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
/*     */ import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RememberMeConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<RememberMeConfigurer<H>, H>
/*     */ {
/*     */   private static final String DEFAULT_REMEMBER_ME_NAME = "remember-me";
/*     */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*     */   private String key;
/*     */   private RememberMeServices rememberMeServices;
/*     */   private LogoutHandler logoutHandler;
/* 100 */   private String rememberMeParameter = "remember-me";
/*     */   
/* 102 */   private String rememberMeCookieName = "remember-me";
/*     */ 
/*     */ 
/*     */   
/*     */   private String rememberMeCookieDomain;
/*     */ 
/*     */ 
/*     */   
/*     */   private PersistentTokenRepository tokenRepository;
/*     */ 
/*     */ 
/*     */   
/*     */   private UserDetailsService userDetailsService;
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer tokenValiditySeconds;
/*     */ 
/*     */   
/*     */   private Boolean useSecureCookie;
/*     */ 
/*     */   
/*     */   private Boolean alwaysRemember;
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> tokenValiditySeconds(int tokenValiditySeconds) {
/* 129 */     this.tokenValiditySeconds = Integer.valueOf(tokenValiditySeconds);
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> useSecureCookie(boolean useSecureCookie) {
/* 147 */     this.useSecureCookie = Boolean.valueOf(useSecureCookie);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> userDetailsService(UserDetailsService userDetailsService) {
/* 162 */     this.userDetailsService = userDetailsService;
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> tokenRepository(PersistentTokenRepository tokenRepository) {
/* 173 */     this.tokenRepository = tokenRepository;
/* 174 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> key(String key) {
/* 186 */     this.key = key;
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> rememberMeParameter(String rememberMeParameter) {
/* 196 */     this.rememberMeParameter = rememberMeParameter;
/* 197 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> rememberMeCookieName(String rememberMeCookieName) {
/* 209 */     this.rememberMeCookieName = rememberMeCookieName;
/* 210 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> rememberMeCookieDomain(String rememberMeCookieDomain) {
/* 221 */     this.rememberMeCookieDomain = rememberMeCookieDomain;
/* 222 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> authenticationSuccessHandler(AuthenticationSuccessHandler authenticationSuccessHandler) {
/* 239 */     this.authenticationSuccessHandler = authenticationSuccessHandler;
/* 240 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> rememberMeServices(RememberMeServices rememberMeServices) {
/* 250 */     this.rememberMeServices = rememberMeServices;
/* 251 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RememberMeConfigurer<H> alwaysRemember(boolean alwaysRemember) {
/* 265 */     this.alwaysRemember = Boolean.valueOf(alwaysRemember);
/* 266 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(H http) throws Exception {
/* 272 */     validateInput();
/* 273 */     String key = getKey();
/* 274 */     RememberMeServices rememberMeServices = getRememberMeServices(http, key);
/* 275 */     http.setSharedObject(RememberMeServices.class, rememberMeServices);
/* 276 */     LogoutConfigurer<H> logoutConfigurer = (LogoutConfigurer<H>)http.getConfigurer(LogoutConfigurer.class);
/* 277 */     if (logoutConfigurer != null && this.logoutHandler != null) {
/* 278 */       logoutConfigurer.addLogoutHandler(this.logoutHandler);
/*     */     }
/* 280 */     RememberMeAuthenticationProvider authenticationProvider = new RememberMeAuthenticationProvider(key);
/* 281 */     authenticationProvider = (RememberMeAuthenticationProvider)postProcess(authenticationProvider);
/* 282 */     http.authenticationProvider((AuthenticationProvider)authenticationProvider);
/* 283 */     initDefaultLoginFilter(http);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 289 */     RememberMeAuthenticationFilter rememberMeFilter = new RememberMeAuthenticationFilter((AuthenticationManager)http.getSharedObject(AuthenticationManager.class), this.rememberMeServices);
/* 290 */     if (this.authenticationSuccessHandler != null) {
/* 291 */       rememberMeFilter.setAuthenticationSuccessHandler(this.authenticationSuccessHandler);
/*     */     }
/* 293 */     SecurityContextConfigurer<?> securityContextConfigurer = (SecurityContextConfigurer)http.getConfigurer(SecurityContextConfigurer.class);
/* 294 */     if (securityContextConfigurer != null && securityContextConfigurer.isRequireExplicitSave()) {
/*     */       
/* 296 */       SecurityContextRepository securityContextRepository = securityContextConfigurer.getSecurityContextRepository();
/* 297 */       rememberMeFilter.setSecurityContextRepository(securityContextRepository);
/*     */     } 
/* 299 */     rememberMeFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/*     */ 
/*     */     
/* 302 */     SessionAuthenticationStrategy sessionAuthenticationStrategy = (SessionAuthenticationStrategy)http.getSharedObject(SessionAuthenticationStrategy.class);
/* 303 */     if (sessionAuthenticationStrategy != null) {
/* 304 */       rememberMeFilter.setSessionAuthenticationStrategy(sessionAuthenticationStrategy);
/*     */     }
/*     */     
/* 307 */     rememberMeFilter = (RememberMeAuthenticationFilter)postProcess(rememberMeFilter);
/* 308 */     http.addFilter((Filter)rememberMeFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateInput() {
/* 316 */     if (this.rememberMeServices != null && !"remember-me".equals(this.rememberMeCookieName)) {
/* 317 */       throw new IllegalArgumentException("Can not set rememberMeCookieName and custom rememberMeServices.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getRememberMeParameter() {
/* 326 */     return this.rememberMeParameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initDefaultLoginFilter(H http) {
/* 336 */     DefaultLoginPageGeneratingFilter loginPageGeneratingFilter = (DefaultLoginPageGeneratingFilter)http.getSharedObject(DefaultLoginPageGeneratingFilter.class);
/* 337 */     if (loginPageGeneratingFilter != null) {
/* 338 */       loginPageGeneratingFilter.setRememberMeParameter(getRememberMeParameter());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RememberMeServices getRememberMeServices(H http, String key) throws Exception {
/* 350 */     if (this.rememberMeServices != null) {
/* 351 */       if (this.rememberMeServices instanceof LogoutHandler && this.logoutHandler == null) {
/* 352 */         this.logoutHandler = (LogoutHandler)this.rememberMeServices;
/*     */       }
/* 354 */       return this.rememberMeServices;
/*     */     } 
/* 356 */     AbstractRememberMeServices tokenRememberMeServices = createRememberMeServices(http, key);
/* 357 */     tokenRememberMeServices.setParameter(this.rememberMeParameter);
/* 358 */     tokenRememberMeServices.setCookieName(this.rememberMeCookieName);
/* 359 */     if (this.rememberMeCookieDomain != null) {
/* 360 */       tokenRememberMeServices.setCookieDomain(this.rememberMeCookieDomain);
/*     */     }
/* 362 */     if (this.tokenValiditySeconds != null) {
/* 363 */       tokenRememberMeServices.setTokenValiditySeconds(this.tokenValiditySeconds.intValue());
/*     */     }
/* 365 */     if (this.useSecureCookie != null) {
/* 366 */       tokenRememberMeServices.setUseSecureCookie(this.useSecureCookie.booleanValue());
/*     */     }
/* 368 */     if (this.alwaysRemember != null) {
/* 369 */       tokenRememberMeServices.setAlwaysRemember(this.alwaysRemember.booleanValue());
/*     */     }
/* 371 */     tokenRememberMeServices.afterPropertiesSet();
/* 372 */     this.logoutHandler = (LogoutHandler)tokenRememberMeServices;
/* 373 */     this.rememberMeServices = (RememberMeServices)tokenRememberMeServices;
/* 374 */     return (RememberMeServices)tokenRememberMeServices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractRememberMeServices createRememberMeServices(H http, String key) {
/* 386 */     return (this.tokenRepository != null) ? createPersistentRememberMeServices(http, key) : 
/* 387 */       createTokenBasedRememberMeServices(http, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractRememberMeServices createTokenBasedRememberMeServices(H http, String key) {
/* 397 */     UserDetailsService userDetailsService = getUserDetailsService(http);
/* 398 */     return (AbstractRememberMeServices)new TokenBasedRememberMeServices(key, userDetailsService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractRememberMeServices createPersistentRememberMeServices(H http, String key) {
/* 408 */     UserDetailsService userDetailsService = getUserDetailsService(http);
/* 409 */     return (AbstractRememberMeServices)new PersistentTokenBasedRememberMeServices(key, userDetailsService, this.tokenRepository);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UserDetailsService getUserDetailsService(H http) {
/* 421 */     if (this.userDetailsService == null) {
/* 422 */       this.userDetailsService = getSharedOrBean(http, UserDetailsService.class);
/*     */     }
/* 424 */     Assert.state((this.userDetailsService != null), () -> "userDetailsService cannot be null. Invoke " + RememberMeConfigurer.class.getSimpleName() + "#userDetailsService(UserDetailsService) or see its javadoc for alternative approaches.");
/*     */ 
/*     */     
/* 427 */     return this.userDetailsService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getKey() {
/* 439 */     if (this.key == null) {
/* 440 */       if (this.rememberMeServices instanceof AbstractRememberMeServices) {
/* 441 */         this.key = ((AbstractRememberMeServices)this.rememberMeServices).getKey();
/*     */       } else {
/*     */         
/* 444 */         this.key = UUID.randomUUID().toString();
/*     */       } 
/*     */     }
/* 447 */     return this.key;
/*     */   }
/*     */   
/*     */   private <C> C getSharedOrBean(H http, Class<C> type) {
/* 451 */     C shared = (C)http.getSharedObject(type);
/* 452 */     if (shared != null) {
/* 453 */       return shared;
/*     */     }
/*     */     
/* 456 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 457 */     if (context == null) {
/* 458 */       return null;
/*     */     }
/* 460 */     return (C)context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\RememberMeConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */