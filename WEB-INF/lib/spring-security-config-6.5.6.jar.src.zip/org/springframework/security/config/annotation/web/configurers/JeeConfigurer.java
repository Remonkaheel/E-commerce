/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.core.authority.mapping.MappableAttributesRetriever;
/*     */ import org.springframework.security.core.authority.mapping.SimpleMappableAttributesRetriever;
/*     */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesUserDetailsService;
/*     */ import org.springframework.security.web.authentication.preauth.j2ee.J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.authentication.preauth.j2ee.J2eePreAuthenticatedProcessingFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JeeConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<JeeConfigurer<H>, H>
/*     */ {
/*     */   private J2eePreAuthenticatedProcessingFilter j2eePreAuthenticatedProcessingFilter;
/*     */   private AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService;
/*  76 */   private Set<String> mappableRoles = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JeeConfigurer<H> mappableAuthorities(String... mappableRoles) {
/* 102 */     this.mappableRoles.clear();
/* 103 */     for (String role : mappableRoles) {
/* 104 */       this.mappableRoles.add(role);
/*     */     }
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JeeConfigurer<H> mappableRoles(String... mappableRoles) {
/* 127 */     this.mappableRoles.clear();
/* 128 */     for (String role : mappableRoles) {
/* 129 */       this.mappableRoles.add("ROLE_" + role);
/*     */     }
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JeeConfigurer<H> mappableAuthorities(Set<String> mappableRoles) {
/* 149 */     this.mappableRoles = mappableRoles;
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JeeConfigurer<H> authenticatedUserDetailsService(AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticatedUserDetailsService) {
/* 163 */     this.authenticationUserDetailsService = authenticatedUserDetailsService;
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JeeConfigurer<H> j2eePreAuthenticatedProcessingFilter(J2eePreAuthenticatedProcessingFilter j2eePreAuthenticatedProcessingFilter) {
/* 178 */     this.j2eePreAuthenticatedProcessingFilter = j2eePreAuthenticatedProcessingFilter;
/* 179 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 192 */     PreAuthenticatedAuthenticationProvider authenticationProvider = new PreAuthenticatedAuthenticationProvider();
/* 193 */     authenticationProvider.setPreAuthenticatedUserDetailsService(getUserDetailsService());
/* 194 */     authenticationProvider = (PreAuthenticatedAuthenticationProvider)postProcess(authenticationProvider);
/* 195 */     http.authenticationProvider((AuthenticationProvider)authenticationProvider)
/* 196 */       .setSharedObject(AuthenticationEntryPoint.class, new Http403ForbiddenEntryPoint());
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 201 */     J2eePreAuthenticatedProcessingFilter filter = getFilter((AuthenticationManager)http.getSharedObject(AuthenticationManager.class), http);
/*     */     
/* 203 */     http.addFilter((Filter)filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private J2eePreAuthenticatedProcessingFilter getFilter(AuthenticationManager authenticationManager, H http) {
/* 213 */     if (this.j2eePreAuthenticatedProcessingFilter == null) {
/* 214 */       this.j2eePreAuthenticatedProcessingFilter = new J2eePreAuthenticatedProcessingFilter();
/* 215 */       this.j2eePreAuthenticatedProcessingFilter.setAuthenticationManager(authenticationManager);
/* 216 */       this.j2eePreAuthenticatedProcessingFilter
/* 217 */         .setAuthenticationDetailsSource((AuthenticationDetailsSource)createWebAuthenticationDetailsSource());
/* 218 */       this.j2eePreAuthenticatedProcessingFilter
/* 219 */         .setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 220 */       this.j2eePreAuthenticatedProcessingFilter = (J2eePreAuthenticatedProcessingFilter)postProcess(this.j2eePreAuthenticatedProcessingFilter);
/*     */     } 
/*     */     
/* 223 */     return this.j2eePreAuthenticatedProcessingFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> getUserDetailsService() {
/* 232 */     return (this.authenticationUserDetailsService != null) ? this.authenticationUserDetailsService : 
/* 233 */       (AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken>)new PreAuthenticatedGrantedAuthoritiesUserDetailsService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource createWebAuthenticationDetailsSource() {
/* 243 */     J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource detailsSource = new J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource();
/* 244 */     SimpleMappableAttributesRetriever rolesRetriever = new SimpleMappableAttributesRetriever();
/* 245 */     rolesRetriever.setMappableAttributes(this.mappableRoles);
/* 246 */     detailsSource.setMappableRolesRetriever((MappableAttributesRetriever)rolesRetriever);
/* 247 */     detailsSource = (J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource)postProcess(detailsSource);
/* 248 */     return detailsSource;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\JeeConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */