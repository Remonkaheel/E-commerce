/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Scope;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.security.authentication.AuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
/*     */ import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
/*     */ import org.springframework.security.config.annotation.authentication.configurers.userdetails.DaoAuthenticationConfigurer;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
/*     */ import org.springframework.security.config.annotation.web.configurers.DefaultLoginPageConfigurer;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.crypto.factory.PasswordEncoderFactories;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.security.web.context.request.async.WebAsyncManagerIntegrationFilter;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.HeaderContentNegotiationStrategy;
/*     */ import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ class HttpSecurityConfiguration
/*     */ {
/*     */   private static final String BEAN_NAME_PREFIX = "org.springframework.security.config.annotation.web.configuration.HttpSecurityConfiguration.";
/*     */   private static final String HTTPSECURITY_BEAN_NAME = "org.springframework.security.config.annotation.web.configuration.HttpSecurityConfiguration.httpSecurity";
/*     */   private ObjectPostProcessor<Object> objectPostProcessor;
/*     */   private AuthenticationConfiguration authenticationConfiguration;
/*     */   private ApplicationContext context;
/*  76 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  78 */   private ContentNegotiationStrategy contentNegotiationStrategy = (ContentNegotiationStrategy)new HeaderContentNegotiationStrategy();
/*     */   
/*     */   @Autowired
/*     */   void setObjectPostProcessor(ObjectPostProcessor<Object> objectPostProcessor) {
/*  82 */     this.objectPostProcessor = objectPostProcessor;
/*     */   }
/*     */   
/*     */   @Autowired
/*     */   void setAuthenticationConfiguration(AuthenticationConfiguration authenticationConfiguration) {
/*  87 */     this.authenticationConfiguration = authenticationConfiguration;
/*     */   }
/*     */   
/*     */   @Autowired
/*     */   void setApplicationContext(ApplicationContext context) {
/*  92 */     this.context = context;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/*  97 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setContentNegotiationStrategy(ContentNegotiationStrategy contentNegotiationStrategy) {
/* 102 */     this.contentNegotiationStrategy = contentNegotiationStrategy;
/*     */   }
/*     */   
/*     */   @Bean({"org.springframework.security.config.annotation.web.configuration.HttpSecurityConfiguration.httpSecurity"})
/*     */   @Scope("prototype")
/*     */   HttpSecurity httpSecurity() throws Exception {
/* 108 */     RequestMatcherFactory.setApplicationContext(this.context);
/* 109 */     LazyPasswordEncoder passwordEncoder = new LazyPasswordEncoder(this.context);
/* 110 */     AuthenticationManagerBuilder authenticationBuilder = new DefaultPasswordEncoderAuthenticationManagerBuilder(this.objectPostProcessor, passwordEncoder);
/*     */     
/* 112 */     authenticationBuilder.parentAuthenticationManager(authenticationManager());
/* 113 */     authenticationBuilder.authenticationEventPublisher(getAuthenticationEventPublisher());
/* 114 */     HttpSecurity http = new HttpSecurity(this.objectPostProcessor, authenticationBuilder, createSharedObjects());
/* 115 */     WebAsyncManagerIntegrationFilter webAsyncManagerIntegrationFilter = new WebAsyncManagerIntegrationFilter();
/* 116 */     webAsyncManagerIntegrationFilter.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/*     */     
/* 118 */     http
/* 119 */       .csrf(Customizer.withDefaults())
/* 120 */       .addFilter((Filter)webAsyncManagerIntegrationFilter)
/* 121 */       .exceptionHandling(Customizer.withDefaults())
/* 122 */       .headers(Customizer.withDefaults())
/* 123 */       .sessionManagement(Customizer.withDefaults())
/* 124 */       .securityContext(Customizer.withDefaults())
/* 125 */       .requestCache(Customizer.withDefaults())
/* 126 */       .anonymous(Customizer.withDefaults())
/* 127 */       .servletApi(Customizer.withDefaults())
/* 128 */       .apply((SecurityConfigurerAdapter)new DefaultLoginPageConfigurer());
/* 129 */     http.logout(Customizer.withDefaults());
/*     */     
/* 131 */     applyCorsIfAvailable(http);
/* 132 */     applyDefaultConfigurers(http);
/* 133 */     return http;
/*     */   }
/*     */   
/*     */   private void applyCorsIfAvailable(HttpSecurity http) throws Exception {
/* 137 */     if ((this.context.getBeanNamesForType(UrlBasedCorsConfigurationSource.class)).length > 0) {
/* 138 */       http.cors(Customizer.withDefaults());
/*     */     }
/*     */   }
/*     */   
/*     */   private AuthenticationManager authenticationManager() throws Exception {
/* 143 */     return this.authenticationConfiguration.getAuthenticationManager();
/*     */   }
/*     */   
/*     */   private AuthenticationEventPublisher getAuthenticationEventPublisher() {
/* 147 */     if ((this.context.getBeanNamesForType(AuthenticationEventPublisher.class)).length > 0) {
/* 148 */       return (AuthenticationEventPublisher)this.context.getBean(AuthenticationEventPublisher.class);
/*     */     }
/* 150 */     return (AuthenticationEventPublisher)this.objectPostProcessor.postProcess(new DefaultAuthenticationEventPublisher());
/*     */   }
/*     */   
/*     */   private void applyDefaultConfigurers(HttpSecurity http) throws Exception {
/* 154 */     ClassLoader classLoader = this.context.getClassLoader();
/*     */     
/* 156 */     List<AbstractHttpConfigurer> defaultHttpConfigurers = SpringFactoriesLoader.loadFactories(AbstractHttpConfigurer.class, classLoader);
/* 157 */     for (AbstractHttpConfigurer configurer : defaultHttpConfigurers) {
/* 158 */       http.apply((SecurityConfigurerAdapter)configurer);
/*     */     }
/*     */   }
/*     */   
/*     */   private Map<Class<?>, Object> createSharedObjects() {
/* 163 */     Map<Class<?>, Object> sharedObjects = new HashMap<>();
/* 164 */     sharedObjects.put(ApplicationContext.class, this.context);
/* 165 */     sharedObjects.put(ContentNegotiationStrategy.class, this.contentNegotiationStrategy);
/* 166 */     return sharedObjects;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultPasswordEncoderAuthenticationManagerBuilder
/*     */     extends AuthenticationManagerBuilder
/*     */   {
/*     */     private PasswordEncoder defaultPasswordEncoder;
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultPasswordEncoderAuthenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor, PasswordEncoder defaultPasswordEncoder) {
/* 179 */       super(objectPostProcessor);
/* 180 */       this.defaultPasswordEncoder = defaultPasswordEncoder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.4", forRemoval = true)
/*     */     DefaultPasswordEncoderAuthenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor, PasswordEncoder defaultPasswordEncoder) {
/* 190 */       super(objectPostProcessor);
/* 191 */       this.defaultPasswordEncoder = defaultPasswordEncoder;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder> inMemoryAuthentication() throws Exception {
/* 197 */       return (InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder>)super.inMemoryAuthentication().passwordEncoder(this.defaultPasswordEncoder);
/*     */     }
/*     */ 
/*     */     
/*     */     public JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder> jdbcAuthentication() throws Exception {
/* 202 */       return (JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder>)super.jdbcAuthentication().passwordEncoder(this.defaultPasswordEncoder);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T extends UserDetailsService> DaoAuthenticationConfigurer<AuthenticationManagerBuilder, T> userDetailsService(T userDetailsService) throws Exception {
/* 208 */       return (DaoAuthenticationConfigurer<AuthenticationManagerBuilder, T>)super.userDetailsService((UserDetailsService)userDetailsService).passwordEncoder(this.defaultPasswordEncoder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class LazyPasswordEncoder
/*     */     implements PasswordEncoder
/*     */   {
/*     */     private ApplicationContext applicationContext;
/*     */     private PasswordEncoder passwordEncoder;
/*     */     
/*     */     LazyPasswordEncoder(ApplicationContext applicationContext) {
/* 220 */       this.applicationContext = applicationContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public String encode(CharSequence rawPassword) {
/* 225 */       return getPasswordEncoder().encode(rawPassword);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 230 */       return getPasswordEncoder().matches(rawPassword, encodedPassword);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean upgradeEncoding(String encodedPassword) {
/* 235 */       return getPasswordEncoder().upgradeEncoding(encodedPassword);
/*     */     }
/*     */     
/*     */     private PasswordEncoder getPasswordEncoder() {
/* 239 */       if (this.passwordEncoder != null) {
/* 240 */         return this.passwordEncoder;
/*     */       }
/* 242 */       this
/* 243 */         .passwordEncoder = (PasswordEncoder)this.applicationContext.getBeanProvider(PasswordEncoder.class).getIfUnique(PasswordEncoderFactories::createDelegatingPasswordEncoder);
/* 244 */       return this.passwordEncoder;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 249 */       return getPasswordEncoder().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\HttpSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */