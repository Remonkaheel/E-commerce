/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.AnonymousConfigurer;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "anonymous", "Lorg/springframework/security/config/annotation/web/configurers/AnonymousConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nAnonymousDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnonymousDsl.kt\norg/springframework/security/config/annotation/web/AnonymousDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n1#2:71\n*E\n"})
/*    */ final class AnonymousDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<AnonymousConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(AnonymousConfigurer anonymous) {
/* 59 */     Intrinsics.checkNotNullParameter(anonymous, "anonymous"); if (AnonymousDsl.this.getKey() != null) { String str1 = AnonymousDsl.this.getKey(); AnonymousDsl anonymousDsl = AnonymousDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 71 */       int $i$a$-also-AnonymousDsl$get$1$1 = 0; anonymous.key(anonymousDsl.getKey()); } else { AnonymousDsl.this.getKey(); }  if (AnonymousDsl.this.getPrincipal() != null) { Object object1 = AnonymousDsl.this.getPrincipal(); AnonymousDsl anonymousDsl = AnonymousDsl.this; Object it = object1; int $i$a$-also-AnonymousDsl$get$1$2 = 0; anonymous.principal(anonymousDsl.getPrincipal()); } else { AnonymousDsl.this.getPrincipal(); }  if (AnonymousDsl.this.getAuthorities() != null) { List<GrantedAuthority> list1 = AnonymousDsl.this.getAuthorities(); AnonymousDsl anonymousDsl = AnonymousDsl.this; List<GrantedAuthority> it = list1; int $i$a$-also-AnonymousDsl$get$1$3 = 0; anonymous.authorities(anonymousDsl.getAuthorities()); } else { AnonymousDsl.this.getAuthorities(); }  if (AnonymousDsl.this.getAuthenticationProvider() != null) { AuthenticationProvider authenticationProvider1 = AnonymousDsl.this.getAuthenticationProvider(); AnonymousDsl anonymousDsl = AnonymousDsl.this; AuthenticationProvider it = authenticationProvider1; int $i$a$-also-AnonymousDsl$get$1$4 = 0; anonymous.authenticationProvider(anonymousDsl.getAuthenticationProvider()); } else { AnonymousDsl.this.getAuthenticationProvider(); }  if (AnonymousDsl.this.getAuthenticationFilter() != null) { AnonymousAuthenticationFilter anonymousAuthenticationFilter1 = AnonymousDsl.this.getAuthenticationFilter(); AnonymousDsl anonymousDsl = AnonymousDsl.this; AnonymousAuthenticationFilter it = anonymousAuthenticationFilter1; int $i$a$-also-AnonymousDsl$get$1$5 = 0;
/*    */       anonymous.authenticationFilter(anonymousDsl.getAuthenticationFilter()); }
/*    */     else
/*    */     { AnonymousDsl.this.getAuthenticationFilter(); }
/*    */     
/*    */     if (AnonymousDsl.access$getDisabled$p(AnonymousDsl.this))
/*    */       anonymous.disable(); 
/*    */   }
/*    */   
/*    */   AnonymousDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AnonymousDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */