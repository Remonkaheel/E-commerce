/*    */ package org.springframework.security.config.annotation.web.oauth2.client;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2ClientConfigurer;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
/*    */ import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
/*    */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
/*    */ import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2ClientSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000L\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020\035\032\030\022\016\022\f0\037R\b\022\004\022\0020!0 \022\004\022\0020\"0\036H\000¢\006\002\b#R\"\020\003\032\n\022\004\022\0020\005\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\"\020\020\032\n\022\004\022\0020\022\030\0010\021X\016¢\006\016\n\000\032\004\b\023\020\024\"\004\b\025\020\026R\034\020\027\032\004\030\0010\030X\016¢\006\016\n\000\032\004\b\031\020\032\"\004\b\033\020\034¨\006$"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/client/AuthorizationCodeGrantDsl;", "", "()V", "accessTokenResponseClient", "Lorg/springframework/security/oauth2/client/endpoint/OAuth2AccessTokenResponseClient;", "Lorg/springframework/security/oauth2/client/endpoint/OAuth2AuthorizationCodeGrantRequest;", "getAccessTokenResponseClient", "()Lorg/springframework/security/oauth2/client/endpoint/OAuth2AccessTokenResponseClient;", "setAccessTokenResponseClient", "(Lorg/springframework/security/oauth2/client/endpoint/OAuth2AccessTokenResponseClient;)V", "authorizationRedirectStrategy", "Lorg/springframework/security/web/RedirectStrategy;", "getAuthorizationRedirectStrategy", "()Lorg/springframework/security/web/RedirectStrategy;", "setAuthorizationRedirectStrategy", "(Lorg/springframework/security/web/RedirectStrategy;)V", "authorizationRequestRepository", "Lorg/springframework/security/oauth2/client/web/AuthorizationRequestRepository;", "Lorg/springframework/security/oauth2/core/endpoint/OAuth2AuthorizationRequest;", "getAuthorizationRequestRepository", "()Lorg/springframework/security/oauth2/client/web/AuthorizationRequestRepository;", "setAuthorizationRequestRepository", "(Lorg/springframework/security/oauth2/client/web/AuthorizationRequestRepository;)V", "authorizationRequestResolver", "Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizationRequestResolver;", "getAuthorizationRequestResolver", "()Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizationRequestResolver;", "setAuthorizationRequestResolver", "(Lorg/springframework/security/oauth2/client/web/OAuth2AuthorizationRequestResolver;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer$AuthorizationCodeGrantConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class AuthorizationCodeGrantDsl
/*    */ {
/*    */   @Nullable
/*    */   private OAuth2AuthorizationRequestResolver authorizationRequestResolver;
/*    */   @Nullable
/*    */   private AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository;
/*    */   @Nullable
/*    */   private RedirectStrategy authorizationRedirectStrategy;
/*    */   @Nullable
/*    */   private OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> accessTokenResponseClient;
/*    */   
/*    */   @Nullable
/*    */   public final OAuth2AuthorizationRequestResolver getAuthorizationRequestResolver() {
/* 41 */     return this.authorizationRequestResolver; } public final void setAuthorizationRequestResolver(@Nullable OAuth2AuthorizationRequestResolver <set-?>) { this.authorizationRequestResolver = <set-?>; } @Nullable
/* 42 */   public final AuthorizationRequestRepository<OAuth2AuthorizationRequest> getAuthorizationRequestRepository() { return this.authorizationRequestRepository; } public final void setAuthorizationRequestRepository(@Nullable AuthorizationRequestRepository<OAuth2AuthorizationRequest> <set-?>) { this.authorizationRequestRepository = <set-?>; } @Nullable
/* 43 */   public final RedirectStrategy getAuthorizationRedirectStrategy() { return this.authorizationRedirectStrategy; } public final void setAuthorizationRedirectStrategy(@Nullable RedirectStrategy <set-?>) { this.authorizationRedirectStrategy = <set-?>; } @Nullable
/* 44 */   public final OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> getAccessTokenResponseClient() { return this.accessTokenResponseClient; } public final void setAccessTokenResponseClient(@Nullable OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> <set-?>) { this.accessTokenResponseClient = <set-?>; }
/*    */   
/*    */   @NotNull
/* 47 */   public final Function1<OAuth2ClientConfigurer<HttpSecurity>.AuthorizationCodeGrantConfigurer, Unit> get$spring_security_config() { return new AuthorizationCodeGrantDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "authorizationCodeGrant", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer$AuthorizationCodeGrantConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nAuthorizationCodeGrantDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AuthorizationCodeGrantDsl.kt\norg/springframework/security/config/annotation/web/oauth2/client/AuthorizationCodeGrantDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1#2:56\n*E\n"})
/* 48 */   static final class AuthorizationCodeGrantDsl$get$1 extends Lambda implements Function1<OAuth2ClientConfigurer<HttpSecurity>.AuthorizationCodeGrantConfigurer, Unit> { public final void invoke(OAuth2ClientConfigurer.AuthorizationCodeGrantConfigurer authorizationCodeGrant) { Intrinsics.checkNotNullParameter(authorizationCodeGrant, "authorizationCodeGrant"); if (AuthorizationCodeGrantDsl.this.getAuthorizationRequestResolver() != null) { OAuth2AuthorizationRequestResolver oAuth2AuthorizationRequestResolver1 = AuthorizationCodeGrantDsl.this.getAuthorizationRequestResolver(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; OAuth2AuthorizationRequestResolver it = oAuth2AuthorizationRequestResolver1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 56 */         int $i$a$-also-AuthorizationCodeGrantDsl$get$1$1 = 0; authorizationCodeGrant.authorizationRequestResolver(authorizationCodeGrantDsl.getAuthorizationRequestResolver()); } else { AuthorizationCodeGrantDsl.this.getAuthorizationRequestResolver(); }  if (AuthorizationCodeGrantDsl.this.getAuthorizationRequestRepository() != null) { AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository1 = AuthorizationCodeGrantDsl.this.getAuthorizationRequestRepository(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; AuthorizationRequestRepository<OAuth2AuthorizationRequest> it = authorizationRequestRepository1; int $i$a$-also-AuthorizationCodeGrantDsl$get$1$2 = 0; authorizationCodeGrant.authorizationRequestRepository(authorizationCodeGrantDsl.getAuthorizationRequestRepository()); } else { AuthorizationCodeGrantDsl.this.getAuthorizationRequestRepository(); }  if (AuthorizationCodeGrantDsl.this.getAuthorizationRedirectStrategy() != null) { RedirectStrategy redirectStrategy1 = AuthorizationCodeGrantDsl.this.getAuthorizationRedirectStrategy(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; RedirectStrategy it = redirectStrategy1; int $i$a$-also-AuthorizationCodeGrantDsl$get$1$3 = 0; authorizationCodeGrant.authorizationRedirectStrategy(authorizationCodeGrantDsl.getAuthorizationRedirectStrategy()); } else { AuthorizationCodeGrantDsl.this.getAuthorizationRedirectStrategy(); }  if (AuthorizationCodeGrantDsl.this.getAccessTokenResponseClient() != null) { OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> oAuth2AccessTokenResponseClient1 = AuthorizationCodeGrantDsl.this.getAccessTokenResponseClient(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> it = oAuth2AccessTokenResponseClient1; int $i$a$-also-AuthorizationCodeGrantDsl$get$1$4 = 0;
/*    */         authorizationCodeGrant.accessTokenResponseClient(authorizationCodeGrantDsl.getAccessTokenResponseClient()); }
/*    */       else
/*    */       { AuthorizationCodeGrantDsl.this.getAccessTokenResponseClient(); }
/*    */        }
/*    */ 
/*    */     
/*    */     AuthorizationCodeGrantDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\client\AuthorizationCodeGrantDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */