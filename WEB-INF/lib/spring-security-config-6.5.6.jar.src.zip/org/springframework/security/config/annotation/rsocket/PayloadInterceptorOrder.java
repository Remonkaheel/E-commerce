/*    */ package org.springframework.security.config.annotation.rsocket;
/*    */ 
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PayloadInterceptorOrder
/*    */   implements Ordered
/*    */ {
/* 38 */   BASIC_AUTHENTICATION,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   JWT_AUTHENTICATION,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   AUTHENTICATION,
/*    */ 
/*    */ 
/*    */   
/* 55 */   ANONYMOUS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   AUTHORIZATION;
/*    */   
/*    */   private static final int INTERVAL = 100;
/*    */   
/*    */   private int order;
/*    */   
/*    */   PayloadInterceptorOrder() {
/* 67 */     this.order = ordinal() * 100;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 72 */     return this.order;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\PayloadInterceptorOrder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */