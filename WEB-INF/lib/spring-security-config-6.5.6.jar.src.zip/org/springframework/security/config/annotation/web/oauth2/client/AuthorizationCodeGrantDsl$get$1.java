/*    */ package org.springframework.security.config.annotation.web.oauth2.client;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2ClientConfigurer;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
/*    */ import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
/*    */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
/*    */ import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
/*    */ import org.springframework.security.web.RedirectStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "authorizationCodeGrant", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer$AuthorizationCodeGrantConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2ClientConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nAuthorizationCodeGrantDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AuthorizationCodeGrantDsl.kt\norg/springframework/security/config/annotation/web/oauth2/client/AuthorizationCodeGrantDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1#2:56\n*E\n"})
/*    */ final class AuthorizationCodeGrantDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OAuth2ClientConfigurer<HttpSecurity>.AuthorizationCodeGrantConfigurer, Unit>
/*    */ {
/*    */   public final void invoke(OAuth2ClientConfigurer.AuthorizationCodeGrantConfigurer authorizationCodeGrant) {
/* 48 */     Intrinsics.checkNotNullParameter(authorizationCodeGrant, "authorizationCodeGrant"); if (AuthorizationCodeGrantDsl.this.getAuthorizationRequestResolver() != null) { OAuth2AuthorizationRequestResolver oAuth2AuthorizationRequestResolver1 = AuthorizationCodeGrantDsl.this.getAuthorizationRequestResolver(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; OAuth2AuthorizationRequestResolver it = oAuth2AuthorizationRequestResolver1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       int $i$a$-also-AuthorizationCodeGrantDsl$get$1$1 = 0; authorizationCodeGrant.authorizationRequestResolver(authorizationCodeGrantDsl.getAuthorizationRequestResolver()); } else { AuthorizationCodeGrantDsl.this.getAuthorizationRequestResolver(); }  if (AuthorizationCodeGrantDsl.this.getAuthorizationRequestRepository() != null) { AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository1 = AuthorizationCodeGrantDsl.this.getAuthorizationRequestRepository(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; AuthorizationRequestRepository<OAuth2AuthorizationRequest> it = authorizationRequestRepository1; int $i$a$-also-AuthorizationCodeGrantDsl$get$1$2 = 0; authorizationCodeGrant.authorizationRequestRepository(authorizationCodeGrantDsl.getAuthorizationRequestRepository()); } else { AuthorizationCodeGrantDsl.this.getAuthorizationRequestRepository(); }  if (AuthorizationCodeGrantDsl.this.getAuthorizationRedirectStrategy() != null) { RedirectStrategy redirectStrategy1 = AuthorizationCodeGrantDsl.this.getAuthorizationRedirectStrategy(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; RedirectStrategy it = redirectStrategy1; int $i$a$-also-AuthorizationCodeGrantDsl$get$1$3 = 0; authorizationCodeGrant.authorizationRedirectStrategy(authorizationCodeGrantDsl.getAuthorizationRedirectStrategy()); } else { AuthorizationCodeGrantDsl.this.getAuthorizationRedirectStrategy(); }  if (AuthorizationCodeGrantDsl.this.getAccessTokenResponseClient() != null) { OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> oAuth2AccessTokenResponseClient1 = AuthorizationCodeGrantDsl.this.getAccessTokenResponseClient(); AuthorizationCodeGrantDsl authorizationCodeGrantDsl = AuthorizationCodeGrantDsl.this; OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> it = oAuth2AccessTokenResponseClient1; int $i$a$-also-AuthorizationCodeGrantDsl$get$1$4 = 0;
/*    */       authorizationCodeGrant.accessTokenResponseClient(authorizationCodeGrantDsl.getAccessTokenResponseClient()); }
/*    */     else
/*    */     { AuthorizationCodeGrantDsl.this.getAccessTokenResponseClient(); }
/*    */   
/*    */   }
/*    */   
/*    */   AuthorizationCodeGrantDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\client\AuthorizationCodeGrantDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */