/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.List;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.vote.AffirmativeBased;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractInterceptUrlConfigurer<C extends AbstractInterceptUrlConfigurer<C, H>, H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<C, H>
/*     */ {
/*     */   private Boolean filterSecurityInterceptorOncePerRequest;
/*     */   private AccessDecisionManager accessDecisionManager;
/*     */   
/*     */   public void configure(H http) throws Exception {
/*  78 */     FilterInvocationSecurityMetadataSource metadataSource = createMetadataSource(http);
/*  79 */     if (metadataSource == null) {
/*     */       return;
/*     */     }
/*  82 */     FilterSecurityInterceptor securityInterceptor = createFilterSecurityInterceptor(http, metadataSource, (AuthenticationManager)http
/*  83 */         .getSharedObject(AuthenticationManager.class));
/*  84 */     if (this.filterSecurityInterceptorOncePerRequest != null) {
/*  85 */       securityInterceptor.setObserveOncePerRequest(this.filterSecurityInterceptorOncePerRequest.booleanValue());
/*     */     }
/*  87 */     securityInterceptor = (FilterSecurityInterceptor)postProcess(securityInterceptor);
/*  88 */     http.addFilter((Filter)securityInterceptor);
/*  89 */     http.setSharedObject(FilterSecurityInterceptor.class, securityInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AccessDecisionManager createDefaultAccessDecisionManager(H http) {
/* 116 */     AffirmativeBased result = new AffirmativeBased(getDecisionVoters(http));
/* 117 */     return (AccessDecisionManager)postProcess(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AccessDecisionManager getAccessDecisionManager(H http) {
/* 128 */     if (this.accessDecisionManager == null) {
/* 129 */       this.accessDecisionManager = createDefaultAccessDecisionManager(http);
/*     */     }
/* 131 */     return this.accessDecisionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FilterSecurityInterceptor createFilterSecurityInterceptor(H http, FilterInvocationSecurityMetadataSource metadataSource, AuthenticationManager authenticationManager) throws Exception {
/* 145 */     FilterSecurityInterceptor securityInterceptor = new FilterSecurityInterceptor();
/* 146 */     securityInterceptor.setSecurityMetadataSource(metadataSource);
/* 147 */     securityInterceptor.setAccessDecisionManager(getAccessDecisionManager(http));
/* 148 */     securityInterceptor.setAuthenticationManager(authenticationManager);
/* 149 */     securityInterceptor.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 150 */     securityInterceptor.afterPropertiesSet();
/* 151 */     return securityInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   abstract FilterInvocationSecurityMetadataSource createMetadataSource(H paramH);
/*     */ 
/*     */ 
/*     */   
/*     */   abstract List<AccessDecisionVoter<?>> getDecisionVoters(H paramH);
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract class AbstractInterceptUrlRegistry<R extends AbstractInterceptUrlRegistry<R, T>, T>
/*     */     extends AbstractConfigAttributeRequestMatcherRegistry<T>
/*     */   {
/*     */     public R accessDecisionManager(AccessDecisionManager accessDecisionManager) {
/* 168 */       AbstractInterceptUrlConfigurer.this.accessDecisionManager = accessDecisionManager;
/* 169 */       return getSelf();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public R filterSecurityInterceptorOncePerRequest(boolean filterSecurityInterceptorOncePerRequest) {
/* 181 */       AbstractInterceptUrlConfigurer.this.filterSecurityInterceptorOncePerRequest = Boolean.valueOf(filterSecurityInterceptorOncePerRequest);
/* 182 */       return getSelf();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private R getSelf() {
/* 191 */       return (R)this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AbstractInterceptUrlConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */