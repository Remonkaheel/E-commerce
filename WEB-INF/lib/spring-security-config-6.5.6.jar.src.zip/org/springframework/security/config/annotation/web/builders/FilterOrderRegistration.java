/*     */ package org.springframework.security.config.annotation.web.builders;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.security.web.access.ExceptionTranslationFilter;
/*     */ import org.springframework.security.web.access.channel.ChannelProcessingFilter;
/*     */ import org.springframework.security.web.access.intercept.AuthorizationFilter;
/*     */ import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
/*     */ import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.AuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutFilter;
/*     */ import org.springframework.security.web.authentication.ott.GenerateOneTimeTokenFilter;
/*     */ import org.springframework.security.web.authentication.ott.OneTimeTokenAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
/*     */ import org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.switchuser.SwitchUserFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLogoutPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultOneTimeTokenSubmitPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultResourcesFilter;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.www.DigestAuthenticationFilter;
/*     */ import org.springframework.security.web.context.SecurityContextHolderFilter;
/*     */ import org.springframework.security.web.context.SecurityContextPersistenceFilter;
/*     */ import org.springframework.security.web.context.request.async.WebAsyncManagerIntegrationFilter;
/*     */ import org.springframework.security.web.csrf.CsrfFilter;
/*     */ import org.springframework.security.web.header.HeaderWriterFilter;
/*     */ import org.springframework.security.web.jaasapi.JaasApiIntegrationFilter;
/*     */ import org.springframework.security.web.savedrequest.RequestCacheAwareFilter;
/*     */ import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
/*     */ import org.springframework.security.web.session.ConcurrentSessionFilter;
/*     */ import org.springframework.security.web.session.DisableEncodeUrlFilter;
/*     */ import org.springframework.security.web.session.ForceEagerSessionCreationFilter;
/*     */ import org.springframework.security.web.session.SessionManagementFilter;
/*     */ import org.springframework.security.web.transport.HttpsRedirectFilter;
/*     */ import org.springframework.web.filter.CorsFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FilterOrderRegistration
/*     */ {
/*     */   private static final int INITIAL_ORDER = 100;
/*     */   private static final int ORDER_STEP = 100;
/*  75 */   private final Map<String, Integer> filterToOrder = new HashMap<>();
/*     */   
/*     */   FilterOrderRegistration() {
/*  78 */     Step order = new Step(100, 100);
/*  79 */     put((Class)DisableEncodeUrlFilter.class, order.next());
/*  80 */     put((Class)ForceEagerSessionCreationFilter.class, order.next());
/*  81 */     put((Class)ChannelProcessingFilter.class, order.next());
/*  82 */     put((Class)HttpsRedirectFilter.class, order.next());
/*  83 */     order.next();
/*  84 */     put((Class)WebAsyncManagerIntegrationFilter.class, order.next());
/*  85 */     put((Class)SecurityContextHolderFilter.class, order.next());
/*  86 */     put((Class)SecurityContextPersistenceFilter.class, order.next());
/*  87 */     put((Class)HeaderWriterFilter.class, order.next());
/*  88 */     put((Class)CorsFilter.class, order.next());
/*  89 */     put((Class)CsrfFilter.class, order.next());
/*  90 */     put((Class)LogoutFilter.class, order.next());
/*  91 */     this.filterToOrder.put("org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter", 
/*     */         
/*  93 */         Integer.valueOf(order.next()));
/*  94 */     this.filterToOrder.put("org.springframework.security.saml2.provider.service.web.Saml2WebSsoAuthenticationRequestFilter", 
/*     */         
/*  96 */         Integer.valueOf(order.next()));
/*  97 */     put((Class)GenerateOneTimeTokenFilter.class, order.next());
/*  98 */     put((Class)X509AuthenticationFilter.class, order.next());
/*  99 */     put((Class)AbstractPreAuthenticatedProcessingFilter.class, order.next());
/* 100 */     this.filterToOrder.put("org.springframework.security.cas.web.CasAuthenticationFilter", Integer.valueOf(order.next()));
/* 101 */     this.filterToOrder.put("org.springframework.security.oauth2.client.web.OAuth2LoginAuthenticationFilter", 
/* 102 */         Integer.valueOf(order.next()));
/* 103 */     this.filterToOrder.put("org.springframework.security.saml2.provider.service.web.authentication.Saml2WebSsoAuthenticationFilter", 
/*     */         
/* 105 */         Integer.valueOf(order.next()));
/* 106 */     put((Class)UsernamePasswordAuthenticationFilter.class, order.next());
/* 107 */     put((Class)OneTimeTokenAuthenticationFilter.class, order.next());
/* 108 */     order.next();
/* 109 */     put((Class)DefaultResourcesFilter.class, order.next());
/* 110 */     put((Class)DefaultLoginPageGeneratingFilter.class, order.next());
/* 111 */     put((Class)DefaultLogoutPageGeneratingFilter.class, order.next());
/* 112 */     put((Class)DefaultOneTimeTokenSubmitPageGeneratingFilter.class, order.next());
/* 113 */     put((Class)ConcurrentSessionFilter.class, order.next());
/* 114 */     put((Class)DigestAuthenticationFilter.class, order.next());
/* 115 */     this.filterToOrder.put("org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter", 
/*     */         
/* 117 */         Integer.valueOf(order.next()));
/* 118 */     put((Class)BasicAuthenticationFilter.class, order.next());
/* 119 */     put((Class)AuthenticationFilter.class, order.next());
/* 120 */     put((Class)RequestCacheAwareFilter.class, order.next());
/* 121 */     put((Class)SecurityContextHolderAwareRequestFilter.class, order.next());
/* 122 */     put((Class)JaasApiIntegrationFilter.class, order.next());
/* 123 */     put((Class)RememberMeAuthenticationFilter.class, order.next());
/* 124 */     put((Class)AnonymousAuthenticationFilter.class, order.next());
/* 125 */     this.filterToOrder.put("org.springframework.security.oauth2.client.web.OAuth2AuthorizationCodeGrantFilter", 
/* 126 */         Integer.valueOf(order.next()));
/* 127 */     put((Class)SessionManagementFilter.class, order.next());
/* 128 */     put((Class)ExceptionTranslationFilter.class, order.next());
/* 129 */     put((Class)FilterSecurityInterceptor.class, order.next());
/* 130 */     put((Class)AuthorizationFilter.class, order.next());
/* 131 */     put((Class)SwitchUserFilter.class, order.next());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(Class<? extends Filter> filter, int position) {
/* 142 */     this.filterToOrder.putIfAbsent(filter.getName(), Integer.valueOf(position));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Integer getOrder(Class<?> clazz) {
/* 152 */     while (clazz != null) {
/* 153 */       Integer result = this.filterToOrder.get(clazz.getName());
/* 154 */       if (result != null) {
/* 155 */         return result;
/*     */       }
/* 157 */       clazz = clazz.getSuperclass();
/*     */     } 
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Step
/*     */   {
/*     */     private int value;
/*     */     private final int stepSize;
/*     */     
/*     */     Step(int initialValue, int stepSize) {
/* 169 */       this.value = initialValue;
/* 170 */       this.stepSize = stepSize;
/*     */     }
/*     */     
/*     */     int next() {
/* 174 */       int value = this.value;
/* 175 */       this.value += this.stepSize;
/* 176 */       return value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\builders\FilterOrderRegistration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */