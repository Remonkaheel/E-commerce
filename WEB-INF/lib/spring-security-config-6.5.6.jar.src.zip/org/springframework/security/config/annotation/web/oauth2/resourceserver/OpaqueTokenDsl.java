/*    */ package org.springframework.security.config.annotation.web.oauth2.resourceserver;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.authentication.AuthenticationManager;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenAuthenticationConverter;
/*    */ import org.springframework.security.oauth2.server.resource.introspection.OpaqueTokenIntrospector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @OAuth2ResourceServerSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\f\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\005\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020 \032\030\022\016\022\f0\"R\b\022\004\022\0020$0#\022\004\022\0020%0!H\000¢\006\002\b&J\026\020'\032\0020%2\006\020(\032\0020\0042\006\020)\032\0020\004R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\020\020\005\032\004\030\0010\006X\016¢\006\002\n\000R\034\020\007\032\004\030\0010\bX\016¢\006\016\n\000\032\004\b\t\020\n\"\004\b\013\020\fR\034\020\r\032\004\030\0010\016X\016¢\006\016\n\000\032\004\b\017\020\020\"\004\b\021\020\022R\034\020\023\032\020\022\004\022\0020\004\022\004\022\0020\004\030\0010\024X\016¢\006\002\n\000R(\020\026\032\004\030\0010\0042\b\020\025\032\004\030\0010\0048F@FX\016¢\006\f\032\004\b\027\020\030\"\004\b\031\020\032R(\020\033\032\004\030\0010\0062\b\020\025\032\004\030\0010\0068F@FX\016¢\006\f\032\004\b\034\020\035\"\004\b\036\020\037¨\006*"}, d2 = {"Lorg/springframework/security/config/annotation/web/oauth2/resourceserver/OpaqueTokenDsl;", "", "()V", "_introspectionUri", "", "_introspector", "Lorg/springframework/security/oauth2/server/resource/introspection/OpaqueTokenIntrospector;", "authenticationConverter", "Lorg/springframework/security/oauth2/server/resource/introspection/OpaqueTokenAuthenticationConverter;", "getAuthenticationConverter", "()Lorg/springframework/security/oauth2/server/resource/introspection/OpaqueTokenAuthenticationConverter;", "setAuthenticationConverter", "(Lorg/springframework/security/oauth2/server/resource/introspection/OpaqueTokenAuthenticationConverter;)V", "authenticationManager", "Lorg/springframework/security/authentication/AuthenticationManager;", "getAuthenticationManager", "()Lorg/springframework/security/authentication/AuthenticationManager;", "setAuthenticationManager", "(Lorg/springframework/security/authentication/AuthenticationManager;)V", "clientCredentials", "Lkotlin/Pair;", "value", "introspectionUri", "getIntrospectionUri", "()Ljava/lang/String;", "setIntrospectionUri", "(Ljava/lang/String;)V", "introspector", "getIntrospector", "()Lorg/springframework/security/oauth2/server/resource/introspection/OpaqueTokenIntrospector;", "setIntrospector", "(Lorg/springframework/security/oauth2/server/resource/introspection/OpaqueTokenIntrospector;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$OpaqueTokenConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "introspectionClientCredentials", "clientId", "clientSecret", "spring-security-config"})
/*    */ public final class OpaqueTokenDsl
/*    */ {
/*    */   @Nullable
/*    */   private String _introspectionUri;
/*    */   @Nullable
/*    */   private OpaqueTokenIntrospector _introspector;
/*    */   @Nullable
/*    */   private Pair<String, String> clientCredentials;
/*    */   @Nullable
/*    */   private AuthenticationManager authenticationManager;
/*    */   @Nullable
/*    */   private OpaqueTokenAuthenticationConverter authenticationConverter;
/*    */   
/*    */   @Nullable
/*    */   public final AuthenticationManager getAuthenticationManager() {
/* 42 */     return this.authenticationManager; } public final void setAuthenticationManager(@Nullable AuthenticationManager <set-?>) { this.authenticationManager = <set-?>; }
/*    */    @Nullable
/*    */   public final String getIntrospectionUri() {
/* 45 */     return this._introspectionUri;
/*    */   } public final void setIntrospectionUri(@Nullable String value) {
/* 47 */     this._introspectionUri = value;
/* 48 */     this._introspector = null;
/*    */   } @Nullable
/*    */   public final OpaqueTokenIntrospector getIntrospector() {
/* 51 */     return this._introspector;
/*    */   } public final void setIntrospector(@Nullable OpaqueTokenIntrospector value) {
/* 53 */     this._introspector = value;
/* 54 */     this._introspectionUri = null;
/* 55 */     this.clientCredentials = null;
/*    */   }
/*    */   @Nullable
/* 58 */   public final OpaqueTokenAuthenticationConverter getAuthenticationConverter() { return this.authenticationConverter; } public final void setAuthenticationConverter(@Nullable OpaqueTokenAuthenticationConverter <set-?>) { this.authenticationConverter = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void introspectionClientCredentials(@NotNull String clientId, @NotNull String clientSecret) {
/* 67 */     Intrinsics.checkNotNullParameter(clientId, "clientId"); Intrinsics.checkNotNullParameter(clientSecret, "clientSecret"); this.clientCredentials = new Pair(clientId, clientSecret);
/* 68 */     this._introspector = null;
/*    */   }
/*    */   
/*    */   @NotNull
/* 72 */   public final Function1<OAuth2ResourceServerConfigurer<HttpSecurity>.OpaqueTokenConfigurer, Unit> get$spring_security_config() { return new OpaqueTokenDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "opaqueToken", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$OpaqueTokenConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOpaqueTokenDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OpaqueTokenDsl.kt\norg/springframework/security/config/annotation/web/oauth2/resourceserver/OpaqueTokenDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,81:1\n1#2:82\n*E\n"})
/* 73 */   static final class OpaqueTokenDsl$get$1 extends Lambda implements Function1<OAuth2ResourceServerConfigurer<HttpSecurity>.OpaqueTokenConfigurer, Unit> { public final void invoke(OAuth2ResourceServerConfigurer.OpaqueTokenConfigurer opaqueToken) { Intrinsics.checkNotNullParameter(opaqueToken, "opaqueToken"); if (OpaqueTokenDsl.this.getIntrospectionUri() != null) { String str1 = OpaqueTokenDsl.this.getIntrospectionUri(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; String it = str1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 82 */         int $i$a$-also-OpaqueTokenDsl$get$1$1 = 0; opaqueToken.introspectionUri(opaqueTokenDsl.getIntrospectionUri()); } else { OpaqueTokenDsl.this.getIntrospectionUri(); }  if (OpaqueTokenDsl.this.getIntrospector() != null) { OpaqueTokenIntrospector opaqueTokenIntrospector1 = OpaqueTokenDsl.this.getIntrospector(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; OpaqueTokenIntrospector it = opaqueTokenIntrospector1; int $i$a$-also-OpaqueTokenDsl$get$1$2 = 0; opaqueToken.introspector(opaqueTokenDsl.getIntrospector()); } else { OpaqueTokenDsl.this.getIntrospector(); }  if (OpaqueTokenDsl.this.getAuthenticationConverter() != null) { OpaqueTokenAuthenticationConverter opaqueTokenAuthenticationConverter1 = OpaqueTokenDsl.this.getAuthenticationConverter(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; OpaqueTokenAuthenticationConverter it = opaqueTokenAuthenticationConverter1; int $i$a$-also-OpaqueTokenDsl$get$1$3 = 0; opaqueToken.authenticationConverter(opaqueTokenDsl.getAuthenticationConverter()); } else { OpaqueTokenDsl.this.getAuthenticationConverter(); }  if (OpaqueTokenDsl.this.clientCredentials != null) { Pair pair1 = OpaqueTokenDsl.this.clientCredentials; OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; Pair it = pair1; int $i$a$-also-OpaqueTokenDsl$get$1$4 = 0; Intrinsics.checkNotNull(opaqueTokenDsl.clientCredentials); Intrinsics.checkNotNull(opaqueTokenDsl.clientCredentials); opaqueToken.introspectionClientCredentials((String)opaqueTokenDsl.clientCredentials.getFirst(), (String)opaqueTokenDsl.clientCredentials.getSecond()); } else { OpaqueTokenDsl.this.clientCredentials; }  if (OpaqueTokenDsl.this.getAuthenticationManager() != null) { AuthenticationManager authenticationManager1 = OpaqueTokenDsl.this.getAuthenticationManager(); OpaqueTokenDsl opaqueTokenDsl = OpaqueTokenDsl.this; AuthenticationManager it = authenticationManager1; int $i$a$-also-OpaqueTokenDsl$get$1$5 = 0;
/*    */         opaqueToken.authenticationManager(opaqueTokenDsl.getAuthenticationManager()); }
/*    */       else
/*    */       { OpaqueTokenDsl.this.getAuthenticationManager(); }
/*    */        }
/*    */ 
/*    */     
/*    */     OpaqueTokenDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\resourceserver\OpaqueTokenDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */