/*     */ package org.springframework.security.config.annotation.authentication.configurers.userdetails;
/*     */ 
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*     */ import org.springframework.security.core.userdetails.UserDetailsPasswordService;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDaoAuthenticationConfigurer<B extends ProviderManagerBuilder<B>, C extends AbstractDaoAuthenticationConfigurer<B, C, U>, U extends UserDetailsService>
/*     */   extends UserDetailsAwareConfigurer<B, U>
/*     */ {
/*     */   private DaoAuthenticationProvider provider;
/*     */   private final U userDetailsService;
/*     */   
/*     */   AbstractDaoAuthenticationConfigurer(U userDetailsService) {
/*  48 */     this.userDetailsService = userDetailsService;
/*  49 */     this.provider = new DaoAuthenticationProvider((UserDetailsService)userDetailsService);
/*  50 */     if (userDetailsService instanceof UserDetailsPasswordService) {
/*  51 */       this.provider.setUserDetailsPasswordService((UserDetailsPasswordService)userDetailsService);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/*  62 */     addObjectPostProcessor(objectPostProcessor);
/*  63 */     return (C)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public C withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/*  73 */     addObjectPostProcessor(objectPostProcessor);
/*  74 */     return (C)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public C passwordEncoder(PasswordEncoder passwordEncoder) {
/*  85 */     this.provider.setPasswordEncoder(passwordEncoder);
/*  86 */     return (C)this;
/*     */   }
/*     */   
/*     */   public C userDetailsPasswordManager(UserDetailsPasswordService passwordManager) {
/*  90 */     this.provider.setUserDetailsPasswordService(passwordManager);
/*  91 */     return (C)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(B builder) throws Exception {
/*  96 */     this.provider = (DaoAuthenticationProvider)postProcess(this.provider);
/*  97 */     builder.authenticationProvider((AuthenticationProvider)this.provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public U getUserDetailsService() {
/* 108 */     return this.userDetailsService;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurer\\userdetails\AbstractDaoAuthenticationConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */