/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ import org.springframework.lang.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AutoProxyRegistrarSelector
/*    */   extends AdviceModeImportSelector<EnableReactiveMethodSecurity>
/*    */ {
/* 74 */   private static final String[] IMPORTS = new String[] { AutoProxyRegistrar.class.getName(), MethodSecurityAdvisorRegistrar.class
/* 75 */       .getName() };
/*    */ 
/*    */   
/*    */   protected String[] selectImports(@NonNull AdviceMode adviceMode) {
/* 79 */     if (adviceMode == AdviceMode.PROXY) {
/* 80 */       return IMPORTS;
/*    */     }
/* 82 */     throw new IllegalStateException("AdviceMode " + String.valueOf(adviceMode) + " is not supported");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\ReactiveMethodSecuritySelector$AutoProxyRegistrarSelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */