/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import kotlin.Deprecated;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*     */ import org.springframework.security.config.annotation.web.headers.CacheControlDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.ContentSecurityPolicyDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.ContentTypeOptionsDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.CrossOriginEmbedderPolicyDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.CrossOriginOpenerPolicyDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.CrossOriginResourcePolicyDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.FrameOptionsDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.HttpPublicKeyPinningDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.HttpStrictTransportSecurityDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.PermissionsPolicyDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.ReferrerPolicyDsl;
/*     */ import org.springframework.security.config.annotation.web.headers.XssProtectionConfigDsl;
/*     */ import org.springframework.security.web.header.HeaderWriter;
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000Ð\001\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\007\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020!\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\b\007\030\0002\0020\001B\005¢\006\002\020\002J\016\020,\032\0020\b2\006\020-\032\0020!J\037\020\003\032\0020\b2\027\020.\032\023\022\004\022\0020/\022\004\022\0020\b0\004¢\006\002\b0J\037\020\t\032\0020\b2\027\0201\032\023\022\004\022\00202\022\004\022\0020\b0\004¢\006\002\b0J\037\020\013\032\0020\b2\027\0203\032\023\022\004\022\00204\022\004\022\0020\b0\004¢\006\002\b0J\037\020\r\032\0020\b2\027\0205\032\023\022\004\022\00206\022\004\022\0020\b0\004¢\006\002\b0J\037\020\017\032\0020\b2\027\0207\032\023\022\004\022\00208\022\004\022\0020\b0\004¢\006\002\b0J\037\020\021\032\0020\b2\027\0209\032\023\022\004\022\0020:\022\004\022\0020\b0\004¢\006\002\b0J\006\020;\032\0020\bJ\020\020<\032\0020\b2\006\020=\032\0020\034H\007J\037\020\035\032\0020\b2\027\020>\032\023\022\004\022\0020?\022\004\022\0020\b0\004¢\006\002\b0J\037\020@\032\024\022\n\022\b\022\004\022\0020\0070\006\022\004\022\0020\b0\004H\000¢\006\002\bAJ!\020B\032\0020\b2\027\020C\032\023\022\004\022\0020D\022\004\022\0020\b0\004¢\006\002\b0H\007J\037\020E\032\0020\b2\027\020F\032\023\022\004\022\0020G\022\004\022\0020\b0\004¢\006\002\b0J\037\020&\032\0020\b2\027\020H\032\023\022\004\022\0020I\022\004\022\0020\b0\004¢\006\002\b0J\037\020(\032\0020\b2\027\020J\032\023\022\004\022\0020K\022\004\022\0020\b0\004¢\006\002\b0J\037\020*\032\0020\b2\027\020L\032\023\022\004\022\0020M\022\004\022\0020\b0\004¢\006\002\b0R&\020\003\032\032\022\016\022\f0\005R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020\t\032\032\022\016\022\f0\nR\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020\013\032\032\022\016\022\f0\fR\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020\r\032\032\022\016\022\f0\016R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020\017\032\032\022\016\022\f0\020R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020\021\032\032\022\016\022\f0\022R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R\036\020\023\032\004\030\0010\024X\016¢\006\020\n\002\020\031\032\004\b\025\020\026\"\004\b\027\020\030R\016\020\032\032\0020\024X\016¢\006\002\n\000R\020\020\033\032\004\030\0010\034X\016¢\006\002\n\000R&\020\035\032\032\022\016\022\f0\036R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R\024\020\037\032\b\022\004\022\0020!0 X\016¢\006\002\n\000R&\020\"\032\032\022\016\022\f0#R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020$\032\032\022\016\022\f0%R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020&\032\032\022\016\022\f0'R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020(\032\032\022\016\022\f0)R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000R&\020*\032\032\022\016\022\f0+R\b\022\004\022\0020\0070\006\022\004\022\0020\b\030\0010\004X\016¢\006\002\n\000¨\006N"}, d2 = {"Lorg/springframework/security/config/annotation/web/HeadersDsl;", "", "()V", "cacheControl", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CacheControlConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "contentSecurityPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ContentSecurityPolicyConfig;", "contentTypeOptions", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ContentTypeOptionsConfig;", "crossOriginEmbedderPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CrossOriginEmbedderPolicyConfig;", "crossOriginOpenerPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CrossOriginOpenerPolicyConfig;", "crossOriginResourcePolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$CrossOriginResourcePolicyConfig;", "defaultsDisabled", "", "getDefaultsDisabled", "()Ljava/lang/Boolean;", "setDefaultsDisabled", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "disabled", "featurePolicyDirectives", "", "frameOptions", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$FrameOptionsConfig;", "headerWriters", "", "Lorg/springframework/security/web/header/HeaderWriter;", "hpkp", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HpkpConfig;", "hsts", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HstsConfig;", "permissionsPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$PermissionsPolicyConfig;", "referrerPolicy", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$ReferrerPolicyConfig;", "xssProtection", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$XXssConfig;", "addHeaderWriter", "headerWriter", "cacheControlConfig", "Lorg/springframework/security/config/annotation/web/headers/CacheControlDsl;", "Lkotlin/ExtensionFunctionType;", "contentSecurityPolicyConfig", "Lorg/springframework/security/config/annotation/web/headers/ContentSecurityPolicyDsl;", "contentTypeOptionsConfig", "Lorg/springframework/security/config/annotation/web/headers/ContentTypeOptionsDsl;", "crossOriginEmbedderPolicyConfig", "Lorg/springframework/security/config/annotation/web/headers/CrossOriginEmbedderPolicyDsl;", "crossOriginOpenerPolicyConfig", "Lorg/springframework/security/config/annotation/web/headers/CrossOriginOpenerPolicyDsl;", "crossOriginResourcePolicyConfig", "Lorg/springframework/security/config/annotation/web/headers/CrossOriginResourcePolicyDsl;", "disable", "featurePolicy", "policyDirectives", "frameOptionsConfig", "Lorg/springframework/security/config/annotation/web/headers/FrameOptionsDsl;", "get", "get$spring_security_config", "httpPublicKeyPinning", "hpkpConfig", "Lorg/springframework/security/config/annotation/web/headers/HttpPublicKeyPinningDsl;", "httpStrictTransportSecurity", "hstsConfig", "Lorg/springframework/security/config/annotation/web/headers/HttpStrictTransportSecurityDsl;", "permissionsPolicyConfig", "Lorg/springframework/security/config/annotation/web/headers/PermissionsPolicyDsl;", "referrerPolicyConfig", "Lorg/springframework/security/config/annotation/web/headers/ReferrerPolicyDsl;", "xssProtectionConfig", "Lorg/springframework/security/config/annotation/web/headers/XssProtectionConfigDsl;", "spring-security-config"})
/*     */ public final class HeadersDsl {
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.ContentTypeOptionsConfig, Unit> contentTypeOptions;
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.XXssConfig, Unit> xssProtection;
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.CacheControlConfig, Unit> cacheControl;
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.HstsConfig, Unit> hsts;
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.FrameOptionsConfig, Unit> frameOptions;
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.HpkpConfig, Unit> hpkp;
/*     */   @Nullable
/*     */   private Function1<? super HeadersConfigurer<HttpSecurity>.ContentSecurityPolicyConfig, Unit> contentSecurityPolicy;
/*     */   @NotNull
/*  49 */   private List<HeaderWriter> headerWriters = new ArrayList<>(); @Nullable private Function1<? super HeadersConfigurer<HttpSecurity>.ReferrerPolicyConfig, Unit> referrerPolicy; @Nullable private String featurePolicyDirectives; @Nullable private Function1<? super HeadersConfigurer<HttpSecurity>.PermissionsPolicyConfig, Unit> permissionsPolicy; @Nullable private Function1<? super HeadersConfigurer<HttpSecurity>.CrossOriginOpenerPolicyConfig, Unit> crossOriginOpenerPolicy; @Nullable private Function1<? super HeadersConfigurer<HttpSecurity>.CrossOriginEmbedderPolicyConfig, Unit> crossOriginEmbedderPolicy; @Nullable private Function1<? super HeadersConfigurer<HttpSecurity>.CrossOriginResourcePolicyConfig, Unit> crossOriginResourcePolicy; private boolean disabled; @Nullable
/*     */   private Boolean defaultsDisabled; @Nullable
/*  51 */   public final Boolean getDefaultsDisabled() { return this.defaultsDisabled; } public final void setDefaultsDisabled(@Nullable Boolean <set-?>) { this.defaultsDisabled = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void contentTypeOptions(@NotNull Function1 contentTypeOptionsConfig) {
/*  61 */     Intrinsics.checkNotNullParameter(contentTypeOptionsConfig, "contentTypeOptionsConfig"); ContentTypeOptionsDsl contentTypeOptionsDsl = new ContentTypeOptionsDsl(); contentTypeOptionsConfig.invoke(contentTypeOptionsDsl); this.contentTypeOptions = contentTypeOptionsDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void xssProtection(@NotNull Function1 xssProtectionConfig) {
/*  76 */     Intrinsics.checkNotNullParameter(xssProtectionConfig, "xssProtectionConfig"); XssProtectionConfigDsl xssProtectionConfigDsl = new XssProtectionConfigDsl(); xssProtectionConfig.invoke(xssProtectionConfigDsl); this.xssProtection = xssProtectionConfigDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void cacheControl(@NotNull Function1 cacheControlConfig) {
/*  91 */     Intrinsics.checkNotNullParameter(cacheControlConfig, "cacheControlConfig"); CacheControlDsl cacheControlDsl = new CacheControlDsl(); cacheControlConfig.invoke(cacheControlDsl); this.cacheControl = cacheControlDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void httpStrictTransportSecurity(@NotNull Function1 hstsConfig) {
/* 102 */     Intrinsics.checkNotNullParameter(hstsConfig, "hstsConfig"); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = new HttpStrictTransportSecurityDsl(); hstsConfig.invoke(httpStrictTransportSecurityDsl); this.hsts = httpStrictTransportSecurityDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void frameOptions(@NotNull Function1 frameOptionsConfig) {
/* 112 */     Intrinsics.checkNotNullParameter(frameOptionsConfig, "frameOptionsConfig"); FrameOptionsDsl frameOptionsDsl = new FrameOptionsDsl(); frameOptionsConfig.invoke(frameOptionsDsl); this.frameOptions = frameOptionsDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "as of 5.8 with no replacement")
/*     */   public final void httpPublicKeyPinning(@NotNull Function1 hpkpConfig) {
/* 124 */     Intrinsics.checkNotNullParameter(hpkpConfig, "hpkpConfig"); HttpPublicKeyPinningDsl httpPublicKeyPinningDsl = new HttpPublicKeyPinningDsl(); hpkpConfig.invoke(httpPublicKeyPinningDsl); this.hpkp = httpPublicKeyPinningDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void contentSecurityPolicy(@NotNull Function1 contentSecurityPolicyConfig) {
/* 138 */     Intrinsics.checkNotNullParameter(contentSecurityPolicyConfig, "contentSecurityPolicyConfig"); ContentSecurityPolicyDsl contentSecurityPolicyDsl = new ContentSecurityPolicyDsl(); contentSecurityPolicyConfig.invoke(contentSecurityPolicyDsl); this.contentSecurityPolicy = contentSecurityPolicyDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void referrerPolicy(@NotNull Function1 referrerPolicyConfig) {
/* 155 */     Intrinsics.checkNotNullParameter(referrerPolicyConfig, "referrerPolicyConfig"); ReferrerPolicyDsl referrerPolicyDsl = new ReferrerPolicyDsl(); referrerPolicyConfig.invoke(referrerPolicyDsl); this.referrerPolicy = referrerPolicyDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(message = "Use 'permissionsPolicy { }' instead.")
/*     */   public final void featurePolicy(@NotNull String policyDirectives) {
/* 171 */     Intrinsics.checkNotNullParameter(policyDirectives, "policyDirectives"); this.featurePolicyDirectives = policyDirectives;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void permissionsPolicy(@NotNull Function1 permissionsPolicyConfig) {
/* 186 */     Intrinsics.checkNotNullParameter(permissionsPolicyConfig, "permissionsPolicyConfig"); PermissionsPolicyDsl permissionsPolicyDsl = new PermissionsPolicyDsl(); permissionsPolicyConfig.invoke(permissionsPolicyDsl); this.permissionsPolicy = permissionsPolicyDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void crossOriginOpenerPolicy(@NotNull Function1 crossOriginOpenerPolicyConfig) {
/* 202 */     Intrinsics.checkNotNullParameter(crossOriginOpenerPolicyConfig, "crossOriginOpenerPolicyConfig"); CrossOriginOpenerPolicyDsl crossOriginOpenerPolicyDsl = new CrossOriginOpenerPolicyDsl(); crossOriginOpenerPolicyConfig.invoke(crossOriginOpenerPolicyDsl); this.crossOriginOpenerPolicy = crossOriginOpenerPolicyDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void crossOriginEmbedderPolicy(@NotNull Function1 crossOriginEmbedderPolicyConfig) {
/* 218 */     Intrinsics.checkNotNullParameter(crossOriginEmbedderPolicyConfig, "crossOriginEmbedderPolicyConfig"); CrossOriginEmbedderPolicyDsl crossOriginEmbedderPolicyDsl = new CrossOriginEmbedderPolicyDsl(); crossOriginEmbedderPolicyConfig.invoke(crossOriginEmbedderPolicyDsl); this.crossOriginEmbedderPolicy = crossOriginEmbedderPolicyDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void crossOriginResourcePolicy(@NotNull Function1 crossOriginResourcePolicyConfig) {
/* 234 */     Intrinsics.checkNotNullParameter(crossOriginResourcePolicyConfig, "crossOriginResourcePolicyConfig"); CrossOriginResourcePolicyDsl crossOriginResourcePolicyDsl = new CrossOriginResourcePolicyDsl(); crossOriginResourcePolicyConfig.invoke(crossOriginResourcePolicyDsl); this.crossOriginResourcePolicy = crossOriginResourcePolicyDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addHeaderWriter(@NotNull HeaderWriter headerWriter) {
/* 244 */     Intrinsics.checkNotNullParameter(headerWriter, "headerWriter"); this.headerWriters.add(headerWriter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void disable() {
/* 253 */     this.disabled = true;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final Function1<HeadersConfigurer<HttpSecurity>, Unit> get$spring_security_config() {
/* 258 */     return new HeadersDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "headers", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nHeadersDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HeadersDsl.kt\norg/springframework/security/config/annotation/web/HeadersDsl$get$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,312:1\n1863#2,2:313\n*S KotlinDebug\n*F\n+ 1 HeadersDsl.kt\norg/springframework/security/config/annotation/web/HeadersDsl$get$1\n*L\n303#1:313,2\n*E\n"})
/* 259 */   static final class HeadersDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>, Unit> { public final void invoke(HeadersConfigurer headers) { Intrinsics.checkNotNullParameter(headers, "headers"); Boolean bool = HeadersDsl.this.getDefaultsDisabled(); HeadersDsl headersDsl = HeadersDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-HeadersDsl$get$1$1 = 0;
/* 260 */       Intrinsics.checkNotNull(headersDsl.getDefaultsDisabled()); if (headersDsl.getDefaultsDisabled().booleanValue()) {
/* 261 */         headers.defaultsDisabled();
/*     */       }
/*     */       HeadersDsl.this.getDefaultsDisabled();
/* 264 */       Function1 function12 = HeadersDsl.this.contentTypeOptions; headersDsl = HeadersDsl.this; Function1 function13 = function12; int $i$a$-also-HeadersDsl$get$1$2 = 0;
/* 265 */       headersDsl.contentTypeOptions; headers.contentTypeOptions((headersDsl.contentTypeOptions != null) ? headersDsl.contentTypeOptions::invoke$lambda$2$lambda$1 : null);
/*     */       HeadersDsl.this.contentTypeOptions;
/* 267 */       function12 = HeadersDsl.this.xssProtection; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$3 = 0;
/* 268 */       headersDsl.xssProtection; headers.xssProtection((headersDsl.xssProtection != null) ? headersDsl.xssProtection::invoke$lambda$4$lambda$3 : null);
/*     */       HeadersDsl.this.xssProtection;
/* 270 */       function12 = HeadersDsl.this.cacheControl; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$4 = 0;
/* 271 */       headersDsl.cacheControl; headers.cacheControl((headersDsl.cacheControl != null) ? headersDsl.cacheControl::invoke$lambda$6$lambda$5 : null);
/*     */       HeadersDsl.this.cacheControl;
/* 273 */       function12 = HeadersDsl.this.hsts; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$5 = 0;
/* 274 */       headersDsl.hsts; headers.httpStrictTransportSecurity((headersDsl.hsts != null) ? headersDsl.hsts::invoke$lambda$8$lambda$7 : null);
/*     */       HeadersDsl.this.hsts;
/* 276 */       function12 = HeadersDsl.this.frameOptions; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$6 = 0;
/* 277 */       headersDsl.frameOptions; headers.frameOptions((headersDsl.frameOptions != null) ? headersDsl.frameOptions::invoke$lambda$10$lambda$9 : null);
/*     */       HeadersDsl.this.frameOptions;
/* 279 */       function12 = HeadersDsl.this.hpkp; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$7 = 0;
/* 280 */       headersDsl.hpkp; headers.httpPublicKeyPinning((headersDsl.hpkp != null) ? headersDsl.hpkp::invoke$lambda$12$lambda$11 : null);
/*     */       HeadersDsl.this.hpkp;
/* 282 */       function12 = HeadersDsl.this.contentSecurityPolicy; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$8 = 0;
/* 283 */       headersDsl.contentSecurityPolicy; headers.contentSecurityPolicy((headersDsl.contentSecurityPolicy != null) ? headersDsl.contentSecurityPolicy::invoke$lambda$14$lambda$13 : null);
/*     */       HeadersDsl.this.contentSecurityPolicy;
/* 285 */       function12 = HeadersDsl.this.referrerPolicy; headersDsl = HeadersDsl.this; function13 = function12; int $i$a$-also-HeadersDsl$get$1$9 = 0;
/* 286 */       headersDsl.referrerPolicy; headers.referrerPolicy((headersDsl.referrerPolicy != null) ? headersDsl.referrerPolicy::invoke$lambda$16$lambda$15 : null);
/*     */       HeadersDsl.this.referrerPolicy;
/* 288 */       String str1 = HeadersDsl.this.featurePolicyDirectives; headersDsl = HeadersDsl.this; String str2 = str1; int $i$a$-also-HeadersDsl$get$1$10 = 0;
/* 289 */       headers.featurePolicy(headersDsl.featurePolicyDirectives);
/*     */       HeadersDsl.this.featurePolicyDirectives;
/* 291 */       Function1 function11 = HeadersDsl.this.permissionsPolicy; headersDsl = HeadersDsl.this; Function1 it = function11; int $i$a$-also-HeadersDsl$get$1$11 = 0;
/* 292 */       headersDsl.permissionsPolicy; headers.permissionsPolicy((headersDsl.permissionsPolicy != null) ? headersDsl.permissionsPolicy::invoke$lambda$19$lambda$18 : null);
/*     */       HeadersDsl.this.permissionsPolicy;
/* 294 */       function11 = HeadersDsl.this.crossOriginOpenerPolicy; headersDsl = HeadersDsl.this; it = function11; int $i$a$-also-HeadersDsl$get$1$12 = 0;
/* 295 */       headersDsl.crossOriginOpenerPolicy; headers.crossOriginOpenerPolicy((headersDsl.crossOriginOpenerPolicy != null) ? headersDsl.crossOriginOpenerPolicy::invoke$lambda$21$lambda$20 : null);
/*     */       HeadersDsl.this.crossOriginOpenerPolicy;
/* 297 */       function11 = HeadersDsl.this.crossOriginEmbedderPolicy; headersDsl = HeadersDsl.this; it = function11; int $i$a$-also-HeadersDsl$get$1$13 = 0;
/* 298 */       headersDsl.crossOriginEmbedderPolicy; headers.crossOriginEmbedderPolicy((headersDsl.crossOriginEmbedderPolicy != null) ? headersDsl.crossOriginEmbedderPolicy::invoke$lambda$23$lambda$22 : null);
/*     */       HeadersDsl.this.crossOriginEmbedderPolicy;
/* 300 */       function11 = HeadersDsl.this.crossOriginResourcePolicy; headersDsl = HeadersDsl.this; it = function11; int $i$a$-also-HeadersDsl$get$1$14 = 0;
/* 301 */       headersDsl.crossOriginResourcePolicy; headers.crossOriginResourcePolicy((headersDsl.crossOriginResourcePolicy != null) ? headersDsl.crossOriginResourcePolicy::invoke$lambda$25$lambda$24 : null);
/*     */       HeadersDsl.this.crossOriginResourcePolicy;
/* 303 */       Iterable $this$forEach$iv = HeadersDsl.this.headerWriters; int $i$f$forEach = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 313 */       Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); HeaderWriter headerWriter = (HeaderWriter)element$iv; int $i$a$-forEach-HeadersDsl$get$1$15 = 0;
/*     */         headers.addHeaderWriter(headerWriter); }
/*     */       
/*     */       if (HeadersDsl.this.disabled)
/*     */         headers.disable();  }
/*     */ 
/*     */     
/*     */     private static final void invoke$lambda$2$lambda$1(Function1 $tmp0, HeadersConfigurer.ContentTypeOptionsConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$4$lambda$3(Function1 $tmp0, HeadersConfigurer.XXssConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$6$lambda$5(Function1 $tmp0, HeadersConfigurer.CacheControlConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$8$lambda$7(Function1 $tmp0, HeadersConfigurer.HstsConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$10$lambda$9(Function1 $tmp0, HeadersConfigurer.FrameOptionsConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$12$lambda$11(Function1 $tmp0, HeadersConfigurer.HpkpConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$14$lambda$13(Function1 $tmp0, HeadersConfigurer.ContentSecurityPolicyConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$16$lambda$15(Function1 $tmp0, HeadersConfigurer.ReferrerPolicyConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$19$lambda$18(Function1 $tmp0, HeadersConfigurer.PermissionsPolicyConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$21$lambda$20(Function1 $tmp0, HeadersConfigurer.CrossOriginOpenerPolicyConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$23$lambda$22(Function1 $tmp0, HeadersConfigurer.CrossOriginEmbedderPolicyConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$25$lambda$24(Function1 $tmp0, HeadersConfigurer.CrossOriginResourcePolicyConfig t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     HeadersDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\HeadersDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */