/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*    */ import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
/*    */ import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
/*    */ import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
/*    */ import org.springframework.security.oauth2.core.oidc.user.OidcUser;
/*    */ import org.springframework.security.oauth2.core.user.OAuth2User;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "userInfoEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$UserInfoEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nUserInfoEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UserInfoEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/UserInfoEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,54:1\n1#2:55\n*E\n"})
/*    */ final class UserInfoEndpointDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OAuth2LoginConfigurer<HttpSecurity>.UserInfoEndpointConfig, Unit>
/*    */ {
/*    */   public final void invoke(OAuth2LoginConfigurer.UserInfoEndpointConfig userInfoEndpoint) {
/* 48 */     Intrinsics.checkNotNullParameter(userInfoEndpoint, "userInfoEndpoint"); if (UserInfoEndpointDsl.this.getUserService() != null) { OAuth2UserService<OAuth2UserRequest, OAuth2User> oAuth2UserService1 = UserInfoEndpointDsl.this.getUserService(); UserInfoEndpointDsl userInfoEndpointDsl = UserInfoEndpointDsl.this; OAuth2UserService<OAuth2UserRequest, OAuth2User> it = oAuth2UserService1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       int $i$a$-also-UserInfoEndpointDsl$get$1$1 = 0; userInfoEndpoint.userService(userInfoEndpointDsl.getUserService()); } else { UserInfoEndpointDsl.this.getUserService(); }  if (UserInfoEndpointDsl.this.getOidcUserService() != null) { OAuth2UserService<OidcUserRequest, OidcUser> oAuth2UserService1 = UserInfoEndpointDsl.this.getOidcUserService(); UserInfoEndpointDsl userInfoEndpointDsl = UserInfoEndpointDsl.this; OAuth2UserService<OidcUserRequest, OidcUser> it = oAuth2UserService1; int $i$a$-also-UserInfoEndpointDsl$get$1$2 = 0; userInfoEndpoint.oidcUserService(userInfoEndpointDsl.getOidcUserService()); } else { UserInfoEndpointDsl.this.getOidcUserService(); }  if (UserInfoEndpointDsl.this.getUserAuthoritiesMapper() != null) { GrantedAuthoritiesMapper grantedAuthoritiesMapper1 = UserInfoEndpointDsl.this.getUserAuthoritiesMapper(); UserInfoEndpointDsl userInfoEndpointDsl = UserInfoEndpointDsl.this; GrantedAuthoritiesMapper it = grantedAuthoritiesMapper1; int $i$a$-also-UserInfoEndpointDsl$get$1$3 = 0;
/*    */       userInfoEndpoint.userAuthoritiesMapper(userInfoEndpointDsl.getUserAuthoritiesMapper()); }
/*    */     else
/*    */     { UserInfoEndpointDsl.this.getUserAuthoritiesMapper(); }
/*    */   
/*    */   }
/*    */   
/*    */   UserInfoEndpointDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\UserInfoEndpointDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */