/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.web.PortMapper;
/*     */ import org.springframework.security.web.PortMapperImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PortMapperConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<PortMapperConfigurer<H>, H>
/*     */ {
/*     */   private PortMapper portMapper;
/*  40 */   private Map<String, String> httpsPortMappings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PortMapperConfigurer<H> portMapper(PortMapper portMapper) {
/*  54 */     this.portMapper = portMapper;
/*  55 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpPortMapping http(int httpPort) {
/*  64 */     return new HttpPortMapping(httpPort);
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/*  69 */     http.setSharedObject(PortMapper.class, getPortMapper());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PortMapper getPortMapper() {
/*  79 */     if (this.portMapper == null) {
/*  80 */       PortMapperImpl portMapper = new PortMapperImpl();
/*  81 */       portMapper.setPortMappings(this.httpsPortMappings);
/*  82 */       this.portMapper = (PortMapper)portMapper;
/*     */     } 
/*  84 */     return this.portMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class HttpPortMapping
/*     */   {
/*     */     private final int httpPort;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private HttpPortMapping(int httpPort) {
/* 104 */       this.httpPort = httpPort;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PortMapperConfigurer<H> mapsTo(int httpsPort) {
/* 113 */       PortMapperConfigurer.this.httpsPortMappings.put(String.valueOf(this.httpPort), String.valueOf(httpsPort));
/* 114 */       return PortMapperConfigurer.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\PortMapperConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */