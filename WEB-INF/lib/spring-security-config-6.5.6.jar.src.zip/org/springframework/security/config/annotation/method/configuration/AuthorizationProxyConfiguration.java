/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.springframework.aop.framework.AopInfrastructureBean;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.security.aot.hint.AuthorizeReturnObjectCoreHintsRegistrar;
/*    */ import org.springframework.security.aot.hint.SecurityHintsRegistrar;
/*    */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*    */ import org.springframework.security.authorization.method.AuthorizationAdvisor;
/*    */ import org.springframework.security.authorization.method.AuthorizationAdvisorProxyFactory;
/*    */ import org.springframework.security.authorization.method.AuthorizeReturnObjectMethodInterceptor;
/*    */ import org.springframework.security.config.Customizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ final class AuthorizationProxyConfiguration
/*    */   implements AopInfrastructureBean
/*    */ {
/*    */   @Bean
/*    */   @Role(2)
/*    */   static AuthorizationAdvisorProxyFactory authorizationProxyFactory(ObjectProvider<AuthorizationAdvisor> authorizationAdvisors, ObjectProvider<AuthorizationAdvisorProxyFactory.TargetVisitor> targetVisitors, ObjectProvider<Customizer<AuthorizationAdvisorProxyFactory>> customizers) {
/* 47 */     List<AuthorizationAdvisor> advisors = new ArrayList<>();
/* 48 */     Objects.requireNonNull(advisors); authorizationAdvisors.forEach(advisors::add);
/* 49 */     List<AuthorizationAdvisorProxyFactory.TargetVisitor> visitors = new ArrayList<>();
/* 50 */     Objects.requireNonNull(visitors); targetVisitors.orderedStream().forEach(visitors::add);
/* 51 */     visitors.add(AuthorizationAdvisorProxyFactory.TargetVisitor.defaults());
/* 52 */     AuthorizationAdvisorProxyFactory factory = new AuthorizationAdvisorProxyFactory(advisors);
/* 53 */     factory.setTargetVisitor(AuthorizationAdvisorProxyFactory.TargetVisitor.of((AuthorizationAdvisorProxyFactory.TargetVisitor[])visitors.toArray(x$0 -> new AuthorizationAdvisorProxyFactory.TargetVisitor[x$0])));
/* 54 */     customizers.forEach(c -> c.customize(factory));
/* 55 */     return factory;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static MethodInterceptor authorizeReturnObjectMethodInterceptor() {
/* 61 */     return (MethodInterceptor)new AuthorizeReturnObjectMethodInterceptor();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   static SecurityHintsRegistrar authorizeReturnObjectHintsRegistrar(AuthorizationProxyFactory proxyFactory) {
/* 67 */     return (SecurityHintsRegistrar)new AuthorizeReturnObjectCoreHintsRegistrar(proxyFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\AuthorizationProxyConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */