package org.springframework.security.config.annotation.web;

import jakarta.servlet.Filter;
import org.springframework.security.config.annotation.SecurityConfigurer;

public interface WebSecurityConfigurer<T extends org.springframework.security.config.annotation.SecurityBuilder<Filter>> extends SecurityConfigurer<Filter, T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\WebSecurityConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */