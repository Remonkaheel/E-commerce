/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.ObjectPostProcessor;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;
/*     */ import org.springframework.security.web.access.expression.ExpressionBasedFilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.access.expression.WebExpressionVoter;
/*     */ import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ExpressionUrlAuthorizationConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractInterceptUrlConfigurer<ExpressionUrlAuthorizationConfigurer<H>, H>
/*     */ {
/*     */   static final String permitAll = "permitAll";
/*     */   private static final String denyAll = "denyAll";
/*     */   private static final String anonymous = "anonymous";
/*     */   private static final String authenticated = "authenticated";
/*     */   private static final String fullyAuthenticated = "fullyAuthenticated";
/*     */   private static final String rememberMe = "rememberMe";
/*     */   private final String rolePrefix;
/*     */   private final ExpressionInterceptUrlRegistry REGISTRY;
/*     */   private SecurityExpressionHandler<FilterInvocation> expressionHandler;
/*     */   
/*     */   public ExpressionUrlAuthorizationConfigurer(ApplicationContext context) {
/* 111 */     GrantedAuthorityDefaults grantedAuthorityDefaults = (GrantedAuthorityDefaults)context.getBeanProvider(GrantedAuthorityDefaults.class).getIfUnique();
/* 112 */     if (grantedAuthorityDefaults != null) {
/* 113 */       this.rolePrefix = grantedAuthorityDefaults.getRolePrefix();
/*     */     } else {
/*     */       
/* 116 */       this.rolePrefix = "ROLE_";
/*     */     } 
/* 118 */     this.REGISTRY = new ExpressionInterceptUrlRegistry(context);
/*     */   }
/*     */   
/*     */   public ExpressionInterceptUrlRegistry getRegistry() {
/* 122 */     return this.REGISTRY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void interceptUrl(Iterable<? extends RequestMatcher> requestMatchers, Collection<ConfigAttribute> configAttributes) {
/* 135 */     for (RequestMatcher requestMatcher : requestMatchers) {
/* 136 */       this.REGISTRY.addMapping(new AbstractConfigAttributeRequestMatcherRegistry.UrlMapping(requestMatcher, configAttributes));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<AccessDecisionVoter<?>> getDecisionVoters(H http) {
/* 144 */     List<AccessDecisionVoter<?>> decisionVoters = new ArrayList<>();
/* 145 */     WebExpressionVoter expressionVoter = new WebExpressionVoter();
/* 146 */     expressionVoter.setExpressionHandler(getExpressionHandler(http));
/* 147 */     decisionVoters.add(expressionVoter);
/* 148 */     return decisionVoters;
/*     */   }
/*     */ 
/*     */   
/*     */   ExpressionBasedFilterInvocationSecurityMetadataSource createMetadataSource(H http) {
/* 153 */     LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap = this.REGISTRY.createRequestMap();
/* 154 */     Assert.state(!requestMap.isEmpty(), "At least one mapping is required (i.e. authorizeRequests().anyRequest().authenticated())");
/*     */     
/* 156 */     return new ExpressionBasedFilterInvocationSecurityMetadataSource(requestMap, getExpressionHandler(http));
/*     */   }
/*     */   
/*     */   private SecurityExpressionHandler<FilterInvocation> getExpressionHandler(H http) {
/* 160 */     if (this.expressionHandler != null) {
/* 161 */       return this.expressionHandler;
/*     */     }
/* 163 */     DefaultWebSecurityExpressionHandler defaultHandler = new DefaultWebSecurityExpressionHandler();
/* 164 */     AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)http.getSharedObject(AuthenticationTrustResolver.class);
/* 165 */     if (trustResolver != null) {
/* 166 */       defaultHandler.setTrustResolver(trustResolver);
/*     */     }
/* 168 */     ApplicationContext context = (ApplicationContext)http.getSharedObject(ApplicationContext.class);
/* 169 */     if (context != null) {
/* 170 */       Objects.requireNonNull(defaultHandler); context.getBeanProvider(RoleHierarchy.class).ifUnique(defaultHandler::setRoleHierarchy);
/* 171 */       context.getBeanProvider(GrantedAuthorityDefaults.class)
/* 172 */         .ifUnique(grantedAuthorityDefaults -> defaultHandler.setDefaultRolePrefix(grantedAuthorityDefaults.getRolePrefix()));
/*     */       
/* 174 */       Objects.requireNonNull(defaultHandler); context.getBeanProvider(PermissionEvaluator.class).ifUnique(defaultHandler::setPermissionEvaluator);
/*     */     } 
/* 176 */     this.expressionHandler = (SecurityExpressionHandler<FilterInvocation>)postProcess(defaultHandler);
/* 177 */     return this.expressionHandler;
/*     */   }
/*     */   
/*     */   private static String hasAnyRole(String rolePrefix, String... authorities) {
/* 181 */     String anyAuthorities = StringUtils.arrayToDelimitedString((Object[])authorities, "','" + rolePrefix);
/* 182 */     return "hasAnyRole('" + rolePrefix + anyAuthorities + "')";
/*     */   }
/*     */   
/*     */   private static String hasRole(String rolePrefix, String role) {
/* 186 */     Assert.notNull(role, "role cannot be null");
/* 187 */     Assert.isTrue((rolePrefix.isEmpty() || !role.startsWith(rolePrefix)), () -> "role should not start with '" + rolePrefix + "' since it is automatically inserted. Got '" + role + "'");
/*     */     
/* 189 */     return "hasRole('" + rolePrefix + role + "')";
/*     */   }
/*     */   
/*     */   private static String hasAuthority(String authority) {
/* 193 */     return "hasAuthority('" + authority + "')";
/*     */   }
/*     */   
/*     */   private static String hasAnyAuthority(String... authorities) {
/* 197 */     String anyAuthorities = StringUtils.arrayToDelimitedString((Object[])authorities, "','");
/* 198 */     return "hasAnyAuthority('" + anyAuthorities + "')";
/*     */   }
/*     */   
/*     */   private static String hasIpAddress(String ipAddressExpression) {
/* 202 */     return "hasIpAddress('" + ipAddressExpression + "')";
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final class ExpressionInterceptUrlRegistry
/*     */     extends AbstractInterceptUrlConfigurer<ExpressionUrlAuthorizationConfigurer<H>, H>.AbstractInterceptUrlRegistry<ExpressionInterceptUrlRegistry, AuthorizedUrl>
/*     */   {
/*     */     private ExpressionInterceptUrlRegistry(ApplicationContext context) {
/* 210 */       setApplicationContext(context);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionUrlAuthorizationConfigurer<H>.AuthorizedUrl chainRequestMatchersInternal(List<RequestMatcher> requestMatchers) {
/* 215 */       return new ExpressionUrlAuthorizationConfigurer.AuthorizedUrl(requestMatchers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionInterceptUrlRegistry expressionHandler(SecurityExpressionHandler<FilterInvocation> expressionHandler) {
/* 227 */       ExpressionUrlAuthorizationConfigurer.this.expressionHandler = expressionHandler;
/* 228 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionInterceptUrlRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 238 */       ExpressionUrlAuthorizationConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 239 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated(since = "6.4", forRemoval = true)
/*     */     public ExpressionInterceptUrlRegistry withObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 248 */       ExpressionUrlAuthorizationConfigurer.this.addObjectPostProcessor(objectPostProcessor);
/* 249 */       return this;
/*     */     }
/*     */     
/*     */     public H and() {
/* 253 */       return (H)ExpressionUrlAuthorizationConfigurer.this.and();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class AuthorizedUrl
/*     */   {
/*     */     private List<? extends RequestMatcher> requestMatchers;
/*     */ 
/*     */     
/*     */     private boolean not;
/*     */ 
/*     */ 
/*     */     
/*     */     AuthorizedUrl(List<? extends RequestMatcher> requestMatchers) {
/* 269 */       this.requestMatchers = requestMatchers;
/*     */     }
/*     */     
/*     */     protected List<? extends RequestMatcher> getMatchers() {
/* 273 */       return this.requestMatchers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizedUrl not() {
/* 282 */       this.not = true;
/* 283 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry hasRole(String role) {
/* 296 */       return access(
/* 297 */           ExpressionUrlAuthorizationConfigurer.hasRole(ExpressionUrlAuthorizationConfigurer.this.rolePrefix, role));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry hasAnyRole(String... roles) {
/* 310 */       return access(
/* 311 */           ExpressionUrlAuthorizationConfigurer.hasAnyRole(ExpressionUrlAuthorizationConfigurer.this.rolePrefix, roles));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry hasAuthority(String authority) {
/* 321 */       return access(ExpressionUrlAuthorizationConfigurer.hasAuthority(authority));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry hasAnyAuthority(String... authorities) {
/* 333 */       return access(ExpressionUrlAuthorizationConfigurer.hasAnyAuthority(authorities));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry hasIpAddress(String ipaddressExpression) {
/* 344 */       return access(ExpressionUrlAuthorizationConfigurer.hasIpAddress(ipaddressExpression));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry permitAll() {
/* 353 */       return access("permitAll");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry anonymous() {
/* 362 */       return access("anonymous");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry rememberMe() {
/* 372 */       return access("rememberMe");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry denyAll() {
/* 381 */       return access("denyAll");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry authenticated() {
/* 390 */       return access("authenticated");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry fullyAuthenticated() {
/* 401 */       return access("fullyAuthenticated");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExpressionUrlAuthorizationConfigurer<H>.ExpressionInterceptUrlRegistry access(String attribute) {
/* 412 */       if (this.not) {
/* 413 */         attribute = "!" + attribute;
/*     */       }
/* 415 */       ExpressionUrlAuthorizationConfigurer.this.interceptUrl(this.requestMatchers, SecurityConfig.createList(new String[] { attribute }));
/* 416 */       return ExpressionUrlAuthorizationConfigurer.this.REGISTRY;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\ExpressionUrlAuthorizationConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */