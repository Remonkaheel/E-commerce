/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.RequestMatcherFactory;
/*     */ import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
/*     */ import org.springframework.security.web.savedrequest.NullRequestCache;
/*     */ import org.springframework.security.web.savedrequest.RequestCache;
/*     */ import org.springframework.security.web.savedrequest.RequestCacheAwareFilter;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.HeaderContentNegotiationStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestCacheConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<RequestCacheConfigurer<H>, H>
/*     */ {
/*     */   public RequestCacheConfigurer<H> requestCache(RequestCache requestCache) {
/*  89 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(RequestCache.class, requestCache);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public H disable() {
/*  95 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(RequestCache.class, new NullRequestCache());
/*  96 */     return super.disable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(H http) {
/* 101 */     http.setSharedObject(RequestCache.class, getRequestCache(http));
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 106 */     RequestCache requestCache = getRequestCache(http);
/* 107 */     RequestCacheAwareFilter requestCacheFilter = new RequestCacheAwareFilter(requestCache);
/* 108 */     requestCacheFilter = (RequestCacheAwareFilter)postProcess(requestCacheFilter);
/* 109 */     http.addFilter((Filter)requestCacheFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RequestCache getRequestCache(H http) {
/* 121 */     RequestCache result = (RequestCache)http.getSharedObject(RequestCache.class);
/* 122 */     if (result != null) {
/* 123 */       return result;
/*     */     }
/* 125 */     result = getBeanOrNull(RequestCache.class);
/* 126 */     if (result != null) {
/* 127 */       return result;
/*     */     }
/* 129 */     HttpSessionRequestCache defaultCache = new HttpSessionRequestCache();
/* 130 */     defaultCache.setRequestMatcher(createDefaultSavedRequestMatcher(http));
/* 131 */     return (RequestCache)defaultCache;
/*     */   }
/*     */   
/*     */   private <T> T getBeanOrNull(Class<T> type) {
/* 135 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)getBuilder()).getSharedObject(ApplicationContext.class);
/* 136 */     if (context == null) {
/* 137 */       return null;
/*     */     }
/*     */     
/* 140 */     return (T)context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */ 
/*     */   
/*     */   private RequestMatcher createDefaultSavedRequestMatcher(H http) {
/* 145 */     NegatedRequestMatcher negatedRequestMatcher1 = new NegatedRequestMatcher(getFaviconRequestMatcher());
/* 146 */     NegatedRequestMatcher negatedRequestMatcher2 = new NegatedRequestMatcher((RequestMatcher)new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
/*     */     
/* 148 */     boolean isCsrfEnabled = (http.getConfigurer(CsrfConfigurer.class) != null);
/* 149 */     List<RequestMatcher> matchers = new ArrayList<>();
/* 150 */     if (isCsrfEnabled) {
/* 151 */       RequestMatcher getRequests = RequestMatcherFactory.matcher(HttpMethod.GET, "/**");
/* 152 */       matchers.add(0, getRequests);
/*     */     } 
/* 154 */     matchers.add(negatedRequestMatcher1);
/* 155 */     matchers.add(notMatchingMediaType(http, MediaType.APPLICATION_JSON));
/* 156 */     matchers.add(negatedRequestMatcher2);
/* 157 */     matchers.add(notMatchingMediaType(http, MediaType.MULTIPART_FORM_DATA));
/* 158 */     matchers.add(notMatchingMediaType(http, MediaType.TEXT_EVENT_STREAM));
/* 159 */     return (RequestMatcher)new AndRequestMatcher(matchers);
/*     */   }
/*     */   private RequestMatcher notMatchingMediaType(H http, MediaType mediaType) {
/*     */     HeaderContentNegotiationStrategy headerContentNegotiationStrategy;
/* 163 */     ContentNegotiationStrategy contentNegotiationStrategy = (ContentNegotiationStrategy)http.getSharedObject(ContentNegotiationStrategy.class);
/* 164 */     if (contentNegotiationStrategy == null) {
/* 165 */       headerContentNegotiationStrategy = new HeaderContentNegotiationStrategy();
/*     */     }
/* 167 */     MediaTypeRequestMatcher mediaRequest = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { mediaType });
/* 168 */     mediaRequest.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 169 */     return (RequestMatcher)new NegatedRequestMatcher((RequestMatcher)mediaRequest);
/*     */   }
/*     */   
/*     */   private RequestMatcher getFaviconRequestMatcher() {
/* 173 */     if (RequestMatcherFactory.usesPathPatterns()) {
/* 174 */       return RequestMatcherFactory.matcher("/favicon.*");
/*     */     }
/*     */     
/* 177 */     return (RequestMatcher)new AntPathRequestMatcher("/**/favicon.*");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\RequestCacheConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */