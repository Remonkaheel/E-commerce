/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.config.annotation.web.AbstractRequestMatcherRegistry;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractConfigAttributeRequestMatcherRegistry<C>
/*     */   extends AbstractRequestMatcherRegistry<C>
/*     */ {
/*  51 */   private List<UrlMapping> urlMappings = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<RequestMatcher> unmappedMatchers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<UrlMapping> getUrlMappings() {
/*  62 */     return this.urlMappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void addMapping(UrlMapping urlMapping) {
/*  72 */     this.unmappedMatchers = null;
/*  73 */     this.urlMappings.add(urlMapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final C chainRequestMatchers(List<RequestMatcher> requestMatchers) {
/*  85 */     this.unmappedMatchers = requestMatchers;
/*  86 */     return chainRequestMatchersInternal(requestMatchers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract C chainRequestMatchersInternal(List<RequestMatcher> paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void addMapping(int index, UrlMapping urlMapping) {
/* 105 */     this.urlMappings.add(index, urlMapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> createRequestMap() {
/* 115 */     Assert.state((this.unmappedMatchers == null), () -> "An incomplete mapping was found for " + String.valueOf(this.unmappedMatchers) + ". Try completing it with something like requestUrls().<something>.hasRole('USER')");
/*     */     
/* 117 */     LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap = new LinkedHashMap<>();
/* 118 */     for (UrlMapping mapping : getUrlMappings()) {
/* 119 */       RequestMatcher matcher = mapping.getRequestMatcher();
/* 120 */       Collection<ConfigAttribute> configAttrs = mapping.getConfigAttrs();
/* 121 */       requestMap.put(matcher, configAttrs);
/*     */     } 
/* 123 */     return requestMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class UrlMapping
/*     */   {
/*     */     private final RequestMatcher requestMatcher;
/*     */ 
/*     */     
/*     */     private final Collection<ConfigAttribute> configAttrs;
/*     */ 
/*     */     
/*     */     UrlMapping(RequestMatcher requestMatcher, Collection<ConfigAttribute> configAttrs) {
/* 137 */       this.requestMatcher = requestMatcher;
/* 138 */       this.configAttrs = configAttrs;
/*     */     }
/*     */     
/*     */     RequestMatcher getRequestMatcher() {
/* 142 */       return this.requestMatcher;
/*     */     }
/*     */     
/*     */     Collection<ConfigAttribute> getConfigAttrs() {
/* 146 */       return this.configAttrs;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\AbstractConfigAttributeRequestMatcherRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */