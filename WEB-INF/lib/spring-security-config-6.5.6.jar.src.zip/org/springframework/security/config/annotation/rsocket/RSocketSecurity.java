/*     */ package org.springframework.security.config.annotation.rsocket;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.messaging.rsocket.annotation.support.RSocketMessageHandler;
/*     */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*     */ import org.springframework.security.authorization.AuthenticatedReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorityReactiveAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.config.Customizer;
/*     */ import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtReactiveAuthenticationManager;
/*     */ import org.springframework.security.rsocket.api.PayloadInterceptor;
/*     */ import org.springframework.security.rsocket.authentication.AnonymousPayloadInterceptor;
/*     */ import org.springframework.security.rsocket.authentication.AuthenticationPayloadExchangeConverter;
/*     */ import org.springframework.security.rsocket.authentication.AuthenticationPayloadInterceptor;
/*     */ import org.springframework.security.rsocket.authentication.BearerPayloadExchangeConverter;
/*     */ import org.springframework.security.rsocket.authentication.PayloadExchangeAuthenticationConverter;
/*     */ import org.springframework.security.rsocket.authorization.AuthorizationPayloadInterceptor;
/*     */ import org.springframework.security.rsocket.authorization.PayloadExchangeMatcherReactiveAuthorizationManager;
/*     */ import org.springframework.security.rsocket.core.PayloadSocketAcceptorInterceptor;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeAuthorizationContext;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcher;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatcherEntry;
/*     */ import org.springframework.security.rsocket.util.matcher.PayloadExchangeMatchers;
/*     */ import org.springframework.security.rsocket.util.matcher.RoutePayloadExchangeMatcher;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RSocketSecurity
/*     */ {
/* 116 */   private List<PayloadInterceptor> payloadInterceptors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private BasicAuthenticationSpec basicAuthSpec;
/*     */ 
/*     */ 
/*     */   
/*     */   private SimpleAuthenticationSpec simpleAuthSpec;
/*     */ 
/*     */ 
/*     */   
/*     */   private JwtSpec jwtSpec;
/*     */ 
/*     */   
/*     */   private AuthorizePayloadsSpec authorizePayload;
/*     */ 
/*     */   
/*     */   private ApplicationContext context;
/*     */ 
/*     */   
/*     */   private ReactiveAuthenticationManager authenticationManager;
/*     */ 
/*     */ 
/*     */   
/*     */   public RSocketSecurity addPayloadInterceptor(PayloadInterceptor interceptor) {
/* 142 */     this.payloadInterceptors.add(interceptor);
/* 143 */     return this;
/*     */   }
/*     */   
/*     */   public RSocketSecurity authenticationManager(ReactiveAuthenticationManager authenticationManager) {
/* 147 */     this.authenticationManager = authenticationManager;
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RSocketSecurity simpleAuthentication(Customizer<SimpleAuthenticationSpec> simple) {
/* 160 */     if (this.simpleAuthSpec == null) {
/* 161 */       this.simpleAuthSpec = new SimpleAuthenticationSpec();
/*     */     }
/* 163 */     simple.customize(this.simpleAuthSpec);
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public RSocketSecurity basicAuthentication(Customizer<BasicAuthenticationSpec> basic) {
/* 175 */     if (this.basicAuthSpec == null) {
/* 176 */       this.basicAuthSpec = new BasicAuthenticationSpec();
/*     */     }
/* 178 */     basic.customize(this.basicAuthSpec);
/* 179 */     return this;
/*     */   }
/*     */   
/*     */   public RSocketSecurity jwt(Customizer<JwtSpec> jwt) {
/* 183 */     if (this.jwtSpec == null) {
/* 184 */       this.jwtSpec = new JwtSpec();
/*     */     }
/* 186 */     jwt.customize(this.jwtSpec);
/* 187 */     return this;
/*     */   }
/*     */   
/*     */   public RSocketSecurity authorizePayload(Customizer<AuthorizePayloadsSpec> authorize) {
/* 191 */     if (this.authorizePayload == null) {
/* 192 */       this.authorizePayload = new AuthorizePayloadsSpec();
/*     */     }
/* 194 */     authorize.customize(this.authorizePayload);
/* 195 */     return this;
/*     */   }
/*     */   
/*     */   public PayloadSocketAcceptorInterceptor build() {
/* 199 */     PayloadSocketAcceptorInterceptor interceptor = new PayloadSocketAcceptorInterceptor(payloadInterceptors());
/* 200 */     RSocketMessageHandler handler = getBean(RSocketMessageHandler.class);
/* 201 */     interceptor.setDefaultDataMimeType(handler.getDefaultDataMimeType());
/* 202 */     interceptor.setDefaultMetadataMimeType(handler.getDefaultMetadataMimeType());
/* 203 */     return interceptor;
/*     */   }
/*     */   
/*     */   private List<PayloadInterceptor> payloadInterceptors() {
/* 207 */     List<PayloadInterceptor> result = new ArrayList<>(this.payloadInterceptors);
/* 208 */     if (this.basicAuthSpec != null) {
/* 209 */       result.add(this.basicAuthSpec.build());
/*     */     }
/* 211 */     if (this.simpleAuthSpec != null) {
/* 212 */       result.add(this.simpleAuthSpec.build());
/*     */     }
/* 214 */     if (this.jwtSpec != null) {
/* 215 */       result.addAll(this.jwtSpec.build());
/*     */     }
/* 217 */     result.add(anonymous());
/* 218 */     if (this.authorizePayload != null) {
/* 219 */       result.add(this.authorizePayload.build());
/*     */     }
/* 221 */     AnnotationAwareOrderComparator.sort(result);
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   private AnonymousPayloadInterceptor anonymous() {
/* 226 */     AnonymousPayloadInterceptor result = new AnonymousPayloadInterceptor("anonymousUser");
/* 227 */     result.setOrder(PayloadInterceptorOrder.ANONYMOUS.getOrder());
/* 228 */     return result;
/*     */   }
/*     */   
/*     */   private <T> T getBean(Class<T> beanClass) {
/* 232 */     if (this.context == null) {
/* 233 */       return null;
/*     */     }
/* 235 */     return (T)this.context.getBean(beanClass);
/*     */   }
/*     */   
/*     */   private <T> T getBeanOrNull(Class<T> beanClass) {
/* 239 */     return getBeanOrNull(ResolvableType.forClass(beanClass));
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T getBeanOrNull(ResolvableType type) {
/* 244 */     if (this.context == null) {
/* 245 */       return null;
/*     */     }
/* 247 */     return (T)this.context.getBeanProvider(type).getIfUnique();
/*     */   }
/*     */   
/*     */   protected void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 251 */     this.context = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class SimpleAuthenticationSpec
/*     */   {
/*     */     private ReactiveAuthenticationManager authenticationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SimpleAuthenticationSpec authenticationManager(ReactiveAuthenticationManager authenticationManager) {
/* 265 */       this.authenticationManager = authenticationManager;
/* 266 */       return this;
/*     */     }
/*     */     
/*     */     private ReactiveAuthenticationManager getAuthenticationManager() {
/* 270 */       if (this.authenticationManager == null) {
/* 271 */         return RSocketSecurity.this.authenticationManager;
/*     */       }
/* 273 */       return this.authenticationManager;
/*     */     }
/*     */     
/*     */     protected AuthenticationPayloadInterceptor build() {
/* 277 */       ReactiveAuthenticationManager manager = getAuthenticationManager();
/* 278 */       AuthenticationPayloadInterceptor result = new AuthenticationPayloadInterceptor(manager);
/* 279 */       result.setAuthenticationConverter((PayloadExchangeAuthenticationConverter)new AuthenticationPayloadExchangeConverter());
/* 280 */       result.setOrder(PayloadInterceptorOrder.AUTHENTICATION.getOrder());
/* 281 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class BasicAuthenticationSpec
/*     */   {
/*     */     private ReactiveAuthenticationManager authenticationManager;
/*     */ 
/*     */ 
/*     */     
/*     */     public BasicAuthenticationSpec authenticationManager(ReactiveAuthenticationManager authenticationManager) {
/* 294 */       this.authenticationManager = authenticationManager;
/* 295 */       return this;
/*     */     }
/*     */     
/*     */     private ReactiveAuthenticationManager getAuthenticationManager() {
/* 299 */       if (this.authenticationManager == null) {
/* 300 */         return RSocketSecurity.this.authenticationManager;
/*     */       }
/* 302 */       return this.authenticationManager;
/*     */     }
/*     */     
/*     */     protected AuthenticationPayloadInterceptor build() {
/* 306 */       ReactiveAuthenticationManager manager = getAuthenticationManager();
/* 307 */       AuthenticationPayloadInterceptor result = new AuthenticationPayloadInterceptor(manager);
/* 308 */       result.setOrder(PayloadInterceptorOrder.AUTHENTICATION.getOrder());
/* 309 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final class JwtSpec
/*     */   {
/*     */     private ReactiveAuthenticationManager authenticationManager;
/*     */ 
/*     */ 
/*     */     
/*     */     public JwtSpec authenticationManager(ReactiveAuthenticationManager authenticationManager) {
/* 322 */       this.authenticationManager = authenticationManager;
/* 323 */       return this;
/*     */     }
/*     */     
/*     */     private ReactiveAuthenticationManager getAuthenticationManager() {
/* 327 */       if (this.authenticationManager != null) {
/* 328 */         return this.authenticationManager;
/*     */       }
/* 330 */       ReactiveJwtDecoder jwtDecoder = RSocketSecurity.this.<ReactiveJwtDecoder>getBeanOrNull(ReactiveJwtDecoder.class);
/* 331 */       if (jwtDecoder != null) {
/* 332 */         this.authenticationManager = (ReactiveAuthenticationManager)new JwtReactiveAuthenticationManager(jwtDecoder);
/* 333 */         return this.authenticationManager;
/*     */       } 
/* 335 */       return RSocketSecurity.this.authenticationManager;
/*     */     }
/*     */     
/*     */     protected List<AuthenticationPayloadInterceptor> build() {
/* 339 */       ReactiveAuthenticationManager manager = getAuthenticationManager();
/* 340 */       AuthenticationPayloadInterceptor legacy = new AuthenticationPayloadInterceptor(manager);
/* 341 */       legacy.setAuthenticationConverter((PayloadExchangeAuthenticationConverter)new BearerPayloadExchangeConverter());
/* 342 */       legacy.setOrder(PayloadInterceptorOrder.AUTHENTICATION.getOrder());
/* 343 */       AuthenticationPayloadInterceptor standard = new AuthenticationPayloadInterceptor(manager);
/* 344 */       standard.setAuthenticationConverter((PayloadExchangeAuthenticationConverter)new AuthenticationPayloadExchangeConverter());
/* 345 */       standard.setOrder(PayloadInterceptorOrder.AUTHENTICATION.getOrder());
/* 346 */       return Arrays.asList(new AuthenticationPayloadInterceptor[] { standard, legacy });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class AuthorizePayloadsSpec
/*     */   {
/* 354 */     private PayloadExchangeMatcherReactiveAuthorizationManager.Builder authzBuilder = PayloadExchangeMatcherReactiveAuthorizationManager.builder();
/*     */     
/*     */     public Access setup() {
/* 357 */       return matcher(PayloadExchangeMatchers.setup());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Access anyRequest() {
/* 367 */       return matcher(PayloadExchangeMatchers.anyRequest());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Access anyExchange() {
/* 375 */       return matcher(PayloadExchangeMatchers.anyExchange());
/*     */     }
/*     */     
/*     */     protected AuthorizationPayloadInterceptor build() {
/* 379 */       AuthorizationPayloadInterceptor result = new AuthorizationPayloadInterceptor((ReactiveAuthorizationManager)this.authzBuilder.build());
/* 380 */       result.setOrder(PayloadInterceptorOrder.AUTHORIZATION.getOrder());
/* 381 */       return result;
/*     */     }
/*     */     
/*     */     public Access route(String pattern) {
/* 385 */       RSocketMessageHandler handler = RSocketSecurity.this.<RSocketMessageHandler>getBean(RSocketMessageHandler.class);
/*     */       
/* 387 */       RoutePayloadExchangeMatcher routePayloadExchangeMatcher = new RoutePayloadExchangeMatcher(handler.getMetadataExtractor(), handler.getRouteMatcher(), pattern);
/* 388 */       return matcher((PayloadExchangeMatcher)routePayloadExchangeMatcher);
/*     */     }
/*     */     
/*     */     public Access matcher(PayloadExchangeMatcher matcher) {
/* 392 */       return new Access(matcher);
/*     */     }
/*     */     
/*     */     public final class Access
/*     */     {
/*     */       private final PayloadExchangeMatcher matcher;
/*     */       
/*     */       private Access(PayloadExchangeMatcher matcher) {
/* 400 */         this.matcher = matcher;
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec authenticated() {
/* 404 */         return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthenticatedReactiveAuthorizationManager.authenticated());
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec hasAuthority(String authority) {
/* 408 */         return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAuthority(authority));
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec hasRole(String role) {
/* 412 */         return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasRole(role));
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec hasAnyRole(String... roles) {
/* 416 */         return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyRole(roles));
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec permitAll() {
/* 420 */         return access((a, ctx) -> Mono.just(new AuthorizationDecision(true)));
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec hasAnyAuthority(String... authorities) {
/* 424 */         return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyAuthority(authorities));
/*     */       }
/*     */ 
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec access(ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext> authorization) {
/* 429 */         RSocketSecurity.AuthorizePayloadsSpec.this.authzBuilder
/* 430 */           .add(new PayloadExchangeMatcherEntry(this.matcher, authorization));
/* 431 */         return RSocketSecurity.AuthorizePayloadsSpec.this;
/*     */       }
/*     */       
/*     */       public RSocketSecurity.AuthorizePayloadsSpec denyAll() {
/* 435 */         return access((a, ctx) -> Mono.just(new AuthorizationDecision(false))); } } } public final class Access { public RSocketSecurity.AuthorizePayloadsSpec denyAll() { return access((a, ctx) -> Mono.just(new AuthorizationDecision(false))); }
/*     */ 
/*     */     
/*     */     private final PayloadExchangeMatcher matcher;
/*     */     
/*     */     private Access(PayloadExchangeMatcher matcher) {
/*     */       this.matcher = matcher;
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec authenticated() {
/*     */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthenticatedReactiveAuthorizationManager.authenticated());
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasAuthority(String authority) {
/*     */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAuthority(authority));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasRole(String role) {
/*     */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasRole(role));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasAnyRole(String... roles) {
/*     */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyRole(roles));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec permitAll() {
/*     */       return access((a, ctx) -> Mono.just(new AuthorizationDecision(true)));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec hasAnyAuthority(String... authorities) {
/*     */       return access((ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext>)AuthorityReactiveAuthorizationManager.hasAnyAuthority(authorities));
/*     */     }
/*     */     
/*     */     public RSocketSecurity.AuthorizePayloadsSpec access(ReactiveAuthorizationManager<PayloadExchangeAuthorizationContext> authorization) {
/*     */       RSocketSecurity.AuthorizePayloadsSpec.this.authzBuilder.add(new PayloadExchangeMatcherEntry(this.matcher, authorization));
/*     */       return RSocketSecurity.AuthorizePayloadsSpec.this;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\RSocketSecurity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */