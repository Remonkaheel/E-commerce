/*    */ package org.springframework.security.config.annotation.authentication.configurers.userdetails;
/*    */ 
/*    */ import org.springframework.security.config.annotation.SecurityBuilder;
/*    */ import org.springframework.security.config.annotation.authentication.ProviderManagerBuilder;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsServiceConfigurer<B extends ProviderManagerBuilder<B>, C extends UserDetailsServiceConfigurer<B, C, U>, U extends UserDetailsService>
/*    */   extends AbstractDaoAuthenticationConfigurer<B, C, U>
/*    */ {
/*    */   public UserDetailsServiceConfigurer(U userDetailsService) {
/* 42 */     super(userDetailsService);
/*    */   }
/*    */ 
/*    */   
/*    */   public void configure(B builder) throws Exception {
/* 47 */     initUserDetailsService();
/* 48 */     super.configure(builder);
/*    */   }
/*    */   
/*    */   protected void initUserDetailsService() throws Exception {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\authentication\configurer\\userdetails\UserDetailsServiceConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */