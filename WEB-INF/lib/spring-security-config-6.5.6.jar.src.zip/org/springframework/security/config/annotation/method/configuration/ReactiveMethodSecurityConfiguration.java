/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Fallback;
/*     */ import org.springframework.context.annotation.ImportAware;
/*     */ import org.springframework.context.annotation.Role;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedAnnotationAttributeFactory;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedPostInvocationAdvice;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedPreInvocationAdvice;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityMetadataSourceAdvisor;
/*     */ import org.springframework.security.access.method.AbstractMethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.method.DelegatingMethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.prepost.PostInvocationAuthorizationAdvice;
/*     */ import org.springframework.security.access.prepost.PreInvocationAuthorizationAdvice;
/*     */ import org.springframework.security.access.prepost.PrePostAdviceReactiveMethodInterceptor;
/*     */ import org.springframework.security.access.prepost.PrePostAnnotationSecurityMetadataSource;
/*     */ import org.springframework.security.access.prepost.PrePostInvocationAttributeFactory;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods = false)
/*     */ @Role(2)
/*     */ class ReactiveMethodSecurityConfiguration
/*     */   implements ImportAware
/*     */ {
/*     */   private int advisorOrder;
/*     */   private GrantedAuthorityDefaults grantedAuthorityDefaults;
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static MethodSecurityMetadataSourceAdvisor methodSecurityInterceptor(AbstractMethodSecurityMetadataSource source, ReactiveMethodSecurityConfiguration configuration) {
/*  58 */     MethodSecurityMetadataSourceAdvisor advisor = new MethodSecurityMetadataSourceAdvisor("securityMethodInterceptor", (MethodSecurityMetadataSource)source, "methodMetadataSource");
/*     */     
/*  60 */     advisor.setOrder(configuration.advisorOrder);
/*  61 */     return advisor;
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   static DelegatingMethodSecurityMetadataSource methodMetadataSource(MethodSecurityExpressionHandler methodSecurityExpressionHandler) {
/*  68 */     ExpressionBasedAnnotationAttributeFactory attributeFactory = new ExpressionBasedAnnotationAttributeFactory(methodSecurityExpressionHandler);
/*     */     
/*  70 */     PrePostAnnotationSecurityMetadataSource prePostSource = new PrePostAnnotationSecurityMetadataSource((PrePostInvocationAttributeFactory)attributeFactory);
/*     */     
/*  72 */     return new DelegatingMethodSecurityMetadataSource(Arrays.asList(new MethodSecurityMetadataSource[] { (MethodSecurityMetadataSource)prePostSource }));
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   static PrePostAdviceReactiveMethodInterceptor securityMethodInterceptor(AbstractMethodSecurityMetadataSource source, MethodSecurityExpressionHandler handler) {
/*  78 */     ExpressionBasedPostInvocationAdvice postAdvice = new ExpressionBasedPostInvocationAdvice(handler);
/*  79 */     ExpressionBasedPreInvocationAdvice preAdvice = new ExpressionBasedPreInvocationAdvice();
/*  80 */     preAdvice.setExpressionHandler(handler);
/*  81 */     return new PrePostAdviceReactiveMethodInterceptor((MethodSecurityMetadataSource)source, (PreInvocationAuthorizationAdvice)preAdvice, (PostInvocationAuthorizationAdvice)postAdvice);
/*     */   }
/*     */ 
/*     */   
/*     */   @Bean
/*     */   @Role(2)
/*     */   @Fallback
/*     */   static DefaultMethodSecurityExpressionHandler methodSecurityExpressionHandler(ReactiveMethodSecurityConfiguration configuration) {
/*  89 */     DefaultMethodSecurityExpressionHandler handler = new DefaultMethodSecurityExpressionHandler();
/*  90 */     if (configuration.grantedAuthorityDefaults != null) {
/*  91 */       handler.setDefaultRolePrefix(configuration.grantedAuthorityDefaults.getRolePrefix());
/*     */     }
/*  93 */     return handler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata) {
/*  98 */     this.advisorOrder = ((Integer)importMetadata.getAnnotationAttributes(EnableReactiveMethodSecurity.class.getName())
/*  99 */       .get("order")).intValue();
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setGrantedAuthorityDefaults(GrantedAuthorityDefaults grantedAuthorityDefaults) {
/* 104 */     this.grantedAuthorityDefaults = grantedAuthorityDefaults;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\ReactiveMethodSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */