/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.X509Configurer;
/*    */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
/*    */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;
/*    */ import org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter;
/*    */ import org.springframework.security.web.authentication.preauth.x509.X509PrincipalExtractor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000\\\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020*\032\024\022\n\022\b\022\004\022\0020-0,\022\004\022\0020.0+H\000¢\006\002\b/R(\020\003\032\020\022\004\022\0020\005\022\004\022\0020\006\030\0010\004X\016¢\006\016\n\000\032\004\b\007\020\b\"\004\b\t\020\nR\"\020\013\032\n\022\004\022\0020\r\030\0010\fX\016¢\006\016\n\000\032\004\b\016\020\017\"\004\b\020\020\021R\034\020\022\032\004\030\0010\023X\016¢\006\016\n\000\032\004\b\024\020\025\"\004\b\026\020\027R\034\020\030\032\004\030\0010\031X\016¢\006\016\n\000\032\004\b\032\020\033\"\004\b\034\020\035R\034\020\036\032\004\030\0010\037X\016¢\006\016\n\000\032\004\b \020!\"\004\b\"\020#R\034\020$\032\004\030\0010%X\016¢\006\016\n\000\032\004\b&\020'\"\004\b(\020)¨\0060"}, d2 = {"Lorg/springframework/security/config/annotation/web/X509Dsl;", "", "()V", "authenticationDetailsSource", "Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "Ljakarta/servlet/http/HttpServletRequest;", "Lorg/springframework/security/web/authentication/preauth/PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails;", "getAuthenticationDetailsSource", "()Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "setAuthenticationDetailsSource", "(Lorg/springframework/security/authentication/AuthenticationDetailsSource;)V", "authenticationUserDetailsService", "Lorg/springframework/security/core/userdetails/AuthenticationUserDetailsService;", "Lorg/springframework/security/web/authentication/preauth/PreAuthenticatedAuthenticationToken;", "getAuthenticationUserDetailsService", "()Lorg/springframework/security/core/userdetails/AuthenticationUserDetailsService;", "setAuthenticationUserDetailsService", "(Lorg/springframework/security/core/userdetails/AuthenticationUserDetailsService;)V", "subjectPrincipalRegex", "", "getSubjectPrincipalRegex", "()Ljava/lang/String;", "setSubjectPrincipalRegex", "(Ljava/lang/String;)V", "userDetailsService", "Lorg/springframework/security/core/userdetails/UserDetailsService;", "getUserDetailsService", "()Lorg/springframework/security/core/userdetails/UserDetailsService;", "setUserDetailsService", "(Lorg/springframework/security/core/userdetails/UserDetailsService;)V", "x509AuthenticationFilter", "Lorg/springframework/security/web/authentication/preauth/x509/X509AuthenticationFilter;", "getX509AuthenticationFilter", "()Lorg/springframework/security/web/authentication/preauth/x509/X509AuthenticationFilter;", "setX509AuthenticationFilter", "(Lorg/springframework/security/web/authentication/preauth/x509/X509AuthenticationFilter;)V", "x509PrincipalExtractor", "Lorg/springframework/security/web/authentication/preauth/x509/X509PrincipalExtractor;", "getX509PrincipalExtractor", "()Lorg/springframework/security/web/authentication/preauth/x509/X509PrincipalExtractor;", "setX509PrincipalExtractor", "(Lorg/springframework/security/web/authentication/preauth/x509/X509PrincipalExtractor;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/X509Configurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class X509Dsl
/*    */ {
/*    */   @Nullable
/*    */   private X509AuthenticationFilter x509AuthenticationFilter;
/*    */   @Nullable
/*    */   private X509PrincipalExtractor x509PrincipalExtractor;
/*    */   @Nullable
/*    */   private AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> authenticationDetailsSource;
/*    */   @Nullable
/*    */   private UserDetailsService userDetailsService;
/*    */   @Nullable
/*    */   private AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService;
/*    */   @Nullable
/*    */   private String subjectPrincipalRegex;
/*    */   
/*    */   @Nullable
/*    */   public final X509AuthenticationFilter getX509AuthenticationFilter() {
/* 49 */     return this.x509AuthenticationFilter; } public final void setX509AuthenticationFilter(@Nullable X509AuthenticationFilter <set-?>) { this.x509AuthenticationFilter = <set-?>; } @Nullable
/* 50 */   public final X509PrincipalExtractor getX509PrincipalExtractor() { return this.x509PrincipalExtractor; } public final void setX509PrincipalExtractor(@Nullable X509PrincipalExtractor <set-?>) { this.x509PrincipalExtractor = <set-?>; } @Nullable
/* 51 */   public final AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> getAuthenticationDetailsSource() { return this.authenticationDetailsSource; } public final void setAuthenticationDetailsSource(@Nullable AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> <set-?>) { this.authenticationDetailsSource = <set-?>; } @Nullable
/* 52 */   public final UserDetailsService getUserDetailsService() { return this.userDetailsService; } public final void setUserDetailsService(@Nullable UserDetailsService <set-?>) { this.userDetailsService = <set-?>; } @Nullable
/* 53 */   public final AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> getAuthenticationUserDetailsService() { return this.authenticationUserDetailsService; } public final void setAuthenticationUserDetailsService(@Nullable AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> <set-?>) { this.authenticationUserDetailsService = <set-?>; } @Nullable
/* 54 */   public final String getSubjectPrincipalRegex() { return this.subjectPrincipalRegex; } public final void setSubjectPrincipalRegex(@Nullable String <set-?>) { this.subjectPrincipalRegex = <set-?>; }
/*    */ 
/*    */   
/*    */   @NotNull
/* 58 */   public final Function1<X509Configurer<HttpSecurity>, Unit> get$spring_security_config() { return new X509Dsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "x509", "Lorg/springframework/security/config/annotation/web/configurers/X509Configurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nX509Dsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 X509Dsl.kt\norg/springframework/security/config/annotation/web/X509Dsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,68:1\n1#2:69\n*E\n"})
/* 59 */   static final class X509Dsl$get$1 extends Lambda implements Function1<X509Configurer<HttpSecurity>, Unit> { public final void invoke(X509Configurer x509) { Intrinsics.checkNotNullParameter(x509, "x509"); if (X509Dsl.this.getX509AuthenticationFilter() != null) { X509AuthenticationFilter x509AuthenticationFilter1 = X509Dsl.this.getX509AuthenticationFilter(); X509Dsl x509Dsl = X509Dsl.this; X509AuthenticationFilter it = x509AuthenticationFilter1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 69 */         int $i$a$-also-X509Dsl$get$1$1 = 0; x509.x509AuthenticationFilter(x509Dsl.getX509AuthenticationFilter()); } else { X509Dsl.this.getX509AuthenticationFilter(); }  if (X509Dsl.this.getX509PrincipalExtractor() != null) { X509PrincipalExtractor x509PrincipalExtractor1 = X509Dsl.this.getX509PrincipalExtractor(); X509Dsl x509Dsl = X509Dsl.this; X509PrincipalExtractor it = x509PrincipalExtractor1; int $i$a$-also-X509Dsl$get$1$2 = 0; x509.x509PrincipalExtractor(x509Dsl.getX509PrincipalExtractor()); } else { X509Dsl.this.getX509PrincipalExtractor(); }  if (X509Dsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> authenticationDetailsSource1 = X509Dsl.this.getAuthenticationDetailsSource(); X509Dsl x509Dsl = X509Dsl.this; AuthenticationDetailsSource<HttpServletRequest, PreAuthenticatedGrantedAuthoritiesWebAuthenticationDetails> it = authenticationDetailsSource1; int $i$a$-also-X509Dsl$get$1$3 = 0; x509.authenticationDetailsSource(x509Dsl.getAuthenticationDetailsSource()); } else { X509Dsl.this.getAuthenticationDetailsSource(); }  if (X509Dsl.this.getUserDetailsService() != null) { UserDetailsService userDetailsService1 = X509Dsl.this.getUserDetailsService(); X509Dsl x509Dsl = X509Dsl.this; UserDetailsService it = userDetailsService1; int $i$a$-also-X509Dsl$get$1$4 = 0; x509.userDetailsService(x509Dsl.getUserDetailsService()); } else { X509Dsl.this.getUserDetailsService(); }  if (X509Dsl.this.getAuthenticationUserDetailsService() != null) { AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> authenticationUserDetailsService1 = X509Dsl.this.getAuthenticationUserDetailsService(); X509Dsl x509Dsl = X509Dsl.this; AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> it = authenticationUserDetailsService1; int $i$a$-also-X509Dsl$get$1$5 = 0; x509.authenticationUserDetailsService(x509Dsl.getAuthenticationUserDetailsService()); } else { X509Dsl.this.getAuthenticationUserDetailsService(); }  if (X509Dsl.this.getSubjectPrincipalRegex() != null) { String str1 = X509Dsl.this.getSubjectPrincipalRegex(); X509Dsl x509Dsl = X509Dsl.this; String it = str1; int $i$a$-also-X509Dsl$get$1$6 = 0;
/*    */         x509.subjectPrincipalRegex(x509Dsl.getSubjectPrincipalRegex()); }
/*    */       else
/*    */       { X509Dsl.this.getSubjectPrincipalRegex(); }
/*    */        }
/*    */ 
/*    */     
/*    */     X509Dsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\X509Dsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */