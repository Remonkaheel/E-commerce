/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "logout", "Lorg/springframework/security/config/annotation/web/configurers/LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nLogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LogoutDsl.kt\norg/springframework/security/config/annotation/web/LogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,128:1\n1#2:129\n216#3,2:130\n1863#4,2:132\n*S KotlinDebug\n*F\n+ 1 LogoutDsl.kt\norg/springframework/security/config/annotation/web/LogoutDsl$get$1\n*L\n116#1:130,2\n119#1:132,2\n*E\n"})
/*     */ final class LogoutDsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<LogoutConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(LogoutConfigurer logout) {
/* 108 */     Intrinsics.checkNotNullParameter(logout, "logout"); if (LogoutDsl.this.getClearAuthentication() != null) { Boolean bool = LogoutDsl.this.getClearAuthentication(); LogoutDsl logoutDsl = LogoutDsl.this; boolean it = bool.booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 129 */       int $i$a$-also-LogoutDsl$get$1$1 = 0; Intrinsics.checkNotNull(logoutDsl.getClearAuthentication()); logout.clearAuthentication(logoutDsl.getClearAuthentication().booleanValue()); } else { LogoutDsl.this.getClearAuthentication(); }  if (LogoutDsl.this.getInvalidateHttpSession() != null) { Boolean bool = LogoutDsl.this.getInvalidateHttpSession(); LogoutDsl logoutDsl = LogoutDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-LogoutDsl$get$1$2 = 0; Intrinsics.checkNotNull(logoutDsl.getInvalidateHttpSession()); logout.invalidateHttpSession(logoutDsl.getInvalidateHttpSession().booleanValue()); } else { LogoutDsl.this.getInvalidateHttpSession(); }  if (LogoutDsl.this.getLogoutUrl() != null) { String str1 = LogoutDsl.this.getLogoutUrl(); LogoutDsl logoutDsl = LogoutDsl.this; String it = str1; int $i$a$-also-LogoutDsl$get$1$3 = 0; logout.logoutUrl(logoutDsl.getLogoutUrl()); } else { LogoutDsl.this.getLogoutUrl(); }  if (LogoutDsl.this.getLogoutRequestMatcher() != null) { RequestMatcher requestMatcher1 = LogoutDsl.this.getLogoutRequestMatcher(); LogoutDsl logoutDsl = LogoutDsl.this; RequestMatcher it = requestMatcher1; int $i$a$-also-LogoutDsl$get$1$4 = 0; logout.logoutRequestMatcher(logoutDsl.getLogoutRequestMatcher()); } else { LogoutDsl.this.getLogoutRequestMatcher(); }  if (LogoutDsl.this.getLogoutSuccessUrl() != null) { String str1 = LogoutDsl.this.getLogoutSuccessUrl(); LogoutDsl logoutDsl = LogoutDsl.this; String it = str1; int $i$a$-also-LogoutDsl$get$1$5 = 0; logout.logoutSuccessUrl(logoutDsl.getLogoutSuccessUrl()); } else { LogoutDsl.this.getLogoutSuccessUrl(); }  if (LogoutDsl.this.getLogoutSuccessHandler() != null) { LogoutSuccessHandler logoutSuccessHandler1 = LogoutDsl.this.getLogoutSuccessHandler(); LogoutDsl logoutDsl = LogoutDsl.this; LogoutSuccessHandler it = logoutSuccessHandler1; int $i$a$-also-LogoutDsl$get$1$6 = 0; logout.logoutSuccessHandler(logoutDsl.getLogoutSuccessHandler()); } else { LogoutDsl.this.getLogoutSuccessHandler(); }  if (LogoutDsl.access$getDeleteCookies$p(LogoutDsl.this) != null) { String[] arrayOfString1 = LogoutDsl.access$getDeleteCookies$p(LogoutDsl.this); LogoutDsl logoutDsl = LogoutDsl.this; String[] it = arrayOfString1; int $i$a$-also-LogoutDsl$get$1$7 = 0; Intrinsics.checkNotNull(LogoutDsl.access$getDeleteCookies$p(logoutDsl)); String[] arrayOfString2 = LogoutDsl.access$getDeleteCookies$p(logoutDsl); logout.deleteCookies(Arrays.<String>copyOf(arrayOfString2, arrayOfString2.length)); } else { LogoutDsl.access$getDeleteCookies$p(LogoutDsl.this); }  if (LogoutDsl.this.getPermitAll() != null) { Boolean bool = LogoutDsl.this.getPermitAll(); LogoutDsl logoutDsl = LogoutDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-LogoutDsl$get$1$8 = 0; Intrinsics.checkNotNull(logoutDsl.getPermitAll()); logout.permitAll(logoutDsl.getPermitAll().booleanValue()); } else { LogoutDsl.this.getPermitAll(); }
/* 130 */      Map map = LogoutDsl.access$getDefaultLogoutSuccessHandlerMappings$p(LogoutDsl.this); int $i$f$forEach = 0; Iterator<Map.Entry> iterator = map.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-LogoutDsl$get$1$9 = 0; RequestMatcher matcher = (RequestMatcher)entry1.getKey(); LogoutSuccessHandler handler = (LogoutSuccessHandler)entry1.getValue(); logout.defaultLogoutSuccessHandlerFor(handler, matcher); }
/*     */      Iterable<Map.Entry> $this$forEach$iv = LogoutDsl.access$getLogoutHandlers$p(LogoutDsl.this); $i$f$forEach = 0;
/* 132 */     iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); LogoutHandler logoutHandler = (LogoutHandler)element$iv; int $i$a$-forEach-LogoutDsl$get$1$10 = 0;
/*     */       logout.addLogoutHandler(logoutHandler); }
/*     */     
/*     */     if (LogoutDsl.access$getDisabled$p(LogoutDsl.this))
/*     */       logout.disable(); 
/*     */   }
/*     */   
/*     */   LogoutDsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\LogoutDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */