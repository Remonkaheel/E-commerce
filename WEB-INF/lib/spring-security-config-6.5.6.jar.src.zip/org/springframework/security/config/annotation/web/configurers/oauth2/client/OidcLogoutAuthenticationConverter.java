/*    */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*    */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*    */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OidcLogoutAuthenticationConverter
/*    */   implements AuthenticationConverter
/*    */ {
/*    */   private static final String DEFAULT_LOGOUT_URI = "/logout/connect/back-channel/{registrationId}";
/* 45 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final ClientRegistrationRepository clientRegistrationRepository;
/*    */   
/* 49 */   private RequestMatcher requestMatcher = (RequestMatcher)PathPatternRequestMatcher.withDefaults()
/* 50 */     .matcher(HttpMethod.POST, "/logout/connect/back-channel/{registrationId}");
/*    */   
/*    */   OidcLogoutAuthenticationConverter(ClientRegistrationRepository clientRegistrationRepository) {
/* 53 */     Assert.notNull(clientRegistrationRepository, "clientRegistrationRepository cannot be null");
/* 54 */     this.clientRegistrationRepository = clientRegistrationRepository;
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication convert(HttpServletRequest request) {
/* 59 */     RequestMatcher.MatchResult result = this.requestMatcher.matcher(request);
/* 60 */     if (!result.isMatch()) {
/* 61 */       return null;
/*    */     }
/* 63 */     String registrationId = (String)result.getVariables().get("registrationId");
/* 64 */     ClientRegistration clientRegistration = this.clientRegistrationRepository.findByRegistrationId(registrationId);
/* 65 */     if (clientRegistration == null) {
/* 66 */       this.logger.debug("Did not process OIDC Back-Channel Logout since no ClientRegistration was found");
/* 67 */       throw new OAuth2AuthenticationException("invalid_request");
/*    */     } 
/* 69 */     String logoutToken = request.getParameter("logout_token");
/* 70 */     if (logoutToken == null) {
/* 71 */       this.logger.debug("Failed to process OIDC Back-Channel Logout since no logout token was found");
/* 72 */       throw new OAuth2AuthenticationException("invalid_request");
/*    */     } 
/* 74 */     return (Authentication)new OidcLogoutAuthenticationToken(logoutToken, clientRegistration);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setRequestMatcher(RequestMatcher requestMatcher) {
/* 83 */     Assert.notNull(requestMatcher, "requestMatcher cannot be null");
/* 84 */     this.requestMatcher = requestMatcher;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcLogoutAuthenticationConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */