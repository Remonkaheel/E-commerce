/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\005\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\013\032\0020\fJ#\020\r\032\030\022\016\022\f0\017R\b\022\004\022\0020\0210\020\022\004\022\0020\f0\016H\000¢\006\002\b\022R\016\020\003\032\0020\004X\016¢\006\002\n\000R\034\020\005\032\004\030\0010\006X\016¢\006\016\n\000\032\004\b\007\020\b\"\004\b\t\020\n¨\006\023"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/XssProtectionConfigDsl;", "", "()V", "disabled", "", "headerValue", "Lorg/springframework/security/web/header/writers/XXssProtectionHeaderWriter$HeaderValue;", "getHeaderValue", "()Lorg/springframework/security/web/header/writers/XXssProtectionHeaderWriter$HeaderValue;", "setHeaderValue", "(Lorg/springframework/security/web/header/writers/XXssProtectionHeaderWriter$HeaderValue;)V", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$XXssConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class XssProtectionConfigDsl
/*    */ {
/*    */   @Nullable
/*    */   private XXssProtectionHeaderWriter.HeaderValue headerValue;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final XXssProtectionHeaderWriter.HeaderValue getHeaderValue() {
/* 34 */     return this.headerValue; } public final void setHeaderValue(@Nullable XXssProtectionHeaderWriter.HeaderValue <set-?>) { this.headerValue = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 42 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 46 */   public final Function1<HeadersConfigurer<HttpSecurity>.XXssConfig, Unit> get$spring_security_config() { return new XssProtectionConfigDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "xssProtection", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$XXssConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nXssProtectionConfigDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 XssProtectionConfigDsl.kt\norg/springframework/security/config/annotation/web/headers/XssProtectionConfigDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1#2:56\n*E\n"})
/* 47 */   static final class XssProtectionConfigDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.XXssConfig, Unit> { public final void invoke(HeadersConfigurer.XXssConfig xssProtection) { Intrinsics.checkNotNullParameter(xssProtection, "xssProtection"); if (XssProtectionConfigDsl.this.getHeaderValue() != null) { XXssProtectionHeaderWriter.HeaderValue headerValue1 = XssProtectionConfigDsl.this.getHeaderValue(); XssProtectionConfigDsl xssProtectionConfigDsl = XssProtectionConfigDsl.this; XXssProtectionHeaderWriter.HeaderValue it = headerValue1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 56 */         int $i$a$-also-XssProtectionConfigDsl$get$1$1 = 0;
/*    */         xssProtection.headerValue(xssProtectionConfigDsl.getHeaderValue()); }
/*    */       else
/*    */       { XssProtectionConfigDsl.this.getHeaderValue(); }
/*    */       
/*    */       if (XssProtectionConfigDsl.this.disabled)
/*    */         xssProtection.disable();  }
/*    */ 
/*    */     
/*    */     XssProtectionConfigDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\XssProtectionConfigDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */