package org.springframework.security.config.annotation.rsocket;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Import;

@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Import({RSocketSecurityConfiguration.class, SecuritySocketAcceptorInterceptorConfiguration.class, ReactiveObservationImportSelector.class})
public @interface EnableRSocketSecurity {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\rsocket\EnableRSocketSecurity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */