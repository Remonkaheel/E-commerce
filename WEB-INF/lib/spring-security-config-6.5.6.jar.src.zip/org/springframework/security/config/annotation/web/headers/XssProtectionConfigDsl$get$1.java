/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "xssProtection", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$XXssConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nXssProtectionConfigDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 XssProtectionConfigDsl.kt\norg/springframework/security/config/annotation/web/headers/XssProtectionConfigDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1#2:56\n*E\n"})
/*    */ final class XssProtectionConfigDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HeadersConfigurer<HttpSecurity>.XXssConfig, Unit>
/*    */ {
/*    */   public final void invoke(HeadersConfigurer.XXssConfig xssProtection) {
/* 47 */     Intrinsics.checkNotNullParameter(xssProtection, "xssProtection"); if (XssProtectionConfigDsl.this.getHeaderValue() != null) { XXssProtectionHeaderWriter.HeaderValue headerValue1 = XssProtectionConfigDsl.this.getHeaderValue(); XssProtectionConfigDsl xssProtectionConfigDsl = XssProtectionConfigDsl.this; XXssProtectionHeaderWriter.HeaderValue it = headerValue1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       int $i$a$-also-XssProtectionConfigDsl$get$1$1 = 0;
/*    */       xssProtection.headerValue(xssProtectionConfigDsl.getHeaderValue()); }
/*    */     else
/*    */     { XssProtectionConfigDsl.this.getHeaderValue(); }
/*    */     
/*    */     if (XssProtectionConfigDsl.access$getDisabled$p(XssProtectionConfigDsl.this))
/*    */       xssProtection.disable(); 
/*    */   }
/*    */   
/*    */   XssProtectionConfigDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\XssProtectionConfigDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */