/*     */ package org.springframework.security.config.annotation.web.socket;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.messaging.Message;
/*     */ import org.springframework.messaging.handler.invocation.HandlerMethodArgumentResolver;
/*     */ import org.springframework.messaging.simp.config.ChannelRegistration;
/*     */ import org.springframework.messaging.support.ChannelInterceptor;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.SpringAuthorizationEventPublisher;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.messaging.access.intercept.AuthorizationChannelInterceptor;
/*     */ import org.springframework.security.messaging.access.intercept.MessageMatcherDelegatingAuthorizationManager;
/*     */ import org.springframework.security.messaging.context.AuthenticationPrincipalArgumentResolver;
/*     */ import org.springframework.security.messaging.context.SecurityContextChannelInterceptor;
/*     */ import org.springframework.security.messaging.web.csrf.XorCsrfChannelInterceptor;
/*     */ import org.springframework.security.messaging.web.socket.server.CsrfTokenHandshakeInterceptor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
/*     */ import org.springframework.web.socket.server.HandshakeInterceptor;
/*     */ import org.springframework.web.socket.server.support.WebSocketHttpRequestHandler;
/*     */ import org.springframework.web.socket.sockjs.SockJsService;
/*     */ import org.springframework.web.socket.sockjs.support.SockJsHttpRequestHandler;
/*     */ import org.springframework.web.socket.sockjs.transport.TransportHandlingSockJsService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483548)
/*     */ @Import({MessageMatcherAuthorizationManagerConfiguration.class})
/*     */ final class WebSocketMessageBrokerSecurityConfiguration
/*     */   implements WebSocketMessageBrokerConfigurer, SmartInitializingSingleton
/*     */ {
/*     */   private static final String SIMPLE_URL_HANDLER_MAPPING_BEAN_NAME = "stompWebSocketHandlerMapping";
/*     */   private static final String CSRF_CHANNEL_INTERCEPTOR_BEAN_NAME = "csrfChannelInterceptor";
/*     */   private MessageMatcherDelegatingAuthorizationManager b;
/*  66 */   private static final AuthorizationManager<Message<?>> ANY_MESSAGE_AUTHENTICATED = MessageMatcherDelegatingAuthorizationManager.builder()
/*  67 */     .anyMessage()
/*  68 */     .authenticated()
/*  69 */     .build();
/*     */ 
/*     */   
/*  72 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*  74 */   private final SecurityContextChannelInterceptor securityContextChannelInterceptor = new SecurityContextChannelInterceptor();
/*     */   
/*  76 */   private ChannelInterceptor csrfChannelInterceptor = (ChannelInterceptor)new XorCsrfChannelInterceptor();
/*     */   
/*  78 */   private AuthorizationManager<Message<?>> authorizationManager = ANY_MESSAGE_AUTHENTICATED;
/*     */   
/*  80 */   private ObjectPostProcessor<AuthorizationManager<Message<?>>> postProcessor = ObjectPostProcessor.identity();
/*     */   
/*     */   private ApplicationContext context;
/*     */   
/*     */   private AnnotationTemplateExpressionDefaults templateDefaults;
/*     */   
/*     */   WebSocketMessageBrokerSecurityConfiguration(ApplicationContext context) {
/*  87 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
/*  92 */     AuthenticationPrincipalArgumentResolver resolver = new AuthenticationPrincipalArgumentResolver();
/*  93 */     resolver.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/*  94 */     resolver.setTemplateDefaults(this.templateDefaults);
/*  95 */     argumentResolvers.add(resolver);
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureClientInboundChannel(ChannelRegistration registration) {
/* 100 */     ChannelInterceptor csrfChannelInterceptor = getBeanOrNull("csrfChannelInterceptor", ChannelInterceptor.class);
/*     */     
/* 102 */     if (csrfChannelInterceptor != null) {
/* 103 */       this.csrfChannelInterceptor = csrfChannelInterceptor;
/*     */     }
/*     */     
/* 106 */     AuthorizationManager<Message<?>> manager = this.authorizationManager;
/* 107 */     manager = (AuthorizationManager<Message<?>>)this.postProcessor.postProcess(manager);
/* 108 */     AuthorizationChannelInterceptor interceptor = new AuthorizationChannelInterceptor(manager);
/* 109 */     interceptor.setAuthorizationEventPublisher((AuthorizationEventPublisher)new SpringAuthorizationEventPublisher((ApplicationEventPublisher)this.context));
/* 110 */     interceptor.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 111 */     this.securityContextChannelInterceptor.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 112 */     registration.interceptors(new ChannelInterceptor[] { (ChannelInterceptor)this.securityContextChannelInterceptor, this.csrfChannelInterceptor, (ChannelInterceptor)interceptor });
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 117 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 118 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setAuthorizationManager(AuthorizationManager<Message<?>> authorizationManager) {
/* 123 */     this.authorizationManager = authorizationManager;
/*     */   }
/*     */ 
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setMessageAuthorizationManagerPostProcessor(ObjectPostProcessor<AuthorizationManager<Message<?>>> postProcessor) {
/* 129 */     this.postProcessor = postProcessor;
/*     */   }
/*     */   
/*     */   @Autowired(required = false)
/*     */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/* 134 */     this.templateDefaults = templateDefaults;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 139 */     SimpleUrlHandlerMapping mapping = getBeanOrNull("stompWebSocketHandlerMapping", SimpleUrlHandlerMapping.class);
/*     */     
/* 141 */     if (mapping == null) {
/*     */       return;
/*     */     }
/* 144 */     configureCsrf(mapping);
/*     */   }
/*     */   
/*     */   private <T> T getBeanOrNull(String name, Class<T> type) {
/* 148 */     Map<String, T> beans = this.context.getBeansOfType(type);
/* 149 */     return beans.get(name);
/*     */   }
/*     */   
/*     */   private void configureCsrf(SimpleUrlHandlerMapping mapping) {
/* 153 */     Map<String, Object> mappings = mapping.getHandlerMap();
/* 154 */     for (Object object : mappings.values()) {
/* 155 */       if (object instanceof SockJsHttpRequestHandler) {
/* 156 */         setHandshakeInterceptors((SockJsHttpRequestHandler)object); continue;
/*     */       } 
/* 158 */       if (object instanceof WebSocketHttpRequestHandler) {
/* 159 */         setHandshakeInterceptors((WebSocketHttpRequestHandler)object);
/*     */         continue;
/*     */       } 
/* 162 */       throw new IllegalStateException("Bean stompWebSocketHandlerMapping is expected to contain mappings to either a SockJsHttpRequestHandler or a WebSocketHttpRequestHandler but got " + String.valueOf(object));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setHandshakeInterceptors(SockJsHttpRequestHandler handler) {
/* 170 */     SockJsService sockJsService = handler.getSockJsService();
/* 171 */     Assert.state(sockJsService instanceof TransportHandlingSockJsService, () -> "sockJsService must be instance of TransportHandlingSockJsService got " + String.valueOf(sockJsService));
/*     */     
/* 173 */     TransportHandlingSockJsService transportHandlingSockJsService = (TransportHandlingSockJsService)sockJsService;
/* 174 */     List<HandshakeInterceptor> handshakeInterceptors = transportHandlingSockJsService.getHandshakeInterceptors();
/* 175 */     List<HandshakeInterceptor> interceptorsToSet = new ArrayList<>(handshakeInterceptors.size() + 1);
/* 176 */     interceptorsToSet.add(new CsrfTokenHandshakeInterceptor());
/* 177 */     interceptorsToSet.addAll(handshakeInterceptors);
/* 178 */     transportHandlingSockJsService.setHandshakeInterceptors(interceptorsToSet);
/*     */   }
/*     */   
/*     */   private void setHandshakeInterceptors(WebSocketHttpRequestHandler handler) {
/* 182 */     List<HandshakeInterceptor> handshakeInterceptors = handler.getHandshakeInterceptors();
/* 183 */     List<HandshakeInterceptor> interceptorsToSet = new ArrayList<>(handshakeInterceptors.size() + 1);
/* 184 */     interceptorsToSet.add(new CsrfTokenHandshakeInterceptor());
/* 185 */     interceptorsToSet.addAll(handshakeInterceptors);
/* 186 */     handler.setHandshakeInterceptors(interceptorsToSet);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\socket\WebSocketMessageBrokerSecurityConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */