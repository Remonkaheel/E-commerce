/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\t\n\002\020\013\n\000\n\002\020\000\n\000\n\002\020\b\n\000\n\002\020\016\n\000\b\b\030\0002\0020\001B\033\022\006\020\002\032\0020\003\022\f\020\004\032\b\022\004\022\0020\0060\005¢\006\002\020\007J\t\020\f\032\0020\003HÆ\003J\017\020\r\032\b\022\004\022\0020\0060\005HÆ\003J#\020\016\032\0020\0002\b\b\002\020\002\032\0020\0032\016\b\002\020\004\032\b\022\004\022\0020\0060\005HÆ\001J\023\020\017\032\0020\0202\b\020\021\032\004\030\0010\022HÖ\003J\t\020\023\032\0020\024HÖ\001J\t\020\025\032\0020\026HÖ\001R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\b\020\tR\032\020\004\032\b\022\004\022\0020\0060\005X\004¢\006\b\n\000\032\004\b\n\020\013¨\006\027"}, d2 = {"Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$MatcherAuthorizationManagerRule;", "Lorg/springframework/security/config/annotation/web/AbstractRequestMatcherDsl$AuthorizationManagerRule;", "matcher", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "rule", "Lorg/springframework/security/authorization/AuthorizationManager;", "Lorg/springframework/security/web/access/intercept/RequestAuthorizationContext;", "(Lorg/springframework/security/web/util/matcher/RequestMatcher;Lorg/springframework/security/authorization/AuthorizationManager;)V", "getMatcher", "()Lorg/springframework/security/web/util/matcher/RequestMatcher;", "getRule", "()Lorg/springframework/security/authorization/AuthorizationManager;", "component1", "component2", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "spring-security-config"})
/*    */ public final class MatcherAuthorizationManagerRule
/*    */   extends AbstractRequestMatcherDsl.AuthorizationManagerRule
/*    */ {
/*    */   @NotNull
/*    */   private final RequestMatcher matcher;
/*    */   @NotNull
/*    */   private final AuthorizationManager<RequestAuthorizationContext> rule;
/*    */   
/*    */   @NotNull
/*    */   public final RequestMatcher getMatcher() {
/* 41 */     return this.matcher;
/* 42 */   } public MatcherAuthorizationManagerRule(@NotNull RequestMatcher matcher, @NotNull AuthorizationManager<RequestAuthorizationContext> rule) { super(rule); this.matcher = matcher; this.rule = rule; } @NotNull public AuthorizationManager<RequestAuthorizationContext> getRule() { return this.rule; }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public final RequestMatcher component1() {
/*    */     return this.matcher;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final AuthorizationManager<RequestAuthorizationContext> component2() {
/*    */     return this.rule;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final MatcherAuthorizationManagerRule copy(@NotNull RequestMatcher matcher, @NotNull AuthorizationManager<RequestAuthorizationContext> rule) {
/*    */     Intrinsics.checkNotNullParameter(matcher, "matcher");
/*    */     Intrinsics.checkNotNullParameter(rule, "rule");
/*    */     return new MatcherAuthorizationManagerRule(matcher, rule);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString() {
/*    */     return "MatcherAuthorizationManagerRule(matcher=" + this.matcher + ", rule=" + this.rule + ")";
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     result = this.matcher.hashCode();
/*    */     return result * 31 + this.rule.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/*    */     if (this == other)
/*    */       return true; 
/*    */     if (!(other instanceof MatcherAuthorizationManagerRule))
/*    */       return false; 
/*    */     MatcherAuthorizationManagerRule matcherAuthorizationManagerRule = (MatcherAuthorizationManagerRule)other;
/*    */     return !Intrinsics.areEqual(this.matcher, matcherAuthorizationManagerRule.matcher) ? false : (!!Intrinsics.areEqual(this.rule, matcherAuthorizationManagerRule.rule));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\AbstractRequestMatcherDsl$MatcherAuthorizationManagerRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */