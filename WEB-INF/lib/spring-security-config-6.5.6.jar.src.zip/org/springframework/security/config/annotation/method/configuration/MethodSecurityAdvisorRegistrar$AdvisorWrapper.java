/*     */ package org.springframework.security.config.annotation.method.configuration;
/*     */ 
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.security.authorization.method.AuthorizationAdvisor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AdvisorWrapper
/*     */   implements PointcutAdvisor, MethodInterceptor, Ordered, AopInfrastructureBean
/*     */ {
/*     */   private final AuthorizationAdvisor advisor;
/*     */   
/*     */   private AdvisorWrapper(AuthorizationAdvisor advisor) {
/*  79 */     this.advisor = advisor;
/*     */   }
/*     */   
/*     */   public static AdvisorWrapper of(AuthorizationAdvisor advisor) {
/*  83 */     return new AdvisorWrapper(advisor);
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/*  88 */     return this.advisor.getAdvice();
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/*  93 */     return this.advisor.getPointcut();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  98 */     return this.advisor.getOrder();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(@NotNull MethodInvocation invocation) throws Throwable {
/* 104 */     return this.advisor.invoke(invocation);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\MethodSecurityAdvisorRegistrar$AdvisorWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */