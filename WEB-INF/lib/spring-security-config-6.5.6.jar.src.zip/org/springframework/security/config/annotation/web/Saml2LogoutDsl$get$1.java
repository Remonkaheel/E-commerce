/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LogoutConfigurer;
/*    */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "saml2Logout", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LogoutConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nSaml2LogoutDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Saml2LogoutDsl.kt\norg/springframework/security/config/annotation/web/Saml2LogoutDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n1#2:71\n*E\n"})
/*    */ final class Saml2LogoutDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<Saml2LogoutConfigurer<HttpSecurity>, Unit>
/*    */ {
/*    */   public final void invoke(Saml2LogoutConfigurer saml2Logout) {
/* 63 */     Intrinsics.checkNotNullParameter(saml2Logout, "saml2Logout"); if (Saml2LogoutDsl.this.getRelyingPartyRegistrationRepository() != null) { RelyingPartyRegistrationRepository relyingPartyRegistrationRepository1 = Saml2LogoutDsl.this.getRelyingPartyRegistrationRepository(); Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; RelyingPartyRegistrationRepository it = relyingPartyRegistrationRepository1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 71 */       int $i$a$-also-Saml2LogoutDsl$get$1$1 = 0; saml2Logout.relyingPartyRegistrationRepository(saml2LogoutDsl.getRelyingPartyRegistrationRepository()); } else { Saml2LogoutDsl.this.getRelyingPartyRegistrationRepository(); }  if (Saml2LogoutDsl.this.getLogoutUrl() != null) { String str1 = Saml2LogoutDsl.this.getLogoutUrl(); Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; String it = str1; int $i$a$-also-Saml2LogoutDsl$get$1$2 = 0; saml2Logout.logoutUrl(saml2LogoutDsl.getLogoutUrl()); } else { Saml2LogoutDsl.this.getLogoutUrl(); }  if (Saml2LogoutDsl.access$getLogoutRequest$p(Saml2LogoutDsl.this) != null) { Function1 function11 = Saml2LogoutDsl.access$getLogoutRequest$p(Saml2LogoutDsl.this); Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; Function1 it = function11; int $i$a$-also-Saml2LogoutDsl$get$1$3 = 0; Saml2LogoutDsl.access$getLogoutRequest$p(saml2LogoutDsl); saml2Logout.logoutRequest((Saml2LogoutDsl.access$getLogoutRequest$p(saml2LogoutDsl) != null) ? Saml2LogoutDsl.access$getLogoutRequest$p(saml2LogoutDsl)::invoke$lambda$3$lambda$2 : null); } else { Saml2LogoutDsl.access$getLogoutRequest$p(Saml2LogoutDsl.this); }  if (Saml2LogoutDsl.access$getLogoutResponse$p(Saml2LogoutDsl.this) != null) { Function1 function11 = Saml2LogoutDsl.access$getLogoutResponse$p(Saml2LogoutDsl.this); Saml2LogoutDsl saml2LogoutDsl = Saml2LogoutDsl.this; Function1 it = function11; int $i$a$-also-Saml2LogoutDsl$get$1$4 = 0;
/*    */       Saml2LogoutDsl.access$getLogoutResponse$p(saml2LogoutDsl);
/*    */       saml2Logout.logoutResponse((Saml2LogoutDsl.access$getLogoutResponse$p(saml2LogoutDsl) != null) ? Saml2LogoutDsl.access$getLogoutResponse$p(saml2LogoutDsl)::invoke$lambda$5$lambda$4 : null); }
/*    */     else
/*    */     { Saml2LogoutDsl.access$getLogoutResponse$p(Saml2LogoutDsl.this); }
/*    */   
/*    */   }
/*    */   
/*    */   private static final void invoke$lambda$3$lambda$2(Function1 $tmp0, Saml2LogoutConfigurer.LogoutRequestConfigurer t) {
/*    */     $tmp0.invoke(t);
/*    */   }
/*    */   
/*    */   private static final void invoke$lambda$5$lambda$4(Function1 $tmp0, Saml2LogoutConfigurer.LogoutResponseConfigurer t) {
/*    */     $tmp0.invoke(t);
/*    */   }
/*    */   
/*    */   Saml2LogoutDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\Saml2LogoutDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */