/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.cors.CorsConfigurationSource;
/*     */ import org.springframework.web.filter.CorsFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorsConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<CorsConfigurer<H>, H>
/*     */ {
/*     */   private static final String CORS_CONFIGURATION_SOURCE_BEAN_NAME = "corsConfigurationSource";
/*     */   private static final String CORS_FILTER_BEAN_NAME = "corsFilter";
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*  54 */   private static final boolean mvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.handler.HandlerMappingIntrospector", CorsConfigurer.class.getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CorsConfigurationSource configurationSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CorsConfigurer<H> configurationSource(CorsConfigurationSource configurationSource) {
/*  66 */     this.configurationSource = configurationSource;
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/*  72 */     ApplicationContext context = (ApplicationContext)http.getSharedObject(ApplicationContext.class);
/*  73 */     CorsFilter corsFilter = getCorsFilter(context);
/*  74 */     Assert.state((corsFilter != null), () -> "Please configure either a corsFilter bean or a corsConfigurationSourcebean.");
/*     */     
/*  76 */     http.addFilter((Filter)corsFilter);
/*     */   }
/*     */   
/*     */   private CorsFilter getCorsFilter(ApplicationContext context) {
/*  80 */     if (this.configurationSource != null) {
/*  81 */       return new CorsFilter(this.configurationSource);
/*     */     }
/*  83 */     boolean containsCorsFilter = context.containsBeanDefinition("corsFilter");
/*  84 */     if (containsCorsFilter) {
/*  85 */       return (CorsFilter)context.getBean("corsFilter", CorsFilter.class);
/*     */     }
/*  87 */     boolean containsCorsSource = context.containsBean("corsConfigurationSource");
/*  88 */     if (containsCorsSource) {
/*  89 */       CorsConfigurationSource configurationSource = (CorsConfigurationSource)context.getBean("corsConfigurationSource", CorsConfigurationSource.class);
/*     */       
/*  91 */       return new CorsFilter(configurationSource);
/*     */     } 
/*  93 */     if (mvcPresent) {
/*  94 */       return MvcCorsFilter.getMvcCorsFilter(context);
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MvcCorsFilter
/*     */   {
/*     */     private static final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static CorsFilter getMvcCorsFilter(ApplicationContext context) {
/* 110 */       if (context.containsBean("mvcHandlerMappingIntrospector")) {
/*     */         
/* 112 */         CorsConfigurationSource corsConfigurationSource = (CorsConfigurationSource)context.getBean("mvcHandlerMappingIntrospector", CorsConfigurationSource.class);
/* 113 */         return new CorsFilter(corsConfigurationSource);
/*     */       } 
/* 115 */       throw new NoSuchBeanDefinitionException(CorsConfigurationSource.class, "Failed to find a bean that implements `CorsConfigurationSource`. Please ensure that you are using `@EnableWebMvc`, are publishing a `WebMvcConfigurer`, or are publishing a `CorsConfigurationSource` bean.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\CorsConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */