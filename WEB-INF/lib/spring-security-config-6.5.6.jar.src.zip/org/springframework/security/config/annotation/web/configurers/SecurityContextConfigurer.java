/*     */ package org.springframework.security.config.annotation.web.configurers;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import org.springframework.security.config.annotation.SecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.http.SessionCreationPolicy;
/*     */ import org.springframework.security.web.context.DelegatingSecurityContextRepository;
/*     */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*     */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*     */ import org.springframework.security.web.context.SecurityContextHolderFilter;
/*     */ import org.springframework.security.web.context.SecurityContextPersistenceFilter;
/*     */ import org.springframework.security.web.context.SecurityContextRepository;
/*     */ import org.springframework.security.web.session.ForceEagerSessionCreationFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityContextConfigurer<H extends HttpSecurityBuilder<H>>
/*     */   extends AbstractHttpConfigurer<SecurityContextConfigurer<H>, H>
/*     */ {
/*     */   private boolean requireExplicitSave = true;
/*     */   
/*     */   public SecurityContextConfigurer<H> securityContextRepository(SecurityContextRepository securityContextRepository) {
/*  84 */     ((HttpSecurityBuilder)getBuilder()).setSharedObject(SecurityContextRepository.class, securityContextRepository);
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public SecurityContextConfigurer<H> requireExplicitSave(boolean requireExplicitSave) {
/*  89 */     this.requireExplicitSave = requireExplicitSave;
/*  90 */     return this;
/*     */   }
/*     */   
/*     */   boolean isRequireExplicitSave() {
/*  94 */     return this.requireExplicitSave;
/*     */   }
/*     */   
/*     */   SecurityContextRepository getSecurityContextRepository() {
/*     */     DelegatingSecurityContextRepository delegatingSecurityContextRepository;
/*  99 */     SecurityContextRepository securityContextRepository = (SecurityContextRepository)((HttpSecurityBuilder)getBuilder()).getSharedObject(SecurityContextRepository.class);
/* 100 */     if (securityContextRepository == null) {
/* 101 */       delegatingSecurityContextRepository = new DelegatingSecurityContextRepository(new SecurityContextRepository[] { (SecurityContextRepository)new RequestAttributeSecurityContextRepository(), (SecurityContextRepository)new HttpSessionSecurityContextRepository() });
/*     */     }
/*     */     
/* 104 */     return (SecurityContextRepository)delegatingSecurityContextRepository;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(H http) {
/* 110 */     SecurityContextRepository securityContextRepository = getSecurityContextRepository();
/* 111 */     if (this.requireExplicitSave) {
/* 112 */       SecurityContextHolderFilter securityContextHolderFilter = (SecurityContextHolderFilter)postProcess(new SecurityContextHolderFilter(securityContextRepository));
/*     */       
/* 114 */       securityContextHolderFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 115 */       http.addFilter((Filter)securityContextHolderFilter);
/*     */     } else {
/*     */       
/* 118 */       SecurityContextPersistenceFilter securityContextFilter = new SecurityContextPersistenceFilter(securityContextRepository);
/*     */       
/* 120 */       securityContextFilter.setSecurityContextHolderStrategy(getSecurityContextHolderStrategy());
/* 121 */       SessionManagementConfigurer<?> sessionManagement = (SessionManagementConfigurer)http.getConfigurer(SessionManagementConfigurer.class);
/*     */       
/* 123 */       SessionCreationPolicy sessionCreationPolicy = (sessionManagement != null) ? sessionManagement.getSessionCreationPolicy() : null;
/* 124 */       if (SessionCreationPolicy.ALWAYS == sessionCreationPolicy) {
/* 125 */         securityContextFilter.setForceEagerSessionCreation(true);
/* 126 */         http.addFilter((Filter)postProcess(new ForceEagerSessionCreationFilter()));
/*     */       } 
/* 128 */       securityContextFilter = (SecurityContextPersistenceFilter)postProcess(securityContextFilter);
/* 129 */       http.addFilter((Filter)securityContextFilter);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\SecurityContextConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */