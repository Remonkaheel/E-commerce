/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
/*     */ import org.springframework.security.config.annotation.web.oauth2.resourceserver.JwtDsl;
/*     */ import org.springframework.security.config.annotation.web.oauth2.resourceserver.OpaqueTokenDsl;
/*     */ import org.springframework.security.oauth2.server.resource.web.BearerTokenResolver;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.access.AccessDeniedHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000^\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020$\032\024\022\n\022\b\022\004\022\0020 0\037\022\004\022\0020!0\035H\000¢\006\002\b%J\037\020\034\032\0020!2\027\020&\032\023\022\004\022\0020'\022\004\022\0020!0\035¢\006\002\b(J\037\020\"\032\0020!2\027\020)\032\023\022\004\022\0020*\022\004\022\0020!0\035¢\006\002\b(R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\"\020\017\032\n\022\004\022\0020\021\030\0010\020X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R\034\020\026\032\004\030\0010\027X\016¢\006\016\n\000\032\004\b\030\020\031\"\004\b\032\020\033R&\020\034\032\032\022\016\022\f0\036R\b\022\004\022\0020 0\037\022\004\022\0020!\030\0010\035X\016¢\006\002\n\000R&\020\"\032\032\022\016\022\f0#R\b\022\004\022\0020 0\037\022\004\022\0020!\030\0010\035X\016¢\006\002\n\000¨\006+"}, d2 = {"Lorg/springframework/security/config/annotation/web/OAuth2ResourceServerDsl;", "", "()V", "accessDeniedHandler", "Lorg/springframework/security/web/access/AccessDeniedHandler;", "getAccessDeniedHandler", "()Lorg/springframework/security/web/access/AccessDeniedHandler;", "setAccessDeniedHandler", "(Lorg/springframework/security/web/access/AccessDeniedHandler;)V", "authenticationEntryPoint", "Lorg/springframework/security/web/AuthenticationEntryPoint;", "getAuthenticationEntryPoint", "()Lorg/springframework/security/web/AuthenticationEntryPoint;", "setAuthenticationEntryPoint", "(Lorg/springframework/security/web/AuthenticationEntryPoint;)V", "authenticationManagerResolver", "Lorg/springframework/security/authentication/AuthenticationManagerResolver;", "Ljakarta/servlet/http/HttpServletRequest;", "getAuthenticationManagerResolver", "()Lorg/springframework/security/authentication/AuthenticationManagerResolver;", "setAuthenticationManagerResolver", "(Lorg/springframework/security/authentication/AuthenticationManagerResolver;)V", "bearerTokenResolver", "Lorg/springframework/security/oauth2/server/resource/web/BearerTokenResolver;", "getBearerTokenResolver", "()Lorg/springframework/security/oauth2/server/resource/web/BearerTokenResolver;", "setBearerTokenResolver", "(Lorg/springframework/security/oauth2/server/resource/web/BearerTokenResolver;)V", "jwt", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$JwtConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "opaqueToken", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer$OpaqueTokenConfigurer;", "get", "get$spring_security_config", "jwtConfig", "Lorg/springframework/security/config/annotation/web/oauth2/resourceserver/JwtDsl;", "Lkotlin/ExtensionFunctionType;", "opaqueTokenConfig", "Lorg/springframework/security/config/annotation/web/oauth2/resourceserver/OpaqueTokenDsl;", "spring-security-config"})
/*     */ public final class OAuth2ResourceServerDsl
/*     */ {
/*     */   @Nullable
/*     */   private AccessDeniedHandler accessDeniedHandler;
/*     */   @Nullable
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/*     */   @Nullable
/*     */   private BearerTokenResolver bearerTokenResolver;
/*     */   @Nullable
/*     */   private AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2ResourceServerConfigurer<HttpSecurity>.JwtConfigurer, Unit> jwt;
/*     */   @Nullable
/*     */   private Function1<? super OAuth2ResourceServerConfigurer<HttpSecurity>.OpaqueTokenConfigurer, Unit> opaqueToken;
/*     */   
/*     */   @Nullable
/*     */   public final AccessDeniedHandler getAccessDeniedHandler() {
/*  44 */     return this.accessDeniedHandler; } public final void setAccessDeniedHandler(@Nullable AccessDeniedHandler <set-?>) { this.accessDeniedHandler = <set-?>; } @Nullable
/*  45 */   public final AuthenticationEntryPoint getAuthenticationEntryPoint() { return this.authenticationEntryPoint; } public final void setAuthenticationEntryPoint(@Nullable AuthenticationEntryPoint <set-?>) { this.authenticationEntryPoint = <set-?>; } @Nullable
/*  46 */   public final BearerTokenResolver getBearerTokenResolver() { return this.bearerTokenResolver; } public final void setBearerTokenResolver(@Nullable BearerTokenResolver <set-?>) { this.bearerTokenResolver = <set-?>; } @Nullable
/*  47 */   public final AuthenticationManagerResolver<HttpServletRequest> getAuthenticationManagerResolver() { return this.authenticationManagerResolver; } public final void setAuthenticationManagerResolver(@Nullable AuthenticationManagerResolver<HttpServletRequest> <set-?>) { this.authenticationManagerResolver = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void jwt(@NotNull Function1 jwtConfig) {
/*  80 */     Intrinsics.checkNotNullParameter(jwtConfig, "jwtConfig"); JwtDsl jwtDsl = new JwtDsl(); jwtConfig.invoke(jwtDsl); this.jwt = jwtDsl.get$spring_security_config();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void opaqueToken(@NotNull Function1 opaqueTokenConfig) {
/* 109 */     Intrinsics.checkNotNullParameter(opaqueTokenConfig, "opaqueTokenConfig"); OpaqueTokenDsl opaqueTokenDsl = new OpaqueTokenDsl(); opaqueTokenConfig.invoke(opaqueTokenDsl); this.opaqueToken = opaqueTokenDsl.get$spring_security_config();
/*     */   }
/*     */   
/*     */   @NotNull
/* 113 */   public final Function1<OAuth2ResourceServerConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new OAuth2ResourceServerDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oauth2ResourceServer", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/server/resource/OAuth2ResourceServerConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOAuth2ResourceServerDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OAuth2ResourceServerDsl.kt\norg/springframework/security/config/annotation/web/OAuth2ResourceServerDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,123:1\n1#2:124\n*E\n"})
/* 114 */   static final class OAuth2ResourceServerDsl$get$1 extends Lambda implements Function1<OAuth2ResourceServerConfigurer<HttpSecurity>, Unit> { public final void invoke(OAuth2ResourceServerConfigurer oauth2ResourceServer) { Intrinsics.checkNotNullParameter(oauth2ResourceServer, "oauth2ResourceServer"); if (OAuth2ResourceServerDsl.this.getAccessDeniedHandler() != null) { AccessDeniedHandler accessDeniedHandler1 = OAuth2ResourceServerDsl.this.getAccessDeniedHandler(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; AccessDeniedHandler it = accessDeniedHandler1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 124 */         int $i$a$-also-OAuth2ResourceServerDsl$get$1$1 = 0; oauth2ResourceServer.accessDeniedHandler(oAuth2ResourceServerDsl.getAccessDeniedHandler()); } else { OAuth2ResourceServerDsl.this.getAccessDeniedHandler(); }  if (OAuth2ResourceServerDsl.this.getAuthenticationEntryPoint() != null) { AuthenticationEntryPoint authenticationEntryPoint1 = OAuth2ResourceServerDsl.this.getAuthenticationEntryPoint(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; AuthenticationEntryPoint it = authenticationEntryPoint1; int $i$a$-also-OAuth2ResourceServerDsl$get$1$2 = 0; oauth2ResourceServer.authenticationEntryPoint(oAuth2ResourceServerDsl.getAuthenticationEntryPoint()); } else { OAuth2ResourceServerDsl.this.getAuthenticationEntryPoint(); }  if (OAuth2ResourceServerDsl.this.getBearerTokenResolver() != null) { BearerTokenResolver bearerTokenResolver1 = OAuth2ResourceServerDsl.this.getBearerTokenResolver(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; BearerTokenResolver it = bearerTokenResolver1; int $i$a$-also-OAuth2ResourceServerDsl$get$1$3 = 0; oauth2ResourceServer.bearerTokenResolver(oAuth2ResourceServerDsl.getBearerTokenResolver()); } else { OAuth2ResourceServerDsl.this.getBearerTokenResolver(); }  if (OAuth2ResourceServerDsl.this.getAuthenticationManagerResolver() != null) { AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver1 = OAuth2ResourceServerDsl.this.getAuthenticationManagerResolver(); OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; AuthenticationManagerResolver<HttpServletRequest> it = authenticationManagerResolver1; int $i$a$-also-OAuth2ResourceServerDsl$get$1$4 = 0; oauth2ResourceServer.authenticationManagerResolver(oAuth2ResourceServerDsl.getAuthenticationManagerResolver()); } else { OAuth2ResourceServerDsl.this.getAuthenticationManagerResolver(); }  if (OAuth2ResourceServerDsl.this.jwt != null) { Function1 function11 = OAuth2ResourceServerDsl.this.jwt; OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; Function1 it = function11; int $i$a$-also-OAuth2ResourceServerDsl$get$1$5 = 0; oAuth2ResourceServerDsl.jwt; oauth2ResourceServer.jwt((oAuth2ResourceServerDsl.jwt != null) ? oAuth2ResourceServerDsl.jwt::invoke$lambda$5$lambda$4 : null); } else { OAuth2ResourceServerDsl.this.jwt; }  if (OAuth2ResourceServerDsl.this.opaqueToken != null) { Function1 function11 = OAuth2ResourceServerDsl.this.opaqueToken; OAuth2ResourceServerDsl oAuth2ResourceServerDsl = OAuth2ResourceServerDsl.this; Function1 it = function11; int $i$a$-also-OAuth2ResourceServerDsl$get$1$6 = 0;
/*     */         oAuth2ResourceServerDsl.opaqueToken;
/*     */         oauth2ResourceServer.opaqueToken((oAuth2ResourceServerDsl.opaqueToken != null) ? oAuth2ResourceServerDsl.opaqueToken::invoke$lambda$7$lambda$6 : null); }
/*     */       else
/*     */       { OAuth2ResourceServerDsl.this.opaqueToken; }
/*     */        }
/*     */ 
/*     */     
/*     */     private static final void invoke$lambda$5$lambda$4(Function1 $tmp0, OAuth2ResourceServerConfigurer.JwtConfigurer t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     private static final void invoke$lambda$7$lambda$6(Function1 $tmp0, OAuth2ResourceServerConfigurer.OpaqueTokenConfigurer t) {
/*     */       $tmp0.invoke(t);
/*     */     }
/*     */     
/*     */     OAuth2ResourceServerDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OAuth2ResourceServerDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */