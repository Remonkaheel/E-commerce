/*    */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*    */ import org.springframework.security.oauth2.client.oidc.authentication.logout.OidcLogoutToken;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OidcBackChannelLogoutAuthentication
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 9095810699956350287L;
/*    */   private final OidcLogoutToken logoutToken;
/*    */   private final ClientRegistration clientRegistration;
/*    */   
/*    */   OidcBackChannelLogoutAuthentication(OidcLogoutToken logoutToken, ClientRegistration clientRegistration) {
/* 52 */     super(Collections.emptyList());
/* 53 */     this.logoutToken = logoutToken;
/* 54 */     this.clientRegistration = clientRegistration;
/* 55 */     setAuthenticated(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OidcLogoutToken getPrincipal() {
/* 63 */     return this.logoutToken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OidcLogoutToken getCredentials() {
/* 71 */     return this.logoutToken;
/*    */   }
/*    */   
/*    */   ClientRegistration getClientRegistration() {
/* 75 */     return this.clientRegistration;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcBackChannelLogoutAuthentication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */