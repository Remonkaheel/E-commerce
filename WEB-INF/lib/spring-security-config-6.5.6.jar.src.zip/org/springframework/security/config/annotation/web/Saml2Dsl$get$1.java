/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.saml2.Saml2LoginConfigurer;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "saml2Login", "Lorg/springframework/security/config/annotation/web/configurers/saml2/Saml2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*     */ @SourceDebugExtension({"SMAP\nSaml2Dsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Saml2Dsl.kt\norg/springframework/security/config/annotation/web/Saml2Dsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,101:1\n1#2:102\n*E\n"})
/*     */ final class Saml2Dsl$get$1
/*     */   extends Lambda
/*     */   implements Function1<Saml2LoginConfigurer<HttpSecurity>, Unit>
/*     */ {
/*     */   public final void invoke(Saml2LoginConfigurer saml2Login) {
/*  84 */     Intrinsics.checkNotNullParameter(saml2Login, "saml2Login"); if (Saml2Dsl.this.getRelyingPartyRegistrationRepository() != null) { RelyingPartyRegistrationRepository relyingPartyRegistrationRepository1 = Saml2Dsl.this.getRelyingPartyRegistrationRepository(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; RelyingPartyRegistrationRepository relyingPartyRegistrationRepository2 = relyingPartyRegistrationRepository1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       int $i$a$-also-Saml2Dsl$get$1$1 = 0; saml2Login.relyingPartyRegistrationRepository(saml2Dsl1.getRelyingPartyRegistrationRepository()); } else { Saml2Dsl.this.getRelyingPartyRegistrationRepository(); }  if (Saml2Dsl.this.getLoginPage() != null) { String str2 = Saml2Dsl.this.getLoginPage(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; String str3 = str2; int $i$a$-also-Saml2Dsl$get$1$2 = 0; saml2Login.loginPage(saml2Dsl1.getLoginPage()); } else { Saml2Dsl.this.getLoginPage(); }  if (Saml2Dsl.this.getFailureUrl() != null) { String str2 = Saml2Dsl.this.getFailureUrl(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; String str3 = str2; int $i$a$-also-Saml2Dsl$get$1$3 = 0; saml2Login.failureUrl(saml2Dsl1.getFailureUrl()); } else { Saml2Dsl.this.getFailureUrl(); }  if (Saml2Dsl.this.getLoginProcessingUrl() != null) { String str2 = Saml2Dsl.this.getLoginProcessingUrl(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; String str3 = str2; int $i$a$-also-Saml2Dsl$get$1$4 = 0; saml2Login.loginProcessingUrl(saml2Dsl1.getLoginProcessingUrl()); } else { Saml2Dsl.this.getLoginProcessingUrl(); }  if (Saml2Dsl.this.getPermitAll() != null) { Boolean bool = Saml2Dsl.this.getPermitAll(); Saml2Dsl saml2Dsl1 = Saml2Dsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-Saml2Dsl$get$1$5 = 0; Intrinsics.checkNotNull(saml2Dsl1.getPermitAll()); saml2Login.permitAll(saml2Dsl1.getPermitAll().booleanValue()); } else { Saml2Dsl.this.getPermitAll(); }  Pair pair1 = Saml2Dsl.access$getDefaultSuccessUrlOption$p(Saml2Dsl.this); Saml2Dsl saml2Dsl = Saml2Dsl.this; Pair pair2 = pair1; int $i$a$-also-Saml2Dsl$get$1$6 = 0; Intrinsics.checkNotNull(Saml2Dsl.access$getDefaultSuccessUrlOption$p(saml2Dsl)); Intrinsics.checkNotNull(Saml2Dsl.access$getDefaultSuccessUrlOption$p(saml2Dsl)); saml2Login.defaultSuccessUrl((String)Saml2Dsl.access$getDefaultSuccessUrlOption$p(saml2Dsl).getFirst(), ((Boolean)Saml2Dsl.access$getDefaultSuccessUrlOption$p(saml2Dsl).getSecond()).booleanValue()); Saml2Dsl.access$getDefaultSuccessUrlOption$p(Saml2Dsl.this); String str1 = Saml2Dsl.this.getAuthenticationRequestUriQuery(); saml2Dsl = Saml2Dsl.this; String it = str1; int $i$a$-also-Saml2Dsl$get$1$7 = 0; saml2Login.authenticationRequestUriQuery(saml2Dsl.getAuthenticationRequestUriQuery()); Saml2Dsl.this.getAuthenticationRequestUriQuery(); if (Saml2Dsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = Saml2Dsl.this.getAuthenticationSuccessHandler(); saml2Dsl = Saml2Dsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-Saml2Dsl$get$1$8 = 0; saml2Login.successHandler(saml2Dsl.getAuthenticationSuccessHandler()); } else { Saml2Dsl.this.getAuthenticationSuccessHandler(); }  if (Saml2Dsl.this.getAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = Saml2Dsl.this.getAuthenticationFailureHandler(); saml2Dsl = Saml2Dsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-Saml2Dsl$get$1$9 = 0; saml2Login.failureHandler(saml2Dsl.getAuthenticationFailureHandler()); } else { Saml2Dsl.this.getAuthenticationFailureHandler(); }  if (Saml2Dsl.this.getAuthenticationManager() != null) { AuthenticationManager authenticationManager1 = Saml2Dsl.this.getAuthenticationManager(); saml2Dsl = Saml2Dsl.this; AuthenticationManager authenticationManager2 = authenticationManager1; int $i$a$-also-Saml2Dsl$get$1$10 = 0;
/*     */       saml2Login.authenticationManager(saml2Dsl.getAuthenticationManager()); }
/*     */     else
/*     */     { Saml2Dsl.this.getAuthenticationManager(); }
/*     */   
/*     */   }
/*     */   
/*     */   Saml2Dsl$get$1() {
/*     */     super(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\Saml2Dsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */