/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.ProviderManager;
/*     */ import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
/*     */ import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*     */ import org.springframework.security.web.authentication.logout.CompositeLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.web.csrf.CsrfFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BackChannelLogoutConfigurer
/*     */ {
/*     */   private AuthenticationConverter authenticationConverter;
/* 133 */   private final AuthenticationManager authenticationManager = (AuthenticationManager)new ProviderManager(new AuthenticationProvider[] { new OidcBackChannelLogoutAuthenticationProvider() });
/*     */ 
/*     */   
/* 136 */   private Function<B, LogoutHandler> logoutHandler = this::logoutHandler;
/*     */   
/*     */   private AuthenticationConverter authenticationConverter(B http) {
/* 139 */     if (this.authenticationConverter == null) {
/*     */       
/* 141 */       ClientRegistrationRepository clientRegistrationRepository = OAuth2ClientConfigurerUtils.getClientRegistrationRepository((HttpSecurityBuilder)http);
/* 142 */       this.authenticationConverter = new OidcLogoutAuthenticationConverter(clientRegistrationRepository);
/*     */     } 
/* 144 */     return this.authenticationConverter;
/*     */   }
/*     */   
/*     */   private AuthenticationManager authenticationManager() {
/* 148 */     return this.authenticationManager;
/*     */   }
/*     */   
/*     */   private LogoutHandler logoutHandler(B http) {
/* 152 */     OidcBackChannelLogoutHandler logoutHandler = getBeanOrNull(OidcBackChannelLogoutHandler.class);
/* 153 */     if (logoutHandler != null) {
/* 154 */       return logoutHandler;
/*     */     }
/* 156 */     logoutHandler = new OidcBackChannelLogoutHandler(OAuth2ClientConfigurerUtils.getOidcSessionRegistry((HttpSecurityBuilder)http));
/* 157 */     return logoutHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BackChannelLogoutConfigurer logoutUri(String logoutUri) {
/* 190 */     this.logoutHandler = (http -> {
/*     */         OidcBackChannelLogoutHandler logoutHandler = new OidcBackChannelLogoutHandler(OAuth2ClientConfigurerUtils.getOidcSessionRegistry(http));
/*     */         
/*     */         logoutHandler.setLogoutUri(logoutUri);
/*     */         return logoutHandler;
/*     */       });
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BackChannelLogoutConfigurer logoutHandler(LogoutHandler logoutHandler) {
/* 271 */     this.logoutHandler = (http -> logoutHandler);
/* 272 */     return this;
/*     */   }
/*     */   void configure(B http) {
/*     */     CompositeLogoutHandler compositeLogoutHandler;
/* 276 */     LogoutHandler oidcLogout = this.logoutHandler.apply(http);
/* 277 */     SecurityContextLogoutHandler securityContextLogoutHandler = new SecurityContextLogoutHandler();
/* 278 */     LogoutConfigurer<B> logout = (LogoutConfigurer<B>)http.getConfigurer(LogoutConfigurer.class);
/* 279 */     if (logout != null) {
/* 280 */       compositeLogoutHandler = new CompositeLogoutHandler(logout.getLogoutHandlers());
/*     */     }
/*     */     
/* 283 */     OidcBackChannelLogoutFilter filter = new OidcBackChannelLogoutFilter(authenticationConverter(http), authenticationManager(), new EitherLogoutHandler(oidcLogout, (LogoutHandler)compositeLogoutHandler));
/* 284 */     http.addFilterBefore((Filter)filter, CsrfFilter.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T getBeanOrNull(Class<?> clazz) {
/* 289 */     ApplicationContext context = (ApplicationContext)((HttpSecurityBuilder)OidcLogoutConfigurer.access$000(OidcLogoutConfigurer.this)).getSharedObject(ApplicationContext.class);
/* 290 */     if (context == null) {
/* 291 */       return null;
/*     */     }
/* 293 */     return (T)context.getBeanProvider(clazz).getIfUnique();
/*     */   }
/*     */   
/*     */   private static final class EitherLogoutHandler
/*     */     implements LogoutHandler
/*     */   {
/*     */     private final LogoutHandler left;
/*     */     private final LogoutHandler right;
/*     */     
/*     */     EitherLogoutHandler(LogoutHandler left, LogoutHandler right) {
/* 303 */       this.left = left;
/* 304 */       this.right = right;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
/* 310 */       if (request.getParameter("_spring_security_internal_logout") == null) {
/* 311 */         this.left.logout(request, response, authentication);
/*     */       } else {
/*     */         
/* 314 */         this.right.logout(request, response, authentication);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcLogoutConfigurer$BackChannelLogoutConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */