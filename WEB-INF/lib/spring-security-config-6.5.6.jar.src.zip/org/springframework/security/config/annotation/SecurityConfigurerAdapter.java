/*     */ package org.springframework.security.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.security.config.ObjectPostProcessor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SecurityConfigurerAdapter<O, B extends SecurityBuilder<O>>
/*     */   implements SecurityConfigurer<O, B>
/*     */ {
/*     */   private B securityBuilder;
/*  43 */   private CompositeObjectPostProcessor objectPostProcessor = new CompositeObjectPostProcessor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(B builder) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(B builder) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.1", forRemoval = true)
/*     */   public B and() {
/*  61 */     return getBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final B getBuilder() {
/*  70 */     Assert.state((this.securityBuilder != null), "securityBuilder cannot be null");
/*  71 */     return this.securityBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T postProcess(T object) {
/*  82 */     return (T)this.objectPostProcessor.postProcess(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/*  92 */     this.objectPostProcessor.addObjectPostProcessor(objectPostProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.4", forRemoval = true)
/*     */   public void addObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 101 */     this.objectPostProcessor.addObjectPostProcessor(objectPostProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuilder(B builder) {
/* 110 */     this.securityBuilder = builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CompositeObjectPostProcessor
/*     */     implements ObjectPostProcessor<Object>
/*     */   {
/* 121 */     private List<ObjectPostProcessor<?>> postProcessors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*     */     public Object postProcess(Object object) {
/* 126 */       for (ObjectPostProcessor<?> opp : this.postProcessors) {
/* 127 */         Class<?> oppClass = opp.getClass();
/* 128 */         Class<?> oppType = GenericTypeResolver.resolveTypeArgument(oppClass, ObjectPostProcessor.class);
/* 129 */         if (oppType == null || oppType.isAssignableFrom(object.getClass())) {
/* 130 */           object = opp.postProcess(object);
/*     */         }
/*     */       } 
/* 133 */       return object;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean addObjectPostProcessor(ObjectPostProcessor<?> objectPostProcessor) {
/* 142 */       boolean result = this.postProcessors.add(objectPostProcessor);
/* 143 */       this.postProcessors.sort((Comparator<? super ObjectPostProcessor<?>>)AnnotationAwareOrderComparator.INSTANCE);
/* 144 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\SecurityConfigurerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */