/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(forRemoval = true)
/*    */ public final class RequestMatcherFactory
/*    */ {
/*    */   private static PathPatternRequestMatcher.Builder builder;
/*    */   
/*    */   public static void setApplicationContext(ApplicationContext context) {
/* 37 */     builder = (PathPatternRequestMatcher.Builder)context.getBeanProvider(PathPatternRequestMatcher.Builder.class).getIfUnique();
/*    */   }
/*    */   
/*    */   public static boolean usesPathPatterns() {
/* 41 */     return (builder != null);
/*    */   }
/*    */   
/*    */   public static RequestMatcher matcher(String path) {
/* 45 */     return matcher(null, path);
/*    */   }
/*    */   
/*    */   public static RequestMatcher matcher(HttpMethod method, String path) {
/* 49 */     if (builder != null) {
/* 50 */       return (RequestMatcher)builder.matcher(method, path);
/*    */     }
/* 52 */     return (RequestMatcher)new AntPathRequestMatcher(path, (method != null) ? method.name() : null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\RequestMatcherFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */