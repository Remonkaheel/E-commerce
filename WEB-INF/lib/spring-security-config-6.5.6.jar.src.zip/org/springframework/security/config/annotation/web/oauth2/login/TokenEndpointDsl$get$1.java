/*    */ package org.springframework.security.config.annotation.web.oauth2.login;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*    */ import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "tokenEndpoint", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer$TokenEndpointConfig;", "Lorg/springframework/security/config/annotation/web/configurers/oauth2/client/OAuth2LoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nTokenEndpointDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TokenEndpointDsl.kt\norg/springframework/security/config/annotation/web/oauth2/login/TokenEndpointDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,43:1\n1#2:44\n*E\n"})
/*    */ final class TokenEndpointDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<OAuth2LoginConfigurer<HttpSecurity>.TokenEndpointConfig, Unit>
/*    */ {
/*    */   public final void invoke(OAuth2LoginConfigurer.TokenEndpointConfig tokenEndpoint) {
/* 39 */     Intrinsics.checkNotNullParameter(tokenEndpoint, "tokenEndpoint"); if (TokenEndpointDsl.this.getAccessTokenResponseClient() != null) { OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> oAuth2AccessTokenResponseClient1 = TokenEndpointDsl.this.getAccessTokenResponseClient(); TokenEndpointDsl tokenEndpointDsl = TokenEndpointDsl.this; OAuth2AccessTokenResponseClient<OAuth2AuthorizationCodeGrantRequest> it = oAuth2AccessTokenResponseClient1;
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 44 */       int $i$a$-also-TokenEndpointDsl$get$1$1 = 0;
/*    */       tokenEndpoint.accessTokenResponseClient(tokenEndpointDsl.getAccessTokenResponseClient()); }
/*    */     else
/*    */     { TokenEndpointDsl.this.getAccessTokenResponseClient(); }
/*    */   
/*    */   }
/*    */   
/*    */   TokenEndpointDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\oauth2\login\TokenEndpointDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */