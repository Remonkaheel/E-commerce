/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "hsts", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HstsConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/*    */ @SourceDebugExtension({"SMAP\nHttpStrictTransportSecurityDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpStrictTransportSecurityDsl.kt\norg/springframework/security/config/annotation/web/headers/HttpStrictTransportSecurityDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,65:1\n1#2:66\n*E\n"})
/*    */ final class HttpStrictTransportSecurityDsl$get$1
/*    */   extends Lambda
/*    */   implements Function1<HeadersConfigurer<HttpSecurity>.HstsConfig, Unit>
/*    */ {
/*    */   public final void invoke(HeadersConfigurer.HstsConfig hsts) {
/* 55 */     Intrinsics.checkNotNullParameter(hsts, "hsts"); if (HttpStrictTransportSecurityDsl.this.getMaxAgeInSeconds() != null) { Long long_ = HttpStrictTransportSecurityDsl.this.getMaxAgeInSeconds(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; long it = long_.longValue();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 66 */       int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$1 = 0; Intrinsics.checkNotNull(httpStrictTransportSecurityDsl.getMaxAgeInSeconds()); hsts.maxAgeInSeconds(httpStrictTransportSecurityDsl.getMaxAgeInSeconds().longValue()); } else { HttpStrictTransportSecurityDsl.this.getMaxAgeInSeconds(); }  if (HttpStrictTransportSecurityDsl.this.getRequestMatcher() != null) { RequestMatcher requestMatcher1 = HttpStrictTransportSecurityDsl.this.getRequestMatcher(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; RequestMatcher it = requestMatcher1; int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$2 = 0; hsts.requestMatcher(httpStrictTransportSecurityDsl.getRequestMatcher()); } else { HttpStrictTransportSecurityDsl.this.getRequestMatcher(); }  if (HttpStrictTransportSecurityDsl.this.getIncludeSubDomains() != null) { Boolean bool = HttpStrictTransportSecurityDsl.this.getIncludeSubDomains(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$3 = 0; Intrinsics.checkNotNull(httpStrictTransportSecurityDsl.getIncludeSubDomains()); hsts.includeSubDomains(httpStrictTransportSecurityDsl.getIncludeSubDomains().booleanValue()); } else { HttpStrictTransportSecurityDsl.this.getIncludeSubDomains(); }  if (HttpStrictTransportSecurityDsl.this.getPreload() != null) { Boolean bool = HttpStrictTransportSecurityDsl.this.getPreload(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$4 = 0;
/*    */       Intrinsics.checkNotNull(httpStrictTransportSecurityDsl.getPreload());
/*    */       hsts.preload(httpStrictTransportSecurityDsl.getPreload().booleanValue()); }
/*    */     else
/*    */     { HttpStrictTransportSecurityDsl.this.getPreload(); }
/*    */     
/*    */     if (HttpStrictTransportSecurityDsl.access$getDisabled$p(HttpStrictTransportSecurityDsl.this))
/*    */       hsts.disable(); 
/*    */   }
/*    */   
/*    */   HttpStrictTransportSecurityDsl$get$1() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\HttpStrictTransportSecurityDsl$get$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */