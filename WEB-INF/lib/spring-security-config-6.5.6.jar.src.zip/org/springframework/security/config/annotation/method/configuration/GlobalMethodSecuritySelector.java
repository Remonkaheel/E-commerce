/*    */ package org.springframework.security.config.annotation.method.configuration;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ import org.springframework.context.annotation.ImportSelector;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ final class GlobalMethodSecuritySelector
/*    */   implements ImportSelector
/*    */ {
/*    */   public String[] selectImports(AnnotationMetadata importingClassMetadata) {
/* 44 */     Class<EnableGlobalMethodSecurity> annoType = EnableGlobalMethodSecurity.class;
/* 45 */     Map<String, Object> annotationAttributes = importingClassMetadata.getAnnotationAttributes(annoType.getName(), false);
/*    */     
/* 47 */     AnnotationAttributes attributes = AnnotationAttributes.fromMap(annotationAttributes);
/* 48 */     Assert.notNull(attributes, () -> String.format("@%s is not present on importing class '%s' as expected", new Object[] { annoType.getSimpleName(), importingClassMetadata.getClassName() }));
/*    */ 
/*    */     
/* 51 */     Class<?> importingClass = ClassUtils.resolveClassName(importingClassMetadata.getClassName(), 
/* 52 */         ClassUtils.getDefaultClassLoader());
/*    */     
/* 54 */     boolean skipMethodSecurityConfiguration = GlobalMethodSecurityConfiguration.class.isAssignableFrom(importingClass);
/* 55 */     AdviceMode mode = (AdviceMode)attributes.getEnum("mode");
/* 56 */     boolean isProxy = (AdviceMode.PROXY == mode);
/*    */     
/* 58 */     String autoProxyClassName = isProxy ? AutoProxyRegistrar.class.getName() : GlobalMethodSecurityAspectJAutoProxyRegistrar.class.getName();
/* 59 */     boolean jsr250Enabled = attributes.getBoolean("jsr250Enabled");
/* 60 */     List<String> classNames = new ArrayList<>(4);
/* 61 */     if (isProxy) {
/* 62 */       classNames.add(MethodSecurityMetadataSourceAdvisorRegistrar.class.getName());
/*    */     }
/* 64 */     classNames.add(autoProxyClassName);
/* 65 */     if (!skipMethodSecurityConfiguration) {
/* 66 */       classNames.add(GlobalMethodSecurityConfiguration.class.getName());
/*    */     }
/* 68 */     if (jsr250Enabled) {
/* 69 */       classNames.add(Jsr250MetadataSourceConfiguration.class.getName());
/*    */     }
/* 71 */     return classNames.<String>toArray(new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\method\configuration\GlobalMethodSecuritySelector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */