/*    */ package org.springframework.security.config.annotation.web.session;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
/*    */ import org.springframework.security.core.session.SessionRegistry;
/*    */ import org.springframework.security.web.authentication.session.SessionLimit;
/*    */ import org.springframework.security.web.session.SessionInformationExpiredStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SessionSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000R\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\020\013\n\002\b\006\n\002\020\b\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\003\b\007\030\0002\0020\001B\005¢\006\002\020\002J#\020%\032\030\022\016\022\f0'R\b\022\004\022\0020)0(\022\004\022\0020*0&H\000¢\006\002\b+J\016\020\026\032\0020*2\006\020,\032\0020\036R\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\036\020\017\032\004\030\0010\020X\016¢\006\020\n\002\020\025\032\004\b\021\020\022\"\004\b\023\020\024R\036\020\026\032\004\030\0010\027X\016¢\006\020\n\002\020\034\032\004\b\030\020\031\"\004\b\032\020\033R\020\020\035\032\004\030\0010\036X\016¢\006\002\n\000R\034\020\037\032\004\030\0010 X\016¢\006\016\n\000\032\004\b!\020\"\"\004\b#\020$¨\006-"}, d2 = {"Lorg/springframework/security/config/annotation/web/session/SessionConcurrencyDsl;", "", "()V", "expiredSessionStrategy", "Lorg/springframework/security/web/session/SessionInformationExpiredStrategy;", "getExpiredSessionStrategy", "()Lorg/springframework/security/web/session/SessionInformationExpiredStrategy;", "setExpiredSessionStrategy", "(Lorg/springframework/security/web/session/SessionInformationExpiredStrategy;)V", "expiredUrl", "", "getExpiredUrl", "()Ljava/lang/String;", "setExpiredUrl", "(Ljava/lang/String;)V", "maxSessionsPreventsLogin", "", "getMaxSessionsPreventsLogin", "()Ljava/lang/Boolean;", "setMaxSessionsPreventsLogin", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "maximumSessions", "", "getMaximumSessions", "()Ljava/lang/Integer;", "setMaximumSessions", "(Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "sessionLimit", "Lorg/springframework/security/web/authentication/session/SessionLimit;", "sessionRegistry", "Lorg/springframework/security/core/session/SessionRegistry;", "getSessionRegistry", "()Lorg/springframework/security/core/session/SessionRegistry;", "setSessionRegistry", "(Lorg/springframework/security/core/session/SessionRegistry;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$ConcurrencyControlConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "max", "spring-security-config"})
/*    */ public final class SessionConcurrencyDsl
/*    */ {
/*    */   @Nullable
/*    */   private Integer maximumSessions;
/*    */   @Nullable
/*    */   private String expiredUrl;
/*    */   @Nullable
/*    */   private SessionInformationExpiredStrategy expiredSessionStrategy;
/*    */   @Nullable
/*    */   private Boolean maxSessionsPreventsLogin;
/*    */   @Nullable
/*    */   private SessionRegistry sessionRegistry;
/*    */   @Nullable
/*    */   private SessionLimit sessionLimit;
/*    */   
/*    */   @Nullable
/*    */   public final Integer getMaximumSessions() {
/* 44 */     return this.maximumSessions; } public final void setMaximumSessions(@Nullable Integer <set-?>) { this.maximumSessions = <set-?>; } @Nullable
/* 45 */   public final String getExpiredUrl() { return this.expiredUrl; } public final void setExpiredUrl(@Nullable String <set-?>) { this.expiredUrl = <set-?>; } @Nullable
/* 46 */   public final SessionInformationExpiredStrategy getExpiredSessionStrategy() { return this.expiredSessionStrategy; } public final void setExpiredSessionStrategy(@Nullable SessionInformationExpiredStrategy <set-?>) { this.expiredSessionStrategy = <set-?>; } @Nullable
/* 47 */   public final Boolean getMaxSessionsPreventsLogin() { return this.maxSessionsPreventsLogin; } public final void setMaxSessionsPreventsLogin(@Nullable Boolean <set-?>) { this.maxSessionsPreventsLogin = <set-?>; } @Nullable
/* 48 */   public final SessionRegistry getSessionRegistry() { return this.sessionRegistry; } public final void setSessionRegistry(@Nullable SessionRegistry <set-?>) { this.sessionRegistry = <set-?>; }
/*    */ 
/*    */   
/*    */   public final void maximumSessions(@NotNull SessionLimit max) {
/* 52 */     Intrinsics.checkNotNullParameter(max, "max"); this.sessionLimit = max;
/*    */   }
/*    */   
/*    */   @NotNull
/* 56 */   public final Function1<SessionManagementConfigurer<HttpSecurity>.ConcurrencyControlConfigurer, Unit> get$spring_security_config() { Assert.isTrue((this.maximumSessions == null || this.sessionLimit == null), "You cannot specify maximumSessions as both an Int and a SessionLimit. Please use only one.");
/* 57 */     return new SessionConcurrencyDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "sessionConcurrencyControl", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer$ConcurrencyControlConfigurer;", "Lorg/springframework/security/config/annotation/web/configurers/SessionManagementConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"})
/* 58 */   static final class SessionConcurrencyDsl$get$1 extends Lambda implements Function1<SessionManagementConfigurer<HttpSecurity>.ConcurrencyControlConfigurer, Unit> { public final void invoke(SessionManagementConfigurer.ConcurrencyControlConfigurer sessionConcurrencyControl) { Intrinsics.checkNotNullParameter(sessionConcurrencyControl, "sessionConcurrencyControl"); Integer integer = SessionConcurrencyDsl.this.getMaximumSessions(); SessionConcurrencyDsl sessionConcurrencyDsl = SessionConcurrencyDsl.this; int i = integer.intValue(), $i$a$-also-SessionConcurrencyDsl$get$1$1 = 0;
/* 59 */       Intrinsics.checkNotNull(sessionConcurrencyDsl.getMaximumSessions()); sessionConcurrencyControl.maximumSessions(sessionConcurrencyDsl.getMaximumSessions().intValue());
/*    */       SessionConcurrencyDsl.this.getMaximumSessions();
/* 61 */       SessionLimit sessionLimit1 = SessionConcurrencyDsl.this.sessionLimit; sessionConcurrencyDsl = SessionConcurrencyDsl.this; SessionLimit sessionLimit2 = sessionLimit1; int $i$a$-also-SessionConcurrencyDsl$get$1$2 = 0;
/* 62 */       Intrinsics.checkNotNull(sessionConcurrencyDsl.sessionLimit); sessionConcurrencyControl.maximumSessions(sessionConcurrencyDsl.sessionLimit);
/*    */       SessionConcurrencyDsl.this.sessionLimit;
/* 64 */       String str1 = SessionConcurrencyDsl.this.getExpiredUrl(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; String str2 = str1; int $i$a$-also-SessionConcurrencyDsl$get$1$3 = 0;
/* 65 */       sessionConcurrencyControl.expiredUrl(sessionConcurrencyDsl.getExpiredUrl());
/*    */       SessionConcurrencyDsl.this.getExpiredUrl();
/* 67 */       SessionInformationExpiredStrategy sessionInformationExpiredStrategy1 = SessionConcurrencyDsl.this.getExpiredSessionStrategy(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; SessionInformationExpiredStrategy sessionInformationExpiredStrategy2 = sessionInformationExpiredStrategy1; int $i$a$-also-SessionConcurrencyDsl$get$1$4 = 0;
/* 68 */       sessionConcurrencyControl.expiredSessionStrategy(sessionConcurrencyDsl.getExpiredSessionStrategy());
/*    */       SessionConcurrencyDsl.this.getExpiredSessionStrategy();
/* 70 */       Boolean bool = SessionConcurrencyDsl.this.getMaxSessionsPreventsLogin(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-SessionConcurrencyDsl$get$1$5 = 0;
/* 71 */       Intrinsics.checkNotNull(sessionConcurrencyDsl.getMaxSessionsPreventsLogin()); sessionConcurrencyControl.maxSessionsPreventsLogin(sessionConcurrencyDsl.getMaxSessionsPreventsLogin().booleanValue());
/*    */       SessionConcurrencyDsl.this.getMaxSessionsPreventsLogin();
/* 73 */       SessionRegistry sessionRegistry1 = SessionConcurrencyDsl.this.getSessionRegistry(); sessionConcurrencyDsl = SessionConcurrencyDsl.this; SessionRegistry it = sessionRegistry1; int $i$a$-also-SessionConcurrencyDsl$get$1$6 = 0;
/* 74 */       sessionConcurrencyControl.sessionRegistry(sessionConcurrencyDsl.getSessionRegistry());
/*    */       SessionConcurrencyDsl.this.getSessionRegistry(); }
/*    */ 
/*    */     
/*    */     SessionConcurrencyDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\session\SessionConcurrencyDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */