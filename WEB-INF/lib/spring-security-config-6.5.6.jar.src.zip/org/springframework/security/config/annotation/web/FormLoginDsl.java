/*     */ package org.springframework.security.config.annotation.web;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.springframework.security.authentication.AuthenticationDetailsSource;
/*     */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*     */ import org.springframework.security.config.annotation.web.configurers.FormLoginConfigurer;
/*     */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*     */ 
/*     */ @SecurityMarker
/*     */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000P\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\020\016\n\002\020\013\n\002\b\031\n\002\020\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\026\0202\032\002032\006\0202\032\0020\0302\006\0204\032\0020\031J\006\0205\032\00203J\037\0206\032\024\022\n\022\b\022\004\022\0020908\022\004\022\0020307H\000¢\006\002\b:J\006\020)\032\00203R&\020\003\032\016\022\004\022\0020\005\022\002\b\003\030\0010\004X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\034\020\n\032\004\030\0010\013X\016¢\006\016\n\000\032\004\b\f\020\r\"\004\b\016\020\017R\034\020\020\032\004\030\0010\021X\016¢\006\016\n\000\032\004\b\022\020\023\"\004\b\024\020\025R\034\020\026\032\020\022\004\022\0020\030\022\004\022\0020\031\030\0010\027X\016¢\006\002\n\000R\016\020\032\032\0020\031X\016¢\006\002\n\000R\034\020\033\032\004\030\0010\030X\016¢\006\016\n\000\032\004\b\034\020\035\"\004\b\036\020\037R\034\020 \032\004\030\0010\030X\016¢\006\016\n\000\032\004\b!\020\035\"\004\b\"\020\037R\034\020#\032\004\030\0010\030X\016¢\006\016\n\000\032\004\b$\020\035\"\004\b%\020\037R\034\020&\032\004\030\0010\030X\016¢\006\016\n\000\032\004\b'\020\035\"\004\b(\020\037R\036\020)\032\004\030\0010\031X\016¢\006\020\n\002\020.\032\004\b*\020+\"\004\b,\020-R\034\020/\032\004\030\0010\030X\016¢\006\016\n\000\032\004\b0\020\035\"\004\b1\020\037¨\006;"}, d2 = {"Lorg/springframework/security/config/annotation/web/FormLoginDsl;", "", "()V", "authenticationDetailsSource", "Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "Ljakarta/servlet/http/HttpServletRequest;", "getAuthenticationDetailsSource", "()Lorg/springframework/security/authentication/AuthenticationDetailsSource;", "setAuthenticationDetailsSource", "(Lorg/springframework/security/authentication/AuthenticationDetailsSource;)V", "authenticationFailureHandler", "Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "getAuthenticationFailureHandler", "()Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "setAuthenticationFailureHandler", "(Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;)V", "authenticationSuccessHandler", "Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "getAuthenticationSuccessHandler", "()Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "setAuthenticationSuccessHandler", "(Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;)V", "defaultSuccessUrlOption", "Lkotlin/Pair;", "", "", "disabled", "failureUrl", "getFailureUrl", "()Ljava/lang/String;", "setFailureUrl", "(Ljava/lang/String;)V", "loginPage", "getLoginPage", "setLoginPage", "loginProcessingUrl", "getLoginProcessingUrl", "setLoginProcessingUrl", "passwordParameter", "getPasswordParameter", "setPasswordParameter", "permitAll", "getPermitAll", "()Ljava/lang/Boolean;", "setPermitAll", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "usernameParameter", "getUsernameParameter", "setUsernameParameter", "defaultSuccessUrl", "", "alwaysUse", "disable", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/FormLoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*     */ public final class FormLoginDsl {
/*     */   @Nullable
/*     */   private String loginPage;
/*     */   @Nullable
/*     */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*     */   @Nullable
/*     */   private AuthenticationFailureHandler authenticationFailureHandler;
/*     */   @Nullable
/*     */   private String failureUrl;
/*     */   @Nullable
/*     */   private String loginProcessingUrl;
/*     */   @Nullable
/*     */   private Boolean permitAll;
/*     */   @Nullable
/*     */   private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource;
/*     */   @Nullable
/*     */   private String usernameParameter;
/*     */   @Nullable
/*     */   private String passwordParameter;
/*     */   @Nullable
/*     */   private Pair<String, Boolean> defaultSuccessUrlOption;
/*     */   private boolean disabled;
/*     */   
/*     */   @Nullable
/*     */   public final String getLoginPage() {
/*  46 */     return this.loginPage; } public final void setLoginPage(@Nullable String <set-?>) { this.loginPage = <set-?>; } @Nullable
/*  47 */   public final AuthenticationSuccessHandler getAuthenticationSuccessHandler() { return this.authenticationSuccessHandler; } public final void setAuthenticationSuccessHandler(@Nullable AuthenticationSuccessHandler <set-?>) { this.authenticationSuccessHandler = <set-?>; } @Nullable
/*  48 */   public final AuthenticationFailureHandler getAuthenticationFailureHandler() { return this.authenticationFailureHandler; } public final void setAuthenticationFailureHandler(@Nullable AuthenticationFailureHandler <set-?>) { this.authenticationFailureHandler = <set-?>; } @Nullable
/*  49 */   public final String getFailureUrl() { return this.failureUrl; } public final void setFailureUrl(@Nullable String <set-?>) { this.failureUrl = <set-?>; } @Nullable
/*  50 */   public final String getLoginProcessingUrl() { return this.loginProcessingUrl; } public final void setLoginProcessingUrl(@Nullable String <set-?>) { this.loginProcessingUrl = <set-?>; } @Nullable
/*  51 */   public final Boolean getPermitAll() { return this.permitAll; } public final void setPermitAll(@Nullable Boolean <set-?>) { this.permitAll = <set-?>; } @Nullable
/*  52 */   public final AuthenticationDetailsSource<HttpServletRequest, ?> getAuthenticationDetailsSource() { return this.authenticationDetailsSource; } public final void setAuthenticationDetailsSource(@Nullable AuthenticationDetailsSource<HttpServletRequest, ?> <set-?>) { this.authenticationDetailsSource = <set-?>; } @Nullable
/*  53 */   public final String getUsernameParameter() { return this.usernameParameter; } public final void setUsernameParameter(@Nullable String <set-?>) { this.usernameParameter = <set-?>; } @Nullable
/*  54 */   public final String getPasswordParameter() { return this.passwordParameter; } public final void setPasswordParameter(@Nullable String <set-?>) { this.passwordParameter = <set-?>; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void disable() {
/*  66 */     this.disabled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void permitAll() {
/*  74 */     this.permitAll = Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void defaultSuccessUrl(@NotNull String defaultSuccessUrl, boolean alwaysUse) {
/*  87 */     Intrinsics.checkNotNullParameter(defaultSuccessUrl, "defaultSuccessUrl"); this.defaultSuccessUrlOption = new Pair(defaultSuccessUrl, Boolean.valueOf(alwaysUse));
/*     */   }
/*     */   
/*     */   @NotNull
/*  91 */   public final Function1<FormLoginConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new FormLoginDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "login", "Lorg/springframework/security/config/annotation/web/configurers/FormLoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nFormLoginDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FormLoginDsl.kt\norg/springframework/security/config/annotation/web/FormLoginDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,110:1\n1#2:111\n*E\n"})
/*  92 */   static final class FormLoginDsl$get$1 extends Lambda implements Function1<FormLoginConfigurer<HttpSecurity>, Unit> { public final void invoke(FormLoginConfigurer login) { Intrinsics.checkNotNullParameter(login, "login"); if (FormLoginDsl.this.getLoginPage() != null) { String str1 = FormLoginDsl.this.getLoginPage(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; String str2 = str1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 111 */         int $i$a$-also-FormLoginDsl$get$1$1 = 0; login.loginPage(formLoginDsl1.getLoginPage()); } else { FormLoginDsl.this.getLoginPage(); }  if (FormLoginDsl.this.getFailureUrl() != null) { String str1 = FormLoginDsl.this.getFailureUrl(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$2 = 0; login.failureUrl(formLoginDsl1.getFailureUrl()); } else { FormLoginDsl.this.getFailureUrl(); }  if (FormLoginDsl.this.getLoginProcessingUrl() != null) { String str1 = FormLoginDsl.this.getLoginProcessingUrl(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$3 = 0; login.loginProcessingUrl(formLoginDsl1.getLoginProcessingUrl()); } else { FormLoginDsl.this.getLoginProcessingUrl(); }  if (FormLoginDsl.this.getPermitAll() != null) { Boolean bool = FormLoginDsl.this.getPermitAll(); FormLoginDsl formLoginDsl1 = FormLoginDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-FormLoginDsl$get$1$4 = 0; Intrinsics.checkNotNull(formLoginDsl1.getPermitAll()); login.permitAll(formLoginDsl1.getPermitAll().booleanValue()); } else { FormLoginDsl.this.getPermitAll(); }  Pair pair1 = FormLoginDsl.this.defaultSuccessUrlOption; FormLoginDsl formLoginDsl = FormLoginDsl.this; Pair it = pair1; int $i$a$-also-FormLoginDsl$get$1$5 = 0; Intrinsics.checkNotNull(formLoginDsl.defaultSuccessUrlOption); Intrinsics.checkNotNull(formLoginDsl.defaultSuccessUrlOption); login.defaultSuccessUrl((String)formLoginDsl.defaultSuccessUrlOption.getFirst(), ((Boolean)formLoginDsl.defaultSuccessUrlOption.getSecond()).booleanValue()); FormLoginDsl.this.defaultSuccessUrlOption; if (FormLoginDsl.this.getAuthenticationSuccessHandler() != null) { AuthenticationSuccessHandler authenticationSuccessHandler1 = FormLoginDsl.this.getAuthenticationSuccessHandler(); formLoginDsl = FormLoginDsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-FormLoginDsl$get$1$6 = 0; login.successHandler(formLoginDsl.getAuthenticationSuccessHandler()); } else { FormLoginDsl.this.getAuthenticationSuccessHandler(); }  if (FormLoginDsl.this.getAuthenticationFailureHandler() != null) { AuthenticationFailureHandler authenticationFailureHandler1 = FormLoginDsl.this.getAuthenticationFailureHandler(); formLoginDsl = FormLoginDsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-FormLoginDsl$get$1$7 = 0; login.failureHandler(formLoginDsl.getAuthenticationFailureHandler()); } else { FormLoginDsl.this.getAuthenticationFailureHandler(); }  if (FormLoginDsl.this.getAuthenticationDetailsSource() != null) { AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource1 = FormLoginDsl.this.getAuthenticationDetailsSource(); formLoginDsl = FormLoginDsl.this; AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource2 = authenticationDetailsSource1; int $i$a$-also-FormLoginDsl$get$1$8 = 0; login.authenticationDetailsSource(formLoginDsl.getAuthenticationDetailsSource()); } else { FormLoginDsl.this.getAuthenticationDetailsSource(); }  if (FormLoginDsl.this.getUsernameParameter() != null) { String str1 = FormLoginDsl.this.getUsernameParameter(); formLoginDsl = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$9 = 0; login.usernameParameter(formLoginDsl.getUsernameParameter()); } else { FormLoginDsl.this.getUsernameParameter(); }  if (FormLoginDsl.this.getPasswordParameter() != null) { String str1 = FormLoginDsl.this.getPasswordParameter(); formLoginDsl = FormLoginDsl.this; String str2 = str1; int $i$a$-also-FormLoginDsl$get$1$10 = 0;
/*     */         login.passwordParameter(formLoginDsl.getPasswordParameter()); }
/*     */       else
/*     */       { FormLoginDsl.this.getPasswordParameter(); }
/*     */       
/*     */       if (FormLoginDsl.this.disabled)
/*     */         login.disable();  }
/*     */ 
/*     */     
/*     */     FormLoginDsl$get$1() {
/*     */       super(1);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\FormLoginDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */