/*     */ package org.springframework.security.config.annotation.web.configuration;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SecurityReactorContextSubscriber<T>
/*     */   implements CoreSubscriber<T>
/*     */ {
/*     */   static final String SECURITY_CONTEXT_ATTRIBUTES = "org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES";
/*     */   private final CoreSubscriber<T> delegate;
/*     */   private final Context context;
/*     */   
/*     */   SecurityReactorContextSubscriber(CoreSubscriber<T> delegate, Map<Object, Object> attributes) {
/* 162 */     this.delegate = delegate;
/* 163 */     Context context = getOrPutContext(attributes, this.delegate.currentContext());
/* 164 */     this.context = context;
/*     */   }
/*     */   
/*     */   private Context getOrPutContext(Map<Object, Object> attributes, Context currentContext) {
/* 168 */     if (currentContext.hasKey("org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES")) {
/* 169 */       return currentContext;
/*     */     }
/* 171 */     return currentContext.put("org.springframework.security.SECURITY_CONTEXT_ATTRIBUTES", attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public Context currentContext() {
/* 176 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSubscribe(Subscription s) {
/* 181 */     this.delegate.onSubscribe(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onNext(T t) {
/* 186 */     this.delegate.onNext(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onError(Throwable ex) {
/* 191 */     this.delegate.onError(ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onComplete() {
/* 196 */     this.delegate.onComplete();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configuration\SecurityReactorContextConfiguration$SecurityReactorContextSubscriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */