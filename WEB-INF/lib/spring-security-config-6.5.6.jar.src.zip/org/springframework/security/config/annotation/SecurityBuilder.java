package org.springframework.security.config.annotation;

public interface SecurityBuilder<O> {
  O build() throws Exception;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\SecurityBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */