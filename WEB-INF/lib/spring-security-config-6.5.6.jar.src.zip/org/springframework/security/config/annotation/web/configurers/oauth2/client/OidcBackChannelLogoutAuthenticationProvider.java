/*     */ package org.springframework.security.config.annotation.web.configurers.oauth2.client;
/*     */ 
/*     */ import com.nimbusds.jose.JOSEObjectType;
/*     */ import com.nimbusds.jose.proc.DefaultJOSEObjectTypeVerifier;
/*     */ import com.nimbusds.jose.proc.JOSEObjectTypeVerifier;
/*     */ import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.oauth2.client.oidc.authentication.OidcIdTokenDecoderFactory;
/*     */ import org.springframework.security.oauth2.client.oidc.authentication.logout.OidcLogoutToken;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.oauth2.core.OAuth2TokenValidator;
/*     */ import org.springframework.security.oauth2.jwt.BadJwtException;
/*     */ import org.springframework.security.oauth2.jwt.Jwt;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoderFactory;
/*     */ import org.springframework.security.oauth2.jwt.JwtValidators;
/*     */ import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OidcBackChannelLogoutAuthenticationProvider
/*     */   implements AuthenticationProvider
/*     */ {
/*     */   private JwtDecoderFactory<ClientRegistration> logoutTokenDecoderFactory;
/*     */   
/*     */   OidcBackChannelLogoutAuthenticationProvider() {
/*  70 */     Function<ClientRegistration, OAuth2TokenValidator<Jwt>> jwtValidator = clientRegistration -> JwtValidators.createDefaultWithValidators(new OAuth2TokenValidator[] { new OidcBackChannelLogoutTokenValidator(clientRegistration) });
/*     */     
/*  72 */     this.logoutTokenDecoderFactory = (clientRegistration -> {
/*     */         String jwkSetUri = clientRegistration.getProviderDetails().getJwkSetUri();
/*     */         if (!StringUtils.hasText(jwkSetUri)) {
/*     */           OAuth2Error oauth2Error = new OAuth2Error("missing_signature_verifier", "Failed to find a Signature Verifier for Client Registration: '" + clientRegistration.getRegistrationId() + "'. Check to ensure you have configured the JwkSet URI.", null);
/*     */           throw new OAuth2AuthenticationException(oauth2Error, oauth2Error.toString());
/*     */         } 
/*     */         DefaultJOSEObjectTypeVerifier defaultJOSEObjectTypeVerifier = new DefaultJOSEObjectTypeVerifier(new JOSEObjectType[] { null, JOSEObjectType.JWT, new JOSEObjectType("logout+jwt") });
/*     */         NimbusJwtDecoder decoder = NimbusJwtDecoder.withJwkSetUri(jwkSetUri).jwtProcessorCustomizer(()).build();
/*     */         decoder.setJwtValidator(jwtValidator.apply(clientRegistration));
/*     */         decoder.setClaimSetConverter((Converter)OidcIdTokenDecoderFactory.createDefaultClaimTypeConverter());
/*     */         return (JwtDecoder)decoder;
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/*     */     OidcLogoutAuthenticationToken token;
/*  98 */     if (authentication instanceof OidcLogoutAuthenticationToken) { token = (OidcLogoutAuthenticationToken)authentication; }
/*  99 */     else { return null; }
/*     */     
/* 101 */     String logoutToken = token.getLogoutToken();
/* 102 */     ClientRegistration registration = token.getClientRegistration();
/* 103 */     Jwt jwt = decode(registration, logoutToken);
/*     */ 
/*     */     
/* 106 */     OidcLogoutToken oidcLogoutToken = OidcLogoutToken.withTokenValue(logoutToken).claims(claims -> claims.putAll(jwt.getClaims())).build();
/* 107 */     return (Authentication)new OidcBackChannelLogoutAuthentication(oidcLogoutToken, registration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> authentication) {
/* 115 */     return OidcLogoutAuthenticationToken.class.isAssignableFrom(authentication);
/*     */   }
/*     */   
/*     */   private Jwt decode(ClientRegistration registration, String token) {
/* 119 */     JwtDecoder logoutTokenDecoder = this.logoutTokenDecoderFactory.createDecoder(registration);
/*     */     try {
/* 121 */       return logoutTokenDecoder.decode(token);
/*     */     }
/* 123 */     catch (BadJwtException failed) {
/* 124 */       OAuth2Error error = new OAuth2Error("invalid_request", failed.getMessage(), "https://openid.net/specs/openid-connect-backchannel-1_0.html#Validation");
/*     */       
/* 126 */       throw new OAuth2AuthenticationException(error, failed);
/*     */     }
/* 128 */     catch (Exception failed) {
/* 129 */       throw new AuthenticationServiceException(failed.getMessage(), failed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setLogoutTokenDecoderFactory(JwtDecoderFactory<ClientRegistration> logoutTokenDecoderFactory) {
/* 139 */     Assert.notNull(logoutTokenDecoderFactory, "logoutTokenDecoderFactory cannot be null");
/* 140 */     this.logoutTokenDecoderFactory = logoutTokenDecoderFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\configurers\oauth2\client\OidcBackChannelLogoutAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */