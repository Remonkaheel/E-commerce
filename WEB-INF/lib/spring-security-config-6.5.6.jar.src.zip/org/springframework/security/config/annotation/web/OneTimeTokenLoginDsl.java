/*    */ package org.springframework.security.config.annotation.web;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.ott.OneTimeTokenService;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.ott.OneTimeTokenLoginConfigurer;
/*    */ import org.springframework.security.web.authentication.AuthenticationConverter;
/*    */ import org.springframework.security.web.authentication.AuthenticationFailureHandler;
/*    */ import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
/*    */ import org.springframework.security.web.authentication.ott.GenerateOneTimeTokenRequestResolver;
/*    */ import org.springframework.security.web.authentication.ott.OneTimeTokenGenerationSuccessHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000h\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\t\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\037\020@\032\024\022\n\022\b\022\004\022\0020C0B\022\004\022\0020D0AH\000¢\006\002\bER\034\020\003\032\004\030\0010\004X\016¢\006\016\n\000\032\004\b\005\020\006\"\004\b\007\020\bR\034\020\t\032\004\030\0010\nX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R\034\020\017\032\004\030\0010\020X\016¢\006\016\n\000\032\004\b\021\020\022\"\004\b\023\020\024R\034\020\025\032\004\030\0010\026X\016¢\006\016\n\000\032\004\b\027\020\030\"\004\b\031\020\032R\034\020\033\032\004\030\0010\034X\016¢\006\016\n\000\032\004\b\035\020\036\"\004\b\037\020 R\034\020!\032\004\030\0010\"X\016¢\006\016\n\000\032\004\b#\020$\"\004\b%\020&R\034\020'\032\004\030\0010\034X\016¢\006\016\n\000\032\004\b(\020\036\"\004\b)\020 R\034\020*\032\004\030\0010+X\016¢\006\016\n\000\032\004\b,\020-\"\004\b.\020/R\036\0200\032\004\030\00101X\016¢\006\020\n\002\0206\032\004\b2\0203\"\004\b4\0205R\034\0207\032\004\030\0010\034X\016¢\006\016\n\000\032\004\b8\020\036\"\004\b9\020 R\034\020:\032\004\030\0010;X\016¢\006\016\n\000\032\004\b<\020=\"\004\b>\020?¨\006F"}, d2 = {"Lorg/springframework/security/config/annotation/web/OneTimeTokenLoginDsl;", "", "()V", "authenticationConverter", "Lorg/springframework/security/web/authentication/AuthenticationConverter;", "getAuthenticationConverter", "()Lorg/springframework/security/web/authentication/AuthenticationConverter;", "setAuthenticationConverter", "(Lorg/springframework/security/web/authentication/AuthenticationConverter;)V", "authenticationFailureHandler", "Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "getAuthenticationFailureHandler", "()Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;", "setAuthenticationFailureHandler", "(Lorg/springframework/security/web/authentication/AuthenticationFailureHandler;)V", "authenticationProvider", "Lorg/springframework/security/authentication/AuthenticationProvider;", "getAuthenticationProvider", "()Lorg/springframework/security/authentication/AuthenticationProvider;", "setAuthenticationProvider", "(Lorg/springframework/security/authentication/AuthenticationProvider;)V", "authenticationSuccessHandler", "Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "getAuthenticationSuccessHandler", "()Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;", "setAuthenticationSuccessHandler", "(Lorg/springframework/security/web/authentication/AuthenticationSuccessHandler;)V", "defaultSubmitPageUrl", "", "getDefaultSubmitPageUrl", "()Ljava/lang/String;", "setDefaultSubmitPageUrl", "(Ljava/lang/String;)V", "generateRequestResolver", "Lorg/springframework/security/web/authentication/ott/GenerateOneTimeTokenRequestResolver;", "getGenerateRequestResolver", "()Lorg/springframework/security/web/authentication/ott/GenerateOneTimeTokenRequestResolver;", "setGenerateRequestResolver", "(Lorg/springframework/security/web/authentication/ott/GenerateOneTimeTokenRequestResolver;)V", "loginProcessingUrl", "getLoginProcessingUrl", "setLoginProcessingUrl", "oneTimeTokenGenerationSuccessHandler", "Lorg/springframework/security/web/authentication/ott/OneTimeTokenGenerationSuccessHandler;", "getOneTimeTokenGenerationSuccessHandler", "()Lorg/springframework/security/web/authentication/ott/OneTimeTokenGenerationSuccessHandler;", "setOneTimeTokenGenerationSuccessHandler", "(Lorg/springframework/security/web/authentication/ott/OneTimeTokenGenerationSuccessHandler;)V", "showDefaultSubmitPage", "", "getShowDefaultSubmitPage", "()Ljava/lang/Boolean;", "setShowDefaultSubmitPage", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "tokenGeneratingUrl", "getTokenGeneratingUrl", "setTokenGeneratingUrl", "tokenService", "Lorg/springframework/security/authentication/ott/OneTimeTokenService;", "getTokenService", "()Lorg/springframework/security/authentication/ott/OneTimeTokenService;", "setTokenService", "(Lorg/springframework/security/authentication/ott/OneTimeTokenService;)V", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/ott/OneTimeTokenLoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "", "get$spring_security_config", "spring-security-config"})
/*    */ public final class OneTimeTokenLoginDsl
/*    */ {
/*    */   @Nullable
/*    */   private OneTimeTokenService tokenService;
/*    */   @Nullable
/*    */   private AuthenticationConverter authenticationConverter;
/*    */   @Nullable
/*    */   private AuthenticationFailureHandler authenticationFailureHandler;
/*    */   @Nullable
/*    */   private AuthenticationSuccessHandler authenticationSuccessHandler;
/*    */   @Nullable
/*    */   private GenerateOneTimeTokenRequestResolver generateRequestResolver;
/*    */   @Nullable
/*    */   private String defaultSubmitPageUrl;
/*    */   @Nullable
/*    */   private String loginProcessingUrl;
/*    */   @Nullable
/*    */   private String tokenGeneratingUrl;
/*    */   
/*    */   @Nullable
/*    */   public final OneTimeTokenService getTokenService() {
/* 48 */     return this.tokenService; } public final void setTokenService(@Nullable OneTimeTokenService <set-?>) { this.tokenService = <set-?>; } @Nullable
/* 49 */   public final AuthenticationConverter getAuthenticationConverter() { return this.authenticationConverter; } public final void setAuthenticationConverter(@Nullable AuthenticationConverter <set-?>) { this.authenticationConverter = <set-?>; } @Nullable
/* 50 */   public final AuthenticationFailureHandler getAuthenticationFailureHandler() { return this.authenticationFailureHandler; } public final void setAuthenticationFailureHandler(@Nullable AuthenticationFailureHandler <set-?>) { this.authenticationFailureHandler = <set-?>; } @Nullable
/* 51 */   public final AuthenticationSuccessHandler getAuthenticationSuccessHandler() { return this.authenticationSuccessHandler; } public final void setAuthenticationSuccessHandler(@Nullable AuthenticationSuccessHandler <set-?>) { this.authenticationSuccessHandler = <set-?>; } @Nullable
/* 52 */   public final GenerateOneTimeTokenRequestResolver getGenerateRequestResolver() { return this.generateRequestResolver; } public final void setGenerateRequestResolver(@Nullable GenerateOneTimeTokenRequestResolver <set-?>) { this.generateRequestResolver = <set-?>; } @Nullable
/* 53 */   public final String getDefaultSubmitPageUrl() { return this.defaultSubmitPageUrl; } public final void setDefaultSubmitPageUrl(@Nullable String <set-?>) { this.defaultSubmitPageUrl = <set-?>; } @Nullable
/* 54 */   public final String getLoginProcessingUrl() { return this.loginProcessingUrl; } public final void setLoginProcessingUrl(@Nullable String <set-?>) { this.loginProcessingUrl = <set-?>; } @Nullable
/* 55 */   public final String getTokenGeneratingUrl() { return this.tokenGeneratingUrl; } public final void setTokenGeneratingUrl(@Nullable String <set-?>) { this.tokenGeneratingUrl = <set-?>; } @Nullable
/* 56 */   private Boolean showDefaultSubmitPage = Boolean.valueOf(true); @Nullable private OneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler; @Nullable private AuthenticationProvider authenticationProvider; @Nullable public final Boolean getShowDefaultSubmitPage() { return this.showDefaultSubmitPage; } public final void setShowDefaultSubmitPage(@Nullable Boolean <set-?>) { this.showDefaultSubmitPage = <set-?>; } @Nullable
/* 57 */   public final OneTimeTokenGenerationSuccessHandler getOneTimeTokenGenerationSuccessHandler() { return this.oneTimeTokenGenerationSuccessHandler; } public final void setOneTimeTokenGenerationSuccessHandler(@Nullable OneTimeTokenGenerationSuccessHandler <set-?>) { this.oneTimeTokenGenerationSuccessHandler = <set-?>; } @Nullable
/* 58 */   public final AuthenticationProvider getAuthenticationProvider() { return this.authenticationProvider; } public final void setAuthenticationProvider(@Nullable AuthenticationProvider <set-?>) { this.authenticationProvider = <set-?>; }
/*    */   
/*    */   @NotNull
/* 61 */   public final Function1<OneTimeTokenLoginConfigurer<HttpSecurity>, Unit> get$spring_security_config() { return new OneTimeTokenLoginDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\022\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\f\020\002\032\b\022\004\022\0020\0040\003H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "oneTimeTokenLoginConfigurer", "Lorg/springframework/security/config/annotation/web/configurers/ott/OneTimeTokenLoginConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nOneTimeTokenLoginDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OneTimeTokenLoginDsl.kt\norg/springframework/security/config/annotation/web/OneTimeTokenLoginDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,92:1\n1#2:93\n*E\n"})
/* 62 */   static final class OneTimeTokenLoginDsl$get$1 extends Lambda implements Function1<OneTimeTokenLoginConfigurer<HttpSecurity>, Unit> { public final void invoke(OneTimeTokenLoginConfigurer oneTimeTokenLoginConfigurer) { Intrinsics.checkNotNullParameter(oneTimeTokenLoginConfigurer, "oneTimeTokenLoginConfigurer"); if (OneTimeTokenLoginDsl.this.getTokenService() != null) { OneTimeTokenService oneTimeTokenService1 = OneTimeTokenLoginDsl.this.getTokenService(); OneTimeTokenLoginDsl oneTimeTokenLoginDsl1 = OneTimeTokenLoginDsl.this; OneTimeTokenService oneTimeTokenService2 = oneTimeTokenService1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 93 */         int $i$a$-also-OneTimeTokenLoginDsl$get$1$1 = 0; oneTimeTokenLoginConfigurer.tokenService(oneTimeTokenLoginDsl1.getTokenService()); } else { OneTimeTokenLoginDsl.this.getTokenService(); }  if (OneTimeTokenLoginDsl.this.getAuthenticationConverter() != null) { AuthenticationConverter authenticationConverter1 = OneTimeTokenLoginDsl.this.getAuthenticationConverter(); OneTimeTokenLoginDsl oneTimeTokenLoginDsl1 = OneTimeTokenLoginDsl.this; AuthenticationConverter authenticationConverter2 = authenticationConverter1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$2 = 0; oneTimeTokenLoginConfigurer.authenticationConverter(oneTimeTokenLoginDsl1.getAuthenticationConverter()); } else { OneTimeTokenLoginDsl.this.getAuthenticationConverter(); }  AuthenticationFailureHandler authenticationFailureHandler1 = OneTimeTokenLoginDsl.this.getAuthenticationFailureHandler(); OneTimeTokenLoginDsl oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; AuthenticationFailureHandler authenticationFailureHandler2 = authenticationFailureHandler1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$3 = 0; oneTimeTokenLoginConfigurer.failureHandler(oneTimeTokenLoginDsl.getAuthenticationFailureHandler()); OneTimeTokenLoginDsl.this.getAuthenticationFailureHandler(); AuthenticationSuccessHandler authenticationSuccessHandler1 = OneTimeTokenLoginDsl.this.getAuthenticationSuccessHandler(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; AuthenticationSuccessHandler authenticationSuccessHandler2 = authenticationSuccessHandler1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$4 = 0; oneTimeTokenLoginConfigurer.successHandler(oneTimeTokenLoginDsl.getAuthenticationSuccessHandler()); OneTimeTokenLoginDsl.this.getAuthenticationSuccessHandler(); GenerateOneTimeTokenRequestResolver generateOneTimeTokenRequestResolver1 = OneTimeTokenLoginDsl.this.getGenerateRequestResolver(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; GenerateOneTimeTokenRequestResolver generateOneTimeTokenRequestResolver2 = generateOneTimeTokenRequestResolver1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$5 = 0; oneTimeTokenLoginConfigurer.generateRequestResolver(oneTimeTokenLoginDsl.getGenerateRequestResolver()); OneTimeTokenLoginDsl.this.getGenerateRequestResolver(); if (OneTimeTokenLoginDsl.this.getDefaultSubmitPageUrl() != null) { String str1 = OneTimeTokenLoginDsl.this.getDefaultSubmitPageUrl(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; String str2 = str1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$6 = 0; oneTimeTokenLoginConfigurer.defaultSubmitPageUrl(oneTimeTokenLoginDsl.getDefaultSubmitPageUrl()); } else { OneTimeTokenLoginDsl.this.getDefaultSubmitPageUrl(); }  if (OneTimeTokenLoginDsl.this.getShowDefaultSubmitPage() != null) { Boolean bool = OneTimeTokenLoginDsl.this.getShowDefaultSubmitPage(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; boolean bool1 = bool.booleanValue(); int $i$a$-also-OneTimeTokenLoginDsl$get$1$7 = 0; Intrinsics.checkNotNull(oneTimeTokenLoginDsl.getShowDefaultSubmitPage()); oneTimeTokenLoginConfigurer.showDefaultSubmitPage(oneTimeTokenLoginDsl.getShowDefaultSubmitPage().booleanValue()); } else { OneTimeTokenLoginDsl.this.getShowDefaultSubmitPage(); }  if (OneTimeTokenLoginDsl.this.getLoginProcessingUrl() != null) { String str1 = OneTimeTokenLoginDsl.this.getLoginProcessingUrl(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; String str2 = str1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$8 = 0; oneTimeTokenLoginConfigurer.loginProcessingUrl(oneTimeTokenLoginDsl.getLoginProcessingUrl()); } else { OneTimeTokenLoginDsl.this.getLoginProcessingUrl(); }  if (OneTimeTokenLoginDsl.this.getTokenGeneratingUrl() != null) { String str1 = OneTimeTokenLoginDsl.this.getTokenGeneratingUrl(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; String str2 = str1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$9 = 0; oneTimeTokenLoginConfigurer.tokenGeneratingUrl(oneTimeTokenLoginDsl.getTokenGeneratingUrl()); } else { OneTimeTokenLoginDsl.this.getTokenGeneratingUrl(); }  OneTimeTokenGenerationSuccessHandler oneTimeTokenGenerationSuccessHandler1 = OneTimeTokenLoginDsl.this.getOneTimeTokenGenerationSuccessHandler(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; OneTimeTokenGenerationSuccessHandler it = oneTimeTokenGenerationSuccessHandler1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$10 = 0; oneTimeTokenLoginConfigurer.tokenGenerationSuccessHandler(oneTimeTokenLoginDsl.getOneTimeTokenGenerationSuccessHandler()); OneTimeTokenLoginDsl.this.getOneTimeTokenGenerationSuccessHandler(); if (OneTimeTokenLoginDsl.this.getAuthenticationProvider() != null) { AuthenticationProvider authenticationProvider1 = OneTimeTokenLoginDsl.this.getAuthenticationProvider(); oneTimeTokenLoginDsl = OneTimeTokenLoginDsl.this; AuthenticationProvider authenticationProvider2 = authenticationProvider1; int $i$a$-also-OneTimeTokenLoginDsl$get$1$11 = 0;
/*    */         oneTimeTokenLoginConfigurer.authenticationProvider(oneTimeTokenLoginDsl.getAuthenticationProvider()); }
/*    */       else
/*    */       { OneTimeTokenLoginDsl.this.getAuthenticationProvider(); }
/*    */        }
/*    */ 
/*    */     
/*    */     OneTimeTokenLoginDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\OneTimeTokenLoginDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */