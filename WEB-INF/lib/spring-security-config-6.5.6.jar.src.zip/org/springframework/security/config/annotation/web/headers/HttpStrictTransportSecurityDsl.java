/*    */ package org.springframework.security.config.annotation.web.headers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @HeadersSecurityMarker
/*    */ @Metadata(mv = {1, 7, 0}, k = 1, xi = 48, d1 = {"\000>\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\007\n\002\020\t\n\002\b\t\n\002\030\002\n\002\b\005\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\b\007\030\0002\0020\001B\005¢\006\002\020\002J\006\020\033\032\0020\034J#\020\035\032\030\022\016\022\f0\037R\b\022\004\022\0020!0 \022\004\022\0020\0340\036H\000¢\006\002\b\"R\016\020\003\032\0020\004X\016¢\006\002\n\000R\036\020\005\032\004\030\0010\004X\016¢\006\020\n\002\020\n\032\004\b\006\020\007\"\004\b\b\020\tR\036\020\013\032\004\030\0010\fX\016¢\006\020\n\002\020\021\032\004\b\r\020\016\"\004\b\017\020\020R\036\020\022\032\004\030\0010\004X\016¢\006\020\n\002\020\n\032\004\b\023\020\007\"\004\b\024\020\tR\034\020\025\032\004\030\0010\026X\016¢\006\016\n\000\032\004\b\027\020\030\"\004\b\031\020\032¨\006#"}, d2 = {"Lorg/springframework/security/config/annotation/web/headers/HttpStrictTransportSecurityDsl;", "", "()V", "disabled", "", "includeSubDomains", "getIncludeSubDomains", "()Ljava/lang/Boolean;", "setIncludeSubDomains", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "maxAgeInSeconds", "", "getMaxAgeInSeconds", "()Ljava/lang/Long;", "setMaxAgeInSeconds", "(Ljava/lang/Long;)V", "Ljava/lang/Long;", "preload", "getPreload", "setPreload", "requestMatcher", "Lorg/springframework/security/web/util/matcher/RequestMatcher;", "getRequestMatcher", "()Lorg/springframework/security/web/util/matcher/RequestMatcher;", "setRequestMatcher", "(Lorg/springframework/security/web/util/matcher/RequestMatcher;)V", "disable", "", "get", "Lkotlin/Function1;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HstsConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "get$spring_security_config", "spring-security-config"})
/*    */ public final class HttpStrictTransportSecurityDsl
/*    */ {
/*    */   @Nullable
/*    */   private Long maxAgeInSeconds;
/*    */   @Nullable
/*    */   private RequestMatcher requestMatcher;
/*    */   @Nullable
/*    */   private Boolean includeSubDomains;
/*    */   @Nullable
/*    */   private Boolean preload;
/*    */   private boolean disabled;
/*    */   
/*    */   @Nullable
/*    */   public final Long getMaxAgeInSeconds() {
/* 39 */     return this.maxAgeInSeconds; } public final void setMaxAgeInSeconds(@Nullable Long <set-?>) { this.maxAgeInSeconds = <set-?>; } @Nullable
/* 40 */   public final RequestMatcher getRequestMatcher() { return this.requestMatcher; } public final void setRequestMatcher(@Nullable RequestMatcher <set-?>) { this.requestMatcher = <set-?>; } @Nullable
/* 41 */   public final Boolean getIncludeSubDomains() { return this.includeSubDomains; } public final void setIncludeSubDomains(@Nullable Boolean <set-?>) { this.includeSubDomains = <set-?>; } @Nullable
/* 42 */   public final Boolean getPreload() { return this.preload; } public final void setPreload(@Nullable Boolean <set-?>) { this.preload = <set-?>; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void disable() {
/* 50 */     this.disabled = true;
/*    */   }
/*    */   
/*    */   @NotNull
/* 54 */   public final Function1<HeadersConfigurer<HttpSecurity>.HstsConfig, Unit> get$spring_security_config() { return new HttpStrictTransportSecurityDsl$get$1(); } @Metadata(mv = {1, 7, 0}, k = 3, xi = 48, d1 = {"\000\026\n\000\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\020\000\032\0020\0012\020\020\002\032\f0\003R\b\022\004\022\0020\0050\004H\n¢\006\002\b\006"}, d2 = {"<anonymous>", "", "hsts", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer$HstsConfig;", "Lorg/springframework/security/config/annotation/web/configurers/HeadersConfigurer;", "Lorg/springframework/security/config/annotation/web/builders/HttpSecurity;", "invoke"}) @SourceDebugExtension({"SMAP\nHttpStrictTransportSecurityDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpStrictTransportSecurityDsl.kt\norg/springframework/security/config/annotation/web/headers/HttpStrictTransportSecurityDsl$get$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,65:1\n1#2:66\n*E\n"})
/* 55 */   static final class HttpStrictTransportSecurityDsl$get$1 extends Lambda implements Function1<HeadersConfigurer<HttpSecurity>.HstsConfig, Unit> { public final void invoke(HeadersConfigurer.HstsConfig hsts) { Intrinsics.checkNotNullParameter(hsts, "hsts"); if (HttpStrictTransportSecurityDsl.this.getMaxAgeInSeconds() != null) { Long long_ = HttpStrictTransportSecurityDsl.this.getMaxAgeInSeconds(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; long it = long_.longValue();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 66 */         int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$1 = 0; Intrinsics.checkNotNull(httpStrictTransportSecurityDsl.getMaxAgeInSeconds()); hsts.maxAgeInSeconds(httpStrictTransportSecurityDsl.getMaxAgeInSeconds().longValue()); } else { HttpStrictTransportSecurityDsl.this.getMaxAgeInSeconds(); }  if (HttpStrictTransportSecurityDsl.this.getRequestMatcher() != null) { RequestMatcher requestMatcher1 = HttpStrictTransportSecurityDsl.this.getRequestMatcher(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; RequestMatcher it = requestMatcher1; int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$2 = 0; hsts.requestMatcher(httpStrictTransportSecurityDsl.getRequestMatcher()); } else { HttpStrictTransportSecurityDsl.this.getRequestMatcher(); }  if (HttpStrictTransportSecurityDsl.this.getIncludeSubDomains() != null) { Boolean bool = HttpStrictTransportSecurityDsl.this.getIncludeSubDomains(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$3 = 0; Intrinsics.checkNotNull(httpStrictTransportSecurityDsl.getIncludeSubDomains()); hsts.includeSubDomains(httpStrictTransportSecurityDsl.getIncludeSubDomains().booleanValue()); } else { HttpStrictTransportSecurityDsl.this.getIncludeSubDomains(); }  if (HttpStrictTransportSecurityDsl.this.getPreload() != null) { Boolean bool = HttpStrictTransportSecurityDsl.this.getPreload(); HttpStrictTransportSecurityDsl httpStrictTransportSecurityDsl = HttpStrictTransportSecurityDsl.this; boolean it = bool.booleanValue(); int $i$a$-also-HttpStrictTransportSecurityDsl$get$1$4 = 0;
/*    */         Intrinsics.checkNotNull(httpStrictTransportSecurityDsl.getPreload());
/*    */         hsts.preload(httpStrictTransportSecurityDsl.getPreload().booleanValue()); }
/*    */       else
/*    */       { HttpStrictTransportSecurityDsl.this.getPreload(); }
/*    */       
/*    */       if (HttpStrictTransportSecurityDsl.this.disabled)
/*    */         hsts.disable();  }
/*    */ 
/*    */     
/*    */     HttpStrictTransportSecurityDsl$get$1() {
/*    */       super(1);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\annotation\web\headers\HttpStrictTransportSecurityDsl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */