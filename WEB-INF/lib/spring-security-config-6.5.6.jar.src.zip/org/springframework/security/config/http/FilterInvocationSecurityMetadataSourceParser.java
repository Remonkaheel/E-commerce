/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;
/*     */ import org.springframework.security.web.access.expression.ExpressionBasedFilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class FilterInvocationSecurityMetadataSourceParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ATT_USE_EXPRESSIONS = "use-expressions";
/*     */   private static final String ATT_HTTP_METHOD = "method";
/*     */   private static final String ATT_PATTERN = "pattern";
/*     */   private static final String ATT_ACCESS = "access";
/*     */   private static final String ATT_SERVLET_PATH = "servlet-path";
/*  64 */   private static final Log logger = LogFactory.getLog(FilterInvocationSecurityMetadataSourceParser.class);
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*  68 */     List<Element> interceptUrls = DomUtils.getChildElementsByTagName(element, "intercept-url");
/*     */     
/*  70 */     for (Element elt : interceptUrls) {
/*  71 */       if (StringUtils.hasLength(elt.getAttribute("requires-channel"))) {
/*  72 */         parserContext.getReaderContext()
/*  73 */           .error("The attribute 'requires-channel' isn't allowed here.", elt);
/*     */       }
/*     */       
/*  76 */       if (StringUtils.hasLength(elt.getAttribute("filters"))) {
/*  77 */         parserContext.getReaderContext()
/*  78 */           .error("The attribute 'filters' isn't allowed here.", elt);
/*     */       }
/*     */       
/*  81 */       if (StringUtils.hasLength(elt.getAttribute("servlet-path"))) {
/*  82 */         parserContext.getReaderContext()
/*  83 */           .error("The attribute 'servlet-path' isn't allowed here.", elt);
/*     */       }
/*     */     } 
/*  86 */     RootBeanDefinition rootBeanDefinition = createSecurityMetadataSource(interceptUrls, false, element, parserContext);
/*  87 */     String id = element.getAttribute("id");
/*  88 */     if (StringUtils.hasText(id)) {
/*  89 */       parserContext.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)rootBeanDefinition, id));
/*  90 */       parserContext.getRegistry().registerBeanDefinition(id, (BeanDefinition)rootBeanDefinition);
/*     */     } 
/*  92 */     return (BeanDefinition)rootBeanDefinition;
/*     */   }
/*     */   
/*     */   static RootBeanDefinition createSecurityMetadataSource(List<Element> interceptUrls, boolean addAllAuth, Element httpElt, ParserContext pc) {
/*     */     BeanDefinitionBuilder fidsBuilder;
/*  97 */     MatcherType matcherType = MatcherType.fromElementOrMvc(httpElt);
/*  98 */     boolean useExpressions = isUseExpressions(httpElt);
/*  99 */     ManagedMap<BeanMetadataElement, BeanDefinition> requestToAttributesMap = parseInterceptUrlsForFilterInvocationRequestMap(matcherType, interceptUrls, useExpressions, addAllAuth, pc);
/*     */ 
/*     */     
/* 102 */     if (useExpressions) {
/* 103 */       Element expressionHandlerElt = DomUtils.getChildElementByTagName(httpElt, "expression-handler");
/*     */       
/* 105 */       String expressionHandlerRef = (expressionHandlerElt != null) ? expressionHandlerElt.getAttribute("ref") : null;
/* 106 */       if (StringUtils.hasText(expressionHandlerRef)) {
/* 107 */         logger.info("Using bean '" + expressionHandlerRef + "' as web SecurityExpressionHandler implementation");
/*     */       }
/*     */       else {
/*     */         
/* 111 */         expressionHandlerRef = registerDefaultExpressionHandler(pc);
/*     */       } 
/*     */       
/* 114 */       fidsBuilder = BeanDefinitionBuilder.rootBeanDefinition(ExpressionBasedFilterInvocationSecurityMetadataSource.class);
/* 115 */       fidsBuilder.addConstructorArgValue(requestToAttributesMap);
/* 116 */       fidsBuilder.addConstructorArgReference(expressionHandlerRef);
/*     */     } else {
/*     */       
/* 119 */       fidsBuilder = BeanDefinitionBuilder.rootBeanDefinition(DefaultFilterInvocationSecurityMetadataSource.class);
/* 120 */       fidsBuilder.addConstructorArgValue(requestToAttributesMap);
/*     */     } 
/* 122 */     fidsBuilder.getRawBeanDefinition().setSource(pc.extractSource(httpElt));
/* 123 */     return (RootBeanDefinition)fidsBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   static String registerDefaultExpressionHandler(ParserContext pc) {
/* 127 */     RootBeanDefinition rootBeanDefinition = GrantedAuthorityDefaultsParserUtils.registerWithDefaultRolePrefix(pc, (Class)DefaultWebSecurityExpressionHandlerBeanFactory.class);
/*     */     
/* 129 */     String expressionHandlerRef = pc.getReaderContext().generateBeanName((BeanDefinition)rootBeanDefinition);
/* 130 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)rootBeanDefinition, expressionHandlerRef));
/* 131 */     return expressionHandlerRef;
/*     */   }
/*     */   
/*     */   static boolean isUseExpressions(Element elt) {
/* 135 */     String useExpressions = elt.getAttribute("use-expressions");
/* 136 */     return (!StringUtils.hasText(useExpressions) || "true".equals(useExpressions));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ManagedMap<BeanMetadataElement, BeanDefinition> parseInterceptUrlsForFilterInvocationRequestMap(MatcherType matcherType, List<Element> urlElts, boolean useExpressions, boolean addAuthenticatedAll, ParserContext parserContext) {
/* 142 */     ManagedMap<BeanMetadataElement, BeanDefinition> filterInvocationDefinitionMap = new ManagedMap();
/* 143 */     for (Element urlElt : urlElts) {
/* 144 */       String access = urlElt.getAttribute("access");
/* 145 */       if (!StringUtils.hasText(access)) {
/*     */         continue;
/*     */       }
/* 148 */       String path = urlElt.getAttribute("pattern");
/* 149 */       String matcherRef = urlElt.getAttribute("request-matcher-ref");
/* 150 */       boolean hasMatcherRef = StringUtils.hasText(matcherRef);
/* 151 */       if (!hasMatcherRef && !StringUtils.hasText(path)) {
/* 152 */         parserContext.getReaderContext().error("path attribute cannot be empty or null", urlElt);
/*     */       }
/* 154 */       String method = urlElt.getAttribute("method");
/* 155 */       if (!StringUtils.hasText(method)) {
/* 156 */         method = null;
/*     */       }
/* 158 */       String servletPath = urlElt.getAttribute("servlet-path");
/* 159 */       if (!StringUtils.hasText(servletPath)) {
/* 160 */         servletPath = null;
/*     */       }
/* 162 */       else if (!MatcherType.mvc.equals(matcherType)) {
/* 163 */         parserContext.getReaderContext()
/* 164 */           .error("servlet-path is not applicable for request-matcher: '" + matcherType.name() + "'", urlElt);
/*     */       } 
/*     */ 
/*     */       
/* 168 */       BeanMetadataElement matcher = hasMatcherRef ? (BeanMetadataElement)new RuntimeBeanReference(matcherRef) : (BeanMetadataElement)matcherType.createMatcher(parserContext, path, method, servletPath);
/* 169 */       BeanDefinitionBuilder attributeBuilder = BeanDefinitionBuilder.rootBeanDefinition(SecurityConfig.class);
/* 170 */       if (useExpressions) {
/* 171 */         logger.info("Creating access control expression attribute '" + access + "' for " + path);
/*     */ 
/*     */         
/* 174 */         attributeBuilder.addConstructorArgValue(new String[] { access });
/* 175 */         attributeBuilder.setFactoryMethod("createList");
/*     */       }
/*     */       else {
/*     */         
/* 179 */         attributeBuilder.addConstructorArgValue(access);
/* 180 */         attributeBuilder.setFactoryMethod("createListFromCommaDelimitedString");
/*     */       } 
/* 182 */       if (filterInvocationDefinitionMap.containsKey(matcher)) {
/* 183 */         logger.warn("Duplicate URL defined: " + path + ". The original attribute values will be overwritten");
/*     */       }
/* 185 */       filterInvocationDefinitionMap.put(matcher, attributeBuilder.getBeanDefinition());
/*     */     } 
/* 187 */     if (addAuthenticatedAll && filterInvocationDefinitionMap.isEmpty()) {
/* 188 */       BeanDefinition matcher = matcherType.createMatcher(parserContext, "/**", (String)null);
/* 189 */       BeanDefinitionBuilder attributeBuilder = BeanDefinitionBuilder.rootBeanDefinition(SecurityConfig.class);
/* 190 */       attributeBuilder.addConstructorArgValue(new String[] { "authenticated" });
/* 191 */       attributeBuilder.setFactoryMethod("createList");
/* 192 */       filterInvocationDefinitionMap.put(matcher, attributeBuilder.getBeanDefinition());
/*     */     } 
/* 194 */     return filterInvocationDefinitionMap;
/*     */   }
/*     */   
/*     */   static class DefaultWebSecurityExpressionHandlerBeanFactory
/*     */     extends GrantedAuthorityDefaultsParserUtils.AbstractGrantedAuthorityDefaultsBeanFactory
/*     */   {
/* 200 */     private DefaultWebSecurityExpressionHandler handler = new DefaultWebSecurityExpressionHandler();
/*     */ 
/*     */     
/*     */     public DefaultWebSecurityExpressionHandler getBean() {
/* 204 */       this.handler.setDefaultRolePrefix(this.rolePrefix);
/* 205 */       return this.handler;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\FilterInvocationSecurityMetadataSourceParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */