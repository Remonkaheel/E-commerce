/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.security.web.servlet.util.matcher.MvcRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RegexRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MatcherType
/*     */ {
/*  42 */   ant((Class)AntPathRequestMatcher.class), regex((Class)RegexRequestMatcher.class), ciRegex((Class)RegexRequestMatcher.class),
/*  43 */   mvc((Class)MvcRequestMatcher.class);
/*     */   
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*     */   
/*     */   private static final boolean mvcPresent;
/*     */   
/*     */   private static final String ATT_MATCHER_TYPE = "request-matcher";
/*     */   
/*     */   final Class<? extends RequestMatcher> type;
/*     */   
/*     */   static {
/*  54 */     mvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.handler.HandlerMappingIntrospector", MatcherType.class.getClassLoader());
/*     */   }
/*     */   
/*     */   MatcherType(Class<? extends RequestMatcher> type) {
/*  58 */     this.type = type;
/*     */   }
/*     */   
/*     */   public BeanDefinition createMatcher(ParserContext pc, String path, String method) {
/*  62 */     return createMatcher(pc, path, method, null);
/*     */   }
/*     */   
/*     */   public BeanDefinition createMatcher(ParserContext pc, String path, String method, String servletPath) {
/*  66 */     if (("/**".equals(path) || "**".equals(path)) && method == null) {
/*  67 */       return (BeanDefinition)new RootBeanDefinition(AnyRequestMatcher.class);
/*     */     }
/*  69 */     BeanDefinitionBuilder matcherBldr = BeanDefinitionBuilder.rootBeanDefinition(this.type);
/*  70 */     if (this == mvc) {
/*  71 */       matcherBldr.addConstructorArgValue(new RootBeanDefinition(HandlerMappingIntrospectorFactoryBean.class));
/*     */     }
/*  73 */     matcherBldr.addConstructorArgValue(path);
/*  74 */     if (this == mvc) {
/*  75 */       matcherBldr.addPropertyValue("method", StringUtils.hasText(method) ? HttpMethod.valueOf(method) : null);
/*  76 */       matcherBldr.addPropertyValue("servletPath", servletPath);
/*     */     } else {
/*     */       
/*  79 */       matcherBldr.addConstructorArgValue(method);
/*     */     } 
/*  81 */     if (this == ciRegex) {
/*  82 */       matcherBldr.addConstructorArgValue(Boolean.valueOf(true));
/*     */     }
/*  84 */     return (BeanDefinition)matcherBldr.getBeanDefinition();
/*     */   }
/*     */   
/*     */   static MatcherType fromElement(Element elt) {
/*  88 */     if (StringUtils.hasText(elt.getAttribute("request-matcher"))) {
/*  89 */       return valueOf(elt.getAttribute("request-matcher"));
/*     */     }
/*     */     
/*  92 */     return ant;
/*     */   }
/*     */   
/*     */   static MatcherType fromElementOrMvc(Element elt) {
/*  96 */     String matcherTypeName = elt.getAttribute("request-matcher");
/*  97 */     if (!StringUtils.hasText(matcherTypeName) && mvcPresent) {
/*  98 */       return mvc;
/*     */     }
/* 100 */     return fromElement(elt);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\MatcherType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */