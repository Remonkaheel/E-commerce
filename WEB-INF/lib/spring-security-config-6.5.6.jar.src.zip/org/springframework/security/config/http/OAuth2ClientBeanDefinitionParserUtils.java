/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OAuth2ClientBeanDefinitionParserUtils
/*    */ {
/*    */   private static final String ATT_CLIENT_REGISTRATION_REPOSITORY_REF = "client-registration-repository-ref";
/*    */   private static final String ATT_AUTHORIZED_CLIENT_REPOSITORY_REF = "authorized-client-repository-ref";
/*    */   private static final String ATT_AUTHORIZED_CLIENT_SERVICE_REF = "authorized-client-service-ref";
/*    */   
/*    */   static BeanMetadataElement getClientRegistrationRepository(Element element) {
/* 44 */     String clientRegistrationRepositoryRef = element.getAttribute("client-registration-repository-ref");
/* 45 */     if (StringUtils.hasLength(clientRegistrationRepositoryRef)) {
/* 46 */       return (BeanMetadataElement)new RuntimeBeanReference(clientRegistrationRepositoryRef);
/*    */     }
/* 48 */     return (BeanMetadataElement)new RuntimeBeanReference(ClientRegistrationRepository.class);
/*    */   }
/*    */   
/*    */   static BeanMetadataElement getAuthorizedClientRepository(Element element) {
/* 52 */     String authorizedClientRepositoryRef = element.getAttribute("authorized-client-repository-ref");
/* 53 */     if (StringUtils.hasLength(authorizedClientRepositoryRef)) {
/* 54 */       return (BeanMetadataElement)new RuntimeBeanReference(authorizedClientRepositoryRef);
/*    */     }
/* 56 */     return null;
/*    */   }
/*    */   
/*    */   static BeanMetadataElement getAuthorizedClientService(Element element) {
/* 60 */     String authorizedClientServiceRef = element.getAttribute("authorized-client-service-ref");
/* 61 */     if (StringUtils.hasLength(authorizedClientServiceRef)) {
/* 62 */       return (BeanMetadataElement)new RuntimeBeanReference(authorizedClientServiceRef);
/*    */     }
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   static BeanDefinition createDefaultAuthorizedClientRepository(BeanMetadataElement clientRegistrationRepository, BeanMetadataElement authorizedClientService) {
/*    */     AbstractBeanDefinition abstractBeanDefinition;
/* 69 */     if (authorizedClientService == null)
/*    */     {
/*    */ 
/*    */       
/* 73 */       abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService").addConstructorArgValue(clientRegistrationRepository).getBeanDefinition();
/*    */     }
/* 75 */     return (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.web.AuthenticatedPrincipalOAuth2AuthorizedClientRepository")
/*    */       
/* 77 */       .addConstructorArgValue(abstractBeanDefinition)
/* 78 */       .getBeanDefinition();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2ClientBeanDefinitionParserUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */