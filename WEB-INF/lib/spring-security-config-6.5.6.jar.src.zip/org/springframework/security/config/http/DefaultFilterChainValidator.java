/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import jakarta.servlet.Filter;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*     */ import org.springframework.security.authentication.TestingAuthenticationToken;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.FilterInvocation;
/*     */ import org.springframework.security.web.SecurityFilterChain;
/*     */ import org.springframework.security.web.UnreachableFilterChainException;
/*     */ import org.springframework.security.web.access.ExceptionTranslationFilter;
/*     */ import org.springframework.security.web.access.intercept.AuthorizationFilter;
/*     */ import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
/*     */ import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
/*     */ import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
/*     */ import org.springframework.security.web.context.SecurityContextPersistenceFilter;
/*     */ import org.springframework.security.web.jaasapi.JaasApiIntegrationFilter;
/*     */ import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
/*     */ import org.springframework.security.web.session.SessionManagementFilter;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFilterChainValidator
/*     */   implements FilterChainProxy.FilterChainValidator
/*     */ {
/*  60 */   private static final Authentication TEST = (Authentication)new TestingAuthenticationToken("", "", Collections.emptyList());
/*     */   
/*  62 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   public void validate(FilterChainProxy fcp) {
/*  66 */     for (SecurityFilterChain filterChain : fcp.getFilterChains()) {
/*  67 */       checkLoginPageIsntProtected(fcp, filterChain.getFilters());
/*  68 */       checkFilterStack(filterChain.getFilters());
/*     */     } 
/*  70 */     checkPathOrder(new ArrayList<>(fcp.getFilterChains()));
/*  71 */     checkForDuplicateMatchers(new ArrayList<>(fcp.getFilterChains()));
/*  72 */     checkAuthorizationFilters(new ArrayList<>(fcp.getFilterChains()));
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkPathOrder(List<SecurityFilterChain> filterChains) {
/*  77 */     Iterator<SecurityFilterChain> chains = filterChains.iterator();
/*  78 */     while (chains.hasNext()) {
/*  79 */       DefaultSecurityFilterChain defaultSecurityFilterChain = (DefaultSecurityFilterChain)chains.next(); if (defaultSecurityFilterChain instanceof DefaultSecurityFilterChain) { DefaultSecurityFilterChain securityFilterChain = defaultSecurityFilterChain;
/*  80 */         if (AnyRequestMatcher.INSTANCE.equals(securityFilterChain.getRequestMatcher()) && chains.hasNext()) {
/*  81 */           throw new UnreachableFilterChainException("A universal match pattern ('/**') is defined  before other patterns in the filter chain, causing them to be ignored. Please check the ordering in your <security:http> namespace or FilterChainProxy bean configuration", securityFilterChain, (SecurityFilterChain)chains
/*     */ 
/*     */               
/*  84 */               .next());
/*     */         } }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkForDuplicateMatchers(List<SecurityFilterChain> chains) {
/*  91 */     DefaultSecurityFilterChain filterChain = null;
/*  92 */     for (SecurityFilterChain chain : chains) {
/*  93 */       if (filterChain != null && 
/*  94 */         chain instanceof DefaultSecurityFilterChain) { DefaultSecurityFilterChain defaultChain = (DefaultSecurityFilterChain)chain;
/*  95 */         if (defaultChain.getRequestMatcher().equals(filterChain.getRequestMatcher())) {
/*  96 */           throw new UnreachableFilterChainException("The FilterChainProxy contains two filter chains using the matcher " + 
/*     */               
/*  98 */               String.valueOf(defaultChain.getRequestMatcher()) + ". If you are using multiple <http> namespace elements, you must use a 'pattern' attribute to define the request patterns to which they apply.", defaultChain, chain);
/*     */         } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 105 */       if (chain instanceof DefaultSecurityFilterChain) { DefaultSecurityFilterChain defaultChain = (DefaultSecurityFilterChain)chain;
/* 106 */         filterChain = defaultChain; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkAuthorizationFilters(List<SecurityFilterChain> chains) {
/* 112 */     Filter authorizationFilter = null;
/* 113 */     Filter filterSecurityInterceptor = null;
/* 114 */     for (SecurityFilterChain chain : chains) {
/* 115 */       for (Filter filter : chain.getFilters()) {
/* 116 */         if (filter instanceof AuthorizationFilter) {
/* 117 */           authorizationFilter = filter;
/*     */         }
/* 119 */         if (filter instanceof FilterSecurityInterceptor) {
/* 120 */           filterSecurityInterceptor = filter;
/*     */         }
/*     */       } 
/* 123 */       if (authorizationFilter != null && filterSecurityInterceptor != null) {
/* 124 */         this.logger.warn("It is not recommended to use authorizeRequests in the configuration. Please only use authorizeHttpRequests");
/*     */       }
/*     */       
/* 127 */       if (filterSecurityInterceptor != null) {
/* 128 */         this.logger.warn("Usage of authorizeRequests is deprecated. Please use authorizeHttpRequests in the configuration");
/*     */       }
/*     */       
/* 131 */       authorizationFilter = null;
/* 132 */       filterSecurityInterceptor = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private <F extends Filter> F getFilter(Class<F> type, List<Filter> filters) {
/* 138 */     for (Filter f : filters) {
/* 139 */       if (type.isAssignableFrom(f.getClass())) {
/* 140 */         return (F)f;
/*     */       }
/*     */     } 
/* 143 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkFilterStack(List<Filter> filters) {
/* 150 */     checkForDuplicates((Class)SecurityContextPersistenceFilter.class, filters);
/* 151 */     checkForDuplicates((Class)UsernamePasswordAuthenticationFilter.class, filters);
/* 152 */     checkForDuplicates((Class)SessionManagementFilter.class, filters);
/* 153 */     checkForDuplicates((Class)BasicAuthenticationFilter.class, filters);
/* 154 */     checkForDuplicates((Class)SecurityContextHolderAwareRequestFilter.class, filters);
/* 155 */     checkForDuplicates((Class)JaasApiIntegrationFilter.class, filters);
/* 156 */     checkForDuplicates((Class)ExceptionTranslationFilter.class, filters);
/* 157 */     checkForDuplicates((Class)FilterSecurityInterceptor.class, filters);
/* 158 */     checkForDuplicates((Class)AuthorizationFilter.class, filters);
/*     */   }
/*     */   
/*     */   private void checkForDuplicates(Class<? extends Filter> clazz, List<Filter> filters) {
/* 162 */     for (int i = 0; i < filters.size(); i++) {
/* 163 */       Filter f1 = filters.get(i);
/* 164 */       if (clazz.isAssignableFrom(f1.getClass()))
/*     */       {
/* 166 */         for (int j = i + 1; j < filters.size(); j++) {
/* 167 */           Filter f2 = filters.get(j);
/* 168 */           if (clazz.isAssignableFrom(f2.getClass())) {
/* 169 */             this.logger.warn("Possible error: Filters at position " + i + " and " + j + " are both instances of " + clazz
/* 170 */                 .getName());
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkLoginPageIsntProtected(FilterChainProxy fcp, List<Filter> filterStack) {
/* 183 */     ExceptionTranslationFilter exceptions = getFilter(ExceptionTranslationFilter.class, filterStack);
/* 184 */     if (exceptions == null || 
/* 185 */       !(exceptions.getAuthenticationEntryPoint() instanceof LoginUrlAuthenticationEntryPoint)) {
/*     */       return;
/*     */     }
/*     */     
/* 189 */     String loginPage = ((LoginUrlAuthenticationEntryPoint)exceptions.getAuthenticationEntryPoint()).getLoginFormUrl();
/* 190 */     this.logger.info("Checking whether login URL '" + loginPage + "' is accessible with your configuration");
/* 191 */     FilterInvocation loginRequest = new FilterInvocation(loginPage, "POST");
/* 192 */     List<Filter> filters = null;
/*     */     try {
/* 194 */       filters = fcp.getFilters(loginPage);
/*     */     }
/* 196 */     catch (Exception ex) {
/*     */ 
/*     */ 
/*     */       
/* 200 */       this.logger.info("Failed to obtain filter chain information for the login page. Unable to complete check.");
/*     */     } 
/* 202 */     if (filters == null || filters.isEmpty()) {
/* 203 */       this.logger.debug("Filter chain is empty for the login page");
/*     */       return;
/*     */     } 
/* 206 */     if (getFilter(DefaultLoginPageGeneratingFilter.class, filters) != null) {
/* 207 */       this.logger.debug("Default generated login page is in use");
/*     */       return;
/*     */     } 
/* 210 */     if (checkLoginPageIsPublic(filters, loginRequest)) {
/*     */       return;
/*     */     }
/* 213 */     AnonymousAuthenticationFilter anonymous = getFilter(AnonymousAuthenticationFilter.class, filters);
/* 214 */     if (anonymous == null) {
/* 215 */       this.logger.warn("The login page is being protected by the filter chain, but you don't appear to have anonymous authentication enabled. This is almost certainly an error.");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 221 */     AnonymousAuthenticationToken token = new AnonymousAuthenticationToken("key", anonymous.getPrincipal(), anonymous.getAuthorities());
/* 222 */     Supplier<Boolean> check = deriveAnonymousCheck(filters, loginRequest, token);
/*     */     try {
/* 224 */       boolean allowed = ((Boolean)check.get()).booleanValue();
/* 225 */       if (!allowed) {
/* 226 */         this.logger.warn("Anonymous access to the login page doesn't appear to be enabled. This is almost certainly an error. Please check your configuration allows unauthenticated access to the configured login page. (Simulated access was rejected)");
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 231 */     catch (Exception ex) {
/*     */ 
/*     */ 
/*     */       
/* 235 */       this.logger.info("Unable to check access to the login page to determine if anonymous access is allowed. This might be an error, but can happen under normal circumstances.", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkLoginPageIsPublic(List<Filter> filters, FilterInvocation loginRequest) {
/* 241 */     FilterSecurityInterceptor authorizationInterceptor = getFilter(FilterSecurityInterceptor.class, filters);
/* 242 */     if (authorizationInterceptor != null) {
/* 243 */       FilterInvocationSecurityMetadataSource fids = authorizationInterceptor.getSecurityMetadataSource();
/* 244 */       Collection<ConfigAttribute> attributes = fids.getAttributes(loginRequest);
/* 245 */       if (attributes == null) {
/* 246 */         this.logger.debug("No access attributes defined for login page URL");
/* 247 */         if (authorizationInterceptor.isRejectPublicInvocations()) {
/* 248 */           this.logger.warn("FilterSecurityInterceptor is configured to reject public invocations. Your login page may not be accessible.");
/*     */         }
/*     */         
/* 251 */         return true;
/*     */       } 
/* 253 */       return false;
/*     */     } 
/* 255 */     AuthorizationFilter authorizationFilter = getFilter(AuthorizationFilter.class, filters);
/* 256 */     if (authorizationFilter != null) {
/*     */       
/* 258 */       AuthorizationManager<HttpServletRequest> authorizationManager = authorizationFilter.getAuthorizationManager();
/*     */       try {
/* 260 */         AuthorizationResult result = authorizationManager.authorize(() -> TEST, loginRequest.getHttpRequest());
/* 261 */         return (result != null && result.isGranted());
/*     */       }
/* 263 */       catch (Exception ex) {
/* 264 */         return false;
/*     */       } 
/*     */     } 
/* 267 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Supplier<Boolean> deriveAnonymousCheck(List<Filter> filters, FilterInvocation loginRequest, AnonymousAuthenticationToken token) {
/* 272 */     FilterSecurityInterceptor authorizationInterceptor = getFilter(FilterSecurityInterceptor.class, filters);
/* 273 */     if (authorizationInterceptor != null) {
/* 274 */       return () -> {
/*     */           FilterInvocationSecurityMetadataSource source = authorizationInterceptor.getSecurityMetadataSource();
/*     */           
/*     */           Collection<ConfigAttribute> attributes = source.getAttributes(loginRequest);
/*     */           try {
/*     */             authorizationInterceptor.getAccessDecisionManager().decide((Authentication)token, loginRequest, attributes);
/*     */             return Boolean.valueOf(true);
/* 281 */           } catch (AccessDeniedException ex) {
/*     */             return Boolean.valueOf(false);
/*     */           } 
/*     */         };
/*     */     }
/* 286 */     AuthorizationFilter authorizationFilter = getFilter(AuthorizationFilter.class, filters);
/* 287 */     if (authorizationFilter != null) {
/* 288 */       return () -> {
/*     */           AuthorizationManager<HttpServletRequest> authorizationManager = authorizationFilter.getAuthorizationManager();
/*     */           
/*     */           AuthorizationResult result = authorizationManager.authorize((), loginRequest.getHttpRequest());
/* 292 */           return Boolean.valueOf((result != null && result.isGranted()));
/*     */         };
/*     */     }
/* 295 */     return () -> Boolean.valueOf(true);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\DefaultFilterChainValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */