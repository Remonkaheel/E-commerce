/*      */ package org.springframework.security.config.http;
/*      */ 
/*      */ import io.micrometer.observation.ObservationRegistry;
/*      */ import jakarta.servlet.ServletRequest;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import org.springframework.beans.BeanMetadataElement;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.factory.FactoryBean;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.BeanReference;
/*      */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*      */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*      */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*      */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*      */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*      */ import org.springframework.beans.factory.support.ManagedList;
/*      */ import org.springframework.beans.factory.support.ManagedMap;
/*      */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*      */ import org.springframework.beans.factory.xml.ParserContext;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.security.access.vote.AffirmativeBased;
/*      */ import org.springframework.security.access.vote.AuthenticatedVoter;
/*      */ import org.springframework.security.access.vote.RoleVoter;
/*      */ import org.springframework.security.core.context.SecurityContextHolder;
/*      */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*      */ import org.springframework.security.core.session.SessionRegistryImpl;
/*      */ import org.springframework.security.web.access.AuthorizationManagerWebInvocationPrivilegeEvaluator;
/*      */ import org.springframework.security.web.access.DefaultWebInvocationPrivilegeEvaluator;
/*      */ import org.springframework.security.web.access.HandlerMappingIntrospectorRequestTransformer;
/*      */ import org.springframework.security.web.access.PathPatternRequestTransformer;
/*      */ import org.springframework.security.web.access.channel.ChannelDecisionManagerImpl;
/*      */ import org.springframework.security.web.access.channel.ChannelProcessingFilter;
/*      */ import org.springframework.security.web.access.channel.InsecureChannelProcessor;
/*      */ import org.springframework.security.web.access.channel.RetryWithHttpEntryPoint;
/*      */ import org.springframework.security.web.access.channel.RetryWithHttpsEntryPoint;
/*      */ import org.springframework.security.web.access.channel.SecureChannelProcessor;
/*      */ import org.springframework.security.web.access.expression.WebExpressionVoter;
/*      */ import org.springframework.security.web.access.intercept.DefaultFilterInvocationSecurityMetadataSource;
/*      */ import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
/*      */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
/*      */ import org.springframework.security.web.authentication.session.ChangeSessionIdAuthenticationStrategy;
/*      */ import org.springframework.security.web.authentication.session.CompositeSessionAuthenticationStrategy;
/*      */ import org.springframework.security.web.authentication.session.ConcurrentSessionControlAuthenticationStrategy;
/*      */ import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
/*      */ import org.springframework.security.web.authentication.session.SessionFixationProtectionStrategy;
/*      */ import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
/*      */ import org.springframework.security.web.context.RequestAttributeSecurityContextRepository;
/*      */ import org.springframework.security.web.context.SecurityContextHolderFilter;
/*      */ import org.springframework.security.web.context.SecurityContextPersistenceFilter;
/*      */ import org.springframework.security.web.context.request.async.WebAsyncManagerIntegrationFilter;
/*      */ import org.springframework.security.web.jaasapi.JaasApiIntegrationFilter;
/*      */ import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
/*      */ import org.springframework.security.web.savedrequest.NullRequestCache;
/*      */ import org.springframework.security.web.savedrequest.RequestCacheAwareFilter;
/*      */ import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
/*      */ import org.springframework.security.web.session.ConcurrentSessionFilter;
/*      */ import org.springframework.security.web.session.DisableEncodeUrlFilter;
/*      */ import org.springframework.security.web.session.ForceEagerSessionCreationFilter;
/*      */ import org.springframework.security.web.session.SessionManagementFilter;
/*      */ import org.springframework.security.web.session.SimpleRedirectInvalidSessionStrategy;
/*      */ import org.springframework.security.web.session.SimpleRedirectSessionInformationExpiredStrategy;
/*      */ import org.springframework.security.web.transport.HttpsRedirectFilter;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.util.xml.DomUtils;
/*      */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*      */ import org.w3c.dom.Element;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class HttpConfigurationBuilder
/*      */ {
/*      */   private static final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/*  105 */   private static final boolean mvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.handler.HandlerMappingIntrospector", HttpConfigurationBuilder.class
/*  106 */       .getClassLoader());
/*      */   
/*      */   private static final String ATT_CREATE_SESSION = "create-session";
/*      */   
/*      */   private static final String ATT_SESSION_FIXATION_PROTECTION = "session-fixation-protection";
/*      */   
/*      */   private static final String OPT_SESSION_FIXATION_NO_PROTECTION = "none";
/*      */   
/*      */   private static final String OPT_SESSION_FIXATION_MIGRATE_SESSION = "migrateSession";
/*      */   
/*      */   private static final String OPT_CHANGE_SESSION_ID = "changeSessionId";
/*      */   
/*      */   private static final String ATT_AUTHENTICATION_STRATEGY_EXPLICIT_INVOCATION = "authentication-strategy-explicit-invocation";
/*      */   
/*      */   private static final String ATT_INVALID_SESSION_URL = "invalid-session-url";
/*      */   
/*      */   private static final String ATT_OBSERVATION_REGISTRY_REF = "observation-registry-ref";
/*      */   
/*      */   private static final String ATT_SESSION_AUTH_STRATEGY_REF = "session-authentication-strategy-ref";
/*      */   
/*      */   private static final String ATT_MAX_SESSIONS_REF = "max-sessions-ref";
/*      */   
/*      */   private static final String ATT_MAX_SESSIONS = "max-sessions";
/*      */   
/*      */   private static final String ATT_SESSION_AUTH_ERROR_URL = "session-authentication-error-url";
/*      */   
/*      */   private static final String ATT_SECURITY_CONTEXT_HOLDER_STRATEGY = "security-context-holder-strategy-ref";
/*      */   
/*      */   private static final String ATT_SECURITY_CONTEXT_REPOSITORY = "security-context-repository-ref";
/*      */   
/*      */   private static final String ATT_SECURITY_CONTEXT_EXPLICIT_SAVE = "security-context-explicit-save";
/*      */   
/*      */   private static final String ATT_INVALID_SESSION_STRATEGY_REF = "invalid-session-strategy-ref";
/*      */   
/*      */   private static final String ATT_DISABLE_URL_REWRITING = "disable-url-rewriting";
/*      */   
/*      */   private static final String ATT_USE_AUTHORIZATION_MGR = "use-authorization-manager";
/*      */   
/*      */   private static final String ATT_AUTHORIZATION_MGR = "authorization-manager-ref";
/*      */   
/*      */   private static final String ATT_ACCESS_MGR = "access-decision-manager-ref";
/*      */   
/*      */   private static final String ATT_ONCE_PER_REQUEST = "once-per-request";
/*      */   
/*      */   private static final String ATT_REF = "ref";
/*      */   
/*      */   private static final String ATT_EXPIRY_URL = "expired-url";
/*      */   
/*      */   private static final String ATT_EXPIRED_SESSION_STRATEGY_REF = "expired-session-strategy-ref";
/*      */   
/*      */   private static final String ATT_SESSION_REGISTRY_ALIAS = "session-registry-alias";
/*      */   
/*      */   private static final String ATT_SESSION_REGISTRY_REF = "session-registry-ref";
/*      */   
/*      */   private static final String ATT_SERVLET_API_PROVISION = "servlet-api-provision";
/*      */   
/*      */   private static final String DEF_SERVLET_API_PROVISION = "true";
/*      */   
/*      */   private static final String ATT_JAAS_API_PROVISION = "jaas-api-provision";
/*      */   
/*      */   private static final String DEF_JAAS_API_PROVISION = "false";
/*      */   
/*      */   private final Element httpElt;
/*      */   
/*      */   private final ParserContext pc;
/*      */   
/*      */   private final SessionCreationPolicy sessionPolicy;
/*      */   
/*      */   private final List<Element> interceptUrls;
/*      */   
/*      */   private final MatcherType matcherType;
/*      */   
/*      */   private BeanDefinition cpf;
/*      */   
/*      */   private BeanDefinition httpsRedirectFilter;
/*      */   
/*      */   private BeanDefinition securityContextPersistenceFilter;
/*      */   
/*      */   private BeanDefinition forceEagerSessionCreationFilter;
/*      */   
/*      */   private BeanMetadataElement holderStrategyRef;
/*      */   
/*      */   private BeanReference contextRepoRef;
/*      */   
/*      */   private BeanReference sessionRegistryRef;
/*      */   
/*      */   private BeanDefinition concurrentSessionFilter;
/*      */   
/*      */   private BeanDefinition webAsyncManagerFilter;
/*      */   
/*      */   private BeanDefinition requestCacheAwareFilter;
/*      */   
/*      */   private BeanReference sessionStrategyRef;
/*      */   
/*      */   private RootBeanDefinition sfpf;
/*      */   
/*      */   private BeanDefinition servApiFilter;
/*      */   
/*      */   private BeanDefinition jaasApiFilter;
/*      */   
/*      */   private final BeanReference portMapper;
/*      */   
/*      */   private final BeanReference portResolver;
/*      */   
/*      */   private BeanReference fsi;
/*      */   
/*      */   private BeanReference requestCache;
/*      */   
/*      */   private BeanDefinition addHeadersFilter;
/*      */   
/*      */   private BeanMetadataElement corsFilter;
/*      */   
/*      */   private BeanDefinition csrfFilter;
/*      */   
/*      */   private BeanDefinition disableUrlRewriteFilter;
/*      */   
/*      */   private BeanDefinition wellKnownChangePasswordRedirectFilter;
/*      */   
/*      */   private BeanMetadataElement csrfLogoutHandler;
/*      */   
/*      */   private BeanMetadataElement csrfAuthStrategy;
/*      */   
/*      */   private CsrfBeanDefinitionParser csrfParser;
/*      */   
/*      */   private BeanDefinition invalidSession;
/*      */   
/*      */   private boolean addAllAuth;
/*      */ 
/*      */   
/*      */   HttpConfigurationBuilder(Element element, boolean addAllAuth, ParserContext pc, BeanReference portMapper, BeanReference portResolver, BeanReference authenticationManager, BeanMetadataElement observationRegistry) {
/*  236 */     this.httpElt = element;
/*  237 */     this.addAllAuth = addAllAuth;
/*  238 */     this.pc = pc;
/*  239 */     this.portMapper = portMapper;
/*  240 */     this.portResolver = portResolver;
/*  241 */     this.matcherType = MatcherType.fromElementOrMvc(element);
/*  242 */     this.interceptUrls = DomUtils.getChildElementsByTagName(element, "intercept-url");
/*  243 */     validateInterceptUrls(pc);
/*  244 */     String createSession = element.getAttribute("create-session");
/*  245 */     this
/*  246 */       .sessionPolicy = !StringUtils.hasText(createSession) ? SessionCreationPolicy.IF_REQUIRED : createPolicy(createSession);
/*  247 */     createSecurityContextHolderStrategy();
/*  248 */     createForceEagerSessionCreationFilter();
/*  249 */     createDisableEncodeUrlFilter();
/*  250 */     createCsrfFilter(observationRegistry);
/*  251 */     createSecurityPersistence();
/*  252 */     createSessionManagementFilters();
/*  253 */     createWebAsyncManagerFilter();
/*  254 */     createRequestCacheFilter();
/*  255 */     createServletApiFilter(authenticationManager);
/*  256 */     createJaasApiFilter();
/*  257 */     createChannelProcessingFilter();
/*  258 */     createHttpsRedirectFilter();
/*  259 */     createFilterSecurity(authenticationManager);
/*  260 */     createAddHeadersFilter();
/*  261 */     createCorsFilter();
/*  262 */     createWellKnownChangePasswordRedirectFilter();
/*      */   }
/*      */   
/*      */   private void validateInterceptUrls(ParserContext pc) {
/*  266 */     for (Element element : this.interceptUrls) {
/*  267 */       if (StringUtils.hasText(element.getAttribute("filters"))) {
/*  268 */         String message = "The use of \"filters='none'\" is no longer supported. Please define a separate <http> element for the pattern you want to exclude and use the attribute \"security='none'\".";
/*      */ 
/*      */         
/*  271 */         pc.getReaderContext().error(message, pc.extractSource(element));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private SessionCreationPolicy createPolicy(String createSession) {
/*  277 */     if ("ifRequired".equals(createSession)) {
/*  278 */       return SessionCreationPolicy.IF_REQUIRED;
/*      */     }
/*  280 */     if ("always".equals(createSession)) {
/*  281 */       return SessionCreationPolicy.ALWAYS;
/*      */     }
/*  283 */     if ("never".equals(createSession)) {
/*  284 */       return SessionCreationPolicy.NEVER;
/*      */     }
/*  286 */     if ("stateless".equals(createSession)) {
/*  287 */       return SessionCreationPolicy.STATELESS;
/*      */     }
/*  289 */     throw new IllegalStateException("Cannot convert " + createSession + " to " + SessionCreationPolicy.class
/*  290 */         .getName());
/*      */   }
/*      */ 
/*      */   
/*      */   void setLogoutHandlers(ManagedList logoutHandlers) {
/*  295 */     if (logoutHandlers != null) {
/*  296 */       if (this.concurrentSessionFilter != null) {
/*  297 */         this.concurrentSessionFilter.getPropertyValues().add("logoutHandlers", logoutHandlers);
/*      */       }
/*  299 */       if (this.servApiFilter != null) {
/*  300 */         this.servApiFilter.getPropertyValues().add("logoutHandlers", logoutHandlers);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   void setEntryPoint(BeanMetadataElement entryPoint) {
/*  306 */     if (this.servApiFilter != null) {
/*  307 */       this.servApiFilter.getPropertyValues().add("authenticationEntryPoint", entryPoint);
/*      */     }
/*      */   }
/*      */   
/*      */   void setAccessDeniedHandler(BeanMetadataElement accessDeniedHandler) {
/*  312 */     if (this.csrfParser != null) {
/*  313 */       this.csrfParser.initAccessDeniedHandler(this.invalidSession, accessDeniedHandler);
/*      */     }
/*      */   }
/*      */   
/*      */   void setCsrfIgnoreRequestMatchers(List<BeanDefinition> requestMatchers) {
/*  318 */     if (this.csrfParser != null) {
/*  319 */       this.csrfParser.setIgnoreCsrfRequestMatchers(requestMatchers);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static String createPath(String path, boolean lowerCase) {
/*  325 */     return lowerCase ? path.toLowerCase(Locale.ENGLISH) : path;
/*      */   }
/*      */   
/*      */   BeanMetadataElement getSecurityContextHolderStrategyForAuthenticationFilters() {
/*  329 */     return this.holderStrategyRef;
/*      */   }
/*      */   
/*      */   BeanReference getSecurityContextRepositoryForAuthenticationFilters() {
/*  333 */     return isExplicitSave() ? this.contextRepoRef : null;
/*      */   }
/*      */   
/*      */   private void createSecurityPersistence() {
/*  337 */     createSecurityContextRepository();
/*  338 */     if (isExplicitSave()) {
/*  339 */       createSecurityContextHolderFilter();
/*      */     } else {
/*      */       
/*  342 */       createSecurityContextPersistenceFilter();
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isExplicitSave() {
/*  347 */     String explicitSaveAttr = this.httpElt.getAttribute("security-context-explicit-save");
/*  348 */     return (!StringUtils.hasText(explicitSaveAttr) || Boolean.parseBoolean(explicitSaveAttr));
/*      */   }
/*      */   
/*      */   private void createForceEagerSessionCreationFilter() {
/*  352 */     if (this.sessionPolicy == SessionCreationPolicy.ALWAYS) {
/*  353 */       this.forceEagerSessionCreationFilter = (BeanDefinition)new RootBeanDefinition(ForceEagerSessionCreationFilter.class);
/*      */     }
/*      */   }
/*      */   
/*      */   private void createSecurityContextPersistenceFilter() {
/*  358 */     BeanDefinitionBuilder scpf = BeanDefinitionBuilder.rootBeanDefinition(SecurityContextPersistenceFilter.class);
/*  359 */     switch (this.sessionPolicy) {
/*      */       case ALWAYS:
/*  361 */         scpf.addPropertyValue("forceEagerSessionCreation", Boolean.TRUE);
/*      */         break;
/*      */       case NEVER:
/*  364 */         scpf.addPropertyValue("forceEagerSessionCreation", Boolean.FALSE);
/*      */         break;
/*      */       default:
/*  367 */         scpf.addPropertyValue("forceEagerSessionCreation", Boolean.FALSE); break;
/*      */     } 
/*  369 */     scpf.addPropertyValue("securityContextHolderStrategy", this.holderStrategyRef);
/*  370 */     scpf.addConstructorArgValue(this.contextRepoRef);
/*      */     
/*  372 */     this.securityContextPersistenceFilter = (BeanDefinition)scpf.getBeanDefinition();
/*      */   }
/*      */   
/*      */   private void createSecurityContextHolderStrategy() {
/*  376 */     String holderStrategyRef = this.httpElt.getAttribute("security-context-holder-strategy-ref");
/*  377 */     if (StringUtils.hasText(holderStrategyRef)) {
/*  378 */       this.holderStrategyRef = (BeanMetadataElement)new RuntimeBeanReference(holderStrategyRef);
/*      */       return;
/*      */     } 
/*  381 */     this
/*  382 */       .holderStrategyRef = (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(SecurityContextHolderStrategyFactory.class).getBeanDefinition();
/*      */   }
/*      */   
/*      */   private void createSecurityContextRepository() {
/*  386 */     String repoRef = this.httpElt.getAttribute("security-context-repository-ref");
/*  387 */     if (!StringUtils.hasText(repoRef)) {
/*      */       BeanDefinitionBuilder contextRepo;
/*  389 */       if (this.sessionPolicy == SessionCreationPolicy.STATELESS) {
/*  390 */         contextRepo = BeanDefinitionBuilder.rootBeanDefinition(RequestAttributeSecurityContextRepository.class);
/*      */       } else {
/*      */         
/*  393 */         contextRepo = BeanDefinitionBuilder.rootBeanDefinition(HttpSessionSecurityContextRepository.class);
/*  394 */         switch (this.sessionPolicy) {
/*      */           case ALWAYS:
/*  396 */             contextRepo.addPropertyValue("allowSessionCreation", Boolean.TRUE);
/*      */             break;
/*      */           case NEVER:
/*  399 */             contextRepo.addPropertyValue("allowSessionCreation", Boolean.FALSE);
/*      */             break;
/*      */           default:
/*  402 */             contextRepo.addPropertyValue("allowSessionCreation", Boolean.TRUE); break;
/*      */         } 
/*  404 */         if (isDisableUrlRewriting()) {
/*  405 */           contextRepo.addPropertyValue("disableUrlRewriting", Boolean.TRUE);
/*      */         }
/*      */       } 
/*  408 */       contextRepo.addPropertyValue("securityContextHolderStrategy", this.holderStrategyRef);
/*  409 */       AbstractBeanDefinition abstractBeanDefinition = contextRepo.getBeanDefinition();
/*  410 */       repoRef = this.pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/*  411 */       this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, repoRef));
/*      */     } 
/*      */     
/*  414 */     this.contextRepoRef = (BeanReference)new RuntimeBeanReference(repoRef);
/*      */   }
/*      */   
/*      */   private boolean isDisableUrlRewriting() {
/*  418 */     String disableUrlRewriting = this.httpElt.getAttribute("disable-url-rewriting");
/*  419 */     return !"false".equals(disableUrlRewriting);
/*      */   }
/*      */   
/*      */   private void createSecurityContextHolderFilter() {
/*  423 */     BeanDefinitionBuilder filter = BeanDefinitionBuilder.rootBeanDefinition(SecurityContextHolderFilter.class);
/*  424 */     filter.addPropertyValue("securityContextHolderStrategy", this.holderStrategyRef);
/*  425 */     filter.addConstructorArgValue(this.contextRepoRef);
/*  426 */     this.securityContextPersistenceFilter = (BeanDefinition)filter.getBeanDefinition();
/*      */   }
/*      */   
/*      */   private void createSessionManagementFilters() {
/*  430 */     Element sessionMgmtElt = DomUtils.getChildElementByTagName(this.httpElt, "session-management");
/*  431 */     Element sessionCtrlElt = null;
/*  432 */     String sessionFixationAttribute = null;
/*  433 */     String invalidSessionUrl = null;
/*  434 */     String invalidSessionStrategyRef = null;
/*  435 */     String sessionAuthStratRef = null;
/*  436 */     String errorUrl = null;
/*  437 */     boolean sessionControlEnabled = false;
/*  438 */     if (sessionMgmtElt != null) {
/*  439 */       if (this.sessionPolicy == SessionCreationPolicy.STATELESS) {
/*  440 */         this.pc.getReaderContext()
/*  441 */           .error("session-management  cannot be used in combination with create-session='" + String.valueOf(SessionCreationPolicy.STATELESS) + "'", this.pc
/*      */             
/*  443 */             .extractSource(sessionMgmtElt));
/*      */       }
/*  445 */       sessionFixationAttribute = sessionMgmtElt.getAttribute("session-fixation-protection");
/*  446 */       invalidSessionUrl = sessionMgmtElt.getAttribute("invalid-session-url");
/*  447 */       invalidSessionStrategyRef = sessionMgmtElt.getAttribute("invalid-session-strategy-ref");
/*  448 */       sessionAuthStratRef = sessionMgmtElt.getAttribute("session-authentication-strategy-ref");
/*  449 */       errorUrl = sessionMgmtElt.getAttribute("session-authentication-error-url");
/*  450 */       sessionCtrlElt = DomUtils.getChildElementByTagName(sessionMgmtElt, "concurrency-control");
/*  451 */       sessionControlEnabled = (sessionCtrlElt != null);
/*  452 */       if (StringUtils.hasText(invalidSessionUrl) && StringUtils.hasText(invalidSessionStrategyRef)) {
/*  453 */         this.pc.getReaderContext()
/*  454 */           .error("invalid-session-url attribute cannot be used in combination with the invalid-session-strategy-ref attribute.", sessionMgmtElt);
/*      */       }
/*      */       
/*  457 */       if (sessionControlEnabled) {
/*  458 */         if (StringUtils.hasText(sessionAuthStratRef)) {
/*  459 */           this.pc.getReaderContext()
/*  460 */             .error("session-authentication-strategy-ref attribute cannot be used in combination with <concurrency-control>", this.pc
/*  461 */               .extractSource(sessionCtrlElt));
/*      */         }
/*  463 */         createConcurrencyControlFilterAndSessionRegistry(sessionCtrlElt);
/*      */       } 
/*      */     } 
/*      */     
/*  467 */     if (!StringUtils.hasText(sessionFixationAttribute)) {
/*  468 */       sessionFixationAttribute = "changeSessionId";
/*      */     }
/*  470 */     else if (StringUtils.hasText(sessionAuthStratRef)) {
/*  471 */       this.pc.getReaderContext()
/*  472 */         .error("session-fixation-protection attribute cannot be used in combination with session-authentication-strategy-ref", this.pc
/*  473 */           .extractSource(sessionMgmtElt));
/*      */     } 
/*      */     
/*  476 */     if (this.sessionPolicy == SessionCreationPolicy.STATELESS) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  481 */     boolean sessionFixationProtectionRequired = !sessionFixationAttribute.equals("none");
/*  482 */     ManagedList<BeanMetadataElement> delegateSessionStrategies = new ManagedList();
/*      */     
/*  484 */     BeanDefinitionBuilder sessionFixationStrategy = null;
/*      */     
/*  486 */     if (this.csrfAuthStrategy != null) {
/*  487 */       delegateSessionStrategies.add(this.csrfAuthStrategy);
/*      */     }
/*  489 */     if (sessionControlEnabled) {
/*  490 */       Assert.state((this.sessionRegistryRef != null), "No sessionRegistryRef found");
/*      */       
/*  492 */       BeanDefinitionBuilder concurrentSessionStrategy = BeanDefinitionBuilder.rootBeanDefinition(ConcurrentSessionControlAuthenticationStrategy.class);
/*  493 */       concurrentSessionStrategy.addConstructorArgValue(this.sessionRegistryRef);
/*      */ 
/*      */       
/*  496 */       String maxSessions = this.pc.getReaderContext().getEnvironment().resolvePlaceholders(sessionCtrlElt.getAttribute("max-sessions"));
/*  497 */       if (StringUtils.hasText(maxSessions)) {
/*  498 */         concurrentSessionStrategy.addPropertyValue("maximumSessions", maxSessions);
/*      */       }
/*      */ 
/*      */       
/*  502 */       String maxSessionsRef = this.pc.getReaderContext().getEnvironment().resolvePlaceholders(sessionCtrlElt.getAttribute("max-sessions-ref"));
/*  503 */       if (StringUtils.hasText(maxSessionsRef)) {
/*  504 */         concurrentSessionStrategy.addPropertyReference("maximumSessions", maxSessionsRef);
/*      */       }
/*  506 */       String exceptionIfMaximumExceeded = sessionCtrlElt.getAttribute("error-if-maximum-exceeded");
/*  507 */       if (StringUtils.hasText(exceptionIfMaximumExceeded)) {
/*  508 */         concurrentSessionStrategy.addPropertyValue("exceptionIfMaximumExceeded", exceptionIfMaximumExceeded);
/*      */       }
/*  510 */       delegateSessionStrategies.add(concurrentSessionStrategy.getBeanDefinition());
/*      */     } 
/*  512 */     boolean useChangeSessionId = "changeSessionId".equals(sessionFixationAttribute);
/*  513 */     if (sessionFixationProtectionRequired || StringUtils.hasText(invalidSessionUrl)) {
/*  514 */       if (useChangeSessionId) {
/*      */         
/*  516 */         sessionFixationStrategy = BeanDefinitionBuilder.rootBeanDefinition(ChangeSessionIdAuthenticationStrategy.class);
/*      */       }
/*      */       else {
/*      */         
/*  520 */         sessionFixationStrategy = BeanDefinitionBuilder.rootBeanDefinition(SessionFixationProtectionStrategy.class);
/*      */       } 
/*  522 */       delegateSessionStrategies.add(sessionFixationStrategy.getBeanDefinition());
/*      */     } 
/*  524 */     if (StringUtils.hasText(sessionAuthStratRef)) {
/*  525 */       delegateSessionStrategies.add(new RuntimeBeanReference(sessionAuthStratRef));
/*      */     }
/*  527 */     if (sessionControlEnabled) {
/*      */       
/*  529 */       BeanDefinitionBuilder registerSessionStrategy = BeanDefinitionBuilder.rootBeanDefinition(RegisterSessionAuthenticationStrategy.class);
/*  530 */       registerSessionStrategy.addConstructorArgValue(this.sessionRegistryRef);
/*  531 */       delegateSessionStrategies.add(registerSessionStrategy.getBeanDefinition());
/*      */     } 
/*  533 */     if (delegateSessionStrategies.isEmpty()) {
/*  534 */       this.sfpf = null;
/*      */       
/*      */       return;
/*      */     } 
/*  538 */     BeanDefinitionBuilder sessionMgmtFilter = BeanDefinitionBuilder.rootBeanDefinition(SessionManagementFilter.class);
/*  539 */     RootBeanDefinition failureHandler = new RootBeanDefinition(SimpleUrlAuthenticationFailureHandler.class);
/*  540 */     if (StringUtils.hasText(errorUrl)) {
/*  541 */       failureHandler.getPropertyValues().addPropertyValue("defaultFailureUrl", errorUrl);
/*      */     }
/*  543 */     sessionMgmtFilter.addPropertyValue("securityContextHolderStrategy", this.holderStrategyRef);
/*  544 */     sessionMgmtFilter.addPropertyValue("authenticationFailureHandler", failureHandler);
/*  545 */     sessionMgmtFilter.addConstructorArgValue(this.contextRepoRef);
/*  546 */     if (!StringUtils.hasText(sessionAuthStratRef) && sessionFixationStrategy != null && !useChangeSessionId && 
/*  547 */       sessionFixationProtectionRequired) {
/*  548 */       sessionFixationStrategy.addPropertyValue("migrateSessionAttributes", 
/*  549 */           Boolean.valueOf(sessionFixationAttribute.equals("migrateSession")));
/*      */     }
/*      */     
/*  552 */     if (!delegateSessionStrategies.isEmpty()) {
/*      */       
/*  554 */       BeanDefinitionBuilder sessionStrategy = BeanDefinitionBuilder.rootBeanDefinition(CompositeSessionAuthenticationStrategy.class);
/*  555 */       AbstractBeanDefinition abstractBeanDefinition = sessionStrategy.getBeanDefinition();
/*  556 */       sessionStrategy.addConstructorArgValue(delegateSessionStrategies);
/*  557 */       sessionAuthStratRef = this.pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/*  558 */       this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, sessionAuthStratRef));
/*      */     } 
/*  560 */     if (StringUtils.hasText(invalidSessionUrl)) {
/*      */       
/*  562 */       BeanDefinitionBuilder invalidSessionBldr = BeanDefinitionBuilder.rootBeanDefinition(SimpleRedirectInvalidSessionStrategy.class);
/*  563 */       invalidSessionBldr.addConstructorArgValue(invalidSessionUrl);
/*  564 */       this.invalidSession = (BeanDefinition)invalidSessionBldr.getBeanDefinition();
/*  565 */       sessionMgmtFilter.addPropertyValue("invalidSessionStrategy", this.invalidSession);
/*      */     }
/*  567 */     else if (StringUtils.hasText(invalidSessionStrategyRef)) {
/*  568 */       sessionMgmtFilter.addPropertyReference("invalidSessionStrategy", invalidSessionStrategyRef);
/*      */     } 
/*  570 */     sessionMgmtFilter.addConstructorArgReference(sessionAuthStratRef);
/*      */     
/*  572 */     boolean registerSessionMgmtFilter = (sessionMgmtElt != null && "false".equals(sessionMgmtElt.getAttribute("authentication-strategy-explicit-invocation")));
/*  573 */     if (registerSessionMgmtFilter || StringUtils.hasText(errorUrl) || StringUtils.hasText(invalidSessionUrl) || 
/*  574 */       StringUtils.hasText(invalidSessionStrategyRef)) {
/*  575 */       this.sfpf = (RootBeanDefinition)sessionMgmtFilter.getBeanDefinition();
/*      */     }
/*  577 */     this.sessionStrategyRef = (BeanReference)new RuntimeBeanReference(sessionAuthStratRef);
/*      */   }
/*      */ 
/*      */   
/*      */   private void createConcurrencyControlFilterAndSessionRegistry(Element element) {
/*  582 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), this.pc.extractSource(element));
/*  583 */     this.pc.pushContainingComponent(compositeDef);
/*  584 */     BeanDefinitionRegistry beanRegistry = this.pc.getRegistry();
/*  585 */     String sessionRegistryId = element.getAttribute("session-registry-ref");
/*  586 */     if (!StringUtils.hasText(sessionRegistryId)) {
/*      */       
/*  588 */       RootBeanDefinition sessionRegistry = new RootBeanDefinition(SessionRegistryImpl.class);
/*  589 */       sessionRegistryId = this.pc.getReaderContext().registerWithGeneratedName((BeanDefinition)sessionRegistry);
/*  590 */       this.pc.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)sessionRegistry, sessionRegistryId));
/*      */     } 
/*  592 */     String registryAlias = element.getAttribute("session-registry-alias");
/*  593 */     if (StringUtils.hasText(registryAlias)) {
/*  594 */       beanRegistry.registerAlias(sessionRegistryId, registryAlias);
/*      */     }
/*  596 */     BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(ConcurrentSessionFilter.class);
/*  597 */     filterBuilder.addConstructorArgReference(sessionRegistryId);
/*  598 */     Object source = this.pc.extractSource(element);
/*  599 */     filterBuilder.getRawBeanDefinition().setSource(source);
/*  600 */     filterBuilder.setRole(2);
/*  601 */     String expiryUrl = element.getAttribute("expired-url");
/*  602 */     String expiredSessionStrategyRef = element.getAttribute("expired-session-strategy-ref");
/*  603 */     if (StringUtils.hasText(expiryUrl) && StringUtils.hasText(expiredSessionStrategyRef)) {
/*  604 */       this.pc.getReaderContext()
/*  605 */         .error("Cannot use 'expired-url' attribute and 'expired-session-strategy-ref' attribute together.", source);
/*      */     }
/*      */     
/*  608 */     String maxSessions = element.getAttribute("max-sessions");
/*  609 */     String maxSessionsRef = element.getAttribute("max-sessions-ref");
/*  610 */     if (StringUtils.hasText(maxSessions) && StringUtils.hasText(maxSessionsRef)) {
/*  611 */       this.pc.getReaderContext()
/*  612 */         .error("Cannot use 'max-sessions' attribute and 'max-sessions-ref' attribute together.", source);
/*      */     }
/*  614 */     if (StringUtils.hasText(expiryUrl)) {
/*      */       
/*  616 */       BeanDefinitionBuilder expiredSessionBldr = BeanDefinitionBuilder.rootBeanDefinition(SimpleRedirectSessionInformationExpiredStrategy.class);
/*  617 */       expiredSessionBldr.addConstructorArgValue(expiryUrl);
/*  618 */       filterBuilder.addConstructorArgValue(expiredSessionBldr.getBeanDefinition());
/*      */     }
/*  620 */     else if (StringUtils.hasText(expiredSessionStrategyRef)) {
/*  621 */       filterBuilder.addConstructorArgReference(expiredSessionStrategyRef);
/*      */     } 
/*  623 */     this.pc.popAndRegisterContainingComponent();
/*  624 */     this.concurrentSessionFilter = (BeanDefinition)filterBuilder.getBeanDefinition();
/*  625 */     this.sessionRegistryRef = (BeanReference)new RuntimeBeanReference(sessionRegistryId);
/*      */   }
/*      */   
/*      */   private void createWebAsyncManagerFilter() {
/*  629 */     boolean asyncSupported = ClassUtils.hasMethod(ServletRequest.class, "startAsync", new Class[0]);
/*  630 */     if (asyncSupported) {
/*  631 */       this.webAsyncManagerFilter = (BeanDefinition)new RootBeanDefinition(WebAsyncManagerIntegrationFilter.class);
/*  632 */       this.webAsyncManagerFilter.getPropertyValues().add("securityContextHolderStrategy", this.holderStrategyRef);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void createServletApiFilter(BeanReference authenticationManager) {
/*  638 */     String provideServletApi = this.httpElt.getAttribute("servlet-api-provision");
/*  639 */     if (!StringUtils.hasText(provideServletApi)) {
/*  640 */       provideServletApi = "true";
/*      */     }
/*  642 */     if ("true".equals(provideServletApi)) {
/*  643 */       this.servApiFilter = (BeanDefinition)GrantedAuthorityDefaultsParserUtils.registerWithDefaultRolePrefix(this.pc, (Class)SecurityContextHolderAwareRequestFilterBeanFactory.class);
/*      */       
/*  645 */       this.servApiFilter.getPropertyValues().add("authenticationManager", authenticationManager);
/*  646 */       this.servApiFilter.getPropertyValues().add("securityContextHolderStrategy", this.holderStrategyRef);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void createJaasApiFilter() {
/*  652 */     String provideJaasApi = this.httpElt.getAttribute("jaas-api-provision");
/*  653 */     if (!StringUtils.hasText(provideJaasApi)) {
/*  654 */       provideJaasApi = "false";
/*      */     }
/*  656 */     if ("true".equals(provideJaasApi)) {
/*  657 */       this
/*      */         
/*  659 */         .jaasApiFilter = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(JaasApiIntegrationFilter.class).addPropertyValue("securityContextHolderStrategy", this.holderStrategyRef).getBeanDefinition();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void createHttpsRedirectFilter() {
/*  665 */     String ref = this.httpElt.getAttribute("redirect-to-https-request-matcher-ref");
/*  666 */     if (!StringUtils.hasText(ref)) {
/*      */       return;
/*      */     }
/*  669 */     RootBeanDefinition channelFilter = new RootBeanDefinition(HttpsRedirectFilter.class);
/*  670 */     channelFilter.getPropertyValues().addPropertyValue("requestMatcher", new RuntimeBeanReference(ref));
/*  671 */     channelFilter.getPropertyValues().addPropertyValue("portMapper", this.portMapper);
/*  672 */     this.httpsRedirectFilter = (BeanDefinition)channelFilter;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   private void createChannelProcessingFilter() {
/*  677 */     ManagedMap<BeanMetadataElement, BeanDefinition> channelRequestMap = parseInterceptUrlsForChannelSecurity();
/*  678 */     if (channelRequestMap.isEmpty()) {
/*      */       return;
/*      */     }
/*  681 */     RootBeanDefinition channelFilter = new RootBeanDefinition(ChannelProcessingFilter.class);
/*      */     
/*  683 */     BeanDefinitionBuilder metadataSourceBldr = BeanDefinitionBuilder.rootBeanDefinition(DefaultFilterInvocationSecurityMetadataSource.class);
/*  684 */     metadataSourceBldr.addConstructorArgValue(channelRequestMap);
/*  685 */     channelFilter.getPropertyValues()
/*  686 */       .addPropertyValue("securityMetadataSource", metadataSourceBldr.getBeanDefinition());
/*  687 */     RootBeanDefinition channelDecisionManager = new RootBeanDefinition(ChannelDecisionManagerImpl.class);
/*  688 */     ManagedList<RootBeanDefinition> channelProcessors = new ManagedList(3);
/*  689 */     RootBeanDefinition secureChannelProcessor = new RootBeanDefinition(SecureChannelProcessor.class);
/*  690 */     RootBeanDefinition retryWithHttp = new RootBeanDefinition(RetryWithHttpEntryPoint.class);
/*  691 */     RootBeanDefinition retryWithHttps = new RootBeanDefinition(RetryWithHttpsEntryPoint.class);
/*  692 */     retryWithHttp.getPropertyValues().addPropertyValue("portMapper", this.portMapper);
/*  693 */     retryWithHttp.getPropertyValues().addPropertyValue("portResolver", this.portResolver);
/*  694 */     retryWithHttps.getPropertyValues().addPropertyValue("portMapper", this.portMapper);
/*  695 */     retryWithHttps.getPropertyValues().addPropertyValue("portResolver", this.portResolver);
/*  696 */     secureChannelProcessor.getPropertyValues().addPropertyValue("entryPoint", retryWithHttps);
/*  697 */     RootBeanDefinition inSecureChannelProcessor = new RootBeanDefinition(InsecureChannelProcessor.class);
/*  698 */     inSecureChannelProcessor.getPropertyValues().addPropertyValue("entryPoint", retryWithHttp);
/*  699 */     channelProcessors.add(secureChannelProcessor);
/*  700 */     channelProcessors.add(inSecureChannelProcessor);
/*  701 */     channelDecisionManager.getPropertyValues().addPropertyValue("channelProcessors", channelProcessors);
/*  702 */     String id = this.pc.getReaderContext().registerWithGeneratedName((BeanDefinition)channelDecisionManager);
/*  703 */     channelFilter.getPropertyValues().addPropertyValue("channelDecisionManager", new RuntimeBeanReference(id));
/*  704 */     this.cpf = (BeanDefinition)channelFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   private ManagedMap<BeanMetadataElement, BeanDefinition> parseInterceptUrlsForChannelSecurity() {
/*  715 */     ManagedMap<BeanMetadataElement, BeanDefinition> channelRequestMap = new ManagedMap();
/*  716 */     for (Element urlElt : this.interceptUrls) {
/*  717 */       String path = urlElt.getAttribute("pattern");
/*  718 */       String method = urlElt.getAttribute("method");
/*  719 */       String matcherRef = urlElt.getAttribute("request-matcher-ref");
/*  720 */       boolean hasMatcherRef = StringUtils.hasText(matcherRef);
/*  721 */       if (!hasMatcherRef && !StringUtils.hasText(path)) {
/*  722 */         this.pc.getReaderContext().error("pattern attribute cannot be empty or null", urlElt);
/*      */       }
/*  724 */       String requiredChannel = urlElt.getAttribute("requires-channel");
/*  725 */       if (StringUtils.hasText(requiredChannel)) {
/*      */         
/*  727 */         BeanMetadataElement matcher = hasMatcherRef ? (BeanMetadataElement)new RuntimeBeanReference(matcherRef) : (BeanMetadataElement)this.matcherType.createMatcher(this.pc, path, method);
/*  728 */         RootBeanDefinition channelAttributes = new RootBeanDefinition(ChannelAttributeFactory.class);
/*  729 */         channelAttributes.getConstructorArgumentValues().addGenericArgumentValue(requiredChannel);
/*  730 */         channelAttributes.setFactoryMethodName("createChannelAttributes");
/*  731 */         channelRequestMap.put(matcher, channelAttributes);
/*      */       } 
/*      */     } 
/*  734 */     return channelRequestMap;
/*      */   }
/*      */   
/*      */   private void createRequestCacheFilter() {
/*  738 */     Element requestCacheElt = DomUtils.getChildElementByTagName(this.httpElt, "request-cache");
/*  739 */     if (requestCacheElt != null) {
/*  740 */       this.requestCache = (BeanReference)new RuntimeBeanReference(requestCacheElt.getAttribute("ref"));
/*      */     } else {
/*      */       BeanDefinitionBuilder requestCacheBldr;
/*      */       
/*  744 */       if (this.sessionPolicy == SessionCreationPolicy.STATELESS) {
/*  745 */         requestCacheBldr = BeanDefinitionBuilder.rootBeanDefinition(NullRequestCache.class);
/*      */       } else {
/*      */         
/*  748 */         requestCacheBldr = BeanDefinitionBuilder.rootBeanDefinition(HttpSessionRequestCache.class);
/*  749 */         requestCacheBldr.addPropertyValue("createSessionAllowed", 
/*  750 */             Boolean.valueOf((this.sessionPolicy == SessionCreationPolicy.IF_REQUIRED)));
/*  751 */         requestCacheBldr.addPropertyValue("portResolver", this.portResolver);
/*  752 */         if (this.csrfFilter != null) {
/*      */           
/*  754 */           BeanDefinitionBuilder requestCacheMatcherBldr = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class);
/*  755 */           requestCacheMatcherBldr.addConstructorArgValue("/**");
/*  756 */           requestCacheMatcherBldr.addConstructorArgValue("GET");
/*  757 */           requestCacheBldr.addPropertyValue("requestMatcher", requestCacheMatcherBldr.getBeanDefinition());
/*      */         } 
/*      */       } 
/*  760 */       AbstractBeanDefinition abstractBeanDefinition = requestCacheBldr.getBeanDefinition();
/*  761 */       String id = this.pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/*  762 */       this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, id));
/*  763 */       this.requestCache = (BeanReference)new RuntimeBeanReference(id);
/*      */     } 
/*  765 */     this.requestCacheAwareFilter = (BeanDefinition)new RootBeanDefinition(RequestCacheAwareFilter.class);
/*  766 */     this.requestCacheAwareFilter.getConstructorArgumentValues().addGenericArgumentValue(this.requestCache);
/*      */   }
/*      */   
/*      */   private void createFilterSecurity(BeanReference authManager) {
/*  770 */     if (StringUtils.hasText(this.httpElt.getAttribute("authorization-manager-ref"))) {
/*  771 */       createAuthorizationFilter();
/*      */       return;
/*      */     } 
/*  774 */     boolean useAuthorizationManager = true;
/*  775 */     if (StringUtils.hasText(this.httpElt.getAttribute("use-authorization-manager"))) {
/*  776 */       useAuthorizationManager = Boolean.parseBoolean(this.httpElt.getAttribute("use-authorization-manager"));
/*      */     }
/*  778 */     if (useAuthorizationManager) {
/*  779 */       createAuthorizationFilter();
/*      */       return;
/*      */     } 
/*  782 */     createFilterSecurityInterceptor(authManager);
/*      */   }
/*      */   
/*      */   private void createAuthorizationFilter() {
/*  786 */     AuthorizationFilterParser authorizationFilterParser = new AuthorizationFilterParser(this.holderStrategyRef);
/*  787 */     BeanDefinition fsiBean = authorizationFilterParser.parse(this.httpElt, this.pc);
/*  788 */     String fsiId = this.pc.getReaderContext().generateBeanName(fsiBean);
/*  789 */     this.pc.registerBeanComponent(new BeanComponentDefinition(fsiBean, fsiId));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  795 */     BeanDefinitionBuilder wipeBldr = BeanDefinitionBuilder.rootBeanDefinition(AuthorizationManagerWebInvocationPrivilegeEvaluator.class).addConstructorArgReference(authorizationFilterParser.getAuthorizationManagerRef());
/*  796 */     if (mvcPresent) {
/*  797 */       wipeBldr.addPropertyValue("requestTransformer", new RootBeanDefinition(HandlerMappingIntrospectorRequestTransformerFactoryBean.class));
/*      */     }
/*      */     
/*  800 */     AbstractBeanDefinition abstractBeanDefinition = wipeBldr.getBeanDefinition();
/*  801 */     this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, this.pc
/*  802 */           .getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition)));
/*  803 */     this.fsi = (BeanReference)new RuntimeBeanReference(fsiId);
/*      */   }
/*      */   
/*      */   private void createFilterSecurityInterceptor(BeanReference authManager) {
/*  807 */     boolean useExpressions = FilterInvocationSecurityMetadataSourceParser.isUseExpressions(this.httpElt);
/*      */     
/*  809 */     RootBeanDefinition securityMds = FilterInvocationSecurityMetadataSourceParser.createSecurityMetadataSource(this.interceptUrls, this.addAllAuth, this.httpElt, this.pc);
/*      */     
/*  811 */     ManagedList<BeanDefinition> voters = new ManagedList(2);
/*  812 */     if (useExpressions) {
/*  813 */       BeanDefinitionBuilder expressionVoter = BeanDefinitionBuilder.rootBeanDefinition(WebExpressionVoter.class);
/*      */ 
/*      */ 
/*      */       
/*  817 */       RuntimeBeanReference expressionHandler = (RuntimeBeanReference)securityMds.getConstructorArgumentValues().getArgumentValue(1, RuntimeBeanReference.class).getValue();
/*  818 */       expressionVoter.addPropertyValue("expressionHandler", expressionHandler);
/*  819 */       voters.add(expressionVoter.getBeanDefinition());
/*      */     } else {
/*      */       
/*  822 */       voters.add(GrantedAuthorityDefaultsParserUtils.registerWithDefaultRolePrefix(this.pc, (Class)RoleVoterBeanFactory.class));
/*      */       
/*  824 */       voters.add(new RootBeanDefinition(AuthenticatedVoter.class));
/*      */     } 
/*  826 */     RootBeanDefinition accessDecisionMgr = new RootBeanDefinition(AffirmativeBased.class);
/*  827 */     accessDecisionMgr.getConstructorArgumentValues().addGenericArgumentValue(voters);
/*  828 */     accessDecisionMgr.setSource(this.pc.extractSource(this.httpElt));
/*      */     
/*  830 */     String accessManagerId = this.httpElt.getAttribute("access-decision-manager-ref");
/*  831 */     if (!StringUtils.hasText(accessManagerId)) {
/*  832 */       accessManagerId = this.pc.getReaderContext().generateBeanName((BeanDefinition)accessDecisionMgr);
/*  833 */       this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)accessDecisionMgr, accessManagerId));
/*      */     } 
/*  835 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(FilterSecurityInterceptor.class);
/*  836 */     builder.addPropertyReference("accessDecisionManager", accessManagerId);
/*  837 */     builder.addPropertyValue("authenticationManager", authManager);
/*  838 */     if ("true".equals(this.httpElt.getAttribute("once-per-request"))) {
/*  839 */       builder.addPropertyValue("observeOncePerRequest", Boolean.TRUE);
/*      */     }
/*  841 */     builder.addPropertyValue("securityMetadataSource", securityMds);
/*  842 */     builder.addPropertyValue("securityContextHolderStrategy", this.holderStrategyRef);
/*  843 */     AbstractBeanDefinition abstractBeanDefinition = builder.getBeanDefinition();
/*  844 */     String fsiId = this.pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/*  845 */     this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, fsiId));
/*      */ 
/*      */     
/*  848 */     RootBeanDefinition rootBeanDefinition1 = new RootBeanDefinition(DefaultWebInvocationPrivilegeEvaluator.class);
/*  849 */     rootBeanDefinition1.getConstructorArgumentValues().addGenericArgumentValue(new RuntimeBeanReference(fsiId));
/*  850 */     this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)rootBeanDefinition1, this.pc
/*  851 */           .getReaderContext().generateBeanName((BeanDefinition)rootBeanDefinition1)));
/*  852 */     this.fsi = (BeanReference)new RuntimeBeanReference(fsiId);
/*      */   }
/*      */   
/*      */   private void createAddHeadersFilter() {
/*  856 */     Element elmt = DomUtils.getChildElementByTagName(this.httpElt, "headers");
/*  857 */     this.addHeadersFilter = (new HeadersBeanDefinitionParser()).parse(elmt, this.pc);
/*      */   }
/*      */   
/*      */   private void createCorsFilter() {
/*  861 */     Element elmt = DomUtils.getChildElementByTagName(this.httpElt, "cors");
/*  862 */     this.corsFilter = (new CorsBeanDefinitionParser()).parse(elmt, this.pc);
/*      */   }
/*      */ 
/*      */   
/*      */   private void createDisableEncodeUrlFilter() {
/*  867 */     if (isDisableUrlRewriting()) {
/*  868 */       this.disableUrlRewriteFilter = (BeanDefinition)new RootBeanDefinition(DisableEncodeUrlFilter.class);
/*      */     }
/*      */   }
/*      */   
/*      */   private void createCsrfFilter(BeanMetadataElement observationRegistry) {
/*  873 */     Element elmt = DomUtils.getChildElementByTagName(this.httpElt, "csrf");
/*  874 */     this.csrfParser = new CsrfBeanDefinitionParser();
/*  875 */     this.csrfParser.setObservationRegistry(observationRegistry);
/*  876 */     this.csrfFilter = this.csrfParser.parse(elmt, this.pc);
/*  877 */     if (this.csrfFilter == null) {
/*  878 */       this.csrfParser = null;
/*      */       return;
/*      */     } 
/*  881 */     this.csrfAuthStrategy = (BeanMetadataElement)this.csrfParser.getCsrfAuthenticationStrategy();
/*  882 */     this.csrfLogoutHandler = (BeanMetadataElement)this.csrfParser.getCsrfLogoutHandler();
/*      */   }
/*      */   
/*      */   private void createWellKnownChangePasswordRedirectFilter() {
/*  886 */     Element element = DomUtils.getChildElementByTagName(this.httpElt, "password-management");
/*  887 */     if (element == null) {
/*      */       return;
/*      */     }
/*  890 */     WellKnownChangePasswordBeanDefinitionParser parser = new WellKnownChangePasswordBeanDefinitionParser();
/*  891 */     this.wellKnownChangePasswordRedirectFilter = parser.parse(element, this.pc);
/*      */   }
/*      */   
/*      */   BeanMetadataElement getCsrfLogoutHandler() {
/*  895 */     return this.csrfLogoutHandler;
/*      */   }
/*      */   
/*      */   BeanReference getSessionStrategy() {
/*  899 */     return this.sessionStrategyRef;
/*      */   }
/*      */   
/*      */   SessionCreationPolicy getSessionCreationPolicy() {
/*  903 */     return this.sessionPolicy;
/*      */   }
/*      */   
/*      */   BeanReference getRequestCache() {
/*  907 */     return this.requestCache;
/*      */   }
/*      */   
/*      */   List<OrderDecorator> getFilters() {
/*  911 */     List<OrderDecorator> filters = new ArrayList<>();
/*  912 */     if (this.forceEagerSessionCreationFilter != null) {
/*  913 */       filters.add(new OrderDecorator((BeanMetadataElement)this.forceEagerSessionCreationFilter, SecurityFilters.FORCE_EAGER_SESSION_FILTER));
/*      */     }
/*      */     
/*  916 */     if (this.disableUrlRewriteFilter != null) {
/*  917 */       filters.add(new OrderDecorator((BeanMetadataElement)this.disableUrlRewriteFilter, SecurityFilters.DISABLE_ENCODE_URL_FILTER));
/*      */     }
/*  919 */     if (this.httpsRedirectFilter != null) {
/*  920 */       filters.add(new OrderDecorator((BeanMetadataElement)this.httpsRedirectFilter, SecurityFilters.HTTPS_REDIRECT_FILTER));
/*      */     }
/*  922 */     if (this.cpf != null) {
/*  923 */       filters.add(new OrderDecorator((BeanMetadataElement)this.cpf, SecurityFilters.CHANNEL_FILTER));
/*      */     }
/*  925 */     if (this.concurrentSessionFilter != null) {
/*  926 */       filters.add(new OrderDecorator((BeanMetadataElement)this.concurrentSessionFilter, SecurityFilters.CONCURRENT_SESSION_FILTER));
/*      */     }
/*  928 */     if (this.webAsyncManagerFilter != null) {
/*  929 */       filters.add(new OrderDecorator((BeanMetadataElement)this.webAsyncManagerFilter, SecurityFilters.WEB_ASYNC_MANAGER_FILTER));
/*      */     }
/*  931 */     filters.add(new OrderDecorator((BeanMetadataElement)this.securityContextPersistenceFilter, SecurityFilters.SECURITY_CONTEXT_FILTER));
/*  932 */     if (this.servApiFilter != null) {
/*  933 */       filters.add(new OrderDecorator((BeanMetadataElement)this.servApiFilter, SecurityFilters.SERVLET_API_SUPPORT_FILTER));
/*      */     }
/*  935 */     if (this.jaasApiFilter != null) {
/*  936 */       filters.add(new OrderDecorator((BeanMetadataElement)this.jaasApiFilter, SecurityFilters.JAAS_API_SUPPORT_FILTER));
/*      */     }
/*  938 */     if (this.sfpf != null) {
/*  939 */       filters.add(new OrderDecorator((BeanMetadataElement)this.sfpf, SecurityFilters.SESSION_MANAGEMENT_FILTER));
/*      */     }
/*  941 */     filters.add(new OrderDecorator((BeanMetadataElement)this.fsi, SecurityFilters.FILTER_SECURITY_INTERCEPTOR));
/*  942 */     if (this.sessionPolicy != SessionCreationPolicy.STATELESS) {
/*  943 */       filters.add(new OrderDecorator((BeanMetadataElement)this.requestCacheAwareFilter, SecurityFilters.REQUEST_CACHE_FILTER));
/*      */     }
/*  945 */     if (this.corsFilter != null) {
/*  946 */       filters.add(new OrderDecorator(this.corsFilter, SecurityFilters.CORS_FILTER));
/*      */     }
/*  948 */     if (this.addHeadersFilter != null) {
/*  949 */       filters.add(new OrderDecorator((BeanMetadataElement)this.addHeadersFilter, SecurityFilters.HEADERS_FILTER));
/*      */     }
/*  951 */     if (this.csrfFilter != null) {
/*  952 */       filters.add(new OrderDecorator((BeanMetadataElement)this.csrfFilter, SecurityFilters.CSRF_FILTER));
/*      */     }
/*  954 */     if (this.wellKnownChangePasswordRedirectFilter != null) {
/*  955 */       filters.add(new OrderDecorator((BeanMetadataElement)this.wellKnownChangePasswordRedirectFilter, SecurityFilters.WELL_KNOWN_CHANGE_PASSWORD_REDIRECT_FILTER));
/*      */     }
/*      */     
/*  958 */     return filters;
/*      */   }
/*      */   
/*      */   private static BeanMetadataElement getObservationRegistry(Element httpElmt) {
/*  962 */     String holderStrategyRef = httpElmt.getAttribute("observation-registry-ref");
/*  963 */     if (StringUtils.hasText(holderStrategyRef)) {
/*  964 */       return (BeanMetadataElement)new RuntimeBeanReference(holderStrategyRef);
/*      */     }
/*  966 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(ObservationRegistryFactory.class).getBeanDefinition();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class HandlerMappingIntrospectorRequestTransformerFactoryBean
/*      */     implements FactoryBean<AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer>, ApplicationContextAware
/*      */   {
/*      */     private ApplicationContext applicationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer getObject() throws Exception {
/*  981 */       AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer requestTransformer = (AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer)this.applicationContext.getBeanProvider(AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer.class).getIfUnique();
/*  982 */       if (requestTransformer != null) {
/*  983 */         return requestTransformer;
/*      */       }
/*      */       
/*  986 */       HandlerMappingIntrospector hmi = (HandlerMappingIntrospector)this.applicationContext.getBeanProvider(HandlerMappingIntrospector.class).getIfAvailable();
/*  987 */       return (hmi != null) ? (AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer)new HandlerMappingIntrospectorRequestTransformer(hmi) : 
/*  988 */         (AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer)new PathPatternRequestTransformer();
/*      */     }
/*      */ 
/*      */     
/*      */     public Class<?> getObjectType() {
/*  993 */       return AuthorizationManagerWebInvocationPrivilegeEvaluator.HttpServletRequestTransformer.class;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  998 */       this.applicationContext = applicationContext;
/*      */     } }
/*      */   
/*      */   static class RoleVoterBeanFactory extends GrantedAuthorityDefaultsParserUtils.AbstractGrantedAuthorityDefaultsBeanFactory {
/*      */     private RoleVoter voter;
/*      */     
/*      */     RoleVoterBeanFactory() {
/* 1005 */       this.voter = new RoleVoter();
/*      */     }
/*      */     
/*      */     public RoleVoter getBean() {
/* 1009 */       this.voter.setRolePrefix(this.rolePrefix);
/* 1010 */       return this.voter;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class SecurityContextHolderAwareRequestFilterBeanFactory
/*      */     extends GrantedAuthorityDefaultsParserUtils.AbstractGrantedAuthorityDefaultsBeanFactory
/*      */   {
/* 1018 */     private SecurityContextHolderAwareRequestFilter filter = new SecurityContextHolderAwareRequestFilter();
/*      */ 
/*      */     
/* 1021 */     private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*      */ 
/*      */     
/*      */     public SecurityContextHolderAwareRequestFilter getBean() {
/* 1025 */       this.filter.setSecurityContextHolderStrategy(this.securityContextHolderStrategy);
/* 1026 */       this.filter.setRolePrefix(this.rolePrefix);
/* 1027 */       return this.filter;
/*      */     }
/*      */     
/*      */     void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 1031 */       this.securityContextHolderStrategy = securityContextHolderStrategy;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class SecurityContextHolderStrategyFactory
/*      */     implements FactoryBean<SecurityContextHolderStrategy>
/*      */   {
/*      */     public SecurityContextHolderStrategy getObject() throws Exception {
/* 1040 */       return SecurityContextHolder.getContextHolderStrategy();
/*      */     }
/*      */ 
/*      */     
/*      */     public Class<?> getObjectType() {
/* 1045 */       return SecurityContextHolderStrategy.class;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class ObservationRegistryFactory
/*      */     implements FactoryBean<ObservationRegistry>
/*      */   {
/*      */     public ObservationRegistry getObject() throws Exception {
/* 1054 */       return ObservationRegistry.NOOP;
/*      */     }
/*      */ 
/*      */     
/*      */     public Class<?> getObjectType() {
/* 1059 */       return ObservationRegistry.class;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\HttpConfigurationBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */