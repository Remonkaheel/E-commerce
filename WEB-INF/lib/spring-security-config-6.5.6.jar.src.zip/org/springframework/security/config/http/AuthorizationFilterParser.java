/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.ObservationAuthorizationManager;
/*     */ import org.springframework.security.web.access.expression.DefaultHttpSecurityExpressionHandler;
/*     */ import org.springframework.security.web.access.expression.WebExpressionAuthorizationManager;
/*     */ import org.springframework.security.web.access.intercept.AuthorizationFilter;
/*     */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*     */ import org.springframework.security.web.access.intercept.RequestMatcherDelegatingAuthorizationManager;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AuthorizationFilterParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ATT_USE_EXPRESSIONS = "use-expressions";
/*     */   private static final String ATT_ACCESS_DECISION_MANAGER_REF = "access-decision-manager-ref";
/*     */   private static final String ATT_OBSERVATION_REGISTRY_REF = "observation-registry-ref";
/*     */   private static final String ATT_HTTP_METHOD = "method";
/*     */   private static final String ATT_PATTERN = "pattern";
/*     */   private static final String ATT_ACCESS = "access";
/*     */   private static final String ATT_SERVLET_PATH = "servlet-path";
/*     */   private static final String ATT_FILTER_ALL_DISPATCHER_TYPES = "filter-all-dispatcher-types";
/*     */   private String authorizationManagerRef;
/*     */   private final BeanMetadataElement securityContextHolderStrategy;
/*     */   
/*     */   AuthorizationFilterParser(BeanMetadataElement securityContextHolderStrategy) {
/*  72 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*  77 */     if (!isUseExpressions(element)) {
/*  78 */       parserContext.getReaderContext()
/*  79 */         .error("AuthorizationManager must be used with `use-expressions=\"true\"; either add `use-authorization-manager=\"false\"` or `use-expressions=`\"false\"` in your `<http>` block", element);
/*     */       
/*  81 */       return null;
/*     */     } 
/*  83 */     if (StringUtils.hasText(element.getAttribute("access-decision-manager-ref"))) {
/*  84 */       parserContext.getReaderContext()
/*  85 */         .error("AuthorizationManager cannot be used in conjunction with `access-decision-manager-ref`; either remove the reference to AccessDecisionManager or add `use-authorization-manager=\"false\"` to your `<http>` block", element);
/*     */       
/*  87 */       return null;
/*     */     } 
/*  89 */     this.authorizationManagerRef = createAuthorizationManager(element, parserContext);
/*  90 */     BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(AuthorizationFilter.class);
/*  91 */     filterBuilder.getRawBeanDefinition().setSource(parserContext.extractSource(element));
/*  92 */     filterBuilder.addConstructorArgReference(this.authorizationManagerRef);
/*  93 */     if ("false".equals(element.getAttribute("filter-all-dispatcher-types"))) {
/*  94 */       filterBuilder.addPropertyValue("shouldFilterAllDispatcherTypes", Boolean.FALSE);
/*     */     }
/*     */ 
/*     */     
/*  98 */     AbstractBeanDefinition abstractBeanDefinition = filterBuilder.addPropertyValue("securityContextHolderStrategy", this.securityContextHolderStrategy).getBeanDefinition();
/*  99 */     String id = element.getAttribute("id");
/* 100 */     if (StringUtils.hasText(id)) {
/* 101 */       parserContext.registerComponent((ComponentDefinition)new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, id));
/* 102 */       parserContext.getRegistry().registerBeanDefinition(id, (BeanDefinition)abstractBeanDefinition);
/*     */     } 
/* 104 */     return (BeanDefinition)abstractBeanDefinition;
/*     */   }
/*     */   
/*     */   String getAuthorizationManagerRef() {
/* 108 */     return this.authorizationManagerRef;
/*     */   }
/*     */   
/*     */   private String createAuthorizationManager(Element element, ParserContext parserContext) {
/* 112 */     XmlReaderContext context = parserContext.getReaderContext();
/* 113 */     String authorizationManagerRef = element.getAttribute("authorization-manager-ref");
/* 114 */     if (StringUtils.hasText(authorizationManagerRef)) {
/* 115 */       return authorizationManagerRef;
/*     */     }
/* 117 */     Element expressionHandlerElt = DomUtils.getChildElementByTagName(element, "expression-handler");
/* 118 */     String expressionHandlerRef = (expressionHandlerElt != null) ? expressionHandlerElt.getAttribute("ref") : null;
/* 119 */     if (expressionHandlerRef == null) {
/* 120 */       expressionHandlerRef = registerDefaultExpressionHandler(parserContext);
/*     */     }
/* 122 */     MatcherType matcherType = MatcherType.fromElementOrMvc(element);
/* 123 */     ManagedMap<BeanMetadataElement, BeanDefinition> matcherToExpression = new ManagedMap();
/* 124 */     List<Element> interceptMessages = DomUtils.getChildElementsByTagName(element, "intercept-url");
/* 125 */     for (Element interceptMessage : interceptMessages) {
/* 126 */       String accessExpression = interceptMessage.getAttribute("access");
/*     */       
/* 128 */       BeanDefinitionBuilder authorizationManager = BeanDefinitionBuilder.rootBeanDefinition(WebExpressionAuthorizationManager.class);
/* 129 */       authorizationManager.addPropertyReference("expressionHandler", expressionHandlerRef);
/* 130 */       authorizationManager.addConstructorArgValue(accessExpression);
/* 131 */       BeanMetadataElement matcher = createMatcher(matcherType, interceptMessage, parserContext);
/* 132 */       matcherToExpression.put(matcher, authorizationManager.getBeanDefinition());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 137 */     BeanDefinitionBuilder mds = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherDelegatingAuthorizationManagerFactory.class).addPropertyValue("requestMatcherMap", matcherToExpression).addPropertyValue("observationRegistry", getObservationRegistry(element));
/* 138 */     return context.registerWithGeneratedName((BeanDefinition)mds.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private BeanMetadataElement createMatcher(MatcherType matcherType, Element urlElt, ParserContext parserContext) {
/* 142 */     String path = urlElt.getAttribute("pattern");
/* 143 */     String matcherRef = urlElt.getAttribute("request-matcher-ref");
/* 144 */     boolean hasMatcherRef = StringUtils.hasText(matcherRef);
/* 145 */     if (!hasMatcherRef && !StringUtils.hasText(path)) {
/* 146 */       parserContext.getReaderContext().error("path attribute cannot be empty or null", urlElt);
/*     */     }
/* 148 */     String method = urlElt.getAttribute("method");
/* 149 */     if (!StringUtils.hasText(method)) {
/* 150 */       method = null;
/*     */     }
/* 152 */     String servletPath = urlElt.getAttribute("servlet-path");
/* 153 */     if (!StringUtils.hasText(servletPath)) {
/* 154 */       servletPath = null;
/*     */     }
/* 156 */     else if (!MatcherType.mvc.equals(matcherType)) {
/* 157 */       parserContext.getReaderContext()
/* 158 */         .error("servlet-path is not applicable for request-matcher: '" + matcherType.name() + "'", urlElt);
/*     */     } 
/*     */     
/* 161 */     return hasMatcherRef ? (BeanMetadataElement)new RuntimeBeanReference(matcherRef) : 
/* 162 */       (BeanMetadataElement)matcherType.createMatcher(parserContext, path, method, servletPath);
/*     */   }
/*     */   
/*     */   String registerDefaultExpressionHandler(ParserContext pc) {
/* 166 */     RootBeanDefinition rootBeanDefinition = GrantedAuthorityDefaultsParserUtils.registerWithDefaultRolePrefix(pc, (Class)DefaultWebSecurityExpressionHandlerBeanFactory.class);
/*     */     
/* 168 */     String expressionHandlerRef = pc.getReaderContext().generateBeanName((BeanDefinition)rootBeanDefinition);
/* 169 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)rootBeanDefinition, expressionHandlerRef));
/* 170 */     return expressionHandlerRef;
/*     */   }
/*     */   
/*     */   boolean isUseExpressions(Element elt) {
/* 174 */     String useExpressions = elt.getAttribute("use-expressions");
/* 175 */     return (!StringUtils.hasText(useExpressions) || "true".equals(useExpressions));
/*     */   }
/*     */   
/*     */   private BeanMetadataElement getObservationRegistry(Element methodSecurityElmt) {
/* 179 */     String holderStrategyRef = methodSecurityElmt.getAttribute("observation-registry-ref");
/* 180 */     if (StringUtils.hasText(holderStrategyRef)) {
/* 181 */       return (BeanMetadataElement)new RuntimeBeanReference(holderStrategyRef);
/*     */     }
/* 183 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(ObservationRegistryFactory.class).getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class RequestMatcherDelegatingAuthorizationManagerFactory
/*     */     implements FactoryBean<AuthorizationManager<HttpServletRequest>>
/*     */   {
/*     */     private Map<RequestMatcher, AuthorizationManager<RequestAuthorizationContext>> beans;
/* 191 */     private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;
/*     */ 
/*     */ 
/*     */     
/*     */     public AuthorizationManager<HttpServletRequest> getObject() throws Exception {
/* 196 */       RequestMatcherDelegatingAuthorizationManager.Builder builder = RequestMatcherDelegatingAuthorizationManager.builder();
/* 197 */       for (Map.Entry<RequestMatcher, AuthorizationManager<RequestAuthorizationContext>> entry : this.beans
/* 198 */         .entrySet()) {
/* 199 */         builder.add(entry.getKey(), entry.getValue());
/*     */       }
/* 201 */       RequestMatcherDelegatingAuthorizationManager requestMatcherDelegatingAuthorizationManager = builder.build();
/* 202 */       if (!this.observationRegistry.isNoop()) {
/* 203 */         return (AuthorizationManager<HttpServletRequest>)new ObservationAuthorizationManager(this.observationRegistry, (AuthorizationManager)requestMatcherDelegatingAuthorizationManager);
/*     */       }
/* 205 */       return (AuthorizationManager<HttpServletRequest>)requestMatcherDelegatingAuthorizationManager;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 210 */       return AuthorizationManager.class;
/*     */     }
/*     */     
/*     */     public void setRequestMatcherMap(Map<RequestMatcher, AuthorizationManager<RequestAuthorizationContext>> beans) {
/* 214 */       this.beans = beans;
/*     */     }
/*     */     
/*     */     public void setObservationRegistry(ObservationRegistry observationRegistry) {
/* 218 */       this.observationRegistry = observationRegistry;
/*     */     }
/*     */   }
/*     */   
/*     */   static class DefaultWebSecurityExpressionHandlerBeanFactory extends GrantedAuthorityDefaultsParserUtils.AbstractGrantedAuthorityDefaultsBeanFactory {
/*     */     private DefaultHttpSecurityExpressionHandler handler;
/*     */     
/*     */     DefaultWebSecurityExpressionHandlerBeanFactory() {
/* 226 */       this.handler = new DefaultHttpSecurityExpressionHandler();
/*     */     }
/*     */     
/*     */     public DefaultHttpSecurityExpressionHandler getBean() {
/* 230 */       if (this.rolePrefix != null) {
/* 231 */         this.handler.setDefaultRolePrefix(this.rolePrefix);
/*     */       }
/* 233 */       return this.handler;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class ObservationRegistryFactory
/*     */     implements FactoryBean<ObservationRegistry>
/*     */   {
/*     */     public ObservationRegistry getObject() throws Exception {
/* 242 */       return ObservationRegistry.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 247 */       return ObservationRegistry.class;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\AuthorizationFilterParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */