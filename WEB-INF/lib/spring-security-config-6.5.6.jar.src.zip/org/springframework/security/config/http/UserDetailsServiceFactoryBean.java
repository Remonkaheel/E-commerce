/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.HierarchicalBeanFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.security.authentication.CachingUserDetailsService;
/*     */ import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UserDetailsByNameServiceWrapper;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserDetailsServiceFactoryBean
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   private ApplicationContext beanFactory;
/*     */   
/*     */   UserDetailsService userDetailsService(String id) {
/*  46 */     if (!StringUtils.hasText(id)) {
/*  47 */       return getUserDetailsService();
/*     */     }
/*  49 */     return (UserDetailsService)this.beanFactory.getBean(id);
/*     */   }
/*     */   
/*     */   UserDetailsService cachingUserDetailsService(String id) {
/*  53 */     if (!StringUtils.hasText(id)) {
/*  54 */       return getUserDetailsService();
/*     */     }
/*     */     
/*  57 */     String cachingId = id + ".caching";
/*  58 */     if (this.beanFactory.containsBeanDefinition(cachingId)) {
/*  59 */       return (UserDetailsService)this.beanFactory.getBean(cachingId);
/*     */     }
/*  61 */     return (UserDetailsService)this.beanFactory.getBean(id);
/*     */   }
/*     */ 
/*     */   
/*     */   AuthenticationUserDetailsService authenticationUserDetailsService(String name) {
/*     */     UserDetailsService uds;
/*  67 */     if (!StringUtils.hasText(name)) {
/*  68 */       Map<String, ?> beans = getBeansOfType(AuthenticationUserDetailsService.class);
/*  69 */       if (!beans.isEmpty()) {
/*  70 */         if (beans.size() > 1) {
/*  71 */           throw new ApplicationContextException("More than one AuthenticationUserDetailsService registered. Please use a specific Id reference.");
/*     */         }
/*     */         
/*  74 */         return (AuthenticationUserDetailsService)beans.values().toArray()[0];
/*     */       } 
/*  76 */       uds = getUserDetailsService();
/*     */     } else {
/*     */       
/*  79 */       Object bean = this.beanFactory.getBean(name);
/*  80 */       if (bean instanceof AuthenticationUserDetailsService) {
/*  81 */         return (AuthenticationUserDetailsService)bean;
/*     */       }
/*  83 */       if (bean instanceof UserDetailsService) {
/*  84 */         uds = cachingUserDetailsService(name);
/*  85 */         if (uds == null) {
/*  86 */           uds = (UserDetailsService)bean;
/*     */         }
/*     */       } else {
/*     */         
/*  90 */         throw new ApplicationContextException("Bean '" + name + "' must be a UserDetailsService or an AuthenticationUserDetailsService");
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     return (AuthenticationUserDetailsService)new UserDetailsByNameServiceWrapper(uds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UserDetailsService getUserDetailsService() {
/* 103 */     Map<String, ?> beans = getBeansOfType(CachingUserDetailsService.class);
/* 104 */     if (beans.isEmpty()) {
/* 105 */       beans = getBeansOfType(UserDetailsService.class);
/*     */     }
/* 107 */     if (beans.isEmpty()) {
/* 108 */       throw new ApplicationContextException("No UserDetailsService registered.");
/*     */     }
/* 110 */     if (beans.size() > 1) {
/* 111 */       throw new ApplicationContextException("More than one UserDetailsService registered. Please use a specific Id reference in <remember-me/> or <x509 /> elements.");
/*     */     }
/*     */     
/* 114 */     return (UserDetailsService)beans.values().toArray()[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext beanFactory) throws BeansException {
/* 119 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   private Map<String, ?> getBeansOfType(Class<?> type) {
/* 123 */     Map<String, ?> beans = this.beanFactory.getBeansOfType(type);
/*     */ 
/*     */     
/* 126 */     BeanFactory parent = this.beanFactory.getParentBeanFactory();
/* 127 */     while (parent != null && beans.isEmpty()) {
/* 128 */       if (parent instanceof ListableBeanFactory) {
/* 129 */         beans = ((ListableBeanFactory)parent).getBeansOfType(type);
/*     */       }
/* 131 */       if (parent instanceof HierarchicalBeanFactory) {
/* 132 */         parent = ((HierarchicalBeanFactory)parent).getParentBeanFactory();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 138 */     return beans;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\UserDetailsServiceFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */