/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum SecurityFilters
/*     */ {
/*  30 */   FIRST(-2147483648),
/*     */   
/*  32 */   DISABLE_ENCODE_URL_FILTER,
/*     */   
/*  34 */   FORCE_EAGER_SESSION_FILTER,
/*     */   
/*  36 */   CHANNEL_FILTER,
/*     */ 
/*     */   
/*  39 */   HTTPS_REDIRECT_FILTER,
/*     */   
/*  41 */   SECURITY_CONTEXT_FILTER,
/*     */   
/*  43 */   CONCURRENT_SESSION_FILTER,
/*     */   
/*  45 */   WEB_ASYNC_MANAGER_FILTER,
/*     */   
/*  47 */   HEADERS_FILTER,
/*     */   
/*  49 */   CORS_FILTER,
/*     */   
/*  51 */   SAML2_LOGOUT_REQUEST_FILTER,
/*     */   
/*  53 */   SAML2_LOGOUT_RESPONSE_FILTER,
/*     */   
/*  55 */   CSRF_FILTER,
/*     */   
/*  57 */   SAML2_LOGOUT_FILTER,
/*     */   
/*  59 */   LOGOUT_FILTER,
/*     */   
/*  61 */   OAUTH2_AUTHORIZATION_REQUEST_FILTER,
/*     */   
/*  63 */   SAML2_AUTHENTICATION_REQUEST_FILTER,
/*     */   
/*  65 */   X509_FILTER,
/*     */   
/*  67 */   PRE_AUTH_FILTER,
/*     */   
/*  69 */   CAS_FILTER,
/*     */   
/*  71 */   OAUTH2_LOGIN_FILTER,
/*     */   
/*  73 */   SAML2_AUTHENTICATION_FILTER,
/*     */   
/*  75 */   FORM_LOGIN_FILTER,
/*     */   
/*  77 */   DEFAULT_RESOURCES_FILTER,
/*     */   
/*  79 */   LOGIN_PAGE_FILTER,
/*     */   
/*  81 */   LOGOUT_PAGE_FILTER,
/*     */   
/*  83 */   DIGEST_AUTH_FILTER,
/*     */   
/*  85 */   BEARER_TOKEN_AUTH_FILTER,
/*     */   
/*  87 */   BASIC_AUTH_FILTER,
/*     */   
/*  89 */   REQUEST_CACHE_FILTER,
/*     */   
/*  91 */   SERVLET_API_SUPPORT_FILTER,
/*     */   
/*  93 */   JAAS_API_SUPPORT_FILTER,
/*     */   
/*  95 */   REMEMBER_ME_FILTER,
/*     */   
/*  97 */   ANONYMOUS_FILTER,
/*     */   
/*  99 */   OAUTH2_AUTHORIZATION_CODE_GRANT_FILTER,
/*     */   
/* 101 */   WELL_KNOWN_CHANGE_PASSWORD_REDIRECT_FILTER,
/*     */   
/* 103 */   SESSION_MANAGEMENT_FILTER,
/*     */   
/* 105 */   EXCEPTION_TRANSLATION_FILTER,
/*     */   
/* 107 */   FILTER_SECURITY_INTERCEPTOR,
/*     */   
/* 109 */   SWITCH_USER_FILTER,
/*     */   
/* 111 */   LAST(2147483647);
/*     */   
/*     */   private static final int INTERVAL = 100;
/*     */   
/*     */   private final int order;
/*     */   
/*     */   SecurityFilters() {
/* 118 */     this.order = ordinal() * 100;
/*     */   }
/*     */   
/*     */   SecurityFilters(int order) {
/* 122 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder() {
/* 126 */     return this.order;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\SecurityFilters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */