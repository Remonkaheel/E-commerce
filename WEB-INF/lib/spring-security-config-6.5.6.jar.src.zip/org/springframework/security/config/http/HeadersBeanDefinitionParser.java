/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.web.header.HeaderWriterFilter;
/*     */ import org.springframework.security.web.header.writers.CacheControlHeadersWriter;
/*     */ import org.springframework.security.web.header.writers.ContentSecurityPolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.CrossOriginEmbedderPolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.CrossOriginOpenerPolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.CrossOriginResourcePolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.FeaturePolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.HpkpHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.HstsHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.PermissionsPolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.StaticHeadersWriter;
/*     */ import org.springframework.security.web.header.writers.XContentTypeOptionsHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
/*     */ import org.springframework.security.web.header.writers.frameoptions.RegExpAllowFromStrategy;
/*     */ import org.springframework.security.web.header.writers.frameoptions.StaticAllowFromStrategy;
/*     */ import org.springframework.security.web.header.writers.frameoptions.WhiteListedAllowFromStrategy;
/*     */ import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeadersBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ATT_DISABLED = "disabled";
/*     */   private static final String ATT_POLICY = "policy";
/*     */   private static final String ATT_STRATEGY = "strategy";
/*     */   private static final String ATT_FROM_PARAMETER = "from-parameter";
/*     */   private static final String ATT_NAME = "name";
/*     */   private static final String ATT_VALUE = "value";
/*     */   private static final String ATT_REF = "ref";
/*     */   private static final String ATT_INCLUDE_SUBDOMAINS = "include-subdomains";
/*     */   private static final String ATT_MAX_AGE_SECONDS = "max-age-seconds";
/*     */   private static final String ATT_REQUEST_MATCHER_REF = "request-matcher-ref";
/*     */   private static final String ATT_PRELOAD = "preload";
/*     */   private static final String ATT_REPORT_ONLY = "report-only";
/*     */   private static final String ATT_REPORT_URI = "report-uri";
/*     */   private static final String ATT_ALGORITHM = "algorithm";
/*     */   private static final String ATT_POLICY_DIRECTIVES = "policy-directives";
/*     */   private static final String ATT_HEADER_VALUE = "header-value";
/*     */   private static final String CACHE_CONTROL_ELEMENT = "cache-control";
/*     */   private static final String HPKP_ELEMENT = "hpkp";
/*     */   private static final String PINS_ELEMENT = "pins";
/*     */   private static final String HSTS_ELEMENT = "hsts";
/*     */   private static final String XSS_ELEMENT = "xss-protection";
/*     */   private static final String CONTENT_TYPE_ELEMENT = "content-type-options";
/*     */   private static final String FRAME_OPTIONS_ELEMENT = "frame-options";
/*     */   private static final String GENERIC_HEADER_ELEMENT = "header";
/*     */   private static final String CONTENT_SECURITY_POLICY_ELEMENT = "content-security-policy";
/*     */   private static final String REFERRER_POLICY_ELEMENT = "referrer-policy";
/*     */   private static final String FEATURE_POLICY_ELEMENT = "feature-policy";
/*     */   private static final String PERMISSIONS_POLICY_ELEMENT = "permissions-policy";
/*     */   private static final String CROSS_ORIGIN_OPENER_POLICY_ELEMENT = "cross-origin-opener-policy";
/*     */   private static final String CROSS_ORIGIN_EMBEDDER_POLICY_ELEMENT = "cross-origin-embedder-policy";
/*     */   private static final String CROSS_ORIGIN_RESOURCE_POLICY_ELEMENT = "cross-origin-resource-policy";
/*     */   private static final String ALLOW_FROM = "ALLOW-FROM";
/*     */   private ManagedList<BeanMetadataElement> headerWriters;
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 138 */     this.headerWriters = new ManagedList();
/* 139 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(HeaderWriterFilter.class);
/* 140 */     boolean disabled = (element != null && "true".equals(resolveAttribute(parserContext, element, "disabled")));
/*     */     
/* 142 */     boolean defaultsDisabled = (element != null && "true".equals(resolveAttribute(parserContext, element, "defaults-disabled")));
/* 143 */     boolean addIfNotPresent = (element == null || (!disabled && !defaultsDisabled));
/* 144 */     parseCacheControlElement(addIfNotPresent, element);
/* 145 */     parseHstsElement(addIfNotPresent, element, parserContext);
/* 146 */     parseXssElement(addIfNotPresent, element, parserContext);
/* 147 */     parseFrameOptionsElement(addIfNotPresent, element, parserContext);
/* 148 */     parseContentTypeOptionsElement(addIfNotPresent, element);
/* 149 */     parseHpkpElement((element == null || !disabled), element, parserContext);
/* 150 */     parseContentSecurityPolicyElement(disabled, element, parserContext);
/* 151 */     parseReferrerPolicyElement(element, parserContext);
/* 152 */     parseFeaturePolicyElement(element, parserContext);
/* 153 */     parsePermissionsPolicyElement(element, parserContext);
/* 154 */     parseCrossOriginOpenerPolicy(disabled, element);
/* 155 */     parseCrossOriginEmbedderPolicy(disabled, element);
/* 156 */     parseCrossOriginResourcePolicy(disabled, element);
/* 157 */     parseHeaderElements(element);
/* 158 */     boolean noWriters = this.headerWriters.isEmpty();
/* 159 */     if (disabled && !noWriters) {
/* 160 */       parserContext.getReaderContext()
/* 161 */         .error("Cannot specify <headers disabled=\"true\"> with child elements.", element);
/*     */     }
/* 163 */     else if (noWriters) {
/* 164 */       return null;
/*     */     } 
/* 166 */     builder.addConstructorArgValue(this.headerWriters);
/* 167 */     return (BeanDefinition)builder.getBeanDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String resolveAttribute(ParserContext pc, Element element, String attributeName) {
/* 178 */     return pc.getReaderContext().getEnvironment().resolvePlaceholders(element.getAttribute(attributeName));
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseCacheControlElement(boolean addIfNotPresent, Element element) {
/* 183 */     Element cacheControlElement = (element != null) ? DomUtils.getChildElementByTagName(element, "cache-control") : null;
/* 184 */     boolean disabled = "true".equals(getAttribute(cacheControlElement, "disabled", "false"));
/* 185 */     if (disabled) {
/*     */       return;
/*     */     }
/* 188 */     if (addIfNotPresent || cacheControlElement != null) {
/* 189 */       addCacheControl();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCacheControl() {
/* 195 */     BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(CacheControlHeadersWriter.class);
/* 196 */     this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private void parseHstsElement(boolean addIfNotPresent, Element element, ParserContext context) {
/* 200 */     Element hstsElement = (element != null) ? DomUtils.getChildElementByTagName(element, "hsts") : null;
/* 201 */     if (addIfNotPresent || hstsElement != null) {
/* 202 */       addHsts(addIfNotPresent, hstsElement, context);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addHsts(boolean addIfNotPresent, Element hstsElement, ParserContext context) {
/* 207 */     BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(HstsHeaderWriter.class);
/* 208 */     if (hstsElement != null) {
/* 209 */       boolean disabled = "true".equals(getAttribute(hstsElement, "disabled", "false"));
/* 210 */       String includeSubDomains = hstsElement.getAttribute("include-subdomains");
/* 211 */       if (StringUtils.hasText(includeSubDomains)) {
/* 212 */         if (disabled) {
/* 213 */           attrNotAllowed(context, "include-subdomains", "disabled", hstsElement);
/*     */         }
/* 215 */         headersWriter.addPropertyValue("includeSubDomains", includeSubDomains);
/*     */       } 
/* 217 */       String maxAgeSeconds = hstsElement.getAttribute("max-age-seconds");
/* 218 */       if (StringUtils.hasText(maxAgeSeconds)) {
/* 219 */         if (disabled) {
/* 220 */           attrNotAllowed(context, "max-age-seconds", "disabled", hstsElement);
/*     */         }
/* 222 */         headersWriter.addPropertyValue("maxAgeInSeconds", maxAgeSeconds);
/*     */       } 
/* 224 */       String requestMatcherRef = hstsElement.getAttribute("request-matcher-ref");
/* 225 */       if (StringUtils.hasText(requestMatcherRef)) {
/* 226 */         if (disabled) {
/* 227 */           attrNotAllowed(context, "request-matcher-ref", "disabled", hstsElement);
/*     */         }
/* 229 */         headersWriter.addPropertyReference("requestMatcher", requestMatcherRef);
/*     */       } 
/* 231 */       String preload = hstsElement.getAttribute("preload");
/* 232 */       if (StringUtils.hasText(preload)) {
/* 233 */         if (disabled) {
/* 234 */           attrNotAllowed(context, "preload", "disabled", hstsElement);
/*     */         }
/* 236 */         headersWriter.addPropertyValue("preload", preload);
/*     */       } 
/* 238 */       if (disabled) {
/*     */         return;
/*     */       }
/*     */     } 
/* 242 */     if (addIfNotPresent || hstsElement != null) {
/* 243 */       this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseHpkpElement(boolean addIfNotPresent, Element element, ParserContext context) {
/* 248 */     Element hpkpElement = (element != null) ? DomUtils.getChildElementByTagName(element, "hpkp") : null;
/* 249 */     if (addIfNotPresent || hpkpElement != null) {
/* 250 */       addHpkp(addIfNotPresent, hpkpElement, context);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addHpkp(boolean addIfNotPresent, Element hpkpElement, ParserContext context) {
/* 255 */     if (hpkpElement != null) {
/* 256 */       boolean disabled = "true".equals(getAttribute(hpkpElement, "disabled", "false"));
/* 257 */       if (disabled) {
/*     */         return;
/*     */       }
/* 260 */       BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(HpkpHeaderWriter.class);
/* 261 */       Element pinsElement = DomUtils.getChildElementByTagName(hpkpElement, "pins");
/* 262 */       if (pinsElement != null) {
/* 263 */         List<Element> pinElements = DomUtils.getChildElements(pinsElement);
/* 264 */         Map<String, String> pins = new LinkedHashMap<>();
/* 265 */         for (Element pinElement : pinElements) {
/* 266 */           String hash = pinElement.getAttribute("algorithm");
/* 267 */           if (!StringUtils.hasText(hash)) {
/* 268 */             hash = "sha256";
/*     */           }
/* 270 */           Node pinValueNode = pinElement.getFirstChild();
/* 271 */           if (pinValueNode == null) {
/* 272 */             context.getReaderContext().warning("Missing value for pin entry.", hpkpElement);
/*     */             continue;
/*     */           } 
/* 275 */           String fingerprint = pinElement.getFirstChild().getTextContent();
/* 276 */           pins.put(fingerprint, hash);
/*     */         } 
/* 278 */         headersWriter.addPropertyValue("pins", pins);
/*     */       } 
/* 280 */       String includeSubDomains = hpkpElement.getAttribute("include-subdomains");
/* 281 */       if (StringUtils.hasText(includeSubDomains)) {
/* 282 */         headersWriter.addPropertyValue("includeSubDomains", includeSubDomains);
/*     */       }
/* 284 */       String maxAgeSeconds = hpkpElement.getAttribute("max-age-seconds");
/* 285 */       if (StringUtils.hasText(maxAgeSeconds)) {
/* 286 */         headersWriter.addPropertyValue("maxAgeInSeconds", maxAgeSeconds);
/*     */       }
/* 288 */       String reportOnly = hpkpElement.getAttribute("report-only");
/* 289 */       if (StringUtils.hasText(reportOnly)) {
/* 290 */         headersWriter.addPropertyValue("reportOnly", reportOnly);
/*     */       }
/* 292 */       String reportUri = hpkpElement.getAttribute("report-uri");
/* 293 */       if (StringUtils.hasText(reportUri)) {
/* 294 */         headersWriter.addPropertyValue("reportUri", reportUri);
/*     */       }
/* 296 */       if (addIfNotPresent) {
/* 297 */         this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseContentSecurityPolicyElement(boolean elementDisabled, Element element, ParserContext context) {
/* 304 */     Element contentSecurityPolicyElement = (elementDisabled || element == null) ? null : DomUtils.getChildElementByTagName(element, "content-security-policy");
/* 305 */     if (contentSecurityPolicyElement != null) {
/* 306 */       addContentSecurityPolicy(contentSecurityPolicyElement, context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addContentSecurityPolicy(Element contentSecurityPolicyElement, ParserContext context) {
/* 312 */     BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(ContentSecurityPolicyHeaderWriter.class);
/* 313 */     String policyDirectives = contentSecurityPolicyElement.getAttribute("policy-directives");
/* 314 */     if (!StringUtils.hasText(policyDirectives)) {
/* 315 */       context.getReaderContext()
/* 316 */         .error("policy-directives requires a 'value' to be set.", contentSecurityPolicyElement);
/*     */     } else {
/*     */       
/* 319 */       headersWriter.addConstructorArgValue(policyDirectives);
/*     */     } 
/* 321 */     String reportOnly = contentSecurityPolicyElement.getAttribute("report-only");
/* 322 */     if (StringUtils.hasText(reportOnly)) {
/* 323 */       headersWriter.addPropertyValue("reportOnly", reportOnly);
/*     */     }
/* 325 */     this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseReferrerPolicyElement(Element element, ParserContext context) {
/* 330 */     Element referrerPolicyElement = (element != null) ? DomUtils.getChildElementByTagName(element, "referrer-policy") : null;
/* 331 */     if (referrerPolicyElement != null) {
/* 332 */       addReferrerPolicy(referrerPolicyElement, context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addReferrerPolicy(Element referrerPolicyElement, ParserContext context) {
/* 338 */     BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(ReferrerPolicyHeaderWriter.class);
/* 339 */     String policy = referrerPolicyElement.getAttribute("policy");
/* 340 */     if (StringUtils.hasLength(policy)) {
/* 341 */       headersWriter.addConstructorArgValue(ReferrerPolicyHeaderWriter.ReferrerPolicy.get(policy));
/*     */     }
/* 343 */     this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseFeaturePolicyElement(Element element, ParserContext context) {
/* 348 */     Element featurePolicyElement = (element != null) ? DomUtils.getChildElementByTagName(element, "feature-policy") : null;
/* 349 */     if (featurePolicyElement != null) {
/* 350 */       addFeaturePolicy(featurePolicyElement, context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addFeaturePolicy(Element featurePolicyElement, ParserContext context) {
/* 356 */     BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(FeaturePolicyHeaderWriter.class);
/* 357 */     String policyDirectives = featurePolicyElement.getAttribute("policy-directives");
/* 358 */     if (!StringUtils.hasText(policyDirectives)) {
/* 359 */       context.getReaderContext()
/* 360 */         .error("policy-directives requires a 'value' to be set.", featurePolicyElement);
/*     */     } else {
/*     */       
/* 363 */       headersWriter.addConstructorArgValue(policyDirectives);
/*     */     } 
/* 365 */     this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */   }
/*     */ 
/*     */   
/*     */   private void parsePermissionsPolicyElement(Element element, ParserContext context) {
/* 370 */     Element permissionsPolicyElement = (element != null) ? DomUtils.getChildElementByTagName(element, "permissions-policy") : null;
/* 371 */     if (permissionsPolicyElement != null) {
/* 372 */       addPermissionsPolicy(permissionsPolicyElement, context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addPermissionsPolicy(Element permissionsPolicyElement, ParserContext context) {
/* 378 */     BeanDefinitionBuilder headersWriter = BeanDefinitionBuilder.genericBeanDefinition(PermissionsPolicyHeaderWriter.class);
/* 379 */     String policyDirectives = permissionsPolicyElement.getAttribute("policy");
/* 380 */     if (!StringUtils.hasText(policyDirectives)) {
/* 381 */       context.getReaderContext().error("policy requires a 'value' to be set.", permissionsPolicyElement);
/*     */     } else {
/*     */       
/* 384 */       headersWriter.addConstructorArgValue(policyDirectives);
/*     */     } 
/* 386 */     this.headerWriters.add(headersWriter.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private void parseCrossOriginOpenerPolicy(boolean elementDisabled, Element element) {
/* 390 */     if (elementDisabled || element == null) {
/*     */       return;
/*     */     }
/* 393 */     CrossOriginOpenerPolicyHeaderWriter writer = new CrossOriginOpenerPolicyHeaderWriter();
/* 394 */     Element crossOriginOpenerPolicyElement = DomUtils.getChildElementByTagName(element, "cross-origin-opener-policy");
/*     */     
/* 396 */     if (crossOriginOpenerPolicyElement != null) {
/* 397 */       addCrossOriginOpenerPolicy(crossOriginOpenerPolicyElement, writer);
/*     */     }
/*     */     
/* 400 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(CrossOriginOpenerPolicyHeaderWriter.class, () -> writer);
/* 401 */     this.headerWriters.add(builder.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private void parseCrossOriginEmbedderPolicy(boolean elementDisabled, Element element) {
/* 405 */     if (elementDisabled || element == null) {
/*     */       return;
/*     */     }
/* 408 */     CrossOriginEmbedderPolicyHeaderWriter writer = new CrossOriginEmbedderPolicyHeaderWriter();
/* 409 */     Element crossOriginEmbedderPolicyElement = DomUtils.getChildElementByTagName(element, "cross-origin-embedder-policy");
/*     */     
/* 411 */     if (crossOriginEmbedderPolicyElement != null) {
/* 412 */       addCrossOriginEmbedderPolicy(crossOriginEmbedderPolicyElement, writer);
/*     */     }
/*     */     
/* 415 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(CrossOriginEmbedderPolicyHeaderWriter.class, () -> writer);
/* 416 */     this.headerWriters.add(builder.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private void parseCrossOriginResourcePolicy(boolean elementDisabled, Element element) {
/* 420 */     if (elementDisabled || element == null) {
/*     */       return;
/*     */     }
/* 423 */     CrossOriginResourcePolicyHeaderWriter writer = new CrossOriginResourcePolicyHeaderWriter();
/* 424 */     Element crossOriginResourcePolicyElement = DomUtils.getChildElementByTagName(element, "cross-origin-resource-policy");
/*     */     
/* 426 */     if (crossOriginResourcePolicyElement != null) {
/* 427 */       addCrossOriginResourcePolicy(crossOriginResourcePolicyElement, writer);
/*     */     }
/*     */     
/* 430 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(CrossOriginResourcePolicyHeaderWriter.class, () -> writer);
/* 431 */     this.headerWriters.add(builder.getBeanDefinition());
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCrossOriginResourcePolicy(Element crossOriginResourcePolicyElement, CrossOriginResourcePolicyHeaderWriter writer) {
/* 436 */     String policy = crossOriginResourcePolicyElement.getAttribute("policy");
/* 437 */     if (StringUtils.hasText(policy)) {
/* 438 */       writer.setPolicy(CrossOriginResourcePolicyHeaderWriter.CrossOriginResourcePolicy.from(policy));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCrossOriginEmbedderPolicy(Element crossOriginEmbedderPolicyElement, CrossOriginEmbedderPolicyHeaderWriter writer) {
/* 444 */     String policy = crossOriginEmbedderPolicyElement.getAttribute("policy");
/* 445 */     if (StringUtils.hasText(policy)) {
/* 446 */       writer.setPolicy(CrossOriginEmbedderPolicyHeaderWriter.CrossOriginEmbedderPolicy.from(policy));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addCrossOriginOpenerPolicy(Element crossOriginOpenerPolicyElement, CrossOriginOpenerPolicyHeaderWriter writer) {
/* 452 */     String policy = crossOriginOpenerPolicyElement.getAttribute("policy");
/* 453 */     if (StringUtils.hasText(policy)) {
/* 454 */       writer.setPolicy(CrossOriginOpenerPolicyHeaderWriter.CrossOriginOpenerPolicy.from(policy));
/*     */     }
/*     */   }
/*     */   
/*     */   private void attrNotAllowed(ParserContext context, String attrName, String otherAttrName, Element element) {
/* 459 */     context.getReaderContext()
/* 460 */       .error("Only one of '" + attrName + "' or '" + otherAttrName + "' can be set.", element);
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseHeaderElements(Element element) {
/* 465 */     List<Element> headerElts = (element != null) ? DomUtils.getChildElementsByTagName(element, "header") : Collections.<Element>emptyList();
/* 466 */     for (Element headerElt : headerElts) {
/* 467 */       String headerFactoryRef = headerElt.getAttribute("ref");
/* 468 */       if (StringUtils.hasText(headerFactoryRef)) {
/* 469 */         this.headerWriters.add(new RuntimeBeanReference(headerFactoryRef));
/*     */         continue;
/*     */       } 
/* 472 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(StaticHeadersWriter.class);
/* 473 */       builder.addConstructorArgValue(headerElt.getAttribute("name"));
/* 474 */       builder.addConstructorArgValue(headerElt.getAttribute("value"));
/* 475 */       this.headerWriters.add(builder.getBeanDefinition());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseContentTypeOptionsElement(boolean addIfNotPresent, Element element) {
/* 482 */     Element contentTypeElt = (element != null) ? DomUtils.getChildElementByTagName(element, "content-type-options") : null;
/* 483 */     boolean disabled = "true".equals(getAttribute(contentTypeElt, "disabled", "false"));
/* 484 */     if (disabled) {
/*     */       return;
/*     */     }
/* 487 */     if (addIfNotPresent || contentTypeElt != null) {
/* 488 */       addContentTypeOptions();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addContentTypeOptions() {
/* 494 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(XContentTypeOptionsHeaderWriter.class);
/* 495 */     this.headerWriters.add(builder.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private void parseFrameOptionsElement(boolean addIfNotPresent, Element element, ParserContext parserContext) {
/* 499 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(XFrameOptionsHeaderWriter.class);
/*     */     
/* 501 */     Element frameElement = (element != null) ? DomUtils.getChildElementByTagName(element, "frame-options") : null;
/* 502 */     if (frameElement == null) {
/* 503 */       if (addIfNotPresent) {
/* 504 */         this.headerWriters.add(builder.getBeanDefinition());
/*     */       }
/*     */       return;
/*     */     } 
/* 508 */     String header = getAttribute(frameElement, "policy", null);
/* 509 */     boolean disabled = "true".equals(getAttribute(frameElement, "disabled", "false"));
/* 510 */     if (disabled && header != null) {
/* 511 */       attrNotAllowed(parserContext, "disabled", "policy", frameElement);
/*     */     }
/* 513 */     header = StringUtils.hasText(header) ? header : "DENY";
/* 514 */     if ("ALLOW-FROM".equals(header)) {
/* 515 */       parseAllowFromFrameOptionsElement(parserContext, builder, frameElement);
/*     */     } else {
/*     */       
/* 518 */       builder.addConstructorArgValue(header);
/*     */     } 
/* 520 */     if (!disabled) {
/* 521 */       this.headerWriters.add(builder.getBeanDefinition());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseAllowFromFrameOptionsElement(ParserContext parserContext, BeanDefinitionBuilder builder, Element frameElement) {
/* 527 */     String strategyRef = getAttribute(frameElement, "ref", null);
/* 528 */     String strategy = getAttribute(frameElement, "strategy", null);
/* 529 */     if (StringUtils.hasText(strategy) && StringUtils.hasText(strategyRef)) {
/* 530 */       parserContext.getReaderContext()
/* 531 */         .error("Only one of 'strategy' or 'strategy-ref' can be set.", frameElement);
/*     */       return;
/*     */     } 
/* 534 */     if (strategyRef != null) {
/* 535 */       builder.addConstructorArgReference(strategyRef);
/*     */       return;
/*     */     } 
/* 538 */     if (strategy == null) {
/* 539 */       parserContext.getReaderContext().error("One of 'strategy' and 'strategy-ref' must be set.", frameElement);
/*     */       return;
/*     */     } 
/* 542 */     String value = getAttribute(frameElement, "value", null);
/* 543 */     if (!StringUtils.hasText(value)) {
/* 544 */       parserContext.getReaderContext().error("Strategy requires a 'value' to be set.", frameElement);
/*     */       
/*     */       return;
/*     */     } 
/* 548 */     if ("static".equals(strategy)) {
/*     */       try {
/* 550 */         builder.addConstructorArgValue(new StaticAllowFromStrategy(new URI(value)));
/*     */       }
/* 552 */       catch (URISyntaxException ex) {
/* 553 */         parserContext.getReaderContext()
/* 554 */           .error("'value' attribute doesn't represent a valid URI.", frameElement, ex);
/*     */       } 
/*     */       return;
/*     */     } 
/* 558 */     BeanDefinitionBuilder allowFromStrategy = getAllowFromStrategy(strategy, value);
/* 559 */     String fromParameter = getAttribute(frameElement, "from-parameter", "from");
/* 560 */     allowFromStrategy.addPropertyValue("allowFromParameterName", fromParameter);
/* 561 */     builder.addConstructorArgValue(allowFromStrategy.getBeanDefinition());
/*     */   }
/*     */   
/*     */   private BeanDefinitionBuilder getAllowFromStrategy(String strategy, String value) {
/* 565 */     if ("whitelist".equals(strategy)) {
/*     */       
/* 567 */       BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.rootBeanDefinition(WhiteListedAllowFromStrategy.class);
/* 568 */       beanDefinitionBuilder.addConstructorArgValue(StringUtils.commaDelimitedListToSet(value));
/* 569 */       return beanDefinitionBuilder;
/*     */     } 
/*     */     
/* 572 */     BeanDefinitionBuilder allowFromStrategy = BeanDefinitionBuilder.rootBeanDefinition(RegExpAllowFromStrategy.class);
/* 573 */     allowFromStrategy.addConstructorArgValue(value);
/* 574 */     return allowFromStrategy;
/*     */   }
/*     */   
/*     */   private void parseXssElement(boolean addIfNotPresent, Element element, ParserContext parserContext) {
/* 578 */     Element xssElt = (element != null) ? DomUtils.getChildElementByTagName(element, "xss-protection") : null;
/* 579 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(XXssProtectionHeaderWriter.class);
/* 580 */     if (xssElt != null) {
/* 581 */       boolean disabled = "true".equals(getAttribute(xssElt, "disabled", "false"));
/*     */       
/* 583 */       XXssProtectionHeaderWriter.HeaderValue headerValue = XXssProtectionHeaderWriter.HeaderValue.from(xssElt.getAttribute("header-value"));
/* 584 */       if (headerValue != null) {
/* 585 */         if (disabled) {
/* 586 */           attrNotAllowed(parserContext, "header-value", "disabled", xssElt);
/*     */         }
/* 588 */         builder.addPropertyValue("headerValue", headerValue);
/*     */       } 
/* 590 */       if (disabled) {
/*     */         return;
/*     */       }
/*     */     } 
/* 594 */     if (addIfNotPresent || xssElt != null) {
/* 595 */       this.headerWriters.add(builder.getBeanDefinition());
/*     */     }
/*     */   }
/*     */   
/*     */   private String getAttribute(Element element, String name, String defaultValue) {
/* 600 */     if (element == null) {
/* 601 */       return defaultValue;
/*     */     }
/* 603 */     String value = element.getAttribute(name);
/* 604 */     if (StringUtils.hasText(value)) {
/* 605 */       return value;
/*     */     }
/* 607 */     return defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\HeadersBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */