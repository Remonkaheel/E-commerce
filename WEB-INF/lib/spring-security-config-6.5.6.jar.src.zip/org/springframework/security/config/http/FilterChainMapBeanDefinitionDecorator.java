/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionDecorator;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterChainMapBeanDefinitionDecorator
/*    */   implements BeanDefinitionDecorator
/*    */ {
/*    */   public BeanDefinitionHolder decorate(Node node, BeanDefinitionHolder holder, ParserContext parserContext) {
/* 47 */     BeanDefinition filterChainProxy = holder.getBeanDefinition();
/* 48 */     ManagedList<BeanMetadataElement> securityFilterChains = new ManagedList();
/* 49 */     Element elt = (Element)node;
/* 50 */     MatcherType matcherType = MatcherType.fromElementOrMvc(elt);
/* 51 */     List<Element> filterChainElts = DomUtils.getChildElementsByTagName(elt, "filter-chain");
/* 52 */     for (Element chain : filterChainElts) {
/* 53 */       String path = chain.getAttribute("pattern");
/* 54 */       String filters = chain.getAttribute("filters");
/* 55 */       if (!StringUtils.hasText(path)) {
/* 56 */         parserContext.getReaderContext()
/* 57 */           .error("The attribute 'pattern' must not be empty", elt);
/*    */       }
/*    */       
/* 60 */       if (!StringUtils.hasText(filters)) {
/* 61 */         parserContext.getReaderContext()
/* 62 */           .error("The attribute 'filters'must not be empty", elt);
/*    */       }
/*    */       
/* 65 */       BeanDefinition matcher = matcherType.createMatcher(parserContext, path, null);
/* 66 */       if (filters.equals("none")) {
/* 67 */         securityFilterChains.add(createSecurityFilterChain(matcher, new ManagedList(0)));
/*    */         continue;
/*    */       } 
/* 70 */       String[] filterBeanNames = StringUtils.tokenizeToStringArray(filters, ",");
/* 71 */       ManagedList<?> filterChain = new ManagedList(filterBeanNames.length);
/* 72 */       for (String name : filterBeanNames) {
/* 73 */         filterChain.add(new RuntimeBeanReference(name));
/*    */       }
/* 75 */       securityFilterChains.add(createSecurityFilterChain(matcher, filterChain));
/*    */     } 
/*    */     
/* 78 */     filterChainProxy.getConstructorArgumentValues().addGenericArgumentValue(securityFilterChains);
/* 79 */     return holder;
/*    */   }
/*    */   
/*    */   private BeanDefinition createSecurityFilterChain(BeanDefinition matcher, ManagedList<?> filters) {
/* 83 */     BeanDefinitionBuilder sfc = BeanDefinitionBuilder.rootBeanDefinition(DefaultSecurityFilterChain.class);
/* 84 */     sfc.addConstructorArgValue(matcher);
/* 85 */     sfc.addConstructorArgValue(filters);
/* 86 */     return (BeanDefinition)sfc.getBeanDefinition();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\FilterChainMapBeanDefinitionDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */