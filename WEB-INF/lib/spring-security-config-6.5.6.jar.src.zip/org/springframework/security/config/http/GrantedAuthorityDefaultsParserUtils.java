/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GrantedAuthorityDefaultsParserUtils
/*    */ {
/*    */   static RootBeanDefinition registerWithDefaultRolePrefix(ParserContext pc, Class<? extends AbstractGrantedAuthorityDefaultsBeanFactory> beanFactoryClass) {
/* 38 */     RootBeanDefinition beanFactoryDefinition = new RootBeanDefinition(beanFactoryClass);
/* 39 */     String beanFactoryRef = pc.getReaderContext().generateBeanName((BeanDefinition)beanFactoryDefinition);
/* 40 */     pc.getRegistry().registerBeanDefinition(beanFactoryRef, (BeanDefinition)beanFactoryDefinition);
/* 41 */     RootBeanDefinition bean = new RootBeanDefinition();
/* 42 */     bean.setFactoryBeanName(beanFactoryRef);
/* 43 */     bean.setFactoryMethodName("getBean");
/* 44 */     return bean;
/*    */   }
/*    */   
/*    */   static abstract class AbstractGrantedAuthorityDefaultsBeanFactory
/*    */     implements ApplicationContextAware {
/* 49 */     protected String rolePrefix = "ROLE_";
/*    */ 
/*    */     
/*    */     public final void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 53 */       applicationContext.getBeanProvider(GrantedAuthorityDefaults.class)
/* 54 */         .ifUnique(grantedAuthorityDefaults -> this.rolePrefix = grantedAuthorityDefaults.getRolePrefix());
/*    */     }
/*    */     
/*    */     abstract Object getBean();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\GrantedAuthorityDefaultsParserUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */