/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ListFactoryBean;
/*     */ import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.security.authentication.AuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
/*     */ import org.springframework.security.authentication.ObservationAuthenticationManager;
/*     */ import org.springframework.security.authentication.ProviderManager;
/*     */ import org.springframework.security.config.authentication.AuthenticationManagerFactoryBean;
/*     */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*     */ import org.springframework.security.web.FilterChainProxy;
/*     */ import org.springframework.security.web.ObservationFilterChainDecorator;
/*     */ import org.springframework.security.web.PortResolverImpl;
/*     */ import org.springframework.security.web.firewall.ObservationMarkingRequestRejectedHandler;
/*     */ import org.springframework.security.web.util.matcher.AnyRequestMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpSecurityBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*  76 */   private static final Log logger = LogFactory.getLog(HttpSecurityBeanDefinitionParser.class);
/*     */ 
/*     */   
/*     */   private static final String ATT_AUTHENTICATION_MANAGER_REF = "authentication-manager-ref";
/*     */ 
/*     */   
/*     */   private static final String ATT_OBSERVATION_REGISTRY_REF = "observation-registry-ref";
/*     */ 
/*     */   
/*     */   static final String ATT_REQUEST_MATCHER_REF = "request-matcher-ref";
/*     */ 
/*     */   
/*     */   static final String ATT_REDIRECT_TO_HTTPS_REQUEST_MATCHER_REF = "redirect-to-https-request-matcher-ref";
/*     */ 
/*     */   
/*     */   static final String ATT_PATH_PATTERN = "pattern";
/*     */ 
/*     */   
/*     */   static final String ATT_HTTP_METHOD = "method";
/*     */ 
/*     */   
/*     */   static final String ATT_FILTERS = "filters";
/*     */ 
/*     */   
/*     */   static final String OPT_FILTERS_NONE = "none";
/*     */ 
/*     */   
/*     */   static final String ATT_REQUIRES_CHANNEL = "requires-channel";
/*     */ 
/*     */   
/*     */   private static final String ATT_REF = "ref";
/*     */ 
/*     */   
/*     */   private static final String ATT_SECURED = "security";
/*     */ 
/*     */   
/*     */   private static final String OPT_SECURITY_NONE = "none";
/*     */ 
/*     */   
/*     */   private static final String ATT_AFTER = "after";
/*     */ 
/*     */   
/*     */   private static final String ATT_BEFORE = "before";
/*     */   
/*     */   private static final String ATT_POSITION = "position";
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/* 124 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), pc.extractSource(element));
/* 125 */     pc.pushContainingComponent(compositeDef);
/* 126 */     registerFilterChainProxyIfNecessary(pc, element);
/*     */     
/* 128 */     BeanDefinition listFactoryBean = pc.getRegistry().getBeanDefinition("org.springframework.security.filterChains");
/*     */ 
/*     */     
/* 131 */     List<BeanReference> filterChains = (List<BeanReference>)listFactoryBean.getPropertyValues().getPropertyValue("sourceList").getValue();
/* 132 */     filterChains.add(createFilterChain(element, pc));
/* 133 */     pc.popAndRegisterContainingComponent();
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanReference createFilterChain(Element element, ParserContext pc) {
/* 141 */     boolean secured = !"none".equals(element.getAttribute("security"));
/* 142 */     if (!secured) {
/* 143 */       validateSecuredFilterChainElement(element, pc);
/* 144 */       for (int i = 0; i < element.getChildNodes().getLength(); i++) {
/* 145 */         if (element.getChildNodes().item(i) instanceof Element) {
/* 146 */           pc.getReaderContext()
/* 147 */             .error("If you are using <http> to define an unsecured pattern, it cannot contain child elements.", pc
/* 148 */               .extractSource(element));
/*     */         }
/*     */       } 
/* 151 */       return createSecurityFilterChainBean(element, pc, Collections.emptyList());
/*     */     } 
/* 153 */     BeanReference portMapper = createPortMapper(element, pc);
/* 154 */     RuntimeBeanReference runtimeBeanReference = createPortResolver(portMapper, pc);
/* 155 */     ManagedList<BeanReference> authenticationProviders = new ManagedList();
/* 156 */     BeanReference authenticationManager = createAuthenticationManager(element, pc, authenticationProviders);
/* 157 */     boolean forceAutoConfig = isDefaultHttpConfig(element);
/* 158 */     BeanMetadataElement observationRegistry = getObservationRegistry(element);
/* 159 */     HttpConfigurationBuilder httpBldr = new HttpConfigurationBuilder(element, forceAutoConfig, pc, portMapper, (BeanReference)runtimeBeanReference, authenticationManager, observationRegistry);
/*     */     
/* 161 */     httpBldr.getSecurityContextRepositoryForAuthenticationFilters();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     AuthenticationConfigBuilder authBldr = new AuthenticationConfigBuilder(element, forceAutoConfig, pc, httpBldr.getSessionCreationPolicy(), httpBldr.getRequestCache(), authenticationManager, httpBldr.getSecurityContextHolderStrategyForAuthenticationFilters(), httpBldr.getSecurityContextRepositoryForAuthenticationFilters(), httpBldr.getSessionStrategy(), portMapper, (BeanReference)runtimeBeanReference, httpBldr.getCsrfLogoutHandler());
/* 167 */     httpBldr.setLogoutHandlers(authBldr.getLogoutHandlers());
/* 168 */     httpBldr.setEntryPoint(authBldr.getEntryPointBean());
/* 169 */     httpBldr.setAccessDeniedHandler(authBldr.getAccessDeniedHandlerBean());
/* 170 */     httpBldr.setCsrfIgnoreRequestMatchers(authBldr.getCsrfIgnoreRequestMatchers());
/* 171 */     authenticationProviders.addAll(authBldr.getProviders());
/* 172 */     List<OrderDecorator> unorderedFilterChain = new ArrayList<>();
/* 173 */     unorderedFilterChain.addAll(httpBldr.getFilters());
/* 174 */     unorderedFilterChain.addAll(authBldr.getFilters());
/* 175 */     unorderedFilterChain.addAll(buildCustomFilterList(element, pc));
/* 176 */     unorderedFilterChain.sort((Comparator<? super OrderDecorator>)new OrderComparator());
/* 177 */     checkFilterChainOrder(unorderedFilterChain, pc, pc.extractSource(element));
/*     */     
/* 179 */     ManagedList<BeanMetadataElement> managedList = new ManagedList();
/* 180 */     for (OrderDecorator od : unorderedFilterChain) {
/* 181 */       managedList.add(od.bean);
/*     */     }
/* 183 */     return createSecurityFilterChainBean(element, pc, (List<?>)managedList);
/*     */   }
/*     */   
/*     */   private void validateSecuredFilterChainElement(Element element, ParserContext pc) {
/* 187 */     if (!StringUtils.hasText(element.getAttribute("pattern")) && 
/* 188 */       !StringUtils.hasText("request-matcher-ref")) {
/* 189 */       String message = "The 'security' attribute must be used in combination with the 'pattern' or 'request-matcher-ref' attributes.";
/*     */       
/* 191 */       pc.getReaderContext().error(message, pc.extractSource(element));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isDefaultHttpConfig(Element httpElt) {
/* 196 */     return (httpElt.getChildNodes().getLength() == 0 && httpElt.getAttributes().getLength() == 0);
/*     */   }
/*     */   
/*     */   private BeanReference createSecurityFilterChainBean(Element element, ParserContext pc, List<?> filterChain) {
/*     */     RootBeanDefinition rootBeanDefinition;
/* 201 */     String requestMatcherRef = element.getAttribute("request-matcher-ref");
/* 202 */     String filterChainPattern = element.getAttribute("pattern");
/* 203 */     if (StringUtils.hasText(requestMatcherRef)) {
/* 204 */       if (StringUtils.hasText(filterChainPattern)) {
/* 205 */         pc.getReaderContext()
/* 206 */           .error("You can't define a pattern and a request-matcher-ref for the same filter chain", pc
/* 207 */             .extractSource(element));
/*     */       }
/* 209 */       RuntimeBeanReference runtimeBeanReference = new RuntimeBeanReference(requestMatcherRef);
/*     */     
/*     */     }
/* 212 */     else if (StringUtils.hasText(filterChainPattern)) {
/* 213 */       BeanDefinition beanDefinition = MatcherType.fromElementOrMvc(element).createMatcher(pc, filterChainPattern, null);
/*     */     } else {
/*     */       
/* 216 */       rootBeanDefinition = new RootBeanDefinition(AnyRequestMatcher.class);
/*     */     } 
/*     */     
/* 219 */     BeanDefinitionBuilder filterChainBldr = BeanDefinitionBuilder.rootBeanDefinition(DefaultSecurityFilterChain.class);
/* 220 */     filterChainBldr.addConstructorArgValue(rootBeanDefinition);
/* 221 */     filterChainBldr.addConstructorArgValue(filterChain);
/* 222 */     AbstractBeanDefinition abstractBeanDefinition = filterChainBldr.getBeanDefinition();
/* 223 */     String id = element.getAttribute("name");
/* 224 */     if (!StringUtils.hasText(id)) {
/* 225 */       id = element.getAttribute("id");
/* 226 */       if (!StringUtils.hasText(id)) {
/* 227 */         id = pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/*     */       }
/*     */     } 
/* 230 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, id));
/* 231 */     return (BeanReference)new RuntimeBeanReference(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanReference createPortMapper(Element elt, ParserContext pc) {
/* 238 */     BeanDefinition portMapper = (new PortMappingsBeanDefinitionParser()).parse(DomUtils.getChildElementByTagName(elt, "port-mappings"), pc);
/* 239 */     String portMapperName = pc.getReaderContext().generateBeanName(portMapper);
/* 240 */     pc.registerBeanComponent(new BeanComponentDefinition(portMapper, portMapperName));
/* 241 */     return (BeanReference)new RuntimeBeanReference(portMapperName);
/*     */   }
/*     */   
/*     */   private RuntimeBeanReference createPortResolver(BeanReference portMapper, ParserContext pc) {
/* 245 */     String beanName = "portResolver";
/* 246 */     if (pc.getRegistry().containsBeanDefinition(beanName)) {
/* 247 */       return new RuntimeBeanReference(beanName);
/*     */     }
/* 249 */     RootBeanDefinition portResolver = new RootBeanDefinition(PortResolverImpl.class);
/* 250 */     portResolver.getPropertyValues().addPropertyValue("portMapper", portMapper);
/* 251 */     String portResolverName = pc.getReaderContext().generateBeanName((BeanDefinition)portResolver);
/* 252 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)portResolver, portResolverName));
/* 253 */     return new RuntimeBeanReference(portResolverName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanReference createAuthenticationManager(Element element, ParserContext pc, ManagedList<BeanReference> authenticationProviders) {
/* 266 */     String parentMgrRef = element.getAttribute("authentication-manager-ref");
/*     */     
/* 268 */     BeanDefinitionBuilder authManager = BeanDefinitionBuilder.rootBeanDefinition(ChildAuthenticationManagerFactoryBean.class);
/* 269 */     authManager.addConstructorArgValue(authenticationProviders);
/* 270 */     if (StringUtils.hasText(parentMgrRef)) {
/* 271 */       RuntimeBeanReference parentAuthManager = new RuntimeBeanReference(parentMgrRef);
/* 272 */       authManager.addConstructorArgValue(parentAuthManager);
/* 273 */       RootBeanDefinition clearCredentials = new RootBeanDefinition(ClearCredentialsMethodInvokingFactoryBean.class);
/*     */       
/* 275 */       clearCredentials.getPropertyValues().addPropertyValue("targetObject", parentAuthManager);
/* 276 */       clearCredentials.getPropertyValues()
/* 277 */         .addPropertyValue("targetMethod", "isEraseCredentialsAfterAuthentication");
/* 278 */       authManager.addPropertyValue("eraseCredentialsAfterAuthentication", clearCredentials);
/*     */     } else {
/*     */       
/* 281 */       RootBeanDefinition amfb = new RootBeanDefinition(AuthenticationManagerFactoryBean.class);
/* 282 */       amfb.setRole(2);
/* 283 */       String amfbId = pc.getReaderContext().generateBeanName((BeanDefinition)amfb);
/* 284 */       pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)amfb, amfbId));
/* 285 */       RootBeanDefinition clearCredentials = new RootBeanDefinition(MethodInvokingFactoryBean.class);
/* 286 */       clearCredentials.getPropertyValues().addPropertyValue("targetObject", new RuntimeBeanReference(amfbId));
/* 287 */       clearCredentials.getPropertyValues()
/* 288 */         .addPropertyValue("targetMethod", "isEraseCredentialsAfterAuthentication");
/* 289 */       authManager.addConstructorArgValue(new RuntimeBeanReference(amfbId));
/* 290 */       authManager.addPropertyValue("eraseCredentialsAfterAuthentication", clearCredentials);
/*     */     } 
/*     */     
/* 293 */     authManager.addPropertyValue("authenticationEventPublisher", new RootBeanDefinition(DefaultAuthenticationEventPublisher.class));
/*     */     
/* 295 */     authManager.addPropertyValue("observationRegistry", getObservationRegistry(element));
/* 296 */     authManager.getRawBeanDefinition().setSource(pc.extractSource(element));
/* 297 */     AbstractBeanDefinition abstractBeanDefinition = authManager.getBeanDefinition();
/* 298 */     String id = pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/* 299 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, id));
/* 300 */     return (BeanReference)new RuntimeBeanReference(id);
/*     */   }
/*     */   
/*     */   private void checkFilterChainOrder(List<OrderDecorator> filters, ParserContext pc, Object source) {
/* 304 */     logger.info("Checking sorted filter chain: " + String.valueOf(filters));
/* 305 */     for (int i = 0; i < filters.size(); i++) {
/* 306 */       OrderDecorator filter = filters.get(i);
/* 307 */       if (i > 0) {
/* 308 */         OrderDecorator previous = filters.get(i - 1);
/* 309 */         if (filter.getOrder() == previous.getOrder()) {
/* 310 */           pc.getReaderContext()
/* 311 */             .error("Filter beans '" + String.valueOf(filter.bean) + "' and '" + String.valueOf(previous.bean) + "' have the same 'order' value. When using custom filters, please make sure the positions do not conflict with default filters. Alternatively you can disable the default filters by removing the corresponding child elements from <http> and avoiding the use of <http auto-config='true'>.", source);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<OrderDecorator> buildCustomFilterList(Element element, ParserContext pc) {
/* 323 */     List<Element> customFilterElts = DomUtils.getChildElementsByTagName(element, "custom-filter");
/* 324 */     List<OrderDecorator> customFilters = new ArrayList<>();
/* 325 */     for (Element elt : customFilterElts) {
/* 326 */       String after = elt.getAttribute("after");
/* 327 */       String before = elt.getAttribute("before");
/* 328 */       String position = elt.getAttribute("position");
/* 329 */       String ref = elt.getAttribute("ref");
/* 330 */       if (!StringUtils.hasText(ref)) {
/* 331 */         pc.getReaderContext().error("The 'ref' attribute must be supplied", pc.extractSource(elt));
/*     */       }
/* 333 */       RuntimeBeanReference bean = new RuntimeBeanReference(ref);
/* 334 */       if (WebConfigUtils.countNonEmpty(new String[] { after, before, position }) != 1) {
/* 335 */         pc.getReaderContext()
/* 336 */           .error("A single 'after', 'before', or 'position' attribute must be supplied", pc
/* 337 */             .extractSource(elt));
/*     */       }
/* 339 */       if (StringUtils.hasText(position)) {
/* 340 */         customFilters.add(new OrderDecorator((BeanMetadataElement)bean, SecurityFilters.valueOf(position))); continue;
/*     */       } 
/* 342 */       if (StringUtils.hasText(after)) {
/* 343 */         SecurityFilters order = SecurityFilters.valueOf(after);
/* 344 */         if (order == SecurityFilters.LAST) {
/* 345 */           customFilters.add(new OrderDecorator((BeanMetadataElement)bean, SecurityFilters.LAST));
/*     */           continue;
/*     */         } 
/* 348 */         customFilters.add(new OrderDecorator((BeanMetadataElement)bean, order.getOrder() + 1));
/*     */         continue;
/*     */       } 
/* 351 */       if (StringUtils.hasText(before)) {
/* 352 */         SecurityFilters order = SecurityFilters.valueOf(before);
/* 353 */         if (order == SecurityFilters.FIRST) {
/* 354 */           customFilters.add(new OrderDecorator((BeanMetadataElement)bean, SecurityFilters.FIRST));
/*     */           continue;
/*     */         } 
/* 357 */         customFilters.add(new OrderDecorator((BeanMetadataElement)bean, order.getOrder() - 1));
/*     */       } 
/*     */     } 
/*     */     
/* 361 */     return customFilters;
/*     */   }
/*     */   
/*     */   static void registerFilterChainProxyIfNecessary(ParserContext pc, Element element) {
/* 365 */     Object source = pc.extractSource(element);
/* 366 */     BeanDefinitionRegistry registry = pc.getRegistry();
/* 367 */     if (registry.containsBeanDefinition("org.springframework.security.filterChainProxy")) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 372 */     RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(ListFactoryBean.class);
/* 373 */     rootBeanDefinition.getPropertyValues().add("sourceList", new ManagedList());
/* 374 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)rootBeanDefinition, "org.springframework.security.filterChains"));
/* 375 */     BeanDefinitionBuilder fcpBldr = BeanDefinitionBuilder.rootBeanDefinition(FilterChainProxy.class);
/* 376 */     fcpBldr.getRawBeanDefinition().setSource(source);
/* 377 */     fcpBldr.addConstructorArgReference("org.springframework.security.filterChains");
/* 378 */     fcpBldr.addPropertyValue("filterChainValidator", new RootBeanDefinition(DefaultFilterChainValidator.class));
/*     */ 
/*     */ 
/*     */     
/* 382 */     AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(FilterChainDecoratorFactory.class).addPropertyValue("observationRegistry", getObservationRegistry(element)).getBeanDefinition();
/* 383 */     fcpBldr.addPropertyValue("filterChainDecorator", abstractBeanDefinition1);
/* 384 */     AbstractBeanDefinition abstractBeanDefinition2 = fcpBldr.getBeanDefinition();
/* 385 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition2, "org.springframework.security.filterChainProxy"));
/* 386 */     registry.registerAlias("org.springframework.security.filterChainProxy", "springSecurityFilterChain");
/*     */     
/* 388 */     BeanDefinitionBuilder requestRejected = BeanDefinitionBuilder.rootBeanDefinition(RequestRejectedHandlerPostProcessor.class);
/* 389 */     requestRejected.setRole(2);
/* 390 */     requestRejected.addConstructorArgValue("requestRejectedHandler");
/* 391 */     requestRejected.addConstructorArgValue("org.springframework.security.filterChainProxy");
/* 392 */     requestRejected.addConstructorArgValue("requestRejectedHandler");
/* 393 */     requestRejected.addPropertyValue("observationRegistry", getObservationRegistry(element));
/* 394 */     AbstractBeanDefinition requestRejectedBean = requestRejected.getBeanDefinition();
/* 395 */     String requestRejectedPostProcessorName = pc.getReaderContext().generateBeanName((BeanDefinition)requestRejectedBean);
/* 396 */     registry.registerBeanDefinition(requestRejectedPostProcessorName, (BeanDefinition)requestRejectedBean);
/*     */   }
/*     */   
/*     */   private static BeanMetadataElement getObservationRegistry(Element methodSecurityElmt) {
/* 400 */     String holderStrategyRef = methodSecurityElmt.getAttribute("observation-registry-ref");
/* 401 */     if (StringUtils.hasText(holderStrategyRef)) {
/* 402 */       return (BeanMetadataElement)new RuntimeBeanReference(holderStrategyRef);
/*     */     }
/* 404 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(ObservationRegistryFactory.class).getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class RequestRejectedHandlerPostProcessor
/*     */     implements BeanDefinitionRegistryPostProcessor
/*     */   {
/*     */     private final String beanName;
/*     */     
/*     */     private final String targetBeanName;
/*     */     private final String targetPropertyName;
/* 415 */     private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;
/*     */     
/*     */     RequestRejectedHandlerPostProcessor(String beanName, String targetBeanName, String targetPropertyName) {
/* 418 */       this.beanName = beanName;
/* 419 */       this.targetBeanName = targetBeanName;
/* 420 */       this.targetPropertyName = targetPropertyName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 425 */       if (registry.containsBeanDefinition(this.beanName)) {
/* 426 */         BeanDefinition beanDefinition = registry.getBeanDefinition(this.targetBeanName);
/* 427 */         beanDefinition.getPropertyValues()
/* 428 */           .add(this.targetPropertyName, new RuntimeBeanReference(this.beanName));
/*     */       }
/* 430 */       else if (!this.observationRegistry.isNoop()) {
/*     */ 
/*     */ 
/*     */         
/* 434 */         AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(ObservationMarkingRequestRejectedHandler.class).addConstructorArgValue(this.observationRegistry).getBeanDefinition();
/* 435 */         BeanDefinition beanDefinition = registry.getBeanDefinition(this.targetBeanName);
/* 436 */         beanDefinition.getPropertyValues().add(this.targetPropertyName, abstractBeanDefinition);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */     
/*     */     public void setObservationRegistry(ObservationRegistry registry) {
/* 446 */       this.observationRegistry = registry;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ClearCredentialsMethodInvokingFactoryBean
/*     */     extends MethodInvokingFactoryBean
/*     */   {
/*     */     public void afterPropertiesSet() throws Exception {
/* 464 */       boolean isTargetProviderManager = getTargetObject() instanceof ProviderManager;
/* 465 */       if (!isTargetProviderManager) {
/* 466 */         setTargetObject(this);
/*     */       }
/* 468 */       super.afterPropertiesSet();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isEraseCredentialsAfterAuthentication() {
/* 482 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class ChildAuthenticationManagerFactoryBean
/*     */     implements FactoryBean<AuthenticationManager>
/*     */   {
/*     */     private final ProviderManager delegate;
/* 491 */     private AuthenticationEventPublisher authenticationEventPublisher = (AuthenticationEventPublisher)new DefaultAuthenticationEventPublisher();
/*     */     
/*     */     private boolean eraseCredentialsAfterAuthentication = true;
/*     */     
/* 495 */     private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;
/*     */ 
/*     */     
/*     */     public ChildAuthenticationManagerFactoryBean(List<AuthenticationProvider> providers, AuthenticationManager parent) {
/* 499 */       this.delegate = new ProviderManager(providers, parent);
/*     */     }
/*     */ 
/*     */     
/*     */     public AuthenticationManager getObject() throws Exception {
/* 504 */       this.delegate.setAuthenticationEventPublisher(this.authenticationEventPublisher);
/* 505 */       this.delegate.setEraseCredentialsAfterAuthentication(this.eraseCredentialsAfterAuthentication);
/* 506 */       if (!this.observationRegistry.isNoop()) {
/* 507 */         return (AuthenticationManager)new ObservationAuthenticationManager(this.observationRegistry, (AuthenticationManager)this.delegate);
/*     */       }
/* 509 */       return (AuthenticationManager)this.delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 514 */       return AuthenticationManager.class;
/*     */     }
/*     */     
/*     */     public void setEraseCredentialsAfterAuthentication(boolean eraseCredentialsAfterAuthentication) {
/* 518 */       this.eraseCredentialsAfterAuthentication = eraseCredentialsAfterAuthentication;
/*     */     }
/*     */     
/*     */     public void setAuthenticationEventPublisher(AuthenticationEventPublisher authenticationEventPublisher) {
/* 522 */       this.authenticationEventPublisher = authenticationEventPublisher;
/*     */     }
/*     */     
/*     */     public void setObservationRegistry(ObservationRegistry observationRegistry) {
/* 526 */       this.observationRegistry = observationRegistry;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class ObservationRegistryFactory
/*     */     implements FactoryBean<ObservationRegistry>
/*     */   {
/*     */     public ObservationRegistry getObject() throws Exception {
/* 535 */       return ObservationRegistry.NOOP;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 540 */       return ObservationRegistry.class;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class FilterChainDecoratorFactory implements FactoryBean<FilterChainProxy.FilterChainDecorator> {
/*     */     private ObservationRegistry observationRegistry;
/*     */     
/*     */     public FilterChainDecoratorFactory() {
/* 548 */       this.observationRegistry = ObservationRegistry.NOOP;
/*     */     }
/*     */     
/*     */     public FilterChainProxy.FilterChainDecorator getObject() throws Exception {
/* 552 */       if (this.observationRegistry.isNoop()) {
/* 553 */         return (FilterChainProxy.FilterChainDecorator)new FilterChainProxy.VirtualFilterChainDecorator();
/*     */       }
/* 555 */       return (FilterChainProxy.FilterChainDecorator)new ObservationFilterChainDecorator(this.observationRegistry);
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 560 */       return FilterChainProxy.FilterChainDecorator.class;
/*     */     }
/*     */     
/*     */     public void setObservationRegistry(ObservationRegistry registry) {
/* 564 */       this.observationRegistry = registry;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\HttpSecurityBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */