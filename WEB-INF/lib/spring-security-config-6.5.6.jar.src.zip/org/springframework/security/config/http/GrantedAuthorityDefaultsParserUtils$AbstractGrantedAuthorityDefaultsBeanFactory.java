/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractGrantedAuthorityDefaultsBeanFactory
/*    */   implements ApplicationContextAware
/*    */ {
/* 49 */   protected String rolePrefix = "ROLE_";
/*    */ 
/*    */   
/*    */   public final void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 53 */     applicationContext.getBeanProvider(GrantedAuthorityDefaults.class)
/* 54 */       .ifUnique(grantedAuthorityDefaults -> this.rolePrefix = grantedAuthorityDefaults.getRolePrefix());
/*    */   }
/*    */   
/*    */   abstract Object getBean();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\GrantedAuthorityDefaultsParserUtils$AbstractGrantedAuthorityDefaultsBeanFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */