/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.beans.factory.BeanCreationException;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.filter.CorsFilter;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CorsBeanDefinitionParser
/*    */ {
/*    */   private static final String ATT_SOURCE = "configuration-source-ref";
/*    */   private static final String ATT_REF = "ref";
/*    */   private static final String HANDLER_MAPPING_INTROSPECTOR = "org.springframework.web.servlet.handler.HandlerMappingIntrospector";
/* 48 */   private static final boolean mvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.handler.HandlerMappingIntrospector", CorsBeanDefinitionParser.class
/* 49 */       .getClassLoader());
/*    */ 
/*    */   
/*    */   public BeanMetadataElement parse(Element element, ParserContext parserContext) {
/* 53 */     if (element == null) {
/* 54 */       return null;
/*    */     }
/* 56 */     String filterRef = element.getAttribute("ref");
/* 57 */     if (StringUtils.hasText(filterRef)) {
/* 58 */       return (BeanMetadataElement)new RuntimeBeanReference(filterRef);
/*    */     }
/* 60 */     BeanMetadataElement configurationSource = getSource(element, parserContext);
/* 61 */     if (configurationSource == null) {
/* 62 */       throw new BeanCreationException("Could not create CorsFilter");
/*    */     }
/* 64 */     BeanDefinitionBuilder filterBldr = BeanDefinitionBuilder.rootBeanDefinition(CorsFilter.class);
/* 65 */     filterBldr.addConstructorArgValue(configurationSource);
/* 66 */     return (BeanMetadataElement)filterBldr.getBeanDefinition();
/*    */   }
/*    */   
/*    */   public BeanMetadataElement getSource(Element element, ParserContext parserContext) {
/* 70 */     String configurationSourceRef = element.getAttribute("configuration-source-ref");
/* 71 */     if (StringUtils.hasText(configurationSourceRef)) {
/* 72 */       return (BeanMetadataElement)new RuntimeBeanReference(configurationSourceRef);
/*    */     }
/* 74 */     if (!mvcPresent) {
/* 75 */       return null;
/*    */     }
/* 77 */     return (BeanMetadataElement)new RootBeanDefinition(HandlerMappingIntrospectorFactoryBean.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\CorsBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */