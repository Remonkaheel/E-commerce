/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.messaging.simp.SimpMessageType;
/*    */ import org.springframework.security.messaging.util.matcher.MessageMatcher;
/*    */ import org.springframework.security.messaging.util.matcher.PathPatternMessageMatcher;
/*    */ import org.springframework.security.messaging.util.matcher.SimpDestinationMessageMatcher;
/*    */ import org.springframework.util.AntPathMatcher;
/*    */ import org.springframework.util.PathMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class MessageMatcherFactoryBean
/*    */   implements FactoryBean<MessageMatcher<?>>, ApplicationContextAware
/*    */ {
/*    */   private PathPatternMessageMatcher.Builder builder;
/*    */   private final SimpMessageType method;
/*    */   private final String path;
/* 39 */   private PathMatcher pathMatcher = (PathMatcher)new AntPathMatcher();
/*    */   
/*    */   public MessageMatcherFactoryBean(String path) {
/* 42 */     this(path, null);
/*    */   }
/*    */   
/*    */   public MessageMatcherFactoryBean(String path, SimpMessageType method) {
/* 46 */     this.method = method;
/* 47 */     this.path = path;
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageMatcher<?> getObject() throws Exception {
/* 52 */     if (this.builder != null) {
/* 53 */       return (MessageMatcher<?>)this.builder.matcher(this.method, this.path);
/*    */     }
/* 55 */     if (this.method == SimpMessageType.SUBSCRIBE) {
/* 56 */       return (MessageMatcher<?>)SimpDestinationMessageMatcher.createSubscribeMatcher(this.path, this.pathMatcher);
/*    */     }
/* 58 */     if (this.method == SimpMessageType.MESSAGE) {
/* 59 */       return (MessageMatcher<?>)SimpDestinationMessageMatcher.createMessageMatcher(this.path, this.pathMatcher);
/*    */     }
/* 61 */     return (MessageMatcher<?>)new SimpDestinationMessageMatcher(this.path, this.pathMatcher);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 66 */     return null;
/*    */   }
/*    */   
/*    */   public void setPathMatcher(PathMatcher pathMatcher) {
/* 70 */     this.pathMatcher = pathMatcher;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setApplicationContext(ApplicationContext context) throws BeansException {
/* 75 */     this.builder = (PathPatternMessageMatcher.Builder)context.getBeanProvider(PathPatternMessageMatcher.Builder.class).getIfUnique();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\MessageMatcherFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */