/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.opensaml.core.Version;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.security.saml2.provider.service.authentication.OpenSaml4AuthenticationProvider;
/*     */ import org.springframework.security.saml2.provider.service.authentication.OpenSaml5AuthenticationProvider;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.DefaultRelyingPartyRegistrationResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.HttpSessionSaml2AuthenticationRequestRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.Saml2AuthenticationTokenConverter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.OpenSaml4AuthenticationRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.OpenSaml5AuthenticationRequestResolver;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Saml2LoginBeanDefinitionParserUtils
/*     */ {
/*  43 */   private static final boolean USE_OPENSAML_5 = Version.getVersion().startsWith("5");
/*     */ 
/*     */   
/*     */   private static final String ATT_RELYING_PARTY_REGISTRATION_REPOSITORY_REF = "relying-party-registration-repository-ref";
/*     */ 
/*     */   
/*     */   private static final String ATT_AUTHENTICATION_REQUEST_REPOSITORY_REF = "authentication-request-repository-ref";
/*     */ 
/*     */   
/*     */   private static final String ATT_AUTHENTICATION_REQUEST_RESOLVER_REF = "authentication-request-resolver-ref";
/*     */   
/*     */   private static final String ATT_AUTHENTICATION_CONVERTER = "authentication-converter-ref";
/*     */ 
/*     */   
/*     */   static BeanMetadataElement getRelyingPartyRegistrationRepository(Element element) {
/*  58 */     String relyingPartyRegistrationRepositoryRef = element.getAttribute("relying-party-registration-repository-ref");
/*  59 */     if (StringUtils.hasText(relyingPartyRegistrationRepositoryRef)) {
/*  60 */       return (BeanMetadataElement)new RuntimeBeanReference(relyingPartyRegistrationRepositoryRef);
/*     */     }
/*  62 */     return (BeanMetadataElement)new RuntimeBeanReference(RelyingPartyRegistrationRepository.class);
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getAuthenticationRequestRepository(Element element) {
/*  66 */     String authenticationRequestRepositoryRef = element.getAttribute("authentication-request-repository-ref");
/*  67 */     if (StringUtils.hasText(authenticationRequestRepositoryRef)) {
/*  68 */       return (BeanMetadataElement)new RuntimeBeanReference(authenticationRequestRepositoryRef);
/*     */     }
/*  70 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(HttpSessionSaml2AuthenticationRequestRepository.class)
/*  71 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getAuthenticationRequestResolver(Element element) {
/*  75 */     String authenticationRequestContextResolver = element.getAttribute("authentication-request-resolver-ref");
/*  76 */     if (StringUtils.hasText(authenticationRequestContextResolver)) {
/*  77 */       return (BeanMetadataElement)new RuntimeBeanReference(authenticationRequestContextResolver);
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BeanMetadataElement createDefaultAuthenticationRequestResolver(BeanMetadataElement relyingPartyRegistrationRepository) {
/*  87 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(DefaultRelyingPartyRegistrationResolver.class).addConstructorArgValue(relyingPartyRegistrationRepository).getBeanDefinition();
/*  88 */     if (USE_OPENSAML_5) {
/*  89 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml5AuthenticationRequestResolver.class)
/*  90 */         .addConstructorArgValue(abstractBeanDefinition)
/*  91 */         .getBeanDefinition();
/*     */     }
/*  93 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml4AuthenticationRequestResolver.class)
/*  94 */       .addConstructorArgValue(abstractBeanDefinition)
/*  95 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanDefinition createAuthenticationProvider() {
/*  99 */     if (USE_OPENSAML_5) {
/* 100 */       return (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml5AuthenticationProvider.class).getBeanDefinition();
/*     */     }
/* 102 */     return (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml4AuthenticationProvider.class).getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getAuthenticationConverter(Element element) {
/* 106 */     String authenticationConverter = element.getAttribute("authentication-converter-ref");
/* 107 */     if (StringUtils.hasText(authenticationConverter)) {
/* 108 */       return (BeanMetadataElement)new RuntimeBeanReference(authenticationConverter);
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BeanDefinition createDefaultAuthenticationConverter(BeanMetadataElement relyingPartyRegistrationRepository) {
/* 117 */     AbstractBeanDefinition resolver = BeanDefinitionBuilder.rootBeanDefinition(DefaultRelyingPartyRegistrationResolver.class).addConstructorArgValue(relyingPartyRegistrationRepository).getBeanDefinition();
/* 118 */     return (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(Saml2AuthenticationTokenConverter.class)
/* 119 */       .addConstructorArgValue(resolver)
/* 120 */       .getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\Saml2LoginBeanDefinitionParserUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */