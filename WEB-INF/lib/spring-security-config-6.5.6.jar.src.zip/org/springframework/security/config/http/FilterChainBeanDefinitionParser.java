/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.web.DefaultSecurityFilterChain;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterChainBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   private static final String ATT_REQUEST_MATCHER_REF = "request-matcher-ref";
/*    */   
/*    */   public BeanDefinition parse(Element elt, ParserContext pc) {
/* 42 */     MatcherType matcherType = MatcherType.fromElementOrMvc(elt);
/* 43 */     String path = elt.getAttribute("pattern");
/* 44 */     String requestMatcher = elt.getAttribute("request-matcher-ref");
/* 45 */     String filters = elt.getAttribute("filters");
/* 46 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(DefaultSecurityFilterChain.class);
/* 47 */     if (StringUtils.hasText(path)) {
/* 48 */       Assert.isTrue(!StringUtils.hasText(requestMatcher), "");
/* 49 */       builder.addConstructorArgValue(matcherType.createMatcher(pc, path, null));
/*    */     } else {
/*    */       
/* 52 */       Assert.isTrue(StringUtils.hasText(requestMatcher), "");
/* 53 */       builder.addConstructorArgReference(requestMatcher);
/*    */     } 
/* 55 */     if (filters.equals("none")) {
/* 56 */       builder.addConstructorArgValue(Collections.EMPTY_LIST);
/*    */     } else {
/*    */       
/* 59 */       String[] filterBeanNames = StringUtils.tokenizeToStringArray(filters, ",");
/* 60 */       ManagedList<RuntimeBeanReference> filterChain = new ManagedList(filterBeanNames.length);
/* 61 */       for (String name : filterBeanNames) {
/* 62 */         filterChain.add(new RuntimeBeanReference(name));
/*    */       }
/* 64 */       builder.addConstructorArgValue(filterChain);
/*    */     } 
/* 66 */     return (BeanDefinition)builder.getBeanDefinition();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\FilterChainBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */