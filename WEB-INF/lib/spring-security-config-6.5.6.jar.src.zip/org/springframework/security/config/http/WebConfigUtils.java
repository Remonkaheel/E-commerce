/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.web.util.UrlUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WebConfigUtils
/*    */ {
/*    */   static int countNonEmpty(String[] objects) {
/* 36 */     int nonNulls = 0;
/* 37 */     for (String object : objects) {
/* 38 */       if (StringUtils.hasText(object)) {
/* 39 */         nonNulls++;
/*    */       }
/*    */     } 
/* 42 */     return nonNulls;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void validateHttpRedirect(String url, ParserContext pc, Object source) {
/* 51 */     if (!StringUtils.hasText(url) || UrlUtils.isValidRedirectUrl(url) || url.startsWith("$") || url
/* 52 */       .startsWith("#")) {
/*    */       return;
/*    */     }
/* 55 */     pc.getReaderContext().warning(url + " is not a valid redirect URL (must start with '/' or http(s))", source);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\WebConfigUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */