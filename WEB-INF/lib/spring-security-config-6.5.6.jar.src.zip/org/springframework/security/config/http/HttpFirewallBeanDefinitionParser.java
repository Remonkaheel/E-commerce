/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpFirewallBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   public BeanDefinition parse(Element element, ParserContext pc) {
/* 38 */     String ref = element.getAttribute("ref");
/* 39 */     if (!StringUtils.hasText(ref)) {
/* 40 */       pc.getReaderContext().error("ref attribute is required", pc.extractSource(element));
/*    */     }
/*    */     
/* 43 */     HttpSecurityBeanDefinitionParser.registerFilterChainProxyIfNecessary(pc, element);
/* 44 */     BeanDefinition filterChainProxy = pc.getRegistry().getBeanDefinition("org.springframework.security.filterChainProxy");
/* 45 */     filterChainProxy.getPropertyValues().addPropertyValue("firewall", new RuntimeBeanReference(ref));
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\HttpFirewallBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */