/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.oauth2.client.authentication.OAuth2AuthorizationCodeAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationCodeGrantFilter;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OAuth2ClientBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ELT_AUTHORIZATION_CODE_GRANT = "authorization-code-grant";
/*     */   private static final String ATT_AUTHORIZATION_REQUEST_REPOSITORY_REF = "authorization-request-repository-ref";
/*     */   private static final String ATT_AUTHORIZATION_REQUEST_RESOLVER_REF = "authorization-request-resolver-ref";
/*     */   private static final String ATT_AUTHORIZATION_REDIRECT_STRATEGY_REF = "authorization-redirect-strategy-ref";
/*     */   private static final String ATT_ACCESS_TOKEN_RESPONSE_CLIENT_REF = "access-token-response-client-ref";
/*     */   private final BeanReference requestCache;
/*     */   private final BeanReference authenticationManager;
/*     */   private final BeanReference authenticationFilterSecurityContextRepositoryRef;
/*     */   private final BeanMetadataElement authenticationFilterSecurityContextHolderStrategy;
/*     */   private BeanDefinition defaultAuthorizedClientRepository;
/*     */   private BeanDefinition authorizationRequestRedirectFilter;
/*     */   private BeanDefinition authorizationCodeGrantFilter;
/*     */   private BeanDefinition authorizationCodeAuthenticationProvider;
/*     */   
/*     */   OAuth2ClientBeanDefinitionParser(BeanReference requestCache, BeanReference authenticationManager, BeanReference authenticationFilterSecurityContextRepositoryRef, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/*  70 */     this.requestCache = requestCache;
/*  71 */     this.authenticationManager = authenticationManager;
/*  72 */     this.authenticationFilterSecurityContextRepositoryRef = authenticationFilterSecurityContextRepositoryRef;
/*  73 */     this.authenticationFilterSecurityContextHolderStrategy = authenticationFilterSecurityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*     */     RuntimeBeanReference runtimeBeanReference;
/*  78 */     Element authorizationCodeGrantElt = DomUtils.getChildElementByTagName(element, "authorization-code-grant");
/*     */     
/*  80 */     BeanMetadataElement clientRegistrationRepository = OAuth2ClientBeanDefinitionParserUtils.getClientRegistrationRepository(element);
/*     */     
/*  82 */     BeanMetadataElement authorizedClientRepository = OAuth2ClientBeanDefinitionParserUtils.getAuthorizedClientRepository(element);
/*  83 */     if (authorizedClientRepository == null) {
/*     */       
/*  85 */       BeanMetadataElement authorizedClientService = OAuth2ClientBeanDefinitionParserUtils.getAuthorizedClientService(element);
/*  86 */       this
/*  87 */         .defaultAuthorizedClientRepository = OAuth2ClientBeanDefinitionParserUtils.createDefaultAuthorizedClientRepository(clientRegistrationRepository, authorizedClientService);
/*  88 */       runtimeBeanReference = new RuntimeBeanReference(OAuth2AuthorizedClientRepository.class);
/*     */     } 
/*  90 */     BeanMetadataElement authorizationRequestRepository = getAuthorizationRequestRepository(authorizationCodeGrantElt);
/*     */     
/*  92 */     BeanMetadataElement authorizationRedirectStrategy = getAuthorizationRedirectStrategy(authorizationCodeGrantElt);
/*     */     
/*  94 */     BeanDefinitionBuilder authorizationRequestRedirectFilterBuilder = BeanDefinitionBuilder.rootBeanDefinition(OAuth2AuthorizationRequestRedirectFilter.class);
/*     */     
/*  96 */     String authorizationRequestResolverRef = (authorizationCodeGrantElt != null) ? authorizationCodeGrantElt.getAttribute("authorization-request-resolver-ref") : null;
/*  97 */     if (StringUtils.hasLength(authorizationRequestResolverRef)) {
/*  98 */       authorizationRequestRedirectFilterBuilder.addConstructorArgReference(authorizationRequestResolverRef);
/*     */     } else {
/*     */       
/* 101 */       authorizationRequestRedirectFilterBuilder.addConstructorArgValue(clientRegistrationRepository);
/*     */     } 
/* 103 */     this
/*     */ 
/*     */ 
/*     */       
/* 107 */       .authorizationRequestRedirectFilter = (BeanDefinition)authorizationRequestRedirectFilterBuilder.addPropertyValue("authorizationRequestRepository", authorizationRequestRepository).addPropertyValue("authorizationRedirectStrategy", authorizationRedirectStrategy).addPropertyValue("requestCache", this.requestCache).getBeanDefinition();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     BeanDefinitionBuilder authorizationCodeGrantFilterBldr = BeanDefinitionBuilder.rootBeanDefinition(OAuth2AuthorizationCodeGrantFilter.class).addConstructorArgValue(clientRegistrationRepository).addConstructorArgValue(runtimeBeanReference).addConstructorArgValue(this.authenticationManager).addPropertyValue("authorizationRequestRepository", authorizationRequestRepository);
/* 114 */     this.authorizationCodeGrantFilter = (BeanDefinition)authorizationCodeGrantFilterBldr.getBeanDefinition();
/*     */     
/* 116 */     BeanMetadataElement accessTokenResponseClient = getAccessTokenResponseClient(authorizationCodeGrantElt);
/* 117 */     this
/*     */ 
/*     */       
/* 120 */       .authorizationCodeAuthenticationProvider = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(OAuth2AuthorizationCodeAuthenticationProvider.class).addConstructorArgValue(accessTokenResponseClient).getBeanDefinition();
/*     */     
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanMetadataElement getAuthorizationRequestRepository(Element element) {
/* 127 */     String authorizationRequestRepositoryRef = (element != null) ? element.getAttribute("authorization-request-repository-ref") : null;
/* 128 */     if (StringUtils.hasLength(authorizationRequestRepositoryRef)) {
/* 129 */       return (BeanMetadataElement)new RuntimeBeanReference(authorizationRequestRepositoryRef);
/*     */     }
/* 131 */     return 
/* 132 */       (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.web.HttpSessionOAuth2AuthorizationRequestRepository")
/*     */       
/* 134 */       .getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanMetadataElement getAuthorizationRedirectStrategy(Element element) {
/* 139 */     String authorizationRedirectStrategyRef = (element != null) ? element.getAttribute("authorization-redirect-strategy-ref") : null;
/* 140 */     if (StringUtils.hasText(authorizationRedirectStrategyRef)) {
/* 141 */       return (BeanMetadataElement)new RuntimeBeanReference(authorizationRedirectStrategyRef);
/*     */     }
/* 143 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.web.DefaultRedirectStrategy")
/* 144 */       .getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanMetadataElement getAccessTokenResponseClient(Element element) {
/* 149 */     String accessTokenResponseClientRef = (element != null) ? element.getAttribute("access-token-response-client-ref") : null;
/* 150 */     if (StringUtils.hasLength(accessTokenResponseClientRef)) {
/* 151 */       return (BeanMetadataElement)new RuntimeBeanReference(accessTokenResponseClientRef);
/*     */     }
/* 153 */     return 
/* 154 */       (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient")
/*     */       
/* 156 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   BeanDefinition getDefaultAuthorizedClientRepository() {
/* 160 */     return this.defaultAuthorizedClientRepository;
/*     */   }
/*     */   
/*     */   BeanDefinition getAuthorizationRequestRedirectFilter() {
/* 164 */     return this.authorizationRequestRedirectFilter;
/*     */   }
/*     */   
/*     */   BeanDefinition getAuthorizationCodeGrantFilter() {
/* 168 */     return this.authorizationCodeGrantFilter;
/*     */   }
/*     */   
/*     */   BeanDefinition getAuthorizationCodeAuthenticationProvider() {
/* 172 */     return this.authorizationCodeAuthenticationProvider;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2ClientBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */