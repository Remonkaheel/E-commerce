/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.web.authentication.ForwardAuthenticationFailureHandler;
/*     */ import org.springframework.security.web.authentication.ForwardAuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
/*     */ import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormLoginBeanDefinitionParser
/*     */ {
/*  45 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   private static final String ATT_LOGIN_URL = "login-processing-url";
/*     */ 
/*     */   
/*     */   static final String ATT_LOGIN_PAGE = "login-page";
/*     */   
/*     */   private static final String DEF_LOGIN_PAGE = "/login";
/*     */   
/*     */   private static final String ATT_FORM_LOGIN_TARGET_URL = "default-target-url";
/*     */   
/*     */   private static final String ATT_ALWAYS_USE_DEFAULT_TARGET_URL = "always-use-default-target";
/*     */   
/*     */   private static final String DEF_FORM_LOGIN_TARGET_URL = "/";
/*     */   
/*     */   private static final String ATT_USERNAME_PARAMETER = "username-parameter";
/*     */   
/*     */   private static final String ATT_PASSWORD_PARAMETER = "password-parameter";
/*     */   
/*     */   private static final String ATT_FORM_LOGIN_AUTHENTICATION_FAILURE_URL = "authentication-failure-url";
/*     */   
/*     */   private static final String DEF_FORM_LOGIN_AUTHENTICATION_FAILURE_URL = "/login?error";
/*     */   
/*     */   private static final String ATT_SUCCESS_HANDLER_REF = "authentication-success-handler-ref";
/*     */   
/*     */   private static final String ATT_FAILURE_HANDLER_REF = "authentication-failure-handler-ref";
/*     */   
/*     */   private static final String ATT_FORM_LOGIN_AUTHENTICATION_FAILURE_FORWARD_URL = "authentication-failure-forward-url";
/*     */   
/*     */   private static final String ATT_FORM_LOGIN_AUTHENTICATION_SUCCESS_FORWARD_URL = "authentication-success-forward-url";
/*     */   
/*     */   private final String defaultLoginProcessingUrl;
/*     */   
/*     */   private final String filterClassName;
/*     */   
/*     */   private final BeanReference requestCache;
/*     */   
/*     */   private final BeanReference sessionStrategy;
/*     */   
/*     */   private final boolean allowSessionCreation;
/*     */   
/*     */   private final BeanReference portMapper;
/*     */   
/*     */   private final BeanReference portResolver;
/*     */   
/*     */   private RootBeanDefinition filterBean;
/*     */   
/*     */   private RootBeanDefinition entryPointBean;
/*     */   
/*     */   private String loginPage;
/*     */   
/*     */   private String loginMethod;
/*     */   
/*     */   private String loginProcessingUrl;
/*     */ 
/*     */   
/*     */   FormLoginBeanDefinitionParser(String defaultLoginProcessingUrl, String loginMethod, String filterClassName, BeanReference requestCache, BeanReference sessionStrategy, boolean allowSessionCreation, BeanReference portMapper, BeanReference portResolver) {
/* 103 */     this.defaultLoginProcessingUrl = defaultLoginProcessingUrl;
/* 104 */     this.loginMethod = loginMethod;
/* 105 */     this.filterClassName = filterClassName;
/* 106 */     this.requestCache = requestCache;
/* 107 */     this.sessionStrategy = sessionStrategy;
/* 108 */     this.allowSessionCreation = allowSessionCreation;
/* 109 */     this.portMapper = portMapper;
/* 110 */     this.portResolver = portResolver;
/*     */   }
/*     */   
/*     */   public BeanDefinition parse(Element elt, ParserContext pc) {
/* 114 */     String loginUrl = null;
/* 115 */     String defaultTargetUrl = null;
/* 116 */     String authenticationFailureUrl = null;
/* 117 */     String alwaysUseDefault = null;
/* 118 */     String successHandlerRef = null;
/* 119 */     String failureHandlerRef = null;
/*     */     
/* 121 */     String usernameParameter = null;
/* 122 */     String passwordParameter = null;
/* 123 */     String authDetailsSourceRef = null;
/* 124 */     String authenticationFailureForwardUrl = null;
/* 125 */     String authenticationSuccessForwardUrl = null;
/* 126 */     Object source = null;
/* 127 */     if (elt != null) {
/* 128 */       source = pc.extractSource(elt);
/* 129 */       loginUrl = elt.getAttribute("login-processing-url");
/* 130 */       WebConfigUtils.validateHttpRedirect(loginUrl, pc, source);
/* 131 */       defaultTargetUrl = elt.getAttribute("default-target-url");
/* 132 */       WebConfigUtils.validateHttpRedirect(defaultTargetUrl, pc, source);
/* 133 */       authenticationFailureUrl = elt.getAttribute("authentication-failure-url");
/* 134 */       WebConfigUtils.validateHttpRedirect(authenticationFailureUrl, pc, source);
/* 135 */       alwaysUseDefault = elt.getAttribute("always-use-default-target");
/* 136 */       this.loginPage = elt.getAttribute("login-page");
/* 137 */       successHandlerRef = elt.getAttribute("authentication-success-handler-ref");
/* 138 */       failureHandlerRef = elt.getAttribute("authentication-failure-handler-ref");
/* 139 */       authDetailsSourceRef = elt.getAttribute("authentication-details-source-ref");
/* 140 */       authenticationFailureForwardUrl = elt.getAttribute("authentication-failure-forward-url");
/* 141 */       WebConfigUtils.validateHttpRedirect(authenticationFailureForwardUrl, pc, source);
/* 142 */       authenticationSuccessForwardUrl = elt.getAttribute("authentication-success-forward-url");
/* 143 */       WebConfigUtils.validateHttpRedirect(authenticationSuccessForwardUrl, pc, source);
/* 144 */       if (!StringUtils.hasText(this.loginPage)) {
/* 145 */         this.loginPage = null;
/*     */       }
/* 147 */       WebConfigUtils.validateHttpRedirect(this.loginPage, pc, source);
/* 148 */       usernameParameter = elt.getAttribute("username-parameter");
/* 149 */       passwordParameter = elt.getAttribute("password-parameter");
/*     */     } 
/* 151 */     this.filterBean = createFilterBean(loginUrl, defaultTargetUrl, alwaysUseDefault, this.loginPage, authenticationFailureUrl, successHandlerRef, failureHandlerRef, authDetailsSourceRef, authenticationFailureForwardUrl, authenticationSuccessForwardUrl);
/*     */ 
/*     */     
/* 154 */     if (StringUtils.hasText(usernameParameter)) {
/* 155 */       this.filterBean.getPropertyValues().addPropertyValue("usernameParameter", usernameParameter);
/*     */     }
/* 157 */     if (StringUtils.hasText(passwordParameter)) {
/* 158 */       this.filterBean.getPropertyValues().addPropertyValue("passwordParameter", passwordParameter);
/*     */     }
/* 160 */     this.filterBean.setSource(source);
/*     */     
/* 162 */     BeanDefinitionBuilder entryPointBuilder = BeanDefinitionBuilder.rootBeanDefinition(LoginUrlAuthenticationEntryPoint.class);
/* 163 */     entryPointBuilder.getRawBeanDefinition().setSource(source);
/* 164 */     entryPointBuilder.addConstructorArgValue((this.loginPage != null) ? this.loginPage : "/login");
/* 165 */     entryPointBuilder.addPropertyValue("portMapper", this.portMapper);
/* 166 */     entryPointBuilder.addPropertyValue("portResolver", this.portResolver);
/* 167 */     this.entryPointBean = (RootBeanDefinition)entryPointBuilder.getBeanDefinition();
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RootBeanDefinition createFilterBean(String loginUrl, String defaultTargetUrl, String alwaysUseDefault, String loginPage, String authenticationFailureUrl, String successHandlerRef, String failureHandlerRef, String authDetailsSourceRef, String authenticationFailureForwardUrl, String authenticationSuccessForwardUrl) {
/* 175 */     BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(this.filterClassName);
/* 176 */     if (!StringUtils.hasText(loginUrl)) {
/* 177 */       loginUrl = this.defaultLoginProcessingUrl;
/*     */     }
/* 179 */     this.loginProcessingUrl = loginUrl;
/*     */     
/* 181 */     BeanDefinitionBuilder matcherBuilder = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class);
/* 182 */     matcherBuilder.addConstructorArgValue(loginUrl);
/* 183 */     if (this.loginMethod != null) {
/* 184 */       matcherBuilder.addConstructorArgValue("POST");
/*     */     }
/* 186 */     filterBuilder.addPropertyValue("requiresAuthenticationRequestMatcher", matcherBuilder.getBeanDefinition());
/* 187 */     if (StringUtils.hasText(successHandlerRef)) {
/* 188 */       filterBuilder.addPropertyReference("authenticationSuccessHandler", successHandlerRef);
/*     */     }
/* 190 */     else if (StringUtils.hasText(authenticationSuccessForwardUrl)) {
/*     */       
/* 192 */       BeanDefinitionBuilder forwardSuccessHandler = BeanDefinitionBuilder.rootBeanDefinition(ForwardAuthenticationSuccessHandler.class);
/* 193 */       forwardSuccessHandler.addConstructorArgValue(authenticationSuccessForwardUrl);
/* 194 */       filterBuilder.addPropertyValue("authenticationSuccessHandler", forwardSuccessHandler.getBeanDefinition());
/*     */     }
/*     */     else {
/*     */       
/* 198 */       BeanDefinitionBuilder successHandler = BeanDefinitionBuilder.rootBeanDefinition(SavedRequestAwareAuthenticationSuccessHandler.class);
/* 199 */       if ("true".equals(alwaysUseDefault)) {
/* 200 */         successHandler.addPropertyValue("alwaysUseDefaultTargetUrl", Boolean.TRUE);
/*     */       }
/* 202 */       successHandler.addPropertyValue("requestCache", this.requestCache);
/* 203 */       successHandler.addPropertyValue("defaultTargetUrl", 
/* 204 */           StringUtils.hasText(defaultTargetUrl) ? defaultTargetUrl : "/");
/* 205 */       filterBuilder.addPropertyValue("authenticationSuccessHandler", successHandler.getBeanDefinition());
/*     */     } 
/* 207 */     if (StringUtils.hasText(authDetailsSourceRef)) {
/* 208 */       filterBuilder.addPropertyReference("authenticationDetailsSource", authDetailsSourceRef);
/*     */     }
/* 210 */     if (this.sessionStrategy != null) {
/* 211 */       filterBuilder.addPropertyValue("sessionAuthenticationStrategy", this.sessionStrategy);
/*     */     }
/* 213 */     if (StringUtils.hasText(failureHandlerRef)) {
/* 214 */       filterBuilder.addPropertyReference("authenticationFailureHandler", failureHandlerRef);
/*     */     }
/* 216 */     else if (StringUtils.hasText(authenticationFailureForwardUrl)) {
/*     */       
/* 218 */       BeanDefinitionBuilder forwardFailureHandler = BeanDefinitionBuilder.rootBeanDefinition(ForwardAuthenticationFailureHandler.class);
/* 219 */       forwardFailureHandler.addConstructorArgValue(authenticationFailureForwardUrl);
/* 220 */       filterBuilder.addPropertyValue("authenticationFailureHandler", forwardFailureHandler.getBeanDefinition());
/*     */     }
/*     */     else {
/*     */       
/* 224 */       BeanDefinitionBuilder failureHandler = BeanDefinitionBuilder.rootBeanDefinition(SimpleUrlAuthenticationFailureHandler.class);
/* 225 */       if (!StringUtils.hasText(authenticationFailureUrl))
/*     */       {
/* 227 */         if (StringUtils.hasText(loginPage)) {
/* 228 */           authenticationFailureUrl = loginPage + "?error";
/*     */         } else {
/*     */           
/* 231 */           authenticationFailureUrl = "/login?error";
/*     */         } 
/*     */       }
/* 234 */       failureHandler.addPropertyValue("defaultFailureUrl", authenticationFailureUrl);
/* 235 */       failureHandler.addPropertyValue("allowSessionCreation", Boolean.valueOf(this.allowSessionCreation));
/* 236 */       filterBuilder.addPropertyValue("authenticationFailureHandler", failureHandler.getBeanDefinition());
/*     */     } 
/* 238 */     return (RootBeanDefinition)filterBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   RootBeanDefinition getFilterBean() {
/* 242 */     return this.filterBean;
/*     */   }
/*     */   
/*     */   RootBeanDefinition getEntryPointBean() {
/* 246 */     return this.entryPointBean;
/*     */   }
/*     */   
/*     */   String getLoginPage() {
/* 250 */     return this.loginPage;
/*     */   }
/*     */   
/*     */   String getLoginProcessingUrl() {
/* 254 */     return this.loginProcessingUrl;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\FormLoginBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */