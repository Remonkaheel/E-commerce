/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.oauth2.client.authentication.OAuth2LoginAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.client.authentication.OAuth2LoginAuthenticationToken;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2LoginAuthenticationFilter;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.core.OAuth2Error;
/*     */ import org.springframework.security.web.AuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.DelegatingAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ import org.springframework.web.accept.HeaderContentNegotiationStrategy;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OAuth2LoginBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String DEFAULT_AUTHORIZATION_REQUEST_BASE_URI = "/oauth2/authorization";
/*     */   private static final String DEFAULT_LOGIN_URI = "/login";
/*     */   private static final String ELT_CLIENT_REGISTRATION = "client-registration";
/*     */   private static final String ATT_REGISTRATION_ID = "registration-id";
/*     */   private static final String ATT_AUTHORIZATION_REQUEST_REPOSITORY_REF = "authorization-request-repository-ref";
/*     */   private static final String ATT_AUTHORIZATION_REQUEST_RESOLVER_REF = "authorization-request-resolver-ref";
/*     */   private static final String ATT_AUTHORIZATION_REDIRECT_STRATEGY_REF = "authorization-redirect-strategy-ref";
/*     */   private static final String ATT_ACCESS_TOKEN_RESPONSE_CLIENT_REF = "access-token-response-client-ref";
/*     */   private static final String ATT_USER_AUTHORITIES_MAPPER_REF = "user-authorities-mapper-ref";
/*     */   private static final String ATT_USER_SERVICE_REF = "user-service-ref";
/*     */   private static final String ATT_OIDC_USER_SERVICE_REF = "oidc-user-service-ref";
/*     */   private static final String ATT_LOGIN_PROCESSING_URL = "login-processing-url";
/*     */   private static final String ATT_LOGIN_PAGE = "login-page";
/*     */   private static final String ATT_AUTHENTICATION_SUCCESS_HANDLER_REF = "authentication-success-handler-ref";
/*     */   private static final String ATT_AUTHENTICATION_FAILURE_HANDLER_REF = "authentication-failure-handler-ref";
/*     */   private static final String ATT_JWT_DECODER_FACTORY_REF = "jwt-decoder-factory-ref";
/*     */   private final BeanReference requestCache;
/*     */   private final BeanReference portMapper;
/*     */   private final BeanReference portResolver;
/*     */   private final BeanReference sessionStrategy;
/*     */   private final boolean allowSessionCreation;
/*     */   private final BeanMetadataElement authenticationFilterSecurityContextHolderStrategy;
/*     */   private BeanDefinition defaultAuthorizedClientRepository;
/*     */   private BeanDefinition oauth2AuthorizationRequestRedirectFilter;
/*     */   private BeanDefinition oauth2LoginAuthenticationEntryPoint;
/*     */   private BeanDefinition oauth2LoginAuthenticationProvider;
/*     */   private BeanDefinition oauth2LoginOidcAuthenticationProvider;
/*     */   private BeanDefinition oauth2LoginLinks;
/*     */   
/*     */   OAuth2LoginBeanDefinitionParser(BeanReference requestCache, BeanReference portMapper, BeanReference portResolver, BeanReference sessionStrategy, boolean allowSessionCreation, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/* 137 */     this.requestCache = requestCache;
/* 138 */     this.portMapper = portMapper;
/* 139 */     this.portResolver = portResolver;
/* 140 */     this.sessionStrategy = sessionStrategy;
/* 141 */     this.allowSessionCreation = allowSessionCreation;
/* 142 */     this.authenticationFilterSecurityContextHolderStrategy = authenticationFilterSecurityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/*     */     RuntimeBeanReference runtimeBeanReference;
/* 149 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(OAuth2LoginBeanConfig.class).getBeanDefinition();
/* 150 */     String oauth2LoginBeanConfigId = parserContext.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/* 151 */     parserContext
/* 152 */       .registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, oauth2LoginBeanConfigId));
/*     */ 
/*     */     
/* 155 */     BeanMetadataElement clientRegistrationRepository = OAuth2ClientBeanDefinitionParserUtils.getClientRegistrationRepository(element);
/*     */     
/* 157 */     BeanMetadataElement authorizedClientRepository = OAuth2ClientBeanDefinitionParserUtils.getAuthorizedClientRepository(element);
/* 158 */     if (authorizedClientRepository == null) {
/*     */       
/* 160 */       BeanMetadataElement authorizedClientService = OAuth2ClientBeanDefinitionParserUtils.getAuthorizedClientService(element);
/* 161 */       this
/* 162 */         .defaultAuthorizedClientRepository = OAuth2ClientBeanDefinitionParserUtils.createDefaultAuthorizedClientRepository(clientRegistrationRepository, authorizedClientService);
/* 163 */       runtimeBeanReference = new RuntimeBeanReference(OAuth2AuthorizedClientRepository.class);
/*     */     } 
/* 165 */     BeanMetadataElement accessTokenResponseClient = getAccessTokenResponseClient(element);
/* 166 */     BeanMetadataElement oauth2UserService = getOAuth2UserService(element);
/* 167 */     BeanMetadataElement authorizationRequestRepository = getAuthorizationRequestRepository(element);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     BeanDefinitionBuilder oauth2LoginAuthenticationFilterBuilder = BeanDefinitionBuilder.rootBeanDefinition(OAuth2LoginAuthenticationFilter.class).addConstructorArgValue(clientRegistrationRepository).addConstructorArgValue(runtimeBeanReference).addPropertyValue("authorizationRequestRepository", authorizationRequestRepository);
/* 173 */     if (this.sessionStrategy != null) {
/* 174 */       oauth2LoginAuthenticationFilterBuilder.addPropertyValue("sessionAuthenticationStrategy", this.sessionStrategy);
/*     */     }
/*     */     
/* 177 */     Object source = parserContext.extractSource(element);
/* 178 */     String loginProcessingUrl = element.getAttribute("login-processing-url");
/* 179 */     if (StringUtils.hasLength(loginProcessingUrl)) {
/* 180 */       WebConfigUtils.validateHttpRedirect(loginProcessingUrl, parserContext, source);
/* 181 */       oauth2LoginAuthenticationFilterBuilder.addConstructorArgValue(loginProcessingUrl);
/*     */     } else {
/*     */       
/* 184 */       oauth2LoginAuthenticationFilterBuilder
/* 185 */         .addConstructorArgValue("/login/oauth2/code/*");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     BeanDefinitionBuilder oauth2LoginAuthenticationProviderBuilder = BeanDefinitionBuilder.rootBeanDefinition(OAuth2LoginAuthenticationProvider.class).addConstructorArgValue(accessTokenResponseClient).addConstructorArgValue(oauth2UserService);
/* 191 */     String userAuthoritiesMapperRef = element.getAttribute("user-authorities-mapper-ref");
/* 192 */     if (StringUtils.hasLength(userAuthoritiesMapperRef)) {
/* 193 */       oauth2LoginAuthenticationProviderBuilder.addPropertyReference("authoritiesMapper", userAuthoritiesMapperRef);
/*     */     }
/*     */     
/* 196 */     this.oauth2LoginAuthenticationProvider = (BeanDefinition)oauth2LoginAuthenticationProviderBuilder.getBeanDefinition();
/* 197 */     this.oauth2LoginOidcAuthenticationProvider = getOidcAuthProvider(element, accessTokenResponseClient, userAuthoritiesMapperRef);
/*     */ 
/*     */     
/* 200 */     BeanDefinitionBuilder oauth2AuthorizationRequestRedirectFilterBuilder = BeanDefinitionBuilder.rootBeanDefinition(OAuth2AuthorizationRequestRedirectFilter.class);
/* 201 */     String authorizationRequestResolverRef = element.getAttribute("authorization-request-resolver-ref");
/* 202 */     if (StringUtils.hasLength(authorizationRequestResolverRef)) {
/* 203 */       oauth2AuthorizationRequestRedirectFilterBuilder.addConstructorArgReference(authorizationRequestResolverRef);
/*     */     } else {
/*     */       
/* 206 */       oauth2AuthorizationRequestRedirectFilterBuilder.addConstructorArgValue(clientRegistrationRepository);
/*     */     } 
/* 208 */     oauth2AuthorizationRequestRedirectFilterBuilder
/* 209 */       .addPropertyValue("authorizationRequestRepository", authorizationRequestRepository)
/* 210 */       .addPropertyValue("authorizationRedirectStrategy", getAuthorizationRedirectStrategy(element))
/* 211 */       .addPropertyValue("requestCache", this.requestCache);
/* 212 */     this
/* 213 */       .oauth2AuthorizationRequestRedirectFilter = (BeanDefinition)oauth2AuthorizationRequestRedirectFilterBuilder.getBeanDefinition();
/* 214 */     String authenticationSuccessHandlerRef = element.getAttribute("authentication-success-handler-ref");
/* 215 */     if (StringUtils.hasLength(authenticationSuccessHandlerRef)) {
/* 216 */       oauth2LoginAuthenticationFilterBuilder.addPropertyReference("authenticationSuccessHandler", authenticationSuccessHandlerRef);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 223 */       BeanDefinitionBuilder successHandlerBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler").addPropertyValue("requestCache", this.requestCache);
/* 224 */       oauth2LoginAuthenticationFilterBuilder.addPropertyValue("authenticationSuccessHandler", successHandlerBuilder
/* 225 */           .getBeanDefinition());
/*     */     } 
/* 227 */     String loginPage = element.getAttribute("login-page");
/* 228 */     if (StringUtils.hasLength(loginPage)) {
/* 229 */       WebConfigUtils.validateHttpRedirect(loginPage, parserContext, source);
/* 230 */       this
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 235 */         .oauth2LoginAuthenticationEntryPoint = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(LoginUrlAuthenticationEntryPoint.class).addConstructorArgValue(loginPage).addPropertyValue("portMapper", this.portMapper).addPropertyValue("portResolver", this.portResolver).getBeanDefinition();
/*     */     } else {
/*     */       
/* 238 */       Map<BeanDefinition, AuthenticationEntryPoint> entryPoint = getLoginEntryPoint(element);
/* 239 */       if (entryPoint != null) {
/* 240 */         this
/*     */ 
/*     */ 
/*     */           
/* 244 */           .oauth2LoginAuthenticationEntryPoint = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(DelegatingAuthenticationEntryPoint.class).addConstructorArgValue(entryPoint).addPropertyValue("defaultEntryPoint", new LoginUrlAuthenticationEntryPoint("/login")).getBeanDefinition();
/*     */       }
/*     */     } 
/* 247 */     String authenticationFailureHandlerRef = element.getAttribute("authentication-failure-handler-ref");
/* 248 */     if (StringUtils.hasLength(authenticationFailureHandlerRef)) {
/* 249 */       oauth2LoginAuthenticationFilterBuilder.addPropertyReference("authenticationFailureHandler", authenticationFailureHandlerRef);
/*     */     }
/*     */     else {
/*     */       
/* 253 */       BeanDefinitionBuilder failureHandlerBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler");
/*     */       
/* 255 */       failureHandlerBuilder.addConstructorArgValue("/login?error");
/*     */       
/* 257 */       failureHandlerBuilder.addPropertyValue("allowSessionCreation", Boolean.valueOf(this.allowSessionCreation));
/* 258 */       oauth2LoginAuthenticationFilterBuilder.addPropertyValue("authenticationFailureHandler", failureHandlerBuilder
/* 259 */           .getBeanDefinition());
/*     */     } 
/* 261 */     oauth2LoginAuthenticationFilterBuilder.addPropertyValue("securityContextHolderStrategy", this.authenticationFilterSecurityContextHolderStrategy);
/*     */ 
/*     */     
/* 264 */     this
/*     */       
/* 266 */       .oauth2LoginLinks = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(Map.class).setFactoryMethodOnBean("getLoginLinks", oauth2LoginBeanConfigId).getBeanDefinition();
/* 267 */     return (BeanDefinition)oauth2LoginAuthenticationFilterBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   private BeanMetadataElement getAuthorizationRequestRepository(Element element) {
/* 271 */     String authorizationRequestRepositoryRef = element.getAttribute("authorization-request-repository-ref");
/* 272 */     if (StringUtils.hasLength(authorizationRequestRepositoryRef)) {
/* 273 */       return (BeanMetadataElement)new RuntimeBeanReference(authorizationRequestRepositoryRef);
/*     */     }
/* 275 */     return 
/* 276 */       (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.web.HttpSessionOAuth2AuthorizationRequestRepository")
/*     */       
/* 278 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   private BeanMetadataElement getAuthorizationRedirectStrategy(Element element) {
/* 282 */     String authorizationRedirectStrategyRef = element.getAttribute("authorization-redirect-strategy-ref");
/* 283 */     if (StringUtils.hasText(authorizationRedirectStrategyRef)) {
/* 284 */       return (BeanMetadataElement)new RuntimeBeanReference(authorizationRedirectStrategyRef);
/*     */     }
/* 286 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.web.DefaultRedirectStrategy")
/* 287 */       .getBeanDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanDefinition getOidcAuthProvider(Element element, BeanMetadataElement accessTokenResponseClient, String userAuthoritiesMapperRef) {
/* 293 */     boolean oidcAuthenticationProviderEnabled = ClassUtils.isPresent("org.springframework.security.oauth2.jwt.JwtDecoder", getClass().getClassLoader());
/* 294 */     if (!oidcAuthenticationProviderEnabled) {
/* 295 */       return (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(OidcAuthenticationRequestChecker.class).getBeanDefinition();
/*     */     }
/* 297 */     BeanMetadataElement oidcUserService = getOidcUserService(element);
/*     */ 
/*     */ 
/*     */     
/* 301 */     BeanDefinitionBuilder oidcAuthProviderBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.oidc.authentication.OidcAuthorizationCodeAuthenticationProvider").addConstructorArgValue(accessTokenResponseClient).addConstructorArgValue(oidcUserService);
/* 302 */     if (StringUtils.hasLength(userAuthoritiesMapperRef)) {
/* 303 */       oidcAuthProviderBuilder.addPropertyReference("authoritiesMapper", userAuthoritiesMapperRef);
/*     */     }
/* 305 */     String jwtDecoderFactoryRef = element.getAttribute("jwt-decoder-factory-ref");
/* 306 */     if (StringUtils.hasLength(jwtDecoderFactoryRef)) {
/* 307 */       oidcAuthProviderBuilder.addPropertyReference("jwtDecoderFactory", jwtDecoderFactoryRef);
/*     */     }
/* 309 */     return (BeanDefinition)oidcAuthProviderBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   private BeanMetadataElement getOidcUserService(Element element) {
/* 313 */     String oidcUserServiceRef = element.getAttribute("oidc-user-service-ref");
/* 314 */     if (StringUtils.hasLength(oidcUserServiceRef)) {
/* 315 */       return (BeanMetadataElement)new RuntimeBeanReference(oidcUserServiceRef);
/*     */     }
/* 317 */     return 
/* 318 */       (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService")
/* 319 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   private BeanMetadataElement getOAuth2UserService(Element element) {
/* 323 */     String oauth2UserServiceRef = element.getAttribute("user-service-ref");
/* 324 */     if (StringUtils.hasLength(oauth2UserServiceRef)) {
/* 325 */       return (BeanMetadataElement)new RuntimeBeanReference(oauth2UserServiceRef);
/*     */     }
/* 327 */     return 
/* 328 */       (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService")
/* 329 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   private BeanMetadataElement getAccessTokenResponseClient(Element element) {
/* 333 */     String accessTokenResponseClientRef = element.getAttribute("access-token-response-client-ref");
/* 334 */     if (StringUtils.hasLength(accessTokenResponseClientRef)) {
/* 335 */       return (BeanMetadataElement)new RuntimeBeanReference(accessTokenResponseClientRef);
/*     */     }
/* 337 */     return 
/* 338 */       (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient")
/*     */       
/* 340 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   BeanDefinition getDefaultAuthorizedClientRepository() {
/* 344 */     return this.defaultAuthorizedClientRepository;
/*     */   }
/*     */   
/*     */   BeanDefinition getOAuth2AuthorizationRequestRedirectFilter() {
/* 348 */     return this.oauth2AuthorizationRequestRedirectFilter;
/*     */   }
/*     */   
/*     */   BeanDefinition getOAuth2LoginAuthenticationEntryPoint() {
/* 352 */     return this.oauth2LoginAuthenticationEntryPoint;
/*     */   }
/*     */   
/*     */   BeanDefinition getOAuth2LoginAuthenticationProvider() {
/* 356 */     return this.oauth2LoginAuthenticationProvider;
/*     */   }
/*     */   
/*     */   BeanDefinition getOAuth2LoginOidcAuthenticationProvider() {
/* 360 */     return this.oauth2LoginOidcAuthenticationProvider;
/*     */   }
/*     */   
/*     */   BeanDefinition getOAuth2LoginLinks() {
/* 364 */     return this.oauth2LoginLinks;
/*     */   }
/*     */   private Map<BeanDefinition, AuthenticationEntryPoint> getLoginEntryPoint(Element element) {
/*     */     ManagedMap<AbstractBeanDefinition, LoginUrlAuthenticationEntryPoint> managedMap;
/* 368 */     Map<BeanDefinition, AuthenticationEntryPoint> entryPoints = null;
/* 369 */     Element clientRegsElt = DomUtils.getChildElementByTagName(element.getOwnerDocument().getDocumentElement(), "client-registrations");
/*     */     
/* 371 */     if (clientRegsElt != null) {
/* 372 */       List<Element> clientRegList = DomUtils.getChildElementsByTagName(clientRegsElt, "client-registration");
/* 373 */       if (clientRegList.size() == 1) {
/*     */ 
/*     */ 
/*     */         
/* 377 */         AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class).addConstructorArgValue("/login").getBeanDefinition();
/*     */ 
/*     */ 
/*     */         
/* 381 */         AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class).addConstructorArgValue("/favicon.ico").getBeanDefinition();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 386 */         AbstractBeanDefinition abstractBeanDefinition3 = BeanDefinitionBuilder.rootBeanDefinition(EntryPointMatcherFactoryBean.class).addConstructorArgValue(abstractBeanDefinition1).addConstructorArgValue(abstractBeanDefinition2).getBeanDefinition();
/* 387 */         Element clientRegElt = clientRegList.get(0);
/* 388 */         managedMap = new ManagedMap();
/* 389 */         managedMap.put(abstractBeanDefinition3, new LoginUrlAuthenticationEntryPoint("/oauth2/authorization/" + clientRegElt
/* 390 */               .getAttribute("registration-id")));
/*     */       } 
/*     */     } 
/* 393 */     return (Map)managedMap;
/*     */   }
/*     */   
/*     */   private static class OidcAuthenticationRequestChecker
/*     */     implements AuthenticationProvider
/*     */   {
/*     */     public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 400 */       OAuth2LoginAuthenticationToken authorizationCodeAuthentication = (OAuth2LoginAuthenticationToken)authentication;
/*     */ 
/*     */ 
/*     */       
/* 404 */       if (!authorizationCodeAuthentication.getAuthorizationExchange().getAuthorizationRequest().getScopes().contains("openid")) {
/* 405 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 411 */       OAuth2Error oauth2Error = new OAuth2Error("oidc_provider_not_configured", "An OpenID Connect Authentication Provider has not been configured. Check to ensure you include the dependency 'spring-security-oauth2-jose'.", null);
/*     */ 
/*     */ 
/*     */       
/* 415 */       throw new OAuth2AuthenticationException(oauth2Error, oauth2Error.toString());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supports(Class<?> authentication) {
/* 420 */       return OAuth2LoginAuthenticationToken.class.isAssignableFrom(authentication);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class OAuth2LoginBeanConfig
/*     */     implements ApplicationContextAware
/*     */   {
/*     */     private ApplicationContext context;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setApplicationContext(ApplicationContext context) throws BeansException {
/* 434 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     Map<String, String> getLoginLinks() {
/* 439 */       Iterable<ClientRegistration> clientRegistrations = null;
/*     */       
/* 441 */       ClientRegistrationRepository clientRegistrationRepository = (ClientRegistrationRepository)this.context.getBean(ClientRegistrationRepository.class);
/* 442 */       ResolvableType type = ResolvableType.forInstance(clientRegistrationRepository).as(Iterable.class);
/* 443 */       if (type != ResolvableType.NONE && ClientRegistration.class.isAssignableFrom(type.resolveGenerics()[0])) {
/* 444 */         clientRegistrations = (Iterable<ClientRegistration>)clientRegistrationRepository;
/*     */       }
/* 446 */       if (clientRegistrations == null) {
/* 447 */         return Collections.emptyMap();
/*     */       }
/* 449 */       String authorizationRequestBaseUri = "/oauth2/authorization";
/* 450 */       Map<String, String> loginUrlToClientName = new HashMap<>();
/* 451 */       clientRegistrations.forEach(registration -> loginUrlToClientName.put(authorizationRequestBaseUri + "/" + authorizationRequestBaseUri, registration.getClientName()));
/*     */ 
/*     */       
/* 454 */       return loginUrlToClientName;
/*     */     }
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   static class EntryPointMatcherFactoryBean
/*     */     implements FactoryBean<RequestMatcher>
/*     */   {
/*     */     private final RequestMatcher entryPointMatcher;
/*     */     
/*     */     EntryPointMatcherFactoryBean(RequestMatcher loginPageMatcher, RequestMatcher faviconMatcher) {
/* 465 */       RequestMatcher defaultEntryPointMatcher = getAuthenticationEntryPointMatcher();
/* 466 */       AndRequestMatcher andRequestMatcher = new AndRequestMatcher(new RequestMatcher[] { (RequestMatcher)new OrRequestMatcher(new RequestMatcher[] { loginPageMatcher, faviconMatcher }), defaultEntryPointMatcher });
/*     */       
/* 468 */       NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
/*     */       
/* 470 */       this.entryPointMatcher = (RequestMatcher)new AndRequestMatcher(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)new NegatedRequestMatcher((RequestMatcher)andRequestMatcher) });
/*     */     }
/*     */ 
/*     */     
/*     */     private RequestMatcher getAuthenticationEntryPointMatcher() {
/* 475 */       HeaderContentNegotiationStrategy headerContentNegotiationStrategy = new HeaderContentNegotiationStrategy();
/* 476 */       MediaTypeRequestMatcher mediaMatcher = new MediaTypeRequestMatcher((ContentNegotiationStrategy)headerContentNegotiationStrategy, new MediaType[] { MediaType.APPLICATION_XHTML_XML, new MediaType("image", "*"), MediaType.TEXT_HTML, MediaType.TEXT_PLAIN });
/*     */ 
/*     */       
/* 479 */       mediaMatcher.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
/* 480 */       NegatedRequestMatcher negatedRequestMatcher = new NegatedRequestMatcher((RequestMatcher)new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
/*     */       
/* 482 */       return (RequestMatcher)new AndRequestMatcher(Arrays.asList(new RequestMatcher[] { (RequestMatcher)negatedRequestMatcher, (RequestMatcher)mediaMatcher }));
/*     */     }
/*     */ 
/*     */     
/*     */     public RequestMatcher getObject() {
/* 487 */       return this.entryPointMatcher;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 492 */       return RequestMatcher.class;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2LoginBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */