/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.web.access.CompositeAccessDeniedHandler;
/*     */ import org.springframework.security.web.access.DelegatingAccessDeniedHandler;
/*     */ import org.springframework.security.web.access.ObservationMarkingAccessDeniedHandler;
/*     */ import org.springframework.security.web.csrf.CsrfAuthenticationStrategy;
/*     */ import org.springframework.security.web.csrf.CsrfFilter;
/*     */ import org.springframework.security.web.csrf.CsrfLogoutHandler;
/*     */ import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
/*     */ import org.springframework.security.web.csrf.MissingCsrfTokenException;
/*     */ import org.springframework.security.web.servlet.support.csrf.CsrfRequestDataValueProcessor;
/*     */ import org.springframework.security.web.session.InvalidSessionAccessDeniedHandler;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.OrRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsrfBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String REQUEST_DATA_VALUE_PROCESSOR = "requestDataValueProcessor";
/*     */   private static final String ATT_MATCHER = "request-matcher-ref";
/*     */   private static final String ATT_REPOSITORY = "token-repository-ref";
/*     */   private static final String ATT_REQUEST_HANDLER = "request-handler-ref";
/*     */   private static final boolean webMvcPresent;
/*     */   private String csrfRepositoryRef;
/*     */   private BeanDefinition csrfFilter;
/*     */   private String requestMatcherRef;
/*     */   private String requestHandlerRef;
/*     */   private BeanMetadataElement observationRegistry;
/*     */   
/*     */   static {
/*  77 */     ClassLoader classLoader = CsrfBeanDefinitionParser.class.getClassLoader();
/*  78 */     webMvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.DispatcherServlet", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*  93 */     boolean disabled = (element != null && "true".equals(element.getAttribute("disabled")));
/*  94 */     if (disabled) {
/*  95 */       return null;
/*     */     }
/*  97 */     if (webMvcPresent && 
/*  98 */       !pc.getRegistry().containsBeanDefinition("requestDataValueProcessor")) {
/*  99 */       RootBeanDefinition beanDefinition = new RootBeanDefinition(CsrfRequestDataValueProcessor.class);
/* 100 */       BeanComponentDefinition componentDefinition = new BeanComponentDefinition((BeanDefinition)beanDefinition, "requestDataValueProcessor");
/*     */       
/* 102 */       pc.registerBeanComponent(componentDefinition);
/*     */     } 
/*     */     
/* 105 */     if (element != null) {
/* 106 */       this.csrfRepositoryRef = element.getAttribute("token-repository-ref");
/* 107 */       this.requestMatcherRef = element.getAttribute("request-matcher-ref");
/* 108 */       this.requestHandlerRef = element.getAttribute("request-handler-ref");
/*     */     } 
/* 110 */     if (!StringUtils.hasText(this.csrfRepositoryRef)) {
/*     */       
/* 112 */       BeanDefinitionBuilder httpSessionCsrfTokenRepository = BeanDefinitionBuilder.rootBeanDefinition(HttpSessionCsrfTokenRepository.class);
/* 113 */       this
/* 114 */         .csrfRepositoryRef = pc.getReaderContext().generateBeanName((BeanDefinition)httpSessionCsrfTokenRepository.getBeanDefinition());
/* 115 */       pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)httpSessionCsrfTokenRepository.getBeanDefinition(), this.csrfRepositoryRef));
/*     */     } 
/*     */     
/* 118 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(CsrfFilter.class);
/* 119 */     builder.addConstructorArgReference(this.csrfRepositoryRef);
/* 120 */     if (StringUtils.hasText(this.requestMatcherRef)) {
/* 121 */       builder.addPropertyReference("requireCsrfProtectionMatcher", this.requestMatcherRef);
/*     */     }
/* 123 */     if (StringUtils.hasText(this.requestHandlerRef)) {
/* 124 */       builder.addPropertyReference("requestHandler", this.requestHandlerRef);
/*     */     }
/* 126 */     this.csrfFilter = (BeanDefinition)builder.getBeanDefinition();
/* 127 */     return this.csrfFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initAccessDeniedHandler(BeanDefinition invalidSessionStrategy, BeanMetadataElement defaultDeniedHandler) {
/* 136 */     BeanMetadataElement accessDeniedHandler = createAccessDeniedHandler(invalidSessionStrategy, defaultDeniedHandler);
/*     */     
/* 138 */     this.csrfFilter.getPropertyValues().addPropertyValue("accessDeniedHandler", accessDeniedHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanMetadataElement createAccessDeniedHandler(BeanDefinition invalidSessionStrategy, BeanMetadataElement defaultDeniedHandler) {
/* 157 */     if (invalidSessionStrategy == null) {
/* 158 */       return defaultDeniedHandler;
/*     */     }
/* 160 */     ManagedMap<Class<? extends AccessDeniedException>, BeanDefinition> handlers = new ManagedMap();
/*     */     
/* 162 */     BeanDefinitionBuilder invalidSessionHandlerBldr = BeanDefinitionBuilder.rootBeanDefinition(InvalidSessionAccessDeniedHandler.class);
/* 163 */     invalidSessionHandlerBldr.addConstructorArgValue(invalidSessionStrategy);
/* 164 */     handlers.put(MissingCsrfTokenException.class, invalidSessionHandlerBldr.getBeanDefinition());
/*     */     
/* 166 */     BeanDefinitionBuilder deniedBldr = BeanDefinitionBuilder.rootBeanDefinition(DelegatingAccessDeniedHandler.class);
/* 167 */     deniedBldr.addConstructorArgValue(handlers);
/* 168 */     deniedBldr.addConstructorArgValue(defaultDeniedHandler);
/* 169 */     AbstractBeanDefinition abstractBeanDefinition1 = deniedBldr.getBeanDefinition();
/* 170 */     ManagedList compositeList = new ManagedList();
/*     */     
/* 172 */     BeanDefinitionBuilder compositeBldr = BeanDefinitionBuilder.rootBeanDefinition(CompositeAccessDeniedHandler.class);
/*     */ 
/*     */     
/* 175 */     AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(ObservationMarkingAccessDeniedHandler.class).addConstructorArgValue(this.observationRegistry).getBeanDefinition();
/* 176 */     compositeList.add(abstractBeanDefinition1);
/* 177 */     compositeList.add(abstractBeanDefinition2);
/* 178 */     compositeBldr.addConstructorArgValue(compositeList);
/* 179 */     return (BeanMetadataElement)compositeBldr.getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   BeanDefinition getCsrfAuthenticationStrategy() {
/* 184 */     BeanDefinitionBuilder csrfAuthenticationStrategy = BeanDefinitionBuilder.rootBeanDefinition(CsrfAuthenticationStrategy.class);
/* 185 */     csrfAuthenticationStrategy.addConstructorArgReference(this.csrfRepositoryRef);
/* 186 */     if (StringUtils.hasText(this.requestHandlerRef)) {
/* 187 */       csrfAuthenticationStrategy.addPropertyReference("requestHandler", this.requestHandlerRef);
/*     */     }
/* 189 */     return (BeanDefinition)csrfAuthenticationStrategy.getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   BeanDefinition getCsrfLogoutHandler() {
/* 194 */     BeanDefinitionBuilder csrfAuthenticationStrategy = BeanDefinitionBuilder.rootBeanDefinition(CsrfLogoutHandler.class);
/* 195 */     csrfAuthenticationStrategy.addConstructorArgReference(this.csrfRepositoryRef);
/* 196 */     return (BeanDefinition)csrfAuthenticationStrategy.getBeanDefinition();
/*     */   }
/*     */   
/*     */   void setIgnoreCsrfRequestMatchers(List<BeanDefinition> requestMatchers) {
/* 200 */     if (!requestMatchers.isEmpty()) {
/*     */ 
/*     */       
/* 203 */       BeanMetadataElement requestMatcher = !StringUtils.hasText(this.requestMatcherRef) ? (BeanMetadataElement)new RootBeanDefinition(DefaultRequiresCsrfMatcher.class) : (BeanMetadataElement)new RuntimeBeanReference(this.requestMatcherRef);
/* 204 */       BeanDefinitionBuilder and = BeanDefinitionBuilder.rootBeanDefinition(AndRequestMatcher.class);
/* 205 */       BeanDefinitionBuilder negated = BeanDefinitionBuilder.rootBeanDefinition(NegatedRequestMatcher.class);
/* 206 */       BeanDefinitionBuilder or = BeanDefinitionBuilder.rootBeanDefinition(OrRequestMatcher.class);
/* 207 */       or.addConstructorArgValue(requestMatchers);
/* 208 */       negated.addConstructorArgValue(or.getBeanDefinition());
/* 209 */       ManagedList<BeanMetadataElement> managedList = new ManagedList();
/* 210 */       managedList.add(requestMatcher);
/* 211 */       managedList.add(negated.getBeanDefinition());
/* 212 */       and.addConstructorArgValue(managedList);
/* 213 */       this.csrfFilter.getPropertyValues().add("requireCsrfProtectionMatcher", and.getBeanDefinition());
/*     */     } 
/*     */   }
/*     */   
/*     */   void setObservationRegistry(BeanMetadataElement observationRegistry) {
/* 218 */     this.observationRegistry = observationRegistry;
/*     */   }
/*     */   
/*     */   private static final class DefaultRequiresCsrfMatcher
/*     */     implements RequestMatcher {
/* 223 */     private final HashSet<String> allowedMethods = new HashSet<>(Arrays.asList(new String[] { "GET", "HEAD", "TRACE", "OPTIONS" }));
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 227 */       return !this.allowedMethods.contains(request.getMethod());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\CsrfBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */