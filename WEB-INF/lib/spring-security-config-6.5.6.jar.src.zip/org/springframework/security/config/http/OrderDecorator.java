/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeanMetadataElement;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OrderDecorator
/*    */   implements Ordered
/*    */ {
/*    */   final BeanMetadataElement bean;
/*    */   final int order;
/*    */   
/*    */   OrderDecorator(BeanMetadataElement bean, SecurityFilters filterOrder) {
/* 34 */     this.bean = bean;
/* 35 */     this.order = filterOrder.getOrder();
/*    */   }
/*    */   
/*    */   OrderDecorator(BeanMetadataElement bean, int order) {
/* 39 */     this.bean = bean;
/* 40 */     this.order = order;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 45 */     return this.order;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return String.valueOf(this.bean) + ", order = " + String.valueOf(this.bean);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OrderDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */