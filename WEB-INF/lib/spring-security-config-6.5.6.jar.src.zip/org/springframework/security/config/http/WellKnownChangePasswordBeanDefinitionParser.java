/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.web.RequestMatcherRedirectFilter;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WellKnownChangePasswordBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   private static final String WELL_KNOWN_CHANGE_PASSWORD_PATTERN = "/.well-known/change-password";
/*    */   private static final String DEFAULT_CHANGE_PASSWORD_PAGE = "/change-password";
/*    */   private static final String ATT_CHANGE_PASSWORD_PAGE = "change-password-page";
/*    */   
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 49 */     AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class).addConstructorArgValue("/.well-known/change-password").getBeanDefinition();
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 54 */     AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherRedirectFilter.class).addConstructorArgValue(abstractBeanDefinition1).addConstructorArgValue(getChangePasswordPage(element)).getBeanDefinition();
/* 55 */     parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)abstractBeanDefinition2);
/* 56 */     return (BeanDefinition)abstractBeanDefinition2;
/*    */   }
/*    */   
/*    */   private String getChangePasswordPage(Element element) {
/* 60 */     String changePasswordPage = element.getAttribute("change-password-page");
/* 61 */     return StringUtils.hasText(changePasswordPage) ? changePasswordPage : "/change-password";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\WellKnownChangePasswordBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */