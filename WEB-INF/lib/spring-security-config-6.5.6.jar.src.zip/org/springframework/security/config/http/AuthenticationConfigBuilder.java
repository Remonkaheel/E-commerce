/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.authentication.AnonymousAuthenticationProvider;
/*     */ import org.springframework.security.authentication.RememberMeAuthenticationProvider;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.mapping.SimpleAttributes2GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.core.authority.mapping.SimpleMappableAttributesRetriever;
/*     */ import org.springframework.security.web.access.AccessDeniedHandlerImpl;
/*     */ import org.springframework.security.web.access.ExceptionTranslationFilter;
/*     */ import org.springframework.security.web.access.RequestMatcherDelegatingAccessDeniedHandler;
/*     */ import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.DelegatingAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
/*     */ import org.springframework.security.web.authentication.preauth.PreAuthenticatedGrantedAuthoritiesUserDetailsService;
/*     */ import org.springframework.security.web.authentication.preauth.j2ee.J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource;
/*     */ import org.springframework.security.web.authentication.preauth.j2ee.J2eePreAuthenticatedProcessingFilter;
/*     */ import org.springframework.security.web.authentication.preauth.x509.SubjectDnX509PrincipalExtractor;
/*     */ import org.springframework.security.web.authentication.preauth.x509.X509AuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLoginPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultLogoutPageGeneratingFilter;
/*     */ import org.springframework.security.web.authentication.ui.DefaultResourcesFilter;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;
/*     */ import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
/*     */ import org.springframework.security.web.csrf.CsrfToken;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AuthenticationConfigBuilder
/*     */ {
/*  82 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private static final boolean webMvcPresent;
/*     */   
/*     */   private static final String ATT_REALM = "realm";
/*     */   
/*     */   private static final String DEF_REALM = "Realm";
/*     */   
/*     */   static final String AUTHENTICATION_PROCESSING_FILTER_CLASS = "org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter";
/*     */   
/*     */   static final String ATT_AUTH_DETAILS_SOURCE_REF = "authentication-details-source-ref";
/*     */   
/*     */   private static final String ATT_AUTO_CONFIG = "auto-config";
/*     */   
/*     */   private static final String ATT_ACCESS_DENIED_ERROR_PAGE = "error-page";
/*     */   
/*     */   private static final String ATT_ENTRY_POINT_REF = "entry-point-ref";
/*     */   
/*     */   private static final String ATT_USER_SERVICE_REF = "user-service-ref";
/*     */   
/*     */   private static final String ATT_KEY = "key";
/*     */   
/*     */   private static final String ATT_MAPPABLE_ROLES = "mappable-roles";
/*     */   
/*     */   private final Element httpElt;
/*     */   
/*     */   private final ParserContext pc;
/*     */   
/*     */   private final boolean autoConfig;
/*     */   
/*     */   private final boolean allowSessionCreation;
/*     */   
/*     */   private RootBeanDefinition anonymousFilter;
/*     */   
/*     */   private BeanReference anonymousProviderRef;
/*     */   
/*     */   private BeanDefinition rememberMeFilter;
/*     */   
/*     */   private String rememberMeServicesId;
/*     */   
/*     */   private BeanReference rememberMeProviderRef;
/*     */   
/*     */   private BeanDefinition basicFilter;
/*     */   
/*     */   private RuntimeBeanReference basicEntryPoint;
/*     */   
/*     */   private BeanDefinition formEntryPoint;
/*     */   
/* 130 */   private String formFilterId = null;
/*     */ 
/*     */   
/*     */   private BeanDefinition x509Filter;
/*     */   
/*     */   private BeanReference x509ProviderRef;
/*     */   
/*     */   private BeanDefinition jeeFilter;
/*     */   
/*     */   private BeanReference jeeProviderRef;
/*     */   
/*     */   private RootBeanDefinition preAuthEntryPoint;
/*     */   
/*     */   private BeanMetadataElement mainEntryPoint;
/*     */   
/*     */   private BeanMetadataElement accessDeniedHandler;
/*     */   
/*     */   private BeanDefinition bearerTokenAuthenticationFilter;
/*     */   
/*     */   private BeanDefinition logoutFilter;
/*     */   
/*     */   private ManagedList logoutHandlers;
/*     */   
/*     */   private BeanMetadataElement logoutSuccessHandler;
/*     */   
/*     */   private BeanDefinition loginPageGenerationFilter;
/*     */   
/*     */   private BeanDefinition logoutPageGenerationFilter;
/*     */   
/*     */   private BeanDefinition defaultResourcesFilter;
/*     */   
/*     */   private BeanDefinition etf;
/*     */   
/*     */   private final BeanReference requestCache;
/*     */   
/*     */   private final BeanReference portMapper;
/*     */   
/*     */   private final BeanReference portResolver;
/*     */   
/*     */   private final BeanMetadataElement csrfLogoutHandler;
/*     */   
/*     */   private String loginProcessingUrl;
/*     */   
/*     */   private String formLoginPage;
/*     */   
/*     */   private boolean oauth2LoginEnabled;
/*     */   
/*     */   private boolean defaultAuthorizedClientRepositoryRegistered;
/*     */   
/*     */   private String oauth2LoginFilterId;
/*     */   
/*     */   private BeanDefinition oauth2AuthorizationRequestRedirectFilter;
/*     */   
/*     */   private BeanDefinition oauth2LoginEntryPoint;
/*     */   
/*     */   private BeanReference oauth2LoginAuthenticationProviderRef;
/*     */   
/*     */   private BeanReference oauth2LoginOidcAuthenticationProviderRef;
/*     */   
/*     */   private BeanDefinition oauth2LoginLinks;
/*     */   
/*     */   private BeanDefinition saml2AuthenticationUrlToProviderName;
/*     */   
/*     */   private BeanDefinition saml2AuthorizationRequestFilter;
/*     */   
/*     */   private String saml2AuthenticationFilterId;
/*     */   
/*     */   private String saml2AuthenticationRequestFilterId;
/*     */   
/*     */   private String saml2LogoutFilterId;
/*     */   
/*     */   private String saml2LogoutRequestFilterId;
/*     */   
/*     */   private String saml2LogoutResponseFilterId;
/*     */   
/*     */   private boolean oauth2ClientEnabled;
/*     */   
/*     */   private BeanDefinition authorizationRequestRedirectFilter;
/*     */   
/*     */   private BeanDefinition authorizationCodeGrantFilter;
/*     */   
/*     */   private BeanReference authorizationCodeAuthenticationProviderRef;
/*     */   
/* 213 */   private final List<BeanReference> authenticationProviders = (List<BeanReference>)new ManagedList();
/*     */   
/* 215 */   private final Map<BeanDefinition, BeanMetadataElement> defaultDeniedHandlerMappings = (Map<BeanDefinition, BeanMetadataElement>)new ManagedMap();
/*     */   
/* 217 */   private final Map<BeanDefinition, BeanMetadataElement> defaultEntryPointMappings = (Map<BeanDefinition, BeanMetadataElement>)new ManagedMap();
/*     */   
/* 219 */   private final List<BeanDefinition> csrfIgnoreRequestMatchers = (List<BeanDefinition>)new ManagedList();
/*     */   
/*     */   static {
/* 222 */     ClassLoader classLoader = AuthenticationConfigBuilder.class.getClassLoader();
/* 223 */     webMvcPresent = ClassUtils.isPresent("org.springframework.web.servlet.DispatcherServlet", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AuthenticationConfigBuilder(Element element, boolean forceAutoConfig, ParserContext pc, SessionCreationPolicy sessionPolicy, BeanReference requestCache, BeanReference authenticationManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef, BeanReference authenticationFilterSecurityContextRepositoryRef, BeanReference sessionStrategy, BeanReference portMapper, BeanReference portResolver, BeanMetadataElement csrfLogoutHandler) {
/* 231 */     this.httpElt = element;
/* 232 */     this.pc = pc;
/* 233 */     this.requestCache = requestCache;
/* 234 */     this.autoConfig = forceAutoConfig | "true".equals(element.getAttribute("auto-config"));
/* 235 */     this.allowSessionCreation = (sessionPolicy != SessionCreationPolicy.NEVER && sessionPolicy != SessionCreationPolicy.STATELESS);
/*     */     
/* 237 */     this.portMapper = portMapper;
/* 238 */     this.portResolver = portResolver;
/* 239 */     this.csrfLogoutHandler = csrfLogoutHandler;
/* 240 */     createAnonymousFilter(authenticationFilterSecurityContextHolderStrategyRef);
/* 241 */     createRememberMeFilter(authenticationManager, authenticationFilterSecurityContextHolderStrategyRef);
/* 242 */     createBasicFilter(authenticationManager, authenticationFilterSecurityContextHolderStrategyRef);
/* 243 */     createBearerTokenAuthenticationFilter(authenticationManager, authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 245 */     createFormLoginFilter(sessionStrategy, authenticationManager, authenticationFilterSecurityContextHolderStrategyRef, authenticationFilterSecurityContextRepositoryRef);
/*     */     
/* 247 */     createOAuth2ClientFilters(sessionStrategy, requestCache, authenticationManager, authenticationFilterSecurityContextRepositoryRef, authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 249 */     createSaml2LoginFilter(authenticationManager, authenticationFilterSecurityContextRepositoryRef);
/* 250 */     createX509Filter(authenticationManager, authenticationFilterSecurityContextHolderStrategyRef);
/* 251 */     createJeeFilter(authenticationManager, authenticationFilterSecurityContextHolderStrategyRef);
/* 252 */     createLogoutFilter(authenticationFilterSecurityContextHolderStrategyRef);
/* 253 */     createSaml2LogoutFilter(authenticationFilterSecurityContextHolderStrategyRef);
/* 254 */     createLoginPageFilterIfNeeded();
/* 255 */     createUserDetailsServiceFactory();
/* 256 */     createExceptionTranslationFilter(authenticationFilterSecurityContextHolderStrategyRef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void createRememberMeFilter(BeanReference authenticationManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 263 */     Element rememberMeElt = DomUtils.getChildElementByTagName(this.httpElt, "remember-me");
/* 264 */     if (rememberMeElt != null) {
/* 265 */       String key = rememberMeElt.getAttribute("key");
/* 266 */       if (!StringUtils.hasText(key)) {
/* 267 */         key = createKey();
/*     */       }
/* 269 */       RememberMeBeanDefinitionParser rememberMeParser = new RememberMeBeanDefinitionParser(key, authenticationManager, authenticationFilterSecurityContextHolderStrategyRef);
/*     */       
/* 271 */       this.rememberMeFilter = rememberMeParser.parse(rememberMeElt, this.pc);
/* 272 */       this.rememberMeServicesId = rememberMeParser.getRememberMeServicesId();
/* 273 */       createRememberMeProvider(key);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void createRememberMeProvider(String key) {
/* 278 */     RootBeanDefinition provider = new RootBeanDefinition(RememberMeAuthenticationProvider.class);
/* 279 */     provider.setSource(this.rememberMeFilter.getSource());
/* 280 */     provider.getConstructorArgumentValues().addGenericArgumentValue(key);
/* 281 */     String id = this.pc.getReaderContext().generateBeanName((BeanDefinition)provider);
/* 282 */     this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)provider, id));
/* 283 */     this.rememberMeProviderRef = (BeanReference)new RuntimeBeanReference(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void createFormLoginFilter(BeanReference sessionStrategy, BeanReference authManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef, BeanReference authenticationFilterSecurityContextRepositoryRef) {
/* 289 */     Element formLoginElt = DomUtils.getChildElementByTagName(this.httpElt, "form-login");
/* 290 */     RootBeanDefinition formFilter = null;
/* 291 */     if (formLoginElt != null || this.autoConfig) {
/* 292 */       FormLoginBeanDefinitionParser parser = new FormLoginBeanDefinitionParser("/login", "POST", "org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter", this.requestCache, sessionStrategy, this.allowSessionCreation, this.portMapper, this.portResolver);
/*     */ 
/*     */       
/* 295 */       parser.parse(formLoginElt, this.pc);
/* 296 */       formFilter = parser.getFilterBean();
/* 297 */       this.formEntryPoint = (BeanDefinition)parser.getEntryPointBean();
/* 298 */       this.loginProcessingUrl = parser.getLoginProcessingUrl();
/* 299 */       this.formLoginPage = parser.getLoginPage();
/*     */     } 
/* 301 */     if (formFilter != null) {
/* 302 */       formFilter.getPropertyValues().addPropertyValue("allowSessionCreation", Boolean.valueOf(this.allowSessionCreation));
/* 303 */       formFilter.getPropertyValues().addPropertyValue("authenticationManager", authManager);
/* 304 */       if (authenticationFilterSecurityContextRepositoryRef != null) {
/* 305 */         formFilter.getPropertyValues()
/* 306 */           .addPropertyValue("securityContextRepository", authenticationFilterSecurityContextRepositoryRef);
/*     */       }
/* 308 */       formFilter.getPropertyValues()
/* 309 */         .addPropertyValue("securityContextHolderStrategy", authenticationFilterSecurityContextHolderStrategyRef);
/*     */ 
/*     */       
/* 312 */       this.formFilterId = this.pc.getReaderContext().generateBeanName((BeanDefinition)formFilter);
/* 313 */       this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)formFilter, this.formFilterId));
/* 314 */       injectRememberMeServicesRef(formFilter, this.rememberMeServicesId);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void createOAuth2ClientFilters(BeanReference sessionStrategy, BeanReference requestCache, BeanReference authenticationManager, BeanReference authenticationFilterSecurityContextRepositoryRef, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/* 321 */     createOAuth2LoginFilter(sessionStrategy, authenticationManager, authenticationFilterSecurityContextRepositoryRef, authenticationFilterSecurityContextHolderStrategy);
/*     */     
/* 323 */     createOAuth2ClientFilter(requestCache, authenticationManager, authenticationFilterSecurityContextRepositoryRef, authenticationFilterSecurityContextHolderStrategy);
/*     */     
/* 325 */     registerOAuth2ClientPostProcessors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void createOAuth2LoginFilter(BeanReference sessionStrategy, BeanReference authManager, BeanReference authenticationFilterSecurityContextRepositoryRef, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/* 331 */     Element oauth2LoginElt = DomUtils.getChildElementByTagName(this.httpElt, "oauth2-login");
/* 332 */     if (oauth2LoginElt == null) {
/*     */       return;
/*     */     }
/* 335 */     this.oauth2LoginEnabled = true;
/* 336 */     OAuth2LoginBeanDefinitionParser parser = new OAuth2LoginBeanDefinitionParser(this.requestCache, this.portMapper, this.portResolver, sessionStrategy, this.allowSessionCreation, authenticationFilterSecurityContextHolderStrategy);
/*     */ 
/*     */     
/* 339 */     BeanDefinition oauth2LoginFilterBean = parser.parse(oauth2LoginElt, this.pc);
/* 340 */     BeanDefinition defaultAuthorizedClientRepository = parser.getDefaultAuthorizedClientRepository();
/* 341 */     registerDefaultAuthorizedClientRepositoryIfNecessary(defaultAuthorizedClientRepository);
/* 342 */     oauth2LoginFilterBean.getPropertyValues().addPropertyValue("authenticationManager", authManager);
/* 343 */     if (authenticationFilterSecurityContextRepositoryRef != null) {
/* 344 */       oauth2LoginFilterBean.getPropertyValues()
/* 345 */         .addPropertyValue("securityContextRepository", authenticationFilterSecurityContextRepositoryRef);
/*     */     }
/*     */ 
/*     */     
/* 349 */     BeanDefinition oauth2LoginAuthProvider = parser.getOAuth2LoginAuthenticationProvider();
/* 350 */     this.oauth2AuthorizationRequestRedirectFilter = parser.getOAuth2AuthorizationRequestRedirectFilter();
/* 351 */     this.oauth2LoginEntryPoint = parser.getOAuth2LoginAuthenticationEntryPoint();
/*     */ 
/*     */     
/* 354 */     String oauth2LoginAuthProviderId = this.pc.getReaderContext().generateBeanName(oauth2LoginAuthProvider);
/* 355 */     this.oauth2LoginFilterId = this.pc.getReaderContext().generateBeanName(oauth2LoginFilterBean);
/*     */     
/* 357 */     String oauth2AuthorizationRequestRedirectFilterId = this.pc.getReaderContext().generateBeanName(this.oauth2AuthorizationRequestRedirectFilter);
/* 358 */     this.oauth2LoginLinks = parser.getOAuth2LoginLinks();
/*     */ 
/*     */     
/* 361 */     this.pc.registerBeanComponent(new BeanComponentDefinition(oauth2LoginFilterBean, this.oauth2LoginFilterId));
/* 362 */     this.pc.registerBeanComponent(new BeanComponentDefinition(this.oauth2AuthorizationRequestRedirectFilter, oauth2AuthorizationRequestRedirectFilterId));
/*     */     
/* 364 */     this.pc.registerBeanComponent(new BeanComponentDefinition(oauth2LoginAuthProvider, oauth2LoginAuthProviderId));
/*     */     
/* 366 */     this.oauth2LoginAuthenticationProviderRef = (BeanReference)new RuntimeBeanReference(oauth2LoginAuthProviderId);
/*     */ 
/*     */     
/* 369 */     BeanDefinition oauth2LoginOidcAuthProvider = parser.getOAuth2LoginOidcAuthenticationProvider();
/* 370 */     String oauth2LoginOidcAuthProviderId = this.pc.getReaderContext().generateBeanName(oauth2LoginOidcAuthProvider);
/* 371 */     this.pc.registerBeanComponent(new BeanComponentDefinition(oauth2LoginOidcAuthProvider, oauth2LoginOidcAuthProviderId));
/*     */     
/* 373 */     this.oauth2LoginOidcAuthenticationProviderRef = (BeanReference)new RuntimeBeanReference(oauth2LoginOidcAuthProviderId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void createOAuth2ClientFilter(BeanReference requestCache, BeanReference authenticationManager, BeanReference authenticationFilterSecurityContextRepositoryRef, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/* 379 */     Element oauth2ClientElt = DomUtils.getChildElementByTagName(this.httpElt, "oauth2-client");
/* 380 */     if (oauth2ClientElt == null) {
/*     */       return;
/*     */     }
/* 383 */     this.oauth2ClientEnabled = true;
/* 384 */     OAuth2ClientBeanDefinitionParser parser = new OAuth2ClientBeanDefinitionParser(requestCache, authenticationManager, authenticationFilterSecurityContextRepositoryRef, authenticationFilterSecurityContextHolderStrategy);
/*     */ 
/*     */     
/* 387 */     parser.parse(oauth2ClientElt, this.pc);
/* 388 */     BeanDefinition defaultAuthorizedClientRepository = parser.getDefaultAuthorizedClientRepository();
/* 389 */     registerDefaultAuthorizedClientRepositoryIfNecessary(defaultAuthorizedClientRepository);
/* 390 */     this.authorizationRequestRedirectFilter = parser.getAuthorizationRequestRedirectFilter();
/*     */     
/* 392 */     String authorizationRequestRedirectFilterId = this.pc.getReaderContext().generateBeanName(this.authorizationRequestRedirectFilter);
/* 393 */     this.pc.registerBeanComponent(new BeanComponentDefinition(this.authorizationRequestRedirectFilter, authorizationRequestRedirectFilterId));
/*     */     
/* 395 */     this.authorizationCodeGrantFilter = parser.getAuthorizationCodeGrantFilter();
/*     */     
/* 397 */     String authorizationCodeGrantFilterId = this.pc.getReaderContext().generateBeanName(this.authorizationCodeGrantFilter);
/* 398 */     this.pc.registerBeanComponent(new BeanComponentDefinition(this.authorizationCodeGrantFilter, authorizationCodeGrantFilterId));
/*     */     
/* 400 */     BeanDefinition authorizationCodeAuthenticationProvider = parser.getAuthorizationCodeAuthenticationProvider();
/*     */     
/* 402 */     String authorizationCodeAuthenticationProviderId = this.pc.getReaderContext().generateBeanName(authorizationCodeAuthenticationProvider);
/* 403 */     this.pc.registerBeanComponent(new BeanComponentDefinition(authorizationCodeAuthenticationProvider, authorizationCodeAuthenticationProviderId));
/*     */     
/* 405 */     this.authorizationCodeAuthenticationProviderRef = (BeanReference)new RuntimeBeanReference(authorizationCodeAuthenticationProviderId);
/*     */   }
/*     */ 
/*     */   
/*     */   void registerDefaultAuthorizedClientRepositoryIfNecessary(BeanDefinition defaultAuthorizedClientRepository) {
/* 410 */     if (!this.defaultAuthorizedClientRepositoryRegistered && defaultAuthorizedClientRepository != null) {
/*     */       
/* 412 */       String authorizedClientRepositoryId = this.pc.getReaderContext().generateBeanName(defaultAuthorizedClientRepository);
/* 413 */       this.pc.registerBeanComponent(new BeanComponentDefinition(defaultAuthorizedClientRepository, authorizedClientRepositoryId));
/*     */       
/* 415 */       this.defaultAuthorizedClientRepositoryRegistered = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void registerOAuth2ClientPostProcessors() {
/* 420 */     if (!this.oauth2LoginEnabled && !this.oauth2ClientEnabled) {
/*     */       return;
/*     */     }
/* 423 */     if (webMvcPresent) {
/* 424 */       this.pc.getReaderContext()
/* 425 */         .registerWithGeneratedName((BeanDefinition)new RootBeanDefinition(OAuth2ClientWebMvcSecurityPostProcessor.class));
/*     */     }
/* 427 */     this.pc.getReaderContext()
/* 428 */       .getRegistry()
/* 429 */       .registerBeanDefinition("authorizedClientManagerRegistrar", (BeanDefinition)new RootBeanDefinition(OAuth2AuthorizedClientManagerRegistrar.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void createSaml2LoginFilter(BeanReference authenticationManager, BeanReference authenticationFilterSecurityContextRepositoryRef) {
/* 435 */     Element saml2LoginElt = DomUtils.getChildElementByTagName(this.httpElt, "saml2-login");
/* 436 */     if (saml2LoginElt == null) {
/*     */       return;
/*     */     }
/* 439 */     Saml2LoginBeanDefinitionParser parser = new Saml2LoginBeanDefinitionParser(this.csrfIgnoreRequestMatchers, this.portMapper, this.portResolver, this.requestCache, this.allowSessionCreation, authenticationManager, authenticationFilterSecurityContextRepositoryRef, this.authenticationProviders, this.defaultEntryPointMappings);
/*     */ 
/*     */ 
/*     */     
/* 443 */     BeanDefinition saml2WebSsoAuthenticationFilter = parser.parse(saml2LoginElt, this.pc);
/* 444 */     this.saml2AuthorizationRequestFilter = parser.getSaml2WebSsoAuthenticationRequestFilter();
/*     */     
/* 446 */     this.saml2AuthenticationFilterId = this.pc.getReaderContext().generateBeanName(saml2WebSsoAuthenticationFilter);
/* 447 */     this
/* 448 */       .saml2AuthenticationRequestFilterId = this.pc.getReaderContext().generateBeanName(this.saml2AuthorizationRequestFilter);
/* 449 */     this.saml2AuthenticationUrlToProviderName = parser.getSaml2AuthenticationUrlToProviderName();
/*     */ 
/*     */     
/* 452 */     this.pc.registerBeanComponent(new BeanComponentDefinition(saml2WebSsoAuthenticationFilter, this.saml2AuthenticationFilterId));
/*     */     
/* 454 */     this.pc.registerBeanComponent(new BeanComponentDefinition(this.saml2AuthorizationRequestFilter, this.saml2AuthenticationRequestFilterId));
/*     */   }
/*     */ 
/*     */   
/*     */   private void injectRememberMeServicesRef(RootBeanDefinition bean, String rememberMeServicesId) {
/* 459 */     if (rememberMeServicesId != null) {
/* 460 */       bean.getPropertyValues()
/* 461 */         .addPropertyValue("rememberMeServices", new RuntimeBeanReference(rememberMeServicesId));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void createBasicFilter(BeanReference authManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 467 */     Element basicAuthElt = DomUtils.getChildElementByTagName(this.httpElt, "http-basic");
/* 468 */     if (basicAuthElt == null && !this.autoConfig) {
/*     */       return;
/*     */     }
/*     */     
/* 472 */     String realm = this.httpElt.getAttribute("realm");
/* 473 */     if (!StringUtils.hasText(realm)) {
/* 474 */       realm = "Realm";
/*     */     }
/* 476 */     BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(BasicAuthenticationFilter.class);
/*     */     
/* 478 */     if (basicAuthElt != null) {
/* 479 */       if (StringUtils.hasText(basicAuthElt.getAttribute("entry-point-ref"))) {
/* 480 */         this.basicEntryPoint = new RuntimeBeanReference(basicAuthElt.getAttribute("entry-point-ref"));
/*     */       }
/* 482 */       injectAuthenticationDetailsSource(basicAuthElt, filterBuilder);
/*     */     } 
/* 484 */     if (this.basicEntryPoint == null) {
/* 485 */       RootBeanDefinition entryPoint = new RootBeanDefinition(BasicAuthenticationEntryPoint.class);
/* 486 */       entryPoint.setSource(this.pc.extractSource(this.httpElt));
/* 487 */       entryPoint.getPropertyValues().addPropertyValue("realmName", realm);
/* 488 */       String entryPointId = this.pc.getReaderContext().generateBeanName((BeanDefinition)entryPoint);
/* 489 */       this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)entryPoint, entryPointId));
/* 490 */       this.basicEntryPoint = new RuntimeBeanReference(entryPointId);
/*     */     } 
/* 492 */     filterBuilder.addConstructorArgValue(authManager);
/* 493 */     filterBuilder.addConstructorArgValue(this.basicEntryPoint);
/* 494 */     filterBuilder.addPropertyValue("securityContextHolderStrategy", authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 496 */     this.basicFilter = (BeanDefinition)filterBuilder.getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   void createBearerTokenAuthenticationFilter(BeanReference authManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 501 */     Element resourceServerElt = DomUtils.getChildElementByTagName(this.httpElt, "oauth2-resource-server");
/* 502 */     if (resourceServerElt == null) {
/*     */       return;
/*     */     }
/*     */     
/* 506 */     OAuth2ResourceServerBeanDefinitionParser resourceServerBuilder = new OAuth2ResourceServerBeanDefinitionParser(authManager, this.authenticationProviders, this.defaultEntryPointMappings, this.defaultDeniedHandlerMappings, this.csrfIgnoreRequestMatchers, authenticationFilterSecurityContextHolderStrategyRef);
/*     */ 
/*     */ 
/*     */     
/* 510 */     this.bearerTokenAuthenticationFilter = resourceServerBuilder.parse(resourceServerElt, this.pc);
/*     */   }
/*     */ 
/*     */   
/*     */   void createX509Filter(BeanReference authManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 515 */     Element x509Elt = DomUtils.getChildElementByTagName(this.httpElt, "x509");
/* 516 */     RootBeanDefinition filter = null;
/* 517 */     if (x509Elt != null) {
/*     */       
/* 519 */       BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(X509AuthenticationFilter.class);
/* 520 */       filterBuilder.getRawBeanDefinition().setSource(this.pc.extractSource(x509Elt));
/* 521 */       filterBuilder.addPropertyValue("authenticationManager", authManager);
/* 522 */       filterBuilder.addPropertyValue("securityContextHolderStrategy", authenticationFilterSecurityContextHolderStrategyRef);
/*     */       
/* 524 */       String regex = x509Elt.getAttribute("subject-principal-regex");
/* 525 */       if (StringUtils.hasText(regex)) {
/*     */         
/* 527 */         BeanDefinitionBuilder extractor = BeanDefinitionBuilder.rootBeanDefinition(SubjectDnX509PrincipalExtractor.class);
/* 528 */         extractor.addPropertyValue("subjectDnRegex", regex);
/* 529 */         filterBuilder.addPropertyValue("principalExtractor", extractor.getBeanDefinition());
/*     */       } 
/* 531 */       injectAuthenticationDetailsSource(x509Elt, filterBuilder);
/* 532 */       filter = (RootBeanDefinition)filterBuilder.getBeanDefinition();
/* 533 */       createPrauthEntryPoint(x509Elt);
/* 534 */       createX509Provider();
/*     */     } 
/* 536 */     this.x509Filter = (BeanDefinition)filter;
/*     */   }
/*     */   
/*     */   private void injectAuthenticationDetailsSource(Element elt, BeanDefinitionBuilder filterBuilder) {
/* 540 */     String authDetailsSourceRef = elt.getAttribute("authentication-details-source-ref");
/* 541 */     if (StringUtils.hasText(authDetailsSourceRef)) {
/* 542 */       filterBuilder.addPropertyReference("authenticationDetailsSource", authDetailsSourceRef);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createX509Provider() {
/* 547 */     Element x509Elt = DomUtils.getChildElementByTagName(this.httpElt, "x509");
/* 548 */     RootBeanDefinition rootBeanDefinition1 = new RootBeanDefinition(PreAuthenticatedAuthenticationProvider.class);
/* 549 */     RootBeanDefinition uds = new RootBeanDefinition();
/* 550 */     uds.setFactoryBeanName("org.springframework.security.userDetailsServiceFactory");
/* 551 */     uds.setFactoryMethodName("authenticationUserDetailsService");
/* 552 */     uds.getConstructorArgumentValues().addGenericArgumentValue(x509Elt.getAttribute("user-service-ref"));
/* 553 */     rootBeanDefinition1.getPropertyValues().addPropertyValue("preAuthenticatedUserDetailsService", uds);
/* 554 */     this.x509ProviderRef = (BeanReference)new RuntimeBeanReference(this.pc.getReaderContext().registerWithGeneratedName((BeanDefinition)rootBeanDefinition1));
/*     */   }
/*     */   
/*     */   private void createPrauthEntryPoint(Element source) {
/* 558 */     if (this.preAuthEntryPoint == null) {
/* 559 */       this.preAuthEntryPoint = new RootBeanDefinition(Http403ForbiddenEntryPoint.class);
/* 560 */       this.preAuthEntryPoint.setSource(this.pc.extractSource(source));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void createJeeFilter(BeanReference authManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 566 */     Element jeeElt = DomUtils.getChildElementByTagName(this.httpElt, "jee");
/* 567 */     RootBeanDefinition filter = null;
/* 568 */     if (jeeElt != null) {
/*     */       
/* 570 */       BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(J2eePreAuthenticatedProcessingFilter.class);
/* 571 */       filterBuilder.getRawBeanDefinition().setSource(this.pc.extractSource(jeeElt));
/* 572 */       filterBuilder.addPropertyValue("authenticationManager", authManager);
/* 573 */       filterBuilder.addPropertyValue("securityContextHolderStrategy", authenticationFilterSecurityContextHolderStrategyRef);
/*     */ 
/*     */       
/* 576 */       BeanDefinitionBuilder adsBldr = BeanDefinitionBuilder.rootBeanDefinition(J2eeBasedPreAuthenticatedWebAuthenticationDetailsSource.class);
/* 577 */       adsBldr.addPropertyValue("userRoles2GrantedAuthoritiesMapper", new RootBeanDefinition(SimpleAttributes2GrantedAuthoritiesMapper.class));
/*     */       
/* 579 */       String roles = jeeElt.getAttribute("mappable-roles");
/* 580 */       Assert.hasLength(roles, "roles is expected to have length");
/* 581 */       BeanDefinitionBuilder rolesBuilder = BeanDefinitionBuilder.rootBeanDefinition(StringUtils.class);
/* 582 */       rolesBuilder.addConstructorArgValue(roles);
/* 583 */       rolesBuilder.setFactoryMethod("commaDelimitedListToSet");
/* 584 */       RootBeanDefinition mappableRolesRetriever = new RootBeanDefinition(SimpleMappableAttributesRetriever.class);
/* 585 */       mappableRolesRetriever.getPropertyValues()
/* 586 */         .addPropertyValue("mappableAttributes", rolesBuilder.getBeanDefinition());
/* 587 */       adsBldr.addPropertyValue("mappableRolesRetriever", mappableRolesRetriever);
/* 588 */       filterBuilder.addPropertyValue("authenticationDetailsSource", adsBldr.getBeanDefinition());
/* 589 */       filter = (RootBeanDefinition)filterBuilder.getBeanDefinition();
/* 590 */       createPrauthEntryPoint(jeeElt);
/* 591 */       createJeeProvider();
/*     */     } 
/* 593 */     this.jeeFilter = (BeanDefinition)filter;
/*     */   }
/*     */   private void createJeeProvider() {
/*     */     RootBeanDefinition uds;
/* 597 */     Element jeeElt = DomUtils.getChildElementByTagName(this.httpElt, "jee");
/* 598 */     RootBeanDefinition rootBeanDefinition1 = new RootBeanDefinition(PreAuthenticatedAuthenticationProvider.class);
/*     */     
/* 600 */     if (StringUtils.hasText(jeeElt.getAttribute("user-service-ref"))) {
/* 601 */       uds = new RootBeanDefinition();
/* 602 */       uds.setFactoryBeanName("org.springframework.security.userDetailsServiceFactory");
/* 603 */       uds.setFactoryMethodName("authenticationUserDetailsService");
/* 604 */       uds.getConstructorArgumentValues().addGenericArgumentValue(jeeElt.getAttribute("user-service-ref"));
/*     */     } else {
/*     */       
/* 607 */       uds = new RootBeanDefinition(PreAuthenticatedGrantedAuthoritiesUserDetailsService.class);
/*     */     } 
/* 609 */     rootBeanDefinition1.getPropertyValues().addPropertyValue("preAuthenticatedUserDetailsService", uds);
/* 610 */     this.jeeProviderRef = (BeanReference)new RuntimeBeanReference(this.pc.getReaderContext().registerWithGeneratedName((BeanDefinition)rootBeanDefinition1));
/*     */   }
/*     */   
/*     */   void createLoginPageFilterIfNeeded() {
/* 614 */     boolean needLoginPage = (this.formFilterId != null || this.oauth2LoginFilterId != null);
/*     */     
/* 616 */     if (needLoginPage && this.formLoginPage == null) {
/* 617 */       this.logger.info("No login page configured. The default internal one will be used. Use the 'login-page' attribute to set the URL of the login page.");
/*     */ 
/*     */       
/* 620 */       BeanDefinitionBuilder loginPageFilter = BeanDefinitionBuilder.rootBeanDefinition(DefaultLoginPageGeneratingFilter.class);
/* 621 */       loginPageFilter.addPropertyValue("resolveHiddenInputs", new CsrfTokenHiddenInputFunction());
/*     */ 
/*     */       
/* 624 */       BeanDefinitionBuilder logoutPageFilter = BeanDefinitionBuilder.rootBeanDefinition(DefaultLogoutPageGeneratingFilter.class);
/* 625 */       logoutPageFilter.addPropertyValue("resolveHiddenInputs", new CsrfTokenHiddenInputFunction());
/* 626 */       if (this.formFilterId != null) {
/* 627 */         loginPageFilter.addConstructorArgReference(this.formFilterId);
/* 628 */         loginPageFilter.addPropertyValue("authenticationUrl", this.loginProcessingUrl);
/*     */       } 
/* 630 */       if (this.oauth2LoginFilterId != null) {
/* 631 */         loginPageFilter.addPropertyValue("Oauth2LoginEnabled", Boolean.valueOf(true));
/* 632 */         loginPageFilter.addPropertyValue("Oauth2AuthenticationUrlToClientName", this.oauth2LoginLinks);
/*     */       } 
/* 634 */       if (this.saml2AuthenticationFilterId != null) {
/* 635 */         loginPageFilter.addPropertyValue("saml2LoginEnabled", Boolean.valueOf(true));
/* 636 */         loginPageFilter.addPropertyValue("saml2AuthenticationUrlToProviderName", this.saml2AuthenticationUrlToProviderName);
/*     */       } 
/*     */       
/* 639 */       this.loginPageGenerationFilter = (BeanDefinition)loginPageFilter.getBeanDefinition();
/* 640 */       this.logoutPageGenerationFilter = (BeanDefinition)logoutPageFilter.getBeanDefinition();
/* 641 */       this
/*     */         
/* 643 */         .defaultResourcesFilter = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(DefaultResourcesFilter.class).setFactoryMethod("css").getBeanDefinition();
/*     */     } 
/*     */   }
/*     */   
/*     */   void createLogoutFilter(BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 648 */     Element logoutElt = DomUtils.getChildElementByTagName(this.httpElt, "logout");
/* 649 */     if (logoutElt != null || this.autoConfig) {
/* 650 */       String formLoginPage = this.formLoginPage;
/* 651 */       if (formLoginPage == null) {
/* 652 */         formLoginPage = "/login";
/*     */       }
/* 654 */       LogoutBeanDefinitionParser logoutParser = new LogoutBeanDefinitionParser(formLoginPage, this.rememberMeServicesId, this.csrfLogoutHandler, authenticationFilterSecurityContextHolderStrategyRef);
/*     */ 
/*     */       
/* 657 */       this.logoutFilter = logoutParser.parse(logoutElt, this.pc);
/* 658 */       this.logoutHandlers = logoutParser.getLogoutHandlers();
/* 659 */       this.logoutSuccessHandler = logoutParser.getLogoutSuccessHandler();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void createSaml2LogoutFilter(BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 664 */     Element saml2LogoutElt = DomUtils.getChildElementByTagName(this.httpElt, "saml2-logout");
/* 665 */     if (saml2LogoutElt == null) {
/*     */       return;
/*     */     }
/* 668 */     Saml2LogoutBeanDefinitionParser parser = new Saml2LogoutBeanDefinitionParser(this.logoutHandlers, this.logoutSuccessHandler, authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 670 */     parser.parse(saml2LogoutElt, this.pc);
/* 671 */     BeanDefinition saml2LogoutFilter = parser.getLogoutFilter();
/* 672 */     BeanDefinition saml2LogoutRequestFilter = parser.getLogoutRequestFilter();
/* 673 */     BeanDefinition saml2LogoutResponseFilter = parser.getLogoutResponseFilter();
/* 674 */     this.saml2LogoutFilterId = this.pc.getReaderContext().generateBeanName(saml2LogoutFilter);
/* 675 */     this.saml2LogoutRequestFilterId = this.pc.getReaderContext().generateBeanName(saml2LogoutRequestFilter);
/* 676 */     this.saml2LogoutResponseFilterId = this.pc.getReaderContext().generateBeanName(saml2LogoutResponseFilter);
/*     */ 
/*     */     
/* 679 */     this.pc.registerBeanComponent(new BeanComponentDefinition(saml2LogoutFilter, this.saml2LogoutFilterId));
/* 680 */     this.pc.registerBeanComponent(new BeanComponentDefinition(saml2LogoutRequestFilter, this.saml2LogoutRequestFilterId));
/*     */     
/* 682 */     this.pc.registerBeanComponent(new BeanComponentDefinition(saml2LogoutResponseFilter, this.saml2LogoutResponseFilterId));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ManagedList getLogoutHandlers() {
/* 688 */     if (this.logoutHandlers == null && this.rememberMeProviderRef != null) {
/* 689 */       this.logoutHandlers = new ManagedList();
/* 690 */       if (this.csrfLogoutHandler != null) {
/* 691 */         this.logoutHandlers.add(this.csrfLogoutHandler);
/*     */       }
/* 693 */       this.logoutHandlers.add(new RuntimeBeanReference(this.rememberMeServicesId));
/* 694 */       this.logoutHandlers.add(new RootBeanDefinition(SecurityContextLogoutHandler.class));
/*     */     } 
/*     */     
/* 697 */     return this.logoutHandlers;
/*     */   }
/*     */   
/*     */   BeanMetadataElement getEntryPointBean() {
/* 701 */     return this.mainEntryPoint;
/*     */   }
/*     */   
/*     */   BeanMetadataElement getAccessDeniedHandlerBean() {
/* 705 */     return this.accessDeniedHandler;
/*     */   }
/*     */   
/*     */   List<BeanDefinition> getCsrfIgnoreRequestMatchers() {
/* 709 */     return this.csrfIgnoreRequestMatchers;
/*     */   }
/*     */   
/*     */   void createAnonymousFilter(BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 713 */     Element anonymousElt = DomUtils.getChildElementByTagName(this.httpElt, "anonymous");
/* 714 */     if (anonymousElt != null && "false".equals(anonymousElt.getAttribute("enabled"))) {
/*     */       return;
/*     */     }
/* 717 */     String grantedAuthority = null;
/* 718 */     String username = null;
/* 719 */     String key = null;
/* 720 */     Object source = this.pc.extractSource(this.httpElt);
/* 721 */     if (anonymousElt != null) {
/* 722 */       grantedAuthority = anonymousElt.getAttribute("granted-authority");
/* 723 */       username = anonymousElt.getAttribute("username");
/* 724 */       key = anonymousElt.getAttribute("key");
/* 725 */       source = this.pc.extractSource(anonymousElt);
/*     */     } 
/* 727 */     if (!StringUtils.hasText(grantedAuthority)) {
/* 728 */       grantedAuthority = "ROLE_ANONYMOUS";
/*     */     }
/* 730 */     if (!StringUtils.hasText(username)) {
/* 731 */       username = "anonymousUser";
/*     */     }
/* 733 */     if (!StringUtils.hasText(key))
/*     */     {
/* 735 */       key = createKey();
/*     */     }
/* 737 */     this.anonymousFilter = new RootBeanDefinition(AnonymousAuthenticationFilter.class);
/* 738 */     this.anonymousFilter.getConstructorArgumentValues().addIndexedArgumentValue(0, key);
/* 739 */     this.anonymousFilter.getConstructorArgumentValues().addIndexedArgumentValue(1, username);
/* 740 */     this.anonymousFilter.getConstructorArgumentValues()
/* 741 */       .addIndexedArgumentValue(2, AuthorityUtils.commaSeparatedStringToAuthorityList(grantedAuthority));
/* 742 */     this.anonymousFilter.getPropertyValues()
/* 743 */       .addPropertyValue("securityContextHolderStrategy", authenticationFilterSecurityContextHolderStrategyRef);
/* 744 */     this.anonymousFilter.setSource(source);
/* 745 */     RootBeanDefinition anonymousProviderBean = new RootBeanDefinition(AnonymousAuthenticationProvider.class);
/* 746 */     anonymousProviderBean.getConstructorArgumentValues().addIndexedArgumentValue(0, key);
/* 747 */     anonymousProviderBean.setSource(this.anonymousFilter.getSource());
/* 748 */     String id = this.pc.getReaderContext().generateBeanName((BeanDefinition)anonymousProviderBean);
/* 749 */     this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)anonymousProviderBean, id));
/* 750 */     this.anonymousProviderRef = (BeanReference)new RuntimeBeanReference(id);
/*     */   }
/*     */   
/*     */   private String createKey() {
/* 754 */     SecureRandom random = new SecureRandom();
/* 755 */     return Long.toString(random.nextLong());
/*     */   }
/*     */   
/*     */   void createExceptionTranslationFilter(BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/* 759 */     BeanDefinitionBuilder etfBuilder = BeanDefinitionBuilder.rootBeanDefinition(ExceptionTranslationFilter.class);
/* 760 */     this.accessDeniedHandler = createAccessDeniedHandler(this.httpElt, this.pc);
/* 761 */     etfBuilder.addPropertyValue("accessDeniedHandler", this.accessDeniedHandler);
/* 762 */     Assert.state((this.requestCache != null), "No request cache found");
/* 763 */     this.mainEntryPoint = selectEntryPoint();
/* 764 */     etfBuilder.addConstructorArgValue(this.mainEntryPoint);
/* 765 */     etfBuilder.addConstructorArgValue(this.requestCache);
/* 766 */     etfBuilder.addPropertyValue("securityContextHolderStrategy", authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 768 */     this.etf = (BeanDefinition)etfBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   private BeanMetadataElement createAccessDeniedHandler(Element element, ParserContext pc) {
/* 772 */     Element accessDeniedElt = DomUtils.getChildElementByTagName(element, "access-denied-handler");
/*     */     
/* 774 */     BeanDefinitionBuilder accessDeniedHandler = BeanDefinitionBuilder.rootBeanDefinition(AccessDeniedHandlerImpl.class);
/* 775 */     if (accessDeniedElt != null) {
/* 776 */       String errorPage = accessDeniedElt.getAttribute("error-page");
/* 777 */       String ref = accessDeniedElt.getAttribute("ref");
/* 778 */       if (StringUtils.hasText(errorPage)) {
/* 779 */         if (StringUtils.hasText(ref)) {
/* 780 */           pc.getReaderContext()
/* 781 */             .error("The attribute error-page cannot be used together with the 'ref' attribute within <access-denied-handler>", pc
/*     */               
/* 783 */               .extractSource(accessDeniedElt));
/*     */         }
/*     */         
/* 786 */         accessDeniedHandler.addPropertyValue("errorPage", errorPage);
/* 787 */         return (BeanMetadataElement)accessDeniedHandler.getBeanDefinition();
/*     */       } 
/* 789 */       if (StringUtils.hasText(ref)) {
/* 790 */         return (BeanMetadataElement)new RuntimeBeanReference(ref);
/*     */       }
/*     */     } 
/* 793 */     if (this.defaultDeniedHandlerMappings.isEmpty()) {
/* 794 */       return (BeanMetadataElement)accessDeniedHandler.getBeanDefinition();
/*     */     }
/* 796 */     if (this.defaultDeniedHandlerMappings.size() == 1) {
/* 797 */       return this.defaultDeniedHandlerMappings.values().iterator().next();
/*     */     }
/*     */     
/* 800 */     accessDeniedHandler = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherDelegatingAccessDeniedHandler.class);
/* 801 */     accessDeniedHandler.addConstructorArgValue(this.defaultDeniedHandlerMappings);
/* 802 */     accessDeniedHandler
/* 803 */       .addConstructorArgValue(BeanDefinitionBuilder.rootBeanDefinition(AccessDeniedHandlerImpl.class));
/* 804 */     return (BeanMetadataElement)accessDeniedHandler.getBeanDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanMetadataElement selectEntryPoint() {
/* 810 */     String customEntryPoint = this.httpElt.getAttribute("entry-point-ref");
/* 811 */     if (StringUtils.hasText(customEntryPoint)) {
/* 812 */       return (BeanMetadataElement)new RuntimeBeanReference(customEntryPoint);
/*     */     }
/* 814 */     if (!this.defaultEntryPointMappings.isEmpty()) {
/* 815 */       if (this.defaultEntryPointMappings.size() == 1) {
/* 816 */         return this.defaultEntryPointMappings.values().iterator().next();
/*     */       }
/*     */       
/* 819 */       BeanDefinitionBuilder delegatingEntryPoint = BeanDefinitionBuilder.rootBeanDefinition(DelegatingAuthenticationEntryPoint.class);
/* 820 */       delegatingEntryPoint.addConstructorArgValue(this.defaultEntryPointMappings);
/* 821 */       return (BeanMetadataElement)delegatingEntryPoint.getBeanDefinition();
/*     */     } 
/* 823 */     Element basicAuthElt = DomUtils.getChildElementByTagName(this.httpElt, "http-basic");
/* 824 */     Element formLoginElt = DomUtils.getChildElementByTagName(this.httpElt, "form-login");
/*     */     
/* 826 */     if (basicAuthElt != null && formLoginElt == null && this.oauth2LoginEntryPoint == null) {
/* 827 */       return (BeanMetadataElement)this.basicEntryPoint;
/*     */     }
/* 829 */     if (this.formFilterId != null) {
/*     */ 
/*     */       
/* 832 */       if (formLoginElt != null && this.oauth2LoginEntryPoint != null) {
/* 833 */         return (BeanMetadataElement)this.formEntryPoint;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 838 */       if (this.oauth2LoginEntryPoint == null) {
/* 839 */         return (BeanMetadataElement)this.formEntryPoint;
/*     */       }
/*     */     } 
/*     */     
/* 843 */     if (this.preAuthEntryPoint != null) {
/* 844 */       return (BeanMetadataElement)this.preAuthEntryPoint;
/*     */     }
/*     */     
/* 847 */     if (this.oauth2LoginEntryPoint != null) {
/* 848 */       return (BeanMetadataElement)this.oauth2LoginEntryPoint;
/*     */     }
/* 850 */     this.pc.getReaderContext()
/* 851 */       .error("No AuthenticationEntryPoint could be established. Please make sure you have a login mechanism configured through the namespace (such as form-login) or specify a custom AuthenticationEntryPoint with the 'entry-point-ref' attribute ", this.pc
/*     */ 
/*     */         
/* 854 */         .extractSource(this.httpElt));
/* 855 */     return null;
/*     */   }
/*     */   
/*     */   private void createUserDetailsServiceFactory() {
/* 859 */     if (this.pc.getRegistry().containsBeanDefinition("org.springframework.security.userDetailsServiceFactory")) {
/*     */       return;
/*     */     }
/*     */     
/* 863 */     RootBeanDefinition bean = new RootBeanDefinition(UserDetailsServiceFactoryBean.class);
/* 864 */     bean.setRole(2);
/* 865 */     this.pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)bean, "org.springframework.security.userDetailsServiceFactory"));
/*     */   }
/*     */   
/*     */   List<OrderDecorator> getFilters() {
/* 869 */     List<OrderDecorator> filters = new ArrayList<>();
/* 870 */     if (this.anonymousFilter != null) {
/* 871 */       filters.add(new OrderDecorator((BeanMetadataElement)this.anonymousFilter, SecurityFilters.ANONYMOUS_FILTER));
/*     */     }
/* 873 */     if (this.rememberMeFilter != null) {
/* 874 */       filters.add(new OrderDecorator((BeanMetadataElement)this.rememberMeFilter, SecurityFilters.REMEMBER_ME_FILTER));
/*     */     }
/* 876 */     if (this.logoutFilter != null) {
/* 877 */       filters.add(new OrderDecorator((BeanMetadataElement)this.logoutFilter, SecurityFilters.LOGOUT_FILTER));
/*     */     }
/* 879 */     if (this.x509Filter != null) {
/* 880 */       filters.add(new OrderDecorator((BeanMetadataElement)this.x509Filter, SecurityFilters.X509_FILTER));
/*     */     }
/* 882 */     if (this.jeeFilter != null) {
/* 883 */       filters.add(new OrderDecorator((BeanMetadataElement)this.jeeFilter, SecurityFilters.PRE_AUTH_FILTER));
/*     */     }
/* 885 */     if (this.formFilterId != null) {
/* 886 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.formFilterId), SecurityFilters.FORM_LOGIN_FILTER));
/*     */     }
/*     */     
/* 889 */     if (this.oauth2LoginFilterId != null) {
/* 890 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.oauth2LoginFilterId), SecurityFilters.OAUTH2_LOGIN_FILTER));
/*     */       
/* 892 */       filters.add(new OrderDecorator((BeanMetadataElement)this.oauth2AuthorizationRequestRedirectFilter, SecurityFilters.OAUTH2_AUTHORIZATION_REQUEST_FILTER));
/*     */     } 
/*     */     
/* 895 */     if (this.loginPageGenerationFilter != null) {
/* 896 */       filters.add(new OrderDecorator((BeanMetadataElement)this.loginPageGenerationFilter, SecurityFilters.LOGIN_PAGE_FILTER));
/* 897 */       filters.add(new OrderDecorator((BeanMetadataElement)this.logoutPageGenerationFilter, SecurityFilters.LOGOUT_PAGE_FILTER));
/*     */     } 
/* 899 */     if (this.defaultResourcesFilter != null) {
/* 900 */       filters.add(new OrderDecorator((BeanMetadataElement)this.defaultResourcesFilter, SecurityFilters.DEFAULT_RESOURCES_FILTER));
/*     */     }
/* 902 */     if (this.basicFilter != null) {
/* 903 */       filters.add(new OrderDecorator((BeanMetadataElement)this.basicFilter, SecurityFilters.BASIC_AUTH_FILTER));
/*     */     }
/* 905 */     if (this.bearerTokenAuthenticationFilter != null) {
/* 906 */       filters.add(new OrderDecorator((BeanMetadataElement)this.bearerTokenAuthenticationFilter, SecurityFilters.BEARER_TOKEN_AUTH_FILTER));
/*     */     }
/*     */     
/* 909 */     if (this.authorizationCodeGrantFilter != null) {
/* 910 */       filters.add(new OrderDecorator((BeanMetadataElement)this.authorizationRequestRedirectFilter, SecurityFilters.OAUTH2_AUTHORIZATION_REQUEST_FILTER
/* 911 */             .getOrder() + 1));
/* 912 */       filters.add(new OrderDecorator((BeanMetadataElement)this.authorizationCodeGrantFilter, SecurityFilters.OAUTH2_AUTHORIZATION_CODE_GRANT_FILTER));
/*     */     } 
/*     */     
/* 915 */     if (this.saml2AuthenticationFilterId != null) {
/* 916 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.saml2AuthenticationFilterId), SecurityFilters.SAML2_AUTHENTICATION_FILTER));
/*     */       
/* 918 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.saml2AuthenticationRequestFilterId), SecurityFilters.SAML2_AUTHENTICATION_REQUEST_FILTER));
/*     */     } 
/*     */     
/* 921 */     if (this.saml2LogoutFilterId != null) {
/* 922 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.saml2LogoutFilterId), SecurityFilters.SAML2_LOGOUT_FILTER));
/*     */       
/* 924 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.saml2LogoutRequestFilterId), SecurityFilters.SAML2_LOGOUT_REQUEST_FILTER));
/*     */       
/* 926 */       filters.add(new OrderDecorator((BeanMetadataElement)new RuntimeBeanReference(this.saml2LogoutResponseFilterId), SecurityFilters.SAML2_LOGOUT_RESPONSE_FILTER));
/*     */     } 
/*     */     
/* 929 */     filters.add(new OrderDecorator((BeanMetadataElement)this.etf, SecurityFilters.EXCEPTION_TRANSLATION_FILTER));
/* 930 */     return filters;
/*     */   }
/*     */   
/*     */   List<BeanReference> getProviders() {
/* 934 */     List<BeanReference> providers = new ArrayList<>();
/* 935 */     if (this.anonymousProviderRef != null) {
/* 936 */       providers.add(this.anonymousProviderRef);
/*     */     }
/* 938 */     if (this.rememberMeProviderRef != null) {
/* 939 */       providers.add(this.rememberMeProviderRef);
/*     */     }
/* 941 */     if (this.x509ProviderRef != null) {
/* 942 */       providers.add(this.x509ProviderRef);
/*     */     }
/* 944 */     if (this.jeeProviderRef != null) {
/* 945 */       providers.add(this.jeeProviderRef);
/*     */     }
/* 947 */     if (this.oauth2LoginAuthenticationProviderRef != null) {
/* 948 */       providers.add(this.oauth2LoginAuthenticationProviderRef);
/*     */     }
/* 950 */     if (this.oauth2LoginOidcAuthenticationProviderRef != null) {
/* 951 */       providers.add(this.oauth2LoginOidcAuthenticationProviderRef);
/*     */     }
/* 953 */     if (this.authorizationCodeAuthenticationProviderRef != null) {
/* 954 */       providers.add(this.authorizationCodeAuthenticationProviderRef);
/*     */     }
/* 956 */     providers.addAll(this.authenticationProviders);
/* 957 */     return providers;
/*     */   }
/*     */   
/*     */   private static class CsrfTokenHiddenInputFunction
/*     */     implements Function<HttpServletRequest, Map<String, String>>
/*     */   {
/*     */     public Map<String, String> apply(HttpServletRequest request) {
/* 964 */       CsrfToken token = (CsrfToken)request.getAttribute(CsrfToken.class.getName());
/* 965 */       if (token == null) {
/* 966 */         return Collections.emptyMap();
/*     */       }
/* 968 */       return Collections.singletonMap(token.getParameterName(), token.getToken());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\AuthenticationConfigBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */