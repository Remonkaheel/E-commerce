/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.annotation.AnnotationBeanNameGenerator;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.oauth2.client.AuthorizationCodeOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.ClientCredentialsOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.DelegatingOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.JwtBearerOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.PasswordOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.RefreshTokenOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.TokenExchangeOAuth2AuthorizedClientProvider;
/*     */ import org.springframework.security.oauth2.client.endpoint.JwtBearerGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2PasswordGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.OAuth2RefreshTokenGrantRequest;
/*     */ import org.springframework.security.oauth2.client.endpoint.TokenExchangeGrantRequest;
/*     */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*     */ import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
/*     */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OAuth2AuthorizedClientManagerRegistrar
/*     */   implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware
/*     */ {
/*     */   static final String BEAN_NAME = "authorizedClientManagerRegistrar";
/*     */   static final String FACTORY_METHOD_NAME = "getAuthorizedClientManager";
/*  77 */   private static final Set<Class<?>> KNOWN_AUTHORIZED_CLIENT_PROVIDERS = Set.of(AuthorizationCodeOAuth2AuthorizedClientProvider.class, RefreshTokenOAuth2AuthorizedClientProvider.class, ClientCredentialsOAuth2AuthorizedClientProvider.class, PasswordOAuth2AuthorizedClientProvider.class, JwtBearerOAuth2AuthorizedClientProvider.class, TokenExchangeOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private final AnnotationBeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */   
/*     */   private ListableBeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/*  93 */     if ((getBeanNamesForType((Class)OAuth2AuthorizedClientManager.class)).length != 0 || (
/*  94 */       getBeanNamesForType((Class)ClientRegistrationRepository.class)).length != 1 || (
/*  95 */       getBeanNamesForType((Class)OAuth2AuthorizedClientRepository.class)).length != 1) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 101 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(OAuth2AuthorizedClientManager.class).setFactoryMethodOnBean("getAuthorizedClientManager", "authorizedClientManagerRegistrar").getBeanDefinition();
/*     */     
/* 103 */     registry.registerBeanDefinition(this.beanNameGenerator.generateBeanName((BeanDefinition)abstractBeanDefinition, registry), (BeanDefinition)abstractBeanDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 113 */     this.beanFactory = (ListableBeanFactory)beanFactory;
/*     */   }
/*     */   
/*     */   private OAuth2AuthorizedClientManager getAuthorizedClientManager() {
/*     */     DelegatingOAuth2AuthorizedClientProvider delegatingOAuth2AuthorizedClientProvider;
/* 118 */     ClientRegistrationRepository clientRegistrationRepository = (ClientRegistrationRepository)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, ClientRegistrationRepository.class, true, true);
/*     */ 
/*     */     
/* 121 */     OAuth2AuthorizedClientRepository authorizedClientRepository = (OAuth2AuthorizedClientRepository)BeanFactoryUtils.beanOfTypeIncludingAncestors(this.beanFactory, OAuth2AuthorizedClientRepository.class, true, true);
/*     */ 
/*     */ 
/*     */     
/* 125 */     Collection<OAuth2AuthorizedClientProvider> authorizedClientProviderBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(this.beanFactory, OAuth2AuthorizedClientProvider.class, true, true).values();
/*     */ 
/*     */     
/* 128 */     if (hasDelegatingAuthorizedClientProvider(authorizedClientProviderBeans)) {
/* 129 */       OAuth2AuthorizedClientProvider authorizedClientProvider = authorizedClientProviderBeans.iterator().next();
/*     */     } else {
/*     */       
/* 132 */       List<OAuth2AuthorizedClientProvider> authorizedClientProviders = new ArrayList<>();
/* 133 */       authorizedClientProviders.add(getAuthorizationCodeAuthorizedClientProvider(authorizedClientProviderBeans));
/* 134 */       authorizedClientProviders.add(getRefreshTokenAuthorizedClientProvider(authorizedClientProviderBeans));
/* 135 */       authorizedClientProviders.add(getClientCredentialsAuthorizedClientProvider(authorizedClientProviderBeans));
/* 136 */       authorizedClientProviders.add(getPasswordAuthorizedClientProvider(authorizedClientProviderBeans));
/*     */       
/* 138 */       OAuth2AuthorizedClientProvider jwtBearerAuthorizedClientProvider = getJwtBearerAuthorizedClientProvider(authorizedClientProviderBeans);
/*     */       
/* 140 */       if (jwtBearerAuthorizedClientProvider != null) {
/* 141 */         authorizedClientProviders.add(jwtBearerAuthorizedClientProvider);
/*     */       }
/*     */       
/* 144 */       OAuth2AuthorizedClientProvider tokenExchangeAuthorizedClientProvider = getTokenExchangeAuthorizedClientProvider(authorizedClientProviderBeans);
/*     */       
/* 146 */       if (tokenExchangeAuthorizedClientProvider != null) {
/* 147 */         authorizedClientProviders.add(tokenExchangeAuthorizedClientProvider);
/*     */       }
/*     */       
/* 150 */       authorizedClientProviders.addAll(getAdditionalAuthorizedClientProviders(authorizedClientProviderBeans));
/* 151 */       delegatingOAuth2AuthorizedClientProvider = new DelegatingOAuth2AuthorizedClientProvider(authorizedClientProviders);
/*     */     } 
/*     */     
/* 154 */     DefaultOAuth2AuthorizedClientManager authorizedClientManager = new DefaultOAuth2AuthorizedClientManager(clientRegistrationRepository, authorizedClientRepository);
/*     */     
/* 156 */     authorizedClientManager.setAuthorizedClientProvider((OAuth2AuthorizedClientProvider)delegatingOAuth2AuthorizedClientProvider);
/*     */     
/* 158 */     Consumer<DefaultOAuth2AuthorizedClientManager> authorizedClientManagerConsumer = getBeanOfType(
/* 159 */         ResolvableType.forClassWithGenerics(Consumer.class, new Class[] { DefaultOAuth2AuthorizedClientManager.class }));
/* 160 */     if (authorizedClientManagerConsumer != null) {
/* 161 */       authorizedClientManagerConsumer.accept(authorizedClientManager);
/*     */     }
/*     */     
/* 164 */     return (OAuth2AuthorizedClientManager)authorizedClientManager;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasDelegatingAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 169 */     if (authorizedClientProviders.size() != 1) {
/* 170 */       return false;
/*     */     }
/* 172 */     return authorizedClientProviders.iterator().next() instanceof DelegatingOAuth2AuthorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getAuthorizationCodeAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 177 */     AuthorizationCodeOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, AuthorizationCodeOAuth2AuthorizedClientProvider.class);
/*     */     
/* 179 */     if (authorizedClientProvider == null) {
/* 180 */       authorizedClientProvider = new AuthorizationCodeOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 183 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getRefreshTokenAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 188 */     RefreshTokenOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, RefreshTokenOAuth2AuthorizedClientProvider.class);
/*     */     
/* 190 */     if (authorizedClientProvider == null) {
/* 191 */       authorizedClientProvider = new RefreshTokenOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 194 */     OAuth2AccessTokenResponseClient<OAuth2RefreshTokenGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 195 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2RefreshTokenGrantRequest.class }));
/*     */     
/* 197 */     if (accessTokenResponseClient != null) {
/* 198 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 201 */     ApplicationEventPublisher applicationEventPublisher = getBeanOfType(
/* 202 */         ResolvableType.forClass(ApplicationEventPublisher.class));
/* 203 */     if (applicationEventPublisher != null) {
/* 204 */       authorizedClientProvider.setApplicationEventPublisher(applicationEventPublisher);
/*     */     }
/*     */     
/* 207 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getClientCredentialsAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 212 */     ClientCredentialsOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, ClientCredentialsOAuth2AuthorizedClientProvider.class);
/*     */     
/* 214 */     if (authorizedClientProvider == null) {
/* 215 */       authorizedClientProvider = new ClientCredentialsOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 218 */     OAuth2AccessTokenResponseClient<OAuth2ClientCredentialsGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 219 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2ClientCredentialsGrantRequest.class }));
/*     */     
/* 221 */     if (accessTokenResponseClient != null) {
/* 222 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 225 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getPasswordAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 230 */     PasswordOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, PasswordOAuth2AuthorizedClientProvider.class);
/*     */     
/* 232 */     if (authorizedClientProvider == null) {
/* 233 */       authorizedClientProvider = new PasswordOAuth2AuthorizedClientProvider();
/*     */     }
/*     */     
/* 236 */     OAuth2AccessTokenResponseClient<OAuth2PasswordGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 237 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { OAuth2PasswordGrantRequest.class }));
/*     */     
/* 239 */     if (accessTokenResponseClient != null) {
/* 240 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     }
/*     */     
/* 243 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getJwtBearerAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 248 */     JwtBearerOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, JwtBearerOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */     
/* 251 */     OAuth2AccessTokenResponseClient<JwtBearerGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 252 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { JwtBearerGrantRequest.class }));
/* 253 */     if (accessTokenResponseClient != null) {
/* 254 */       if (authorizedClientProvider == null) {
/* 255 */         authorizedClientProvider = new JwtBearerOAuth2AuthorizedClientProvider();
/*     */       }
/*     */       
/* 258 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     } 
/*     */     
/* 261 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private OAuth2AuthorizedClientProvider getTokenExchangeAuthorizedClientProvider(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 266 */     TokenExchangeOAuth2AuthorizedClientProvider authorizedClientProvider = getAuthorizedClientProviderByType(authorizedClientProviders, TokenExchangeOAuth2AuthorizedClientProvider.class);
/*     */ 
/*     */     
/* 269 */     OAuth2AccessTokenResponseClient<TokenExchangeGrantRequest> accessTokenResponseClient = getBeanOfType(
/* 270 */         ResolvableType.forClassWithGenerics(OAuth2AccessTokenResponseClient.class, new Class[] { TokenExchangeGrantRequest.class }));
/*     */     
/* 272 */     if (accessTokenResponseClient != null) {
/* 273 */       if (authorizedClientProvider == null) {
/* 274 */         authorizedClientProvider = new TokenExchangeOAuth2AuthorizedClientProvider();
/*     */       }
/*     */       
/* 277 */       authorizedClientProvider.setAccessTokenResponseClient(accessTokenResponseClient);
/*     */     } 
/*     */     
/* 280 */     return (OAuth2AuthorizedClientProvider)authorizedClientProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<OAuth2AuthorizedClientProvider> getAdditionalAuthorizedClientProviders(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders) {
/* 285 */     List<OAuth2AuthorizedClientProvider> additionalAuthorizedClientProviders = new ArrayList<>(authorizedClientProviders);
/*     */     
/* 287 */     additionalAuthorizedClientProviders
/* 288 */       .removeIf(provider -> KNOWN_AUTHORIZED_CLIENT_PROVIDERS.contains(provider.getClass()));
/* 289 */     return additionalAuthorizedClientProviders;
/*     */   }
/*     */   
/*     */   private <T extends OAuth2AuthorizedClientProvider> T getAuthorizedClientProviderByType(Collection<OAuth2AuthorizedClientProvider> authorizedClientProviders, Class<T> providerClass) {
/*     */     OAuth2AuthorizedClientProvider oAuth2AuthorizedClientProvider;
/* 294 */     T authorizedClientProvider = null;
/* 295 */     for (OAuth2AuthorizedClientProvider current : authorizedClientProviders) {
/* 296 */       if (providerClass.isInstance(current)) {
/* 297 */         assertAuthorizedClientProviderIsNull((OAuth2AuthorizedClientProvider)authorizedClientProvider);
/* 298 */         oAuth2AuthorizedClientProvider = (OAuth2AuthorizedClientProvider)providerClass.cast(current);
/*     */       } 
/*     */     } 
/* 301 */     return (T)oAuth2AuthorizedClientProvider;
/*     */   }
/*     */   
/*     */   private static void assertAuthorizedClientProviderIsNull(OAuth2AuthorizedClientProvider authorizedClientProvider) {
/* 305 */     if (authorizedClientProvider != null)
/*     */     {
/* 307 */       throw new BeanInitializationException(String.format("Unable to create an %s bean. Expected one bean of type %s, but found multiple. Please consider defining only a single bean of this type, or define an %s bean yourself.", new Object[] { OAuth2AuthorizedClientManager.class
/*     */ 
/*     */               
/* 310 */               .getName(), authorizedClientProvider
/* 311 */               .getClass().getName(), OAuth2AuthorizedClientManager.class
/* 312 */               .getName() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> String[] getBeanNamesForType(Class<T> beanClass) {
/* 318 */     return BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.beanFactory, beanClass, false, false);
/*     */   }
/*     */   
/*     */   private <T> T getBeanOfType(ResolvableType resolvableType) {
/* 322 */     ObjectProvider<T> objectProvider = this.beanFactory.getBeanProvider(resolvableType, true);
/* 323 */     return (T)objectProvider.getIfAvailable();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2AuthorizedClientManagerRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */