/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.web.authentication.logout.CookieClearingLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutFilter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessEventPublishingLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LogoutBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   static final String ATT_LOGOUT_SUCCESS_URL = "logout-success-url";
/*     */   static final String ATT_INVALIDATE_SESSION = "invalidate-session";
/*     */   static final String ATT_LOGOUT_URL = "logout-url";
/*     */   static final String DEF_LOGOUT_URL = "/logout";
/*     */   static final String ATT_LOGOUT_HANDLER = "success-handler-ref";
/*     */   static final String ATT_DELETE_COOKIES = "delete-cookies";
/*     */   final String rememberMeServices;
/*     */   private final String defaultLogoutUrl;
/*  58 */   private ManagedList<BeanMetadataElement> logoutHandlers = new ManagedList();
/*     */   
/*     */   private boolean csrfEnabled;
/*     */   
/*     */   private BeanMetadataElement logoutSuccessHandler;
/*     */   
/*     */   private BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef;
/*     */ 
/*     */   
/*     */   LogoutBeanDefinitionParser(String loginPageUrl, String rememberMeServices, BeanMetadataElement csrfLogoutHandler, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/*  68 */     this.defaultLogoutUrl = loginPageUrl + "?logout";
/*  69 */     this.rememberMeServices = rememberMeServices;
/*  70 */     this.csrfEnabled = (csrfLogoutHandler != null);
/*  71 */     if (this.csrfEnabled) {
/*  72 */       this.logoutHandlers.add(csrfLogoutHandler);
/*     */     }
/*  74 */     this.authenticationFilterSecurityContextHolderStrategyRef = authenticationFilterSecurityContextHolderStrategyRef;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*  79 */     String logoutUrl = null;
/*  80 */     String successHandlerRef = null;
/*  81 */     String logoutSuccessUrl = null;
/*  82 */     String invalidateSession = null;
/*  83 */     String deleteCookies = null;
/*  84 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(LogoutFilter.class);
/*  85 */     if (element != null) {
/*  86 */       Object source = pc.extractSource(element);
/*  87 */       builder.getRawBeanDefinition().setSource(source);
/*  88 */       logoutUrl = element.getAttribute("logout-url");
/*  89 */       successHandlerRef = element.getAttribute("success-handler-ref");
/*  90 */       WebConfigUtils.validateHttpRedirect(logoutUrl, pc, source);
/*  91 */       logoutSuccessUrl = element.getAttribute("logout-success-url");
/*  92 */       WebConfigUtils.validateHttpRedirect(logoutSuccessUrl, pc, source);
/*  93 */       invalidateSession = element.getAttribute("invalidate-session");
/*  94 */       deleteCookies = element.getAttribute("delete-cookies");
/*     */     } 
/*  96 */     if (!StringUtils.hasText(logoutUrl)) {
/*  97 */       logoutUrl = "/logout";
/*     */     }
/*  99 */     builder.addPropertyValue("logoutRequestMatcher", getLogoutRequestMatcher(logoutUrl));
/* 100 */     if (StringUtils.hasText(successHandlerRef)) {
/* 101 */       if (StringUtils.hasText(logoutSuccessUrl)) {
/* 102 */         pc.getReaderContext()
/* 103 */           .error("Use logout-success-url or success-handler-ref, but not both", pc
/* 104 */             .extractSource(element));
/*     */       }
/* 106 */       builder.addConstructorArgReference(successHandlerRef);
/* 107 */       this.logoutSuccessHandler = (BeanMetadataElement)new RuntimeBeanReference(successHandlerRef);
/*     */     }
/*     */     else {
/*     */       
/* 111 */       if (!StringUtils.hasText(logoutSuccessUrl)) {
/* 112 */         logoutSuccessUrl = this.defaultLogoutUrl;
/*     */       }
/* 114 */       builder.addConstructorArgValue(logoutSuccessUrl);
/*     */     } 
/* 116 */     RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(SecurityContextLogoutHandler.class);
/* 117 */     rootBeanDefinition.getPropertyValues().addPropertyValue("invalidateHttpSession", Boolean.valueOf(!"false".equals(invalidateSession)));
/* 118 */     this.logoutHandlers.add(rootBeanDefinition);
/* 119 */     if (this.rememberMeServices != null) {
/* 120 */       this.logoutHandlers.add(new RuntimeBeanReference(this.rememberMeServices));
/*     */     }
/* 122 */     if (StringUtils.hasText(deleteCookies)) {
/* 123 */       RootBeanDefinition rootBeanDefinition1 = new RootBeanDefinition(CookieClearingLogoutHandler.class);
/* 124 */       String[] names = StringUtils.tokenizeToStringArray(deleteCookies, ",");
/* 125 */       rootBeanDefinition1.getConstructorArgumentValues().addGenericArgumentValue(names);
/* 126 */       this.logoutHandlers.add(rootBeanDefinition1);
/*     */     } 
/* 128 */     this.logoutHandlers.add(new RootBeanDefinition(LogoutSuccessEventPublishingLogoutHandler.class));
/* 129 */     builder.addConstructorArgValue(this.logoutHandlers);
/* 130 */     builder.addPropertyValue("securityContextHolderStrategy", this.authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 132 */     return (BeanDefinition)builder.getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanDefinition getLogoutRequestMatcher(String logoutUrl) {
/* 137 */     BeanDefinitionBuilder matcherBuilder = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class);
/* 138 */     matcherBuilder.addConstructorArgValue(logoutUrl);
/* 139 */     if (this.csrfEnabled) {
/* 140 */       matcherBuilder.addConstructorArgValue("POST");
/*     */     }
/* 142 */     return (BeanDefinition)matcherBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   ManagedList<BeanMetadataElement> getLogoutHandlers() {
/* 146 */     return this.logoutHandlers;
/*     */   }
/*     */   
/*     */   BeanMetadataElement getLogoutSuccessHandler() {
/* 150 */     return this.logoutSuccessHandler;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\LogoutBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */