/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SessionCreationPolicy
/*    */ {
/* 34 */   ALWAYS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   NEVER,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   IF_REQUIRED,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   STATELESS;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\SessionCreationPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */