/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.security.web.servlet.util.matcher.PathPatternRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class RequestMatcherFactoryBean
/*    */   implements FactoryBean<RequestMatcher>, ApplicationContextAware
/*    */ {
/*    */   private PathPatternRequestMatcher.Builder builder;
/*    */   private final HttpMethod method;
/*    */   private final String path;
/*    */   
/*    */   public RequestMatcherFactoryBean(String path) {
/* 38 */     this(path, null);
/*    */   }
/*    */   
/*    */   public RequestMatcherFactoryBean(String path, HttpMethod method) {
/* 42 */     this.method = method;
/* 43 */     this.path = path;
/*    */   }
/*    */ 
/*    */   
/*    */   public RequestMatcher getObject() throws Exception {
/* 48 */     if (this.builder != null) {
/* 49 */       return (RequestMatcher)this.builder.matcher(this.method, this.path);
/*    */     }
/* 51 */     return (RequestMatcher)new AntPathRequestMatcher(this.path, (this.method != null) ? this.method.name() : null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 56 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setApplicationContext(ApplicationContext context) throws BeansException {
/* 61 */     this.builder = (PathPatternRequestMatcher.Builder)context.getBeanProvider(PathPatternRequestMatcher.Builder.class).getIfUnique();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\RequestMatcherFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */