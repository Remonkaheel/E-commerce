/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
/*     */ import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
/*     */ import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RememberMeBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   static final String ATT_DATA_SOURCE = "data-source-ref";
/*     */   static final String ATT_SERVICES_REF = "services-ref";
/*     */   static final String ATT_SERVICES_ALIAS = "services-alias";
/*     */   static final String ATT_TOKEN_REPOSITORY = "token-repository-ref";
/*     */   static final String ATT_USER_SERVICE_REF = "user-service-ref";
/*     */   static final String ATT_SUCCESS_HANDLER_REF = "authentication-success-handler-ref";
/*     */   static final String ATT_TOKEN_VALIDITY = "token-validity-seconds";
/*     */   static final String ATT_SECURE_COOKIE = "use-secure-cookie";
/*     */   static final String ATT_FORM_REMEMBERME_PARAMETER = "remember-me-parameter";
/*     */   static final String ATT_REMEMBERME_COOKIE = "remember-me-cookie";
/*  68 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final String key;
/*     */   
/*     */   private final BeanReference authenticationManager;
/*     */   
/*     */   private final BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef;
/*     */   
/*     */   private String rememberMeServicesId;
/*     */ 
/*     */   
/*     */   RememberMeBeanDefinitionParser(String key, BeanReference authenticationManager, BeanMetadataElement authenticationFilterSecurityContextHolderStrategyRef) {
/*  80 */     this.key = key;
/*  81 */     this.authenticationManager = authenticationManager;
/*  82 */     this.authenticationFilterSecurityContextHolderStrategyRef = authenticationFilterSecurityContextHolderStrategyRef;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*     */     String servicesName;
/*  88 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), pc.extractSource(element));
/*  89 */     pc.pushContainingComponent(compositeDef);
/*  90 */     String tokenRepository = element.getAttribute("token-repository-ref");
/*  91 */     String dataSource = element.getAttribute("data-source-ref");
/*  92 */     String userServiceRef = element.getAttribute("user-service-ref");
/*  93 */     String successHandlerRef = element.getAttribute("authentication-success-handler-ref");
/*  94 */     String rememberMeServicesRef = element.getAttribute("services-ref");
/*  95 */     String tokenValiditySeconds = element.getAttribute("token-validity-seconds");
/*  96 */     String useSecureCookie = element.getAttribute("use-secure-cookie");
/*  97 */     String remembermeParameter = element.getAttribute("remember-me-parameter");
/*  98 */     String remembermeCookie = element.getAttribute("remember-me-cookie");
/*  99 */     Object source = pc.extractSource(element);
/* 100 */     RootBeanDefinition services = null;
/* 101 */     boolean dataSourceSet = StringUtils.hasText(dataSource);
/* 102 */     boolean tokenRepoSet = StringUtils.hasText(tokenRepository);
/* 103 */     boolean servicesRefSet = StringUtils.hasText(rememberMeServicesRef);
/* 104 */     boolean userServiceSet = StringUtils.hasText(userServiceRef);
/* 105 */     boolean useSecureCookieSet = StringUtils.hasText(useSecureCookie);
/* 106 */     boolean tokenValiditySet = StringUtils.hasText(tokenValiditySeconds);
/* 107 */     boolean remembermeParameterSet = StringUtils.hasText(remembermeParameter);
/* 108 */     boolean remembermeCookieSet = StringUtils.hasText(remembermeCookie);
/* 109 */     if (servicesRefSet && (dataSourceSet || tokenRepoSet || userServiceSet || tokenValiditySet || useSecureCookieSet || remembermeParameterSet || remembermeCookieSet))
/*     */     {
/* 111 */       pc.getReaderContext()
/* 112 */         .error("services-ref can't be used in combination with attributes token-repository-ref,data-source-ref, user-service-ref, token-validity-seconds, use-secure-cookie, remember-me-parameter or remember-me-cookie", source);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (dataSourceSet && tokenRepoSet) {
/* 118 */       pc.getReaderContext()
/* 119 */         .error("Specify token-repository-ref or data-source-ref but not both", source);
/*     */     }
/* 121 */     boolean isPersistent = dataSourceSet | tokenRepoSet;
/* 122 */     if (isPersistent) {
/*     */       Object tokenRepo;
/* 124 */       services = new RootBeanDefinition(PersistentTokenBasedRememberMeServices.class);
/* 125 */       if (tokenRepoSet) {
/* 126 */         tokenRepo = new RuntimeBeanReference(tokenRepository);
/*     */       } else {
/*     */         
/* 129 */         tokenRepo = new RootBeanDefinition(JdbcTokenRepositoryImpl.class);
/* 130 */         ((BeanDefinition)tokenRepo).getPropertyValues()
/* 131 */           .addPropertyValue("dataSource", new RuntimeBeanReference(dataSource));
/*     */       } 
/* 133 */       services.getConstructorArgumentValues().addIndexedArgumentValue(2, tokenRepo);
/*     */     }
/* 135 */     else if (!servicesRefSet) {
/* 136 */       services = new RootBeanDefinition(TokenBasedRememberMeServices.class);
/*     */     } 
/*     */     
/* 139 */     if (services != null) {
/* 140 */       RootBeanDefinition uds = new RootBeanDefinition();
/* 141 */       uds.setFactoryBeanName("org.springframework.security.userDetailsServiceFactory");
/* 142 */       uds.setFactoryMethodName("cachingUserDetailsService");
/* 143 */       uds.getConstructorArgumentValues().addGenericArgumentValue(userServiceRef);
/* 144 */       services.getConstructorArgumentValues().addGenericArgumentValue(this.key);
/* 145 */       services.getConstructorArgumentValues().addGenericArgumentValue(uds);
/*     */ 
/*     */       
/* 148 */       if (useSecureCookieSet) {
/* 149 */         services.getPropertyValues().addPropertyValue("useSecureCookie", Boolean.valueOf(useSecureCookie));
/*     */       }
/* 151 */       if (tokenValiditySet) {
/* 152 */         boolean isTokenValidityNegative = tokenValiditySeconds.startsWith("-");
/* 153 */         if (isTokenValidityNegative && isPersistent) {
/* 154 */           pc.getReaderContext()
/* 155 */             .error("token-validity-seconds cannot be negative if using a persistent remember-me token repository", source);
/*     */         }
/*     */         
/* 158 */         services.getPropertyValues().addPropertyValue("tokenValiditySeconds", tokenValiditySeconds);
/*     */       } 
/* 160 */       if (remembermeParameterSet) {
/* 161 */         services.getPropertyValues().addPropertyValue("parameter", remembermeParameter);
/*     */       }
/* 163 */       if (remembermeCookieSet) {
/* 164 */         services.getPropertyValues().addPropertyValue("cookieName", remembermeCookie);
/*     */       }
/* 166 */       services.setSource(source);
/* 167 */       servicesName = pc.getReaderContext().generateBeanName((BeanDefinition)services);
/* 168 */       pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)services, servicesName));
/*     */     } else {
/*     */       
/* 171 */       servicesName = rememberMeServicesRef;
/*     */     } 
/* 173 */     if (StringUtils.hasText(element.getAttribute("services-alias"))) {
/* 174 */       pc.getRegistry().registerAlias(servicesName, element.getAttribute("services-alias"));
/*     */     }
/* 176 */     this.rememberMeServicesId = servicesName;
/* 177 */     BeanDefinitionBuilder filter = BeanDefinitionBuilder.rootBeanDefinition(RememberMeAuthenticationFilter.class);
/* 178 */     filter.getRawBeanDefinition().setSource(source);
/* 179 */     if (StringUtils.hasText(successHandlerRef)) {
/* 180 */       filter.addPropertyReference("authenticationSuccessHandler", successHandlerRef);
/*     */     }
/* 182 */     filter.addConstructorArgValue(this.authenticationManager);
/* 183 */     filter.addConstructorArgReference(servicesName);
/* 184 */     filter.addPropertyValue("securityContextHolderStrategy", this.authenticationFilterSecurityContextHolderStrategyRef);
/*     */     
/* 186 */     pc.popAndRegisterContainingComponent();
/* 187 */     return (BeanDefinition)filter.getBeanDefinition();
/*     */   }
/*     */   
/*     */   String getRememberMeServicesId() {
/* 191 */     return this.rememberMeServicesId;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\RememberMeBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */