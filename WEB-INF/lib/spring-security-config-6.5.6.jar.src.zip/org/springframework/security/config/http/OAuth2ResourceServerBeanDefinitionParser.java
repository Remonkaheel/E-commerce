/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationManagerResolver;
/*     */ import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
/*     */ import org.springframework.security.oauth2.jwt.JwtDecoder;
/*     */ import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.OpaqueTokenAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.SpringOpaqueTokenIntrospector;
/*     */ import org.springframework.security.oauth2.server.resource.web.BearerTokenAuthenticationEntryPoint;
/*     */ import org.springframework.security.oauth2.server.resource.web.BearerTokenResolver;
/*     */ import org.springframework.security.oauth2.server.resource.web.DefaultBearerTokenResolver;
/*     */ import org.springframework.security.oauth2.server.resource.web.access.BearerTokenAccessDeniedHandler;
/*     */ import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OAuth2ResourceServerBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   static final String AUTHENTICATION_MANAGER_RESOLVER_REF = "authentication-manager-resolver-ref";
/*     */   static final String BEARER_TOKEN_RESOLVER_REF = "bearer-token-resolver-ref";
/*     */   static final String ENTRY_POINT_REF = "entry-point-ref";
/*     */   static final String BEARER_TOKEN_RESOLVER = "bearerTokenResolver";
/*     */   static final String AUTHENTICATION_ENTRY_POINT = "authenticationEntryPoint";
/*     */   private final BeanReference authenticationManager;
/*     */   private final List<BeanReference> authenticationProviders;
/*     */   private final Map<BeanDefinition, BeanMetadataElement> entryPoints;
/*     */   private final Map<BeanDefinition, BeanMetadataElement> deniedHandlers;
/*     */   private final List<BeanDefinition> ignoreCsrfRequestMatchers;
/*  83 */   private final BeanDefinition authenticationEntryPoint = (BeanDefinition)new RootBeanDefinition(BearerTokenAuthenticationEntryPoint.class);
/*     */ 
/*     */   
/*  86 */   private final BeanDefinition accessDeniedHandler = (BeanDefinition)new RootBeanDefinition(BearerTokenAccessDeniedHandler.class);
/*     */ 
/*     */   
/*     */   private final BeanMetadataElement authenticationFilterSecurityContextHolderStrategy;
/*     */ 
/*     */ 
/*     */   
/*     */   OAuth2ResourceServerBeanDefinitionParser(BeanReference authenticationManager, List<BeanReference> authenticationProviders, Map<BeanDefinition, BeanMetadataElement> entryPoints, Map<BeanDefinition, BeanMetadataElement> deniedHandlers, List<BeanDefinition> ignoreCsrfRequestMatchers, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/*  94 */     this.authenticationManager = authenticationManager;
/*  95 */     this.authenticationProviders = authenticationProviders;
/*  96 */     this.entryPoints = entryPoints;
/*  97 */     this.deniedHandlers = deniedHandlers;
/*  98 */     this.ignoreCsrfRequestMatchers = ignoreCsrfRequestMatchers;
/*  99 */     this.authenticationFilterSecurityContextHolderStrategy = authenticationFilterSecurityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element oauth2ResourceServer, ParserContext pc) {
/* 112 */     Element jwt = DomUtils.getChildElementByTagName(oauth2ResourceServer, "jwt");
/* 113 */     Element opaqueToken = DomUtils.getChildElementByTagName(oauth2ResourceServer, "opaque-token");
/* 114 */     validateConfiguration(oauth2ResourceServer, jwt, opaqueToken, pc);
/* 115 */     if (jwt != null) {
/* 116 */       BeanDefinition jwtAuthenticationProvider = (new JwtBeanDefinitionParser()).parse(jwt, pc);
/* 117 */       this.authenticationProviders.add(new RuntimeBeanReference(pc
/* 118 */             .getReaderContext().registerWithGeneratedName(jwtAuthenticationProvider)));
/*     */     } 
/* 120 */     if (opaqueToken != null) {
/* 121 */       BeanDefinition opaqueTokenAuthenticationProvider = (new OpaqueTokenBeanDefinitionParser()).parse(opaqueToken, pc);
/*     */       
/* 123 */       this.authenticationProviders.add(new RuntimeBeanReference(pc
/* 124 */             .getReaderContext().registerWithGeneratedName(opaqueTokenAuthenticationProvider)));
/*     */     } 
/* 126 */     BeanMetadataElement bearerTokenResolver = getBearerTokenResolver(oauth2ResourceServer);
/*     */     
/* 128 */     BeanDefinitionBuilder requestMatcherBuilder = BeanDefinitionBuilder.rootBeanDefinition(BearerTokenRequestMatcher.class);
/* 129 */     requestMatcherBuilder.addConstructorArgValue(bearerTokenResolver);
/* 130 */     AbstractBeanDefinition abstractBeanDefinition = requestMatcherBuilder.getBeanDefinition();
/* 131 */     BeanMetadataElement authenticationEntryPoint = getEntryPoint(oauth2ResourceServer);
/* 132 */     this.entryPoints.put(abstractBeanDefinition, authenticationEntryPoint);
/* 133 */     this.deniedHandlers.put(abstractBeanDefinition, this.accessDeniedHandler);
/* 134 */     this.ignoreCsrfRequestMatchers.add(abstractBeanDefinition);
/*     */     
/* 136 */     BeanDefinitionBuilder filterBuilder = BeanDefinitionBuilder.rootBeanDefinition(BearerTokenAuthenticationFilter.class);
/* 137 */     BeanMetadataElement authenticationManagerResolver = getAuthenticationManagerResolver(oauth2ResourceServer);
/* 138 */     filterBuilder.addConstructorArgValue(authenticationManagerResolver);
/* 139 */     filterBuilder.addPropertyValue("bearerTokenResolver", bearerTokenResolver);
/* 140 */     filterBuilder.addPropertyValue("authenticationEntryPoint", authenticationEntryPoint);
/* 141 */     filterBuilder.addPropertyValue("securityContextHolderStrategy", this.authenticationFilterSecurityContextHolderStrategy);
/*     */     
/* 143 */     return (BeanDefinition)filterBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   void validateConfiguration(Element oauth2ResourceServer, Element jwt, Element opaqueToken, ParserContext pc) {
/* 147 */     if (!oauth2ResourceServer.hasAttribute("authentication-manager-resolver-ref")) {
/* 148 */       if (jwt == null && opaqueToken == null) {
/* 149 */         pc.getReaderContext()
/* 150 */           .error("Didn't find authentication-manager-resolver-ref, <jwt>, or <opaque-token>. Please select one.", oauth2ResourceServer);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 155 */     if (jwt != null) {
/* 156 */       pc.getReaderContext()
/* 157 */         .error("Found <jwt> as well as authentication-manager-resolver-ref. Please select just one.", oauth2ResourceServer);
/*     */     }
/*     */     
/* 160 */     if (opaqueToken != null) {
/* 161 */       pc.getReaderContext()
/* 162 */         .error("Found <opaque-token> as well as authentication-manager-resolver-ref. Please select just one.", oauth2ResourceServer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   BeanMetadataElement getAuthenticationManagerResolver(Element element) {
/* 168 */     String authenticationManagerResolverRef = element.getAttribute("authentication-manager-resolver-ref");
/* 169 */     if (StringUtils.hasLength(authenticationManagerResolverRef)) {
/* 170 */       return (BeanMetadataElement)new RuntimeBeanReference(authenticationManagerResolverRef);
/*     */     }
/*     */     
/* 173 */     BeanDefinitionBuilder authenticationManagerResolver = BeanDefinitionBuilder.rootBeanDefinition(StaticAuthenticationManagerResolver.class);
/* 174 */     authenticationManagerResolver.addConstructorArgValue(this.authenticationManager);
/* 175 */     return (BeanMetadataElement)authenticationManagerResolver.getBeanDefinition();
/*     */   }
/*     */   
/*     */   BeanMetadataElement getBearerTokenResolver(Element element) {
/* 179 */     String bearerTokenResolverRef = element.getAttribute("bearer-token-resolver-ref");
/* 180 */     if (!StringUtils.hasLength(bearerTokenResolverRef)) {
/* 181 */       return (BeanMetadataElement)new RootBeanDefinition(DefaultBearerTokenResolver.class);
/*     */     }
/* 183 */     return (BeanMetadataElement)new RuntimeBeanReference(bearerTokenResolverRef);
/*     */   }
/*     */   
/*     */   BeanMetadataElement getEntryPoint(Element element) {
/* 187 */     String entryPointRef = element.getAttribute("entry-point-ref");
/* 188 */     if (!StringUtils.hasLength(entryPointRef)) {
/* 189 */       return (BeanMetadataElement)this.authenticationEntryPoint;
/*     */     }
/* 191 */     return (BeanMetadataElement)new RuntimeBeanReference(entryPointRef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class JwtBeanDefinitionParser
/*     */     implements BeanDefinitionParser
/*     */   {
/*     */     static final String DECODER_REF = "decoder-ref";
/*     */     
/*     */     static final String JWK_SET_URI = "jwk-set-uri";
/*     */     
/*     */     static final String JWT_AUTHENTICATION_CONVERTER_REF = "jwt-authentication-converter-ref";
/*     */     
/*     */     static final String JWT_AUTHENTICATION_CONVERTER = "jwtAuthenticationConverter";
/*     */ 
/*     */     
/*     */     public BeanDefinition parse(Element element, ParserContext pc) {
/* 209 */       validateConfiguration(element, pc);
/*     */       
/* 211 */       BeanDefinitionBuilder jwtProviderBuilder = BeanDefinitionBuilder.rootBeanDefinition(JwtAuthenticationProvider.class);
/* 212 */       jwtProviderBuilder.addConstructorArgValue(getDecoder(element));
/* 213 */       jwtProviderBuilder.addPropertyValue("jwtAuthenticationConverter", getJwtAuthenticationConverter(element));
/* 214 */       return (BeanDefinition)jwtProviderBuilder.getBeanDefinition();
/*     */     }
/*     */     
/*     */     void validateConfiguration(Element element, ParserContext pc) {
/* 218 */       boolean usesDecoder = element.hasAttribute("decoder-ref");
/* 219 */       boolean usesJwkSetUri = element.hasAttribute("jwk-set-uri");
/* 220 */       if (usesDecoder == usesJwkSetUri) {
/* 221 */         pc.getReaderContext().error("Please specify either decoder-ref or jwk-set-uri.", element);
/*     */       }
/*     */     }
/*     */     
/*     */     Object getDecoder(Element element) {
/* 226 */       String decoderRef = element.getAttribute("decoder-ref");
/* 227 */       if (StringUtils.hasLength(decoderRef)) {
/* 228 */         return new RuntimeBeanReference(decoderRef);
/*     */       }
/*     */       
/* 231 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(OAuth2ResourceServerBeanDefinitionParser.NimbusJwtDecoderJwkSetUriFactoryBean.class);
/* 232 */       builder.addConstructorArgValue(element.getAttribute("jwk-set-uri"));
/* 233 */       return builder.getBeanDefinition();
/*     */     }
/*     */     
/*     */     Object getJwtAuthenticationConverter(Element element) {
/* 237 */       String jwtDecoderRef = element.getAttribute("jwt-authentication-converter-ref");
/* 238 */       return StringUtils.hasLength(jwtDecoderRef) ? new RuntimeBeanReference(jwtDecoderRef) : 
/* 239 */         new JwtAuthenticationConverter();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class OpaqueTokenBeanDefinitionParser
/*     */     implements BeanDefinitionParser
/*     */   {
/*     */     static final String INTROSPECTOR_REF = "introspector-ref";
/*     */ 
/*     */     
/*     */     static final String INTROSPECTION_URI = "introspection-uri";
/*     */     
/*     */     static final String CLIENT_ID = "client-id";
/*     */     
/*     */     static final String CLIENT_SECRET = "client-secret";
/*     */     
/*     */     static final String AUTHENTICATION_CONVERTER_REF = "authentication-converter-ref";
/*     */     
/*     */     static final String AUTHENTICATION_CONVERTER = "authenticationConverter";
/*     */ 
/*     */     
/*     */     public BeanDefinition parse(Element element, ParserContext pc) {
/* 263 */       validateConfiguration(element, pc);
/* 264 */       BeanMetadataElement introspector = getIntrospector(element);
/* 265 */       String authenticationConverterRef = element.getAttribute("authentication-converter-ref");
/*     */       
/* 267 */       BeanDefinitionBuilder opaqueTokenProviderBuilder = BeanDefinitionBuilder.rootBeanDefinition(OpaqueTokenAuthenticationProvider.class);
/* 268 */       opaqueTokenProviderBuilder.addConstructorArgValue(introspector);
/* 269 */       if (StringUtils.hasText(authenticationConverterRef)) {
/* 270 */         opaqueTokenProviderBuilder.addPropertyReference("authenticationConverter", authenticationConverterRef);
/*     */       }
/* 272 */       return (BeanDefinition)opaqueTokenProviderBuilder.getBeanDefinition();
/*     */     }
/*     */     
/*     */     void validateConfiguration(Element element, ParserContext pc) {
/* 276 */       boolean usesIntrospector = element.hasAttribute("introspector-ref");
/*     */       
/* 278 */       boolean usesEndpoint = (element.hasAttribute("introspection-uri") || element.hasAttribute("client-id") || element.hasAttribute("client-secret"));
/* 279 */       if (usesIntrospector == usesEndpoint) {
/* 280 */         pc.getReaderContext()
/* 281 */           .error("Please specify either introspector-ref or all of introspection-uri, client-id, and client-secret.", element);
/*     */         
/*     */         return;
/*     */       } 
/* 285 */       if (usesEndpoint && (
/* 286 */         !element.hasAttribute("introspection-uri") || !element.hasAttribute("client-id") || 
/* 287 */         !element.hasAttribute("client-secret"))) {
/* 288 */         pc.getReaderContext()
/* 289 */           .error("Please specify introspection-uri, client-id, and client-secret together", element);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     BeanMetadataElement getIntrospector(Element element) {
/* 295 */       String introspectorRef = element.getAttribute("introspector-ref");
/* 296 */       if (StringUtils.hasLength(introspectorRef)) {
/* 297 */         return (BeanMetadataElement)new RuntimeBeanReference(introspectorRef);
/*     */       }
/* 299 */       String introspectionUri = element.getAttribute("introspection-uri");
/* 300 */       String clientId = element.getAttribute("client-id");
/* 301 */       String clientSecret = element.getAttribute("client-secret");
/*     */       
/* 303 */       BeanDefinitionBuilder introspectorBuilder = BeanDefinitionBuilder.rootBeanDefinition(SpringOpaqueTokenIntrospector.class);
/* 304 */       introspectorBuilder.addConstructorArgValue(introspectionUri);
/* 305 */       introspectorBuilder.addConstructorArgValue(clientId);
/* 306 */       introspectorBuilder.addConstructorArgValue(clientSecret);
/* 307 */       return (BeanMetadataElement)introspectorBuilder.getBeanDefinition();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class StaticAuthenticationManagerResolver
/*     */     implements AuthenticationManagerResolver<HttpServletRequest>
/*     */   {
/*     */     private final AuthenticationManager authenticationManager;
/*     */     
/*     */     StaticAuthenticationManagerResolver(AuthenticationManager authenticationManager) {
/* 318 */       this.authenticationManager = authenticationManager;
/*     */     }
/*     */ 
/*     */     
/*     */     public AuthenticationManager resolve(HttpServletRequest context) {
/* 323 */       return this.authenticationManager;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class NimbusJwtDecoderJwkSetUriFactoryBean
/*     */     implements FactoryBean<JwtDecoder>
/*     */   {
/*     */     private final String jwkSetUri;
/*     */     
/*     */     NimbusJwtDecoderJwkSetUriFactoryBean(String jwkSetUri) {
/* 333 */       this.jwkSetUri = jwkSetUri;
/*     */     }
/*     */ 
/*     */     
/*     */     public JwtDecoder getObject() {
/* 338 */       return (JwtDecoder)NimbusJwtDecoder.withJwkSetUri(this.jwkSetUri).build();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getObjectType() {
/* 343 */       return JwtDecoder.class;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class BearerTokenRequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/*     */     private final BearerTokenResolver bearerTokenResolver;
/*     */     
/*     */     BearerTokenRequestMatcher(BearerTokenResolver bearerTokenResolver) {
/* 353 */       Assert.notNull(bearerTokenResolver, "bearerTokenResolver cannot be null");
/* 354 */       this.bearerTokenResolver = bearerTokenResolver;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/*     */       try {
/* 360 */         return (this.bearerTokenResolver.resolve(request) != null);
/*     */       }
/* 362 */       catch (OAuth2AuthenticationException ex) {
/* 363 */         return false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2ResourceServerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */