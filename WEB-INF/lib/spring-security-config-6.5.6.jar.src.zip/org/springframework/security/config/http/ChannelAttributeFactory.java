/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.BeanCreationException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class ChannelAttributeFactory
/*    */ {
/*    */   private static final String OPT_REQUIRES_HTTP = "http";
/*    */   private static final String OPT_REQUIRES_HTTPS = "https";
/*    */   private static final String OPT_ANY_CHANNEL = "any";
/*    */   
/*    */   public static List<ConfigAttribute> createChannelAttributes(String requiredChannel) {
/* 54 */     switch (requiredChannel) { case "https": 
/*    */       case "http":
/*    */       
/*    */       case "any":
/* 58 */        }  throw new BeanCreationException("Unknown channel attribute " + requiredChannel);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\ChannelAttributeFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */