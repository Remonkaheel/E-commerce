/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JwtBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   static final String DECODER_REF = "decoder-ref";
/*     */   static final String JWK_SET_URI = "jwk-set-uri";
/*     */   static final String JWT_AUTHENTICATION_CONVERTER_REF = "jwt-authentication-converter-ref";
/*     */   static final String JWT_AUTHENTICATION_CONVERTER = "jwtAuthenticationConverter";
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/* 209 */     validateConfiguration(element, pc);
/*     */     
/* 211 */     BeanDefinitionBuilder jwtProviderBuilder = BeanDefinitionBuilder.rootBeanDefinition(JwtAuthenticationProvider.class);
/* 212 */     jwtProviderBuilder.addConstructorArgValue(getDecoder(element));
/* 213 */     jwtProviderBuilder.addPropertyValue("jwtAuthenticationConverter", getJwtAuthenticationConverter(element));
/* 214 */     return (BeanDefinition)jwtProviderBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   void validateConfiguration(Element element, ParserContext pc) {
/* 218 */     boolean usesDecoder = element.hasAttribute("decoder-ref");
/* 219 */     boolean usesJwkSetUri = element.hasAttribute("jwk-set-uri");
/* 220 */     if (usesDecoder == usesJwkSetUri) {
/* 221 */       pc.getReaderContext().error("Please specify either decoder-ref or jwk-set-uri.", element);
/*     */     }
/*     */   }
/*     */   
/*     */   Object getDecoder(Element element) {
/* 226 */     String decoderRef = element.getAttribute("decoder-ref");
/* 227 */     if (StringUtils.hasLength(decoderRef)) {
/* 228 */       return new RuntimeBeanReference(decoderRef);
/*     */     }
/*     */     
/* 231 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(OAuth2ResourceServerBeanDefinitionParser.NimbusJwtDecoderJwkSetUriFactoryBean.class);
/* 232 */     builder.addConstructorArgValue(element.getAttribute("jwk-set-uri"));
/* 233 */     return builder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   Object getJwtAuthenticationConverter(Element element) {
/* 237 */     String jwtDecoderRef = element.getAttribute("jwt-authentication-converter-ref");
/* 238 */     return StringUtils.hasLength(jwtDecoderRef) ? new RuntimeBeanReference(jwtDecoderRef) : 
/* 239 */       new JwtAuthenticationConverter();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2ResourceServerBeanDefinitionParser$JwtBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */