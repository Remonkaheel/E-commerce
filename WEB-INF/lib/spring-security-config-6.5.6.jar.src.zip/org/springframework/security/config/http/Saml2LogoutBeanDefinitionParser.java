/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.saml2.provider.service.web.DefaultRelyingPartyRegistrationResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutRequestFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2LogoutResponseFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.Saml2RelyingPartyInitiatedLogoutSuccessHandler;
/*     */ import org.springframework.security.web.authentication.logout.LogoutFilter;
/*     */ import org.springframework.security.web.authentication.logout.LogoutSuccessEventPublishingLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
/*     */ import org.springframework.security.web.util.matcher.AndRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.ParameterRequestMatcher;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Saml2LogoutBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ATT_LOGOUT_REQUEST_URL = "logout-request-url";
/*     */   private static final String ATT_LOGOUT_RESPONSE_URL = "logout-response-url";
/*     */   private static final String ATT_LOGOUT_URL = "logout-url";
/*     */   private List<BeanMetadataElement> logoutHandlers;
/*  65 */   private String logoutUrl = "/logout";
/*     */   
/*  67 */   private String logoutRequestUrl = "/logout/saml2/slo";
/*     */   
/*  69 */   private String logoutResponseUrl = "/logout/saml2/slo";
/*     */ 
/*     */   
/*     */   private BeanMetadataElement logoutSuccessHandler;
/*     */   
/*     */   private BeanDefinition logoutRequestFilter;
/*     */   
/*     */   private BeanDefinition logoutResponseFilter;
/*     */   
/*     */   private BeanDefinition logoutFilter;
/*     */   
/*     */   private BeanMetadataElement authenticationFilterSecurityContextHolderStrategy;
/*     */ 
/*     */   
/*     */   Saml2LogoutBeanDefinitionParser(ManagedList<BeanMetadataElement> logoutHandlers, BeanMetadataElement logoutSuccessHandler, BeanMetadataElement authenticationFilterSecurityContextHolderStrategy) {
/*  84 */     this.logoutHandlers = (List<BeanMetadataElement>)logoutHandlers;
/*  85 */     this.logoutSuccessHandler = logoutSuccessHandler;
/*  86 */     this.authenticationFilterSecurityContextHolderStrategy = authenticationFilterSecurityContextHolderStrategy;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*  91 */     String logoutUrl = element.getAttribute("logout-url");
/*  92 */     if (StringUtils.hasText(logoutUrl)) {
/*  93 */       this.logoutUrl = logoutUrl;
/*     */     }
/*  95 */     String logoutRequestUrl = element.getAttribute("logout-request-url");
/*  96 */     if (StringUtils.hasText(logoutRequestUrl)) {
/*  97 */       this.logoutRequestUrl = logoutRequestUrl;
/*     */     }
/*  99 */     String logoutResponseUrl = element.getAttribute("logout-response-url");
/* 100 */     if (StringUtils.hasText(logoutResponseUrl)) {
/* 101 */       this.logoutResponseUrl = logoutResponseUrl;
/*     */     }
/* 103 */     WebConfigUtils.validateHttpRedirect(this.logoutUrl, pc, element);
/* 104 */     WebConfigUtils.validateHttpRedirect(this.logoutRequestUrl, pc, element);
/* 105 */     WebConfigUtils.validateHttpRedirect(this.logoutResponseUrl, pc, element);
/* 106 */     if (CollectionUtils.isEmpty(this.logoutHandlers)) {
/* 107 */       this.logoutHandlers = createDefaultLogoutHandlers();
/*     */     }
/* 109 */     if (this.logoutSuccessHandler == null) {
/* 110 */       this.logoutSuccessHandler = createDefaultLogoutSuccessHandler();
/*     */     }
/*     */     
/* 113 */     BeanMetadataElement relyingPartyRegistrationRepository = Saml2LogoutBeanDefinitionParserUtils.getRelyingPartyRegistrationRepository(element);
/*     */ 
/*     */ 
/*     */     
/* 117 */     AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(DefaultRelyingPartyRegistrationResolver.class).addConstructorArgValue(relyingPartyRegistrationRepository).getBeanDefinition();
/*     */     
/* 119 */     BeanMetadataElement logoutResponseResolver = Saml2LogoutBeanDefinitionParserUtils.getLogoutResponseResolver(element, (BeanMetadataElement)abstractBeanDefinition1);
/*     */     
/* 121 */     BeanMetadataElement logoutRequestValidator = Saml2LogoutBeanDefinitionParserUtils.getLogoutRequestValidator(element);
/* 122 */     BeanMetadataElement logoutRequestMatcher = createSaml2LogoutRequestMatcher();
/* 123 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       .logoutRequestFilter = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(Saml2LogoutRequestFilter.class).addConstructorArgValue(abstractBeanDefinition1).addConstructorArgValue(logoutRequestValidator).addConstructorArgValue(logoutResponseResolver).addConstructorArgValue(this.logoutHandlers).addPropertyValue("logoutRequestMatcher", logoutRequestMatcher).addPropertyValue("securityContextHolderStrategy", this.authenticationFilterSecurityContextHolderStrategy).getBeanDefinition();
/*     */     
/* 132 */     BeanMetadataElement logoutResponseValidator = Saml2LogoutBeanDefinitionParserUtils.getLogoutResponseValidator(element);
/*     */     
/* 134 */     BeanMetadataElement logoutRequestRepository = Saml2LogoutBeanDefinitionParserUtils.getLogoutRequestRepository(element);
/* 135 */     BeanMetadataElement logoutResponseMatcher = createSaml2LogoutResponseMatcher();
/* 136 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       .logoutResponseFilter = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(Saml2LogoutResponseFilter.class).addConstructorArgValue(abstractBeanDefinition1).addConstructorArgValue(logoutResponseValidator).addConstructorArgValue(this.logoutSuccessHandler).addPropertyValue("logoutRequestMatcher", logoutResponseMatcher).addPropertyValue("logoutRequestRepository", logoutRequestRepository).getBeanDefinition();
/*     */     
/* 144 */     BeanMetadataElement logoutRequestResolver = Saml2LogoutBeanDefinitionParserUtils.getLogoutRequestResolver(element, (BeanMetadataElement)abstractBeanDefinition1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(Saml2RelyingPartyInitiatedLogoutSuccessHandler.class).addConstructorArgValue(logoutRequestResolver).addPropertyValue("logoutRequestRepository", logoutRequestRepository).getBeanDefinition();
/* 150 */     this
/*     */ 
/*     */ 
/*     */       
/* 154 */       .logoutFilter = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(LogoutFilter.class).addConstructorArgValue(abstractBeanDefinition2).addConstructorArgValue(this.logoutHandlers).addPropertyValue("logoutRequestMatcher", createLogoutRequestMatcher()).getBeanDefinition();
/* 155 */     return null;
/*     */   }
/*     */   
/*     */   private static List<BeanMetadataElement> createDefaultLogoutHandlers() {
/* 159 */     ManagedList<AbstractBeanDefinition> managedList = new ManagedList();
/* 160 */     managedList.add(BeanDefinitionBuilder.rootBeanDefinition(SecurityContextLogoutHandler.class).getBeanDefinition());
/* 161 */     managedList.add(BeanDefinitionBuilder.rootBeanDefinition(LogoutSuccessEventPublishingLogoutHandler.class)
/* 162 */         .getBeanDefinition());
/* 163 */     return (List)managedList;
/*     */   }
/*     */   
/*     */   private static BeanMetadataElement createDefaultLogoutSuccessHandler() {
/* 167 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(SimpleUrlLogoutSuccessHandler.class)
/* 168 */       .addPropertyValue("defaultTargetUrl", "/login?logout")
/* 169 */       .getBeanDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanMetadataElement createLogoutRequestMatcher() {
/* 176 */     AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class).addConstructorArgValue(this.logoutUrl).addConstructorArgValue("POST").getBeanDefinition();
/*     */ 
/*     */     
/* 179 */     AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(Saml2RequestMatcher.class).addPropertyValue("securityContextHolderStrategy", this.authenticationFilterSecurityContextHolderStrategy).getBeanDefinition();
/* 180 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(AndRequestMatcher.class)
/* 181 */       .addConstructorArgValue(toManagedList(new BeanMetadataElement[] { (BeanMetadataElement)abstractBeanDefinition1, (BeanMetadataElement)abstractBeanDefinition2
/* 182 */           })).getBeanDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanMetadataElement createSaml2LogoutRequestMatcher() {
/* 189 */     AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class).addConstructorArgValue(this.logoutRequestUrl).getBeanDefinition();
/*     */ 
/*     */ 
/*     */     
/* 193 */     AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(ParameterRequestMatcher.class).addConstructorArgValue("SAMLRequest").getBeanDefinition();
/* 194 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(AndRequestMatcher.class)
/* 195 */       .addConstructorArgValue(toManagedList(new BeanMetadataElement[] { (BeanMetadataElement)abstractBeanDefinition1, (BeanMetadataElement)abstractBeanDefinition2
/* 196 */           })).getBeanDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanMetadataElement createSaml2LogoutResponseMatcher() {
/* 203 */     AbstractBeanDefinition abstractBeanDefinition1 = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class).addConstructorArgValue(this.logoutResponseUrl).getBeanDefinition();
/*     */ 
/*     */ 
/*     */     
/* 207 */     AbstractBeanDefinition abstractBeanDefinition2 = BeanDefinitionBuilder.rootBeanDefinition(ParameterRequestMatcher.class).addConstructorArgValue("SAMLResponse").getBeanDefinition();
/* 208 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(AndRequestMatcher.class)
/* 209 */       .addConstructorArgValue(toManagedList(new BeanMetadataElement[] { (BeanMetadataElement)abstractBeanDefinition1, (BeanMetadataElement)abstractBeanDefinition2
/* 210 */           })).getBeanDefinition();
/*     */   }
/*     */   
/*     */   private static List<BeanMetadataElement> toManagedList(BeanMetadataElement... elements) {
/* 214 */     ManagedList managedList = new ManagedList();
/* 215 */     managedList.addAll(Arrays.asList(elements));
/* 216 */     return (List<BeanMetadataElement>)managedList;
/*     */   }
/*     */   
/*     */   BeanDefinition getLogoutRequestFilter() {
/* 220 */     return this.logoutRequestFilter;
/*     */   }
/*     */   
/*     */   BeanDefinition getLogoutResponseFilter() {
/* 224 */     return this.logoutResponseFilter;
/*     */   }
/*     */   
/*     */   BeanDefinition getLogoutFilter() {
/* 228 */     return this.logoutFilter;
/*     */   }
/*     */   
/*     */   public static class Saml2RequestMatcher
/*     */     implements RequestMatcher
/*     */   {
/* 234 */     private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */     
/*     */     public boolean matches(HttpServletRequest request) {
/* 238 */       Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 239 */       if (authentication == null) {
/* 240 */         return false;
/*     */       }
/* 242 */       return authentication.getPrincipal() instanceof org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
/*     */     }
/*     */     
/*     */     public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 246 */       this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\Saml2LogoutBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */