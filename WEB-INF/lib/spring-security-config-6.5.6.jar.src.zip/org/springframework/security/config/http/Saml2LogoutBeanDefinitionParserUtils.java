/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.opensaml.core.Version;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml4LogoutRequestValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml4LogoutResponseValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml5LogoutRequestValidator;
/*     */ import org.springframework.security.saml2.provider.service.authentication.logout.OpenSaml5LogoutResponseValidator;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.HttpSessionLogoutRequestRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml4LogoutRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml4LogoutResponseResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml5LogoutRequestResolver;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.logout.OpenSaml5LogoutResponseResolver;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Saml2LogoutBeanDefinitionParserUtils
/*     */ {
/*  43 */   private static final boolean USE_OPENSAML_5 = Version.getVersion().startsWith("5");
/*     */ 
/*     */   
/*     */   private static final String ATT_RELYING_PARTY_REGISTRATION_REPOSITORY_REF = "relying-party-registration-repository-ref";
/*     */ 
/*     */   
/*     */   private static final String ATT_LOGOUT_REQUEST_VALIDATOR_REF = "logout-request-validator-ref";
/*     */ 
/*     */   
/*     */   private static final String ATT_LOGOUT_REQUEST_REPOSITORY_REF = "logout-request-repository-ref";
/*     */   
/*     */   private static final String ATT_LOGOUT_REQUEST_RESOLVER_REF = "logout-request-resolver-ref";
/*     */   
/*     */   private static final String ATT_LOGOUT_RESPONSE_RESOLVER_REF = "logout-response-resolver-ref";
/*     */   
/*     */   private static final String ATT_LOGOUT_RESPONSE_VALIDATOR_REF = "logout-response-validator-ref";
/*     */ 
/*     */   
/*     */   static BeanMetadataElement getRelyingPartyRegistrationRepository(Element element) {
/*  62 */     String relyingPartyRegistrationRepositoryRef = element.getAttribute("relying-party-registration-repository-ref");
/*  63 */     if (StringUtils.hasText(relyingPartyRegistrationRepositoryRef)) {
/*  64 */       return (BeanMetadataElement)new RuntimeBeanReference(relyingPartyRegistrationRepositoryRef);
/*     */     }
/*  66 */     return (BeanMetadataElement)new RuntimeBeanReference(RelyingPartyRegistrationRepository.class);
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getLogoutResponseResolver(Element element, BeanMetadataElement registrations) {
/*  70 */     String logoutResponseResolver = element.getAttribute("logout-response-resolver-ref");
/*  71 */     if (StringUtils.hasText(logoutResponseResolver)) {
/*  72 */       return (BeanMetadataElement)new RuntimeBeanReference(logoutResponseResolver);
/*     */     }
/*  74 */     if (USE_OPENSAML_5) {
/*  75 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml5LogoutResponseResolver.class)
/*  76 */         .addConstructorArgValue(registrations)
/*  77 */         .getBeanDefinition();
/*     */     }
/*  79 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml4LogoutResponseResolver.class)
/*  80 */       .addConstructorArgValue(registrations)
/*  81 */       .getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getLogoutRequestValidator(Element element) {
/*  85 */     String logoutRequestValidator = element.getAttribute("logout-request-validator-ref");
/*  86 */     if (StringUtils.hasText(logoutRequestValidator)) {
/*  87 */       return (BeanMetadataElement)new RuntimeBeanReference(logoutRequestValidator);
/*     */     }
/*  89 */     if (USE_OPENSAML_5) {
/*  90 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml5LogoutRequestValidator.class).getBeanDefinition();
/*     */     }
/*  92 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml4LogoutRequestValidator.class).getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getLogoutResponseValidator(Element element) {
/*  96 */     String logoutResponseValidator = element.getAttribute("logout-response-validator-ref");
/*  97 */     if (StringUtils.hasText(logoutResponseValidator)) {
/*  98 */       return (BeanMetadataElement)new RuntimeBeanReference(logoutResponseValidator);
/*     */     }
/* 100 */     if (USE_OPENSAML_5) {
/* 101 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml5LogoutResponseValidator.class).getBeanDefinition();
/*     */     }
/* 103 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml4LogoutResponseValidator.class).getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getLogoutRequestRepository(Element element) {
/* 107 */     String logoutRequestRepository = element.getAttribute("logout-request-repository-ref");
/* 108 */     if (StringUtils.hasText(logoutRequestRepository)) {
/* 109 */       return (BeanMetadataElement)new RuntimeBeanReference(logoutRequestRepository);
/*     */     }
/* 111 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(HttpSessionLogoutRequestRepository.class).getBeanDefinition();
/*     */   }
/*     */   
/*     */   static BeanMetadataElement getLogoutRequestResolver(Element element, BeanMetadataElement registrations) {
/* 115 */     String logoutRequestResolver = element.getAttribute("logout-request-resolver-ref");
/* 116 */     if (StringUtils.hasText(logoutRequestResolver)) {
/* 117 */       return (BeanMetadataElement)new RuntimeBeanReference(logoutRequestResolver);
/*     */     }
/* 119 */     if (USE_OPENSAML_5) {
/* 120 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml5LogoutRequestResolver.class)
/* 121 */         .addConstructorArgValue(registrations)
/* 122 */         .getBeanDefinition();
/*     */     }
/* 124 */     return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(OpenSaml4LogoutRequestResolver.class)
/* 125 */       .addConstructorArgValue(registrations)
/* 126 */       .getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\Saml2LogoutBeanDefinitionParserUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */