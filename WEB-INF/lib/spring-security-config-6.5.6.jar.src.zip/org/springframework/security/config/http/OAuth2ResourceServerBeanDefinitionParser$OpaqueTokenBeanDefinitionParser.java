/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.oauth2.server.resource.authentication.OpaqueTokenAuthenticationProvider;
/*     */ import org.springframework.security.oauth2.server.resource.introspection.SpringOpaqueTokenIntrospector;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OpaqueTokenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   static final String INTROSPECTOR_REF = "introspector-ref";
/*     */   static final String INTROSPECTION_URI = "introspection-uri";
/*     */   static final String CLIENT_ID = "client-id";
/*     */   static final String CLIENT_SECRET = "client-secret";
/*     */   static final String AUTHENTICATION_CONVERTER_REF = "authentication-converter-ref";
/*     */   static final String AUTHENTICATION_CONVERTER = "authenticationConverter";
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/* 263 */     validateConfiguration(element, pc);
/* 264 */     BeanMetadataElement introspector = getIntrospector(element);
/* 265 */     String authenticationConverterRef = element.getAttribute("authentication-converter-ref");
/*     */     
/* 267 */     BeanDefinitionBuilder opaqueTokenProviderBuilder = BeanDefinitionBuilder.rootBeanDefinition(OpaqueTokenAuthenticationProvider.class);
/* 268 */     opaqueTokenProviderBuilder.addConstructorArgValue(introspector);
/* 269 */     if (StringUtils.hasText(authenticationConverterRef)) {
/* 270 */       opaqueTokenProviderBuilder.addPropertyReference("authenticationConverter", authenticationConverterRef);
/*     */     }
/* 272 */     return (BeanDefinition)opaqueTokenProviderBuilder.getBeanDefinition();
/*     */   }
/*     */   
/*     */   void validateConfiguration(Element element, ParserContext pc) {
/* 276 */     boolean usesIntrospector = element.hasAttribute("introspector-ref");
/*     */     
/* 278 */     boolean usesEndpoint = (element.hasAttribute("introspection-uri") || element.hasAttribute("client-id") || element.hasAttribute("client-secret"));
/* 279 */     if (usesIntrospector == usesEndpoint) {
/* 280 */       pc.getReaderContext()
/* 281 */         .error("Please specify either introspector-ref or all of introspection-uri, client-id, and client-secret.", element);
/*     */       
/*     */       return;
/*     */     } 
/* 285 */     if (usesEndpoint && (
/* 286 */       !element.hasAttribute("introspection-uri") || !element.hasAttribute("client-id") || 
/* 287 */       !element.hasAttribute("client-secret"))) {
/* 288 */       pc.getReaderContext()
/* 289 */         .error("Please specify introspection-uri, client-id, and client-secret together", element);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   BeanMetadataElement getIntrospector(Element element) {
/* 295 */     String introspectorRef = element.getAttribute("introspector-ref");
/* 296 */     if (StringUtils.hasLength(introspectorRef)) {
/* 297 */       return (BeanMetadataElement)new RuntimeBeanReference(introspectorRef);
/*     */     }
/* 299 */     String introspectionUri = element.getAttribute("introspection-uri");
/* 300 */     String clientId = element.getAttribute("client-id");
/* 301 */     String clientSecret = element.getAttribute("client-secret");
/*     */     
/* 303 */     BeanDefinitionBuilder introspectorBuilder = BeanDefinitionBuilder.rootBeanDefinition(SpringOpaqueTokenIntrospector.class);
/* 304 */     introspectorBuilder.addConstructorArgValue(introspectionUri);
/* 305 */     introspectorBuilder.addConstructorArgValue(clientId);
/* 306 */     introspectorBuilder.addConstructorArgValue(clientSecret);
/* 307 */     return (BeanMetadataElement)introspectorBuilder.getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2ResourceServerBeanDefinitionParser$OpaqueTokenBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */