/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
/*     */ import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
/*     */ import org.springframework.security.saml2.provider.service.web.Saml2WebSsoAuthenticationRequestFilter;
/*     */ import org.springframework.security.saml2.provider.service.web.authentication.Saml2WebSsoAuthenticationFilter;
/*     */ import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Saml2LoginBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String DEFAULT_LOGIN_URI = "/login";
/*     */   private static final String DEFAULT_AUTHENTICATION_REQUEST_PROCESSING_URL = "/saml2/authenticate/{registrationId}";
/*     */   private static final String ATT_LOGIN_PROCESSING_URL = "login-processing-url";
/*     */   private static final String ATT_LOGIN_PAGE = "login-page";
/*     */   private static final String ELT_RELYING_PARTY_REGISTRATION = "relying-party-registration";
/*     */   private static final String ELT_REGISTRATION_ID = "registration-id";
/*     */   private static final String ATT_AUTHENTICATION_FAILURE_HANDLER_REF = "authentication-failure-handler-ref";
/*     */   private static final String ATT_AUTHENTICATION_SUCCESS_HANDLER_REF = "authentication-success-handler-ref";
/*     */   private static final String ATT_AUTHENTICATION_MANAGER_REF = "authentication-manager-ref";
/*     */   private final List<BeanDefinition> csrfIgnoreRequestMatchers;
/*     */   private final BeanReference portMapper;
/*     */   private final BeanReference portResolver;
/*     */   private final BeanReference requestCache;
/*     */   private final boolean allowSessionCreation;
/*     */   private final BeanReference authenticationManager;
/*     */   private final BeanReference authenticationFilterSecurityContextRepositoryRef;
/*     */   private final List<BeanReference> authenticationProviders;
/*     */   private final Map<BeanDefinition, BeanMetadataElement> entryPoints;
/*  93 */   private String loginProcessingUrl = "/login/saml2/sso/{registrationId}";
/*     */ 
/*     */   
/*     */   private BeanDefinition saml2WebSsoAuthenticationRequestFilter;
/*     */ 
/*     */   
/*     */   private BeanDefinition saml2AuthenticationUrlToProviderName;
/*     */ 
/*     */   
/*     */   Saml2LoginBeanDefinitionParser(List<BeanDefinition> csrfIgnoreRequestMatchers, BeanReference portMapper, BeanReference portResolver, BeanReference requestCache, boolean allowSessionCreation, BeanReference authenticationManager, BeanReference authenticationFilterSecurityContextRepositoryRef, List<BeanReference> authenticationProviders, Map<BeanDefinition, BeanMetadataElement> entryPoints) {
/* 103 */     this.csrfIgnoreRequestMatchers = csrfIgnoreRequestMatchers;
/* 104 */     this.portMapper = portMapper;
/* 105 */     this.portResolver = portResolver;
/* 106 */     this.requestCache = requestCache;
/* 107 */     this.allowSessionCreation = allowSessionCreation;
/* 108 */     this.authenticationManager = authenticationManager;
/* 109 */     this.authenticationFilterSecurityContextRepositoryRef = authenticationFilterSecurityContextRepositoryRef;
/* 110 */     this.authenticationProviders = authenticationProviders;
/* 111 */     this.entryPoints = entryPoints;
/*     */   }
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*     */     BeanDefinition beanDefinition1;
/* 116 */     String loginProcessingUrl = element.getAttribute("login-processing-url");
/* 117 */     if (StringUtils.hasText(loginProcessingUrl)) {
/* 118 */       this.loginProcessingUrl = loginProcessingUrl;
/*     */     }
/*     */     
/* 121 */     AbstractBeanDefinition abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(Saml2LoginBeanConfig.class).getBeanDefinition();
/* 122 */     String saml2LoginBeanConfigId = pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/* 123 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, saml2LoginBeanConfigId));
/* 124 */     registerDefaultCsrfOverride();
/*     */     
/* 126 */     BeanMetadataElement relyingPartyRegistrationRepository = Saml2LoginBeanDefinitionParserUtils.getRelyingPartyRegistrationRepository(element);
/*     */     
/* 128 */     BeanMetadataElement authenticationRequestRepository = Saml2LoginBeanDefinitionParserUtils.getAuthenticationRequestRepository(element);
/*     */     
/* 130 */     BeanMetadataElement authenticationRequestResolver = Saml2LoginBeanDefinitionParserUtils.getAuthenticationRequestResolver(element);
/* 131 */     if (authenticationRequestResolver == null)
/*     */     {
/* 133 */       authenticationRequestResolver = Saml2LoginBeanDefinitionParserUtils.createDefaultAuthenticationRequestResolver(relyingPartyRegistrationRepository);
/*     */     }
/*     */     
/* 136 */     BeanMetadataElement authenticationConverter = Saml2LoginBeanDefinitionParserUtils.getAuthenticationConverter(element);
/* 137 */     if (authenticationConverter == null) {
/* 138 */       if (!this.loginProcessingUrl.contains("{registrationId}")) {
/* 139 */         pc.getReaderContext().error("loginProcessingUrl must contain {registrationId} path variable", element);
/*     */       }
/*     */       
/* 142 */       beanDefinition1 = Saml2LoginBeanDefinitionParserUtils.createDefaultAuthenticationConverter(relyingPartyRegistrationRepository);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     BeanDefinitionBuilder saml2WebSsoAuthenticationFilterBuilder = BeanDefinitionBuilder.rootBeanDefinition(Saml2WebSsoAuthenticationFilter.class).addConstructorArgValue(beanDefinition1).addConstructorArgValue(this.loginProcessingUrl).addPropertyValue("authenticationRequestRepository", authenticationRequestRepository);
/* 150 */     resolveLoginPage(element, pc);
/* 151 */     resolveAuthenticationSuccessHandler(element, saml2WebSsoAuthenticationFilterBuilder);
/* 152 */     resolveAuthenticationFailureHandler(element, saml2WebSsoAuthenticationFilterBuilder);
/* 153 */     resolveAuthenticationManager(element, saml2WebSsoAuthenticationFilterBuilder);
/* 154 */     resolveSecurityContextRepository(element, saml2WebSsoAuthenticationFilterBuilder);
/*     */     
/* 156 */     this
/*     */ 
/*     */ 
/*     */       
/* 160 */       .saml2WebSsoAuthenticationRequestFilter = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(Saml2WebSsoAuthenticationRequestFilter.class).addConstructorArgValue(authenticationRequestResolver).addPropertyValue("authenticationRequestRepository", authenticationRequestRepository).getBeanDefinition();
/* 161 */     BeanDefinition saml2AuthenticationProvider = Saml2LoginBeanDefinitionParserUtils.createAuthenticationProvider();
/* 162 */     this.authenticationProviders.add(new RuntimeBeanReference(pc
/* 163 */           .getReaderContext().registerWithGeneratedName(saml2AuthenticationProvider)));
/* 164 */     this
/*     */       
/* 166 */       .saml2AuthenticationUrlToProviderName = (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(Map.class).setFactoryMethodOnBean("getAuthenticationUrlToProviderName", saml2LoginBeanConfigId).getBeanDefinition();
/* 167 */     return (BeanDefinition)saml2WebSsoAuthenticationFilterBuilder.getBeanDefinition();
/*     */   }
/*     */ 
/*     */   
/*     */   private void resolveAuthenticationManager(Element element, BeanDefinitionBuilder saml2WebSsoAuthenticationFilterBuilder) {
/* 172 */     String authenticationManagerRef = element.getAttribute("authentication-manager-ref");
/* 173 */     if (StringUtils.hasText(authenticationManagerRef)) {
/* 174 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyReference("authenticationManager", authenticationManagerRef);
/*     */     }
/*     */     else {
/*     */       
/* 178 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyValue("authenticationManager", this.authenticationManager);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void resolveSecurityContextRepository(Element element, BeanDefinitionBuilder saml2WebSsoAuthenticationFilterBuilder) {
/* 185 */     if (this.authenticationFilterSecurityContextRepositoryRef != null) {
/* 186 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyValue("securityContextRepository", this.authenticationFilterSecurityContextRepositoryRef);
/*     */     }
/*     */   }
/*     */   
/*     */   private void resolveLoginPage(Element element, ParserContext parserContext) {
/*     */     AbstractBeanDefinition abstractBeanDefinition;
/* 192 */     String loginPage = element.getAttribute("login-page");
/* 193 */     Object source = parserContext.extractSource(element);
/* 194 */     BeanDefinition saml2LoginAuthenticationEntryPoint = null;
/* 195 */     if (StringUtils.hasText(loginPage)) {
/* 196 */       WebConfigUtils.validateHttpRedirect(loginPage, parserContext, source);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(LoginUrlAuthenticationEntryPoint.class).addConstructorArgValue(loginPage).addPropertyValue("portMapper", this.portMapper).addPropertyValue("portResolver", this.portResolver).getBeanDefinition();
/*     */     } else {
/*     */       
/* 205 */       Map<String, String> identityProviderUrlMap = getIdentityProviderUrlMap(element);
/* 206 */       if (identityProviderUrlMap.size() == 1) {
/* 207 */         String loginUrl = (String)((Map.Entry)identityProviderUrlMap.entrySet().iterator().next()).getKey();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 213 */         abstractBeanDefinition = BeanDefinitionBuilder.rootBeanDefinition(LoginUrlAuthenticationEntryPoint.class).addConstructorArgValue(loginUrl).addPropertyValue("portMapper", this.portMapper).addPropertyValue("portResolver", this.portResolver).getBeanDefinition();
/*     */       } 
/*     */     } 
/* 216 */     if (abstractBeanDefinition != null) {
/*     */       
/* 218 */       BeanDefinitionBuilder requestMatcherBuilder = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class);
/* 219 */       requestMatcherBuilder.addConstructorArgValue(this.loginProcessingUrl);
/* 220 */       AbstractBeanDefinition abstractBeanDefinition1 = requestMatcherBuilder.getBeanDefinition();
/* 221 */       this.entryPoints.put(abstractBeanDefinition1, abstractBeanDefinition);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void resolveAuthenticationFailureHandler(Element element, BeanDefinitionBuilder saml2WebSsoAuthenticationFilterBuilder) {
/* 227 */     String authenticationFailureHandlerRef = element.getAttribute("authentication-failure-handler-ref");
/* 228 */     if (StringUtils.hasText(authenticationFailureHandlerRef)) {
/* 229 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyReference("authenticationFailureHandler", authenticationFailureHandlerRef);
/*     */     }
/*     */     else {
/*     */       
/* 233 */       BeanDefinitionBuilder failureHandlerBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler");
/*     */       
/* 235 */       failureHandlerBuilder.addConstructorArgValue("/login?error");
/*     */       
/* 237 */       failureHandlerBuilder.addPropertyValue("allowSessionCreation", Boolean.valueOf(this.allowSessionCreation));
/* 238 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyValue("authenticationFailureHandler", failureHandlerBuilder
/* 239 */           .getBeanDefinition());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void resolveAuthenticationSuccessHandler(Element element, BeanDefinitionBuilder saml2WebSsoAuthenticationFilterBuilder) {
/* 245 */     String authenticationSuccessHandlerRef = element.getAttribute("authentication-success-handler-ref");
/* 246 */     if (StringUtils.hasText(authenticationSuccessHandlerRef)) {
/* 247 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyReference("authenticationSuccessHandler", authenticationSuccessHandlerRef);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 254 */       BeanDefinitionBuilder successHandlerBuilder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler").addPropertyValue("requestCache", this.requestCache);
/* 255 */       saml2WebSsoAuthenticationFilterBuilder.addPropertyValue("authenticationSuccessHandler", successHandlerBuilder
/* 256 */           .getBeanDefinition());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerDefaultCsrfOverride() {
/* 262 */     BeanDefinitionBuilder requestMatcherBuilder = BeanDefinitionBuilder.rootBeanDefinition(RequestMatcherFactoryBean.class);
/* 263 */     requestMatcherBuilder.addConstructorArgValue(this.loginProcessingUrl);
/* 264 */     AbstractBeanDefinition abstractBeanDefinition = requestMatcherBuilder.getBeanDefinition();
/* 265 */     this.csrfIgnoreRequestMatchers.add(abstractBeanDefinition);
/*     */   }
/*     */   
/*     */   private Map<String, String> getIdentityProviderUrlMap(Element element) {
/* 269 */     Map<String, String> idps = new LinkedHashMap<>();
/* 270 */     Element relyingPartyRegistrationsElt = DomUtils.getChildElementByTagName(element
/* 271 */         .getOwnerDocument().getDocumentElement(), "relying-party-registrations");
/* 272 */     String authenticationRequestProcessingUrl = "/saml2/authenticate/{registrationId}";
/* 273 */     if (relyingPartyRegistrationsElt != null) {
/* 274 */       List<Element> relyingPartyRegList = DomUtils.getChildElementsByTagName(relyingPartyRegistrationsElt, "relying-party-registration");
/*     */       
/* 276 */       for (Element relyingPartyReg : relyingPartyRegList) {
/* 277 */         String registrationId = relyingPartyReg.getAttribute("registration-id");
/* 278 */         idps.put(authenticationRequestProcessingUrl.replace("{registrationId}", registrationId), registrationId);
/*     */       } 
/*     */     } 
/*     */     
/* 282 */     return idps;
/*     */   }
/*     */   
/*     */   BeanDefinition getSaml2WebSsoAuthenticationRequestFilter() {
/* 286 */     return this.saml2WebSsoAuthenticationRequestFilter;
/*     */   }
/*     */   
/*     */   BeanDefinition getSaml2AuthenticationUrlToProviderName() {
/* 290 */     return this.saml2AuthenticationUrlToProviderName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Saml2LoginBeanConfig
/*     */     implements ApplicationContextAware
/*     */   {
/*     */     private ApplicationContext context;
/*     */ 
/*     */     
/*     */     Map<String, String> getAuthenticationUrlToProviderName() {
/* 302 */       Iterable<RelyingPartyRegistration> relyingPartyRegistrations = null;
/*     */       
/* 304 */       RelyingPartyRegistrationRepository relyingPartyRegistrationRepository = (RelyingPartyRegistrationRepository)this.context.getBean(RelyingPartyRegistrationRepository.class);
/* 305 */       ResolvableType type = ResolvableType.forInstance(relyingPartyRegistrationRepository).as(Iterable.class);
/* 306 */       if (type != ResolvableType.NONE && RelyingPartyRegistration.class
/* 307 */         .isAssignableFrom(type.resolveGenerics()[0])) {
/* 308 */         relyingPartyRegistrations = (Iterable<RelyingPartyRegistration>)relyingPartyRegistrationRepository;
/*     */       }
/* 310 */       if (relyingPartyRegistrations == null) {
/* 311 */         return Collections.emptyMap();
/*     */       }
/* 313 */       String authenticationRequestProcessingUrl = "/saml2/authenticate/{registrationId}";
/* 314 */       Map<String, String> saml2AuthenticationUrlToProviderName = new HashMap<>();
/* 315 */       relyingPartyRegistrations.forEach(registration -> saml2AuthenticationUrlToProviderName.put(authenticationRequestProcessingUrl.replace("{registrationId}", registration.getRegistrationId()), registration.getRegistrationId()));
/*     */ 
/*     */       
/* 318 */       return saml2AuthenticationUrlToProviderName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setApplicationContext(ApplicationContext context) throws BeansException {
/* 323 */       this.context = context;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\Saml2LoginBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */