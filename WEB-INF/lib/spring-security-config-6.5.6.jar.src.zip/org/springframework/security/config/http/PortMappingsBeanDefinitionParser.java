/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.ManagedMap;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.web.PortMapperImpl;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PortMappingsBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   public static final String ATT_HTTP_PORT = "http";
/*    */   public static final String ATT_HTTPS_PORT = "https";
/*    */   
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 49 */     RootBeanDefinition portMapper = new RootBeanDefinition(PortMapperImpl.class);
/* 50 */     portMapper.setSource(parserContext.extractSource(element));
/* 51 */     if (element != null) {
/* 52 */       List<Element> mappingElts = DomUtils.getChildElementsByTagName(element, "port-mapping");
/* 53 */       if (mappingElts.isEmpty()) {
/* 54 */         parserContext.getReaderContext().error("No port-mapping child elements specified", element);
/*    */       }
/* 56 */       ManagedMap<String, String> managedMap = new ManagedMap();
/* 57 */       for (Element elt : mappingElts) {
/* 58 */         String httpPort = elt.getAttribute("http");
/* 59 */         String httpsPort = elt.getAttribute("https");
/* 60 */         if (!StringUtils.hasText(httpPort)) {
/* 61 */           parserContext.getReaderContext().error("No http port supplied in port mapping", elt);
/*    */         }
/* 63 */         if (!StringUtils.hasText(httpsPort)) {
/* 64 */           parserContext.getReaderContext().error("No https port supplied in port mapping", elt);
/*    */         }
/* 66 */         managedMap.put(httpPort, httpsPort);
/*    */       } 
/* 68 */       portMapper.getPropertyValues().addPropertyValue("portMappings", managedMap);
/*    */     } 
/* 70 */     return (BeanDefinition)portMapper;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\PortMappingsBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */