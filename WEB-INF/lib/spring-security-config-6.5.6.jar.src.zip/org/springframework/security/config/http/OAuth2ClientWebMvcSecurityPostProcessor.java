/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.PropertyValue;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.BeanFactoryUtils;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
/*    */ import org.springframework.security.oauth2.client.web.method.annotation.OAuth2AuthorizedClientArgumentResolver;
/*    */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OAuth2ClientWebMvcSecurityPostProcessor
/*    */   implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware
/*    */ {
/*    */   private static final String CUSTOM_ARGUMENT_RESOLVERS_PROPERTY = "customArgumentResolvers";
/*    */   private BeanFactory beanFactory;
/*    */   
/*    */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 49 */     String[] clientRegistrationRepositoryBeanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.beanFactory, ClientRegistrationRepository.class, false, false);
/*    */     
/* 51 */     String[] authorizedClientRepositoryBeanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.beanFactory, OAuth2AuthorizedClientRepository.class, false, false);
/*    */     
/* 53 */     if (clientRegistrationRepositoryBeanNames.length != 1 || authorizedClientRepositoryBeanNames.length != 1) {
/*    */       return;
/*    */     }
/* 56 */     for (String beanName : registry.getBeanDefinitionNames()) {
/* 57 */       BeanDefinition beanDefinition = registry.getBeanDefinition(beanName);
/* 58 */       if (RequestMappingHandlerAdapter.class.getName().equals(beanDefinition.getBeanClassName())) {
/*    */         
/* 60 */         PropertyValue currentArgumentResolvers = beanDefinition.getPropertyValues().getPropertyValue("customArgumentResolvers");
/* 61 */         ManagedList<Object> argumentResolvers = new ManagedList();
/* 62 */         if (currentArgumentResolvers != null) {
/* 63 */           argumentResolvers.addAll((Collection)currentArgumentResolvers.getValue());
/*    */         }
/* 65 */         String[] authorizedClientManagerBeanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors((ListableBeanFactory)this.beanFactory, OAuth2AuthorizedClientManager.class, false, false);
/*    */ 
/*    */         
/* 68 */         BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(OAuth2AuthorizedClientArgumentResolver.class);
/* 69 */         if (authorizedClientManagerBeanNames.length == 1) {
/* 70 */           beanDefinitionBuilder.addConstructorArgReference(authorizedClientManagerBeanNames[0]);
/*    */         } else {
/*    */           
/* 73 */           beanDefinitionBuilder.addConstructorArgReference(clientRegistrationRepositoryBeanNames[0]);
/* 74 */           beanDefinitionBuilder.addConstructorArgReference(authorizedClientRepositoryBeanNames[0]);
/*    */         } 
/* 76 */         argumentResolvers.add(beanDefinitionBuilder.getBeanDefinition());
/* 77 */         beanDefinition.getPropertyValues().add("customArgumentResolvers", argumentResolvers);
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*    */ 
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 89 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\OAuth2ClientWebMvcSecurityPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */