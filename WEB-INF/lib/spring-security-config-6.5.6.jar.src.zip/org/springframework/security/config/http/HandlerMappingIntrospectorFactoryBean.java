/*    */ package org.springframework.security.config.http;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HandlerMappingIntrospectorFactoryBean
/*    */   implements FactoryBean<HandlerMappingIntrospector>, ApplicationContextAware
/*    */ {
/*    */   private static final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector";
/*    */   private ApplicationContext context;
/*    */   
/*    */   public HandlerMappingIntrospector getObject() {
/* 43 */     if (!this.context.containsBean("mvcHandlerMappingIntrospector")) {
/* 44 */       throw new NoSuchBeanDefinitionException("mvcHandlerMappingIntrospector", "A Bean named mvcHandlerMappingIntrospector of type " + HandlerMappingIntrospector.class
/*    */           
/* 46 */           .getName() + " is required to use MvcRequestMatcher. Please ensure Spring Security & Spring MVC are configured in a shared ApplicationContext.");
/*    */     }
/*    */ 
/*    */     
/* 50 */     return (HandlerMappingIntrospector)this.context.getBean("mvcHandlerMappingIntrospector", HandlerMappingIntrospector.class);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Class<?> getObjectType() {
/* 56 */     return HandlerMappingIntrospector.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 61 */     this.context = applicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\HandlerMappingIntrospectorFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */