/*     */ package org.springframework.security.config.http;
/*     */ 
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.ObservationAuthorizationManager;
/*     */ import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
/*     */ import org.springframework.security.web.access.intercept.RequestMatcherDelegatingAuthorizationManager;
/*     */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestMatcherDelegatingAuthorizationManagerFactory
/*     */   implements FactoryBean<AuthorizationManager<HttpServletRequest>>
/*     */ {
/*     */   private Map<RequestMatcher, AuthorizationManager<RequestAuthorizationContext>> beans;
/* 191 */   private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManager<HttpServletRequest> getObject() throws Exception {
/* 196 */     RequestMatcherDelegatingAuthorizationManager.Builder builder = RequestMatcherDelegatingAuthorizationManager.builder();
/* 197 */     for (Map.Entry<RequestMatcher, AuthorizationManager<RequestAuthorizationContext>> entry : this.beans
/* 198 */       .entrySet()) {
/* 199 */       builder.add(entry.getKey(), entry.getValue());
/*     */     }
/* 201 */     RequestMatcherDelegatingAuthorizationManager requestMatcherDelegatingAuthorizationManager = builder.build();
/* 202 */     if (!this.observationRegistry.isNoop()) {
/* 203 */       return (AuthorizationManager<HttpServletRequest>)new ObservationAuthorizationManager(this.observationRegistry, (AuthorizationManager)requestMatcherDelegatingAuthorizationManager);
/*     */     }
/* 205 */     return (AuthorizationManager<HttpServletRequest>)requestMatcherDelegatingAuthorizationManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getObjectType() {
/* 210 */     return AuthorizationManager.class;
/*     */   }
/*     */   
/*     */   public void setRequestMatcherMap(Map<RequestMatcher, AuthorizationManager<RequestAuthorizationContext>> beans) {
/* 214 */     this.beans = beans;
/*     */   }
/*     */   
/*     */   public void setObservationRegistry(ObservationRegistry observationRegistry) {
/* 218 */     this.observationRegistry = observationRegistry;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\http\AuthorizationFilterParser$RequestMatcherDelegatingAuthorizationManagerFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */