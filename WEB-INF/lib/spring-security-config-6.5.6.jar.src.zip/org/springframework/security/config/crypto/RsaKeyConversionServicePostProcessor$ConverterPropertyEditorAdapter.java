/*     */ package org.springframework.security.config.crypto;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConverterPropertyEditorAdapter<T>
/*     */   extends PropertyEditorSupport
/*     */ {
/*     */   private final Converter<String, T> converter;
/*     */   
/*     */   ConverterPropertyEditorAdapter(Converter<String, T> converter) {
/*  93 */     this.converter = converter;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAsText() {
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsText(String text) throws IllegalArgumentException {
/* 103 */     if (StringUtils.hasText(text)) {
/* 104 */       setValue(this.converter.convert(text));
/*     */     } else {
/*     */       
/* 107 */       setValue(null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\crypto\RsaKeyConversionServicePostProcessor$ConverterPropertyEditorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */