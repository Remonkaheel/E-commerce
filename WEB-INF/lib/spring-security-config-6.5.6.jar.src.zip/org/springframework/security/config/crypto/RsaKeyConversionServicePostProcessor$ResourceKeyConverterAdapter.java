/*     */ package org.springframework.security.config.crypto;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Key;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceKeyConverterAdapter<T extends Key>
/*     */   implements Converter<String, T>
/*     */ {
/* 115 */   private ResourceLoader resourceLoader = (ResourceLoader)new DefaultResourceLoader();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Converter<String, T> delegate;
/*     */ 
/*     */ 
/*     */   
/*     */   ResourceKeyConverterAdapter(Converter<InputStream, T> delegate) {
/* 124 */     this.delegate = pemInputStreamConverter().andThen(autoclose(delegate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T convert(String source) {
/* 132 */     return (T)this.delegate.convert(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setResourceLoader(ResourceLoader resourceLoader) {
/* 140 */     Assert.notNull(resourceLoader, "resourceLoader cannot be null");
/* 141 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */   
/*     */   private Converter<String, InputStream> pemInputStreamConverter() {
/* 145 */     return source -> source.startsWith("-----") ? toInputStream(source) : toInputStream(this.resourceLoader.getResource(source));
/*     */   }
/*     */ 
/*     */   
/*     */   private InputStream toInputStream(String raw) {
/* 150 */     return new ByteArrayInputStream(raw.getBytes(StandardCharsets.UTF_8));
/*     */   }
/*     */   
/*     */   private InputStream toInputStream(Resource resource) {
/*     */     try {
/* 155 */       return resource.getInputStream();
/*     */     }
/* 157 */     catch (IOException ex) {
/* 158 */       throw new UncheckedIOException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> Converter<InputStream, T> autoclose(Converter<InputStream, T> inputStreamKeyConverter) {
/* 163 */     return inputStream -> { try { InputStream is = inputStream; try { Object object = inputStreamKeyConverter.convert(is); if (is != null)
/* 164 */               is.close();  return object; } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */                 throw throwable; }
/*     */            }
/* 167 */         catch (IOException ex)
/*     */         { throw new UncheckedIOException(ex); }
/*     */       
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\crypto\RsaKeyConversionServicePostProcessor$ResourceKeyConverterAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */