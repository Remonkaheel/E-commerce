/*     */ package org.springframework.security.config.crypto;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Key;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.security.converter.RsaKeyConverters;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RsaKeyConversionServicePostProcessor
/*     */   implements BeanFactoryPostProcessor
/*     */ {
/*     */   private static final String CONVERSION_SERVICE_BEAN_NAME = "conversionService";
/*  54 */   private ResourceKeyConverterAdapter<RSAPublicKey> x509 = new ResourceKeyConverterAdapter<>(RsaKeyConverters.x509());
/*     */   
/*  56 */   private ResourceKeyConverterAdapter<RSAPrivateKey> pkcs8 = new ResourceKeyConverterAdapter<>(
/*  57 */       RsaKeyConverters.pkcs8());
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/*  60 */     Assert.notNull(resourceLoader, "resourceLoader cannot be null");
/*  61 */     this.x509.setResourceLoader(resourceLoader);
/*  62 */     this.pkcs8.setResourceLoader(resourceLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/*  67 */     if (hasUserDefinedConversionService(beanFactory)) {
/*     */       return;
/*     */     }
/*  70 */     ConversionService service = beanFactory.getConversionService();
/*  71 */     if (service instanceof ConverterRegistry) { ConverterRegistry registry = (ConverterRegistry)service;
/*  72 */       registry.addConverter(String.class, RSAPrivateKey.class, this.pkcs8);
/*  73 */       registry.addConverter(String.class, RSAPublicKey.class, this.x509); }
/*     */     else
/*     */     
/*  76 */     { beanFactory.addPropertyEditorRegistrar(registry -> {
/*     */             registry.registerCustomEditor(RSAPublicKey.class, new ConverterPropertyEditorAdapter(this.x509));
/*     */             registry.registerCustomEditor(RSAPrivateKey.class, new ConverterPropertyEditorAdapter(this.pkcs8));
/*     */           }); }
/*     */   
/*     */   }
/*     */   
/*     */   private boolean hasUserDefinedConversionService(ConfigurableListableBeanFactory beanFactory) {
/*  84 */     return (beanFactory.containsBean("conversionService") && beanFactory
/*  85 */       .isTypeMatch("conversionService", ConversionService.class));
/*     */   }
/*     */   
/*     */   private static class ConverterPropertyEditorAdapter<T>
/*     */     extends PropertyEditorSupport {
/*     */     private final Converter<String, T> converter;
/*     */     
/*     */     ConverterPropertyEditorAdapter(Converter<String, T> converter) {
/*  93 */       this.converter = converter;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAsText() {
/*  98 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setAsText(String text) throws IllegalArgumentException {
/* 103 */       if (StringUtils.hasText(text)) {
/* 104 */         setValue(this.converter.convert(text));
/*     */       } else {
/*     */         
/* 107 */         setValue(null);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ResourceKeyConverterAdapter<T extends Key>
/*     */     implements Converter<String, T>
/*     */   {
/* 115 */     private ResourceLoader resourceLoader = (ResourceLoader)new DefaultResourceLoader();
/*     */ 
/*     */ 
/*     */     
/*     */     private final Converter<String, T> delegate;
/*     */ 
/*     */ 
/*     */     
/*     */     ResourceKeyConverterAdapter(Converter<InputStream, T> delegate) {
/* 124 */       this.delegate = pemInputStreamConverter().andThen(autoclose(delegate));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T convert(String source) {
/* 132 */       return (T)this.delegate.convert(source);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setResourceLoader(ResourceLoader resourceLoader) {
/* 140 */       Assert.notNull(resourceLoader, "resourceLoader cannot be null");
/* 141 */       this.resourceLoader = resourceLoader;
/*     */     }
/*     */     
/*     */     private Converter<String, InputStream> pemInputStreamConverter() {
/* 145 */       return source -> source.startsWith("-----") ? toInputStream(source) : toInputStream(this.resourceLoader.getResource(source));
/*     */     }
/*     */ 
/*     */     
/*     */     private InputStream toInputStream(String raw) {
/* 150 */       return new ByteArrayInputStream(raw.getBytes(StandardCharsets.UTF_8));
/*     */     }
/*     */     
/*     */     private InputStream toInputStream(Resource resource) {
/*     */       try {
/* 155 */         return resource.getInputStream();
/*     */       }
/* 157 */       catch (IOException ex) {
/* 158 */         throw new UncheckedIOException(ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private <T> Converter<InputStream, T> autoclose(Converter<InputStream, T> inputStreamKeyConverter) {
/* 163 */       return inputStream -> { try { InputStream is = inputStream; try { Object object = inputStreamKeyConverter.convert(is); if (is != null)
/* 164 */                 is.close();  return object; } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */                   throw throwable; }
/*     */              }
/* 167 */           catch (IOException ex)
/*     */           { throw new UncheckedIOException(ex); }
/*     */         
/*     */         };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\crypto\RsaKeyConversionServicePostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */