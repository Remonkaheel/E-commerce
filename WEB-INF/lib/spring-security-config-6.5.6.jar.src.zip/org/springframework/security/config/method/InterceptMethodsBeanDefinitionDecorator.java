/*     */ package org.springframework.security.config.method;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.config.AbstractInterceptorDrivenBeanDefinitionDecorator;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionDecorator;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityInterceptor;
/*     */ import org.springframework.security.access.method.MapBasedMethodSecurityMetadataSource;
/*     */ import org.springframework.security.authorization.method.AuthorizationManagerBeforeMethodInterceptor;
/*     */ import org.springframework.security.authorization.method.MethodExpressionAuthorizationManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterceptMethodsBeanDefinitionDecorator
/*     */   implements BeanDefinitionDecorator
/*     */ {
/*  54 */   private final InternalAuthorizationManagerInterceptMethodsBeanDefinitionDecorator authorizationManagerDelegate = new InternalAuthorizationManagerInterceptMethodsBeanDefinitionDecorator();
/*     */   
/*  56 */   private final BeanDefinitionDecorator delegate = (BeanDefinitionDecorator)new InternalInterceptMethodsBeanDefinitionDecorator();
/*     */ 
/*     */   
/*     */   public BeanDefinitionHolder decorate(Node node, BeanDefinitionHolder definition, ParserContext parserContext) {
/*  60 */     if (this.authorizationManagerDelegate.supports(node)) {
/*  61 */       return this.authorizationManagerDelegate.decorate(node, definition, parserContext);
/*     */     }
/*  63 */     MethodConfigUtils.registerDefaultMethodAccessManagerIfNecessary(parserContext);
/*  64 */     return this.delegate.decorate(node, definition, parserContext);
/*     */   }
/*     */ 
/*     */   
/*     */   static class InternalAuthorizationManagerInterceptMethodsBeanDefinitionDecorator
/*     */     extends AbstractInterceptorDrivenBeanDefinitionDecorator
/*     */   {
/*     */     static final String ATT_METHOD = "method";
/*     */     
/*     */     static final String ATT_ACCESS = "access";
/*     */     
/*     */     private static final String ATT_USE_AUTHORIZATION_MGR = "use-authorization-manager";
/*     */     
/*     */     private static final String ATT_AUTHORIZATION_MGR = "authorization-manager-ref";
/*     */     
/*     */     protected BeanDefinition createInterceptorDefinition(Node node) {
/*  80 */       Element interceptMethodsElt = (Element)node;
/*     */       
/*  82 */       BeanDefinitionBuilder interceptor = BeanDefinitionBuilder.rootBeanDefinition(AuthorizationManagerBeforeMethodInterceptor.class);
/*  83 */       interceptor.setAutowireMode(2);
/*  84 */       ManagedMap<Pointcut, BeanMetadataElement> managedMap = new ManagedMap();
/*  85 */       List<Element> methods = DomUtils.getChildElementsByTagName(interceptMethodsElt, "protect");
/*  86 */       for (Element protectElt : methods) {
/*  87 */         managedMap.put(pointcut(interceptMethodsElt, protectElt), 
/*  88 */             authorizationManager(interceptMethodsElt, protectElt));
/*     */       }
/*  90 */       return (BeanDefinition)interceptor.addConstructorArgValue(Pointcut.TRUE)
/*  91 */         .addConstructorArgValue(authorizationManager((Map<Pointcut, BeanMetadataElement>)managedMap))
/*  92 */         .getBeanDefinition();
/*     */     }
/*     */     
/*     */     boolean supports(Node node) {
/*  96 */       Element interceptMethodsElt = (Element)node;
/*  97 */       if (StringUtils.hasText(interceptMethodsElt.getAttribute("authorization-manager-ref"))) {
/*  98 */         return true;
/*     */       }
/* 100 */       if (StringUtils.hasText(interceptMethodsElt.getAttribute("use-authorization-manager"))) {
/* 101 */         return Boolean.parseBoolean(interceptMethodsElt.getAttribute("use-authorization-manager"));
/*     */       }
/* 103 */       return true;
/*     */     }
/*     */     
/*     */     private Pointcut pointcut(Element interceptorElt, Element protectElt) {
/* 107 */       String method = protectElt.getAttribute("method");
/* 108 */       String parentBeanClass = ((Element)interceptorElt.getParentNode()).getAttribute("class");
/* 109 */       return PrefixBasedMethodMatcher.fromClass(parentBeanClass, method);
/*     */     }
/*     */     
/*     */     private BeanMetadataElement authorizationManager(Element interceptMethodsElt, Element protectElt) {
/* 113 */       String authorizationManager = interceptMethodsElt.getAttribute("authorization-manager-ref");
/* 114 */       if (StringUtils.hasText(authorizationManager)) {
/* 115 */         return (BeanMetadataElement)new RuntimeBeanReference(authorizationManager);
/*     */       }
/* 117 */       String access = protectElt.getAttribute("access");
/* 118 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(MethodExpressionAuthorizationManager.class)
/* 119 */         .addConstructorArgValue(access)
/* 120 */         .getBeanDefinition();
/*     */     }
/*     */     
/*     */     private BeanMetadataElement authorizationManager(Map<Pointcut, BeanMetadataElement> managers) {
/* 124 */       return (BeanMetadataElement)BeanDefinitionBuilder.rootBeanDefinition(PointcutDelegatingAuthorizationManager.class)
/* 125 */         .addConstructorArgValue(managers)
/* 126 */         .getBeanDefinition();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static class InternalInterceptMethodsBeanDefinitionDecorator
/*     */     extends AbstractInterceptorDrivenBeanDefinitionDecorator
/*     */   {
/*     */     static final String ATT_METHOD = "method";
/*     */ 
/*     */ 
/*     */     
/*     */     static final String ATT_ACCESS = "access";
/*     */ 
/*     */ 
/*     */     
/*     */     private static final String ATT_ACCESS_MGR = "access-decision-manager-ref";
/*     */ 
/*     */ 
/*     */     
/*     */     protected BeanDefinition createInterceptorDefinition(Node node) {
/* 150 */       Element interceptMethodsElt = (Element)node;
/*     */       
/* 152 */       BeanDefinitionBuilder interceptor = BeanDefinitionBuilder.rootBeanDefinition(MethodSecurityInterceptor.class);
/*     */       
/* 154 */       interceptor.setAutowireMode(2);
/* 155 */       String accessManagerId = interceptMethodsElt.getAttribute("access-decision-manager-ref");
/* 156 */       if (!StringUtils.hasText(accessManagerId)) {
/* 157 */         accessManagerId = "org.springframework.security.defaultMethodAccessManager";
/*     */       }
/* 159 */       interceptor.addPropertyValue("accessDecisionManager", new RuntimeBeanReference(accessManagerId));
/* 160 */       interceptor.addPropertyValue("authenticationManager", new RuntimeBeanReference("org.springframework.security.authenticationManager"));
/*     */ 
/*     */       
/* 163 */       String parentBeanClass = ((Element)interceptMethodsElt.getParentNode()).getAttribute("class");
/*     */       
/* 165 */       List<Element> methods = DomUtils.getChildElementsByTagName(interceptMethodsElt, "protect");
/* 166 */       ManagedMap<String, AbstractBeanDefinition> managedMap = new ManagedMap();
/* 167 */       for (Element protectmethodElt : methods) {
/* 168 */         BeanDefinitionBuilder attributeBuilder = BeanDefinitionBuilder.rootBeanDefinition(SecurityConfig.class);
/* 169 */         attributeBuilder.setFactoryMethod("createListFromCommaDelimitedString");
/* 170 */         attributeBuilder.addConstructorArgValue(protectmethodElt.getAttribute("access"));
/*     */         
/* 172 */         String methodName = protectmethodElt.getAttribute("method");
/* 173 */         if (methodName.lastIndexOf(".") == -1 && 
/* 174 */           parentBeanClass != null && !"".equals(parentBeanClass)) {
/* 175 */           methodName = parentBeanClass + "." + parentBeanClass;
/*     */         }
/*     */         
/* 178 */         managedMap.put(methodName, attributeBuilder.getBeanDefinition());
/*     */       } 
/* 180 */       RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(MapBasedMethodSecurityMetadataSource.class);
/* 181 */       rootBeanDefinition.getConstructorArgumentValues().addGenericArgumentValue(managedMap);
/* 182 */       interceptor.addPropertyValue("securityMetadataSource", rootBeanDefinition);
/* 183 */       return (BeanDefinition)interceptor.getBeanDefinition();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\method\InterceptMethodsBeanDefinitionDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */