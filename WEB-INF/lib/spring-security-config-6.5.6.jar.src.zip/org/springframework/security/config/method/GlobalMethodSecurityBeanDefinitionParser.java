/*     */ package org.springframework.security.config.method;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.config.AopNamespaceUtils;
/*     */ import org.springframework.aop.framework.ProxyFactoryBean;
/*     */ import org.springframework.aop.target.LazyInitTargetSource;
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.access.annotation.Jsr250MethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.annotation.Jsr250Voter;
/*     */ import org.springframework.security.access.annotation.SecuredAnnotationSecurityMetadataSource;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedAnnotationAttributeFactory;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedPostInvocationAdvice;
/*     */ import org.springframework.security.access.expression.method.ExpressionBasedPreInvocationAdvice;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.intercept.AfterInvocationProviderManager;
/*     */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityInterceptor;
/*     */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityMetadataSourceAdvisor;
/*     */ import org.springframework.security.access.intercept.aspectj.AspectJMethodSecurityInterceptor;
/*     */ import org.springframework.security.access.method.DelegatingMethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.method.MapBasedMethodSecurityMetadataSource;
/*     */ import org.springframework.security.access.prepost.PostInvocationAdviceProvider;
/*     */ import org.springframework.security.access.prepost.PreInvocationAuthorizationAdviceVoter;
/*     */ import org.springframework.security.access.prepost.PrePostAnnotationSecurityMetadataSource;
/*     */ import org.springframework.security.access.vote.AffirmativeBased;
/*     */ import org.springframework.security.access.vote.AuthenticatedVoter;
/*     */ import org.springframework.security.access.vote.RoleVoter;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.config.core.GrantedAuthorityDefaults;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GlobalMethodSecurityBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*  98 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private static final String ATT_AUTHENTICATION_MANAGER_REF = "authentication-manager-ref";
/*     */   
/*     */   private static final String ATT_ACCESS = "access";
/*     */   
/*     */   private static final String ATT_EXPRESSION = "expression";
/*     */   
/*     */   private static final String ATT_ACCESS_MGR = "access-decision-manager-ref";
/*     */   
/*     */   private static final String ATT_RUN_AS_MGR = "run-as-manager-ref";
/*     */   
/*     */   private static final String ATT_USE_JSR250 = "jsr250-annotations";
/*     */   
/*     */   private static final String ATT_USE_SECURED = "secured-annotations";
/*     */   
/*     */   private static final String ATT_USE_PREPOST = "pre-post-annotations";
/*     */   
/*     */   private static final String ATT_REF = "ref";
/*     */   
/*     */   private static final String ATT_MODE = "mode";
/*     */   
/*     */   private static final String ATT_ADVICE_ORDER = "order";
/*     */   
/*     */   private static final String ATT_META_DATA_SOURCE_REF = "metadata-source-ref";
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext pc) {
/*     */     AbstractBeanDefinition abstractBeanDefinition;
/* 127 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), pc.extractSource(element));
/* 128 */     pc.pushContainingComponent(compositeDef);
/* 129 */     Object source = pc.extractSource(element);
/*     */     
/* 131 */     ManagedList<BeanMetadataElement> delegates = new ManagedList();
/* 132 */     boolean jsr250Enabled = "enabled".equals(element.getAttribute("jsr250-annotations"));
/* 133 */     boolean useSecured = "enabled".equals(element.getAttribute("secured-annotations"));
/* 134 */     boolean prePostAnnotationsEnabled = "enabled".equals(element.getAttribute("pre-post-annotations"));
/* 135 */     boolean useAspectJ = "aspectj".equals(element.getAttribute("mode"));
/* 136 */     BeanDefinition preInvocationVoter = null;
/* 137 */     ManagedList<BeanMetadataElement> afterInvocationProviders = new ManagedList();
/*     */ 
/*     */     
/* 140 */     String metaDataSourceId = element.getAttribute("metadata-source-ref");
/* 141 */     if (StringUtils.hasText(metaDataSourceId)) {
/* 142 */       delegates.add(new RuntimeBeanReference(metaDataSourceId));
/*     */     }
/* 144 */     if (prePostAnnotationsEnabled) {
/* 145 */       Element prePostElt = DomUtils.getChildElementByTagName(element, "pre-post-annotation-handling");
/* 146 */       Element expressionHandlerElt = DomUtils.getChildElementByTagName(element, "expression-handler");
/* 147 */       if (prePostElt != null && expressionHandlerElt != null) {
/* 148 */         pc.getReaderContext()
/* 149 */           .error("pre-post-annotation-handling and expression-handler cannot be used together ", source);
/*     */       }
/*     */ 
/*     */       
/* 153 */       BeanDefinitionBuilder preInvocationVoterBldr = BeanDefinitionBuilder.rootBeanDefinition(PreInvocationAuthorizationAdviceVoter.class);
/*     */ 
/*     */ 
/*     */       
/* 157 */       BeanDefinitionBuilder afterInvocationBldr = BeanDefinitionBuilder.rootBeanDefinition(PostInvocationAdviceProvider.class);
/*     */ 
/*     */       
/* 160 */       BeanDefinitionBuilder mds = BeanDefinitionBuilder.rootBeanDefinition(PrePostAnnotationSecurityMetadataSource.class);
/* 161 */       if (prePostElt != null) {
/*     */ 
/*     */ 
/*     */         
/* 165 */         String attributeFactoryRef = DomUtils.getChildElementByTagName(prePostElt, "invocation-attribute-factory").getAttribute("ref");
/*     */         
/* 167 */         String preAdviceRef = DomUtils.getChildElementByTagName(prePostElt, "pre-invocation-advice").getAttribute("ref");
/*     */         
/* 169 */         String postAdviceRef = DomUtils.getChildElementByTagName(prePostElt, "post-invocation-advice").getAttribute("ref");
/* 170 */         mds.addConstructorArgReference(attributeFactoryRef);
/* 171 */         preInvocationVoterBldr.addConstructorArgReference(preAdviceRef);
/* 172 */         afterInvocationBldr.addConstructorArgReference(postAdviceRef);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 177 */         String expressionHandlerRef = (expressionHandlerElt != null) ? expressionHandlerElt.getAttribute("ref") : null;
/* 178 */         if (StringUtils.hasText(expressionHandlerRef)) {
/* 179 */           this.logger.info(LogMessage.format("Using bean '%s' as method ExpressionHandler implementation", expressionHandlerRef));
/*     */           
/* 181 */           RootBeanDefinition lazyInitPP = new RootBeanDefinition(LazyInitBeanDefinitionRegistryPostProcessor.class);
/*     */           
/* 183 */           lazyInitPP.getConstructorArgumentValues().addGenericArgumentValue(expressionHandlerRef);
/* 184 */           pc.getReaderContext().registerWithGeneratedName((BeanDefinition)lazyInitPP);
/*     */           
/* 186 */           BeanDefinitionBuilder lazyMethodSecurityExpressionHandlerBldr = BeanDefinitionBuilder.rootBeanDefinition(LazyInitTargetSource.class);
/* 187 */           lazyMethodSecurityExpressionHandlerBldr.addPropertyValue("targetBeanName", expressionHandlerRef);
/*     */           
/* 189 */           BeanDefinitionBuilder expressionHandlerProxyBldr = BeanDefinitionBuilder.rootBeanDefinition(ProxyFactoryBean.class);
/* 190 */           expressionHandlerProxyBldr.addPropertyValue("targetSource", lazyMethodSecurityExpressionHandlerBldr
/* 191 */               .getBeanDefinition());
/* 192 */           expressionHandlerProxyBldr.addPropertyValue("proxyInterfaces", MethodSecurityExpressionHandler.class);
/*     */ 
/*     */           
/* 195 */           expressionHandlerRef = pc.getReaderContext().generateBeanName((BeanDefinition)expressionHandlerProxyBldr.getBeanDefinition());
/* 196 */           pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)expressionHandlerProxyBldr.getBeanDefinition(), expressionHandlerRef));
/*     */         }
/*     */         else {
/*     */           
/* 200 */           RootBeanDefinition expressionHandler = registerWithDefaultRolePrefix(pc, (Class)DefaultMethodSecurityExpressionHandlerBeanFactory.class);
/*     */           
/* 202 */           expressionHandlerRef = pc.getReaderContext().generateBeanName((BeanDefinition)expressionHandler);
/* 203 */           pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)expressionHandler, expressionHandlerRef));
/* 204 */           this.logger.info("Expressions were enabled for method security but no SecurityExpressionHandler was configured. All hasPermission() expressions will evaluate to false.");
/*     */         } 
/*     */ 
/*     */         
/* 208 */         BeanDefinitionBuilder expressionPreAdviceBldr = BeanDefinitionBuilder.rootBeanDefinition(ExpressionBasedPreInvocationAdvice.class);
/* 209 */         expressionPreAdviceBldr.addPropertyReference("expressionHandler", expressionHandlerRef);
/* 210 */         preInvocationVoterBldr.addConstructorArgValue(expressionPreAdviceBldr.getBeanDefinition());
/*     */         
/* 212 */         BeanDefinitionBuilder expressionPostAdviceBldr = BeanDefinitionBuilder.rootBeanDefinition(ExpressionBasedPostInvocationAdvice.class);
/* 213 */         expressionPostAdviceBldr.addConstructorArgReference(expressionHandlerRef);
/* 214 */         afterInvocationBldr.addConstructorArgValue(expressionPostAdviceBldr.getBeanDefinition());
/*     */         
/* 216 */         BeanDefinitionBuilder annotationInvocationFactory = BeanDefinitionBuilder.rootBeanDefinition(ExpressionBasedAnnotationAttributeFactory.class);
/* 217 */         annotationInvocationFactory.addConstructorArgReference(expressionHandlerRef);
/* 218 */         mds.addConstructorArgValue(annotationInvocationFactory.getBeanDefinition());
/*     */       } 
/* 220 */       abstractBeanDefinition = preInvocationVoterBldr.getBeanDefinition();
/* 221 */       afterInvocationProviders.add(afterInvocationBldr.getBeanDefinition());
/* 222 */       delegates.add(mds.getBeanDefinition());
/*     */     } 
/* 224 */     if (useSecured) {
/* 225 */       delegates.add(BeanDefinitionBuilder.rootBeanDefinition(SecuredAnnotationSecurityMetadataSource.class)
/* 226 */           .getBeanDefinition());
/*     */     }
/* 228 */     if (jsr250Enabled) {
/* 229 */       RootBeanDefinition jsrMetadataSource = registerWithDefaultRolePrefix(pc, (Class)Jsr250MethodSecurityMetadataSourceBeanFactory.class);
/*     */       
/* 231 */       delegates.add(jsrMetadataSource);
/*     */     } 
/*     */ 
/*     */     
/* 235 */     Map<String, List<ConfigAttribute>> pointcutMap = parseProtectPointcuts(pc, 
/* 236 */         DomUtils.getChildElementsByTagName(element, "protect-pointcut"));
/* 237 */     if (pointcutMap.size() > 0) {
/* 238 */       if (useAspectJ) {
/* 239 */         pc.getReaderContext().error("You can't use AspectJ mode with protect-pointcut definitions", source);
/*     */       }
/*     */       
/* 242 */       RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(MapBasedMethodSecurityMetadataSource.class);
/*     */       
/* 244 */       RuntimeBeanReference runtimeBeanReference = new RuntimeBeanReference(pc.getReaderContext().generateBeanName((BeanDefinition)rootBeanDefinition));
/* 245 */       delegates.add(runtimeBeanReference);
/* 246 */       pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)rootBeanDefinition, runtimeBeanReference.getBeanName()));
/* 247 */       registerProtectPointcutPostProcessor(pc, pointcutMap, (BeanReference)runtimeBeanReference, source);
/*     */     } 
/* 249 */     BeanReference metadataSource = registerDelegatingMethodSecurityMetadataSource(pc, delegates, source);
/*     */     
/* 251 */     List<Element> afterInvocationElts = DomUtils.getChildElementsByTagName(element, "after-invocation-provider");
/*     */     
/* 253 */     for (Element elt : afterInvocationElts) {
/* 254 */       afterInvocationProviders.add(new RuntimeBeanReference(elt.getAttribute("ref")));
/*     */     }
/* 256 */     String accessManagerId = element.getAttribute("access-decision-manager-ref");
/* 257 */     if (!StringUtils.hasText(accessManagerId)) {
/* 258 */       accessManagerId = registerAccessManager(pc, jsr250Enabled, (BeanDefinition)abstractBeanDefinition);
/*     */     }
/* 260 */     String authMgrRef = element.getAttribute("authentication-manager-ref");
/* 261 */     String runAsManagerId = element.getAttribute("run-as-manager-ref");
/* 262 */     BeanReference interceptor = registerMethodSecurityInterceptor(pc, authMgrRef, accessManagerId, runAsManagerId, metadataSource, (List<BeanMetadataElement>)afterInvocationProviders, source, useAspectJ);
/*     */     
/* 264 */     if (useAspectJ) {
/* 265 */       BeanDefinitionBuilder aspect = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.security.access.intercept.aspectj.aspect.AnnotationSecurityAspect");
/*     */       
/* 267 */       aspect.setFactoryMethod("aspectOf");
/* 268 */       aspect.setRole(2);
/* 269 */       aspect.addPropertyValue("securityInterceptor", interceptor);
/* 270 */       String id = pc.getReaderContext().registerWithGeneratedName((BeanDefinition)aspect.getBeanDefinition());
/* 271 */       pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)aspect.getBeanDefinition(), id));
/*     */     } else {
/*     */       
/* 274 */       registerAdvisor(pc, interceptor, metadataSource, source, element.getAttribute("order"));
/* 275 */       AopNamespaceUtils.registerAutoProxyCreatorIfNecessary(pc, element);
/*     */     } 
/* 277 */     pc.popAndRegisterContainingComponent();
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String registerAccessManager(ParserContext pc, boolean jsr250Enabled, BeanDefinition expressionVoter) {
/* 288 */     BeanDefinitionBuilder accessMgrBuilder = BeanDefinitionBuilder.rootBeanDefinition(AffirmativeBased.class);
/* 289 */     ManagedList voters = new ManagedList(4);
/* 290 */     if (expressionVoter != null) {
/* 291 */       voters.add(expressionVoter);
/*     */     }
/* 293 */     voters.add(new RootBeanDefinition(RoleVoter.class));
/* 294 */     voters.add(new RootBeanDefinition(AuthenticatedVoter.class));
/* 295 */     if (jsr250Enabled) {
/* 296 */       voters.add(new RootBeanDefinition(Jsr250Voter.class));
/*     */     }
/* 298 */     accessMgrBuilder.addConstructorArgValue(voters);
/* 299 */     AbstractBeanDefinition abstractBeanDefinition = accessMgrBuilder.getBeanDefinition();
/* 300 */     String id = pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/* 301 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, id));
/* 302 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanReference registerDelegatingMethodSecurityMetadataSource(ParserContext pc, ManagedList delegates, Object source) {
/* 308 */     RootBeanDefinition delegatingMethodSecurityMetadataSource = new RootBeanDefinition(DelegatingMethodSecurityMetadataSource.class);
/*     */     
/* 310 */     delegatingMethodSecurityMetadataSource.setSource(source);
/* 311 */     delegatingMethodSecurityMetadataSource.getConstructorArgumentValues().addGenericArgumentValue(delegates);
/* 312 */     String id = pc.getReaderContext().generateBeanName((BeanDefinition)delegatingMethodSecurityMetadataSource);
/* 313 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)delegatingMethodSecurityMetadataSource, id));
/*     */     
/* 315 */     return (BeanReference)new RuntimeBeanReference(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerProtectPointcutPostProcessor(ParserContext parserContext, Map<String, List<ConfigAttribute>> pointcutMap, BeanReference mapBasedMethodSecurityMetadataSource, Object source) {
/* 321 */     RootBeanDefinition ppbp = new RootBeanDefinition(ProtectPointcutPostProcessor.class);
/* 322 */     ppbp.setRole(2);
/* 323 */     ppbp.setSource(source);
/* 324 */     ppbp.getConstructorArgumentValues().addGenericArgumentValue(mapBasedMethodSecurityMetadataSource);
/* 325 */     ppbp.getPropertyValues().addPropertyValue("pointcutMap", pointcutMap);
/* 326 */     parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)ppbp);
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, List<ConfigAttribute>> parseProtectPointcuts(ParserContext parserContext, List<Element> protectPointcutElts) {
/* 331 */     Map<String, List<ConfigAttribute>> pointcutMap = new LinkedHashMap<>();
/* 332 */     for (Element childElt : protectPointcutElts) {
/* 333 */       String accessConfig = childElt.getAttribute("access");
/* 334 */       String expression = childElt.getAttribute("expression");
/* 335 */       if (!StringUtils.hasText(accessConfig)) {
/* 336 */         parserContext.getReaderContext()
/* 337 */           .error("Access configuration required", parserContext.extractSource(childElt));
/*     */       }
/* 339 */       if (!StringUtils.hasText(expression)) {
/* 340 */         parserContext.getReaderContext()
/* 341 */           .error("Pointcut expression required", parserContext.extractSource(childElt));
/*     */       }
/* 343 */       String[] attributeTokens = StringUtils.commaDelimitedListToStringArray(accessConfig);
/* 344 */       List<ConfigAttribute> attributes = new ArrayList<>(attributeTokens.length);
/* 345 */       for (String token : attributeTokens) {
/* 346 */         attributes.add(new SecurityConfig(token));
/*     */       }
/* 348 */       pointcutMap.put(expression, attributes);
/*     */     } 
/* 350 */     return pointcutMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanReference registerMethodSecurityInterceptor(ParserContext pc, String authMgrRef, String accessManagerId, String runAsManagerId, BeanReference metadataSource, List<BeanMetadataElement> afterInvocationProviders, Object source, boolean useAspectJ) {
/* 357 */     BeanDefinitionBuilder bldr = BeanDefinitionBuilder.rootBeanDefinition(useAspectJ ? AspectJMethodSecurityInterceptor.class : MethodSecurityInterceptor.class);
/* 358 */     bldr.getRawBeanDefinition().setSource(source);
/* 359 */     bldr.addPropertyReference("accessDecisionManager", accessManagerId);
/* 360 */     RootBeanDefinition authMgr = new RootBeanDefinition(AuthenticationManagerDelegator.class);
/* 361 */     authMgr.getConstructorArgumentValues().addGenericArgumentValue(authMgrRef);
/* 362 */     bldr.addPropertyValue("authenticationManager", authMgr);
/* 363 */     bldr.addPropertyValue("securityMetadataSource", metadataSource);
/* 364 */     if (StringUtils.hasText(runAsManagerId)) {
/* 365 */       bldr.addPropertyReference("runAsManager", runAsManagerId);
/*     */     }
/* 367 */     if (!afterInvocationProviders.isEmpty()) {
/*     */       
/* 369 */       RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(AfterInvocationProviderManager.class);
/* 370 */       rootBeanDefinition.getPropertyValues().addPropertyValue("providers", afterInvocationProviders);
/* 371 */       bldr.addPropertyValue("afterInvocationManager", rootBeanDefinition);
/*     */     } 
/* 373 */     AbstractBeanDefinition abstractBeanDefinition = bldr.getBeanDefinition();
/* 374 */     String id = pc.getReaderContext().generateBeanName((BeanDefinition)abstractBeanDefinition);
/* 375 */     pc.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)abstractBeanDefinition, id));
/* 376 */     return (BeanReference)new RuntimeBeanReference(id);
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerAdvisor(ParserContext parserContext, BeanReference interceptor, BeanReference metadataSource, Object source, String adviceOrder) {
/* 381 */     if (parserContext.getRegistry().containsBeanDefinition("org.springframework.security.methodSecurityMetadataSourceAdvisor")) {
/* 382 */       parserContext.getReaderContext().error("Duplicate <global-method-security> detected.", source);
/*     */     }
/* 384 */     RootBeanDefinition advisor = new RootBeanDefinition(MethodSecurityMetadataSourceAdvisor.class);
/* 385 */     if (StringUtils.hasText(adviceOrder)) {
/* 386 */       advisor.getPropertyValues().addPropertyValue("order", adviceOrder);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 391 */     advisor.setRole(2);
/* 392 */     advisor.setSource(source);
/* 393 */     advisor.getConstructorArgumentValues().addGenericArgumentValue(interceptor.getBeanName());
/* 394 */     advisor.getConstructorArgumentValues().addGenericArgumentValue(metadataSource);
/* 395 */     advisor.getConstructorArgumentValues().addGenericArgumentValue(metadataSource.getBeanName());
/* 396 */     parserContext.getRegistry().registerBeanDefinition("org.springframework.security.methodSecurityMetadataSourceAdvisor", (BeanDefinition)advisor);
/*     */   }
/*     */ 
/*     */   
/*     */   private RootBeanDefinition registerWithDefaultRolePrefix(ParserContext pc, Class<? extends AbstractGrantedAuthorityDefaultsBeanFactory> beanFactoryClass) {
/* 401 */     RootBeanDefinition beanFactoryDefinition = new RootBeanDefinition(beanFactoryClass);
/* 402 */     String beanFactoryRef = pc.getReaderContext().generateBeanName((BeanDefinition)beanFactoryDefinition);
/* 403 */     pc.getRegistry().registerBeanDefinition(beanFactoryRef, (BeanDefinition)beanFactoryDefinition);
/* 404 */     RootBeanDefinition bean = new RootBeanDefinition();
/* 405 */     bean.setFactoryBeanName(beanFactoryRef);
/* 406 */     bean.setFactoryMethodName("getBean");
/* 407 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AuthenticationManagerDelegator
/*     */     implements AuthenticationManager, BeanFactoryAware
/*     */   {
/*     */     private AuthenticationManager delegate;
/*     */ 
/*     */ 
/*     */     
/* 421 */     private final Object delegateMonitor = new Object();
/*     */     
/*     */     private BeanFactory beanFactory;
/*     */     
/*     */     private final String authMgrBean;
/*     */     
/*     */     AuthenticationManagerDelegator(String authMgrBean) {
/* 428 */       this.authMgrBean = StringUtils.hasText(authMgrBean) ? authMgrBean : "org.springframework.security.authenticationManager";
/*     */     }
/*     */ 
/*     */     
/*     */     public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 433 */       synchronized (this.delegateMonitor) {
/* 434 */         if (this.delegate == null) {
/* 435 */           Assert.state((this.beanFactory != null), () -> "BeanFactory must be set to resolve " + this.authMgrBean);
/*     */           
/*     */           try {
/* 438 */             this.delegate = (AuthenticationManager)this.beanFactory.getBean(this.authMgrBean, AuthenticationManager.class);
/*     */           }
/* 440 */           catch (NoSuchBeanDefinitionException ex) {
/* 441 */             if ("org.springframework.security.authenticationManager".equals(ex.getBeanName())) {
/* 442 */               throw new NoSuchBeanDefinitionException("org.springframework.security.authenticationManager", "Did you forget to add a global <authentication-manager> element to your configuration (with child <authentication-provider> elements)? Alternatively you can use the authentication-manager-ref attribute on your <http> and <global-method-security> elements.");
/*     */             }
/*     */             
/* 445 */             throw ex;
/*     */           } 
/*     */         } 
/*     */       } 
/* 449 */       return this.delegate.authenticate(authentication);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 454 */       this.beanFactory = beanFactory;
/*     */     }
/*     */   }
/*     */   
/*     */   static class Jsr250MethodSecurityMetadataSourceBeanFactory
/*     */     extends AbstractGrantedAuthorityDefaultsBeanFactory
/*     */   {
/* 461 */     private Jsr250MethodSecurityMetadataSource source = new Jsr250MethodSecurityMetadataSource();
/*     */     
/*     */     Jsr250MethodSecurityMetadataSource getBean() {
/* 464 */       this.source.setDefaultRolePrefix(this.rolePrefix);
/* 465 */       return this.source;
/*     */     }
/*     */   }
/*     */   
/*     */   static class DefaultMethodSecurityExpressionHandlerBeanFactory
/*     */     extends AbstractGrantedAuthorityDefaultsBeanFactory
/*     */   {
/* 472 */     private DefaultMethodSecurityExpressionHandler handler = new DefaultMethodSecurityExpressionHandler();
/*     */     
/*     */     DefaultMethodSecurityExpressionHandler getBean() {
/* 475 */       this.handler.setDefaultRolePrefix(this.rolePrefix);
/* 476 */       return this.handler;
/*     */     } }
/*     */   
/*     */   static abstract class AbstractGrantedAuthorityDefaultsBeanFactory implements ApplicationContextAware {
/*     */     protected String rolePrefix;
/*     */     
/*     */     AbstractGrantedAuthorityDefaultsBeanFactory() {
/* 483 */       this.rolePrefix = "ROLE_";
/*     */     }
/*     */     
/*     */     public final void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 487 */       applicationContext.getBeanProvider(GrantedAuthorityDefaults.class)
/* 488 */         .ifUnique(grantedAuthorityDefaults -> this.rolePrefix = grantedAuthorityDefaults.getRolePrefix());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class LazyInitBeanDefinitionRegistryPostProcessor
/*     */     implements BeanDefinitionRegistryPostProcessor
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private LazyInitBeanDefinitionRegistryPostProcessor(String beanName) {
/* 506 */       this.beanName = beanName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
/* 511 */       if (!registry.containsBeanDefinition(this.beanName)) {
/*     */         return;
/*     */       }
/* 514 */       BeanDefinition beanDefinition = registry.getBeanDefinition(this.beanName);
/* 515 */       beanDefinition.setLazyInit(true);
/*     */     }
/*     */     
/*     */     public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\method\GlobalMethodSecurityBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */