/*     */ package org.springframework.security.config.method;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.aop.config.AbstractInterceptorDrivenBeanDefinitionDecorator;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.security.access.SecurityConfig;
/*     */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityInterceptor;
/*     */ import org.springframework.security.access.method.MapBasedMethodSecurityMetadataSource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class InternalInterceptMethodsBeanDefinitionDecorator
/*     */   extends AbstractInterceptorDrivenBeanDefinitionDecorator
/*     */ {
/*     */   static final String ATT_METHOD = "method";
/*     */   static final String ATT_ACCESS = "access";
/*     */   private static final String ATT_ACCESS_MGR = "access-decision-manager-ref";
/*     */   
/*     */   protected BeanDefinition createInterceptorDefinition(Node node) {
/* 150 */     Element interceptMethodsElt = (Element)node;
/*     */     
/* 152 */     BeanDefinitionBuilder interceptor = BeanDefinitionBuilder.rootBeanDefinition(MethodSecurityInterceptor.class);
/*     */     
/* 154 */     interceptor.setAutowireMode(2);
/* 155 */     String accessManagerId = interceptMethodsElt.getAttribute("access-decision-manager-ref");
/* 156 */     if (!StringUtils.hasText(accessManagerId)) {
/* 157 */       accessManagerId = "org.springframework.security.defaultMethodAccessManager";
/*     */     }
/* 159 */     interceptor.addPropertyValue("accessDecisionManager", new RuntimeBeanReference(accessManagerId));
/* 160 */     interceptor.addPropertyValue("authenticationManager", new RuntimeBeanReference("org.springframework.security.authenticationManager"));
/*     */ 
/*     */     
/* 163 */     String parentBeanClass = ((Element)interceptMethodsElt.getParentNode()).getAttribute("class");
/*     */     
/* 165 */     List<Element> methods = DomUtils.getChildElementsByTagName(interceptMethodsElt, "protect");
/* 166 */     ManagedMap<String, AbstractBeanDefinition> managedMap = new ManagedMap();
/* 167 */     for (Element protectmethodElt : methods) {
/* 168 */       BeanDefinitionBuilder attributeBuilder = BeanDefinitionBuilder.rootBeanDefinition(SecurityConfig.class);
/* 169 */       attributeBuilder.setFactoryMethod("createListFromCommaDelimitedString");
/* 170 */       attributeBuilder.addConstructorArgValue(protectmethodElt.getAttribute("access"));
/*     */       
/* 172 */       String methodName = protectmethodElt.getAttribute("method");
/* 173 */       if (methodName.lastIndexOf(".") == -1 && 
/* 174 */         parentBeanClass != null && !"".equals(parentBeanClass)) {
/* 175 */         methodName = parentBeanClass + "." + parentBeanClass;
/*     */       }
/*     */       
/* 178 */       managedMap.put(methodName, attributeBuilder.getBeanDefinition());
/*     */     } 
/* 180 */     RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(MapBasedMethodSecurityMetadataSource.class);
/* 181 */     rootBeanDefinition.getConstructorArgumentValues().addGenericArgumentValue(managedMap);
/* 182 */     interceptor.addPropertyValue("securityMetadataSource", rootBeanDefinition);
/* 183 */     return (BeanDefinition)interceptor.getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\method\InterceptMethodsBeanDefinitionDecorator$InternalInterceptMethodsBeanDefinitionDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */