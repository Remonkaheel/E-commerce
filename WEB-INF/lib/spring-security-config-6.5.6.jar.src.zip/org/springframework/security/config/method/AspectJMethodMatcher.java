/*    */ package org.springframework.security.config.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.aspectj.weaver.tools.PointcutExpression;
/*    */ import org.aspectj.weaver.tools.PointcutParser;
/*    */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ import org.springframework.aop.Pointcut;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AspectJMethodMatcher
/*    */   implements MethodMatcher, ClassFilter, Pointcut
/*    */ {
/*    */   private static final PointcutParser parser;
/*    */   private final PointcutExpression expression;
/*    */   
/*    */   static {
/* 36 */     Set<PointcutPrimitive> supportedPrimitives = new HashSet<>(3);
/* 37 */     supportedPrimitives.add(PointcutPrimitive.EXECUTION);
/* 38 */     supportedPrimitives.add(PointcutPrimitive.ARGS);
/* 39 */     supportedPrimitives.add(PointcutPrimitive.REFERENCE);
/*    */     
/* 41 */     parser = PointcutParser.getPointcutParserSupportingSpecifiedPrimitivesAndUsingContextClassloaderForResolution(supportedPrimitives);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   AspectJMethodMatcher(String expression) {
/* 47 */     this.expression = parser.parsePointcutExpression(expression);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(Class<?> clazz) {
/* 52 */     return this.expression.couldMatchJoinPointsInType(clazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(Method method, Class<?> targetClass) {
/* 57 */     return this.expression.matchesMethodExecution(method).alwaysMatches();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRuntime() {
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 67 */     return matches(method, targetClass);
/*    */   }
/*    */ 
/*    */   
/*    */   public ClassFilter getClassFilter() {
/* 72 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodMatcher getMethodMatcher() {
/* 77 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\method\AspectJMethodMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */