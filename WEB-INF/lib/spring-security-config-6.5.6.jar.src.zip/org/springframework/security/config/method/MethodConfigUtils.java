/*    */ package org.springframework.security.config.method;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.vote.AffirmativeBased;
/*    */ import org.springframework.security.access.vote.AuthenticatedVoter;
/*    */ import org.springframework.security.access.vote.RoleVoter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ abstract class MethodConfigUtils
/*    */ {
/*    */   static void registerDefaultMethodAccessManagerIfNecessary(ParserContext parserContext) {
/* 43 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.security.defaultMethodAccessManager")) {
/* 44 */       parserContext.getRegistry()
/* 45 */         .registerBeanDefinition("org.springframework.security.defaultMethodAccessManager", 
/* 46 */           (BeanDefinition)createAccessManagerBean((Class<? extends AccessDecisionVoter>[])new Class[] { RoleVoter.class, AuthenticatedVoter.class }));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static RootBeanDefinition createAccessManagerBean(Class<? extends AccessDecisionVoter>... voters) {
/* 52 */     ManagedList defaultVoters = new ManagedList(voters.length);
/* 53 */     for (Class<? extends AccessDecisionVoter> voter : voters) {
/* 54 */       defaultVoters.add(new RootBeanDefinition(voter));
/*    */     }
/* 56 */     BeanDefinitionBuilder accessMgrBuilder = BeanDefinitionBuilder.rootBeanDefinition(AffirmativeBased.class);
/* 57 */     accessMgrBuilder.addConstructorArgValue(defaultVoters);
/* 58 */     return (RootBeanDefinition)accessMgrBuilder.getBeanDefinition();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-config-6.5.6.jar!\org\springframework\security\config\method\MethodConfigUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */