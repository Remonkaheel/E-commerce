package org.aopalliance.aop;

public interface Advice {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\aopalliance\aop\Advice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */