package org.aopalliance.intercept;

import javax.annotation.Nonnull;

public interface Invocation extends Joinpoint {
  @Nonnull
  Object[] getArguments();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\aopalliance\intercept\Invocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */