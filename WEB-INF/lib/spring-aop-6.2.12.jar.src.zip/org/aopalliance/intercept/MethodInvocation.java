package org.aopalliance.intercept;

import java.lang.reflect.Method;
import javax.annotation.Nonnull;

public interface MethodInvocation extends Invocation {
  @Nonnull
  Method getMethod();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\aopalliance\intercept\MethodInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */