package org.aopalliance.intercept;

import java.lang.reflect.Constructor;
import javax.annotation.Nonnull;

public interface ConstructorInvocation extends Invocation {
  @Nonnull
  Constructor<?> getConstructor();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\aopalliance\intercept\ConstructorInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */