package org.aopalliance.intercept;

import java.lang.reflect.AccessibleObject;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public interface Joinpoint {
  @Nullable
  Object proceed() throws Throwable;
  
  @Nullable
  Object getThis();
  
  @Nonnull
  AccessibleObject getStaticPart();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\aopalliance\intercept\Joinpoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */