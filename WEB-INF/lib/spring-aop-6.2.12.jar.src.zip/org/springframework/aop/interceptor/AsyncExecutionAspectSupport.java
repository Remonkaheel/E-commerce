/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.EmbeddedValueResolver;
/*     */ import org.springframework.core.task.AsyncListenableTaskExecutor;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.core.task.support.TaskExecutorAdapter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ import org.springframework.util.concurrent.ListenableFuture;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AsyncExecutionAspectSupport
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   public static final String DEFAULT_TASK_EXECUTOR_BEAN_NAME = "taskExecutor";
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private SingletonSupplier<Executor> defaultExecutor;
/*     */   
/*     */   private SingletonSupplier<AsyncUncaughtExceptionHandler> exceptionHandler;
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   
/*  87 */   private final Map<Method, AsyncTaskExecutor> executors = new ConcurrentHashMap<>(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncExecutionAspectSupport(@Nullable Executor defaultExecutor) {
/*  98 */     this.defaultExecutor = new SingletonSupplier(defaultExecutor, () -> getDefaultExecutor(this.beanFactory));
/*  99 */     this.exceptionHandler = SingletonSupplier.of(SimpleAsyncUncaughtExceptionHandler::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncExecutionAspectSupport(@Nullable Executor defaultExecutor, AsyncUncaughtExceptionHandler exceptionHandler) {
/* 111 */     this.defaultExecutor = new SingletonSupplier(defaultExecutor, () -> getDefaultExecutor(this.beanFactory));
/* 112 */     this.exceptionHandler = SingletonSupplier.of(exceptionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(@Nullable Supplier<Executor> defaultExecutor, @Nullable Supplier<AsyncUncaughtExceptionHandler> exceptionHandler) {
/* 124 */     this.defaultExecutor = new SingletonSupplier(defaultExecutor, () -> getDefaultExecutor(this.beanFactory));
/* 125 */     this.exceptionHandler = new SingletonSupplier(exceptionHandler, SimpleAsyncUncaughtExceptionHandler::new);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExecutor(Executor defaultExecutor) {
/* 139 */     this.defaultExecutor = SingletonSupplier.of(defaultExecutor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionHandler(AsyncUncaughtExceptionHandler exceptionHandler) {
/* 147 */     this.exceptionHandler = SingletonSupplier.of(exceptionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 158 */     this.beanFactory = beanFactory;
/* 159 */     if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory configurableBeanFactory = (ConfigurableBeanFactory)beanFactory;
/* 160 */       this.embeddedValueResolver = (StringValueResolver)new EmbeddedValueResolver(configurableBeanFactory); }
/*     */     
/* 162 */     this.executors.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected AsyncTaskExecutor determineAsyncExecutor(Method method) {
/* 172 */     AsyncTaskExecutor executor = this.executors.get(method);
/* 173 */     if (executor == null) {
/*     */       Executor targetExecutor;
/* 175 */       String qualifier = getExecutorQualifier(method);
/* 176 */       if (this.embeddedValueResolver != null && StringUtils.hasLength(qualifier)) {
/* 177 */         qualifier = this.embeddedValueResolver.resolveStringValue(qualifier);
/*     */       }
/* 179 */       if (StringUtils.hasLength(qualifier)) {
/* 180 */         targetExecutor = findQualifiedExecutor(this.beanFactory, qualifier);
/*     */       } else {
/*     */         
/* 183 */         targetExecutor = (Executor)this.defaultExecutor.get();
/*     */       } 
/* 185 */       if (targetExecutor == null) {
/* 186 */         return null;
/*     */       }
/* 188 */       AsyncTaskExecutor asyncTaskExecutor = (AsyncTaskExecutor)targetExecutor;
/* 189 */       executor = (targetExecutor instanceof AsyncTaskExecutor) ? asyncTaskExecutor : (AsyncTaskExecutor)new TaskExecutorAdapter(targetExecutor);
/* 190 */       this.executors.put(method, executor);
/*     */     } 
/* 192 */     return executor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Executor findQualifiedExecutor(@Nullable BeanFactory beanFactory, String qualifier) {
/* 218 */     if (beanFactory == null) {
/* 219 */       throw new IllegalStateException("BeanFactory must be set on " + getClass().getSimpleName() + " to access qualified executor '" + qualifier + "'");
/*     */     }
/*     */     
/* 222 */     return (Executor)BeanFactoryAnnotationUtils.qualifiedBeanOfType(beanFactory, Executor.class, qualifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Executor getDefaultExecutor(@Nullable BeanFactory beanFactory) {
/* 239 */     if (beanFactory != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 244 */         return (Executor)beanFactory.getBean(TaskExecutor.class);
/*     */       }
/* 246 */       catch (NoUniqueBeanDefinitionException ex) {
/* 247 */         this.logger.debug("Could not find unique TaskExecutor bean. Continuing search for an Executor bean named 'taskExecutor'", (Throwable)ex);
/*     */         
/*     */         try {
/* 250 */           return (Executor)beanFactory.getBean("taskExecutor", Executor.class);
/*     */         }
/* 252 */         catch (NoSuchBeanDefinitionException ex2) {
/* 253 */           if (this.logger.isInfoEnabled()) {
/* 254 */             this.logger.info("More than one TaskExecutor bean found within the context, and none is named 'taskExecutor'. Mark one of them as primary or name it 'taskExecutor' (possibly as an alias) in order to use it for async processing: " + 
/*     */                 
/* 256 */                 String.valueOf(ex.getBeanNamesFound()));
/*     */           }
/*     */         }
/*     */       
/* 260 */       } catch (NoSuchBeanDefinitionException ex) {
/* 261 */         this.logger.debug("Could not find default TaskExecutor bean. Continuing search for an Executor bean named 'taskExecutor'", (Throwable)ex);
/*     */         
/*     */         try {
/* 264 */           return (Executor)beanFactory.getBean("taskExecutor", Executor.class);
/*     */         }
/* 266 */         catch (NoSuchBeanDefinitionException ex2) {
/* 267 */           this.logger.info("No task executor bean found for async processing: no bean of type TaskExecutor and no bean named 'taskExecutor' either");
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object doSubmit(Callable<Object> task, AsyncTaskExecutor executor, Class<?> returnType) {
/* 287 */     if (CompletableFuture.class.isAssignableFrom(returnType)) {
/* 288 */       return executor.submitCompletable(task);
/*     */     }
/* 290 */     if (ListenableFuture.class.isAssignableFrom(returnType)) {
/* 291 */       return ((AsyncListenableTaskExecutor)executor).submitListenable(task);
/*     */     }
/* 293 */     if (Future.class.isAssignableFrom(returnType)) {
/* 294 */       return executor.submit(task);
/*     */     }
/* 296 */     if (void.class == returnType || "kotlin.Unit".equals(returnType.getName())) {
/* 297 */       executor.submit(task);
/* 298 */       return null;
/*     */     } 
/*     */     
/* 301 */     throw new IllegalArgumentException("Invalid return type for async method (only Future and void supported): " + String.valueOf(returnType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleError(Throwable ex, Method method, Object... params) throws Exception {
/* 319 */     if (Future.class.isAssignableFrom(method.getReturnType())) {
/* 320 */       ReflectionUtils.rethrowException(ex);
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 325 */         ((AsyncUncaughtExceptionHandler)this.exceptionHandler.obtain()).handleUncaughtException(ex, method, params);
/*     */       }
/* 327 */       catch (Throwable ex2) {
/* 328 */         this.logger.warn("Exception handler for async method '" + method.toGenericString() + "' threw unexpected exception itself", ex2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract String getExecutorQualifier(Method paramMethod);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\AsyncExecutionAspectSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */