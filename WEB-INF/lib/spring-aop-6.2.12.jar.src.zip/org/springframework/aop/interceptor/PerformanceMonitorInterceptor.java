/*    */ package org.springframework.aop.interceptor;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.util.StopWatch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerformanceMonitorInterceptor
/*    */   extends AbstractMonitoringInterceptor
/*    */ {
/*    */   public PerformanceMonitorInterceptor() {}
/*    */   
/*    */   public PerformanceMonitorInterceptor(boolean useDynamicLogger) {
/* 51 */     setUseDynamicLogger(useDynamicLogger);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger) throws Throwable {
/* 57 */     String name = createInvocationTraceName(invocation);
/* 58 */     StopWatch stopWatch = new StopWatch(name);
/* 59 */     stopWatch.start(name);
/*    */     try {
/* 61 */       return invocation.proceed();
/*    */     } finally {
/*    */       
/* 64 */       stopWatch.stop();
/* 65 */       writeToLog(logger, stopWatch.shortSummary());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\PerformanceMonitorInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */