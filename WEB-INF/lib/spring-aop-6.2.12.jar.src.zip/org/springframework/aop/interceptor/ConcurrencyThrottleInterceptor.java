/*    */ package org.springframework.aop.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ConcurrencyThrottleSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConcurrencyThrottleInterceptor
/*    */   extends ConcurrencyThrottleSupport
/*    */   implements MethodInterceptor, Serializable
/*    */ {
/*    */   public ConcurrencyThrottleInterceptor() {
/* 48 */     setConcurrencyLimit(1);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation methodInvocation) throws Throwable {
/* 54 */     beforeAccess();
/*    */     try {
/* 56 */       return methodInvocation.proceed();
/*    */     } finally {
/*    */       
/* 59 */       afterAccess();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\ConcurrencyThrottleInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */