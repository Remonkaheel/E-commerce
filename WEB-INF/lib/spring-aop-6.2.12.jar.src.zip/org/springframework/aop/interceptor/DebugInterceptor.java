/*    */ package org.springframework.aop.interceptor;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugInterceptor
/*    */   extends SimpleTraceInterceptor
/*    */ {
/*    */   private volatile long count;
/*    */   
/*    */   public DebugInterceptor() {}
/*    */   
/*    */   public DebugInterceptor(boolean useDynamicLogger) {
/* 56 */     setUseDynamicLogger(useDynamicLogger);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 63 */     synchronized (this) {
/* 64 */       this.count++;
/*    */     } 
/* 66 */     return super.invoke(invocation);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getInvocationDescription(MethodInvocation invocation) {
/* 71 */     return String.valueOf(invocation) + "; count=" + String.valueOf(invocation);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getCount() {
/* 79 */     return this.count;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void resetCount() {
/* 86 */     this.count = 0L;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\DebugInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */