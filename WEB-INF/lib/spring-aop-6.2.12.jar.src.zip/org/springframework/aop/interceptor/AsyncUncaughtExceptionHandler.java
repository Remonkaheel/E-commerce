package org.springframework.aop.interceptor;

import java.lang.reflect.Method;

@FunctionalInterface
public interface AsyncUncaughtExceptionHandler {
  void handleUncaughtException(Throwable paramThrowable, Method paramMethod, Object... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\AsyncUncaughtExceptionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */