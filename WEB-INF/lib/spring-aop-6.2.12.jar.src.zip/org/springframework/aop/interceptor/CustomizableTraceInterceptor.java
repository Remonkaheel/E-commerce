/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StopWatch;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomizableTraceInterceptor
/*     */   extends AbstractTraceInterceptor
/*     */ {
/*     */   public static final String PLACEHOLDER_METHOD_NAME = "$[methodName]";
/*     */   public static final String PLACEHOLDER_TARGET_CLASS_NAME = "$[targetClassName]";
/*     */   public static final String PLACEHOLDER_TARGET_CLASS_SHORT_NAME = "$[targetClassShortName]";
/*     */   public static final String PLACEHOLDER_RETURN_VALUE = "$[returnValue]";
/*     */   public static final String PLACEHOLDER_ARGUMENT_TYPES = "$[argumentTypes]";
/*     */   public static final String PLACEHOLDER_ARGUMENTS = "$[arguments]";
/*     */   public static final String PLACEHOLDER_EXCEPTION = "$[exception]";
/*     */   public static final String PLACEHOLDER_INVOCATION_TIME = "$[invocationTime]";
/*     */   private static final String DEFAULT_ENTER_MESSAGE = "Entering method '$[methodName]' of class [$[targetClassName]]";
/*     */   private static final String DEFAULT_EXIT_MESSAGE = "Exiting method '$[methodName]' of class [$[targetClassName]]";
/*     */   private static final String DEFAULT_EXCEPTION_MESSAGE = "Exception thrown in method '$[methodName]' of class [$[targetClassName]]";
/* 150 */   private static final Pattern PATTERN = Pattern.compile("\\$\\[\\p{Alpha}+]");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   static final Set<String> ALLOWED_PLACEHOLDERS = Set.of("$[methodName]", "$[targetClassName]", "$[targetClassShortName]", "$[returnValue]", "$[argumentTypes]", "$[arguments]", "$[exception]", "$[invocationTime]");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   private String enterMessage = "Entering method '$[methodName]' of class [$[targetClassName]]";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   private String exitMessage = "Exiting method '$[methodName]' of class [$[targetClassName]]";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   private String exceptionMessage = "Exception thrown in method '$[methodName]' of class [$[targetClassName]]";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnterMessage(String enterMessage) throws IllegalArgumentException {
/* 193 */     Assert.hasText(enterMessage, "enterMessage must not be empty");
/* 194 */     checkForInvalidPlaceholders(enterMessage);
/* 195 */     Assert.doesNotContain(enterMessage, "$[returnValue]", "enterMessage cannot contain placeholder $[returnValue]");
/*     */     
/* 197 */     Assert.doesNotContain(enterMessage, "$[exception]", "enterMessage cannot contain placeholder $[exception]");
/*     */     
/* 199 */     Assert.doesNotContain(enterMessage, "$[invocationTime]", "enterMessage cannot contain placeholder $[invocationTime]");
/*     */     
/* 201 */     this.enterMessage = enterMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExitMessage(String exitMessage) {
/* 217 */     Assert.hasText(exitMessage, "exitMessage must not be empty");
/* 218 */     checkForInvalidPlaceholders(exitMessage);
/* 219 */     Assert.doesNotContain(exitMessage, "$[exception]", "exitMessage cannot contain placeholder$[exception]");
/*     */     
/* 221 */     this.exitMessage = exitMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionMessage(String exceptionMessage) {
/* 236 */     Assert.hasText(exceptionMessage, "exceptionMessage must not be empty");
/* 237 */     checkForInvalidPlaceholders(exceptionMessage);
/* 238 */     Assert.doesNotContain(exceptionMessage, "$[returnValue]", "exceptionMessage cannot contain placeholder $[returnValue]");
/*     */     
/* 240 */     this.exceptionMessage = exceptionMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger) throws Throwable {
/* 255 */     String name = ClassUtils.getQualifiedMethodName(invocation.getMethod());
/* 256 */     StopWatch stopWatch = new StopWatch(name);
/* 257 */     Object returnValue = null;
/* 258 */     boolean exitThroughException = false;
/*     */     try {
/* 260 */       stopWatch.start(name);
/* 261 */       writeToLog(logger, 
/* 262 */           replacePlaceholders(this.enterMessage, invocation, (Object)null, (Throwable)null, -1L));
/* 263 */       returnValue = invocation.proceed();
/* 264 */       return returnValue;
/*     */     }
/* 266 */     catch (Throwable ex) {
/* 267 */       if (stopWatch.isRunning()) {
/* 268 */         stopWatch.stop();
/*     */       }
/* 270 */       exitThroughException = true;
/* 271 */       writeToLog(logger, replacePlaceholders(this.exceptionMessage, invocation, (Object)null, ex, stopWatch
/* 272 */             .getTotalTimeMillis()), ex);
/* 273 */       throw ex;
/*     */     } finally {
/*     */       
/* 276 */       if (!exitThroughException) {
/* 277 */         if (stopWatch.isRunning()) {
/* 278 */           stopWatch.stop();
/*     */         }
/* 280 */         writeToLog(logger, replacePlaceholders(this.exitMessage, invocation, returnValue, (Throwable)null, stopWatch
/* 281 */               .getTotalTimeMillis()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String replacePlaceholders(String message, MethodInvocation methodInvocation, @Nullable Object returnValue, @Nullable Throwable throwable, long invocationTime) {
/* 305 */     Object target = methodInvocation.getThis();
/* 306 */     Assert.state((target != null), "Target must not be null");
/*     */     
/* 308 */     StringBuilder output = new StringBuilder();
/* 309 */     Matcher matcher = PATTERN.matcher(message);
/* 310 */     while (matcher.find()) {
/* 311 */       String className, shortName, match = matcher.group();
/* 312 */       switch (match) { case "$[methodName]":
/* 313 */           matcher.appendReplacement(output, 
/* 314 */               Matcher.quoteReplacement(methodInvocation.getMethod().getName())); continue;
/*     */         case "$[targetClassName]":
/* 316 */           className = getClassForLogging(target).getName();
/* 317 */           matcher.appendReplacement(output, Matcher.quoteReplacement(className));
/*     */           continue;
/*     */         case "$[targetClassShortName]":
/* 320 */           shortName = ClassUtils.getShortName(getClassForLogging(target));
/* 321 */           matcher.appendReplacement(output, Matcher.quoteReplacement(shortName)); continue;
/*     */         case "$[arguments]":
/* 323 */           matcher.appendReplacement(output, 
/* 324 */               Matcher.quoteReplacement(StringUtils.arrayToCommaDelimitedString(methodInvocation.getArguments()))); continue;
/* 325 */         case "$[argumentTypes]": appendArgumentTypes(methodInvocation, matcher, output); continue;
/* 326 */         case "$[returnValue]": appendReturnValue(methodInvocation, matcher, output, returnValue); continue;
/*     */         case "$[exception]":
/* 328 */           if (throwable != null)
/* 329 */             matcher.appendReplacement(output, Matcher.quoteReplacement(throwable.toString())); 
/*     */           continue;
/*     */         case "$[invocationTime]":
/* 332 */           matcher.appendReplacement(output, Long.toString(invocationTime));
/*     */           continue; }
/*     */       
/* 335 */       throw new IllegalArgumentException("Unknown placeholder [" + match + "]");
/*     */     } 
/*     */ 
/*     */     
/* 339 */     matcher.appendTail(output);
/*     */     
/* 341 */     return output.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void appendReturnValue(MethodInvocation methodInvocation, Matcher matcher, StringBuilder output, @Nullable Object returnValue) {
/* 356 */     if (methodInvocation.getMethod().getReturnType() == void.class) {
/* 357 */       matcher.appendReplacement(output, "void");
/*     */     }
/* 359 */     else if (returnValue == null) {
/* 360 */       matcher.appendReplacement(output, "null");
/*     */     } else {
/*     */       
/* 363 */       matcher.appendReplacement(output, Matcher.quoteReplacement(returnValue.toString()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void appendArgumentTypes(MethodInvocation methodInvocation, Matcher matcher, StringBuilder output) {
/* 378 */     Class<?>[] argumentTypes = methodInvocation.getMethod().getParameterTypes();
/* 379 */     String[] argumentTypeShortNames = new String[argumentTypes.length];
/* 380 */     for (int i = 0; i < argumentTypeShortNames.length; i++) {
/* 381 */       argumentTypeShortNames[i] = ClassUtils.getShortName(argumentTypes[i]);
/*     */     }
/* 383 */     matcher.appendReplacement(output, 
/* 384 */         Matcher.quoteReplacement(StringUtils.arrayToCommaDelimitedString((Object[])argumentTypeShortNames)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkForInvalidPlaceholders(String message) throws IllegalArgumentException {
/* 393 */     Matcher matcher = PATTERN.matcher(message);
/* 394 */     while (matcher.find()) {
/* 395 */       String match = matcher.group();
/* 396 */       if (!ALLOWED_PLACEHOLDERS.contains(match))
/* 397 */         throw new IllegalArgumentException("Placeholder [" + match + "] is not valid"); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\CustomizableTraceInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */