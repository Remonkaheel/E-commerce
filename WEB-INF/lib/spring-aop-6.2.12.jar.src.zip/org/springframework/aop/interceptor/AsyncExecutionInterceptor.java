/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Future;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncExecutionInterceptor
/*     */   extends AsyncExecutionAspectSupport
/*     */   implements MethodInterceptor, Ordered
/*     */ {
/*     */   public AsyncExecutionInterceptor(@Nullable Executor defaultExecutor) {
/*  77 */     super(defaultExecutor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncExecutionInterceptor(@Nullable Executor defaultExecutor, AsyncUncaughtExceptionHandler exceptionHandler) {
/*  88 */     super(defaultExecutor, exceptionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 103 */     Class<?> targetClass = (invocation.getThis() != null) ? AopUtils.getTargetClass(invocation.getThis()) : null;
/* 104 */     Method userMethod = BridgeMethodResolver.getMostSpecificMethod(invocation.getMethod(), targetClass);
/*     */     
/* 106 */     AsyncTaskExecutor executor = determineAsyncExecutor(userMethod);
/* 107 */     if (executor == null) {
/* 108 */       throw new IllegalStateException("No executor specified and no default executor set on AsyncExecutionInterceptor either");
/*     */     }
/*     */ 
/*     */     
/* 112 */     Callable<Object> task = () -> {
/*     */         try {
/*     */           Object result = invocation.proceed();
/*     */           if (result instanceof Future) {
/*     */             Future<?> future = (Future)result;
/*     */             return future.get();
/*     */           } 
/* 119 */         } catch (ExecutionException ex) {
/*     */           
/*     */           handleError(ex.getCause(), userMethod, invocation.getArguments());
/* 122 */         } catch (Throwable ex) {
/*     */           handleError(ex, userMethod, invocation.getArguments());
/*     */         } 
/*     */         
/*     */         return null;
/*     */       };
/* 128 */     return doSubmit(task, executor, userMethod.getReturnType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getExecutorQualifier(Method method) {
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Executor getDefaultExecutor(@Nullable BeanFactory beanFactory) {
/* 159 */     Executor defaultExecutor = super.getDefaultExecutor(beanFactory);
/* 160 */     return (defaultExecutor != null) ? defaultExecutor : (Executor)new SimpleAsyncTaskExecutor();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 165 */     return Integer.MIN_VALUE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\AsyncExecutionInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */