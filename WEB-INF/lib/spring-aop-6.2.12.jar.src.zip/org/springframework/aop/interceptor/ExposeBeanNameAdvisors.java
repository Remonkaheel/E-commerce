/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.support.DefaultIntroductionAdvisor;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.beans.factory.NamedBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExposeBeanNameAdvisors
/*     */ {
/*  49 */   private static final String BEAN_NAME_ATTRIBUTE = ExposeBeanNameAdvisors.class.getName() + ".BEAN_NAME";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBeanName() throws IllegalStateException {
/*  60 */     return getBeanName(ExposeInvocationInterceptor.currentInvocation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBeanName(MethodInvocation mi) throws IllegalStateException {
/*     */     ProxyMethodInvocation pmi;
/*  71 */     if (mi instanceof ProxyMethodInvocation) { pmi = (ProxyMethodInvocation)mi; }
/*  72 */     else { throw new IllegalArgumentException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(mi)); }
/*     */     
/*  74 */     String beanName = (String)pmi.getUserAttribute(BEAN_NAME_ATTRIBUTE);
/*  75 */     if (beanName == null) {
/*  76 */       throw new IllegalStateException("Cannot get bean name; not set on MethodInvocation: " + String.valueOf(mi));
/*     */     }
/*  78 */     return beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Advisor createAdvisorWithoutIntroduction(String beanName) {
/*  87 */     return (Advisor)new DefaultPointcutAdvisor((Advice)new ExposeBeanNameInterceptor(beanName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Advisor createAdvisorIntroducingNamedBean(String beanName) {
/*  97 */     return (Advisor)new DefaultIntroductionAdvisor((Advice)new ExposeBeanNameIntroduction(beanName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ExposeBeanNameInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */     
/*     */     public ExposeBeanNameInterceptor(String beanName) {
/* 109 */       this.beanName = beanName;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation mi) throws Throwable {
/*     */       ProxyMethodInvocation pmi;
/* 115 */       if (mi instanceof ProxyMethodInvocation) { pmi = (ProxyMethodInvocation)mi; }
/* 116 */       else { throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(mi)); }
/*     */       
/* 118 */       pmi.setUserAttribute(ExposeBeanNameAdvisors.BEAN_NAME_ATTRIBUTE, this.beanName);
/* 119 */       return mi.proceed();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ExposeBeanNameIntroduction
/*     */     extends DelegatingIntroductionInterceptor
/*     */     implements NamedBean
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */     
/*     */     public ExposeBeanNameIntroduction(String beanName) {
/* 133 */       this.beanName = beanName;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation mi) throws Throwable {
/*     */       ProxyMethodInvocation pmi;
/* 139 */       if (mi instanceof ProxyMethodInvocation) { pmi = (ProxyMethodInvocation)mi; }
/* 140 */       else { throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(mi)); }
/*     */       
/* 142 */       pmi.setUserAttribute(ExposeBeanNameAdvisors.BEAN_NAME_ATTRIBUTE, this.beanName);
/* 143 */       return super.invoke(mi);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getBeanName() {
/* 148 */       return this.beanName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\interceptor\ExposeBeanNameAdvisors.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */