/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.aop.scope.ScopedProxyUtils;
/*    */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionDecorator;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ScopedProxyBeanDefinitionDecorator
/*    */   implements BeanDefinitionDecorator
/*    */ {
/*    */   private static final String PROXY_TARGET_CLASS = "proxy-target-class";
/*    */   
/*    */   public BeanDefinitionHolder decorate(Node node, BeanDefinitionHolder definition, ParserContext parserContext) {
/* 44 */     boolean proxyTargetClass = true;
/* 45 */     if (node instanceof Element) { Element ele = (Element)node; if (ele.hasAttribute("proxy-target-class")) {
/* 46 */         proxyTargetClass = Boolean.parseBoolean(ele.getAttribute("proxy-target-class"));
/*    */       } }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     BeanDefinitionHolder holder = ScopedProxyUtils.createScopedProxy(definition, parserContext.getRegistry(), proxyTargetClass);
/* 53 */     String targetBeanName = ScopedProxyUtils.getTargetBeanName(definition.getBeanName());
/* 54 */     parserContext.getReaderContext().fireComponentRegistered((ComponentDefinition)new BeanComponentDefinition(definition
/* 55 */           .getBeanDefinition(), targetBeanName));
/* 56 */     return holder;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\config\ScopedProxyBeanDefinitionDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */