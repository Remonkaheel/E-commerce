/*    */ package org.springframework.aop.config;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.ParseState;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String id;
/*    */   private final String ref;
/*    */   
/*    */   public AspectEntry(String id, String ref) {
/* 42 */     this.id = id;
/* 43 */     this.ref = ref;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return "Aspect: " + (StringUtils.hasLength(this.id) ? ("id='" + this.id + "'") : ("ref='" + 
/* 50 */       this.ref + "'"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\config\AspectEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */