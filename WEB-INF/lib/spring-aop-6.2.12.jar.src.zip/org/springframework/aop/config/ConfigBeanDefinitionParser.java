/*     */ package org.springframework.aop.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.AspectJPointcutAdvisor;
/*     */ import org.springframework.aop.aspectj.DeclareParentsAdvisor;
/*     */ import org.springframework.aop.support.DefaultBeanFactoryPointcutAdvisor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanNameReference;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ParseState;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String ASPECT = "aspect";
/*     */   private static final String EXPRESSION = "expression";
/*     */   private static final String ID = "id";
/*     */   private static final String POINTCUT = "pointcut";
/*     */   private static final String ADVICE_BEAN_NAME = "adviceBeanName";
/*     */   private static final String ADVISOR = "advisor";
/*     */   private static final String ADVICE_REF = "advice-ref";
/*     */   private static final String POINTCUT_REF = "pointcut-ref";
/*     */   private static final String REF = "ref";
/*     */   private static final String BEFORE = "before";
/*     */   private static final String DECLARE_PARENTS = "declare-parents";
/*     */   private static final String TYPE_PATTERN = "types-matching";
/*     */   private static final String DEFAULT_IMPL = "default-impl";
/*     */   private static final String DELEGATE_REF = "delegate-ref";
/*     */   private static final String IMPLEMENT_INTERFACE = "implement-interface";
/*     */   private static final String AFTER = "after";
/*     */   private static final String AFTER_RETURNING_ELEMENT = "after-returning";
/*     */   private static final String AFTER_THROWING_ELEMENT = "after-throwing";
/*     */   private static final String AROUND = "around";
/*     */   private static final String RETURNING = "returning";
/*     */   private static final String RETURNING_PROPERTY = "returningName";
/*     */   private static final String THROWING = "throwing";
/*     */   private static final String THROWING_PROPERTY = "throwingName";
/*     */   private static final String ARG_NAMES = "arg-names";
/*     */   private static final String ARG_NAMES_PROPERTY = "argumentNames";
/*     */   private static final String ASPECT_NAME_PROPERTY = "aspectName";
/*     */   private static final String DECLARATION_ORDER_PROPERTY = "declarationOrder";
/*     */   private static final String ORDER_PROPERTY = "order";
/*     */   private static final int METHOD_INDEX = 0;
/*     */   private static final int POINTCUT_INDEX = 1;
/*     */   private static final int ASPECT_INSTANCE_FACTORY_INDEX = 2;
/*  96 */   private final ParseState parseState = new ParseState();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 103 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), parserContext.extractSource(element));
/* 104 */     parserContext.pushContainingComponent(compositeDef);
/*     */     
/* 106 */     configureAutoProxyCreator(parserContext, element);
/*     */     
/* 108 */     List<Element> childElts = DomUtils.getChildElements(element);
/* 109 */     for (Element elt : childElts) {
/* 110 */       String localName = parserContext.getDelegate().getLocalName(elt);
/* 111 */       switch (localName) { case "pointcut":
/* 112 */           parsePointcut(elt, parserContext);
/* 113 */         case "advisor": parseAdvisor(elt, parserContext);
/* 114 */         case "aspect": parseAspect(elt, parserContext); }
/*     */ 
/*     */     
/*     */     } 
/* 118 */     parserContext.popAndRegisterContainingComponent();
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureAutoProxyCreator(ParserContext parserContext, Element element) {
/* 129 */     AopNamespaceUtils.registerAspectJAutoProxyCreatorIfNecessary(parserContext, element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAdvisor(Element advisorElement, ParserContext parserContext) {
/* 138 */     AbstractBeanDefinition advisorDef = createAdvisorBeanDefinition(advisorElement, parserContext);
/* 139 */     String id = advisorElement.getAttribute("id");
/*     */     
/*     */     try {
/* 142 */       this.parseState.push(new AdvisorEntry(id));
/* 143 */       String advisorBeanName = id;
/* 144 */       if (StringUtils.hasText(advisorBeanName)) {
/* 145 */         parserContext.getRegistry().registerBeanDefinition(advisorBeanName, (BeanDefinition)advisorDef);
/*     */       } else {
/*     */         
/* 148 */         advisorBeanName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)advisorDef);
/*     */       } 
/*     */       
/* 151 */       Object pointcut = parsePointcutProperty(advisorElement, parserContext);
/* 152 */       if (pointcut instanceof BeanDefinition) { BeanDefinition beanDefinition = (BeanDefinition)pointcut;
/* 153 */         advisorDef.getPropertyValues().add("pointcut", pointcut);
/* 154 */         parserContext.registerComponent((ComponentDefinition)new AdvisorComponentDefinition(advisorBeanName, (BeanDefinition)advisorDef, beanDefinition));
/*     */          }
/*     */       
/* 157 */       else if (pointcut instanceof String) { String beanName = (String)pointcut;
/* 158 */         advisorDef.getPropertyValues().add("pointcut", new RuntimeBeanReference(beanName));
/* 159 */         parserContext.registerComponent((ComponentDefinition)new AdvisorComponentDefinition(advisorBeanName, (BeanDefinition)advisorDef)); }
/*     */ 
/*     */     
/*     */     } finally {
/*     */       
/* 164 */       this.parseState.pop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractBeanDefinition createAdvisorBeanDefinition(Element advisorElement, ParserContext parserContext) {
/* 173 */     RootBeanDefinition advisorDefinition = new RootBeanDefinition(DefaultBeanFactoryPointcutAdvisor.class);
/* 174 */     advisorDefinition.setSource(parserContext.extractSource(advisorElement));
/*     */     
/* 176 */     String adviceRef = advisorElement.getAttribute("advice-ref");
/* 177 */     if (!StringUtils.hasText(adviceRef)) {
/* 178 */       parserContext.getReaderContext().error("'advice-ref' attribute contains empty value.", advisorElement, this.parseState
/* 179 */           .snapshot());
/*     */     } else {
/*     */       
/* 182 */       advisorDefinition.getPropertyValues().add("adviceBeanName", new RuntimeBeanNameReference(adviceRef));
/*     */     } 
/*     */ 
/*     */     
/* 186 */     if (advisorElement.hasAttribute("order")) {
/* 187 */       advisorDefinition.getPropertyValues().add("order", advisorElement
/* 188 */           .getAttribute("order"));
/*     */     }
/*     */     
/* 191 */     return (AbstractBeanDefinition)advisorDefinition;
/*     */   }
/*     */   
/*     */   private void parseAspect(Element aspectElement, ParserContext parserContext) {
/* 195 */     String aspectId = aspectElement.getAttribute("id");
/* 196 */     String aspectName = aspectElement.getAttribute("ref");
/*     */     
/*     */     try {
/* 199 */       this.parseState.push(new AspectEntry(aspectId, aspectName));
/* 200 */       List<BeanDefinition> beanDefinitions = new ArrayList<>();
/* 201 */       List<BeanReference> beanReferences = new ArrayList<>();
/*     */       
/* 203 */       List<Element> declareParents = DomUtils.getChildElementsByTagName(aspectElement, "declare-parents");
/* 204 */       for (Element declareParent : declareParents) {
/* 205 */         beanDefinitions.add(parseDeclareParents(declareParent, parserContext));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 210 */       NodeList nodeList = aspectElement.getChildNodes();
/* 211 */       boolean adviceFoundAlready = false;
/* 212 */       for (int i = 0; i < nodeList.getLength(); i++) {
/* 213 */         Node node = nodeList.item(i);
/* 214 */         if (isAdviceNode(node, parserContext)) {
/* 215 */           if (!adviceFoundAlready) {
/* 216 */             adviceFoundAlready = true;
/* 217 */             if (!StringUtils.hasText(aspectName)) {
/* 218 */               parserContext.getReaderContext().error("<aspect> tag needs aspect bean reference via 'ref' attribute when declaring advices.", aspectElement, this.parseState
/*     */                   
/* 220 */                   .snapshot());
/*     */               return;
/*     */             } 
/* 223 */             beanReferences.add(new RuntimeBeanReference(aspectName));
/*     */           } 
/* 225 */           AbstractBeanDefinition advisorDefinition = parseAdvice(aspectName, i, aspectElement, (Element)node, parserContext, beanDefinitions, beanReferences);
/*     */           
/* 227 */           beanDefinitions.add(advisorDefinition);
/*     */         } 
/*     */       } 
/*     */       
/* 231 */       AspectComponentDefinition aspectComponentDefinition = createAspectComponentDefinition(aspectElement, aspectId, beanDefinitions, beanReferences, parserContext);
/*     */       
/* 233 */       parserContext.pushContainingComponent(aspectComponentDefinition);
/*     */       
/* 235 */       List<Element> pointcuts = DomUtils.getChildElementsByTagName(aspectElement, "pointcut");
/* 236 */       for (Element pointcutElement : pointcuts) {
/* 237 */         parsePointcut(pointcutElement, parserContext);
/*     */       }
/*     */       
/* 240 */       parserContext.popAndRegisterContainingComponent();
/*     */     } finally {
/*     */       
/* 243 */       this.parseState.pop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AspectComponentDefinition createAspectComponentDefinition(Element aspectElement, String aspectId, List<BeanDefinition> beanDefs, List<BeanReference> beanRefs, ParserContext parserContext) {
/* 251 */     BeanDefinition[] beanDefArray = beanDefs.<BeanDefinition>toArray(new BeanDefinition[0]);
/* 252 */     BeanReference[] beanRefArray = beanRefs.<BeanReference>toArray(new BeanReference[0]);
/* 253 */     Object source = parserContext.extractSource(aspectElement);
/* 254 */     return new AspectComponentDefinition(aspectId, beanDefArray, beanRefArray, source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAdviceNode(Node aNode, ParserContext parserContext) {
/* 263 */     if (!(aNode instanceof Element)) {
/* 264 */       return false;
/*     */     }
/*     */     
/* 267 */     String name = parserContext.getDelegate().getLocalName(aNode);
/* 268 */     return ("before".equals(name) || "after".equals(name) || "after-returning".equals(name) || "after-throwing"
/* 269 */       .equals(name) || "around".equals(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractBeanDefinition parseDeclareParents(Element declareParentsElement, ParserContext parserContext) {
/* 279 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(DeclareParentsAdvisor.class);
/* 280 */     builder.addConstructorArgValue(declareParentsElement.getAttribute("implement-interface"));
/* 281 */     builder.addConstructorArgValue(declareParentsElement.getAttribute("types-matching"));
/*     */     
/* 283 */     String defaultImpl = declareParentsElement.getAttribute("default-impl");
/* 284 */     String delegateRef = declareParentsElement.getAttribute("delegate-ref");
/*     */     
/* 286 */     if (StringUtils.hasText(defaultImpl) && !StringUtils.hasText(delegateRef)) {
/* 287 */       builder.addConstructorArgValue(defaultImpl);
/*     */     }
/* 289 */     else if (StringUtils.hasText(delegateRef) && !StringUtils.hasText(defaultImpl)) {
/* 290 */       builder.addConstructorArgReference(delegateRef);
/*     */     } else {
/*     */       
/* 293 */       parserContext.getReaderContext().error("Exactly one of the default-impl or delegate-ref attributes must be specified", declareParentsElement, this.parseState
/*     */           
/* 295 */           .snapshot());
/*     */     } 
/*     */     
/* 298 */     AbstractBeanDefinition definition = builder.getBeanDefinition();
/* 299 */     definition.setSource(parserContext.extractSource(declareParentsElement));
/* 300 */     parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)definition);
/* 301 */     return definition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractBeanDefinition parseAdvice(String aspectName, int order, Element aspectElement, Element adviceElement, ParserContext parserContext, List<BeanDefinition> beanDefinitions, List<BeanReference> beanReferences) {
/*     */     try {
/* 315 */       this.parseState.push(new AdviceEntry(parserContext.getDelegate().getLocalName(adviceElement)));
/*     */ 
/*     */       
/* 318 */       RootBeanDefinition methodDefinition = new RootBeanDefinition(MethodLocatingFactoryBean.class);
/* 319 */       methodDefinition.getPropertyValues().add("targetBeanName", aspectName);
/* 320 */       methodDefinition.getPropertyValues().add("methodName", adviceElement.getAttribute("method"));
/* 321 */       methodDefinition.setSynthetic(true);
/*     */ 
/*     */       
/* 324 */       RootBeanDefinition aspectFactoryDef = new RootBeanDefinition(SimpleBeanFactoryAwareAspectInstanceFactory.class);
/*     */       
/* 326 */       aspectFactoryDef.getPropertyValues().add("aspectBeanName", aspectName);
/* 327 */       aspectFactoryDef.setSynthetic(true);
/*     */ 
/*     */       
/* 330 */       AbstractBeanDefinition adviceDef = createAdviceDefinition(adviceElement, parserContext, aspectName, order, methodDefinition, aspectFactoryDef, beanDefinitions, beanReferences);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 335 */       RootBeanDefinition advisorDefinition = new RootBeanDefinition(AspectJPointcutAdvisor.class);
/* 336 */       advisorDefinition.setSource(parserContext.extractSource(adviceElement));
/* 337 */       advisorDefinition.getConstructorArgumentValues().addGenericArgumentValue(adviceDef);
/* 338 */       if (aspectElement.hasAttribute("order")) {
/* 339 */         advisorDefinition.getPropertyValues().add("order", aspectElement
/* 340 */             .getAttribute("order"));
/*     */       }
/*     */ 
/*     */       
/* 344 */       parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)advisorDefinition);
/*     */       
/* 346 */       return (AbstractBeanDefinition)advisorDefinition;
/*     */     } finally {
/*     */       
/* 349 */       this.parseState.pop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractBeanDefinition createAdviceDefinition(Element adviceElement, ParserContext parserContext, String aspectName, int order, RootBeanDefinition methodDef, RootBeanDefinition aspectFactoryDef, List<BeanDefinition> beanDefinitions, List<BeanReference> beanReferences) {
/* 364 */     RootBeanDefinition adviceDefinition = new RootBeanDefinition(getAdviceClass(adviceElement, parserContext));
/* 365 */     adviceDefinition.setSource(parserContext.extractSource(adviceElement));
/*     */     
/* 367 */     adviceDefinition.getPropertyValues().add("aspectName", aspectName);
/* 368 */     adviceDefinition.getPropertyValues().add("declarationOrder", Integer.valueOf(order));
/*     */     
/* 370 */     if (adviceElement.hasAttribute("returning")) {
/* 371 */       adviceDefinition.getPropertyValues().add("returningName", adviceElement
/* 372 */           .getAttribute("returning"));
/*     */     }
/* 374 */     if (adviceElement.hasAttribute("throwing")) {
/* 375 */       adviceDefinition.getPropertyValues().add("throwingName", adviceElement
/* 376 */           .getAttribute("throwing"));
/*     */     }
/* 378 */     if (adviceElement.hasAttribute("arg-names")) {
/* 379 */       adviceDefinition.getPropertyValues().add("argumentNames", adviceElement
/* 380 */           .getAttribute("arg-names"));
/*     */     }
/*     */     
/* 383 */     ConstructorArgumentValues cav = adviceDefinition.getConstructorArgumentValues();
/* 384 */     cav.addIndexedArgumentValue(0, methodDef);
/*     */     
/* 386 */     Object pointcut = parsePointcutProperty(adviceElement, parserContext);
/* 387 */     if (pointcut instanceof BeanDefinition) { BeanDefinition beanDefinition = (BeanDefinition)pointcut;
/* 388 */       cav.addIndexedArgumentValue(1, pointcut);
/* 389 */       beanDefinitions.add(beanDefinition); }
/*     */     
/* 391 */     else if (pointcut instanceof String) { String beanName = (String)pointcut;
/* 392 */       RuntimeBeanReference pointcutRef = new RuntimeBeanReference(beanName);
/* 393 */       cav.addIndexedArgumentValue(1, pointcutRef);
/* 394 */       beanReferences.add(pointcutRef); }
/*     */ 
/*     */     
/* 397 */     cav.addIndexedArgumentValue(2, aspectFactoryDef);
/*     */     
/* 399 */     return (AbstractBeanDefinition)adviceDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> getAdviceClass(Element adviceElement, ParserContext parserContext) {
/* 406 */     String elementName = parserContext.getDelegate().getLocalName(adviceElement);
/* 407 */     switch (elementName) { case "before": 
/*     */       case "after": 
/*     */       case "after-returning": 
/*     */       case "after-throwing":
/*     */       
/*     */       case "around":
/* 413 */        }  throw new IllegalArgumentException("Unknown advice kind [" + elementName + "].");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractBeanDefinition parsePointcut(Element pointcutElement, ParserContext parserContext) {
/* 422 */     String id = pointcutElement.getAttribute("id");
/* 423 */     String expression = pointcutElement.getAttribute("expression");
/*     */     
/* 425 */     AbstractBeanDefinition pointcutDefinition = null;
/*     */     
/*     */     try {
/* 428 */       this.parseState.push(new PointcutEntry(id));
/* 429 */       pointcutDefinition = createPointcutDefinition(expression);
/* 430 */       pointcutDefinition.setSource(parserContext.extractSource(pointcutElement));
/*     */       
/* 432 */       String pointcutBeanName = id;
/* 433 */       if (StringUtils.hasText(pointcutBeanName)) {
/* 434 */         parserContext.getRegistry().registerBeanDefinition(pointcutBeanName, (BeanDefinition)pointcutDefinition);
/*     */       } else {
/*     */         
/* 437 */         pointcutBeanName = parserContext.getReaderContext().registerWithGeneratedName((BeanDefinition)pointcutDefinition);
/*     */       } 
/*     */       
/* 440 */       parserContext.registerComponent((ComponentDefinition)new PointcutComponentDefinition(pointcutBeanName, (BeanDefinition)pointcutDefinition, expression));
/*     */     }
/*     */     finally {
/*     */       
/* 444 */       this.parseState.pop();
/*     */     } 
/*     */     
/* 447 */     return pointcutDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object parsePointcutProperty(Element element, ParserContext parserContext) {
/* 458 */     if (element.hasAttribute("pointcut") && element.hasAttribute("pointcut-ref")) {
/* 459 */       parserContext.getReaderContext().error("Cannot define both 'pointcut' and 'pointcut-ref' on <advisor> tag.", element, this.parseState
/*     */           
/* 461 */           .snapshot());
/* 462 */       return null;
/*     */     } 
/* 464 */     if (element.hasAttribute("pointcut")) {
/*     */       
/* 466 */       String expression = element.getAttribute("pointcut");
/* 467 */       AbstractBeanDefinition pointcutDefinition = createPointcutDefinition(expression);
/* 468 */       pointcutDefinition.setSource(parserContext.extractSource(element));
/* 469 */       return pointcutDefinition;
/*     */     } 
/* 471 */     if (element.hasAttribute("pointcut-ref")) {
/* 472 */       String pointcutRef = element.getAttribute("pointcut-ref");
/* 473 */       if (!StringUtils.hasText(pointcutRef)) {
/* 474 */         parserContext.getReaderContext().error("'pointcut-ref' attribute contains empty value.", element, this.parseState
/* 475 */             .snapshot());
/* 476 */         return null;
/*     */       } 
/* 478 */       return pointcutRef;
/*     */     } 
/*     */     
/* 481 */     parserContext.getReaderContext().error("Must define one of 'pointcut' or 'pointcut-ref' on <advisor> tag.", element, this.parseState
/*     */         
/* 483 */         .snapshot());
/* 484 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractBeanDefinition createPointcutDefinition(String expression) {
/* 493 */     RootBeanDefinition beanDefinition = new RootBeanDefinition(AspectJExpressionPointcut.class);
/* 494 */     beanDefinition.setScope("prototype");
/* 495 */     beanDefinition.setSynthetic(true);
/* 496 */     beanDefinition.getPropertyValues().add("expression", expression);
/* 497 */     return (AbstractBeanDefinition)beanDefinition;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\config\ConfigBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */