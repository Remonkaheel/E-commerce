/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClassFilters
/*     */ {
/*     */   public static ClassFilter union(ClassFilter cf1, ClassFilter cf2) {
/*  49 */     Assert.notNull(cf1, "First ClassFilter must not be null");
/*  50 */     Assert.notNull(cf2, "Second ClassFilter must not be null");
/*  51 */     return new UnionClassFilter(new ClassFilter[] { cf1, cf2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFilter union(ClassFilter[] classFilters) {
/*  61 */     Assert.notEmpty((Object[])classFilters, "ClassFilter array must not be empty");
/*  62 */     return new UnionClassFilter(classFilters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFilter intersection(ClassFilter cf1, ClassFilter cf2) {
/*  73 */     Assert.notNull(cf1, "First ClassFilter must not be null");
/*  74 */     Assert.notNull(cf2, "Second ClassFilter must not be null");
/*  75 */     return new IntersectionClassFilter(new ClassFilter[] { cf1, cf2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFilter intersection(ClassFilter[] classFilters) {
/*  85 */     Assert.notEmpty((Object[])classFilters, "ClassFilter array must not be empty");
/*  86 */     return new IntersectionClassFilter(classFilters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFilter negate(ClassFilter classFilter) {
/*  97 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/*  98 */     return new NegateClassFilter(classFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class UnionClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private final ClassFilter[] filters;
/*     */ 
/*     */ 
/*     */     
/*     */     UnionClassFilter(ClassFilter[] filters) {
/* 111 */       this.filters = filters;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Class<?> clazz) {
/* 116 */       for (ClassFilter filter : this.filters) {
/* 117 */         if (filter.matches(clazz)) {
/* 118 */           return true;
/*     */         }
/*     */       } 
/* 121 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 126 */       if (this != other) { if (other instanceof UnionClassFilter) { UnionClassFilter that = (UnionClassFilter)other;
/* 127 */           if (ObjectUtils.nullSafeEquals(this.filters, that.filters)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 132 */       return Arrays.hashCode((Object[])this.filters);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 137 */       return getClass().getName() + ": " + getClass().getName();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IntersectionClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private final ClassFilter[] filters;
/*     */ 
/*     */ 
/*     */     
/*     */     IntersectionClassFilter(ClassFilter[] filters) {
/* 151 */       this.filters = filters;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Class<?> clazz) {
/* 156 */       for (ClassFilter filter : this.filters) {
/* 157 */         if (!filter.matches(clazz)) {
/* 158 */           return false;
/*     */         }
/*     */       } 
/* 161 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 166 */       if (this != other) { if (other instanceof IntersectionClassFilter) { IntersectionClassFilter that = (IntersectionClassFilter)other;
/* 167 */           if (ObjectUtils.nullSafeEquals(this.filters, that.filters)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 172 */       return Arrays.hashCode((Object[])this.filters);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 177 */       return getClass().getName() + ": " + getClass().getName();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NegateClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private final ClassFilter original;
/*     */ 
/*     */ 
/*     */     
/*     */     NegateClassFilter(ClassFilter original) {
/* 191 */       this.original = original;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Class<?> clazz) {
/* 196 */       return !this.original.matches(clazz);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 201 */       if (this != other) { if (other instanceof NegateClassFilter) { NegateClassFilter that = (NegateClassFilter)other; if (this.original
/* 202 */             .equals(that.original)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 207 */       return Objects.hash(new Object[] { getClass(), this.original });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 212 */       return "Negate " + String.valueOf(this.original);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\ClassFilters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */