/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractExpressionPointcut
/*    */   implements ExpressionPointcut, Serializable
/*    */ {
/*    */   @Nullable
/*    */   private String location;
/*    */   @Nullable
/*    */   private String expression;
/*    */   
/*    */   public void setLocation(@Nullable String location) {
/* 47 */     this.location = location;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getLocation() {
/* 58 */     return this.location;
/*    */   }
/*    */   
/*    */   public void setExpression(@Nullable String expression) {
/* 62 */     this.expression = expression;
/*    */     try {
/* 64 */       onSetExpression(expression);
/*    */     }
/* 66 */     catch (IllegalArgumentException ex) {
/*    */       
/* 68 */       if (this.location != null) {
/* 69 */         throw new IllegalArgumentException("Invalid expression at location [" + this.location + "]: " + String.valueOf(ex));
/*    */       }
/*    */       
/* 72 */       throw ex;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void onSetExpression(@Nullable String expression) throws IllegalArgumentException {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getExpression() {
/* 94 */     return this.expression;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\AbstractExpressionPointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */