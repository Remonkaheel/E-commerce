package org.springframework.aop.support;

import org.springframework.aop.Pointcut;
import org.springframework.lang.Nullable;

public interface ExpressionPointcut extends Pointcut {
  @Nullable
  String getExpression();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\ExpressionPointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */