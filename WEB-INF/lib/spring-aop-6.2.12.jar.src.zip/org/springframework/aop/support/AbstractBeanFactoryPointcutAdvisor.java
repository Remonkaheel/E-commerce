/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBeanFactoryPointcutAdvisor
/*     */   extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   @Nullable
/*     */   private String adviceBeanName;
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   @Nullable
/*     */   private volatile transient Advice advice;
/*  54 */   private transient Object adviceMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdviceBeanName(@Nullable String adviceBeanName) {
/*  66 */     this.adviceBeanName = adviceBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getAdviceBeanName() {
/*  74 */     return this.adviceBeanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*  79 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdvice(Advice advice) {
/*  88 */     synchronized (this.adviceMonitor) {
/*  89 */       this.advice = advice;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/*  95 */     Advice advice = this.advice;
/*  96 */     if (advice != null) {
/*  97 */       return advice;
/*     */     }
/*     */     
/* 100 */     Assert.state((this.adviceBeanName != null), "'adviceBeanName' must be specified");
/* 101 */     Assert.state((this.beanFactory != null), "BeanFactory must be set to resolve 'adviceBeanName'");
/*     */     
/* 103 */     if (this.beanFactory.isSingleton(this.adviceBeanName)) {
/*     */       
/* 105 */       advice = (Advice)this.beanFactory.getBean(this.adviceBeanName, Advice.class);
/* 106 */       this.advice = advice;
/* 107 */       return advice;
/*     */     } 
/*     */ 
/*     */     
/* 111 */     synchronized (this.adviceMonitor) {
/* 112 */       advice = this.advice;
/* 113 */       if (advice == null) {
/* 114 */         advice = (Advice)this.beanFactory.getBean(this.adviceBeanName, Advice.class);
/* 115 */         this.advice = advice;
/*     */       } 
/* 117 */       return advice;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 125 */     sb.append(": advice ");
/* 126 */     if (this.adviceBeanName != null) {
/* 127 */       sb.append("bean '").append(this.adviceBeanName).append('\'');
/*     */     } else {
/*     */       
/* 130 */       sb.append(this.advice);
/*     */     } 
/* 132 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 142 */     ois.defaultReadObject();
/*     */ 
/*     */     
/* 145 */     this.adviceMonitor = new Object();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\AbstractBeanFactoryPointcutAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */