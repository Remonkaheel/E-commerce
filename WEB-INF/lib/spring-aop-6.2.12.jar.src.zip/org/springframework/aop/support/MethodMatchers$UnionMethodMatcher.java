/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UnionMethodMatcher
/*     */   implements MethodMatcher, Serializable
/*     */ {
/*     */   protected final MethodMatcher mm1;
/*     */   protected final MethodMatcher mm2;
/*     */   
/*     */   public UnionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2) {
/* 127 */     Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 128 */     Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 129 */     this.mm1 = mm1;
/* 130 */     this.mm2 = mm2;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass) {
/* 135 */     return ((matchesClass1(targetClass) && this.mm1.matches(method, targetClass)) || (
/* 136 */       matchesClass2(targetClass) && this.mm2.matches(method, targetClass)));
/*     */   }
/*     */   
/*     */   protected boolean matchesClass1(Class<?> targetClass) {
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean matchesClass2(Class<?> targetClass) {
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRuntime() {
/* 149 */     return (this.mm1.isRuntime() || this.mm2.isRuntime());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 154 */     return (this.mm1.matches(method, targetClass, args) || this.mm2.matches(method, targetClass, args));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 159 */     if (this != other) { if (other instanceof UnionMethodMatcher) { UnionMethodMatcher that = (UnionMethodMatcher)other; if (this.mm1
/* 160 */           .equals(that.mm1) && this.mm2.equals(that.mm2)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 165 */     return 37 * this.mm1.hashCode() + this.mm2.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 170 */     return getClass().getName() + ": " + getClass().getName() + ", " + String.valueOf(this.mm1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\MethodMatchers$UnionMethodMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */