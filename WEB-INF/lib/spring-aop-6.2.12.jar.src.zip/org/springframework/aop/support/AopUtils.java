/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import kotlin.coroutines.Continuation;
/*     */ import kotlin.coroutines.CoroutineContext;
/*     */ import kotlinx.coroutines.Job;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.CoroutinesUtils;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.lang.Contract;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AopUtils
/*     */ {
/*  69 */   private static final boolean coroutinesReactorPresent = ClassUtils.isPresent("kotlinx.coroutines.reactor.MonoKt", AopUtils.class
/*  70 */       .getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null -> false")
/*     */   public static boolean isAopProxy(@Nullable Object object) {
/*  83 */     return (object instanceof SpringProxy && (Proxy.isProxyClass(object.getClass()) || object
/*  84 */       .getClass().getName().contains("$$")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null -> false")
/*     */   public static boolean isJdkDynamicProxy(@Nullable Object object) {
/*  97 */     return (object instanceof SpringProxy && Proxy.isProxyClass(object.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null -> false")
/*     */   public static boolean isCglibProxy(@Nullable Object object) {
/* 110 */     return (object instanceof SpringProxy && object
/* 111 */       .getClass().getName().contains("$$"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getTargetClass(Object candidate) {
/* 124 */     Assert.notNull(candidate, "Candidate object must not be null");
/* 125 */     Class<?> result = null;
/* 126 */     if (candidate instanceof TargetClassAware) { TargetClassAware targetClassAware = (TargetClassAware)candidate;
/* 127 */       result = targetClassAware.getTargetClass(); }
/*     */     
/* 129 */     if (result == null) {
/* 130 */       result = isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method selectInvocableMethod(Method method, @Nullable Class<?> targetType) {
/* 148 */     if (targetType == null) {
/* 149 */       return method;
/*     */     }
/* 151 */     Method methodToUse = MethodIntrospector.selectInvocableMethod(method, targetType);
/* 152 */     if (Modifier.isPrivate(methodToUse.getModifiers()) && !Modifier.isStatic(methodToUse.getModifiers()) && SpringProxy.class
/* 153 */       .isAssignableFrom(targetType)) {
/* 154 */       throw new IllegalStateException(String.format("Need to invoke method '%s' found on proxy for target class '%s' but cannot be delegated to target bean. Switch its visibility to package or protected.", new Object[] { method
/*     */ 
/*     */               
/* 157 */               .getName(), method.getDeclaringClass().getSimpleName() }));
/*     */     }
/* 159 */     return methodToUse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEqualsMethod(@Nullable Method method) {
/* 167 */     return ReflectionUtils.isEqualsMethod(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHashCodeMethod(@Nullable Method method) {
/* 175 */     return ReflectionUtils.isHashCodeMethod(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isToStringMethod(@Nullable Method method) {
/* 183 */     return ReflectionUtils.isToStringMethod(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFinalizeMethod(@Nullable Method method) {
/* 191 */     return (method != null && method.getName().equals("finalize") && method
/* 192 */       .getParameterCount() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMostSpecificMethod(Method method, @Nullable Class<?> targetClass) {
/* 213 */     Class<?> specificTargetClass = (targetClass != null) ? ClassUtils.getUserClass(targetClass) : null;
/* 214 */     return BridgeMethodResolver.getMostSpecificMethod(method, specificTargetClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canApply(Pointcut pc, Class<?> targetClass) {
/* 226 */     return canApply(pc, targetClass, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canApply(Pointcut pc, Class<?> targetClass, boolean hasIntroductions) {
/* 240 */     Assert.notNull(pc, "Pointcut must not be null");
/* 241 */     if (!pc.getClassFilter().matches(targetClass)) {
/* 242 */       return false;
/*     */     }
/*     */     
/* 245 */     MethodMatcher methodMatcher = pc.getMethodMatcher();
/* 246 */     if (methodMatcher == MethodMatcher.TRUE)
/*     */     {
/* 248 */       return true;
/*     */     }
/*     */     
/* 251 */     IntroductionAwareMethodMatcher introductionAwareMethodMatcher = null;
/* 252 */     if (methodMatcher instanceof IntroductionAwareMethodMatcher) { IntroductionAwareMethodMatcher iamm = (IntroductionAwareMethodMatcher)methodMatcher;
/* 253 */       introductionAwareMethodMatcher = iamm; }
/*     */ 
/*     */     
/* 256 */     Set<Class<?>> classes = new LinkedHashSet<>();
/* 257 */     if (!Proxy.isProxyClass(targetClass)) {
/* 258 */       classes.add(ClassUtils.getUserClass(targetClass));
/*     */     }
/* 260 */     classes.addAll(ClassUtils.getAllInterfacesForClassAsSet(targetClass));
/*     */     
/* 262 */     for (Class<?> clazz : classes) {
/* 263 */       Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz);
/* 264 */       for (Method method : methods) {
/* 265 */         if ((introductionAwareMethodMatcher != null) ? introductionAwareMethodMatcher
/* 266 */           .matches(method, targetClass, hasIntroductions) : methodMatcher
/* 267 */           .matches(method, targetClass)) {
/* 268 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 273 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canApply(Advisor advisor, Class<?> targetClass) {
/* 285 */     return canApply(advisor, targetClass, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canApply(Advisor advisor, Class<?> targetClass, boolean hasIntroductions) {
/* 299 */     if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor ia = (IntroductionAdvisor)advisor;
/* 300 */       return ia.getClassFilter().matches(targetClass); }
/*     */     
/* 302 */     if (advisor instanceof PointcutAdvisor) { PointcutAdvisor pca = (PointcutAdvisor)advisor;
/* 303 */       return canApply(pca.getPointcut(), targetClass, hasIntroductions); }
/*     */ 
/*     */ 
/*     */     
/* 307 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Advisor> findAdvisorsThatCanApply(List<Advisor> candidateAdvisors, Class<?> clazz) {
/* 320 */     if (candidateAdvisors.isEmpty()) {
/* 321 */       return candidateAdvisors;
/*     */     }
/* 323 */     List<Advisor> eligibleAdvisors = new ArrayList<>();
/* 324 */     for (Advisor candidate : candidateAdvisors) {
/* 325 */       if (candidate instanceof IntroductionAdvisor && canApply(candidate, clazz)) {
/* 326 */         eligibleAdvisors.add(candidate);
/*     */       }
/*     */     } 
/* 329 */     boolean hasIntroductions = !eligibleAdvisors.isEmpty();
/* 330 */     for (Advisor candidate : candidateAdvisors) {
/* 331 */       if (candidate instanceof IntroductionAdvisor) {
/*     */         continue;
/*     */       }
/*     */       
/* 335 */       if (canApply(candidate, clazz, hasIntroductions)) {
/* 336 */         eligibleAdvisors.add(candidate);
/*     */       }
/*     */     } 
/* 339 */     return eligibleAdvisors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object invokeJoinpointUsingReflection(@Nullable Object target, Method method, Object[] args) throws Throwable {
/*     */     try {
/* 357 */       Method originalMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 358 */       ReflectionUtils.makeAccessible(originalMethod);
/* 359 */       return (coroutinesReactorPresent && KotlinDetector.isSuspendingFunction(originalMethod)) ? 
/* 360 */         KotlinDelegate.invokeSuspendingFunction(originalMethod, target, args) : originalMethod.invoke(target, args);
/*     */     }
/* 362 */     catch (InvocationTargetException ex) {
/*     */ 
/*     */       
/* 365 */       throw ex.getTargetException();
/*     */     }
/* 367 */     catch (IllegalArgumentException ex) {
/* 368 */       throw new AopInvocationException("AOP configuration seems to be invalid: tried calling method [" + String.valueOf(method) + "] on target [" + String.valueOf(target) + "]", ex);
/*     */     
/*     */     }
/* 371 */     catch (IllegalAccessException|java.lang.reflect.InaccessibleObjectException ex) {
/* 372 */       throw new AopInvocationException("Could not access method [" + String.valueOf(method) + "]", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     public static Object invokeSuspendingFunction(Method method, @Nullable Object target, Object... args) {
/* 383 */       Continuation<?> continuation = (Continuation)args[args.length - 1];
/* 384 */       Assert.state((continuation != null), "No Continuation available");
/* 385 */       CoroutineContext context = continuation.getContext().minusKey((CoroutineContext.Key)Job.Key);
/* 386 */       return CoroutinesUtils.invokeSuspendingFunction(context, method, target, args);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\AopUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */