/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComposablePointcut
/*     */   implements Pointcut, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -2743223737633663832L;
/*     */   private ClassFilter classFilter;
/*     */   private MethodMatcher methodMatcher;
/*     */   
/*     */   public ComposablePointcut() {
/*  61 */     this.classFilter = ClassFilter.TRUE;
/*  62 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut(Pointcut pointcut) {
/*  70 */     Assert.notNull(pointcut, "Pointcut must not be null");
/*  71 */     this.classFilter = pointcut.getClassFilter();
/*  72 */     this.methodMatcher = pointcut.getMethodMatcher();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut(ClassFilter classFilter) {
/*  81 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/*  82 */     this.classFilter = classFilter;
/*  83 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut(MethodMatcher methodMatcher) {
/*  92 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/*  93 */     this.classFilter = ClassFilter.TRUE;
/*  94 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut(ClassFilter classFilter, MethodMatcher methodMatcher) {
/* 103 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/* 104 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/* 105 */     this.classFilter = classFilter;
/* 106 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut union(ClassFilter other) {
/* 116 */     this.classFilter = ClassFilters.union(this.classFilter, other);
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut intersection(ClassFilter other) {
/* 126 */     this.classFilter = ClassFilters.intersection(this.classFilter, other);
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut union(MethodMatcher other) {
/* 136 */     this.methodMatcher = MethodMatchers.union(this.methodMatcher, other);
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut intersection(MethodMatcher other) {
/* 146 */     this.methodMatcher = MethodMatchers.intersection(this.methodMatcher, other);
/* 147 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut union(Pointcut other) {
/* 160 */     this.methodMatcher = MethodMatchers.union(this.methodMatcher, this.classFilter, other
/* 161 */         .getMethodMatcher(), other.getClassFilter());
/* 162 */     this.classFilter = ClassFilters.union(this.classFilter, other.getClassFilter());
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComposablePointcut intersection(Pointcut other) {
/* 172 */     this.classFilter = ClassFilters.intersection(this.classFilter, other.getClassFilter());
/* 173 */     this.methodMatcher = MethodMatchers.intersection(this.methodMatcher, other.getMethodMatcher());
/* 174 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFilter getClassFilter() {
/* 180 */     return this.classFilter;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodMatcher getMethodMatcher() {
/* 185 */     return this.methodMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 190 */     if (this != other) { if (other instanceof ComposablePointcut) { ComposablePointcut otherPointcut = (ComposablePointcut)other; if (this.classFilter
/* 191 */           .equals(otherPointcut.classFilter) && this.methodMatcher
/* 192 */           .equals(otherPointcut.methodMatcher)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 197 */     return this.classFilter.hashCode() * 37 + this.methodMatcher.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 202 */     return getClass().getName() + ": " + getClass().getName() + ", " + String.valueOf(this.classFilter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\ComposablePointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */