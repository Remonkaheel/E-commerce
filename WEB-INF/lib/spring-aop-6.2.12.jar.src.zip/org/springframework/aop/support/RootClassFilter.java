/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RootClassFilter
/*    */   implements ClassFilter, Serializable
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   
/*    */   public RootClassFilter(Class<?> clazz) {
/* 38 */     Assert.notNull(clazz, "Class must not be null");
/* 39 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matches(Class<?> candidate) {
/* 45 */     return this.clazz.isAssignableFrom(candidate);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 50 */     if (this != other) { if (other instanceof RootClassFilter) { RootClassFilter that = (RootClassFilter)other; if (this.clazz
/* 51 */           .equals(that.clazz)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 56 */     return this.clazz.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     return getClass().getName() + ": " + getClass().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\RootClassFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */