/*     */ package org.springframework.aop.support.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.aop.support.StaticMethodMatcher;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMethodMatcher
/*     */   extends StaticMethodMatcher
/*     */ {
/*     */   private final Class<? extends Annotation> annotationType;
/*     */   private final boolean checkInherited;
/*     */   
/*     */   public AnnotationMethodMatcher(Class<? extends Annotation> annotationType) {
/*  51 */     this(annotationType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationMethodMatcher(Class<? extends Annotation> annotationType, boolean checkInherited) {
/*  64 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*  65 */     this.annotationType = annotationType;
/*  66 */     this.checkInherited = checkInherited;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass) {
/*  73 */     if (matchesMethod(method)) {
/*  74 */       return true;
/*     */     }
/*     */     
/*  77 */     if (Proxy.isProxyClass(targetClass)) {
/*  78 */       return false;
/*     */     }
/*     */     
/*  81 */     Method specificMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/*  82 */     return (specificMethod != method && matchesMethod(specificMethod));
/*     */   }
/*     */   
/*     */   private boolean matchesMethod(Method method) {
/*  86 */     return this.checkInherited ? AnnotatedElementUtils.hasAnnotation(method, this.annotationType) : 
/*  87 */       method.isAnnotationPresent(this.annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*  92 */     if (this != other) { if (other instanceof AnnotationMethodMatcher) { AnnotationMethodMatcher otherMm = (AnnotationMethodMatcher)other; if (this.annotationType
/*  93 */           .equals(otherMm.annotationType) && this.checkInherited == otherMm.checkInherited); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   }
/*     */   public int hashCode() {
/*  99 */     return this.annotationType.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\annotation\AnnotationMethodMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */