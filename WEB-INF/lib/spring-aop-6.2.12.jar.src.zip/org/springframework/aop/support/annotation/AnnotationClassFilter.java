/*    */ package org.springframework.aop.support.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationClassFilter
/*    */   implements ClassFilter
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */   private final boolean checkInherited;
/*    */   
/*    */   public AnnotationClassFilter(Class<? extends Annotation> annotationType) {
/* 45 */     this(annotationType, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AnnotationClassFilter(Class<? extends Annotation> annotationType, boolean checkInherited) {
/* 57 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 58 */     this.annotationType = annotationType;
/* 59 */     this.checkInherited = checkInherited;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matches(Class<?> clazz) {
/* 65 */     return this.checkInherited ? AnnotatedElementUtils.hasAnnotation(clazz, this.annotationType) : 
/* 66 */       clazz.isAnnotationPresent(this.annotationType);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 71 */     if (this != other) { if (other instanceof AnnotationClassFilter) { AnnotationClassFilter otherCf = (AnnotationClassFilter)other; if (this.annotationType
/* 72 */           .equals(otherCf.annotationType) && this.checkInherited == otherCf.checkInherited); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   }
/*    */   public int hashCode() {
/* 78 */     return this.annotationType.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     return getClass().getName() + ": " + getClass().getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\annotation\AnnotationClassFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */