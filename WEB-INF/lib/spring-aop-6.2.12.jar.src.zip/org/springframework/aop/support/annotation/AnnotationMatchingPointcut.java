/*     */ package org.springframework.aop.support.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMatchingPointcut
/*     */   implements Pointcut
/*     */ {
/*     */   private final ClassFilter classFilter;
/*     */   private final MethodMatcher methodMatcher;
/*     */   
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType) {
/*  50 */     this(classAnnotationType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType, boolean checkInherited) {
/*  61 */     this.classFilter = new AnnotationClassFilter(classAnnotationType, checkInherited);
/*  62 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationMatchingPointcut(@Nullable Class<? extends Annotation> classAnnotationType, @Nullable Class<? extends Annotation> methodAnnotationType) {
/*  75 */     this(classAnnotationType, methodAnnotationType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationMatchingPointcut(@Nullable Class<? extends Annotation> classAnnotationType, @Nullable Class<? extends Annotation> methodAnnotationType, boolean checkInherited) {
/*  94 */     Assert.isTrue((classAnnotationType != null || methodAnnotationType != null), "Either Class annotation type or Method annotation type needs to be specified (or both)");
/*     */ 
/*     */     
/*  97 */     if (classAnnotationType != null) {
/*  98 */       this.classFilter = new AnnotationClassFilter(classAnnotationType, checkInherited);
/*     */     } else {
/*     */       
/* 101 */       this.classFilter = new AnnotationCandidateClassFilter(methodAnnotationType);
/*     */     } 
/*     */     
/* 104 */     if (methodAnnotationType != null) {
/* 105 */       this.methodMatcher = (MethodMatcher)new AnnotationMethodMatcher(methodAnnotationType, checkInherited);
/*     */     } else {
/*     */       
/* 108 */       this.methodMatcher = MethodMatcher.TRUE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFilter getClassFilter() {
/* 115 */     return this.classFilter;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodMatcher getMethodMatcher() {
/* 120 */     return this.methodMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 125 */     if (this != other) { if (other instanceof AnnotationMatchingPointcut) { AnnotationMatchingPointcut otherPointcut = (AnnotationMatchingPointcut)other; if (this.classFilter
/* 126 */           .equals(otherPointcut.classFilter) && this.methodMatcher
/* 127 */           .equals(otherPointcut.methodMatcher)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 132 */     return this.classFilter.hashCode() * 37 + this.methodMatcher.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "AnnotationMatchingPointcut: " + String.valueOf(this.classFilter) + ", " + String.valueOf(this.methodMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationMatchingPointcut forClassAnnotation(Class<? extends Annotation> annotationType) {
/* 147 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 148 */     return new AnnotationMatchingPointcut(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationMatchingPointcut forMethodAnnotation(Class<? extends Annotation> annotationType) {
/* 158 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 159 */     return new AnnotationMatchingPointcut(null, annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AnnotationCandidateClassFilter
/*     */     implements ClassFilter
/*     */   {
/*     */     private final Class<? extends Annotation> annotationType;
/*     */ 
/*     */ 
/*     */     
/*     */     AnnotationCandidateClassFilter(Class<? extends Annotation> annotationType) {
/* 173 */       this.annotationType = annotationType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Class<?> clazz) {
/* 178 */       return AnnotationUtils.isCandidateClass(clazz, this.annotationType);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 183 */       if (this != other) { if (other instanceof AnnotationCandidateClassFilter) { AnnotationCandidateClassFilter that = (AnnotationCandidateClassFilter)other; if (this.annotationType
/* 184 */             .equals(that.annotationType)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 189 */       return this.annotationType.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 194 */       return getClass().getName() + ": " + getClass().getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\annotation\AnnotationMatchingPointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */