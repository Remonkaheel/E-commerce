/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Objects;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MethodMatchers
/*     */ {
/*     */   public static MethodMatcher union(MethodMatcher mm1, MethodMatcher mm2) {
/*  54 */     return (mm1 instanceof IntroductionAwareMethodMatcher || mm2 instanceof IntroductionAwareMethodMatcher) ? 
/*  55 */       new UnionIntroductionAwareMethodMatcher(mm1, mm2) : new UnionMethodMatcher(mm1, mm2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MethodMatcher union(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2) {
/*  68 */     return (mm1 instanceof IntroductionAwareMethodMatcher || mm2 instanceof IntroductionAwareMethodMatcher) ? 
/*  69 */       new ClassFilterAwareUnionIntroductionAwareMethodMatcher(mm1, cf1, mm2, cf2) : 
/*  70 */       new ClassFilterAwareUnionMethodMatcher(mm1, cf1, mm2, cf2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodMatcher intersection(MethodMatcher mm1, MethodMatcher mm2) {
/*  81 */     return (mm1 instanceof IntroductionAwareMethodMatcher || mm2 instanceof IntroductionAwareMethodMatcher) ? 
/*  82 */       new IntersectionIntroductionAwareMethodMatcher(mm1, mm2) : new IntersectionMethodMatcher(mm1, mm2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodMatcher negate(MethodMatcher methodMatcher) {
/*  93 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/*  94 */     return new NegateMethodMatcher(methodMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(MethodMatcher mm, Method method, Class<?> targetClass, boolean hasIntroductions) {
/* 109 */     Assert.notNull(mm, "MethodMatcher must not be null");
/* 110 */     IntroductionAwareMethodMatcher iamm = (IntroductionAwareMethodMatcher)mm; return (mm instanceof IntroductionAwareMethodMatcher) ? 
/* 111 */       iamm.matches(method, targetClass, hasIntroductions) : 
/* 112 */       mm.matches(method, targetClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class UnionMethodMatcher
/*     */     implements MethodMatcher, Serializable
/*     */   {
/*     */     protected final MethodMatcher mm1;
/*     */ 
/*     */     
/*     */     protected final MethodMatcher mm2;
/*     */ 
/*     */     
/*     */     public UnionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2) {
/* 127 */       Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 128 */       Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 129 */       this.mm1 = mm1;
/* 130 */       this.mm2 = mm2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 135 */       return ((matchesClass1(targetClass) && this.mm1.matches(method, targetClass)) || (
/* 136 */         matchesClass2(targetClass) && this.mm2.matches(method, targetClass)));
/*     */     }
/*     */     
/*     */     protected boolean matchesClass1(Class<?> targetClass) {
/* 140 */       return true;
/*     */     }
/*     */     
/*     */     protected boolean matchesClass2(Class<?> targetClass) {
/* 144 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRuntime() {
/* 149 */       return (this.mm1.isRuntime() || this.mm2.isRuntime());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 154 */       return (this.mm1.matches(method, targetClass, args) || this.mm2.matches(method, targetClass, args));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 159 */       if (this != other) { if (other instanceof UnionMethodMatcher) { UnionMethodMatcher that = (UnionMethodMatcher)other; if (this.mm1
/* 160 */             .equals(that.mm1) && this.mm2.equals(that.mm2)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 165 */       return 37 * this.mm1.hashCode() + this.mm2.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 170 */       return getClass().getName() + ": " + getClass().getName() + ", " + String.valueOf(this.mm1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class UnionIntroductionAwareMethodMatcher
/*     */     extends UnionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher
/*     */   {
/*     */     public UnionIntroductionAwareMethodMatcher(MethodMatcher mm1, MethodMatcher mm2) {
/* 185 */       super(mm1, mm2);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions) {
/* 190 */       return ((matchesClass1(targetClass) && MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions)) || (
/* 191 */         matchesClass2(targetClass) && MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ClassFilterAwareUnionMethodMatcher
/*     */     extends UnionMethodMatcher
/*     */   {
/*     */     private final ClassFilter cf1;
/*     */ 
/*     */     
/*     */     private final ClassFilter cf2;
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassFilterAwareUnionMethodMatcher(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2) {
/* 208 */       super(mm1, mm2);
/* 209 */       this.cf1 = cf1;
/* 210 */       this.cf2 = cf2;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchesClass1(Class<?> targetClass) {
/* 215 */       return this.cf1.matches(targetClass);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean matchesClass2(Class<?> targetClass) {
/* 220 */       return this.cf2.matches(targetClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 225 */       if (this == other) {
/* 226 */         return true;
/*     */       }
/* 228 */       if (!super.equals(other)) {
/* 229 */         return false;
/*     */       }
/* 231 */       ClassFilter otherCf1 = ClassFilter.TRUE;
/* 232 */       ClassFilter otherCf2 = ClassFilter.TRUE;
/* 233 */       if (other instanceof ClassFilterAwareUnionMethodMatcher) { ClassFilterAwareUnionMethodMatcher cfa = (ClassFilterAwareUnionMethodMatcher)other;
/* 234 */         otherCf1 = cfa.cf1;
/* 235 */         otherCf2 = cfa.cf2; }
/*     */       
/* 237 */       return (this.cf1.equals(otherCf1) && this.cf2.equals(otherCf2));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 243 */       return super.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 248 */       return getClass().getName() + ": " + getClass().getName() + ", " + String.valueOf(this.cf1) + ", " + String.valueOf(this.mm1) + ", " + String.valueOf(this.cf2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ClassFilterAwareUnionIntroductionAwareMethodMatcher
/*     */     extends ClassFilterAwareUnionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher
/*     */   {
/*     */     public ClassFilterAwareUnionIntroductionAwareMethodMatcher(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2) {
/* 266 */       super(mm1, cf1, mm2, cf2);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions) {
/* 271 */       return ((matchesClass1(targetClass) && MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions)) || (
/* 272 */         matchesClass2(targetClass) && MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IntersectionMethodMatcher
/*     */     implements MethodMatcher, Serializable
/*     */   {
/*     */     protected final MethodMatcher mm1;
/*     */ 
/*     */     
/*     */     protected final MethodMatcher mm2;
/*     */ 
/*     */     
/*     */     public IntersectionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2) {
/* 288 */       Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 289 */       Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 290 */       this.mm1 = mm1;
/* 291 */       this.mm2 = mm2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 296 */       return (this.mm1.matches(method, targetClass) && this.mm2.matches(method, targetClass));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRuntime() {
/* 301 */       return (this.mm1.isRuntime() || this.mm2.isRuntime());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 310 */       boolean aMatches = this.mm1.isRuntime() ? this.mm1.matches(method, targetClass, args) : this.mm1.matches(method, targetClass);
/*     */       
/* 312 */       boolean bMatches = this.mm2.isRuntime() ? this.mm2.matches(method, targetClass, args) : this.mm2.matches(method, targetClass);
/* 313 */       return (aMatches && bMatches);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 318 */       if (this != other) { if (other instanceof IntersectionMethodMatcher) { IntersectionMethodMatcher that = (IntersectionMethodMatcher)other; if (this.mm1
/* 319 */             .equals(that.mm1) && this.mm2.equals(that.mm2)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 324 */       return 37 * this.mm1.hashCode() + this.mm2.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 329 */       return getClass().getName() + ": " + getClass().getName() + ", " + String.valueOf(this.mm1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IntersectionIntroductionAwareMethodMatcher
/*     */     extends IntersectionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher
/*     */   {
/*     */     public IntersectionIntroductionAwareMethodMatcher(MethodMatcher mm1, MethodMatcher mm2) {
/* 344 */       super(mm1, mm2);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions) {
/* 349 */       return (MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions) && 
/* 350 */         MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class NegateMethodMatcher
/*     */     implements MethodMatcher, Serializable
/*     */   {
/*     */     private final MethodMatcher original;
/*     */     
/*     */     NegateMethodMatcher(MethodMatcher original) {
/* 361 */       this.original = original;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 366 */       return !this.original.matches(method, targetClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRuntime() {
/* 371 */       return this.original.isRuntime();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 376 */       return !this.original.matches(method, targetClass, args);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 381 */       if (this != other) { if (other instanceof NegateMethodMatcher) { NegateMethodMatcher that = (NegateMethodMatcher)other; if (this.original
/* 382 */             .equals(that.original)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 387 */       return Objects.hash(new Object[] { getClass(), this.original });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 392 */       return "Negate " + String.valueOf(this.original);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\MethodMatchers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */