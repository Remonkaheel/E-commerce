/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UnionClassFilter
/*     */   implements ClassFilter, Serializable
/*     */ {
/*     */   private final ClassFilter[] filters;
/*     */   
/*     */   UnionClassFilter(ClassFilter[] filters) {
/* 111 */     this.filters = filters;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Class<?> clazz) {
/* 116 */     for (ClassFilter filter : this.filters) {
/* 117 */       if (filter.matches(clazz)) {
/* 118 */         return true;
/*     */       }
/*     */     } 
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 126 */     if (this != other) { if (other instanceof UnionClassFilter) { UnionClassFilter that = (UnionClassFilter)other;
/* 127 */         if (ObjectUtils.nullSafeEquals(this.filters, that.filters)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 132 */     return Arrays.hashCode((Object[])this.filters);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\ClassFilters$UnionClassFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */