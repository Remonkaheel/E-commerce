/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Pointcuts
/*     */ {
/*  39 */   public static final Pointcut SETTERS = SetterPointcut.INSTANCE;
/*     */ 
/*     */   
/*  42 */   public static final Pointcut GETTERS = GetterPointcut.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pointcut union(Pointcut pc1, Pointcut pc2) {
/*  53 */     return (new ComposablePointcut(pc1)).union(pc2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pointcut intersection(Pointcut pc1, Pointcut pc2) {
/*  64 */     return (new ComposablePointcut(pc1)).intersection(pc2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(Pointcut pointcut, Method method, Class<?> targetClass, Object... args) {
/*  76 */     Assert.notNull(pointcut, "Pointcut must not be null");
/*  77 */     if (pointcut == Pointcut.TRUE) {
/*  78 */       return true;
/*     */     }
/*  80 */     if (pointcut.getClassFilter().matches(targetClass)) {
/*     */       
/*  82 */       MethodMatcher mm = pointcut.getMethodMatcher();
/*  83 */       if (mm.matches(method, targetClass))
/*     */       {
/*  85 */         return (!mm.isRuntime() || mm.matches(method, targetClass, args));
/*     */       }
/*     */     } 
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SetterPointcut
/*     */     extends StaticMethodMatcherPointcut
/*     */     implements Serializable
/*     */   {
/*  98 */     public static final SetterPointcut INSTANCE = new SetterPointcut();
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 102 */       return (method.getName().startsWith("set") && method
/* 103 */         .getParameterCount() == 1 && method
/* 104 */         .getReturnType() == void.class);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 108 */       return INSTANCE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 113 */       return "Pointcuts.SETTERS";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class GetterPointcut
/*     */     extends StaticMethodMatcherPointcut
/*     */     implements Serializable
/*     */   {
/* 124 */     public static final GetterPointcut INSTANCE = new GetterPointcut();
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 128 */       return (method.getName().startsWith("get") && method
/* 129 */         .getParameterCount() == 0 && method
/* 130 */         .getReturnType() != void.class);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 134 */       return INSTANCE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 139 */       return "Pointcuts.GETTERS";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\Pointcuts.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */