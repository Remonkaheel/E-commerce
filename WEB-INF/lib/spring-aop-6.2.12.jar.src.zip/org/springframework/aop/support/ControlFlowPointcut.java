/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlFlowPointcut
/*     */   implements Pointcut, ClassFilter, MethodMatcher, Serializable
/*     */ {
/*     */   protected final Class<?> clazz;
/*     */   protected final List<String> methodNamePatterns;
/*  65 */   private final AtomicInteger evaluationCount = new AtomicInteger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlowPointcut(Class<?> clazz) {
/*  73 */     this(clazz, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlowPointcut(Class<?> clazz, @Nullable String methodNamePattern) {
/*  85 */     Assert.notNull(clazz, "Class must not be null");
/*  86 */     this.clazz = clazz;
/*  87 */     this
/*  88 */       .methodNamePatterns = (methodNamePattern != null) ? Collections.<String>singletonList(methodNamePattern) : Collections.<String>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlowPointcut(Class<?> clazz, String... methodNamePatterns) {
/* 101 */     this(clazz, Arrays.asList(methodNamePatterns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlowPointcut(Class<?> clazz, List<String> methodNamePatterns) {
/* 114 */     Assert.notNull(clazz, "Class must not be null");
/* 115 */     Assert.notNull(methodNamePatterns, "List of method name patterns must not be null");
/* 116 */     Assert.noNullElements(methodNamePatterns, "List of method name patterns must not contain null elements");
/* 117 */     this.clazz = clazz;
/* 118 */     this.methodNamePatterns = methodNamePatterns.stream().distinct().toList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Class<?> clazz) {
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass) {
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRuntime() {
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 147 */     incrementEvaluationCount();
/*     */     
/* 149 */     for (StackTraceElement element : (new Throwable()).getStackTrace()) {
/* 150 */       if (element.getClassName().equals(this.clazz.getName())) {
/* 151 */         if (this.methodNamePatterns.isEmpty()) {
/* 152 */           return true;
/*     */         }
/* 154 */         String methodName = element.getMethodName();
/* 155 */         for (int i = 0; i < this.methodNamePatterns.size(); i++) {
/* 156 */           if (isMatch(methodName, i)) {
/* 157 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEvaluations() {
/* 171 */     return this.evaluationCount.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void incrementEvaluationCount() {
/* 180 */     this.evaluationCount.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMatch(String methodName, int patternIndex) {
/* 201 */     String methodNamePattern = this.methodNamePatterns.get(patternIndex);
/* 202 */     return isMatch(methodName, methodNamePattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMatch(String methodName, String methodNamePattern) {
/* 220 */     return (methodName.equals(methodNamePattern) || 
/* 221 */       PatternMatchUtils.simpleMatch(methodNamePattern, methodName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFilter getClassFilter() {
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodMatcher getMethodMatcher() {
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 238 */     if (this != other) { if (other instanceof ControlFlowPointcut) { ControlFlowPointcut that = (ControlFlowPointcut)other; if (this.clazz
/* 239 */           .equals(that.clazz) && this.methodNamePatterns.equals(that.methodNamePatterns)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 244 */     int code = this.clazz.hashCode();
/* 245 */     code = 37 * code + this.methodNamePatterns.hashCode();
/* 246 */     return code;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 251 */     return getClass().getName() + ": class = " + getClass().getName() + "; methodNamePatterns = " + this.clazz.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\ControlFlowPointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */