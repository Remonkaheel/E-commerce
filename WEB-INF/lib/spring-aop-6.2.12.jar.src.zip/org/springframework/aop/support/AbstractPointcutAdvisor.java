/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.PointcutAdvisor;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPointcutAdvisor
/*    */   implements PointcutAdvisor, Ordered, Serializable
/*    */ {
/*    */   @Nullable
/*    */   private Integer order;
/*    */   
/*    */   public void setOrder(int order) {
/* 46 */     this.order = Integer.valueOf(order);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 51 */     if (this.order != null) {
/* 52 */       return this.order.intValue();
/*    */     }
/* 54 */     Advice advice = getAdvice();
/* 55 */     if (advice instanceof Ordered) { Ordered ordered = (Ordered)advice;
/* 56 */       return ordered.getOrder(); }
/*    */     
/* 58 */     return Integer.MAX_VALUE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 64 */     if (this != other) { if (other instanceof PointcutAdvisor) { PointcutAdvisor otherAdvisor = (PointcutAdvisor)other;
/* 65 */         if (ObjectUtils.nullSafeEquals(getAdvice(), otherAdvisor.getAdvice()) && 
/* 66 */           ObjectUtils.nullSafeEquals(getPointcut(), otherAdvisor.getPointcut())); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 71 */     return PointcutAdvisor.class.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\AbstractPointcutAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */