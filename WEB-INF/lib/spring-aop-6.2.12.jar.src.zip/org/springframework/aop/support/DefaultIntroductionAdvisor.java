/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.DynamicIntroductionAdvice;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionInfo;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultIntroductionAdvisor
/*     */   implements IntroductionAdvisor, ClassFilter, Ordered, Serializable
/*     */ {
/*     */   private final Advice advice;
/*  47 */   private final Set<Class<?>> interfaces = new LinkedHashSet<>();
/*     */   
/*  49 */   private int order = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultIntroductionAdvisor(Advice advice) {
/*  59 */     this(advice, (advice instanceof IntroductionInfo) ? introductionInfo : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultIntroductionAdvisor(Advice advice, @Nullable IntroductionInfo introductionInfo) {
/*  69 */     Assert.notNull(advice, "Advice must not be null");
/*  70 */     this.advice = advice;
/*  71 */     if (introductionInfo != null) {
/*  72 */       Class<?>[] introducedInterfaces = introductionInfo.getInterfaces();
/*  73 */       if (introducedInterfaces.length == 0) {
/*  74 */         throw new IllegalArgumentException("IntroductionInfo defines no interfaces to introduce: " + String.valueOf(introductionInfo));
/*     */       }
/*     */       
/*  77 */       for (Class<?> ifc : introducedInterfaces) {
/*  78 */         addInterface(ifc);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultIntroductionAdvisor(DynamicIntroductionAdvice advice, Class<?> ifc) {
/*  89 */     Assert.notNull(advice, "Advice must not be null");
/*  90 */     this.advice = (Advice)advice;
/*  91 */     addInterface(ifc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInterface(Class<?> ifc) {
/* 100 */     Assert.notNull(ifc, "Interface must not be null");
/* 101 */     if (!ifc.isInterface()) {
/* 102 */       throw new IllegalArgumentException("Specified class [" + ifc.getName() + "] must be an interface");
/*     */     }
/* 104 */     this.interfaces.add(ifc);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getInterfaces() {
/* 109 */     return ClassUtils.toClassArray(this.interfaces);
/*     */   }
/*     */ 
/*     */   
/*     */   public void validateInterfaces() throws IllegalArgumentException {
/* 114 */     for (Class<?> ifc : this.interfaces) {
/* 115 */       Advice advice = this.advice; if (advice instanceof DynamicIntroductionAdvice) { DynamicIntroductionAdvice dynamicIntroductionAdvice = (DynamicIntroductionAdvice)advice;
/* 116 */         if (!dynamicIntroductionAdvice.implementsInterface(ifc))
/* 117 */           throw new IllegalArgumentException("DynamicIntroductionAdvice [" + String.valueOf(this.advice) + "] does not implement interface [" + ifc
/* 118 */               .getName() + "] specified for introduction");  }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 124 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 129 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 134 */     return this.advice;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassFilter getClassFilter() {
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Class<?> clazz) {
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 150 */     if (this != other) { if (other instanceof DefaultIntroductionAdvisor) { DefaultIntroductionAdvisor otherAdvisor = (DefaultIntroductionAdvisor)other; if (this.advice
/* 151 */           .equals(otherAdvisor.advice) && this.interfaces
/* 152 */           .equals(otherAdvisor.interfaces)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 157 */     return this.advice.hashCode() * 13 + this.interfaces.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return getClass().getName() + ": advice [" + getClass().getName() + "]; interfaces " + String.valueOf(this.advice);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\DefaultIntroductionAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */