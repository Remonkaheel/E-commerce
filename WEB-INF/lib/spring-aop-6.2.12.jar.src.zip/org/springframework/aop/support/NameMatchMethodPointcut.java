/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameMatchMethodPointcut
/*     */   extends StaticMethodMatcherPointcut
/*     */   implements Serializable
/*     */ {
/*  49 */   private List<String> mappedNamePatterns = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappedName(String mappedNamePattern) {
/*  58 */     setMappedNames(new String[] { mappedNamePattern });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappedNames(String... mappedNamePatterns) {
/*  67 */     this.mappedNamePatterns = new ArrayList<>(Arrays.asList(mappedNamePatterns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameMatchMethodPointcut addMethodName(String mappedNamePattern) {
/*  82 */     this.mappedNamePatterns.add(mappedNamePattern);
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass) {
/*  89 */     for (String mappedNamePattern : this.mappedNamePatterns) {
/*  90 */       if (mappedNamePattern.equals(method.getName()) || isMatch(method.getName(), mappedNamePattern)) {
/*  91 */         return true;
/*     */       }
/*     */     } 
/*  94 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMatch(String methodName, String mappedNamePattern) {
/* 108 */     return PatternMatchUtils.simpleMatch(mappedNamePattern, methodName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 114 */     if (this != other) { if (other instanceof NameMatchMethodPointcut) { NameMatchMethodPointcut that = (NameMatchMethodPointcut)other; if (this.mappedNamePatterns
/* 115 */           .equals(that.mappedNamePatterns)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 120 */     return this.mappedNamePatterns.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\support\NameMatchMethodPointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */