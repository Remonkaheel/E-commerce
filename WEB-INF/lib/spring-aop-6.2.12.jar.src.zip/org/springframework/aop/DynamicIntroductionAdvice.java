package org.springframework.aop;

import org.aopalliance.aop.Advice;

public interface DynamicIntroductionAdvice extends Advice {
  boolean implementsInterface(Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\DynamicIntroductionAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */