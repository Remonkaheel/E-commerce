package org.springframework.aop;

import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

public interface AfterReturningAdvice extends AfterAdvice {
  void afterReturning(@Nullable Object paramObject1, Method paramMethod, Object[] paramArrayOfObject, @Nullable Object paramObject2) throws Throwable;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\AfterReturningAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */