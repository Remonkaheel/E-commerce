package org.springframework.aop;

import org.springframework.lang.Nullable;

public interface TargetClassAware {
  @Nullable
  Class<?> getTargetClass();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\TargetClassAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */