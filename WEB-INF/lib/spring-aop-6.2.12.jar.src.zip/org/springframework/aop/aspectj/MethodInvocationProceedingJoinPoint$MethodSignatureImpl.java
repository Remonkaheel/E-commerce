/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodSignatureImpl
/*     */   implements MethodSignature
/*     */ {
/*     */   @Nullable
/*     */   private volatile String[] parameterNames;
/*     */   
/*     */   public String getName() {
/* 188 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 193 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getModifiers();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaringType() {
/* 198 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getDeclaringClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDeclaringTypeName() {
/* 203 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getDeclaringClass().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getReturnType() {
/* 208 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getReturnType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/* 213 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getParameterTypes() {
/* 218 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getParameterTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getParameterNames() {
/* 224 */     String[] parameterNames = this.parameterNames;
/* 225 */     if (parameterNames == null) {
/* 226 */       parameterNames = MethodInvocationProceedingJoinPoint.parameterNameDiscoverer.getParameterNames(getMethod());
/* 227 */       this.parameterNames = parameterNames;
/*     */     } 
/* 229 */     return parameterNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getExceptionTypes() {
/* 234 */     return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getExceptionTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toShortString() {
/* 239 */     return toString(false, false, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toLongString() {
/* 244 */     return toString(true, true, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 249 */     return toString(false, true, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String toString(boolean includeModifier, boolean includeReturnTypeAndArgs, boolean useLongReturnAndArgumentTypeName, boolean useLongTypeName) {
/* 255 */     StringBuilder sb = new StringBuilder();
/* 256 */     if (includeModifier) {
/* 257 */       sb.append(Modifier.toString(getModifiers()));
/* 258 */       sb.append(' ');
/*     */     } 
/* 260 */     if (includeReturnTypeAndArgs) {
/* 261 */       appendType(sb, getReturnType(), useLongReturnAndArgumentTypeName);
/* 262 */       sb.append(' ');
/*     */     } 
/* 264 */     appendType(sb, getDeclaringType(), useLongTypeName);
/* 265 */     sb.append('.');
/* 266 */     sb.append(getMethod().getName());
/* 267 */     sb.append('(');
/* 268 */     Class<?>[] parametersTypes = getParameterTypes();
/* 269 */     appendTypes(sb, parametersTypes, includeReturnTypeAndArgs, useLongReturnAndArgumentTypeName);
/* 270 */     sb.append(')');
/* 271 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendTypes(StringBuilder sb, Class<?>[] types, boolean includeArgs, boolean useLongReturnAndArgumentTypeName) {
/* 277 */     if (includeArgs) {
/* 278 */       for (int size = types.length, i = 0; i < size; i++) {
/* 279 */         appendType(sb, types[i], useLongReturnAndArgumentTypeName);
/* 280 */         if (i < size - 1) {
/* 281 */           sb.append(',');
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 286 */     else if (types.length != 0) {
/* 287 */       sb.append("..");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void appendType(StringBuilder sb, Class<?> type, boolean useLongTypeName) {
/* 293 */     if (type.isArray()) {
/* 294 */       appendType(sb, type.componentType(), useLongTypeName);
/* 295 */       sb.append("[]");
/*     */     } else {
/*     */       
/* 298 */       sb.append(useLongTypeName ? type.getName() : type.getSimpleName());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\MethodInvocationProceedingJoinPoint$MethodSignatureImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */