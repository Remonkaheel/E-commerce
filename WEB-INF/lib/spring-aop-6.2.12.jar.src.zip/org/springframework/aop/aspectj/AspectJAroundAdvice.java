/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.aspectj.lang.JoinPoint;
/*    */ import org.aspectj.lang.ProceedingJoinPoint;
/*    */ import org.aspectj.weaver.tools.JoinPointMatch;
/*    */ import org.springframework.aop.ProxyMethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectJAroundAdvice
/*    */   extends AbstractAspectJAdvice
/*    */   implements MethodInterceptor, Serializable
/*    */ {
/*    */   public AspectJAroundAdvice(Method aspectJAroundAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif) {
/* 44 */     super(aspectJAroundAdviceMethod, pointcut, aif);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isBeforeAdvice() {
/* 50 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAfterAdvice() {
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean supportsProceedingJoinPoint() {
/* 60 */     return true;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation mi) throws Throwable {
/*    */     ProxyMethodInvocation pmi;
/* 66 */     if (mi instanceof ProxyMethodInvocation) { pmi = (ProxyMethodInvocation)mi; }
/* 67 */     else { throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(mi)); }
/*    */     
/* 69 */     ProceedingJoinPoint pjp = lazyGetProceedingJoinPoint(pmi);
/* 70 */     JoinPointMatch jpm = getJoinPointMatch(pmi);
/* 71 */     return invokeAdviceMethod((JoinPoint)pjp, jpm, null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ProceedingJoinPoint lazyGetProceedingJoinPoint(ProxyMethodInvocation rmi) {
/* 82 */     return new MethodInvocationProceedingJoinPoint(rmi);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AspectJAroundAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */