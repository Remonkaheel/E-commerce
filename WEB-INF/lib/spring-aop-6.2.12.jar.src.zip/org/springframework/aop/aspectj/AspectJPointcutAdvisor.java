/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.PointcutAdvisor;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectJPointcutAdvisor
/*    */   implements PointcutAdvisor, Ordered
/*    */ {
/*    */   private final AbstractAspectJAdvice advice;
/*    */   private final Pointcut pointcut;
/*    */   @Nullable
/*    */   private Integer order;
/*    */   
/*    */   public AspectJPointcutAdvisor(AbstractAspectJAdvice advice) {
/* 50 */     Assert.notNull(advice, "Advice must not be null");
/* 51 */     this.advice = advice;
/* 52 */     this.pointcut = advice.buildSafePointcut();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setOrder(int order) {
/* 57 */     this.order = Integer.valueOf(order);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 62 */     if (this.order != null) {
/* 63 */       return this.order.intValue();
/*    */     }
/*    */     
/* 66 */     return this.advice.getOrder();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Advice getAdvice() {
/* 72 */     return this.advice;
/*    */   }
/*    */ 
/*    */   
/*    */   public Pointcut getPointcut() {
/* 77 */     return this.pointcut;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAspectName() {
/* 86 */     return this.advice.getAspectName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 92 */     if (this != other) { if (other instanceof AspectJPointcutAdvisor) { AspectJPointcutAdvisor that = (AspectJPointcutAdvisor)other; if (this.advice
/* 93 */           .equals(that.advice)); }
/*    */       
/*    */       return false; }
/*    */   
/*    */   } public int hashCode() {
/* 98 */     return AspectJPointcutAdvisor.class.hashCode() * 29 + this.advice.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AspectJPointcutAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */