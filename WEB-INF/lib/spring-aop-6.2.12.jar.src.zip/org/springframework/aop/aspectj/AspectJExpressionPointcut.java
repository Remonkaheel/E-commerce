/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.util.FuzzyBoolean;
/*     */ import org.aspectj.weaver.patterns.NamePattern;
/*     */ import org.aspectj.weaver.reflect.ReflectionWorld;
/*     */ import org.aspectj.weaver.reflect.ShadowMatchImpl;
/*     */ import org.aspectj.weaver.tools.ContextBasedMatcher;
/*     */ import org.aspectj.weaver.tools.FuzzyBoolean;
/*     */ import org.aspectj.weaver.tools.JoinPointMatch;
/*     */ import org.aspectj.weaver.tools.MatchingContext;
/*     */ import org.aspectj.weaver.tools.PointcutDesignatorHandler;
/*     */ import org.aspectj.weaver.tools.PointcutExpression;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*     */ import org.aspectj.weaver.tools.ShadowMatch;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.framework.autoproxy.ProxyCreationContext;
/*     */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*     */ import org.springframework.aop.support.AbstractExpressionPointcut;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJExpressionPointcut
/*     */   extends AbstractExpressionPointcut
/*     */   implements ClassFilter, IntroductionAwareMethodMatcher, BeanFactoryAware
/*     */ {
/*     */   private static final String AJC_MAGIC = "ajc$";
/*  88 */   private static final Set<PointcutPrimitive> SUPPORTED_PRIMITIVES = Set.of(PointcutPrimitive.EXECUTION, PointcutPrimitive.ARGS, PointcutPrimitive.REFERENCE, PointcutPrimitive.THIS, PointcutPrimitive.TARGET, PointcutPrimitive.WITHIN, PointcutPrimitive.AT_ANNOTATION, PointcutPrimitive.AT_WITHIN, PointcutPrimitive.AT_ARGS, PointcutPrimitive.AT_TARGET);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static final Log logger = LogFactory.getLog(AspectJExpressionPointcut.class);
/*     */   
/*     */   @Nullable
/*     */   private Class<?> pointcutDeclarationScope;
/*     */   
/*     */   private boolean aspectCompiledByAjc;
/*     */   
/* 107 */   private String[] pointcutParameterNames = new String[0];
/*     */   
/* 109 */   private Class<?>[] pointcutParameterTypes = new Class[0];
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile transient ClassLoader pointcutClassLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile transient PointcutExpression pointcutExpression;
/*     */ 
/*     */   
/*     */   private volatile transient boolean pointcutParsingFailed;
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectJExpressionPointcut() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectJExpressionPointcut(Class<?> declarationScope, String[] paramNames, Class<?>[] paramTypes) {
/* 136 */     setPointcutDeclarationScope(declarationScope);
/* 137 */     if (paramNames.length != paramTypes.length) {
/* 138 */       throw new IllegalStateException("Number of pointcut parameter names must match number of pointcut parameter types");
/*     */     }
/*     */     
/* 141 */     this.pointcutParameterNames = paramNames;
/* 142 */     this.pointcutParameterTypes = paramTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPointcutDeclarationScope(Class<?> pointcutDeclarationScope) {
/* 150 */     this.pointcutDeclarationScope = pointcutDeclarationScope;
/* 151 */     this.aspectCompiledByAjc = compiledByAjc(pointcutDeclarationScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterNames(String... names) {
/* 158 */     this.pointcutParameterNames = names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterTypes(Class<?>... types) {
/* 165 */     this.pointcutParameterTypes = types;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 170 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFilter getClassFilter() {
/* 176 */     checkExpression();
/* 177 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodMatcher getMethodMatcher() {
/* 182 */     checkExpression();
/* 183 */     return (MethodMatcher)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkExpression() {
/* 191 */     if (getExpression() == null) {
/* 192 */       throw new IllegalStateException("Must set property 'expression' before attempting to match");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PointcutExpression obtainPointcutExpression() {
/* 200 */     PointcutExpression pointcutExpression = this.pointcutExpression;
/* 201 */     if (pointcutExpression == null) {
/* 202 */       ClassLoader pointcutClassLoader = determinePointcutClassLoader();
/* 203 */       pointcutExpression = buildPointcutExpression(pointcutClassLoader);
/* 204 */       this.pointcutClassLoader = pointcutClassLoader;
/* 205 */       this.pointcutExpression = pointcutExpression;
/*     */     } 
/* 207 */     return pointcutExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader determinePointcutClassLoader() {
/* 215 */     BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/* 216 */       return cbf.getBeanClassLoader(); }
/*     */     
/* 218 */     if (this.pointcutDeclarationScope != null) {
/* 219 */       return this.pointcutDeclarationScope.getClassLoader();
/*     */     }
/* 221 */     return ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PointcutExpression buildPointcutExpression(@Nullable ClassLoader classLoader) {
/* 228 */     PointcutParser parser = initializePointcutParser(classLoader);
/* 229 */     PointcutParameter[] pointcutParameters = new PointcutParameter[this.pointcutParameterNames.length];
/* 230 */     for (int i = 0; i < pointcutParameters.length; i++) {
/* 231 */       pointcutParameters[i] = parser.createPointcutParameter(this.pointcutParameterNames[i], this.pointcutParameterTypes[i]);
/*     */     }
/*     */     
/* 234 */     return parser.parsePointcutExpression(replaceBooleanOperators(resolveExpression()), this.pointcutDeclarationScope, pointcutParameters);
/*     */   }
/*     */ 
/*     */   
/*     */   private String resolveExpression() {
/* 239 */     String expression = getExpression();
/* 240 */     Assert.state((expression != null), "No expression set");
/* 241 */     return expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PointcutParser initializePointcutParser(@Nullable ClassLoader classLoader) {
/* 249 */     PointcutParser parser = PointcutParser.getPointcutParserSupportingSpecifiedPrimitivesAndUsingSpecifiedClassLoaderForResolution(SUPPORTED_PRIMITIVES, classLoader);
/*     */     
/* 251 */     parser.registerPointcutDesignatorHandler(new BeanPointcutDesignatorHandler());
/* 252 */     return parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String replaceBooleanOperators(String pcExpr) {
/* 263 */     String result = StringUtils.replace(pcExpr, " and ", " && ");
/* 264 */     result = StringUtils.replace(result, " or ", " || ");
/* 265 */     result = StringUtils.replace(result, " not ", " ! ");
/* 266 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointcutExpression getPointcutExpression() {
/* 274 */     return obtainPointcutExpression();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Class<?> targetClass) {
/* 279 */     if (this.pointcutParsingFailed)
/*     */     {
/* 281 */       return false;
/*     */     }
/* 283 */     if (this.aspectCompiledByAjc && compiledByAjc(targetClass))
/*     */     {
/* 285 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 290 */       return obtainPointcutExpression().couldMatchJoinPointsInType(targetClass);
/*     */     }
/* 292 */     catch (org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException ex) {
/* 293 */       logger.debug("PointcutExpression matching rejected target class - trying fallback expression", (Throwable)ex);
/*     */       
/* 295 */       PointcutExpression fallbackExpression = getFallbackPointcutExpression(targetClass);
/* 296 */       if (fallbackExpression != null) {
/* 297 */         return fallbackExpression.couldMatchJoinPointsInType(targetClass);
/*     */       
/*     */       }
/*     */     }
/* 301 */     catch (IllegalArgumentException|IllegalStateException|org.aspectj.weaver.tools.UnsupportedPointcutPrimitiveException ex) {
/* 302 */       this.pointcutParsingFailed = true;
/* 303 */       if (logger.isDebugEnabled()) {
/* 304 */         logger.debug("Pointcut parser rejected expression [" + getExpression() + "]: " + String.valueOf(ex));
/*     */       }
/*     */     }
/* 307 */     catch (Throwable ex) {
/* 308 */       logger.debug("PointcutExpression matching rejected target class", ex);
/*     */     } 
/* 310 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions) {
/* 315 */     ShadowMatch shadowMatch = getTargetShadowMatch(method, targetClass);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     if (shadowMatch.alwaysMatches()) {
/* 321 */       return true;
/*     */     }
/* 323 */     if (shadowMatch.neverMatches()) {
/* 324 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 328 */     if (hasIntroductions) {
/* 329 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     RuntimeTestWalker walker = getRuntimeTestWalker(shadowMatch);
/* 336 */     return (!walker.testsSubtypeSensitiveVars() || walker.testTargetInstanceOfResidue(targetClass));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass) {
/* 342 */     return matches(method, targetClass, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRuntime() {
/* 347 */     return obtainPointcutExpression().mayNeedDynamicTest();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 352 */     ShadowMatch shadowMatch = getTargetShadowMatch(method, targetClass);
/*     */ 
/*     */ 
/*     */     
/* 356 */     ProxyMethodInvocation pmi = null;
/* 357 */     Object targetObject = null;
/* 358 */     Object thisObject = null;
/*     */     try {
/* 360 */       MethodInvocation curr = ExposeInvocationInterceptor.currentInvocation();
/* 361 */       if (curr.getMethod() == method) {
/* 362 */         ProxyMethodInvocation currPmi; targetObject = curr.getThis();
/* 363 */         if (curr instanceof ProxyMethodInvocation) { currPmi = (ProxyMethodInvocation)curr; }
/* 364 */         else { throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(curr)); }
/*     */         
/* 366 */         pmi = currPmi;
/* 367 */         thisObject = pmi.getProxy();
/*     */       }
/*     */     
/* 370 */     } catch (IllegalStateException ex) {
/*     */       
/* 372 */       if (logger.isDebugEnabled()) {
/* 373 */         logger.debug("Could not access current invocation - matching with limited context: " + String.valueOf(ex));
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 378 */       JoinPointMatch joinPointMatch = shadowMatch.matchesJoinPoint(thisObject, targetObject, args);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 388 */       if (pmi != null && thisObject != null) {
/* 389 */         RuntimeTestWalker originalMethodResidueTest = getRuntimeTestWalker(getShadowMatch(method, method));
/* 390 */         if (!originalMethodResidueTest.testThisInstanceOfResidue(thisObject.getClass())) {
/* 391 */           return false;
/*     */         }
/* 393 */         if (joinPointMatch.matches()) {
/* 394 */           bindParameters(pmi, joinPointMatch);
/*     */         }
/*     */       } 
/*     */       
/* 398 */       return joinPointMatch.matches();
/*     */     }
/* 400 */     catch (Throwable ex) {
/* 401 */       if (logger.isDebugEnabled()) {
/* 402 */         logger.debug("Failed to evaluate join point for arguments " + Arrays.toString(args) + " - falling back to non-match", ex);
/*     */       }
/*     */       
/* 405 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected String getCurrentProxiedBeanName() {
/* 411 */     return ProxyCreationContext.getCurrentProxiedBeanName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PointcutExpression getFallbackPointcutExpression(Class<?> targetClass) {
/*     */     try {
/* 421 */       ClassLoader classLoader = targetClass.getClassLoader();
/* 422 */       if (classLoader != null && classLoader != this.pointcutClassLoader) {
/* 423 */         return buildPointcutExpression(classLoader);
/*     */       }
/*     */     }
/* 426 */     catch (Throwable ex) {
/* 427 */       logger.debug("Failed to create fallback PointcutExpression", ex);
/*     */     } 
/* 429 */     return null;
/*     */   }
/*     */   
/*     */   private RuntimeTestWalker getRuntimeTestWalker(ShadowMatch shadowMatch) {
/* 433 */     if (shadowMatch instanceof DefensiveShadowMatch) { DefensiveShadowMatch defensiveShadowMatch = (DefensiveShadowMatch)shadowMatch;
/* 434 */       return new RuntimeTestWalker(defensiveShadowMatch.primary); }
/*     */     
/* 436 */     return new RuntimeTestWalker(shadowMatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void bindParameters(ProxyMethodInvocation invocation, JoinPointMatch jpm) {
/* 446 */     invocation.setUserAttribute(resolveExpression(), jpm);
/*     */   }
/*     */   
/*     */   private ShadowMatch getTargetShadowMatch(Method method, Class<?> targetClass) {
/* 450 */     Method targetMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/* 451 */     if (targetMethod.getDeclaringClass().isInterface() && targetMethod.getDeclaringClass() != targetClass && 
/* 452 */       obtainPointcutExpression().getPointcutExpression().contains("." + targetMethod.getName() + "(")) {
/*     */ 
/*     */ 
/*     */       
/* 456 */       Set<Class<?>> ifcs = ClassUtils.getAllInterfacesForClassAsSet(targetClass);
/* 457 */       if (ifcs.size() > 1) {
/*     */         try {
/* 459 */           Class<?> compositeInterface = ClassUtils.createCompositeInterface(
/* 460 */               ClassUtils.toClassArray(ifcs), targetClass.getClassLoader());
/* 461 */           targetMethod = ClassUtils.getMostSpecificMethod(targetMethod, compositeInterface);
/*     */         }
/* 463 */         catch (IllegalArgumentException illegalArgumentException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 469 */     return getShadowMatch(targetMethod, method);
/*     */   }
/*     */   
/*     */   private ShadowMatch getShadowMatch(Method targetMethod, Method originalMethod) {
/* 473 */     ShadowMatchKey key = new ShadowMatchKey(this, targetMethod);
/* 474 */     ShadowMatch shadowMatch = ShadowMatchUtils.getShadowMatch(key);
/* 475 */     if (shadowMatch == null) {
/* 476 */       PointcutExpression pointcutExpression = obtainPointcutExpression();
/* 477 */       synchronized (pointcutExpression) {
/* 478 */         ShadowMatchImpl shadowMatchImpl; DefensiveShadowMatch defensiveShadowMatch; shadowMatch = ShadowMatchUtils.getShadowMatch(key);
/* 479 */         if (shadowMatch != null) {
/* 480 */           return shadowMatch;
/*     */         }
/* 482 */         PointcutExpression fallbackExpression = null;
/* 483 */         Method methodToMatch = targetMethod;
/*     */         try {
/*     */           try {
/* 486 */             shadowMatch = pointcutExpression.matchesMethodExecution(methodToMatch);
/*     */           }
/* 488 */           catch (org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException ex) {
/*     */ 
/*     */             
/*     */             try {
/* 492 */               fallbackExpression = getFallbackPointcutExpression(methodToMatch.getDeclaringClass());
/* 493 */               if (fallbackExpression != null) {
/* 494 */                 shadowMatch = fallbackExpression.matchesMethodExecution(methodToMatch);
/*     */               }
/*     */             }
/* 497 */             catch (org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException ex2) {
/* 498 */               fallbackExpression = null;
/*     */             } 
/*     */           } 
/* 501 */           if (targetMethod != originalMethod && (shadowMatch == null || (
/* 502 */             Proxy.isProxyClass(targetMethod.getDeclaringClass()) && (shadowMatch
/* 503 */             .neverMatches() || containsAnnotationPointcut())))) {
/*     */ 
/*     */ 
/*     */             
/* 507 */             methodToMatch = originalMethod;
/*     */             try {
/* 509 */               shadowMatch = pointcutExpression.matchesMethodExecution(methodToMatch);
/*     */             }
/* 511 */             catch (org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException ex) {
/*     */ 
/*     */               
/*     */               try {
/* 515 */                 fallbackExpression = getFallbackPointcutExpression(methodToMatch.getDeclaringClass());
/* 516 */                 if (fallbackExpression != null) {
/* 517 */                   shadowMatch = fallbackExpression.matchesMethodExecution(methodToMatch);
/*     */                 }
/*     */               }
/* 520 */               catch (org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException ex2) {
/* 521 */                 fallbackExpression = null;
/*     */               }
/*     */             
/*     */             } 
/*     */           } 
/* 526 */         } catch (Throwable ex) {
/*     */           
/* 528 */           logger.debug("PointcutExpression matching rejected target method", ex);
/* 529 */           fallbackExpression = null;
/*     */         } 
/* 531 */         if (shadowMatch == null) {
/* 532 */           shadowMatchImpl = new ShadowMatchImpl(FuzzyBoolean.NO, null, null, null);
/*     */         }
/* 534 */         else if (shadowMatchImpl.maybeMatches() && fallbackExpression != null) {
/*     */           
/* 536 */           defensiveShadowMatch = new DefensiveShadowMatch((ShadowMatch)shadowMatchImpl, fallbackExpression.matchesMethodExecution(methodToMatch));
/*     */         } 
/* 538 */         shadowMatch = ShadowMatchUtils.setShadowMatch(key, defensiveShadowMatch);
/*     */       } 
/*     */     } 
/* 541 */     return shadowMatch;
/*     */   }
/*     */   
/*     */   private boolean containsAnnotationPointcut() {
/* 545 */     return resolveExpression().contains("@annotation");
/*     */   }
/*     */   
/*     */   private static boolean compiledByAjc(Class<?> clazz) {
/* 549 */     for (Field field : clazz.getDeclaredFields()) {
/* 550 */       if (field.getName().startsWith("ajc$")) {
/* 551 */         return true;
/*     */       }
/*     */     } 
/* 554 */     Class<?> superclass = clazz.getSuperclass();
/* 555 */     return (superclass != null && compiledByAjc(superclass));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 561 */     if (this != other) { if (other instanceof AspectJExpressionPointcut) { AspectJExpressionPointcut that = (AspectJExpressionPointcut)other;
/* 562 */         if (ObjectUtils.nullSafeEquals(getExpression(), that.getExpression()) && 
/* 563 */           ObjectUtils.nullSafeEquals(this.pointcutDeclarationScope, that.pointcutDeclarationScope) && 
/* 564 */           ObjectUtils.nullSafeEquals(this.pointcutParameterNames, that.pointcutParameterNames) && 
/* 565 */           ObjectUtils.nullSafeEquals(this.pointcutParameterTypes, that.pointcutParameterTypes)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 570 */     return ObjectUtils.nullSafeHash(new Object[] { getExpression(), this.pointcutDeclarationScope, this.pointcutParameterNames, this.pointcutParameterTypes });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 576 */     StringBuilder sb = new StringBuilder("AspectJExpressionPointcut: (");
/* 577 */     for (int i = 0; i < this.pointcutParameterTypes.length; i++) {
/* 578 */       sb.append(this.pointcutParameterTypes[i].getName());
/* 579 */       sb.append(' ');
/* 580 */       sb.append(this.pointcutParameterNames[i]);
/* 581 */       if (i + 1 < this.pointcutParameterTypes.length) {
/* 582 */         sb.append(", ");
/*     */       }
/*     */     } 
/* 585 */     sb.append(") ");
/* 586 */     if (getExpression() != null) {
/* 587 */       sb.append(getExpression());
/*     */     } else {
/*     */       
/* 590 */       sb.append("<pointcut expression not set>");
/*     */     } 
/* 592 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class BeanPointcutDesignatorHandler
/*     */     implements PointcutDesignatorHandler
/*     */   {
/*     */     private static final String BEAN_DESIGNATOR_NAME = "bean";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDesignatorName() {
/* 610 */       return "bean";
/*     */     }
/*     */ 
/*     */     
/*     */     public ContextBasedMatcher parse(String expression) {
/* 615 */       return new AspectJExpressionPointcut.BeanContextMatcher(expression);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class BeanContextMatcher
/*     */     implements ContextBasedMatcher
/*     */   {
/*     */     private final NamePattern expressionPattern;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BeanContextMatcher(String expression) {
/* 632 */       this.expressionPattern = new NamePattern(expression);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public boolean couldMatchJoinPointsInType(Class<?> someClass) {
/* 639 */       return (contextMatch(someClass) == FuzzyBoolean.YES);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public boolean couldMatchJoinPointsInType(Class<?> someClass, MatchingContext context) {
/* 646 */       return (contextMatch(someClass) == FuzzyBoolean.YES);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matchesDynamically(MatchingContext context) {
/* 651 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public FuzzyBoolean matchesStatically(MatchingContext context) {
/* 656 */       return contextMatch(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean mayNeedDynamicTest() {
/* 661 */       return false;
/*     */     }
/*     */     
/*     */     private FuzzyBoolean contextMatch(@Nullable Class<?> targetType) {
/* 665 */       String advisedBeanName = AspectJExpressionPointcut.this.getCurrentProxiedBeanName();
/* 666 */       if (advisedBeanName == null)
/*     */       {
/* 668 */         return FuzzyBoolean.MAYBE;
/*     */       }
/* 670 */       if (BeanFactoryUtils.isGeneratedBeanName(advisedBeanName)) {
/* 671 */         return FuzzyBoolean.NO;
/*     */       }
/* 673 */       if (targetType != null) {
/* 674 */         boolean isFactory = FactoryBean.class.isAssignableFrom(targetType);
/* 675 */         return FuzzyBoolean.fromBoolean(
/* 676 */             matchesBean(isFactory ? ("&" + advisedBeanName) : advisedBeanName));
/*     */       } 
/*     */       
/* 679 */       return FuzzyBoolean.fromBoolean((matchesBean(advisedBeanName) || 
/* 680 */           matchesBean("&" + advisedBeanName)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean matchesBean(String advisedBeanName) {
/* 686 */       Objects.requireNonNull(this.expressionPattern); return BeanFactoryAnnotationUtils.isQualifierMatch(this.expressionPattern::matches, advisedBeanName, AspectJExpressionPointcut.this.beanFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefensiveShadowMatch
/*     */     implements ShadowMatch
/*     */   {
/*     */     private final ShadowMatch primary;
/*     */     private final ShadowMatch other;
/*     */     
/*     */     public DefensiveShadowMatch(ShadowMatch primary, ShadowMatch other) {
/* 698 */       this.primary = primary;
/* 699 */       this.other = other;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean alwaysMatches() {
/* 704 */       return this.primary.alwaysMatches();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean maybeMatches() {
/* 709 */       return this.primary.maybeMatches();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean neverMatches() {
/* 714 */       return this.primary.neverMatches();
/*     */     }
/*     */ 
/*     */     
/*     */     public JoinPointMatch matchesJoinPoint(Object thisObject, Object targetObject, Object[] args) {
/*     */       try {
/* 720 */         return this.primary.matchesJoinPoint(thisObject, targetObject, args);
/*     */       }
/* 722 */       catch (org.aspectj.weaver.reflect.ReflectionWorld.ReflectionWorldException ex) {
/* 723 */         return this.other.matchesJoinPoint(thisObject, targetObject, args);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void setMatchingContext(MatchingContext aMatchContext) {
/* 729 */       this.primary.setMatchingContext(aMatchContext);
/* 730 */       this.other.setMatchingContext(aMatchContext);
/*     */     } }
/*     */   private static final class ShadowMatchKey extends Record { private final AspectJExpressionPointcut expression;
/*     */     private final Method method;
/*     */     
/* 735 */     private ShadowMatchKey(AspectJExpressionPointcut expression, Method method) { this.expression = expression; this.method = method; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/aop/aspectj/AspectJExpressionPointcut$ShadowMatchKey;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #735	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 735 */       //   0	7	0	this	Lorg/springframework/aop/aspectj/AspectJExpressionPointcut$ShadowMatchKey; } public AspectJExpressionPointcut expression() { return this.expression; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/aop/aspectj/AspectJExpressionPointcut$ShadowMatchKey;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #735	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aop/aspectj/AspectJExpressionPointcut$ShadowMatchKey; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/aop/aspectj/AspectJExpressionPointcut$ShadowMatchKey;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #735	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/aop/aspectj/AspectJExpressionPointcut$ShadowMatchKey;
/* 735 */       //   0	8	1	o	Ljava/lang/Object; } public Method method() { return this.method; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AspectJExpressionPointcut.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */