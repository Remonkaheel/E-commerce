/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.PointcutAdvisor;
/*    */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AspectJProxyUtils
/*    */ {
/*    */   public static boolean makeAdvisorChainAspectJCapableIfNecessary(List<Advisor> advisors) {
/* 49 */     if (!advisors.isEmpty()) {
/* 50 */       boolean foundAspectJAdvice = false;
/* 51 */       for (Advisor advisor : advisors) {
/*    */ 
/*    */         
/* 54 */         if (isAspectJAdvice(advisor)) {
/* 55 */           foundAspectJAdvice = true;
/*    */           break;
/*    */         } 
/*    */       } 
/* 59 */       if (foundAspectJAdvice && !advisors.contains(ExposeInvocationInterceptor.ADVISOR)) {
/* 60 */         advisors.add(0, ExposeInvocationInterceptor.ADVISOR);
/* 61 */         return true;
/*    */       } 
/*    */     } 
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isAspectJAdvice(Advisor advisor) {
/* 73 */     if (!(advisor instanceof InstantiationModelAwarePointcutAdvisor) && !(advisor.getAdvice() instanceof AbstractAspectJAdvice)) { if (advisor instanceof PointcutAdvisor) {
/* 74 */         PointcutAdvisor pointcutAdvisor = (PointcutAdvisor)advisor; if (pointcutAdvisor
/* 75 */           .getPointcut() instanceof AspectJExpressionPointcut);
/*    */       } 
/*    */       return false; }
/*    */      } static boolean isVariableName(@Nullable String name) {
/* 79 */     if (!StringUtils.hasLength(name)) {
/* 80 */       return false;
/*    */     }
/* 82 */     if (!Character.isJavaIdentifierStart(name.charAt(0))) {
/* 83 */       return false;
/*    */     }
/* 85 */     for (int i = 1; i < name.length(); i++) {
/* 86 */       if (!Character.isJavaIdentifierPart(name.charAt(i))) {
/* 87 */         return false;
/*    */       }
/*    */     } 
/* 90 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AspectJProxyUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */