/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.TypePatternMatcher;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePatternClassFilter
/*     */   implements ClassFilter
/*     */ {
/*  40 */   private String typePattern = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypePatternMatcher aspectJTypePatternMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePatternClassFilter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePatternClassFilter(String typePattern) {
/*  62 */     setTypePattern(typePattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypePattern(String typePattern) {
/*  82 */     Assert.notNull(typePattern, "Type pattern must not be null");
/*  83 */     this.typePattern = typePattern;
/*  84 */     this
/*     */       
/*  86 */       .aspectJTypePatternMatcher = PointcutParser.getPointcutParserSupportingAllPrimitivesAndUsingContextClassloaderForResolution().parseTypePattern(replaceBooleanOperators(typePattern));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypePattern() {
/*  93 */     return this.typePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Class<?> clazz) {
/* 105 */     Assert.state((this.aspectJTypePatternMatcher != null), "No type pattern has been set");
/* 106 */     return this.aspectJTypePatternMatcher.matches(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String replaceBooleanOperators(String pcExpr) {
/* 116 */     String result = StringUtils.replace(pcExpr, " and ", " && ");
/* 117 */     result = StringUtils.replace(result, " or ", " || ");
/* 118 */     return StringUtils.replace(result, " not ", " ! ");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 123 */     if (this != other) { if (other instanceof TypePatternClassFilter) { TypePatternClassFilter that = (TypePatternClassFilter)other;
/* 124 */         if (ObjectUtils.nullSafeEquals(this.typePattern, that.typePattern)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 129 */     return Objects.hashCode(this.typePattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return getClass().getName() + ": " + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\TypePatternClassFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */