package org.springframework.aop.aspectj;

import org.springframework.core.Ordered;

public interface AspectJPrecedenceInformation extends Ordered {
  String getAspectName();
  
  int getDeclarationOrder();
  
  boolean isBeforeAdvice();
  
  boolean isAfterAdvice();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AspectJPrecedenceInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */