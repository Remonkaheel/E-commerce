package org.springframework.aop.aspectj;

import org.springframework.aop.PointcutAdvisor;

public interface InstantiationModelAwarePointcutAdvisor extends PointcutAdvisor {
  boolean isLazy();
  
  boolean isAdviceInstantiated();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\InstantiationModelAwarePointcutAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */