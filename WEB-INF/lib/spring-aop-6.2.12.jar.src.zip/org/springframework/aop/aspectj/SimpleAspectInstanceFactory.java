/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleAspectInstanceFactory
/*     */   implements AspectInstanceFactory
/*     */ {
/*     */   private final Class<?> aspectClass;
/*     */   
/*     */   public SimpleAspectInstanceFactory(Class<?> aspectClass) {
/*  45 */     Assert.notNull(aspectClass, "Aspect class must not be null");
/*  46 */     this.aspectClass = aspectClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class<?> getAspectClass() {
/*  54 */     return this.aspectClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object getAspectInstance() {
/*     */     try {
/*  60 */       return ReflectionUtils.accessibleConstructor(this.aspectClass, new Class[0]).newInstance(new Object[0]);
/*     */     }
/*  62 */     catch (NoSuchMethodException ex) {
/*  63 */       throw new AopConfigException("No default constructor on aspect class: " + this.aspectClass
/*  64 */           .getName(), ex);
/*     */     }
/*  66 */     catch (InstantiationException ex) {
/*  67 */       throw new AopConfigException("Unable to instantiate aspect class: " + this.aspectClass
/*  68 */           .getName(), ex);
/*     */     }
/*  70 */     catch (IllegalAccessException|java.lang.reflect.InaccessibleObjectException ex) {
/*  71 */       throw new AopConfigException("Could not access aspect constructor: " + this.aspectClass
/*  72 */           .getName(), ex);
/*     */     }
/*  74 */     catch (InvocationTargetException ex) {
/*  75 */       throw new AopConfigException("Failed to invoke aspect constructor: " + this.aspectClass
/*  76 */           .getName(), ex.getTargetException());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getAspectClassLoader() {
/*  83 */     return this.aspectClass.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  96 */     return getOrderForAspectClass(this.aspectClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getOrderForAspectClass(Class<?> aspectClass) {
/* 107 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\SimpleAspectInstanceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */