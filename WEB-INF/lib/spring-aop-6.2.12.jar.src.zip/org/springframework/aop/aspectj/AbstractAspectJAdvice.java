/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.weaver.tools.JoinPointMatch;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ import org.springframework.aop.support.MethodMatchers;
/*     */ import org.springframework.aop.support.StaticMethodMatcher;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAspectJAdvice
/*     */   implements Advice, AspectJPrecedenceInformation, Serializable
/*     */ {
/*  68 */   protected static final String JOIN_POINT_KEY = JoinPoint.class.getName();
/*     */   
/*     */   private final Class<?> declaringClass;
/*     */   private final String methodName;
/*     */   private final Class<?>[] parameterTypes;
/*     */   protected transient Method aspectJAdviceMethod;
/*     */   private final AspectJExpressionPointcut pointcut;
/*     */   private final AspectInstanceFactory aspectInstanceFactory;
/*     */   
/*     */   public static JoinPoint currentJoinPoint() {
/*     */     ProxyMethodInvocation pmi;
/*     */     MethodInvocationProceedingJoinPoint methodInvocationProceedingJoinPoint;
/*  80 */     MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/*  81 */     if (mi instanceof ProxyMethodInvocation) { pmi = (ProxyMethodInvocation)mi; }
/*  82 */     else { throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(mi)); }
/*     */     
/*  84 */     JoinPoint jp = (JoinPoint)pmi.getUserAttribute(JOIN_POINT_KEY);
/*  85 */     if (jp == null) {
/*  86 */       methodInvocationProceedingJoinPoint = new MethodInvocationProceedingJoinPoint(pmi);
/*  87 */       pmi.setUserAttribute(JOIN_POINT_KEY, methodInvocationProceedingJoinPoint);
/*     */     } 
/*  89 */     return (JoinPoint)methodInvocationProceedingJoinPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private String aspectName = "";
/*     */ 
/*     */ 
/*     */   
/*     */   private int declarationOrder;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String[] argumentNames;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String throwingName;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String returningName;
/*     */ 
/*     */   
/* 132 */   private Class<?> discoveredReturningType = Object.class;
/*     */   
/* 134 */   private Class<?> discoveredThrowingType = Object.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private int joinPointArgumentIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private int joinPointStaticPartArgumentIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Map<String, Integer> argumentBindings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean argumentsIntrospected = false;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Type discoveredReturningGenericType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractAspectJAdvice(Method aspectJAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aspectInstanceFactory) {
/* 168 */     Assert.notNull(aspectJAdviceMethod, "Advice method must not be null");
/* 169 */     this.declaringClass = aspectJAdviceMethod.getDeclaringClass();
/* 170 */     this.methodName = aspectJAdviceMethod.getName();
/* 171 */     this.parameterTypes = aspectJAdviceMethod.getParameterTypes();
/* 172 */     this.aspectJAdviceMethod = aspectJAdviceMethod;
/* 173 */     this.pointcut = pointcut;
/* 174 */     this.aspectInstanceFactory = aspectInstanceFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Method getAspectJAdviceMethod() {
/* 182 */     return this.aspectJAdviceMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AspectJExpressionPointcut getPointcut() {
/* 189 */     calculateArgumentBindings();
/* 190 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Pointcut buildSafePointcut() {
/* 199 */     AspectJExpressionPointcut aspectJExpressionPointcut = getPointcut();
/* 200 */     MethodMatcher safeMethodMatcher = MethodMatchers.intersection((MethodMatcher)new AdviceExcludingMethodMatcher(this.aspectJAdviceMethod), aspectJExpressionPointcut
/* 201 */         .getMethodMatcher());
/* 202 */     return (Pointcut)new ComposablePointcut(aspectJExpressionPointcut.getClassFilter(), safeMethodMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AspectInstanceFactory getAspectInstanceFactory() {
/* 209 */     return this.aspectInstanceFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final ClassLoader getAspectClassLoader() {
/* 217 */     return this.aspectInstanceFactory.getAspectClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 222 */     return this.aspectInstanceFactory.getOrder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAspectName(String name) {
/* 230 */     this.aspectName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAspectName() {
/* 235 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeclarationOrder(int order) {
/* 242 */     this.declarationOrder = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDeclarationOrder() {
/* 247 */     return this.declarationOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArgumentNames(String argumentNames) {
/* 257 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(argumentNames);
/* 258 */     setArgumentNamesFromStringArray(tokens);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArgumentNamesFromStringArray(String... argumentNames) {
/* 268 */     this.argumentNames = new String[argumentNames.length]; int i;
/* 269 */     for (i = 0; i < argumentNames.length; i++) {
/* 270 */       this.argumentNames[i] = argumentNames[i].strip();
/* 271 */       if (!isVariableName(this.argumentNames[i])) {
/* 272 */         throw new IllegalArgumentException("'argumentNames' property of AbstractAspectJAdvice contains an argument name '" + this.argumentNames[i] + "' that is not a valid Java identifier");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 277 */     if (this.aspectJAdviceMethod.getParameterCount() == this.argumentNames.length + 1)
/*     */     {
/* 279 */       for (i = 0; i < this.aspectJAdviceMethod.getParameterCount(); i++) {
/* 280 */         Class<?> argType = this.aspectJAdviceMethod.getParameterTypes()[i];
/* 281 */         if (argType == JoinPoint.class || argType == ProceedingJoinPoint.class || argType == JoinPoint.StaticPart.class) {
/*     */ 
/*     */           
/* 284 */           String[] oldNames = this.argumentNames;
/* 285 */           this.argumentNames = new String[oldNames.length + 1];
/* 286 */           System.arraycopy(oldNames, 0, this.argumentNames, 0, i);
/* 287 */           this.argumentNames[i] = "THIS_JOIN_POINT";
/* 288 */           System.arraycopy(oldNames, i, this.argumentNames, i + 1, oldNames.length - i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void setReturningName(String name) {
/* 296 */     throw new UnsupportedOperationException("Only afterReturning advice can be used to bind a return value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setReturningNameNoCheck(String name) {
/* 305 */     if (isVariableName(name)) {
/* 306 */       this.returningName = name;
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 311 */         this.discoveredReturningType = ClassUtils.forName(name, getAspectClassLoader());
/*     */       }
/* 313 */       catch (Throwable ex) {
/* 314 */         throw new IllegalArgumentException("Returning name '" + name + "' is neither a valid argument name nor the fully-qualified name of a Java type on the classpath. Root cause: " + String.valueOf(ex));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getDiscoveredReturningType() {
/* 322 */     return this.discoveredReturningType;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Type getDiscoveredReturningGenericType() {
/* 327 */     return this.discoveredReturningGenericType;
/*     */   }
/*     */   
/*     */   public void setThrowingName(String name) {
/* 331 */     throw new UnsupportedOperationException("Only afterThrowing advice can be used to bind a thrown exception");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setThrowingNameNoCheck(String name) {
/* 340 */     if (isVariableName(name)) {
/* 341 */       this.throwingName = name;
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 346 */         this.discoveredThrowingType = ClassUtils.forName(name, getAspectClassLoader());
/*     */       }
/* 348 */       catch (Throwable ex) {
/* 349 */         throw new IllegalArgumentException("Throwing name '" + name + "' is neither a valid argument name nor the fully-qualified name of a Java type on the classpath. Root cause: " + String.valueOf(ex));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getDiscoveredThrowingType() {
/* 357 */     return this.discoveredThrowingType;
/*     */   }
/*     */   
/*     */   private static boolean isVariableName(String name) {
/* 361 */     return AspectJProxyUtils.isVariableName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void calculateArgumentBindings() {
/* 380 */     if (this.argumentsIntrospected || this.parameterTypes.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 384 */     int numUnboundArgs = this.parameterTypes.length;
/* 385 */     Class<?>[] parameterTypes = this.aspectJAdviceMethod.getParameterTypes();
/* 386 */     if (maybeBindJoinPoint(parameterTypes[0]) || maybeBindProceedingJoinPoint(parameterTypes[0]) || 
/* 387 */       maybeBindJoinPointStaticPart(parameterTypes[0])) {
/* 388 */       numUnboundArgs--;
/*     */     }
/*     */     
/* 391 */     if (numUnboundArgs > 0)
/*     */     {
/* 393 */       bindArgumentsByName(numUnboundArgs);
/*     */     }
/*     */     
/* 396 */     this.argumentsIntrospected = true;
/*     */   }
/*     */   
/*     */   private boolean maybeBindJoinPoint(Class<?> candidateParameterType) {
/* 400 */     if (JoinPoint.class == candidateParameterType) {
/* 401 */       this.joinPointArgumentIndex = 0;
/* 402 */       return true;
/*     */     } 
/*     */     
/* 405 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean maybeBindProceedingJoinPoint(Class<?> candidateParameterType) {
/* 410 */     if (ProceedingJoinPoint.class == candidateParameterType) {
/* 411 */       if (!supportsProceedingJoinPoint()) {
/* 412 */         throw new IllegalArgumentException("ProceedingJoinPoint is only supported for around advice");
/*     */       }
/* 414 */       this.joinPointArgumentIndex = 0;
/* 415 */       return true;
/*     */     } 
/*     */     
/* 418 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supportsProceedingJoinPoint() {
/* 423 */     return false;
/*     */   }
/*     */   
/*     */   private boolean maybeBindJoinPointStaticPart(Class<?> candidateParameterType) {
/* 427 */     if (JoinPoint.StaticPart.class == candidateParameterType) {
/* 428 */       this.joinPointStaticPartArgumentIndex = 0;
/* 429 */       return true;
/*     */     } 
/*     */     
/* 432 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void bindArgumentsByName(int numArgumentsExpectingToBind) {
/* 437 */     if (this.argumentNames == null) {
/* 438 */       this.argumentNames = createParameterNameDiscoverer().getParameterNames(this.aspectJAdviceMethod);
/*     */     }
/* 440 */     if (this.argumentNames != null) {
/*     */       
/* 442 */       bindExplicitArguments(numArgumentsExpectingToBind);
/*     */     } else {
/*     */       
/* 445 */       throw new IllegalStateException("Advice method [" + this.aspectJAdviceMethod.getName() + "] requires " + numArgumentsExpectingToBind + " arguments to be bound by name, but the argument names were not specified and could not be discovered.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParameterNameDiscoverer createParameterNameDiscoverer() {
/* 459 */     DefaultParameterNameDiscoverer discoverer = new DefaultParameterNameDiscoverer();
/*     */     
/* 461 */     AspectJAdviceParameterNameDiscoverer adviceParameterNameDiscoverer = new AspectJAdviceParameterNameDiscoverer(this.pointcut.getExpression());
/* 462 */     adviceParameterNameDiscoverer.setReturningName(this.returningName);
/* 463 */     adviceParameterNameDiscoverer.setThrowingName(this.throwingName);
/*     */     
/* 465 */     adviceParameterNameDiscoverer.setRaiseExceptions(true);
/* 466 */     discoverer.addDiscoverer(adviceParameterNameDiscoverer);
/* 467 */     return (ParameterNameDiscoverer)discoverer;
/*     */   }
/*     */   
/*     */   private void bindExplicitArguments(int numArgumentsLeftToBind) {
/* 471 */     Assert.state((this.argumentNames != null), "No argument names available");
/* 472 */     this.argumentBindings = new HashMap<>();
/*     */     
/* 474 */     int numExpectedArgumentNames = this.aspectJAdviceMethod.getParameterCount();
/* 475 */     if (this.argumentNames.length != numExpectedArgumentNames) {
/* 476 */       throw new IllegalStateException("Expecting to find " + numExpectedArgumentNames + " arguments to bind by name in advice, but actually found " + this.argumentNames.length + " arguments.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 482 */     int argumentIndexOffset = this.parameterTypes.length - numArgumentsLeftToBind;
/* 483 */     for (int i = argumentIndexOffset; i < this.argumentNames.length; i++) {
/* 484 */       this.argumentBindings.put(this.argumentNames[i], Integer.valueOf(i));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 489 */     if (this.returningName != null) {
/* 490 */       if (!this.argumentBindings.containsKey(this.returningName)) {
/* 491 */         throw new IllegalStateException("Returning argument name '" + this.returningName + "' was not bound in advice arguments");
/*     */       }
/*     */ 
/*     */       
/* 495 */       Integer index = this.argumentBindings.get(this.returningName);
/* 496 */       this.discoveredReturningType = this.aspectJAdviceMethod.getParameterTypes()[index.intValue()];
/* 497 */       this.discoveredReturningGenericType = this.aspectJAdviceMethod.getGenericParameterTypes()[index.intValue()];
/*     */     } 
/*     */     
/* 500 */     if (this.throwingName != null) {
/* 501 */       if (!this.argumentBindings.containsKey(this.throwingName)) {
/* 502 */         throw new IllegalStateException("Throwing argument name '" + this.throwingName + "' was not bound in advice arguments");
/*     */       }
/*     */ 
/*     */       
/* 506 */       Integer index = this.argumentBindings.get(this.throwingName);
/* 507 */       this.discoveredThrowingType = this.aspectJAdviceMethod.getParameterTypes()[index.intValue()];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 512 */     configurePointcutParameters(this.argumentNames, argumentIndexOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configurePointcutParameters(String[] argumentNames, int argumentIndexOffset) {
/* 521 */     int numParametersToRemove = argumentIndexOffset;
/* 522 */     if (this.returningName != null) {
/* 523 */       numParametersToRemove++;
/*     */     }
/* 525 */     if (this.throwingName != null) {
/* 526 */       numParametersToRemove++;
/*     */     }
/* 528 */     String[] pointcutParameterNames = new String[argumentNames.length - numParametersToRemove];
/* 529 */     Class<?>[] pointcutParameterTypes = new Class[pointcutParameterNames.length];
/* 530 */     Class<?>[] methodParameterTypes = this.aspectJAdviceMethod.getParameterTypes();
/*     */     
/* 532 */     int index = 0;
/* 533 */     for (int i = 0; i < argumentNames.length; i++) {
/* 534 */       if (i >= argumentIndexOffset)
/*     */       {
/*     */         
/* 537 */         if (!argumentNames[i].equals(this.returningName) && 
/* 538 */           !argumentNames[i].equals(this.throwingName)) {
/*     */ 
/*     */           
/* 541 */           pointcutParameterNames[index] = argumentNames[i];
/* 542 */           pointcutParameterTypes[index] = methodParameterTypes[i];
/* 543 */           index++;
/*     */         }  } 
/*     */     } 
/* 546 */     this.pointcut.setParameterNames(pointcutParameterNames);
/* 547 */     this.pointcut.setParameterTypes(pointcutParameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] argBinding(JoinPoint jp, @Nullable JoinPointMatch jpMatch, @Nullable Object returnValue, @Nullable Throwable ex) {
/* 563 */     calculateArgumentBindings();
/*     */ 
/*     */     
/* 566 */     Object[] adviceInvocationArgs = new Object[this.parameterTypes.length];
/* 567 */     int numBound = 0;
/*     */     
/* 569 */     if (this.joinPointArgumentIndex != -1) {
/* 570 */       adviceInvocationArgs[this.joinPointArgumentIndex] = jp;
/* 571 */       numBound++;
/*     */     }
/* 573 */     else if (this.joinPointStaticPartArgumentIndex != -1) {
/* 574 */       adviceInvocationArgs[this.joinPointStaticPartArgumentIndex] = jp.getStaticPart();
/* 575 */       numBound++;
/*     */     } 
/*     */     
/* 578 */     if (!CollectionUtils.isEmpty(this.argumentBindings)) {
/*     */       
/* 580 */       if (jpMatch != null) {
/* 581 */         PointcutParameter[] parameterBindings = jpMatch.getParameterBindings();
/* 582 */         for (PointcutParameter parameter : parameterBindings) {
/* 583 */           String name = parameter.getName();
/* 584 */           Integer index = this.argumentBindings.get(name);
/* 585 */           adviceInvocationArgs[index.intValue()] = parameter.getBinding();
/* 586 */           numBound++;
/*     */         } 
/*     */       } 
/*     */       
/* 590 */       if (this.returningName != null) {
/* 591 */         Integer index = this.argumentBindings.get(this.returningName);
/* 592 */         adviceInvocationArgs[index.intValue()] = returnValue;
/* 593 */         numBound++;
/*     */       } 
/*     */       
/* 596 */       if (this.throwingName != null) {
/* 597 */         Integer index = this.argumentBindings.get(this.throwingName);
/* 598 */         adviceInvocationArgs[index.intValue()] = ex;
/* 599 */         numBound++;
/*     */       } 
/*     */     } 
/*     */     
/* 603 */     if (numBound != this.parameterTypes.length) {
/* 604 */       throw new IllegalStateException("Required to bind " + this.parameterTypes.length + " arguments, but only bound " + numBound + " (JoinPointMatch " + (
/*     */           
/* 606 */           (jpMatch == null) ? "was NOT" : "WAS") + " bound in invocation)");
/*     */     }
/*     */     
/* 609 */     return adviceInvocationArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object invokeAdviceMethod(@Nullable JoinPointMatch jpMatch, @Nullable Object returnValue, @Nullable Throwable ex) throws Throwable {
/* 624 */     return invokeAdviceMethodWithGivenArgs(argBinding(getJoinPoint(), jpMatch, returnValue, ex));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object invokeAdviceMethod(JoinPoint jp, @Nullable JoinPointMatch jpMatch, @Nullable Object returnValue, @Nullable Throwable t) throws Throwable {
/* 631 */     return invokeAdviceMethodWithGivenArgs(argBinding(jp, jpMatch, returnValue, t));
/*     */   }
/*     */   @Nullable
/*     */   protected Object invokeAdviceMethodWithGivenArgs(Object[] args) throws Throwable {
/* 635 */     Object[] actualArgs = args;
/* 636 */     if (this.aspectJAdviceMethod.getParameterCount() == 0) {
/* 637 */       actualArgs = null;
/*     */     }
/* 639 */     Object aspectInstance = this.aspectInstanceFactory.getAspectInstance();
/* 640 */     if (aspectInstance.equals((Object)null)) {
/*     */       
/* 642 */       JoinPoint joinPoint = getJoinPoint(); if (joinPoint instanceof ProceedingJoinPoint) { ProceedingJoinPoint pjp = (ProceedingJoinPoint)joinPoint;
/* 643 */         return pjp.proceed(); }
/*     */       
/* 645 */       return null;
/*     */     } 
/*     */     try {
/* 648 */       ReflectionUtils.makeAccessible(this.aspectJAdviceMethod);
/* 649 */       return this.aspectJAdviceMethod.invoke(aspectInstance, actualArgs);
/*     */     }
/* 651 */     catch (IllegalArgumentException ex) {
/* 652 */       throw new AopInvocationException("Mismatch on arguments to advice method [" + String.valueOf(this.aspectJAdviceMethod) + "]; pointcut expression [" + 
/*     */           
/* 654 */           String.valueOf(this.pointcut.getPointcutExpression()) + "]", ex);
/*     */     }
/* 656 */     catch (InvocationTargetException ex) {
/* 657 */       throw ex.getTargetException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JoinPoint getJoinPoint() {
/* 665 */     return currentJoinPoint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected JoinPointMatch getJoinPointMatch() {
/*     */     ProxyMethodInvocation pmi;
/* 673 */     MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/* 674 */     if (mi instanceof ProxyMethodInvocation) { pmi = (ProxyMethodInvocation)mi; }
/* 675 */     else { throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + String.valueOf(mi)); }
/*     */     
/* 677 */     return getJoinPointMatch(pmi);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected JoinPointMatch getJoinPointMatch(ProxyMethodInvocation pmi) {
/* 688 */     String expression = this.pointcut.getExpression();
/* 689 */     return (expression != null) ? (JoinPointMatch)pmi.getUserAttribute(expression) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 695 */     return getClass().getName() + ": advice method [" + getClass().getName() + "]; aspect name '" + String.valueOf(this.aspectJAdviceMethod) + "'";
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException {
/* 700 */     inputStream.defaultReadObject();
/*     */     try {
/* 702 */       this.aspectJAdviceMethod = this.declaringClass.getMethod(this.methodName, this.parameterTypes);
/*     */     }
/* 704 */     catch (NoSuchMethodException ex) {
/* 705 */       throw new IllegalStateException("Failed to find advice method on deserialization", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AdviceExcludingMethodMatcher
/*     */     extends StaticMethodMatcher
/*     */   {
/*     */     private final Method adviceMethod;
/*     */ 
/*     */ 
/*     */     
/*     */     public AdviceExcludingMethodMatcher(Method adviceMethod) {
/* 719 */       this.adviceMethod = adviceMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 724 */       return !this.adviceMethod.equals(method);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 729 */       if (this != other) { if (other instanceof AdviceExcludingMethodMatcher) { AdviceExcludingMethodMatcher that = (AdviceExcludingMethodMatcher)other; if (this.adviceMethod
/* 730 */             .equals(that.adviceMethod)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 735 */       return this.adviceMethod.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 740 */       return getClass().getName() + ": " + getClass().getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AbstractAspectJAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */