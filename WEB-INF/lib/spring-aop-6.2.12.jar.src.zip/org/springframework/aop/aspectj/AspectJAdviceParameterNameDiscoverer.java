/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.weaver.tools.PointcutParser;
/*     */ import org.aspectj.weaver.tools.PointcutPrimitive;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJAdviceParameterNameDiscoverer
/*     */   implements ParameterNameDiscoverer
/*     */ {
/*     */   private static final String THIS_JOIN_POINT = "thisJoinPoint";
/*     */   private static final String THIS_JOIN_POINT_STATIC_PART = "thisJoinPointStaticPart";
/*     */   private static final int STEP_JOIN_POINT_BINDING = 1;
/*     */   private static final int STEP_THROWING_BINDING = 2;
/*     */   private static final int STEP_ANNOTATION_BINDING = 3;
/*     */   private static final int STEP_RETURNING_BINDING = 4;
/*     */   private static final int STEP_PRIMITIVE_ARGS_BINDING = 5;
/*     */   private static final int STEP_THIS_TARGET_ARGS_BINDING = 6;
/*     */   private static final int STEP_REFERENCE_PCUT_BINDING = 7;
/*     */   private static final int STEP_FINISHED = 8;
/* 135 */   private static final Set<String> singleValuedAnnotationPcds = Set.of("@this", "@target", "@within", "@withincode", "@annotation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   private static final Set<String> nonReferencePointcutTokens = new HashSet<>(); @Nullable
/*     */   private final String pointcutExpression; private boolean raiseExceptions; @Nullable
/*     */   private String returningName; @Nullable
/*     */   private String throwingName; static {
/* 146 */     Set<PointcutPrimitive> pointcutPrimitives = PointcutParser.getAllSupportedPointcutPrimitives();
/* 147 */     for (PointcutPrimitive primitive : pointcutPrimitives) {
/* 148 */       nonReferencePointcutTokens.add(primitive.getName());
/*     */     }
/* 150 */     nonReferencePointcutTokens.add("&&");
/* 151 */     nonReferencePointcutTokens.add("!");
/* 152 */     nonReferencePointcutTokens.add("||");
/* 153 */     nonReferencePointcutTokens.add("and");
/* 154 */     nonReferencePointcutTokens.add("or");
/* 155 */     nonReferencePointcutTokens.add("not");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   private Class<?>[] argumentTypes = new Class[0];
/*     */   
/* 175 */   private String[] parameterNameBindings = new String[0];
/*     */ 
/*     */ 
/*     */   
/*     */   private int numberOfRemainingUnboundArguments;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectJAdviceParameterNameDiscoverer(@Nullable String pointcutExpression) {
/* 185 */     this.pointcutExpression = pointcutExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRaiseExceptions(boolean raiseExceptions) {
/* 195 */     this.raiseExceptions = raiseExceptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturningName(@Nullable String returningName) {
/* 204 */     this.returningName = returningName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThrowingName(@Nullable String throwingName) {
/* 213 */     this.throwingName = throwingName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getParameterNames(Method method) {
/* 226 */     this.argumentTypes = method.getParameterTypes();
/* 227 */     this.numberOfRemainingUnboundArguments = this.argumentTypes.length;
/* 228 */     this.parameterNameBindings = new String[this.numberOfRemainingUnboundArguments];
/*     */     
/* 230 */     int minimumNumberUnboundArgs = 0;
/* 231 */     if (this.returningName != null) {
/* 232 */       minimumNumberUnboundArgs++;
/*     */     }
/* 234 */     if (this.throwingName != null) {
/* 235 */       minimumNumberUnboundArgs++;
/*     */     }
/* 237 */     if (this.numberOfRemainingUnboundArguments < minimumNumberUnboundArgs) {
/* 238 */       throw new IllegalStateException("Not enough arguments in method to satisfy binding of returning and throwing variables");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 243 */       int algorithmicStep = 1;
/* 244 */       while (this.numberOfRemainingUnboundArguments > 0 && algorithmicStep < 8) {
/* 245 */         switch (algorithmicStep++) {
/*     */           case 1:
/* 247 */             if (!maybeBindThisJoinPoint())
/* 248 */               maybeBindThisJoinPointStaticPart(); 
/*     */             continue;
/*     */           case 2:
/* 251 */             maybeBindThrowingVariable(); continue;
/* 252 */           case 3: maybeBindAnnotationsFromPointcutExpression(); continue;
/* 253 */           case 4: maybeBindReturningVariable(); continue;
/* 254 */           case 5: maybeBindPrimitiveArgsFromPointcutExpression(); continue;
/* 255 */           case 6: maybeBindThisOrTargetOrArgsFromPointcutExpression(); continue;
/* 256 */           case 7: maybeBindReferencePointcutParameter(); continue;
/* 257 */         }  throw new IllegalStateException("Unknown algorithmic step: " + algorithmicStep - 1);
/*     */       }
/*     */     
/*     */     }
/* 261 */     catch (AmbiguousBindingException|IllegalArgumentException ex) {
/* 262 */       if (this.raiseExceptions) {
/* 263 */         throw ex;
/*     */       }
/*     */       
/* 266 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 270 */     if (this.numberOfRemainingUnboundArguments == 0) {
/* 271 */       return this.parameterNameBindings;
/*     */     }
/*     */     
/* 274 */     if (this.raiseExceptions) {
/* 275 */       throw new IllegalStateException("Failed to bind all argument names: " + this.numberOfRemainingUnboundArguments + " argument(s) could not be bound");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String[] getParameterNames(Constructor<?> ctor) {
/* 294 */     if (this.raiseExceptions) {
/* 295 */       throw new UnsupportedOperationException("An advice method can never be a constructor");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void bindParameterName(int index, @Nullable String name) {
/* 306 */     this.parameterNameBindings[index] = name;
/* 307 */     this.numberOfRemainingUnboundArguments--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean maybeBindThisJoinPoint() {
/* 315 */     if (this.argumentTypes[0] == JoinPoint.class || this.argumentTypes[0] == ProceedingJoinPoint.class) {
/* 316 */       bindParameterName(0, "thisJoinPoint");
/* 317 */       return true;
/*     */     } 
/*     */     
/* 320 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void maybeBindThisJoinPointStaticPart() {
/* 325 */     if (this.argumentTypes[0] == JoinPoint.StaticPart.class) {
/* 326 */       bindParameterName(0, "thisJoinPointStaticPart");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeBindThrowingVariable() {
/* 335 */     if (this.throwingName == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 340 */     int throwableIndex = -1;
/* 341 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 342 */       if (isUnbound(i) && isSubtypeOf(Throwable.class, i)) {
/* 343 */         if (throwableIndex == -1) {
/* 344 */           throwableIndex = i;
/*     */         }
/*     */         else {
/*     */           
/* 348 */           throw new AmbiguousBindingException("Binding of throwing parameter '" + this.throwingName + "' is ambiguous: could be bound to argument " + throwableIndex + " or " + i);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 355 */     if (throwableIndex == -1) {
/* 356 */       throw new IllegalStateException("Binding of throwing parameter '" + this.throwingName + "' could not be completed as no available arguments are a subtype of Throwable");
/*     */     }
/*     */ 
/*     */     
/* 360 */     bindParameterName(throwableIndex, this.throwingName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeBindReturningVariable() {
/* 368 */     if (this.numberOfRemainingUnboundArguments == 0) {
/* 369 */       throw new IllegalStateException("Algorithm assumes that there must be at least one unbound parameter on entry to this method");
/*     */     }
/*     */ 
/*     */     
/* 373 */     if (this.returningName != null) {
/* 374 */       if (this.numberOfRemainingUnboundArguments > 1) {
/* 375 */         throw new AmbiguousBindingException("Binding of returning parameter '" + this.returningName + "' is ambiguous: there are " + this.numberOfRemainingUnboundArguments + " candidates. Consider compiling with -parameters in order to make declared parameter names available.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 381 */       for (int i = 0; i < this.parameterNameBindings.length; i++) {
/* 382 */         if (this.parameterNameBindings[i] == null) {
/* 383 */           bindParameterName(i, this.returningName);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeBindAnnotationsFromPointcutExpression() {
/* 398 */     List<String> varNames = new ArrayList<>();
/* 399 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 400 */     for (int i = 0; i < tokens.length; i++) {
/* 401 */       String toMatch = tokens[i];
/* 402 */       int firstParenIndex = toMatch.indexOf('(');
/* 403 */       if (firstParenIndex != -1) {
/* 404 */         toMatch = toMatch.substring(0, firstParenIndex);
/*     */       }
/* 406 */       if (singleValuedAnnotationPcds.contains(toMatch)) {
/* 407 */         PointcutBody body = getPointcutBody(tokens, i);
/* 408 */         i += body.numTokensConsumed;
/* 409 */         String varName = maybeExtractVariableName(body.text);
/* 410 */         if (varName != null) {
/* 411 */           varNames.add(varName);
/*     */         }
/*     */       }
/* 414 */       else if (tokens[i].startsWith("@args(") || tokens[i].equals("@args")) {
/* 415 */         PointcutBody body = getPointcutBody(tokens, i);
/* 416 */         i += body.numTokensConsumed;
/* 417 */         maybeExtractVariableNamesFromArgs(body.text, varNames);
/*     */       } 
/*     */     } 
/*     */     
/* 421 */     bindAnnotationsFromVarNames(varNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void bindAnnotationsFromVarNames(List<String> varNames) {
/* 428 */     if (!varNames.isEmpty()) {
/*     */       
/* 430 */       int numAnnotationSlots = countNumberOfUnboundAnnotationArguments();
/* 431 */       if (numAnnotationSlots > 1) {
/* 432 */         throw new AmbiguousBindingException("Found " + varNames.size() + " potential annotation variable(s) and " + numAnnotationSlots + " potential argument slots");
/*     */       }
/*     */ 
/*     */       
/* 436 */       if (numAnnotationSlots == 1) {
/* 437 */         if (varNames.size() == 1) {
/*     */           
/* 439 */           findAndBind(Annotation.class, varNames.get(0));
/*     */         }
/*     */         else {
/*     */           
/* 443 */           throw new IllegalArgumentException("Found " + varNames.size() + " candidate annotation binding variables but only one potential argument binding slot");
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String maybeExtractVariableName(@Nullable String candidateToken) {
/* 459 */     if (AspectJProxyUtils.isVariableName(candidateToken)) {
/* 460 */       return candidateToken;
/*     */     }
/* 462 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeExtractVariableNamesFromArgs(@Nullable String argsSpec, List<String> varNames) {
/* 470 */     if (argsSpec == null) {
/*     */       return;
/*     */     }
/* 473 */     String[] tokens = StringUtils.tokenizeToStringArray(argsSpec, ",");
/* 474 */     for (int i = 0; i < tokens.length; i++) {
/* 475 */       tokens[i] = tokens[i].strip();
/* 476 */       String varName = maybeExtractVariableName(tokens[i]);
/* 477 */       if (varName != null) {
/* 478 */         varNames.add(varName);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeBindThisOrTargetOrArgsFromPointcutExpression() {
/* 488 */     if (this.numberOfRemainingUnboundArguments > 1) {
/* 489 */       throw new AmbiguousBindingException("Still " + this.numberOfRemainingUnboundArguments + " unbound args at this()/target()/args() binding stage, with no way to determine between them");
/*     */     }
/*     */ 
/*     */     
/* 493 */     List<String> varNames = new ArrayList<>();
/* 494 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 495 */     for (int i = 0; i < tokens.length; i++) {
/* 496 */       if (tokens[i].equals("this") || tokens[i]
/* 497 */         .startsWith("this(") || tokens[i]
/* 498 */         .equals("target") || tokens[i]
/* 499 */         .startsWith("target(")) {
/* 500 */         PointcutBody body = getPointcutBody(tokens, i);
/* 501 */         i += body.numTokensConsumed;
/* 502 */         String varName = maybeExtractVariableName(body.text);
/* 503 */         if (varName != null) {
/* 504 */           varNames.add(varName);
/*     */         }
/*     */       }
/* 507 */       else if (tokens[i].equals("args") || tokens[i].startsWith("args(")) {
/* 508 */         PointcutBody body = getPointcutBody(tokens, i);
/* 509 */         i += body.numTokensConsumed;
/* 510 */         List<String> candidateVarNames = new ArrayList<>();
/* 511 */         maybeExtractVariableNamesFromArgs(body.text, candidateVarNames);
/*     */ 
/*     */         
/* 514 */         for (String varName : candidateVarNames) {
/* 515 */           if (!alreadyBound(varName)) {
/* 516 */             varNames.add(varName);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 522 */     if (varNames.size() > 1) {
/* 523 */       throw new AmbiguousBindingException("Found " + varNames.size() + " candidate this(), target(), or args() variables but only one unbound argument slot");
/*     */     }
/*     */     
/* 526 */     if (varNames.size() == 1) {
/* 527 */       for (int j = 0; j < this.parameterNameBindings.length; j++) {
/* 528 */         if (isUnbound(j)) {
/* 529 */           bindParameterName(j, varNames.get(0));
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void maybeBindReferencePointcutParameter() {
/* 538 */     if (this.numberOfRemainingUnboundArguments > 1) {
/* 539 */       throw new AmbiguousBindingException("Still " + this.numberOfRemainingUnboundArguments + " unbound args at reference pointcut binding stage, with no way to determine between them");
/*     */     }
/*     */ 
/*     */     
/* 543 */     List<String> varNames = new ArrayList<>();
/* 544 */     String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " ");
/* 545 */     for (int i = 0; i < tokens.length; i++) {
/* 546 */       String toMatch = tokens[i];
/* 547 */       if (toMatch.startsWith("!")) {
/* 548 */         toMatch = toMatch.substring(1);
/*     */       }
/* 550 */       int firstParenIndex = toMatch.indexOf('(');
/* 551 */       if (firstParenIndex != -1) {
/* 552 */         toMatch = toMatch.substring(0, firstParenIndex);
/*     */       } else {
/*     */         
/* 555 */         if (tokens.length < i + 2) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 560 */         String nextToken = tokens[i + 1];
/* 561 */         if (nextToken.charAt(0) != '(') {
/*     */           continue;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 570 */       PointcutBody body = getPointcutBody(tokens, i);
/* 571 */       i += body.numTokensConsumed;
/*     */       
/* 573 */       if (!nonReferencePointcutTokens.contains(toMatch)) {
/*     */         
/* 575 */         String varName = maybeExtractVariableName(body.text);
/* 576 */         if (varName != null) {
/* 577 */           varNames.add(varName);
/*     */         }
/*     */       } 
/*     */       continue;
/*     */     } 
/* 582 */     if (varNames.size() > 1) {
/* 583 */       throw new AmbiguousBindingException("Found " + varNames.size() + " candidate reference pointcut variables but only one unbound argument slot");
/*     */     }
/*     */     
/* 586 */     if (varNames.size() == 1) {
/* 587 */       for (int j = 0; j < this.parameterNameBindings.length; j++) {
/* 588 */         if (isUnbound(j)) {
/* 589 */           bindParameterName(j, varNames.get(0));
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PointcutBody getPointcutBody(String[] tokens, int startIndex) {
/* 602 */     int numTokensConsumed = 0;
/* 603 */     String currentToken = tokens[startIndex];
/* 604 */     int bodyStart = currentToken.indexOf('(');
/* 605 */     if (currentToken.charAt(currentToken.length() - 1) == ')')
/*     */     {
/* 607 */       return new PointcutBody(0, currentToken.substring(bodyStart + 1, currentToken.length() - 1));
/*     */     }
/*     */     
/* 610 */     StringBuilder sb = new StringBuilder();
/* 611 */     if (bodyStart >= 0 && bodyStart != currentToken.length() - 1) {
/* 612 */       sb.append(currentToken.substring(bodyStart + 1));
/* 613 */       sb.append(' ');
/*     */     } 
/* 615 */     numTokensConsumed++;
/* 616 */     int currentIndex = startIndex + numTokensConsumed;
/* 617 */     while (currentIndex < tokens.length) {
/* 618 */       if (tokens[currentIndex].equals("(")) {
/* 619 */         currentIndex++;
/*     */         
/*     */         continue;
/*     */       } 
/* 623 */       if (tokens[currentIndex].endsWith(")")) {
/* 624 */         sb.append(tokens[currentIndex], 0, tokens[currentIndex].length() - 1);
/* 625 */         return new PointcutBody(numTokensConsumed, sb.toString().trim());
/*     */       } 
/*     */       
/* 628 */       String toAppend = tokens[currentIndex];
/* 629 */       if (toAppend.startsWith("(")) {
/* 630 */         toAppend = toAppend.substring(1);
/*     */       }
/* 632 */       sb.append(toAppend);
/* 633 */       sb.append(' ');
/* 634 */       currentIndex++;
/* 635 */       numTokensConsumed++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 641 */     return new PointcutBody(numTokensConsumed, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeBindPrimitiveArgsFromPointcutExpression() {
/* 648 */     int numUnboundPrimitives = countNumberOfUnboundPrimitiveArguments();
/* 649 */     if (numUnboundPrimitives > 1) {
/* 650 */       throw new AmbiguousBindingException("Found " + numUnboundPrimitives + " unbound primitive arguments with no way to distinguish between them.");
/*     */     }
/*     */     
/* 653 */     if (numUnboundPrimitives == 1) {
/*     */       
/* 655 */       List<String> varNames = new ArrayList<>();
/* 656 */       String[] tokens = StringUtils.tokenizeToStringArray(this.pointcutExpression, " "); int i;
/* 657 */       for (i = 0; i < tokens.length; i++) {
/* 658 */         if (tokens[i].equals("args") || tokens[i].startsWith("args(")) {
/* 659 */           PointcutBody body = getPointcutBody(tokens, i);
/* 660 */           i += body.numTokensConsumed;
/* 661 */           maybeExtractVariableNamesFromArgs(body.text, varNames);
/*     */         } 
/*     */       } 
/* 664 */       if (varNames.size() > 1) {
/* 665 */         throw new AmbiguousBindingException("Found " + varNames.size() + " candidate variable names but only one candidate binding slot when matching primitive args");
/*     */       }
/*     */       
/* 668 */       if (varNames.size() == 1)
/*     */       {
/* 670 */         for (i = 0; i < this.argumentTypes.length; i++) {
/* 671 */           if (isUnbound(i) && this.argumentTypes[i].isPrimitive()) {
/* 672 */             bindParameterName(i, varNames.get(0));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUnbound(int i) {
/* 685 */     return (this.parameterNameBindings[i] == null);
/*     */   }
/*     */   
/*     */   private boolean alreadyBound(String varName) {
/* 689 */     for (int i = 0; i < this.parameterNameBindings.length; i++) {
/* 690 */       if (!isUnbound(i) && varName.equals(this.parameterNameBindings[i])) {
/* 691 */         return true;
/*     */       }
/*     */     } 
/* 694 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSubtypeOf(Class<?> supertype, int argumentNumber) {
/* 702 */     return supertype.isAssignableFrom(this.argumentTypes[argumentNumber]);
/*     */   }
/*     */   
/*     */   private int countNumberOfUnboundAnnotationArguments() {
/* 706 */     int count = 0;
/* 707 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 708 */       if (isUnbound(i) && isSubtypeOf(Annotation.class, i)) {
/* 709 */         count++;
/*     */       }
/*     */     } 
/* 712 */     return count;
/*     */   }
/*     */   
/*     */   private int countNumberOfUnboundPrimitiveArguments() {
/* 716 */     int count = 0;
/* 717 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 718 */       if (isUnbound(i) && this.argumentTypes[i].isPrimitive()) {
/* 719 */         count++;
/*     */       }
/*     */     } 
/* 722 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findAndBind(Class<?> argumentType, String varName) {
/* 730 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/* 731 */       if (isUnbound(i) && isSubtypeOf(argumentType, i)) {
/* 732 */         bindParameterName(i, varName);
/*     */         return;
/*     */       } 
/*     */     } 
/* 736 */     throw new IllegalStateException("Expected to find an unbound argument of type '" + argumentType
/* 737 */         .getName() + "'");
/*     */   } private static final class PointcutBody extends Record {
/*     */     private final int numTokensConsumed; @Nullable
/*     */     private final String text; public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/aop/aspectj/AspectJAdviceParameterNameDiscoverer$PointcutBody;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #745	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aop/aspectj/AspectJAdviceParameterNameDiscoverer$PointcutBody;
/*     */     } public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/aop/aspectj/AspectJAdviceParameterNameDiscoverer$PointcutBody;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #745	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/aop/aspectj/AspectJAdviceParameterNameDiscoverer$PointcutBody;
/*     */     }
/* 745 */     private PointcutBody(int numTokensConsumed, @Nullable String text) { this.numTokensConsumed = numTokensConsumed; this.text = text; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/aop/aspectj/AspectJAdviceParameterNameDiscoverer$PointcutBody;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #745	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/aop/aspectj/AspectJAdviceParameterNameDiscoverer$PointcutBody;
/* 745 */       //   0	8	1	o	Ljava/lang/Object; } public int numTokensConsumed() { return this.numTokensConsumed; } @Nullable public String text() { return this.text; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AmbiguousBindingException
/*     */     extends RuntimeException
/*     */   {
/*     */     public AmbiguousBindingException(String msg) {
/* 761 */       super(msg);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\AspectJAdviceParameterNameDiscoverer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */