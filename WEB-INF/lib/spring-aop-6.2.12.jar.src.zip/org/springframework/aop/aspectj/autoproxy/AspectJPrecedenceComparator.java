/*     */ package org.springframework.aop.aspectj.autoproxy;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.aspectj.AspectJAopUtils;
/*     */ import org.springframework.aop.aspectj.AspectJPrecedenceInformation;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AspectJPrecedenceComparator
/*     */   implements Comparator<Advisor>
/*     */ {
/*     */   private static final int HIGHER_PRECEDENCE = -1;
/*     */   private static final int SAME_PRECEDENCE = 0;
/*     */   private static final int LOWER_PRECEDENCE = 1;
/*     */   private final Comparator<? super Advisor> advisorComparator;
/*     */   
/*     */   public AspectJPrecedenceComparator() {
/*  67 */     this.advisorComparator = (Comparator<? super Advisor>)AnnotationAwareOrderComparator.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectJPrecedenceComparator(Comparator<? super Advisor> advisorComparator) {
/*  76 */     Assert.notNull(advisorComparator, "Advisor comparator must not be null");
/*  77 */     this.advisorComparator = advisorComparator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(Advisor o1, Advisor o2) {
/*  83 */     int advisorPrecedence = this.advisorComparator.compare(o1, o2);
/*  84 */     if (advisorPrecedence == 0 && declaredInSameAspect(o1, o2)) {
/*  85 */       advisorPrecedence = comparePrecedenceWithinAspect(o1, o2);
/*     */     }
/*  87 */     return advisorPrecedence;
/*     */   }
/*     */ 
/*     */   
/*     */   private int comparePrecedenceWithinAspect(Advisor advisor1, Advisor advisor2) {
/*  92 */     boolean oneOrOtherIsAfterAdvice = (AspectJAopUtils.isAfterAdvice(advisor1) || AspectJAopUtils.isAfterAdvice(advisor2));
/*  93 */     int adviceDeclarationOrderDelta = getAspectDeclarationOrder(advisor1) - getAspectDeclarationOrder(advisor2);
/*     */     
/*  95 */     if (oneOrOtherIsAfterAdvice) {
/*     */       
/*  97 */       if (adviceDeclarationOrderDelta < 0)
/*     */       {
/*     */         
/* 100 */         return 1;
/*     */       }
/* 102 */       if (adviceDeclarationOrderDelta == 0) {
/* 103 */         return 0;
/*     */       }
/*     */       
/* 106 */       return -1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (adviceDeclarationOrderDelta < 0)
/*     */     {
/*     */       
/* 114 */       return -1;
/*     */     }
/* 116 */     if (adviceDeclarationOrderDelta == 0) {
/* 117 */       return 0;
/*     */     }
/*     */     
/* 120 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean declaredInSameAspect(Advisor advisor1, Advisor advisor2) {
/* 126 */     return (hasAspectName(advisor1) && hasAspectName(advisor2) && 
/* 127 */       getAspectName(advisor1).equals(getAspectName(advisor2)));
/*     */   }
/*     */   
/*     */   private boolean hasAspectName(Advisor advisor) {
/* 131 */     return (advisor instanceof AspectJPrecedenceInformation || advisor
/* 132 */       .getAdvice() instanceof AspectJPrecedenceInformation);
/*     */   }
/*     */ 
/*     */   
/*     */   private String getAspectName(Advisor advisor) {
/* 137 */     AspectJPrecedenceInformation precedenceInfo = AspectJAopUtils.getAspectJPrecedenceInformationFor(advisor);
/* 138 */     Assert.state((precedenceInfo != null), () -> "Unresolvable AspectJPrecedenceInformation for " + String.valueOf(advisor));
/* 139 */     return precedenceInfo.getAspectName();
/*     */   }
/*     */   
/*     */   private int getAspectDeclarationOrder(Advisor advisor) {
/* 143 */     AspectJPrecedenceInformation precedenceInfo = AspectJAopUtils.getAspectJPrecedenceInformationFor(advisor);
/* 144 */     return (precedenceInfo != null) ? precedenceInfo.getDeclarationOrder() : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\autoproxy\AspectJPrecedenceComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */