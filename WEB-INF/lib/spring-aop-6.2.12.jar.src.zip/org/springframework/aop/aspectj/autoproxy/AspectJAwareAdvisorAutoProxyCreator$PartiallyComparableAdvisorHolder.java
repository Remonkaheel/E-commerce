/*     */ package org.springframework.aop.aspectj.autoproxy;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aspectj.util.PartialOrder;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.aspectj.AbstractAspectJAdvice;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PartiallyComparableAdvisorHolder
/*     */   implements PartialOrder.PartialComparable
/*     */ {
/*     */   private final Advisor advisor;
/*     */   private final Comparator<Advisor> comparator;
/*     */   
/*     */   public PartiallyComparableAdvisorHolder(Advisor advisor, Comparator<Advisor> comparator) {
/* 136 */     this.advisor = advisor;
/* 137 */     this.comparator = comparator;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object obj) {
/* 142 */     Advisor otherAdvisor = ((PartiallyComparableAdvisorHolder)obj).advisor;
/* 143 */     return this.comparator.compare(this.advisor, otherAdvisor);
/*     */   }
/*     */ 
/*     */   
/*     */   public int fallbackCompareTo(Object obj) {
/* 148 */     return 0;
/*     */   }
/*     */   
/*     */   public Advisor getAdvisor() {
/* 152 */     return this.advisor;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 157 */     Advice advice = this.advisor.getAdvice();
/* 158 */     StringBuilder sb = new StringBuilder(ClassUtils.getShortName(advice.getClass()));
/* 159 */     boolean appended = false;
/* 160 */     Advisor advisor = this.advisor; if (advisor instanceof Ordered) { Ordered ordered = (Ordered)advisor;
/* 161 */       sb.append(": order = ").append(ordered.getOrder());
/* 162 */       appended = true; }
/*     */     
/* 164 */     if (advice instanceof AbstractAspectJAdvice) { AbstractAspectJAdvice ajAdvice = (AbstractAspectJAdvice)advice;
/* 165 */       sb.append(!appended ? ": " : ", ");
/* 166 */       sb.append("aspect name = ");
/* 167 */       sb.append(ajAdvice.getAspectName());
/* 168 */       sb.append(", declaration order = ");
/* 169 */       sb.append(ajAdvice.getDeclarationOrder()); }
/*     */     
/* 171 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\autoproxy\AspectJAwareAdvisorAutoProxyCreator$PartiallyComparableAdvisorHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */