/*     */ package org.springframework.aop.aspectj.autoproxy;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aspectj.util.PartialOrder;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.aspectj.AbstractAspectJAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJPointcutAdvisor;
/*     */ import org.springframework.aop.aspectj.AspectJProxyUtils;
/*     */ import org.springframework.aop.aspectj.ShadowMatchUtils;
/*     */ import org.springframework.aop.framework.autoproxy.AbstractAdvisorAutoProxyCreator;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJAwareAdvisorAutoProxyCreator
/*     */   extends AbstractAdvisorAutoProxyCreator
/*     */   implements SmartInitializingSingleton, DisposableBean
/*     */ {
/*  53 */   private static final Comparator<Advisor> DEFAULT_PRECEDENCE_COMPARATOR = new AspectJPrecedenceComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Advisor> sortAdvisors(List<Advisor> advisors) {
/*  74 */     List<PartiallyComparableAdvisorHolder> partiallyComparableAdvisors = new ArrayList<>(advisors.size());
/*  75 */     for (Advisor advisor : advisors) {
/*  76 */       partiallyComparableAdvisors.add(new PartiallyComparableAdvisorHolder(advisor, DEFAULT_PRECEDENCE_COMPARATOR));
/*     */     }
/*     */     
/*  79 */     List<PartiallyComparableAdvisorHolder> sorted = PartialOrder.sort(partiallyComparableAdvisors);
/*  80 */     if (sorted != null) {
/*  81 */       List<Advisor> result = new ArrayList<>(advisors.size());
/*  82 */       for (PartiallyComparableAdvisorHolder pcAdvisor : sorted) {
/*  83 */         result.add(pcAdvisor.getAdvisor());
/*     */       }
/*  85 */       return result;
/*     */     } 
/*     */     
/*  88 */     return super.sortAdvisors(advisors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendAdvisors(List<Advisor> candidateAdvisors) {
/*  99 */     AspectJProxyUtils.makeAdvisorChainAspectJCapableIfNecessary(candidateAdvisors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldSkip(Class<?> beanClass, String beanName) {
/* 105 */     List<Advisor> candidateAdvisors = findCandidateAdvisors();
/* 106 */     for (Advisor advisor : candidateAdvisors) {
/* 107 */       if (advisor instanceof AspectJPointcutAdvisor) { AspectJPointcutAdvisor pointcutAdvisor = (AspectJPointcutAdvisor)advisor; if (pointcutAdvisor
/* 108 */           .getAspectName().equals(beanName))
/* 109 */           return true;  }
/*     */     
/*     */     } 
/* 112 */     return super.shouldSkip(beanClass, beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 117 */     ShadowMatchUtils.clearCache();
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 122 */     ShadowMatchUtils.clearCache();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PartiallyComparableAdvisorHolder
/*     */     implements PartialOrder.PartialComparable
/*     */   {
/*     */     private final Advisor advisor;
/*     */     
/*     */     private final Comparator<Advisor> comparator;
/*     */ 
/*     */     
/*     */     public PartiallyComparableAdvisorHolder(Advisor advisor, Comparator<Advisor> comparator) {
/* 136 */       this.advisor = advisor;
/* 137 */       this.comparator = comparator;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Object obj) {
/* 142 */       Advisor otherAdvisor = ((PartiallyComparableAdvisorHolder)obj).advisor;
/* 143 */       return this.comparator.compare(this.advisor, otherAdvisor);
/*     */     }
/*     */ 
/*     */     
/*     */     public int fallbackCompareTo(Object obj) {
/* 148 */       return 0;
/*     */     }
/*     */     
/*     */     public Advisor getAdvisor() {
/* 152 */       return this.advisor;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 157 */       Advice advice = this.advisor.getAdvice();
/* 158 */       StringBuilder sb = new StringBuilder(ClassUtils.getShortName(advice.getClass()));
/* 159 */       boolean appended = false;
/* 160 */       Advisor advisor = this.advisor; if (advisor instanceof Ordered) { Ordered ordered = (Ordered)advisor;
/* 161 */         sb.append(": order = ").append(ordered.getOrder());
/* 162 */         appended = true; }
/*     */       
/* 164 */       if (advice instanceof AbstractAspectJAdvice) { AbstractAspectJAdvice ajAdvice = (AbstractAspectJAdvice)advice;
/* 165 */         sb.append(!appended ? ": " : ", ");
/* 166 */         sb.append("aspect name = ");
/* 167 */         sb.append(ajAdvice.getAspectName());
/* 168 */         sb.append(", declaration order = ");
/* 169 */         sb.append(ajAdvice.getDeclarationOrder()); }
/*     */       
/* 171 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\autoproxy\AspectJAwareAdvisorAutoProxyCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */