/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AspectDelegate
/*    */ {
/*    */   @Nullable
/*    */   private static AspectJBeanFactoryInitializationAotProcessor.AspectContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 64 */     BeanFactoryAspectJAdvisorsBuilder builder = new BeanFactoryAspectJAdvisorsBuilder((ListableBeanFactory)beanFactory);
/* 65 */     List<Advisor> advisors = builder.buildAspectJAdvisors();
/* 66 */     return advisors.isEmpty() ? null : new AspectJBeanFactoryInitializationAotProcessor.AspectContribution(advisors);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AspectJBeanFactoryInitializationAotProcessor$AspectDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */