/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.DeclareParents;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.aspectj.AspectJAfterAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterReturningAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAfterThrowingAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJAroundAdvice;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.AspectJMethodBeforeAdvice;
/*     */ import org.springframework.aop.aspectj.DeclareParentsAdvisor;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.convert.converter.ConvertingComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.InstanceComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectiveAspectJAdvisorFactory
/*     */   extends AbstractAspectJAdvisorFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final ReflectionUtils.MethodFilter adviceMethodFilter;
/*     */   private static final Comparator<Method> adviceMethodComparator;
/*     */   @Nullable
/*     */   private final BeanFactory beanFactory;
/*     */   
/*     */   static {
/*  77 */     adviceMethodFilter = ReflectionUtils.USER_DECLARED_METHODS.and(method -> (AnnotationUtils.getAnnotation(method, Pointcut.class) == null));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     ConvertingComparator<Method> convertingComparator = new ConvertingComparator((Comparator)new InstanceComparator(new Class[] { Around.class, Before.class, After.class, AfterReturning.class, AfterThrowing.class }, ), method -> {
/*     */           AbstractAspectJAdvisorFactory.AspectJAnnotation ann = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(method);
/*     */ 
/*     */           
/*     */           return (ann != null) ? ann.getAnnotation() : null;
/*     */         });
/*     */     
/*  94 */     ConvertingComparator convertingComparator1 = new ConvertingComparator(Method::getName);
/*  95 */     adviceMethodComparator = convertingComparator.thenComparing((Comparator<? super Method>)convertingComparator1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveAspectJAdvisorFactory() {
/* 107 */     this((BeanFactory)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectiveAspectJAdvisorFactory(@Nullable BeanFactory beanFactory) {
/* 120 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Advisor> getAdvisors(MetadataAwareAspectInstanceFactory aspectInstanceFactory) {
/* 126 */     Class<?> aspectClass = aspectInstanceFactory.getAspectMetadata().getAspectClass();
/* 127 */     String aspectName = aspectInstanceFactory.getAspectMetadata().getAspectName();
/* 128 */     validate(aspectClass);
/*     */ 
/*     */ 
/*     */     
/* 132 */     MetadataAwareAspectInstanceFactory lazySingletonAspectInstanceFactory = new LazySingletonAspectInstanceFactoryDecorator(aspectInstanceFactory);
/*     */ 
/*     */     
/* 135 */     List<Advisor> advisors = new ArrayList<>();
/* 136 */     for (Method method : getAdvisorMethods(aspectClass)) {
/* 137 */       if (method.equals(ClassUtils.getMostSpecificMethod(method, aspectClass))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         Advisor advisor = getAdvisor(method, lazySingletonAspectInstanceFactory, 0, aspectName);
/* 147 */         if (advisor != null) {
/* 148 */           advisors.add(advisor);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 154 */     if (!advisors.isEmpty() && lazySingletonAspectInstanceFactory.getAspectMetadata().isLazilyInstantiated()) {
/* 155 */       SyntheticInstantiationAdvisor syntheticInstantiationAdvisor = new SyntheticInstantiationAdvisor(lazySingletonAspectInstanceFactory);
/* 156 */       advisors.add(0, syntheticInstantiationAdvisor);
/*     */     } 
/*     */ 
/*     */     
/* 160 */     for (Field field : aspectClass.getDeclaredFields()) {
/* 161 */       Advisor advisor = getDeclareParentsAdvisor(field);
/* 162 */       if (advisor != null) {
/* 163 */         advisors.add(advisor);
/*     */       }
/*     */     } 
/*     */     
/* 167 */     return advisors;
/*     */   }
/*     */   
/*     */   private List<Method> getAdvisorMethods(Class<?> aspectClass) {
/* 171 */     List<Method> methods = new ArrayList<>();
/* 172 */     Objects.requireNonNull(methods); ReflectionUtils.doWithMethods(aspectClass, methods::add, adviceMethodFilter);
/* 173 */     if (methods.size() > 1) {
/* 174 */       methods.sort(adviceMethodComparator);
/*     */     }
/* 176 */     return methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Advisor getDeclareParentsAdvisor(Field introductionField) {
/* 188 */     DeclareParents declareParents = introductionField.<DeclareParents>getAnnotation(DeclareParents.class);
/* 189 */     if (declareParents == null)
/*     */     {
/* 191 */       return null;
/*     */     }
/*     */     
/* 194 */     if (DeclareParents.class == declareParents.defaultImpl()) {
/* 195 */       throw new IllegalStateException("'defaultImpl' attribute must be set on DeclareParents");
/*     */     }
/*     */     
/* 198 */     return (Advisor)new DeclareParentsAdvisor(introductionField
/* 199 */         .getType(), declareParents.value(), declareParents.defaultImpl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Advisor getAdvisor(Method candidateAdviceMethod, MetadataAwareAspectInstanceFactory aspectInstanceFactory, int declarationOrderInAspect, String aspectName) {
/* 208 */     validate(aspectInstanceFactory.getAspectMetadata().getAspectClass());
/*     */     
/* 210 */     AspectJExpressionPointcut expressionPointcut = getPointcut(candidateAdviceMethod, aspectInstanceFactory
/* 211 */         .getAspectMetadata().getAspectClass());
/* 212 */     if (expressionPointcut == null) {
/* 213 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 217 */       return (Advisor)new InstantiationModelAwarePointcutAdvisorImpl(expressionPointcut, candidateAdviceMethod, this, aspectInstanceFactory, declarationOrderInAspect, aspectName);
/*     */     
/*     */     }
/* 220 */     catch (IllegalArgumentException|IllegalStateException ex) {
/* 221 */       if (this.logger.isDebugEnabled()) {
/* 222 */         this.logger.debug("Ignoring incompatible advice method: " + String.valueOf(candidateAdviceMethod), ex);
/*     */       }
/* 224 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private AspectJExpressionPointcut getPointcut(Method candidateAdviceMethod, Class<?> candidateAspectClass) {
/* 231 */     AbstractAspectJAdvisorFactory.AspectJAnnotation aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(candidateAdviceMethod);
/* 232 */     if (aspectJAnnotation == null) {
/* 233 */       return null;
/*     */     }
/*     */     
/* 236 */     AspectJExpressionPointcut ajexp = new AspectJExpressionPointcut(candidateAspectClass, new String[0], new Class[0]);
/*     */     
/* 238 */     ajexp.setExpression(aspectJAnnotation.getPointcutExpression());
/* 239 */     if (this.beanFactory != null) {
/* 240 */       ajexp.setBeanFactory(this.beanFactory);
/*     */     }
/* 242 */     return ajexp; } @Nullable
/*     */   public Advice getAdvice(Method candidateAdviceMethod, AspectJExpressionPointcut expressionPointcut, MetadataAwareAspectInstanceFactory aspectInstanceFactory, int declarationOrder, String aspectName) {
/*     */     AspectJAroundAdvice aspectJAroundAdvice;
/*     */     AspectJMethodBeforeAdvice aspectJMethodBeforeAdvice;
/*     */     AspectJAfterAdvice aspectJAfterAdvice;
/*     */     AspectJAfterReturningAdvice aspectJAfterReturningAdvice;
/*     */     AspectJAfterThrowingAdvice aspectJAfterThrowingAdvice;
/*     */     AfterReturning afterReturningAnnotation;
/*     */     AfterThrowing afterThrowingAnnotation;
/* 251 */     Class<?> candidateAspectClass = aspectInstanceFactory.getAspectMetadata().getAspectClass();
/* 252 */     validate(candidateAspectClass);
/*     */ 
/*     */     
/* 255 */     AbstractAspectJAdvisorFactory.AspectJAnnotation aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(candidateAdviceMethod);
/* 256 */     if (aspectJAnnotation == null) {
/* 257 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 262 */     if (!isAspect(candidateAspectClass)) {
/* 263 */       throw new AopConfigException("Advice must be declared inside an aspect type: Offending method '" + String.valueOf(candidateAdviceMethod) + "' in class [" + candidateAspectClass
/*     */           
/* 265 */           .getName() + "]");
/*     */     }
/*     */     
/* 268 */     if (this.logger.isDebugEnabled()) {
/* 269 */       this.logger.debug("Found AspectJ method: " + String.valueOf(candidateAdviceMethod));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 274 */     switch (aspectJAnnotation.getAnnotationType()) {
/*     */       case AtPointcut:
/* 276 */         if (this.logger.isDebugEnabled()) {
/* 277 */           this.logger.debug("Processing pointcut '" + candidateAdviceMethod.getName() + "'");
/*     */         }
/* 279 */         return null;
/*     */       case AtAround:
/* 281 */         aspectJAroundAdvice = new AspectJAroundAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory); break;
/*     */       case AtBefore:
/* 283 */         aspectJMethodBeforeAdvice = new AspectJMethodBeforeAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory); break;
/*     */       case AtAfter:
/* 285 */         aspectJAfterAdvice = new AspectJAfterAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */         break;
/*     */       case AtAfterReturning:
/* 288 */         aspectJAfterReturningAdvice = new AspectJAfterReturningAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */         
/* 290 */         afterReturningAnnotation = (AfterReturning)aspectJAnnotation.getAnnotation();
/* 291 */         if (StringUtils.hasText(afterReturningAnnotation.returning())) {
/* 292 */           aspectJAfterReturningAdvice.setReturningName(afterReturningAnnotation.returning());
/*     */         }
/*     */         break;
/*     */       case AtAfterThrowing:
/* 296 */         aspectJAfterThrowingAdvice = new AspectJAfterThrowingAdvice(candidateAdviceMethod, expressionPointcut, aspectInstanceFactory);
/*     */         
/* 298 */         afterThrowingAnnotation = (AfterThrowing)aspectJAnnotation.getAnnotation();
/* 299 */         if (StringUtils.hasText(afterThrowingAnnotation.throwing()))
/* 300 */           aspectJAfterThrowingAdvice.setThrowingName(afterThrowingAnnotation.throwing()); 
/*     */         break;
/*     */       default:
/* 303 */         throw new UnsupportedOperationException("Unsupported advice type on method: " + String.valueOf(candidateAdviceMethod));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 308 */     aspectJAfterThrowingAdvice.setAspectName(aspectName);
/* 309 */     aspectJAfterThrowingAdvice.setDeclarationOrder(declarationOrder);
/* 310 */     String[] argNames = this.parameterNameDiscoverer.getParameterNames(candidateAdviceMethod);
/* 311 */     if (argNames != null) {
/* 312 */       aspectJAfterThrowingAdvice.setArgumentNamesFromStringArray(argNames);
/*     */     }
/* 314 */     aspectJAfterThrowingAdvice.calculateArgumentBindings();
/*     */     
/* 316 */     return (Advice)aspectJAfterThrowingAdvice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class SyntheticInstantiationAdvisor
/*     */     extends DefaultPointcutAdvisor
/*     */   {
/*     */     public SyntheticInstantiationAdvisor(MetadataAwareAspectInstanceFactory aif) {
/* 329 */       super(aif.getAspectMetadata().getPerClausePointcut(), (Advice)((method, args, target) -> aif.getAspectInstance()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\ReflectiveAspectJAdvisorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */