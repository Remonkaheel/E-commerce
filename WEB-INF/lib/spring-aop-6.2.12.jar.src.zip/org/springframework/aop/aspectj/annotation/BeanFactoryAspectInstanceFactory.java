/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.OrderUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanFactoryAspectInstanceFactory
/*     */   implements MetadataAwareAspectInstanceFactory, Serializable
/*     */ {
/*     */   private final BeanFactory beanFactory;
/*     */   private final String name;
/*     */   private final AspectMetadata aspectMetadata;
/*     */   
/*     */   public BeanFactoryAspectInstanceFactory(BeanFactory beanFactory, String name) {
/*  63 */     this(beanFactory, name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanFactoryAspectInstanceFactory(BeanFactory beanFactory, String name, @Nullable Class<?> type) {
/*  76 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*  77 */     Assert.notNull(name, "Bean name must not be null");
/*  78 */     this.beanFactory = beanFactory;
/*  79 */     this.name = name;
/*  80 */     Class<?> resolvedType = type;
/*  81 */     if (resolvedType == null) {
/*  82 */       resolvedType = beanFactory.getType(name);
/*  83 */       Assert.notNull(resolvedType, "Unresolvable bean type - explicitly specify the aspect class");
/*     */     } 
/*  85 */     this.aspectMetadata = new AspectMetadata(resolvedType, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAspectInstance() {
/*  91 */     return this.beanFactory.getBean(this.name);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getAspectClassLoader() {
/*  97 */     BeanFactory beanFactory = this.beanFactory; ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory; return (beanFactory instanceof ConfigurableBeanFactory) ? 
/*  98 */       cbf.getBeanClassLoader() : ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   public AspectMetadata getAspectMetadata() {
/* 103 */     return this.aspectMetadata;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getAspectCreationMutex() {
/* 109 */     if (this.beanFactory.isSingleton(this.name))
/*     */     {
/* 111 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 131 */     Class<?> type = this.beanFactory.getType(this.name);
/* 132 */     if (type != null) {
/* 133 */       if (Ordered.class.isAssignableFrom(type) && this.beanFactory.isSingleton(this.name)) {
/*     */         try {
/* 135 */           return ((Ordered)this.beanFactory.getBean(this.name, Ordered.class)).getOrder();
/*     */         }
/* 137 */         catch (BeanNotOfRequiredTypeException beanNotOfRequiredTypeException) {}
/*     */       }
/*     */ 
/*     */       
/* 141 */       return OrderUtils.getOrder(type, 2147483647);
/*     */     } 
/* 143 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return getClass().getSimpleName() + ": bean name '" + getClass().getSimpleName() + "'";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\BeanFactoryAspectInstanceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */