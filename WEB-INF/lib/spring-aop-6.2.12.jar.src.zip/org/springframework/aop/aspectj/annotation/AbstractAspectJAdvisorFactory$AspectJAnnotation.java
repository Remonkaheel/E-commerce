/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Map;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectJAnnotation
/*     */ {
/* 163 */   private static final String[] EXPRESSION_ATTRIBUTES = new String[] { "pointcut", "value" };
/*     */   
/* 165 */   private static final Map<Class<?>, AbstractAspectJAdvisorFactory.AspectJAnnotationType> annotationTypeMap = Map.of(Pointcut.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtPointcut, Around.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAround, Before.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtBefore, After.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfter, AfterReturning.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterReturning, AfterThrowing.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterThrowing);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Annotation annotation;
/*     */ 
/*     */   
/*     */   private final AbstractAspectJAdvisorFactory.AspectJAnnotationType annotationType;
/*     */ 
/*     */   
/*     */   private final String pointcutExpression;
/*     */ 
/*     */   
/*     */   private final String argumentNames;
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectJAnnotation(Annotation annotation) {
/* 183 */     this.annotation = annotation;
/* 184 */     this.annotationType = determineAnnotationType(annotation);
/*     */     try {
/* 186 */       this.pointcutExpression = resolvePointcutExpression(annotation);
/* 187 */       Object argNames = AnnotationUtils.getValue(annotation, "argNames");
/* 188 */       String names = (String)argNames; this.argumentNames = (argNames instanceof String) ? names : "";
/*     */     }
/* 190 */     catch (Exception ex) {
/* 191 */       throw new IllegalArgumentException(String.valueOf(annotation) + " is not a valid AspectJ annotation", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private AbstractAspectJAdvisorFactory.AspectJAnnotationType determineAnnotationType(Annotation annotation) {
/* 196 */     AbstractAspectJAdvisorFactory.AspectJAnnotationType type = annotationTypeMap.get(annotation.annotationType());
/* 197 */     if (type != null) {
/* 198 */       return type;
/*     */     }
/* 200 */     throw new IllegalStateException("Unknown annotation type: " + String.valueOf(annotation));
/*     */   }
/*     */   
/*     */   private String resolvePointcutExpression(Annotation annotation) {
/* 204 */     for (String attributeName : EXPRESSION_ATTRIBUTES) {
/* 205 */       Object val = AnnotationUtils.getValue(annotation, attributeName);
/* 206 */       if (val instanceof String) { String str = (String)val; if (!str.isEmpty())
/* 207 */           return str;  }
/*     */     
/*     */     } 
/* 210 */     throw new IllegalStateException("Failed to resolve pointcut expression in: " + String.valueOf(annotation));
/*     */   }
/*     */   
/*     */   public AbstractAspectJAdvisorFactory.AspectJAnnotationType getAnnotationType() {
/* 214 */     return this.annotationType;
/*     */   }
/*     */   
/*     */   public Annotation getAnnotation() {
/* 218 */     return this.annotation;
/*     */   }
/*     */   
/*     */   public String getPointcutExpression() {
/* 222 */     return this.pointcutExpression;
/*     */   }
/*     */   
/*     */   public String getArgumentNames() {
/* 226 */     return this.argumentNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 231 */     return this.annotation.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AbstractAspectJAdvisorFactory$AspectJAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */