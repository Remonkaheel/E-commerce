/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ 


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AspectMetadata$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */