/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AspectJAdvisorBeanRegistrationAotProcessor
/*    */   implements BeanRegistrationAotProcessor
/*    */ {
/*    */   private static final String AJC_MAGIC = "ajc$";
/* 41 */   private static final boolean aspectjPresent = ClassUtils.isPresent("org.aspectj.lang.annotation.Pointcut", AspectJAdvisorBeanRegistrationAotProcessor.class
/* 42 */       .getClassLoader());
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 48 */     if (aspectjPresent) {
/* 49 */       Class<?> beanClass = registeredBean.getBeanClass();
/* 50 */       if (compiledByAjc(beanClass)) {
/* 51 */         return new AspectJAdvisorContribution(beanClass);
/*    */       }
/*    */     } 
/* 54 */     return null;
/*    */   }
/*    */   
/*    */   private static boolean compiledByAjc(Class<?> clazz) {
/* 58 */     for (Field field : clazz.getDeclaredFields()) {
/* 59 */       if (field.getName().startsWith("ajc$")) {
/* 60 */         return true;
/*    */       }
/*    */     } 
/* 63 */     return false;
/*    */   }
/*    */   
/*    */   private static class AspectJAdvisorContribution
/*    */     implements BeanRegistrationAotContribution
/*    */   {
/*    */     private final Class<?> beanClass;
/*    */     
/*    */     public AspectJAdvisorContribution(Class<?> beanClass) {
/* 72 */       this.beanClass = beanClass;
/*    */     }
/*    */ 
/*    */     
/*    */     public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 77 */       generationContext.getRuntimeHints().reflection().registerType(this.beanClass, new MemberCategory[] { MemberCategory.DECLARED_FIELDS });
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AspectJAdvisorBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */