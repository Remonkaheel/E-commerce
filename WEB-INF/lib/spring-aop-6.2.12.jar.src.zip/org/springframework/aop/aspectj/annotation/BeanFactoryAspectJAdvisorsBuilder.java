/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanFactoryAspectJAdvisorsBuilder
/*     */ {
/*  46 */   private static final Log logger = LogFactory.getLog(BeanFactoryAspectJAdvisorsBuilder.class);
/*     */   
/*     */   private final ListableBeanFactory beanFactory;
/*     */   
/*     */   private final AspectJAdvisorFactory advisorFactory;
/*     */   
/*     */   @Nullable
/*     */   private volatile List<String> aspectBeanNames;
/*     */   
/*  55 */   private final Map<String, List<Advisor>> advisorsCache = new ConcurrentHashMap<>();
/*     */   
/*  57 */   private final Map<String, MetadataAwareAspectInstanceFactory> aspectFactoryCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanFactoryAspectJAdvisorsBuilder(ListableBeanFactory beanFactory) {
/*  65 */     this(beanFactory, new ReflectiveAspectJAdvisorFactory((BeanFactory)beanFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanFactoryAspectJAdvisorsBuilder(ListableBeanFactory beanFactory, AspectJAdvisorFactory advisorFactory) {
/*  74 */     Assert.notNull(beanFactory, "ListableBeanFactory must not be null");
/*  75 */     Assert.notNull(advisorFactory, "AspectJAdvisorFactory must not be null");
/*  76 */     this.beanFactory = beanFactory;
/*  77 */     this.advisorFactory = advisorFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Advisor> buildAspectJAdvisors() {
/*  90 */     List<String> aspectNames = this.aspectBeanNames;
/*     */     
/*  92 */     if (aspectNames == null) {
/*  93 */       synchronized (this) {
/*  94 */         aspectNames = this.aspectBeanNames;
/*  95 */         if (aspectNames == null) {
/*  96 */           List<Advisor> list = new ArrayList<>();
/*  97 */           aspectNames = new ArrayList<>();
/*  98 */           String[] beanNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.beanFactory, Object.class, true, false);
/*     */           
/* 100 */           for (String beanName : beanNames) {
/* 101 */             if (isEligibleBean(beanName)) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 106 */               Class<?> beanType = this.beanFactory.getType(beanName, false);
/* 107 */               if (beanType != null)
/*     */               {
/*     */                 
/* 110 */                 if (this.advisorFactory.isAspect(beanType))
/*     */                   try {
/* 112 */                     AspectMetadata amd = new AspectMetadata(beanType, beanName);
/* 113 */                     if (amd.getAjType().getPerClause().getKind() == PerClauseKind.SINGLETON) {
/* 114 */                       MetadataAwareAspectInstanceFactory factory = new BeanFactoryAspectInstanceFactory((BeanFactory)this.beanFactory, beanName);
/*     */                       
/* 116 */                       List<Advisor> classAdvisors = this.advisorFactory.getAdvisors(factory);
/* 117 */                       if (this.beanFactory.isSingleton(beanName)) {
/* 118 */                         this.advisorsCache.put(beanName, classAdvisors);
/*     */                       } else {
/*     */                         
/* 121 */                         this.aspectFactoryCache.put(beanName, factory);
/*     */                       } 
/* 123 */                       list.addAll(classAdvisors);
/*     */                     }
/*     */                     else {
/*     */                       
/* 127 */                       if (this.beanFactory.isSingleton(beanName)) {
/* 128 */                         throw new IllegalArgumentException("Bean with name '" + beanName + "' is a singleton, but aspect instantiation model is not singleton");
/*     */                       }
/*     */                       
/* 131 */                       MetadataAwareAspectInstanceFactory factory = new PrototypeAspectInstanceFactory((BeanFactory)this.beanFactory, beanName);
/*     */                       
/* 133 */                       this.aspectFactoryCache.put(beanName, factory);
/* 134 */                       list.addAll(this.advisorFactory.getAdvisors(factory));
/*     */                     } 
/* 136 */                     aspectNames.add(beanName);
/*     */                   }
/* 138 */                   catch (IllegalArgumentException|IllegalStateException|org.springframework.aop.framework.AopConfigException ex) {
/* 139 */                     if (logger.isDebugEnabled())
/* 140 */                       logger.debug("Ignoring incompatible aspect [" + beanType.getName() + "]: " + String.valueOf(ex)); 
/*     */                   }  
/*     */               }
/*     */             } 
/*     */           } 
/* 145 */           this.aspectBeanNames = aspectNames;
/* 146 */           return list;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 151 */     if (aspectNames.isEmpty()) {
/* 152 */       return Collections.emptyList();
/*     */     }
/* 154 */     List<Advisor> advisors = new ArrayList<>();
/* 155 */     for (String aspectName : aspectNames) {
/* 156 */       List<Advisor> cachedAdvisors = this.advisorsCache.get(aspectName);
/* 157 */       if (cachedAdvisors != null) {
/* 158 */         advisors.addAll(cachedAdvisors);
/*     */         continue;
/*     */       } 
/* 161 */       MetadataAwareAspectInstanceFactory factory = this.aspectFactoryCache.get(aspectName);
/* 162 */       advisors.addAll(this.advisorFactory.getAdvisors(factory));
/*     */     } 
/*     */     
/* 165 */     return advisors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEligibleBean(String beanName) {
/* 174 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\BeanFactoryAspectJAdvisorsBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */