/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.AspectJPrecedenceInformation;
/*     */ import org.springframework.aop.aspectj.InstantiationModelAwarePointcutAdvisor;
/*     */ import org.springframework.aop.support.DynamicMethodMatcherPointcut;
/*     */ import org.springframework.aop.support.Pointcuts;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InstantiationModelAwarePointcutAdvisorImpl
/*     */   implements InstantiationModelAwarePointcutAdvisor, AspectJPrecedenceInformation, Serializable
/*     */ {
/*  51 */   private static final Advice EMPTY_ADVICE = new Advice()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */   
/*     */   private final AspectJExpressionPointcut declaredPointcut;
/*     */   
/*     */   private final Class<?> declaringClass;
/*     */   
/*     */   private final String methodName;
/*     */   
/*     */   private final Class<?>[] parameterTypes;
/*     */   
/*     */   private transient Method aspectJAdviceMethod;
/*     */   
/*     */   private final AspectJAdvisorFactory aspectJAdvisorFactory;
/*     */   
/*     */   private final MetadataAwareAspectInstanceFactory aspectInstanceFactory;
/*     */   
/*     */   private final int declarationOrder;
/*     */   
/*     */   private final String aspectName;
/*     */   
/*     */   private final Pointcut pointcut;
/*     */   
/*     */   private final boolean lazy;
/*     */   
/*     */   @Nullable
/*     */   private Advice instantiatedAdvice;
/*     */   
/*     */   @Nullable
/*     */   private Boolean isBeforeAdvice;
/*     */   
/*     */   @Nullable
/*     */   private Boolean isAfterAdvice;
/*     */ 
/*     */   
/*     */   public InstantiationModelAwarePointcutAdvisorImpl(AspectJExpressionPointcut declaredPointcut, Method aspectJAdviceMethod, AspectJAdvisorFactory aspectJAdvisorFactory, MetadataAwareAspectInstanceFactory aspectInstanceFactory, int declarationOrder, String aspectName) {
/*  90 */     this.declaredPointcut = declaredPointcut;
/*  91 */     this.declaringClass = aspectJAdviceMethod.getDeclaringClass();
/*  92 */     this.methodName = aspectJAdviceMethod.getName();
/*  93 */     this.parameterTypes = aspectJAdviceMethod.getParameterTypes();
/*  94 */     this.aspectJAdviceMethod = aspectJAdviceMethod;
/*  95 */     this.aspectJAdvisorFactory = aspectJAdvisorFactory;
/*  96 */     this.aspectInstanceFactory = aspectInstanceFactory;
/*  97 */     this.declarationOrder = declarationOrder;
/*  98 */     this.aspectName = aspectName;
/*     */     
/* 100 */     if (aspectInstanceFactory.getAspectMetadata().isLazilyInstantiated()) {
/*     */       
/* 102 */       Pointcut preInstantiationPointcut = Pointcuts.union(aspectInstanceFactory
/* 103 */           .getAspectMetadata().getPerClausePointcut(), (Pointcut)this.declaredPointcut);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       this.pointcut = (Pointcut)new PerTargetInstantiationModelPointcut(this.declaredPointcut, preInstantiationPointcut, aspectInstanceFactory);
/*     */       
/* 110 */       this.lazy = true;
/*     */     }
/*     */     else {
/*     */       
/* 114 */       this.pointcut = (Pointcut)this.declaredPointcut;
/* 115 */       this.lazy = false;
/* 116 */       this.instantiatedAdvice = instantiateAdvice(this.declaredPointcut);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 127 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLazy() {
/* 132 */     return this.lazy;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean isAdviceInstantiated() {
/* 137 */     return (this.instantiatedAdvice != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Advice getAdvice() {
/* 145 */     if (this.instantiatedAdvice == null) {
/* 146 */       this.instantiatedAdvice = instantiateAdvice(this.declaredPointcut);
/*     */     }
/* 148 */     return this.instantiatedAdvice;
/*     */   }
/*     */   
/*     */   private Advice instantiateAdvice(AspectJExpressionPointcut pointcut) {
/* 152 */     Advice advice = this.aspectJAdvisorFactory.getAdvice(this.aspectJAdviceMethod, pointcut, this.aspectInstanceFactory, this.declarationOrder, this.aspectName);
/*     */     
/* 154 */     return (advice != null) ? advice : EMPTY_ADVICE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 164 */     return (getAspectMetadata().getAjType().getPerClause().getKind() != PerClauseKind.SINGLETON);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AspectMetadata getAspectMetadata() {
/* 171 */     return this.aspectInstanceFactory.getAspectMetadata();
/*     */   }
/*     */   
/*     */   public MetadataAwareAspectInstanceFactory getAspectInstanceFactory() {
/* 175 */     return this.aspectInstanceFactory;
/*     */   }
/*     */   
/*     */   public AspectJExpressionPointcut getDeclaredPointcut() {
/* 179 */     return this.declaredPointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 184 */     return this.aspectInstanceFactory.getOrder();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAspectName() {
/* 189 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDeclarationOrder() {
/* 194 */     return this.declarationOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBeforeAdvice() {
/* 200 */     if (this.isBeforeAdvice == null) {
/* 201 */       determineAdviceType();
/*     */     }
/* 203 */     return this.isBeforeAdvice.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAfterAdvice() {
/* 209 */     if (this.isAfterAdvice == null) {
/* 210 */       determineAdviceType();
/*     */     }
/* 212 */     return this.isAfterAdvice.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void determineAdviceType() {
/* 221 */     AbstractAspectJAdvisorFactory.AspectJAnnotation aspectJAnnotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(this.aspectJAdviceMethod);
/* 222 */     if (aspectJAnnotation == null) {
/* 223 */       this.isBeforeAdvice = Boolean.valueOf(false);
/* 224 */       this.isAfterAdvice = Boolean.valueOf(false);
/*     */     } else {
/*     */       
/* 227 */       switch (aspectJAnnotation.getAnnotationType()) { case AtPointcut:
/*     */         case AtAround:
/* 229 */           this.isBeforeAdvice = Boolean.valueOf(false);
/* 230 */           this.isAfterAdvice = Boolean.valueOf(false);
/*     */           break;
/*     */         case AtBefore:
/* 233 */           this.isBeforeAdvice = Boolean.valueOf(true);
/* 234 */           this.isAfterAdvice = Boolean.valueOf(false); break;
/*     */         case AtAfter: case AtAfterReturning:
/*     */         case AtAfterThrowing:
/* 237 */           this.isBeforeAdvice = Boolean.valueOf(false);
/* 238 */           this.isAfterAdvice = Boolean.valueOf(true);
/*     */           break; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException {
/* 246 */     inputStream.defaultReadObject();
/*     */     try {
/* 248 */       this.aspectJAdviceMethod = this.declaringClass.getMethod(this.methodName, this.parameterTypes);
/*     */     }
/* 250 */     catch (NoSuchMethodException ex) {
/* 251 */       throw new IllegalStateException("Failed to find advice method on deserialization", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 257 */     return "InstantiationModelAwarePointcutAdvisor: expression [" + getDeclaredPointcut().getExpression() + "]; advice method [" + String.valueOf(this.aspectJAdviceMethod) + "]; perClauseKind=" + 
/*     */       
/* 259 */       String.valueOf(this.aspectInstanceFactory.getAspectMetadata().getAjType().getPerClause().getKind());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class PerTargetInstantiationModelPointcut
/*     */     extends DynamicMethodMatcherPointcut
/*     */   {
/*     */     private final AspectJExpressionPointcut declaredPointcut;
/*     */ 
/*     */     
/*     */     private final Pointcut preInstantiationPointcut;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private LazySingletonAspectInstanceFactoryDecorator aspectInstanceFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     public PerTargetInstantiationModelPointcut(AspectJExpressionPointcut declaredPointcut, Pointcut preInstantiationPointcut, MetadataAwareAspectInstanceFactory aspectInstanceFactory) {
/* 280 */       this.declaredPointcut = declaredPointcut;
/* 281 */       this.preInstantiationPointcut = preInstantiationPointcut;
/* 282 */       if (aspectInstanceFactory instanceof LazySingletonAspectInstanceFactoryDecorator) { LazySingletonAspectInstanceFactoryDecorator lazyFactory = (LazySingletonAspectInstanceFactoryDecorator)aspectInstanceFactory;
/* 283 */         this.aspectInstanceFactory = lazyFactory; }
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 291 */       return ((isAspectMaterialized() && this.declaredPointcut.matches(method, targetClass)) || this.preInstantiationPointcut
/* 292 */         .getMethodMatcher().matches(method, targetClass));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, Object... args) {
/* 298 */       return (isAspectMaterialized() && this.declaredPointcut.matches(method, targetClass, args));
/*     */     }
/*     */     
/*     */     private boolean isAspectMaterialized() {
/* 302 */       return (this.aspectInstanceFactory == null || this.aspectInstanceFactory.isMaterialized());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 311 */       if (this != other) { if (other instanceof PerTargetInstantiationModelPointcut) { PerTargetInstantiationModelPointcut that = (PerTargetInstantiationModelPointcut)other;
/* 312 */           if (ObjectUtils.nullSafeEquals(this.preInstantiationPointcut, that.preInstantiationPointcut)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 317 */       return ObjectUtils.nullSafeHashCode(this.declaredPointcut.getExpression());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 322 */       return PerTargetInstantiationModelPointcut.class.getName() + ": " + PerTargetInstantiationModelPointcut.class.getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\InstantiationModelAwarePointcutAdvisorImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */