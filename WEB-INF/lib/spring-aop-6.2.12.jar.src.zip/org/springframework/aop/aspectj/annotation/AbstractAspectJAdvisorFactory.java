/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.aspectj.lang.annotation.After;
/*     */ import org.aspectj.lang.annotation.AfterReturning;
/*     */ import org.aspectj.lang.annotation.AfterThrowing;
/*     */ import org.aspectj.lang.annotation.Around;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.annotation.Before;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAspectJAdvisorFactory
/*     */   implements AspectJAdvisorFactory
/*     */ {
/*  60 */   private static final Class<?>[] ASPECTJ_ANNOTATION_CLASSES = new Class[] { Pointcut.class, Around.class, Before.class, After.class, AfterReturning.class, AfterThrowing.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String AJC_MAGIC = "ajc$";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String IGNORE_AJC_PROPERTY_NAME = "spring.aop.ajc.ignore";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final boolean shouldIgnoreAjcCompiledAspects = SpringProperties.getFlag("spring.aop.ajc.ignore");
/*     */ 
/*     */ 
/*     */   
/*  82 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  84 */   protected final ParameterNameDiscoverer parameterNameDiscoverer = new AspectJAnnotationParameterNameDiscoverer();
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAspect(Class<?> clazz) {
/*  89 */     return (AnnotationUtils.findAnnotation(clazz, Aspect.class) != null && (!shouldIgnoreAjcCompiledAspects || 
/*  90 */       !compiledByAjc(clazz)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void validate(Class<?> aspectClass) throws AopConfigException {
/*  95 */     AjType<?> ajType = AjTypeSystem.getAjType(aspectClass);
/*  96 */     if (!ajType.isAspect()) {
/*  97 */       throw new NotAnAtAspectException(aspectClass);
/*     */     }
/*  99 */     if (ajType.getPerClause().getKind() == PerClauseKind.PERCFLOW) {
/* 100 */       throw new AopConfigException(aspectClass.getName() + " uses percflow instantiation model: This is not supported in Spring AOP.");
/*     */     }
/*     */     
/* 103 */     if (ajType.getPerClause().getKind() == PerClauseKind.PERCFLOWBELOW) {
/* 104 */       throw new AopConfigException(aspectClass.getName() + " uses percflowbelow instantiation model: This is not supported in Spring AOP.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected static AspectJAnnotation findAspectJAnnotationOnMethod(Method method) {
/* 117 */     for (Class<?> annotationType : ASPECTJ_ANNOTATION_CLASSES) {
/* 118 */       AspectJAnnotation annotation = findAnnotation(method, (Class)annotationType);
/* 119 */       if (annotation != null) {
/* 120 */         return annotation;
/*     */       }
/*     */     } 
/* 123 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static AspectJAnnotation findAnnotation(Method method, Class<? extends Annotation> annotationType) {
/* 128 */     Annotation annotation = AnnotationUtils.findAnnotation(method, annotationType);
/* 129 */     if (annotation != null) {
/* 130 */       return new AspectJAnnotation(annotation);
/*     */     }
/*     */     
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean compiledByAjc(Class<?> clazz) {
/* 138 */     for (Field field : clazz.getDeclaredFields()) {
/* 139 */       if (field.getName().startsWith("ajc$")) {
/* 140 */         return true;
/*     */       }
/*     */     } 
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected enum AspectJAnnotationType
/*     */   {
/* 153 */     AtPointcut, AtAround, AtBefore, AtAfter, AtAfterReturning, AtAfterThrowing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class AspectJAnnotation
/*     */   {
/* 163 */     private static final String[] EXPRESSION_ATTRIBUTES = new String[] { "pointcut", "value" };
/*     */     
/* 165 */     private static final Map<Class<?>, AbstractAspectJAdvisorFactory.AspectJAnnotationType> annotationTypeMap = Map.of(Pointcut.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtPointcut, Around.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAround, Before.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtBefore, After.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfter, AfterReturning.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterReturning, AfterThrowing.class, AbstractAspectJAdvisorFactory.AspectJAnnotationType.AtAfterThrowing);
/*     */ 
/*     */ 
/*     */     
/*     */     private final Annotation annotation;
/*     */ 
/*     */     
/*     */     private final AbstractAspectJAdvisorFactory.AspectJAnnotationType annotationType;
/*     */ 
/*     */     
/*     */     private final String pointcutExpression;
/*     */ 
/*     */     
/*     */     private final String argumentNames;
/*     */ 
/*     */ 
/*     */     
/*     */     public AspectJAnnotation(Annotation annotation) {
/* 183 */       this.annotation = annotation;
/* 184 */       this.annotationType = determineAnnotationType(annotation);
/*     */       try {
/* 186 */         this.pointcutExpression = resolvePointcutExpression(annotation);
/* 187 */         Object argNames = AnnotationUtils.getValue(annotation, "argNames");
/* 188 */         String names = (String)argNames; this.argumentNames = (argNames instanceof String) ? names : "";
/*     */       }
/* 190 */       catch (Exception ex) {
/* 191 */         throw new IllegalArgumentException(String.valueOf(annotation) + " is not a valid AspectJ annotation", ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private AbstractAspectJAdvisorFactory.AspectJAnnotationType determineAnnotationType(Annotation annotation) {
/* 196 */       AbstractAspectJAdvisorFactory.AspectJAnnotationType type = annotationTypeMap.get(annotation.annotationType());
/* 197 */       if (type != null) {
/* 198 */         return type;
/*     */       }
/* 200 */       throw new IllegalStateException("Unknown annotation type: " + String.valueOf(annotation));
/*     */     }
/*     */     
/*     */     private String resolvePointcutExpression(Annotation annotation) {
/* 204 */       for (String attributeName : EXPRESSION_ATTRIBUTES) {
/* 205 */         Object val = AnnotationUtils.getValue(annotation, attributeName);
/* 206 */         if (val instanceof String) { String str = (String)val; if (!str.isEmpty())
/* 207 */             return str;  }
/*     */       
/*     */       } 
/* 210 */       throw new IllegalStateException("Failed to resolve pointcut expression in: " + String.valueOf(annotation));
/*     */     }
/*     */     
/*     */     public AbstractAspectJAdvisorFactory.AspectJAnnotationType getAnnotationType() {
/* 214 */       return this.annotationType;
/*     */     }
/*     */     
/*     */     public Annotation getAnnotation() {
/* 218 */       return this.annotation;
/*     */     }
/*     */     
/*     */     public String getPointcutExpression() {
/* 222 */       return this.pointcutExpression;
/*     */     }
/*     */     
/*     */     public String getArgumentNames() {
/* 226 */       return this.argumentNames;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 231 */       return this.annotation.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AspectJAnnotationParameterNameDiscoverer
/*     */     implements ParameterNameDiscoverer
/*     */   {
/* 242 */     private static final String[] EMPTY_ARRAY = new String[0];
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String[] getParameterNames(Method method) {
/* 247 */       if (method.getParameterCount() == 0) {
/* 248 */         return EMPTY_ARRAY;
/*     */       }
/* 250 */       AbstractAspectJAdvisorFactory.AspectJAnnotation annotation = AbstractAspectJAdvisorFactory.findAspectJAnnotationOnMethod(method);
/* 251 */       if (annotation == null) {
/* 252 */         return null;
/*     */       }
/* 254 */       StringTokenizer nameTokens = new StringTokenizer(annotation.getArgumentNames(), ",");
/* 255 */       int numTokens = nameTokens.countTokens();
/* 256 */       if (numTokens > 0) {
/* 257 */         String[] names = new String[numTokens];
/* 258 */         for (int i = 0; i < names.length; i++) {
/* 259 */           names[i] = nameTokens.nextToken();
/*     */         }
/* 261 */         return names;
/*     */       } 
/*     */       
/* 264 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String[] getParameterNames(Constructor<?> ctor) {
/* 271 */       throw new UnsupportedOperationException("Spring AOP cannot handle constructor advice");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AbstractAspectJAdvisorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */