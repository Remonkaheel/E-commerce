/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.aspectj.AbstractAspectJAdvice;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.ExecutableMode;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AspectContribution
/*    */   implements BeanFactoryInitializationAotContribution
/*    */ {
/*    */   private final List<Advisor> advisors;
/*    */   
/*    */   public AspectContribution(List<Advisor> advisors) {
/* 76 */     this.advisors = advisors;
/*    */   }
/*    */ 
/*    */   
/*    */   public void applyTo(GenerationContext generationContext, BeanFactoryInitializationCode beanFactoryInitializationCode) {
/* 81 */     ReflectionHints reflectionHints = generationContext.getRuntimeHints().reflection();
/* 82 */     for (Advisor advisor : this.advisors) {
/* 83 */       Advice advice = advisor.getAdvice(); if (advice instanceof AbstractAspectJAdvice) { AbstractAspectJAdvice aspectJAdvice = (AbstractAspectJAdvice)advice;
/* 84 */         reflectionHints.registerMethod(aspectJAdvice.getAspectJAdviceMethod(), ExecutableMode.INVOKE); }
/*    */     
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AspectJBeanFactoryInitializationAotProcessor$AspectContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */