/*     */ package org.springframework.aop.aspectj.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.reflect.AjType;
/*     */ import org.aspectj.lang.reflect.AjTypeSystem;
/*     */ import org.aspectj.lang.reflect.PerClauseKind;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.aspectj.AspectJExpressionPointcut;
/*     */ import org.springframework.aop.aspectj.TypePatternClassFilter;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AspectMetadata
/*     */   implements Serializable
/*     */ {
/*     */   private final String aspectName;
/*     */   private final Class<?> aspectClass;
/*     */   private transient AjType<?> ajType;
/*     */   private final Pointcut perClausePointcut;
/*     */   
/*     */   public AspectMetadata(Class<?> aspectClass, String aspectName) {
/*     */     AspectJExpressionPointcut ajexp;
/*  82 */     this.aspectName = aspectName;
/*     */     
/*  84 */     Class<?> currClass = aspectClass;
/*  85 */     AjType<?> ajType = null;
/*  86 */     while (currClass != Object.class) {
/*  87 */       AjType<?> ajTypeToCheck = AjTypeSystem.getAjType(currClass);
/*  88 */       if (ajTypeToCheck.isAspect()) {
/*  89 */         ajType = ajTypeToCheck;
/*     */         break;
/*     */       } 
/*  92 */       currClass = currClass.getSuperclass();
/*     */     } 
/*  94 */     if (ajType == null) {
/*  95 */       throw new IllegalArgumentException("Class '" + aspectClass.getName() + "' is not an @AspectJ aspect");
/*     */     }
/*  97 */     if ((ajType.getDeclarePrecedence()).length > 0) {
/*  98 */       throw new IllegalArgumentException("DeclarePrecedence not presently supported in Spring AOP");
/*     */     }
/* 100 */     this.aspectClass = ajType.getJavaClass();
/* 101 */     this.ajType = ajType;
/*     */     
/* 103 */     switch (this.ajType.getPerClause().getKind()) {
/*     */       case SINGLETON:
/* 105 */         this.perClausePointcut = Pointcut.TRUE; return;
/*     */       case PERTARGET:
/*     */       case PERTHIS:
/* 108 */         ajexp = new AspectJExpressionPointcut();
/* 109 */         ajexp.setLocation(aspectClass.getName());
/* 110 */         ajexp.setExpression(findPerClause(aspectClass));
/* 111 */         ajexp.setPointcutDeclarationScope(aspectClass);
/* 112 */         this.perClausePointcut = (Pointcut)ajexp;
/*     */         return;
/*     */       
/*     */       case PERTYPEWITHIN:
/* 116 */         this.perClausePointcut = (Pointcut)new ComposablePointcut((ClassFilter)new TypePatternClassFilter(findPerClause(aspectClass))); return;
/*     */     } 
/* 118 */     throw new AopConfigException("PerClause " + 
/* 119 */         String.valueOf(ajType.getPerClause().getKind()) + " not supported by Spring AOP for " + String.valueOf(aspectClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String findPerClause(Class<?> aspectClass) {
/* 127 */     Aspect ann = aspectClass.<Aspect>getAnnotation(Aspect.class);
/* 128 */     if (ann == null) {
/* 129 */       return "";
/*     */     }
/* 131 */     String value = ann.value();
/* 132 */     int beginIndex = value.indexOf('(');
/* 133 */     if (beginIndex < 0) {
/* 134 */       return "";
/*     */     }
/* 136 */     return value.substring(beginIndex + 1, value.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AjType<?> getAjType() {
/* 144 */     return this.ajType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getAspectClass() {
/* 151 */     return this.aspectClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAspectName() {
/* 158 */     return this.aspectName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPerClausePointcut() {
/* 166 */     return this.perClausePointcut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPerThisOrPerTarget() {
/* 173 */     PerClauseKind kind = getAjType().getPerClause().getKind();
/* 174 */     return (kind == PerClauseKind.PERTARGET || kind == PerClauseKind.PERTHIS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPerTypeWithin() {
/* 181 */     PerClauseKind kind = getAjType().getPerClause().getKind();
/* 182 */     return (kind == PerClauseKind.PERTYPEWITHIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLazilyInstantiated() {
/* 189 */     return (isPerThisOrPerTarget() || isPerTypeWithin());
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException {
/* 194 */     inputStream.defaultReadObject();
/* 195 */     this.ajType = AjTypeSystem.getAjType(this.aspectClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\annotation\AspectMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */