/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.aspectj.weaver.tools.ShadowMatch;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ShadowMatchUtils
/*    */ {
/* 35 */   private static final Map<Object, ShadowMatch> shadowMatchCache = new ConcurrentHashMap<>(256);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   static ShadowMatch getShadowMatch(Object key) {
/* 46 */     return shadowMatchCache.get(key);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ShadowMatch setShadowMatch(Object key, ShadowMatch shadowMatch) {
/* 58 */     ShadowMatch existing = shadowMatchCache.putIfAbsent(key, shadowMatch);
/* 59 */     return (existing != null) ? existing : shadowMatch;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void clearCache() {
/* 66 */     shadowMatchCache.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\ShadowMatchUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */