/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import org.aspectj.weaver.ReferenceType;
/*     */ import org.aspectj.weaver.ReferenceTypeDelegate;
/*     */ import org.aspectj.weaver.ResolvedType;
/*     */ import org.aspectj.weaver.ast.Instanceof;
/*     */ import org.aspectj.weaver.ast.Test;
/*     */ import org.aspectj.weaver.reflect.ReflectionVar;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class InstanceOfResidueTestVisitor
/*     */   extends RuntimeTestWalker.TestVisitorAdapter
/*     */ {
/*     */   private final Class<?> matchClass;
/*     */   private boolean matches;
/*     */   private final int matchVarType;
/*     */   
/*     */   public InstanceOfResidueTestVisitor(Class<?> matchClass, boolean defaultMatches, int matchVarType) {
/* 187 */     this.matchClass = matchClass;
/* 188 */     this.matches = defaultMatches;
/* 189 */     this.matchVarType = matchVarType;
/*     */   }
/*     */   
/*     */   public boolean instanceOfMatches(Test test) {
/* 193 */     test.accept(this);
/* 194 */     return this.matches;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Instanceof i) {
/* 199 */     int varType = getVarType((ReflectionVar)i.getVar());
/* 200 */     if (varType != this.matchVarType) {
/*     */       return;
/*     */     }
/* 203 */     Class<?> typeClass = null;
/* 204 */     ResolvedType type = (ResolvedType)i.getType();
/* 205 */     if (type instanceof ReferenceType) { ReferenceType referenceType = (ReferenceType)type;
/* 206 */       ReferenceTypeDelegate delegate = referenceType.getDelegate();
/* 207 */       if (delegate instanceof org.aspectj.weaver.reflect.ReflectionBasedReferenceTypeDelegate) {
/*     */         try {
/* 209 */           ReflectionUtils.makeAccessible(RuntimeTestWalker.myClassField);
/* 210 */           typeClass = (Class)RuntimeTestWalker.myClassField.get(delegate);
/*     */         }
/* 212 */         catch (IllegalAccessException ex) {
/* 213 */           throw new IllegalStateException(ex);
/*     */         } 
/*     */       } }
/*     */ 
/*     */     
/*     */     try {
/* 219 */       if (typeClass == null) {
/* 220 */         typeClass = ClassUtils.forName(type.getName(), this.matchClass.getClassLoader());
/*     */       }
/* 222 */       this.matches = typeClass.isAssignableFrom(this.matchClass);
/*     */     }
/* 224 */     catch (ClassNotFoundException ex) {
/* 225 */       this.matches = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\RuntimeTestWalker$InstanceOfResidueTestVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */