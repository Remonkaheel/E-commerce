/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import org.aspectj.weaver.ast.And;
/*     */ import org.aspectj.weaver.ast.Call;
/*     */ import org.aspectj.weaver.ast.FieldGetCall;
/*     */ import org.aspectj.weaver.ast.HasAnnotation;
/*     */ import org.aspectj.weaver.ast.ITestVisitor;
/*     */ import org.aspectj.weaver.ast.Instanceof;
/*     */ import org.aspectj.weaver.ast.Literal;
/*     */ import org.aspectj.weaver.ast.Not;
/*     */ import org.aspectj.weaver.ast.Or;
/*     */ import org.aspectj.weaver.internal.tools.MatchingContextBasedTest;
/*     */ import org.aspectj.weaver.reflect.ReflectionVar;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TestVisitorAdapter
/*     */   implements ITestVisitor
/*     */ {
/*     */   protected static final int THIS_VAR = 0;
/*     */   protected static final int TARGET_VAR = 1;
/*     */   protected static final int AT_THIS_VAR = 3;
/*     */   protected static final int AT_TARGET_VAR = 4;
/*     */   protected static final int AT_ANNOTATION_VAR = 8;
/*     */   
/*     */   public void visit(And e) {
/* 127 */     e.getLeft().accept(this);
/* 128 */     e.getRight().accept(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Or e) {
/* 133 */     e.getLeft().accept(this);
/* 134 */     e.getRight().accept(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(Not e) {
/* 139 */     e.getBody().accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Instanceof i) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Literal literal) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Call call) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(FieldGetCall fieldGetCall) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(HasAnnotation hasAnnotation) {}
/*     */ 
/*     */   
/*     */   public void visit(MatchingContextBasedTest matchingContextTest) {}
/*     */ 
/*     */   
/*     */   protected int getVarType(ReflectionVar v) {
/*     */     try {
/* 168 */       ReflectionUtils.makeAccessible(RuntimeTestWalker.varTypeField);
/* 169 */       return ((Integer)RuntimeTestWalker.varTypeField.get(v)).intValue();
/*     */     }
/* 171 */     catch (IllegalAccessException ex) {
/* 172 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\aspectj\RuntimeTestWalker$TestVisitorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */