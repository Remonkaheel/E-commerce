package org.springframework.aop;

public interface IntroductionInfo {
  Class<?>[] getInterfaces();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\IntroductionInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */