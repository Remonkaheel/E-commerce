/*    */ package org.springframework.aop;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TargetSource
/*    */   extends TargetClassAware
/*    */ {
/*    */   @Nullable
/*    */   Class<?> getTargetClass();
/*    */   
/*    */   default boolean isStatic() {
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   Object getTarget() throws Exception;
/*    */   
/*    */   default void releaseTarget(Object target) throws Exception {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\TargetSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */