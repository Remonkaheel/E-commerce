package org.springframework.aop;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.lang.Nullable;

public interface ProxyMethodInvocation extends MethodInvocation {
  Object getProxy();
  
  MethodInvocation invocableClone();
  
  MethodInvocation invocableClone(Object... paramVarArgs);
  
  void setArguments(Object... paramVarArgs);
  
  void setUserAttribute(String paramString, @Nullable Object paramObject);
  
  @Nullable
  Object getUserAttribute(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\ProxyMethodInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */