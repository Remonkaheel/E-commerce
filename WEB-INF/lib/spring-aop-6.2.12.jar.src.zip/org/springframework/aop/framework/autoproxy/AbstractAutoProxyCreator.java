/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyConfig;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.framework.ProxyProcessorSupport;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.target.EmptyTargetSource;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAutoProxyCreator
/*     */   extends ProxyProcessorSupport
/*     */   implements SmartInstantiationAwareBeanPostProcessor, BeanFactoryAware
/*     */ {
/*     */   @Nullable
/* 105 */   protected static final Object[] DO_NOT_PROXY = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   protected static final Object[] PROXY_WITHOUT_ADDITIONAL_INTERCEPTORS = new Object[0];
/*     */ 
/*     */ 
/*     */   
/* 116 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/* 119 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean freezeProxy = false;
/*     */ 
/*     */ 
/*     */   
/* 128 */   private String[] interceptorNames = new String[0];
/*     */   
/*     */   private boolean applyCommonInterceptorsFirst = true;
/*     */   
/*     */   @Nullable
/*     */   private TargetSourceCreator[] customTargetSourceCreators;
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/* 138 */   private final Set<String> targetSourcedBeans = ConcurrentHashMap.newKeySet(16);
/*     */   
/* 140 */   private final Map<Object, Object> earlyBeanReferences = new ConcurrentHashMap<>(16);
/*     */   
/* 142 */   private final Map<Object, Class<?>> proxyTypes = new ConcurrentHashMap<>(16);
/*     */   
/* 144 */   private final Map<Object, Boolean> advisedBeans = new ConcurrentHashMap<>(256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrozen(boolean frozen) {
/* 155 */     this.freezeProxy = frozen;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFrozen() {
/* 160 */     return this.freezeProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry) {
/* 169 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomTargetSourceCreators(TargetSourceCreator... targetSourceCreators) {
/* 187 */     this.customTargetSourceCreators = targetSourceCreators;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterceptorNames(String... interceptorNames) {
/* 198 */     this.interceptorNames = interceptorNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplyCommonInterceptorsFirst(boolean applyCommonInterceptorsFirst) {
/* 206 */     this.applyCommonInterceptorsFirst = applyCommonInterceptorsFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 211 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected BeanFactory getBeanFactory() {
/* 220 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> predictBeanType(Class<?> beanClass, String beanName) {
/* 227 */     if (this.proxyTypes.isEmpty()) {
/* 228 */       return null;
/*     */     }
/* 230 */     Object cacheKey = getCacheKey(beanClass, beanName);
/* 231 */     return this.proxyTypes.get(cacheKey);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> determineBeanType(Class<?> beanClass, String beanName) {
/* 236 */     Object cacheKey = getCacheKey(beanClass, beanName);
/* 237 */     Class<?> proxyType = this.proxyTypes.get(cacheKey);
/* 238 */     if (proxyType == null) {
/* 239 */       EmptyTargetSource emptyTargetSource; TargetSource targetSource = getCustomTargetSource(beanClass, beanName);
/* 240 */       if (targetSource != null) {
/* 241 */         if (StringUtils.hasLength(beanName)) {
/* 242 */           this.targetSourcedBeans.add(beanName);
/*     */         }
/*     */       } else {
/*     */         
/* 246 */         emptyTargetSource = EmptyTargetSource.forClass(beanClass);
/*     */       } 
/* 248 */       Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(beanClass, beanName, (TargetSource)emptyTargetSource);
/* 249 */       if (specificInterceptors != DO_NOT_PROXY) {
/* 250 */         this.advisedBeans.put(cacheKey, Boolean.TRUE);
/* 251 */         proxyType = createProxyClass(beanClass, beanName, specificInterceptors, (TargetSource)emptyTargetSource);
/* 252 */         this.proxyTypes.put(cacheKey, proxyType);
/*     */       } 
/*     */     } 
/* 255 */     return (proxyType != null) ? proxyType : beanClass;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Constructor<?>[] determineCandidateConstructors(Class<?> beanClass, String beanName) {
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEarlyBeanReference(Object bean, String beanName) {
/* 266 */     Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 267 */     this.earlyBeanReferences.put(cacheKey, bean);
/* 268 */     return wrapIfNecessary(bean, beanName, cacheKey);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) {
/* 274 */     Object cacheKey = getCacheKey(beanClass, beanName);
/*     */     
/* 276 */     if (!StringUtils.hasLength(beanName) || !this.targetSourcedBeans.contains(beanName)) {
/* 277 */       if (this.advisedBeans.containsKey(cacheKey)) {
/* 278 */         return null;
/*     */       }
/* 280 */       if (isInfrastructureClass(beanClass) || shouldSkip(beanClass, beanName)) {
/* 281 */         this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 282 */         return null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     TargetSource targetSource = getCustomTargetSource(beanClass, beanName);
/* 290 */     if (targetSource != null) {
/* 291 */       if (StringUtils.hasLength(beanName)) {
/* 292 */         this.targetSourcedBeans.add(beanName);
/*     */       }
/* 294 */       Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(beanClass, beanName, targetSource);
/* 295 */       Object proxy = createProxy(beanClass, beanName, specificInterceptors, targetSource);
/* 296 */       this.proxyTypes.put(cacheKey, proxy.getClass());
/* 297 */       return proxy;
/*     */     } 
/*     */     
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) {
/* 305 */     return pvs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object postProcessAfterInitialization(@Nullable Object bean, String beanName) {
/* 316 */     if (bean != null) {
/* 317 */       Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 318 */       if (this.earlyBeanReferences.remove(cacheKey) != bean) {
/* 319 */         return wrapIfNecessary(bean, beanName, cacheKey);
/*     */       }
/*     */     } 
/* 322 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getCacheKey(Class<?> beanClass, @Nullable String beanName) {
/* 338 */     if (StringUtils.hasLength(beanName)) {
/* 339 */       return FactoryBean.class.isAssignableFrom(beanClass) ? ("&" + 
/* 340 */         beanName) : beanName;
/*     */     }
/*     */     
/* 343 */     return beanClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object wrapIfNecessary(Object bean, String beanName, Object cacheKey) {
/* 355 */     if (StringUtils.hasLength(beanName) && this.targetSourcedBeans.contains(beanName)) {
/* 356 */       return bean;
/*     */     }
/* 358 */     if (Boolean.FALSE.equals(this.advisedBeans.get(cacheKey))) {
/* 359 */       return bean;
/*     */     }
/* 361 */     if (isInfrastructureClass(bean.getClass()) || shouldSkip(bean.getClass(), beanName)) {
/* 362 */       this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 363 */       return bean;
/*     */     } 
/*     */ 
/*     */     
/* 367 */     Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(bean.getClass(), beanName, (TargetSource)null);
/* 368 */     if (specificInterceptors != DO_NOT_PROXY) {
/* 369 */       this.advisedBeans.put(cacheKey, Boolean.TRUE);
/* 370 */       Object proxy = createProxy(bean
/* 371 */           .getClass(), beanName, specificInterceptors, (TargetSource)new SingletonTargetSource(bean));
/* 372 */       this.proxyTypes.put(cacheKey, proxy.getClass());
/* 373 */       return proxy;
/*     */     } 
/*     */     
/* 376 */     this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 377 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInfrastructureClass(Class<?> beanClass) {
/* 396 */     boolean retVal = (Advice.class.isAssignableFrom(beanClass) || Pointcut.class.isAssignableFrom(beanClass) || Advisor.class.isAssignableFrom(beanClass) || AopInfrastructureBean.class.isAssignableFrom(beanClass));
/* 397 */     if (retVal && this.logger.isTraceEnabled()) {
/* 398 */       this.logger.trace("Did not attempt to auto-proxy infrastructure class [" + beanClass.getName() + "]");
/*     */     }
/* 400 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldSkip(Class<?> beanClass, String beanName) {
/* 416 */     return AutoProxyUtils.isOriginalInstance(beanName, beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TargetSource getCustomTargetSource(Class<?> beanClass, String beanName) {
/* 432 */     if (this.customTargetSourceCreators != null && this.beanFactory != null && this.beanFactory
/* 433 */       .containsBean(beanName)) {
/* 434 */       for (TargetSourceCreator tsc : this.customTargetSourceCreators) {
/* 435 */         TargetSource ts = tsc.getTargetSource(beanClass, beanName);
/* 436 */         if (ts != null) {
/*     */           
/* 438 */           if (this.logger.isTraceEnabled()) {
/* 439 */             this.logger.trace("TargetSourceCreator [" + String.valueOf(tsc) + "] found custom TargetSource for bean with name '" + beanName + "'");
/*     */           }
/*     */           
/* 442 */           return ts;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 448 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object createProxy(Class<?> beanClass, @Nullable String beanName, @Nullable Object[] specificInterceptors, TargetSource targetSource) {
/* 465 */     return buildProxy(beanClass, beanName, specificInterceptors, targetSource, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> createProxyClass(Class<?> beanClass, @Nullable String beanName, @Nullable Object[] specificInterceptors, TargetSource targetSource) {
/* 471 */     return (Class)buildProxy(beanClass, beanName, specificInterceptors, targetSource, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object buildProxy(Class<?> beanClass, @Nullable String beanName, @Nullable Object[] specificInterceptors, TargetSource targetSource, boolean classOnly) {
/* 477 */     BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)beanFactory;
/* 478 */       AutoProxyUtils.exposeTargetClass(clbf, beanName, beanClass); }
/*     */ 
/*     */     
/* 481 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 482 */     proxyFactory.copyFrom((ProxyConfig)this);
/*     */     
/* 484 */     if (proxyFactory.isProxyTargetClass()) {
/*     */       
/* 486 */       if (Proxy.isProxyClass(beanClass) || ClassUtils.isLambdaClass(beanClass))
/*     */       {
/* 488 */         for (Class<?> ifc : beanClass.getInterfaces()) {
/* 489 */           proxyFactory.addInterface(ifc);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     }
/* 495 */     else if (shouldProxyTargetClass(beanClass, beanName)) {
/* 496 */       proxyFactory.setProxyTargetClass(true);
/*     */     } else {
/*     */       
/* 499 */       evaluateProxyInterfaces(beanClass, proxyFactory);
/*     */     } 
/*     */ 
/*     */     
/* 503 */     Advisor[] advisors = buildAdvisors(beanName, specificInterceptors);
/* 504 */     proxyFactory.addAdvisors(advisors);
/* 505 */     proxyFactory.setTargetSource(targetSource);
/* 506 */     customizeProxyFactory(proxyFactory);
/*     */     
/* 508 */     proxyFactory.setFrozen(this.freezeProxy);
/* 509 */     if (advisorsPreFiltered()) {
/* 510 */       proxyFactory.setPreFiltered(true);
/*     */     }
/*     */ 
/*     */     
/* 514 */     ClassLoader classLoader = getProxyClassLoader();
/* 515 */     if (classLoader instanceof SmartClassLoader) { SmartClassLoader smartClassLoader = (SmartClassLoader)classLoader; if (classLoader != beanClass.getClassLoader())
/* 516 */         classLoader = smartClassLoader.getOriginalClassLoader();  }
/*     */     
/* 518 */     return classOnly ? proxyFactory.getProxyClass(classLoader) : proxyFactory.getProxy(classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldProxyTargetClass(Class<?> beanClass, @Nullable String beanName) {
/* 531 */     BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)beanFactory;
/* 532 */       if (AutoProxyUtils.shouldProxyTargetClass(clbf, beanName)); }
/*     */     
/*     */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean advisorsPreFiltered() {
/* 546 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Advisor[] buildAdvisors(@Nullable String beanName, @Nullable Object[] specificInterceptors) {
/* 559 */     Advisor[] commonInterceptors = resolveInterceptorNames();
/*     */     
/* 561 */     List<Object> allInterceptors = new ArrayList();
/* 562 */     if (specificInterceptors != null) {
/* 563 */       if (specificInterceptors.length > 0)
/*     */       {
/* 565 */         allInterceptors.addAll(Arrays.asList(specificInterceptors));
/*     */       }
/* 567 */       if (commonInterceptors.length > 0) {
/* 568 */         if (this.applyCommonInterceptorsFirst) {
/* 569 */           allInterceptors.addAll(0, Arrays.asList((Object[])commonInterceptors));
/*     */         } else {
/*     */           
/* 572 */           allInterceptors.addAll(Arrays.asList((Object[])commonInterceptors));
/*     */         } 
/*     */       }
/*     */     } 
/* 576 */     if (this.logger.isTraceEnabled()) {
/* 577 */       int nrOfCommonInterceptors = commonInterceptors.length;
/* 578 */       int nrOfSpecificInterceptors = (specificInterceptors != null) ? specificInterceptors.length : 0;
/* 579 */       this.logger.trace("Creating implicit proxy for bean '" + beanName + "' with " + nrOfCommonInterceptors + " common interceptors and " + nrOfSpecificInterceptors + " specific interceptors");
/*     */     } 
/*     */ 
/*     */     
/* 583 */     Advisor[] advisors = new Advisor[allInterceptors.size()];
/* 584 */     for (int i = 0; i < allInterceptors.size(); i++) {
/* 585 */       advisors[i] = this.advisorAdapterRegistry.wrap(allInterceptors.get(i));
/*     */     }
/* 587 */     return advisors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Advisor[] resolveInterceptorNames() {
/* 595 */     BeanFactory bf = this.beanFactory;
/* 596 */     ConfigurableBeanFactory _cbf = (ConfigurableBeanFactory)bf, cbf = (bf instanceof ConfigurableBeanFactory) ? _cbf : null;
/* 597 */     List<Advisor> advisors = new ArrayList<>();
/* 598 */     for (String beanName : this.interceptorNames) {
/* 599 */       if (cbf == null || !cbf.isCurrentlyInCreation(beanName)) {
/* 600 */         Assert.state((bf != null), "BeanFactory required for resolving interceptor names");
/* 601 */         Object next = bf.getBean(beanName);
/* 602 */         advisors.add(this.advisorAdapterRegistry.wrap(next));
/*     */       } 
/*     */     } 
/* 605 */     return advisors.<Advisor>toArray(new Advisor[0]);
/*     */   }
/*     */   
/*     */   protected void customizeProxyFactory(ProxyFactory proxyFactory) {}
/*     */   
/*     */   @Nullable
/*     */   protected abstract Object[] getAdvicesAndAdvisorsForBean(Class<?> paramClass, String paramString, @Nullable TargetSource paramTargetSource) throws BeansException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\autoproxy\AbstractAutoProxyCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */