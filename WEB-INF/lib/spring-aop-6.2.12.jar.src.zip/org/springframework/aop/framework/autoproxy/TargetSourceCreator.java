package org.springframework.aop.framework.autoproxy;

import org.springframework.aop.TargetSource;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface TargetSourceCreator {
  @Nullable
  TargetSource getTargetSource(Class<?> paramClass, String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\autoproxy\TargetSourceCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */