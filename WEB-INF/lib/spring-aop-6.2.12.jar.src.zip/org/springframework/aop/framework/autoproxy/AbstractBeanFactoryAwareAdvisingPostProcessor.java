/*    */ package org.springframework.aop.framework.autoproxy;
/*    */ 
/*    */ import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBeanFactoryAwareAdvisingPostProcessor
/*    */   extends AbstractAdvisingBeanPostProcessor
/*    */   implements BeanFactoryAware
/*    */ {
/*    */   @Nullable
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/* 49 */     ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)beanFactory; this.beanFactory = (beanFactory instanceof ConfigurableListableBeanFactory) ? clbf : null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ProxyFactory prepareProxyFactory(Object bean, String beanName) {
/* 54 */     if (this.beanFactory != null) {
/* 55 */       AutoProxyUtils.exposeTargetClass(this.beanFactory, beanName, bean.getClass());
/*    */     }
/*    */     
/* 58 */     ProxyFactory proxyFactory = super.prepareProxyFactory(bean, beanName);
/* 59 */     if (!proxyFactory.isProxyTargetClass() && this.beanFactory != null && 
/* 60 */       AutoProxyUtils.shouldProxyTargetClass(this.beanFactory, beanName)) {
/* 61 */       proxyFactory.setProxyTargetClass(true);
/*    */     }
/* 63 */     return proxyFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isEligible(Object bean, String beanName) {
/* 68 */     return (!AutoProxyUtils.isOriginalInstance(beanName, bean.getClass()) && super
/* 69 */       .isEligible(bean, beanName));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\autoproxy\AbstractBeanFactoryAwareAdvisingPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */