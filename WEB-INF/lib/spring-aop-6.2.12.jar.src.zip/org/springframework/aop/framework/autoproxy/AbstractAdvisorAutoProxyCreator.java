/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAdvisorAutoProxyCreator
/*     */   extends AbstractAutoProxyCreator
/*     */ {
/*     */   @Nullable
/*     */   private BeanFactoryAdvisorRetrievalHelper advisorRetrievalHelper;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*     */     ConfigurableListableBeanFactory clbf;
/*  62 */     super.setBeanFactory(beanFactory);
/*  63 */     if (beanFactory instanceof ConfigurableListableBeanFactory) { clbf = (ConfigurableListableBeanFactory)beanFactory; }
/*  64 */     else { throw new IllegalArgumentException("AdvisorAutoProxyCreator requires a ConfigurableListableBeanFactory: " + String.valueOf(beanFactory)); }
/*     */ 
/*     */     
/*  67 */     initBeanFactory(clbf);
/*     */   }
/*     */   
/*     */   protected void initBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/*  71 */     this.advisorRetrievalHelper = new BeanFactoryAdvisorRetrievalHelperAdapter(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object[] getAdvicesAndAdvisorsForBean(Class<?> beanClass, String beanName, @Nullable TargetSource targetSource) {
/*  80 */     List<Advisor> advisors = findEligibleAdvisors(beanClass, beanName);
/*  81 */     if (advisors.isEmpty()) {
/*  82 */       return DO_NOT_PROXY;
/*     */     }
/*  84 */     return advisors.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Advisor> findEligibleAdvisors(Class<?> beanClass, String beanName) {
/*  98 */     List<Advisor> candidateAdvisors = findCandidateAdvisors();
/*  99 */     List<Advisor> eligibleAdvisors = findAdvisorsThatCanApply(candidateAdvisors, beanClass, beanName);
/* 100 */     extendAdvisors(eligibleAdvisors);
/* 101 */     if (!eligibleAdvisors.isEmpty()) {
/*     */       try {
/* 103 */         eligibleAdvisors = sortAdvisors(eligibleAdvisors);
/*     */       }
/* 105 */       catch (BeanCreationException ex) {
/* 106 */         throw new AopConfigException("Advisor sorting failed with unexpected bean creation, probably due to custom use of the Ordered interface. Consider using the @Order annotation instead.", ex);
/*     */       } 
/*     */     }
/*     */     
/* 110 */     return eligibleAdvisors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Advisor> findCandidateAdvisors() {
/* 118 */     Assert.state((this.advisorRetrievalHelper != null), "No BeanFactoryAdvisorRetrievalHelper available");
/* 119 */     return this.advisorRetrievalHelper.findAdvisorBeans();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Advisor> findAdvisorsThatCanApply(List<Advisor> candidateAdvisors, Class<?> beanClass, String beanName) {
/* 134 */     ProxyCreationContext.setCurrentProxiedBeanName(beanName);
/*     */     try {
/* 136 */       return AopUtils.findAdvisorsThatCanApply(candidateAdvisors, beanClass);
/*     */     } finally {
/*     */       
/* 139 */       ProxyCreationContext.setCurrentProxiedBeanName(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEligibleAdvisorBean(String beanName) {
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Advisor> sortAdvisors(List<Advisor> advisors) {
/* 163 */     AnnotationAwareOrderComparator.sort(advisors);
/* 164 */     return advisors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void extendAdvisors(List<Advisor> candidateAdvisors) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean advisorsPreFiltered() {
/* 184 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class BeanFactoryAdvisorRetrievalHelperAdapter
/*     */     extends BeanFactoryAdvisorRetrievalHelper
/*     */   {
/*     */     public BeanFactoryAdvisorRetrievalHelperAdapter(ConfigurableListableBeanFactory beanFactory) {
/* 195 */       super(beanFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean isEligibleBean(String beanName) {
/* 200 */       return AbstractAdvisorAutoProxyCreator.this.isEligibleAdvisorBean(beanName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\autoproxy\AbstractAdvisorAutoProxyCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */