/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AopProxyUtils
/*     */ {
/*     */   @Nullable
/*     */   public static Object getSingletonTarget(Object candidate) {
/*  63 */     if (candidate instanceof Advised) { Advised advised = (Advised)candidate;
/*  64 */       TargetSource targetSource = advised.getTargetSource();
/*  65 */       if (targetSource instanceof SingletonTargetSource) { SingletonTargetSource singleTargetSource = (SingletonTargetSource)targetSource;
/*  66 */         return singleTargetSource.getTarget(); }
/*     */        }
/*     */     
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> ultimateTargetClass(Object candidate) {
/*  83 */     Assert.notNull(candidate, "Candidate object must not be null");
/*  84 */     Object current = candidate;
/*  85 */     Class<?> result = null;
/*  86 */     while (current instanceof TargetClassAware) { TargetClassAware targetClassAware = (TargetClassAware)current;
/*  87 */       result = targetClassAware.getTargetClass();
/*  88 */       current = getSingletonTarget(current); }
/*     */     
/*  90 */     if (result == null) {
/*  91 */       result = AopUtils.isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/*  93 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] completeJdkProxyInterfaces(Class<?>... userInterfaces) {
/* 123 */     List<Class<?>> completedInterfaces = new ArrayList<>(userInterfaces.length + 3);
/* 124 */     for (Class<?> ifc : userInterfaces) {
/* 125 */       Assert.notNull(ifc, "'userInterfaces' must not contain null values");
/* 126 */       Assert.isTrue((ifc.isInterface() && !ifc.isSealed()), () -> ifc.getName() + " must be a non-sealed interface");
/*     */       
/* 128 */       completedInterfaces.add(ifc);
/*     */     } 
/* 130 */     completedInterfaces.add(SpringProxy.class);
/* 131 */     completedInterfaces.add(Advised.class);
/* 132 */     completedInterfaces.add(DecoratingProxy.class);
/* 133 */     return (Class[])completedInterfaces.toArray(x$0 -> new Class[x$0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised) {
/* 147 */     return completeProxiedInterfaces(advised, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised, boolean decoratingProxy) {
/* 164 */     Class<?>[] specifiedInterfaces = advised.getProxiedInterfaces();
/* 165 */     if (specifiedInterfaces.length == 0) {
/*     */       
/* 167 */       Class<?> targetClass = advised.getTargetClass();
/* 168 */       if (targetClass != null) {
/* 169 */         if (targetClass.isInterface()) {
/* 170 */           advised.setInterfaces(new Class[] { targetClass });
/*     */         }
/* 172 */         else if (Proxy.isProxyClass(targetClass) || ClassUtils.isLambdaClass(targetClass)) {
/* 173 */           advised.setInterfaces(targetClass.getInterfaces());
/*     */         } 
/* 175 */         specifiedInterfaces = advised.getProxiedInterfaces();
/*     */       } 
/*     */     } 
/* 178 */     List<Class<?>> proxiedInterfaces = new ArrayList<>(specifiedInterfaces.length + 3);
/* 179 */     for (Class<?> ifc : specifiedInterfaces) {
/*     */       
/* 181 */       if (!ifc.isSealed()) {
/* 182 */         proxiedInterfaces.add(ifc);
/*     */       }
/*     */     } 
/* 185 */     if (!advised.isInterfaceProxied(SpringProxy.class)) {
/* 186 */       proxiedInterfaces.add(SpringProxy.class);
/*     */     }
/* 188 */     if (!advised.isOpaque() && !advised.isInterfaceProxied(Advised.class)) {
/* 189 */       proxiedInterfaces.add(Advised.class);
/*     */     }
/* 191 */     if (decoratingProxy && !advised.isInterfaceProxied(DecoratingProxy.class)) {
/* 192 */       proxiedInterfaces.add(DecoratingProxy.class);
/*     */     }
/* 194 */     return ClassUtils.toClassArray(proxiedInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] proxiedUserInterfaces(Object proxy) {
/* 206 */     Class<?>[] proxyInterfaces = proxy.getClass().getInterfaces();
/* 207 */     int nonUserIfcCount = 0;
/* 208 */     if (proxy instanceof SpringProxy) {
/* 209 */       nonUserIfcCount++;
/*     */     }
/* 211 */     if (proxy instanceof Advised) {
/* 212 */       nonUserIfcCount++;
/*     */     }
/* 214 */     if (proxy instanceof DecoratingProxy) {
/* 215 */       nonUserIfcCount++;
/*     */     }
/* 217 */     Class<?>[] userInterfaces = (Class[])Arrays.<Class<?>[]>copyOf((Class<?>[][])proxyInterfaces, proxyInterfaces.length - nonUserIfcCount);
/* 218 */     Assert.notEmpty((Object[])userInterfaces, "JDK proxy must implement one or more interfaces");
/* 219 */     return userInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalsInProxy(AdvisedSupport a, AdvisedSupport b) {
/* 228 */     return (a == b || (
/* 229 */       equalsProxiedInterfaces(a, b) && equalsAdvisors(a, b) && a.getTargetSource().equals(b.getTargetSource())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalsProxiedInterfaces(AdvisedSupport a, AdvisedSupport b) {
/* 236 */     return Arrays.equals((Object[])a.getProxiedInterfaces(), (Object[])b.getProxiedInterfaces());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalsAdvisors(AdvisedSupport a, AdvisedSupport b) {
/* 243 */     return (a.getAdvisorCount() == b.getAdvisorCount() && Arrays.equals((Object[])a.getAdvisors(), (Object[])b.getAdvisors()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object[] adaptArgumentsIfNecessary(Method method, @Nullable Object[] arguments) {
/* 257 */     if (ObjectUtils.isEmpty(arguments)) {
/* 258 */       return new Object[0];
/*     */     }
/* 260 */     if (method.isVarArgs() && method.getParameterCount() == arguments.length) {
/* 261 */       Class<?>[] paramTypes = method.getParameterTypes();
/* 262 */       int varargIndex = paramTypes.length - 1;
/* 263 */       Class<?> varargType = paramTypes[varargIndex];
/* 264 */       if (varargType.isArray()) {
/* 265 */         Object varargArray = arguments[varargIndex];
/* 266 */         if (varargArray instanceof Object[] && !varargType.isInstance(varargArray)) {
/* 267 */           Object[] newArguments = new Object[arguments.length];
/* 268 */           System.arraycopy(arguments, 0, newArguments, 0, varargIndex);
/* 269 */           Class<?> targetElementType = varargType.componentType();
/* 270 */           int varargLength = Array.getLength(varargArray);
/* 271 */           Object newVarargArray = Array.newInstance(targetElementType, varargLength);
/* 272 */           System.arraycopy(varargArray, 0, newVarargArray, 0, varargLength);
/* 273 */           newArguments[varargIndex] = newVarargArray;
/* 274 */           return newArguments;
/*     */         } 
/*     */       } 
/*     */     } 
/* 278 */     return arguments;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\AopProxyUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */