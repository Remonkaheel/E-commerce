/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import kotlin.coroutines.Continuation;
/*    */ import kotlinx.coroutines.reactive.ReactiveFlowKt;
/*    */ import kotlinx.coroutines.reactor.MonoKt;
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.lang.Nullable;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class CoroutinesUtils
/*    */ {
/*    */   static Object asFlow(@Nullable Object publisher) {
/* 36 */     if (publisher instanceof Publisher) { Publisher<?> rsPublisher = (Publisher)publisher;
/* 37 */       return ReactiveFlowKt.asFlow(rsPublisher); }
/*    */ 
/*    */     
/* 40 */     throw new IllegalArgumentException("Not a Reactive Streams Publisher: " + String.valueOf(publisher));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   static Object awaitSingleOrNull(@Nullable Object value, Object continuation) {
/* 47 */     Mono mono = (Mono)value; return MonoKt.awaitSingleOrNull((value instanceof Mono) ? mono : Mono.justOrEmpty(value), (Continuation)continuation);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\CoroutinesUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */