/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.RawTargetAccess;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.aot.AotDetector;
/*     */ import org.springframework.cglib.core.ClassLoaderAwareGeneratorStrategy;
/*     */ import org.springframework.cglib.core.CodeGenerationException;
/*     */ import org.springframework.cglib.core.GeneratorStrategy;
/*     */ import org.springframework.cglib.core.NamingPolicy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Dispatcher;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.Factory;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.cglib.transform.impl.UndeclaredThrowableStrategy;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CglibAopProxy
/*     */   implements AopProxy, Serializable
/*     */ {
/*     */   private static final int AOP_PROXY = 0;
/*     */   private static final int INVOKE_TARGET = 1;
/*     */   private static final int NO_OVERRIDE = 2;
/*     */   private static final int DISPATCH_TARGET = 3;
/*     */   private static final int DISPATCH_ADVISED = 4;
/*     */   private static final int INVOKE_EQUALS = 5;
/*     */   private static final int INVOKE_HASHCODE = 6;
/*     */   private static final String COROUTINES_FLOW_CLASS_NAME = "kotlinx.coroutines.flow.Flow";
/* 101 */   private static final boolean coroutinesReactorPresent = ClassUtils.isPresent("kotlinx.coroutines.reactor.MonoKt", CglibAopProxy.class
/* 102 */       .getClassLoader());
/*     */   
/* 104 */   private static final GeneratorStrategy undeclaredThrowableStrategy = (GeneratorStrategy)new UndeclaredThrowableStrategy(UndeclaredThrowableException.class);
/*     */ 
/*     */ 
/*     */   
/* 108 */   protected static final Log logger = LogFactory.getLog(CglibAopProxy.class);
/*     */ 
/*     */   
/* 111 */   private static final Map<Class<?>, Boolean> validatedClasses = new WeakHashMap<>();
/*     */ 
/*     */   
/*     */   protected final AdvisedSupport advised;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object[] constructorArgs;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?>[] constructorArgTypes;
/*     */   
/*     */   private final transient AdvisedDispatcher advisedDispatcher;
/*     */   
/* 126 */   private transient Map<Method, Integer> fixedInterceptorMap = Collections.emptyMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int fixedInterceptorOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CglibAopProxy(AdvisedSupport config) throws AopConfigException {
/* 138 */     Assert.notNull(config, "AdvisedSupport must not be null");
/* 139 */     this.advised = config;
/* 140 */     this.advisedDispatcher = new AdvisedDispatcher(this.advised);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConstructorArguments(@Nullable Object[] constructorArgs, @Nullable Class<?>[] constructorArgTypes) {
/* 149 */     if (constructorArgs == null || constructorArgTypes == null) {
/* 150 */       throw new IllegalArgumentException("Both 'constructorArgs' and 'constructorArgTypes' need to be specified");
/*     */     }
/* 152 */     if (constructorArgs.length != constructorArgTypes.length) {
/* 153 */       throw new IllegalArgumentException("Number of 'constructorArgs' (" + constructorArgs.length + ") must match number of 'constructorArgTypes' (" + constructorArgTypes.length + ")");
/*     */     }
/*     */     
/* 156 */     this.constructorArgs = constructorArgs;
/* 157 */     this.constructorArgTypes = constructorArgTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProxy() {
/* 163 */     return buildProxy(null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProxy(@Nullable ClassLoader classLoader) {
/* 168 */     return buildProxy(classLoader, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getProxyClass(@Nullable ClassLoader classLoader) {
/* 173 */     return (Class)buildProxy(classLoader, true);
/*     */   }
/*     */   
/*     */   private Object buildProxy(@Nullable ClassLoader classLoader, boolean classOnly) {
/* 177 */     if (logger.isTraceEnabled()) {
/* 178 */       logger.trace("Creating CGLIB proxy: " + String.valueOf(this.advised.getTargetSource()));
/*     */     }
/*     */     
/*     */     try {
/* 182 */       Class<?> rootClass = this.advised.getTargetClass();
/* 183 */       Assert.state((rootClass != null), "Target class must be available for creating a CGLIB proxy");
/*     */       
/* 185 */       Class<?> proxySuperClass = rootClass;
/* 186 */       if (rootClass.getName().contains("$$")) {
/* 187 */         proxySuperClass = rootClass.getSuperclass();
/* 188 */         Class<?>[] additionalInterfaces = rootClass.getInterfaces();
/* 189 */         for (Class<?> additionalInterface : additionalInterfaces) {
/* 190 */           this.advised.addInterface(additionalInterface);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 195 */       validateClassIfNecessary(proxySuperClass, classLoader);
/*     */ 
/*     */       
/* 198 */       Enhancer enhancer = createEnhancer();
/* 199 */       if (classLoader != null) {
/* 200 */         enhancer.setClassLoader(classLoader);
/* 201 */         if (classLoader instanceof SmartClassLoader) { SmartClassLoader smartClassLoader = (SmartClassLoader)classLoader; if (smartClassLoader
/* 202 */             .isClassReloadable(proxySuperClass))
/* 203 */             enhancer.setUseCache(false);  }
/*     */       
/*     */       } 
/* 206 */       enhancer.setSuperclass(proxySuperClass);
/* 207 */       enhancer.setInterfaces(AopProxyUtils.completeProxiedInterfaces(this.advised));
/* 208 */       enhancer.setNamingPolicy((NamingPolicy)SpringNamingPolicy.INSTANCE);
/* 209 */       enhancer.setAttemptLoad((enhancer.getUseCache() && AotDetector.useGeneratedArtifacts()));
/* 210 */       enhancer.setStrategy(KotlinDetector.isKotlinType(proxySuperClass) ? 
/* 211 */           (GeneratorStrategy)new ClassLoaderAwareGeneratorStrategy(classLoader) : 
/* 212 */           (GeneratorStrategy)new ClassLoaderAwareGeneratorStrategy(classLoader, undeclaredThrowableStrategy));
/*     */ 
/*     */       
/* 215 */       Callback[] callbacks = getCallbacks(rootClass);
/* 216 */       Class<?>[] types = new Class[callbacks.length];
/* 217 */       for (int x = 0; x < types.length; x++) {
/* 218 */         types[x] = callbacks[x].getClass();
/*     */       }
/*     */ 
/*     */       
/* 222 */       ProxyCallbackFilter filter = new ProxyCallbackFilter(this.advised.getConfigurationOnlyCopy(), this.fixedInterceptorMap, this.fixedInterceptorOffset);
/* 223 */       enhancer.setCallbackFilter(filter);
/* 224 */       enhancer.setCallbackTypes(types);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 229 */         return classOnly ? createProxyClass(enhancer) : createProxyClassAndInstance(enhancer, callbacks);
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 234 */         filter.advised.reduceToAdvisorKey();
/*     */       }
/*     */     
/* 237 */     } catch (CodeGenerationException|IllegalArgumentException ex) {
/* 238 */       throw new AopConfigException("Could not generate CGLIB subclass of " + String.valueOf(this.advised.getTargetClass()) + ": Common causes of this problem include using a final class or a non-visible class", ex);
/*     */ 
/*     */     
/*     */     }
/* 242 */     catch (Throwable ex) {
/*     */       
/* 244 */       throw new AopConfigException("Unexpected AOP exception", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Class<?> createProxyClass(Enhancer enhancer) {
/* 249 */     enhancer.setInterceptDuringConstruction(false);
/* 250 */     return enhancer.createClass();
/*     */   }
/*     */   
/*     */   protected Object createProxyClassAndInstance(Enhancer enhancer, Callback[] callbacks) {
/* 254 */     enhancer.setInterceptDuringConstruction(false);
/* 255 */     enhancer.setCallbacks(callbacks);
/* 256 */     return (this.constructorArgs != null && this.constructorArgTypes != null) ? 
/* 257 */       enhancer.create(this.constructorArgTypes, this.constructorArgs) : 
/* 258 */       enhancer.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Enhancer createEnhancer() {
/* 266 */     return new Enhancer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateClassIfNecessary(Class<?> proxySuperClass, @Nullable ClassLoader proxyClassLoader) {
/* 274 */     if (!this.advised.isOptimize() && logger.isInfoEnabled()) {
/* 275 */       synchronized (validatedClasses) {
/* 276 */         validatedClasses.computeIfAbsent(proxySuperClass, clazz -> {
/*     */               doValidateClass(clazz, proxyClassLoader, ClassUtils.getAllInterfacesForClassAsSet(clazz));
/*     */               return Boolean.TRUE;
/*     */             });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doValidateClass(Class<?> proxySuperClass, @Nullable ClassLoader proxyClassLoader, Set<Class<?>> ifcs) {
/* 289 */     if (proxySuperClass != Object.class) {
/* 290 */       Method[] methods = proxySuperClass.getDeclaredMethods();
/* 291 */       for (Method method : methods) {
/* 292 */         int mod = method.getModifiers();
/* 293 */         if (!Modifier.isStatic(mod) && !Modifier.isPrivate(mod)) {
/* 294 */           if (Modifier.isFinal(mod)) {
/* 295 */             if (logger.isWarnEnabled() && implementsInterface(method, ifcs)) {
/* 296 */               logger.warn("Unable to proxy interface-implementing method [" + String.valueOf(method) + "] because it is marked as final, consider using interface-based JDK proxies instead.");
/*     */             }
/*     */             
/* 299 */             if (logger.isDebugEnabled()) {
/* 300 */               logger.debug("Final method [" + String.valueOf(method) + "] cannot get proxied via CGLIB: Calls to this method will NOT be routed to the target instance and might lead to NPEs against uninitialized fields in the proxy instance.");
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 305 */           else if (logger.isDebugEnabled() && !Modifier.isPublic(mod) && !Modifier.isProtected(mod) && proxyClassLoader != null && proxySuperClass
/* 306 */             .getClassLoader() != proxyClassLoader) {
/* 307 */             logger.debug("Method [" + String.valueOf(method) + "] is package-visible across different ClassLoaders and cannot get proxied via CGLIB: Declare this method as public or protected if you need to support invocations through the proxy.");
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 313 */       doValidateClass(proxySuperClass.getSuperclass(), proxyClassLoader, ifcs);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Callback[] getCallbacks(Class<?> rootClass) throws Exception {
/*     */     Callback targetInterceptor;
/* 319 */     boolean isStatic = this.advised.getTargetSource().isStatic();
/* 320 */     boolean isFrozen = this.advised.isFrozen();
/* 321 */     boolean exposeProxy = this.advised.isExposeProxy();
/*     */ 
/*     */     
/* 324 */     DynamicAdvisedInterceptor dynamicAdvisedInterceptor = new DynamicAdvisedInterceptor(this.advised);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     if (exposeProxy) {
/*     */ 
/*     */       
/* 332 */       targetInterceptor = isStatic ? (Callback)new StaticUnadvisedExposedInterceptor(this.advised.getTargetSource().getTarget()) : (Callback)new DynamicUnadvisedExposedInterceptor(this.advised.getTargetSource());
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 337 */       targetInterceptor = isStatic ? (Callback)new StaticUnadvisedInterceptor(this.advised.getTargetSource().getTarget()) : (Callback)new DynamicUnadvisedInterceptor(this.advised.getTargetSource());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     Callback targetDispatcher = isStatic ? (Callback)new StaticDispatcher(this.advised.getTargetSource().getTarget()) : (Callback)new SerializableNoOp();
/*     */     
/* 345 */     Callback[] mainCallbacks = { (Callback)dynamicAdvisedInterceptor, targetInterceptor, (Callback)new SerializableNoOp(), targetDispatcher, (Callback)this.advisedDispatcher, (Callback)new EqualsInterceptor(this.advised), (Callback)new HashCodeInterceptor(this.advised) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     if (isStatic && isFrozen) {
/* 358 */       Method[] methods = rootClass.getMethods();
/* 359 */       int methodsCount = methods.length;
/* 360 */       List<Callback> fixedCallbacks = new ArrayList<>(methodsCount);
/* 361 */       this.fixedInterceptorMap = CollectionUtils.newHashMap(methodsCount);
/*     */       
/* 363 */       int advicedMethodCount = methodsCount;
/* 364 */       for (int x = 0; x < methodsCount; x++) {
/* 365 */         Method method = methods[x];
/*     */         
/* 367 */         if (method.getDeclaringClass() == Object.class) {
/* 368 */           advicedMethodCount--;
/*     */         } else {
/*     */           
/* 371 */           List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, rootClass);
/* 372 */           fixedCallbacks.add(new FixedChainStaticTargetInterceptor(chain, this.advised
/* 373 */                 .getTargetSource().getTarget(), this.advised.getTargetClass()));
/* 374 */           this.fixedInterceptorMap.put(method, Integer.valueOf(x - methodsCount - advicedMethodCount));
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 379 */       Callback[] callbacks = new Callback[mainCallbacks.length + advicedMethodCount];
/* 380 */       System.arraycopy(mainCallbacks, 0, callbacks, 0, mainCallbacks.length);
/* 381 */       System.arraycopy(fixedCallbacks.toArray(x$0 -> new Callback[x$0]), 0, callbacks, mainCallbacks.length, advicedMethodCount);
/*     */       
/* 383 */       this.fixedInterceptorOffset = mainCallbacks.length;
/* 384 */       return callbacks;
/*     */     } 
/* 386 */     return mainCallbacks;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/* 392 */     if (this != other) { if (other instanceof CglibAopProxy) { CglibAopProxy that = (CglibAopProxy)other;
/* 393 */         if (AopProxyUtils.equalsInProxy(this.advised, that.advised)); }
/*     */       
/*     */       return false; }
/*     */   
/*     */   } public int hashCode() {
/* 398 */     return CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean implementsInterface(Method method, Set<Class<?>> ifcs) {
/* 406 */     for (Class<?> ifc : ifcs) {
/* 407 */       if (ClassUtils.hasMethod(ifc, method)) {
/* 408 */         return true;
/*     */       }
/*     */     } 
/* 411 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Object processReturnType(Object proxy, @Nullable Object target, Method method, Object[] arguments, @Nullable Object returnValue) {
/* 424 */     if (returnValue != null && returnValue == target && 
/* 425 */       !RawTargetAccess.class.isAssignableFrom(method.getDeclaringClass()))
/*     */     {
/*     */       
/* 428 */       returnValue = proxy;
/*     */     }
/* 430 */     Class<?> returnType = method.getReturnType();
/* 431 */     if (returnValue == null && returnType != void.class && returnType.isPrimitive()) {
/* 432 */       throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + String.valueOf(method));
/*     */     }
/*     */     
/* 435 */     if (coroutinesReactorPresent && KotlinDetector.isSuspendingFunction(method)) {
/* 436 */       return "kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName()) ? 
/* 437 */         CoroutinesUtils.asFlow(returnValue) : 
/* 438 */         CoroutinesUtils.awaitSingleOrNull(returnValue, arguments[arguments.length - 1]);
/*     */     }
/* 440 */     return returnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SerializableNoOp
/*     */     implements NoOp, Serializable {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StaticUnadvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     @Nullable
/*     */     private final Object target;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticUnadvisedInterceptor(@Nullable Object target) {
/* 463 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 469 */       Object retVal = AopUtils.invokeJoinpointUsingReflection(this.target, method, args);
/* 470 */       return CglibAopProxy.processReturnType(proxy, this.target, method, args, retVal);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StaticUnadvisedExposedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     @Nullable
/*     */     private final Object target;
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticUnadvisedExposedInterceptor(@Nullable Object target) {
/* 485 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 491 */       Object oldProxy = null;
/*     */       try {
/* 493 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 494 */         Object retVal = AopUtils.invokeJoinpointUsingReflection(this.target, method, args);
/* 495 */         return CglibAopProxy.processReturnType(proxy, this.target, method, args, retVal);
/*     */       } finally {
/*     */         
/* 498 */         AopContext.setCurrentProxy(oldProxy);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DynamicUnadvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final TargetSource targetSource;
/*     */ 
/*     */ 
/*     */     
/*     */     public DynamicUnadvisedInterceptor(TargetSource targetSource) {
/* 514 */       this.targetSource = targetSource;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 520 */       Object target = this.targetSource.getTarget();
/*     */       try {
/* 522 */         Object retVal = AopUtils.invokeJoinpointUsingReflection(target, method, args);
/* 523 */         return CglibAopProxy.processReturnType(proxy, target, method, args, retVal);
/*     */       } finally {
/*     */         
/* 526 */         if (target != null) {
/* 527 */           this.targetSource.releaseTarget(target);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DynamicUnadvisedExposedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final TargetSource targetSource;
/*     */ 
/*     */     
/*     */     public DynamicUnadvisedExposedInterceptor(TargetSource targetSource) {
/* 542 */       this.targetSource = targetSource;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 548 */       Object oldProxy = null;
/* 549 */       Object target = this.targetSource.getTarget();
/*     */       try {
/* 551 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 552 */         Object retVal = AopUtils.invokeJoinpointUsingReflection(target, method, args);
/* 553 */         return CglibAopProxy.processReturnType(proxy, target, method, args, retVal);
/*     */       } finally {
/*     */         
/* 556 */         AopContext.setCurrentProxy(oldProxy);
/* 557 */         if (target != null) {
/* 558 */           this.targetSource.releaseTarget(target);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StaticDispatcher
/*     */     implements Dispatcher, Serializable
/*     */   {
/*     */     @Nullable
/*     */     private final Object target;
/*     */ 
/*     */ 
/*     */     
/*     */     public StaticDispatcher(@Nullable Object target) {
/* 576 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object loadObject() {
/* 582 */       return this.target;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AdvisedDispatcher
/*     */     implements Dispatcher, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */     
/*     */     public AdvisedDispatcher(AdvisedSupport advised) {
/* 595 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object loadObject() {
/* 600 */       return this.advised;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EqualsInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */ 
/*     */     
/*     */     public EqualsInterceptor(AdvisedSupport advised) {
/* 614 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) {
/* 619 */       Object other = args[0];
/* 620 */       if (proxy == other) {
/* 621 */         return Boolean.valueOf(true);
/*     */       }
/* 623 */       if (other instanceof Factory) { Factory factory = (Factory)other;
/* 624 */         Callback callback = factory.getCallback(5);
/* 625 */         if (callback instanceof EqualsInterceptor) { EqualsInterceptor that = (EqualsInterceptor)callback;
/* 626 */           if (AopProxyUtils.equalsInProxy(this.advised, that.advised)); }  return Boolean.valueOf(false); }
/*     */       
/* 628 */       return Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class HashCodeInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */ 
/*     */     
/*     */     public HashCodeInterceptor(AdvisedSupport advised) {
/* 642 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) {
/* 647 */       return Integer.valueOf(CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class FixedChainStaticTargetInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final List<Object> adviceChain;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Object target;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Class<?> targetClass;
/*     */ 
/*     */     
/*     */     public FixedChainStaticTargetInterceptor(List<Object> adviceChain, @Nullable Object target, @Nullable Class<?> targetClass) {
/* 668 */       this.adviceChain = adviceChain;
/* 669 */       this.target = target;
/* 670 */       this.targetClass = targetClass;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 676 */       ReflectiveMethodInvocation reflectiveMethodInvocation = new ReflectiveMethodInvocation(proxy, this.target, method, args, this.targetClass, this.adviceChain);
/*     */ 
/*     */       
/* 679 */       Object retVal = reflectiveMethodInvocation.proceed();
/* 680 */       retVal = CglibAopProxy.processReturnType(proxy, this.target, method, args, retVal);
/* 681 */       return retVal;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DynamicAdvisedInterceptor
/*     */     implements MethodInterceptor, Serializable
/*     */   {
/*     */     private final AdvisedSupport advised;
/*     */ 
/*     */ 
/*     */     
/*     */     public DynamicAdvisedInterceptor(AdvisedSupport advised) {
/* 695 */       this.advised = advised;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
/* 701 */       Object oldProxy = null;
/* 702 */       boolean setProxyContext = false;
/* 703 */       Object target = null;
/* 704 */       TargetSource targetSource = this.advised.getTargetSource(); try {
/*     */         Object retVal;
/* 706 */         if (this.advised.exposeProxy) {
/*     */           
/* 708 */           oldProxy = AopContext.setCurrentProxy(proxy);
/* 709 */           setProxyContext = true;
/*     */         } 
/*     */         
/* 712 */         target = targetSource.getTarget();
/* 713 */         Class<?> targetClass = (target != null) ? target.getClass() : null;
/* 714 */         List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*     */ 
/*     */ 
/*     */         
/* 718 */         if (chain.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 723 */           Object[] argsToUse = AopProxyUtils.adaptArgumentsIfNecessary(method, args);
/* 724 */           retVal = AopUtils.invokeJoinpointUsingReflection(target, method, argsToUse);
/*     */         }
/*     */         else {
/*     */           
/* 728 */           retVal = (new ReflectiveMethodInvocation(proxy, target, method, args, targetClass, chain)).proceed();
/*     */         } 
/* 730 */         return CglibAopProxy.processReturnType(proxy, target, method, args, retVal);
/*     */       } finally {
/*     */         
/* 733 */         if (target != null && !targetSource.isStatic()) {
/* 734 */           targetSource.releaseTarget(target);
/*     */         }
/* 736 */         if (setProxyContext)
/*     */         {
/* 738 */           AopContext.setCurrentProxy(oldProxy);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 745 */       if (this != other) { if (other instanceof DynamicAdvisedInterceptor) {
/* 746 */           DynamicAdvisedInterceptor dynamicAdvisedInterceptor = (DynamicAdvisedInterceptor)other; if (this.advised
/* 747 */             .equals(dynamicAdvisedInterceptor.advised));
/*     */         } 
/*     */         return false; }
/*     */     
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 755 */       return this.advised.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ProxyCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     final AdvisedSupport advised;
/*     */ 
/*     */     
/*     */     private final Map<Method, Integer> fixedInterceptorMap;
/*     */ 
/*     */     
/*     */     private final int fixedInterceptorOffset;
/*     */ 
/*     */     
/*     */     public ProxyCallbackFilter(AdvisedSupport advised, Map<Method, Integer> fixedInterceptorMap, int fixedInterceptorOffset) {
/* 774 */       this.advised = advised;
/* 775 */       this.fixedInterceptorMap = fixedInterceptorMap;
/* 776 */       this.fixedInterceptorOffset = fixedInterceptorOffset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int accept(Method method) {
/* 817 */       if (AopUtils.isFinalizeMethod(method)) {
/* 818 */         CglibAopProxy.logger.trace("Found finalize() method - using NO_OVERRIDE");
/* 819 */         return 2;
/*     */       } 
/* 821 */       if (!this.advised.isOpaque() && method.getDeclaringClass().isInterface() && method
/* 822 */         .getDeclaringClass().isAssignableFrom(Advised.class)) {
/* 823 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/* 824 */           CglibAopProxy.logger.trace("Method is declared on Advised interface: " + String.valueOf(method));
/*     */         }
/* 826 */         return 4;
/*     */       } 
/*     */       
/* 829 */       if (AopUtils.isEqualsMethod(method)) {
/* 830 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/* 831 */           CglibAopProxy.logger.trace("Found 'equals' method: " + String.valueOf(method));
/*     */         }
/* 833 */         return 5;
/*     */       } 
/*     */       
/* 836 */       if (AopUtils.isHashCodeMethod(method)) {
/* 837 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/* 838 */           CglibAopProxy.logger.trace("Found 'hashCode' method: " + String.valueOf(method));
/*     */         }
/* 840 */         return 6;
/*     */       } 
/* 842 */       Class<?> targetClass = this.advised.getTargetClass();
/*     */       
/* 844 */       List<?> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/* 845 */       boolean haveAdvice = !chain.isEmpty();
/* 846 */       boolean isStatic = this.advised.getTargetSource().isStatic();
/* 847 */       boolean isFrozen = this.advised.isFrozen();
/* 848 */       boolean exposeProxy = this.advised.isExposeProxy();
/* 849 */       if (haveAdvice || !isFrozen) {
/*     */         
/* 851 */         if (exposeProxy) {
/* 852 */           if (CglibAopProxy.logger.isTraceEnabled()) {
/* 853 */             CglibAopProxy.logger.trace("Must expose proxy on advised method: " + String.valueOf(method));
/*     */           }
/* 855 */           return 0;
/*     */         } 
/*     */ 
/*     */         
/* 859 */         if (isStatic && isFrozen && this.fixedInterceptorMap.containsKey(method)) {
/* 860 */           if (CglibAopProxy.logger.isTraceEnabled()) {
/* 861 */             CglibAopProxy.logger.trace("Method has advice and optimizations are enabled: " + String.valueOf(method));
/*     */           }
/*     */           
/* 864 */           int index = ((Integer)this.fixedInterceptorMap.get(method)).intValue();
/* 865 */           return index + this.fixedInterceptorOffset;
/*     */         } 
/*     */         
/* 868 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/* 869 */           CglibAopProxy.logger.trace("Unable to apply any optimizations to advised method: " + String.valueOf(method));
/*     */         }
/* 871 */         return 0;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 880 */       if (exposeProxy || !isStatic) {
/* 881 */         return 1;
/*     */       }
/* 883 */       Class<?> returnType = method.getReturnType();
/* 884 */       if (targetClass != null && returnType.isAssignableFrom(targetClass)) {
/* 885 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/* 886 */           CglibAopProxy.logger.trace("Method return type is assignable from target type and may therefore return 'this' - using INVOKE_TARGET: " + String.valueOf(method));
/*     */         }
/*     */         
/* 889 */         return 1;
/*     */       } 
/*     */       
/* 892 */       if (CglibAopProxy.logger.isTraceEnabled()) {
/* 893 */         CglibAopProxy.logger.trace("Method return type ensures 'this' cannot be returned - using DISPATCH_TARGET: " + String.valueOf(method));
/*     */       }
/*     */       
/* 896 */       return 3;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 903 */       if (this != other) { if (other instanceof ProxyCallbackFilter) { ProxyCallbackFilter that = (ProxyCallbackFilter)other; if (this.advised
/* 904 */             .getAdvisorKey().equals(that.advised.getAdvisorKey()) && 
/* 905 */             AopProxyUtils.equalsProxiedInterfaces(this.advised, that.advised) && 
/* 906 */             ObjectUtils.nullSafeEquals(this.advised.getTargetClass(), that.advised.getTargetClass()) && this.advised
/* 907 */             .getTargetSource().isStatic() == that.advised.getTargetSource().isStatic() && this.advised
/* 908 */             .isFrozen() == that.advised.isFrozen() && this.advised
/* 909 */             .isExposeProxy() == that.advised.isExposeProxy() && this.advised
/* 910 */             .isOpaque() == that.advised.isOpaque()); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 915 */       return this.advised.getAdvisorKey().hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\CglibAopProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */