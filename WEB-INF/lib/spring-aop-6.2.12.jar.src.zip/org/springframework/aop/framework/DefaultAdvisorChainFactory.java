/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultAdvisorChainFactory
/*     */   implements AdvisorChainFactory, Serializable
/*     */ {
/*  54 */   public static final DefaultAdvisorChainFactory INSTANCE = new DefaultAdvisorChainFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> getInterceptorsAndDynamicInterceptionAdvice(Advised config, Method method, @Nullable Class<?> targetClass) {
/*  63 */     AdvisorAdapterRegistry registry = GlobalAdvisorAdapterRegistry.getInstance();
/*  64 */     Advisor[] advisors = config.getAdvisors();
/*  65 */     List<Object> interceptorList = new ArrayList(advisors.length);
/*  66 */     Class<?> actualClass = (targetClass != null) ? targetClass : method.getDeclaringClass();
/*  67 */     Boolean hasIntroductions = null;
/*     */     
/*  69 */     for (Advisor advisor : advisors) {
/*  70 */       if (advisor instanceof PointcutAdvisor) { PointcutAdvisor pointcutAdvisor = (PointcutAdvisor)advisor;
/*     */         
/*  72 */         if (config.isPreFiltered() || pointcutAdvisor.getPointcut().getClassFilter().matches(actualClass)) {
/*  73 */           boolean match; MethodMatcher mm = pointcutAdvisor.getPointcut().getMethodMatcher();
/*     */           
/*  75 */           if (mm instanceof IntroductionAwareMethodMatcher) { IntroductionAwareMethodMatcher iamm = (IntroductionAwareMethodMatcher)mm;
/*  76 */             if (hasIntroductions == null) {
/*  77 */               hasIntroductions = Boolean.valueOf(hasMatchingIntroductions(advisors, actualClass));
/*     */             }
/*  79 */             match = iamm.matches(method, actualClass, hasIntroductions.booleanValue()); }
/*     */           else
/*     */           
/*  82 */           { match = mm.matches(method, actualClass); }
/*     */           
/*  84 */           if (match) {
/*  85 */             MethodInterceptor[] interceptors = registry.getInterceptors(advisor);
/*  86 */             if (mm.isRuntime()) {
/*     */ 
/*     */               
/*  89 */               for (MethodInterceptor interceptor : interceptors) {
/*  90 */                 interceptorList.add(new InterceptorAndDynamicMethodMatcher(interceptor, mm));
/*     */               }
/*     */             } else {
/*     */               
/*  94 */               interceptorList.addAll(Arrays.asList((Object[])interceptors));
/*     */             }
/*     */           
/*     */           } 
/*     */         }  }
/*  99 */       else if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor ia = (IntroductionAdvisor)advisor;
/* 100 */         if (config.isPreFiltered() || ia.getClassFilter().matches(actualClass)) {
/* 101 */           MethodInterceptor[] arrayOfMethodInterceptor = registry.getInterceptors(advisor);
/* 102 */           interceptorList.addAll(Arrays.asList((Object[])arrayOfMethodInterceptor));
/*     */         }  }
/*     */       else
/*     */       
/* 106 */       { MethodInterceptor[] arrayOfMethodInterceptor = registry.getInterceptors(advisor);
/* 107 */         interceptorList.addAll(Arrays.asList((Object[])arrayOfMethodInterceptor)); }
/*     */     
/*     */     } 
/*     */     
/* 111 */     return interceptorList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasMatchingIntroductions(Advisor[] advisors, Class<?> actualClass) {
/* 118 */     for (Advisor advisor : advisors) {
/* 119 */       if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor ia = (IntroductionAdvisor)advisor; if (ia.getClassFilter().matches(actualClass))
/* 120 */           return true;  }
/*     */     
/*     */     } 
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\DefaultAdvisorChainFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */