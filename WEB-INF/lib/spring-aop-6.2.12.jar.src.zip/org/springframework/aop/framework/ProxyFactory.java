/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.Interceptor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyFactory
/*     */   extends ProxyCreatorSupport
/*     */ {
/*     */   public ProxyFactory() {}
/*     */   
/*     */   public ProxyFactory(Object target) {
/*  50 */     setTarget(target);
/*  51 */     setInterfaces(ClassUtils.getAllInterfaces(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProxyFactory(Class<?>... proxyInterfaces) {
/*  60 */     setInterfaces(proxyInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProxyFactory(Class<?> proxyInterface, Interceptor interceptor) {
/*  72 */     addInterface(proxyInterface);
/*  73 */     addAdvice((Advice)interceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProxyFactory(Class<?> proxyInterface, TargetSource targetSource) {
/*  83 */     addInterface(proxyInterface);
/*  84 */     setTargetSource(targetSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProxy() {
/*  97 */     return createAopProxy().getProxy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProxy(@Nullable ClassLoader classLoader) {
/* 110 */     return createAopProxy().getProxy(classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getProxyClass(@Nullable ClassLoader classLoader) {
/* 121 */     return createAopProxy().getProxyClass(classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getProxy(Class<T> proxyInterface, Interceptor interceptor) {
/* 137 */     return (T)(new ProxyFactory(proxyInterface, interceptor)).getProxy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getProxy(Class<T> proxyInterface, TargetSource targetSource) {
/* 150 */     return (T)(new ProxyFactory(proxyInterface, targetSource)).getProxy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getProxy(TargetSource targetSource) {
/* 160 */     if (targetSource.getTargetClass() == null) {
/* 161 */       throw new IllegalArgumentException("Cannot create class proxy for TargetSource with null target class");
/*     */     }
/* 163 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 164 */     proxyFactory.setTargetSource(targetSource);
/* 165 */     proxyFactory.setProxyTargetClass(true);
/* 166 */     return proxyFactory.getProxy();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\ProxyFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */