/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.RawTargetAccess;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JdkDynamicAopProxy
/*     */   implements AopProxy, InvocationHandler, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5531744639992436476L;
/*     */   private static final String COROUTINES_FLOW_CLASS_NAME = "kotlinx.coroutines.flow.Flow";
/*  78 */   private static final boolean coroutinesReactorPresent = ClassUtils.isPresent("kotlinx.coroutines.reactor.MonoKt", JdkDynamicAopProxy.class
/*  79 */       .getClassLoader());
/*     */ 
/*     */   
/*  82 */   private static final Log logger = LogFactory.getLog(JdkDynamicAopProxy.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AdvisedSupport advised;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient ProxiedInterfacesCache cache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkDynamicAopProxy(AdvisedSupport config) throws AopConfigException {
/*     */     ProxiedInterfacesCache cache;
/*  98 */     Assert.notNull(config, "AdvisedSupport must not be null");
/*  99 */     this.advised = config;
/*     */ 
/*     */ 
/*     */     
/* 103 */     Object object = config.proxyMetadataCache; if (object instanceof ProxiedInterfacesCache) { ProxiedInterfacesCache proxiedInterfacesCache = (ProxiedInterfacesCache)object;
/* 104 */       cache = proxiedInterfacesCache; }
/*     */     else
/*     */     
/* 107 */     { cache = new ProxiedInterfacesCache(config);
/* 108 */       config.proxyMetadataCache = cache; }
/*     */     
/* 110 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProxy() {
/* 116 */     return getProxy(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProxy(@Nullable ClassLoader classLoader) {
/* 121 */     if (logger.isTraceEnabled()) {
/* 122 */       logger.trace("Creating JDK dynamic proxy: " + String.valueOf(this.advised.getTargetSource()));
/*     */     }
/* 124 */     return Proxy.newProxyInstance(determineClassLoader(classLoader), this.cache.proxiedInterfaces, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getProxyClass(@Nullable ClassLoader classLoader) {
/* 130 */     return Proxy.getProxyClass(determineClassLoader(classLoader), this.cache.proxiedInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassLoader determineClassLoader(@Nullable ClassLoader classLoader) {
/* 138 */     if (classLoader == null)
/*     */     {
/* 140 */       return getClass().getClassLoader();
/*     */     }
/* 142 */     if (classLoader.getParent() == null) {
/*     */       
/* 144 */       ClassLoader aopClassLoader = getClass().getClassLoader();
/* 145 */       ClassLoader aopParent = aopClassLoader.getParent();
/* 146 */       while (aopParent != null) {
/* 147 */         if (classLoader == aopParent)
/*     */         {
/*     */           
/* 150 */           return aopClassLoader;
/*     */         }
/* 152 */         aopParent = aopParent.getParent();
/*     */       } 
/*     */     } 
/*     */     
/* 156 */     return classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 168 */     Object oldProxy = null;
/* 169 */     boolean setProxyContext = false;
/*     */     
/* 171 */     TargetSource targetSource = this.advised.targetSource;
/* 172 */     Object target = null;
/*     */     try {
/*     */       Object retVal;
/* 175 */       if (!this.cache.equalsDefined && AopUtils.isEqualsMethod(method)) {
/*     */         
/* 177 */         retVal = Boolean.valueOf(equals(args[0])); return retVal;
/*     */       } 
/* 179 */       if (!this.cache.hashCodeDefined && AopUtils.isHashCodeMethod(method)) {
/*     */         
/* 181 */         retVal = Integer.valueOf(hashCode()); return retVal;
/*     */       } 
/* 183 */       if (method.getDeclaringClass() == DecoratingProxy.class) {
/*     */         
/* 185 */         retVal = AopProxyUtils.ultimateTargetClass(this.advised); return retVal;
/*     */       } 
/* 187 */       if (!this.advised.opaque && method.getDeclaringClass().isInterface() && method
/* 188 */         .getDeclaringClass().isAssignableFrom(Advised.class)) {
/*     */         
/* 190 */         retVal = AopUtils.invokeJoinpointUsingReflection(this.advised, method, args); return retVal;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 195 */       if (this.advised.exposeProxy) {
/*     */         
/* 197 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 198 */         setProxyContext = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 203 */       target = targetSource.getTarget();
/* 204 */       Class<?> targetClass = (target != null) ? target.getClass() : null;
/*     */ 
/*     */       
/* 207 */       List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*     */ 
/*     */ 
/*     */       
/* 211 */       if (chain.isEmpty()) {
/*     */ 
/*     */ 
/*     */         
/* 215 */         Object[] argsToUse = AopProxyUtils.adaptArgumentsIfNecessary(method, args);
/* 216 */         retVal = AopUtils.invokeJoinpointUsingReflection(target, method, argsToUse);
/*     */       }
/*     */       else {
/*     */         
/* 220 */         ReflectiveMethodInvocation reflectiveMethodInvocation = new ReflectiveMethodInvocation(proxy, target, method, args, targetClass, chain);
/*     */ 
/*     */         
/* 223 */         retVal = reflectiveMethodInvocation.proceed();
/*     */       } 
/*     */ 
/*     */       
/* 227 */       Class<?> returnType = method.getReturnType();
/* 228 */       if (retVal != null && retVal == target && returnType != Object.class && returnType
/* 229 */         .isInstance(proxy) && 
/* 230 */         !RawTargetAccess.class.isAssignableFrom(method.getDeclaringClass())) {
/*     */ 
/*     */ 
/*     */         
/* 234 */         retVal = proxy;
/*     */       }
/* 236 */       else if (retVal == null && returnType != void.class && returnType.isPrimitive()) {
/* 237 */         throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + String.valueOf(method));
/*     */       } 
/*     */       
/* 240 */       if (coroutinesReactorPresent && KotlinDetector.isSuspendingFunction(method)) {
/* 241 */         return "kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName()) ? 
/* 242 */           CoroutinesUtils.asFlow(retVal) : CoroutinesUtils.awaitSingleOrNull(retVal, args[args.length - 1]);
/*     */       }
/* 244 */       return retVal;
/*     */     } finally {
/*     */       
/* 247 */       if (target != null && !targetSource.isStatic())
/*     */       {
/* 249 */         targetSource.releaseTarget(target);
/*     */       }
/* 251 */       if (setProxyContext)
/*     */       {
/* 253 */         AopContext.setCurrentProxy(oldProxy);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     JdkDynamicAopProxy otherProxy;
/* 266 */     if (other == this) {
/* 267 */       return true;
/*     */     }
/* 269 */     if (other == null) {
/* 270 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 274 */     if (other instanceof JdkDynamicAopProxy) { JdkDynamicAopProxy jdkDynamicAopProxy = (JdkDynamicAopProxy)other;
/* 275 */       otherProxy = jdkDynamicAopProxy; }
/*     */     
/* 277 */     else if (Proxy.isProxyClass(other.getClass()))
/* 278 */     { JdkDynamicAopProxy jdkDynamicAopProxy; InvocationHandler ih = Proxy.getInvocationHandler(other);
/* 279 */       if (ih instanceof JdkDynamicAopProxy) { jdkDynamicAopProxy = (JdkDynamicAopProxy)ih; }
/* 280 */       else { return false; }
/*     */       
/* 282 */       otherProxy = jdkDynamicAopProxy; }
/*     */     
/*     */     else
/*     */     
/* 286 */     { return false; }
/*     */ 
/*     */ 
/*     */     
/* 290 */     return AopProxyUtils.equalsInProxy(this.advised, otherProxy.advised);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 298 */     return JdkDynamicAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 308 */     ois.defaultReadObject();
/*     */ 
/*     */     
/* 311 */     this.cache = new ProxiedInterfacesCache(this.advised);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ProxiedInterfacesCache
/*     */   {
/*     */     final Class<?>[] proxiedInterfaces;
/*     */ 
/*     */     
/*     */     final boolean equalsDefined;
/*     */ 
/*     */     
/*     */     final boolean hashCodeDefined;
/*     */ 
/*     */ 
/*     */     
/*     */     ProxiedInterfacesCache(AdvisedSupport config) {
/* 329 */       this.proxiedInterfaces = AopProxyUtils.completeProxiedInterfaces(config, true);
/*     */ 
/*     */ 
/*     */       
/* 333 */       boolean equalsDefined = false;
/* 334 */       boolean hashCodeDefined = false;
/* 335 */       for (Class<?> proxiedInterface : this.proxiedInterfaces) {
/* 336 */         Method[] methods = proxiedInterface.getDeclaredMethods();
/* 337 */         for (Method method : methods) {
/* 338 */           if (AopUtils.isEqualsMethod(method)) {
/* 339 */             equalsDefined = true;
/* 340 */             if (hashCodeDefined) {
/*     */               break;
/*     */             }
/*     */           } 
/* 344 */           if (AopUtils.isHashCodeMethod(method)) {
/* 345 */             hashCodeDefined = true;
/* 346 */             if (equalsDefined) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */         } 
/* 351 */         if (equalsDefined && hashCodeDefined) {
/*     */           break;
/*     */         }
/*     */       } 
/* 355 */       this.equalsDefined = equalsDefined;
/* 356 */       this.hashCodeDefined = hashCodeDefined;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\JdkDynamicAopProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */