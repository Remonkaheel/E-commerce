/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Proxy;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAopProxyFactory
/*    */   implements AopProxyFactory, Serializable
/*    */ {
/* 54 */   public static final DefaultAopProxyFactory INSTANCE = new DefaultAopProxyFactory();
/*    */ 
/*    */   
/*    */   private static final long serialVersionUID = 7930414337282325166L;
/*    */ 
/*    */   
/*    */   public AopProxy createAopProxy(AdvisedSupport config) throws AopConfigException {
/* 61 */     if (config.isOptimize() || config.isProxyTargetClass() || !config.hasUserSuppliedInterfaces()) {
/* 62 */       Class<?> targetClass = config.getTargetClass();
/* 63 */       if (targetClass == null && (config.getProxiedInterfaces()).length == 0) {
/* 64 */         throw new AopConfigException("TargetSource cannot determine target class: Either an interface or a target is required for proxy creation.");
/*    */       }
/*    */       
/* 67 */       if (targetClass == null || targetClass.isInterface() || 
/* 68 */         Proxy.isProxyClass(targetClass) || ClassUtils.isLambdaClass(targetClass)) {
/* 69 */         return new JdkDynamicAopProxy(config);
/*    */       }
/* 71 */       return new ObjenesisCglibAopProxy(config);
/*    */     } 
/*    */     
/* 74 */     return new JdkDynamicAopProxy(config);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\DefaultAopProxyFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */