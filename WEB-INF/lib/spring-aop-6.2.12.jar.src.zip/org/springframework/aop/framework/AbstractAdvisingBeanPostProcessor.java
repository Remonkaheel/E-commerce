/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAdvisingBeanPostProcessor
/*     */   extends ProxyProcessorSupport
/*     */   implements SmartInstantiationAwareBeanPostProcessor
/*     */ {
/*     */   @Nullable
/*     */   protected Advisor advisor;
/*     */   protected boolean beforeExistingAdvisors = false;
/*  45 */   private final Map<Class<?>, Boolean> eligibleBeans = new ConcurrentHashMap<>(256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeforeExistingAdvisors(boolean beforeExistingAdvisors) {
/*  58 */     this.beforeExistingAdvisors = beforeExistingAdvisors;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> determineBeanType(Class<?> beanClass, String beanName) {
/*  64 */     if (this.advisor != null && isEligible(beanClass)) {
/*  65 */       ProxyFactory proxyFactory = new ProxyFactory();
/*  66 */       proxyFactory.copyFrom(this);
/*  67 */       proxyFactory.setTargetClass(beanClass);
/*     */       
/*  69 */       if (!proxyFactory.isProxyTargetClass()) {
/*  70 */         evaluateProxyInterfaces(beanClass, proxyFactory);
/*     */       }
/*  72 */       proxyFactory.addAdvisor(this.advisor);
/*  73 */       customizeProxyFactory(proxyFactory);
/*     */ 
/*     */       
/*  76 */       ClassLoader classLoader = getProxyClassLoader();
/*  77 */       if (classLoader instanceof SmartClassLoader) { SmartClassLoader smartClassLoader = (SmartClassLoader)classLoader; if (classLoader != beanClass
/*  78 */           .getClassLoader())
/*  79 */           classLoader = smartClassLoader.getOriginalClassLoader();  }
/*     */       
/*  81 */       return proxyFactory.getProxyClass(classLoader);
/*     */     } 
/*     */     
/*  84 */     return beanClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName) {
/*  89 */     if (this.advisor == null || bean instanceof AopInfrastructureBean)
/*     */     {
/*  91 */       return bean;
/*     */     }
/*     */     
/*  94 */     if (bean instanceof Advised) { Advised advised = (Advised)bean;
/*  95 */       if (!advised.isFrozen() && isEligible(AopUtils.getTargetClass(bean))) {
/*     */         
/*  97 */         if (this.beforeExistingAdvisors) {
/*  98 */           advised.addAdvisor(0, this.advisor);
/*     */         } else {
/* 100 */           if (advised.getTargetSource() == AdvisedSupport.EMPTY_TARGET_SOURCE && advised
/* 101 */             .getAdvisorCount() > 0) {
/*     */             
/* 103 */             advised.addAdvisor(advised.getAdvisorCount() - 1, this.advisor);
/* 104 */             return bean;
/*     */           } 
/*     */           
/* 107 */           advised.addAdvisor(this.advisor);
/*     */         } 
/* 109 */         return bean;
/*     */       }  }
/*     */ 
/*     */     
/* 113 */     if (isEligible(bean, beanName)) {
/* 114 */       ProxyFactory proxyFactory = prepareProxyFactory(bean, beanName);
/* 115 */       if (!proxyFactory.isProxyTargetClass()) {
/* 116 */         evaluateProxyInterfaces(bean.getClass(), proxyFactory);
/*     */       }
/* 118 */       proxyFactory.addAdvisor(this.advisor);
/* 119 */       customizeProxyFactory(proxyFactory);
/* 120 */       proxyFactory.setPreFiltered(true);
/*     */ 
/*     */       
/* 123 */       ClassLoader classLoader = getProxyClassLoader();
/* 124 */       if (classLoader instanceof SmartClassLoader) { SmartClassLoader smartClassLoader = (SmartClassLoader)classLoader; if (classLoader != bean
/* 125 */           .getClass().getClassLoader())
/* 126 */           classLoader = smartClassLoader.getOriginalClassLoader();  }
/*     */       
/* 128 */       return proxyFactory.getProxy(classLoader);
/*     */     } 
/*     */ 
/*     */     
/* 132 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEligible(Object bean, String beanName) {
/* 151 */     return isEligible(bean.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isEligible(Class<?> targetClass) {
/* 162 */     Boolean eligible = this.eligibleBeans.get(targetClass);
/* 163 */     if (eligible != null) {
/* 164 */       return eligible.booleanValue();
/*     */     }
/* 166 */     if (this.advisor == null) {
/* 167 */       return false;
/*     */     }
/* 169 */     eligible = Boolean.valueOf(AopUtils.canApply(this.advisor, targetClass));
/* 170 */     this.eligibleBeans.put(targetClass, eligible);
/* 171 */     return eligible.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProxyFactory prepareProxyFactory(Object bean, String beanName) {
/* 189 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 190 */     proxyFactory.copyFrom(this);
/* 191 */     proxyFactory.setTarget(bean);
/* 192 */     return proxyFactory;
/*     */   }
/*     */   
/*     */   protected void customizeProxyFactory(ProxyFactory proxyFactory) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\AbstractAdvisingBeanPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */