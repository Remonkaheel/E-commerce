/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionInfo;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.DefaultIntroductionAdvisor;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.aop.target.EmptyTargetSource;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdvisedSupport
/*     */   extends ProxyConfig
/*     */   implements Advised
/*     */ {
/*     */   private static final long serialVersionUID = 2651364800145442165L;
/*  78 */   public static final TargetSource EMPTY_TARGET_SOURCE = (TargetSource)EmptyTargetSource.INSTANCE;
/*     */ 
/*     */ 
/*     */   
/*  82 */   TargetSource targetSource = EMPTY_TARGET_SOURCE;
/*     */ 
/*     */   
/*     */   private boolean preFiltered = false;
/*     */ 
/*     */   
/*  88 */   private AdvisorChainFactory advisorChainFactory = DefaultAdvisorChainFactory.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private List<Class<?>> interfaces = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private List<Advisor> advisors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private List<Advisor> advisorKey = this.advisors;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private transient Map<MethodCacheKey, List<Object>> methodCache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private volatile transient List<Object> cachedInterceptors;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   volatile transient Object proxyMetadataCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvisedSupport() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvisedSupport(Class<?>... interfaces) {
/* 139 */     setInterfaces(interfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(Object target) {
/* 150 */     setTargetSource((TargetSource)new SingletonTargetSource(target));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTargetSource(@Nullable TargetSource targetSource) {
/* 155 */     this.targetSource = (targetSource != null) ? targetSource : EMPTY_TARGET_SOURCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public TargetSource getTargetSource() {
/* 160 */     return this.targetSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetClass(@Nullable Class<?> targetClass) {
/* 177 */     this.targetSource = (TargetSource)EmptyTargetSource.forClass(targetClass);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getTargetClass() {
/* 183 */     return this.targetSource.getTargetClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPreFiltered(boolean preFiltered) {
/* 188 */     this.preFiltered = preFiltered;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPreFiltered() {
/* 193 */     return this.preFiltered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdvisorChainFactory(AdvisorChainFactory advisorChainFactory) {
/* 201 */     Assert.notNull(advisorChainFactory, "AdvisorChainFactory must not be null");
/* 202 */     this.advisorChainFactory = advisorChainFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvisorChainFactory getAdvisorChainFactory() {
/* 209 */     return this.advisorChainFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterfaces(Class<?>... interfaces) {
/* 217 */     Assert.notNull(interfaces, "Interfaces must not be null");
/* 218 */     this.interfaces.clear();
/* 219 */     for (Class<?> ifc : interfaces) {
/* 220 */       addInterface(ifc);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInterface(Class<?> ifc) {
/* 229 */     Assert.notNull(ifc, "Interface must not be null");
/* 230 */     if (!ifc.isInterface()) {
/* 231 */       throw new IllegalArgumentException("[" + ifc.getName() + "] is not an interface");
/*     */     }
/* 233 */     if (!this.interfaces.contains(ifc)) {
/* 234 */       this.interfaces.add(ifc);
/* 235 */       adviceChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeInterface(Class<?> ifc) {
/* 247 */     return this.interfaces.remove(ifc);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getProxiedInterfaces() {
/* 252 */     return ClassUtils.toClassArray(this.interfaces);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInterfaceProxied(Class<?> ifc) {
/* 257 */     for (Class<?> proxyIntf : this.interfaces) {
/* 258 */       if (ifc.isAssignableFrom(proxyIntf)) {
/* 259 */         return true;
/*     */       }
/*     */     } 
/* 262 */     return false;
/*     */   }
/*     */   
/*     */   boolean hasUserSuppliedInterfaces() {
/* 266 */     for (Class<?> ifc : this.interfaces) {
/* 267 */       if (!SpringProxy.class.isAssignableFrom(ifc) && !isAdvisorIntroducedInterface(ifc)) {
/* 268 */         return true;
/*     */       }
/*     */     } 
/* 271 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isAdvisorIntroducedInterface(Class<?> ifc) {
/* 275 */     for (Advisor advisor : this.advisors) {
/* 276 */       if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor introductionAdvisor = (IntroductionAdvisor)advisor;
/* 277 */         for (Class<?> introducedInterface : introductionAdvisor.getInterfaces()) {
/* 278 */           if (introducedInterface == ifc) {
/* 279 */             return true;
/*     */           }
/*     */         }  }
/*     */     
/*     */     } 
/* 284 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Advisor[] getAdvisors() {
/* 290 */     return this.advisors.<Advisor>toArray(new Advisor[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAdvisorCount() {
/* 295 */     return this.advisors.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAdvisor(Advisor advisor) {
/* 300 */     int pos = this.advisors.size();
/* 301 */     addAdvisor(pos, advisor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAdvisor(int pos, Advisor advisor) throws AopConfigException {
/* 306 */     if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor introductionAdvisor = (IntroductionAdvisor)advisor;
/* 307 */       validateIntroductionAdvisor(introductionAdvisor); }
/*     */     
/* 309 */     addAdvisorInternal(pos, advisor);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAdvisor(Advisor advisor) {
/* 314 */     int index = indexOf(advisor);
/* 315 */     if (index == -1) {
/* 316 */       return false;
/*     */     }
/*     */     
/* 319 */     removeAdvisor(index);
/* 320 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAdvisor(int index) throws AopConfigException {
/* 326 */     if (isFrozen()) {
/* 327 */       throw new AopConfigException("Cannot remove Advisor: Configuration is frozen.");
/*     */     }
/* 329 */     if (index < 0 || index > this.advisors.size() - 1) {
/* 330 */       throw new AopConfigException("Advisor index " + index + " is out of bounds: This configuration only has " + this.advisors
/* 331 */           .size() + " advisors.");
/*     */     }
/*     */     
/* 334 */     Advisor advisor = this.advisors.remove(index);
/* 335 */     if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor introductionAdvisor = (IntroductionAdvisor)advisor;
/*     */       
/* 337 */       for (Class<?> ifc : introductionAdvisor.getInterfaces()) {
/* 338 */         removeInterface(ifc);
/*     */       } }
/*     */ 
/*     */     
/* 342 */     adviceChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Advisor advisor) {
/* 347 */     Assert.notNull(advisor, "Advisor must not be null");
/* 348 */     return this.advisors.indexOf(advisor);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean replaceAdvisor(Advisor a, Advisor b) throws AopConfigException {
/* 353 */     Assert.notNull(a, "Advisor a must not be null");
/* 354 */     Assert.notNull(b, "Advisor b must not be null");
/* 355 */     int index = indexOf(a);
/* 356 */     if (index == -1) {
/* 357 */       return false;
/*     */     }
/* 359 */     removeAdvisor(index);
/* 360 */     addAdvisor(index, b);
/* 361 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAdvisors(Advisor... advisors) {
/* 369 */     addAdvisors(Arrays.asList(advisors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAdvisors(Collection<Advisor> advisors) {
/* 377 */     if (isFrozen()) {
/* 378 */       throw new AopConfigException("Cannot add advisor: Configuration is frozen.");
/*     */     }
/* 380 */     if (!CollectionUtils.isEmpty(advisors)) {
/* 381 */       for (Advisor advisor : advisors) {
/* 382 */         if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor introductionAdvisor = (IntroductionAdvisor)advisor;
/* 383 */           validateIntroductionAdvisor(introductionAdvisor); }
/*     */         
/* 385 */         Assert.notNull(advisor, "Advisor must not be null");
/* 386 */         this.advisors.add(advisor);
/*     */       } 
/* 388 */       adviceChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateIntroductionAdvisor(IntroductionAdvisor advisor) {
/* 393 */     advisor.validateInterfaces();
/*     */     
/* 395 */     for (Class<?> ifc : advisor.getInterfaces()) {
/* 396 */       addInterface(ifc);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addAdvisorInternal(int pos, Advisor advisor) throws AopConfigException {
/* 401 */     Assert.notNull(advisor, "Advisor must not be null");
/* 402 */     if (isFrozen()) {
/* 403 */       throw new AopConfigException("Cannot add advisor: Configuration is frozen.");
/*     */     }
/* 405 */     if (pos > this.advisors.size()) {
/* 406 */       throw new IllegalArgumentException("Illegal position " + pos + " in advisor list with size " + this.advisors
/* 407 */           .size());
/*     */     }
/* 409 */     this.advisors.add(pos, advisor);
/* 410 */     adviceChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final List<Advisor> getAdvisorsInternal() {
/* 419 */     return this.advisors;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAdvice(Advice advice) throws AopConfigException {
/* 424 */     int pos = this.advisors.size();
/* 425 */     addAdvice(pos, advice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAdvice(int pos, Advice advice) throws AopConfigException {
/* 433 */     Assert.notNull(advice, "Advice must not be null");
/* 434 */     if (advice instanceof IntroductionInfo) { IntroductionInfo introductionInfo = (IntroductionInfo)advice;
/*     */ 
/*     */       
/* 437 */       addAdvisor(pos, (Advisor)new DefaultIntroductionAdvisor(advice, introductionInfo)); }
/*     */     else
/* 439 */     { if (advice instanceof org.springframework.aop.DynamicIntroductionAdvice)
/*     */       {
/* 441 */         throw new AopConfigException("DynamicIntroductionAdvice may only be added as part of IntroductionAdvisor");
/*     */       }
/*     */       
/* 444 */       addAdvisor(pos, (Advisor)new DefaultPointcutAdvisor(advice)); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAdvice(Advice advice) throws AopConfigException {
/* 450 */     int index = indexOf(advice);
/* 451 */     if (index == -1) {
/* 452 */       return false;
/*     */     }
/*     */     
/* 455 */     removeAdvisor(index);
/* 456 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(Advice advice) {
/* 462 */     Assert.notNull(advice, "Advice must not be null");
/* 463 */     for (int i = 0; i < this.advisors.size(); i++) {
/* 464 */       Advisor advisor = this.advisors.get(i);
/* 465 */       if (advisor.getAdvice() == advice) {
/* 466 */         return i;
/*     */       }
/*     */     } 
/* 469 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean adviceIncluded(@Nullable Advice advice) {
/* 478 */     if (advice != null) {
/* 479 */       for (Advisor advisor : this.advisors) {
/* 480 */         if (advisor.getAdvice() == advice) {
/* 481 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 485 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countAdvicesOfType(@Nullable Class<?> adviceClass) {
/* 494 */     int count = 0;
/* 495 */     if (adviceClass != null) {
/* 496 */       for (Advisor advisor : this.advisors) {
/* 497 */         if (adviceClass.isInstance(advisor.getAdvice())) {
/* 498 */           count++;
/*     */         }
/*     */       } 
/*     */     }
/* 502 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> getInterceptorsAndDynamicInterceptionAdvice(Method method, @Nullable Class<?> targetClass) {
/*     */     List<Object> cachedInterceptors;
/* 515 */     if (this.methodCache != null) {
/*     */       
/* 517 */       MethodCacheKey cacheKey = new MethodCacheKey(method);
/* 518 */       cachedInterceptors = this.methodCache.get(cacheKey);
/* 519 */       if (cachedInterceptors == null) {
/* 520 */         cachedInterceptors = this.advisorChainFactory.getInterceptorsAndDynamicInterceptionAdvice(this, method, targetClass);
/*     */         
/* 522 */         this.methodCache.put(cacheKey, cachedInterceptors);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 527 */       cachedInterceptors = this.cachedInterceptors;
/* 528 */       if (cachedInterceptors == null) {
/* 529 */         cachedInterceptors = this.advisorChainFactory.getInterceptorsAndDynamicInterceptionAdvice(this, method, targetClass);
/*     */         
/* 531 */         this.cachedInterceptors = cachedInterceptors;
/*     */       } 
/*     */     } 
/* 534 */     return cachedInterceptors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adviceChanged() {
/* 541 */     this.methodCache = null;
/* 542 */     this.cachedInterceptors = null;
/* 543 */     this.proxyMetadataCache = null;
/*     */ 
/*     */ 
/*     */     
/* 547 */     for (Advisor advisor : this.advisors) {
/* 548 */       if (advisor instanceof PointcutAdvisor) {
/* 549 */         this.methodCache = new ConcurrentHashMap<>();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyConfigurationFrom(AdvisedSupport other) {
/* 561 */     copyConfigurationFrom(other, other.targetSource, new ArrayList<>(other.advisors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyConfigurationFrom(AdvisedSupport other, TargetSource targetSource, List<Advisor> advisors) {
/* 572 */     copyFrom(other);
/* 573 */     this.targetSource = targetSource;
/* 574 */     this.advisorChainFactory = other.advisorChainFactory;
/* 575 */     this.interfaces = new ArrayList<>(other.interfaces);
/* 576 */     for (Advisor advisor : advisors) {
/* 577 */       if (advisor instanceof IntroductionAdvisor) { IntroductionAdvisor introductionAdvisor = (IntroductionAdvisor)advisor;
/* 578 */         validateIntroductionAdvisor(introductionAdvisor); }
/*     */       
/* 580 */       Assert.notNull(advisor, "Advisor must not be null");
/* 581 */       this.advisors.add(advisor);
/*     */     } 
/* 583 */     adviceChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AdvisedSupport getConfigurationOnlyCopy() {
/* 591 */     AdvisedSupport copy = new AdvisedSupport();
/* 592 */     copy.copyFrom(this);
/* 593 */     copy.targetSource = (TargetSource)EmptyTargetSource.forClass(getTargetClass(), getTargetSource().isStatic());
/* 594 */     copy.preFiltered = this.preFiltered;
/* 595 */     copy.advisorChainFactory = this.advisorChainFactory;
/* 596 */     copy.interfaces = new ArrayList<>(this.interfaces);
/* 597 */     copy.advisors = new ArrayList<>(this.advisors);
/* 598 */     copy.advisorKey = new ArrayList<>(this.advisors.size());
/* 599 */     for (Advisor advisor : this.advisors) {
/* 600 */       copy.advisorKey.add(new AdvisorKeyEntry(advisor));
/*     */     }
/* 602 */     copy.methodCache = this.methodCache;
/* 603 */     copy.cachedInterceptors = this.cachedInterceptors;
/* 604 */     copy.proxyMetadataCache = this.proxyMetadataCache;
/* 605 */     return copy;
/*     */   }
/*     */   
/*     */   void reduceToAdvisorKey() {
/* 609 */     this.advisors = this.advisorKey;
/* 610 */     this.methodCache = null;
/* 611 */     this.cachedInterceptors = null;
/* 612 */     this.proxyMetadataCache = null;
/*     */   }
/*     */   
/*     */   Object getAdvisorKey() {
/* 616 */     return this.advisorKey;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toProxyConfigString() {
/* 622 */     return toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 630 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 631 */     sb.append(": ").append(this.interfaces.size()).append(" interfaces ");
/* 632 */     sb.append(ClassUtils.classNamesToString(this.interfaces)).append("; ");
/* 633 */     sb.append(this.advisors.size()).append(" advisors ");
/* 634 */     sb.append(this.advisors).append("; ");
/* 635 */     sb.append("targetSource [").append(this.targetSource).append("]; ");
/* 636 */     sb.append(super.toString());
/* 637 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 647 */     ois.defaultReadObject();
/*     */ 
/*     */     
/* 650 */     adviceChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MethodCacheKey
/*     */     implements Comparable<MethodCacheKey>
/*     */   {
/*     */     private final Method method;
/*     */ 
/*     */     
/*     */     private final int hashCode;
/*     */ 
/*     */     
/*     */     public MethodCacheKey(Method method) {
/* 665 */       this.method = method;
/* 666 */       this.hashCode = method.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/* 671 */       if (this != other) { if (other instanceof MethodCacheKey) { MethodCacheKey that = (MethodCacheKey)other; if (this.method == that.method || this.method
/* 672 */             .equals(that.method)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 677 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 682 */       return this.method.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(MethodCacheKey other) {
/* 687 */       int result = this.method.getName().compareTo(other.method.getName());
/* 688 */       if (result == 0) {
/* 689 */         result = this.method.toString().compareTo(other.method.toString());
/*     */       }
/* 691 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class AdvisorKeyEntry
/*     */     implements Advisor
/*     */   {
/*     */     private final Class<?> adviceType;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final String classFilterKey;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final String methodMatcherKey;
/*     */ 
/*     */ 
/*     */     
/*     */     public AdvisorKeyEntry(Advisor advisor) {
/* 715 */       this.adviceType = advisor.getAdvice().getClass();
/* 716 */       if (advisor instanceof PointcutAdvisor) { PointcutAdvisor pointcutAdvisor = (PointcutAdvisor)advisor;
/* 717 */         Pointcut pointcut = pointcutAdvisor.getPointcut();
/* 718 */         this.classFilterKey = pointcut.getClassFilter().toString();
/* 719 */         this.methodMatcherKey = pointcut.getMethodMatcher().toString(); }
/*     */       else
/*     */       
/* 722 */       { this.classFilterKey = null;
/* 723 */         this.methodMatcherKey = null; }
/*     */     
/*     */     }
/*     */ 
/*     */     
/*     */     public Advice getAdvice() {
/* 729 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 734 */       if (this != other) { if (other instanceof AdvisorKeyEntry) { AdvisorKeyEntry that = (AdvisorKeyEntry)other; if (this.adviceType == that.adviceType && 
/*     */             
/* 736 */             ObjectUtils.nullSafeEquals(this.classFilterKey, that.classFilterKey) && 
/* 737 */             ObjectUtils.nullSafeEquals(this.methodMatcherKey, that.methodMatcherKey)); }
/*     */         
/*     */         return false; }
/*     */     
/*     */     } public int hashCode() {
/* 742 */       return this.adviceType.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\AdvisedSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */