package org.springframework.aop.framework;

import org.springframework.lang.Nullable;

public interface AopProxy {
  Object getProxy();
  
  Object getProxy(@Nullable ClassLoader paramClassLoader);
  
  Class<?> getProxyClass(@Nullable ClassLoader paramClassLoader);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\AopProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */