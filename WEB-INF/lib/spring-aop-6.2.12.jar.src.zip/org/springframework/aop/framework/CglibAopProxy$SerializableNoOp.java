package org.springframework.aop.framework;

import java.io.Serializable;
import org.springframework.cglib.proxy.NoOp;

public class SerializableNoOp implements NoOp, Serializable {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\CglibAopProxy$SerializableNoOp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */