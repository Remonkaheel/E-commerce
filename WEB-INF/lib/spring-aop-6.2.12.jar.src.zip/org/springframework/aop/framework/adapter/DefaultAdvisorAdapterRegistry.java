/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.aopalliance.aop.Advice;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAdvisorAdapterRegistry
/*    */   implements AdvisorAdapterRegistry, Serializable
/*    */ {
/* 43 */   private final List<AdvisorAdapter> adapters = new ArrayList<>(3);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultAdvisorAdapterRegistry() {
/* 50 */     registerAdvisorAdapter(new MethodBeforeAdviceAdapter());
/* 51 */     registerAdvisorAdapter(new AfterReturningAdviceAdapter());
/* 52 */     registerAdvisorAdapter(new ThrowsAdviceAdapter());
/*    */   }
/*    */ 
/*    */   
/*    */   public Advisor wrap(Object adviceObject) throws UnknownAdviceTypeException {
/*    */     Advice advice;
/* 58 */     if (adviceObject instanceof Advisor) { Advisor advisor = (Advisor)adviceObject;
/* 59 */       return advisor; }
/*    */     
/* 61 */     if (adviceObject instanceof Advice) { advice = (Advice)adviceObject; }
/* 62 */     else { throw new UnknownAdviceTypeException(adviceObject); }
/*    */     
/* 64 */     if (advice instanceof MethodInterceptor)
/*    */     {
/* 66 */       return (Advisor)new DefaultPointcutAdvisor(advice);
/*    */     }
/* 68 */     for (AdvisorAdapter adapter : this.adapters) {
/*    */       
/* 70 */       if (adapter.supportsAdvice(advice)) {
/* 71 */         return (Advisor)new DefaultPointcutAdvisor(advice);
/*    */       }
/*    */     } 
/* 74 */     throw new UnknownAdviceTypeException(advice);
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodInterceptor[] getInterceptors(Advisor advisor) throws UnknownAdviceTypeException {
/* 79 */     List<MethodInterceptor> interceptors = new ArrayList<>(3);
/* 80 */     Advice advice = advisor.getAdvice();
/* 81 */     if (advice instanceof MethodInterceptor) { MethodInterceptor methodInterceptor = (MethodInterceptor)advice;
/* 82 */       interceptors.add(methodInterceptor); }
/*    */     
/* 84 */     for (AdvisorAdapter adapter : this.adapters) {
/* 85 */       if (adapter.supportsAdvice(advice)) {
/* 86 */         interceptors.add(adapter.getInterceptor(advisor));
/*    */       }
/*    */     } 
/* 89 */     if (interceptors.isEmpty()) {
/* 90 */       throw new UnknownAdviceTypeException(advisor.getAdvice());
/*    */     }
/* 92 */     return interceptors.<MethodInterceptor>toArray(new MethodInterceptor[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void registerAdvisorAdapter(AdvisorAdapter adapter) {
/* 97 */     this.adapters.add(adapter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\adapter\DefaultAdvisorAdapterRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */