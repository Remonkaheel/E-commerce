/*     */ package org.springframework.aop.framework.adapter;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.AfterAdvice;
/*     */ import org.springframework.aop.framework.AopConfigException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowsAdviceInterceptor
/*     */   implements MethodInterceptor, AfterAdvice
/*     */ {
/*     */   private static final String AFTER_THROWING = "afterThrowing";
/*  62 */   private static final Log logger = LogFactory.getLog(ThrowsAdviceInterceptor.class);
/*     */ 
/*     */   
/*     */   private final Object throwsAdvice;
/*     */ 
/*     */   
/*  68 */   private final Map<Class<?>, Method> exceptionHandlerMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThrowsAdviceInterceptor(Object throwsAdvice) {
/*  77 */     Assert.notNull(throwsAdvice, "Advice must not be null");
/*  78 */     this.throwsAdvice = throwsAdvice;
/*     */     
/*  80 */     Method[] methods = throwsAdvice.getClass().getMethods();
/*  81 */     for (Method method : methods) {
/*  82 */       if (method.getName().equals("afterThrowing")) {
/*  83 */         Class<?> throwableParam = null;
/*  84 */         if (method.getParameterCount() == 1) {
/*     */           
/*  86 */           throwableParam = method.getParameterTypes()[0];
/*  87 */           if (!Throwable.class.isAssignableFrom(throwableParam)) {
/*  88 */             throw new AopConfigException("Invalid afterThrowing signature: single argument must be a Throwable subclass");
/*     */           
/*     */           }
/*     */         }
/*  92 */         else if (method.getParameterCount() == 4) {
/*     */           
/*  94 */           Class<?>[] paramTypes = method.getParameterTypes();
/*  95 */           if (!Method.class.equals(paramTypes[0]) || !Object[].class.equals(paramTypes[1]) || Throwable.class
/*  96 */             .equals(paramTypes[2]) || !Throwable.class.isAssignableFrom(paramTypes[3])) {
/*  97 */             throw new AopConfigException("Invalid afterThrowing signature: four arguments must be Method, Object[], target, throwable: " + String.valueOf(method));
/*     */           }
/*     */           
/* 100 */           throwableParam = paramTypes[3];
/*     */         } 
/* 102 */         if (throwableParam == null) {
/* 103 */           throw new AopConfigException("Unsupported afterThrowing signature: single throwable argument or four arguments Method, Object[], target, throwable expected: " + String.valueOf(method));
/*     */         }
/*     */ 
/*     */         
/* 107 */         Method existingMethod = this.exceptionHandlerMap.put(throwableParam, method);
/* 108 */         if (existingMethod != null) {
/* 109 */           throw new AopConfigException("Only one afterThrowing method per specific Throwable subclass allowed: " + String.valueOf(method) + " / " + String.valueOf(existingMethod));
/*     */         }
/*     */         
/* 112 */         if (logger.isDebugEnabled()) {
/* 113 */           logger.debug("Found exception handler method on throws advice: " + String.valueOf(method));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 118 */     if (this.exceptionHandlerMap.isEmpty()) {
/* 119 */       throw new AopConfigException("At least one handler method must be found in class [" + 
/* 120 */           String.valueOf(throwsAdvice.getClass()) + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHandlerMethodCount() {
/* 129 */     return this.exceptionHandlerMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/*     */     try {
/* 137 */       return mi.proceed();
/*     */     }
/* 139 */     catch (Throwable ex) {
/* 140 */       Method handlerMethod = getExceptionHandler(ex);
/* 141 */       if (handlerMethod != null) {
/* 142 */         invokeHandlerMethod(mi, ex, handlerMethod);
/*     */       }
/* 144 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Method getExceptionHandler(Throwable exception) {
/* 155 */     Class<?> exceptionClass = exception.getClass();
/* 156 */     if (logger.isTraceEnabled()) {
/* 157 */       logger.trace("Trying to find handler for exception of type [" + exceptionClass.getName() + "]");
/*     */     }
/* 159 */     Method handler = this.exceptionHandlerMap.get(exceptionClass);
/* 160 */     while (handler == null && exceptionClass != Throwable.class) {
/* 161 */       exceptionClass = exceptionClass.getSuperclass();
/* 162 */       handler = this.exceptionHandlerMap.get(exceptionClass);
/*     */     } 
/* 164 */     if (handler != null && logger.isTraceEnabled()) {
/* 165 */       logger.trace("Found handler for exception of type [" + exceptionClass.getName() + "]: " + String.valueOf(handler));
/*     */     }
/* 167 */     return handler;
/*     */   }
/*     */   
/*     */   private void invokeHandlerMethod(MethodInvocation mi, Throwable ex, Method method) throws Throwable {
/*     */     Object[] handlerArgs;
/* 172 */     if (method.getParameterCount() == 1) {
/* 173 */       handlerArgs = new Object[] { ex };
/*     */     } else {
/*     */       
/* 176 */       handlerArgs = new Object[] { mi.getMethod(), mi.getArguments(), mi.getThis(), ex };
/*     */     } 
/*     */     try {
/* 179 */       method.invoke(this.throwsAdvice, handlerArgs);
/*     */     }
/* 181 */     catch (InvocationTargetException targetEx) {
/* 182 */       throw targetEx.getTargetException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\adapter\ThrowsAdviceInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */