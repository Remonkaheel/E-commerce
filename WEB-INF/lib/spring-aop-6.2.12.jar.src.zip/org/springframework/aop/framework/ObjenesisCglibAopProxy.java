/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.cglib.proxy.Callback;
/*    */ import org.springframework.cglib.proxy.Enhancer;
/*    */ import org.springframework.cglib.proxy.Factory;
/*    */ import org.springframework.objenesis.SpringObjenesis;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ObjenesisCglibAopProxy
/*    */   extends CglibAopProxy
/*    */ {
/* 41 */   private static final Log logger = LogFactory.getLog(ObjenesisCglibAopProxy.class);
/*    */   
/* 43 */   private static final SpringObjenesis objenesis = new SpringObjenesis();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ObjenesisCglibAopProxy(AdvisedSupport config) {
/* 51 */     super(config);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class<?> createProxyClass(Enhancer enhancer) {
/* 57 */     return enhancer.createClass();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object createProxyClassAndInstance(Enhancer enhancer, Callback[] callbacks) {
/* 62 */     Class<?> proxyClass = enhancer.createClass();
/* 63 */     Object proxyInstance = null;
/*    */     
/* 65 */     if (objenesis.isWorthTrying()) {
/*    */       try {
/* 67 */         proxyInstance = objenesis.newInstance(proxyClass, enhancer.getUseCache());
/*    */       }
/* 69 */       catch (Throwable ex) {
/* 70 */         logger.debug("Unable to instantiate proxy using Objenesis, falling back to regular proxy construction", ex);
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/* 75 */     if (proxyInstance == null) {
/*    */       
/*    */       try {
/*    */ 
/*    */         
/* 80 */         Constructor<?> ctor = (this.constructorArgs != null) ? proxyClass.getDeclaredConstructor(this.constructorArgTypes) : proxyClass.getDeclaredConstructor(new Class[0]);
/* 81 */         ReflectionUtils.makeAccessible(ctor);
/*    */         
/* 83 */         proxyInstance = (this.constructorArgs != null) ? ctor.newInstance(this.constructorArgs) : ctor.newInstance(new Object[0]);
/*    */       }
/* 85 */       catch (Throwable ex) {
/* 86 */         throw new AopConfigException("Unable to instantiate proxy using Objenesis, and regular proxy instantiation via default constructor fails as well", ex);
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/* 91 */     ((Factory)proxyInstance).setCallbacks(callbacks);
/* 92 */     return proxyInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\ObjenesisCglibAopProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */