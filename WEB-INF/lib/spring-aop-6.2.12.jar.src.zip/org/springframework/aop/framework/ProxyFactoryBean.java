/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.Interceptor;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.UnknownAdviceTypeException;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyFactoryBean
/*     */   extends ProxyCreatorSupport
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware, BeanFactoryAware
/*     */ {
/*     */   public static final String GLOBAL_SUFFIX = "*";
/* 102 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private String[] interceptorNames;
/*     */   
/*     */   @Nullable
/*     */   private String targetName;
/*     */   
/*     */   private boolean autodetectInterfaces = true;
/*     */   
/*     */   private boolean singleton = true;
/*     */   
/* 114 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*     */   
/*     */   private boolean freezeProxy = false;
/*     */   
/*     */   @Nullable
/* 119 */   private transient ClassLoader proxyClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */ 
/*     */   
/*     */   private transient boolean classLoaderConfigured = false;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private transient BeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean advisorChainInitialized = false;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object singletonInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyInterfaces(Class<?>[] proxyInterfaces) throws ClassNotFoundException {
/* 143 */     setInterfaces(proxyInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterceptorNames(String... interceptorNames) {
/* 164 */     this.interceptorNames = interceptorNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetName(String targetName) {
/* 177 */     this.targetName = targetName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutodetectInterfaces(boolean autodetectInterfaces) {
/* 187 */     this.autodetectInterfaces = autodetectInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSingleton(boolean singleton) {
/* 199 */     this.singleton = singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry) {
/* 208 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFrozen(boolean frozen) {
/* 213 */     this.freezeProxy = frozen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyClassLoader(@Nullable ClassLoader classLoader) {
/* 223 */     this.proxyClassLoader = classLoader;
/* 224 */     this.classLoaderConfigured = (classLoader != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 229 */     if (!this.classLoaderConfigured) {
/* 230 */       this.proxyClassLoader = classLoader;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 236 */     this.beanFactory = beanFactory;
/* 237 */     checkInterceptorNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject() throws BeansException {
/* 251 */     initializeAdvisorChain();
/* 252 */     if (isSingleton()) {
/* 253 */       return getSingletonInstance();
/*     */     }
/*     */     
/* 256 */     if (this.targetName == null) {
/* 257 */       this.logger.info("Using non-singleton proxies with singleton targets is often undesirable. Enable prototype proxies by setting the 'targetName' property.");
/*     */     }
/*     */     
/* 260 */     return newPrototypeInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectType() {
/* 273 */     synchronized (this) {
/* 274 */       if (this.singletonInstance != null) {
/* 275 */         return this.singletonInstance.getClass();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 281 */       return createAopProxy().getProxyClass(this.proxyClassLoader);
/*     */     }
/* 283 */     catch (AopConfigException ex) {
/* 284 */       if (getTargetClass() == null) {
/* 285 */         if (this.logger.isDebugEnabled()) {
/* 286 */           this.logger.debug("Failed to determine early proxy class: " + ex.getMessage());
/*     */         }
/* 288 */         return null;
/*     */       } 
/*     */       
/* 291 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 298 */     return this.singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized Object getSingletonInstance() {
/* 308 */     if (this.singletonInstance == null) {
/* 309 */       this.targetSource = freshTargetSource();
/* 310 */       if (this.autodetectInterfaces && (getProxiedInterfaces()).length == 0 && !isProxyTargetClass()) {
/*     */         
/* 312 */         Class<?> targetClass = getTargetClass();
/* 313 */         if (targetClass == null) {
/* 314 */           throw new FactoryBeanNotInitializedException("Cannot determine target class for proxy");
/*     */         }
/* 316 */         setInterfaces(ClassUtils.getAllInterfacesForClass(targetClass, this.proxyClassLoader));
/*     */       } 
/*     */       
/* 319 */       super.setFrozen(this.freezeProxy);
/* 320 */       this.singletonInstance = getProxy(createAopProxy());
/*     */     } 
/* 322 */     return this.singletonInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized Object newPrototypeInstance() {
/* 335 */     ProxyCreatorSupport copy = new ProxyCreatorSupport(getAopProxyFactory());
/*     */ 
/*     */     
/* 338 */     TargetSource targetSource = freshTargetSource();
/* 339 */     copy.copyConfigurationFrom(this, targetSource, freshAdvisorChain());
/* 340 */     if (this.autodetectInterfaces && (getProxiedInterfaces()).length == 0 && !isProxyTargetClass()) {
/*     */       
/* 342 */       Class<?> targetClass = targetSource.getTargetClass();
/* 343 */       if (targetClass != null) {
/* 344 */         copy.setInterfaces(ClassUtils.getAllInterfacesForClass(targetClass, this.proxyClassLoader));
/*     */       }
/*     */     } 
/* 347 */     copy.setFrozen(this.freezeProxy);
/*     */     
/* 349 */     return getProxy(copy.createAopProxy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getProxy(AopProxy aopProxy) {
/* 362 */     return aopProxy.getProxy(this.proxyClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkInterceptorNames() {
/* 370 */     if (!ObjectUtils.isEmpty((Object[])this.interceptorNames)) {
/* 371 */       String finalName = this.interceptorNames[this.interceptorNames.length - 1];
/* 372 */       if (this.targetName == null && this.targetSource == EMPTY_TARGET_SOURCE)
/*     */       {
/*     */         
/* 375 */         if (!finalName.endsWith("*") && !isNamedBeanAnAdvisorOrAdvice(finalName)) {
/*     */           
/* 377 */           this.targetName = finalName;
/* 378 */           if (this.logger.isDebugEnabled()) {
/* 379 */             this.logger.debug("Bean with name '" + finalName + "' concluding interceptor chain is not an advisor class: treating it as a target or TargetSource");
/*     */           }
/*     */           
/* 382 */           this.interceptorNames = Arrays.<String>copyOf(this.interceptorNames, this.interceptorNames.length - 1);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isNamedBeanAnAdvisorOrAdvice(String beanName) {
/* 396 */     Assert.state((this.beanFactory != null), "No BeanFactory set");
/* 397 */     Class<?> namedBeanClass = this.beanFactory.getType(beanName);
/* 398 */     if (namedBeanClass != null) {
/* 399 */       return (Advisor.class.isAssignableFrom(namedBeanClass) || Advice.class.isAssignableFrom(namedBeanClass));
/*     */     }
/*     */     
/* 402 */     if (this.logger.isDebugEnabled()) {
/* 403 */       this.logger.debug("Could not determine type of bean with name '" + beanName + "' - assuming it is neither an Advisor nor an Advice");
/*     */     }
/*     */     
/* 406 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initializeAdvisorChain() throws AopConfigException, BeansException {
/* 416 */     if (!this.advisorChainInitialized && !ObjectUtils.isEmpty((Object[])this.interceptorNames)) {
/* 417 */       if (this.beanFactory == null) {
/* 418 */         throw new IllegalStateException("No BeanFactory available anymore (probably due to serialization) - cannot resolve interceptor names " + 
/* 419 */             Arrays.toString(this.interceptorNames));
/*     */       }
/*     */ 
/*     */       
/* 423 */       if (this.interceptorNames[this.interceptorNames.length - 1].endsWith("*") && this.targetName == null && this.targetSource == EMPTY_TARGET_SOURCE)
/*     */       {
/* 425 */         throw new AopConfigException("Target required after globals");
/*     */       }
/*     */ 
/*     */       
/* 429 */       for (String name : this.interceptorNames) {
/* 430 */         if (name.endsWith("*")) {
/* 431 */           ListableBeanFactory lbf; BeanFactory beanFactory = this.beanFactory; if (beanFactory instanceof ListableBeanFactory) { lbf = (ListableBeanFactory)beanFactory; }
/* 432 */           else { throw new AopConfigException("Can only use global advisors or interceptors with a ListableBeanFactory"); }
/*     */ 
/*     */           
/* 435 */           addGlobalAdvisors(lbf, name.substring(0, name.length() - "*".length()));
/*     */         } else {
/*     */           Object advice;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 442 */           if (this.singleton || this.beanFactory.isSingleton(name)) {
/*     */             
/* 444 */             advice = this.beanFactory.getBean(name);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 449 */             advice = new PrototypePlaceholderAdvisor(name);
/*     */           } 
/* 451 */           addAdvisorOnChainCreation(advice);
/*     */         } 
/*     */       } 
/*     */       
/* 455 */       this.advisorChainInitialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Advisor> freshAdvisorChain() {
/* 466 */     Advisor[] advisors = getAdvisors();
/* 467 */     List<Advisor> freshAdvisors = new ArrayList<>(advisors.length);
/* 468 */     for (Advisor advisor : advisors) {
/* 469 */       if (advisor instanceof PrototypePlaceholderAdvisor) { PrototypePlaceholderAdvisor ppa = (PrototypePlaceholderAdvisor)advisor;
/* 470 */         if (this.logger.isDebugEnabled()) {
/* 471 */           this.logger.debug("Refreshing bean named '" + ppa.getBeanName() + "'");
/*     */         }
/*     */         
/* 474 */         if (this.beanFactory == null) {
/* 475 */           throw new IllegalStateException("No BeanFactory available anymore (probably due to serialization) - cannot resolve prototype advisor '" + ppa
/* 476 */               .getBeanName() + "'");
/*     */         }
/* 478 */         Object bean = this.beanFactory.getBean(ppa.getBeanName());
/* 479 */         Advisor refreshedAdvisor = namedBeanToAdvisor(bean);
/* 480 */         freshAdvisors.add(refreshedAdvisor); }
/*     */       
/*     */       else
/*     */       
/* 484 */       { freshAdvisors.add(advisor); }
/*     */     
/*     */     } 
/* 487 */     return freshAdvisors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addGlobalAdvisors(ListableBeanFactory beanFactory, String prefix) {
/* 495 */     String[] globalAdvisorNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, Advisor.class);
/*     */     
/* 497 */     String[] globalInterceptorNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, Interceptor.class);
/* 498 */     if (globalAdvisorNames.length > 0 || globalInterceptorNames.length > 0) {
/* 499 */       List<Object> beans = new ArrayList(globalAdvisorNames.length + globalInterceptorNames.length);
/* 500 */       for (String name : globalAdvisorNames) {
/* 501 */         if (name.startsWith(prefix)) {
/* 502 */           beans.add(beanFactory.getBean(name));
/*     */         }
/*     */       } 
/* 505 */       for (String name : globalInterceptorNames) {
/* 506 */         if (name.startsWith(prefix)) {
/* 507 */           beans.add(beanFactory.getBean(name));
/*     */         }
/*     */       } 
/* 510 */       AnnotationAwareOrderComparator.sort(beans);
/* 511 */       for (Object bean : beans) {
/* 512 */         addAdvisorOnChainCreation(bean);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addAdvisorOnChainCreation(Object next) {
/* 527 */     addAdvisor(namedBeanToAdvisor(next));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TargetSource freshTargetSource() {
/* 537 */     if (this.targetName == null)
/*     */     {
/* 539 */       return this.targetSource;
/*     */     }
/*     */     
/* 542 */     if (this.beanFactory == null) {
/* 543 */       throw new IllegalStateException("No BeanFactory available anymore (probably due to serialization) - cannot resolve target with name '" + this.targetName + "'");
/*     */     }
/*     */     
/* 546 */     if (this.logger.isDebugEnabled()) {
/* 547 */       this.logger.debug("Refreshing target with name '" + this.targetName + "'");
/*     */     }
/* 549 */     Object target = this.beanFactory.getBean(this.targetName);
/* 550 */     TargetSource targetSource = (TargetSource)target; return (target instanceof TargetSource) ? targetSource : (TargetSource)new SingletonTargetSource(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Advisor namedBeanToAdvisor(Object next) {
/*     */     try {
/* 560 */       return this.advisorAdapterRegistry.wrap(next);
/*     */     }
/* 562 */     catch (UnknownAdviceTypeException ex) {
/*     */ 
/*     */       
/* 565 */       throw new AopConfigException("Unknown advisor type " + String.valueOf(next.getClass()) + "; can only include Advisor or Advice type beans in interceptorNames chain except for last entry which may also be target instance or TargetSource", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adviceChanged() {
/* 576 */     super.adviceChanged();
/* 577 */     if (this.singleton) {
/* 578 */       this.logger.debug("Advice has changed; re-caching singleton instance");
/* 579 */       synchronized (this) {
/* 580 */         this.singletonInstance = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 592 */     ois.defaultReadObject();
/*     */ 
/*     */     
/* 595 */     this.proxyClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PrototypePlaceholderAdvisor
/*     */     implements Advisor, Serializable
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */     
/*     */     private final String message;
/*     */ 
/*     */     
/*     */     public PrototypePlaceholderAdvisor(String beanName) {
/* 610 */       this.beanName = beanName;
/* 611 */       this.message = "Placeholder for prototype Advisor/Advice with bean name '" + beanName + "'";
/*     */     }
/*     */     
/*     */     public String getBeanName() {
/* 615 */       return this.beanName;
/*     */     }
/*     */ 
/*     */     
/*     */     public Advice getAdvice() {
/* 620 */       throw new UnsupportedOperationException("Cannot invoke methods: " + this.message);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 625 */       return this.message;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\framework\ProxyFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */