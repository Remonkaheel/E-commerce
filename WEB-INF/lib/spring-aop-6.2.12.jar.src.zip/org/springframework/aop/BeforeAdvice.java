package org.springframework.aop;

import org.aopalliance.aop.Advice;

public interface BeforeAdvice extends Advice {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\BeforeAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */