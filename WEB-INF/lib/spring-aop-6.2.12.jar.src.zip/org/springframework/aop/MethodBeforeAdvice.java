package org.springframework.aop;

import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

public interface MethodBeforeAdvice extends BeforeAdvice {
  void before(Method paramMethod, Object[] paramArrayOfObject, @Nullable Object paramObject) throws Throwable;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\MethodBeforeAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */