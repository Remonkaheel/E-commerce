/*     */ package org.springframework.aop.scope;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.InstanceSupplier;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ScopedProxyBeanRegistrationAotProcessor
/*     */   implements BeanRegistrationAotProcessor
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(ScopedProxyBeanRegistrationAotProcessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/*  59 */     Class<?> beanClass = registeredBean.getBeanClass();
/*  60 */     if (beanClass.equals(ScopedProxyFactoryBean.class)) {
/*  61 */       String targetBeanName = getTargetBeanName((BeanDefinition)registeredBean.getMergedBeanDefinition());
/*     */       
/*  63 */       BeanDefinition targetBeanDefinition = getTargetBeanDefinition((ConfigurableBeanFactory)registeredBean.getBeanFactory(), targetBeanName);
/*  64 */       if (targetBeanDefinition == null) {
/*  65 */         logger.warn("Could not handle " + ScopedProxyFactoryBean.class.getSimpleName() + ": no target bean definition found with name " + targetBeanName);
/*     */         
/*  67 */         return null;
/*     */       } 
/*  69 */       return BeanRegistrationAotContribution.withCustomCodeFragments(codeFragments -> new ScopedProxyBeanRegistrationCodeFragments(codeFragments, registeredBean, targetBeanName, targetBeanDefinition));
/*     */     } 
/*     */ 
/*     */     
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getTargetBeanName(BeanDefinition beanDefinition) {
/*  78 */     Object value = beanDefinition.getPropertyValues().get("targetBeanName");
/*  79 */     String targetBeanName = (String)value; return (value instanceof String) ? targetBeanName : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private BeanDefinition getTargetBeanDefinition(ConfigurableBeanFactory beanFactory, @Nullable String targetBeanName) {
/*  86 */     if (targetBeanName != null && beanFactory.containsBean(targetBeanName)) {
/*  87 */       return beanFactory.getMergedBeanDefinition(targetBeanName);
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ScopedProxyBeanRegistrationCodeFragments
/*     */     extends BeanRegistrationCodeFragmentsDecorator
/*     */   {
/*     */     private static final String REGISTERED_BEAN_PARAMETER_NAME = "registeredBean";
/*     */     
/*     */     private final RegisteredBean registeredBean;
/*     */     
/*     */     private final String targetBeanName;
/*     */     
/*     */     private final BeanDefinition targetBeanDefinition;
/*     */ 
/*     */     
/*     */     ScopedProxyBeanRegistrationCodeFragments(BeanRegistrationCodeFragments delegate, RegisteredBean registeredBean, String targetBeanName, BeanDefinition targetBeanDefinition) {
/* 106 */       super(delegate);
/* 107 */       this.registeredBean = registeredBean;
/* 108 */       this.targetBeanName = targetBeanName;
/* 109 */       this.targetBeanDefinition = targetBeanDefinition;
/*     */     }
/*     */ 
/*     */     
/*     */     public ClassName getTarget(RegisteredBean registeredBean) {
/* 114 */       return ClassName.get(this.targetBeanDefinition.getResolvableType().toClass());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateNewBeanDefinitionCode(GenerationContext generationContext, ResolvableType beanType, BeanRegistrationCode beanRegistrationCode) {
/* 121 */       return super.generateNewBeanDefinitionCode(generationContext, this.targetBeanDefinition
/* 122 */           .getResolvableType(), beanRegistrationCode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateSetBeanDefinitionPropertiesCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, RootBeanDefinition beanDefinition, Predicate<String> attributeFilter) {
/* 130 */       RootBeanDefinition processedBeanDefinition = new RootBeanDefinition(beanDefinition);
/* 131 */       processedBeanDefinition.setTargetType(this.targetBeanDefinition.getResolvableType());
/* 132 */       processedBeanDefinition.getPropertyValues().removePropertyValue("targetBeanName");
/* 133 */       return super.generateSetBeanDefinitionPropertiesCode(generationContext, beanRegistrationCode, processedBeanDefinition, attributeFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 143 */       GeneratedMethod generatedMethod = beanRegistrationCode.getMethods().add("getScopedProxyInstance", method -> {
/*     */             method.addJavadoc("Create the scoped proxy bean instance for '$L'.", new Object[] { this.registeredBean.getBeanName() });
/*     */             
/*     */             method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */             
/*     */             method.returns(ScopedProxyFactoryBean.class);
/*     */             
/*     */             method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */             method.addStatement("$T factory = new $T()", new Object[] { ScopedProxyFactoryBean.class, ScopedProxyFactoryBean.class });
/*     */             method.addStatement("factory.setTargetBeanName($S)", new Object[] { this.targetBeanName });
/*     */             method.addStatement("factory.setBeanFactory($L.getBeanFactory())", new Object[] { "registeredBean" });
/*     */             method.addStatement("return factory", new Object[0]);
/*     */           });
/* 156 */       return CodeBlock.of("$T.of($L)", new Object[] { InstanceSupplier.class, generatedMethod
/* 157 */             .toMethodReference().toCodeBlock() });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\scope\ScopedProxyBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */