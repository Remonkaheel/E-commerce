package org.springframework.aop.scope;

import org.springframework.aop.RawTargetAccess;

public interface ScopedObject extends RawTargetAccess {
  Object getTargetObject();
  
  void removeFromScope();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\scope\ScopedObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */