/*     */ package org.springframework.aop.scope;
/*     */ 
/*     */ import org.springframework.aop.framework.autoproxy.AutoProxyUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.lang.Contract;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ScopedProxyUtils
/*     */ {
/*     */   private static final String TARGET_NAME_PREFIX = "scopedTarget.";
/*  44 */   private static final int TARGET_NAME_PREFIX_LENGTH = "scopedTarget.".length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanDefinitionHolder createScopedProxy(BeanDefinitionHolder definition, BeanDefinitionRegistry registry, boolean proxyTargetClass) {
/*  60 */     String originalBeanName = definition.getBeanName();
/*  61 */     BeanDefinition targetDefinition = definition.getBeanDefinition();
/*  62 */     String targetBeanName = getTargetBeanName(originalBeanName);
/*     */ 
/*     */ 
/*     */     
/*  66 */     RootBeanDefinition proxyDefinition = new RootBeanDefinition(ScopedProxyFactoryBean.class);
/*  67 */     proxyDefinition.setDecoratedDefinition(new BeanDefinitionHolder(targetDefinition, targetBeanName));
/*  68 */     proxyDefinition.setOriginatingBeanDefinition(targetDefinition);
/*  69 */     proxyDefinition.setSource(definition.getSource());
/*  70 */     proxyDefinition.setRole(targetDefinition.getRole());
/*     */     
/*  72 */     proxyDefinition.getPropertyValues().add("targetBeanName", targetBeanName);
/*  73 */     if (proxyTargetClass) {
/*  74 */       targetDefinition.setAttribute(AutoProxyUtils.PRESERVE_TARGET_CLASS_ATTRIBUTE, Boolean.TRUE);
/*     */     }
/*     */     else {
/*     */       
/*  78 */       proxyDefinition.getPropertyValues().add("proxyTargetClass", Boolean.FALSE);
/*     */     } 
/*     */ 
/*     */     
/*  82 */     proxyDefinition.setAutowireCandidate(targetDefinition.isAutowireCandidate());
/*  83 */     proxyDefinition.setPrimary(targetDefinition.isPrimary());
/*  84 */     proxyDefinition.setFallback(targetDefinition.isFallback());
/*  85 */     if (targetDefinition instanceof AbstractBeanDefinition) { AbstractBeanDefinition abd = (AbstractBeanDefinition)targetDefinition;
/*  86 */       proxyDefinition.setDefaultCandidate(abd.isDefaultCandidate());
/*  87 */       proxyDefinition.copyQualifiersFrom(abd); }
/*     */ 
/*     */ 
/*     */     
/*  91 */     targetDefinition.setAutowireCandidate(false);
/*  92 */     targetDefinition.setPrimary(false);
/*  93 */     targetDefinition.setFallback(false);
/*  94 */     if (targetDefinition instanceof AbstractBeanDefinition) { AbstractBeanDefinition abd = (AbstractBeanDefinition)targetDefinition;
/*  95 */       abd.setDefaultCandidate(false); }
/*     */ 
/*     */ 
/*     */     
/*  99 */     registry.registerBeanDefinition(targetBeanName, targetDefinition);
/*     */ 
/*     */ 
/*     */     
/* 103 */     return new BeanDefinitionHolder((BeanDefinition)proxyDefinition, originalBeanName, definition.getAliases());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTargetBeanName(String originalBeanName) {
/* 113 */     return "scopedTarget." + originalBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getOriginalBeanName(@Nullable String targetBeanName) {
/* 128 */     Assert.isTrue(isScopedTarget(targetBeanName), () -> "bean name '" + targetBeanName + "' does not refer to the target of a scoped proxy");
/*     */     
/* 130 */     return targetBeanName.substring(TARGET_NAME_PREFIX_LENGTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("null -> false")
/*     */   public static boolean isScopedTarget(@Nullable String beanName) {
/* 140 */     return (beanName != null && beanName.startsWith("scopedTarget."));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\scope\ScopedProxyUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */