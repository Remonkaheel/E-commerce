/*     */ package org.springframework.aop.scope;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyConfig;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.aop.target.SimpleBeanTargetSource;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScopedProxyFactoryBean
/*     */   extends ProxyConfig
/*     */   implements FactoryBean<Object>, BeanFactoryAware, AopInfrastructureBean
/*     */ {
/*  59 */   private final SimpleBeanTargetSource scopedTargetSource = new SimpleBeanTargetSource();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String targetBeanName;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object proxy;
/*     */ 
/*     */ 
/*     */   
/*     */   public ScopedProxyFactoryBean() {
/*  74 */     setProxyTargetClass(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetBeanName(String targetBeanName) {
/*  82 */     this.targetBeanName = targetBeanName;
/*  83 */     this.scopedTargetSource.setTargetBeanName(targetBeanName);
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*     */     ConfigurableBeanFactory cbf;
/*  88 */     if (beanFactory instanceof ConfigurableBeanFactory) { cbf = (ConfigurableBeanFactory)beanFactory; }
/*  89 */     else { throw new IllegalStateException("Not running in a ConfigurableBeanFactory: " + String.valueOf(beanFactory)); }
/*     */     
/*  91 */     this.scopedTargetSource.setBeanFactory(beanFactory);
/*     */     
/*  93 */     ProxyFactory pf = new ProxyFactory();
/*  94 */     pf.copyFrom(this);
/*  95 */     pf.setTargetSource((TargetSource)this.scopedTargetSource);
/*     */     
/*  97 */     Assert.notNull(this.targetBeanName, "Property 'targetBeanName' is required");
/*  98 */     Class<?> beanType = beanFactory.getType(this.targetBeanName);
/*  99 */     if (beanType == null) {
/* 100 */       throw new IllegalStateException("Cannot create scoped proxy for bean '" + this.targetBeanName + "': Target type could not be determined at the time of proxy creation.");
/*     */     }
/*     */     
/* 103 */     if (!isProxyTargetClass() || beanType.isInterface() || Modifier.isPrivate(beanType.getModifiers())) {
/* 104 */       pf.setInterfaces(ClassUtils.getAllInterfacesForClass(beanType, cbf.getBeanClassLoader()));
/*     */     }
/*     */ 
/*     */     
/* 108 */     ScopedObject scopedObject = new DefaultScopedObject(cbf, this.scopedTargetSource.getTargetBeanName());
/* 109 */     pf.addAdvice((Advice)new DelegatingIntroductionInterceptor(scopedObject));
/*     */ 
/*     */ 
/*     */     
/* 113 */     pf.addInterface(AopInfrastructureBean.class);
/*     */     
/* 115 */     this.proxy = pf.getProxy(cbf.getBeanClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getObject() {
/* 122 */     if (this.proxy == null) {
/* 123 */       throw new FactoryBeanNotInitializedException();
/*     */     }
/* 125 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getObjectType() {
/* 131 */     if (this.proxy != null) {
/* 132 */       return this.proxy.getClass();
/*     */     }
/* 134 */     return this.scopedTargetSource.getTargetClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 139 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aop-6.2.12.jar!\org\springframework\aop\scope\ScopedProxyFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */