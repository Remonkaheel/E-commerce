package META-INF.versions.9.net.bytebuddy.dynamic.scaffold.subclass;

import java.util.List;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.scaffold.MethodRegistry;

public interface ConstructorStrategy {
  List<MethodDescription.Token> extractConstructors(TypeDescription paramTypeDescription);
  
  MethodRegistry inject(TypeDescription paramTypeDescription, MethodRegistry paramMethodRegistry);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\subclass\ConstructorStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */