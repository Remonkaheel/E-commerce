package META-INF.versions.9.net.bytebuddy.dynamic.scaffold.inline;

import java.util.List;
import java.util.Map;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.dynamic.DynamicType;

public interface MethodRebaseResolver {
  Resolution resolve(MethodDescription.InDefinedShape paramInDefinedShape);
  
  List<DynamicType> getAuxiliaryTypes();
  
  Map<MethodDescription.SignatureToken, Resolution> asTokenMap();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\inline\MethodRebaseResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */