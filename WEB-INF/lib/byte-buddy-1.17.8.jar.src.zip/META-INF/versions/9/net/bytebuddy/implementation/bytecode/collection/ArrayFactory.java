/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.collection;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.implementation.bytecode.collection.CollectionFactory;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ArrayFactory
/*     */   implements CollectionFactory
/*     */ {
/*     */   private final TypeDescription.Generic componentType;
/*     */   private final ArrayCreator arrayCreator;
/*     */   @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.IGNORE)
/*     */   private final StackManipulation.Size sizeDecrease;
/*     */   
/*     */   protected ArrayFactory(TypeDescription.Generic componentType, ArrayCreator arrayCreator) {
/*  65 */     this.componentType = componentType;
/*  66 */     this.arrayCreator = arrayCreator;
/*     */     
/*  68 */     this.sizeDecrease = StackSize.DOUBLE.toDecreasingSize().aggregate(componentType.getStackSize().toDecreasingSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.collection.ArrayFactory forType(TypeDescription.Generic componentType) {
/*  78 */     return new net.bytebuddy.implementation.bytecode.collection.ArrayFactory(componentType, makeArrayCreatorFor((TypeDefinition)componentType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ArrayCreator makeArrayCreatorFor(TypeDefinition componentType) {
/*  88 */     if (!componentType.isPrimitive())
/*  89 */       return (ArrayCreator)new ArrayCreator.ForReferenceType(componentType.asErasure()); 
/*  90 */     if (componentType.represents(boolean.class))
/*  91 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.BOOLEAN; 
/*  92 */     if (componentType.represents(byte.class))
/*  93 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.BYTE; 
/*  94 */     if (componentType.represents(short.class))
/*  95 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.SHORT; 
/*  96 */     if (componentType.represents(char.class))
/*  97 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.CHARACTER; 
/*  98 */     if (componentType.represents(int.class))
/*  99 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.INTEGER; 
/* 100 */     if (componentType.represents(long.class))
/* 101 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.LONG; 
/* 102 */     if (componentType.represents(float.class))
/* 103 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.FLOAT; 
/* 104 */     if (componentType.represents(double.class)) {
/* 105 */       return (ArrayCreator)ArrayCreator.ForPrimitiveType.DOUBLE;
/*     */     }
/* 107 */     throw new IllegalArgumentException("Cannot create array of type " + componentType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation withValues(List<? extends StackManipulation> stackManipulations) {
/* 115 */     return (StackManipulation)new ArrayStackManipulation(this, stackManipulations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescription.Generic getComponentType() {
/* 122 */     return this.componentType;
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.componentType.equals(((net.bytebuddy.implementation.bytecode.collection.ArrayFactory)paramObject).componentType) ? false : (!!this.arrayCreator.equals(((net.bytebuddy.implementation.bytecode.collection.ArrayFactory)paramObject).arrayCreator)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.componentType.hashCode()) * 31 + this.arrayCreator.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\collection\ArrayFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */