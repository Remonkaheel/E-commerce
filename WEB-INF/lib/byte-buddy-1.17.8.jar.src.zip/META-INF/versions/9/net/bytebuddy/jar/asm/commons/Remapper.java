/*     */ package META-INF.versions.9.net.bytebuddy.jar.asm.commons;
/*     */ 
/*     */ import net.bytebuddy.jar.asm.ConstantDynamic;
/*     */ import net.bytebuddy.jar.asm.Handle;
/*     */ import net.bytebuddy.jar.asm.Type;
/*     */ import net.bytebuddy.jar.asm.commons.SignatureRemapper;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureReader;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureVisitor;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Remapper
/*     */ {
/*     */   final int api;
/*     */   
/*     */   @Deprecated
/*     */   public Remapper() {
/*  59 */     this.api = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Remapper(int api) {
/*  69 */     if (api != 589824 && api != 524288 && api != 458752 && api != 393216 && api != 327680 && api != 262144 && api != 17432576)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       throw new IllegalArgumentException(stringConcat$0(api));
/*     */     }
/*  78 */     this.api = api;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapDesc(String descriptor) {
/*  90 */     return mapType(Type.getType(descriptor)).getDescriptor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type mapType(Type type) {
/*     */     StringBuilder remappedDescriptor;
/*     */     int i;
/*     */     String remappedInternalName;
/* 104 */     switch (type.getSort()) {
/*     */       case 9:
/* 106 */         remappedDescriptor = new StringBuilder();
/* 107 */         for (i = 0; i < type.getDimensions(); i++) {
/* 108 */           remappedDescriptor.append('[');
/*     */         }
/* 110 */         remappedDescriptor.append(mapType(type.getElementType()).getDescriptor());
/* 111 */         return Type.getType(remappedDescriptor.toString());
/*     */       case 10:
/* 113 */         remappedInternalName = map(type.getInternalName());
/* 114 */         return (remappedInternalName != null) ? Type.getObjectType(remappedInternalName) : type;
/*     */       case 11:
/* 116 */         return Type.getMethodType(mapMethodDesc(type.getDescriptor()));
/*     */     } 
/* 118 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapType(String internalName) {
/* 131 */     if (internalName == null) {
/* 132 */       return null;
/*     */     }
/* 134 */     return mapType(Type.getObjectType(internalName)).getInternalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] mapTypes(String[] internalNames) {
/* 146 */     String[] remappedInternalNames = null;
/* 147 */     for (int i = 0; i < internalNames.length; i++) {
/* 148 */       String internalName = internalNames[i];
/* 149 */       String remappedInternalName = mapType(internalName);
/* 150 */       if (remappedInternalName != null) {
/* 151 */         if (remappedInternalNames == null) {
/* 152 */           remappedInternalNames = (String[])internalNames.clone();
/*     */         }
/* 154 */         remappedInternalNames[i] = remappedInternalName;
/*     */       } 
/*     */     } 
/* 157 */     return (remappedInternalNames != null) ? remappedInternalNames : internalNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapMethodDesc(String methodDescriptor) {
/* 169 */     if ("()V".equals(methodDescriptor)) {
/* 170 */       return methodDescriptor;
/*     */     }
/*     */     
/* 173 */     StringBuilder stringBuilder = new StringBuilder("(");
/* 174 */     for (Type argumentType : Type.getArgumentTypes(methodDescriptor)) {
/* 175 */       stringBuilder.append(mapType(argumentType).getDescriptor());
/*     */     }
/* 177 */     Type returnType = Type.getReturnType(methodDescriptor);
/* 178 */     if (returnType == Type.VOID_TYPE) {
/* 179 */       stringBuilder.append(")V");
/*     */     } else {
/* 181 */       stringBuilder.append(')').append(mapType(returnType).getDescriptor());
/*     */     } 
/* 183 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object mapValue(Object value) {
/* 197 */     if (value instanceof Type) {
/* 198 */       return mapType((Type)value);
/*     */     }
/* 200 */     if (value instanceof Handle) {
/* 201 */       Handle handle = (Handle)value;
/* 202 */       boolean isFieldHandle = (handle.getTag() <= 4);
/*     */       
/* 204 */       return new Handle(handle
/* 205 */           .getTag(), 
/* 206 */           mapType(handle.getOwner()), 
/* 207 */           isFieldHandle ? 
/* 208 */           mapFieldName(handle.getOwner(), handle.getName(), handle.getDesc()) : 
/* 209 */           mapMethodName(handle.getOwner(), handle.getName(), handle.getDesc()), 
/* 210 */           isFieldHandle ? mapDesc(handle.getDesc()) : mapMethodDesc(handle.getDesc()), handle
/* 211 */           .isInterface());
/*     */     } 
/* 213 */     if (value instanceof ConstantDynamic) {
/* 214 */       ConstantDynamic constantDynamic = (ConstantDynamic)value;
/* 215 */       String name = constantDynamic.getName();
/* 216 */       String descriptor = constantDynamic.getDescriptor();
/* 217 */       Handle bootstrapMethod = constantDynamic.getBootstrapMethod();
/* 218 */       int bootstrapMethodArgumentCount = constantDynamic.getBootstrapMethodArgumentCount();
/* 219 */       Object[] bootstrapMethodArguments = new Object[bootstrapMethodArgumentCount];
/* 220 */       Object[] remappedBootstrapMethodArguments = new Object[bootstrapMethodArgumentCount];
/* 221 */       for (int i = 0; i < bootstrapMethodArgumentCount; i++) {
/* 222 */         bootstrapMethodArguments[i] = constantDynamic.getBootstrapMethodArgument(i);
/* 223 */         remappedBootstrapMethodArguments[i] = mapValue(bootstrapMethodArguments[i]);
/*     */       } 
/* 225 */       if (this.api == 0) {
/* 226 */         name = mapInvokeDynamicMethodName(name, descriptor);
/*     */       } else {
/*     */         
/* 229 */         name = mapInvokeDynamicMethodName(name, descriptor, bootstrapMethod, bootstrapMethodArguments);
/*     */       } 
/* 231 */       return new ConstantDynamic(name, 
/*     */           
/* 233 */           mapDesc(descriptor), (Handle)
/* 234 */           mapValue(bootstrapMethod), remappedBootstrapMethodArguments);
/*     */     } 
/*     */     
/* 237 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapSignature(String signature, boolean typeSignature) {
/* 250 */     if (signature == null) {
/* 251 */       return null;
/*     */     }
/* 253 */     SignatureReader signatureReader = new SignatureReader(signature);
/* 254 */     SignatureWriter signatureWriter = new SignatureWriter();
/* 255 */     SignatureVisitor signatureRemapper = createSignatureRemapper((SignatureVisitor)signatureWriter);
/* 256 */     if (typeSignature) {
/* 257 */       signatureReader.acceptType(signatureRemapper);
/*     */     } else {
/* 259 */       signatureReader.accept(signatureRemapper);
/*     */     } 
/* 261 */     return signatureWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected SignatureVisitor createRemappingSignatureAdapter(SignatureVisitor signatureVisitor) {
/* 275 */     return createSignatureRemapper(signatureVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SignatureVisitor createSignatureRemapper(SignatureVisitor signatureVisitor) {
/* 286 */     return (SignatureVisitor)new SignatureRemapper(signatureVisitor, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapAnnotationAttributeName(String descriptor, String name) {
/* 298 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapInnerClassName(String name, String ownerName, String innerName) {
/* 315 */     String remappedInnerName = mapType(name);
/*     */     
/* 317 */     if (remappedInnerName.equals(name)) {
/* 318 */       return innerName;
/*     */     }
/* 320 */     int originSplit = name.lastIndexOf('/');
/* 321 */     int remappedSplit = remappedInnerName.lastIndexOf('/');
/* 322 */     if (originSplit != -1 && remappedSplit != -1 && 
/* 323 */       name.substring(originSplit).equals(remappedInnerName.substring(remappedSplit)))
/*     */     {
/* 325 */       return innerName;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (remappedInnerName.contains("$")) {
/* 331 */       int index = remappedInnerName.lastIndexOf('$') + 1;
/* 332 */       while (index < remappedInnerName.length() && 
/* 333 */         Character.isDigit(remappedInnerName.charAt(index))) {
/* 334 */         index++;
/*     */       }
/* 336 */       return remappedInnerName.substring(index);
/*     */     } 
/* 338 */     return innerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapMethodName(String owner, String name, String descriptor) {
/* 353 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String mapInvokeDynamicMethodName(String name, String descriptor) {
/* 367 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapInvokeDynamicMethodName(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 388 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapRecordComponentName(String owner, String name, String descriptor) {
/* 403 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapFieldName(String owner, String name, String descriptor) {
/* 417 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapPackageName(String name) {
/* 428 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapModuleName(String name) {
/* 439 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String map(String internalName) {
/* 450 */     return internalName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\jar\asm\commons\Remapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */