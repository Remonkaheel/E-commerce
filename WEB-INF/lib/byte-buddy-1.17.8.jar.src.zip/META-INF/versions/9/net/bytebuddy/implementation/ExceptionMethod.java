/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.Throw;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ExceptionMethod
/*     */   implements Implementation, ByteCodeAppender
/*     */ {
/*     */   private final ConstructionDelegate constructionDelegate;
/*     */   
/*     */   public ExceptionMethod(ConstructionDelegate constructionDelegate) {
/*  49 */     this.constructionDelegate = constructionDelegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation throwing(Class<? extends Throwable> throwableType) {
/*  62 */     return throwing(TypeDescription.ForLoadedType.of(throwableType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation throwing(TypeDescription throwableType) {
/*  75 */     if (!throwableType.isAssignableTo(Throwable.class)) {
/*  76 */       throw new IllegalArgumentException(throwableType + " does not extend throwable");
/*     */     }
/*  78 */     return new net.bytebuddy.implementation.ExceptionMethod((ConstructionDelegate)new ConstructionDelegate.ForDefaultConstructor(throwableType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation throwing(Class<? extends Throwable> throwableType, String message) {
/*  92 */     return throwing(TypeDescription.ForLoadedType.of(throwableType), message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation throwing(TypeDescription throwableType, String message) {
/* 106 */     if (!throwableType.isAssignableTo(Throwable.class)) {
/* 107 */       throw new IllegalArgumentException(throwableType + " does not extend throwable");
/*     */     }
/* 109 */     return new net.bytebuddy.implementation.ExceptionMethod((ConstructionDelegate)new ConstructionDelegate.ForStringConstructor(throwableType, message));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 116 */     return instrumentedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 133 */     StackManipulation.Size stackSize = (new StackManipulation.Compound(new StackManipulation[] { this.constructionDelegate.make(), (StackManipulation)Throw.INSTANCE })).apply(methodVisitor, implementationContext);
/* 134 */     return new ByteCodeAppender.Size(stackSize.getMaximalSize(), instrumentedMethod.getStackSize());
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.constructionDelegate.equals(((net.bytebuddy.implementation.ExceptionMethod)paramObject).constructionDelegate))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return getClass().hashCode() * 31 + this.constructionDelegate.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\ExceptionMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */