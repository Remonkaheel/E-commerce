/*     */ package META-INF.versions.9.net.bytebuddy.utility;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Set;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.description.NamedElement;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.annotation.AnnotationSource;
/*     */ import net.bytebuddy.description.type.PackageDescription;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaModule
/*     */   implements NamedElement.WithOptionalName, AnnotationSource
/*     */ {
/*     */   @AlwaysNull
/*  43 */   public static final net.bytebuddy.utility.JavaModule UNSUPPORTED = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   protected static final Resolver RESOLVER = doPrivileged(JavaDispatcher.of(Resolver.class));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected static final Module MODULE = doPrivileged(JavaDispatcher.of(Module.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AnnotatedElement module;
/*     */ 
/*     */   
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */   
/*     */   protected JavaModule(AnnotatedElement module) {
/*  66 */     this.module = module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  78 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public static net.bytebuddy.utility.JavaModule ofType(Class<?> type) {
/*  89 */     Object module = RESOLVER.getModule(type);
/*  90 */     return (module == null) ? UNSUPPORTED : new net.bytebuddy.utility.JavaModule((AnnotatedElement)module);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.utility.JavaModule of(Object module) {
/* 103 */     if (!MODULE.isInstance(module)) {
/* 104 */       throw new IllegalArgumentException("Not a Java module: " + module);
/*     */     }
/* 106 */     return new net.bytebuddy.utility.JavaModule((AnnotatedElement)module);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSupported() {
/* 115 */     return ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtLeast(ClassFileVersion.JAVA_V9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNamed() {
/* 122 */     return MODULE.isNamed(this.module);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActualName() {
/* 129 */     return MODULE.getName(this.module);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getPackages() {
/* 138 */     return MODULE.getPackages(this.module);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public InputStream getResourceAsStream(String name) throws IOException {
/* 150 */     return MODULE.getResourceAsStream(this.module, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public ClassLoader getClassLoader() {
/* 160 */     return MODULE.getClassLoader(this.module);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object unwrap() {
/* 169 */     return this.module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(net.bytebuddy.utility.JavaModule module) {
/* 179 */     return MODULE.canRead(this.module, module.unwrap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExported(@MaybeNull PackageDescription packageDescription, net.bytebuddy.utility.JavaModule module) {
/* 190 */     return (packageDescription == null || packageDescription
/* 191 */       .isDefault() || MODULE
/* 192 */       .isExported(this.module, packageDescription.getName(), module.unwrap()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpened(@MaybeNull PackageDescription packageDescription, net.bytebuddy.utility.JavaModule module) {
/* 203 */     return (packageDescription == null || packageDescription
/* 204 */       .isDefault() || MODULE
/* 205 */       .isOpen(this.module, packageDescription.getName(), module.unwrap()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationList getDeclaredAnnotations() {
/* 212 */     return (AnnotationList)new AnnotationList.ForLoadedAnnotations(this.module.getDeclaredAnnotations());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 217 */     return this.module.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object other) {
/* 222 */     if (this == other)
/* 223 */       return true; 
/* 224 */     if (!(other instanceof net.bytebuddy.utility.JavaModule)) {
/* 225 */       return false;
/*     */     }
/* 227 */     net.bytebuddy.utility.JavaModule javaModule = (net.bytebuddy.utility.JavaModule)other;
/* 228 */     return this.module.equals(javaModule.module);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 233 */     return this.module.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\JavaModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */