/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bind;
/*    */ 
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.implementation.bind.MethodDelegationBinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ParameterLengthResolver
/*    */   implements MethodDelegationBinder.AmbiguityResolver
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodDelegationBinder.AmbiguityResolver.Resolution resolve(MethodDescription source, MethodDelegationBinder.MethodBinding left, MethodDelegationBinder.MethodBinding right) {
/* 37 */     int leftLength = left.getTarget().getParameters().size();
/* 38 */     int rightLength = right.getTarget().getParameters().size();
/* 39 */     if (leftLength == rightLength)
/* 40 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.AMBIGUOUS; 
/* 41 */     if (leftLength < rightLength) {
/* 42 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT;
/*    */     }
/* 44 */     return MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\ParameterLengthResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */