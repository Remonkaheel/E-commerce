package META-INF.versions.9.net.bytebuddy.implementation.bytecode;

import net.bytebuddy.implementation.Implementation;
import net.bytebuddy.jar.asm.MethodVisitor;

public interface StackManipulation {
  boolean isValid();
  
  Size apply(MethodVisitor paramMethodVisitor, Implementation.Context paramContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\StackManipulation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */