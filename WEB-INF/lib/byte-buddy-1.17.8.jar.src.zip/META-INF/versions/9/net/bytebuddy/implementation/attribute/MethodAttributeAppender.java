package META-INF.versions.9.net.bytebuddy.implementation.attribute;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
import net.bytebuddy.jar.asm.MethodVisitor;

public interface MethodAttributeAppender {
  void apply(MethodVisitor paramMethodVisitor, MethodDescription paramMethodDescription, AnnotationValueFilter paramAnnotationValueFilter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\MethodAttributeAppender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */