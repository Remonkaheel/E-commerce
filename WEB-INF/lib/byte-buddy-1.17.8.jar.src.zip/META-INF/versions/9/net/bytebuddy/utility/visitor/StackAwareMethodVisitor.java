/*     */ package META-INF.versions.9.net.bytebuddy.utility.visitor;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.Handle;
/*     */ import net.bytebuddy.jar.asm.Label;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.Opcodes;
/*     */ import net.bytebuddy.jar.asm.Type;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackAwareMethodVisitor
/*     */   extends MethodVisitor
/*     */ {
/*     */   public static final String UNADJUSTED_PROPERTY = "net.bytebuddy.unadjusted";
/*     */   public static final boolean UNADJUSTED;
/*     */   private List<StackSize> current;
/*     */   private final Map<Label, List<StackSize>> sizes;
/*     */   private int freeIndex;
/*  84 */   private static final int[] SIZE_CHANGE = new int[202]; private static final boolean ACCESS_CONTROLLER; static {
/*  85 */     String encoded = "EFFFFFFFFGGFFFGGFFFEEFGFGFEEEEEEEEEEEEEEEEEEEEDEDEDDDDDCDCDEEEEEEEEEEEEEEEEEEEEBABABBBBDCFFFGGGEDCDCDCDCDCDCDCDCDCDCEEEEDDDDDDDCDCDCEFEFDDEEFFDEDEEEBDDBBDDDDDDCCCCCCCCEEEDDDCDCDEEEEEEEEEEFEEEEEEDDEEDDEE";
/*     */ 
/*     */ 
/*     */     
/*  89 */     for (int index = 0; index < SIZE_CHANGE.length; index++)
/*  90 */       SIZE_CHANGE[index] = encoded.charAt(index) - 69;  } static { boolean disabled;
/*     */     
/*  92 */     try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */     
/*     */     try {
/*     */       disabled = Boolean.parseBoolean(doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.unadjusted")));
/*     */     } catch (Exception ignored) {
/*     */       disabled = false;
/*     */     } 
/*     */     UNADJUSTED = disabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StackAwareMethodVisitor(MethodVisitor methodVisitor, MethodDescription instrumentedMethod) {
/* 117 */     super(OpenedClassReader.ASM_API, methodVisitor);
/* 118 */     this.current = new ArrayList<>();
/* 119 */     this.sizes = new HashMap<>();
/* 120 */     this.freeIndex = instrumentedMethod.getStackSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodVisitor of(MethodVisitor methodVisitor, MethodDescription instrumentedMethod) {
/* 131 */     return UNADJUSTED ? methodVisitor : new net.bytebuddy.utility.visitor.StackAwareMethodVisitor(methodVisitor, instrumentedMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 145 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustStack(int delta) {
/* 154 */     adjustStack(delta, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustStack(int delta, int offset) {
/* 165 */     if (delta > 2)
/* 166 */       throw new IllegalStateException("Cannot push multiple values onto the operand stack: " + delta); 
/* 167 */     if (delta > 0)
/* 168 */     { int position = this.current.size();
/*     */       
/* 170 */       while (offset > 0 && position > 0) {
/* 171 */         offset -= ((StackSize)this.current.get(--position)).getSize();
/*     */       }
/* 173 */       if (offset < 0) {
/* 174 */         throw new IllegalStateException("Unexpected offset underflow: " + offset);
/*     */       }
/* 176 */       this.current.add(position, StackSize.of(delta)); }
/* 177 */     else { if (offset != 0) {
/* 178 */         throw new IllegalStateException("Cannot specify non-zero offset " + offset + " for non-incrementing value: " + delta);
/*     */       }
/* 180 */       while (delta < 0) {
/*     */         
/* 182 */         if (this.current.isEmpty()) {
/*     */           return;
/*     */         }
/* 185 */         delta += ((StackSize)this.current.remove(this.current.size() - 1)).getSize();
/*     */       } 
/* 187 */       if (delta == 1) {
/* 188 */         this.current.add(StackSize.SINGLE);
/* 189 */       } else if (delta != 0) {
/* 190 */         throw new IllegalStateException("Unexpected remainder on the operand stack: " + delta);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drainStack() {
/* 199 */     doDrain(this.current);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int drainStack(int store, int load, StackSize size) {
/* 213 */     if (this.current.isEmpty()) {
/* 214 */       return 0;
/*     */     }
/* 216 */     int difference = ((StackSize)this.current.get(this.current.size() - 1)).getSize() - size.getSize();
/* 217 */     if (this.current.size() == 1 && difference == 0) {
/* 218 */       return 0;
/*     */     }
/* 220 */     super.visitVarInsn(store, this.freeIndex);
/* 221 */     if (difference == 1) {
/* 222 */       super.visitInsn(87);
/* 223 */     } else if (difference != 0) {
/* 224 */       throw new IllegalStateException("Unexpected remainder on the operand stack: " + difference);
/*     */     } 
/* 226 */     doDrain(this.current.subList(0, this.current.size() - 1));
/* 227 */     super.visitVarInsn(load, this.freeIndex);
/* 228 */     return this.freeIndex + size.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doDrain(List<StackSize> stackSizes) {
/* 238 */     ListIterator<StackSize> iterator = stackSizes.listIterator(stackSizes.size());
/* 239 */     while (iterator.hasPrevious()) {
/* 240 */       StackSize current = iterator.previous();
/* 241 */       switch (null.$SwitchMap$net$bytebuddy$implementation$bytecode$StackSize[current.ordinal()]) {
/*     */         case 1:
/* 243 */           super.visitInsn(87);
/*     */           continue;
/*     */         case 2:
/* 246 */           super.visitInsn(88);
/*     */           continue;
/*     */       } 
/* 249 */       throw new IllegalStateException("Unexpected stack size: " + current);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(Label label, List<StackSize> stackSizes) {
/* 261 */     this.sizes.put(label, stackSizes);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInsn(int opcode) {
/* 266 */     switch (opcode) {
/*     */       case 172:
/*     */       case 173:
/*     */       case 174:
/*     */       case 175:
/*     */       case 176:
/*     */       case 177:
/*     */       case 191:
/* 274 */         this.current.clear();
/*     */         break;
/*     */       case 90:
/*     */       case 93:
/* 278 */         adjustStack(SIZE_CHANGE[opcode], SIZE_CHANGE[opcode] + 1);
/*     */         break;
/*     */       case 91:
/*     */       case 94:
/* 282 */         adjustStack(SIZE_CHANGE[opcode], SIZE_CHANGE[opcode] + 2);
/*     */         break;
/*     */       case 136:
/*     */       case 137:
/*     */       case 142:
/*     */       case 144:
/* 288 */         adjustStack(-2);
/* 289 */         adjustStack(1);
/*     */         break;
/*     */       case 133:
/*     */       case 135:
/*     */       case 140:
/*     */       case 141:
/* 295 */         adjustStack(-1);
/* 296 */         adjustStack(2);
/*     */         break;
/*     */       case 47:
/*     */       case 49:
/* 300 */         adjustStack(-2);
/* 301 */         adjustStack(2);
/*     */         break;
/*     */       default:
/* 304 */         adjustStack(SIZE_CHANGE[opcode]); break;
/*     */     } 
/* 306 */     super.visitInsn(opcode);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand) {
/* 311 */     adjustStack(SIZE_CHANGE[opcode]);
/* 312 */     super.visitIntInsn(opcode, operand);
/*     */   }
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"SF_SWITCH_NO_DEFAULT"}, justification = "No action required on default option.")
/*     */   public void visitVarInsn(int opcode, int variable) {
/* 318 */     switch (opcode) {
/*     */       case 54:
/*     */       case 56:
/*     */       case 58:
/* 322 */         this.freeIndex = Math.max(this.freeIndex, variable + 1);
/*     */         break;
/*     */       case 55:
/*     */       case 57:
/* 326 */         this.freeIndex = Math.max(this.freeIndex, variable + 2);
/*     */         break;
/*     */       case 169:
/* 329 */         this.current.clear();
/*     */         break;
/*     */     } 
/* 332 */     adjustStack(SIZE_CHANGE[opcode]);
/* 333 */     super.visitVarInsn(opcode, variable);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type) {
/* 338 */     adjustStack(SIZE_CHANGE[opcode]);
/* 339 */     super.visitTypeInsn(opcode, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
/* 344 */     int baseline = Type.getType(descriptor).getSize();
/* 345 */     switch (opcode) {
/*     */       case 180:
/* 347 */         adjustStack(-1);
/* 348 */         adjustStack(baseline);
/*     */         break;
/*     */       case 178:
/* 351 */         adjustStack(baseline);
/*     */         break;
/*     */       case 181:
/* 354 */         adjustStack(-baseline - 1);
/*     */         break;
/*     */       case 179:
/* 357 */         adjustStack(-baseline);
/*     */         break;
/*     */       default:
/* 360 */         throw new IllegalStateException("Unexpected opcode: " + opcode);
/*     */     } 
/* 362 */     super.visitFieldInsn(opcode, owner, name, descriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
/* 367 */     int baseline = Type.getArgumentsAndReturnSizes(descriptor);
/* 368 */     adjustStack(-(baseline >> 2) + ((opcode == 184) ? 1 : 0));
/* 369 */     adjustStack(baseline & 0x3);
/* 370 */     super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrap, Object... bootstrapArguments) {
/* 375 */     int baseline = Type.getArgumentsAndReturnSizes(descriptor);
/* 376 */     adjustStack(-(baseline >> 2) + 1);
/* 377 */     adjustStack(baseline & 0x3);
/* 378 */     super.visitInvokeDynamicInsn(name, descriptor, bootstrap, bootstrapArguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLdcInsn(Object value) {
/* 383 */     adjustStack((value instanceof Long || value instanceof Double) ? 2 : 1);
/* 384 */     super.visitLdcInsn(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMultiANewArrayInsn(String descriptor, int dimension) {
/* 389 */     adjustStack(1 - dimension);
/* 390 */     super.visitMultiANewArrayInsn(descriptor, dimension);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label) {
/* 395 */     adjustStack(SIZE_CHANGE[opcode]);
/* 396 */     this.sizes.put(label, new ArrayList<>((opcode == 168) ? 
/* 397 */           CompoundList.of(this.current, StackSize.SINGLE) : this.current));
/*     */     
/* 399 */     if (opcode == 167) {
/* 400 */       this.current.clear();
/*     */     }
/* 402 */     super.visitJumpInsn(opcode, label);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLabel(Label label) {
/* 407 */     List<StackSize> current = this.sizes.get(label);
/* 408 */     if (current != null) {
/* 409 */       this.current = new ArrayList<>(current);
/*     */     }
/* 411 */     super.visitLabel(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTableSwitchInsn(int minimum, int maximum, Label defaultOption, Label... option) {
/* 416 */     adjustStack(-1);
/* 417 */     List<StackSize> current = new ArrayList<>(this.current);
/* 418 */     this.sizes.put(defaultOption, current);
/* 419 */     for (Label label : option) {
/* 420 */       this.sizes.put(label, current);
/*     */     }
/* 422 */     super.visitTableSwitchInsn(minimum, maximum, defaultOption, option);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitLookupSwitchInsn(Label defaultOption, int[] key, Label[] option) {
/* 427 */     adjustStack(-1);
/* 428 */     List<StackSize> current = new ArrayList<>(this.current);
/* 429 */     this.sizes.put(defaultOption, current);
/* 430 */     for (Label label : option) {
/* 431 */       this.sizes.put(label, current);
/*     */     }
/* 433 */     super.visitLookupSwitchInsn(defaultOption, key, option);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitTryCatchBlock(Label start, Label end, Label handler, @MaybeNull String type) {
/* 438 */     this.sizes.put(handler, Collections.singletonList(StackSize.SINGLE));
/* 439 */     super.visitTryCatchBlock(start, end, handler, type);
/*     */   }
/*     */   
/*     */   @SuppressFBWarnings(value = {"RC_REF_COMPARISON_BAD_PRACTICE"}, justification = "ASM models frames by reference identity.")
/*     */   public void visitFrame(int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/*     */     int index;
/* 445 */     switch (type) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/* 449 */         this.current.clear();
/*     */         break;
/*     */       case 4:
/* 452 */         this.current.clear();
/* 453 */         if (stack[0] == Opcodes.LONG || stack[0] == Opcodes.DOUBLE) {
/* 454 */           this.current.add(StackSize.DOUBLE); break;
/*     */         } 
/* 456 */         this.current.add(StackSize.SINGLE);
/*     */         break;
/*     */       
/*     */       case -1:
/*     */       case 0:
/* 461 */         this.current.clear();
/* 462 */         for (index = 0; index < stackSize; index++) {
/* 463 */           if (stack[index] == Opcodes.LONG || stack[index] == Opcodes.DOUBLE) {
/* 464 */             this.current.add(StackSize.DOUBLE);
/*     */           } else {
/* 466 */             this.current.add(StackSize.SINGLE);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       default:
/* 471 */         throw new IllegalStateException("Unknown frame type: " + type);
/*     */     } 
/* 473 */     super.visitFrame(type, localVariableLength, localVariable, stackSize, stack);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\visitor\StackAwareMethodVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */