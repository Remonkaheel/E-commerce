/*    */ package META-INF.versions.9.net.bytebuddy.description.annotation;
/*    */ 
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AnnotationValue<T, S>
/*    */ {
/*    */   @AlwaysNull
/* 55 */   public static final net.bytebuddy.description.annotation.AnnotationValue<?, ?> UNDEFINED = null;
/*    */   
/*    */   State getState();
/*    */   
/*    */   Sort getSort();
/*    */   
/*    */   net.bytebuddy.description.annotation.AnnotationValue<T, S> filter(MethodDescription.InDefinedShape paramInDefinedShape);
/*    */   
/*    */   net.bytebuddy.description.annotation.AnnotationValue<T, S> filter(MethodDescription.InDefinedShape paramInDefinedShape, TypeDefinition paramTypeDefinition);
/*    */   
/*    */   T resolve();
/*    */   
/*    */   <W> W resolve(Class<? extends W> paramClass);
/*    */   
/*    */   Loaded<S> load(@MaybeNull ClassLoader paramClassLoader);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\annotation\AnnotationValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */