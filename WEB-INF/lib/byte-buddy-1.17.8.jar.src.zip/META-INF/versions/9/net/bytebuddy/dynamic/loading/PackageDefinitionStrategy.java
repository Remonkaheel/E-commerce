package META-INF.versions.9.net.bytebuddy.dynamic.loading;

public interface PackageDefinitionStrategy {
  Definition define(ClassLoader paramClassLoader, String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\PackageDefinitionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */