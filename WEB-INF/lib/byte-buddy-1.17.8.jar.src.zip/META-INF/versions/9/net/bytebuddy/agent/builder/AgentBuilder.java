package META-INF.versions.9.net.bytebuddy.agent.builder;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.util.Collection;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.agent.builder.ResettableClassFileTransformer;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.ClassFileLocator;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.utility.JavaModule;

public interface AgentBuilder {
  net.bytebuddy.agent.builder.AgentBuilder with(ByteBuddy paramByteBuddy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(Listener paramListener);
  
  net.bytebuddy.agent.builder.AgentBuilder with(CircularityLock paramCircularityLock);
  
  net.bytebuddy.agent.builder.AgentBuilder with(PoolStrategy paramPoolStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(LocationStrategy paramLocationStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(ClassFileLocator paramClassFileLocator);
  
  net.bytebuddy.agent.builder.AgentBuilder with(TypeStrategy paramTypeStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(InitializationStrategy paramInitializationStrategy);
  
  RedefinitionListenable.WithoutBatchStrategy with(RedefinitionStrategy paramRedefinitionStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(LambdaInstrumentationStrategy paramLambdaInstrumentationStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(DescriptionStrategy paramDescriptionStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(FallbackStrategy paramFallbackStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(ClassFileBufferStrategy paramClassFileBufferStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(InstallationListener paramInstallationListener);
  
  net.bytebuddy.agent.builder.AgentBuilder with(InjectionStrategy paramInjectionStrategy);
  
  net.bytebuddy.agent.builder.AgentBuilder with(TransformerDecorator paramTransformerDecorator);
  
  net.bytebuddy.agent.builder.AgentBuilder enableNativeMethodPrefix(String paramString);
  
  net.bytebuddy.agent.builder.AgentBuilder disableNativeMethodPrefix();
  
  net.bytebuddy.agent.builder.AgentBuilder disableClassFormatChanges();
  
  net.bytebuddy.agent.builder.AgentBuilder warmUp(Class<?>... paramVarArgs);
  
  net.bytebuddy.agent.builder.AgentBuilder warmUp(Collection<Class<?>> paramCollection);
  
  net.bytebuddy.agent.builder.AgentBuilder assureReadEdgeTo(Instrumentation paramInstrumentation, Class<?>... paramVarArgs);
  
  net.bytebuddy.agent.builder.AgentBuilder assureReadEdgeTo(Instrumentation paramInstrumentation, JavaModule... paramVarArgs);
  
  net.bytebuddy.agent.builder.AgentBuilder assureReadEdgeTo(Instrumentation paramInstrumentation, Collection<? extends JavaModule> paramCollection);
  
  net.bytebuddy.agent.builder.AgentBuilder assureReadEdgeFromAndTo(Instrumentation paramInstrumentation, Class<?>... paramVarArgs);
  
  net.bytebuddy.agent.builder.AgentBuilder assureReadEdgeFromAndTo(Instrumentation paramInstrumentation, JavaModule... paramVarArgs);
  
  net.bytebuddy.agent.builder.AgentBuilder assureReadEdgeFromAndTo(Instrumentation paramInstrumentation, Collection<? extends JavaModule> paramCollection);
  
  Identified.Narrowable type(ElementMatcher<? super TypeDescription> paramElementMatcher);
  
  Identified.Narrowable type(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1);
  
  Identified.Narrowable type(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1, ElementMatcher<? super JavaModule> paramElementMatcher2);
  
  Identified.Narrowable type(RawMatcher paramRawMatcher);
  
  Ignored ignore(ElementMatcher<? super TypeDescription> paramElementMatcher);
  
  Ignored ignore(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1);
  
  Ignored ignore(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1, ElementMatcher<? super JavaModule> paramElementMatcher2);
  
  Ignored ignore(RawMatcher paramRawMatcher);
  
  ClassFileTransformer makeRaw();
  
  ResettableClassFileTransformer installOn(Instrumentation paramInstrumentation);
  
  ResettableClassFileTransformer installOnByteBuddyAgent();
  
  ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer);
  
  ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, RawMatcher paramRawMatcher);
  
  ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, PatchMode paramPatchMode);
  
  ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, RawMatcher paramRawMatcher, PatchMode paramPatchMode);
  
  ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer paramResettableClassFileTransformer);
  
  ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer paramResettableClassFileTransformer, PatchMode paramPatchMode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\agent\builder\AgentBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */