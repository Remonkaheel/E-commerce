/*      */ package META-INF.versions.9.net.bytebuddy.matcher;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.description.NamedElement;
/*      */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.field.FieldList;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.method.ParameterDescription;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*      */ import net.bytebuddy.matcher.AnnotationTypeMatcher;
/*      */ import net.bytebuddy.matcher.BooleanMatcher;
/*      */ import net.bytebuddy.matcher.CachingMatcher;
/*      */ import net.bytebuddy.matcher.ClassFileVersionMatcher;
/*      */ import net.bytebuddy.matcher.ClassLoaderParentMatcher;
/*      */ import net.bytebuddy.matcher.CollectionElementMatcher;
/*      */ import net.bytebuddy.matcher.CollectionItemMatcher;
/*      */ import net.bytebuddy.matcher.CollectionOneToOneMatcher;
/*      */ import net.bytebuddy.matcher.DeclaringAnnotationMatcher;
/*      */ import net.bytebuddy.matcher.DeclaringFieldMatcher;
/*      */ import net.bytebuddy.matcher.DefinedShapeMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.EqualityMatcher;
/*      */ import net.bytebuddy.matcher.InstanceTypeMatcher;
/*      */ import net.bytebuddy.matcher.MethodOverrideMatcher;
/*      */ import net.bytebuddy.matcher.MethodParameterTypeMatcher;
/*      */ import net.bytebuddy.matcher.MethodParameterTypesMatcher;
/*      */ import net.bytebuddy.matcher.MethodParametersMatcher;
/*      */ import net.bytebuddy.matcher.MethodReturnTypeMatcher;
/*      */ import net.bytebuddy.matcher.MethodSortMatcher;
/*      */ import net.bytebuddy.matcher.ModifierMatcher;
/*      */ import net.bytebuddy.matcher.NameMatcher;
/*      */ import net.bytebuddy.matcher.NegatingMatcher;
/*      */ import net.bytebuddy.matcher.NullMatcher;
/*      */ import net.bytebuddy.matcher.StringMatcher;
/*      */ import net.bytebuddy.matcher.SubTypeMatcher;
/*      */ import net.bytebuddy.matcher.TypeSortMatcher;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ public final class ElementMatchers {
/*      */   private ElementMatchers() {
/*   57 */     throw new UnsupportedOperationException("This class is a utility class and not supposed to be instantiated");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> failSafe(ElementMatcher<? super T> matcher) {
/*   68 */     return (ElementMatcher.Junction<T>)new FailSafeMatcher(matcher, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> cached(ElementMatcher<? super T> matcher, ConcurrentMap<? super T, Boolean> map) {
/*   87 */     return (ElementMatcher.Junction<T>)new CachingMatcher(matcher, map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> cached(ElementMatcher<? super T> matcher, int evictionSize) {
/*  108 */     if (evictionSize < 1) {
/*  109 */       throw new IllegalArgumentException("Eviction size must be a positive number: " + evictionSize);
/*      */     }
/*  111 */     return (ElementMatcher.Junction<T>)new CachingMatcher.WithInlineEviction(matcher, new ConcurrentHashMap<>(), evictionSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> is(@MaybeNull Object value) {
/*  123 */     return (value == null) ? 
/*  124 */       NullMatcher.make() : (ElementMatcher.Junction<T>)new EqualityMatcher(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> is(Field field) {
/*  136 */     return is((FieldDescription.InDefinedShape)new FieldDescription.ForLoadedField(field));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> is(FieldDescription.InDefinedShape field) {
/*  147 */     return definedField((ElementMatcher<? super FieldDescription.InDefinedShape>)new EqualityMatcher(field));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> definedField(ElementMatcher<? super FieldDescription.InDefinedShape> matcher) {
/*  158 */     return (ElementMatcher.Junction<T>)new DefinedShapeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> is(Method method) {
/*  169 */     return is((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> is(Constructor<?> constructor) {
/*  180 */     return is((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> is(MethodDescription.InDefinedShape method) {
/*  191 */     return definedMethod((ElementMatcher<? super MethodDescription.InDefinedShape>)new EqualityMatcher(method));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> definedMethod(ElementMatcher<? super MethodDescription.InDefinedShape> matcher) {
/*  202 */     return (ElementMatcher.Junction<T>)new DefinedShapeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ParameterDescription> ElementMatcher.Junction<T> is(ParameterDescription.InDefinedShape parameter) {
/*  213 */     return definedParameter((ElementMatcher<? super ParameterDescription.InDefinedShape>)new EqualityMatcher(parameter));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ParameterDescription> ElementMatcher.Junction<T> definedParameter(ElementMatcher<? super ParameterDescription.InDefinedShape> matcher) {
/*  224 */     return (ElementMatcher.Junction<T>)new DefinedShapeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ParameterDescription> ElementMatcher.Junction<T> hasType(ElementMatcher<? super TypeDescription> matcher) {
/*  235 */     return hasGenericType((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ParameterDescription> ElementMatcher.Junction<T> hasGenericType(ElementMatcher<? super TypeDescription.Generic> matcher) {
/*  246 */     return (ElementMatcher.Junction<T>)new MethodParameterTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ParameterDescription> ElementMatcher.Junction<T> isMandated() {
/*  256 */     return ModifierMatcher.of(ModifierMatcher.Mode.MANDATED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> is(Type type) {
/*  267 */     return is(TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> is(Annotation annotation) {
/*  278 */     return is(AnnotationDescription.ForLoadedAnnotation.of(annotation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> not(ElementMatcher<? super T> matcher) {
/*  289 */     return (ElementMatcher.Junction<T>)new NegatingMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> any() {
/*  299 */     return BooleanMatcher.of(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> none() {
/*  309 */     return BooleanMatcher.of(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> anyOf(Object... value) {
/*  327 */     return anyOf(Arrays.asList(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> anyOf(Iterable<?> values) {
/*  345 */     ElementMatcher.Junction<T> matcher = null;
/*  346 */     for (Object value : values)
/*      */     {
/*      */       
/*  349 */       matcher = (matcher == null) ? is(value) : matcher.or((ElementMatcher)is(value));
/*      */     }
/*  351 */     return (matcher == null) ? 
/*  352 */       none() : matcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> anyOf(Type... value) {
/*  365 */     return anyOf((Iterable<?>)new TypeList.Generic.ForLoadedTypes(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> anyOf(Constructor<?>... value) {
/*  377 */     return definedMethod((ElementMatcher)anyOf((Iterable<?>)new MethodList.ForLoadedMethods((Constructor[])value, new Method[0])));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> anyOf(Method... value) {
/*  389 */     return definedMethod((ElementMatcher)anyOf((Iterable<?>)new MethodList.ForLoadedMethods(new Constructor[0], value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> anyOf(Field... value) {
/*  401 */     return definedField((ElementMatcher)anyOf((Iterable<?>)new FieldList.ForLoadedFields(value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> anyOf(Annotation... value) {
/*  413 */     return anyOf((Iterable<?>)new AnnotationList.ForLoadedAnnotations(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> noneOf(Object... value) {
/*  425 */     return noneOf(Arrays.asList(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<T> noneOf(Iterable<?> values) {
/*  437 */     ElementMatcher.Junction<T> matcher = null;
/*  438 */     for (Object value : values)
/*      */     {
/*      */       
/*  441 */       matcher = (matcher == null) ? not((ElementMatcher)is(value)) : matcher.and((ElementMatcher)not((ElementMatcher<?>)is(value)));
/*      */     }
/*  443 */     return (matcher == null) ? 
/*  444 */       any() : matcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> noneOf(Type... value) {
/*  457 */     return noneOf((Iterable<?>)new TypeList.Generic.ForLoadedTypes(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> noneOf(Constructor<?>... value) {
/*  469 */     return definedMethod((ElementMatcher)noneOf((Iterable<?>)new MethodList.ForLoadedMethods((Constructor[])value, new Method[0])));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> noneOf(Method... value) {
/*  481 */     return definedMethod((ElementMatcher)noneOf((Iterable<?>)new MethodList.ForLoadedMethods(new Constructor[0], value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> noneOf(Field... value) {
/*  493 */     return definedField((ElementMatcher)noneOf((Iterable<?>)new FieldList.ForLoadedFields(value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> noneOf(Annotation... value) {
/*  505 */     return noneOf((Iterable<?>)new AnnotationList.ForLoadedAnnotations(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<Iterable<? extends T>> whereAny(ElementMatcher<? super T> matcher) {
/*  517 */     return (ElementMatcher.Junction<Iterable<? extends T>>)new CollectionItemMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ElementMatcher.Junction<Iterable<? extends T>> whereNone(ElementMatcher<? super T> matcher) {
/*  528 */     return not((ElementMatcher<? super Iterable<? extends T>>)whereAny(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription.Generic> ElementMatcher.Junction<T> erasure(Class<?> type) {
/*  540 */     return erasure((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription.Generic> ElementMatcher.Junction<T> erasure(TypeDescription type) {
/*  552 */     return erasure((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription.Generic> ElementMatcher.Junction<T> erasure(ElementMatcher<? super TypeDescription> matcher) {
/*  564 */     return (ElementMatcher.Junction<T>)new ErasureMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Iterable<? extends TypeDescription.Generic>> ElementMatcher.Junction<T> erasures(Class<?>... type) {
/*  576 */     return erasures((Iterable<? extends TypeDescription>)new TypeList.ForLoadedTypes(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Iterable<? extends TypeDescription.Generic>> ElementMatcher.Junction<T> erasures(TypeDescription... type) {
/*  588 */     return erasures(Arrays.asList(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Iterable<? extends TypeDescription.Generic>> ElementMatcher.Junction<T> erasures(Iterable<? extends TypeDescription> types) {
/*  601 */     List<ElementMatcher<? super TypeDescription>> typeMatchers = new ArrayList<>();
/*  602 */     for (TypeDescription type : types) {
/*  603 */       typeMatchers.add((ElementMatcher)is(type));
/*      */     }
/*  605 */     return erasures((ElementMatcher<? super Iterable<? extends TypeDescription>>)new CollectionOneToOneMatcher(typeMatchers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Iterable<? extends TypeDescription.Generic>> ElementMatcher.Junction<T> erasures(ElementMatcher<? super Iterable<? extends TypeDescription>> matcher) {
/*  618 */     return (ElementMatcher.Junction<T>)new CollectionErasureMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> isVariable(String symbol) {
/*  629 */     return isVariable((ElementMatcher<? super NamedElement>)named(symbol));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> isVariable(ElementMatcher<? super NamedElement> matcher) {
/*  640 */     return (new TypeSortMatcher((ElementMatcher)anyOf(new Object[] { TypeDefinition.Sort.VARIABLE, TypeDefinition.Sort.VARIABLE_SYMBOLIC }))).and(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> named(String name) {
/*  651 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(name, StringMatcher.Mode.EQUALS_FULLY));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> namedOneOf(String... names) {
/*  662 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringSetMatcher(new HashSet(Arrays.asList((Object[])names))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> namedIgnoreCase(String name) {
/*  674 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(name, StringMatcher.Mode.EQUALS_FULLY_IGNORE_CASE));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameStartsWith(String prefix) {
/*  685 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(prefix, StringMatcher.Mode.STARTS_WITH));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameStartsWithIgnoreCase(String prefix) {
/*  697 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(prefix, StringMatcher.Mode.STARTS_WITH_IGNORE_CASE));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameEndsWith(String suffix) {
/*  708 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(suffix, StringMatcher.Mode.ENDS_WITH));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameEndsWithIgnoreCase(String suffix) {
/*  720 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(suffix, StringMatcher.Mode.ENDS_WITH_IGNORE_CASE));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameContains(String infix) {
/*  731 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(infix, StringMatcher.Mode.CONTAINS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameContainsIgnoreCase(String infix) {
/*  743 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(infix, StringMatcher.Mode.CONTAINS_IGNORE_CASE));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement> ElementMatcher.Junction<T> nameMatches(String regex) {
/*  754 */     return (ElementMatcher.Junction<T>)new NameMatcher((ElementMatcher)new StringMatcher(regex, StringMatcher.Mode.MATCHES));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement.WithOptionalName> ElementMatcher.Junction<T> isNamed() {
/*  764 */     return (ElementMatcher.Junction<T>)new IsNamedMatcher();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NamedElement.WithDescriptor> ElementMatcher.Junction<T> hasDescriptor(String descriptor) {
/*  775 */     return (ElementMatcher.Junction<T>)new DescriptorMatcher((ElementMatcher)new StringMatcher(descriptor, StringMatcher.Mode.EQUALS_FULLY));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isDeclaredBy(Class<?> type) {
/*  787 */     return isDeclaredBy(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isDeclaredBy(TypeDescription type) {
/*  799 */     return isDeclaredBy((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isDeclaredBy(ElementMatcher<? super TypeDescription> matcher) {
/*  812 */     return isDeclaredByGeneric((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isDeclaredByGeneric(Type type) {
/*  823 */     return isDeclaredByGeneric(TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isDeclaredByGeneric(TypeDescription.Generic type) {
/*  834 */     return isDeclaredByGeneric((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isDeclaredByGeneric(ElementMatcher<? super TypeDescription.Generic> matcher) {
/*  845 */     return (ElementMatcher.Junction<T>)new DeclaringTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isVisibleTo(Class<?> type) {
/*  856 */     return isVisibleTo(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isVisibleTo(TypeDescription type) {
/*  867 */     return (ElementMatcher.Junction<T>)new VisibilityMatcher(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isAccessibleTo(Class<?> type) {
/*  878 */     return isAccessibleTo(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ByteCodeElement> ElementMatcher.Junction<T> isAccessibleTo(TypeDescription type) {
/*  889 */     return (ElementMatcher.Junction<T>)new AccessibilityMatcher(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfAbstraction> ElementMatcher.Junction<T> isAbstract() {
/*  899 */     return ModifierMatcher.of(ModifierMatcher.Mode.ABSTRACT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfEnumeration> ElementMatcher.Junction<T> isEnum() {
/*  909 */     return ModifierMatcher.of(ModifierMatcher.Mode.ENUMERATION);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.annotation.AnnotationSource> ElementMatcher.Junction<T> isAnnotatedWith(Class<? extends Annotation> type) {
/*  922 */     return isAnnotatedWith(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.annotation.AnnotationSource> ElementMatcher.Junction<T> isAnnotatedWith(TypeDescription type) {
/*  936 */     return isAnnotatedWith((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.annotation.AnnotationSource> ElementMatcher.Junction<T> isAnnotatedWith(ElementMatcher<? super TypeDescription> matcher) {
/*  951 */     return declaresAnnotation((ElementMatcher<? super AnnotationDescription>)annotationType(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.annotation.AnnotationSource> ElementMatcher.Junction<T> declaresAnnotation(ElementMatcher<? super AnnotationDescription> matcher) {
/*  966 */     return (ElementMatcher.Junction<T>)new DeclaringAnnotationMatcher((ElementMatcher)new CollectionItemMatcher(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfByteCodeElement> ElementMatcher.Junction<T> isPublic() {
/*  976 */     return ModifierMatcher.of(ModifierMatcher.Mode.PUBLIC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfByteCodeElement> ElementMatcher.Junction<T> isProtected() {
/*  986 */     return ModifierMatcher.of(ModifierMatcher.Mode.PROTECTED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfByteCodeElement> ElementMatcher.Junction<T> isPackagePrivate() {
/*  996 */     return not((ElementMatcher<? super T>)isPublic().or((ElementMatcher)isProtected()).or((ElementMatcher)isPrivate()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfByteCodeElement> ElementMatcher.Junction<T> isPrivate() {
/* 1006 */     return ModifierMatcher.of(ModifierMatcher.Mode.PRIVATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.OfByteCodeElement> ElementMatcher.Junction<T> isStatic() {
/* 1016 */     return ModifierMatcher.of(ModifierMatcher.Mode.STATIC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable> ElementMatcher.Junction<T> isFinal() {
/* 1026 */     return ModifierMatcher.of(ModifierMatcher.Mode.FINAL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable> ElementMatcher.Junction<T> isSynthetic() {
/* 1036 */     return ModifierMatcher.of(ModifierMatcher.Mode.SYNTHETIC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.ForMethodDescription> ElementMatcher.Junction<T> isSynchronized() {
/* 1046 */     return ModifierMatcher.of(ModifierMatcher.Mode.SYNCHRONIZED);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.ForMethodDescription> ElementMatcher.Junction<T> isNative() {
/* 1056 */     return ModifierMatcher.of(ModifierMatcher.Mode.NATIVE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.ForMethodDescription> ElementMatcher.Junction<T> isStrict() {
/* 1066 */     return ModifierMatcher.of(ModifierMatcher.Mode.STRICT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.ForMethodDescription> ElementMatcher.Junction<T> isVarArgs() {
/* 1076 */     return ModifierMatcher.of(ModifierMatcher.Mode.VAR_ARGS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.description.ModifierReviewable.ForMethodDescription> ElementMatcher.Junction<T> isBridge() {
/* 1086 */     return ModifierMatcher.of(ModifierMatcher.Mode.BRIDGE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> returnsGeneric(Type type) {
/* 1097 */     return returnsGeneric(TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> returnsGeneric(TypeDescription.Generic type) {
/* 1109 */     return returnsGeneric((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> returns(Class<?> type) {
/* 1120 */     return returnsGeneric((ElementMatcher<? super TypeDescription.Generic>)erasure(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> returns(TypeDescription type) {
/* 1131 */     return returns((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> returns(ElementMatcher<? super TypeDescription> matcher) {
/* 1142 */     return returnsGeneric((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> returnsGeneric(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1153 */     return (ElementMatcher.Junction<T>)new MethodReturnTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArgument(int index, Type type) {
/* 1165 */     return takesGenericArgument(index, TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArgument(int index, TypeDescription.Generic type) {
/* 1177 */     return takesGenericArgument(index, (ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArgument(int index, ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1189 */     return takesGenericArguments((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionElementMatcher(index, matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArguments(Type... type) {
/* 1200 */     return takesGenericArguments((List<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArguments(TypeDefinition... type) {
/* 1211 */     return takesGenericArguments(Arrays.asList(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArguments(List<? extends TypeDefinition> types) {
/* 1222 */     List<ElementMatcher<? super TypeDescription.Generic>> typeMatchers = new ArrayList<>();
/* 1223 */     for (TypeDefinition type : types) {
/* 1224 */       typeMatchers.add((ElementMatcher)is(type));
/*      */     }
/* 1226 */     return takesGenericArguments((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionOneToOneMatcher(typeMatchers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesGenericArguments(ElementMatcher<? super Iterable<? extends TypeDescription.Generic>> matchers) {
/* 1237 */     return (ElementMatcher.Junction<T>)new MethodParametersMatcher((ElementMatcher)new MethodParameterTypesMatcher(matchers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArgument(int index, Class<?> type) {
/* 1249 */     return takesArgument(index, TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArgument(int index, TypeDescription type) {
/* 1261 */     return takesArgument(index, (ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArgument(int index, ElementMatcher<? super TypeDescription> matcher) {
/* 1273 */     return takesGenericArgument(index, (ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArguments(Class<?>... type) {
/* 1284 */     return takesGenericArguments((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)erasures(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArguments(TypeDescription... type) {
/* 1295 */     return takesGenericArguments((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)erasures(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArguments(Iterable<? extends TypeDescription> types) {
/* 1306 */     List<ElementMatcher<? super TypeDescription.Generic>> typeMatchers = new ArrayList<>();
/* 1307 */     for (TypeDescription type : types) {
/* 1308 */       typeMatchers.add((ElementMatcher<? super TypeDescription.Generic>)erasure(type));
/*      */     }
/* 1310 */     return takesGenericArguments((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionOneToOneMatcher(typeMatchers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArguments(ElementMatcher<? super Iterable<? extends TypeDescription>> matchers) {
/* 1321 */     return (ElementMatcher.Junction<T>)new MethodParametersMatcher((ElementMatcher)new MethodParameterTypesMatcher((ElementMatcher)erasures(matchers)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesArguments(int length) {
/* 1332 */     return (ElementMatcher.Junction<T>)new MethodParametersMatcher((ElementMatcher)new CollectionSizeMatcher(length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> takesNoArguments() {
/* 1342 */     return takesArguments(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> hasParameters(ElementMatcher<? super Iterable<? extends ParameterDescription>> matcher) {
/* 1355 */     return (ElementMatcher.Junction<T>)new MethodParametersMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> canThrow(Class<? extends Throwable> exceptionType) {
/* 1367 */     return canThrow(TypeDescription.ForLoadedType.of(exceptionType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> canThrow(TypeDescription exceptionType) {
/* 1379 */     return (exceptionType.isAssignableTo(RuntimeException.class) || exceptionType.isAssignableTo(Error.class)) ? 
/* 1380 */       BooleanMatcher.of(true) : 
/* 1381 */       declaresGenericException((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionItemMatcher((ElementMatcher)erasure((ElementMatcher<? super TypeDescription>)isSuperTypeOf(exceptionType))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> declaresGenericException(Type exceptionType) {
/* 1394 */     return declaresGenericException(TypeDefinition.Sort.describe(exceptionType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> declaresGenericException(TypeDescription.Generic exceptionType) {
/* 1407 */     return (!exceptionType.getSort().isWildcard() && exceptionType.asErasure().isAssignableTo(Throwable.class)) ? 
/* 1408 */       declaresGenericException((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionItemMatcher((ElementMatcher)is(exceptionType))) : 
/* 1409 */       BooleanMatcher.of(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> declaresException(Class<? extends Throwable> exceptionType) {
/* 1420 */     return declaresException(TypeDescription.ForLoadedType.of(exceptionType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> declaresException(TypeDescription exceptionType) {
/* 1431 */     return exceptionType.isAssignableTo(Throwable.class) ? 
/* 1432 */       declaresGenericException((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionItemMatcher((ElementMatcher)erasure(exceptionType))) : 
/* 1433 */       BooleanMatcher.of(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> declaresGenericException(ElementMatcher<? super Iterable<? extends TypeDescription.Generic>> matcher) {
/* 1445 */     return (ElementMatcher.Junction<T>)new MethodExceptionTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isOverriddenFrom(Class<?> type) {
/* 1456 */     return isOverriddenFrom(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isOverriddenFrom(TypeDescription type) {
/* 1467 */     return isOverriddenFrom((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isOverriddenFrom(ElementMatcher<? super TypeDescription> matcher) {
/* 1479 */     return isOverriddenFromGeneric((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isOverriddenFromGeneric(Type type) {
/* 1490 */     return isOverriddenFromGeneric(TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isOverriddenFromGeneric(TypeDescription.Generic type) {
/* 1501 */     return isOverriddenFromGeneric((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isOverriddenFromGeneric(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1513 */     return (ElementMatcher.Junction<T>)new MethodOverrideMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> isInterface() {
/* 1524 */     return ModifierMatcher.of(ModifierMatcher.Mode.INTERFACE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> isAnnotation() {
/* 1534 */     return ModifierMatcher.of(ModifierMatcher.Mode.ANNOTATION);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isMethod() {
/* 1544 */     return MethodSortMatcher.of(MethodSortMatcher.Sort.METHOD);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isConstructor() {
/* 1554 */     return MethodSortMatcher.of(MethodSortMatcher.Sort.CONSTRUCTOR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isTypeInitializer() {
/* 1564 */     return MethodSortMatcher.of(MethodSortMatcher.Sort.TYPE_INITIALIZER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isVirtual() {
/* 1574 */     return MethodSortMatcher.of(MethodSortMatcher.Sort.VIRTUAL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isDefaultMethod() {
/* 1584 */     return MethodSortMatcher.of(MethodSortMatcher.Sort.DEFAULT_METHOD);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isDefaultConstructor() {
/* 1594 */     return isConstructor().and((ElementMatcher)takesNoArguments());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isMain() {
/* 1604 */     return named("main").and((ElementMatcher)takesArguments(new Class[] { String[].class })).and((ElementMatcher)returns(TypeDescription.ForLoadedType.of(void.class)).and((ElementMatcher)isStatic()).and((ElementMatcher)isPublic()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isDefaultFinalizer() {
/* 1614 */     return isFinalizer().and((ElementMatcher)isDeclaredBy(TypeDescription.ForLoadedType.of(Object.class)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isFinalizer() {
/* 1624 */     return named("finalize").and((ElementMatcher)takesNoArguments()).and((ElementMatcher)returns(TypeDescription.ForLoadedType.of(void.class)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isHashCode() {
/* 1634 */     return named("hashCode").and((ElementMatcher)takesNoArguments()).and((ElementMatcher)returns(int.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isEquals() {
/* 1644 */     return named("equals").and((ElementMatcher)takesArguments(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object.class) })).and((ElementMatcher)returns(boolean.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isClone() {
/* 1654 */     return named("clone").and((ElementMatcher)takesNoArguments());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isToString() {
/* 1664 */     return named("toString").and((ElementMatcher)takesNoArguments()).and((ElementMatcher)returns(TypeDescription.ForLoadedType.of(String.class)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isSetter() {
/* 1674 */     return nameStartsWith("set").and((ElementMatcher)takesArguments(1)).and((ElementMatcher)returns(TypeDescription.ForLoadedType.of(void.class)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isSetter(String property) {
/* 1686 */     return isSetter().and((property.length() == 0) ? 
/* 1687 */         (ElementMatcher)named("set") : 
/* 1688 */         (ElementMatcher)named("set" + Character.toUpperCase(property.charAt(0)) + property.substring(1)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isSetter(Class<?> type) {
/* 1699 */     return isSetter(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGenericSetter(Type type) {
/* 1710 */     return isGenericSetter(TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isSetter(TypeDescription type) {
/* 1721 */     return isSetter((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGenericSetter(TypeDescription.Generic type) {
/* 1732 */     return isGenericSetter((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isSetter(ElementMatcher<? super TypeDescription> matcher) {
/* 1743 */     return isGenericSetter((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGenericSetter(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1754 */     return isSetter().and((ElementMatcher)takesGenericArguments((ElementMatcher<? super Iterable<? extends TypeDescription.Generic>>)new CollectionOneToOneMatcher(Collections.singletonList(matcher))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGetter() {
/* 1764 */     return takesNoArguments().and((ElementMatcher)not((ElementMatcher<?>)returns(TypeDescription.ForLoadedType.of(void.class)))).and((ElementMatcher)nameStartsWith("get").or((ElementMatcher)nameStartsWith("is").and((ElementMatcher)returnsGeneric((ElementMatcher)anyOf(new Type[] { boolean.class, Boolean.class })))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGetter(String property) {
/* 1777 */     return isGetter().and((property.length() == 0) ? 
/* 1778 */         (ElementMatcher)named("get").or((ElementMatcher)named("is")) : 
/* 1779 */         (ElementMatcher)named("get" + Character.toUpperCase(property.charAt(0)) + property.substring(1)).or((ElementMatcher)named("is" + Character.toUpperCase(property.charAt(0)) + property.substring(1))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGetter(Class<?> type) {
/* 1790 */     return isGetter(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGenericGetter(Type type) {
/* 1801 */     return isGenericGetter(TypeDefinition.Sort.describe(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGetter(TypeDescription type) {
/* 1812 */     return isGetter((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGenericGetter(TypeDescription.Generic type) {
/* 1823 */     return isGenericGetter((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGetter(ElementMatcher<? super TypeDescription> matcher) {
/* 1834 */     return isGenericGetter((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> isGenericGetter(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1845 */     return isGetter().and((ElementMatcher)returnsGeneric(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> hasMethodName(String internalName) {
/* 1856 */     if ("<init>".equals(internalName))
/* 1857 */       return isConstructor(); 
/* 1858 */     if ("<clinit>".equals(internalName)) {
/* 1859 */       return isTypeInitializer();
/*      */     }
/* 1861 */     return (ElementMatcher.Junction)named(internalName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MethodDescription> ElementMatcher.Junction<T> hasSignature(MethodDescription.SignatureToken token) {
/* 1873 */     return (ElementMatcher.Junction<T>)new SignatureTokenMatcher((ElementMatcher)is(token));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> isSubTypeOf(Class<?> type) {
/* 1884 */     return isSubTypeOf(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> isSubTypeOf(TypeDescription type) {
/* 1895 */     return (ElementMatcher.Junction<T>)new SubTypeMatcher(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> isSuperTypeOf(Class<?> type) {
/* 1906 */     return isSuperTypeOf(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> isSuperTypeOf(TypeDescription type) {
/* 1917 */     return (ElementMatcher.Junction<T>)new SuperTypeMatcher(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasSuperClass(ElementMatcher<? super TypeDescription> matcher) {
/* 1928 */     return hasGenericSuperClass((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasGenericSuperClass(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1939 */     return (ElementMatcher.Junction<T>)new HasSuperClassMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasSuperType(ElementMatcher<? super TypeDescription> matcher) {
/* 1950 */     return hasGenericSuperType((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasGenericSuperType(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 1961 */     return (ElementMatcher.Junction<T>)new HasSuperTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> inheritsAnnotation(Class<?> type) {
/* 1973 */     return inheritsAnnotation(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> inheritsAnnotation(TypeDescription type) {
/* 1985 */     return inheritsAnnotation((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> inheritsAnnotation(ElementMatcher<? super TypeDescription> matcher) {
/* 1997 */     return hasAnnotation((ElementMatcher<? super AnnotationDescription>)annotationType(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasAnnotation(ElementMatcher<? super AnnotationDescription> matcher) {
/* 2009 */     return (ElementMatcher.Junction<T>)new InheritedAnnotationMatcher((ElementMatcher)new CollectionItemMatcher(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasClassFileVersionAtLeast(ClassFileVersion classFileVersion) {
/* 2020 */     return (ElementMatcher.Junction<T>)new ClassFileVersionMatcher(classFileVersion, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDescription> ElementMatcher.Junction<T> hasClassFileVersionAtMost(ClassFileVersion classFileVersion) {
/* 2031 */     return (ElementMatcher.Junction<T>)new ClassFileVersionMatcher(classFileVersion, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> declaresField(ElementMatcher<? super FieldDescription> matcher) {
/* 2042 */     return (ElementMatcher.Junction<T>)new DeclaringFieldMatcher((ElementMatcher)new CollectionItemMatcher(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> declaresMethod(ElementMatcher<? super MethodDescription> matcher) {
/* 2053 */     return (ElementMatcher.Junction<T>)new DeclaringMethodMatcher((ElementMatcher)new CollectionItemMatcher(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> ofSort(TypeDefinition.Sort sort) {
/* 2064 */     return ofSort((ElementMatcher)is(sort));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> ofSort(ElementMatcher<? super TypeDefinition.Sort> matcher) {
/* 2075 */     return (ElementMatcher.Junction<T>)new TypeSortMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> isPrimitive() {
/* 2085 */     return (ElementMatcher.Junction<T>)new PrimitiveTypeMatcher();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> isArray() {
/* 2095 */     return (ElementMatcher.Junction<T>)new ArrayTypeMatcher();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends TypeDefinition> ElementMatcher.Junction<T> isRecord() {
/* 2105 */     return (ElementMatcher.Junction<T>)new RecordMatcher();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> genericFieldType(Type fieldType) {
/* 2116 */     return genericFieldType(TypeDefinition.Sort.describe(fieldType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> genericFieldType(TypeDescription.Generic fieldType) {
/* 2127 */     return genericFieldType((ElementMatcher)is(fieldType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> genericFieldType(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 2138 */     return (ElementMatcher.Junction<T>)new FieldTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> fieldType(Class<?> fieldType) {
/* 2149 */     return fieldType(TypeDescription.ForLoadedType.of(fieldType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> fieldType(TypeDescription fieldType) {
/* 2160 */     return fieldType((ElementMatcher)is(fieldType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> fieldType(ElementMatcher<? super TypeDescription> matcher) {
/* 2171 */     return genericFieldType((ElementMatcher<? super TypeDescription.Generic>)erasure(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> isVolatile() {
/* 2181 */     return ModifierMatcher.of(ModifierMatcher.Mode.VOLATILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends FieldDescription> ElementMatcher.Junction<T> isTransient() {
/* 2191 */     return ModifierMatcher.of(ModifierMatcher.Mode.TRANSIENT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> annotationType(Class<? extends Annotation> type) {
/* 2202 */     return annotationType(TypeDescription.ForLoadedType.of(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> annotationType(TypeDescription type) {
/* 2213 */     return annotationType((ElementMatcher)is(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> annotationType(ElementMatcher<? super TypeDescription> matcher) {
/* 2224 */     return (ElementMatcher.Junction<T>)new AnnotationTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends AnnotationDescription> ElementMatcher.Junction<T> targetsElement(ElementType elementType) {
/* 2235 */     return (ElementMatcher.Junction<T>)new AnnotationTargetMatcher(elementType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> isBootstrapClassLoader() {
/* 2246 */     return NullMatcher.make();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> isSystemClassLoader() {
/* 2257 */     return (ElementMatcher.Junction<T>)new EqualityMatcher(ClassLoader.getSystemClassLoader());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> isExtensionClassLoader() {
/* 2268 */     ClassLoader classLoader = ClassLoader.getSystemClassLoader().getParent();
/* 2269 */     return (classLoader == null) ? 
/* 2270 */       none() : (ElementMatcher.Junction<T>)new EqualityMatcher(classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> isChildOf(@MaybeNull ClassLoader classLoader) {
/* 2283 */     return (classLoader == ClassLoadingStrategy.BOOTSTRAP_LOADER) ? 
/* 2284 */       BooleanMatcher.of(true) : 
/* 2285 */       hasChild((ElementMatcher)is(classLoader));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> hasChild(ElementMatcher<? super ClassLoader> matcher) {
/* 2296 */     return (ElementMatcher.Junction<T>)new ClassLoaderHierarchyMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> isParentOf(@MaybeNull ClassLoader classLoader) {
/* 2308 */     return (classLoader == ClassLoadingStrategy.BOOTSTRAP_LOADER) ? 
/* 2309 */       isBootstrapClassLoader() : (ElementMatcher.Junction<T>)new ClassLoaderParentMatcher(classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends ClassLoader> ElementMatcher.Junction<T> ofType(ElementMatcher<? super TypeDescription> matcher) {
/* 2321 */     return (ElementMatcher.Junction<T>)new InstanceTypeMatcher(matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends net.bytebuddy.utility.JavaModule> ElementMatcher.Junction<T> supportsModules() {
/* 2331 */     return not((ElementMatcher<? super T>)NullMatcher.make());
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\ElementMatchers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */