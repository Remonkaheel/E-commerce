/*    */ package META-INF.versions.9.net.bytebuddy.dynamic.loading;
/*    */ 
/*    */ import java.security.ProtectionDomain;
/*    */ import java.util.Map;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ClassLoadingStrategy<T extends ClassLoader>
/*    */ {
/*    */   @AlwaysNull
/* 40 */   public static final ClassLoader BOOTSTRAP_LOADER = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @AlwaysNull
/* 46 */   public static final ProtectionDomain NO_PROTECTION_DOMAIN = null;
/*    */   
/*    */   Map<TypeDescription, Class<?>> load(@MaybeNull T paramT, Map<TypeDescription, byte[]> paramMap);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\ClassLoadingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */