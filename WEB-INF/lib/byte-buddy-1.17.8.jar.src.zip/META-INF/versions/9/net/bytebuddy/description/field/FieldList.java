package META-INF.versions.9.net.bytebuddy.description.field;

import net.bytebuddy.description.ByteCodeElement;
import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.field.FieldList;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.FilterableList;

public interface FieldList<T extends FieldDescription> extends FilterableList<T, FieldList<T>> {
  ByteCodeElement.Token.TokenList<FieldDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
  
  FieldList<FieldDescription.InDefinedShape> asDefined();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\field\FieldList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */