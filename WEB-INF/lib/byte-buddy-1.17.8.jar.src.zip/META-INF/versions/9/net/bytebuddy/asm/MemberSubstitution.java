/*     */ package META-INF.versions.9.net.bytebuddy.asm;
/*     */ 
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.JavaConstant;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MemberSubstitution
/*     */   implements AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper
/*     */ {
/*     */   protected static final int THIS_REFERENCE = 0;
/*     */   private final MethodGraph.Compiler methodGraphCompiler;
/*     */   private final TypePoolResolver typePoolResolver;
/*     */   private final boolean strict;
/*     */   private final boolean failIfNoMatch;
/*     */   private final Replacement.Factory replacementFactory;
/*     */   
/*     */   protected MemberSubstitution(boolean strict) {
/* 125 */     this(MethodGraph.Compiler.DEFAULT, (TypePoolResolver)TypePoolResolver.OfImplicitPool.INSTANCE, strict, false, (Replacement.Factory)Replacement.NoOp.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MemberSubstitution(MethodGraph.Compiler methodGraphCompiler, TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, Replacement.Factory replacementFactory) {
/* 142 */     this.methodGraphCompiler = methodGraphCompiler;
/* 143 */     this.typePoolResolver = typePoolResolver;
/* 144 */     this.failIfNoMatch = failIfNoMatch;
/* 145 */     this.strict = strict;
/* 146 */     this.replacementFactory = replacementFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.MemberSubstitution strict() {
/* 156 */     return new net.bytebuddy.asm.MemberSubstitution(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.MemberSubstitution relaxed() {
/* 167 */     return new net.bytebuddy.asm.MemberSubstitution(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification<Target.ForMember> element(ElementMatcher<? super ByteCodeElement.Member> matcher) {
/* 177 */     return (WithoutSpecification<Target.ForMember>)new WithoutSpecification.ForMatchedByteCodeElement(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification.ForMatchedField field(ElementMatcher<? super FieldDescription> matcher) {
/* 187 */     return new WithoutSpecification.ForMatchedField(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification.ForMatchedMethod method(ElementMatcher<? super MethodDescription> matcher) {
/* 197 */     return new WithoutSpecification.ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification<Target.ForMember> constructor(ElementMatcher<? super MethodDescription> matcher) {
/* 207 */     return invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification<Target.ForMember> invokable(ElementMatcher<? super MethodDescription> matcher) {
/* 217 */     return (WithoutSpecification<Target.ForMember>)new WithoutSpecification.ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification.ForMatchedDynamicInvocation lambdaExpression() {
/* 226 */     return dynamic((ElementMatcher<? super JavaConstant.MethodHandle>)new LambdaMetaFactoryMatcher());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithoutSpecification.ForMatchedDynamicInvocation dynamic(ElementMatcher<? super JavaConstant.MethodHandle> matcher) {
/* 236 */     return new WithoutSpecification.ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 242 */         ElementMatchers.any(), 
/* 243 */         ElementMatchers.any(), 
/* 244 */         ElementMatchers.any());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberSubstitution with(MethodGraph.Compiler methodGraphCompiler) {
/* 254 */     return new net.bytebuddy.asm.MemberSubstitution(methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberSubstitution with(TypePoolResolver typePoolResolver) {
/* 264 */     return new net.bytebuddy.asm.MemberSubstitution(this.methodGraphCompiler, typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberSubstitution failIfNoMatch(boolean failIfNoMatch) {
/* 274 */     return new net.bytebuddy.asm.MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, failIfNoMatch, this.replacementFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper.ForDeclaredMethods on(ElementMatcher<? super MethodDescription> matcher) {
/* 284 */     return (new AsmVisitorWrapper.ForDeclaredMethods()).invokable(matcher, new AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper[] { this });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor wrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, TypePool typePool, int writerFlags, int readerFlags) {
/* 297 */     typePool = this.typePoolResolver.resolve(instrumentedType, instrumentedMethod, typePool);
/* 298 */     return (MethodVisitor)new SubstitutingMethodVisitor(methodVisitor, instrumentedType, instrumentedMethod, this.methodGraphCompiler, this.strict, this.failIfNoMatch, this.replacementFactory
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 304 */         .make(instrumentedType, instrumentedMethod, typePool), implementationContext, typePool, implementationContext
/*     */ 
/*     */         
/* 307 */         .getClassFileVersion().isAtLeast(ClassFileVersion.JAVA_V11));
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.strict != ((net.bytebuddy.asm.MemberSubstitution)paramObject).strict) ? false : ((this.failIfNoMatch != ((net.bytebuddy.asm.MemberSubstitution)paramObject).failIfNoMatch) ? false : (!this.methodGraphCompiler.equals(((net.bytebuddy.asm.MemberSubstitution)paramObject).methodGraphCompiler) ? false : (!this.typePoolResolver.equals(((net.bytebuddy.asm.MemberSubstitution)paramObject).typePoolResolver) ? false : (!!this.replacementFactory.equals(((net.bytebuddy.asm.MemberSubstitution)paramObject).replacementFactory))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.typePoolResolver.hashCode()) * 31 + this.strict) * 31 + this.failIfNoMatch) * 31 + this.replacementFactory.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\MemberSubstitution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */