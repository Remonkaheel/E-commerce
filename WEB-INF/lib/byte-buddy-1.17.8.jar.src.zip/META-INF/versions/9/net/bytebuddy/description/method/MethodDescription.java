/*    */ package META-INF.versions.9.net.bytebuddy.description.method;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ import net.bytebuddy.description.ByteCodeElement;
/*    */ import net.bytebuddy.description.DeclaredByType;
/*    */ import net.bytebuddy.description.ModifierReviewable;
/*    */ import net.bytebuddy.description.TypeVariableSource;
/*    */ import net.bytebuddy.description.annotation.AnnotationValue;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.method.ParameterList;
/*    */ import net.bytebuddy.description.modifier.Visibility;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.description.type.TypeList;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MethodDescription
/*    */   extends TypeVariableSource, ModifierReviewable.ForMethodDescription, DeclaredByType.WithMandatoryDeclaration, ByteCodeElement.Member, ByteCodeElement.TypeDependant<MethodDescription.InDefinedShape, MethodDescription.Token>
/*    */ {
/*    */   public static final String CONSTRUCTOR_INTERNAL_NAME = "<init>";
/*    */   public static final String TYPE_INITIALIZER_INTERNAL_NAME = "<clinit>";
/*    */   public static final int TYPE_INITIALIZER_MODIFIER = 8;
/*    */   @AlwaysNull
/* 84 */   public static final InDefinedShape UNDEFINED = null;
/*    */   
/*    */   @Nonnull
/*    */   TypeDefinition getDeclaringType();
/*    */   
/*    */   TypeDescription.Generic getReturnType();
/*    */   
/*    */   ParameterList<?> getParameters();
/*    */   
/*    */   TypeList.Generic getExceptionTypes();
/*    */   
/*    */   int getActualModifiers();
/*    */   
/*    */   int getActualModifiers(boolean paramBoolean);
/*    */   
/*    */   int getActualModifiers(boolean paramBoolean, Visibility paramVisibility);
/*    */   
/*    */   boolean isConstructor();
/*    */   
/*    */   boolean isMethod();
/*    */   
/*    */   boolean isTypeInitializer();
/*    */   
/*    */   boolean represents(Method paramMethod);
/*    */   
/*    */   boolean represents(Constructor<?> paramConstructor);
/*    */   
/*    */   boolean isVirtual();
/*    */   
/*    */   int getStackSize();
/*    */   
/*    */   boolean isDefaultMethod();
/*    */   
/*    */   boolean isSpecializableFor(TypeDescription paramTypeDescription);
/*    */   
/*    */   @MaybeNull
/*    */   AnnotationValue<?, ?> getDefaultValue();
/*    */   
/*    */   @MaybeNull
/*    */   <T> T getDefaultValue(Class<T> paramClass);
/*    */   
/*    */   boolean isInvokableOn(TypeDescription paramTypeDescription);
/*    */   
/*    */   boolean isInvokeBootstrap();
/*    */   
/*    */   boolean isInvokeBootstrap(List<? extends TypeDefinition> paramList);
/*    */   
/*    */   boolean isConstantBootstrap();
/*    */   
/*    */   boolean isConstantBootstrap(List<? extends TypeDefinition> paramList);
/*    */   
/*    */   boolean isDefaultValue();
/*    */   
/*    */   boolean isDefaultValue(AnnotationValue<?, ?> paramAnnotationValue);
/*    */   
/*    */   @MaybeNull
/*    */   TypeDescription.Generic getReceiverType();
/*    */   
/*    */   SignatureToken asSignatureToken();
/*    */   
/*    */   TypeToken asTypeToken();
/*    */   
/*    */   boolean isBridgeCompatible(TypeToken paramTypeToken);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\method\MethodDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */