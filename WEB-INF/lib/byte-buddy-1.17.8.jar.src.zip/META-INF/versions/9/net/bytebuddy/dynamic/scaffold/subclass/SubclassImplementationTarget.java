/*     */ package META-INF.versions.9.net.bytebuddy.dynamic.scaffold.subclass;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class SubclassImplementationTarget
/*     */   extends Implementation.Target.AbstractBase
/*     */ {
/*     */   protected final OriginTypeResolver originTypeResolver;
/*     */   
/*     */   protected SubclassImplementationTarget(TypeDescription instrumentedType, MethodGraph.Linked methodGraph, Implementation.Target.AbstractBase.DefaultMethodInvocation defaultMethodInvocation, OriginTypeResolver originTypeResolver) {
/*  54 */     super(instrumentedType, methodGraph, defaultMethodInvocation);
/*  55 */     this.originTypeResolver = originTypeResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.SpecialMethodInvocation invokeSuper(MethodDescription.SignatureToken token) {
/*  62 */     return token.getName().equals("<init>") ? 
/*  63 */       invokeConstructor(token) : 
/*  64 */       invokeMethod(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Implementation.SpecialMethodInvocation invokeConstructor(MethodDescription.SignatureToken token) {
/*  74 */     TypeDescription.Generic superClass = this.instrumentedType.getSuperClass();
/*     */ 
/*     */     
/*  77 */     MethodList<?> candidates = (superClass == null) ? (MethodList<?>)new MethodList.Empty() : (MethodList)superClass.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.hasSignature(token).and((ElementMatcher)ElementMatchers.isVisibleTo(this.instrumentedType)));
/*  78 */     return (candidates.size() == 1) ? 
/*  79 */       Implementation.SpecialMethodInvocation.Simple.of((MethodDescription)candidates.getOnly(), superClass.asErasure()) : (Implementation.SpecialMethodInvocation)Implementation.SpecialMethodInvocation.Illegal.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming super class for given instance.")
/*     */   private Implementation.SpecialMethodInvocation invokeMethod(MethodDescription.SignatureToken token) {
/*  91 */     MethodGraph.Node methodNode = this.methodGraph.getSuperClassGraph().locate(token);
/*  92 */     return methodNode.getSort().isUnique() ? 
/*  93 */       Implementation.SpecialMethodInvocation.Simple.of(methodNode.getRepresentative(), this.instrumentedType.getSuperClass().asErasure()) : (Implementation.SpecialMethodInvocation)Implementation.SpecialMethodInvocation.Illegal.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDefinition getOriginType() {
/* 101 */     return this.originTypeResolver.identify(this.instrumentedType);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.originTypeResolver.equals(((net.bytebuddy.dynamic.scaffold.subclass.SubclassImplementationTarget)paramObject).originTypeResolver)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return super.hashCode() * 31 + this.originTypeResolver.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\subclass\SubclassImplementationTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */