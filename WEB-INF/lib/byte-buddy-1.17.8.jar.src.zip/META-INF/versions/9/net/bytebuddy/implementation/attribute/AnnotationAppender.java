/*    */ package META-INF.versions.9.net.bytebuddy.implementation.attribute;
/*    */ 
/*    */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*    */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AnnotationAppender
/*    */ {
/*    */   @AlwaysNull
/* 41 */   public static final String NO_NAME = null;
/*    */   
/*    */   net.bytebuddy.implementation.attribute.AnnotationAppender append(AnnotationDescription paramAnnotationDescription, AnnotationValueFilter paramAnnotationValueFilter);
/*    */   
/*    */   net.bytebuddy.implementation.attribute.AnnotationAppender append(AnnotationDescription paramAnnotationDescription, AnnotationValueFilter paramAnnotationValueFilter, int paramInt, String paramString);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\AnnotationAppender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */