/*     */ package META-INF.versions.9.net.bytebuddy.utility.visitor;
/*     */ 
/*     */ import net.bytebuddy.jar.asm.Handle;
/*     */ import net.bytebuddy.jar.asm.Label;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExceptionTableSensitiveMethodVisitor
/*     */   extends MethodVisitor
/*     */ {
/*     */   private boolean trigger;
/*     */   
/*     */   protected ExceptionTableSensitiveMethodVisitor(int api, MethodVisitor methodVisitor) {
/*  39 */     super(api, methodVisitor);
/*  40 */     this.trigger = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void considerEndOfExceptionTable() {
/*  47 */     if (this.trigger) {
/*  48 */       this.trigger = false;
/*  49 */       onAfterExceptionTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void onAfterExceptionTable();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void visitFrame(int type, int localVariableLength, Object[] localVariable, int stackSize, Object[] stack) {
/*  62 */     considerEndOfExceptionTable();
/*  63 */     onVisitFrame(type, localVariableLength, localVariable, stackSize, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitFrame(int type, int localVariableLength, Object[] localVariable, int stackSize, Object[] stack) {
/*  76 */     super.visitFrame(type, localVariableLength, localVariable, stackSize, stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitLabel(Label label) {
/*  81 */     considerEndOfExceptionTable();
/*  82 */     onVisitLabel(label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitLabel(Label label) {
/*  92 */     super.visitLabel(label);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitIntInsn(int opcode, int operand) {
/*  97 */     considerEndOfExceptionTable();
/*  98 */     onVisitIntInsn(opcode, operand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitIntInsn(int opcode, int operand) {
/* 108 */     super.visitIntInsn(opcode, operand);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitVarInsn(int opcode, int offset) {
/* 113 */     considerEndOfExceptionTable();
/* 114 */     onVisitVarInsn(opcode, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitVarInsn(int opcode, int offset) {
/* 124 */     super.visitVarInsn(opcode, offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitTypeInsn(int opcode, String type) {
/* 129 */     considerEndOfExceptionTable();
/* 130 */     onVisitTypeInsn(opcode, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitTypeInsn(int opcode, String type) {
/* 140 */     super.visitTypeInsn(opcode, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitFieldInsn(int opcode, String owner, String name, String descriptor) {
/* 145 */     considerEndOfExceptionTable();
/* 146 */     onVisitFieldInsn(opcode, owner, name, descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitFieldInsn(int opcode, String owner, String name, String descriptor) {
/* 158 */     super.visitFieldInsn(opcode, owner, name, descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void visitMethodInsn(int opcode, String owner, String name, String descriptor) {
/* 164 */     considerEndOfExceptionTable();
/* 165 */     onVisitMethodInsn(opcode, owner, name, descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void onVisitMethodInsn(int opcode, String owner, String name, String descriptor) {
/* 180 */     super.visitMethodInsn(opcode, owner, name, descriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
/* 185 */     considerEndOfExceptionTable();
/* 186 */     onVisitMethodInsn(opcode, owner, name, descriptor, isInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
/* 199 */     super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitInvokeDynamicInsn(String name, String descriptor, Handle handle, Object... argument) {
/* 204 */     considerEndOfExceptionTable();
/* 205 */     onVisitInvokeDynamicInsn(name, descriptor, handle, argument);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitInvokeDynamicInsn(String name, String descriptor, Handle handle, Object... argument) {
/* 217 */     super.visitInvokeDynamicInsn(name, descriptor, handle, argument);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitJumpInsn(int opcode, Label label) {
/* 222 */     considerEndOfExceptionTable();
/* 223 */     onVisitJumpInsn(opcode, label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitJumpInsn(int opcode, Label label) {
/* 233 */     super.visitJumpInsn(opcode, label);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitLdcInsn(Object constant) {
/* 238 */     considerEndOfExceptionTable();
/* 239 */     onVisitLdcInsn(constant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitLdcInsn(Object constant) {
/* 248 */     super.visitLdcInsn(constant);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitIincInsn(int offset, int increment) {
/* 253 */     considerEndOfExceptionTable();
/* 254 */     onVisitIincInsn(offset, increment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitIincInsn(int offset, int increment) {
/* 264 */     super.visitIincInsn(offset, increment);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitTableSwitchInsn(int minimum, int maximum, Label defaultTarget, Label... label) {
/* 269 */     considerEndOfExceptionTable();
/* 270 */     onVisitTableSwitchInsn(minimum, maximum, defaultTarget, label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitTableSwitchInsn(int minimum, int maximum, Label defaultTarget, Label... label) {
/* 282 */     super.visitTableSwitchInsn(minimum, maximum, defaultTarget, label);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitLookupSwitchInsn(Label dflt, int[] key, Label[] label) {
/* 287 */     considerEndOfExceptionTable();
/* 288 */     onVisitLookupSwitchInsn(dflt, key, label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitLookupSwitchInsn(Label defaultTarget, int[] key, Label[] label) {
/* 299 */     super.visitLookupSwitchInsn(defaultTarget, key, label);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitMultiANewArrayInsn(String descriptor, int dimensions) {
/* 304 */     considerEndOfExceptionTable();
/* 305 */     onVisitMultiANewArrayInsn(descriptor, dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitMultiANewArrayInsn(String descriptor, int dimensions) {
/* 315 */     super.visitMultiANewArrayInsn(descriptor, dimensions);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitInsn(int opcode) {
/* 320 */     considerEndOfExceptionTable();
/* 321 */     onVisitInsn(opcode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitInsn(int opcode) {
/* 330 */     super.visitInsn(opcode);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\visitor\ExceptionTableSensitiveMethodVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */