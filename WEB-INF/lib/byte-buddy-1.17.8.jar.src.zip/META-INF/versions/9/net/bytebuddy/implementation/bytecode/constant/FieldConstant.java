/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*    */ 
/*    */ import net.bytebuddy.description.field.FieldDescription;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*    */ import net.bytebuddy.implementation.bytecode.constant.TextConstant;
/*    */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldConstant
/*    */   extends StackManipulation.AbstractBase
/*    */ {
/*    */   private final FieldDescription.InDefinedShape fieldDescription;
/*    */   
/*    */   public FieldConstant(FieldDescription.InDefinedShape fieldDescription) {
/* 46 */     this.fieldDescription = fieldDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation cached() {
/* 55 */     return (StackManipulation)new Cached((StackManipulation)this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*    */     try {
/* 63 */       return (new StackManipulation.Compound(new StackManipulation[] {
/* 64 */             ClassConstant.of(this.fieldDescription.getDeclaringType()), (StackManipulation)new TextConstant(this.fieldDescription
/* 65 */               .getInternalName()), 
/* 66 */             (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(Class.class.getMethod("getDeclaredField", new Class[] { String.class })))
/* 67 */           })).apply(methodVisitor, implementationContext);
/* 68 */     } catch (NoSuchMethodException exception) {
/* 69 */       throw new IllegalStateException("Cannot locate Class::getDeclaredField", exception);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     return this.fieldDescription.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@MaybeNull Object other) {
/* 80 */     if (this == other)
/* 81 */       return true; 
/* 82 */     if (other == null || getClass() != other.getClass()) {
/* 83 */       return false;
/*    */     }
/* 85 */     net.bytebuddy.implementation.bytecode.constant.FieldConstant fieldConstant = (net.bytebuddy.implementation.bytecode.constant.FieldConstant)other;
/* 86 */     return this.fieldDescription.equals(fieldConstant.fieldDescription);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\FieldConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */