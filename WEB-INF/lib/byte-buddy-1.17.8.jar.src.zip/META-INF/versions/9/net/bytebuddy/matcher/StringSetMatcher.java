/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import java.util.Set;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class StringSetMatcher
/*    */   extends ElementMatcher.Junction.ForNonNullValues<String>
/*    */ {
/*    */   private final Set<String> values;
/*    */   
/*    */   public StringSetMatcher(Set<String> values) {
/* 39 */     this.values = values;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(String target) {
/* 46 */     return this.values.contains(target);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     StringBuilder stringBuilder = (new StringBuilder()).append("in(");
/* 52 */     boolean first = true;
/* 53 */     for (String value : this.values) {
/* 54 */       if (first) {
/* 55 */         first = false;
/*    */       } else {
/* 57 */         stringBuilder.append(", ");
/*    */       } 
/* 59 */       stringBuilder.append(value);
/*    */     } 
/* 61 */     return stringBuilder.append(")").toString();
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.values.equals(((net.bytebuddy.matcher.StringSetMatcher)paramObject).values)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return super.hashCode() * 31 + this.values.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\StringSetMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */