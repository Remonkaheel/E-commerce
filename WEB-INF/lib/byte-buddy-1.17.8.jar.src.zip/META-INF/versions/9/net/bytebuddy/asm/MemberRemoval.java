/*     */ package META-INF.versions.9.net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MemberRemoval
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private final ElementMatcher.Junction<FieldDescription.InDefinedShape> fieldMatcher;
/*     */   private final ElementMatcher.Junction<MethodDescription> methodMatcher;
/*     */   
/*     */   public MemberRemoval() {
/*  72 */     this(ElementMatchers.none(), ElementMatchers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MemberRemoval(ElementMatcher.Junction<FieldDescription.InDefinedShape> fieldMatcher, ElementMatcher.Junction<MethodDescription> methodMatcher) {
/*  83 */     this.fieldMatcher = fieldMatcher;
/*  84 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberRemoval stripFields(ElementMatcher<? super FieldDescription.InDefinedShape> matcher) {
/*  94 */     return new net.bytebuddy.asm.MemberRemoval(this.fieldMatcher.or(matcher), this.methodMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberRemoval stripMethods(ElementMatcher<? super MethodDescription> matcher) {
/* 105 */     return stripInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberRemoval stripConstructors(ElementMatcher<? super MethodDescription> matcher) {
/* 115 */     return stripInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.MemberRemoval stripInvokables(ElementMatcher<? super MethodDescription> matcher) {
/* 126 */     return new net.bytebuddy.asm.MemberRemoval(this.fieldMatcher, this.methodMatcher.or(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 140 */     Map<String, FieldDescription.InDefinedShape> mappedFields = new HashMap<>();
/* 141 */     for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 142 */       mappedFields.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */     }
/* 144 */     Map<String, MethodDescription> mappedMethods = new HashMap<>();
/* 145 */     for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 146 */       mappedMethods.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */     }
/* 148 */     return (ClassVisitor)new MemberRemovingClassVisitor(classVisitor, this.fieldMatcher, this.methodMatcher, mappedFields, mappedMethods, null);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.fieldMatcher.equals(((net.bytebuddy.asm.MemberRemoval)paramObject).fieldMatcher) ? false : (!!this.methodMatcher.equals(((net.bytebuddy.asm.MemberRemoval)paramObject).methodMatcher)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.fieldMatcher.hashCode()) * 31 + this.methodMatcher.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\MemberRemoval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */