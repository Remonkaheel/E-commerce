/*     */ package META-INF.versions.9.net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ModifierAdjustment
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private final List<Adjustment<TypeDescription>> typeAdjustments;
/*     */   private final List<Adjustment<FieldDescription.InDefinedShape>> fieldAdjustments;
/*     */   private final List<Adjustment<MethodDescription>> methodAdjustments;
/*     */   
/*     */   public ModifierAdjustment() {
/*  73 */     this(Collections.emptyList(), 
/*  74 */         Collections.emptyList(), 
/*  75 */         Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModifierAdjustment(List<Adjustment<TypeDescription>> typeAdjustments, List<Adjustment<FieldDescription.InDefinedShape>> fieldAdjustments, List<Adjustment<MethodDescription>> methodAdjustments) {
/*  88 */     this.typeAdjustments = typeAdjustments;
/*  89 */     this.fieldAdjustments = fieldAdjustments;
/*  90 */     this.methodAdjustments = methodAdjustments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withTypeModifiers(ModifierContributor.ForType... modifierContributor) {
/* 100 */     return withTypeModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withTypeModifiers(List<? extends ModifierContributor.ForType> modifierContributors) {
/* 110 */     return withTypeModifiers((ElementMatcher<? super TypeDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withTypeModifiers(ElementMatcher<? super TypeDescription> matcher, ModifierContributor.ForType... modifierContributor) {
/* 122 */     return withTypeModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withTypeModifiers(ElementMatcher<? super TypeDescription> matcher, List<? extends ModifierContributor.ForType> modifierContributors) {
/* 134 */     return new net.bytebuddy.asm.ModifierAdjustment(CompoundList.of(new Adjustment(matcher, 
/* 135 */             ModifierContributor.Resolver.of(modifierContributors)), this.typeAdjustments), this.fieldAdjustments, this.methodAdjustments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withFieldModifiers(ModifierContributor.ForField... modifierContributor) {
/* 145 */     return withFieldModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withFieldModifiers(List<? extends ModifierContributor.ForField> modifierContributors) {
/* 155 */     return withFieldModifiers((ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withFieldModifiers(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, ModifierContributor.ForField... modifierContributor) {
/* 167 */     return withFieldModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withFieldModifiers(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, List<? extends ModifierContributor.ForField> modifierContributors) {
/* 179 */     return new net.bytebuddy.asm.ModifierAdjustment(this.typeAdjustments, CompoundList.of(new Adjustment(matcher, 
/* 180 */             ModifierContributor.Resolver.of(modifierContributors)), this.fieldAdjustments), this.methodAdjustments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withMethodModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 190 */     return withMethodModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withMethodModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 200 */     return withMethodModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withMethodModifiers(ElementMatcher<? super MethodDescription> matcher, ModifierContributor.ForMethod... modifierContributor) {
/* 212 */     return withMethodModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withMethodModifiers(ElementMatcher<? super MethodDescription> matcher, List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 224 */     return withInvokableModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withConstructorModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 234 */     return withConstructorModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withConstructorModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 244 */     return withConstructorModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withConstructorModifiers(ElementMatcher<? super MethodDescription> matcher, ModifierContributor.ForMethod... modifierContributor) {
/* 256 */     return withConstructorModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withConstructorModifiers(ElementMatcher<? super MethodDescription> matcher, List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 268 */     return withInvokableModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withInvokableModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 278 */     return withInvokableModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withInvokableModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 288 */     return withInvokableModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withInvokableModifiers(ElementMatcher<? super MethodDescription> matcher, ModifierContributor.ForMethod... modifierContributor) {
/* 300 */     return withInvokableModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.ModifierAdjustment withInvokableModifiers(ElementMatcher<? super MethodDescription> matcher, List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 312 */     return new net.bytebuddy.asm.ModifierAdjustment(this.typeAdjustments, this.fieldAdjustments, CompoundList.of(new Adjustment(matcher, 
/* 313 */             ModifierContributor.Resolver.of(modifierContributors)), this.methodAdjustments));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustingClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 327 */     Map<String, FieldDescription.InDefinedShape> mappedFields = new HashMap<>();
/* 328 */     for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 329 */       mappedFields.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */     }
/* 331 */     Map<String, MethodDescription> mappedMethods = new HashMap<>();
/* 332 */     for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 333 */       mappedMethods.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */     }
/* 335 */     return new ModifierAdjustingClassVisitor(classVisitor, this.typeAdjustments, this.fieldAdjustments, this.methodAdjustments, instrumentedType, mappedFields, mappedMethods);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.typeAdjustments.equals(((net.bytebuddy.asm.ModifierAdjustment)paramObject).typeAdjustments) ? false : (!this.fieldAdjustments.equals(((net.bytebuddy.asm.ModifierAdjustment)paramObject).fieldAdjustments) ? false : (!!this.methodAdjustments.equals(((net.bytebuddy.asm.ModifierAdjustment)paramObject).methodAdjustments))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((getClass().hashCode() * 31 + this.typeAdjustments.hashCode()) * 31 + this.fieldAdjustments.hashCode()) * 31 + this.methodAdjustments.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\ModifierAdjustment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */