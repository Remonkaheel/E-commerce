/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PrimitiveUnboxingDelegate
/*     */   implements StackManipulation
/*     */ {
/*  36 */   BOOLEAN(Boolean.class, boolean.class, StackSize.ZERO, "booleanValue", "()Z"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   BYTE(Byte.class, byte.class, StackSize.ZERO, "byteValue", "()B"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   SHORT(Short.class, short.class, StackSize.ZERO, "shortValue", "()S"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   CHARACTER(Character.class, char.class, StackSize.ZERO, "charValue", "()C"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   INTEGER(Integer.class, int.class, StackSize.ZERO, "intValue", "()I"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   LONG(Long.class, long.class, StackSize.SINGLE, "longValue", "()J"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   FLOAT(Float.class, float.class, StackSize.ZERO, "floatValue", "()F"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   DOUBLE(Double.class, double.class, StackSize.SINGLE, "doubleValue", "()D");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TypeDescription wrapperType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TypeDescription primitiveType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation.Size size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String unboxingMethodName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String unboxingMethodDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrimitiveUnboxingDelegate(Class<?> wrapperType, Class<?> primitiveType, StackSize sizeDifference, String unboxingMethodName, String unboxingMethodDescriptor) {
/* 112 */     this.size = sizeDifference.toIncreasingSize();
/* 113 */     this.wrapperType = TypeDescription.ForLoadedType.of(wrapperType);
/* 114 */     this.primitiveType = TypeDescription.ForLoadedType.of(primitiveType);
/* 115 */     this.unboxingMethodName = unboxingMethodName;
/* 116 */     this.unboxingMethodDescriptor = unboxingMethodDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveUnboxingDelegate forPrimitive(TypeDefinition typeDefinition) {
/* 126 */     if (typeDefinition.represents(boolean.class))
/* 127 */       return BOOLEAN; 
/* 128 */     if (typeDefinition.represents(byte.class))
/* 129 */       return BYTE; 
/* 130 */     if (typeDefinition.represents(short.class))
/* 131 */       return SHORT; 
/* 132 */     if (typeDefinition.represents(char.class))
/* 133 */       return CHARACTER; 
/* 134 */     if (typeDefinition.represents(int.class))
/* 135 */       return INTEGER; 
/* 136 */     if (typeDefinition.represents(long.class))
/* 137 */       return LONG; 
/* 138 */     if (typeDefinition.represents(float.class))
/* 139 */       return FLOAT; 
/* 140 */     if (typeDefinition.represents(double.class)) {
/* 141 */       return DOUBLE;
/*     */     }
/* 143 */     throw new IllegalArgumentException("Expected non-void primitive type instead of " + typeDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnboxingResponsible forReferenceType(TypeDefinition typeDefinition) {
/* 162 */     if (typeDefinition.isPrimitive())
/* 163 */       throw new IllegalArgumentException("Expected reference type instead of " + typeDefinition); 
/* 164 */     if (typeDefinition.represents(Boolean.class))
/* 165 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.BOOLEAN; 
/* 166 */     if (typeDefinition.represents(Byte.class))
/* 167 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.BYTE; 
/* 168 */     if (typeDefinition.represents(Short.class))
/* 169 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.SHORT; 
/* 170 */     if (typeDefinition.represents(Character.class))
/* 171 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.CHARACTER; 
/* 172 */     if (typeDefinition.represents(Integer.class))
/* 173 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.INTEGER; 
/* 174 */     if (typeDefinition.represents(Long.class))
/* 175 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.LONG; 
/* 176 */     if (typeDefinition.represents(Float.class))
/* 177 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.FLOAT; 
/* 178 */     if (typeDefinition.represents(Double.class)) {
/* 179 */       return (UnboxingResponsible)ExplicitlyTypedUnboxingResponsible.DOUBLE;
/*     */     }
/* 181 */     return (UnboxingResponsible)new ImplicitlyTypedUnboxingResponsible(typeDefinition.asGenericType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeDescription.Generic getWrapperType() {
/* 191 */     return this.wrapperType.asGenericType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 198 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 205 */     methodVisitor.visitMethodInsn(182, this.wrapperType
/* 206 */         .asErasure().getInternalName(), this.unboxingMethodName, this.unboxingMethodDescriptor, false);
/*     */ 
/*     */ 
/*     */     
/* 210 */     return this.size;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\PrimitiveUnboxingDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */