/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Duplication
/*     */   implements StackManipulation
/*     */ {
/*  31 */   ZERO(StackSize.ZERO, 0),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   SINGLE(StackSize.SINGLE, 89),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   DOUBLE(StackSize.DOUBLE, 92);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final StackManipulation.Size size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int opcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Duplication(StackSize stackSize, int opcode) {
/*  94 */     this.size = stackSize.toIncreasingSize();
/*  95 */     this.opcode = opcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.Duplication of(TypeDefinition typeDefinition) {
/* 105 */     switch (null.$SwitchMap$net$bytebuddy$implementation$bytecode$StackSize[typeDefinition.getStackSize().ordinal()]) {
/*     */       case 1:
/* 107 */         return SINGLE;
/*     */       case 2:
/* 109 */         return DOUBLE;
/*     */       case 3:
/* 111 */         return ZERO;
/*     */     } 
/* 113 */     throw new AssertionError("Unexpected type: " + typeDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 136 */     methodVisitor.visitInsn(this.opcode);
/* 137 */     return this.size;
/*     */   }
/*     */   
/*     */   public abstract StackManipulation flipOver(TypeDefinition paramTypeDefinition);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\Duplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */