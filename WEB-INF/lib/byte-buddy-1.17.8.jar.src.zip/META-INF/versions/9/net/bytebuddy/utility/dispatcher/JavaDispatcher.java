/*     */ package META-INF.versions.9.net.bytebuddy.utility.dispatcher;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*     */ import net.bytebuddy.utility.GraalImageCode;
/*     */ import net.bytebuddy.utility.Invoker;
/*     */ import net.bytebuddy.utility.MethodComparator;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class JavaDispatcher<T>
/*     */   implements PrivilegedAction<T>
/*     */ {
/*     */   public static final String GENERATE_PROPERTY = "net.bytebuddy.generate";
/*  75 */   private static final boolean GENERATE = Boolean.parseBoolean(doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.generate")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private static final DynamicClassLoader.Resolver RESOLVER = doPrivileged((PrivilegedAction<DynamicClassLoader.Resolver>)DynamicClassLoader.Resolver.CreationAction.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private static final Invoker INVOKER = doPrivileged((PrivilegedAction<Invoker>)new InvokerCreationAction(null)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<T> proxy;
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */   private final ClassLoader classLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean generate;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaDispatcher(Class<T> proxy, @MaybeNull ClassLoader classLoader, boolean generate) {
/* 115 */     this.proxy = proxy;
/* 116 */     this.classLoader = classLoader;
/* 117 */     this.generate = generate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 129 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> PrivilegedAction<T> of(Class<T> type) {
/* 140 */     return of(type, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> PrivilegedAction<T> of(Class<T> type, @MaybeNull ClassLoader classLoader) {
/* 152 */     return of(type, classLoader, GENERATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T> PrivilegedAction<T> of(Class<T> type, @MaybeNull ClassLoader classLoader, boolean generate) {
/* 165 */     if (!type.isInterface())
/* 166 */       throw new IllegalArgumentException("Expected an interface instead of " + type); 
/* 167 */     if (!type.isAnnotationPresent((Class)Proxied.class))
/* 168 */       throw new IllegalArgumentException("Expected " + type.getName() + " to be annotated with " + Proxied.class.getName()); 
/* 169 */     if (((Proxied)type.<Proxied>getAnnotation(Proxied.class)).value().startsWith("java.security.")) {
/* 170 */       throw new IllegalArgumentException("Classes related to Java security cannot be proxied: " + type.getName());
/*     */     }
/* 172 */     return new net.bytebuddy.utility.dispatcher.JavaDispatcher<>(type, classLoader, generate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T run() {
/*     */     Class<?> target;
/*     */     try {
/* 182 */       Object securityManager = System.class.getMethod("getSecurityManager", new Class[0]).invoke((Object)null, new Object[0]);
/* 183 */       if (securityManager != null) {
/*     */ 
/*     */         
/* 186 */         Object permission = Class.forName("java.lang.RuntimePermission").getConstructor(new Class[] { String.class }).newInstance(new Object[] { "net.bytebuddy.createJavaDispatcher" });
/* 187 */         Class.forName("java.lang.SecurityManager")
/* 188 */           .getMethod("checkPermission", new Class[] { Permission.class
/* 189 */             }).invoke(securityManager, new Object[] { permission });
/*     */       } 
/* 191 */     } catch (NoSuchMethodException noSuchMethodException) {
/*     */     
/* 193 */     } catch (ClassNotFoundException classNotFoundException) {
/*     */     
/* 195 */     } catch (InvocationTargetException exception) {
/* 196 */       Throwable cause = exception.getTargetException();
/* 197 */       if (cause instanceof RuntimeException) {
/* 198 */         throw (RuntimeException)cause;
/*     */       }
/* 200 */       throw new IllegalStateException("Failed to assert access rights using security manager", cause);
/*     */     }
/* 202 */     catch (IllegalAccessException exception) {
/* 203 */       throw new IllegalStateException("Failed to access security manager", exception);
/* 204 */     } catch (InstantiationException exception) {
/* 205 */       throw new IllegalStateException("Failed to instantiate runtime permission", exception);
/*     */     } 
/* 207 */     Map<Method, Dispatcher> dispatchers = this.generate ? new LinkedHashMap<>() : new HashMap<>();
/*     */ 
/*     */     
/* 210 */     boolean defaults = this.proxy.isAnnotationPresent((Class)Defaults.class);
/* 211 */     String name = ((Proxied)this.proxy.<Proxied>getAnnotation(Proxied.class)).value();
/*     */     
/*     */     try {
/* 214 */       target = Class.forName(name, false, this.classLoader);
/* 215 */     } catch (ClassNotFoundException exception) {
/* 216 */       for (Method method : this.generate ? 
/* 217 */         (Method[])GraalImageCode.getCurrent().sorted((Object[])this.proxy.getMethods(), (Comparator)MethodComparator.INSTANCE) : this.proxy
/* 218 */         .getMethods()) {
/* 219 */         if (method.getDeclaringClass() != Object.class)
/*     */         {
/*     */           
/* 222 */           if (method.isAnnotationPresent((Class)Instance.class)) {
/* 223 */             if ((method.getParameterTypes()).length != 1 || method.getParameterTypes()[0].isPrimitive() || method.getParameterTypes()[0].isArray())
/* 224 */               throw new IllegalStateException("Instance check requires a single regular-typed argument: " + method); 
/* 225 */             if (method.getReturnType() != boolean.class) {
/* 226 */               throw new IllegalStateException("Instance check requires a boolean return type: " + method);
/*     */             }
/* 228 */             dispatchers.put(method, Dispatcher.ForDefaultValue.BOOLEAN);
/*     */           } else {
/*     */             
/* 231 */             dispatchers.put(method, (defaults || method.isAnnotationPresent((Class)Defaults.class)) ? 
/* 232 */                 Dispatcher.ForDefaultValue.of(method.getReturnType()) : (Dispatcher)new Dispatcher.ForUnresolvedMethod("Type not available on current VM: " + exception
/* 233 */                   .getMessage()));
/*     */           }  } 
/*     */       } 
/* 236 */       if (this.generate) {
/* 237 */         return (T)DynamicClassLoader.proxy(this.proxy, dispatchers);
/*     */       }
/* 239 */       return (T)Proxy.newProxyInstance(this.proxy.getClassLoader(), new Class[] { this.proxy }, (InvocationHandler)new ProxiedInvocationHandler(name, dispatchers));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 244 */     boolean generate = this.generate;
/* 245 */     for (Method method : generate ? 
/* 246 */       (Method[])GraalImageCode.getCurrent().sorted((Object[])this.proxy.getMethods(), (Comparator)MethodComparator.INSTANCE) : this.proxy
/* 247 */       .getMethods()) {
/* 248 */       if (method.getDeclaringClass() != Object.class)
/*     */       {
/*     */         
/* 251 */         if (method.isAnnotationPresent((Class)Instance.class)) {
/* 252 */           if ((method.getParameterTypes()).length != 1 || !method.getParameterTypes()[0].isAssignableFrom(target))
/* 253 */             throw new IllegalStateException("Instance check requires a single regular-typed argument: " + method); 
/* 254 */           if (method.getReturnType() != boolean.class) {
/* 255 */             throw new IllegalStateException("Instance check requires a boolean return type: " + method);
/*     */           }
/* 257 */           dispatchers.put(method, new Dispatcher.ForInstanceCheck(target));
/*     */         }
/* 259 */         else if (method.isAnnotationPresent((Class)Container.class)) {
/* 260 */           if ((method.getParameterTypes()).length != 1 || method.getParameterTypes()[0] != int.class)
/* 261 */             throw new IllegalStateException("Container creation requires a single int-typed argument: " + method); 
/* 262 */           if (!method.getReturnType().isArray() || !method.getReturnType().getComponentType().isAssignableFrom(target)) {
/* 263 */             throw new IllegalStateException("Container creation requires an assignable array as return value: " + method);
/*     */           }
/* 265 */           dispatchers.put(method, new Dispatcher.ForContainerCreation(target));
/*     */         } else {
/* 267 */           if (target.getName().equals("java.lang.invoke.MethodHandles") && method.getName().equals("lookup"))
/* 268 */             throw new UnsupportedOperationException("Cannot resolve Byte Buddy lookup via dispatcher"); 
/*     */           try {
/*     */             int offset;
/* 271 */             Class<?>[] parameterType = method.getParameterTypes();
/*     */             
/* 273 */             if (method.isAnnotationPresent((Class)IsStatic.class) || method.isAnnotationPresent((Class)IsConstructor.class)) {
/* 274 */               offset = 0;
/*     */             } else {
/* 276 */               offset = 1;
/* 277 */               if (parameterType.length == 0)
/* 278 */                 throw new IllegalStateException("Expected self type: " + method); 
/* 279 */               if (!parameterType[0].isAssignableFrom(target)) {
/* 280 */                 throw new IllegalStateException("Cannot assign self type: " + target + " on " + method);
/*     */               }
/* 282 */               Class<?>[] adjusted = new Class[parameterType.length - 1];
/* 283 */               System.arraycopy(parameterType, 1, adjusted, 0, adjusted.length);
/* 284 */               parameterType = adjusted;
/*     */             } 
/* 286 */             Annotation[][] parameterAnnotation = method.getParameterAnnotations();
/* 287 */             for (int index = 0; index < parameterType.length; index++) {
/* 288 */               for (Annotation annotation : parameterAnnotation[index + offset]) {
/* 289 */                 if (annotation instanceof Proxied) {
/* 290 */                   int arity = 0;
/* 291 */                   while (parameterType[index].isArray()) {
/* 292 */                     arity++;
/* 293 */                     parameterType[index] = parameterType[index].getComponentType();
/*     */                   } 
/* 295 */                   if (arity > 0) {
/* 296 */                     if (parameterType[index].isPrimitive())
/* 297 */                       throw new IllegalStateException("Primitive values are not supposed to be proxied: " + index + " of " + method); 
/* 298 */                     if (!parameterType[index].isAssignableFrom(Class.forName(((Proxied)annotation).value(), false, this.classLoader))) {
/* 299 */                       throw new IllegalStateException("Cannot resolve to component type: " + ((Proxied)annotation).value() + " at " + index + " of " + method);
/*     */                     }
/* 301 */                     StringBuilder stringBuilder = new StringBuilder();
/* 302 */                     while (arity-- > 0) {
/* 303 */                       stringBuilder.append('[');
/*     */                     }
/* 305 */                     parameterType[index] = Class.forName(stringBuilder.append('L')
/* 306 */                         .append(((Proxied)annotation).value())
/* 307 */                         .append(';')
/* 308 */                         .toString(), false, this.classLoader); break;
/*     */                   } 
/* 310 */                   Class<?> resolved = Class.forName(((Proxied)annotation).value(), false, this.classLoader);
/* 311 */                   if (!parameterType[index].isAssignableFrom(resolved)) {
/* 312 */                     throw new IllegalStateException("Cannot resolve to type: " + resolved.getName() + " at " + index + " of " + method);
/*     */                   }
/* 314 */                   parameterType[index] = resolved;
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 320 */             if (method.isAnnotationPresent((Class)IsConstructor.class)) {
/* 321 */               Constructor<?> resolved = target.getConstructor(parameterType);
/* 322 */               if (!method.getReturnType().isAssignableFrom(target)) {
/* 323 */                 throw new IllegalStateException("Cannot assign " + resolved.getDeclaringClass().getName() + " to " + method);
/*     */               }
/* 325 */               if ((resolved.getModifiers() & 0x1) == 0 || (target.getModifiers() & 0x1) == 0) {
/* 326 */                 resolved.setAccessible(true);
/* 327 */                 generate = false;
/*     */               } 
/* 329 */               dispatchers.put(method, new Dispatcher.ForConstructor(resolved));
/*     */             } else {
/* 331 */               Proxied proxied = method.<Proxied>getAnnotation(Proxied.class);
/* 332 */               Method resolved = target.getMethod((proxied == null) ? method.getName() : proxied.value(), parameterType);
/* 333 */               if (!method.getReturnType().isAssignableFrom(resolved.getReturnType())) {
/* 334 */                 throw new IllegalStateException("Cannot assign " + resolved.getReturnType().getName() + " to " + method);
/*     */               }
/*     */               
/* 337 */               for (Class<?> type : resolved.getExceptionTypes()) {
/* 338 */                 if (!RuntimeException.class.isAssignableFrom(type) && !Error.class.isAssignableFrom(type)) {
/*     */ 
/*     */                   
/* 341 */                   Class[] arrayOfClass = method.getExceptionTypes(); int i = arrayOfClass.length; byte b = 0; while (true) { if (b < i) { Class<?> exception = arrayOfClass[b];
/* 342 */                       if (exception.isAssignableFrom(type))
/*     */                         break;  b++;
/*     */                       continue; }
/*     */                     
/* 346 */                     throw new IllegalStateException("Resolved method for " + method + " throws undeclared checked exception " + type.getName()); } 
/*     */                 } 
/* 348 */               }  if ((resolved.getModifiers() & 0x1) == 0 || (resolved.getDeclaringClass().getModifiers() & 0x1) == 0) {
/* 349 */                 resolved.setAccessible(true);
/* 350 */                 generate = false;
/*     */               } 
/* 352 */               if (Modifier.isStatic(resolved.getModifiers())) {
/* 353 */                 if (!method.isAnnotationPresent((Class)IsStatic.class)) {
/* 354 */                   throw new IllegalStateException("Resolved method for " + method + " was expected to be static: " + resolved);
/*     */                 }
/* 356 */                 dispatchers.put(method, new Dispatcher.ForStaticMethod(resolved));
/*     */               } else {
/* 358 */                 if (method.isAnnotationPresent((Class)IsStatic.class)) {
/* 359 */                   throw new IllegalStateException("Resolved method for " + method + " was expected to be virtual: " + resolved);
/*     */                 }
/* 361 */                 dispatchers.put(method, new Dispatcher.ForNonStaticMethod(resolved));
/*     */               } 
/*     */             } 
/* 364 */           } catch (ClassNotFoundException exception) {
/* 365 */             dispatchers.put(method, (defaults || method.isAnnotationPresent((Class)Defaults.class)) ? 
/* 366 */                 Dispatcher.ForDefaultValue.of(method.getReturnType()) : (Dispatcher)new Dispatcher.ForUnresolvedMethod("Class not available on current VM: " + exception
/* 367 */                   .getMessage()));
/* 368 */           } catch (NoSuchMethodException exception) {
/* 369 */             dispatchers.put(method, (defaults || method.isAnnotationPresent((Class)Defaults.class)) ? 
/* 370 */                 Dispatcher.ForDefaultValue.of(method.getReturnType()) : (Dispatcher)new Dispatcher.ForUnresolvedMethod("Method not available on current VM: " + exception
/* 371 */                   .getMessage()));
/* 372 */           } catch (Throwable throwable) {
/* 373 */             dispatchers.put(method, new Dispatcher.ForUnresolvedMethod("Unexpected error: " + throwable.getMessage()));
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 377 */     if (generate) {
/* 378 */       return (T)DynamicClassLoader.proxy(this.proxy, dispatchers);
/*     */     }
/* 380 */     return (T)Proxy.newProxyInstance(this.proxy.getClassLoader(), new Class[] { this.proxy }, (InvocationHandler)new ProxiedInvocationHandler(target
/*     */           
/* 382 */           .getName(), dispatchers));
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     if (this == paramObject)
/*     */       return true; 
/*     */     if (paramObject == null)
/*     */       return false; 
/*     */     if (getClass() != paramObject.getClass())
/*     */       return false; 
/*     */     if (this.generate != ((net.bytebuddy.utility.dispatcher.JavaDispatcher)paramObject).generate)
/*     */       return false; 
/*     */     if (!this.proxy.equals(((net.bytebuddy.utility.dispatcher.JavaDispatcher)paramObject).proxy))
/*     */       return false; 
/*     */     ClassLoader classLoader1 = ((net.bytebuddy.utility.dispatcher.JavaDispatcher)paramObject).classLoader;
/*     */     ClassLoader classLoader2 = this.classLoader;
/*     */     if (classLoader1 != null) {
/*     */       if (classLoader2 != null) {
/*     */         if (!classLoader2.equals(classLoader1))
/*     */           return false; 
/*     */       } else {
/*     */         return false;
/*     */       } 
/*     */     } else if (classLoader2 != null) {
/*     */       return false;
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     ClassLoader classLoader = this.classLoader;
/*     */     if (classLoader != null);
/*     */     return ((getClass().hashCode() * 31 + this.proxy.hashCode()) * 31 + classLoader.hashCode()) * 31 + this.generate;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\dispatcher\JavaDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */