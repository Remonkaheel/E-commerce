/*     */ package META-INF.versions.9.net.bytebuddy.description.type;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Type;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.TypeVariableSource;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.PackageDescription;
/*     */ import net.bytebuddy.description.type.RecordComponentDescription;
/*     */ import net.bytebuddy.description.type.RecordComponentList;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TypeDescription
/*     */   extends TypeDefinition, ByteCodeElement, TypeVariableSource
/*     */ {
/*     */   @Deprecated
/*  71 */   public static final net.bytebuddy.description.type.TypeDescription OBJECT = LazyProxy.of(Object.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  79 */   public static final net.bytebuddy.description.type.TypeDescription STRING = LazyProxy.of(String.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  87 */   public static final net.bytebuddy.description.type.TypeDescription CLASS = LazyProxy.of(Class.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  95 */   public static final net.bytebuddy.description.type.TypeDescription THROWABLE = LazyProxy.of(Throwable.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 103 */   public static final net.bytebuddy.description.type.TypeDescription VOID = LazyProxy.of(void.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final TypeList.Generic ARRAY_INTERFACES = (TypeList.Generic)new TypeList.Generic.ForLoadedTypes(new Type[] { Cloneable.class, Serializable.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @AlwaysNull
/* 115 */   public static final net.bytebuddy.description.type.TypeDescription UNDEFINED = null;
/*     */   
/*     */   FieldList<FieldDescription.InDefinedShape> getDeclaredFields();
/*     */   
/*     */   MethodList<MethodDescription.InDefinedShape> getDeclaredMethods();
/*     */   
/*     */   RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents();
/*     */   
/*     */   boolean isInstance(Object paramObject);
/*     */   
/*     */   boolean isAssignableFrom(Class<?> paramClass);
/*     */   
/*     */   boolean isAssignableFrom(net.bytebuddy.description.type.TypeDescription paramTypeDescription);
/*     */   
/*     */   boolean isAssignableTo(Class<?> paramClass);
/*     */   
/*     */   boolean isAssignableTo(net.bytebuddy.description.type.TypeDescription paramTypeDescription);
/*     */   
/*     */   boolean isInHierarchyWith(Class<?> paramClass);
/*     */   
/*     */   boolean isInHierarchyWith(net.bytebuddy.description.type.TypeDescription paramTypeDescription);
/*     */   
/*     */   @MaybeNull
/*     */   net.bytebuddy.description.type.TypeDescription getComponentType();
/*     */   
/*     */   @MaybeNull
/*     */   net.bytebuddy.description.type.TypeDescription getDeclaringType();
/*     */   
/*     */   TypeList getDeclaredTypes();
/*     */   
/*     */   @MaybeNull
/*     */   MethodDescription.InDefinedShape getEnclosingMethod();
/*     */   
/*     */   @MaybeNull
/*     */   net.bytebuddy.description.type.TypeDescription getEnclosingType();
/*     */   
/*     */   int getActualModifiers(boolean paramBoolean);
/*     */   
/*     */   String getSimpleName();
/*     */   
/*     */   String getLongSimpleName();
/*     */   
/*     */   @MaybeNull
/*     */   String getCanonicalName();
/*     */   
/*     */   boolean isAnonymousType();
/*     */   
/*     */   boolean isLocalType();
/*     */   
/*     */   boolean isMemberType();
/*     */   
/*     */   @MaybeNull
/*     */   PackageDescription getPackage();
/*     */   
/*     */   AnnotationList getInheritedAnnotations();
/*     */   
/*     */   boolean isSamePackage(net.bytebuddy.description.type.TypeDescription paramTypeDescription);
/*     */   
/*     */   boolean isPrimitiveWrapper();
/*     */   
/*     */   boolean isAnnotationReturnType();
/*     */   
/*     */   boolean isAnnotationValue();
/*     */   
/*     */   boolean isAnnotationValue(Object paramObject);
/*     */   
/*     */   boolean isPackageType();
/*     */   
/*     */   int getInnerClassCount();
/*     */   
/*     */   boolean isInnerClass();
/*     */   
/*     */   boolean isNestedClass();
/*     */   
/*     */   net.bytebuddy.description.type.TypeDescription asBoxed();
/*     */   
/*     */   net.bytebuddy.description.type.TypeDescription asUnboxed();
/*     */   
/*     */   @MaybeNull
/*     */   Object getDefaultValue();
/*     */   
/*     */   net.bytebuddy.description.type.TypeDescription getNestHost();
/*     */   
/*     */   TypeList getNestMembers();
/*     */   
/*     */   boolean isNestHost();
/*     */   
/*     */   boolean isNestMateOf(Class<?> paramClass);
/*     */   
/*     */   boolean isNestMateOf(net.bytebuddy.description.type.TypeDescription paramTypeDescription);
/*     */   
/*     */   boolean isCompileTimeConstant();
/*     */   
/*     */   TypeList getPermittedSubtypes();
/*     */   
/*     */   boolean isSealed();
/*     */   
/*     */   @MaybeNull
/*     */   ClassFileVersion getClassFileVersion();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\type\TypeDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */