package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.dynamic.scaffold.TypeWriter;
import net.bytebuddy.implementation.bytecode.ByteCodeAppender;

public interface TypeInitializer extends ByteCodeAppender {
  boolean isDefined();
  
  net.bytebuddy.dynamic.scaffold.TypeInitializer expandWith(ByteCodeAppender paramByteCodeAppender);
  
  TypeWriter.MethodPool.Record wrap(TypeWriter.MethodPool.Record paramRecord);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\TypeInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */