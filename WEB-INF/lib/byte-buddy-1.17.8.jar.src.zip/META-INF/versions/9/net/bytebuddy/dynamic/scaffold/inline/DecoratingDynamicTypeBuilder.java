/*     */ package META-INF.versions.9.net.bytebuddy.dynamic.scaffold.inline;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.type.RecordComponentDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeVariableToken;
/*     */ import net.bytebuddy.dynamic.ClassFileLocator;
/*     */ import net.bytebuddy.dynamic.DynamicType;
/*     */ import net.bytebuddy.dynamic.Transformer;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeWriter;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*     */ import net.bytebuddy.implementation.attribute.AnnotationRetention;
/*     */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*     */ import net.bytebuddy.implementation.attribute.TypeAttributeAppender;
/*     */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.matcher.LatentMatcher;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.AsmClassReader;
/*     */ import net.bytebuddy.utility.AsmClassWriter;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class DecoratingDynamicTypeBuilder<T>
/*     */   extends DynamicType.Builder.AbstractBase.UsingTypeWriter<T>
/*     */ {
/*     */   private final TypeDescription instrumentedType;
/*     */   private final TypeAttributeAppender typeAttributeAppender;
/*     */   private final AsmVisitorWrapper asmVisitorWrapper;
/*     */   private final ClassFileVersion classFileVersion;
/*     */   private final AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy;
/*     */   private final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*     */   private final AnnotationRetention annotationRetention;
/*     */   private final Implementation.Context.Factory implementationContextFactory;
/*     */   private final MethodGraph.Compiler methodGraphCompiler;
/*     */   private final TypeValidation typeValidation;
/*     */   private final AsmClassReader.Factory classReaderFactory;
/*     */   private final AsmClassWriter.Factory classWriterFactory;
/*     */   private final LatentMatcher<? super MethodDescription> ignoredMethods;
/*     */   private final List<DynamicType> auxiliaryTypes;
/*     */   private final ClassFileLocator classFileLocator;
/*     */   
/*     */   public DecoratingDynamicTypeBuilder(TypeDescription instrumentedType, ClassFileVersion classFileVersion, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, Implementation.Context.Factory implementationContextFactory, MethodGraph.Compiler methodGraphCompiler, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, LatentMatcher<? super MethodDescription> ignoredMethods, ClassFileLocator classFileLocator) {
/* 168 */     this(instrumentedType, 
/* 169 */         annotationRetention.isEnabled() ? (TypeAttributeAppender)new TypeAttributeAppender.ForInstrumentedType.Differentiating(instrumentedType) : (TypeAttributeAppender)TypeAttributeAppender.ForInstrumentedType.INSTANCE, (AsmVisitorWrapper)AsmVisitorWrapper.NoOp.INSTANCE, classFileVersion, auxiliaryTypeNamingStrategy, annotationValueFilterFactory, annotationRetention, implementationContextFactory, methodGraphCompiler, typeValidation, classReaderFactory, classWriterFactory, ignoredMethods, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 183 */         Collections.emptyList(), classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DecoratingDynamicTypeBuilder(TypeDescription instrumentedType, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, ClassFileVersion classFileVersion, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, Implementation.Context.Factory implementationContextFactory, MethodGraph.Compiler methodGraphCompiler, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, LatentMatcher<? super MethodDescription> ignoredMethods, List<DynamicType> auxiliaryTypes, ClassFileLocator classFileLocator) {
/* 221 */     this.instrumentedType = instrumentedType;
/* 222 */     this.typeAttributeAppender = typeAttributeAppender;
/* 223 */     this.asmVisitorWrapper = asmVisitorWrapper;
/* 224 */     this.classFileVersion = classFileVersion;
/* 225 */     this.auxiliaryTypeNamingStrategy = auxiliaryTypeNamingStrategy;
/* 226 */     this.annotationValueFilterFactory = annotationValueFilterFactory;
/* 227 */     this.annotationRetention = annotationRetention;
/* 228 */     this.implementationContextFactory = implementationContextFactory;
/* 229 */     this.methodGraphCompiler = methodGraphCompiler;
/* 230 */     this.typeValidation = typeValidation;
/* 231 */     this.classReaderFactory = classReaderFactory;
/* 232 */     this.classWriterFactory = classWriterFactory;
/* 233 */     this.ignoredMethods = ignoredMethods;
/* 234 */     this.auxiliaryTypes = auxiliaryTypes;
/* 235 */     this.classFileLocator = classFileLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> visit(AsmVisitorWrapper asmVisitorWrapper) {
/* 242 */     return (DynamicType.Builder<T>)new net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder(this.instrumentedType, this.typeAttributeAppender, (AsmVisitorWrapper)new AsmVisitorWrapper.Compound(new AsmVisitorWrapper[] { this.asmVisitorWrapper, asmVisitorWrapper }, ), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes, this.classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> suffix(String suffix) {
/* 263 */     throw new UnsupportedOperationException("Cannot change name of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> name(String name) {
/* 270 */     throw new UnsupportedOperationException("Cannot change name of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> modifiers(int modifiers) {
/* 277 */     throw new UnsupportedOperationException("Cannot change modifiers of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> merge(Collection<? extends ModifierContributor.ForType> modifierContributors) {
/* 284 */     throw new UnsupportedOperationException("Cannot change modifiers of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> topLevelType() {
/* 291 */     throw new UnsupportedOperationException("Cannot change type declaration of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.InnerTypeDefinition.ForType<T> innerTypeOf(TypeDescription type) {
/* 298 */     throw new UnsupportedOperationException("Cannot change type declaration of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.InnerTypeDefinition<T> innerTypeOf(MethodDescription.InDefinedShape methodDescription) {
/* 305 */     throw new UnsupportedOperationException("Cannot change type declaration of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> declaredTypes(Collection<? extends TypeDescription> types) {
/* 312 */     throw new UnsupportedOperationException("Cannot change type declaration of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> nestHost(TypeDescription type) {
/* 319 */     throw new UnsupportedOperationException("Cannot change type declaration of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> nestMembers(Collection<? extends TypeDescription> types) {
/* 326 */     throw new UnsupportedOperationException("Cannot change type declaration of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> permittedSubclass(Collection<? extends TypeDescription> types) {
/* 333 */     throw new UnsupportedOperationException("Cannot change permitted subclasses of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> unsealed() {
/* 340 */     throw new UnsupportedOperationException("Cannot unseal decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> attribute(TypeAttributeAppender typeAttributeAppender) {
/* 347 */     return (DynamicType.Builder<T>)new net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder(this.instrumentedType, (TypeAttributeAppender)new TypeAttributeAppender.Compound(new TypeAttributeAppender[] { this.typeAttributeAppender, typeAttributeAppender }, ), this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes, this.classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> annotateType(Collection<? extends AnnotationDescription> annotations) {
/* 368 */     return attribute((TypeAttributeAppender)new TypeAttributeAppender.Explicit(new ArrayList<>(annotations)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<T> implement(Collection<? extends TypeDefinition> interfaceTypes) {
/* 375 */     throw new UnsupportedOperationException("Cannot implement interface for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> initializer(ByteCodeAppender byteCodeAppender) {
/* 382 */     throw new UnsupportedOperationException("Cannot add initializer of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> initializer(LoadedTypeInitializer loadedTypeInitializer) {
/* 389 */     throw new UnsupportedOperationException("Cannot add initializer of decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.TypeVariableDefinition<T> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) {
/* 396 */     throw new UnsupportedOperationException("Cannot add type variable to decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> transform(ElementMatcher<? super TypeDescription.Generic> matcher, Transformer<TypeVariableToken> transformer) {
/* 403 */     throw new UnsupportedOperationException("Cannot transform decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.FieldDefinition.Optional.Valuable<T> defineField(String name, TypeDefinition type, int modifiers) {
/* 410 */     throw new UnsupportedOperationException("Cannot define field for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.FieldDefinition.Valuable<T> field(LatentMatcher<? super FieldDescription> matcher) {
/* 417 */     throw new UnsupportedOperationException("Cannot change field for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> ignoreAlso(LatentMatcher<? super MethodDescription> ignoredMethods) {
/* 425 */     return (DynamicType.Builder<T>)new net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder(this.instrumentedType, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.classReaderFactory, this.classWriterFactory, (LatentMatcher<? super MethodDescription>)new LatentMatcher.Disjunction(new LatentMatcher[] { this.ignoredMethods, ignoredMethods }, ), this.auxiliaryTypes, this.classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String name, TypeDefinition returnType, int modifiers) {
/* 446 */     throw new UnsupportedOperationException("Cannot define method for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<T> defineConstructor(int modifiers) {
/* 453 */     throw new UnsupportedOperationException("Cannot define constructor for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.MethodDefinition.ImplementationDefinition<T> invokable(LatentMatcher<? super MethodDescription> matcher) {
/* 460 */     throw new UnsupportedOperationException("Cannot intercept method for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.RecordComponentDefinition.Optional<T> defineRecordComponent(String name, TypeDefinition type) {
/* 467 */     throw new UnsupportedOperationException("Cannot define record component for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder.RecordComponentDefinition<T> recordComponent(LatentMatcher<? super RecordComponentDescription> matcher) {
/* 474 */     throw new UnsupportedOperationException("Cannot change record component for decorated type: " + this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType.Builder<T> require(Collection<DynamicType> auxiliaryTypes) {
/* 481 */     return (DynamicType.Builder<T>)new net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder(this.instrumentedType, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 494 */         CompoundList.of(this.auxiliaryTypes, new ArrayList<>(auxiliaryTypes)), this.classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeWriter<T> toTypeWriter() {
/* 502 */     return toTypeWriter((TypePool)TypePool.Empty.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeWriter<T> toTypeWriter(TypePool typePool) {
/* 509 */     return TypeWriter.Default.forDecoration(this.instrumentedType, this.classFileVersion, this.auxiliaryTypes, 
/*     */ 
/*     */         
/* 512 */         CompoundList.of((List)this.methodGraphCompiler.compile((TypeDefinition)this.instrumentedType)
/* 513 */           .listNodes()
/* 514 */           .asMethodList()
/* 515 */           .filter((ElementMatcher)ElementMatchers.not(this.ignoredMethods.resolve(this.instrumentedType))), (List)this.instrumentedType.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isVirtual()))), this.typeAttributeAppender, this.asmVisitorWrapper, this.annotationValueFilterFactory, this.annotationRetention, this.auxiliaryTypeNamingStrategy, this.implementationContextFactory, this.typeValidation, this.classReaderFactory, this.classWriterFactory, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 525 */         TypePool.Explicit.wrap(this.instrumentedType, this.auxiliaryTypes, typePool), this.classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescription toTypeDescription() {
/* 533 */     return this.instrumentedType;
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.annotationRetention.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).annotationRetention) ? false : (!this.typeValidation.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).typeValidation) ? false : (!this.instrumentedType.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).instrumentedType) ? false : (!this.typeAttributeAppender.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).typeAttributeAppender) ? false : (!this.asmVisitorWrapper.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).asmVisitorWrapper) ? false : (!this.classFileVersion.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).classFileVersion) ? false : (!this.auxiliaryTypeNamingStrategy.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).auxiliaryTypeNamingStrategy) ? false : (!this.annotationValueFilterFactory.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).annotationValueFilterFactory) ? false : (!this.implementationContextFactory.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).implementationContextFactory) ? false : (!this.methodGraphCompiler.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).methodGraphCompiler) ? false : (!this.classReaderFactory.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).classReaderFactory) ? false : (!this.classWriterFactory.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).classWriterFactory) ? false : (!this.ignoredMethods.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).ignoredMethods) ? false : (!this.auxiliaryTypes.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).auxiliaryTypes) ? false : (!!this.classFileLocator.equals(((net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder)paramObject).classFileLocator))))))))))))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((((((((((((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.typeAttributeAppender.hashCode()) * 31 + this.asmVisitorWrapper.hashCode()) * 31 + this.classFileVersion.hashCode()) * 31 + this.auxiliaryTypeNamingStrategy.hashCode()) * 31 + this.annotationValueFilterFactory.hashCode()) * 31 + this.annotationRetention.hashCode()) * 31 + this.implementationContextFactory.hashCode()) * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.typeValidation.hashCode()) * 31 + this.classReaderFactory.hashCode()) * 31 + this.classWriterFactory.hashCode()) * 31 + this.ignoredMethods.hashCode()) * 31 + this.auxiliaryTypes.hashCode()) * 31 + this.classFileLocator.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\inline\DecoratingDynamicTypeBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */