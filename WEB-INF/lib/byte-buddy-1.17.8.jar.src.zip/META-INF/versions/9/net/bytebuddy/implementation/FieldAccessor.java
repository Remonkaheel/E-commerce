/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public abstract class FieldAccessor
/*     */   implements Implementation
/*     */ {
/*     */   protected final FieldLocation fieldLocation;
/*     */   protected final Assigner assigner;
/*     */   protected final Assigner.Typing typing;
/*     */   
/*     */   protected FieldAccessor(FieldLocation fieldLocation, Assigner assigner, Assigner.Typing typing) {
/*  94 */     this.fieldLocation = fieldLocation;
/*  95 */     this.assigner = assigner;
/*  96 */     this.typing = typing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OwnerTypeLocatable ofField(String name) {
/* 106 */     return of((FieldNameExtractor)new FieldNameExtractor.ForFixedValue(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OwnerTypeLocatable ofBeanProperty() {
/* 117 */     return of(new FieldNameExtractor[] { (FieldNameExtractor)FieldNameExtractor.ForBeanProperty.INSTANCE, (FieldNameExtractor)FieldNameExtractor.ForBeanProperty.CAPITALIZED });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OwnerTypeLocatable of(FieldNameExtractor fieldNameExtractor) {
/* 127 */     return of(Collections.singletonList(fieldNameExtractor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OwnerTypeLocatable of(FieldNameExtractor... fieldNameExtractor) {
/* 137 */     return of(Arrays.asList(fieldNameExtractor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OwnerTypeLocatable of(List<? extends FieldNameExtractor> fieldNameExtractors) {
/* 147 */     return (OwnerTypeLocatable)new ForImplicitProperty((FieldLocation)new FieldLocation.Relative(fieldNameExtractors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable of(Field field) {
/* 157 */     return of((FieldDescription)new FieldDescription.ForLoadedField(field));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable of(FieldDescription fieldDescription) {
/* 167 */     return (AssignerConfigurable)new ForImplicitProperty((FieldLocation)new FieldLocation.Absolute(fieldDescription));
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.typing.equals(((net.bytebuddy.implementation.FieldAccessor)paramObject).typing) ? false : (!this.fieldLocation.equals(((net.bytebuddy.implementation.FieldAccessor)paramObject).fieldLocation) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.FieldAccessor)paramObject).assigner))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((getClass().hashCode() * 31 + this.fieldLocation.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\FieldAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */