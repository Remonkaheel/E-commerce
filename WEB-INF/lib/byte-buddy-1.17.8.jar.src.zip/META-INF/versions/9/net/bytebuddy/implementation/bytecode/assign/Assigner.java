/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveTypeAwareAssigner;
/*    */ import net.bytebuddy.implementation.bytecode.assign.primitive.VoidAwareAssigner;
/*    */ import net.bytebuddy.implementation.bytecode.assign.reference.GenericTypeAwareAssigner;
/*    */ import net.bytebuddy.implementation.bytecode.assign.reference.ReferenceTypeAwareAssigner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SuppressFBWarnings(value = {"IC_SUPERCLASS_USES_SUBCLASS_DURING_INITIALIZATION"}, justification = "Safe initialization is implied.")
/*    */ public interface Assigner
/*    */ {
/* 38 */   public static final net.bytebuddy.implementation.bytecode.assign.Assigner DEFAULT = (net.bytebuddy.implementation.bytecode.assign.Assigner)new VoidAwareAssigner((net.bytebuddy.implementation.bytecode.assign.Assigner)new PrimitiveTypeAwareAssigner((net.bytebuddy.implementation.bytecode.assign.Assigner)ReferenceTypeAwareAssigner.INSTANCE));
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public static final net.bytebuddy.implementation.bytecode.assign.Assigner GENERICS_AWARE = (net.bytebuddy.implementation.bytecode.assign.Assigner)new VoidAwareAssigner((net.bytebuddy.implementation.bytecode.assign.Assigner)new PrimitiveTypeAwareAssigner((net.bytebuddy.implementation.bytecode.assign.Assigner)GenericTypeAwareAssigner.INSTANCE));
/*    */   
/*    */   StackManipulation assign(TypeDescription.Generic paramGeneric1, TypeDescription.Generic paramGeneric2, Typing paramTyping);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\Assigner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */