package META-INF.versions.9.net.bytebuddy.description.method;

import net.bytebuddy.description.ByteCodeElement;
import net.bytebuddy.description.method.ParameterDescription;
import net.bytebuddy.description.method.ParameterList;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeList;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.FilterableList;

public interface ParameterList<T extends ParameterDescription> extends FilterableList<T, ParameterList<T>> {
  TypeList.Generic asTypeList();
  
  ByteCodeElement.Token.TokenList<ParameterDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
  
  ParameterList<ParameterDescription.InDefinedShape> asDefined();
  
  boolean hasExplicitMetaData();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\method\ParameterList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */