package META-INF.versions.9.net.bytebuddy.dynamic.scaffold.inline;

import net.bytebuddy.description.method.MethodDescription;

public interface MethodNameTransformer {
  String transform(MethodDescription paramMethodDescription);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\inline\MethodNameTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */