package META-INF.versions.9.net.bytebuddy.implementation.attribute;

import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
import net.bytebuddy.jar.asm.FieldVisitor;

public interface FieldAttributeAppender {
  void apply(FieldVisitor paramFieldVisitor, FieldDescription paramFieldDescription, AnnotationValueFilter paramAnnotationValueFilter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\FieldAttributeAppender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */