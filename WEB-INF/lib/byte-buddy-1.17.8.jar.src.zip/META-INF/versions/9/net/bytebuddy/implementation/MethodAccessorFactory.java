package META-INF.versions.9.net.bytebuddy.implementation;

import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.implementation.Implementation;

public interface MethodAccessorFactory {
  MethodDescription.InDefinedShape registerAccessorFor(Implementation.SpecialMethodInvocation paramSpecialMethodInvocation, AccessType paramAccessType);
  
  MethodDescription.InDefinedShape registerGetterFor(FieldDescription paramFieldDescription, AccessType paramAccessType);
  
  MethodDescription.InDefinedShape registerSetterFor(FieldDescription paramFieldDescription, AccessType paramAccessType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\MethodAccessorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */