/*     */ package META-INF.versions.9.net.bytebuddy.implementation.auxiliary;
/*     */ 
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.ByteBuddy;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.modifier.Visibility;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.DynamicType;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*     */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*     */ import net.bytebuddy.implementation.FieldAccessor;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.MethodAccessorFactory;
/*     */ import net.bytebuddy.implementation.MethodCall;
/*     */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.RandomString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PrivilegedMemberLookupAction
/*     */   implements AuxiliaryType
/*     */ {
/*  50 */   FOR_PUBLIC_METHOD("getMethod", "name", String.class, "parameters", Class[].class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   FOR_DECLARED_METHOD("getDeclaredMethod", "name", String.class, "parameters", Class[].class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   FOR_PUBLIC_CONSTRUCTOR("getConstructor", "parameters", Class[].class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   FOR_DECLARED_CONSTRUCTOR("getDeclaredConstructor", "parameters", Class[].class);
/*     */   
/*     */   private static final String TYPE_FIELD = "type";
/*     */   
/*     */   private static final MethodDescription.InDefinedShape DEFAULT_CONSTRUCTOR;
/*     */   
/*     */   private final MethodDescription.InDefinedShape methodDescription;
/*     */   
/*     */   private final Map<String, Class<?>> fields;
/*     */ 
/*     */   
/*     */   static {
/*  77 */     DEFAULT_CONSTRUCTOR = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Object.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).getOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrivilegedMemberLookupAction(String name, String field, Class<?> type) {
/*     */     try {
/*  98 */       this.methodDescription = (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(Class.class.getMethod(name, new Class[] { type }));
/*  99 */     } catch (NoSuchMethodException exception) {
/* 100 */       throw new IllegalStateException("Could not locate method: " + name, exception);
/*     */     } 
/* 102 */     this.fields = Collections.singletonMap(field, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrivilegedMemberLookupAction(String name, String firstField, Class<?> firstType, String secondField, Class<?> secondType) {
/*     */     try {
/* 116 */       this.methodDescription = (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(Class.class.getMethod(name, new Class[] { firstType, secondType }));
/* 117 */     } catch (NoSuchMethodException exception) {
/* 118 */       throw new IllegalStateException("Could not locate method: " + name, exception);
/*     */     } 
/* 120 */     this.fields = new LinkedHashMap<>();
/* 121 */     this.fields.put(firstField, firstType);
/* 122 */     this.fields.put(secondField, secondType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuxiliaryType of(MethodDescription methodDescription) {
/* 132 */     if (methodDescription.isConstructor()) {
/* 133 */       return methodDescription.isPublic() ? FOR_PUBLIC_CONSTRUCTOR : FOR_DECLARED_CONSTRUCTOR;
/*     */     }
/*     */     
/* 136 */     if (methodDescription.isMethod()) {
/* 137 */       return methodDescription.isPublic() ? FOR_PUBLIC_METHOD : FOR_DECLARED_METHOD;
/*     */     }
/*     */ 
/*     */     
/* 141 */     throw new IllegalStateException("Cannot load constant for type initializer: " + methodDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuffix() {
/* 149 */     return RandomString.hashOf(name().hashCode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType make(String auxiliaryTypeName, ClassFileVersion classFileVersion, MethodAccessorFactory methodAccessorFactory) {
/* 158 */     Implementation.Composable constructor = MethodCall.invoke((MethodDescription)DEFAULT_CONSTRUCTOR).andThen(FieldAccessor.ofField("type").setsArgumentAt(0));
/* 159 */     int index = 1;
/* 160 */     for (String field : this.fields.keySet()) {
/* 161 */       constructor = constructor.andThen(FieldAccessor.ofField(field).setsArgumentAt(index++));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     DynamicType.Builder.FieldDefinition.Optional.Valuable valuable = (new ByteBuddy(classFileVersion)).with(TypeValidation.DISABLED).subclass(PrivilegedExceptionAction.class, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).name(auxiliaryTypeName).modifiers(DEFAULT_TYPE_MODIFIER).defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(CompoundList.of(Class.class, new ArrayList(this.fields.values()))).intercept((Implementation)constructor).method((ElementMatcher)ElementMatchers.named("run")).intercept((Implementation)MethodCall.invoke((MethodDescription)this.methodDescription).onField("type").withField((String[])this.fields.keySet().toArray((Object[])new String[0]))).defineField("type", Class.class, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE });
/* 176 */     for (Map.Entry<String, Class<?>> entry : this.fields.entrySet()) {
/* 177 */       valuable = valuable.defineField(entry.getKey(), entry.getValue(), new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE });
/*     */     } 
/* 179 */     return (DynamicType)valuable.make();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\auxiliary\PrivilegedMemberLookupAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */