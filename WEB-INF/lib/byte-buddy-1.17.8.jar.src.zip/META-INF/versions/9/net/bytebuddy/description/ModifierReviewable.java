package META-INF.versions.9.net.bytebuddy.description;

import net.bytebuddy.description.modifier.SyntheticState;

public interface ModifierReviewable {
  public static final int EMPTY_MASK = 0;
  
  int getModifiers();
  
  boolean isFinal();
  
  boolean isSynthetic();
  
  SyntheticState getSyntheticState();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\ModifierReviewable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */