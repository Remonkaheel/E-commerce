/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class CollectionElementMatcher<T>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<Iterable<? extends T>>
/*    */ {
/*    */   private final int index;
/*    */   private final ElementMatcher<? super T> matcher;
/*    */   
/*    */   public CollectionElementMatcher(int index, ElementMatcher<? super T> matcher) {
/* 48 */     this.index = index;
/* 49 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(Iterable<? extends T> target) {
/* 56 */     Iterator<? extends T> iterator = target.iterator();
/* 57 */     for (int index = 0; index < this.index; index++) {
/* 58 */       if (iterator.hasNext()) {
/* 59 */         iterator.next();
/*    */       } else {
/* 61 */         return false;
/*    */       } 
/*    */     } 
/* 64 */     return (iterator.hasNext() && this.matcher.matches(iterator.next()));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     return "with(" + this.index + " matches " + this.matcher + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.index != ((net.bytebuddy.matcher.CollectionElementMatcher)paramObject).index) ? false : (!!this.matcher.equals(((net.bytebuddy.matcher.CollectionElementMatcher)paramObject).matcher))))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return (super.hashCode() * 31 + this.index) * 31 + this.matcher.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\CollectionElementMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */