/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.ByteCodeElement;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class VisibilityMatcher<T extends ByteCodeElement>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<T>
/*    */ {
/*    */   private final TypeDescription typeDescription;
/*    */   
/*    */   public VisibilityMatcher(TypeDescription typeDescription) {
/* 41 */     this.typeDescription = typeDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(T target) {
/* 48 */     return target.isVisibleTo(this.typeDescription);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     return "isVisibleTo(" + this.typeDescription + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.typeDescription.equals(((net.bytebuddy.matcher.VisibilityMatcher)paramObject).typeDescription)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return super.hashCode() * 31 + this.typeDescription.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\VisibilityMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */