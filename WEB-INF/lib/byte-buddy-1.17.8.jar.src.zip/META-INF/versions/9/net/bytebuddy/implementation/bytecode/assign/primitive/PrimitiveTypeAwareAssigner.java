/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*    */ import net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveBoxingDelegate;
/*    */ import net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveUnboxingDelegate;
/*    */ import net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveWideningDelegate;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class PrimitiveTypeAwareAssigner
/*    */   implements Assigner
/*    */ {
/*    */   private final Assigner referenceTypeAwareAssigner;
/*    */   
/*    */   public PrimitiveTypeAwareAssigner(Assigner referenceTypeAwareAssigner) {
/* 54 */     this.referenceTypeAwareAssigner = referenceTypeAwareAssigner;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation assign(TypeDescription.Generic source, TypeDescription.Generic target, Assigner.Typing typing) {
/* 61 */     if (source.isPrimitive() && target.isPrimitive())
/* 62 */       return PrimitiveWideningDelegate.forPrimitive((TypeDefinition)source).widenTo((TypeDefinition)target); 
/* 63 */     if (source.isPrimitive())
/* 64 */       return PrimitiveBoxingDelegate.forPrimitive((TypeDefinition)source).assignBoxedTo(target, this.referenceTypeAwareAssigner, typing); 
/* 65 */     if (target.isPrimitive()) {
/* 66 */       return PrimitiveUnboxingDelegate.forReferenceType((TypeDefinition)source).assignUnboxedTo(target, this.referenceTypeAwareAssigner, typing);
/*    */     }
/* 68 */     return this.referenceTypeAwareAssigner.assign(source, target, typing);
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.referenceTypeAwareAssigner.equals(((net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveTypeAwareAssigner)paramObject).referenceTypeAwareAssigner))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.referenceTypeAwareAssigner.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\PrimitiveTypeAwareAssigner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */