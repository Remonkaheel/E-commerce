package META-INF.versions.9.net.bytebuddy.description.type;

import net.bytebuddy.description.ByteCodeElement;
import net.bytebuddy.description.DeclaredByType;
import net.bytebuddy.description.NamedElement;
import net.bytebuddy.description.annotation.AnnotationSource;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.type.RecordComponentDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

public interface RecordComponentDescription extends DeclaredByType.WithMandatoryDeclaration, NamedElement.WithDescriptor, AnnotationSource, ByteCodeElement.TypeDependant<RecordComponentDescription.InDefinedShape, RecordComponentDescription.Token> {
  TypeDescription.Generic getType();
  
  MethodDescription getAccessor();
  
  Token asToken(ElementMatcher<? super TypeDescription> paramElementMatcher);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\type\RecordComponentDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */