/*    */ package META-INF.versions.9.net.bytebuddy.description.type;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.description.type.TypeList;
/*    */ import net.bytebuddy.matcher.FilterableList;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TypeList
/*    */   extends FilterableList<TypeDescription, TypeList>
/*    */ {
/*    */   @AlwaysNull
/* 51 */   public static final TypeList UNDEFINED = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @AlwaysNull
/*    */   @SuppressFBWarnings(value = {"MS_MUTABLE_ARRAY", "MS_OOI_PKGPROTECT"}, justification = "Null reference cannot be mutated.")
/* 58 */   public static final String[] NO_INTERFACES = null;
/*    */   
/*    */   @MaybeNull
/*    */   String[] toInternalNames();
/*    */   
/*    */   int getStackSize();
/*    */   
/*    */   Generic asGenericTypes();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\type\TypeList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */