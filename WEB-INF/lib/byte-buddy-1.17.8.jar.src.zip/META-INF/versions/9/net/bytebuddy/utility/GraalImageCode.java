/*     */ package META-INF.versions.9.net.bytebuddy.utility;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Locale;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum GraalImageCode
/*     */ {
/*  38 */   AGENT(true, false),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   BUILD(true, false),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   RUNTIME(true, true),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   UNKNOWN(false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   NONE(false, false);
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*     */       Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*     */       ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*     */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       ACCESS_CONTROLLER = false;
/*     */     } catch (SecurityException securityException) {
/*     */       ACCESS_CONTROLLER = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   @SuppressFBWarnings(value = {"LI_LAZY_INIT_STATIC", "NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "This behaviour is intended to avoid early binding in native images.")
/*     */   public static net.bytebuddy.utility.GraalImageCode getCurrent() {
/*  74 */     net.bytebuddy.utility.GraalImageCode current = net.bytebuddy.utility.GraalImageCode.current;
/*  75 */     if (current == null) {
/*  76 */       String value = doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("org.graalvm.nativeimage.imagecode"));
/*  77 */       if (value == null) {
/*  78 */         String vendor = doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("java.vm.vendor"));
/*     */         
/*  80 */         current = (vendor != null && vendor.toLowerCase(Locale.US).contains("graalvm")) ? doPrivileged((PrivilegedAction<net.bytebuddy.utility.GraalImageCode>)ImageCodeContextAction.INSTANCE) : NONE;
/*     */       }
/*  82 */       else if (value.equalsIgnoreCase("agent")) {
/*  83 */         current = AGENT;
/*  84 */       } else if (value.equalsIgnoreCase("runtime")) {
/*  85 */         current = RUNTIME;
/*  86 */       } else if (value.equalsIgnoreCase("buildtime")) {
/*  87 */         current = BUILD;
/*     */       } else {
/*  89 */         current = UNKNOWN;
/*     */       } 
/*  91 */       net.bytebuddy.utility.GraalImageCode.current = current;
/*     */     } 
/*  93 */     return current;
/*     */   }
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   private static net.bytebuddy.utility.GraalImageCode current;
/*     */   
/*     */   private final boolean defined;
/*     */   private final boolean nativeImageExecution;
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */   
/*     */   public <T> T[] sorted(T[] value, Comparator<? super T> comparator) {
/* 105 */     if (this.defined) {
/* 106 */       Arrays.sort(value, comparator);
/*     */     }
/* 108 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 121 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GraalImageCode(boolean defined, boolean nativeImageExecution) {
/* 141 */     this.defined = defined;
/* 142 */     this.nativeImageExecution = nativeImageExecution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefined() {
/* 151 */     return this.defined;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNativeImageExecution() {
/* 160 */     return this.nativeImageExecution;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\GraalImageCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */