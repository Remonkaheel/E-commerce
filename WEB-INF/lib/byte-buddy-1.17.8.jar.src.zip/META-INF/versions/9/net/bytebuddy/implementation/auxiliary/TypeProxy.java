/*     */ package META-INF.versions.9.net.bytebuddy.implementation.auxiliary;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Type;
/*     */ import net.bytebuddy.ByteBuddy;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.modifier.Ownership;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.DynamicType;
/*     */ import net.bytebuddy.dynamic.TargetType;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.MethodAccessorFactory;
/*     */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.RandomString;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class TypeProxy
/*     */   implements AuxiliaryType
/*     */ {
/*     */   public static final String REFLECTION_METHOD = "make";
/*     */   public static final String INSTANCE_FIELD = "target";
/*     */   private final TypeDescription proxiedType;
/*     */   private final Implementation.Target implementationTarget;
/*     */   private final InvocationFactory invocationFactory;
/*     */   private final boolean ignoreFinalizer;
/*     */   private final boolean serializableProxy;
/*     */   
/*     */   public TypeProxy(TypeDescription proxiedType, Implementation.Target implementationTarget, InvocationFactory invocationFactory, boolean ignoreFinalizer, boolean serializableProxy) {
/* 104 */     this.proxiedType = proxiedType;
/* 105 */     this.implementationTarget = implementationTarget;
/* 106 */     this.invocationFactory = invocationFactory;
/* 107 */     this.ignoreFinalizer = ignoreFinalizer;
/* 108 */     this.serializableProxy = serializableProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuffix() {
/* 115 */     return RandomString.hashOf(this.proxiedType.hashCode()) + (this.ignoreFinalizer ? "I" : "0") + (this.serializableProxy ? "S" : "0");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType make(String auxiliaryTypeName, ClassFileVersion classFileVersion, MethodAccessorFactory methodAccessorFactory) {
/* 131 */     (new Class[1])[0] = Serializable.class; return (DynamicType)(new ByteBuddy(classFileVersion)).with(TypeValidation.DISABLED).ignore(this.ignoreFinalizer ? (ElementMatcher)ElementMatchers.isFinalizer() : (ElementMatcher)ElementMatchers.none()).subclass((TypeDefinition)this.proxiedType).name(auxiliaryTypeName).modifiers(DEFAULT_TYPE_MODIFIER)
/* 132 */       .implement(this.serializableProxy ? (Type[])new Class[1] : (Type[])new Class[0])
/* 133 */       .method((ElementMatcher)ElementMatchers.any()).intercept((Implementation)new MethodCall(this, methodAccessorFactory))
/* 134 */       .defineMethod("make", TargetType.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Ownership.STATIC }).intercept((Implementation)SilentConstruction.INSTANCE)
/* 135 */       .make();
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.ignoreFinalizer != ((net.bytebuddy.implementation.auxiliary.TypeProxy)paramObject).ignoreFinalizer) ? false : ((this.serializableProxy != ((net.bytebuddy.implementation.auxiliary.TypeProxy)paramObject).serializableProxy) ? false : (!this.proxiedType.equals(((net.bytebuddy.implementation.auxiliary.TypeProxy)paramObject).proxiedType) ? false : (!this.implementationTarget.equals(((net.bytebuddy.implementation.auxiliary.TypeProxy)paramObject).implementationTarget) ? false : (!!this.invocationFactory.equals(((net.bytebuddy.implementation.auxiliary.TypeProxy)paramObject).invocationFactory))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.proxiedType.hashCode()) * 31 + this.implementationTarget.hashCode()) * 31 + this.invocationFactory.hashCode()) * 31 + this.ignoreFinalizer) * 31 + this.serializableProxy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\auxiliary\TypeProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */