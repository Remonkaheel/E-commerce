/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bind.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.annotation.AnnotationSource;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.method.ParameterDescription;
/*    */ import net.bytebuddy.implementation.bind.MethodDelegationBinder;
/*    */ import net.bytebuddy.implementation.bind.annotation.IgnoreForBinding;
/*    */ import net.bytebuddy.implementation.bind.annotation.RuntimeType;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class TargetMethodAnnotationDrivenBinder
/*    */   implements MethodDelegationBinder
/*    */ {
/*    */   private final DelegationProcessor delegationProcessor;
/*    */   
/*    */   protected TargetMethodAnnotationDrivenBinder(DelegationProcessor delegationProcessor) {
/* 56 */     this.delegationProcessor = delegationProcessor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MethodDelegationBinder of(List<? extends ParameterBinder<?>> parameterBinders) {
/* 68 */     return new net.bytebuddy.implementation.bind.annotation.TargetMethodAnnotationDrivenBinder(DelegationProcessor.of(parameterBinders));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodDelegationBinder.Record compile(MethodDescription candidate) {
/* 75 */     if (IgnoreForBinding.Verifier.check(candidate)) {
/* 76 */       return (MethodDelegationBinder.Record)MethodDelegationBinder.Record.Illegal.INSTANCE;
/*    */     }
/* 78 */     List<DelegationProcessor.Handler> handlers = new ArrayList<>(candidate.getParameters().size());
/* 79 */     for (ParameterDescription parameterDescription : candidate.getParameters()) {
/* 80 */       handlers.add(this.delegationProcessor.prepare(parameterDescription));
/*    */     }
/* 82 */     return (MethodDelegationBinder.Record)new Record(candidate, handlers, RuntimeType.Verifier.check((AnnotationSource)candidate));
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.delegationProcessor.equals(((net.bytebuddy.implementation.bind.annotation.TargetMethodAnnotationDrivenBinder)paramObject).delegationProcessor))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.delegationProcessor.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\annotation\TargetMethodAnnotationDrivenBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */