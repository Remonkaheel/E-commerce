/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.collection.ArrayFactory;
/*     */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MethodConstant
/*     */   extends StackManipulation.AbstractBase
/*     */ {
/*     */   @MaybeNull
/*  52 */   protected static final MethodDescription.InDefinedShape DO_PRIVILEGED = doPrivileged();
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*     */   private static MethodDescription.InDefinedShape doPrivileged() {
/*     */     MethodDescription.InDefinedShape doPrivileged;
/*     */     try {
/*  65 */       MethodDescription.ForLoadedMethod forLoadedMethod = new MethodDescription.ForLoadedMethod(Class.forName("java.security.AccessController").getMethod("doPrivileged", new Class[] { PrivilegedExceptionAction.class }));
/*     */       try {
/*  67 */         if (!Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"))) {
/*  68 */           forLoadedMethod = null;
/*     */         }
/*  70 */       } catch (SecurityException securityException) {}
/*     */     
/*     */     }
/*  73 */     catch (Exception ignored) {
/*  74 */       doPrivileged = null;
/*     */     } 
/*  76 */     return doPrivileged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodConstant(MethodDescription.InDefinedShape methodDescription) {
/*  91 */     this.methodDescription = methodDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CanCache of(MethodDescription.InDefinedShape methodDescription) {
/* 101 */     if (methodDescription.isTypeInitializer())
/* 102 */       return (CanCache)CanCacheIllegal.INSTANCE; 
/* 103 */     if (methodDescription.isConstructor()) {
/* 104 */       return (CanCache)new ForConstructor(methodDescription);
/*     */     }
/* 106 */     return (CanCache)new ForMethod(methodDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CanCache ofPrivileged(MethodDescription.InDefinedShape methodDescription) {
/* 119 */     if (DO_PRIVILEGED == null) {
/* 120 */       return of(methodDescription);
/*     */     }
/* 122 */     if (methodDescription.isTypeInitializer())
/* 123 */       return (CanCache)CanCacheIllegal.INSTANCE; 
/* 124 */     if (methodDescription.isConstructor()) {
/* 125 */       return (new ForConstructor(methodDescription)).withPrivilegedLookup();
/*     */     }
/* 127 */     return (new ForMethod(methodDescription)).withPrivilegedLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static List<StackManipulation> typeConstantsFor(List<TypeDescription> parameterTypes) {
/* 139 */     List<StackManipulation> typeConstants = new ArrayList<>(parameterTypes.size());
/* 140 */     for (TypeDescription parameterType : parameterTypes) {
/* 141 */       typeConstants.add(ClassConstant.of(parameterType));
/*     */     }
/* 143 */     return typeConstants;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 150 */     return (new StackManipulation.Compound(new StackManipulation[] {
/* 151 */           ClassConstant.of(this.methodDescription.getDeclaringType()), 
/* 152 */           methodName(), 
/* 153 */           ArrayFactory.forType(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Class.class))
/* 154 */           .withValues(typeConstantsFor((List<TypeDescription>)this.methodDescription.getParameters().asTypeList().asErasures())), 
/* 155 */           (StackManipulation)MethodInvocation.invoke(accessorMethod())
/* 156 */         })).apply(methodVisitor, implementationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CanCache withPrivilegedLookup() {
/* 165 */     return (CanCache)new PrivilegedLookup(this.methodDescription, methodName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract StackManipulation methodName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract MethodDescription.InDefinedShape accessorMethod();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 184 */     return this.methodDescription.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object other) {
/* 189 */     if (this == other)
/* 190 */       return true; 
/* 191 */     if (other == null || getClass() != other.getClass()) {
/* 192 */       return false;
/*     */     }
/* 194 */     net.bytebuddy.implementation.bytecode.constant.MethodConstant methodConstant = (net.bytebuddy.implementation.bytecode.constant.MethodConstant)other;
/* 195 */     return this.methodDescription.equals(methodConstant.methodDescription);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\MethodConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */