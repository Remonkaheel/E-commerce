/*     */ package META-INF.versions.9.net.bytebuddy.description.modifier;
/*     */ 
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TypeManifestation
/*     */   implements ModifierContributor.ForType
/*     */ {
/*  28 */   PLAIN(0),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   FINAL(16),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   ABSTRACT(1024),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   INTERFACE(1536),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   ANNOTATION(9728);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int mask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeManifestation(int mask) {
/*  61 */     this.mask = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMask() {
/*  68 */     return this.mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRange() {
/*  75 */     return 9744;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/*  82 */     return (this == PLAIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinal() {
/*  91 */     return ((this.mask & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbstract() {
/* 100 */     return ((this.mask & 0x400) != 0 && !isInterface());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterface() {
/* 109 */     return ((this.mask & 0x200) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotation() {
/* 118 */     return ((this.mask & 0x2000) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\modifier\TypeManifestation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */