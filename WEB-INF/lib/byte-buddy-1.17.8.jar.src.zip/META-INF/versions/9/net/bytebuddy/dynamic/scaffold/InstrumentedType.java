package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import java.util.List;
import net.bytebuddy.description.annotation.AnnotationDescription;
import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.type.RecordComponentDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeList;
import net.bytebuddy.description.type.TypeVariableToken;
import net.bytebuddy.dynamic.scaffold.TypeInitializer;
import net.bytebuddy.implementation.LoadedTypeInitializer;
import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface InstrumentedType extends TypeDescription {
  net.bytebuddy.dynamic.scaffold.InstrumentedType withField(FieldDescription.Token paramToken);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withAuxiliaryField(FieldDescription.Token paramToken, Object paramObject);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withMethod(MethodDescription.Token paramToken);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withRecordComponent(RecordComponentDescription.Token paramToken);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withModifiers(int paramInt);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withInterfaces(TypeList.Generic paramGeneric);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withTypeVariable(TypeVariableToken paramTypeVariableToken);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withAnnotations(List<? extends AnnotationDescription> paramList);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withNestHost(TypeDescription paramTypeDescription);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withNestMembers(TypeList paramTypeList);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withEnclosingType(TypeDescription paramTypeDescription);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withEnclosingMethod(MethodDescription.InDefinedShape paramInDefinedShape);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withDeclaringType(@MaybeNull TypeDescription paramTypeDescription);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withDeclaredTypes(TypeList paramTypeList);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withPermittedSubclasses(@MaybeNull TypeList paramTypeList);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withLocalClass(boolean paramBoolean);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withAnonymousClass(boolean paramBoolean);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withRecord(boolean paramBoolean);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withInitializer(LoadedTypeInitializer paramLoadedTypeInitializer);
  
  net.bytebuddy.dynamic.scaffold.InstrumentedType withInitializer(ByteCodeAppender paramByteCodeAppender);
  
  LoadedTypeInitializer getLoadedTypeInitializer();
  
  TypeInitializer getTypeInitializer();
  
  TypeDescription validated();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\InstrumentedType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */