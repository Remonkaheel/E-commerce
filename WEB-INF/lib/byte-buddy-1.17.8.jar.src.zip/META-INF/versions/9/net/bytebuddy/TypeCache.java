/*     */ package META-INF.versions.9.net.bytebuddy;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeCache<T>
/*     */   extends ReferenceQueue<ClassLoader>
/*     */ {
/*     */   @AlwaysNull
/*  63 */   private static final Class<?> NOT_FOUND = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Sort sort;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ConcurrentMap<StorageKey, ConcurrentMap<T, Object>> cache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeCache() {
/*  79 */     this(Sort.STRONG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeCache(Sort sort) {
/*  88 */     this.sort = sort;
/*  89 */     this.cache = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   @SuppressFBWarnings(value = {"GC_UNRELATED_TYPES"}, justification = "Cross-comparison is intended.")
/*     */   public Class<?> find(@MaybeNull ClassLoader classLoader, T key) {
/* 102 */     ConcurrentMap<T, Object> storage = this.cache.get(new LookupKey(classLoader));
/* 103 */     if (storage == null) {
/* 104 */       return NOT_FOUND;
/*     */     }
/* 106 */     Object value = storage.get(key);
/* 107 */     if (value == null)
/* 108 */       return NOT_FOUND; 
/* 109 */     if (value instanceof Reference) {
/* 110 */       return ((Reference<Class<?>>)value).get();
/*     */     }
/* 112 */     return (Class)value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"GC_UNRELATED_TYPES"}, justification = "Cross-comparison is intended.")
/*     */   public Class<?> insert(@MaybeNull ClassLoader classLoader, T key, Class<?> type) {
/* 127 */     ConcurrentMap<T, Object> storage = this.cache.get(new LookupKey(classLoader));
/* 128 */     if (storage == null) {
/* 129 */       storage = new ConcurrentHashMap<>();
/* 130 */       ConcurrentMap<T, Object> concurrentMap = this.cache.putIfAbsent(new StorageKey(classLoader, this), storage);
/* 131 */       if (concurrentMap != null) {
/* 132 */         storage = concurrentMap;
/*     */       }
/*     */     } 
/* 135 */     Object value = this.sort.wrap(type), previous = storage.putIfAbsent(key, value);
/* 136 */     while (previous != null) {
/*     */       
/* 138 */       Class<?> previousType = (previous instanceof Reference) ? ((Reference<Class<?>>)previous).get() : (Class)previous;
/*     */       
/* 140 */       if (previousType != null)
/* 141 */         return previousType; 
/* 142 */       if (storage.remove(key, previous)) {
/* 143 */         previous = storage.putIfAbsent(key, value); continue;
/*     */       } 
/* 145 */       previous = storage.get(key);
/* 146 */       if (previous == null) {
/* 147 */         previous = storage.putIfAbsent(key, value);
/*     */       }
/*     */     } 
/*     */     
/* 151 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findOrInsert(@MaybeNull ClassLoader classLoader, T key, Callable<Class<?>> lazy) {
/* 163 */     Class<?> type = find(classLoader, key);
/* 164 */     if (type != null) {
/* 165 */       return type;
/*     */     }
/*     */     try {
/* 168 */       return insert(classLoader, key, lazy.call());
/* 169 */     } catch (Throwable throwable) {
/* 170 */       throw new IllegalArgumentException("Could not create type", throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findOrInsert(@MaybeNull ClassLoader classLoader, T key, Callable<Class<?>> lazy, Object monitor) {
/* 185 */     Class<?> type = find(classLoader, key);
/* 186 */     if (type != null) {
/* 187 */       return type;
/*     */     }
/* 189 */     synchronized (monitor) {
/* 190 */       return findOrInsert(classLoader, key, lazy);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expungeStaleEntries() {
/*     */     Reference<?> reference;
/* 200 */     while ((reference = poll()) != null) {
/* 201 */       this.cache.remove(reference);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 209 */     this.cache.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\TypeCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */