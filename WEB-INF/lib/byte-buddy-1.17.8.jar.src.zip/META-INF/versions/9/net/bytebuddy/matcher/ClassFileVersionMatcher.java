/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import net.bytebuddy.ClassFileVersion;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class ClassFileVersionMatcher<T extends TypeDescription>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<T>
/*    */ {
/*    */   private final ClassFileVersion classFileVersion;
/*    */   private final boolean atMost;
/*    */   
/*    */   public ClassFileVersionMatcher(ClassFileVersion classFileVersion, boolean atMost) {
/* 47 */     this.classFileVersion = classFileVersion;
/* 48 */     this.atMost = atMost;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean doMatch(T target) {
/* 53 */     ClassFileVersion classFileVersion = target.getClassFileVersion();
/* 54 */     return (classFileVersion != null && (this.atMost ? classFileVersion.isAtMost(this.classFileVersion) : classFileVersion.isAtLeast(this.classFileVersion)));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return "hasClassFileVersion(at " + (this.atMost ? "most" : "least") + " " + this.classFileVersion + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.atMost != ((net.bytebuddy.matcher.ClassFileVersionMatcher)paramObject).atMost) ? false : (!!this.classFileVersion.equals(((net.bytebuddy.matcher.ClassFileVersionMatcher)paramObject).classFileVersion))))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return (super.hashCode() * 31 + this.classFileVersion.hashCode()) * 31 + this.atMost;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\ClassFileVersionMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */