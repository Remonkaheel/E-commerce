/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.member;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.constant.JavaConstantValue;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.JavaConstant;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class Invokedynamic
/*    */   extends StackManipulation.AbstractBase
/*    */ {
/*    */   private final String name;
/*    */   private final JavaConstant.MethodType type;
/*    */   private final JavaConstant.MethodHandle bootstrap;
/*    */   private final List<? extends JavaConstant> arguments;
/*    */   
/*    */   public Invokedynamic(String name, JavaConstant.MethodType type, JavaConstant.MethodHandle bootstrap, List<? extends JavaConstant> arguments) {
/* 65 */     this.name = name;
/* 66 */     this.type = type;
/* 67 */     this.bootstrap = bootstrap;
/* 68 */     this.arguments = arguments;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 75 */     Object[] argument = new Object[this.arguments.size()];
/* 76 */     for (int index = 0; index < this.arguments.size(); index++) {
/* 77 */       argument[index] = ((JavaConstant)this.arguments.get(index)).accept((JavaConstant.Visitor)JavaConstantValue.Visitor.INSTANCE);
/*    */     }
/* 79 */     methodVisitor.visitInvokeDynamicInsn(this.name, this.type
/* 80 */         .getDescriptor(), JavaConstantValue.Visitor.INSTANCE
/* 81 */         .onMethodHandle(this.bootstrap), argument);
/*    */     
/* 83 */     return new StackManipulation.Size(this.type
/* 84 */         .getReturnType().getStackSize().getSize() - this.type.getParameterTypes().getStackSize(), this.type
/* 85 */         .getReturnType().getStackSize().getSize());
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.name.equals(((net.bytebuddy.implementation.bytecode.member.Invokedynamic)paramObject).name) ? false : (!this.type.equals(((net.bytebuddy.implementation.bytecode.member.Invokedynamic)paramObject).type) ? false : (!this.bootstrap.equals(((net.bytebuddy.implementation.bytecode.member.Invokedynamic)paramObject).bootstrap) ? false : (!!this.arguments.equals(((net.bytebuddy.implementation.bytecode.member.Invokedynamic)paramObject).arguments)))))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return (((getClass().hashCode() * 31 + this.name.hashCode()) * 31 + this.type.hashCode()) * 31 + this.bootstrap.hashCode()) * 31 + this.arguments.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\member\Invokedynamic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */