/*      */ package META-INF.versions.9.net.bytebuddy;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.Type;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Random;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.NamingStrategy;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.modifier.EnumerationState;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.modifier.Ownership;
/*      */ import net.bytebuddy.description.modifier.TypeManifestation;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.PackageDescription;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.dynamic.ClassFileLocator;
/*      */ import net.bytebuddy.dynamic.DynamicType;
/*      */ import net.bytebuddy.dynamic.TargetType;
/*      */ import net.bytebuddy.dynamic.VisibilityBridgeStrategy;
/*      */ import net.bytebuddy.dynamic.scaffold.ClassWriterStrategy;
/*      */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*      */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*      */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*      */ import net.bytebuddy.dynamic.scaffold.inline.DecoratingDynamicTypeBuilder;
/*      */ import net.bytebuddy.dynamic.scaffold.inline.MethodNameTransformer;
/*      */ import net.bytebuddy.dynamic.scaffold.inline.RebaseDynamicTypeBuilder;
/*      */ import net.bytebuddy.dynamic.scaffold.inline.RedefinitionDynamicTypeBuilder;
/*      */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*      */ import net.bytebuddy.dynamic.scaffold.subclass.SubclassDynamicTypeBuilder;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.MethodCall;
/*      */ import net.bytebuddy.implementation.SuperMethodCall;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationRetention;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*      */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*      */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.matcher.LatentMatcher;
/*      */ import net.bytebuddy.utility.AsmClassReader;
/*      */ import net.bytebuddy.utility.AsmClassWriter;
/*      */ import net.bytebuddy.utility.GraalImageCode;
/*      */ import net.bytebuddy.utility.JavaType;
/*      */ import net.bytebuddy.utility.RandomString;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Enhance
/*      */ public class ByteBuddy
/*      */ {
/*      */   public static final String DEFAULT_NAMING_PROPERTY = "net.bytebuddy.naming";
/*      */   public static final String DEFAULT_VALIDATION_PROPERTY = "net.bytebuddy.validation";
/*      */   private static final String BYTE_BUDDY_DEFAULT_PREFIX = "ByteBuddy";
/*      */   private static final String BYTE_BUDDY_DEFAULT_SUFFIX = "auxiliary";
/*      */   private static final String BYTE_BUDDY_DEFAULT_CONTEXT_NAME = "synthetic";
/*      */   private static final TypeValidation DEFAULT_TYPE_VALIDATION;
/*      */   @MaybeNull
/*      */   private static final NamingStrategy DEFAULT_NAMING_STRATEGY;
/*      */   @MaybeNull
/*      */   private static final AuxiliaryType.NamingStrategy DEFAULT_AUXILIARY_NAMING_STRATEGY;
/*      */   @MaybeNull
/*      */   private static final Implementation.Context.Factory DEFAULT_IMPLEMENTATION_CONTEXT_FACTORY;
/*      */   protected final ClassFileVersion classFileVersion;
/*      */   protected final NamingStrategy namingStrategy;
/*      */   protected final AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy;
/*      */   protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*      */   protected final AnnotationRetention annotationRetention;
/*      */   protected final Implementation.Context.Factory implementationContextFactory;
/*      */   protected final MethodGraph.Compiler methodGraphCompiler;
/*      */   protected final InstrumentedType.Factory instrumentedTypeFactory;
/*      */   protected final LatentMatcher<? super MethodDescription> ignoredMethods;
/*      */   protected final TypeValidation typeValidation;
/*      */   protected final VisibilityBridgeStrategy visibilityBridgeStrategy;
/*      */   protected final AsmClassReader.Factory classReaderFactory;
/*      */   protected final AsmClassWriter.Factory classWriterFactory;
/*      */   private static final boolean ACCESS_CONTROLLER;
/*      */   
/*      */   static {
/*      */     String validation, naming;
/*      */     NamingStrategy.SuffixingRandom suffixingRandom;
/*      */     AuxiliaryType.NamingStrategy.Suffixing suffixing;
/*      */     Implementation.Context.Default.Factory.WithFixedSuffix withFixedSuffix;
/*      */     
/*  221 */     try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }  try { validation = doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.validation")); }
/*      */     catch (Throwable ignored) { validation = null; }
/*      */      DEFAULT_TYPE_VALIDATION = (validation == null || Boolean.parseBoolean(validation)) ? TypeValidation.ENABLED : TypeValidation.DISABLED; try { naming = doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.naming")); }
/*      */     catch (Throwable ignored) { naming = null; }
/*      */      if (naming == null) { if (GraalImageCode.getCurrent().isDefined()) { NamingStrategy.Suffixing suffixing1 = new NamingStrategy.Suffixing("ByteBuddy", (NamingStrategy.Suffixing.BaseNameResolver)new NamingStrategy.Suffixing.BaseNameResolver.WithCallerSuffix((NamingStrategy.Suffixing.BaseNameResolver)NamingStrategy.Suffixing.BaseNameResolver.ForUnnamedType.INSTANCE), "net.bytebuddy.renamed"); suffixing = new AuxiliaryType.NamingStrategy.Suffixing("auxiliary"); withFixedSuffix = new Implementation.Context.Default.Factory.WithFixedSuffix("synthetic"); }
/*      */       else { NamingStrategy namingStrategy = null; AuxiliaryType.NamingStrategy auxiliaryNamingStrategy = null; Implementation.Context.Factory implementationContextFactory = null; }
/*      */        }
/*      */     else if (naming.equalsIgnoreCase("fixed")) { NamingStrategy.Suffixing suffixing1 = new NamingStrategy.Suffixing("ByteBuddy", (NamingStrategy.Suffixing.BaseNameResolver)NamingStrategy.Suffixing.BaseNameResolver.ForUnnamedType.INSTANCE, "net.bytebuddy.renamed"); suffixing = new AuxiliaryType.NamingStrategy.Suffixing("auxiliary"); withFixedSuffix = new Implementation.Context.Default.Factory.WithFixedSuffix("synthetic"); }
/*      */     else if (naming.equalsIgnoreCase("caller")) { NamingStrategy.Suffixing suffixing1 = new NamingStrategy.Suffixing("ByteBuddy", (NamingStrategy.Suffixing.BaseNameResolver)new NamingStrategy.Suffixing.BaseNameResolver.WithCallerSuffix((NamingStrategy.Suffixing.BaseNameResolver)NamingStrategy.Suffixing.BaseNameResolver.ForUnnamedType.INSTANCE), "net.bytebuddy.renamed"); suffixing = new AuxiliaryType.NamingStrategy.Suffixing("auxiliary"); withFixedSuffix = new Implementation.Context.Default.Factory.WithFixedSuffix("synthetic"); }
/*      */     else { long seed; try { seed = Long.parseLong(naming); }
/*      */       catch (Exception ignored) { throw new IllegalStateException("'net.bytebuddy.naming' is set to an unknown, non-numeric value: " + naming); }
/*      */        suffixingRandom = new NamingStrategy.SuffixingRandom("ByteBuddy", (NamingStrategy.Suffixing.BaseNameResolver)NamingStrategy.Suffixing.BaseNameResolver.ForUnnamedType.INSTANCE, "net.bytebuddy.renamed", new RandomString(8, new Random(seed))); suffixing = new AuxiliaryType.NamingStrategy.Suffixing("auxiliary"); withFixedSuffix = new Implementation.Context.Default.Factory.WithFixedSuffix("synthetic"); }
/*  233 */      DEFAULT_NAMING_STRATEGY = (NamingStrategy)suffixingRandom; DEFAULT_AUXILIARY_NAMING_STRATEGY = (AuxiliaryType.NamingStrategy)suffixing; DEFAULT_IMPLEMENTATION_CONTEXT_FACTORY = (Implementation.Context.Factory)withFixedSuffix; } @MaybeNull @Enhance private static <T> T doPrivileged(PrivilegedAction<T> action) { return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuddy() {
/*  313 */     this(ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuddy(ClassFileVersion classFileVersion) {
/*  322 */     this(classFileVersion, (DEFAULT_NAMING_STRATEGY == null) ? (NamingStrategy)new NamingStrategy.SuffixingRandom("ByteBuddy") : DEFAULT_NAMING_STRATEGY, (DEFAULT_AUXILIARY_NAMING_STRATEGY == null) ? (AuxiliaryType.NamingStrategy)new AuxiliaryType.NamingStrategy.SuffixingRandom("auxiliary") : DEFAULT_AUXILIARY_NAMING_STRATEGY, (AnnotationValueFilter.Factory)AnnotationValueFilter.Default.APPEND_DEFAULTS, AnnotationRetention.ENABLED, (DEFAULT_IMPLEMENTATION_CONTEXT_FACTORY == null) ? (Implementation.Context.Factory)Implementation.Context.Default.Factory.INSTANCE : DEFAULT_IMPLEMENTATION_CONTEXT_FACTORY, MethodGraph.Compiler.DEFAULT, (InstrumentedType.Factory)InstrumentedType.Factory.Default.MODIFIABLE, DEFAULT_TYPE_VALIDATION, (VisibilityBridgeStrategy)VisibilityBridgeStrategy.Default.ALWAYS, (AsmClassReader.Factory)AsmClassReader.Factory.Default.IMPLICIT, (AsmClassWriter.Factory)AsmClassWriter.Factory.Default.IMPLICIT, (LatentMatcher<? super MethodDescription>)new LatentMatcher.Resolved(
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  340 */           (ElementMatcher)ElementMatchers.isSynthetic().or((ElementMatcher)ElementMatchers.isDefaultFinalizer())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ByteBuddy(ClassFileVersion classFileVersion, NamingStrategy namingStrategy, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, Implementation.Context.Factory implementationContextFactory, MethodGraph.Compiler methodGraphCompiler, InstrumentedType.Factory instrumentedTypeFactory, TypeValidation typeValidation, VisibilityBridgeStrategy visibilityBridgeStrategy, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, LatentMatcher<? super MethodDescription> ignoredMethods) {
/*  373 */     this.classFileVersion = classFileVersion;
/*  374 */     this.namingStrategy = namingStrategy;
/*  375 */     this.auxiliaryTypeNamingStrategy = auxiliaryTypeNamingStrategy;
/*  376 */     this.annotationValueFilterFactory = annotationValueFilterFactory;
/*  377 */     this.annotationRetention = annotationRetention;
/*  378 */     this.implementationContextFactory = implementationContextFactory;
/*  379 */     this.methodGraphCompiler = methodGraphCompiler;
/*  380 */     this.instrumentedTypeFactory = instrumentedTypeFactory;
/*  381 */     this.typeValidation = typeValidation;
/*  382 */     this.visibilityBridgeStrategy = visibilityBridgeStrategy;
/*  383 */     this.classReaderFactory = classReaderFactory;
/*  384 */     this.classWriterFactory = classWriterFactory;
/*  385 */     this.ignoredMethods = ignoredMethods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> subclass(Class<T> superType) {
/*  412 */     return (DynamicType.Builder)subclass((TypeDefinition)TypeDescription.ForLoadedType.of(superType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> subclass(Class<T> superType, ConstructorStrategy constructorStrategy) {
/*  435 */     return (DynamicType.Builder)subclass((TypeDefinition)TypeDescription.ForLoadedType.of(superType), constructorStrategy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> subclass(Type superType) {
/*  463 */     return subclass((TypeDefinition)TypeDefinition.Sort.describe(superType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> subclass(Type superType, ConstructorStrategy constructorStrategy) {
/*  487 */     return subclass((TypeDefinition)TypeDefinition.Sort.describe(superType), constructorStrategy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> subclass(TypeDefinition superType) {
/*  515 */     return subclass(superType, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> subclass(TypeDefinition superType, ConstructorStrategy constructorStrategy) {
/*      */     TypeDescription.Generic actualSuperType;
/*      */     TypeList.Generic.Empty empty;
/*  541 */     if (superType.isPrimitive() || superType.isArray() || superType.isFinal())
/*  542 */       throw new IllegalArgumentException("Cannot subclass primitive, array or final types: " + superType); 
/*  543 */     if (superType.isInterface()) {
/*  544 */       actualSuperType = TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class);
/*  545 */       TypeList.Generic.Explicit explicit = new TypeList.Generic.Explicit(new TypeDefinition[] { superType });
/*      */     } else {
/*  547 */       actualSuperType = superType.asGenericType();
/*  548 */       empty = new TypeList.Generic.Empty();
/*      */     } 
/*  550 */     return (DynamicType.Builder<?>)new SubclassDynamicTypeBuilder(this.instrumentedTypeFactory.subclass(this.namingStrategy.subclass(superType.asGenericType()), 
/*  551 */           ModifierContributor.Resolver.of(new ModifierContributor.ForType[] { (ModifierContributor.ForType)Visibility.PUBLIC, (ModifierContributor.ForType)TypeManifestation.PLAIN }, ).resolve(superType.getModifiers()), actualSuperType)
/*  552 */         .withInterfaces((TypeList.Generic)empty), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, constructorStrategy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makeInterface() {
/*  579 */     return makeInterface(Collections.emptyList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> makeInterface(Class<T> interfaceType) {
/*  600 */     return (DynamicType.Builder)makeInterface(Collections.singletonList(interfaceType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makeInterface(Type... interfaceType) {
/*  622 */     return makeInterface(Arrays.asList(interfaceType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makeInterface(List<? extends Type> interfaceTypes) {
/*  644 */     return makeInterface((Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(interfaceTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makeInterface(TypeDefinition... interfaceType) {
/*  666 */     return makeInterface(Arrays.asList(interfaceType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makeInterface(Collection<? extends TypeDefinition> interfaceTypes) {
/*  688 */     return subclass((Class)Object.class, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).implement(interfaceTypes).modifiers(new ModifierContributor.ForType[] { (ModifierContributor.ForType)TypeManifestation.INTERFACE, (ModifierContributor.ForType)Visibility.PUBLIC });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makePackage(String name) {
/*  706 */     return (DynamicType.Builder<?>)new SubclassDynamicTypeBuilder(this.instrumentedTypeFactory.subclass(name + "." + "package-info", 5632, 
/*      */           
/*  708 */           TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> makeRecord() {
/*  742 */     TypeDescription.Generic record = InstrumentedType.Default.of(JavaType.RECORD.getTypeStub().getName(), TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), new ModifierContributor.ForType[] { (ModifierContributor.ForType)Visibility.PUBLIC }).withMethod(new MethodDescription.Token(4)).withMethod(new MethodDescription.Token("hashCode", 1025, TypeDescription.ForLoadedType.of(int.class).asGenericType())).withMethod(new MethodDescription.Token("equals", 1025, TypeDescription.ForLoadedType.of(boolean.class).asGenericType(), Collections.singletonList(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)))).withMethod(new MethodDescription.Token("toString", 1025, TypeDescription.ForLoadedType.of(String.class).asGenericType())).asGenericType();
/*  743 */     return (DynamicType.Builder<?>)(new SubclassDynamicTypeBuilder(this.instrumentedTypeFactory.subclass(this.namingStrategy.subclass(record), 17, record).withRecord(true), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, (ConstructorStrategy)RecordConstructorStrategy.INSTANCE))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  756 */       .method((ElementMatcher)ElementMatchers.isHashCode()).intercept((Implementation)RecordObjectMethod.HASH_CODE)
/*  757 */       .method((ElementMatcher)ElementMatchers.isEquals()).intercept((Implementation)RecordObjectMethod.EQUALS)
/*  758 */       .method((ElementMatcher)ElementMatchers.isToString()).intercept((Implementation)RecordObjectMethod.TO_STRING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<? extends Annotation> makeAnnotation() {
/*  774 */     return (DynamicType.Builder<? extends Annotation>)new SubclassDynamicTypeBuilder(this.instrumentedTypeFactory.subclass(this.namingStrategy.subclass(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Annotation.class)), 
/*  775 */           ModifierContributor.Resolver.of(new ModifierContributor.ForType[] { (ModifierContributor.ForType)Visibility.PUBLIC, (ModifierContributor.ForType)TypeManifestation.ANNOTATION }, ).resolve(), 
/*  776 */           TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)).withInterfaces((TypeList.Generic)new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Annotation.class) })), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<? extends Enum<?>> makeEnumeration(String... value) {
/*  804 */     return makeEnumeration(Arrays.asList(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<? extends Enum<?>> makeEnumeration(Collection<? extends String> values) {
/*  820 */     if (values.isEmpty()) {
/*  821 */       throw new IllegalArgumentException("Require at least one enumeration constant");
/*      */     }
/*  823 */     TypeDescription.Generic enumType = TypeDescription.Generic.Builder.parameterizedType(Enum.class, new Type[] { TargetType.class }).build();
/*  824 */     return (DynamicType.Builder<? extends Enum<?>>)(new SubclassDynamicTypeBuilder(this.instrumentedTypeFactory.subclass(this.namingStrategy.subclass(enumType), 
/*  825 */           ModifierContributor.Resolver.of(new ModifierContributor.ForType[] { (ModifierContributor.ForType)Visibility.PUBLIC, (ModifierContributor.ForType)TypeManifestation.FINAL, (ModifierContributor.ForType)EnumerationState.ENUMERATION }, ).resolve(), enumType), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  839 */       .defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { String.class, int.class
/*  840 */         }).intercept((Implementation)SuperMethodCall.INSTANCE)
/*  841 */       .defineMethod("valueOf", TargetType.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC, (ModifierContributor.ForMethod)Ownership.STATIC
/*      */         
/*  843 */         }).withParameters(new Type[] { String.class
/*  844 */         }).intercept((Implementation)MethodCall.invoke((MethodDescription)((MethodList)enumType.getDeclaredMethods()
/*  845 */           .filter((ElementMatcher)ElementMatchers.named("valueOf").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { Class.class, String.class })))).getOnly())
/*  846 */         .withOwnType().withArgument(new int[] { 0
/*  847 */           }).withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC))
/*  848 */       .defineMethod("values", TargetType[].class, new ModifierContributor.ForMethod[] {
/*      */           
/*      */           (ModifierContributor.ForMethod)Visibility.PUBLIC, (ModifierContributor.ForMethod)Ownership.STATIC
/*  851 */         }).intercept((Implementation)new EnumerationImplementation(new ArrayList<>(values)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> redefine(Class<T> type) {
/*  876 */     return redefine(type, ClassFileLocator.ForClassLoader.of(type.getClassLoader()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> redefine(Class<T> type, ClassFileLocator classFileLocator) {
/*  898 */     return redefine(TypeDescription.ForLoadedType.of(type), classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> redefine(TypeDescription type, ClassFileLocator classFileLocator) {
/*  920 */     if (type.isArray() || type.isPrimitive()) {
/*  921 */       throw new IllegalArgumentException("Cannot redefine array or primitive type: " + type);
/*      */     }
/*  923 */     return (DynamicType.Builder<T>)new RedefinitionDynamicTypeBuilder(this.instrumentedTypeFactory.represent(type), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, type, classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> rebase(Class<T> type) {
/*  955 */     return rebase(type, ClassFileLocator.ForClassLoader.of(type.getClassLoader()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> rebase(Class<T> type, ClassFileLocator classFileLocator) {
/*  976 */     return rebase(TypeDescription.ForLoadedType.of(type), classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> rebase(Class<T> type, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer) {
/*  991 */     return rebase(TypeDescription.ForLoadedType.of(type), classFileLocator, methodNameTransformer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> rebase(TypeDescription type, ClassFileLocator classFileLocator) {
/* 1012 */     return rebase(type, classFileLocator, MethodNameTransformer.Suffixing.withRandomSuffix());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> rebase(TypeDescription type, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer) {
/* 1027 */     if (type.isArray() || type.isPrimitive()) {
/* 1028 */       throw new IllegalArgumentException("Cannot rebase array or primitive type: " + type);
/*      */     }
/* 1030 */     return (DynamicType.Builder<T>)new RebaseDynamicTypeBuilder(this.instrumentedTypeFactory.represent(type), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, type, classFileLocator, methodNameTransformer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> rebase(Package aPackage, ClassFileLocator classFileLocator) {
/* 1057 */     return rebase((PackageDescription)new PackageDescription.ForLoadedPackage(aPackage), classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DynamicType.Builder<?> rebase(PackageDescription aPackage, ClassFileLocator classFileLocator) {
/* 1070 */     return rebase((TypeDescription)new TypeDescription.ForPackageDescription(aPackage), classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> decorate(Class<T> type) {
/* 1090 */     return decorate(type, ClassFileLocator.ForClassLoader.of(type.getClassLoader()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> decorate(Class<T> type, ClassFileLocator classFileLocator) {
/* 1111 */     return decorate(TypeDescription.ForLoadedType.of(type), classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> DynamicType.Builder<T> decorate(TypeDescription type, ClassFileLocator classFileLocator) {
/* 1132 */     if (type.isArray() || type.isPrimitive()) {
/* 1133 */       throw new IllegalArgumentException("Cannot decorate array or primitive type: " + type);
/*      */     }
/* 1135 */     return (DynamicType.Builder<T>)new DecoratingDynamicTypeBuilder(type, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, classFileLocator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(ClassFileVersion classFileVersion) {
/* 1159 */     return new net.bytebuddy.ByteBuddy(classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(NamingStrategy namingStrategy) {
/* 1184 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy) {
/* 1208 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1233 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(AnnotationRetention annotationRetention) {
/* 1265 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(Implementation.Context.Factory implementationContextFactory) {
/* 1292 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(MethodGraph.Compiler methodGraphCompiler) {
/* 1319 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(InstrumentedType.Factory instrumentedTypeFactory) {
/* 1342 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(TypeValidation typeValidation) {
/* 1367 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(VisibilityBridgeStrategy visibilityBridgeStrategy) {
/* 1390 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public net.bytebuddy.ByteBuddy with(ClassWriterStrategy classWriterStrategy) {
/* 1415 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, (AsmClassWriter.Factory)new ClassWriterStrategy.Delegating(classWriterStrategy), this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(AsmClassReader.Factory classReaderFactory) {
/* 1437 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, classReaderFactory, this.classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy with(AsmClassWriter.Factory classWriterFactory) {
/* 1459 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, classWriterFactory, this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy withIgnoredClassReader() {
/* 1480 */     if (this.classWriterFactory instanceof AsmClassWriter.Factory.Suppressing) {
/* 1481 */       return this;
/*      */     }
/* 1483 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, (AsmClassWriter.Factory)new AsmClassWriter.Factory.Suppressing(this.classWriterFactory), this.ignoredMethods);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy ignore(ElementMatcher<? super MethodDescription> ignoredMethods) {
/* 1508 */     return ignore((LatentMatcher<? super MethodDescription>)new LatentMatcher.Resolved(ignoredMethods));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public net.bytebuddy.ByteBuddy ignore(LatentMatcher<? super MethodDescription> ignoredMethods) {
/* 1524 */     return new net.bytebuddy.ByteBuddy(this.classFileVersion, this.namingStrategy, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.instrumentedTypeFactory, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, ignoredMethods);
/*      */   }
/*      */   
/*      */   public boolean equals(@MaybeNull Object paramObject) {
/*      */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.annotationRetention.equals(((net.bytebuddy.ByteBuddy)paramObject).annotationRetention) ? false : (!this.typeValidation.equals(((net.bytebuddy.ByteBuddy)paramObject).typeValidation) ? false : (!this.classFileVersion.equals(((net.bytebuddy.ByteBuddy)paramObject).classFileVersion) ? false : (!this.namingStrategy.equals(((net.bytebuddy.ByteBuddy)paramObject).namingStrategy) ? false : (!this.auxiliaryTypeNamingStrategy.equals(((net.bytebuddy.ByteBuddy)paramObject).auxiliaryTypeNamingStrategy) ? false : (!this.annotationValueFilterFactory.equals(((net.bytebuddy.ByteBuddy)paramObject).annotationValueFilterFactory) ? false : (!this.implementationContextFactory.equals(((net.bytebuddy.ByteBuddy)paramObject).implementationContextFactory) ? false : (!this.methodGraphCompiler.equals(((net.bytebuddy.ByteBuddy)paramObject).methodGraphCompiler) ? false : (!this.instrumentedTypeFactory.equals(((net.bytebuddy.ByteBuddy)paramObject).instrumentedTypeFactory) ? false : (!this.ignoredMethods.equals(((net.bytebuddy.ByteBuddy)paramObject).ignoredMethods) ? false : (!this.visibilityBridgeStrategy.equals(((net.bytebuddy.ByteBuddy)paramObject).visibilityBridgeStrategy) ? false : (!this.classReaderFactory.equals(((net.bytebuddy.ByteBuddy)paramObject).classReaderFactory) ? false : (!!this.classWriterFactory.equals(((net.bytebuddy.ByteBuddy)paramObject).classWriterFactory))))))))))))))));
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*      */     return ((((((((((((getClass().hashCode() * 31 + this.classFileVersion.hashCode()) * 31 + this.namingStrategy.hashCode()) * 31 + this.auxiliaryTypeNamingStrategy.hashCode()) * 31 + this.annotationValueFilterFactory.hashCode()) * 31 + this.annotationRetention.hashCode()) * 31 + this.implementationContextFactory.hashCode()) * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.instrumentedTypeFactory.hashCode()) * 31 + this.ignoredMethods.hashCode()) * 31 + this.typeValidation.hashCode()) * 31 + this.visibilityBridgeStrategy.hashCode()) * 31 + this.classReaderFactory.hashCode()) * 31 + this.classWriterFactory.hashCode();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\ByteBuddy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */