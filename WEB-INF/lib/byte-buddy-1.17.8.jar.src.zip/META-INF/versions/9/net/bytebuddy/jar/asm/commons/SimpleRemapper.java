/*     */ package META-INF.versions.9.net.bytebuddy.jar.asm.commons;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.jar.asm.Handle;
/*     */ import net.bytebuddy.jar.asm.commons.Remapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleRemapper
/*     */   extends Remapper
/*     */ {
/*     */   private final Map<String, String> mapping;
/*     */   
/*     */   @Deprecated
/*     */   public SimpleRemapper(Map<String, String> mapping) {
/*  68 */     this.mapping = mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleRemapper(int api, Map<String, String> mapping) {
/*  93 */     super(api);
/*  94 */     this.mapping = mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SimpleRemapper(String oldName, String newName) {
/* 108 */     this.mapping = Collections.singletonMap(oldName, newName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleRemapper(int api, String oldName, String newName) {
/* 122 */     super(api);
/* 123 */     this.mapping = Collections.singletonMap(oldName, newName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapMethodName(String owner, String name, String descriptor) {
/* 128 */     String remappedName = map(stringConcat$0(owner, name, descriptor));
/* 129 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapInvokeDynamicMethodName(String name, String descriptor) {
/* 134 */     String remappedName = map(stringConcat$1(name, descriptor));
/* 135 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapInvokeDynamicMethodName(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 144 */     String remappedName = map(stringConcat$2(name, descriptor));
/* 145 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapAnnotationAttributeName(String descriptor, String name) {
/* 150 */     String remappedName = map(stringConcat$3(descriptor, name));
/* 151 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String mapFieldName(String owner, String name, String descriptor) {
/* 156 */     String remappedName = map(stringConcat$4(owner, name));
/* 157 */     return (remappedName == null) ? name : remappedName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String map(String key) {
/* 162 */     return this.mapping.get(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\jar\asm\commons\SimpleRemapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */