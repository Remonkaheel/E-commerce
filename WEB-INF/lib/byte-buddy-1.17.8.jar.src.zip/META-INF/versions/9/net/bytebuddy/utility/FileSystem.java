/*    */ package META-INF.versions.9.net.bytebuddy.utility;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*    */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FileSystem
/*    */ {
/*    */   private static final boolean ACCESS_CONTROLLER;
/*    */   
/*    */   @Enhance("INSTANCE")
/*    */   public static net.bytebuddy.utility.FileSystem getInstance() {}
/*    */   
/*    */   @Enhance
/*    */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 56 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void link(File source, File target) throws IOException {
/* 76 */     copy(source, target);
/*    */   }
/*    */   
/*    */   public abstract void copy(File paramFile1, File paramFile2) throws IOException;
/*    */   
/*    */   public abstract void move(File paramFile1, File paramFile2) throws IOException;
/*    */   
/*    */   static {
/*    */     try {
/*    */       Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*    */       ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*    */     } catch (ClassNotFoundException classNotFoundException) {
/*    */       ACCESS_CONTROLLER = false;
/*    */     } catch (SecurityException securityException) {
/*    */       ACCESS_CONTROLLER = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\FileSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */