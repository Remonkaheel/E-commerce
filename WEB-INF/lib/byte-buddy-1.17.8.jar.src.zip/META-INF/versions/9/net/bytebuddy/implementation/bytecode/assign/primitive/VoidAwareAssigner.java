/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.bytecode.Removal;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*    */ import net.bytebuddy.implementation.bytecode.constant.DefaultValue;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class VoidAwareAssigner
/*    */   implements Assigner
/*    */ {
/*    */   private final Assigner chained;
/*    */   
/*    */   public VoidAwareAssigner(Assigner chained) {
/* 51 */     this.chained = chained;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation assign(TypeDescription.Generic source, TypeDescription.Generic target, Assigner.Typing typing) {
/* 58 */     if (source.represents(void.class) && target.represents(void.class))
/* 59 */       return (StackManipulation)StackManipulation.Trivial.INSTANCE; 
/* 60 */     if (source.represents(void.class)) {
/* 61 */       return typing.isDynamic() ? 
/* 62 */         DefaultValue.of((TypeDefinition)target) : (StackManipulation)StackManipulation.Illegal.INSTANCE;
/*    */     }
/* 64 */     if (target.represents(void.class)) {
/* 65 */       return Removal.of((TypeDefinition)source);
/*    */     }
/* 67 */     return this.chained.assign(source, target, typing);
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.chained.equals(((net.bytebuddy.implementation.bytecode.assign.primitive.VoidAwareAssigner)paramObject).chained))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.chained.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\VoidAwareAssigner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */