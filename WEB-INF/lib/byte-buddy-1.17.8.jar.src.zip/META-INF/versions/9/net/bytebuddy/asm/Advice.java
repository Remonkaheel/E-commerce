/*     */ package META-INF.versions.9.net.bytebuddy.asm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.ClassFileLocator;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.SuperMethodCall;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.AsmClassReader;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ import net.bytebuddy.utility.visitor.LineNumberPrependingMethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class Advice
/*     */   implements AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper, Implementation
/*     */ {
/*     */   @AlwaysNull
/*     */   private static final AsmClassReader UNDEFINED;
/*     */   private static final MethodDescription.InDefinedShape SKIP_ON;
/*     */   private static final MethodDescription.InDefinedShape SKIP_ON_INDEX;
/*     */   private static final MethodDescription.InDefinedShape PREPEND_LINE_NUMBER;
/*     */   private static final MethodDescription.InDefinedShape INLINE_ENTER;
/*     */   private static final MethodDescription.InDefinedShape SUPPRESS_ENTER;
/*     */   private static final MethodDescription.InDefinedShape REPEAT_ON;
/*     */   private static final MethodDescription.InDefinedShape REPEAT_ON_INDEX;
/*     */   private static final MethodDescription.InDefinedShape ON_THROWABLE;
/*     */   private static final MethodDescription.InDefinedShape BACKUP_ARGUMENTS;
/*     */   private static final MethodDescription.InDefinedShape INLINE_EXIT;
/*     */   private static final MethodDescription.InDefinedShape SUPPRESS_EXIT;
/*     */   private final Dispatcher.Resolved.ForMethodEnter methodEnter;
/*     */   private final Dispatcher.Resolved.ForMethodExit methodExit;
/*     */   private final Assigner assigner;
/*     */   private final ExceptionHandler exceptionHandler;
/*     */   private final Implementation delegate;
/*     */   
/*     */   protected Advice(Dispatcher.Resolved.ForMethodEnter methodEnter, Dispatcher.Resolved.ForMethodExit methodExit) {
/* 275 */     this(methodEnter, methodExit, Assigner.DEFAULT, (ExceptionHandler)ExceptionHandler.Default.SUPPRESSING, (Implementation)SuperMethodCall.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Advice(Dispatcher.Resolved.ForMethodEnter methodEnter, Dispatcher.Resolved.ForMethodExit methodExit, Assigner assigner, ExceptionHandler exceptionHandler, Implementation delegate) {
/* 292 */     this.methodEnter = methodEnter;
/* 293 */     this.methodExit = methodExit;
/* 294 */     this.assigner = assigner;
/* 295 */     this.exceptionHandler = exceptionHandler;
/* 296 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(Class<?> advice) {
/* 307 */     return to(advice, ClassFileLocator.ForClassLoader.of(advice.getClassLoader()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(Class<?> advice, ClassFileLocator classFileLocator) {
/* 318 */     return to(TypeDescription.ForLoadedType.of(advice), classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(TypeDescription advice) {
/* 330 */     return to(advice, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(TypeDescription advice, ClassFileLocator classFileLocator) {
/* 341 */     return to(advice, (PostProcessor.Factory)PostProcessor.NoOp.INSTANCE, classFileLocator, 
/*     */ 
/*     */         
/* 344 */         Collections.emptyList(), (Delegator.Factory)Delegator.ForRegularInvocation.Factory.INSTANCE, (AsmClassReader.Factory)AsmClassReader.Factory.Default.IMPLICIT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static net.bytebuddy.asm.Advice to(TypeDescription advice, PostProcessor.Factory postProcessorFactory, ClassFileLocator classFileLocator, List<? extends OffsetMapping.Factory<?>> userFactories, Delegator.Factory delegatorFactory, AsmClassReader.Factory classReaderFactory) {
/*     */     Dispatcher.Unresolved unresolved1, unresolved2;
/* 366 */     Dispatcher.Inactive inactive1 = Dispatcher.Inactive.INSTANCE, inactive2 = Dispatcher.Inactive.INSTANCE;
/* 367 */     for (MethodDescription.InDefinedShape methodDescription : advice.getDeclaredMethods()) {
/* 368 */       unresolved1 = locate((Class)OnMethodEnter.class, INLINE_ENTER, (Dispatcher.Unresolved)inactive1, methodDescription, delegatorFactory);
/* 369 */       unresolved2 = locate((Class)OnMethodExit.class, INLINE_EXIT, (Dispatcher.Unresolved)inactive2, methodDescription, delegatorFactory);
/*     */     } 
/* 371 */     if (!unresolved1.isAlive() && !unresolved2.isAlive()) {
/* 372 */       throw new IllegalArgumentException("No advice defined by " + advice);
/*     */     }
/*     */     
/*     */     try {
/* 376 */       AsmClassReader classReader = (unresolved1.isBinary() || unresolved2.isBinary()) ? classReaderFactory.make(classFileLocator.locate(advice.getName()).resolve()) : UNDEFINED;
/*     */       
/* 378 */       return new net.bytebuddy.asm.Advice(unresolved1.asMethodEnter(userFactories, classReader, unresolved2, postProcessorFactory), unresolved2
/* 379 */           .asMethodExit(userFactories, classReader, unresolved1, postProcessorFactory));
/* 380 */     } catch (IOException exception) {
/* 381 */       throw new IllegalStateException("Error reading class file of " + advice, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(Class<?> enterAdvice, Class<?> exitAdvice) {
/* 394 */     ClassLoader enterLoader = enterAdvice.getClassLoader(), exitLoader = exitAdvice.getClassLoader();
/* 395 */     return to(enterAdvice, exitAdvice, (enterLoader == exitLoader) ? 
/* 396 */         ClassFileLocator.ForClassLoader.of(enterLoader) : (ClassFileLocator)new ClassFileLocator.Compound(new ClassFileLocator[] {
/* 397 */             ClassFileLocator.ForClassLoader.of(enterLoader), ClassFileLocator.ForClassLoader.of(exitLoader)
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(Class<?> enterAdvice, Class<?> exitAdvice, ClassFileLocator classFileLocator) {
/* 409 */     return to(TypeDescription.ForLoadedType.of(enterAdvice), TypeDescription.ForLoadedType.of(exitAdvice), classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice) {
/* 422 */     return to(enterAdvice, exitAdvice, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice, ClassFileLocator classFileLocator) {
/* 434 */     return to(enterAdvice, exitAdvice, (PostProcessor.Factory)PostProcessor.NoOp.INSTANCE, classFileLocator, 
/*     */ 
/*     */ 
/*     */         
/* 438 */         Collections.emptyList(), (Delegator.Factory)Delegator.ForRegularInvocation.Factory.INSTANCE, (AsmClassReader.Factory)AsmClassReader.Factory.Default.IMPLICIT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static net.bytebuddy.asm.Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice, PostProcessor.Factory postProcessorFactory, ClassFileLocator classFileLocator, List<? extends OffsetMapping.Factory<?>> userFactories, Delegator.Factory delegatorFactory, AsmClassReader.Factory classReaderFactory) {
/*     */     Dispatcher.Unresolved unresolved1, unresolved2;
/* 462 */     Dispatcher.Inactive inactive1 = Dispatcher.Inactive.INSTANCE, inactive2 = Dispatcher.Inactive.INSTANCE;
/* 463 */     for (MethodDescription.InDefinedShape methodDescription : enterAdvice.getDeclaredMethods()) {
/* 464 */       unresolved1 = locate((Class)OnMethodEnter.class, INLINE_ENTER, (Dispatcher.Unresolved)inactive1, methodDescription, delegatorFactory);
/*     */     }
/* 466 */     if (!unresolved1.isAlive()) {
/* 467 */       throw new IllegalArgumentException("No enter advice defined by " + enterAdvice);
/*     */     }
/* 469 */     for (MethodDescription.InDefinedShape methodDescription : exitAdvice.getDeclaredMethods()) {
/* 470 */       unresolved2 = locate((Class)OnMethodExit.class, INLINE_EXIT, (Dispatcher.Unresolved)inactive2, methodDescription, delegatorFactory);
/*     */     }
/* 472 */     if (!unresolved2.isAlive()) {
/* 473 */       throw new IllegalArgumentException("No exit advice defined by " + exitAdvice);
/*     */     }
/*     */     try {
/* 476 */       return new net.bytebuddy.asm.Advice(unresolved1.asMethodEnter(userFactories, unresolved1.isBinary() ? classReaderFactory
/* 477 */             .make(classFileLocator.locate(enterAdvice.getName()).resolve()) : UNDEFINED, unresolved2, postProcessorFactory), unresolved2
/* 478 */           .asMethodExit(userFactories, unresolved2.isBinary() ? classReaderFactory
/* 479 */             .make(classFileLocator.locate(exitAdvice.getName()).resolve()) : UNDEFINED, unresolved1, postProcessorFactory));
/*     */     }
/* 481 */     catch (IOException exception) {
/* 482 */       throw new IllegalStateException("Error reading class file of " + enterAdvice + " or " + exitAdvice, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Dispatcher.Unresolved locate(Class<? extends Annotation> type, MethodDescription.InDefinedShape property, Dispatcher.Unresolved dispatcher, MethodDescription.InDefinedShape methodDescription, Delegator.Factory delegatorFactory) {
/* 501 */     AnnotationDescription.Loadable loadable = methodDescription.getDeclaredAnnotations().ofType(type);
/* 502 */     if (loadable == null)
/* 503 */       return dispatcher; 
/* 504 */     if (dispatcher.isAlive())
/* 505 */       throw new IllegalStateException("Duplicate advice for " + dispatcher + " and " + methodDescription); 
/* 506 */     if (!methodDescription.isStatic()) {
/* 507 */       throw new IllegalStateException("Advice for " + methodDescription + " is not static");
/*     */     }
/* 509 */     return ((Boolean)loadable.getValue(property).resolve(Boolean.class)).booleanValue() ? (Dispatcher.Unresolved)new Dispatcher.Inlining(methodDescription) : (Dispatcher.Unresolved)new Dispatcher.Delegating(methodDescription, delegatorFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithCustomMapping withCustomMapping() {
/* 522 */     return new WithCustomMapping();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper.ForDeclaredMethods on(ElementMatcher<? super MethodDescription> matcher) {
/* 532 */     return (new AsmVisitorWrapper.ForDeclaredMethods()).invokable(matcher, new AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper[] { this });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor wrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, TypePool typePool, int writerFlags, int readerFlags) {
/* 545 */     return (instrumentedMethod.isAbstract() || instrumentedMethod.isNative()) ? methodVisitor : 
/*     */       
/* 547 */       doWrap(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, writerFlags, readerFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodVisitor doWrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, int writerFlags, int readerFlags) {
/*     */     LineNumberPrependingMethodVisitor lineNumberPrependingMethodVisitor;
/* 567 */     if (this.methodEnter.isPrependLineNumber()) {
/* 568 */       lineNumberPrependingMethodVisitor = new LineNumberPrependingMethodVisitor(methodVisitor);
/*     */     }
/* 570 */     if (!this.methodExit.isAlive()) {
/* 571 */       return (MethodVisitor)new AdviceVisitor.WithoutExitAdvice((MethodVisitor)lineNumberPrependingMethodVisitor, implementationContext, this.assigner, this.exceptionHandler
/*     */ 
/*     */           
/* 574 */           .resolve(instrumentedMethod, instrumentedType), instrumentedType, instrumentedMethod, this.methodEnter, writerFlags, readerFlags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 580 */     if (this.methodExit.getThrowable().represents(NoExceptionHandler.class)) {
/* 581 */       return (MethodVisitor)new AdviceVisitor.WithExitAdvice.WithoutExceptionHandling((MethodVisitor)lineNumberPrependingMethodVisitor, implementationContext, this.assigner, this.exceptionHandler
/*     */ 
/*     */           
/* 584 */           .resolve(instrumentedMethod, instrumentedType), instrumentedType, instrumentedMethod, this.methodEnter, this.methodExit, writerFlags, readerFlags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 591 */     if (instrumentedMethod.isConstructor()) {
/* 592 */       throw new IllegalStateException("Cannot catch exception during constructor call for " + instrumentedMethod);
/*     */     }
/* 594 */     return (MethodVisitor)new AdviceVisitor.WithExitAdvice.WithExceptionHandling((MethodVisitor)lineNumberPrependingMethodVisitor, implementationContext, this.assigner, this.exceptionHandler
/*     */ 
/*     */         
/* 597 */         .resolve(instrumentedMethod, instrumentedType), instrumentedType, instrumentedMethod, this.methodEnter, this.methodExit, writerFlags, readerFlags, this.methodExit
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 604 */         .getThrowable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 612 */     return this.delegate.prepare(instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 619 */     return (ByteCodeAppender)new Appender(this, implementationTarget, this.delegate.appender(implementationTarget));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.Advice withAssigner(Assigner assigner) {
/* 629 */     return new net.bytebuddy.asm.Advice(this.methodEnter, this.methodExit, assigner, this.exceptionHandler, this.delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.Advice withExceptionPrinting() {
/* 638 */     return withExceptionHandler((ExceptionHandler)ExceptionHandler.Default.PRINTING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.Advice withExceptionHandler(StackManipulation exceptionHandler) {
/* 649 */     return withExceptionHandler((ExceptionHandler)new ExceptionHandler.Simple(exceptionHandler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.asm.Advice withExceptionHandler(ExceptionHandler exceptionHandler) {
/* 660 */     return new net.bytebuddy.asm.Advice(this.methodEnter, this.methodExit, this.assigner, exceptionHandler, this.delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation wrap(Implementation implementation) {
/* 670 */     return new net.bytebuddy.asm.Advice(this.methodEnter, this.methodExit, this.assigner, this.exceptionHandler, implementation);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.methodEnter.equals(((net.bytebuddy.asm.Advice)paramObject).methodEnter) ? false : (!this.methodExit.equals(((net.bytebuddy.asm.Advice)paramObject).methodExit) ? false : (!this.assigner.equals(((net.bytebuddy.asm.Advice)paramObject).assigner) ? false : (!this.exceptionHandler.equals(((net.bytebuddy.asm.Advice)paramObject).exceptionHandler) ? false : (!!this.delegate.equals(((net.bytebuddy.asm.Advice)paramObject).delegate))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.methodEnter.hashCode()) * 31 + this.methodExit.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.exceptionHandler.hashCode()) * 31 + this.delegate.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\Advice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */