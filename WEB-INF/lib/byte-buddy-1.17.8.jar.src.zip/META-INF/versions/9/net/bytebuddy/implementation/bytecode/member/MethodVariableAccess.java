/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.member;
/*     */ 
/*     */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MethodVariableAccess
/*     */ {
/*     */   INTEGER, LONG, FLOAT, DOUBLE, REFERENCE;
/*     */   private final int loadOpcode;
/*     */   private final int storeOpcode;
/*     */   private final StackSize size;
/*     */   
/*     */   MethodVariableAccess(int loadOpcode, int storeOpcode, StackSize stackSize) {
/*  87 */     this.loadOpcode = loadOpcode;
/*  88 */     this.size = stackSize;
/*  89 */     this.storeOpcode = storeOpcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.member.MethodVariableAccess of(TypeDefinition typeDefinition) {
/*  99 */     if (typeDefinition.isPrimitive()) {
/* 100 */       if (typeDefinition.represents(long.class))
/* 101 */         return LONG; 
/* 102 */       if (typeDefinition.represents(double.class))
/* 103 */         return DOUBLE; 
/* 104 */       if (typeDefinition.represents(float.class))
/* 105 */         return FLOAT; 
/* 106 */       if (typeDefinition.represents(void.class)) {
/* 107 */         throw new IllegalArgumentException("Variable type cannot be void");
/*     */       }
/* 109 */       return INTEGER;
/*     */     } 
/*     */     
/* 112 */     return REFERENCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodLoading allArgumentsOf(MethodDescription methodDescription) {
/* 123 */     return new MethodLoading(methodDescription, (MethodLoading.TypeCastingHandler)MethodLoading.TypeCastingHandler.NoOp.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance("loadThis")
/*     */   public static StackManipulation loadThis() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation loadFrom(int offset) {
/* 143 */     return (StackManipulation)new OffsetLoading(this, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation storeAt(int offset) {
/* 153 */     return (StackManipulation)new OffsetWriting(this, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation increment(int offset, int value) {
/* 164 */     if (this != INTEGER) {
/* 165 */       throw new IllegalStateException("Cannot increment type: " + this);
/*     */     }
/* 167 */     return (StackManipulation)new OffsetIncrementing(offset, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation load(ParameterDescription parameterDescription) {
/* 177 */     return of((TypeDefinition)parameterDescription.getType()).loadFrom(parameterDescription.getOffset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation store(ParameterDescription parameterDescription) {
/* 187 */     return of((TypeDefinition)parameterDescription.getType()).storeAt(parameterDescription.getOffset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation increment(ParameterDescription parameterDescription, int value) {
/* 198 */     return of((TypeDefinition)parameterDescription.getType()).increment(parameterDescription.getOffset(), value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\member\MethodVariableAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */