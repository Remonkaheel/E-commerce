/*    */ package META-INF.versions.9.net.bytebuddy.description;
/*    */ 
/*    */ import net.bytebuddy.description.ModifierReviewable;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.description.type.TypeList;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TypeVariableSource
/*    */   extends ModifierReviewable.OfAbstraction
/*    */ {
/*    */   @AlwaysNull
/* 35 */   public static final net.bytebuddy.description.TypeVariableSource UNDEFINED = null;
/*    */   
/*    */   TypeList.Generic getTypeVariables();
/*    */   
/*    */   @MaybeNull
/*    */   net.bytebuddy.description.TypeVariableSource getEnclosingSource();
/*    */   
/*    */   boolean isInferrable();
/*    */   
/*    */   @MaybeNull
/*    */   TypeDescription.Generic findVariable(String paramString);
/*    */   
/*    */   TypeDescription.Generic findExpectedVariable(String paramString);
/*    */   
/*    */   <T> T accept(Visitor<T> paramVisitor);
/*    */   
/*    */   boolean isGenerified();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\TypeVariableSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */