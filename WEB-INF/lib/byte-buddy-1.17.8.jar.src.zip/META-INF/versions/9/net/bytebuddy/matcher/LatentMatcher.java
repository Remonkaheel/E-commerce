package META-INF.versions.9.net.bytebuddy.matcher;

import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

public interface LatentMatcher<T> {
  ElementMatcher<? super T> resolve(TypeDescription paramTypeDescription);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\LatentMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */