/*     */ package META-INF.versions.9.net.bytebuddy.asm;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.ByteBuddy;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.modifier.FieldManifestation;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.modifier.Ownership;
/*     */ import net.bytebuddy.description.modifier.Visibility;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.DynamicType;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*     */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*     */ import net.bytebuddy.implementation.ExceptionMethod;
/*     */ import net.bytebuddy.implementation.FieldAccessor;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.MethodCall;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.Duplication;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.TypeCreation;
/*     */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public abstract class ClassVisitorFactory<T>
/*     */ {
/*     */   private static final String DELEGATE = "delegate";
/*     */   private static final String LABELS = "labels";
/*     */   private static final String WRAP = "wrap";
/*     */   private final Class<?> type;
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */   
/*     */   protected ClassVisitorFactory(Class<?> type) {
/*  95 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 104 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> net.bytebuddy.asm.ClassVisitorFactory<S> of(Class<S> classVisitor) {
/* 115 */     return of(classVisitor, (new ByteBuddy()).with(TypeValidation.DISABLED));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> net.bytebuddy.asm.ClassVisitorFactory<S> of(Class<S> classVisitor, ByteBuddy byteBuddy) {
/* 127 */     return doPrivileged((PrivilegedAction<net.bytebuddy.asm.ClassVisitorFactory<S>>)new CreateClassVisitorFactory(classVisitor, byteBuddy));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 139 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static DynamicType.Builder<?> toVisitorBuilder(ByteBuddy byteBuddy, Class<?> sourceVisitor, Class<?> targetVisitor, @MaybeNull Class<?> sourceTypePath, @MaybeNull Class<?> targetTypePath, Implementation appendix) throws Exception {
/* 170 */     DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition = byteBuddy.subclass(sourceVisitor, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).defineField("delegate", targetVisitor, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)FieldManifestation.FINAL }).defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { targetVisitor }).intercept(MethodCall.invoke(sourceVisitor.getDeclaredConstructor(new Class[] { int.class })).with(new Object[] { Integer.valueOf(OpenedClassReader.ASM_API) }).andThen(FieldAccessor.ofField("delegate").setsArgumentAt(0)).andThen(appendix)).defineMethod("wrap", sourceVisitor, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters(new Type[] { targetVisitor }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new NullCheckedConstruction(targetVisitor) }));
/* 171 */     if (sourceTypePath == null || targetTypePath == null) {
/* 172 */       return (DynamicType.Builder<?>)receiverTypeDefinition;
/*     */     }
/* 174 */     return (DynamicType.Builder<?>)receiverTypeDefinition
/* 175 */       .defineMethod("typePath", targetTypePath, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC
/* 176 */         }).withParameters(new Type[] { sourceTypePath
/* 177 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new TypePathTranslator(sourceTypePath, targetTypePath) }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static DynamicType.Builder<?> toMethodVisitorBuilder(ByteBuddy byteBuddy, Class<?> sourceVisitor, Class<?> targetVisitor, @MaybeNull Class<?> sourceTypePath, @MaybeNull Class<?> targetTypePath, @MaybeNull Class<?> sourceLabel, @MaybeNull Class<?> targetLabel, @MaybeNull Class<?> sourceType, @MaybeNull Class<?> targetType, @MaybeNull Class<?> sourceHandle, @MaybeNull Class<?> targetHandle, @MaybeNull Class<?> sourceConstantDynamic, @MaybeNull Class<?> targetConstantDynamic) throws Exception {
/*     */     DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition;
/* 213 */     DynamicType.Builder<?> builder = toVisitorBuilder(byteBuddy, sourceVisitor, targetVisitor, sourceTypePath, targetTypePath, 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 218 */         (Implementation)FieldAccessor.ofField("labels").setsValue((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { TypeCreation.of(TypeDescription.ForLoadedType.of(HashMap.class)), (StackManipulation)Duplication.SINGLE, 
/*     */               
/* 220 */               (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(HashMap.class)
/* 221 */                 .getDeclaredMethods()
/* 222 */                 .filter((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.takesArguments(0))))
/* 223 */                 .getOnly()) }, ), Map.class));
/* 224 */     if (sourceLabel != null && targetLabel != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       receiverTypeDefinition = builder.defineField("labels", Map.class, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)FieldManifestation.FINAL }).defineMethod("label", targetLabel, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { sourceLabel }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new LabelTranslator(targetLabel) })).defineMethod("labels", (TypeDefinition)TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(targetLabel)), new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new TypeDefinition[] { (TypeDefinition)TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(sourceLabel)) }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new LabelArrayTranslator(sourceLabel, targetLabel) })).defineMethod("frames", Object[].class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { Object[].class }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new FrameTranslator(sourceLabel, targetLabel) }));
/*     */     }
/* 237 */     if (sourceHandle != null && targetHandle != null)
/*     */     {
/*     */ 
/*     */       
/* 241 */       receiverTypeDefinition = receiverTypeDefinition.defineMethod("handle", targetHandle, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters(new Type[] { sourceHandle }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new HandleTranslator(sourceHandle, targetHandle) }));
/*     */     }
/* 243 */     if (sourceConstantDynamic != null && targetConstantDynamic != null && sourceHandle != null && targetHandle != null)
/*     */     {
/*     */ 
/*     */       
/* 247 */       receiverTypeDefinition = receiverTypeDefinition.defineMethod("constantDyanmic", targetConstantDynamic, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters(new Type[] { sourceConstantDynamic }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new ConstantDynamicTranslator(sourceConstantDynamic, targetConstantDynamic, sourceHandle, targetHandle) }));
/*     */     }
/* 249 */     return (DynamicType.Builder<?>)receiverTypeDefinition
/* 250 */       .defineMethod("constant", Object.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC
/* 251 */         }).withParameters(new Type[] { Object.class
/* 252 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new ConstantTranslator(sourceHandle, targetHandle, sourceType, targetType, sourceConstantDynamic, targetConstantDynamic)
/* 253 */           })).defineMethod("constants", Object[].class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC
/* 254 */         }).withParameters(new Type[] { Object[].class
/* 255 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new ConstantArrayTranslator() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MethodCall.ArgumentLoader.Factory toConvertedParameter(TypeDescription source, Class<?> target, String method, int offset, boolean virtual) {
/* 269 */     return (MethodCall.ArgumentLoader.Factory)new MethodCall.ArgumentLoader.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { virtual ? MethodVariableAccess.loadThis() : (StackManipulation)StackManipulation.Trivial.INSTANCE, MethodVariableAccess.REFERENCE
/* 270 */             .loadFrom(offset), 
/* 271 */             (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)((MethodList)source.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named(method))).getOnly()) }, ), target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static DynamicType toAttributeWrapper(DynamicType.Builder<?> builder, Class<?> source, Class<?> target, TypeDescription sourceWrapper, TypeDescription targetWrapper) throws Exception {
/* 286 */     return (DynamicType)builder
/* 287 */       .defineField("delegate", target, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PUBLIC, (ModifierContributor.ForField)FieldManifestation.FINAL
/* 288 */         }).defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC
/* 289 */         }).withParameters(new Type[] { target
/* 290 */         }).intercept((Implementation)MethodCall.invoke(source.getDeclaredConstructor(new Class[] { String.class
/* 291 */             })).onSuper()
/* 292 */         .with((StackManipulation)new StackManipulation.Compound(new StackManipulation[] {
/* 293 */               MethodVariableAccess.REFERENCE.loadFrom(1), 
/* 294 */               FieldAccess.forField((FieldDescription.InDefinedShape)new FieldDescription.ForLoadedField(target.getField("type"))).read() }, ), String.class)
/* 295 */         .andThen(FieldAccessor.ofField("delegate").setsArgumentAt(0)))
/* 296 */       .defineMethod("attribute", source, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC, (ModifierContributor.ForMethod)Ownership.STATIC
/* 297 */         }).withParameters(new Type[] { target
/* 298 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { (ByteCodeAppender)new AttributeTranslator(source, target, sourceWrapper, targetWrapper)
/* 299 */           })).method((ElementMatcher)ElementMatchers.isProtected())
/* 300 */       .intercept(ExceptionMethod.throwing(UnsupportedOperationException.class))
/* 301 */       .method((ElementMatcher)ElementMatchers.named("isUnknown"))
/* 302 */       .intercept((Implementation)MethodCall.invoke(target.getMethod("isUnknown", new Class[0])).onField("delegate"))
/* 303 */       .method((ElementMatcher)ElementMatchers.named("isCodeAttribute"))
/* 304 */       .intercept((Implementation)MethodCall.invoke(target.getMethod("isCodeAttribute", new Class[0])).onField("delegate"))
/* 305 */       .make();
/*     */   }
/*     */   
/*     */   public abstract T wrap(ClassVisitor paramClassVisitor);
/*     */   
/*     */   public abstract ClassVisitor unwrap(T paramT);
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.type.equals(((net.bytebuddy.asm.ClassVisitorFactory)paramObject).type))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return getClass().hashCode() * 31 + this.type.hashCode();
/*     */   }
/*     */   
/*     */   static {
/*     */     try {
/*     */       Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*     */       ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*     */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       ACCESS_CONTROLLER = false;
/*     */     } catch (SecurityException securityException) {
/*     */       ACCESS_CONTROLLER = true;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\ClassVisitorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */