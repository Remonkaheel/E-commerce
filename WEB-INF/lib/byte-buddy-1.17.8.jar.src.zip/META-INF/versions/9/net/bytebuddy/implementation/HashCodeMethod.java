/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class HashCodeMethod
/*     */   implements Implementation
/*     */ {
/*     */   private static final int DEFAULT_OFFSET = 17;
/*     */   private static final int DEFAULT_MULTIPLIER = 31;
/*     */   private static final MethodDescription.InDefinedShape HASH_CODE;
/*     */   private static final MethodDescription.InDefinedShape GET_CLASS;
/*     */   private final OffsetProvider offsetProvider;
/*     */   private final int multiplier;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> ignored;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> nonNullable;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> identity;
/*     */   
/*     */   protected HashCodeMethod(OffsetProvider offsetProvider) {
/* 108 */     this(offsetProvider, 31, ElementMatchers.none(), ElementMatchers.none(), ElementMatchers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashCodeMethod(OffsetProvider offsetProvider, int multiplier, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> ignored, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> nonNullable, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> identity) {
/* 125 */     this.offsetProvider = offsetProvider;
/* 126 */     this.multiplier = multiplier;
/* 127 */     this.ignored = ignored;
/* 128 */     this.nonNullable = nonNullable;
/* 129 */     this.identity = identity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.HashCodeMethod usingSuperClassOffset() {
/* 138 */     return new net.bytebuddy.implementation.HashCodeMethod((OffsetProvider)OffsetProvider.ForSuperMethodCall.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.HashCodeMethod usingTypeHashOffset(boolean dynamic) {
/* 148 */     return new net.bytebuddy.implementation.HashCodeMethod(dynamic ? (OffsetProvider)OffsetProvider.ForDynamicTypeHash.INSTANCE : (OffsetProvider)OffsetProvider.ForStaticTypeHash.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.HashCodeMethod usingDefaultOffset() {
/* 157 */     return usingOffset(17);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.HashCodeMethod usingOffset(int value) {
/* 167 */     return new net.bytebuddy.implementation.HashCodeMethod((OffsetProvider)new OffsetProvider.ForFixedValue(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.HashCodeMethod withIgnoredFields(ElementMatcher<? super FieldDescription.InDefinedShape> ignored) {
/* 178 */     return new net.bytebuddy.implementation.HashCodeMethod(this.offsetProvider, this.multiplier, this.ignored.or(ignored), this.nonNullable, this.identity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.HashCodeMethod withNonNullableFields(ElementMatcher<? super FieldDescription.InDefinedShape> nonNullable) {
/* 190 */     return new net.bytebuddy.implementation.HashCodeMethod(this.offsetProvider, this.multiplier, this.ignored, this.nonNullable.or(nonNullable), this.identity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.HashCodeMethod withIdentityFields(ElementMatcher<? super FieldDescription.InDefinedShape> identity) {
/* 200 */     return new net.bytebuddy.implementation.HashCodeMethod(this.offsetProvider, this.multiplier, this.ignored, this.nonNullable, this.identity.or(identity));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.HashCodeMethod withMultiplier(int multiplier) {
/* 212 */     if (multiplier == 0) {
/* 213 */       throw new IllegalArgumentException("Hash code multiplier must not be zero");
/*     */     }
/* 215 */     return new net.bytebuddy.implementation.HashCodeMethod(this.offsetProvider, multiplier, this.ignored, this.nonNullable, this.identity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 222 */     return instrumentedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 229 */     if (implementationTarget.getInstrumentedType().isInterface()) {
/* 230 */       throw new IllegalStateException("Cannot implement meaningful hash code method for " + implementationTarget.getInstrumentedType());
/*     */     }
/* 232 */     return (ByteCodeAppender)new Appender(this.offsetProvider.resolve(implementationTarget.getInstrumentedType()), this.multiplier, (List)implementationTarget
/*     */         
/* 234 */         .getInstrumentedType().getDeclaredFields().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic().or((ElementMatcher)this.ignored))), (ElementMatcher)this.nonNullable, (ElementMatcher)this.identity);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.multiplier != ((net.bytebuddy.implementation.HashCodeMethod)paramObject).multiplier) ? false : (!this.offsetProvider.equals(((net.bytebuddy.implementation.HashCodeMethod)paramObject).offsetProvider) ? false : (!this.ignored.equals(((net.bytebuddy.implementation.HashCodeMethod)paramObject).ignored) ? false : (!this.nonNullable.equals(((net.bytebuddy.implementation.HashCodeMethod)paramObject).nonNullable) ? false : (!!this.identity.equals(((net.bytebuddy.implementation.HashCodeMethod)paramObject).identity))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.offsetProvider.hashCode()) * 31 + this.multiplier) * 31 + this.ignored.hashCode()) * 31 + this.nonNullable.hashCode()) * 31 + this.identity.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\HashCodeMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */