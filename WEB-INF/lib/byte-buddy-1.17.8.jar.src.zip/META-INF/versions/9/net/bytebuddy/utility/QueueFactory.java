/*    */ package META-INF.versions.9.net.bytebuddy.utility;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedList;
/*    */ import java.util.Queue;
/*    */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class QueueFactory
/*    */ {
/* 38 */   private static final net.bytebuddy.utility.QueueFactory INSTANCE = new net.bytebuddy.utility.QueueFactory(); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*    */      }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   private final Dispatcher dispatcher = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*    */ 
/*    */ 
/*    */   
/*    */   private static final boolean ACCESS_CONTROLLER;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> Queue<T> make() {
/* 59 */     Queue<T> queue = INSTANCE.dispatcher.arrayDeque();
/* 60 */     return (queue == null) ? new LinkedList<>() : queue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> Queue<T> make(Collection<? extends T> elements) {
/* 73 */     Queue<T> queue = INSTANCE.dispatcher.arrayDeque(elements);
/* 74 */     return (queue == null) ? new LinkedList<>(elements) : queue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Enhance
/*    */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 88 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.dispatcher.equals(((net.bytebuddy.utility.QueueFactory)paramObject).dispatcher))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.dispatcher.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\QueueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */