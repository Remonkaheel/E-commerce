package META-INF.versions.9.net.bytebuddy.utility;

import net.bytebuddy.utility.ConstantValue;

public interface JavaConstant extends ConstantValue {
  Object toDescription();
  
  <T> T accept(Visitor<T> paramVisitor);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\JavaConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */