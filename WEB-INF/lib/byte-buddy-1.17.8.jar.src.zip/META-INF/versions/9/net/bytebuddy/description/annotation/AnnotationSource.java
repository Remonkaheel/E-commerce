package META-INF.versions.9.net.bytebuddy.description.annotation;

import net.bytebuddy.description.annotation.AnnotationList;

public interface AnnotationSource {
  AnnotationList getDeclaredAnnotations();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\annotation\AnnotationSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */