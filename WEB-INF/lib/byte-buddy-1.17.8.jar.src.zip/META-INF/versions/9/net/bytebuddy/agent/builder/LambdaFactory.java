/*     */ package META-INF.versions.9.net.bytebuddy.agent.builder;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.ClassFileLocator;
/*     */ import net.bytebuddy.dynamic.loading.ClassInjector;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class LambdaFactory
/*     */ {
/*     */   private static final String FIELD_NAME = "CLASS_FILE_TRANSFORMERS";
/*     */   @SuppressFBWarnings(value = {"MS_MUTABLE_COLLECTION_PKGPROTECT"}, justification = "The field must be accessible by different class loader instances.")
/*     */   public static final Map<ClassFileTransformer, net.bytebuddy.agent.builder.LambdaFactory> CLASS_FILE_TRANSFORMERS;
/*     */   private final Object target;
/*     */   private final Method dispatcher;
/*     */   
/*     */   public LambdaFactory(Object target, Method dispatcher) {
/*  70 */     this.target = target;
/*  71 */     this.dispatcher = dispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register(ClassFileTransformer classFileTransformer, Object classFileFactory) {
/*     */     try {
/*  92 */       TypeDescription typeDescription = TypeDescription.ForLoadedType.of(net.bytebuddy.agent.builder.LambdaFactory.class);
/*     */ 
/*     */       
/*  95 */       Class<?> lambdaFactory = (Class)ClassInjector.UsingReflection.ofSystemClassLoader().inject(Collections.singletonMap(typeDescription, ClassFileLocator.ForClassLoader.read(net.bytebuddy.agent.builder.LambdaFactory.class))).get(typeDescription);
/*     */ 
/*     */ 
/*     */       
/*  99 */       Map<ClassFileTransformer, Object> classFileTransformers = (Map<ClassFileTransformer, Object>)lambdaFactory.getField("CLASS_FILE_TRANSFORMERS").get(null);
/* 100 */       synchronized (classFileTransformers) {
/*     */         try {
/* 102 */           return classFileTransformers.isEmpty();
/*     */         } finally {
/* 104 */           classFileTransformers.put(classFileTransformer, lambdaFactory
/* 105 */               .getConstructor(new Class[] { Object.class, Method.class
/* 106 */                 }).newInstance(new Object[] { classFileFactory, classFileFactory.getClass().getMethod("make", new Class[] { Object.class, String.class, Object.class, Object.class, Object.class, Object.class, boolean.class, List.class, List.class, Collection.class }) }));
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 119 */     catch (RuntimeException exception) {
/* 120 */       throw exception;
/* 121 */     } catch (Exception exception) {
/* 122 */       throw new IllegalStateException("Could not register class file transformer", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean release(ClassFileTransformer classFileTransformer) {
/*     */     try {
/* 140 */       Map<ClassFileTransformer, ?> classFileTransformers = (Map<ClassFileTransformer, ?>)ClassLoader.getSystemClassLoader().loadClass(net.bytebuddy.agent.builder.LambdaFactory.class.getName()).getField("CLASS_FILE_TRANSFORMERS").get(null);
/* 141 */       synchronized (classFileTransformers) {
/* 142 */         return (classFileTransformers.remove(classFileTransformer) != null && classFileTransformers.isEmpty());
/*     */       } 
/* 144 */     } catch (RuntimeException exception) {
/* 145 */       throw exception;
/* 146 */     } catch (Exception exception) {
/* 147 */       throw new IllegalStateException("Could not release class file transformer", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] invoke(Object caller, String invokedName, Object invokedType, Object samMethodType, Object implMethod, Object instantiatedMethodType, boolean serializable, List<Class<?>> markerInterfaces, List<?> additionalBridges, Collection<ClassFileTransformer> classFileTransformers) {
/*     */     try {
/* 178 */       return (byte[])this.dispatcher.invoke(this.target, new Object[] { caller, invokedName, invokedType, samMethodType, implMethod, instantiatedMethodType, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 185 */             Boolean.valueOf(serializable), markerInterfaces, additionalBridges, classFileTransformers });
/*     */ 
/*     */     
/*     */     }
/* 189 */     catch (RuntimeException exception) {
/* 190 */       throw exception;
/* 191 */     } catch (Exception exception) {
/* 192 */       throw new IllegalStateException("Cannot create class for lambda expression", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] make(Object caller, String invokedName, Object invokedType, Object samMethodType, Object implMethod, Object instantiatedMethodType, boolean serializable, List<Class<?>> markerInterfaces, List<?> additionalBridges) {
/* 219 */     return ((net.bytebuddy.agent.builder.LambdaFactory)CLASS_FILE_TRANSFORMERS.values().iterator().next()).invoke(caller, invokedName, invokedType, samMethodType, implMethod, instantiatedMethodType, serializable, markerInterfaces, additionalBridges, CLASS_FILE_TRANSFORMERS
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 228 */         .keySet());
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.target.equals(((net.bytebuddy.agent.builder.LambdaFactory)paramObject).target) ? false : (!!this.dispatcher.equals(((net.bytebuddy.agent.builder.LambdaFactory)paramObject).dispatcher)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.dispatcher.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\agent\builder\LambdaFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */