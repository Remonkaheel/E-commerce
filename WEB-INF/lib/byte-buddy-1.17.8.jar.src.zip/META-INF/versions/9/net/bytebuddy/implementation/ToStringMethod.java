/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ToStringMethod
/*     */   implements Implementation
/*     */ {
/*     */   private static final MethodDescription.InDefinedShape STRING_BUILDER_CONSTRUCTOR;
/*     */   private static final MethodDescription.InDefinedShape TO_STRING;
/*     */   private final PrefixResolver prefixResolver;
/*     */   private final String start;
/*     */   private final String end;
/*     */   private final String separator;
/*     */   private final String definer;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> ignored;
/*     */   
/*     */   protected ToStringMethod(PrefixResolver prefixResolver) {
/* 102 */     this(prefixResolver, "{", "}", ", ", "=", ElementMatchers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ToStringMethod(PrefixResolver prefixResolver, String start, String end, String separator, String definer, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> ignored) {
/* 121 */     this.prefixResolver = prefixResolver;
/* 122 */     this.start = start;
/* 123 */     this.end = end;
/* 124 */     this.separator = separator;
/* 125 */     this.definer = definer;
/* 126 */     this.ignored = ignored;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.ToStringMethod prefixedByFullyQualifiedClassName() {
/* 135 */     return prefixedBy((PrefixResolver)PrefixResolver.Default.FULLY_QUALIFIED_CLASS_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.ToStringMethod prefixedByCanonicalClassName() {
/* 144 */     return prefixedBy((PrefixResolver)PrefixResolver.Default.CANONICAL_CLASS_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.ToStringMethod prefixedBySimpleClassName() {
/* 153 */     return prefixedBy((PrefixResolver)PrefixResolver.Default.SIMPLE_CLASS_NAME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.ToStringMethod prefixedBy(String prefix) {
/* 163 */     if (prefix == null) {
/* 164 */       throw new IllegalArgumentException("Prefix cannot be null");
/*     */     }
/* 166 */     return prefixedBy((PrefixResolver)new PrefixResolver.ForFixedValue(prefix));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.ToStringMethod prefixedBy(PrefixResolver prefixResolver) {
/* 176 */     return new net.bytebuddy.implementation.ToStringMethod(prefixResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.ToStringMethod withIgnoredFields(ElementMatcher<? super FieldDescription.InDefinedShape> ignored) {
/* 187 */     return new net.bytebuddy.implementation.ToStringMethod(this.prefixResolver, this.start, this.end, this.separator, this.definer, this.ignored.or(ignored));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation withTokens(String start, String end, String separator, String definer) {
/* 200 */     if (start == null || end == null || separator == null || definer == null) {
/* 201 */       throw new IllegalArgumentException("Token values cannot be null");
/*     */     }
/* 203 */     return new net.bytebuddy.implementation.ToStringMethod(this.prefixResolver, start, end, separator, definer, this.ignored);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 210 */     return instrumentedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Appender appender(Implementation.Target implementationTarget) {
/* 217 */     if (implementationTarget.getInstrumentedType().isInterface()) {
/* 218 */       throw new IllegalStateException("Cannot implement meaningful toString method for " + implementationTarget.getInstrumentedType());
/*     */     }
/* 220 */     String prefix = this.prefixResolver.resolve(implementationTarget.getInstrumentedType());
/* 221 */     if (prefix == null) {
/* 222 */       throw new IllegalStateException("Prefix for toString method cannot be null");
/*     */     }
/* 224 */     return new Appender(prefix, this.start, this.end, this.separator, this.definer, (List)implementationTarget
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         .getInstrumentedType().getDeclaredFields().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic().or((ElementMatcher)this.ignored))));
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.start.equals(((net.bytebuddy.implementation.ToStringMethod)paramObject).start) ? false : (!this.end.equals(((net.bytebuddy.implementation.ToStringMethod)paramObject).end) ? false : (!this.separator.equals(((net.bytebuddy.implementation.ToStringMethod)paramObject).separator) ? false : (!this.definer.equals(((net.bytebuddy.implementation.ToStringMethod)paramObject).definer) ? false : (!this.prefixResolver.equals(((net.bytebuddy.implementation.ToStringMethod)paramObject).prefixResolver) ? false : (!!this.ignored.equals(((net.bytebuddy.implementation.ToStringMethod)paramObject).ignored)))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (((((getClass().hashCode() * 31 + this.prefixResolver.hashCode()) * 31 + this.start.hashCode()) * 31 + this.end.hashCode()) * 31 + this.separator.hashCode()) * 31 + this.definer.hashCode()) * 31 + this.ignored.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\ToStringMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */