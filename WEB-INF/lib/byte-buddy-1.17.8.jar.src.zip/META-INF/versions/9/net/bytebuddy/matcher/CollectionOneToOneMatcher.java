/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class CollectionOneToOneMatcher<T>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<Iterable<? extends T>>
/*    */ {
/*    */   private final List<? extends ElementMatcher<? super T>> matchers;
/*    */   
/*    */   public CollectionOneToOneMatcher(List<? extends ElementMatcher<? super T>> matchers) {
/* 47 */     this.matchers = matchers;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(Iterable<? extends T> target) {
/* 54 */     if (target instanceof Collection && ((Collection)target).size() != this.matchers.size()) {
/* 55 */       return false;
/*    */     }
/* 57 */     Iterator<? extends ElementMatcher<? super T>> iterator = this.matchers.iterator();
/* 58 */     for (T value : target) {
/* 59 */       if (!iterator.hasNext() || !((ElementMatcher)iterator.next()).matches(value)) {
/* 60 */         return false;
/*    */       }
/*    */     } 
/* 63 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     StringBuilder stringBuilder = new StringBuilder("containing(");
/* 69 */     boolean first = true;
/* 70 */     for (Object<? super T> value : this.matchers) {
/* 71 */       if (first) {
/* 72 */         first = false;
/*    */       } else {
/* 74 */         stringBuilder.append(", ");
/*    */       } 
/* 76 */       stringBuilder.append(value);
/*    */     } 
/* 78 */     return stringBuilder.append(')').toString();
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.matchers.equals(((net.bytebuddy.matcher.CollectionOneToOneMatcher)paramObject).matchers)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return super.hashCode() * 31 + this.matchers.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\CollectionOneToOneMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */