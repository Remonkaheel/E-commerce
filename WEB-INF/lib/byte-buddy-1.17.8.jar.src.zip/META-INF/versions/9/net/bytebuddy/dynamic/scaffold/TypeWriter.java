package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.dynamic.TypeResolutionStrategy;
import net.bytebuddy.jar.asm.ClassVisitor;
import net.bytebuddy.utility.visitor.ContextClassVisitor;

public interface TypeWriter<T> {
  public static final String DUMP_PROPERTY = "net.bytebuddy.dump";
  
  DynamicType.Unloaded<T> make(TypeResolutionStrategy.Resolved paramResolved);
  
  ContextClassVisitor wrap(ClassVisitor paramClassVisitor, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\TypeWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */