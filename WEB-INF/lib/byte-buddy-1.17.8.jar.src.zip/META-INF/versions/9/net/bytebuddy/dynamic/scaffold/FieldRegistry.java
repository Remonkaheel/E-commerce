package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.Transformer;
import net.bytebuddy.implementation.attribute.FieldAttributeAppender;
import net.bytebuddy.matcher.LatentMatcher;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface FieldRegistry {
  net.bytebuddy.dynamic.scaffold.FieldRegistry prepend(LatentMatcher<? super FieldDescription> paramLatentMatcher, FieldAttributeAppender.Factory paramFactory, @MaybeNull Object paramObject, Transformer<FieldDescription> paramTransformer);
  
  Compiled compile(TypeDescription paramTypeDescription);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\FieldRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */