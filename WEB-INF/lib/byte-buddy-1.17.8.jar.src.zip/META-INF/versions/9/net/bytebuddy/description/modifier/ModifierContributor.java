package META-INF.versions.9.net.bytebuddy.description.modifier;

public interface ModifierContributor {
  public static final int EMPTY_MASK = 0;
  
  int getMask();
  
  int getRange();
  
  boolean isDefault();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\modifier\ModifierContributor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */