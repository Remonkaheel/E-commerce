/*     */ package META-INF.versions.9.net.bytebuddy.utility;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompoundList
/*     */ {
/*     */   private CompoundList() {
/*  31 */     throw new UnsupportedOperationException("This class is a utility class and not supposed to be instantiated");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> List<S> of(S left, List<? extends S> right) {
/*  43 */     if (right.isEmpty()) {
/*  44 */       return Collections.singletonList(left);
/*     */     }
/*  46 */     List<S> list = new ArrayList<>(1 + right.size());
/*  47 */     list.add(left);
/*  48 */     list.addAll(right);
/*  49 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> List<S> of(List<? extends S> left, S right) {
/*  62 */     if (left.isEmpty()) {
/*  63 */       return Collections.singletonList(right);
/*     */     }
/*  65 */     List<S> list = new ArrayList<>(left.size() + 1);
/*  66 */     list.addAll(left);
/*  67 */     list.add(right);
/*  68 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> List<S> of(List<? extends S> left, List<? extends S> right) {
/*  81 */     List<S> list = new ArrayList<>(left.size() + right.size());
/*  82 */     list.addAll(left);
/*  83 */     list.addAll(right);
/*  84 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S> List<S> of(List<? extends S> left, List<? extends S> middle, List<? extends S> right) {
/*  98 */     List<S> list = new ArrayList<>(left.size() + middle.size() + right.size());
/*  99 */     list.addAll(left);
/* 100 */     list.addAll(middle);
/* 101 */     list.addAll(right);
/* 102 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\CompoundList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */