/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*    */ 
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.StackSize;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DoubleConstant
/*    */   implements StackManipulation
/*    */ {
/* 33 */   ZERO(14),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   ONE(15);
/*    */   private static final StackManipulation.Size SIZE;
/*    */   private final int opcode;
/*    */   
/*    */   static {
/* 43 */     SIZE = StackSize.DOUBLE.toIncreasingSize();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DoubleConstant(int opcode) {
/* 56 */     this.opcode = opcode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StackManipulation forValue(double value) {
/* 68 */     if (value == 0.0D)
/* 69 */       return ZERO; 
/* 70 */     if (value == 1.0D) {
/* 71 */       return ONE;
/*    */     }
/* 73 */     return (StackManipulation)new ConstantPool(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 81 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 88 */     methodVisitor.visitInsn(this.opcode);
/* 89 */     return SIZE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\DoubleConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */