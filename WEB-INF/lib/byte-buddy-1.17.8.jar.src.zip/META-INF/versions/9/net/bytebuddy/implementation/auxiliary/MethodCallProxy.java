/*     */ package META-INF.versions.9.net.bytebuddy.implementation.auxiliary;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import net.bytebuddy.ByteBuddy;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.modifier.Visibility;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.DynamicType;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*     */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.MethodAccessorFactory;
/*     */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.utility.RandomString;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MethodCallProxy
/*     */   implements AuxiliaryType
/*     */ {
/*     */   private static final String FIELD_NAME_PREFIX = "argument";
/*     */   private final Implementation.SpecialMethodInvocation specialMethodInvocation;
/*     */   private final boolean serializableProxy;
/*     */   private final Assigner assigner;
/*     */   
/*     */   public MethodCallProxy(Implementation.SpecialMethodInvocation specialMethodInvocation, boolean serializableProxy) {
/* 101 */     this(specialMethodInvocation, serializableProxy, Assigner.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodCallProxy(Implementation.SpecialMethodInvocation specialMethodInvocation, boolean serializableProxy, Assigner assigner) {
/* 114 */     this.specialMethodInvocation = specialMethodInvocation;
/* 115 */     this.serializableProxy = serializableProxy;
/* 116 */     this.assigner = assigner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static LinkedHashMap<String, TypeDescription> extractFields(MethodDescription methodDescription) {
/* 127 */     LinkedHashMap<String, TypeDescription> typeDescriptions = new LinkedHashMap<>();
/* 128 */     int currentIndex = 0;
/* 129 */     if (!methodDescription.isStatic()) {
/* 130 */       typeDescriptions.put(fieldName(currentIndex++), methodDescription.getDeclaringType().asErasure());
/*     */     }
/* 132 */     for (ParameterDescription parameterDescription : methodDescription.getParameters()) {
/* 133 */       typeDescriptions.put(fieldName(currentIndex++), parameterDescription.getType().asErasure());
/*     */     }
/* 135 */     return typeDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String fieldName(int index) {
/* 145 */     return "argument" + index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuffix() {
/* 152 */     return RandomString.hashOf(this.specialMethodInvocation.getMethodDescription().hashCode()) + (this.serializableProxy ? "S" : "0");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicType make(String auxiliaryTypeName, ClassFileVersion classFileVersion, MethodAccessorFactory methodAccessorFactory) {
/*     */     DynamicType.Builder.FieldDefinition.Optional.Valuable valuable;
/* 161 */     MethodDescription.InDefinedShape inDefinedShape = methodAccessorFactory.registerAccessorFor(this.specialMethodInvocation, MethodAccessorFactory.AccessType.DEFAULT);
/* 162 */     LinkedHashMap<String, TypeDescription> parameterFields = extractFields((MethodDescription)inDefinedShape);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     (new Class[1])[0] = Serializable.class;
/*     */ 
/*     */     
/* 172 */     DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition = (new ByteBuddy(classFileVersion)).with(TypeValidation.DISABLED).with((MethodGraph.Compiler)PrecomputedMethodGraph.INSTANCE).subclass(Object.class, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).name(auxiliaryTypeName).modifiers(DEFAULT_TYPE_MODIFIER).implement(new Type[] { Runnable.class, Callable.class }).intercept((Implementation)new MethodCall((MethodDescription)inDefinedShape, this.assigner)).implement(this.serializableProxy ? (Type[])new Class[1] : (Type[])new Class[0]).defineConstructor(new ModifierContributor.ForMethod[0]).withParameters(parameterFields.values()).intercept((Implementation)ConstructorCall.INSTANCE);
/* 173 */     for (Map.Entry<String, TypeDescription> field : parameterFields.entrySet()) {
/* 174 */       valuable = receiverTypeDefinition.defineField(field.getKey(), (TypeDefinition)field.getValue(), new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE });
/*     */     } 
/* 176 */     return (DynamicType)valuable.make();
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.serializableProxy != ((net.bytebuddy.implementation.auxiliary.MethodCallProxy)paramObject).serializableProxy) ? false : (!this.specialMethodInvocation.equals(((net.bytebuddy.implementation.auxiliary.MethodCallProxy)paramObject).specialMethodInvocation) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.auxiliary.MethodCallProxy)paramObject).assigner))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((getClass().hashCode() * 31 + this.specialMethodInvocation.hashCode()) * 31 + this.serializableProxy) * 31 + this.assigner.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\auxiliary\MethodCallProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */