package META-INF.versions.9.net.bytebuddy.implementation.attribute;

import net.bytebuddy.description.type.RecordComponentDescription;
import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
import net.bytebuddy.jar.asm.RecordComponentVisitor;

public interface RecordComponentAttributeAppender {
  void apply(RecordComponentVisitor paramRecordComponentVisitor, RecordComponentDescription paramRecordComponentDescription, AnnotationValueFilter paramAnnotationValueFilter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\RecordComponentAttributeAppender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */