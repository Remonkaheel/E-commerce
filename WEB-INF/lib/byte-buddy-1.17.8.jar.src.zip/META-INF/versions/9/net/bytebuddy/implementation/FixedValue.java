/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodReturn;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.utility.ConstantValue;
/*     */ import net.bytebuddy.utility.JavaConstant;
/*     */ import net.bytebuddy.utility.RandomString;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public abstract class FixedValue
/*     */   implements Implementation
/*     */ {
/*     */   protected final Assigner assigner;
/*     */   protected final Assigner.Typing typing;
/*     */   
/*     */   protected FixedValue(Assigner assigner, Assigner.Typing typing) {
/*  66 */     this.assigner = assigner;
/*  67 */     this.typing = typing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable value(Object value) {
/*  93 */     ConstantValue constant = ConstantValue.Simple.wrapOrNull(value);
/*  94 */     return (constant == null) ? 
/*  95 */       reference(value) : (AssignerConfigurable)new ForConstantValue(constant
/*  96 */         .toStackManipulation(), constant.getTypeDescription());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable reference(Object value) {
/* 110 */     return reference(value, "value$" + RandomString.hashOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable reference(Object value, String name) {
/* 124 */     return (AssignerConfigurable)new ForValue(value, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable value(TypeDescription type) {
/* 134 */     return (AssignerConfigurable)new ForConstantValue(ClassConstant.of(type), TypeDescription.ForLoadedType.of(Class.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable value(ConstantValue constant) {
/* 144 */     return (AssignerConfigurable)new ForConstantValue(constant.toStackManipulation(), constant.getTypeDescription());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable value(JavaConstant constant) {
/* 154 */     return value((ConstantValue)constant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable argument(int index) {
/* 164 */     if (index < 0) {
/* 165 */       throw new IllegalArgumentException("Argument index cannot be negative: " + index);
/*     */     }
/* 167 */     return (AssignerConfigurable)new ForArgument(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable self() {
/* 176 */     return (AssignerConfigurable)new ForThisValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation nullValue() {
/* 185 */     return (Implementation)ForNullValue.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AssignerConfigurable originType() {
/* 194 */     return (AssignerConfigurable)new ForOriginType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod, TypeDescription.Generic typeDescription, StackManipulation stackManipulation) {
/* 214 */     StackManipulation assignment = this.assigner.assign(typeDescription, instrumentedMethod.getReturnType(), this.typing);
/* 215 */     if (!assignment.isValid()) {
/* 216 */       throw new IllegalArgumentException("Cannot return value of type " + typeDescription + " for " + instrumentedMethod);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     StackManipulation.Size stackSize = (new StackManipulation.Compound(new StackManipulation[] { stackManipulation, assignment, MethodReturn.of((TypeDefinition)instrumentedMethod.getReturnType()) })).apply(methodVisitor, implementationContext);
/* 223 */     return new ByteCodeAppender.Size(stackSize.getMaximalSize(), instrumentedMethod.getStackSize());
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.typing.equals(((net.bytebuddy.implementation.FixedValue)paramObject).typing) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.FixedValue)paramObject).assigner)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\FixedValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */