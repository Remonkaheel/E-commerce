package META-INF.versions.9.net.bytebuddy.description.enumeration;

import net.bytebuddy.description.NamedElement;
import net.bytebuddy.description.type.TypeDescription;

public interface EnumerationDescription extends NamedElement {
  String getValue();
  
  TypeDescription getEnumerationType();
  
  <T extends Enum<T>> T load(Class<T> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\enumeration\EnumerationDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */