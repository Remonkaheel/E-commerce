/*    */ package META-INF.versions.9.net.bytebuddy.utility.privilege;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.Arrays;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class GetMethodAction
/*    */   implements PrivilegedAction<Method>
/*    */ {
/*    */   private final String type;
/*    */   private final String name;
/*    */   private final Class<?>[] parameter;
/*    */   
/*    */   public GetMethodAction(String type, String name, Class<?>... parameter) {
/* 55 */     this.type = type;
/* 56 */     this.name = name;
/* 57 */     this.parameter = parameter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @MaybeNull
/*    */   @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*    */   public Method run() {
/*    */     try {
/* 67 */       return Class.forName(this.type).getMethod(this.name, this.parameter);
/* 68 */     } catch (Exception ignored) {
/* 69 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.type.equals(((net.bytebuddy.utility.privilege.GetMethodAction)paramObject).type) ? false : (!this.name.equals(((net.bytebuddy.utility.privilege.GetMethodAction)paramObject).name) ? false : (!!Arrays.equals((Object[])this.parameter, (Object[])((net.bytebuddy.utility.privilege.GetMethodAction)paramObject).parameter))))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return ((getClass().hashCode() * 31 + this.type.hashCode()) * 31 + this.name.hashCode()) * 31 + Arrays.hashCode((Object[])this.parameter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\privilege\GetMethodAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */