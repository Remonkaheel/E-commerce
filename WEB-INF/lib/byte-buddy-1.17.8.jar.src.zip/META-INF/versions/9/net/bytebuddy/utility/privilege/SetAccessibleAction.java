/*    */ package META-INF.versions.9.net.bytebuddy.utility.privilege;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.security.PrivilegedAction;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class SetAccessibleAction<T extends AccessibleObject>
/*    */   implements PrivilegedAction<T>
/*    */ {
/*    */   private final T accessibleObject;
/*    */   
/*    */   public SetAccessibleAction(T accessibleObject) {
/* 42 */     this.accessibleObject = accessibleObject;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T run() {
/* 49 */     this.accessibleObject.setAccessible(true);
/* 50 */     return this.accessibleObject;
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.accessibleObject.equals(((net.bytebuddy.utility.privilege.SetAccessibleAction)paramObject).accessibleObject))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.accessibleObject.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\privilege\SetAccessibleAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */