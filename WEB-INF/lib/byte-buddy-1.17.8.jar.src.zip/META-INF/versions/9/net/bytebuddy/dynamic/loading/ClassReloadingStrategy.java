/*     */ package META-INF.versions.9.net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.instrument.ClassDefinition;
/*     */ import java.lang.instrument.Instrumentation;
/*     */ import java.lang.instrument.UnmodifiableClassException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.bytebuddy.agent.builder.AgentBuilder;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.ClassFileLocator;
/*     */ import net.bytebuddy.dynamic.loading.ClassInjector;
/*     */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*     */ import net.bytebuddy.utility.JavaModule;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ClassReloadingStrategy
/*     */   implements ClassLoadingStrategy<ClassLoader>
/*     */ {
/*  59 */   protected static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Instrumentation instrumentation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Strategy strategy;
/*     */ 
/*     */ 
/*     */   
/*     */   private final BootstrapInjection bootstrapInjection;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, Class<?>> preregisteredTypes;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassReloadingStrategy(Instrumentation instrumentation, Strategy strategy) {
/*  90 */     this(instrumentation, strategy, (BootstrapInjection)BootstrapInjection.Disabled.INSTANCE, 
/*     */ 
/*     */         
/*  93 */         Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassReloadingStrategy(Instrumentation instrumentation, Strategy strategy, BootstrapInjection bootstrapInjection, Map<String, Class<?>> preregisteredTypes) {
/* 108 */     this.instrumentation = instrumentation;
/* 109 */     this.strategy = strategy.validate(instrumentation);
/* 110 */     this.bootstrapInjection = bootstrapInjection;
/* 111 */     this.preregisteredTypes = preregisteredTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 123 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.dynamic.loading.ClassReloadingStrategy of(Instrumentation instrumentation) {
/* 136 */     if (DISPATCHER.isRetransformClassesSupported(instrumentation))
/* 137 */       return new net.bytebuddy.dynamic.loading.ClassReloadingStrategy(instrumentation, Strategy.RETRANSFORMATION); 
/* 138 */     if (instrumentation.isRedefineClassesSupported()) {
/* 139 */       return new net.bytebuddy.dynamic.loading.ClassReloadingStrategy(instrumentation, Strategy.REDEFINITION);
/*     */     }
/* 141 */     throw new IllegalArgumentException("Instrumentation does not support reloading of classes: " + instrumentation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Instrumentation resolveByteBuddyAgentInstrumentation() {
/*     */     try {
/* 152 */       Class<?> installer = ClassLoader.getSystemClassLoader().loadClass("net.bytebuddy.agent.Installer");
/* 153 */       JavaModule source = JavaModule.ofType(AgentBuilder.class), target = JavaModule.ofType(installer);
/* 154 */       if (source != null && !source.canRead(target)) {
/* 155 */         Class<?> module = Class.forName("java.lang.Module");
/* 156 */         module.getMethod("addReads", new Class[] { module }).invoke(source.unwrap(), new Object[] { target.unwrap() });
/*     */       } 
/* 158 */       return (Instrumentation)installer.getMethod("getInstrumentation", new Class[0]).invoke(null, new Object[0]);
/* 159 */     } catch (RuntimeException exception) {
/* 160 */       throw exception;
/* 161 */     } catch (Exception exception) {
/* 162 */       throw new IllegalStateException("The Byte Buddy agent is not installed or not accessible", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.dynamic.loading.ClassReloadingStrategy fromInstalledAgent() {
/* 183 */     return of(resolveByteBuddyAgentInstrumentation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.dynamic.loading.ClassReloadingStrategy fromInstalledAgent(Strategy strategy) {
/* 203 */     return new net.bytebuddy.dynamic.loading.ClassReloadingStrategy(resolveByteBuddyAgentInstrumentation(), strategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 210 */     Map<String, Class<?>> availableTypes = new HashMap<>(this.preregisteredTypes);
/* 211 */     for (Class<?> type : this.instrumentation.getInitiatedClasses(classLoader)) {
/* 212 */       availableTypes.put(TypeDescription.ForLoadedType.getName(type), type);
/*     */     }
/* 214 */     Map<Class<?>, ClassDefinition> classDefinitions = new ConcurrentHashMap<>();
/* 215 */     Map<TypeDescription, Class<?>> loadedClasses = new HashMap<>();
/* 216 */     Map<TypeDescription, byte[]> unloadedClasses = (Map)new LinkedHashMap<>();
/* 217 */     for (Map.Entry<TypeDescription, byte[]> entry : types.entrySet()) {
/* 218 */       Class<?> type = availableTypes.get(((TypeDescription)entry.getKey()).getName());
/* 219 */       if (type != null) {
/* 220 */         classDefinitions.put(type, new ClassDefinition(type, entry.getValue()));
/* 221 */         loadedClasses.put(entry.getKey(), type); continue;
/*     */       } 
/* 223 */       unloadedClasses.put(entry.getKey(), entry.getValue());
/*     */     } 
/*     */     
/*     */     try {
/* 227 */       this.strategy.apply(this.instrumentation, classDefinitions);
/* 228 */       if (!unloadedClasses.isEmpty()) {
/* 229 */         loadedClasses.putAll(((classLoader == null) ? this.bootstrapInjection
/* 230 */             .make(this.instrumentation) : new ClassInjector.UsingReflection(classLoader))
/* 231 */             .inject(unloadedClasses));
/*     */       }
/* 233 */     } catch (ClassNotFoundException exception) {
/* 234 */       throw new IllegalArgumentException("Could not locate classes for redefinition", exception);
/* 235 */     } catch (UnmodifiableClassException exception) {
/* 236 */       throw new IllegalStateException("Cannot redefine specified class", exception);
/*     */     } 
/* 238 */     return loadedClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.dynamic.loading.ClassReloadingStrategy reset(Class<?>... type) throws IOException {
/* 249 */     return (type.length == 0) ? this : 
/*     */       
/* 251 */       reset(ClassFileLocator.ForClassLoader.of(type[0].getClassLoader()), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.dynamic.loading.ClassReloadingStrategy reset(ClassFileLocator classFileLocator, Class<?>... type) throws IOException {
/* 263 */     if (type.length > 0) {
/*     */       try {
/* 265 */         this.strategy.reset(this.instrumentation, classFileLocator, Arrays.asList(type));
/* 266 */       } catch (ClassNotFoundException exception) {
/* 267 */         throw new IllegalArgumentException("Cannot locate types " + Arrays.toString(type), exception);
/* 268 */       } catch (UnmodifiableClassException exception) {
/* 269 */         throw new IllegalStateException("Cannot reset types " + Arrays.toString(type), exception);
/*     */       } 
/*     */     }
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.dynamic.loading.ClassReloadingStrategy enableBootstrapInjection(File folder) {
/* 282 */     return new net.bytebuddy.dynamic.loading.ClassReloadingStrategy(this.instrumentation, this.strategy, (BootstrapInjection)new BootstrapInjection.Enabled(folder), this.preregisteredTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.dynamic.loading.ClassReloadingStrategy preregistered(Class<?>... type) {
/* 292 */     Map<String, Class<?>> preregisteredTypes = new HashMap<>(this.preregisteredTypes);
/* 293 */     for (Class<?> aType : type) {
/* 294 */       preregisteredTypes.put(TypeDescription.ForLoadedType.getName(aType), aType);
/*     */     }
/* 296 */     return new net.bytebuddy.dynamic.loading.ClassReloadingStrategy(this.instrumentation, this.strategy, this.bootstrapInjection, preregisteredTypes);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.strategy.equals(((net.bytebuddy.dynamic.loading.ClassReloadingStrategy)paramObject).strategy) ? false : (!this.instrumentation.equals(((net.bytebuddy.dynamic.loading.ClassReloadingStrategy)paramObject).instrumentation) ? false : (!this.bootstrapInjection.equals(((net.bytebuddy.dynamic.loading.ClassReloadingStrategy)paramObject).bootstrapInjection) ? false : (!!this.preregisteredTypes.equals(((net.bytebuddy.dynamic.loading.ClassReloadingStrategy)paramObject).preregisteredTypes)))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (((getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.strategy.hashCode()) * 31 + this.bootstrapInjection.hashCode()) * 31 + this.preregisteredTypes.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\ClassReloadingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */