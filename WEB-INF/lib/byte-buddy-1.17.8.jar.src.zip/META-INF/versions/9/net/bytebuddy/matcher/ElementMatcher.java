package META-INF.versions.9.net.bytebuddy.matcher;

import net.bytebuddy.utility.nullability.UnknownNull;

public interface ElementMatcher<T> {
  boolean matches(@UnknownNull T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\ElementMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */