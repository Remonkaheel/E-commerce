/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.reference;
/*    */ 
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*    */ import net.bytebuddy.implementation.bytecode.assign.TypeCasting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ReferenceTypeAwareAssigner
/*    */   implements Assigner
/*    */ {
/* 32 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation assign(TypeDescription.Generic source, TypeDescription.Generic target, Assigner.Typing typing) {
/* 38 */     if (source.isPrimitive() || target.isPrimitive()) {
/* 39 */       return source.equals(target) ? (StackManipulation)StackManipulation.Trivial.INSTANCE : (StackManipulation)StackManipulation.Illegal.INSTANCE;
/*    */     }
/*    */     
/* 42 */     if (source.asErasure().isAssignableTo(target.asErasure()))
/* 43 */       return (StackManipulation)StackManipulation.Trivial.INSTANCE; 
/* 44 */     if (typing.isDynamic()) {
/* 45 */       return TypeCasting.to((TypeDefinition)target);
/*    */     }
/* 47 */     return (StackManipulation)StackManipulation.Illegal.INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\reference\ReferenceTypeAwareAssigner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */