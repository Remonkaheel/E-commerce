package META-INF.versions.9.net.bytebuddy.description.method;

import java.util.List;
import net.bytebuddy.description.ByteCodeElement;
import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.description.method.MethodList;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.FilterableList;

public interface MethodList<T extends MethodDescription> extends FilterableList<T, MethodList<T>> {
  ByteCodeElement.Token.TokenList<MethodDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
  
  List<MethodDescription.SignatureToken> asSignatureTokenList();
  
  List<MethodDescription.SignatureToken> asSignatureTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher, TypeDescription paramTypeDescription);
  
  MethodList<MethodDescription.InDefinedShape> asDefined();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\method\MethodList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */