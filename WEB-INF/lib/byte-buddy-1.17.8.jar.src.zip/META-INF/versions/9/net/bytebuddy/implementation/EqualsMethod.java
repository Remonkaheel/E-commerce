/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class EqualsMethod
/*     */   implements Implementation
/*     */ {
/*     */   private static final MethodDescription.InDefinedShape EQUALS;
/*     */   private final SuperClassCheck superClassCheck;
/*     */   private final TypeCompatibilityCheck typeCompatibilityCheck;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> ignored;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> nonNullable;
/*     */   private final ElementMatcher.Junction<? super FieldDescription.InDefinedShape> identity;
/*     */   private final Comparator<? super FieldDescription.InDefinedShape> comparator;
/*     */   
/*     */   protected EqualsMethod(SuperClassCheck superClassCheck) {
/*  98 */     this(superClassCheck, TypeCompatibilityCheck.EXACT, ElementMatchers.none(), ElementMatchers.none(), ElementMatchers.none(), (Comparator<? super FieldDescription.InDefinedShape>)NaturalOrderComparator.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EqualsMethod(SuperClassCheck superClassCheck, TypeCompatibilityCheck typeCompatibilityCheck, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> ignored, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> nonNullable, ElementMatcher.Junction<? super FieldDescription.InDefinedShape> identity, Comparator<? super FieldDescription.InDefinedShape> comparator) {
/* 117 */     this.superClassCheck = superClassCheck;
/* 118 */     this.typeCompatibilityCheck = typeCompatibilityCheck;
/* 119 */     this.ignored = ignored;
/* 120 */     this.nonNullable = nonNullable;
/* 121 */     this.identity = identity;
/* 122 */     this.comparator = comparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.EqualsMethod requiringSuperClassEquality() {
/* 131 */     return new net.bytebuddy.implementation.EqualsMethod(SuperClassCheck.ENABLED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.EqualsMethod isolated() {
/* 140 */     return new net.bytebuddy.implementation.EqualsMethod(SuperClassCheck.DISABLED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withIgnoredFields(ElementMatcher<? super FieldDescription.InDefinedShape> ignored) {
/* 151 */     return new net.bytebuddy.implementation.EqualsMethod(this.superClassCheck, this.typeCompatibilityCheck, this.ignored.or(ignored), this.nonNullable, this.identity, this.comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withNonNullableFields(ElementMatcher<? super FieldDescription.InDefinedShape> nonNullable) {
/* 163 */     return new net.bytebuddy.implementation.EqualsMethod(this.superClassCheck, this.typeCompatibilityCheck, this.ignored, this.nonNullable.or(nonNullable), this.identity, this.comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withIdentityFields(ElementMatcher<? super FieldDescription.InDefinedShape> identity) {
/* 173 */     return new net.bytebuddy.implementation.EqualsMethod(this.superClassCheck, this.typeCompatibilityCheck, this.ignored, this.nonNullable, this.identity.or(identity), this.comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withPrimitiveTypedFieldsFirst() {
/* 182 */     return withFieldOrder((Comparator<? super FieldDescription.InDefinedShape>)TypePropertyComparator.FOR_PRIMITIVE_TYPES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withEnumerationTypedFieldsFirst() {
/* 191 */     return withFieldOrder((Comparator<? super FieldDescription.InDefinedShape>)TypePropertyComparator.FOR_ENUMERATION_TYPES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withPrimitiveWrapperTypedFieldsFirst() {
/* 200 */     return withFieldOrder((Comparator<? super FieldDescription.InDefinedShape>)TypePropertyComparator.FOR_PRIMITIVE_WRAPPER_TYPES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withStringTypedFieldsFirst() {
/* 209 */     return withFieldOrder((Comparator<? super FieldDescription.InDefinedShape>)TypePropertyComparator.FOR_STRING_TYPES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withFieldOrder(Comparator<? super FieldDescription.InDefinedShape> comparator) {
/* 221 */     return new net.bytebuddy.implementation.EqualsMethod(this.superClassCheck, this.typeCompatibilityCheck, this.ignored, this.nonNullable, this.identity, (Comparator<? super FieldDescription.InDefinedShape>)new CompoundComparator(new Comparator[] { this.comparator, comparator }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.EqualsMethod withSubclassEquality() {
/* 232 */     return new net.bytebuddy.implementation.EqualsMethod(this.superClassCheck, TypeCompatibilityCheck.SUBCLASS, this.ignored, this.nonNullable, this.identity, this.comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 239 */     return instrumentedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 246 */     if (implementationTarget.getInstrumentedType().isInterface()) {
/* 247 */       throw new IllegalStateException("Cannot implement meaningful equals method for " + implementationTarget.getInstrumentedType());
/*     */     }
/*     */ 
/*     */     
/* 251 */     List<FieldDescription.InDefinedShape> fields = new ArrayList<>((Collection<? extends FieldDescription.InDefinedShape>)implementationTarget.getInstrumentedType().getDeclaredFields().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic().or((ElementMatcher)this.ignored))));
/* 252 */     Collections.sort(fields, this.comparator);
/* 253 */     return (ByteCodeAppender)new Appender(implementationTarget.getInstrumentedType(), (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.superClassCheck
/* 254 */             .resolve(implementationTarget.getInstrumentedType()), 
/* 255 */             MethodVariableAccess.loadThis(), MethodVariableAccess.REFERENCE
/* 256 */             .loadFrom(1), 
/* 257 */             ConditionalReturn.onIdentity().returningTrue(), this.typeCompatibilityCheck
/* 258 */             .resolve(implementationTarget.getInstrumentedType()) }, ), fields, (ElementMatcher)this.nonNullable, (ElementMatcher)this.identity);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.superClassCheck.equals(((net.bytebuddy.implementation.EqualsMethod)paramObject).superClassCheck) ? false : (!this.typeCompatibilityCheck.equals(((net.bytebuddy.implementation.EqualsMethod)paramObject).typeCompatibilityCheck) ? false : (!this.ignored.equals(((net.bytebuddy.implementation.EqualsMethod)paramObject).ignored) ? false : (!this.nonNullable.equals(((net.bytebuddy.implementation.EqualsMethod)paramObject).nonNullable) ? false : (!this.identity.equals(((net.bytebuddy.implementation.EqualsMethod)paramObject).identity) ? false : (!!this.comparator.equals(((net.bytebuddy.implementation.EqualsMethod)paramObject).comparator)))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (((((getClass().hashCode() * 31 + this.superClassCheck.hashCode()) * 31 + this.typeCompatibilityCheck.hashCode()) * 31 + this.ignored.hashCode()) * 31 + this.nonNullable.hashCode()) * 31 + this.identity.hashCode()) * 31 + this.comparator.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\EqualsMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */