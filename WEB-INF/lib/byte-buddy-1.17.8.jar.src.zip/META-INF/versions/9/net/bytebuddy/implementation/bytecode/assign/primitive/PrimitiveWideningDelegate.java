/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PrimitiveWideningDelegate
/*     */ {
/*  35 */   BOOLEAN((StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   BYTE((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new WideningStackManipulation(133, StackSize.SINGLE
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  52 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(134, StackSize.ZERO
/*  53 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(133, StackSize.SINGLE
/*  54 */       .toIncreasingSize())),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   SHORT((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new WideningStackManipulation(133, StackSize.SINGLE
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  64 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(134, StackSize.ZERO
/*  65 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(135, StackSize.SINGLE
/*  66 */       .toIncreasingSize())),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   CHARACTER((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new WideningStackManipulation(133, StackSize.SINGLE
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(134, StackSize.ZERO
/*  77 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(135, StackSize.SINGLE
/*  78 */       .toIncreasingSize())),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   INTEGER((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new WideningStackManipulation(133, StackSize.SINGLE
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  88 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(134, StackSize.ZERO
/*  89 */       .toIncreasingSize()), (StackManipulation)new WideningStackManipulation(135, StackSize.SINGLE
/*  90 */       .toIncreasingSize())),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   LONG((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new WideningStackManipulation(137, StackSize.SINGLE
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       .toDecreasingSize()), (StackManipulation)new WideningStackManipulation(138, StackSize.ZERO
/* 102 */       .toIncreasingSize())),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   FLOAT((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new WideningStackManipulation(141, StackSize.SINGLE
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       .toIncreasingSize())),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   DOUBLE((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toBooleanStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toByteStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toShortStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toCharacterStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toIntegerStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toLongStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toFloatStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toDoubleStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrimitiveWideningDelegate(StackManipulation toBooleanStackManipulation, StackManipulation toByteStackManipulation, StackManipulation toShortStackManipulation, StackManipulation toCharacterStackManipulation, StackManipulation toIntegerStackManipulation, StackManipulation toLongStackManipulation, StackManipulation toFloatStackManipulation, StackManipulation toDoubleStackManipulation) {
/* 196 */     this.toBooleanStackManipulation = toBooleanStackManipulation;
/* 197 */     this.toByteStackManipulation = toByteStackManipulation;
/* 198 */     this.toShortStackManipulation = toShortStackManipulation;
/* 199 */     this.toCharacterStackManipulation = toCharacterStackManipulation;
/* 200 */     this.toIntegerStackManipulation = toIntegerStackManipulation;
/* 201 */     this.toLongStackManipulation = toLongStackManipulation;
/* 202 */     this.toFloatStackManipulation = toFloatStackManipulation;
/* 203 */     this.toDoubleStackManipulation = toDoubleStackManipulation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveWideningDelegate forPrimitive(TypeDefinition typeDefinition) {
/* 213 */     if (typeDefinition.represents(boolean.class))
/* 214 */       return BOOLEAN; 
/* 215 */     if (typeDefinition.represents(byte.class))
/* 216 */       return BYTE; 
/* 217 */     if (typeDefinition.represents(short.class))
/* 218 */       return SHORT; 
/* 219 */     if (typeDefinition.represents(char.class))
/* 220 */       return CHARACTER; 
/* 221 */     if (typeDefinition.represents(int.class))
/* 222 */       return INTEGER; 
/* 223 */     if (typeDefinition.represents(long.class))
/* 224 */       return LONG; 
/* 225 */     if (typeDefinition.represents(float.class))
/* 226 */       return FLOAT; 
/* 227 */     if (typeDefinition.represents(double.class)) {
/* 228 */       return DOUBLE;
/*     */     }
/* 230 */     throw new IllegalArgumentException("Not a primitive, non-void type: " + typeDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation widenTo(TypeDefinition typeDefinition) {
/* 241 */     if (typeDefinition.represents(boolean.class))
/* 242 */       return this.toBooleanStackManipulation; 
/* 243 */     if (typeDefinition.represents(byte.class))
/* 244 */       return this.toByteStackManipulation; 
/* 245 */     if (typeDefinition.represents(short.class))
/* 246 */       return this.toShortStackManipulation; 
/* 247 */     if (typeDefinition.represents(char.class))
/* 248 */       return this.toCharacterStackManipulation; 
/* 249 */     if (typeDefinition.represents(int.class))
/* 250 */       return this.toIntegerStackManipulation; 
/* 251 */     if (typeDefinition.represents(long.class))
/* 252 */       return this.toLongStackManipulation; 
/* 253 */     if (typeDefinition.represents(float.class))
/* 254 */       return this.toFloatStackManipulation; 
/* 255 */     if (typeDefinition.represents(double.class)) {
/* 256 */       return this.toDoubleStackManipulation;
/*     */     }
/* 258 */     throw new IllegalArgumentException("Not a primitive non-void type: " + typeDefinition);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\PrimitiveWideningDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */