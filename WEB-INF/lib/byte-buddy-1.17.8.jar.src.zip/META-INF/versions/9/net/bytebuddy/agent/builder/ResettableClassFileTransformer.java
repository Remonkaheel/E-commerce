package META-INF.versions.9.net.bytebuddy.agent.builder;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;
import java.util.Iterator;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.utility.JavaModule;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface ResettableClassFileTransformer extends ClassFileTransformer {
  Iterator<AgentBuilder.Transformer> iterator(TypeDescription paramTypeDescription, @MaybeNull ClassLoader paramClassLoader, @MaybeNull JavaModule paramJavaModule, @MaybeNull Class<?> paramClass, @MaybeNull ProtectionDomain paramProtectionDomain);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.Listener paramListener);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener paramListener);
  
  boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener paramListener);
  
  boolean reset(Instrumentation paramInstrumentation, net.bytebuddy.agent.builder.ResettableClassFileTransformer paramResettableClassFileTransformer, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener paramListener);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\agent\builder\ResettableClassFileTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */