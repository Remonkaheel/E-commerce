/*    */ package META-INF.versions.9.net.bytebuddy.asm;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public abstract class MemberAttributeExtension<T>
/*    */ {
/*    */   protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*    */   protected final T attributeAppenderFactory;
/*    */   
/*    */   protected MemberAttributeExtension(AnnotationValueFilter.Factory annotationValueFilterFactory, T attributeAppenderFactory) {
/* 65 */     this.annotationValueFilterFactory = annotationValueFilterFactory;
/* 66 */     this.attributeAppenderFactory = attributeAppenderFactory;
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.annotationValueFilterFactory.equals(((net.bytebuddy.asm.MemberAttributeExtension)paramObject).annotationValueFilterFactory) ? false : (!!this.attributeAppenderFactory.equals(((net.bytebuddy.asm.MemberAttributeExtension)paramObject).attributeAppenderFactory)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return (getClass().hashCode() * 31 + this.annotationValueFilterFactory.hashCode()) * 31 + this.attributeAppenderFactory.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\MemberAttributeExtension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */