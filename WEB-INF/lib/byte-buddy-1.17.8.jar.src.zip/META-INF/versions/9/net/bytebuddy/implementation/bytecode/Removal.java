/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Removal
/*     */   implements StackManipulation
/*     */ {
/*  31 */   ZERO(StackSize.ZERO, 0),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   SINGLE(StackSize.SINGLE, 87),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   DOUBLE(StackSize.DOUBLE, 88);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation.Size size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int opcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Removal(StackSize stackSize, int opcode) {
/*  65 */     this.size = stackSize.toDecreasingSize();
/*  66 */     this.opcode = opcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation of(TypeDefinition typeDefinition) {
/*  76 */     switch (null.$SwitchMap$net$bytebuddy$implementation$bytecode$StackSize[typeDefinition.getStackSize().ordinal()]) {
/*     */       case 1:
/*  78 */         return SINGLE;
/*     */       case 2:
/*  80 */         return DOUBLE;
/*     */       case 3:
/*  82 */         return ZERO;
/*     */     } 
/*  84 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*  99 */     methodVisitor.visitInsn(this.opcode);
/* 100 */     return this.size;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\Removal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */