/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class StringMatcher
/*    */   extends ElementMatcher.Junction.ForNonNullValues<String>
/*    */ {
/*    */   private final String value;
/*    */   private final Mode mode;
/*    */   
/*    */   public StringMatcher(String value, Mode mode) {
/* 45 */     this.value = value;
/* 46 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(String target) {
/* 53 */     return this.mode.matches(this.value, target);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 58 */     return this.mode.getDescription() + '(' + this.value + ')';
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.mode.equals(((net.bytebuddy.matcher.StringMatcher)paramObject).mode) ? false : (!!this.value.equals(((net.bytebuddy.matcher.StringMatcher)paramObject).value))))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return (super.hashCode() * 31 + this.value.hashCode()) * 31 + this.mode.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\StringMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */