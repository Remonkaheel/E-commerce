/*    */ package META-INF.versions.9.net.bytebuddy.utility.visitor;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.OpenedClassReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableAwareMethodVisitor
/*    */   extends MethodVisitor
/*    */ {
/*    */   private int freeOffset;
/*    */   
/*    */   public LocalVariableAwareMethodVisitor(MethodVisitor methodVisitor, MethodDescription methodDescription) {
/* 41 */     super(OpenedClassReader.ASM_API, methodVisitor);
/* 42 */     this.freeOffset = methodDescription.getStackSize();
/*    */   }
/*    */ 
/*    */   
/*    */   @SuppressFBWarnings(value = {"SF_SWITCH_NO_DEFAULT"}, justification = "No action required on default option.")
/*    */   public void visitVarInsn(int opcode, int offset) {
/* 48 */     switch (opcode) {
/*    */       case 54:
/*    */       case 56:
/*    */       case 58:
/* 52 */         this.freeOffset = Math.max(this.freeOffset, offset + 1);
/*    */         break;
/*    */       case 55:
/*    */       case 57:
/* 56 */         this.freeOffset = Math.max(this.freeOffset, offset + 2);
/*    */         break;
/*    */     } 
/* 59 */     super.visitVarInsn(opcode, offset);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFreeOffset() {
/* 68 */     return this.freeOffset;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\visitor\LocalVariableAwareMethodVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */