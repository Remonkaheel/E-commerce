/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*     */ 
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum IntegerConstant
/*     */   implements StackManipulation
/*     */ {
/*  36 */   MINUS_ONE(2),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   ZERO(3),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   ONE(4),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   TWO(5),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   THREE(6),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   FOUR(7),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   FIVE(8);
/*     */   private static final StackManipulation.Size SIZE;
/*     */   private final int opcode;
/*     */   
/*     */   static {
/*  71 */     SIZE = StackSize.SINGLE.toIncreasingSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IntegerConstant(int opcode) {
/*  84 */     this.opcode = opcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation forValue(boolean value) {
/*  94 */     return value ? ONE : ZERO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation forValue(int value) {
/* 106 */     switch (value) {
/*     */       case -1:
/* 108 */         return MINUS_ONE;
/*     */       case 0:
/* 110 */         return ZERO;
/*     */       case 1:
/* 112 */         return ONE;
/*     */       case 2:
/* 114 */         return TWO;
/*     */       case 3:
/* 116 */         return THREE;
/*     */       case 4:
/* 118 */         return FOUR;
/*     */       case 5:
/* 120 */         return FIVE;
/*     */     } 
/* 122 */     if (value >= -128 && value <= 127)
/* 123 */       return (StackManipulation)new SingleBytePush((byte)value); 
/* 124 */     if (value >= -32768 && value <= 32767) {
/* 125 */       return (StackManipulation)new TwoBytePush((short)value);
/*     */     }
/* 127 */     return (StackManipulation)new ConstantPool(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 143 */     methodVisitor.visitInsn(this.opcode);
/* 144 */     return SIZE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\IntegerConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */