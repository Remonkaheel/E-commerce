/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.collection;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.bytecode.Duplication;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.implementation.bytecode.constant.IntegerConstant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ArrayAccess
/*     */ {
/*  39 */   BYTE(51, 84, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   SHORT(53, 86, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   CHARACTER(52, 85, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   INTEGER(46, 79, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   LONG(47, 80, StackSize.DOUBLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   FLOAT(48, 81, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   DOUBLE(49, 82, StackSize.DOUBLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   REFERENCE(50, 83, StackSize.SINGLE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int loadOpcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int storeOpcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackSize stackSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayAccess(int loadOpcode, int storeOpcode, StackSize stackSize) {
/*  99 */     this.loadOpcode = loadOpcode;
/* 100 */     this.storeOpcode = storeOpcode;
/* 101 */     this.stackSize = stackSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.collection.ArrayAccess of(TypeDefinition componentType) {
/* 111 */     if (!componentType.isPrimitive())
/* 112 */       return REFERENCE; 
/* 113 */     if (componentType.represents(boolean.class) || componentType.represents(byte.class))
/* 114 */       return BYTE; 
/* 115 */     if (componentType.represents(short.class))
/* 116 */       return SHORT; 
/* 117 */     if (componentType.represents(char.class))
/* 118 */       return CHARACTER; 
/* 119 */     if (componentType.represents(int.class))
/* 120 */       return INTEGER; 
/* 121 */     if (componentType.represents(long.class))
/* 122 */       return LONG; 
/* 123 */     if (componentType.represents(float.class))
/* 124 */       return FLOAT; 
/* 125 */     if (componentType.represents(double.class)) {
/* 126 */       return DOUBLE;
/*     */     }
/* 128 */     throw new IllegalArgumentException("Not a legal array type: " + componentType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation load() {
/* 138 */     return (StackManipulation)new Loader(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation store() {
/* 147 */     return (StackManipulation)new Putter(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation forEach(List<? extends StackManipulation> processInstructions) {
/* 157 */     List<StackManipulation> stackManipulations = new ArrayList<>(processInstructions.size());
/* 158 */     int index = 0;
/* 159 */     for (StackManipulation processInstruction : processInstructions) {
/* 160 */       stackManipulations.add(new StackManipulation.Compound(new StackManipulation[] { (StackManipulation)Duplication.SINGLE, 
/*     */               
/* 162 */               IntegerConstant.forValue(index++), (StackManipulation)new Loader(this), processInstruction }));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 167 */     return (StackManipulation)new StackManipulation.Compound(stackManipulations);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\collection\ArrayAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */