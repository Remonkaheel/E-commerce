/*    */ package META-INF.versions.9.net.bytebuddy.dynamic;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TargetType
/*    */ {
/* 30 */   public static final TypeDescription DESCRIPTION = TypeDescription.ForLoadedType.of(net.bytebuddy.dynamic.TargetType.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*    */   public static TypeDescription resolve(TypeDescription typeDescription, TypeDescription targetType) {
/* 42 */     int arity = 0;
/* 43 */     TypeDescription componentType = typeDescription;
/* 44 */     while (componentType.isArray()) {
/* 45 */       componentType = componentType.getComponentType();
/* 46 */       arity++;
/*    */     } 
/* 48 */     return componentType.represents(net.bytebuddy.dynamic.TargetType.class) ? 
/* 49 */       TypeDescription.ArrayProjection.of(targetType, arity) : typeDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private TargetType() {
/* 57 */     throw new UnsupportedOperationException("This class only serves as a marker type and should not be instantiated");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\TargetType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */