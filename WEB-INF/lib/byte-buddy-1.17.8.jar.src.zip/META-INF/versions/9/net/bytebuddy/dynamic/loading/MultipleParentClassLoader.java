/*     */ package META-INF.versions.9.net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*     */ import net.bytebuddy.dynamic.loading.InjectionClassLoader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleParentClassLoader
/*     */   extends InjectionClassLoader
/*     */ {
/*     */   private final List<? extends ClassLoader> parents;
/*     */   
/*     */   static {
/*  58 */     doRegisterAsParallelCapable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Must be invoked from targeting class loader type.")
/*     */   private static void doRegisterAsParallelCapable() {
/*     */     try {
/*  67 */       Method method = ClassLoader.class.getDeclaredMethod("registerAsParallelCapable", new Class[0]);
/*  68 */       method.setAccessible(true);
/*  69 */       method.invoke(null, new Object[0]);
/*  70 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipleParentClassLoader(List<? extends ClassLoader> parents) {
/*  87 */     this(ClassLoadingStrategy.BOOTSTRAP_LOADER, parents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipleParentClassLoader(@MaybeNull ClassLoader parent, List<? extends ClassLoader> parents) {
/*  99 */     this(parent, parents, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipleParentClassLoader(@MaybeNull ClassLoader parent, List<? extends ClassLoader> parents, boolean sealed) {
/* 112 */     super(parent, sealed);
/* 113 */     this.parents = parents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 120 */     for (ClassLoader parent : this.parents) {
/*     */       try {
/* 122 */         Class<?> type = parent.loadClass(name);
/* 123 */         if (resolve) {
/* 124 */           resolveClass(type);
/*     */         }
/* 126 */         return type;
/* 127 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     } 
/*     */ 
/*     */     
/* 131 */     return super.loadClass(name, resolve);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/* 138 */     for (ClassLoader parent : this.parents) {
/* 139 */       URL url = parent.getResource(name);
/* 140 */       if (url != null) {
/* 141 */         return url;
/*     */       }
/*     */     } 
/* 144 */     return super.getResource(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String name) throws IOException {
/* 151 */     List<Enumeration<URL>> enumerations = new ArrayList<>(this.parents.size() + 1);
/* 152 */     for (ClassLoader parent : this.parents) {
/* 153 */       enumerations.add(parent.getResources(name));
/*     */     }
/* 155 */     enumerations.add(super.getResources(name));
/* 156 */     return (Enumeration<URL>)new CompoundEnumeration(enumerations);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, Class<?>> doDefineClasses(Map<String, byte[]> typeDefinitions) {
/* 161 */     Map<String, Class<?>> types = new HashMap<>();
/* 162 */     for (Map.Entry<String, byte[]> entry : typeDefinitions.entrySet()) {
/* 163 */       types.put(entry.getKey(), defineClass(entry.getKey(), entry.getValue(), 0, ((byte[])entry.getValue()).length));
/*     */     }
/* 165 */     return types;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\MultipleParentClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */