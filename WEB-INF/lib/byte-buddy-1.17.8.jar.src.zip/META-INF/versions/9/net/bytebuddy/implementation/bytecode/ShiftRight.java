/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode;
/*    */ 
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.StackSize;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ShiftRight
/*    */   implements StackManipulation
/*    */ {
/* 30 */   INTEGER(122, StackSize.SINGLE, (StackManipulation)Unsigned.INTEGER),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   LONG(123, StackSize.DOUBLE, (StackManipulation)Unsigned.LONG);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final int opcode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final StackSize stackSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final StackManipulation unsigned;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ShiftRight(int opcode, StackSize stackSize, StackManipulation unsigned) {
/* 60 */     this.opcode = opcode;
/* 61 */     this.stackSize = stackSize;
/* 62 */     this.unsigned = unsigned;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation toUnsigned() {
/* 71 */     return this.unsigned;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 78 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 85 */     methodVisitor.visitInsn(this.opcode);
/* 86 */     return this.stackSize.toDecreasingSize();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\ShiftRight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */