/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.FieldLocator;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*     */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.ConstantValue;
/*     */ import net.bytebuddy.utility.JavaConstant;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MethodCall
/*     */   implements Implementation.Composable
/*     */ {
/*     */   protected final MethodLocator.Factory methodLocator;
/*     */   protected final TargetHandler.Factory targetHandler;
/*     */   protected final List<ArgumentLoader.Factory> argumentLoaders;
/*     */   protected final MethodInvoker.Factory methodInvoker;
/*     */   protected final TerminationHandler.Factory terminationHandler;
/*     */   protected final Assigner assigner;
/*     */   protected final Assigner.Typing typing;
/*     */   
/*     */   protected MethodCall(MethodLocator.Factory methodLocator, TargetHandler.Factory targetHandler, List<ArgumentLoader.Factory> argumentLoaders, MethodInvoker.Factory methodInvoker, TerminationHandler.Factory terminationHandler, Assigner assigner, Assigner.Typing typing) {
/* 116 */     this.methodLocator = methodLocator;
/* 117 */     this.targetHandler = targetHandler;
/* 118 */     this.argumentLoaders = argumentLoaders;
/* 119 */     this.methodInvoker = methodInvoker;
/* 120 */     this.terminationHandler = terminationHandler;
/* 121 */     this.assigner = assigner;
/* 122 */     this.typing = typing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invoke(Method method) {
/* 133 */     return invoke((MethodDescription)new MethodDescription.ForLoadedMethod(method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invoke(Constructor<?> constructor) {
/* 149 */     return invoke((MethodDescription)new MethodDescription.ForLoadedConstructor(constructor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invoke(MethodDescription methodDescription) {
/* 167 */     return invoke((MethodLocator.Factory)new MethodLocator.ForExplicitMethod(methodDescription));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invoke(ElementMatcher<? super MethodDescription> matcher) {
/* 178 */     return invoke(matcher, MethodGraph.Compiler.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invoke(ElementMatcher<? super MethodDescription> matcher, MethodGraph.Compiler methodGraphCompiler) {
/* 189 */     return invoke((MethodLocator.Factory)new MethodLocator.ForElementMatcher.Factory(matcher, methodGraphCompiler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invoke(MethodLocator.Factory methodLocator) {
/* 202 */     return new WithoutSpecifiedTarget(methodLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithoutSpecifiedTarget invokeSelf() {
/* 212 */     return new WithoutSpecifiedTarget((MethodLocator.Factory)MethodLocator.ForInstrumentedMethod.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodCall invokeSuper() {
/* 221 */     return invokeSelf().onSuper();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation.Composable call(Callable<?> callable) {
/*     */     try {
/* 233 */       return invoke(Callable.class.getMethod("call", new Class[0])).on(callable, Callable.class).withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC);
/* 234 */     } catch (NoSuchMethodException exception) {
/* 235 */       throw new IllegalStateException("Could not locate Callable::call method", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation.Composable run(Runnable runnable) {
/*     */     try {
/* 247 */       return invoke(Runnable.class.getMethod("run", new Class[0])).on(runnable, Runnable.class).withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC);
/* 248 */     } catch (NoSuchMethodException exception) {
/* 249 */       throw new IllegalStateException("Could not locate Runnable::run method", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodCall construct(Constructor<?> constructor) {
/* 260 */     return construct((MethodDescription)new MethodDescription.ForLoadedConstructor(constructor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodCall construct(MethodDescription methodDescription) {
/* 270 */     if (!methodDescription.isConstructor()) {
/* 271 */       throw new IllegalArgumentException("Not a constructor: " + methodDescription);
/*     */     }
/* 273 */     return new net.bytebuddy.implementation.MethodCall((MethodLocator.Factory)new MethodLocator.ForExplicitMethod(methodDescription), (TargetHandler.Factory)TargetHandler.ForConstructingInvocation.Factory.INSTANCE, 
/*     */         
/* 275 */         Collections.emptyList(), (MethodInvoker.Factory)MethodInvoker.ForContextualInvocation.Factory.INSTANCE, (TerminationHandler.Factory)TerminationHandler.Simple.RETURNING, Assigner.DEFAULT, Assigner.Typing.STATIC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(Object... argument) {
/* 293 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(argument.length);
/* 294 */     for (Object anArgument : argument) {
/* 295 */       argumentLoaders.add(ArgumentLoader.ForStackManipulation.of(anArgument));
/*     */     }
/* 297 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(TypeDescription... typeDescription) {
/* 308 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(typeDescription.length);
/* 309 */     for (TypeDescription aTypeDescription : typeDescription) {
/* 310 */       argumentLoaders.add(new ArgumentLoader.ForStackManipulation(ClassConstant.of(aTypeDescription), Class.class));
/*     */     }
/* 312 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(EnumerationDescription... enumerationDescription) {
/* 323 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(enumerationDescription.length);
/* 324 */     for (EnumerationDescription anEnumerationDescription : enumerationDescription) {
/* 325 */       argumentLoaders.add(new ArgumentLoader.ForStackManipulation(FieldAccess.forEnumeration(anEnumerationDescription), (TypeDefinition)anEnumerationDescription.getEnumerationType()));
/*     */     }
/* 327 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(ConstantValue... constant) {
/* 338 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(constant.length);
/* 339 */     for (ConstantValue aConstant : constant) {
/* 340 */       argumentLoaders.add(new ArgumentLoader.ForStackManipulation(aConstant.toStackManipulation(), (TypeDefinition)aConstant.getTypeDescription()));
/*     */     }
/* 342 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(JavaConstant... constant) {
/* 353 */     return with((ConstantValue[])constant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withReference(Object... argument) {
/* 365 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(argument.length);
/* 366 */     for (Object anArgument : argument) {
/* 367 */       argumentLoaders.add((anArgument == null) ? (ArgumentLoader.Factory)ArgumentLoader.ForNullConstant.INSTANCE : (ArgumentLoader.Factory)new ArgumentLoader.ForInstance.Factory(anArgument));
/*     */     }
/*     */ 
/*     */     
/* 371 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withArgument(int... index) {
/* 383 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(index.length);
/* 384 */     for (int anIndex : index) {
/* 385 */       if (anIndex < 0) {
/* 386 */         throw new IllegalArgumentException("Negative index: " + anIndex);
/*     */       }
/* 388 */       argumentLoaders.add(new ArgumentLoader.ForMethodParameter.Factory(anIndex));
/*     */     } 
/* 390 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withAllArguments() {
/* 399 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)ArgumentLoader.ForMethodParameter.OfInstrumentedMethod.INSTANCE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withArgumentArray() {
/* 408 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)ArgumentLoader.ForMethodParameterArray.ForInstrumentedMethod.INSTANCE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withArgumentArrayElements(int index) {
/* 425 */     if (index < 0) {
/* 426 */       throw new IllegalArgumentException("A parameter index cannot be negative: " + index);
/*     */     }
/* 428 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)new ArgumentLoader.ForMethodParameterArrayElement.OfInvokedMethod(index) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withArgumentArrayElements(int index, int size) {
/* 446 */     return withArgumentArrayElements(index, 0, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withArgumentArrayElements(int index, int start, int size) {
/* 465 */     if (index < 0)
/* 466 */       throw new IllegalArgumentException("A parameter index cannot be negative: " + index); 
/* 467 */     if (start < 0)
/* 468 */       throw new IllegalArgumentException("An array index cannot be negative: " + start); 
/* 469 */     if (size == 0)
/* 470 */       return this; 
/* 471 */     if (size < 0) {
/* 472 */       throw new IllegalArgumentException("Size cannot be negative: " + size);
/*     */     }
/* 474 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(size);
/* 475 */     for (int position = 0; position < size; position++) {
/* 476 */       argumentLoaders.add(new ArgumentLoader.ForMethodParameterArrayElement.OfParameter(index, start + position));
/*     */     }
/* 478 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withThis() {
/* 488 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)ArgumentLoader.ForThisReference.Factory.INSTANCE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withOwnType() {
/* 498 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)ArgumentLoader.ForInstrumentedType.Factory.INSTANCE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withField(String... name) {
/* 508 */     return withField((FieldLocator.Factory)FieldLocator.ForClassHierarchy.Factory.INSTANCE, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withField(FieldLocator.Factory fieldLocatorFactory, String... name) {
/* 519 */     List<ArgumentLoader.Factory> argumentLoaders = new ArrayList<>(name.length);
/* 520 */     for (String aName : name) {
/* 521 */       argumentLoaders.add(new ArgumentLoader.ForField.Factory(aName, fieldLocatorFactory));
/*     */     }
/* 523 */     return with(argumentLoaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall withMethodCall(net.bytebuddy.implementation.MethodCall methodCall) {
/* 533 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)new ArgumentLoader.ForMethodCall.Factory(methodCall) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(StackManipulation stackManipulation, Type type) {
/* 544 */     return with(stackManipulation, (TypeDefinition)TypeDefinition.Sort.describe(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(StackManipulation stackManipulation, TypeDefinition typeDefinition) {
/* 555 */     return with(new ArgumentLoader.Factory[] { (ArgumentLoader.Factory)new ArgumentLoader.ForStackManipulation(stackManipulation, typeDefinition) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(ArgumentLoader.Factory... argumentLoader) {
/* 565 */     return with(Arrays.asList(argumentLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.MethodCall with(List<? extends ArgumentLoader.Factory> argumentLoaders) {
/* 575 */     return new net.bytebuddy.implementation.MethodCall(this.methodLocator, this.targetHandler, 
/*     */         
/* 577 */         CompoundList.of(this.argumentLoaders, argumentLoaders), this.methodInvoker, this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldSetting setsField(Field field) {
/* 592 */     return setsField((FieldDescription)new FieldDescription.ForLoadedField(field));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldSetting setsField(FieldDescription fieldDescription) {
/* 603 */     return new FieldSetting(new net.bytebuddy.implementation.MethodCall(this.methodLocator, this.targetHandler, this.argumentLoaders, this.methodInvoker, (TerminationHandler.Factory)new TerminationHandler.FieldSetting.Explicit(fieldDescription), this.assigner, this.typing));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldSetting setsField(ElementMatcher<? super FieldDescription> matcher) {
/* 620 */     return new FieldSetting(new net.bytebuddy.implementation.MethodCall(this.methodLocator, this.targetHandler, this.argumentLoaders, this.methodInvoker, (TerminationHandler.Factory)new TerminationHandler.FieldSetting.Implicit(matcher), this.assigner, this.typing));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.Composable withAssigner(Assigner assigner, Assigner.Typing typing) {
/* 641 */     return new net.bytebuddy.implementation.MethodCall(this.methodLocator, this.targetHandler, this.argumentLoaders, this.methodInvoker, this.terminationHandler, assigner, typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation andThen(Implementation implementation) {
/* 654 */     return (Implementation)new Implementation.Compound(new Implementation[] { (Implementation)new net.bytebuddy.implementation.MethodCall(this.methodLocator, this.targetHandler, this.argumentLoaders, this.methodInvoker, (TerminationHandler.Factory)TerminationHandler.Simple.DROPPING, this.assigner, this.typing), implementation });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.Composable andThen(Implementation.Composable implementation) {
/* 667 */     return (Implementation.Composable)new Implementation.Compound.Composable((Implementation)new net.bytebuddy.implementation.MethodCall(this.methodLocator, this.targetHandler, this.argumentLoaders, this.methodInvoker, (TerminationHandler.Factory)TerminationHandler.Simple.DROPPING, this.assigner, this.typing), implementation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 680 */     for (InstrumentedType.Prepareable prepareable : this.argumentLoaders) {
/* 681 */       instrumentedType = prepareable.prepare(instrumentedType);
/*     */     }
/* 683 */     return this.targetHandler.prepare(instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 690 */     return (ByteCodeAppender)new Appender(this, implementationTarget, this.terminationHandler.make(implementationTarget.getInstrumentedType()));
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.typing.equals(((net.bytebuddy.implementation.MethodCall)paramObject).typing) ? false : (!this.methodLocator.equals(((net.bytebuddy.implementation.MethodCall)paramObject).methodLocator) ? false : (!this.targetHandler.equals(((net.bytebuddy.implementation.MethodCall)paramObject).targetHandler) ? false : (!this.argumentLoaders.equals(((net.bytebuddy.implementation.MethodCall)paramObject).argumentLoaders) ? false : (!this.methodInvoker.equals(((net.bytebuddy.implementation.MethodCall)paramObject).methodInvoker) ? false : (!this.terminationHandler.equals(((net.bytebuddy.implementation.MethodCall)paramObject).terminationHandler) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.MethodCall)paramObject).assigner))))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((((getClass().hashCode() * 31 + this.methodLocator.hashCode()) * 31 + this.targetHandler.hashCode()) * 31 + this.argumentLoaders.hashCode()) * 31 + this.methodInvoker.hashCode()) * 31 + this.terminationHandler.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\MethodCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */