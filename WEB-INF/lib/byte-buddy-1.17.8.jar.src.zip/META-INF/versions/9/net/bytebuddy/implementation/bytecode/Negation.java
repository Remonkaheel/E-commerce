/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode;
/*    */ 
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Negation
/*    */   implements StackManipulation
/*    */ {
/* 30 */   INTEGER(116),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   LONG(117),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   FLOAT(118),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   DOUBLE(119);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final int opcode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Negation(int opcode) {
/* 58 */     this.opcode = opcode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 72 */     methodVisitor.visitInsn(this.opcode);
/* 73 */     return StackManipulation.Size.ZERO;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\Negation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */