/*    */ package META-INF.versions.9.net.bytebuddy.utility;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FieldComparator
/*    */   implements Comparator<Field>
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compare(Field left, Field right) {
/* 35 */     if (left == right) {
/* 36 */       return 0;
/*    */     }
/* 38 */     int comparison = left.getName().compareTo(right.getName());
/* 39 */     if (comparison == 0) {
/* 40 */       return left.getType().getName().compareTo(right.getType().getName());
/*    */     }
/* 42 */     return comparison;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\FieldComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */