/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bind;
/*    */ 
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.bind.MethodDelegationBinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DeclaringTypeResolver
/*    */   implements MethodDelegationBinder.AmbiguityResolver
/*    */ {
/* 30 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodDelegationBinder.AmbiguityResolver.Resolution resolve(MethodDescription source, MethodDelegationBinder.MethodBinding left, MethodDelegationBinder.MethodBinding right) {
/* 38 */     TypeDescription leftType = left.getTarget().getDeclaringType().asErasure();
/* 39 */     TypeDescription rightType = right.getTarget().getDeclaringType().asErasure();
/* 40 */     if (leftType.equals(rightType))
/* 41 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.AMBIGUOUS; 
/* 42 */     if (leftType.isAssignableFrom(rightType))
/* 43 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT; 
/* 44 */     if (leftType.isAssignableTo(rightType)) {
/* 45 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT;
/*    */     }
/* 47 */     return MethodDelegationBinder.AmbiguityResolver.Resolution.AMBIGUOUS;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\DeclaringTypeResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */