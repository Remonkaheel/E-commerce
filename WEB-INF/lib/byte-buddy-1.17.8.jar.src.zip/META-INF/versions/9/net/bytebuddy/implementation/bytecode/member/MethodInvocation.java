/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.member;
/*     */ 
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.utility.JavaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MethodInvocation
/*     */ {
/*  41 */   VIRTUAL(182, 5, 182, 5),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   INTERFACE(185, 9, 185, 9),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   STATIC(184, 6, 184, 6),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   SPECIAL(183, 7, 183, 7),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   SPECIAL_CONSTRUCTOR(183, 8, 183, 8),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   VIRTUAL_PRIVATE(182, 5, 183, 7),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   INTERFACE_PRIVATE(185, 9, 183, 7);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int opcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int handle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int legacyOpcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int legacyHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodInvocation(int opcode, int handle, int legacyOpcode, int legacyHandle) {
/* 102 */     this.opcode = opcode;
/* 103 */     this.handle = handle;
/* 104 */     this.legacyOpcode = legacyOpcode;
/* 105 */     this.legacyHandle = legacyHandle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitInvocationTargetType invoke(MethodDescription.InDefinedShape methodDescription) {
/* 115 */     if (methodDescription.isTypeInitializer())
/* 116 */       return (WithImplicitInvocationTargetType)IllegalInvocation.INSTANCE; 
/* 117 */     if (methodDescription.isStatic()) {
/* 118 */       STATIC.getClass(); return (WithImplicitInvocationTargetType)new Invocation(STATIC, methodDescription);
/* 119 */     }  if (methodDescription.isConstructor()) {
/* 120 */       SPECIAL_CONSTRUCTOR.getClass(); return (WithImplicitInvocationTargetType)new Invocation(SPECIAL_CONSTRUCTOR, methodDescription);
/* 121 */     }  if (methodDescription.isPrivate()) {
/* 122 */       (methodDescription.getDeclaringType().isInterface() ? INTERFACE_PRIVATE : VIRTUAL_PRIVATE).getClass(); return (WithImplicitInvocationTargetType)new Invocation(methodDescription.getDeclaringType().isInterface() ? INTERFACE_PRIVATE : VIRTUAL_PRIVATE, methodDescription);
/*     */     } 
/*     */     
/* 125 */     if (methodDescription.getDeclaringType().isInterface()) {
/* 126 */       INTERFACE.getClass(); return (WithImplicitInvocationTargetType)new Invocation(INTERFACE, methodDescription);
/*     */     } 
/* 128 */     VIRTUAL.getClass(); return (WithImplicitInvocationTargetType)new Invocation(VIRTUAL, methodDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitInvocationTargetType invoke(MethodDescription methodDescription) {
/* 140 */     MethodDescription.InDefinedShape declaredMethod = (MethodDescription.InDefinedShape)methodDescription.asDefined();
/* 141 */     return declaredMethod.getReturnType().asErasure().equals(methodDescription.getReturnType().asErasure()) ? 
/* 142 */       invoke(declaredMethod) : 
/* 143 */       OfGenericMethod.of(methodDescription, invoke(declaredMethod));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation lookup() {
/* 152 */     return (StackManipulation)invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLES.getTypeStub(), new MethodDescription.Token("lookup", 9, JavaType.METHOD_HANDLES_LOOKUP
/*     */             
/* 154 */             .getTypeStub().asGenericType())));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\member\MethodInvocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */