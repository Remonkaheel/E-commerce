/*     */ package META-INF.versions.9.net.bytebuddy.dynamic.scaffold.inline;
/*     */ 
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.dynamic.scaffold.inline.MethodRebaseResolver;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class RebaseImplementationTarget
/*     */   extends Implementation.Target.AbstractBase
/*     */ {
/*     */   private final Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> rebaseableMethods;
/*     */   
/*     */   protected RebaseImplementationTarget(TypeDescription instrumentedType, MethodGraph.Linked methodGraph, Implementation.Target.AbstractBase.DefaultMethodInvocation defaultMethodInvocation, Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> rebaseableMethods) {
/*  66 */     super(instrumentedType, methodGraph, defaultMethodInvocation);
/*  67 */     this.rebaseableMethods = rebaseableMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Implementation.Target of(TypeDescription instrumentedType, MethodGraph.Linked methodGraph, ClassFileVersion classFileVersion, MethodRebaseResolver methodRebaseResolver) {
/*  83 */     return (Implementation.Target)new net.bytebuddy.dynamic.scaffold.inline.RebaseImplementationTarget(instrumentedType, methodGraph, Implementation.Target.AbstractBase.DefaultMethodInvocation.of(classFileVersion), methodRebaseResolver.asTokenMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.SpecialMethodInvocation invokeSuper(MethodDescription.SignatureToken token) {
/*  90 */     MethodRebaseResolver.Resolution resolution = this.rebaseableMethods.get(token);
/*  91 */     return (resolution == null) ? 
/*  92 */       invokeSuper(this.methodGraph.getSuperClassGraph().locate(token)) : 
/*  93 */       invokeSuper(resolution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Implementation.SpecialMethodInvocation invokeSuper(MethodGraph.Node node) {
/* 103 */     TypeDescription.Generic superClass = this.instrumentedType.getSuperClass();
/* 104 */     return (node.getSort().isResolved() && superClass != null) ? 
/* 105 */       Implementation.SpecialMethodInvocation.Simple.of(node.getRepresentative(), superClass.asErasure()) : (Implementation.SpecialMethodInvocation)Implementation.SpecialMethodInvocation.Illegal.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Implementation.SpecialMethodInvocation invokeSuper(MethodRebaseResolver.Resolution resolution) {
/* 116 */     return resolution.isRebased() ? 
/* 117 */       RebasedMethodInvocation.of(resolution.getResolvedMethod(), this.instrumentedType, resolution.getAppendedParameters()) : 
/* 118 */       Implementation.SpecialMethodInvocation.Simple.of((MethodDescription)resolution.getResolvedMethod(), this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescription getOriginType() {
/* 125 */     return this.instrumentedType;
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.rebaseableMethods.equals(((net.bytebuddy.dynamic.scaffold.inline.RebaseImplementationTarget)paramObject).rebaseableMethods)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return super.hashCode() * 31 + this.rebaseableMethods.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\inline\RebaseImplementationTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */