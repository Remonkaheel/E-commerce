/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.annotation.AnnotationList;
/*    */ import net.bytebuddy.description.annotation.AnnotationSource;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class DeclaringAnnotationMatcher<T extends AnnotationSource>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<T>
/*    */ {
/*    */   private final ElementMatcher<? super AnnotationList> matcher;
/*    */   
/*    */   public DeclaringAnnotationMatcher(ElementMatcher<? super AnnotationList> matcher) {
/* 41 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(T target) {
/* 48 */     return this.matcher.matches(target.getDeclaredAnnotations());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     return "declaresAnnotations(" + this.matcher + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.matcher.equals(((net.bytebuddy.matcher.DeclaringAnnotationMatcher)paramObject).matcher)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return super.hashCode() * 31 + this.matcher.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\DeclaringAnnotationMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */