/*     */ package META-INF.versions.9.net.bytebuddy.matcher;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MethodOverrideMatcher<T extends MethodDescription>
/*     */   extends ElementMatcher.Junction.ForNonNullValues<T>
/*     */ {
/*     */   private final ElementMatcher<? super TypeDescription.Generic> matcher;
/*     */   
/*     */   public MethodOverrideMatcher(ElementMatcher<? super TypeDescription.Generic> matcher) {
/*  48 */     this.matcher = matcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doMatch(T target) {
/*  55 */     Set<TypeDescription> duplicates = new HashSet<>();
/*  56 */     for (TypeDefinition typeDefinition : target.getDeclaringType()) {
/*  57 */       if (matches((MethodDescription)target, typeDefinition) || matches((MethodDescription)target, (List<? extends TypeDefinition>)typeDefinition.getInterfaces(), duplicates)) {
/*  58 */         return true;
/*     */       }
/*     */     } 
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(MethodDescription target, List<? extends TypeDefinition> typeDefinitions, Set<TypeDescription> duplicates) {
/*  73 */     for (TypeDefinition anInterface : typeDefinitions) {
/*  74 */       if (duplicates.add(anInterface.asErasure()) && (matches(target, anInterface) || matches(target, (List<? extends TypeDefinition>)anInterface.getInterfaces(), duplicates))) {
/*  75 */         return true;
/*     */       }
/*     */     } 
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matches(MethodDescription target, TypeDefinition typeDefinition) {
/*  89 */     for (MethodDescription methodDescription : typeDefinition.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isVirtual())) {
/*  90 */       if (methodDescription.asSignatureToken().equals(target.asSignatureToken())) {
/*  91 */         if (this.matcher.matches(typeDefinition.asGenericType())) {
/*  92 */           return true;
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return "isOverriddenFrom(" + this.matcher + ")";
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.matcher.equals(((net.bytebuddy.matcher.MethodOverrideMatcher)paramObject).matcher)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return super.hashCode() * 31 + this.matcher.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\MethodOverrideMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */