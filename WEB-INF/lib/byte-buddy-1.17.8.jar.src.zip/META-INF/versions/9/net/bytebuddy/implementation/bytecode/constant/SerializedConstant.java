/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.Duplication;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.TypeCreation;
/*    */ import net.bytebuddy.implementation.bytecode.constant.NullConstant;
/*    */ import net.bytebuddy.implementation.bytecode.constant.TextConstant;
/*    */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class SerializedConstant
/*    */   extends StackManipulation.AbstractBase
/*    */ {
/*    */   private static final String CHARSET = "ISO-8859-1";
/*    */   private final String serialization;
/*    */   
/*    */   protected SerializedConstant(String serialization) {
/* 53 */     this.serialization = serialization;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StackManipulation of(@MaybeNull Serializable value) {
/* 63 */     if (value == null) {
/* 64 */       return (StackManipulation)NullConstant.INSTANCE;
/*    */     }
/*    */     try {
/* 67 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 68 */       ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
/*    */       try {
/* 70 */         objectOutputStream.writeObject(value);
/*    */       } finally {
/* 72 */         objectOutputStream.close();
/*    */       } 
/* 74 */       return (StackManipulation)new net.bytebuddy.implementation.bytecode.constant.SerializedConstant(byteArrayOutputStream.toString("ISO-8859-1"));
/* 75 */     } catch (IOException exception) {
/* 76 */       throw new IllegalStateException("Cannot serialize " + value, exception);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*    */     try {
/* 85 */       return (new StackManipulation.Compound(new StackManipulation[] {
/* 86 */             TypeCreation.of(TypeDescription.ForLoadedType.of(ObjectInputStream.class)), (StackManipulation)Duplication.SINGLE, 
/*    */             
/* 88 */             TypeCreation.of(TypeDescription.ForLoadedType.of(ByteArrayInputStream.class)), (StackManipulation)Duplication.SINGLE, (StackManipulation)new TextConstant(this.serialization), (StackManipulation)new TextConstant("ISO-8859-1"), 
/*    */ 
/*    */ 
/*    */             
/* 92 */             (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(String.class.getMethod("getBytes", new Class[] { String.class
/* 93 */                   }))), (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(ByteArrayInputStream.class.getConstructor(new Class[] { byte[].class
/* 94 */                   }))), (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(ObjectInputStream.class.getConstructor(new Class[] { InputStream.class
/* 95 */                   }))), (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(ObjectInputStream.class.getMethod("readObject", new Class[0])))
/* 96 */           })).apply(methodVisitor, implementationContext);
/* 97 */     } catch (NoSuchMethodException exception) {
/* 98 */       throw new IllegalStateException("Could not locate Java API method", exception);
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.serialization.equals(((net.bytebuddy.implementation.bytecode.constant.SerializedConstant)paramObject).serialization))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.serialization.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\SerializedConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */