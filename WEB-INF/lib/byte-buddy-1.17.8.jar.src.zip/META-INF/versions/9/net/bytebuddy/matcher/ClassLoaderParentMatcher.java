/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class ClassLoaderParentMatcher<T extends ClassLoader>
/*    */   extends ElementMatcher.Junction.AbstractBase<T>
/*    */ {
/*    */   @MaybeNull
/*    */   @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*    */   private final ClassLoader classLoader;
/*    */   
/*    */   public ClassLoaderParentMatcher(@MaybeNull ClassLoader classLoader) {
/* 42 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matches(@MaybeNull T target) {
/* 49 */     ClassLoader current = this.classLoader;
/* 50 */     while (current != null) {
/* 51 */       if (current == target) {
/* 52 */         return true;
/*    */       }
/* 54 */       current = current.getParent();
/*    */     } 
/* 56 */     return (target == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     return "isParentOf(" + this.classLoader + ')';
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     if (this == paramObject)
/*    */       return true; 
/*    */     if (paramObject == null)
/*    */       return false; 
/*    */     if (getClass() != paramObject.getClass())
/*    */       return false; 
/*    */     ClassLoader classLoader1 = ((net.bytebuddy.matcher.ClassLoaderParentMatcher)paramObject).classLoader;
/*    */     ClassLoader classLoader2 = this.classLoader;
/*    */     if (classLoader1 != null) {
/*    */       if (classLoader2 != null) {
/*    */         if (!classLoader2.equals(classLoader1))
/*    */           return false; 
/*    */       } else {
/*    */         return false;
/*    */       } 
/*    */     } else if (classLoader2 != null) {
/*    */       return false;
/*    */     } 
/*    */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     ClassLoader classLoader = this.classLoader;
/*    */     if (classLoader != null);
/*    */     return getClass().hashCode() * 31 + classLoader.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\ClassLoaderParentMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */