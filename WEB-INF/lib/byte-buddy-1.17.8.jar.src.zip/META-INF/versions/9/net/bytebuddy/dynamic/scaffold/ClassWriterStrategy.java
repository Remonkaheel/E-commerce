package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.jar.asm.ClassReader;
import net.bytebuddy.jar.asm.ClassWriter;
import net.bytebuddy.pool.TypePool;

@Deprecated
public interface ClassWriterStrategy {
  ClassWriter resolve(int paramInt, TypePool paramTypePool);
  
  ClassWriter resolve(int paramInt, TypePool paramTypePool, ClassReader paramClassReader);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\ClassWriterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */