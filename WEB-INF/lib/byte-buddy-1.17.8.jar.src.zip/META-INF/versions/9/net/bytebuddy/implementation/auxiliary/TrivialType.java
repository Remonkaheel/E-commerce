/*    */ package META-INF.versions.9.net.bytebuddy.implementation.auxiliary;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import net.bytebuddy.ByteBuddy;
/*    */ import net.bytebuddy.ClassFileVersion;
/*    */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*    */ import net.bytebuddy.dynamic.DynamicType;
/*    */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*    */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*    */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*    */ import net.bytebuddy.implementation.MethodAccessorFactory;
/*    */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*    */ import net.bytebuddy.utility.RandomString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TrivialType
/*    */   implements AuxiliaryType
/*    */ {
/* 39 */   SIGNATURE_RELEVANT(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   PLAIN(false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final boolean eager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   TrivialType(boolean eager) {
/* 57 */     this.eager = eager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSuffix() {
/* 64 */     return RandomString.hashOf(name().hashCode());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DynamicType make(String auxiliaryTypeName, ClassFileVersion classFileVersion, MethodAccessorFactory methodAccessorFactory) {
/* 73 */     return (DynamicType)(new ByteBuddy(classFileVersion))
/* 74 */       .with(TypeValidation.DISABLED)
/* 75 */       .with((MethodGraph.Compiler)MethodGraph.Empty.INSTANCE)
/* 76 */       .subclass(Object.class, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS)
/* 77 */       .annotateType(this.eager ? 
/* 78 */         Collections.<AnnotationDescription>singletonList(AnnotationDescription.Builder.ofType(AuxiliaryType.SignatureRelevant.class).build(false)) : 
/* 79 */         Collections.emptyList())
/* 80 */       .name(auxiliaryTypeName)
/* 81 */       .modifiers(DEFAULT_TYPE_MODIFIER)
/* 82 */       .make();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\auxiliary\TrivialType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */