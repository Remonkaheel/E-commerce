package META-INF.versions.9.net.bytebuddy.implementation.bind.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.PARAMETER})
public @interface DefaultCall {
  Class<?> targetType() default void.class;
  
  boolean serializableProxy() default false;
  
  boolean nullIfImpossible() default false;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\annotation\DefaultCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */