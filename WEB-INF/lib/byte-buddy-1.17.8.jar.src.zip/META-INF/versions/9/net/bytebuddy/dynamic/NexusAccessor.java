/*     */ package META-INF.versions.9.net.bytebuddy.dynamic;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*     */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class NexusAccessor
/*     */ {
/*  58 */   private static final Dispatcher DISPATCHER = doPrivileged((PrivilegedAction<Dispatcher>)Dispatcher.CreationAction.INSTANCE); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */   private final ReferenceQueue<? super ClassLoader> referenceQueue;
/*     */   
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */   
/*     */   public NexusAccessor() {
/*  71 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NexusAccessor(@MaybeNull ReferenceQueue<? super ClassLoader> referenceQueue) {
/*  83 */     this.referenceQueue = referenceQueue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  95 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAlive() {
/* 104 */     return DISPATCHER.isAlive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clean(Reference<? extends ClassLoader> reference) {
/* 115 */     DISPATCHER.clean(reference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(String name, @MaybeNull ClassLoader classLoader, int identification, LoadedTypeInitializer loadedTypeInitializer) {
/* 127 */     if (loadedTypeInitializer.isAlive())
/* 128 */       DISPATCHER.register(name, classLoader, this.referenceQueue, identification, loadedTypeInitializer); 
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     if (this == paramObject)
/*     */       return true; 
/*     */     if (paramObject == null)
/*     */       return false; 
/*     */     if (getClass() != paramObject.getClass())
/*     */       return false; 
/*     */     ReferenceQueue<? super ClassLoader> referenceQueue1 = ((net.bytebuddy.dynamic.NexusAccessor)paramObject).referenceQueue;
/*     */     ReferenceQueue<? super ClassLoader> referenceQueue2 = this.referenceQueue;
/*     */     if (referenceQueue1 != null) {
/*     */       if (referenceQueue2 != null) {
/*     */         if (!referenceQueue2.equals(referenceQueue1))
/*     */           return false; 
/*     */       } else {
/*     */         return false;
/*     */       } 
/*     */     } else if (referenceQueue2 != null) {
/*     */       return false;
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     ReferenceQueue<? super ClassLoader> referenceQueue = this.referenceQueue;
/*     */     if (referenceQueue != null);
/*     */     return getClass().hashCode() * 31 + referenceQueue.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\NexusAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */