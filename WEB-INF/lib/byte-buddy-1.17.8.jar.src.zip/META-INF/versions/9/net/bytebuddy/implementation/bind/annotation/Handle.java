package META-INF.versions.9.net.bytebuddy.implementation.bind.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.bytebuddy.utility.JavaConstant;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.PARAMETER})
public @interface Handle {
  JavaConstant.MethodHandle.HandleType type();
  
  Class<?> owner() default void.class;
  
  String name();
  
  Class<?> returnType();
  
  Class<?>[] parameterTypes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\annotation\Handle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */