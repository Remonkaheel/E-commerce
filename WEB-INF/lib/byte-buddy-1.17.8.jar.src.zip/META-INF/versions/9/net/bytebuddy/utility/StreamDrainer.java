/*    */ package META-INF.versions.9.net.bytebuddy.utility;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class StreamDrainer
/*    */ {
/*    */   public static final int DEFAULT_BUFFER_SIZE = 1024;
/*    */   public static final net.bytebuddy.utility.StreamDrainer DEFAULT;
/*    */   private static final int END_OF_STREAM = -1;
/*    */   private static final int FROM_BEGINNING = 0;
/*    */   private final int bufferSize;
/*    */   
/*    */   public StreamDrainer() {
/* 60 */     this(1024);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StreamDrainer(int bufferSize) {
/* 69 */     this.bufferSize = bufferSize;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] drain(InputStream inputStream) throws IOException {
/* 80 */     List<byte[]> previousBytes = (List)new ArrayList<>();
/* 81 */     byte[] currentArray = new byte[this.bufferSize];
/* 82 */     int currentIndex = 0;
/*    */     
/*    */     while (true) {
/* 85 */       int currentRead = inputStream.read(currentArray, currentIndex, this.bufferSize - currentIndex);
/* 86 */       currentIndex += Math.max(currentRead, 0);
/* 87 */       if (currentIndex == this.bufferSize) {
/* 88 */         previousBytes.add(currentArray);
/* 89 */         currentArray = new byte[this.bufferSize];
/* 90 */         currentIndex = 0;
/*    */       } 
/* 92 */       if (currentRead == -1) {
/* 93 */         byte[] result = new byte[previousBytes.size() * this.bufferSize + currentIndex];
/* 94 */         int arrayIndex = 0;
/* 95 */         for (byte[] previousByte : previousBytes) {
/* 96 */           System.arraycopy(previousByte, 0, result, arrayIndex++ * this.bufferSize, this.bufferSize);
/*    */         }
/* 98 */         System.arraycopy(currentArray, 0, result, arrayIndex * this.bufferSize, currentIndex);
/* 99 */         return result;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!(this.bufferSize != ((net.bytebuddy.utility.StreamDrainer)paramObject).bufferSize))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.bufferSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\StreamDrainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */