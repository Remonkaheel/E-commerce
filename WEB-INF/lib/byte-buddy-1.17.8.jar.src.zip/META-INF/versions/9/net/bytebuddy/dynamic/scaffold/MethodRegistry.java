package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.description.method.MethodDescription;
import net.bytebuddy.dynamic.Transformer;
import net.bytebuddy.dynamic.VisibilityBridgeStrategy;
import net.bytebuddy.dynamic.scaffold.InstrumentedType;
import net.bytebuddy.dynamic.scaffold.MethodGraph;
import net.bytebuddy.dynamic.scaffold.TypeValidation;
import net.bytebuddy.implementation.attribute.MethodAttributeAppender;
import net.bytebuddy.matcher.LatentMatcher;

public interface MethodRegistry {
  net.bytebuddy.dynamic.scaffold.MethodRegistry prepend(LatentMatcher<? super MethodDescription> paramLatentMatcher, Handler paramHandler, MethodAttributeAppender.Factory paramFactory, Transformer<MethodDescription> paramTransformer);
  
  net.bytebuddy.dynamic.scaffold.MethodRegistry append(LatentMatcher<? super MethodDescription> paramLatentMatcher, Handler paramHandler, MethodAttributeAppender.Factory paramFactory, Transformer<MethodDescription> paramTransformer);
  
  Prepared prepare(InstrumentedType paramInstrumentedType, MethodGraph.Compiler paramCompiler, TypeValidation paramTypeValidation, VisibilityBridgeStrategy paramVisibilityBridgeStrategy, LatentMatcher<? super MethodDescription> paramLatentMatcher);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\MethodRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */