package META-INF.versions.9.net.bytebuddy.implementation.attribute;

import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
import net.bytebuddy.jar.asm.ClassVisitor;

public interface TypeAttributeAppender {
  void apply(ClassVisitor paramClassVisitor, TypeDescription paramTypeDescription, AnnotationValueFilter paramAnnotationValueFilter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\TypeAttributeAppender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */