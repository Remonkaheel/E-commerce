/*    */ package META-INF.versions.9.net.bytebuddy.utility;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.bytebuddy.jar.asm.Attribute;
/*    */ import net.bytebuddy.jar.asm.ClassVisitor;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AsmClassReader
/*    */ {
/* 41 */   public static final Attribute[] NO_ATTRIBUTES = new Attribute[0];
/*    */   
/*    */   @MaybeNull
/*    */   <T> T unwrap(Class<T> paramClass);
/*    */   
/*    */   int getModifiers();
/*    */   
/*    */   String getInternalName();
/*    */   
/*    */   @MaybeNull
/*    */   String getSuperClassInternalName();
/*    */   
/*    */   List<String> getInterfaceInternalNames();
/*    */   
/*    */   void accept(ClassVisitor paramClassVisitor, int paramInt);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\AsmClassReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */