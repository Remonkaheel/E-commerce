package META-INF.versions.9.net.bytebuddy.description.type;

import java.lang.reflect.Type;
import net.bytebuddy.description.ModifierReviewable;
import net.bytebuddy.description.NamedElement;
import net.bytebuddy.description.field.FieldList;
import net.bytebuddy.description.method.MethodList;
import net.bytebuddy.description.type.RecordComponentList;
import net.bytebuddy.description.type.TypeDefinition;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeList;
import net.bytebuddy.implementation.bytecode.StackSize;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface TypeDefinition extends NamedElement, ModifierReviewable.ForTypeDefinition, Iterable<TypeDefinition> {
  public static final String RAW_TYPES_PROPERTY = "net.bytebuddy.raw";
  
  TypeDescription.Generic asGenericType();
  
  TypeDescription asErasure();
  
  @MaybeNull
  TypeDescription.Generic getSuperClass();
  
  TypeList.Generic getInterfaces();
  
  FieldList<?> getDeclaredFields();
  
  MethodList<?> getDeclaredMethods();
  
  @MaybeNull
  TypeDefinition getComponentType();
  
  RecordComponentList<?> getRecordComponents();
  
  Sort getSort();
  
  String getTypeName();
  
  StackSize getStackSize();
  
  boolean isArray();
  
  boolean isRecord();
  
  boolean isPrimitive();
  
  boolean represents(Type paramType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\type\TypeDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */