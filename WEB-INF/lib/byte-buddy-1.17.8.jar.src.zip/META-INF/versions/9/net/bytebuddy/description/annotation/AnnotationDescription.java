/*    */ package META-INF.versions.9.net.bytebuddy.description.annotation;
/*    */ 
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.util.Set;
/*    */ import net.bytebuddy.description.annotation.AnnotationValue;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AnnotationDescription
/*    */ {
/*    */   @AlwaysNull
/* 63 */   public static final Loadable<?> UNDEFINED = null;
/*    */   
/*    */   AnnotationValue<?, ?> getValue(String paramString);
/*    */   
/*    */   AnnotationValue<?, ?> getValue(MethodDescription.InDefinedShape paramInDefinedShape);
/*    */   
/*    */   TypeDescription getAnnotationType();
/*    */   
/*    */   <T extends java.lang.annotation.Annotation> Loadable<T> prepare(Class<T> paramClass);
/*    */   
/*    */   RetentionPolicy getRetention();
/*    */   
/*    */   Set<ElementType> getElementTypes();
/*    */   
/*    */   boolean isSupportedOn(ElementType paramElementType);
/*    */   
/*    */   boolean isSupportedOn(String paramString);
/*    */   
/*    */   boolean isInherited();
/*    */   
/*    */   boolean isDocumented();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\annotation\AnnotationDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */