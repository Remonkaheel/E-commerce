/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PrimitiveBoxingDelegate
/*     */ {
/*  35 */   BOOLEAN(Boolean.class, StackSize.ZERO, "valueOf", "(Z)Ljava/lang/Boolean;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   BYTE(Byte.class, StackSize.ZERO, "valueOf", "(B)Ljava/lang/Byte;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   SHORT(Short.class, StackSize.ZERO, "valueOf", "(S)Ljava/lang/Short;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   CHARACTER(Character.class, StackSize.ZERO, "valueOf", "(C)Ljava/lang/Character;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   INTEGER(Integer.class, StackSize.ZERO, "valueOf", "(I)Ljava/lang/Integer;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   LONG(Long.class, StackSize.SINGLE, "valueOf", "(J)Ljava/lang/Long;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   FLOAT(Float.class, StackSize.ZERO, "valueOf", "(F)Ljava/lang/Float;"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   DOUBLE(Double.class, StackSize.SINGLE, "valueOf", "(D)Ljava/lang/Double;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TypeDescription wrapperType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation.Size size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String boxingMethodName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String boxingMethodDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrimitiveBoxingDelegate(Class<?> wrapperType, StackSize sizeDifference, String boxingMethodName, String boxingMethodDescriptor) {
/* 104 */     this.wrapperType = TypeDescription.ForLoadedType.of(wrapperType);
/* 105 */     this.size = sizeDifference.toDecreasingSize();
/* 106 */     this.boxingMethodName = boxingMethodName;
/* 107 */     this.boxingMethodDescriptor = boxingMethodDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveBoxingDelegate forPrimitive(TypeDefinition typeDefinition) {
/* 117 */     if (typeDefinition.represents(boolean.class))
/* 118 */       return BOOLEAN; 
/* 119 */     if (typeDefinition.represents(byte.class))
/* 120 */       return BYTE; 
/* 121 */     if (typeDefinition.represents(short.class))
/* 122 */       return SHORT; 
/* 123 */     if (typeDefinition.represents(char.class))
/* 124 */       return CHARACTER; 
/* 125 */     if (typeDefinition.represents(int.class))
/* 126 */       return INTEGER; 
/* 127 */     if (typeDefinition.represents(long.class))
/* 128 */       return LONG; 
/* 129 */     if (typeDefinition.represents(float.class))
/* 130 */       return FLOAT; 
/* 131 */     if (typeDefinition.represents(double.class)) {
/* 132 */       return DOUBLE;
/*     */     }
/* 134 */     throw new IllegalArgumentException("Not a non-void, primitive type: " + typeDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation assignBoxedTo(TypeDescription.Generic target, Assigner chainedAssigner, Assigner.Typing typing) {
/* 148 */     return (StackManipulation)new BoxingStackManipulation(this, chainedAssigner.assign(this.wrapperType.asGenericType(), target, typing));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\PrimitiveBoxingDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */