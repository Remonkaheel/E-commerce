package META-INF.versions.9.net.bytebuddy.dynamic;

import net.bytebuddy.description.type.TypeDescription;

public interface Transformer<T> {
  T transform(TypeDescription paramTypeDescription, T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\Transformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */