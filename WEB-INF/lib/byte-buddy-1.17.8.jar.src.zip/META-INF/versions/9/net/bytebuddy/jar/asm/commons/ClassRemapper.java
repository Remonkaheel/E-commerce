/*     */ package META-INF.versions.9.net.bytebuddy.jar.asm.commons;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*     */ import net.bytebuddy.jar.asm.Attribute;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.ModuleVisitor;
/*     */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*     */ import net.bytebuddy.jar.asm.TypePath;
/*     */ import net.bytebuddy.jar.asm.commons.AnnotationRemapper;
/*     */ import net.bytebuddy.jar.asm.commons.FieldRemapper;
/*     */ import net.bytebuddy.jar.asm.commons.MethodRemapper;
/*     */ import net.bytebuddy.jar.asm.commons.ModuleHashesAttribute;
/*     */ import net.bytebuddy.jar.asm.commons.ModuleRemapper;
/*     */ import net.bytebuddy.jar.asm.commons.RecordComponentRemapper;
/*     */ import net.bytebuddy.jar.asm.commons.Remapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassRemapper
/*     */   extends ClassVisitor
/*     */ {
/*     */   protected final Remapper remapper;
/*     */   protected String className;
/*     */   
/*     */   public ClassRemapper(ClassVisitor classVisitor, Remapper remapper) {
/*  77 */     this(589824, classVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassRemapper(int api, ClassVisitor classVisitor, Remapper remapper) {
/*  89 */     super(api, classVisitor);
/*  90 */     this.remapper = remapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/* 101 */     this.className = name;
/* 102 */     super.visit(version, access, this.remapper
/*     */ 
/*     */         
/* 105 */         .mapType(name), this.remapper
/* 106 */         .mapSignature(signature, false), this.remapper
/* 107 */         .mapType(superName), 
/* 108 */         (interfaces == null) ? null : this.remapper.mapTypes(interfaces));
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleVisitor visitModule(String name, int flags, String version) {
/* 113 */     ModuleVisitor moduleVisitor = super.visitModule(this.remapper.mapModuleName(name), flags, version);
/* 114 */     return (moduleVisitor == null) ? null : createModuleRemapper(moduleVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 120 */     AnnotationVisitor annotationVisitor = super.visitAnnotation(this.remapper.mapDesc(descriptor), visible);
/* 121 */     return (annotationVisitor == null) ? 
/* 122 */       null : 
/* 123 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
/* 130 */     AnnotationVisitor annotationVisitor = super.visitTypeAnnotation(typeRef, typePath, this.remapper.mapDesc(descriptor), visible);
/* 131 */     return (annotationVisitor == null) ? 
/* 132 */       null : 
/* 133 */       createAnnotationRemapper(descriptor, annotationVisitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitAttribute(Attribute attribute) {
/* 138 */     if (attribute instanceof ModuleHashesAttribute) {
/* 139 */       ModuleHashesAttribute moduleHashesAttribute = (ModuleHashesAttribute)attribute;
/* 140 */       List<String> modules = moduleHashesAttribute.modules;
/* 141 */       for (int i = 0; i < modules.size(); i++) {
/* 142 */         modules.set(i, this.remapper.mapModuleName(modules.get(i)));
/*     */       }
/*     */     } 
/* 145 */     super.visitAttribute(attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecordComponentVisitor visitRecordComponent(String name, String descriptor, String signature) {
/* 152 */     RecordComponentVisitor recordComponentVisitor = super.visitRecordComponent(this.remapper
/* 153 */         .mapRecordComponentName(this.className, name, descriptor), this.remapper
/* 154 */         .mapDesc(descriptor), this.remapper
/* 155 */         .mapSignature(signature, true));
/* 156 */     return (recordComponentVisitor == null) ? 
/* 157 */       null : 
/* 158 */       createRecordComponentRemapper(recordComponentVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
/* 169 */     FieldVisitor fieldVisitor = super.visitField(access, this.remapper
/*     */         
/* 171 */         .mapFieldName(this.className, name, descriptor), this.remapper
/* 172 */         .mapDesc(descriptor), this.remapper
/* 173 */         .mapSignature(signature, true), 
/* 174 */         (value == null) ? null : this.remapper.mapValue(value));
/* 175 */     return (fieldVisitor == null) ? null : createFieldRemapper(fieldVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
/* 185 */     String remappedDescriptor = this.remapper.mapMethodDesc(descriptor);
/*     */     
/* 187 */     MethodVisitor methodVisitor = super.visitMethod(access, this.remapper
/*     */         
/* 189 */         .mapMethodName(this.className, name, descriptor), remappedDescriptor, this.remapper
/*     */         
/* 191 */         .mapSignature(signature, false), 
/* 192 */         (exceptions == null) ? null : this.remapper.mapTypes(exceptions));
/* 193 */     return (methodVisitor == null) ? null : createMethodRemapper(methodVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitInnerClass(String name, String outerName, String innerName, int access) {
/* 199 */     super.visitInnerClass(this.remapper
/* 200 */         .mapType(name), 
/* 201 */         (outerName == null) ? null : this.remapper.mapType(outerName), 
/* 202 */         (innerName == null) ? null : this.remapper.mapInnerClassName(name, outerName, innerName), access);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void visitOuterClass(String owner, String name, String descriptor) {
/* 208 */     super.visitOuterClass(this.remapper
/* 209 */         .mapType(owner), 
/* 210 */         (name == null) ? null : this.remapper.mapMethodName(owner, name, descriptor), 
/* 211 */         (descriptor == null) ? null : this.remapper.mapMethodDesc(descriptor));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNestHost(String nestHost) {
/* 216 */     super.visitNestHost(this.remapper.mapType(nestHost));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNestMember(String nestMember) {
/* 221 */     super.visitNestMember(this.remapper.mapType(nestMember));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitPermittedSubclass(String permittedSubclass) {
/* 226 */     super.visitPermittedSubclass(this.remapper.mapType(permittedSubclass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldVisitor createFieldRemapper(FieldVisitor fieldVisitor) {
/* 237 */     return (FieldVisitor)new FieldRemapper(this.api, fieldVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodVisitor createMethodRemapper(MethodVisitor methodVisitor) {
/* 248 */     return (MethodVisitor)new MethodRemapper(this.api, methodVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AnnotationVisitor createAnnotationRemapper(AnnotationVisitor annotationVisitor) {
/* 261 */     return (AnnotationVisitor)new AnnotationRemapper(this.api, null, annotationVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationVisitor createAnnotationRemapper(String descriptor, AnnotationVisitor annotationVisitor) {
/* 274 */     return (new AnnotationRemapper(this.api, descriptor, annotationVisitor, this.remapper))
/* 275 */       .orDeprecatedValue(createAnnotationRemapper(annotationVisitor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleVisitor createModuleRemapper(ModuleVisitor moduleVisitor) {
/* 286 */     return (ModuleVisitor)new ModuleRemapper(this.api, moduleVisitor, this.remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RecordComponentVisitor createRecordComponentRemapper(RecordComponentVisitor recordComponentVisitor) {
/* 298 */     return (RecordComponentVisitor)new RecordComponentRemapper(this.api, recordComponentVisitor, this.remapper);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\jar\asm\commons\ClassRemapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */