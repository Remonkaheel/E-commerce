/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Queue;
/*    */ import java.util.Set;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.QueueFactory;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class HasSuperTypeMatcher<T extends TypeDescription>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<T>
/*    */ {
/*    */   private final ElementMatcher<? super TypeDescription.Generic> matcher;
/*    */   
/*    */   public HasSuperTypeMatcher(ElementMatcher<? super TypeDescription.Generic> matcher) {
/* 46 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doMatch(T target) {
/* 53 */     Set<TypeDescription> previous = new HashSet<>();
/* 54 */     for (TypeDefinition typeDefinition : target) {
/* 55 */       if (!previous.add(typeDefinition.asErasure()))
/* 56 */         return false; 
/* 57 */       if (this.matcher.matches(typeDefinition.asGenericType())) {
/* 58 */         return true;
/*    */       }
/* 60 */       Queue<TypeDefinition> interfaceTypes = QueueFactory.make((Collection)typeDefinition.getInterfaces());
/* 61 */       while (!interfaceTypes.isEmpty()) {
/* 62 */         TypeDefinition interfaceType = interfaceTypes.remove();
/* 63 */         if (previous.add(interfaceType.asErasure())) {
/* 64 */           if (this.matcher.matches(interfaceType.asGenericType())) {
/* 65 */             return true;
/*    */           }
/* 67 */           interfaceTypes.addAll((Collection<? extends TypeDefinition>)interfaceType.getInterfaces());
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 72 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 77 */     return "hasSuperType(" + this.matcher + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.matcher.equals(((net.bytebuddy.matcher.HasSuperTypeMatcher)paramObject).matcher)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return super.hashCode() * 31 + this.matcher.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\HasSuperTypeMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */