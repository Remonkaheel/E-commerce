/*     */ package META-INF.versions.9.net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.loading.ClassFilePostProcessor;
/*     */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*     */ import net.bytebuddy.dynamic.loading.InjectionClassLoader;
/*     */ import net.bytebuddy.dynamic.loading.PackageDefinitionStrategy;
/*     */ import net.bytebuddy.utility.GraalImageCode;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArrayClassLoader
/*     */   extends InjectionClassLoader
/*     */ {
/*     */   public static final String URL_SCHEMA = "bytebuddy";
/*     */   private static final int FROM_BEGINNING = 0;
/*     */   @AlwaysNull
/*  73 */   private static final URL NO_URL = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final PackageLookupStrategy PACKAGE_LOOKUP_STRATEGY = doPrivileged((PrivilegedAction<PackageLookupStrategy>)PackageLookupStrategy.CreationAction.INSTANCE); protected final ConcurrentMap<String, byte[]> typeDefinitions;
/*     */   protected final PersistenceHandler persistenceHandler;
/*     */   @MaybeNull
/*     */   protected final ProtectionDomain protectionDomain;
/*     */   protected final PackageDefinitionStrategy packageDefinitionStrategy;
/*  83 */   protected static final SynchronizationStrategy.Initializable SYNCHRONIZATION_STRATEGY = doPrivileged((PrivilegedAction<SynchronizationStrategy.Initializable>)SynchronizationStrategy.CreationAction.INSTANCE); protected final ClassFilePostProcessor classFilePostProcessor;
/*     */   @MaybeNull
/*     */   protected final Object accessControlContext;
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */   
/*     */   static {
/*  89 */     doRegisterAsParallelCapable(); } static { 
/*  90 */     try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Must be invoked from targeting class loader type.")
/*     */   private static void doRegisterAsParallelCapable() {
/*     */     try {
/*  98 */       Method method = ClassLoader.class.getDeclaredMethod("registerAsParallelCapable", new Class[0]);
/*  99 */       method.setAccessible(true);
/* 100 */       method.invoke(null, new Object[0]);
/* 101 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 115 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions) {
/* 157 */     this(parent, true, typeDefinitions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions) {
/* 168 */     this(parent, sealed, typeDefinitions, PersistenceHandler.LATENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, PersistenceHandler persistenceHandler) {
/* 179 */     this(parent, true, typeDefinitions, persistenceHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, PersistenceHandler persistenceHandler) {
/* 191 */     this(parent, sealed, typeDefinitions, ClassLoadingStrategy.NO_PROTECTION_DOMAIN, persistenceHandler, (PackageDefinitionStrategy)PackageDefinitionStrategy.Trivial.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy) {
/* 208 */     this(parent, true, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy) {
/* 227 */     this(parent, sealed, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy, (ClassFilePostProcessor)ClassFilePostProcessor.NoOp.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, ClassFilePostProcessor classFilePostProcessor) {
/* 246 */     this(parent, true, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy, classFilePostProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, ClassFilePostProcessor classFilePostProcessor) {
/* 267 */     super(parent, sealed);
/* 268 */     this.typeDefinitions = (ConcurrentMap)new ConcurrentHashMap<>((Map)typeDefinitions);
/* 269 */     this.protectionDomain = protectionDomain;
/* 270 */     this.persistenceHandler = persistenceHandler;
/* 271 */     this.packageDefinitionStrategy = packageDefinitionStrategy;
/* 272 */     this.classFilePostProcessor = classFilePostProcessor;
/* 273 */     this.accessControlContext = getContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   @Enhance
/*     */   private static Object getContext() {
/* 284 */     return ACCESS_CONTROLLER ? AccessController.getContext() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action, @MaybeNull Object context) {
/* 297 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0, (AccessControlContext)SYNTHETIC_LOCAL_VARIABLE_1) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object methodHandle() throws Exception {
/* 307 */     return Class.forName("java.lang.invoke.MethodHandles").getMethod("lookup", new Class[0]).invoke(null, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 318 */     return load(classLoader, types, ClassLoadingStrategy.NO_PROTECTION_DOMAIN, PersistenceHandler.LATENT, (PackageDefinitionStrategy)PackageDefinitionStrategy.Trivial.INSTANCE, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"DP_CREATE_CLASSLOADER_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*     */   public static Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, boolean forbidExisting, boolean sealed) {
/* 347 */     Map<String, byte[]> typesByName = (Map)new HashMap<>();
/* 348 */     for (Map.Entry<TypeDescription, byte[]> entry : types.entrySet()) {
/* 349 */       typesByName.put(((TypeDescription)entry.getKey()).getName(), entry.getValue());
/*     */     }
/* 351 */     net.bytebuddy.dynamic.loading.ByteArrayClassLoader byteArrayClassLoader = new net.bytebuddy.dynamic.loading.ByteArrayClassLoader(classLoader, sealed, typesByName, protectionDomain, persistenceHandler, packageDefinitionStrategy, (ClassFilePostProcessor)ClassFilePostProcessor.NoOp.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 358 */     Map<TypeDescription, Class<?>> result = new LinkedHashMap<>();
/* 359 */     for (TypeDescription typeDescription : types.keySet()) {
/*     */       try {
/* 361 */         Class<?> type = Class.forName(typeDescription.getName(), false, (ClassLoader)byteArrayClassLoader);
/* 362 */         if (!GraalImageCode.getCurrent().isNativeImageExecution() && forbidExisting && type.getClassLoader() != byteArrayClassLoader) {
/* 363 */           throw new IllegalStateException("Class already loaded: " + type);
/*     */         }
/* 365 */         result.put(typeDescription, type);
/* 366 */       } catch (ClassNotFoundException exception) {
/* 367 */         throw new IllegalStateException("Cannot load class " + typeDescription, exception);
/*     */       } 
/*     */     } 
/* 370 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, Class<?>> doDefineClasses(Map<String, byte[]> typeDefinitions) throws ClassNotFoundException {
/* 375 */     Map<String, byte[]> previous = (Map)new HashMap<>();
/* 376 */     for (Map.Entry<String, byte[]> entry : typeDefinitions.entrySet()) {
/* 377 */       previous.put(entry.getKey(), this.typeDefinitions.putIfAbsent(entry.getKey(), entry.getValue()));
/*     */     }
/*     */     try {
/* 380 */       Map<String, Class<?>> types = new LinkedHashMap<>();
/* 381 */       for (String name : typeDefinitions.keySet()) {
/* 382 */         synchronized (SYNCHRONIZATION_STRATEGY.initialize().getClassLoadingLock(this, name)) {
/* 383 */           types.put(name, loadClass(name));
/*     */         } 
/*     */       } 
/* 386 */       return types;
/*     */     } finally {
/* 388 */       for (Map.Entry<String, byte[]> entry : previous.entrySet()) {
/* 389 */         if (entry.getValue() == null) {
/* 390 */           this.persistenceHandler.release(entry.getKey(), this.typeDefinitions); continue;
/*     */         } 
/* 392 */         this.typeDefinitions.put(entry.getKey(), entry.getValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> findClass(String name) throws ClassNotFoundException {
/* 402 */     byte[] binaryRepresentation = this.persistenceHandler.lookup(name, this.typeDefinitions);
/* 403 */     if (binaryRepresentation == null) {
/* 404 */       throw new ClassNotFoundException(name);
/*     */     }
/* 406 */     return doPrivileged((PrivilegedAction<Class<?>>)new ClassDefinitionAction(this, name, this.classFilePostProcessor.transform((ClassLoader)this, name, this.protectionDomain, binaryRepresentation)), this.accessControlContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   protected URL findResource(String name) {
/* 418 */     return this.persistenceHandler.url(name, this.typeDefinitions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Enumeration<URL> findResources(String name) {
/* 425 */     URL url = this.persistenceHandler.url(name, this.typeDefinitions);
/* 426 */     return (url == null) ? (Enumeration<URL>)EmptyEnumeration.INSTANCE : (Enumeration<URL>)new SingletonEnumeration(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   private Package doGetPackage(String name) {
/* 440 */     return getPackage(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\ByteArrayClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */