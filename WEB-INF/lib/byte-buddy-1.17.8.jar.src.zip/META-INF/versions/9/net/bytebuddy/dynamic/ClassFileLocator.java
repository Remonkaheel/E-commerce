package META-INF.versions.9.net.bytebuddy.dynamic;

import java.io.Closeable;
import java.io.IOException;

public interface ClassFileLocator extends Closeable {
  public static final String CLASS_FILE_EXTENSION = ".class";
  
  public static final String META_INF_VERSIONS = "META-INF/versions/";
  
  Resolution locate(String paramString) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\ClassFileLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */