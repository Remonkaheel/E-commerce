/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.reference;
/*    */ 
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*    */ import net.bytebuddy.implementation.bytecode.assign.TypeCasting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum GenericTypeAwareAssigner
/*    */   implements Assigner
/*    */ {
/* 42 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation assign(TypeDescription.Generic source, TypeDescription.Generic target, Assigner.Typing typing) {
/* 48 */     if (source.isPrimitive() || target.isPrimitive()) {
/* 49 */       return source.equals(target) ? (StackManipulation)StackManipulation.Trivial.INSTANCE : (StackManipulation)StackManipulation.Illegal.INSTANCE;
/*    */     }
/*    */     
/* 52 */     if (((Boolean)source.accept((TypeDescription.Generic.Visitor)new IsAssignableToVisitor(target))).booleanValue())
/* 53 */       return (StackManipulation)StackManipulation.Trivial.INSTANCE; 
/* 54 */     if (typing.isDynamic()) {
/* 55 */       return source.asErasure().isAssignableTo(target.asErasure()) ? (StackManipulation)StackManipulation.Trivial.INSTANCE : 
/*    */         
/* 57 */         TypeCasting.to((TypeDefinition)target);
/*    */     }
/* 59 */     return (StackManipulation)StackManipulation.Illegal.INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\reference\GenericTypeAwareAssigner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */