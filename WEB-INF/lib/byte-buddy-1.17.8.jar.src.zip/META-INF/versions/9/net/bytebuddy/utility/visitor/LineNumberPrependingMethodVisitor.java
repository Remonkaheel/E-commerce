/*    */ package META-INF.versions.9.net.bytebuddy.utility.visitor;
/*    */ 
/*    */ import net.bytebuddy.jar.asm.Label;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.OpenedClassReader;
/*    */ import net.bytebuddy.utility.visitor.ExceptionTableSensitiveMethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineNumberPrependingMethodVisitor
/*    */   extends ExceptionTableSensitiveMethodVisitor
/*    */ {
/*    */   private final Label startOfMethod;
/*    */   private boolean prependLineNumber;
/*    */   
/*    */   public LineNumberPrependingMethodVisitor(MethodVisitor methodVisitor) {
/* 43 */     super(OpenedClassReader.ASM_API, methodVisitor);
/* 44 */     this.startOfMethod = new Label();
/* 45 */     this.prependLineNumber = true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void onAfterExceptionTable() {
/* 50 */     visitLabel(this.startOfMethod);
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitLineNumber(int line, Label start) {
/* 55 */     if (this.prependLineNumber) {
/* 56 */       start = this.startOfMethod;
/* 57 */       this.prependLineNumber = false;
/*    */     } 
/* 59 */     super.visitLineNumber(line, start);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\visitor\LineNumberPrependingMethodVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */