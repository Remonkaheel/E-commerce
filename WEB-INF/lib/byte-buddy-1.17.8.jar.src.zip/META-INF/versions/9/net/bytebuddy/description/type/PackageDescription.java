/*    */ package META-INF.versions.9.net.bytebuddy.description.type;
/*    */ 
/*    */ import net.bytebuddy.description.NamedElement;
/*    */ import net.bytebuddy.description.annotation.AnnotationSource;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PackageDescription
/*    */   extends NamedElement.WithRuntimeName, AnnotationSource
/*    */ {
/* 33 */   public static final net.bytebuddy.description.type.PackageDescription DEFAULT = (net.bytebuddy.description.type.PackageDescription)new Simple("");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final String PACKAGE_CLASS_NAME = "package-info";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final int PACKAGE_MODIFIERS = 5632;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @AlwaysNull
/* 49 */   public static final net.bytebuddy.description.type.PackageDescription UNDEFINED = null;
/*    */   
/*    */   boolean contains(TypeDescription paramTypeDescription);
/*    */   
/*    */   boolean isDefault();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\type\PackageDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */