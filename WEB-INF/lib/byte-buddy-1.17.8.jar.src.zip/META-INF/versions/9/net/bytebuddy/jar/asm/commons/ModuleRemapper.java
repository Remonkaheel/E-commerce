/*     */ package META-INF.versions.9.net.bytebuddy.jar.asm.commons;
/*     */ 
/*     */ import net.bytebuddy.jar.asm.ModuleVisitor;
/*     */ import net.bytebuddy.jar.asm.commons.Remapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleRemapper
/*     */   extends ModuleVisitor
/*     */ {
/*     */   protected final Remapper remapper;
/*     */   
/*     */   public ModuleRemapper(ModuleVisitor moduleVisitor, Remapper remapper) {
/*  52 */     this(589824, moduleVisitor, remapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleRemapper(int api, ModuleVisitor moduleVisitor, Remapper remapper) {
/*  65 */     super(api, moduleVisitor);
/*  66 */     this.remapper = remapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitMainClass(String mainClass) {
/*  71 */     super.visitMainClass(this.remapper.mapType(mainClass));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitPackage(String packaze) {
/*  76 */     super.visitPackage(this.remapper.mapPackageName(packaze));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitRequire(String module, int access, String version) {
/*  81 */     super.visitRequire(this.remapper.mapModuleName(module), access, version);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitExport(String packaze, int access, String... modules) {
/*  86 */     String[] remappedModules = null;
/*  87 */     if (modules != null) {
/*  88 */       remappedModules = new String[modules.length];
/*  89 */       for (int i = 0; i < modules.length; i++) {
/*  90 */         remappedModules[i] = this.remapper.mapModuleName(modules[i]);
/*     */       }
/*     */     } 
/*  93 */     super.visitExport(this.remapper.mapPackageName(packaze), access, remappedModules);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitOpen(String packaze, int access, String... modules) {
/*  98 */     String[] remappedModules = null;
/*  99 */     if (modules != null) {
/* 100 */       remappedModules = new String[modules.length];
/* 101 */       for (int i = 0; i < modules.length; i++) {
/* 102 */         remappedModules[i] = this.remapper.mapModuleName(modules[i]);
/*     */       }
/*     */     } 
/* 105 */     super.visitOpen(this.remapper.mapPackageName(packaze), access, remappedModules);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitUse(String service) {
/* 110 */     super.visitUse(this.remapper.mapType(service));
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitProvide(String service, String... providers) {
/* 115 */     String[] remappedProviders = new String[providers.length];
/* 116 */     for (int i = 0; i < providers.length; i++) {
/* 117 */       remappedProviders[i] = this.remapper.mapType(providers[i]);
/*     */     }
/* 119 */     super.visitProvide(this.remapper.mapType(service), remappedProviders);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\jar\asm\commons\ModuleRemapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */