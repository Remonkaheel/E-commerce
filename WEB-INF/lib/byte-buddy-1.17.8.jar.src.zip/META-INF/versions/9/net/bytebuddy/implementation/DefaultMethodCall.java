/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class DefaultMethodCall
/*     */   implements Implementation
/*     */ {
/*     */   private final List<TypeDescription> prioritizedInterfaces;
/*     */   
/*     */   protected DefaultMethodCall(List<TypeDescription> prioritizedInterfaces) {
/*  64 */     this.prioritizedInterfaces = prioritizedInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation prioritize(Class<?>... prioritizedInterface) {
/*  79 */     return prioritize((Collection<? extends TypeDescription>)new TypeList.ForLoadedTypes(prioritizedInterface));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation prioritize(Iterable<? extends Class<?>> prioritizedInterfaces) {
/*  94 */     List<Class<?>> list = new ArrayList<>();
/*  95 */     for (Class<?> prioritizedInterface : prioritizedInterfaces) {
/*  96 */       list.add(prioritizedInterface);
/*     */     }
/*  98 */     return prioritize((Collection<? extends TypeDescription>)new TypeList.ForLoadedTypes(list));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation prioritize(TypeDescription... prioritizedInterface) {
/* 113 */     return prioritize(Arrays.asList(prioritizedInterface));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation prioritize(Collection<? extends TypeDescription> prioritizedInterfaces) {
/* 128 */     return new net.bytebuddy.implementation.DefaultMethodCall(new ArrayList<>(prioritizedInterfaces));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Implementation unambiguousOnly() {
/* 141 */     return new net.bytebuddy.implementation.DefaultMethodCall(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 148 */     return instrumentedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 155 */     return (ByteCodeAppender)new Appender(implementationTarget, filterRelevant(implementationTarget.getInstrumentedType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<TypeDescription> filterRelevant(TypeDescription typeDescription) {
/* 166 */     List<TypeDescription> filtered = new ArrayList<>(this.prioritizedInterfaces.size());
/* 167 */     Set<TypeDescription> relevant = new HashSet<>((Collection<? extends TypeDescription>)typeDescription.getInterfaces().asErasures());
/* 168 */     for (TypeDescription prioritizedInterface : this.prioritizedInterfaces) {
/* 169 */       if (relevant.remove(prioritizedInterface)) {
/* 170 */         filtered.add(prioritizedInterface);
/*     */       }
/*     */     } 
/* 173 */     return filtered;
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.prioritizedInterfaces.equals(((net.bytebuddy.implementation.DefaultMethodCall)paramObject).prioritizedInterfaces))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return getClass().hashCode() * 31 + this.prioritizedInterfaces.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\DefaultMethodCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */