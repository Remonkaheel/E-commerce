package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;

import net.bytebuddy.utility.nullability.NeverNull.ByDefault;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */