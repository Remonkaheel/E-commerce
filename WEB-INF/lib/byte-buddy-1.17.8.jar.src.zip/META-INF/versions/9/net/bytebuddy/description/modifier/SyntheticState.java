/*    */ package META-INF.versions.9.net.bytebuddy.description.modifier;
/*    */ 
/*    */ import net.bytebuddy.description.modifier.ModifierContributor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SyntheticState
/*    */   implements ModifierContributor.ForType, ModifierContributor.ForMethod, ModifierContributor.ForField, ModifierContributor.ForParameter
/*    */ {
/* 31 */   PLAIN(0),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   SYNTHETIC(4096);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final int mask;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SyntheticState(int mask) {
/* 49 */     this.mask = mask;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMask() {
/* 56 */     return this.mask;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getRange() {
/* 63 */     return 4096;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isDefault() {
/* 70 */     return (this == PLAIN);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSynthetic() {
/* 79 */     return (this == SYNTHETIC);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\modifier\SyntheticState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */