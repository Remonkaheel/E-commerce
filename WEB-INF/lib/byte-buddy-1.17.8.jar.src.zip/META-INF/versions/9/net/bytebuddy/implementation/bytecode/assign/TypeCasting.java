/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.StackSize;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class TypeCasting
/*    */   extends StackManipulation.AbstractBase
/*    */ {
/*    */   private final TypeDescription typeDescription;
/*    */   
/*    */   protected TypeCasting(TypeDescription typeDescription) {
/* 45 */     this.typeDescription = typeDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StackManipulation to(TypeDefinition typeDefinition) {
/* 55 */     if (typeDefinition.isPrimitive()) {
/* 56 */       throw new IllegalArgumentException("Cannot cast to primitive type: " + typeDefinition);
/*    */     }
/* 58 */     return (StackManipulation)new net.bytebuddy.implementation.bytecode.assign.TypeCasting(typeDefinition.asErasure());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 65 */     methodVisitor.visitTypeInsn(192, this.typeDescription.getInternalName());
/* 66 */     return StackSize.ZERO.toIncreasingSize();
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.typeDescription.equals(((net.bytebuddy.implementation.bytecode.assign.TypeCasting)paramObject).typeDescription))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\TypeCasting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */