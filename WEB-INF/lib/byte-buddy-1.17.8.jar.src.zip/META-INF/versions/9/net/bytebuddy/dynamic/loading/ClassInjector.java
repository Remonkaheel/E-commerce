package META-INF.versions.9.net.bytebuddy.dynamic.loading;

import java.util.Map;
import java.util.Set;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.ClassFileLocator;

public interface ClassInjector {
  public static final boolean ALLOW_EXISTING_TYPES = false;
  
  boolean isAlive();
  
  Map<TypeDescription, Class<?>> inject(Set<? extends TypeDescription> paramSet, ClassFileLocator paramClassFileLocator);
  
  Map<String, Class<?>> injectRaw(Set<String> paramSet, ClassFileLocator paramClassFileLocator);
  
  Map<TypeDescription, Class<?>> inject(Map<? extends TypeDescription, byte[]> paramMap);
  
  Map<String, Class<?>> injectRaw(Map<String, byte[]> paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\ClassInjector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */