/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.member;
/*     */ 
/*     */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum FieldAccess
/*     */ {
/*  40 */   STATIC(179, 178, StackSize.ZERO),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   INSTANCE(181, 180, StackSize.SINGLE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int putterOpcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int getterOpcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int targetSizeChange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FieldAccess(int putterOpcode, int getterOpcode, StackSize targetSizeChange) {
/*  72 */     this.putterOpcode = putterOpcode;
/*  73 */     this.getterOpcode = getterOpcode;
/*  74 */     this.targetSizeChange = targetSizeChange.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation forEnumeration(EnumerationDescription enumerationDescription) {
/*  86 */     FieldList<FieldDescription.InDefinedShape> fieldList = (FieldList<FieldDescription.InDefinedShape>)enumerationDescription.getEnumerationType().getDeclaredFields().filter((ElementMatcher)ElementMatchers.named(enumerationDescription.getValue()));
/*  87 */     STATIC.getClass(); return (fieldList.size() != 1 || !((FieldDescription.InDefinedShape)fieldList.getOnly()).isStatic() || !((FieldDescription.InDefinedShape)fieldList.getOnly()).isPublic() || !((FieldDescription.InDefinedShape)fieldList.getOnly()).isEnum()) ? (StackManipulation)StackManipulation.Illegal.INSTANCE : (new AccessDispatcher(STATIC, (FieldDescription.InDefinedShape)fieldList
/*     */         
/*  89 */         .getOnly())).read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Defined forField(FieldDescription.InDefinedShape fieldDescription) {
/*  99 */     STATIC.getClass(); INSTANCE.getClass(); return fieldDescription.isStatic() ? (Defined)new AccessDispatcher(STATIC, fieldDescription) : (Defined)new AccessDispatcher(INSTANCE, fieldDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Defined forField(FieldDescription fieldDescription) {
/* 112 */     FieldDescription.InDefinedShape declaredField = (FieldDescription.InDefinedShape)fieldDescription.asDefined();
/* 113 */     return fieldDescription.getType().asErasure().equals(declaredField.getType().asErasure()) ? 
/* 114 */       forField(declaredField) : 
/* 115 */       OfGenericField.of(fieldDescription, forField(declaredField));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\member\FieldAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */