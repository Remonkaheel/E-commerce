/*    */ package META-INF.versions.9.net.bytebuddy.implementation.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AnnotationRetention
/*    */ {
/* 29 */   ENABLED(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   DISABLED(false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final boolean enabled;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   AnnotationRetention(boolean enabled) {
/* 47 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static net.bytebuddy.implementation.attribute.AnnotationRetention of(boolean enabled) {
/* 57 */     return enabled ? ENABLED : DISABLED;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 68 */     return this.enabled;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\AnnotationRetention.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */