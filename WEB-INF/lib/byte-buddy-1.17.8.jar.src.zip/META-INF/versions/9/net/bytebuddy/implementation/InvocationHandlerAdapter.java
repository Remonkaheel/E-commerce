/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.dynamic.scaffold.FieldLocator;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.Removal;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.implementation.bytecode.collection.ArrayFactory;
/*     */ import net.bytebuddy.implementation.bytecode.constant.MethodConstant;
/*     */ import net.bytebuddy.implementation.bytecode.constant.NullConstant;
/*     */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.RandomString;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public abstract class InvocationHandlerAdapter
/*     */   implements Implementation.Composable
/*     */ {
/*     */   private static final TypeDescription.Generic INVOCATION_HANDLER_TYPE;
/*     */   private static final boolean UNCACHED = false;
/*     */   private static final boolean CACHED = true;
/*     */   private static final boolean UNPRIVILEGED = false;
/*     */   private static final boolean PRIVILEGED = true;
/*     */   private static final boolean RETURNING = true;
/*     */   private static final boolean DROPPING = false;
/*     */   protected final String fieldName;
/*     */   protected final boolean cached;
/*     */   protected final boolean privileged;
/*     */   protected final boolean returning;
/*     */   protected final Assigner assigner;
/*     */   
/*     */   protected InvocationHandlerAdapter(String fieldName, boolean cached, boolean privileged, boolean returning, Assigner assigner) {
/* 126 */     this.fieldName = fieldName;
/* 127 */     this.cached = cached;
/* 128 */     this.privileged = privileged;
/* 129 */     this.returning = returning;
/* 130 */     this.assigner = assigner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.InvocationHandlerAdapter of(InvocationHandler invocationHandler) {
/* 141 */     return of(invocationHandler, "invocationHandler$" + RandomString.hashOf(invocationHandler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.InvocationHandlerAdapter of(InvocationHandler invocationHandler, String fieldName) {
/* 153 */     return (net.bytebuddy.implementation.InvocationHandlerAdapter)new ForInstance(fieldName, true, false, true, Assigner.DEFAULT, invocationHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.InvocationHandlerAdapter toField(String name) {
/* 166 */     return toField(name, (FieldLocator.Factory)FieldLocator.ForClassHierarchy.Factory.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.InvocationHandlerAdapter toField(String name, FieldLocator.Factory fieldLocatorFactory) {
/* 180 */     return (net.bytebuddy.implementation.InvocationHandlerAdapter)new ForField(name, true, false, true, Assigner.DEFAULT, fieldLocatorFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<StackManipulation> argumentValuesOf(MethodDescription instrumentedMethod) {
/* 190 */     TypeList.Generic parameterTypes = instrumentedMethod.getParameters().asTypeList();
/* 191 */     List<StackManipulation> instruction = new ArrayList<>(parameterTypes.size());
/* 192 */     int currentIndex = 1;
/* 193 */     for (TypeDescription.Generic parameterType : parameterTypes) {
/* 194 */       instruction.add(new StackManipulation.Compound(new StackManipulation[] {
/* 195 */               MethodVariableAccess.of((TypeDefinition)parameterType).loadFrom(currentIndex), this.assigner
/* 196 */               .assign(parameterType, TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), Assigner.Typing.STATIC) }));
/* 197 */       currentIndex += parameterType.getStackSize().getSize();
/*     */     } 
/* 199 */     return instruction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod, StackManipulation preparingManipulation, FieldDescription fieldDescription) {
/* 241 */     if (instrumentedMethod.isStatic() || instrumentedMethod.isConstructor()) {
/* 242 */       throw new IllegalStateException("It is not possible to apply an invocation handler onto the static method or constructor " + instrumentedMethod);
/*     */     }
/*     */ 
/*     */     
/* 246 */     MethodConstant.CanCache methodConstant = this.privileged ? MethodConstant.ofPrivileged((MethodDescription.InDefinedShape)instrumentedMethod.asDefined()) : MethodConstant.of((MethodDescription.InDefinedShape)instrumentedMethod.asDefined());
/* 247 */     (new StackManipulation[7])[0] = preparingManipulation; (new StackManipulation[7])[1] = 
/*     */       
/* 249 */       FieldAccess.forField(fieldDescription).read(); (new StackManipulation[7])[2] = 
/* 250 */       MethodVariableAccess.loadThis(); (new StackManipulation[7])[3] = this.cached ? methodConstant
/* 251 */       .cached() : (StackManipulation)methodConstant; (new StackManipulation[7])[4] = 
/* 252 */       instrumentedMethod.getParameters().isEmpty() ? (StackManipulation)NullConstant.INSTANCE : 
/*     */       
/* 254 */       ArrayFactory.forType(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)).withValues(argumentValuesOf(instrumentedMethod)); (new StackManipulation[7])[5] = 
/* 255 */       (StackManipulation)MethodInvocation.invoke((MethodDescription)((MethodList)INVOCATION_HANDLER_TYPE.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isAbstract())).getOnly()); if (this.returning) {
/*     */     
/*     */     } else {
/*     */     
/* 259 */     }  StackManipulation.Size stackSize = (new StackManipulation.Compound(new StackManipulation[] { null, null, null, null, null, null, (StackManipulation)Removal.SINGLE })).apply(methodVisitor, implementationContext);
/* 260 */     return new ByteCodeAppender.Size(stackSize.getMaximalSize(), instrumentedMethod.getStackSize());
/*     */   }
/*     */   
/*     */   public abstract WithoutPrivilegeConfiguration withoutMethodCache();
/*     */   
/*     */   public abstract Implementation withAssigner(Assigner paramAssigner);
/*     */   
/*     */   public abstract AssignerConfigurable withPrivilegedLookup();
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.cached != ((net.bytebuddy.implementation.InvocationHandlerAdapter)paramObject).cached) ? false : ((this.privileged != ((net.bytebuddy.implementation.InvocationHandlerAdapter)paramObject).privileged) ? false : ((this.returning != ((net.bytebuddy.implementation.InvocationHandlerAdapter)paramObject).returning) ? false : (!this.fieldName.equals(((net.bytebuddy.implementation.InvocationHandlerAdapter)paramObject).fieldName) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.InvocationHandlerAdapter)paramObject).assigner))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.fieldName.hashCode()) * 31 + this.cached) * 31 + this.privileged) * 31 + this.returning) * 31 + this.assigner.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\InvocationHandlerAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */