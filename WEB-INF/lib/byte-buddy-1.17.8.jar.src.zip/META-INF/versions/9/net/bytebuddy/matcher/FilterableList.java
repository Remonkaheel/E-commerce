package META-INF.versions.9.net.bytebuddy.matcher;

import java.util.List;
import net.bytebuddy.matcher.ElementMatcher;

public interface FilterableList<T, S extends net.bytebuddy.matcher.FilterableList<T, S>> extends List<T> {
  S filter(ElementMatcher<? super T> paramElementMatcher);
  
  T getOnly();
  
  S subList(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\FilterableList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */