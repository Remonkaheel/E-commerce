/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import java.util.Collection;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class CollectionSizeMatcher<T extends Iterable<?>>
/*    */   extends ElementMatcher.Junction.ForNonNullValues<T>
/*    */ {
/*    */   private final int size;
/*    */   
/*    */   public CollectionSizeMatcher(int size) {
/* 42 */     this.size = size;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressFBWarnings(value = {"DLS_DEAD_LOCAL_STORE"}, justification = "Iteration required to count size of an iterable.")
/*    */   protected boolean doMatch(T target) {
/* 50 */     if (target instanceof Collection) {
/* 51 */       return (((Collection)target).size() == this.size);
/*    */     }
/* 53 */     int size = 0;
/* 54 */     for (Object ignored : target) {
/* 55 */       size++;
/*    */     }
/* 57 */     return (size == this.size);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return "ofSize(" + this.size + ')';
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!(this.size != ((net.bytebuddy.matcher.CollectionSizeMatcher)paramObject).size)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return super.hashCode() * 31 + this.size;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\CollectionSizeMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */