/*     */ package META-INF.versions.9.net.bytebuddy;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.ClassFileLocator;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassFileVersion
/*     */   implements Comparable<ClassFileVersion>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int BASE_VERSION = 44;
/*  50 */   public static final ClassFileVersion JAVA_V1 = new ClassFileVersion(196653);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final ClassFileVersion JAVA_V2 = new ClassFileVersion(46);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ClassFileVersion JAVA_V3 = new ClassFileVersion(47);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final ClassFileVersion JAVA_V4 = new ClassFileVersion(48);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final ClassFileVersion JAVA_V5 = new ClassFileVersion(49);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static final ClassFileVersion JAVA_V6 = new ClassFileVersion(50);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final ClassFileVersion JAVA_V7 = new ClassFileVersion(51);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static final ClassFileVersion JAVA_V8 = new ClassFileVersion(52);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final ClassFileVersion JAVA_V9 = new ClassFileVersion(53);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static final ClassFileVersion JAVA_V10 = new ClassFileVersion(54);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public static final ClassFileVersion JAVA_V11 = new ClassFileVersion(55);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static final ClassFileVersion JAVA_V12 = new ClassFileVersion(56);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public static final ClassFileVersion JAVA_V13 = new ClassFileVersion(57);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final ClassFileVersion JAVA_V14 = new ClassFileVersion(58);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public static final ClassFileVersion JAVA_V15 = new ClassFileVersion(59);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static final ClassFileVersion JAVA_V16 = new ClassFileVersion(60);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public static final ClassFileVersion JAVA_V17 = new ClassFileVersion(61);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public static final ClassFileVersion JAVA_V18 = new ClassFileVersion(62);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public static final ClassFileVersion JAVA_V19 = new ClassFileVersion(63);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public static final ClassFileVersion JAVA_V20 = new ClassFileVersion(64);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public static final ClassFileVersion JAVA_V21 = new ClassFileVersion(65);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static final ClassFileVersion JAVA_V22 = new ClassFileVersion(66);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public static final ClassFileVersion JAVA_V23 = new ClassFileVersion(67);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public static final ClassFileVersion JAVA_V24 = new ClassFileVersion(68);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public static final ClassFileVersion JAVA_V25 = new ClassFileVersion(69);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public static final ClassFileVersion JAVA_V26 = new ClassFileVersion(70);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   private static final ClassFileVersion[] CLASS_FILE_VERSIONS = new ClassFileVersion[] { JAVA_V1, JAVA_V2, JAVA_V3, JAVA_V4, JAVA_V5, JAVA_V6, JAVA_V7, JAVA_V8, JAVA_V9, JAVA_V10, JAVA_V11, JAVA_V12, JAVA_V13, JAVA_V14, JAVA_V15, JAVA_V16, JAVA_V17, JAVA_V18, JAVA_V19, JAVA_V20, JAVA_V21, JAVA_V22, JAVA_V23, JAVA_V24, JAVA_V25, JAVA_V26 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   private static final VersionLocator VERSION_LOCATOR = doPrivileged((PrivilegedAction<VersionLocator>)VersionLocator.Resolver.INSTANCE); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int versionNumber;
/*     */ 
/*     */   
/*     */   private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */   
/*     */   protected ClassFileVersion(int versionNumber) {
/* 223 */     this.versionNumber = versionNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 235 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion ofMinorMajor(int versionNumber) {
/* 245 */     ClassFileVersion classFileVersion = new ClassFileVersion(versionNumber);
/* 246 */     if (classFileVersion.getMajorVersion() > 0 && classFileVersion.getMajorVersion() <= 44) {
/* 247 */       throw new IllegalArgumentException("Class version " + versionNumber + " is not valid");
/*     */     }
/* 249 */     return classFileVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion ofJavaVersionString(String javaVersionString) {
/* 259 */     int index = javaVersionString.indexOf('.');
/*     */     try {
/*     */       int javaVersion;
/* 262 */       if (index == -1) {
/* 263 */         javaVersion = Integer.parseInt(javaVersionString);
/*     */       } else {
/* 265 */         javaVersion = Integer.parseInt(javaVersionString.substring(index + 1));
/* 266 */         if (Integer.parseInt(javaVersionString.substring(0, index)) != 1 || javaVersion > 8) {
/* 267 */           throw new IllegalArgumentException("Java versions with minor version must be of format 1.[1-7]: " + javaVersionString);
/*     */         }
/*     */       } 
/* 270 */       return ofJavaVersion(javaVersion);
/* 271 */     } catch (NumberFormatException exception) {
/* 272 */       throw new IllegalStateException("Failed to read Java version from: " + javaVersionString, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion ofJavaVersion(int javaVersion) {
/* 283 */     if (javaVersion < 1)
/* 284 */       throw new IllegalArgumentException("Java version must be positive: " + javaVersion); 
/* 285 */     if (javaVersion - 1 < CLASS_FILE_VERSIONS.length) {
/* 286 */       return CLASS_FILE_VERSIONS[javaVersion - 1];
/*     */     }
/* 288 */     return new ClassFileVersion(44 + javaVersion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion latest() {
/* 298 */     return JAVA_V26;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion ofThisVm() {
/* 309 */     return VERSION_LOCATOR.resolve();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*     */   public static ClassFileVersion ofThisVm(ClassFileVersion fallback) {
/*     */     try {
/* 323 */       return ofThisVm();
/* 324 */     } catch (Exception ignored) {
/* 325 */       return fallback;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion of(Class<?> type) throws IOException {
/* 337 */     return of(type, ClassFileLocator.ForClassLoader.of(type.getClassLoader()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion of(Class<?> type, ClassFileLocator classFileLocator) throws IOException {
/* 349 */     return of(TypeDescription.ForLoadedType.of(type), classFileLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion of(TypeDescription typeDescription, ClassFileLocator classFileLocator) throws IOException {
/* 361 */     return ofClassFile(classFileLocator.locate(typeDescription.getName()).resolve());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileVersion ofClassFile(byte[] binaryRepresentation) {
/* 371 */     if (binaryRepresentation.length < 7) {
/* 372 */       throw new IllegalArgumentException("Supplied byte array is too short to be a class file with " + binaryRepresentation.length + " byte");
/*     */     }
/* 374 */     return ofMinorMajor(binaryRepresentation[4] << 24 | binaryRepresentation[5] << 16 | binaryRepresentation[6] << 8 | binaryRepresentation[7]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorMajorVersion() {
/* 386 */     return this.versionNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getMajorVersion() {
/* 395 */     return (short)(this.versionNumber & 0xFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getMinorVersion() {
/* 404 */     return (short)(this.versionNumber >>> 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getJavaVersion() {
/* 413 */     return getMajorVersion() - 44;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAtLeast(ClassFileVersion classFileVersion) {
/* 423 */     return (compareTo(classFileVersion) > -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGreaterThan(ClassFileVersion classFileVersion) {
/* 433 */     return (compareTo(classFileVersion) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAtMost(ClassFileVersion classFileVersion) {
/* 443 */     return (compareTo(classFileVersion) < 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLessThan(ClassFileVersion classFileVersion) {
/* 453 */     return (compareTo(classFileVersion) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFileVersion asPreviewVersion() {
/* 462 */     return new ClassFileVersion(this.versionNumber | 0xFFFF0000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPreviewVersion() {
/* 471 */     return ((this.versionNumber & 0xFFFF0000) == -65536);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ClassFileVersion other) {
/* 478 */     return Integer.signum((getMajorVersion() == other.getMajorVersion()) ? (
/* 479 */         getMinorVersion() - other.getMinorVersion()) : (
/* 480 */         getMajorVersion() - other.getMajorVersion()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 485 */     return this.versionNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object other) {
/* 490 */     if (this == other)
/* 491 */       return true; 
/* 492 */     if (other == null || getClass() != other.getClass()) {
/* 493 */       return false;
/*     */     }
/* 495 */     return (this.versionNumber == ((ClassFileVersion)other).versionNumber);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 500 */     return "Java " + getJavaVersion() + " (" + getMinorMajorVersion() + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\ClassFileVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */