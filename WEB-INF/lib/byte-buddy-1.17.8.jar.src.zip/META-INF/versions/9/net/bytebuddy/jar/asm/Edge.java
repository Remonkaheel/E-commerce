/*    */ package META-INF.versions.9.net.bytebuddy.jar.asm;
/*    */ 
/*    */ import net.bytebuddy.jar.asm.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Edge
/*    */ {
/*    */   static final int JUMP = 0;
/*    */   static final int EXCEPTION = 2147483647;
/*    */   final int info;
/*    */   final Label successor;
/*    */   net.bytebuddy.jar.asm.Edge nextEdge;
/*    */   
/*    */   Edge(int info, Label successor, net.bytebuddy.jar.asm.Edge nextEdge) {
/* 87 */     this.info = info;
/* 88 */     this.successor = successor;
/* 89 */     this.nextEdge = nextEdge;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\jar\asm\Edge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */