package META-INF.versions.9.net.bytebuddy.utility;

import net.bytebuddy.jar.asm.ClassVisitor;

public interface AsmClassWriter {
  ClassVisitor getVisitor();
  
  byte[] getBinaryRepresentation();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\AsmClassWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */