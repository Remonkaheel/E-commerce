/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class InstanceCheck
/*    */   extends StackManipulation.AbstractBase
/*    */ {
/*    */   private final TypeDescription typeDescription;
/*    */   
/*    */   protected InstanceCheck(TypeDescription typeDescription) {
/* 42 */     this.typeDescription = typeDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StackManipulation of(TypeDescription typeDescription) {
/* 52 */     if (typeDescription.isPrimitive()) {
/* 53 */       throw new IllegalArgumentException("Cannot check an instance against a primitive type: " + typeDescription);
/*    */     }
/* 55 */     return (StackManipulation)new net.bytebuddy.implementation.bytecode.assign.InstanceCheck(typeDescription);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 62 */     methodVisitor.visitTypeInsn(193, this.typeDescription.getInternalName());
/* 63 */     return StackManipulation.Size.ZERO;
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.typeDescription.equals(((net.bytebuddy.implementation.bytecode.assign.InstanceCheck)paramObject).typeDescription))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\InstanceCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */