/*    */ package META-INF.versions.9.net.bytebuddy.description.field;
/*    */ 
/*    */ import javax.annotation.Nonnull;
/*    */ import net.bytebuddy.description.ByteCodeElement;
/*    */ import net.bytebuddy.description.DeclaredByType;
/*    */ import net.bytebuddy.description.ModifierReviewable;
/*    */ import net.bytebuddy.description.field.FieldDescription;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface FieldDescription
/*    */   extends ModifierReviewable.ForFieldDescription, DeclaredByType.WithMandatoryDeclaration, ByteCodeElement.Member, ByteCodeElement.TypeDependant<FieldDescription.InDefinedShape, FieldDescription.Token>
/*    */ {
/*    */   @AlwaysNull
/* 53 */   public static final Object NO_DEFAULT_VALUE = null;
/*    */   
/*    */   @Nonnull
/*    */   TypeDefinition getDeclaringType();
/*    */   
/*    */   TypeDescription.Generic getType();
/*    */   
/*    */   int getActualModifiers();
/*    */   
/*    */   SignatureToken asSignatureToken();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\field\FieldDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */