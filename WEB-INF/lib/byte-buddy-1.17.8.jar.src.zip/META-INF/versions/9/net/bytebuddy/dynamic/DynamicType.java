package META-INF.versions.9.net.bytebuddy.dynamic;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Manifest;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.ClassFileLocator;
import net.bytebuddy.implementation.LoadedTypeInitializer;

public interface DynamicType extends ClassFileLocator {
  TypeDescription getTypeDescription();
  
  byte[] getBytes();
  
  LoadedTypeInitializer getLoadedTypeInitializer();
  
  List<? extends net.bytebuddy.dynamic.DynamicType> getAuxiliaries();
  
  Set<TypeDescription> getAuxiliaryTypeDescriptions();
  
  Set<TypeDescription> getAllTypeDescriptions();
  
  Map<TypeDescription, byte[]> getAuxiliaryTypes();
  
  Map<TypeDescription, byte[]> getAllTypes();
  
  Map<TypeDescription, LoadedTypeInitializer> getLoadedTypeInitializers();
  
  boolean hasAliveLoadedTypeInitializers();
  
  Map<TypeDescription, File> saveIn(File paramFile) throws IOException;
  
  File inject(File paramFile1, File paramFile2) throws IOException;
  
  File inject(File paramFile) throws IOException;
  
  File toJar(File paramFile) throws IOException;
  
  File toJar(File paramFile, Manifest paramManifest) throws IOException;
  
  void close();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\DynamicType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */