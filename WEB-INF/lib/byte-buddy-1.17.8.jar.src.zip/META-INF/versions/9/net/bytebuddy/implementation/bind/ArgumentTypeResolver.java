/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bind;
/*     */ 
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.method.ParameterList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.bind.MethodDelegationBinder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ArgumentTypeResolver
/*     */   implements MethodDelegationBinder.AmbiguityResolver
/*     */ {
/*  50 */   INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MethodDelegationBinder.AmbiguityResolver.Resolution resolveRivalBinding(TypeDescription sourceParameterType, int leftParameterIndex, MethodDelegationBinder.MethodBinding left, int rightParameterIndex, MethodDelegationBinder.MethodBinding right) {
/*  67 */     TypeDescription leftParameterType = ((ParameterDescription)left.getTarget().getParameters().get(leftParameterIndex)).getType().asErasure();
/*  68 */     TypeDescription rightParameterType = ((ParameterDescription)right.getTarget().getParameters().get(rightParameterIndex)).getType().asErasure();
/*  69 */     if (!leftParameterType.equals(rightParameterType)) {
/*  70 */       if (leftParameterType.isPrimitive() && rightParameterType.isPrimitive())
/*  71 */         return PrimitiveTypePrecedence.forPrimitive(leftParameterType).resolve(PrimitiveTypePrecedence.forPrimitive(rightParameterType)); 
/*  72 */       if (leftParameterType.isPrimitive())
/*  73 */         return sourceParameterType.isPrimitive() ? MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT : MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT; 
/*  74 */       if (rightParameterType.isPrimitive()) {
/*  75 */         return sourceParameterType.isPrimitive() ? MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT : MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT;
/*     */       }
/*     */       
/*  78 */       if (leftParameterType.isAssignableFrom(rightParameterType))
/*  79 */         return MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT; 
/*  80 */       if (rightParameterType.isAssignableFrom(leftParameterType)) {
/*  81 */         return MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT;
/*     */       }
/*  83 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.AMBIGUOUS;
/*     */     } 
/*     */ 
/*     */     
/*  87 */     return MethodDelegationBinder.AmbiguityResolver.Resolution.UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MethodDelegationBinder.AmbiguityResolver.Resolution resolveByScore(int boundParameterScore) {
/* 100 */     if (boundParameterScore == 0)
/* 101 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.AMBIGUOUS; 
/* 102 */     if (boundParameterScore > 0) {
/* 103 */       return MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT;
/*     */     }
/* 105 */     return MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodDelegationBinder.AmbiguityResolver.Resolution resolve(MethodDescription source, MethodDelegationBinder.MethodBinding left, MethodDelegationBinder.MethodBinding right) {
/* 115 */     MethodDelegationBinder.AmbiguityResolver.Resolution resolution = MethodDelegationBinder.AmbiguityResolver.Resolution.UNKNOWN;
/* 116 */     ParameterList<?> sourceParameters = source.getParameters();
/* 117 */     int leftExtra = 0, rightExtra = 0;
/* 118 */     for (int sourceParameterIndex = 0; sourceParameterIndex < sourceParameters.size(); sourceParameterIndex++) {
/* 119 */       ParameterIndexToken parameterIndexToken = new ParameterIndexToken(sourceParameterIndex);
/* 120 */       Integer leftParameterIndex = left.getTargetParameterIndex(parameterIndexToken);
/* 121 */       Integer rightParameterIndex = right.getTargetParameterIndex(parameterIndexToken);
/* 122 */       if (leftParameterIndex != null && rightParameterIndex != null) {
/* 123 */         resolution = resolution.merge(resolveRivalBinding(((ParameterDescription)sourceParameters.get(sourceParameterIndex)).getType().asErasure(), leftParameterIndex
/* 124 */               .intValue(), left, rightParameterIndex
/*     */               
/* 126 */               .intValue(), right));
/*     */       }
/* 128 */       else if (leftParameterIndex != null) {
/* 129 */         leftExtra++;
/* 130 */       } else if (rightParameterIndex != null) {
/* 131 */         rightExtra++;
/*     */       } 
/*     */     } 
/* 134 */     return (resolution == MethodDelegationBinder.AmbiguityResolver.Resolution.UNKNOWN) ? 
/* 135 */       resolveByScore(leftExtra - rightExtra) : resolution;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\ArgumentTypeResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */