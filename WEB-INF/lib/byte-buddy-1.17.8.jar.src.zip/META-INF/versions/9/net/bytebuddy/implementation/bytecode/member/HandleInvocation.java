/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.member;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ import net.bytebuddy.utility.JavaConstant;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class HandleInvocation
/*    */   extends StackManipulation.AbstractBase
/*    */ {
/*    */   private static final String METHOD_HANDLE_NAME = "java/lang/invoke/MethodHandle";
/*    */   private static final String INVOKE_EXACT = "invokeExact";
/*    */   private final JavaConstant.MethodType methodType;
/*    */   
/*    */   public HandleInvocation(JavaConstant.MethodType methodType) {
/* 52 */     this.methodType = methodType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 59 */     methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invokeExact", this.methodType.getDescriptor(), false);
/* 60 */     int size = this.methodType.getReturnType().getStackSize().getSize() - this.methodType.getParameterTypes().getStackSize();
/* 61 */     return new StackManipulation.Size(size, Math.max(size, 0));
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.methodType.equals(((net.bytebuddy.implementation.bytecode.member.HandleInvocation)paramObject).methodType))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return getClass().hashCode() * 31 + this.methodType.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\member\HandleInvocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */