/*    */ package META-INF.versions.9.net.bytebuddy.jar.asm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MethodTooLargeException
/*    */   extends IndexOutOfBoundsException
/*    */ {
/*    */   private static final long serialVersionUID = 6807380416709738314L;
/*    */   private final String className;
/*    */   private final String methodName;
/*    */   private final String descriptor;
/*    */   private final int codeSize;
/*    */   
/*    */   public MethodTooLargeException(String className, String methodName, String descriptor, int codeSize) {
/* 57 */     super(stringConcat$0(className, methodName, descriptor));
/* 58 */     this.className = className;
/* 59 */     this.methodName = methodName;
/* 60 */     this.descriptor = descriptor;
/* 61 */     this.codeSize = codeSize;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 70 */     return this.className;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMethodName() {
/* 79 */     return this.methodName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescriptor() {
/* 88 */     return this.descriptor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCodeSize() {
/* 97 */     return this.codeSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\jar\asm\MethodTooLargeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */