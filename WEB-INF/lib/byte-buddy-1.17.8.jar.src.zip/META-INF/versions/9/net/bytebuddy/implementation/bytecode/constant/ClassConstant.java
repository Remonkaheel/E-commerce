/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ClassConstant
/*     */   implements StackManipulation
/*     */ {
/*  36 */   VOID(Void.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   BOOLEAN(Boolean.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   BYTE(Byte.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   SHORT(Short.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   CHARACTER(Character.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   INTEGER(Integer.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   LONG(Long.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   FLOAT(Float.class),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   DOUBLE(Double.class);
/*     */   private static final StackManipulation.Size SIZE;
/*     */   private static final String PRIMITIVE_TYPE_FIELD = "TYPE";
/*     */   
/*     */   static {
/*  81 */     SIZE = StackSize.SINGLE.toIncreasingSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CLASS_TYPE_INTERNAL_NAME = "Ljava/lang/Class;";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String fieldOwnerInternalName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ClassConstant(Class<?> type) {
/* 104 */     this.fieldOwnerInternalName = Type.getInternalName(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation of(TypeDescription typeDescription) {
/* 115 */     if (!typeDescription.isPrimitive())
/* 116 */       return (StackManipulation)new ForReferenceType(typeDescription); 
/* 117 */     if (typeDescription.represents(boolean.class))
/* 118 */       return BOOLEAN; 
/* 119 */     if (typeDescription.represents(byte.class))
/* 120 */       return BYTE; 
/* 121 */     if (typeDescription.represents(short.class))
/* 122 */       return SHORT; 
/* 123 */     if (typeDescription.represents(char.class))
/* 124 */       return CHARACTER; 
/* 125 */     if (typeDescription.represents(int.class))
/* 126 */       return INTEGER; 
/* 127 */     if (typeDescription.represents(long.class))
/* 128 */       return LONG; 
/* 129 */     if (typeDescription.represents(float.class))
/* 130 */       return FLOAT; 
/* 131 */     if (typeDescription.represents(double.class)) {
/* 132 */       return DOUBLE;
/*     */     }
/* 134 */     return VOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 149 */     methodVisitor.visitFieldInsn(178, this.fieldOwnerInternalName, "TYPE", "Ljava/lang/Class;");
/* 150 */     return SIZE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\ClassConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */