package META-INF.versions.9.net.bytebuddy;

import net.bytebuddy.description.type.TypeDescription;

public interface NamingStrategy {
  public static final String BYTE_BUDDY_RENAME_PACKAGE = "net.bytebuddy.renamed";
  
  public static final String NO_PREFIX = "";
  
  String subclass(TypeDescription.Generic paramGeneric);
  
  String redefine(TypeDescription paramTypeDescription);
  
  String rebase(TypeDescription paramTypeDescription);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\NamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */