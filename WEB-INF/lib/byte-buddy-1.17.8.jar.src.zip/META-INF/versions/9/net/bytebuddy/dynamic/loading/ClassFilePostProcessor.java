package META-INF.versions.9.net.bytebuddy.dynamic.loading;

import java.security.ProtectionDomain;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface ClassFilePostProcessor {
  byte[] transform(@MaybeNull ClassLoader paramClassLoader, String paramString, @MaybeNull ProtectionDomain paramProtectionDomain, byte[] paramArrayOfbyte);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\loading\ClassFilePostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */