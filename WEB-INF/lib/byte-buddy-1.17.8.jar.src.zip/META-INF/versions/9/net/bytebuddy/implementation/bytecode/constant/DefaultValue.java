/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.constant.DoubleConstant;
/*     */ import net.bytebuddy.implementation.bytecode.constant.FloatConstant;
/*     */ import net.bytebuddy.implementation.bytecode.constant.IntegerConstant;
/*     */ import net.bytebuddy.implementation.bytecode.constant.LongConstant;
/*     */ import net.bytebuddy.implementation.bytecode.constant.NullConstant;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DefaultValue
/*     */   implements StackManipulation
/*     */ {
/*  32 */   INTEGER((StackManipulation)IntegerConstant.ZERO),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   LONG((StackManipulation)LongConstant.ZERO),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   FLOAT((StackManipulation)FloatConstant.ZERO),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   DOUBLE((StackManipulation)DoubleConstant.ZERO),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   VOID((StackManipulation)StackManipulation.Trivial.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   REFERENCE((StackManipulation)NullConstant.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation stackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultValue(StackManipulation stackManipulation) {
/*  71 */     this.stackManipulation = stackManipulation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation of(TypeDefinition typeDefinition) {
/*  81 */     if (typeDefinition.isPrimitive()) {
/*  82 */       if (typeDefinition.represents(long.class))
/*  83 */         return LONG; 
/*  84 */       if (typeDefinition.represents(double.class))
/*  85 */         return DOUBLE; 
/*  86 */       if (typeDefinition.represents(float.class))
/*  87 */         return FLOAT; 
/*  88 */       if (typeDefinition.represents(void.class)) {
/*  89 */         return VOID;
/*     */       }
/*  91 */       return INTEGER;
/*     */     } 
/*     */     
/*  94 */     return REFERENCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 102 */     return this.stackManipulation.isValid();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 109 */     return this.stackManipulation.apply(methodVisitor, implementationContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\DefaultValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */