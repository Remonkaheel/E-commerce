/*    */ package META-INF.versions.9.net.bytebuddy.implementation;
/*    */ 
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.type.TypeDefinition;
/*    */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.constant.DefaultValue;
/*    */ import net.bytebuddy.implementation.bytecode.member.MethodReturn;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum StubMethod
/*    */   implements Implementation.Composable, ByteCodeAppender
/*    */ {
/* 42 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 48 */     return instrumentedType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 55 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Implementation andThen(Implementation implementation) {
/* 62 */     return implementation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Implementation.Composable andThen(Implementation.Composable implementation) {
/* 69 */     return implementation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 81 */     StackManipulation.Size stackSize = (new StackManipulation.Compound(new StackManipulation[] { DefaultValue.of((TypeDefinition)instrumentedMethod.getReturnType()), MethodReturn.of((TypeDefinition)instrumentedMethod.getReturnType()) })).apply(methodVisitor, implementationContext);
/* 82 */     return new ByteCodeAppender.Size(stackSize.getMaximalSize(), instrumentedMethod.getStackSize());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\StubMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */