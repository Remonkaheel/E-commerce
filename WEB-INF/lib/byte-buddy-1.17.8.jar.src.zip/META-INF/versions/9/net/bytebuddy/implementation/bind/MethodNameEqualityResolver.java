/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bind;
/*    */ 
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.implementation.bind.MethodDelegationBinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MethodNameEqualityResolver
/*    */   implements MethodDelegationBinder.AmbiguityResolver
/*    */ {
/* 34 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodDelegationBinder.AmbiguityResolver.Resolution resolve(MethodDescription source, MethodDelegationBinder.MethodBinding left, MethodDelegationBinder.MethodBinding right) {
/* 42 */     boolean leftEquals = left.getTarget().getName().equals(source.getName());
/* 43 */     boolean rightEquals = right.getTarget().getName().equals(source.getName());
/* 44 */     if (leftEquals ^ rightEquals) {
/* 45 */       return leftEquals ? MethodDelegationBinder.AmbiguityResolver.Resolution.LEFT : MethodDelegationBinder.AmbiguityResolver.Resolution.RIGHT;
/*    */     }
/* 47 */     return MethodDelegationBinder.AmbiguityResolver.Resolution.AMBIGUOUS;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bind\MethodNameEqualityResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */