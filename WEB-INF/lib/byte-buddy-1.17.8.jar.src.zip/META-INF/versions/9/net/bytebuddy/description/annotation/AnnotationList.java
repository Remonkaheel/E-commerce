package META-INF.versions.9.net.bytebuddy.description.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.Set;
import net.bytebuddy.description.annotation.AnnotationDescription;
import net.bytebuddy.description.annotation.AnnotationList;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeList;
import net.bytebuddy.matcher.ElementMatcher;
import net.bytebuddy.matcher.FilterableList;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface AnnotationList extends FilterableList<AnnotationDescription, AnnotationList> {
  boolean isAnnotationPresent(Class<? extends Annotation> paramClass);
  
  boolean isAnnotationPresent(TypeDescription paramTypeDescription);
  
  @MaybeNull
  <T extends Annotation> AnnotationDescription.Loadable<T> ofType(Class<T> paramClass);
  
  AnnotationDescription ofType(TypeDescription paramTypeDescription);
  
  AnnotationList inherited(Set<? extends TypeDescription> paramSet);
  
  AnnotationList visibility(ElementMatcher<? super RetentionPolicy> paramElementMatcher);
  
  TypeList asTypeList();
  
  List<String> asTypeNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\annotation\AnnotationList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */