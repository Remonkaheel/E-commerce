/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.member;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MethodReturn
/*     */   implements StackManipulation
/*     */ {
/*  33 */   INTEGER(172, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   DOUBLE(175, StackSize.DOUBLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   FLOAT(174, StackSize.SINGLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   LONG(173, StackSize.DOUBLE),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   VOID(177, StackSize.ZERO),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   REFERENCE(176, StackSize.SINGLE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int returnOpcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackSize stackSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodReturn(int returnOpcode, StackSize stackSize) {
/*  77 */     this.returnOpcode = returnOpcode;
/*  78 */     this.stackSize = stackSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackManipulation of(TypeDefinition typeDefinition) {
/*  88 */     if (typeDefinition.isPrimitive()) {
/*  89 */       if (typeDefinition.represents(long.class))
/*  90 */         return LONG; 
/*  91 */       if (typeDefinition.represents(double.class))
/*  92 */         return DOUBLE; 
/*  93 */       if (typeDefinition.represents(float.class))
/*  94 */         return FLOAT; 
/*  95 */       if (typeDefinition.represents(void.class)) {
/*  96 */         return VOID;
/*     */       }
/*  98 */       return INTEGER;
/*     */     } 
/*     */     
/* 101 */     return REFERENCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 116 */     methodVisitor.visitInsn(this.returnOpcode);
/* 117 */     return this.stackSize.toDecreasingSize();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\member\MethodReturn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */