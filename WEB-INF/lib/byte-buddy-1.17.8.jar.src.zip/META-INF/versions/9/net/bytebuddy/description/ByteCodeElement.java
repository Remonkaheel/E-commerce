package META-INF.versions.9.net.bytebuddy.description;

import net.bytebuddy.description.DeclaredByType;
import net.bytebuddy.description.ModifierReviewable;
import net.bytebuddy.description.NamedElement;
import net.bytebuddy.description.annotation.AnnotationSource;
import net.bytebuddy.description.type.TypeDescription;

public interface ByteCodeElement extends NamedElement.WithRuntimeName, NamedElement.WithDescriptor, ModifierReviewable.OfByteCodeElement, DeclaredByType, AnnotationSource {
  boolean isVisibleTo(TypeDescription paramTypeDescription);
  
  boolean isAccessibleTo(TypeDescription paramTypeDescription);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\ByteCodeElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */