package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.description.type.RecordComponentDescription;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.Transformer;
import net.bytebuddy.implementation.attribute.RecordComponentAttributeAppender;
import net.bytebuddy.matcher.LatentMatcher;

public interface RecordComponentRegistry {
  net.bytebuddy.dynamic.scaffold.RecordComponentRegistry prepend(LatentMatcher<? super RecordComponentDescription> paramLatentMatcher, RecordComponentAttributeAppender.Factory paramFactory, Transformer<RecordComponentDescription> paramTransformer);
  
  Compiled compile(TypeDescription paramTypeDescription);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\RecordComponentRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */