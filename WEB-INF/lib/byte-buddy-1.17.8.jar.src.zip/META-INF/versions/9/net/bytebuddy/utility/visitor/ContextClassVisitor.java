/*    */ package META-INF.versions.9.net.bytebuddy.utility.visitor;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.bytebuddy.dynamic.DynamicType;
/*    */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*    */ import net.bytebuddy.jar.asm.ClassVisitor;
/*    */ import net.bytebuddy.utility.OpenedClassReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContextClassVisitor
/*    */   extends ClassVisitor
/*    */ {
/*    */   private boolean active;
/*    */   
/*    */   protected ContextClassVisitor(ClassVisitor classVisitor) {
/* 42 */     super(OpenedClassReader.ASM_API, classVisitor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public net.bytebuddy.utility.visitor.ContextClassVisitor active() {
/* 51 */     this.active = true;
/* 52 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract List<DynamicType> getAuxiliaryTypes();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract LoadedTypeInitializer getLoadedTypeInitializer();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visitEnd() {
/* 71 */     super.visitEnd();
/* 72 */     if (!this.active && (!getAuxiliaryTypes().isEmpty() || getLoadedTypeInitializer().isAlive()))
/* 73 */       throw new IllegalStateException(this + " is not defined 'active' but defines auxiliary types or an alive type initializer"); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\visitor\ContextClassVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */