/*     */ package META-INF.versions.9.net.bytebuddy.utility;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.jar.asm.ClassReader;
/*     */ import net.bytebuddy.utility.AsmClassReader;
/*     */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenedClassReader
/*     */   implements AsmClassReader.Factory
/*     */ {
/*     */   public static final String EXPERIMENTAL_PROPERTY = "net.bytebuddy.experimental";
/*     */   public static final String PROCESSOR_PROPERTY = "net.bytebuddy.processor";
/*     */   public static final boolean EXPERIMENTAL;
/*     */   private static final boolean ACCESS_CONTROLLER;
/*  63 */   public static final int ASM_API = 589824; static { boolean experimental; 
/*  64 */     try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      try {
/*     */       experimental = Boolean.parseBoolean(doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.experimental")));
/*     */     } catch (Exception ignored) {
/*     */       experimental = false;
/*     */     } 
/*  70 */     EXPERIMENTAL = experimental; } public AsmClassReader make(byte[] binaryRepresentation) { return (AsmClassReader)new AsmClassReader.ForAsm(of(binaryRepresentation)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmClassReader make(byte[] binaryRepresentation, boolean experimental) {
/*  77 */     return (AsmClassReader)new AsmClassReader.ForAsm(of(binaryRepresentation, experimental));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  89 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassReader of(byte[] binaryRepresentation) {
/* 100 */     return of(binaryRepresentation, EXPERIMENTAL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassReader of(byte[] binaryRepresentation, boolean experimental) {
/* 111 */     ClassFileVersion classFileVersion = ClassFileVersion.ofClassFile(binaryRepresentation), latest = ClassFileVersion.latest();
/* 112 */     if (classFileVersion.isGreaterThan(latest)) {
/* 113 */       if (experimental) {
/* 114 */         binaryRepresentation[4] = (byte)(latest.getMinorVersion() >>> 8);
/* 115 */         binaryRepresentation[5] = (byte)latest.getMinorVersion();
/* 116 */         binaryRepresentation[6] = (byte)(latest.getMajorVersion() >>> 8);
/* 117 */         binaryRepresentation[7] = (byte)latest.getMajorVersion();
/* 118 */         ClassReader classReader = new ClassReader(binaryRepresentation);
/* 119 */         binaryRepresentation[4] = (byte)(classFileVersion.getMinorVersion() >>> 8);
/* 120 */         binaryRepresentation[5] = (byte)classFileVersion.getMinorVersion();
/* 121 */         binaryRepresentation[6] = (byte)(classFileVersion.getMajorVersion() >>> 8);
/* 122 */         binaryRepresentation[7] = (byte)classFileVersion.getMajorVersion();
/* 123 */         return classReader;
/*     */       } 
/* 125 */       throw new IllegalArgumentException(classFileVersion + " is not supported by the current version of Byte Buddy which officially supports " + latest + " - update Byte Buddy or set " + "net.bytebuddy.experimental" + " as a VM property");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 130 */     return new ClassReader(binaryRepresentation);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\OpenedClassReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */