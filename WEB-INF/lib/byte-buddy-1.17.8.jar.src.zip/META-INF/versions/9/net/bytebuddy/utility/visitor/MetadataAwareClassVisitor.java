/*     */ package META-INF.versions.9.net.bytebuddy.utility.visitor;
/*     */ 
/*     */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*     */ import net.bytebuddy.jar.asm.Attribute;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*     */ import net.bytebuddy.jar.asm.TypePath;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MetadataAwareClassVisitor
/*     */   extends ClassVisitor
/*     */ {
/*     */   private boolean triggerNestHost;
/*     */   private boolean triggerOuterClass;
/*     */   private boolean triggerAttributes;
/*     */   
/*     */   protected MetadataAwareClassVisitor(int api, ClassVisitor classVisitor) {
/*  48 */     super(api, classVisitor);
/*  49 */     this.triggerNestHost = true;
/*  50 */     this.triggerOuterClass = true;
/*  51 */     this.triggerAttributes = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onNestHost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onOuterType() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onAfterAttributes() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void considerTriggerNestHost() {
/*  79 */     if (this.triggerNestHost) {
/*  80 */       this.triggerNestHost = false;
/*  81 */       onNestHost();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void considerTriggerOuterClass() {
/*  89 */     if (this.triggerOuterClass) {
/*  90 */       this.triggerOuterClass = false;
/*  91 */       onOuterType();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void considerTriggerAfterAttributes() {
/*  99 */     if (this.triggerAttributes) {
/* 100 */       this.triggerAttributes = false;
/* 101 */       onAfterAttributes();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitNestHost(String nestHost) {
/* 107 */     this.triggerNestHost = false;
/* 108 */     onVisitNestHost(nestHost);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitNestHost(String nestHost) {
/* 117 */     super.visitNestHost(nestHost);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitOuterClass(String owner, @MaybeNull String name, @MaybeNull String descriptor) {
/* 122 */     considerTriggerNestHost();
/* 123 */     this.triggerOuterClass = false;
/* 124 */     onVisitOuterClass(owner, name, descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitOuterClass(String owner, @MaybeNull String name, @MaybeNull String descriptor) {
/* 135 */     super.visitOuterClass(owner, name, descriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitPermittedSubclass(String permittedSubclass) {
/* 140 */     considerTriggerNestHost();
/* 141 */     considerTriggerOuterClass();
/* 142 */     considerTriggerAfterAttributes();
/* 143 */     onVisitPermittedSubclass(permittedSubclass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitPermittedSubclass(String permittedSubclass) {
/* 152 */     super.visitPermittedSubclass(permittedSubclass);
/*     */   }
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public RecordComponentVisitor visitRecordComponent(String name, String descriptor, @MaybeNull String signature) {
/* 158 */     considerTriggerNestHost();
/* 159 */     considerTriggerOuterClass();
/* 160 */     considerTriggerAfterAttributes();
/* 161 */     return onVisitRecordComponent(name, descriptor, signature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   protected RecordComponentVisitor onVisitRecordComponent(String name, String descriptor, @MaybeNull String signature) {
/* 174 */     return super.visitRecordComponent(name, descriptor, signature);
/*     */   }
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public final AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 180 */     considerTriggerNestHost();
/* 181 */     considerTriggerOuterClass();
/* 182 */     return onVisitAnnotation(descriptor, visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   protected AnnotationVisitor onVisitAnnotation(String descriptor, boolean visible) {
/* 194 */     return super.visitAnnotation(descriptor, visible);
/*     */   }
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public final AnnotationVisitor visitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) {
/* 200 */     considerTriggerNestHost();
/* 201 */     considerTriggerOuterClass();
/* 202 */     return onVisitTypeAnnotation(typeReference, typePath, descriptor, visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   protected AnnotationVisitor onVisitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) {
/* 216 */     return super.visitTypeAnnotation(typeReference, typePath, descriptor, visible);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitAttribute(Attribute attribute) {
/* 221 */     considerTriggerNestHost();
/* 222 */     considerTriggerOuterClass();
/* 223 */     onVisitAttribute(attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitAttribute(Attribute attribute) {
/* 232 */     super.visitAttribute(attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitNestMember(String nestMember) {
/* 237 */     considerTriggerNestHost();
/* 238 */     considerTriggerOuterClass();
/* 239 */     considerTriggerAfterAttributes();
/* 240 */     onVisitNestMember(nestMember);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitNestMember(String nestMember) {
/* 249 */     super.visitNestMember(nestMember);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitInnerClass(String name, @MaybeNull String outerName, @MaybeNull String innerName, int modifiers) {
/* 254 */     considerTriggerNestHost();
/* 255 */     considerTriggerOuterClass();
/* 256 */     considerTriggerAfterAttributes();
/* 257 */     onVisitInnerClass(name, outerName, innerName, modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitInnerClass(String internalName, @MaybeNull String outerName, @MaybeNull String innerName, int modifiers) {
/* 269 */     super.visitInnerClass(internalName, outerName, innerName, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public final FieldVisitor visitField(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 275 */     considerTriggerNestHost();
/* 276 */     considerTriggerOuterClass();
/* 277 */     considerTriggerAfterAttributes();
/* 278 */     return onVisitField(modifiers, internalName, descriptor, signature, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   protected FieldVisitor onVisitField(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 293 */     return super.visitField(modifiers, internalName, descriptor, signature, value);
/*     */   }
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   public final MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 299 */     considerTriggerNestHost();
/* 300 */     considerTriggerOuterClass();
/* 301 */     considerTriggerAfterAttributes();
/* 302 */     return onVisitMethod(modifiers, internalName, descriptor, signature, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   protected MethodVisitor onVisitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 317 */     return super.visitMethod(modifiers, internalName, descriptor, signature, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void visitEnd() {
/* 322 */     considerTriggerNestHost();
/* 323 */     considerTriggerOuterClass();
/* 324 */     considerTriggerAfterAttributes();
/* 325 */     onVisitEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onVisitEnd() {
/* 332 */     super.visitEnd();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\visitor\MetadataAwareClassVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */