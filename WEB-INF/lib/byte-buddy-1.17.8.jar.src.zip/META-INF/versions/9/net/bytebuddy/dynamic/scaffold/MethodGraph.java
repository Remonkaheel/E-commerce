package META-INF.versions.9.net.bytebuddy.dynamic.scaffold;

import net.bytebuddy.description.method.MethodDescription;

public interface MethodGraph {
  Node locate(MethodDescription.SignatureToken paramSignatureToken);
  
  NodeList listNodes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\dynamic\scaffold\MethodGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */