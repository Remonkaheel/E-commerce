/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.scaffold.FieldLocator;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bind.MethodDelegationBinder;
/*     */ import net.bytebuddy.implementation.bind.annotation.TargetMethodAnnotationDrivenBinder;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MethodDelegation
/*     */   implements Implementation.Composable
/*     */ {
/*     */   private final ImplementationDelegate implementationDelegate;
/*     */   private final List<TargetMethodAnnotationDrivenBinder.ParameterBinder<?>> parameterBinders;
/*     */   private final MethodDelegationBinder.AmbiguityResolver ambiguityResolver;
/*     */   private final MethodDelegationBinder.TerminationHandler terminationHandler;
/*     */   private final MethodDelegationBinder.BindingResolver bindingResolver;
/*     */   private final Assigner assigner;
/*     */   
/*     */   protected MethodDelegation(ImplementationDelegate implementationDelegate, List<TargetMethodAnnotationDrivenBinder.ParameterBinder<?>> parameterBinders, MethodDelegationBinder.AmbiguityResolver ambiguityResolver, MethodDelegationBinder.BindingResolver bindingResolver) {
/* 233 */     this(implementationDelegate, parameterBinders, ambiguityResolver, (MethodDelegationBinder.TerminationHandler)MethodDelegationBinder.TerminationHandler.Default.RETURNING, bindingResolver, Assigner.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodDelegation(ImplementationDelegate implementationDelegate, List<TargetMethodAnnotationDrivenBinder.ParameterBinder<?>> parameterBinders, MethodDelegationBinder.AmbiguityResolver ambiguityResolver, MethodDelegationBinder.TerminationHandler terminationHandler, MethodDelegationBinder.BindingResolver bindingResolver, Assigner assigner) {
/* 257 */     this.implementationDelegate = implementationDelegate;
/* 258 */     this.parameterBinders = parameterBinders;
/* 259 */     this.terminationHandler = terminationHandler;
/* 260 */     this.ambiguityResolver = ambiguityResolver;
/* 261 */     this.bindingResolver = bindingResolver;
/* 262 */     this.assigner = assigner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Class<?> type) {
/* 276 */     return withDefaultConfiguration().to(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(TypeDescription typeDescription) {
/* 290 */     return withDefaultConfiguration().to(typeDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target) {
/* 304 */     return withDefaultConfiguration().to(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, MethodGraph.Compiler methodGraphCompiler) {
/* 319 */     return withDefaultConfiguration().to(target, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, String fieldName) {
/* 334 */     return withDefaultConfiguration().to(target, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, String fieldName, MethodGraph.Compiler methodGraphCompiler) {
/* 350 */     return withDefaultConfiguration().to(target, fieldName, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, Type type) {
/* 365 */     return withDefaultConfiguration().to(target, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, Type type, MethodGraph.Compiler methodGraphCompiler) {
/* 381 */     return withDefaultConfiguration().to(target, type, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, Type type, String fieldName) {
/* 397 */     return withDefaultConfiguration().to(target, type, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, Type type, String fieldName, MethodGraph.Compiler methodGraphCompiler) {
/* 414 */     return withDefaultConfiguration().to(target, type, fieldName, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, TypeDefinition typeDefinition) {
/* 429 */     return withDefaultConfiguration().to(target, typeDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, TypeDefinition typeDefinition, MethodGraph.Compiler methodGraphCompiler) {
/* 445 */     return withDefaultConfiguration().to(target, typeDefinition, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, TypeDefinition typeDefinition, String fieldName) {
/* 461 */     return withDefaultConfiguration().to(target, typeDefinition, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation to(Object target, TypeDefinition typeDefinition, String fieldName, MethodGraph.Compiler methodGraphCompiler) {
/* 478 */     return withDefaultConfiguration().to(target, typeDefinition, fieldName, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toConstructor(Class<?> type) {
/* 492 */     return withDefaultConfiguration().toConstructor(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toConstructor(TypeDescription typeDescription) {
/* 506 */     return withDefaultConfiguration().toConstructor(typeDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toField(String name) {
/* 520 */     return withDefaultConfiguration().toField(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toField(String name, FieldLocator.Factory fieldLocatorFactory) {
/* 535 */     return withDefaultConfiguration().toField(name, fieldLocatorFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toField(String name, MethodGraph.Compiler methodGraphCompiler) {
/* 550 */     return withDefaultConfiguration().toField(name, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toField(String name, FieldLocator.Factory fieldLocatorFactory, MethodGraph.Compiler methodGraphCompiler) {
/* 566 */     return withDefaultConfiguration().toField(name, fieldLocatorFactory, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toMethodReturnOf(String name) {
/* 580 */     return withDefaultConfiguration().toMethodReturnOf(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.MethodDelegation toMethodReturnOf(String name, MethodGraph.Compiler methodGraphCompiler) {
/* 595 */     return withDefaultConfiguration().toMethodReturnOf(name, methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithCustomProperties withDefaultConfiguration() {
/* 606 */     return new WithCustomProperties(MethodDelegationBinder.AmbiguityResolver.DEFAULT, TargetMethodAnnotationDrivenBinder.ParameterBinder.DEFAULTS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithCustomProperties withEmptyConfiguration() {
/* 617 */     return new WithCustomProperties((MethodDelegationBinder.AmbiguityResolver)MethodDelegationBinder.AmbiguityResolver.NoOp.INSTANCE, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.Composable withAssigner(Assigner assigner) {
/* 627 */     return new net.bytebuddy.implementation.MethodDelegation(this.implementationDelegate, this.parameterBinders, this.ambiguityResolver, this.terminationHandler, this.bindingResolver, assigner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation andThen(Implementation implementation) {
/* 639 */     return (Implementation)new Implementation.Compound(new Implementation[] { (Implementation)new net.bytebuddy.implementation.MethodDelegation(this.implementationDelegate, this.parameterBinders, this.ambiguityResolver, (MethodDelegationBinder.TerminationHandler)MethodDelegationBinder.TerminationHandler.Default.DROPPING, this.bindingResolver, this.assigner), implementation });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.Composable andThen(Implementation.Composable implementation) {
/* 651 */     return (Implementation.Composable)new Implementation.Compound.Composable((Implementation)new net.bytebuddy.implementation.MethodDelegation(this.implementationDelegate, this.parameterBinders, this.ambiguityResolver, (MethodDelegationBinder.TerminationHandler)MethodDelegationBinder.TerminationHandler.Default.DROPPING, this.bindingResolver, this.assigner), implementation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 663 */     return this.implementationDelegate.prepare(instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 670 */     ImplementationDelegate.Compiled compiled = this.implementationDelegate.compile(implementationTarget.getInstrumentedType());
/* 671 */     return (ByteCodeAppender)new Appender(implementationTarget, (MethodDelegationBinder.Record)new MethodDelegationBinder.Processor(compiled
/* 672 */           .getRecords(), this.ambiguityResolver, this.bindingResolver), this.terminationHandler, this.assigner, compiled);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.implementationDelegate.equals(((net.bytebuddy.implementation.MethodDelegation)paramObject).implementationDelegate) ? false : (!this.parameterBinders.equals(((net.bytebuddy.implementation.MethodDelegation)paramObject).parameterBinders) ? false : (!this.ambiguityResolver.equals(((net.bytebuddy.implementation.MethodDelegation)paramObject).ambiguityResolver) ? false : (!this.terminationHandler.equals(((net.bytebuddy.implementation.MethodDelegation)paramObject).terminationHandler) ? false : (!this.bindingResolver.equals(((net.bytebuddy.implementation.MethodDelegation)paramObject).bindingResolver) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.MethodDelegation)paramObject).assigner)))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (((((getClass().hashCode() * 31 + this.implementationDelegate.hashCode()) * 31 + this.parameterBinders.hashCode()) * 31 + this.ambiguityResolver.hashCode()) * 31 + this.terminationHandler.hashCode()) * 31 + this.bindingResolver.hashCode()) * 31 + this.assigner.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\MethodDelegation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */