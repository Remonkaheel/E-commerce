/*    */ package META-INF.versions.9.net.bytebuddy.implementation.auxiliary;
/*    */ 
/*    */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*    */ import net.bytebuddy.ClassFileVersion;
/*    */ import net.bytebuddy.description.modifier.ModifierContributor;
/*    */ import net.bytebuddy.description.modifier.SyntheticState;
/*    */ import net.bytebuddy.dynamic.DynamicType;
/*    */ import net.bytebuddy.implementation.MethodAccessorFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AuxiliaryType
/*    */ {
/*    */   @SuppressFBWarnings(value = {"MS_MUTABLE_ARRAY", "MS_OOI_PKGPROTECT"}, justification = "The array is not modified by class contract.")
/* 44 */   public static final ModifierContributor.ForType[] DEFAULT_TYPE_MODIFIER = new ModifierContributor.ForType[] { (ModifierContributor.ForType)SyntheticState.SYNTHETIC };
/*    */   
/*    */   DynamicType make(String paramString, ClassFileVersion paramClassFileVersion, MethodAccessorFactory paramMethodAccessorFactory);
/*    */   
/*    */   String getSuffix();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\auxiliary\AuxiliaryType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */