package META-INF.versions.9.net.bytebuddy.description;

import net.bytebuddy.description.type.TypeDefinition;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface DeclaredByType {
  @MaybeNull
  TypeDefinition getDeclaringType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\DeclaredByType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */