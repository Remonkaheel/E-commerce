/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum StackSize
/*     */ {
/*  31 */   ZERO(0),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   SINGLE(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   DOUBLE(2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StackSize(int size) {
/*  54 */     this.size = size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.StackSize of(Class<?> type) {
/*  64 */     if (type == void.class)
/*  65 */       return ZERO; 
/*  66 */     if (type == double.class || type == long.class) {
/*  67 */       return DOUBLE;
/*     */     }
/*  69 */     return SINGLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.StackSize of(int size) {
/*  80 */     switch (size) {
/*     */       case 0:
/*  82 */         return ZERO;
/*     */       case 1:
/*  84 */         return SINGLE;
/*     */       case 2:
/*  86 */         return DOUBLE;
/*     */     } 
/*  88 */     throw new IllegalArgumentException("Unexpected stack size value: " + size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int of(TypeDefinition... typeDefinition) {
/*  99 */     return of(Arrays.asList(typeDefinition));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int of(Collection<? extends TypeDefinition> typeDefinitions) {
/* 109 */     int size = 0;
/* 110 */     for (TypeDefinition typeDefinition : typeDefinitions) {
/* 111 */       size += typeDefinition.getStackSize().getSize();
/*     */     }
/* 113 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 122 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size toIncreasingSize() {
/* 133 */     return new StackManipulation.Size(getSize(), getSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation.Size toDecreasingSize() {
/* 144 */     return new StackManipulation.Size(-1 * getSize(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.bytecode.StackSize maximum(net.bytebuddy.implementation.bytecode.StackSize stackSize) {
/* 154 */     switch (null.$SwitchMap$net$bytebuddy$implementation$bytecode$StackSize[ordinal()]) {
/*     */       case 3:
/* 156 */         return stackSize;
/*     */       case 2:
/* 158 */         switch (null.$SwitchMap$net$bytebuddy$implementation$bytecode$StackSize[stackSize.ordinal()]) {
/*     */           case 1:
/* 160 */             return stackSize;
/*     */           case 2:
/*     */           case 3:
/* 163 */             return this;
/*     */         } 
/* 165 */         throw new AssertionError();
/*     */       
/*     */       case 1:
/* 168 */         return this;
/*     */     } 
/* 170 */     throw new AssertionError();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\StackSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */