/*    */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.constant;
/*    */ 
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*    */ import net.bytebuddy.implementation.bytecode.StackSize;
/*    */ import net.bytebuddy.jar.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FloatConstant
/*    */   implements StackManipulation
/*    */ {
/* 33 */   ZERO(11),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   ONE(12),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   TWO(13);
/*    */   private static final StackManipulation.Size SIZE;
/*    */   private final int opcode;
/*    */   
/*    */   static {
/* 48 */     SIZE = StackSize.SINGLE.toIncreasingSize();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   FloatConstant(int opcode) {
/* 61 */     this.opcode = opcode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StackManipulation forValue(float value) {
/* 73 */     if (value == 0.0F)
/* 74 */       return ZERO; 
/* 75 */     if (value == 1.0F)
/* 76 */       return ONE; 
/* 77 */     if (value == 2.0F) {
/* 78 */       return TWO;
/*    */     }
/* 80 */     return (StackManipulation)new ConstantPool(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 88 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 95 */     methodVisitor.visitInsn(this.opcode);
/* 96 */     return SIZE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\constant\FloatConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */