package META-INF.versions.9.net.bytebuddy.implementation.attribute;

import net.bytebuddy.description.annotation.AnnotationDescription;
import net.bytebuddy.description.method.MethodDescription;

public interface AnnotationValueFilter {
  boolean isRelevant(AnnotationDescription paramAnnotationDescription, MethodDescription.InDefinedShape paramInDefinedShape);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\attribute\AnnotationValueFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */