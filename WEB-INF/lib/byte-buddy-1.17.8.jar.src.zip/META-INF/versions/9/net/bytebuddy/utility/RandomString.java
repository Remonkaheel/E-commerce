/*     */ package META-INF.versions.9.net.bytebuddy.utility;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.util.Random;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomString
/*     */ {
/*     */   public static final int DEFAULT_LENGTH = 8;
/*     */   private static final char[] SYMBOL;
/*     */   private static final int KEY_BITS;
/*     */   private final Random random;
/*     */   private final int length;
/*     */   
/*     */   static {
/*  47 */     StringBuilder symbol = new StringBuilder(); char character;
/*  48 */     for (character = '0'; character <= '9'; character = (char)(character + 1)) {
/*  49 */       symbol.append(character);
/*     */     }
/*  51 */     for (character = 'a'; character <= 'z'; character = (char)(character + 1)) {
/*  52 */       symbol.append(character);
/*     */     }
/*  54 */     for (character = 'A'; character <= 'Z'; character = (char)(character + 1)) {
/*  55 */       symbol.append(character);
/*     */     }
/*  57 */     SYMBOL = symbol.toString().toCharArray();
/*  58 */     int bits = 32 - Integer.numberOfLeadingZeros(SYMBOL.length);
/*  59 */     KEY_BITS = bits - ((Integer.bitCount(SYMBOL.length) == bits) ? 0 : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomString() {
/*  77 */     this(8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomString(int length) {
/*  86 */     this(length, new Random());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RandomString(int length, Random random) {
/*  96 */     if (length <= 0) {
/*  97 */       throw new IllegalArgumentException("A random string's length cannot be zero or negative");
/*     */     }
/*  99 */     this.length = length;
/* 100 */     this.random = random;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String make() {
/* 109 */     return make(8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String make(int length) {
/* 119 */     return (new net.bytebuddy.utility.RandomString(length)).nextString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hashOf(@MaybeNull Object value) {
/* 130 */     return hashOf((value == null) ? 0 : (value
/*     */         
/* 132 */         .getClass().hashCode() ^ System.identityHashCode(value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hashOf(int value) {
/* 143 */     char[] buffer = new char[32 / KEY_BITS + ((32 % KEY_BITS == 0) ? 0 : 1)];
/* 144 */     for (int index = 0; index < buffer.length; index++) {
/* 145 */       buffer[index] = SYMBOL[value >>> index * KEY_BITS & -1 >>> 32 - KEY_BITS];
/*     */     }
/* 147 */     return new String(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"DMI_RANDOM_USED_ONLY_ONCE"}, justification = "Random value is used on each invocation.")
/*     */   public String nextString() {
/* 157 */     char[] buffer = new char[this.length];
/* 158 */     for (int index = 0; index < this.length; index++) {
/* 159 */       buffer[index] = SYMBOL[this.random.nextInt(SYMBOL.length)];
/*     */     }
/* 161 */     return new String(buffer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\RandomString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */