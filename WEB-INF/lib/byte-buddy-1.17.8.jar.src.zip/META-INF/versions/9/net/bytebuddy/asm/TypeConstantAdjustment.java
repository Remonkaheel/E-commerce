/*    */ package META-INF.versions.9.net.bytebuddy.asm;
/*    */ 
/*    */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*    */ import net.bytebuddy.description.field.FieldDescription;
/*    */ import net.bytebuddy.description.field.FieldList;
/*    */ import net.bytebuddy.description.method.MethodList;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.jar.asm.ClassVisitor;
/*    */ import net.bytebuddy.pool.TypePool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TypeConstantAdjustment
/*    */   implements AsmVisitorWrapper
/*    */ {
/* 48 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int mergeWriter(int flags) {
/* 54 */     return flags;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int mergeReader(int flags) {
/* 61 */     return flags;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 75 */     return (ClassVisitor)new TypeConstantDissolvingClassVisitor(classVisitor);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\TypeConstantAdjustment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */