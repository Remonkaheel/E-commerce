/*     */ package META-INF.versions.9.net.bytebuddy.implementation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationValue;
/*     */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.dynamic.scaffold.FieldLocator;
/*     */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.ConstantValue;
/*     */ import net.bytebuddy.utility.JavaConstant;
/*     */ import net.bytebuddy.utility.JavaType;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class InvokeDynamic
/*     */   implements Implementation.Composable
/*     */ {
/*     */   protected final MethodDescription.InDefinedShape bootstrap;
/*     */   protected final List<? extends JavaConstant> arguments;
/*     */   protected final InvocationProvider invocationProvider;
/*     */   protected final TerminationHandler terminationHandler;
/*     */   protected final Assigner assigner;
/*     */   protected final Assigner.Typing typing;
/*     */   
/*     */   protected InvokeDynamic(MethodDescription.InDefinedShape bootstrap, List<? extends JavaConstant> arguments, InvocationProvider invocationProvider, TerminationHandler terminationHandler, Assigner assigner, Assigner.Typing typing) {
/* 112 */     this.bootstrap = bootstrap;
/* 113 */     this.arguments = arguments;
/* 114 */     this.invocationProvider = invocationProvider;
/* 115 */     this.terminationHandler = terminationHandler;
/* 116 */     this.assigner = assigner;
/* 117 */     this.typing = typing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitTarget bootstrap(Method method, Object... constant) {
/* 132 */     return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), constant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitTarget bootstrap(Method method, List<?> constants) {
/* 147 */     return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), constants);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitTarget bootstrap(Constructor<?> constructor, Object... constant) {
/* 162 */     return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), constant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitTarget bootstrap(Constructor<?> constructor, List<?> constants) {
/* 177 */     return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), constants);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitTarget bootstrap(MethodDescription.InDefinedShape bootstrap, Object... constant) {
/* 192 */     return bootstrap(bootstrap, Arrays.asList(constant));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitTarget bootstrap(MethodDescription.InDefinedShape bootstrap, List<?> constants) {
/* 207 */     List<JavaConstant> arguments = JavaConstant.Simple.wrap(constants);
/* 208 */     if (!bootstrap.isInvokeBootstrap((List)TypeList.Explicit.of(arguments))) {
/* 209 */       throw new IllegalArgumentException("Not a valid bootstrap method " + bootstrap + " for " + arguments);
/*     */     }
/* 211 */     return new WithImplicitTarget(bootstrap, arguments, (InvocationProvider)new InvocationProvider.Default(), TerminationHandler.RETURNING, Assigner.DEFAULT, Assigner.Typing.STATIC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitArguments lambda(Method method, Type functionalInterface) {
/* 236 */     return lambda((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), (TypeDefinition)TypeDefinition.Sort.describe(functionalInterface));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitArguments lambda(Method method, Type functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 257 */     return lambda((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), (TypeDefinition)TypeDefinition.Sort.describe(functionalInterface), methodGraphCompiler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitArguments lambda(MethodDescription.InDefinedShape methodDescription, TypeDefinition functionalInterface) {
/* 277 */     return lambda(methodDescription, functionalInterface, MethodGraph.Compiler.Default.forJavaHierarchy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WithImplicitArguments lambda(MethodDescription.InDefinedShape methodDescription, TypeDefinition functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 300 */     if (!functionalInterface.isInterface()) {
/* 301 */       throw new IllegalArgumentException(functionalInterface + " is not an interface type");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 306 */     MethodList<?> methods = (MethodList)methodGraphCompiler.compile(functionalInterface).listNodes().asMethodList().filter((ElementMatcher)ElementMatchers.isAbstract());
/* 307 */     if (methods.size() != 1) {
/* 308 */       throw new IllegalArgumentException(functionalInterface + " does not define exactly one abstract method: " + methods);
/*     */     }
/* 310 */     return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.Latent((TypeDescription)new TypeDescription.Latent("java.lang.invoke.LambdaMetafactory", 1, 
/*     */             
/* 312 */             TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), new TypeDescription.Generic[0]), "metafactory", 9, 
/*     */ 
/*     */           
/* 315 */           Collections.emptyList(), JavaType.CALL_SITE
/* 316 */           .getTypeStub().asGenericType(), 
/* 317 */           Arrays.asList(new ParameterDescription.Token[] { new ParameterDescription.Token(JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().asGenericType()), new ParameterDescription.Token(
/* 318 */                 TypeDescription.ForLoadedType.of(String.class).asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 319 */                 .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 320 */                 .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_HANDLE
/* 321 */                 .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 322 */                 .getTypeStub().asGenericType())
/* 323 */             }, ), Collections.emptyList(), 
/* 324 */           Collections.emptyList(), AnnotationValue.UNDEFINED, TypeDescription.Generic.UNDEFINED), new Object[] {
/*     */ 
/*     */           
/* 327 */           JavaConstant.MethodType.ofSignature((MethodDescription)methods.asDefined().getOnly()), 
/* 328 */           JavaConstant.MethodHandle.of(methodDescription), 
/* 329 */           JavaConstant.MethodType.ofSignature((MethodDescription)methods.getOnly()) }).invoke(((MethodDescription.InDefinedShape)methods.asDefined().getOnly()).getInternalName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withBooleanValue(boolean... value) {
/* 340 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 341 */     for (boolean aValue : value) {
/* 342 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForBooleanConstant(aValue));
/*     */     }
/* 344 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 346 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withByteValue(byte... value) {
/* 360 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 361 */     for (byte aValue : value) {
/* 362 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForByteConstant(aValue));
/*     */     }
/* 364 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 366 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withShortValue(short... value) {
/* 380 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 381 */     for (short aValue : value) {
/* 382 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForShortConstant(aValue));
/*     */     }
/* 384 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 386 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withCharacterValue(char... value) {
/* 400 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 401 */     for (char aValue : value) {
/* 402 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForCharacterConstant(aValue));
/*     */     }
/* 404 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 406 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withIntegerValue(int... value) {
/* 420 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 421 */     for (int aValue : value) {
/* 422 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForIntegerConstant(aValue));
/*     */     }
/* 424 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 426 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withLongValue(long... value) {
/* 440 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 441 */     for (long aValue : value) {
/* 442 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForLongConstant(aValue));
/*     */     }
/* 444 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 446 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withFloatValue(float... value) {
/* 460 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 461 */     for (float aValue : value) {
/* 462 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForFloatConstant(aValue));
/*     */     }
/* 464 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 466 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withDoubleValue(double... value) {
/* 480 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 481 */     for (double aValue : value) {
/* 482 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForDoubleConstant(aValue));
/*     */     }
/* 484 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 486 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withValue(Object... value) {
/* 504 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 505 */     for (Object aValue : value) {
/* 506 */       argumentProviders.add(InvocationProvider.ArgumentProvider.ConstantPoolWrapper.of(aValue));
/*     */     }
/* 508 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 510 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithImplicitType withReference(Object value) {
/* 526 */     return (WithImplicitType)new WithImplicitType.OfInstance(this.bootstrap, this.arguments, this.invocationProvider, this.terminationHandler, this.assigner, this.typing, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withReference(Object... value) {
/* 544 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(value.length);
/* 545 */     for (Object aValue : value) {
/* 546 */       argumentProviders.add(InvocationProvider.ArgumentProvider.ForInstance.of(aValue));
/*     */     }
/* 548 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 550 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withType(TypeDescription... typeDescription) {
/* 565 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(typeDescription.length);
/* 566 */     for (TypeDescription aTypeDescription : typeDescription) {
/* 567 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForClassConstant(aTypeDescription));
/*     */     }
/* 569 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 571 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withEnumeration(EnumerationDescription... enumerationDescription) {
/* 586 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(enumerationDescription.length);
/* 587 */     for (EnumerationDescription anEnumerationDescription : enumerationDescription) {
/* 588 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForEnumerationValue(anEnumerationDescription));
/*     */     }
/* 590 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 592 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withInstance(ConstantValue... constant) {
/* 607 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(constant.length);
/* 608 */     for (ConstantValue aConstant : constant) {
/* 609 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForJavaConstant(aConstant));
/*     */     }
/* 611 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 613 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withInstance(JavaConstant... constant) {
/* 628 */     return withInstance((ConstantValue[])constant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withNullValue(Class<?>... type) {
/* 638 */     return withNullValue((TypeDescription[])(new TypeList.ForLoadedTypes(type)).toArray((Object[])new TypeDescription[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withNullValue(TypeDescription... typeDescription) {
/* 648 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(typeDescription.length);
/* 649 */     for (TypeDescription aTypeDescription : typeDescription) {
/* 650 */       if (aTypeDescription.isPrimitive()) {
/* 651 */         throw new IllegalArgumentException("Cannot assign null to primitive type: " + aTypeDescription);
/*     */       }
/* 653 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForNullValue(aTypeDescription));
/*     */     } 
/* 655 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 657 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withArgument(int... index) {
/* 670 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(index.length);
/* 671 */     for (int anIndex : index) {
/* 672 */       if (anIndex < 0) {
/* 673 */         throw new IllegalArgumentException("Method parameter indices cannot be negative: " + anIndex);
/*     */       }
/* 675 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForMethodParameter(anIndex));
/*     */     } 
/* 677 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 679 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithImplicitType withArgument(int index) {
/* 693 */     if (index < 0) {
/* 694 */       throw new IllegalArgumentException("Method parameter indices cannot be negative: " + index);
/*     */     }
/* 696 */     return (WithImplicitType)new WithImplicitType.OfArgument(this.bootstrap, this.arguments, this.invocationProvider, this.terminationHandler, this.assigner, this.typing, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withThis(Class<?>... type) {
/* 713 */     return withThis((TypeDescription[])(new TypeList.ForLoadedTypes(type)).toArray((Object[])new TypeDescription[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withThis(TypeDescription... typeDescription) {
/* 724 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(typeDescription.length);
/* 725 */     for (TypeDescription aTypeDescription : typeDescription) {
/* 726 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForThisInstance(aTypeDescription));
/*     */     }
/* 728 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 730 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withMethodArguments() {
/* 742 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 744 */         .appendArgument((InvocationProvider.ArgumentProvider)InvocationProvider.ArgumentProvider.ForInterceptedMethodParameters.INSTANCE), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withImplicitAndMethodArguments() {
/* 757 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 759 */         .appendArgument((InvocationProvider.ArgumentProvider)InvocationProvider.ArgumentProvider.ForInterceptedMethodInstanceAndParameters.INSTANCE), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withField(String... name) {
/* 773 */     return withField((FieldLocator.Factory)FieldLocator.ForClassHierarchy.Factory.INSTANCE, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public net.bytebuddy.implementation.InvokeDynamic withField(FieldLocator.Factory fieldLocatorFactory, String... name) {
/* 785 */     List<InvocationProvider.ArgumentProvider> argumentProviders = new ArrayList<>(name.length);
/* 786 */     for (String aName : name) {
/* 787 */       argumentProviders.add(new InvocationProvider.ArgumentProvider.ForField(aName, fieldLocatorFactory));
/*     */     }
/* 789 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider
/*     */         
/* 791 */         .appendArguments(argumentProviders), this.terminationHandler, this.assigner, this.typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithImplicitType withField(String name) {
/* 805 */     return withField(name, (FieldLocator.Factory)FieldLocator.ForClassHierarchy.Factory.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WithImplicitType withField(String name, FieldLocator.Factory fieldLocatorFactory) {
/* 817 */     return (WithImplicitType)new WithImplicitType.OfField(this.bootstrap, this.arguments, this.invocationProvider, this.terminationHandler, this.assigner, this.typing, name, fieldLocatorFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.Composable withAssigner(Assigner assigner, Assigner.Typing typing) {
/* 836 */     return new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider, this.terminationHandler, assigner, typing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation andThen(Implementation implementation) {
/* 848 */     return (Implementation)new Implementation.Compound(new Implementation[] { (Implementation)new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider, TerminationHandler.DROPPING, this.assigner, this.typing), implementation });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.Composable andThen(Implementation.Composable implementation) {
/* 861 */     return (Implementation.Composable)new Implementation.Compound.Composable((Implementation)new net.bytebuddy.implementation.InvokeDynamic(this.bootstrap, this.arguments, this.invocationProvider, TerminationHandler.DROPPING, this.assigner, this.typing), implementation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 874 */     return this.invocationProvider.prepare(instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 881 */     return (ByteCodeAppender)new Appender(this, implementationTarget.getInstrumentedType());
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.terminationHandler.equals(((net.bytebuddy.implementation.InvokeDynamic)paramObject).terminationHandler) ? false : (!this.typing.equals(((net.bytebuddy.implementation.InvokeDynamic)paramObject).typing) ? false : (!this.bootstrap.equals(((net.bytebuddy.implementation.InvokeDynamic)paramObject).bootstrap) ? false : (!this.arguments.equals(((net.bytebuddy.implementation.InvokeDynamic)paramObject).arguments) ? false : (!this.invocationProvider.equals(((net.bytebuddy.implementation.InvokeDynamic)paramObject).invocationProvider) ? false : (!!this.assigner.equals(((net.bytebuddy.implementation.InvokeDynamic)paramObject).assigner)))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (((((getClass().hashCode() * 31 + this.bootstrap.hashCode()) * 31 + this.arguments.hashCode()) * 31 + this.invocationProvider.hashCode()) * 31 + this.terminationHandler.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\InvokeDynamic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */