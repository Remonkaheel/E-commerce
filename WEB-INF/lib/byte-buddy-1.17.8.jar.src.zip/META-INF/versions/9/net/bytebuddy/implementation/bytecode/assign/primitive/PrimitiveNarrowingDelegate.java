/*     */ package META-INF.versions.9.net.bytebuddy.implementation.bytecode.assign.primitive;
/*     */ 
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PrimitiveNarrowingDelegate
/*     */ {
/*  36 */   BOOLEAN((StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   BYTE((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 146 }, StackSize.ZERO
/*     */ 
/*     */ 
/*     */       
/*  52 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   SHORT((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 145 }, StackSize.ZERO
/*     */       
/*  63 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 146 }, StackSize.ZERO
/*     */ 
/*     */       
/*  66 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   CHARACTER((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 145 }, StackSize.ZERO
/*     */       
/*  77 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 147 }, StackSize.ZERO
/*     */       
/*  79 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   INTEGER((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 145 }, StackSize.ZERO
/*     */       
/*  91 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 147 }, StackSize.ZERO
/*     */       
/*  93 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 146 }, StackSize.ZERO
/*     */       
/*  95 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   LONG((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 136, 145 }, StackSize.SINGLE
/*     */       
/* 106 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 136, 147 }, StackSize.SINGLE
/*     */       
/* 108 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 136, 146 }, StackSize.SINGLE
/*     */       
/* 110 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 136 }, StackSize.SINGLE
/*     */       
/* 112 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   FLOAT((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 139, 145 }, StackSize.ZERO
/*     */       
/* 122 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 139, 147 }, StackSize.ZERO
/*     */       
/* 124 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 139, 146 }, StackSize.ZERO
/*     */       
/* 126 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 139 }, StackSize.ZERO
/*     */       
/* 128 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 140 }, StackSize.SINGLE
/*     */       
/* 130 */       .toIncreasingSize()), (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Illegal.INSTANCE),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   DOUBLE((StackManipulation)StackManipulation.Illegal.INSTANCE, (StackManipulation)new NarrowingStackManipulation(new int[] { 142, 145 }, StackSize.SINGLE
/*     */       
/* 139 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 142, 147 }, StackSize.SINGLE
/*     */       
/* 141 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 142, 146 }, StackSize.SINGLE
/*     */       
/* 143 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 142 }, StackSize.SINGLE
/*     */       
/* 145 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 143 }, StackSize.ZERO
/*     */       
/* 147 */       .toDecreasingSize()), (StackManipulation)new NarrowingStackManipulation(new int[] { 144 }, StackSize.SINGLE
/*     */       
/* 149 */       .toDecreasingSize()), (StackManipulation)StackManipulation.Trivial.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toBooleanStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toByteStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toShortStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toCharacterStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toIntegerStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toLongStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toFloatStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StackManipulation toDoubleStackManipulation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrimitiveNarrowingDelegate(StackManipulation toBooleanStackManipulation, StackManipulation toByteStackManipulation, StackManipulation toShortStackManipulation, StackManipulation toCharacterStackManipulation, StackManipulation toIntegerStackManipulation, StackManipulation toLongStackManipulation, StackManipulation toFloatStackManipulation, StackManipulation toDoubleStackManipulation) {
/* 220 */     this.toBooleanStackManipulation = toBooleanStackManipulation;
/* 221 */     this.toByteStackManipulation = toByteStackManipulation;
/* 222 */     this.toShortStackManipulation = toShortStackManipulation;
/* 223 */     this.toCharacterStackManipulation = toCharacterStackManipulation;
/* 224 */     this.toIntegerStackManipulation = toIntegerStackManipulation;
/* 225 */     this.toLongStackManipulation = toLongStackManipulation;
/* 226 */     this.toFloatStackManipulation = toFloatStackManipulation;
/* 227 */     this.toDoubleStackManipulation = toDoubleStackManipulation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.implementation.bytecode.assign.primitive.PrimitiveNarrowingDelegate forPrimitive(TypeDefinition typeDefinition) {
/* 237 */     if (typeDefinition.represents(boolean.class))
/* 238 */       return BOOLEAN; 
/* 239 */     if (typeDefinition.represents(byte.class))
/* 240 */       return BYTE; 
/* 241 */     if (typeDefinition.represents(short.class))
/* 242 */       return SHORT; 
/* 243 */     if (typeDefinition.represents(char.class))
/* 244 */       return CHARACTER; 
/* 245 */     if (typeDefinition.represents(int.class))
/* 246 */       return INTEGER; 
/* 247 */     if (typeDefinition.represents(long.class))
/* 248 */       return LONG; 
/* 249 */     if (typeDefinition.represents(float.class))
/* 250 */       return FLOAT; 
/* 251 */     if (typeDefinition.represents(double.class)) {
/* 252 */       return DOUBLE;
/*     */     }
/* 254 */     throw new IllegalArgumentException("Not a primitive, non-void type: " + typeDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackManipulation narrowTo(TypeDefinition typeDefinition) {
/* 265 */     if (typeDefinition.represents(boolean.class))
/* 266 */       return this.toBooleanStackManipulation; 
/* 267 */     if (typeDefinition.represents(byte.class))
/* 268 */       return this.toByteStackManipulation; 
/* 269 */     if (typeDefinition.represents(short.class))
/* 270 */       return this.toShortStackManipulation; 
/* 271 */     if (typeDefinition.represents(char.class))
/* 272 */       return this.toCharacterStackManipulation; 
/* 273 */     if (typeDefinition.represents(int.class))
/* 274 */       return this.toIntegerStackManipulation; 
/* 275 */     if (typeDefinition.represents(long.class))
/* 276 */       return this.toLongStackManipulation; 
/* 277 */     if (typeDefinition.represents(float.class))
/* 278 */       return this.toFloatStackManipulation; 
/* 279 */     if (typeDefinition.represents(double.class)) {
/* 280 */       return this.toDoubleStackManipulation;
/*     */     }
/* 282 */     throw new IllegalArgumentException("Not a primitive non-void type: " + typeDefinition);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\bytecode\assign\primitive\PrimitiveNarrowingDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */