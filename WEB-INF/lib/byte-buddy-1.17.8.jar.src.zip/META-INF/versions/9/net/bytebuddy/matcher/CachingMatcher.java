/*    */ package META-INF.versions.9.net.bytebuddy.matcher;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance(permitSubclassEquality = true)
/*    */ public class CachingMatcher<T>
/*    */   extends ElementMatcher.Junction.AbstractBase<T>
/*    */ {
/*    */   private static final Object NULL_VALUE;
/*    */   private final ElementMatcher<? super T> matcher;
/*    */   @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.IGNORE)
/*    */   protected final ConcurrentMap<? super T, Boolean> map;
/*    */   
/*    */   public CachingMatcher(ElementMatcher<? super T> matcher, ConcurrentMap<? super T, Boolean> map) {
/* 57 */     this.matcher = matcher;
/* 58 */     this.map = map;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matches(@MaybeNull T target) {
/* 65 */     Boolean cached = this.map.get((target == null) ? NULL_VALUE : target);
/*    */ 
/*    */     
/* 68 */     if (cached == null) {
/* 69 */       cached = Boolean.valueOf(onCacheMiss(target));
/*    */     }
/* 71 */     return cached.booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean onCacheMiss(@MaybeNull T target) {
/* 82 */     boolean cached = this.matcher.matches(target);
/* 83 */     this.map.put((target == null) ? (T)NULL_VALUE : target, 
/*    */         
/* 85 */         Boolean.valueOf(cached));
/* 86 */     return cached;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return "cached(" + this.matcher + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : (!(paramObject instanceof net.bytebuddy.matcher.CachingMatcher) ? false : (!!this.matcher.equals(((net.bytebuddy.matcher.CachingMatcher)paramObject).matcher)));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return net.bytebuddy.matcher.CachingMatcher.class.hashCode() * 31 + this.matcher.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\matcher\CachingMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */