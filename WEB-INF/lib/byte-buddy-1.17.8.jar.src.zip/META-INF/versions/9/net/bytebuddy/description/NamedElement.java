/*    */ package META-INF.versions.9.net.bytebuddy.description;
/*    */ 
/*    */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface NamedElement
/*    */ {
/*    */   @AlwaysNull
/* 30 */   public static final String NO_NAME = null;
/*    */   public static final String EMPTY_NAME = "";
/*    */   
/*    */   String getActualName();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\description\NamedElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */