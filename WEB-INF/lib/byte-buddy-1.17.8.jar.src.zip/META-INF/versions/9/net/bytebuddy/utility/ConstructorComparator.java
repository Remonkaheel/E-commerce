/*    */ package META-INF.versions.9.net.bytebuddy.utility;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ConstructorComparator
/*    */   implements Comparator<Constructor<?>>
/*    */ {
/* 29 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compare(Constructor<?> left, Constructor<?> right) {
/* 35 */     if (left == right) {
/* 36 */       return 0;
/*    */     }
/* 38 */     int comparison = left.getName().compareTo(right.getName());
/* 39 */     if (comparison == 0) {
/* 40 */       Class<?>[] leftParameterType = left.getParameterTypes(), rightParameterType = right.getParameterTypes();
/* 41 */       if (leftParameterType.length < rightParameterType.length)
/* 42 */         return -1; 
/* 43 */       if (leftParameterType.length > rightParameterType.length) {
/* 44 */         return 1;
/*    */       }
/* 46 */       for (int index = 0; index < leftParameterType.length; index++) {
/* 47 */         int comparisonParameterType = leftParameterType[index].getName().compareTo(rightParameterType[index].getName());
/* 48 */         if (comparisonParameterType != 0) {
/* 49 */           return comparisonParameterType;
/*    */         }
/*    */       } 
/* 52 */       return 0;
/*    */     } 
/*    */     
/* 55 */     return comparison;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\ConstructorComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */