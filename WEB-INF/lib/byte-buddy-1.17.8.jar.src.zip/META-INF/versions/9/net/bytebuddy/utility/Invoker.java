package META-INF.versions.9.net.bytebuddy.utility;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface Invoker {
  Object newInstance(Constructor<?> paramConstructor, Object[] paramArrayOfObject) throws InstantiationException, IllegalAccessException, InvocationTargetException;
  
  @MaybeNull
  Object invoke(Method paramMethod, @MaybeNull Object paramObject, @MaybeNull Object[] paramArrayOfObject) throws IllegalAccessException, InvocationTargetException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebudd\\utility\Invoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */