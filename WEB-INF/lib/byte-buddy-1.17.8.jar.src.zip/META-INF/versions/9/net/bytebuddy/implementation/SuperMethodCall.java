/*    */ package META-INF.versions.9.net.bytebuddy.implementation;
/*    */ 
/*    */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*    */ import net.bytebuddy.implementation.Implementation;
/*    */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SuperMethodCall
/*    */   implements Implementation.Composable
/*    */ {
/* 43 */   INSTANCE;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 49 */     return instrumentedType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 56 */     return (ByteCodeAppender)new Appender(implementationTarget, Appender.TerminationHandler.RETURNING);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Implementation andThen(Implementation implementation) {
/* 63 */     return (Implementation)new Implementation.Compound(new Implementation[] { (Implementation)WithoutReturn.INSTANCE, implementation });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Implementation.Composable andThen(Implementation.Composable implementation) {
/* 70 */     return (Implementation.Composable)new Implementation.Compound.Composable((Implementation)WithoutReturn.INSTANCE, implementation);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\SuperMethodCall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */