package META-INF.versions.9.net.bytebuddy.implementation;

import net.bytebuddy.dynamic.scaffold.InstrumentedType;
import net.bytebuddy.implementation.bytecode.ByteCodeAppender;

public interface Implementation extends InstrumentedType.Prepareable {
  ByteCodeAppender appender(Target paramTarget);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\implementation\Implementation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */