/*     */ package META-INF.versions.9.net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class AnnotationRemoval
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private static final int METHOD_NONE = -4;
/*     */   private static final int METHOD_ALL = -3;
/*     */   private static final int METHOD_ONLY = -2;
/*     */   private static final int METHOD_PARAMETERS = -1;
/*     */   private final boolean type;
/*     */   private final ElementMatcher<? super FieldDescription.InDefinedShape> fieldMatcher;
/*     */   private final ElementMatcher<? super MethodDescription> methodMatcher;
/*     */   private final ElementMatcher<? super AnnotationDescription> annotationMatcher;
/*     */   private final int parameters;
/*     */   
/*     */   protected AnnotationRemoval(boolean type, ElementMatcher<? super FieldDescription.InDefinedShape> fieldMatcher, ElementMatcher<? super MethodDescription> methodMatcher, ElementMatcher<? super AnnotationDescription> annotationMatcher, int parameters) {
/* 109 */     this.type = type;
/* 110 */     this.fieldMatcher = fieldMatcher;
/* 111 */     this.methodMatcher = methodMatcher;
/* 112 */     this.annotationMatcher = annotationMatcher;
/* 113 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static net.bytebuddy.asm.AnnotationRemoval strip(ElementMatcher<? super AnnotationDescription> matcher) {
/* 123 */     return new net.bytebuddy.asm.AnnotationRemoval(true, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.any(), (ElementMatcher<? super MethodDescription>)ElementMatchers.any(), matcher, -3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onType() {
/* 132 */     return (AsmVisitorWrapper)new net.bytebuddy.asm.AnnotationRemoval(true, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), (ElementMatcher<? super MethodDescription>)ElementMatchers.none(), this.annotationMatcher, -4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onFields(ElementMatcher<? super FieldDescription> matcher) {
/* 142 */     return (AsmVisitorWrapper)new net.bytebuddy.asm.AnnotationRemoval(false, (ElementMatcher)matcher, (ElementMatcher<? super MethodDescription>)ElementMatchers.none(), this.annotationMatcher, -4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethods(ElementMatcher<? super MethodDescription> matcher) {
/* 152 */     return onInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethodsAndParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 162 */     return onInvokablesAndParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethodParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 172 */     return onInvokableParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethodParameter(ElementMatcher<? super MethodDescription> matcher, int parameter) {
/* 184 */     return onInvokableParameter((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher), parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructors(ElementMatcher<? super MethodDescription> matcher) {
/* 194 */     return onInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructorsAndParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 204 */     return onInvokablesAndParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructorParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 214 */     return onInvokableParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructorParameter(ElementMatcher<? super MethodDescription> matcher, int parameter) {
/* 226 */     return onInvokableParameter((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher), parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokables(ElementMatcher<? super MethodDescription> matcher) {
/* 236 */     return (AsmVisitorWrapper)new net.bytebuddy.asm.AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, -2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokablesAndParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 247 */     return (AsmVisitorWrapper)new net.bytebuddy.asm.AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, -3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokableParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 258 */     return (AsmVisitorWrapper)new net.bytebuddy.asm.AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokableParameter(ElementMatcher<? super MethodDescription> matcher, int parameter) {
/* 270 */     if (parameter < 0) {
/* 271 */       throw new IllegalArgumentException("Parameter index cannot be negative: " + parameter);
/*     */     }
/* 273 */     return (AsmVisitorWrapper)new net.bytebuddy.asm.AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 287 */     Map<String, AnnotationDescription> mappedAnnotations = new HashMap<>();
/* 288 */     if (this.type) {
/* 289 */       for (AnnotationDescription annotation : instrumentedType.getDeclaredAnnotations()) {
/* 290 */         mappedAnnotations.put(annotation.getAnnotationType().getDescriptor(), annotation);
/*     */       }
/*     */     }
/* 293 */     Map<String, FieldDescription.InDefinedShape> mappedFields = new HashMap<>();
/* 294 */     for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 295 */       mappedFields.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */     }
/* 297 */     Map<String, MethodDescription> mappedMethods = new HashMap<>();
/* 298 */     for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 299 */       mappedMethods.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */     }
/* 301 */     return (ClassVisitor)new AnnotationRemovingClassVisitor(classVisitor, this.fieldMatcher, this.methodMatcher, this.annotationMatcher, this.parameters, mappedFields, mappedMethods, mappedAnnotations, null);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.type != ((net.bytebuddy.asm.AnnotationRemoval)paramObject).type) ? false : ((this.parameters != ((net.bytebuddy.asm.AnnotationRemoval)paramObject).parameters) ? false : (!this.fieldMatcher.equals(((net.bytebuddy.asm.AnnotationRemoval)paramObject).fieldMatcher) ? false : (!this.methodMatcher.equals(((net.bytebuddy.asm.AnnotationRemoval)paramObject).methodMatcher) ? false : (!!this.annotationMatcher.equals(((net.bytebuddy.asm.AnnotationRemoval)paramObject).annotationMatcher))))))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.type) * 31 + this.fieldMatcher.hashCode()) * 31 + this.methodMatcher.hashCode()) * 31 + this.annotationMatcher.hashCode()) * 31 + this.parameters;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\9\net\bytebuddy\asm\AnnotationRemoval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */