/*     */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*     */ 
/*     */ import java.lang.classfile.BufWriter;
/*     */ import java.lang.constant.ClassDesc;
/*     */ import java.lang.constant.ConstantDesc;
/*     */ import java.lang.constant.DirectMethodHandleDesc;
/*     */ import java.lang.constant.DynamicCallSiteDesc;
/*     */ import java.lang.constant.DynamicConstantDesc;
/*     */ import java.lang.constant.MethodHandleDesc;
/*     */ import java.lang.constant.MethodTypeDesc;
/*     */ import java.lang.constant.ModuleDesc;
/*     */ import java.lang.constant.PackageDesc;
/*     */ import java.util.function.IntFunction;
/*     */ import net.bytebuddy.jar.asm.ClassWriter;
/*     */ import net.bytebuddy.jar.asm.Handle;
/*     */ import net.bytebuddy.jar.asmjdkbridge.AsmAttribute;
/*     */ import net.bytebuddy.jar.asmjdkbridge.JdkClassWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DelegatingClassWriter
/*     */   extends ClassWriter
/*     */ {
/*     */   private final BufWriter delegate;
/*     */   
/*     */   private DelegatingClassWriter(BufWriter delegate) {
/* 228 */     super(0);
/* 229 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFlags(int flags) {
/* 234 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/* 239 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int newConst(Object value) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: dup
/*     */     //   2: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   5: pop
/*     */     //   6: astore_2
/*     */     //   7: iconst_0
/*     */     //   8: istore_3
/*     */     //   9: aload_2
/*     */     //   10: iload_3
/*     */     //   11: <illegal opcode> typeSwitch : (Ljava/lang/Object;I)I
/*     */     //   16: tableswitch default -> 583, 0 -> 80, 1 -> 121, 2 -> 154, 3 -> 187, 4 -> 220, 5 -> 253, 6 -> 286, 7 -> 319, 8 -> 352, 9 -> 382, 10 -> 500, 11 -> 538
/*     */     //   80: aload_2
/*     */     //   81: checkcast java/lang/Boolean
/*     */     //   84: astore #4
/*     */     //   86: aload_0
/*     */     //   87: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   90: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   95: aload #4
/*     */     //   97: invokevirtual booleanValue : ()Z
/*     */     //   100: ifeq -> 107
/*     */     //   103: iconst_1
/*     */     //   104: goto -> 108
/*     */     //   107: iconst_0
/*     */     //   108: invokeinterface intEntry : (I)Ljava/lang/classfile/constantpool/IntegerEntry;
/*     */     //   113: invokeinterface index : ()I
/*     */     //   118: goto -> 591
/*     */     //   121: aload_2
/*     */     //   122: checkcast java/lang/Byte
/*     */     //   125: astore #5
/*     */     //   127: aload_0
/*     */     //   128: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   131: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   136: aload #5
/*     */     //   138: invokevirtual byteValue : ()B
/*     */     //   141: invokeinterface intEntry : (I)Ljava/lang/classfile/constantpool/IntegerEntry;
/*     */     //   146: invokeinterface index : ()I
/*     */     //   151: goto -> 591
/*     */     //   154: aload_2
/*     */     //   155: checkcast java/lang/Short
/*     */     //   158: astore #6
/*     */     //   160: aload_0
/*     */     //   161: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   164: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   169: aload #6
/*     */     //   171: invokevirtual shortValue : ()S
/*     */     //   174: invokeinterface intEntry : (I)Ljava/lang/classfile/constantpool/IntegerEntry;
/*     */     //   179: invokeinterface index : ()I
/*     */     //   184: goto -> 591
/*     */     //   187: aload_2
/*     */     //   188: checkcast java/lang/Character
/*     */     //   191: astore #7
/*     */     //   193: aload_0
/*     */     //   194: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   197: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   202: aload #7
/*     */     //   204: invokevirtual charValue : ()C
/*     */     //   207: invokeinterface intEntry : (I)Ljava/lang/classfile/constantpool/IntegerEntry;
/*     */     //   212: invokeinterface index : ()I
/*     */     //   217: goto -> 591
/*     */     //   220: aload_2
/*     */     //   221: checkcast java/lang/Integer
/*     */     //   224: astore #8
/*     */     //   226: aload_0
/*     */     //   227: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   230: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   235: aload #8
/*     */     //   237: invokevirtual intValue : ()I
/*     */     //   240: invokeinterface intEntry : (I)Ljava/lang/classfile/constantpool/IntegerEntry;
/*     */     //   245: invokeinterface index : ()I
/*     */     //   250: goto -> 591
/*     */     //   253: aload_2
/*     */     //   254: checkcast java/lang/Long
/*     */     //   257: astore #9
/*     */     //   259: aload_0
/*     */     //   260: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   263: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   268: aload #9
/*     */     //   270: invokevirtual longValue : ()J
/*     */     //   273: invokeinterface longEntry : (J)Ljava/lang/classfile/constantpool/LongEntry;
/*     */     //   278: invokeinterface index : ()I
/*     */     //   283: goto -> 591
/*     */     //   286: aload_2
/*     */     //   287: checkcast java/lang/Float
/*     */     //   290: astore #10
/*     */     //   292: aload_0
/*     */     //   293: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   296: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   301: aload #10
/*     */     //   303: invokevirtual floatValue : ()F
/*     */     //   306: invokeinterface floatEntry : (F)Ljava/lang/classfile/constantpool/FloatEntry;
/*     */     //   311: invokeinterface index : ()I
/*     */     //   316: goto -> 591
/*     */     //   319: aload_2
/*     */     //   320: checkcast java/lang/Double
/*     */     //   323: astore #11
/*     */     //   325: aload_0
/*     */     //   326: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   329: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   334: aload #11
/*     */     //   336: invokevirtual doubleValue : ()D
/*     */     //   339: invokeinterface doubleEntry : (D)Ljava/lang/classfile/constantpool/DoubleEntry;
/*     */     //   344: invokeinterface index : ()I
/*     */     //   349: goto -> 591
/*     */     //   352: aload_2
/*     */     //   353: checkcast java/lang/String
/*     */     //   356: astore #12
/*     */     //   358: aload_0
/*     */     //   359: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   362: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   367: aload #12
/*     */     //   369: invokeinterface stringEntry : (Ljava/lang/String;)Ljava/lang/classfile/constantpool/StringEntry;
/*     */     //   374: invokeinterface index : ()I
/*     */     //   379: goto -> 591
/*     */     //   382: aload_2
/*     */     //   383: checkcast net/bytebuddy/jar/asm/Type
/*     */     //   386: astore #13
/*     */     //   388: aload #13
/*     */     //   390: invokevirtual getSort : ()I
/*     */     //   393: lookupswitch default -> 470, 10 -> 420, 11 -> 445
/*     */     //   420: aload_0
/*     */     //   421: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   424: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   429: aload #13
/*     */     //   431: invokevirtual getInternalName : ()Ljava/lang/String;
/*     */     //   434: invokestatic ofInternalName : (Ljava/lang/String;)Ljava/lang/constant/ClassDesc;
/*     */     //   437: invokeinterface classEntry : (Ljava/lang/constant/ClassDesc;)Ljava/lang/classfile/constantpool/ClassEntry;
/*     */     //   442: goto -> 492
/*     */     //   445: aload_0
/*     */     //   446: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   449: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   454: aload #13
/*     */     //   456: invokevirtual getDescriptor : ()Ljava/lang/String;
/*     */     //   459: invokestatic ofDescriptor : (Ljava/lang/String;)Ljava/lang/constant/MethodTypeDesc;
/*     */     //   462: invokeinterface methodTypeEntry : (Ljava/lang/constant/MethodTypeDesc;)Ljava/lang/classfile/constantpool/MethodTypeEntry;
/*     */     //   467: goto -> 492
/*     */     //   470: aload_0
/*     */     //   471: getfield delegate : Ljava/lang/classfile/BufWriter;
/*     */     //   474: invokeinterface constantPool : ()Ljava/lang/classfile/constantpool/ConstantPoolBuilder;
/*     */     //   479: aload #13
/*     */     //   481: invokevirtual getDescriptor : ()Ljava/lang/String;
/*     */     //   484: invokestatic ofDescriptor : (Ljava/lang/String;)Ljava/lang/constant/ClassDesc;
/*     */     //   487: invokeinterface classEntry : (Ljava/lang/constant/ClassDesc;)Ljava/lang/classfile/constantpool/ClassEntry;
/*     */     //   492: invokeinterface index : ()I
/*     */     //   497: goto -> 591
/*     */     //   500: aload_2
/*     */     //   501: checkcast net/bytebuddy/jar/asm/Handle
/*     */     //   504: astore #14
/*     */     //   506: aload_0
/*     */     //   507: aload #14
/*     */     //   509: invokevirtual getTag : ()I
/*     */     //   512: aload #14
/*     */     //   514: invokevirtual getOwner : ()Ljava/lang/String;
/*     */     //   517: aload #14
/*     */     //   519: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   522: aload #14
/*     */     //   524: invokevirtual getDesc : ()Ljava/lang/String;
/*     */     //   527: aload #14
/*     */     //   529: invokevirtual isInterface : ()Z
/*     */     //   532: invokevirtual newHandle : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)I
/*     */     //   535: goto -> 591
/*     */     //   538: aload_2
/*     */     //   539: checkcast net/bytebuddy/jar/asm/ConstantDynamic
/*     */     //   542: astore #15
/*     */     //   544: aload_0
/*     */     //   545: aload #15
/*     */     //   547: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   550: aload #15
/*     */     //   552: invokevirtual getDescriptor : ()Ljava/lang/String;
/*     */     //   555: aload #15
/*     */     //   557: invokevirtual getBootstrapMethod : ()Lnet/bytebuddy/jar/asm/Handle;
/*     */     //   560: aload #15
/*     */     //   562: invokevirtual getBootstrapMethodArgumentCount : ()I
/*     */     //   565: aload #15
/*     */     //   567: dup
/*     */     //   568: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   571: pop
/*     */     //   572: <illegal opcode> apply : (Lnet/bytebuddy/jar/asm/ConstantDynamic;)Ljava/util/function/IntFunction;
/*     */     //   577: invokevirtual newConstantDynamic : (Ljava/lang/String;Ljava/lang/String;Lnet/bytebuddy/jar/asm/Handle;ILjava/util/function/IntFunction;)I
/*     */     //   580: goto -> 591
/*     */     //   583: new java/lang/IllegalArgumentException
/*     */     //   586: dup
/*     */     //   587: invokespecial <init> : ()V
/*     */     //   590: athrow
/*     */     //   591: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #244	-> 0
/*     */     //   #245	-> 80
/*     */     //   #246	-> 121
/*     */     //   #247	-> 154
/*     */     //   #248	-> 187
/*     */     //   #249	-> 220
/*     */     //   #250	-> 253
/*     */     //   #251	-> 286
/*     */     //   #252	-> 319
/*     */     //   #253	-> 352
/*     */     //   #254	-> 382
/*     */     //   #256	-> 420
/*     */     //   #258	-> 445
/*     */     //   #259	-> 470
/*     */     //   #260	-> 492
/*     */     //   #261	-> 500
/*     */     //   #262	-> 514
/*     */     //   #263	-> 519
/*     */     //   #264	-> 524
/*     */     //   #265	-> 529
/*     */     //   #261	-> 532
/*     */     //   #266	-> 538
/*     */     //   #267	-> 552
/*     */     //   #268	-> 557
/*     */     //   #269	-> 562
/*     */     //   #270	-> 568
/*     */     //   #266	-> 577
/*     */     //   #271	-> 583
/*     */     //   #244	-> 591
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   86	35	4	constant	Ljava/lang/Boolean;
/*     */     //   127	27	5	constant	Ljava/lang/Byte;
/*     */     //   160	27	6	constant	Ljava/lang/Short;
/*     */     //   193	27	7	constant	Ljava/lang/Character;
/*     */     //   226	27	8	constant	Ljava/lang/Integer;
/*     */     //   259	27	9	constant	Ljava/lang/Long;
/*     */     //   292	27	10	constant	Ljava/lang/Float;
/*     */     //   325	27	11	constant	Ljava/lang/Double;
/*     */     //   358	24	12	constant	Ljava/lang/String;
/*     */     //   388	112	13	constant	Lnet/bytebuddy/jar/asm/Type;
/*     */     //   506	32	14	constant	Lnet/bytebuddy/jar/asm/Handle;
/*     */     //   544	39	15	constant	Lnet/bytebuddy/jar/asm/ConstantDynamic;
/*     */     //   0	592	0	this	Lnet/bytebuddy/jar/asmjdkbridge/AsmAttribute$DelegatingClassWriter;
/*     */     //   0	592	1	value	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int newUTF8(String value) {
/* 277 */     return this.delegate.constantPool().utf8Entry(value).index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newClass(String value) {
/* 282 */     return this.delegate.constantPool().classEntry(ClassDesc.ofInternalName(value)).index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newMethodType(String methodDescriptor) {
/* 287 */     return this.delegate.constantPool().methodTypeEntry(MethodTypeDesc.ofDescriptor(methodDescriptor)).index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newModule(String moduleName) {
/* 292 */     return this.delegate.constantPool().moduleEntry(ModuleDesc.of(moduleName)).index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newPackage(String packageName) {
/* 297 */     return this.delegate.constantPool().packageEntry(PackageDesc.ofInternalName(packageName)).index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newHandle(int tag, String owner, String name, String descriptor, boolean isInterface) {
/* 302 */     return this.delegate.constantPool().methodHandleEntry(MethodHandleDesc.of(
/* 303 */           DirectMethodHandleDesc.Kind.valueOf(tag, isInterface), 
/* 304 */           ClassDesc.ofInternalName(owner), name, descriptor))
/*     */       
/* 306 */       .index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newConstantDynamic(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 311 */     return newConstantDynamic(name, descriptor, bootstrapMethodHandle, bootstrapMethodArguments.length, index -> bootstrapMethodArguments[index]);
/*     */   }
/*     */   
/*     */   private int newConstantDynamic(String name, String descriptor, Handle bootstrapMethodHandle, int length, IntFunction<Object> resolver) {
/* 315 */     ConstantDesc[] constants = new ConstantDesc[length];
/* 316 */     for (int index = 0; index < length; index++) {
/* 317 */       constants[index] = JdkClassWriter.toConstantDesc(resolver.apply(index));
/*     */     }
/* 319 */     return this.delegate.constantPool().constantDynamicEntry(DynamicConstantDesc.ofNamed(
/* 320 */           MethodHandleDesc.of(
/* 321 */             DirectMethodHandleDesc.Kind.valueOf(bootstrapMethodHandle.getTag(), bootstrapMethodHandle.isInterface()), 
/* 322 */             ClassDesc.ofInternalName(bootstrapMethodHandle.getOwner()), bootstrapMethodHandle
/* 323 */             .getName(), bootstrapMethodHandle
/* 324 */             .getDesc()), name, 
/*     */           
/* 326 */           ClassDesc.ofDescriptor(descriptor), constants))
/* 327 */       .index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newInvokeDynamic(String name, String descriptor, Handle bootstrapMethodHandle, Object... bootstrapMethodArguments) {
/* 332 */     ConstantDesc[] constants = new ConstantDesc[bootstrapMethodArguments.length];
/* 333 */     for (int index = 0; index < bootstrapMethodArguments.length; index++) {
/* 334 */       constants[index] = JdkClassWriter.toConstantDesc(bootstrapMethodArguments[index]);
/*     */     }
/* 336 */     return this.delegate.constantPool().invokeDynamicEntry(DynamicCallSiteDesc.of(
/* 337 */           MethodHandleDesc.of(
/* 338 */             DirectMethodHandleDesc.Kind.valueOf(bootstrapMethodHandle.getTag(), bootstrapMethodHandle.isInterface()), 
/* 339 */             ClassDesc.ofInternalName(bootstrapMethodHandle.getOwner()), bootstrapMethodHandle
/* 340 */             .getName(), bootstrapMethodHandle
/* 341 */             .getDesc()), name, 
/*     */           
/* 343 */           MethodTypeDesc.ofDescriptor(descriptor), constants))
/* 344 */       .index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newField(String owner, String name, String descriptor) {
/* 349 */     return this.delegate.constantPool().fieldRefEntry(
/* 350 */         ClassDesc.ofInternalName(owner), name, 
/*     */         
/* 352 */         ClassDesc.ofDescriptor(descriptor)).index();
/*     */   }
/*     */ 
/*     */   
/*     */   public int newMethod(String owner, String name, String descriptor, boolean isInterface) {
/* 357 */     if (isInterface) {
/* 358 */       return this.delegate.constantPool().interfaceMethodRefEntry(
/* 359 */           ClassDesc.ofInternalName(owner), name, 
/*     */           
/* 361 */           MethodTypeDesc.ofDescriptor(descriptor)).index();
/*     */     }
/* 363 */     return this.delegate.constantPool().methodRefEntry(
/* 364 */         ClassDesc.ofInternalName(owner), name, 
/*     */         
/* 366 */         MethodTypeDesc.ofDescriptor(descriptor)).index();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int newNameType(String name, String descriptor) {
/* 372 */     return this.delegate.constantPool().nameAndTypeEntry(name, 
/*     */         
/* 374 */         ClassDesc.ofDescriptor(descriptor)).index();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmAttribute$DelegatingClassWriter.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */