/*     */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*     */ 
/*     */ import java.lang.classfile.Opcode;
/*     */ import java.lang.classfile.TypeAnnotation;
/*     */ import java.lang.classfile.TypeKind;
/*     */ import net.bytebuddy.jar.asmjdkbridge.JdkClassReader;
/*     */ 


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\JdkClassReader$1.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */