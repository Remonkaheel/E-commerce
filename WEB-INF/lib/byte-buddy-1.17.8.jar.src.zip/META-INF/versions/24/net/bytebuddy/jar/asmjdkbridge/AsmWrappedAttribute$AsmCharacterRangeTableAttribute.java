/*     */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*     */ 
/*     */ import java.lang.classfile.Attribute;
/*     */ import java.lang.classfile.attribute.CharacterRangeInfo;
/*     */ import java.lang.classfile.attribute.CharacterRangeTableAttribute;
/*     */ import java.lang.classfile.attribute.CodeAttribute;
/*     */ import java.lang.classfile.instruction.CharacterRange;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.jar.asm.ByteVector;
/*     */ import net.bytebuddy.jar.asm.ClassWriter;
/*     */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AsmCharacterRangeTableAttribute
/*     */   extends AsmWrappedAttribute<CharacterRangeTableAttribute>
/*     */ {
/*     */   AsmCharacterRangeTableAttribute(CharacterRangeTableAttribute attribute) {
/* 116 */     super((Attribute)attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   static AsmWrappedAttribute<CharacterRangeTableAttribute> of(List<CharacterRange> characterRanges, CodeAttribute codeAttribute) {
/* 121 */     return new AsmCharacterRangeTableAttribute(CharacterRangeTableAttribute.of(characterRanges.stream().map(characterRange -> CharacterRangeInfo.of(codeAttribute.labelToBci(characterRange.startScope()), codeAttribute.labelToBci(characterRange.endScope()), characterRange.characterRangeStart(), characterRange.characterRangeEnd(), characterRange.flags()))
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 126 */           .toList()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected ByteVector write(ClassWriter classWriter, byte[] code, int codeLength, int maxStack, int maxLocals) {
/* 131 */     ByteVector byteVector = new ByteVector(2 + 14 * ((CharacterRangeTableAttribute)this.attribute).characterRangeTable().size());
/* 132 */     byteVector.putShort(((CharacterRangeTableAttribute)this.attribute).characterRangeTable().size());
/* 133 */     for (CharacterRangeInfo characterRangeInfo : ((CharacterRangeTableAttribute)this.attribute).characterRangeTable()) {
/* 134 */       byteVector.putShort(characterRangeInfo.startPc());
/* 135 */       byteVector.putShort(characterRangeInfo.endPc());
/* 136 */       byteVector.putInt(characterRangeInfo.characterRangeStart());
/* 137 */       byteVector.putInt(characterRangeInfo.characterRangeEnd());
/* 138 */       byteVector.putShort(characterRangeInfo.flags());
/*     */     } 
/* 140 */     return byteVector;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCodeAttribute() {
/* 145 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmWrappedAttribute$AsmCharacterRangeTableAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */