package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;

import net.bytebuddy.jar.asm.AnnotationVisitor;

@FunctionalInterface
interface AnnotationVisitorSource {
  AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\JdkClassReader$AnnotationVisitorSource.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */