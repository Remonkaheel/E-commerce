/*      */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*      */ 
/*      */ import java.lang.classfile.Annotation;
/*      */ import java.lang.classfile.ClassBuilder;
/*      */ import java.lang.classfile.ClassElement;
/*      */ import java.lang.classfile.ClassFile;
/*      */ import java.lang.classfile.ClassFileElement;
/*      */ import java.lang.classfile.ClassHierarchyResolver;
/*      */ import java.lang.classfile.ClassModel;
/*      */ import java.lang.classfile.TypeAnnotation;
/*      */ import java.lang.classfile.attribute.DeprecatedAttribute;
/*      */ import java.lang.classfile.attribute.EnclosingMethodAttribute;
/*      */ import java.lang.classfile.attribute.InnerClassInfo;
/*      */ import java.lang.classfile.attribute.InnerClassesAttribute;
/*      */ import java.lang.classfile.attribute.NestHostAttribute;
/*      */ import java.lang.classfile.attribute.NestMembersAttribute;
/*      */ import java.lang.classfile.attribute.PermittedSubclassesAttribute;
/*      */ import java.lang.classfile.attribute.RecordAttribute;
/*      */ import java.lang.classfile.attribute.RecordComponentInfo;
/*      */ import java.lang.classfile.attribute.RuntimeInvisibleAnnotationsAttribute;
/*      */ import java.lang.classfile.attribute.RuntimeInvisibleTypeAnnotationsAttribute;
/*      */ import java.lang.classfile.attribute.RuntimeVisibleAnnotationsAttribute;
/*      */ import java.lang.classfile.attribute.RuntimeVisibleTypeAnnotationsAttribute;
/*      */ import java.lang.classfile.attribute.SignatureAttribute;
/*      */ import java.lang.classfile.attribute.SourceDebugExtensionAttribute;
/*      */ import java.lang.classfile.attribute.SourceFileAttribute;
/*      */ import java.lang.classfile.constantpool.ConstantPoolBuilder;
/*      */ import java.lang.constant.ClassDesc;
/*      */ import java.lang.constant.ConstantDesc;
/*      */ import java.lang.constant.ConstantDescs;
/*      */ import java.lang.constant.MethodTypeDesc;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*      */ import net.bytebuddy.jar.asm.Attribute;
/*      */ import net.bytebuddy.jar.asm.ClassVisitor;
/*      */ import net.bytebuddy.jar.asm.FieldVisitor;
/*      */ import net.bytebuddy.jar.asm.MethodVisitor;
/*      */ import net.bytebuddy.jar.asm.ModuleVisitor;
/*      */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*      */ import net.bytebuddy.jar.asm.Type;
/*      */ import net.bytebuddy.jar.asm.TypePath;
/*      */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*      */ import net.bytebuddy.jar.asmjdkbridge.JdkClassReader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JdkClassWriter
/*      */   extends ClassVisitor
/*      */ {
/*      */   private final int flags;
/*      */   private final Function<String, String> getSuperClass;
/*      */   private final ClassModel classModel;
/*  103 */   private final List<ClassDesc> nestMembers = new ArrayList<>();
/*  104 */   private final List<InnerClassInfo> innerClasses = new ArrayList<>();
/*  105 */   private final List<ClassDesc> permittedSubclasses = new ArrayList<>();
/*  106 */   private final List<RecordComponentInfo> recordComponents = new ArrayList<>();
/*  107 */   private final List<ClassElement> attributes = new ArrayList<>();
/*  108 */   private final List<Annotation> visibleAnnotations = new ArrayList<>(); private final List<Annotation> invisibleAnnotations = new ArrayList<>();
/*  109 */   private final List<TypeAnnotation> visibleTypeAnnotations = new ArrayList<>(); private final List<TypeAnnotation> invisibleTypeAnnotations = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ClassDesc thisClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final List<Consumer<ClassBuilder>> classConsumers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] bytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdkClassWriter(int flags) {
/*  151 */     super(589824); this.classConsumers = new ArrayList<>(List.of(classBuilder -> { for (ClassElement attribute : this.attributes) classBuilder.with((ClassFileElement)attribute);  if (!this.visibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleAnnotationsAttribute.of(this.visibleAnnotations));  if (!this.invisibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleAnnotationsAttribute.of(this.invisibleAnnotations));  if (!this.visibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleTypeAnnotationsAttribute.of(this.visibleTypeAnnotations));  if (!this.invisibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleTypeAnnotationsAttribute.of(this.invisibleTypeAnnotations));  if (!this.nestMembers.isEmpty()) classBuilder.with((ClassFileElement)NestMembersAttribute.ofSymbols(this.nestMembers));  if (!this.innerClasses.isEmpty()) classBuilder.with((ClassFileElement)InnerClassesAttribute.of(this.innerClasses));  if (!this.permittedSubclasses.isEmpty()) classBuilder.with((ClassFileElement)PermittedSubclassesAttribute.ofSymbols(this.permittedSubclasses));  if (this.isRecord || !this.recordComponents.isEmpty())
/*  152 */               classBuilder.with((ClassFileElement)RecordAttribute.of(this.recordComponents));  })); this.flags = flags;
/*  153 */     this.classModel = null;
/*  154 */     this.getSuperClass = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdkClassWriter(JdkClassReader classReader, int flags) {
/*  164 */     super(589824); this.classConsumers = new ArrayList<>(List.of(classBuilder -> { for (ClassElement attribute : this.attributes) classBuilder.with((ClassFileElement)attribute);  if (!this.visibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleAnnotationsAttribute.of(this.visibleAnnotations));  if (!this.invisibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleAnnotationsAttribute.of(this.invisibleAnnotations));  if (!this.visibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleTypeAnnotationsAttribute.of(this.visibleTypeAnnotations));  if (!this.invisibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleTypeAnnotationsAttribute.of(this.invisibleTypeAnnotations));  if (!this.nestMembers.isEmpty()) classBuilder.with((ClassFileElement)NestMembersAttribute.ofSymbols(this.nestMembers));  if (!this.innerClasses.isEmpty()) classBuilder.with((ClassFileElement)InnerClassesAttribute.of(this.innerClasses));  if (!this.permittedSubclasses.isEmpty()) classBuilder.with((ClassFileElement)PermittedSubclassesAttribute.ofSymbols(this.permittedSubclasses));  if (this.isRecord || !this.recordComponents.isEmpty())
/*  165 */               classBuilder.with((ClassFileElement)RecordAttribute.of(this.recordComponents));  })); this.flags = flags;
/*  166 */     this.classModel = (classReader == null) ? null : classReader.getClassModel();
/*  167 */     this.getSuperClass = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdkClassWriter(int flags, Method getSuperClass, Object target) {
/*  180 */     super(589824); this.classConsumers = new ArrayList<>(List.of(classBuilder -> { for (ClassElement attribute : this.attributes) classBuilder.with((ClassFileElement)attribute);  if (!this.visibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleAnnotationsAttribute.of(this.visibleAnnotations));  if (!this.invisibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleAnnotationsAttribute.of(this.invisibleAnnotations));  if (!this.visibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleTypeAnnotationsAttribute.of(this.visibleTypeAnnotations));  if (!this.invisibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleTypeAnnotationsAttribute.of(this.invisibleTypeAnnotations));  if (!this.nestMembers.isEmpty()) classBuilder.with((ClassFileElement)NestMembersAttribute.ofSymbols(this.nestMembers));  if (!this.innerClasses.isEmpty()) classBuilder.with((ClassFileElement)InnerClassesAttribute.of(this.innerClasses));  if (!this.permittedSubclasses.isEmpty()) classBuilder.with((ClassFileElement)PermittedSubclassesAttribute.ofSymbols(this.permittedSubclasses));  if (this.isRecord || !this.recordComponents.isEmpty())
/*  181 */               classBuilder.with((ClassFileElement)RecordAttribute.of(this.recordComponents));  })); this.flags = flags;
/*  182 */     this.classModel = null;
/*  183 */     this.getSuperClass = (getSuperClass == null) ? null : (name -> {
/*      */         try {
/*      */           return (String)getSuperClass.invoke(target, new Object[] { name });
/*  186 */         } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/*      */           throw new RuntimeException(e);
/*      */         } 
/*      */       });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdkClassWriter(JdkClassReader classReader, int flags, Method getSuperClass, Object target) {
/*  203 */     super(589824); this.classConsumers = new ArrayList<>(List.of(classBuilder -> { for (ClassElement attribute : this.attributes) classBuilder.with((ClassFileElement)attribute);  if (!this.visibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleAnnotationsAttribute.of(this.visibleAnnotations));  if (!this.invisibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleAnnotationsAttribute.of(this.invisibleAnnotations));  if (!this.visibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleTypeAnnotationsAttribute.of(this.visibleTypeAnnotations));  if (!this.invisibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleTypeAnnotationsAttribute.of(this.invisibleTypeAnnotations));  if (!this.nestMembers.isEmpty()) classBuilder.with((ClassFileElement)NestMembersAttribute.ofSymbols(this.nestMembers));  if (!this.innerClasses.isEmpty()) classBuilder.with((ClassFileElement)InnerClassesAttribute.of(this.innerClasses));  if (!this.permittedSubclasses.isEmpty()) classBuilder.with((ClassFileElement)PermittedSubclassesAttribute.ofSymbols(this.permittedSubclasses));  if (this.isRecord || !this.recordComponents.isEmpty())
/*  204 */               classBuilder.with((ClassFileElement)RecordAttribute.of(this.recordComponents));  })); this.flags = flags;
/*  205 */     this.classModel = (classReader == null) ? null : classReader.getClassModel();
/*  206 */     this.getSuperClass = (getSuperClass == null) ? null : (name -> {
/*      */         try {
/*      */           return (String)getSuperClass.invoke(target, new Object[] { name });
/*  209 */         } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/*      */           throw new RuntimeException(e);
/*      */         } 
/*      */       });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdkClassWriter(int flags, Function<String, String> getSuperClass) {
/*  223 */     super(589824); this.classConsumers = new ArrayList<>(List.of(classBuilder -> { for (ClassElement attribute : this.attributes) classBuilder.with((ClassFileElement)attribute);  if (!this.visibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleAnnotationsAttribute.of(this.visibleAnnotations));  if (!this.invisibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleAnnotationsAttribute.of(this.invisibleAnnotations));  if (!this.visibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleTypeAnnotationsAttribute.of(this.visibleTypeAnnotations));  if (!this.invisibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleTypeAnnotationsAttribute.of(this.invisibleTypeAnnotations));  if (!this.nestMembers.isEmpty()) classBuilder.with((ClassFileElement)NestMembersAttribute.ofSymbols(this.nestMembers));  if (!this.innerClasses.isEmpty()) classBuilder.with((ClassFileElement)InnerClassesAttribute.of(this.innerClasses));  if (!this.permittedSubclasses.isEmpty()) classBuilder.with((ClassFileElement)PermittedSubclassesAttribute.ofSymbols(this.permittedSubclasses));  if (this.isRecord || !this.recordComponents.isEmpty())
/*  224 */               classBuilder.with((ClassFileElement)RecordAttribute.of(this.recordComponents));  })); this.flags = flags;
/*  225 */     this.classModel = null;
/*  226 */     this.getSuperClass = getSuperClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdkClassWriter(JdkClassReader classReader, int flags, Function<String, String> getSuperClass) {
/*  238 */     super(589824); this.classConsumers = new ArrayList<>(List.of(classBuilder -> { for (ClassElement attribute : this.attributes) classBuilder.with((ClassFileElement)attribute);  if (!this.visibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleAnnotationsAttribute.of(this.visibleAnnotations));  if (!this.invisibleAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleAnnotationsAttribute.of(this.invisibleAnnotations));  if (!this.visibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeVisibleTypeAnnotationsAttribute.of(this.visibleTypeAnnotations));  if (!this.invisibleTypeAnnotations.isEmpty()) classBuilder.with((ClassFileElement)RuntimeInvisibleTypeAnnotationsAttribute.of(this.invisibleTypeAnnotations));  if (!this.nestMembers.isEmpty()) classBuilder.with((ClassFileElement)NestMembersAttribute.ofSymbols(this.nestMembers));  if (!this.innerClasses.isEmpty()) classBuilder.with((ClassFileElement)InnerClassesAttribute.of(this.innerClasses));  if (!this.permittedSubclasses.isEmpty()) classBuilder.with((ClassFileElement)PermittedSubclassesAttribute.ofSymbols(this.permittedSubclasses));  if (this.isRecord || !this.recordComponents.isEmpty())
/*  239 */               classBuilder.with((ClassFileElement)RecordAttribute.of(this.recordComponents));  })); this.flags = flags;
/*  240 */     this.classModel = (classReader == null) ? null : classReader.getClassModel();
/*  241 */     this.getSuperClass = getSuperClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/*  246 */     this.thisClass = ClassDesc.ofInternalName(name);
/*  247 */     this.isRecord = ((access & 0x10000) != 0);
/*  248 */     this.classConsumers.add(classBuilder -> {
/*      */           classBuilder.withVersion(version & 0xFFFF, version >>> 16);
/*      */           classBuilder.withFlags(access & 0xFFFCFFFF);
/*      */           if ((access & 0x20000) != 0) {
/*      */             classBuilder.with((ClassFileElement)DeprecatedAttribute.of());
/*      */           }
/*      */           if (signature != null) {
/*      */             classBuilder.with((ClassFileElement)SignatureAttribute.of(classBuilder.constantPool().utf8Entry(signature)));
/*      */           }
/*      */           if (superName != null) {
/*      */             classBuilder.withSuperclass(ClassDesc.ofInternalName(superName));
/*      */           }
/*      */           if (interfaces != null) {
/*      */             ClassDesc[] entries = new ClassDesc[interfaces.length];
/*      */             for (int index = 0; index < interfaces.length; index++) {
/*      */               entries[index] = ClassDesc.ofInternalName(interfaces[index]);
/*      */             }
/*      */             classBuilder.withInterfaceSymbols(entries);
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitSource(String source, String debug) {
/*  272 */     this.classConsumers.add(classBuilder -> {
/*      */           if (source != null) {
/*      */             classBuilder.with((ClassFileElement)SourceFileAttribute.of(source));
/*      */           }
/*      */           if (debug != null) {
/*      */             classBuilder.with((ClassFileElement)SourceDebugExtensionAttribute.of(debug.getBytes(StandardCharsets.UTF_8)));
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public ModuleVisitor visitModule(String name, int access, String version) {
/*  284 */     return (ModuleVisitor)new WritingModuleVisitor(this, name, access, version);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitNestHost(String nestHost) {
/*  391 */     this.classConsumers.add(classBuilder -> classBuilder.with((ClassFileElement)NestHostAttribute.of(ClassDesc.ofInternalName(nestHost))));
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitOuterClass(String owner, String name, String descriptor) {
/*  396 */     this.classConsumers.add(classBuilder -> classBuilder.with((ClassFileElement)EnclosingMethodAttribute.of(ClassDesc.ofInternalName(owner), Optional.ofNullable(name), Optional.<String>ofNullable(descriptor).map(MethodTypeDesc::ofDescriptor))));
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/*  401 */     Objects.requireNonNull(visible ? this.visibleAnnotations : this.invisibleAnnotations); return WritingAnnotationVisitor.of(this, descriptor, visible ? this.visibleAnnotations : this.invisibleAnnotations::add);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitAttribute(Attribute attribute) {
/*  406 */     this.attributes.add((ClassElement)AsmWrappedAttribute.unwrap(attribute, ClassElement.class));
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotationVisitor visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
/*  411 */     Objects.requireNonNull(visible ? this.visibleTypeAnnotations : this.invisibleTypeAnnotations); return WritingAnnotationVisitor.ofTypeAnnotation(this, descriptor, typeRef, typePath, visible ? this.visibleTypeAnnotations : this.invisibleTypeAnnotations::add);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitNestMember(String nestMember) {
/*  416 */     this.nestMembers.add(ClassDesc.ofInternalName(nestMember));
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitPermittedSubclass(String permittedSubclass) {
/*  421 */     this.permittedSubclasses.add(ClassDesc.ofInternalName(permittedSubclass));
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitInnerClass(String name, String outerName, String innerName, int access) {
/*  426 */     this.innerClasses.add(InnerClassInfo.of(ClassDesc.ofInternalName(name), Optional.<String>ofNullable(outerName).map(ClassDesc::ofInternalName), Optional.ofNullable(innerName), access));
/*      */   }
/*      */ 
/*      */   
/*      */   public RecordComponentVisitor visitRecordComponent(String name, String descriptor, String signature) {
/*  431 */     return (RecordComponentVisitor)new Object(this, 589824, signature, name, descriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
/*  477 */     return (FieldVisitor)new WritingFieldVisitor(this, access, name, descriptor, signature, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
/*  563 */     return (MethodVisitor)new WritingMethodVisitor(this, access, name, descriptor, signature, exceptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitEnd() {
/* 1173 */     ClassFile classFile = getClassFile(this.flags);
/* 1174 */     if (this.classModel == null) {
/* 1175 */       this.bytes = classFile.build(this.thisClass, classBuilder -> this.classConsumers.forEach(()));
/*      */     } else {
/* 1177 */       ConstantPoolBuilder constantPoolBuilder = ConstantPoolBuilder.of(this.classModel);
/* 1178 */       this.bytes = classFile.build(constantPoolBuilder.classEntry(this.thisClass), constantPoolBuilder, classBuilder -> this.classConsumers.forEach(()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClassFile getClassFile(int flags) {
/* 1189 */     if ((flags & 0x2) == 0) {
/* 1190 */       return ClassFile.of(new ClassFile.Option[] { (ClassFile.Option)ClassFile.DeadCodeOption.KEEP_DEAD_CODE, (ClassFile.Option)ClassFile.StackMapsOption.DROP_STACK_MAPS });
/*      */     }
/* 1192 */     return ClassFile.of(new ClassFile.Option[] { (ClassFile.Option)ClassFile.DeadCodeOption.PATCH_DEAD_CODE, (ClassFile.Option)ClassFile.StackMapsOption.STACK_MAPS_WHEN_REQUIRED, (ClassFile.Option)ClassFile.ClassHierarchyResolverOption.of(classDesc -> {
/*      */               if (!classDesc.isClassOrInterface()) {
/*      */                 return null;
/*      */               }
/*      */               if (classDesc.equals(ConstantDescs.CD_Object)) {
/*      */                 return ClassHierarchyResolver.ClassHierarchyInfo.ofClass(null);
/*      */               }
/*      */               String descriptor = classDesc.descriptorString();
/*      */               String superClass = getSuperClass(descriptor.substring(1, descriptor.length() - 1));
/*      */               return (superClass == null) ? ClassHierarchyResolver.ClassHierarchyInfo.ofInterface() : ClassHierarchyResolver.ClassHierarchyInfo.ofClass(ClassDesc.ofInternalName(superClass));
/*      */             }) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ConstantDesc toConstantDesc(Object asm) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: astore_1
/*      */     //   2: iconst_0
/*      */     //   3: istore_2
/*      */     //   4: aload_1
/*      */     //   5: iload_2
/*      */     //   6: <illegal opcode> typeSwitch : (Ljava/lang/Object;I)I
/*      */     //   11: tableswitch default -> 355, -1 -> 355, 0 -> 60, 1 -> 69, 2 -> 80, 3 -> 91, 4 -> 102, 5 -> 113, 6 -> 192, 7 -> 235
/*      */     //   60: aload_1
/*      */     //   61: checkcast java/lang/Integer
/*      */     //   64: astore_3
/*      */     //   65: aload_3
/*      */     //   66: goto -> 372
/*      */     //   69: aload_1
/*      */     //   70: checkcast java/lang/Long
/*      */     //   73: astore #4
/*      */     //   75: aload #4
/*      */     //   77: goto -> 372
/*      */     //   80: aload_1
/*      */     //   81: checkcast java/lang/Float
/*      */     //   84: astore #5
/*      */     //   86: aload #5
/*      */     //   88: goto -> 372
/*      */     //   91: aload_1
/*      */     //   92: checkcast java/lang/Double
/*      */     //   95: astore #6
/*      */     //   97: aload #6
/*      */     //   99: goto -> 372
/*      */     //   102: aload_1
/*      */     //   103: checkcast java/lang/String
/*      */     //   106: astore #7
/*      */     //   108: aload #7
/*      */     //   110: goto -> 372
/*      */     //   113: aload_1
/*      */     //   114: checkcast net/bytebuddy/jar/asm/Type
/*      */     //   117: astore #8
/*      */     //   119: aload #8
/*      */     //   121: invokevirtual getSort : ()I
/*      */     //   124: tableswitch default -> 174, 9 -> 152, 10 -> 152, 11 -> 163
/*      */     //   152: aload #8
/*      */     //   154: invokevirtual getDescriptor : ()Ljava/lang/String;
/*      */     //   157: invokestatic ofDescriptor : (Ljava/lang/String;)Ljava/lang/constant/ClassDesc;
/*      */     //   160: goto -> 372
/*      */     //   163: aload #8
/*      */     //   165: invokevirtual getDescriptor : ()Ljava/lang/String;
/*      */     //   168: invokestatic ofDescriptor : (Ljava/lang/String;)Ljava/lang/constant/MethodTypeDesc;
/*      */     //   171: goto -> 372
/*      */     //   174: new java/lang/IllegalArgumentException
/*      */     //   177: dup
/*      */     //   178: aload #8
/*      */     //   180: invokevirtual getSort : ()I
/*      */     //   183: <illegal opcode> makeConcatWithConstants : (I)Ljava/lang/String;
/*      */     //   188: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   191: athrow
/*      */     //   192: aload_1
/*      */     //   193: checkcast net/bytebuddy/jar/asm/Handle
/*      */     //   196: astore #9
/*      */     //   198: aload #9
/*      */     //   200: invokevirtual getTag : ()I
/*      */     //   203: aload #9
/*      */     //   205: invokevirtual isInterface : ()Z
/*      */     //   208: invokestatic valueOf : (IZ)Ljava/lang/constant/DirectMethodHandleDesc$Kind;
/*      */     //   211: aload #9
/*      */     //   213: invokevirtual getOwner : ()Ljava/lang/String;
/*      */     //   216: invokestatic ofInternalName : (Ljava/lang/String;)Ljava/lang/constant/ClassDesc;
/*      */     //   219: aload #9
/*      */     //   221: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   224: aload #9
/*      */     //   226: invokevirtual getDesc : ()Ljava/lang/String;
/*      */     //   229: invokestatic of : (Ljava/lang/constant/DirectMethodHandleDesc$Kind;Ljava/lang/constant/ClassDesc;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/constant/DirectMethodHandleDesc;
/*      */     //   232: goto -> 372
/*      */     //   235: aload_1
/*      */     //   236: checkcast net/bytebuddy/jar/asm/ConstantDynamic
/*      */     //   239: astore #10
/*      */     //   241: aload #10
/*      */     //   243: invokevirtual getBootstrapMethodArgumentCount : ()I
/*      */     //   246: anewarray java/lang/constant/ConstantDesc
/*      */     //   249: astore #11
/*      */     //   251: iconst_0
/*      */     //   252: istore #12
/*      */     //   254: iload #12
/*      */     //   256: aload #10
/*      */     //   258: invokevirtual getBootstrapMethodArgumentCount : ()I
/*      */     //   261: if_icmpge -> 285
/*      */     //   264: aload #11
/*      */     //   266: iload #12
/*      */     //   268: aload #10
/*      */     //   270: iload #12
/*      */     //   272: invokevirtual getBootstrapMethodArgument : (I)Ljava/lang/Object;
/*      */     //   275: invokestatic toConstantDesc : (Ljava/lang/Object;)Ljava/lang/constant/ConstantDesc;
/*      */     //   278: aastore
/*      */     //   279: iinc #12, 1
/*      */     //   282: goto -> 254
/*      */     //   285: aload #10
/*      */     //   287: invokevirtual getBootstrapMethod : ()Lnet/bytebuddy/jar/asm/Handle;
/*      */     //   290: invokevirtual getTag : ()I
/*      */     //   293: aload #10
/*      */     //   295: invokevirtual getBootstrapMethod : ()Lnet/bytebuddy/jar/asm/Handle;
/*      */     //   298: invokevirtual isInterface : ()Z
/*      */     //   301: invokestatic valueOf : (IZ)Ljava/lang/constant/DirectMethodHandleDesc$Kind;
/*      */     //   304: aload #10
/*      */     //   306: invokevirtual getBootstrapMethod : ()Lnet/bytebuddy/jar/asm/Handle;
/*      */     //   309: invokevirtual getOwner : ()Ljava/lang/String;
/*      */     //   312: invokestatic ofInternalName : (Ljava/lang/String;)Ljava/lang/constant/ClassDesc;
/*      */     //   315: aload #10
/*      */     //   317: invokevirtual getBootstrapMethod : ()Lnet/bytebuddy/jar/asm/Handle;
/*      */     //   320: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   323: aload #10
/*      */     //   325: invokevirtual getBootstrapMethod : ()Lnet/bytebuddy/jar/asm/Handle;
/*      */     //   328: invokevirtual getDesc : ()Ljava/lang/String;
/*      */     //   331: invokestatic of : (Ljava/lang/constant/DirectMethodHandleDesc$Kind;Ljava/lang/constant/ClassDesc;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/constant/DirectMethodHandleDesc;
/*      */     //   334: aload #10
/*      */     //   336: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   339: aload #10
/*      */     //   341: invokevirtual getDescriptor : ()Ljava/lang/String;
/*      */     //   344: invokestatic ofDescriptor : (Ljava/lang/String;)Ljava/lang/constant/ClassDesc;
/*      */     //   347: aload #11
/*      */     //   349: invokestatic ofNamed : (Ljava/lang/constant/DirectMethodHandleDesc;Ljava/lang/String;Ljava/lang/constant/ClassDesc;[Ljava/lang/constant/ConstantDesc;)Ljava/lang/constant/DynamicConstantDesc;
/*      */     //   352: goto -> 372
/*      */     //   355: new java/lang/IllegalArgumentException
/*      */     //   358: dup
/*      */     //   359: aload_0
/*      */     //   360: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   363: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   368: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   371: athrow
/*      */     //   372: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1205	-> 0
/*      */     //   #1206	-> 60
/*      */     //   #1207	-> 69
/*      */     //   #1208	-> 80
/*      */     //   #1209	-> 91
/*      */     //   #1210	-> 102
/*      */     //   #1211	-> 113
/*      */     //   #1212	-> 152
/*      */     //   #1213	-> 163
/*      */     //   #1214	-> 174
/*      */     //   #1216	-> 192
/*      */     //   #1217	-> 198
/*      */     //   #1218	-> 235
/*      */     //   #1219	-> 241
/*      */     //   #1220	-> 251
/*      */     //   #1221	-> 264
/*      */     //   #1220	-> 279
/*      */     //   #1223	-> 285
/*      */     //   #1225	-> 355
/*      */     //   #1205	-> 372
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   65	4	3	value	Ljava/lang/Integer;
/*      */     //   75	5	4	value	Ljava/lang/Long;
/*      */     //   86	5	5	value	Ljava/lang/Float;
/*      */     //   97	5	6	value	Ljava/lang/Double;
/*      */     //   108	5	7	value	Ljava/lang/String;
/*      */     //   119	73	8	value	Lnet/bytebuddy/jar/asm/Type;
/*      */     //   198	37	9	value	Lnet/bytebuddy/jar/asm/Handle;
/*      */     //   254	31	12	index	I
/*      */     //   251	104	11	constants	[Ljava/lang/constant/ConstantDesc;
/*      */     //   241	114	10	value	Lnet/bytebuddy/jar/asm/ConstantDynamic;
/*      */     //   0	373	0	asm	Ljava/lang/Object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toByteArray() {
/* 1235 */     if (this.bytes == null) {
/* 1236 */       throw new IllegalStateException("Did not visitEnd, and no byte array was created");
/*      */     }
/* 1238 */     return this.bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSuperClass(String name) {
/*      */     Class<?> type;
/* 1252 */     if (this.getSuperClass != null) {
/* 1253 */       return this.getSuperClass.apply(name);
/*      */     }
/* 1255 */     ClassLoader classLoader = getClassLoader();
/*      */     
/*      */     try {
/* 1258 */       type = Class.forName(name.replace('/', '.'), false, classLoader);
/* 1259 */     } catch (ClassNotFoundException e) {
/* 1260 */       throw new TypeNotPresentException(name.replace('/', '.'), e);
/*      */     } 
/* 1262 */     if (type.isInterface()) {
/* 1263 */       return null;
/*      */     }
/* 1265 */     return Type.getInternalName(type.getSuperclass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClassLoader getClassLoader() {
/* 1275 */     return getClass().getClassLoader();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\JdkClassWriter.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */