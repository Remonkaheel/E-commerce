/*    */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*    */ 
/*    */ import java.lang.classfile.Attribute;
/*    */ import net.bytebuddy.jar.asm.Attribute;
/*    */ import net.bytebuddy.jar.asm.ByteVector;
/*    */ import net.bytebuddy.jar.asm.ClassReader;
/*    */ import net.bytebuddy.jar.asm.ClassWriter;
/*    */ import net.bytebuddy.jar.asm.Label;
/*    */ import net.bytebuddy.jar.asmjdkbridge.AsmAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AsmWrappedAttribute<A extends Attribute<?>>
/*    */   extends Attribute
/*    */ {
/*    */   final A attribute;
/*    */   
/*    */   protected AsmWrappedAttribute(A attribute) {
/* 26 */     super(attribute.attributeName().stringValue());
/* 27 */     this.attribute = attribute;
/*    */   }
/*    */   
/*    */   static <T> T unwrap(Attribute attribute, Class<T> type) {
/* 31 */     net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute<?> wrappedAttribute = (net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute)attribute; return type.cast((attribute instanceof net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute) ? 
/* 32 */         type.cast(wrappedAttribute.attribute) : 
/* 33 */         type.cast(AsmAttribute.of(attribute)));
/*    */   }
/*    */ 
/*    */   
/*    */   protected final Attribute read(ClassReader classReader, int offset, int length, char[] charBuffer, int codeAttributeOffset, Label[] labels) {
/* 38 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract ByteVector write(ClassWriter paramClassWriter, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3);
/*    */ 
/*    */   
/*    */   public final boolean isUnknown() {
/* 46 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmWrappedAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */