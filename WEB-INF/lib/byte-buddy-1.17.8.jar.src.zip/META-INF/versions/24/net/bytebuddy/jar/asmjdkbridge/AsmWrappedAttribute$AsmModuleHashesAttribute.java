/*    */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*    */ 
/*    */ import java.lang.classfile.Attribute;
/*    */ import java.lang.classfile.attribute.ModuleHashInfo;
/*    */ import java.lang.classfile.attribute.ModuleHashesAttribute;
/*    */ import net.bytebuddy.jar.asm.ByteVector;
/*    */ import net.bytebuddy.jar.asm.ClassWriter;
/*    */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AsmModuleHashesAttribute
/*    */   extends AsmWrappedAttribute<ModuleHashesAttribute>
/*    */ {
/*    */   AsmModuleHashesAttribute(ModuleHashesAttribute attribute) {
/* 67 */     super((Attribute)attribute);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ByteVector write(ClassWriter classWriter, byte[] code, int codeLength, int maxStack, int maxLocals) {
/* 72 */     ByteVector bytes = new ByteVector();
/* 73 */     bytes.putShort(classWriter.newUTF8(((ModuleHashesAttribute)this.attribute).algorithm().stringValue()));
/* 74 */     bytes.putShort(((ModuleHashesAttribute)this.attribute).hashes().size());
/* 75 */     for (ModuleHashInfo info : ((ModuleHashesAttribute)this.attribute).hashes()) {
/* 76 */       bytes.putShort(classWriter.newModule(info.moduleName().name().stringValue()));
/* 77 */       bytes.putShort((info.hash()).length);
/* 78 */       bytes.putByteArray(info.hash(), 0, (info.hash()).length);
/*    */     } 
/* 80 */     return bytes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmWrappedAttribute$AsmModuleHashesAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */