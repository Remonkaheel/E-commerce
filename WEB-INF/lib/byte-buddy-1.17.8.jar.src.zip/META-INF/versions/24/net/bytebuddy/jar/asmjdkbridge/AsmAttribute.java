/*    */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*    */ 
/*    */ import java.lang.classfile.AttributeMapper;
/*    */ import java.lang.classfile.CustomAttribute;
/*    */ import net.bytebuddy.jar.asm.Attribute;
/*    */ import net.bytebuddy.jar.asmjdkbridge.AsmAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AsmAttribute
/*    */   extends CustomAttribute<AsmAttribute>
/*    */ {
/*    */   final Attribute attribute;
/*    */   
/*    */   static AsmAttribute of(Attribute attribute) {
/* 48 */     return new AsmAttribute((AttributeMapper<AsmAttribute>)new Object(attribute), attribute);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private AsmAttribute(AttributeMapper<AsmAttribute> mapper, Attribute attribute) {
/* 96 */     super(mapper);
/* 97 */     this.attribute = attribute;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */