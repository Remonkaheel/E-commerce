/*     */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*     */ 
/*     */ import java.lang.classfile.Attribute;
/*     */ import java.lang.classfile.attribute.SourceIDAttribute;
/*     */ import net.bytebuddy.jar.asm.ByteVector;
/*     */ import net.bytebuddy.jar.asm.ClassWriter;
/*     */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AsmSourceIdAttribute
/*     */   extends AsmWrappedAttribute<SourceIDAttribute>
/*     */ {
/*     */   AsmSourceIdAttribute(SourceIDAttribute attribute) {
/* 101 */     super((Attribute)attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ByteVector write(ClassWriter classWriter, byte[] code, int codeLength, int maxStack, int maxLocals) {
/* 106 */     int index = classWriter.newUTF8(((SourceIDAttribute)this.attribute).sourceId().stringValue());
/* 107 */     ByteVector byteVector = new ByteVector(2);
/* 108 */     byteVector.putShort(index);
/* 109 */     return byteVector;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmWrappedAttribute$AsmSourceIdAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */