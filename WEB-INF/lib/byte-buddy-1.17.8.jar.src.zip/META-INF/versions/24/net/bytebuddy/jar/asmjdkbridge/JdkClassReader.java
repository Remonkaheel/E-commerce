/*     */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.classfile.Annotation;
/*     */ import java.lang.classfile.AnnotationElement;
/*     */ import java.lang.classfile.AnnotationValue;
/*     */ import java.lang.classfile.Attribute;
/*     */ import java.lang.classfile.AttributedElement;
/*     */ import java.lang.classfile.Attributes;
/*     */ import java.lang.classfile.ClassElement;
/*     */ import java.lang.classfile.ClassFile;
/*     */ import java.lang.classfile.ClassModel;
/*     */ import java.lang.classfile.FieldModel;
/*     */ import java.lang.classfile.Label;
/*     */ import java.lang.classfile.MethodModel;
/*     */ import java.lang.classfile.TypeAnnotation;
/*     */ import java.lang.classfile.attribute.AnnotationDefaultAttribute;
/*     */ import java.lang.classfile.attribute.CharacterRangeTableAttribute;
/*     */ import java.lang.classfile.attribute.CodeAttribute;
/*     */ import java.lang.classfile.attribute.CompilationIDAttribute;
/*     */ import java.lang.classfile.attribute.ConstantValueAttribute;
/*     */ import java.lang.classfile.attribute.EnclosingMethodAttribute;
/*     */ import java.lang.classfile.attribute.ExceptionsAttribute;
/*     */ import java.lang.classfile.attribute.InnerClassInfo;
/*     */ import java.lang.classfile.attribute.InnerClassesAttribute;
/*     */ import java.lang.classfile.attribute.MethodParameterInfo;
/*     */ import java.lang.classfile.attribute.MethodParametersAttribute;
/*     */ import java.lang.classfile.attribute.ModuleAttribute;
/*     */ import java.lang.classfile.attribute.ModuleExportInfo;
/*     */ import java.lang.classfile.attribute.ModuleHashesAttribute;
/*     */ import java.lang.classfile.attribute.ModuleMainClassAttribute;
/*     */ import java.lang.classfile.attribute.ModuleOpenInfo;
/*     */ import java.lang.classfile.attribute.ModulePackagesAttribute;
/*     */ import java.lang.classfile.attribute.ModuleProvideInfo;
/*     */ import java.lang.classfile.attribute.ModuleRequireInfo;
/*     */ import java.lang.classfile.attribute.ModuleResolutionAttribute;
/*     */ import java.lang.classfile.attribute.NestHostAttribute;
/*     */ import java.lang.classfile.attribute.NestMembersAttribute;
/*     */ import java.lang.classfile.attribute.PermittedSubclassesAttribute;
/*     */ import java.lang.classfile.attribute.RecordAttribute;
/*     */ import java.lang.classfile.attribute.RecordComponentInfo;
/*     */ import java.lang.classfile.attribute.RuntimeInvisibleAnnotationsAttribute;
/*     */ import java.lang.classfile.attribute.RuntimeInvisibleParameterAnnotationsAttribute;
/*     */ import java.lang.classfile.attribute.RuntimeInvisibleTypeAnnotationsAttribute;
/*     */ import java.lang.classfile.attribute.RuntimeVisibleAnnotationsAttribute;
/*     */ import java.lang.classfile.attribute.RuntimeVisibleParameterAnnotationsAttribute;
/*     */ import java.lang.classfile.attribute.RuntimeVisibleTypeAnnotationsAttribute;
/*     */ import java.lang.classfile.attribute.SignatureAttribute;
/*     */ import java.lang.classfile.attribute.SourceDebugExtensionAttribute;
/*     */ import java.lang.classfile.attribute.SourceFileAttribute;
/*     */ import java.lang.classfile.attribute.SourceIDAttribute;
/*     */ import java.lang.classfile.attribute.StackMapFrameInfo;
/*     */ import java.lang.classfile.attribute.StackMapTableAttribute;
/*     */ import java.lang.classfile.attribute.UnknownAttribute;
/*     */ import java.lang.classfile.constantpool.ClassEntry;
/*     */ import java.lang.classfile.constantpool.ModuleEntry;
/*     */ import java.lang.classfile.constantpool.NameAndTypeEntry;
/*     */ import java.lang.classfile.constantpool.PackageEntry;
/*     */ import java.lang.classfile.constantpool.Utf8Entry;
/*     */ import java.lang.classfile.instruction.LocalVariable;
/*     */ import java.lang.classfile.instruction.LocalVariableType;
/*     */ import java.lang.classfile.instruction.SwitchCase;
/*     */ import java.lang.constant.ClassDesc;
/*     */ import java.lang.constant.ConstantDesc;
/*     */ import java.lang.reflect.AccessFlag;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*     */ import net.bytebuddy.jar.asm.Attribute;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.Label;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.ModuleVisitor;
/*     */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*     */ import net.bytebuddy.jar.asm.TypePath;
/*     */ import net.bytebuddy.jar.asm.TypeReference;
/*     */ import net.bytebuddy.jar.asmjdkbridge.AsmAttribute;
/*     */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*     */ import net.bytebuddy.jar.asmjdkbridge.JdkClassWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdkClassReader
/*     */ {
/*     */   private static final int SAME_LOCALS_1_STACK_ITEM_EXTENDED = 247;
/*     */   private static final int SAME_EXTENDED = 251;
/*     */   private final ClassModel classModel;
/*     */   private final AttributeFunction attributes;
/*     */   
/*     */   public JdkClassReader(byte[] classFile, Attribute... attributePrototypes) {
/* 119 */     this.attributes = new AttributeFunction(attributePrototypes);
/* 120 */     this.classModel = ClassFile.of(new ClassFile.Option[] { (ClassFile.Option)ClassFile.AttributeMapperOption.of((Function)this.attributes) }).parse(classFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClassReader(InputStream inputStream, Attribute... attributePrototypes) throws IOException {
/* 131 */     this(inputStream.readAllBytes(), attributePrototypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdkClassReader(String className, Attribute... attributePrototypes) throws IOException {
/* 142 */     this.attributes = new AttributeFunction(attributePrototypes);
/* 143 */     ClassFile classFile = ClassFile.of(new ClassFile.Option[] { (ClassFile.Option)ClassFile.AttributeMapperOption.of((Function)this.attributes) });
/* 144 */     InputStream inputStream = ClassLoader.getSystemResourceAsStream(className.replace('.', '/') + ".class"); 
/* 145 */     try { this.classModel = classFile.parse(inputStream.readAllBytes());
/* 146 */       if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null)
/*     */         try { inputStream.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 150 */      } ClassModel getClassModel() { return this.classModel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAccess() {
/* 159 */     return this.classModel.flags().flagsMask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 168 */     return this.classModel.thisClass().asInternalName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuperName() {
/* 177 */     return this.classModel.superclass().map(ClassEntry::asInternalName).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getInterfaces() {
/* 186 */     return (String[])this.classModel.interfaces().stream().map(ClassEntry::asInternalName).toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor classVisitor, int flags) {
/* 196 */     Map<Label, Label> labels = new HashMap<>();
/* 197 */     classVisitor.visit(this.classModel.minorVersion() << 16 | this.classModel.majorVersion(), 
/* 198 */         getAccess() | (
/* 199 */         this.classModel.findAttribute(Attributes.deprecated()).isPresent() ? 131072 : 0) | (
/* 200 */         this.classModel.findAttribute(Attributes.synthetic()).isPresent() ? 4096 : 0) | (
/* 201 */         this.classModel.findAttribute(Attributes.record()).isPresent() ? 65536 : 0), 
/* 202 */         getClassName(), this.classModel
/* 203 */         .findAttribute(Attributes.signature()).map(signature -> signature.signature().stringValue()).orElse(null), 
/* 204 */         getSuperName(), 
/* 205 */         getInterfaces());
/* 206 */     if ((flags & 0x2) == 0) {
/*     */ 
/*     */       
/* 209 */       String sourceFile = this.classModel.findAttribute(Attributes.sourceFile()).map(attribute -> attribute.sourceFile().stringValue()).orElse(null);
/*     */ 
/*     */       
/* 212 */       String debug = this.classModel.findAttribute(Attributes.sourceDebugExtension()).map(attribute -> new String(attribute.contents(), StandardCharsets.UTF_8)).orElse(null);
/* 213 */       if (sourceFile != null || debug != null) {
/* 214 */         classVisitor.visitSource(sourceFile, debug);
/*     */       }
/*     */     } 
/* 217 */     this.classModel.findAttribute(Attributes.module()).ifPresent(module -> {
/*     */           String moduleName = module.moduleName().name().stringValue();
/*     */           
/*     */           int moduleFlags = module.moduleFlagsMask();
/*     */           
/*     */           String moduleVersion = module.moduleVersion().map(Utf8Entry::stringValue).orElse(null);
/*     */           
/*     */           ModuleVisitor moduleVisitor = classVisitor.visitModule(moduleName, moduleFlags, moduleVersion);
/*     */           
/*     */           if (moduleVisitor instanceof JdkClassWriter.WritingModuleVisitor) {
/*     */             JdkClassWriter.WritingModuleVisitor writingModuleVisitor = (JdkClassWriter.WritingModuleVisitor)moduleVisitor;
/*     */             if (writingModuleVisitor.has(this.classModel, moduleName, moduleFlags, moduleVersion)) {
/*     */               Objects.requireNonNull(writingModuleVisitor);
/*     */               this.classModel.findAttribute(Attributes.moduleMainClass()).ifPresent(writingModuleVisitor::add);
/*     */               Objects.requireNonNull(writingModuleVisitor);
/*     */               this.classModel.findAttribute(Attributes.modulePackages()).ifPresent(writingModuleVisitor::add);
/*     */               writingModuleVisitor.add((ClassElement)module);
/*     */               return;
/*     */             } 
/*     */           } 
/*     */           if (moduleVisitor != null) {
/*     */             Objects.requireNonNull(moduleVisitor);
/*     */             this.classModel.findAttribute(Attributes.moduleMainClass()).map(()).ifPresent(moduleVisitor::visitMainClass);
/*     */             Objects.requireNonNull(moduleVisitor);
/*     */             this.classModel.findAttribute(Attributes.modulePackages()).stream().flatMap(()).map(()).forEach(moduleVisitor::visitPackage);
/*     */             module.requires().forEach(());
/*     */             module.exports().forEach(());
/*     */             module.opens().forEach(());
/*     */             module.uses().forEach(());
/*     */             module.provides().forEach(());
/*     */             moduleVisitor.visitEnd();
/*     */           } 
/*     */         });
/* 250 */     this.classModel.findAttribute(Attributes.nestHost()).ifPresent(nestHost -> classVisitor.visitNestHost(nestHost.nestHost().asInternalName()));
/* 251 */     this.classModel.findAttribute(Attributes.enclosingMethod()).ifPresent(enclosingMethod -> classVisitor.visitOuterClass(enclosingMethod.enclosingClass().asInternalName(), enclosingMethod.enclosingMethod().map(()).orElse(null), enclosingMethod.enclosingMethod().map(()).orElse(null)));
/*     */ 
/*     */     
/* 254 */     Objects.requireNonNull(classVisitor); Objects.requireNonNull(classVisitor); acceptAnnotations((AttributedElement)this.classModel, classVisitor::visitAnnotation, classVisitor::visitTypeAnnotation);
/* 255 */     this.classModel.findAttribute(Attributes.sourceId()).ifPresent(sourceIDAttribute -> classVisitor.visitAttribute((Attribute)new AsmWrappedAttribute.AsmSourceIdAttribute(sourceIDAttribute)));
/* 256 */     this.classModel.findAttribute(Attributes.compilationId()).ifPresent(sourceIDAttribute -> classVisitor.visitAttribute((Attribute)new AsmWrappedAttribute.AsmCompilationIdAttribute(sourceIDAttribute)));
/* 257 */     this.classModel.findAttribute(Attributes.moduleResolution()).ifPresent(moduleResolutionAttribute -> classVisitor.visitAttribute((Attribute)new AsmWrappedAttribute.AsmModuleResolutionAttribute(moduleResolutionAttribute)));
/* 258 */     this.classModel.findAttribute(Attributes.moduleHashes()).ifPresent(moduleResolutionAttribute -> classVisitor.visitAttribute((Attribute)new AsmWrappedAttribute.AsmModuleHashesAttribute(moduleResolutionAttribute)));
/* 259 */     Objects.requireNonNull(classVisitor); acceptAttributes((AttributedElement)this.classModel, false, classVisitor::visitAttribute);
/* 260 */     this.classModel.findAttribute(Attributes.nestMembers()).stream()
/* 261 */       .flatMap(nestMembers -> nestMembers.nestMembers().stream())
/* 262 */       .forEach(nestMember -> classVisitor.visitNestMember(nestMember.asInternalName()));
/* 263 */     this.classModel.findAttribute(Attributes.permittedSubclasses()).stream()
/* 264 */       .flatMap(permittedSubclasses -> permittedSubclasses.permittedSubclasses().stream())
/* 265 */       .forEach(nestMember -> classVisitor.visitPermittedSubclass(nestMember.asInternalName()));
/* 266 */     this.classModel.findAttribute(Attributes.innerClasses()).stream()
/* 267 */       .flatMap(innerClasses -> innerClasses.classes().stream())
/* 268 */       .forEach(innerClass -> classVisitor.visitInnerClass(innerClass.innerClass().asInternalName(), innerClass.outerClass().map(ClassEntry::asInternalName).orElse(null), innerClass.innerName().map(Utf8Entry::stringValue).orElse(null), innerClass.flagsMask()));
/*     */ 
/*     */ 
/*     */     
/* 272 */     this.classModel.findAttribute(Attributes.record()).stream()
/* 273 */       .flatMap(record -> record.components().stream())
/* 274 */       .forEach(recordComponent -> {
/*     */           RecordComponentVisitor recordComponentVisitor = classVisitor.visitRecordComponent(recordComponent.name().stringValue(), recordComponent.descriptor().stringValue(), recordComponent.findAttribute(Attributes.signature()).map(()).orElse(null)); if (recordComponentVisitor != null) {
/*     */             Objects.requireNonNull(recordComponentVisitor);
/*     */             Objects.requireNonNull(recordComponentVisitor);
/*     */             acceptAnnotations((AttributedElement)recordComponent, recordComponentVisitor::visitAnnotation, recordComponentVisitor::visitTypeAnnotation);
/*     */             Objects.requireNonNull(recordComponentVisitor);
/*     */             acceptAttributes((AttributedElement)recordComponent, false, recordComponentVisitor::visitAttribute);
/*     */             recordComponentVisitor.visitEnd();
/*     */           } 
/*     */         });
/* 284 */     for (FieldModel fieldModel : this.classModel.fields()) {
/*     */ 
/*     */       
/* 287 */       int fieldFlags = fieldModel.flags().flagsMask() | (fieldModel.findAttribute(Attributes.deprecated()).isPresent() ? 131072 : 0) | (fieldModel.findAttribute(Attributes.synthetic()).isPresent() ? 4096 : 0);
/* 288 */       String fieldName = fieldModel.fieldName().stringValue();
/* 289 */       String fieldType = fieldModel.fieldType().stringValue();
/* 290 */       String fieldSignature = fieldModel.findAttribute(Attributes.signature()).map(signature -> signature.signature().stringValue()).orElse(null);
/* 291 */       Object fieldConstant = fieldModel.findAttribute(Attributes.constantValue()).map(constantValue -> toAsmConstant(constantValue.constant().constantValue())).orElse(null);
/* 292 */       FieldVisitor fieldVisitor = classVisitor.visitField(fieldFlags, fieldName, fieldType, fieldSignature, fieldConstant);
/* 293 */       if (fieldVisitor instanceof JdkClassWriter.WritingFieldVisitor) { JdkClassWriter.WritingFieldVisitor writingFieldVisitor = (JdkClassWriter.WritingFieldVisitor)fieldVisitor; if (writingFieldVisitor.has(this.classModel, fieldFlags, fieldName, fieldType, fieldSignature, fieldConstant))
/* 294 */         { writingFieldVisitor.add(fieldModel); continue; }  }
/* 295 */        if (fieldVisitor != null) {
/* 296 */         Objects.requireNonNull(fieldVisitor); Objects.requireNonNull(fieldVisitor); acceptAnnotations((AttributedElement)fieldModel, fieldVisitor::visitAnnotation, fieldVisitor::visitTypeAnnotation);
/* 297 */         Objects.requireNonNull(fieldVisitor); acceptAttributes((AttributedElement)fieldModel, false, fieldVisitor::visitAttribute);
/* 298 */         fieldVisitor.visitEnd();
/*     */       } 
/*     */     } 
/* 301 */     for (MethodModel methodModel : this.classModel.methods()) {
/*     */ 
/*     */       
/* 304 */       int methodFlags = methodModel.flags().flagsMask() | (methodModel.findAttribute(Attributes.deprecated()).isPresent() ? 131072 : 0) | (methodModel.findAttribute(Attributes.synthetic()).isPresent() ? 4096 : 0);
/* 305 */       String methodName = methodModel.methodName().stringValue();
/* 306 */       String methodType = methodModel.methodType().stringValue();
/* 307 */       String methodSignature = methodModel.findAttribute(Attributes.signature()).map(signature -> signature.signature().stringValue()).orElse(null);
/* 308 */       String[] methodExceptions = methodModel.findAttribute(Attributes.exceptions()).map(exceptions -> (String[])exceptions.exceptions().stream().map(ClassEntry::asInternalName).toArray(())).orElse(null);
/* 309 */       MethodVisitor methodVisitor = classVisitor.visitMethod(methodFlags, methodName, methodType, methodSignature, methodExceptions);
/* 310 */       if (methodVisitor instanceof JdkClassWriter.WritingMethodVisitor) { JdkClassWriter.WritingMethodVisitor writingMethodVisitor = (JdkClassWriter.WritingMethodVisitor)methodVisitor; if (writingMethodVisitor.has(this.classModel, methodFlags, methodName, methodType, methodSignature, methodExceptions))
/* 311 */         { writingMethodVisitor.add(methodModel); continue; }  }
/* 312 */        if (methodVisitor != null) {
/* 313 */         if ((flags & 0x2) == 0) {
/* 314 */           methodModel.findAttribute(Attributes.methodParameters()).stream()
/* 315 */             .flatMap(methodParameters -> methodParameters.parameters().stream())
/* 316 */             .forEach(methodParameter -> methodVisitor.visitParameter(methodParameter.name().map(Utf8Entry::stringValue).orElse(null), methodParameter.flagsMask()));
/*     */         }
/* 318 */         methodModel.findAttribute(Attributes.annotationDefault()).ifPresent(annotationDefault -> {
/*     */               AnnotationVisitor annotationVisitor = methodVisitor.visitAnnotationDefault();
/*     */               if (annotationVisitor != null) {
/*     */                 appendAnnotationValue(annotationVisitor, null, annotationDefault.defaultValue());
/*     */                 annotationVisitor.visitEnd();
/*     */               } 
/*     */             });
/* 325 */         Objects.requireNonNull(methodVisitor); Objects.requireNonNull(methodVisitor); acceptAnnotations((AttributedElement)methodModel, methodVisitor::visitAnnotation, methodVisitor::visitTypeAnnotation);
/* 326 */         acceptParameterAnnotations(methodModel, methodVisitor, true);
/* 327 */         acceptParameterAnnotations(methodModel, methodVisitor, false);
/* 328 */         Objects.requireNonNull(methodVisitor); acceptAttributes((AttributedElement)methodModel, false, methodVisitor::visitAttribute);
/* 329 */         methodModel.findAttribute(Attributes.code()).filter(paramCodeAttribute -> ((flags & 0x1) == 0)).ifPresent(code -> {
/*     */               // Byte code:
/*     */               //   0: aload_1
/*     */               //   1: invokeinterface methodType : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   6: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   11: invokestatic getMethodType : (Ljava/lang/String;)Lnet/bytebuddy/jar/asm/Type;
/*     */               //   14: invokevirtual getArgumentTypes : ()[Lnet/bytebuddy/jar/asm/Type;
/*     */               //   17: arraylength
/*     */               //   18: aload_1
/*     */               //   19: invokeinterface flags : ()Ljava/lang/classfile/AccessFlags;
/*     */               //   24: getstatic java/lang/reflect/AccessFlag.STATIC : Ljava/lang/reflect/AccessFlag;
/*     */               //   27: invokeinterface has : (Ljava/lang/reflect/AccessFlag;)Z
/*     */               //   32: ifeq -> 39
/*     */               //   35: iconst_0
/*     */               //   36: goto -> 40
/*     */               //   39: iconst_1
/*     */               //   40: iadd
/*     */               //   41: istore #6
/*     */               //   43: iload_2
/*     */               //   44: iconst_4
/*     */               //   45: iand
/*     */               //   46: ifne -> 79
/*     */               //   49: aload #5
/*     */               //   51: invokestatic stackMapTable : ()Ljava/lang/classfile/AttributeMapper;
/*     */               //   54: invokeinterface findAttribute : (Ljava/lang/classfile/AttributeMapper;)Ljava/util/Optional;
/*     */               //   59: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   64: invokevirtual map : (Ljava/util/function/Function;)Ljava/util/Optional;
/*     */               //   67: invokestatic emptyMap : ()Ljava/util/Map;
/*     */               //   70: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */               //   73: checkcast java/util/Map
/*     */               //   76: goto -> 82
/*     */               //   79: invokestatic of : ()Ljava/util/Map;
/*     */               //   82: astore #7
/*     */               //   84: new java/util/LinkedHashMap
/*     */               //   87: dup
/*     */               //   88: invokespecial <init> : ()V
/*     */               //   91: astore #8
/*     */               //   93: new java/util/IdentityHashMap
/*     */               //   96: dup
/*     */               //   97: invokespecial <init> : ()V
/*     */               //   100: astore #9
/*     */               //   102: new java/util/ArrayList
/*     */               //   105: dup
/*     */               //   106: invokespecial <init> : ()V
/*     */               //   109: astore #10
/*     */               //   111: new java/util/ArrayList
/*     */               //   114: dup
/*     */               //   115: invokespecial <init> : ()V
/*     */               //   118: astore #11
/*     */               //   120: aload_3
/*     */               //   121: invokevirtual visitCode : ()V
/*     */               //   124: aconst_null
/*     */               //   125: astore #12
/*     */               //   127: new net/bytebuddy/jar/asmjdkbridge/JdkClassReader$PushbackIterator
/*     */               //   130: dup
/*     */               //   131: aload #5
/*     */               //   133: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */               //   138: invokespecial <init> : (Ljava/util/Iterator;)V
/*     */               //   141: astore #13
/*     */               //   143: aload #13
/*     */               //   145: invokevirtual hasNext : ()Z
/*     */               //   148: ifeq -> 2924
/*     */               //   151: aload #13
/*     */               //   153: invokevirtual next : ()Ljava/lang/Object;
/*     */               //   156: checkcast java/lang/classfile/CodeElement
/*     */               //   159: astore #14
/*     */               //   161: aload #14
/*     */               //   163: dup
/*     */               //   164: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */               //   167: pop
/*     */               //   168: astore #15
/*     */               //   170: iconst_0
/*     */               //   171: istore #16
/*     */               //   173: aload #15
/*     */               //   175: iload #16
/*     */               //   177: <illegal opcode> typeSwitch : (Ljava/lang/classfile/CodeElement;I)I
/*     */               //   182: tableswitch default -> 2865, 0 -> 332, 1 -> 356, 2 -> 392, 3 -> 525, 4 -> 549, 5 -> 573, 6 -> 640, 7 -> 668, 8 -> 728, 9 -> 806, 10 -> 871, 11 -> 1005, 12 -> 1041, 13 -> 1141, 14 -> 1274, 15 -> 1298, 16 -> 1322, 17 -> 1440, 18 -> 1464, 19 -> 1488, 20 -> 1512, 21 -> 1548, 22 -> 1572, 23 -> 1605, 24 -> 1639, 25 -> 1734, 26 -> 1836, 27 -> 1931, 28 -> 1980, 29 -> 2672, 30 -> 2692, 31 -> 2721, 32 -> 2750, 33 -> 2815
/*     */               //   332: aload #15
/*     */               //   334: checkcast java/lang/classfile/instruction/MonitorInstruction
/*     */               //   337: astore #17
/*     */               //   339: aload_3
/*     */               //   340: aload #17
/*     */               //   342: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   347: invokevirtual bytecode : ()I
/*     */               //   350: invokevirtual visitInsn : (I)V
/*     */               //   353: goto -> 2883
/*     */               //   356: aload #15
/*     */               //   358: checkcast java/lang/classfile/instruction/TypeCheckInstruction
/*     */               //   361: astore #18
/*     */               //   363: aload_3
/*     */               //   364: aload #18
/*     */               //   366: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   371: invokevirtual bytecode : ()I
/*     */               //   374: aload #18
/*     */               //   376: invokeinterface type : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */               //   381: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */               //   386: invokevirtual visitTypeInsn : (ILjava/lang/String;)V
/*     */               //   389: goto -> 2883
/*     */               //   392: aload #15
/*     */               //   394: checkcast java/lang/classfile/instruction/LoadInstruction
/*     */               //   397: astore #19
/*     */               //   399: aload_3
/*     */               //   400: getstatic net/bytebuddy/jar/asmjdkbridge/JdkClassReader$1.$SwitchMap$java$lang$classfile$TypeKind : [I
/*     */               //   403: aload #19
/*     */               //   405: invokeinterface typeKind : ()Ljava/lang/classfile/TypeKind;
/*     */               //   410: invokevirtual ordinal : ()I
/*     */               //   413: iaload
/*     */               //   414: tableswitch default -> 489, 1 -> 464, 2 -> 464, 3 -> 464, 4 -> 464, 5 -> 464, 6 -> 469, 7 -> 474, 8 -> 479, 9 -> 484
/*     */               //   464: bipush #21
/*     */               //   466: goto -> 512
/*     */               //   469: bipush #22
/*     */               //   471: goto -> 512
/*     */               //   474: bipush #23
/*     */               //   476: goto -> 512
/*     */               //   479: bipush #24
/*     */               //   481: goto -> 512
/*     */               //   484: bipush #25
/*     */               //   486: goto -> 512
/*     */               //   489: new java/lang/IllegalStateException
/*     */               //   492: dup
/*     */               //   493: aload #19
/*     */               //   495: invokeinterface typeKind : ()Ljava/lang/classfile/TypeKind;
/*     */               //   500: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */               //   503: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */               //   508: invokespecial <init> : (Ljava/lang/String;)V
/*     */               //   511: athrow
/*     */               //   512: aload #19
/*     */               //   514: invokeinterface slot : ()I
/*     */               //   519: invokevirtual visitVarInsn : (II)V
/*     */               //   522: goto -> 2883
/*     */               //   525: aload #15
/*     */               //   527: checkcast java/lang/classfile/instruction/OperatorInstruction
/*     */               //   530: astore #20
/*     */               //   532: aload_3
/*     */               //   533: aload #20
/*     */               //   535: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   540: invokevirtual bytecode : ()I
/*     */               //   543: invokevirtual visitInsn : (I)V
/*     */               //   546: goto -> 2883
/*     */               //   549: aload #15
/*     */               //   551: checkcast java/lang/classfile/instruction/ReturnInstruction
/*     */               //   554: astore #21
/*     */               //   556: aload_3
/*     */               //   557: aload #21
/*     */               //   559: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   564: invokevirtual bytecode : ()I
/*     */               //   567: invokevirtual visitInsn : (I)V
/*     */               //   570: goto -> 2883
/*     */               //   573: aload #15
/*     */               //   575: checkcast java/lang/classfile/instruction/InvokeInstruction
/*     */               //   578: astore #22
/*     */               //   580: aload_3
/*     */               //   581: aload #22
/*     */               //   583: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   588: invokevirtual bytecode : ()I
/*     */               //   591: aload #22
/*     */               //   593: invokeinterface owner : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */               //   598: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */               //   603: aload #22
/*     */               //   605: invokeinterface name : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   610: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   615: aload #22
/*     */               //   617: invokeinterface type : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   622: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   627: aload #22
/*     */               //   629: invokeinterface isInterface : ()Z
/*     */               //   634: invokevirtual visitMethodInsn : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
/*     */               //   637: goto -> 2883
/*     */               //   640: aload #15
/*     */               //   642: checkcast java/lang/classfile/instruction/IncrementInstruction
/*     */               //   645: astore #23
/*     */               //   647: aload_3
/*     */               //   648: aload #23
/*     */               //   650: invokeinterface slot : ()I
/*     */               //   655: aload #23
/*     */               //   657: invokeinterface constant : ()I
/*     */               //   662: invokevirtual visitIincInsn : (II)V
/*     */               //   665: goto -> 2883
/*     */               //   668: aload #15
/*     */               //   670: checkcast java/lang/classfile/instruction/FieldInstruction
/*     */               //   673: astore #24
/*     */               //   675: aload_3
/*     */               //   676: aload #24
/*     */               //   678: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   683: invokevirtual bytecode : ()I
/*     */               //   686: aload #24
/*     */               //   688: invokeinterface owner : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */               //   693: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */               //   698: aload #24
/*     */               //   700: invokeinterface name : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   705: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   710: aload #24
/*     */               //   712: invokeinterface type : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   717: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   722: invokevirtual visitFieldInsn : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */               //   725: goto -> 2883
/*     */               //   728: aload #15
/*     */               //   730: checkcast java/lang/classfile/instruction/InvokeDynamicInstruction
/*     */               //   733: astore #25
/*     */               //   735: aload_3
/*     */               //   736: aload #25
/*     */               //   738: invokeinterface name : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   743: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   748: aload #25
/*     */               //   750: invokeinterface type : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   755: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   760: aload #25
/*     */               //   762: invokeinterface bootstrapMethod : ()Ljava/lang/constant/DirectMethodHandleDesc;
/*     */               //   767: invokestatic toAsmConstant : (Ljava/lang/constant/ConstantDesc;)Ljava/lang/Object;
/*     */               //   770: checkcast net/bytebuddy/jar/asm/Handle
/*     */               //   773: aload #25
/*     */               //   775: invokeinterface bootstrapArgs : ()Ljava/util/List;
/*     */               //   780: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   785: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   790: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   795: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */               //   800: invokevirtual visitInvokeDynamicInsn : (Ljava/lang/String;Ljava/lang/String;Lnet/bytebuddy/jar/asm/Handle;[Ljava/lang/Object;)V
/*     */               //   803: goto -> 2883
/*     */               //   806: aload #15
/*     */               //   808: checkcast java/lang/classfile/instruction/BranchInstruction
/*     */               //   811: astore #26
/*     */               //   813: aload_3
/*     */               //   814: aload #26
/*     */               //   816: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   821: getstatic java/lang/classfile/Opcode.GOTO_W : Ljava/lang/classfile/Opcode;
/*     */               //   824: if_acmpne -> 833
/*     */               //   827: sipush #167
/*     */               //   830: goto -> 843
/*     */               //   833: aload #26
/*     */               //   835: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   840: invokevirtual bytecode : ()I
/*     */               //   843: aload #4
/*     */               //   845: aload #26
/*     */               //   847: invokeinterface target : ()Ljava/lang/classfile/Label;
/*     */               //   852: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   857: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   862: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   865: invokevirtual visitJumpInsn : (ILnet/bytebuddy/jar/asm/Label;)V
/*     */               //   868: goto -> 2883
/*     */               //   871: aload #15
/*     */               //   873: checkcast java/lang/classfile/instruction/StoreInstruction
/*     */               //   876: astore #27
/*     */               //   878: aload_3
/*     */               //   879: getstatic net/bytebuddy/jar/asmjdkbridge/JdkClassReader$1.$SwitchMap$java$lang$classfile$TypeKind : [I
/*     */               //   882: aload #27
/*     */               //   884: invokeinterface typeKind : ()Ljava/lang/classfile/TypeKind;
/*     */               //   889: invokevirtual ordinal : ()I
/*     */               //   892: iaload
/*     */               //   893: tableswitch default -> 969, 1 -> 944, 2 -> 944, 3 -> 944, 4 -> 944, 5 -> 944, 6 -> 949, 7 -> 954, 8 -> 959, 9 -> 964
/*     */               //   944: bipush #54
/*     */               //   946: goto -> 992
/*     */               //   949: bipush #55
/*     */               //   951: goto -> 992
/*     */               //   954: bipush #56
/*     */               //   956: goto -> 992
/*     */               //   959: bipush #57
/*     */               //   961: goto -> 992
/*     */               //   964: bipush #58
/*     */               //   966: goto -> 992
/*     */               //   969: new java/lang/IllegalStateException
/*     */               //   972: dup
/*     */               //   973: aload #27
/*     */               //   975: invokeinterface typeKind : ()Ljava/lang/classfile/TypeKind;
/*     */               //   980: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */               //   983: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */               //   988: invokespecial <init> : (Ljava/lang/String;)V
/*     */               //   991: athrow
/*     */               //   992: aload #27
/*     */               //   994: invokeinterface slot : ()I
/*     */               //   999: invokevirtual visitVarInsn : (II)V
/*     */               //   1002: goto -> 2883
/*     */               //   1005: aload #15
/*     */               //   1007: checkcast java/lang/classfile/instruction/NewReferenceArrayInstruction
/*     */               //   1010: astore #28
/*     */               //   1012: aload_3
/*     */               //   1013: aload #28
/*     */               //   1015: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1020: invokevirtual bytecode : ()I
/*     */               //   1023: aload #28
/*     */               //   1025: invokeinterface componentType : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */               //   1030: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */               //   1035: invokevirtual visitTypeInsn : (ILjava/lang/String;)V
/*     */               //   1038: goto -> 2883
/*     */               //   1041: aload #15
/*     */               //   1043: checkcast java/lang/classfile/instruction/LookupSwitchInstruction
/*     */               //   1046: astore #29
/*     */               //   1048: aload_3
/*     */               //   1049: aload #4
/*     */               //   1051: aload #29
/*     */               //   1053: invokeinterface defaultTarget : ()Ljava/lang/classfile/Label;
/*     */               //   1058: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1063: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1068: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1071: aload #29
/*     */               //   1073: invokeinterface cases : ()Ljava/util/List;
/*     */               //   1078: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   1083: <illegal opcode> applyAsInt : ()Ljava/util/function/ToIntFunction;
/*     */               //   1088: invokeinterface mapToInt : (Ljava/util/function/ToIntFunction;)Ljava/util/stream/IntStream;
/*     */               //   1093: invokeinterface toArray : ()[I
/*     */               //   1098: aload #29
/*     */               //   1100: invokeinterface cases : ()Ljava/util/List;
/*     */               //   1105: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   1110: aload #4
/*     */               //   1112: <illegal opcode> apply : (Ljava/util/Map;)Ljava/util/function/Function;
/*     */               //   1117: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   1122: <illegal opcode> apply : ()Ljava/util/function/IntFunction;
/*     */               //   1127: invokeinterface toArray : (Ljava/util/function/IntFunction;)[Ljava/lang/Object;
/*     */               //   1132: checkcast [Lnet/bytebuddy/jar/asm/Label;
/*     */               //   1135: invokevirtual visitLookupSwitchInsn : (Lnet/bytebuddy/jar/asm/Label;[I[Lnet/bytebuddy/jar/asm/Label;)V
/*     */               //   1138: goto -> 2883
/*     */               //   1141: aload #15
/*     */               //   1143: checkcast java/lang/classfile/instruction/TableSwitchInstruction
/*     */               //   1146: astore #30
/*     */               //   1148: aload #30
/*     */               //   1150: invokeinterface cases : ()Ljava/util/List;
/*     */               //   1155: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   1160: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1165: invokestatic identity : ()Ljava/util/function/Function;
/*     */               //   1168: invokestatic toMap : (Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/stream/Collector;
/*     */               //   1171: invokeinterface collect : (Ljava/util/stream/Collector;)Ljava/lang/Object;
/*     */               //   1176: checkcast java/util/Map
/*     */               //   1179: astore #31
/*     */               //   1181: aload #4
/*     */               //   1183: aload #30
/*     */               //   1185: invokeinterface defaultTarget : ()Ljava/lang/classfile/Label;
/*     */               //   1190: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1195: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1200: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1203: astore #32
/*     */               //   1205: aload_3
/*     */               //   1206: aload #30
/*     */               //   1208: invokeinterface lowValue : ()I
/*     */               //   1213: aload #30
/*     */               //   1215: invokeinterface highValue : ()I
/*     */               //   1220: aload #32
/*     */               //   1222: aload #30
/*     */               //   1224: invokeinterface lowValue : ()I
/*     */               //   1229: aload #30
/*     */               //   1231: invokeinterface highValue : ()I
/*     */               //   1236: invokestatic rangeClosed : (II)Ljava/util/stream/IntStream;
/*     */               //   1239: aload #31
/*     */               //   1241: aload #32
/*     */               //   1243: aload #4
/*     */               //   1245: <illegal opcode> apply : (Ljava/util/Map;Lnet/bytebuddy/jar/asm/Label;Ljava/util/Map;)Ljava/util/function/IntFunction;
/*     */               //   1250: invokeinterface mapToObj : (Ljava/util/function/IntFunction;)Ljava/util/stream/Stream;
/*     */               //   1255: <illegal opcode> apply : ()Ljava/util/function/IntFunction;
/*     */               //   1260: invokeinterface toArray : (Ljava/util/function/IntFunction;)[Ljava/lang/Object;
/*     */               //   1265: checkcast [Lnet/bytebuddy/jar/asm/Label;
/*     */               //   1268: invokevirtual visitTableSwitchInsn : (IILnet/bytebuddy/jar/asm/Label;[Lnet/bytebuddy/jar/asm/Label;)V
/*     */               //   1271: goto -> 2883
/*     */               //   1274: aload #15
/*     */               //   1276: checkcast java/lang/classfile/instruction/ArrayStoreInstruction
/*     */               //   1279: astore #31
/*     */               //   1281: aload_3
/*     */               //   1282: aload #31
/*     */               //   1284: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1289: invokevirtual bytecode : ()I
/*     */               //   1292: invokevirtual visitInsn : (I)V
/*     */               //   1295: goto -> 2883
/*     */               //   1298: aload #15
/*     */               //   1300: checkcast java/lang/classfile/instruction/ArrayLoadInstruction
/*     */               //   1303: astore #32
/*     */               //   1305: aload_3
/*     */               //   1306: aload #32
/*     */               //   1308: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1313: invokevirtual bytecode : ()I
/*     */               //   1316: invokevirtual visitInsn : (I)V
/*     */               //   1319: goto -> 2883
/*     */               //   1322: aload #15
/*     */               //   1324: checkcast java/lang/classfile/instruction/ConstantInstruction
/*     */               //   1327: astore #33
/*     */               //   1329: getstatic net/bytebuddy/jar/asmjdkbridge/JdkClassReader$1.$SwitchMap$java$lang$classfile$Opcode : [I
/*     */               //   1332: aload #33
/*     */               //   1334: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1339: invokevirtual ordinal : ()I
/*     */               //   1342: iaload
/*     */               //   1343: tableswitch default -> 1423, 1 -> 1376, 2 -> 1376, 3 -> 1376, 4 -> 1393, 5 -> 1393
/*     */               //   1376: aload_3
/*     */               //   1377: aload #33
/*     */               //   1379: invokeinterface constantValue : ()Ljava/lang/constant/ConstantDesc;
/*     */               //   1384: invokestatic toAsmConstant : (Ljava/lang/constant/ConstantDesc;)Ljava/lang/Object;
/*     */               //   1387: invokevirtual visitLdcInsn : (Ljava/lang/Object;)V
/*     */               //   1390: goto -> 2883
/*     */               //   1393: aload_3
/*     */               //   1394: aload #33
/*     */               //   1396: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1401: invokevirtual bytecode : ()I
/*     */               //   1404: aload #33
/*     */               //   1406: invokeinterface constantValue : ()Ljava/lang/constant/ConstantDesc;
/*     */               //   1411: checkcast java/lang/Integer
/*     */               //   1414: invokevirtual intValue : ()I
/*     */               //   1417: invokevirtual visitIntInsn : (II)V
/*     */               //   1420: goto -> 2883
/*     */               //   1423: aload_3
/*     */               //   1424: aload #33
/*     */               //   1426: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1431: invokevirtual bytecode : ()I
/*     */               //   1434: invokevirtual visitInsn : (I)V
/*     */               //   1437: goto -> 2883
/*     */               //   1440: aload #15
/*     */               //   1442: checkcast java/lang/classfile/instruction/StackInstruction
/*     */               //   1445: astore #34
/*     */               //   1447: aload_3
/*     */               //   1448: aload #34
/*     */               //   1450: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1455: invokevirtual bytecode : ()I
/*     */               //   1458: invokevirtual visitInsn : (I)V
/*     */               //   1461: goto -> 2883
/*     */               //   1464: aload #15
/*     */               //   1466: checkcast java/lang/classfile/instruction/NopInstruction
/*     */               //   1469: astore #35
/*     */               //   1471: aload_3
/*     */               //   1472: aload #35
/*     */               //   1474: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1479: invokevirtual bytecode : ()I
/*     */               //   1482: invokevirtual visitInsn : (I)V
/*     */               //   1485: goto -> 2883
/*     */               //   1488: aload #15
/*     */               //   1490: checkcast java/lang/classfile/instruction/ThrowInstruction
/*     */               //   1493: astore #36
/*     */               //   1495: aload_3
/*     */               //   1496: aload #36
/*     */               //   1498: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1503: invokevirtual bytecode : ()I
/*     */               //   1506: invokevirtual visitInsn : (I)V
/*     */               //   1509: goto -> 2883
/*     */               //   1512: aload #15
/*     */               //   1514: checkcast java/lang/classfile/instruction/NewObjectInstruction
/*     */               //   1517: astore #37
/*     */               //   1519: aload_3
/*     */               //   1520: aload #37
/*     */               //   1522: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1527: invokevirtual bytecode : ()I
/*     */               //   1530: aload #37
/*     */               //   1532: invokeinterface className : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */               //   1537: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */               //   1542: invokevirtual visitTypeInsn : (ILjava/lang/String;)V
/*     */               //   1545: goto -> 2883
/*     */               //   1548: aload #15
/*     */               //   1550: checkcast java/lang/classfile/instruction/ConvertInstruction
/*     */               //   1553: astore #38
/*     */               //   1555: aload_3
/*     */               //   1556: aload #38
/*     */               //   1558: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1563: invokevirtual bytecode : ()I
/*     */               //   1566: invokevirtual visitInsn : (I)V
/*     */               //   1569: goto -> 2883
/*     */               //   1572: aload #15
/*     */               //   1574: checkcast java/lang/classfile/instruction/NewMultiArrayInstruction
/*     */               //   1577: astore #39
/*     */               //   1579: aload_3
/*     */               //   1580: aload #39
/*     */               //   1582: invokeinterface arrayType : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */               //   1587: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */               //   1592: aload #39
/*     */               //   1594: invokeinterface dimensions : ()I
/*     */               //   1599: invokevirtual visitMultiANewArrayInsn : (Ljava/lang/String;I)V
/*     */               //   1602: goto -> 2883
/*     */               //   1605: aload #15
/*     */               //   1607: checkcast java/lang/classfile/instruction/NewPrimitiveArrayInstruction
/*     */               //   1610: astore #40
/*     */               //   1612: aload_3
/*     */               //   1613: aload #40
/*     */               //   1615: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   1620: invokevirtual bytecode : ()I
/*     */               //   1623: aload #40
/*     */               //   1625: invokeinterface typeKind : ()Ljava/lang/classfile/TypeKind;
/*     */               //   1630: invokevirtual newarrayCode : ()I
/*     */               //   1633: invokevirtual visitIntInsn : (II)V
/*     */               //   1636: goto -> 2883
/*     */               //   1639: aload #15
/*     */               //   1641: checkcast java/lang/classfile/instruction/LocalVariableType
/*     */               //   1644: astore #41
/*     */               //   1646: aload #8
/*     */               //   1648: new net/bytebuddy/jar/asmjdkbridge/JdkClassReader$MergedLocalVariableKey
/*     */               //   1651: dup
/*     */               //   1652: aload #4
/*     */               //   1654: aload #41
/*     */               //   1656: invokeinterface startScope : ()Ljava/lang/classfile/Label;
/*     */               //   1661: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1666: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1671: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1674: aload #4
/*     */               //   1676: aload #41
/*     */               //   1678: invokeinterface endScope : ()Ljava/lang/classfile/Label;
/*     */               //   1683: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1688: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1693: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1696: aload #41
/*     */               //   1698: invokeinterface name : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   1703: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   1708: aload #41
/*     */               //   1710: invokeinterface slot : ()I
/*     */               //   1715: invokespecial <init> : (Lnet/bytebuddy/jar/asm/Label;Lnet/bytebuddy/jar/asm/Label;Ljava/lang/String;I)V
/*     */               //   1718: aload #41
/*     */               //   1720: <illegal opcode> apply : (Ljava/lang/classfile/instruction/LocalVariableType;)Ljava/util/function/BiFunction;
/*     */               //   1725: invokeinterface compute : (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;
/*     */               //   1730: pop
/*     */               //   1731: goto -> 2883
/*     */               //   1734: aload #15
/*     */               //   1736: checkcast java/lang/classfile/instruction/ExceptionCatch
/*     */               //   1739: astore #42
/*     */               //   1741: aload_3
/*     */               //   1742: aload #4
/*     */               //   1744: aload #42
/*     */               //   1746: invokeinterface tryStart : ()Ljava/lang/classfile/Label;
/*     */               //   1751: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1756: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1761: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1764: aload #4
/*     */               //   1766: aload #42
/*     */               //   1768: invokeinterface tryEnd : ()Ljava/lang/classfile/Label;
/*     */               //   1773: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1778: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1783: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1786: aload #4
/*     */               //   1788: aload #42
/*     */               //   1790: invokeinterface handler : ()Ljava/lang/classfile/Label;
/*     */               //   1795: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1800: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1805: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1808: aload #42
/*     */               //   1810: invokeinterface catchType : ()Ljava/util/Optional;
/*     */               //   1815: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1820: invokevirtual map : (Ljava/util/function/Function;)Ljava/util/Optional;
/*     */               //   1823: aconst_null
/*     */               //   1824: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */               //   1827: checkcast java/lang/String
/*     */               //   1830: invokevirtual visitTryCatchBlock : (Lnet/bytebuddy/jar/asm/Label;Lnet/bytebuddy/jar/asm/Label;Lnet/bytebuddy/jar/asm/Label;Ljava/lang/String;)V
/*     */               //   1833: goto -> 2883
/*     */               //   1836: aload #15
/*     */               //   1838: checkcast java/lang/classfile/instruction/LocalVariable
/*     */               //   1841: astore #43
/*     */               //   1843: aload #8
/*     */               //   1845: new net/bytebuddy/jar/asmjdkbridge/JdkClassReader$MergedLocalVariableKey
/*     */               //   1848: dup
/*     */               //   1849: aload #4
/*     */               //   1851: aload #43
/*     */               //   1853: invokeinterface startScope : ()Ljava/lang/classfile/Label;
/*     */               //   1858: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1863: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1868: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1871: aload #4
/*     */               //   1873: aload #43
/*     */               //   1875: invokeinterface endScope : ()Ljava/lang/classfile/Label;
/*     */               //   1880: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   1885: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   1890: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   1893: aload #43
/*     */               //   1895: invokeinterface name : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */               //   1900: invokeinterface stringValue : ()Ljava/lang/String;
/*     */               //   1905: aload #43
/*     */               //   1907: invokeinterface slot : ()I
/*     */               //   1912: invokespecial <init> : (Lnet/bytebuddy/jar/asm/Label;Lnet/bytebuddy/jar/asm/Label;Ljava/lang/String;I)V
/*     */               //   1915: aload #43
/*     */               //   1917: <illegal opcode> apply : (Ljava/lang/classfile/instruction/LocalVariable;)Ljava/util/function/BiFunction;
/*     */               //   1922: invokeinterface compute : (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;
/*     */               //   1927: pop
/*     */               //   1928: goto -> 2883
/*     */               //   1931: aload #15
/*     */               //   1933: checkcast java/lang/classfile/instruction/LineNumber
/*     */               //   1936: astore #44
/*     */               //   1938: iload_2
/*     */               //   1939: iconst_2
/*     */               //   1940: iand
/*     */               //   1941: ifne -> 2883
/*     */               //   1944: aload #12
/*     */               //   1946: ifnonnull -> 1964
/*     */               //   1949: new net/bytebuddy/jar/asm/Label
/*     */               //   1952: dup
/*     */               //   1953: invokespecial <init> : ()V
/*     */               //   1956: astore #12
/*     */               //   1958: aload_3
/*     */               //   1959: aload #12
/*     */               //   1961: invokevirtual visitLabel : (Lnet/bytebuddy/jar/asm/Label;)V
/*     */               //   1964: aload_3
/*     */               //   1965: aload #44
/*     */               //   1967: invokeinterface line : ()I
/*     */               //   1972: aload #12
/*     */               //   1974: invokevirtual visitLineNumber : (ILnet/bytebuddy/jar/asm/Label;)V
/*     */               //   1977: goto -> 2883
/*     */               //   1980: aload #15
/*     */               //   1982: checkcast java/lang/classfile/instruction/LabelTarget
/*     */               //   1985: astore #45
/*     */               //   1987: aload #4
/*     */               //   1989: aload #45
/*     */               //   1991: invokeinterface label : ()Ljava/lang/classfile/Label;
/*     */               //   1996: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   2001: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   2006: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   2009: astore #12
/*     */               //   2011: aload_3
/*     */               //   2012: aload #12
/*     */               //   2014: invokevirtual visitLabel : (Lnet/bytebuddy/jar/asm/Label;)V
/*     */               //   2017: aload #7
/*     */               //   2019: aload #45
/*     */               //   2021: invokeinterface label : ()Ljava/lang/classfile/Label;
/*     */               //   2026: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */               //   2031: checkcast java/lang/classfile/attribute/StackMapFrameInfo
/*     */               //   2034: astore #46
/*     */               //   2036: aload #46
/*     */               //   2038: ifnull -> 2669
/*     */               //   2041: iload_2
/*     */               //   2042: iconst_2
/*     */               //   2043: iand
/*     */               //   2044: ifne -> 2103
/*     */               //   2047: aload #13
/*     */               //   2049: invokevirtual hasNext : ()Z
/*     */               //   2052: ifeq -> 2103
/*     */               //   2055: aload #13
/*     */               //   2057: invokevirtual next : ()Ljava/lang/Object;
/*     */               //   2060: checkcast java/lang/classfile/CodeElement
/*     */               //   2063: astore #47
/*     */               //   2065: aload #47
/*     */               //   2067: instanceof java/lang/classfile/instruction/LineNumber
/*     */               //   2070: ifeq -> 2096
/*     */               //   2073: aload #47
/*     */               //   2075: checkcast java/lang/classfile/instruction/LineNumber
/*     */               //   2078: astore #48
/*     */               //   2080: aload_3
/*     */               //   2081: aload #48
/*     */               //   2083: invokeinterface line : ()I
/*     */               //   2088: aload #12
/*     */               //   2090: invokevirtual visitLineNumber : (ILnet/bytebuddy/jar/asm/Label;)V
/*     */               //   2093: goto -> 2103
/*     */               //   2096: aload #13
/*     */               //   2098: aload #47
/*     */               //   2100: invokevirtual push : (Ljava/lang/Object;)V
/*     */               //   2103: iload_2
/*     */               //   2104: bipush #8
/*     */               //   2106: iand
/*     */               //   2107: ifeq -> 2238
/*     */               //   2110: aload_3
/*     */               //   2111: iconst_m1
/*     */               //   2112: aload #46
/*     */               //   2114: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2119: invokeinterface size : ()I
/*     */               //   2124: aload #46
/*     */               //   2126: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2131: invokeinterface isEmpty : ()Z
/*     */               //   2136: ifeq -> 2143
/*     */               //   2139: aconst_null
/*     */               //   2140: goto -> 2172
/*     */               //   2143: aload #46
/*     */               //   2145: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2150: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   2155: aload #4
/*     */               //   2157: <illegal opcode> apply : (Ljava/util/Map;)Ljava/util/function/Function;
/*     */               //   2162: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   2167: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */               //   2172: aload #46
/*     */               //   2174: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2179: invokeinterface size : ()I
/*     */               //   2184: aload #46
/*     */               //   2186: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2191: invokeinterface isEmpty : ()Z
/*     */               //   2196: ifeq -> 2203
/*     */               //   2199: aconst_null
/*     */               //   2200: goto -> 2232
/*     */               //   2203: aload #46
/*     */               //   2205: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2210: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   2215: aload #4
/*     */               //   2217: <illegal opcode> apply : (Ljava/util/Map;)Ljava/util/function/Function;
/*     */               //   2222: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   2227: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */               //   2232: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2235: goto -> 2669
/*     */               //   2238: aload #46
/*     */               //   2240: invokeinterface frameType : ()I
/*     */               //   2245: bipush #64
/*     */               //   2247: if_icmpge -> 2262
/*     */               //   2250: aload_3
/*     */               //   2251: iconst_3
/*     */               //   2252: iconst_0
/*     */               //   2253: aconst_null
/*     */               //   2254: iconst_0
/*     */               //   2255: aconst_null
/*     */               //   2256: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2259: goto -> 2669
/*     */               //   2262: aload #46
/*     */               //   2264: invokeinterface frameType : ()I
/*     */               //   2269: sipush #128
/*     */               //   2272: if_icmpge -> 2313
/*     */               //   2275: aload_3
/*     */               //   2276: iconst_4
/*     */               //   2277: iconst_0
/*     */               //   2278: aconst_null
/*     */               //   2279: iconst_1
/*     */               //   2280: iconst_1
/*     */               //   2281: anewarray java/lang/Object
/*     */               //   2284: dup
/*     */               //   2285: iconst_0
/*     */               //   2286: aload #46
/*     */               //   2288: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2293: invokeinterface getFirst : ()Ljava/lang/Object;
/*     */               //   2298: checkcast java/lang/classfile/attribute/StackMapFrameInfo$VerificationTypeInfo
/*     */               //   2301: aload #4
/*     */               //   2303: invokestatic toAsmFrameValue : (Ljava/lang/classfile/attribute/StackMapFrameInfo$VerificationTypeInfo;Ljava/util/Map;)Ljava/lang/Object;
/*     */               //   2306: aastore
/*     */               //   2307: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2310: goto -> 2669
/*     */               //   2313: aload #46
/*     */               //   2315: invokeinterface frameType : ()I
/*     */               //   2320: sipush #247
/*     */               //   2323: if_icmpge -> 2346
/*     */               //   2326: new java/lang/IllegalArgumentException
/*     */               //   2329: dup
/*     */               //   2330: aload #46
/*     */               //   2332: invokeinterface frameType : ()I
/*     */               //   2337: <illegal opcode> makeConcatWithConstants : (I)Ljava/lang/String;
/*     */               //   2342: invokespecial <init> : (Ljava/lang/String;)V
/*     */               //   2345: athrow
/*     */               //   2346: aload #46
/*     */               //   2348: invokeinterface frameType : ()I
/*     */               //   2353: sipush #247
/*     */               //   2356: if_icmpne -> 2397
/*     */               //   2359: aload_3
/*     */               //   2360: iconst_4
/*     */               //   2361: iconst_0
/*     */               //   2362: aconst_null
/*     */               //   2363: iconst_1
/*     */               //   2364: iconst_1
/*     */               //   2365: anewarray java/lang/Object
/*     */               //   2368: dup
/*     */               //   2369: iconst_0
/*     */               //   2370: aload #46
/*     */               //   2372: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2377: invokeinterface getFirst : ()Ljava/lang/Object;
/*     */               //   2382: checkcast java/lang/classfile/attribute/StackMapFrameInfo$VerificationTypeInfo
/*     */               //   2385: aload #4
/*     */               //   2387: invokestatic toAsmFrameValue : (Ljava/lang/classfile/attribute/StackMapFrameInfo$VerificationTypeInfo;Ljava/util/Map;)Ljava/lang/Object;
/*     */               //   2390: aastore
/*     */               //   2391: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2394: goto -> 2669
/*     */               //   2397: aload #46
/*     */               //   2399: invokeinterface frameType : ()I
/*     */               //   2404: sipush #251
/*     */               //   2407: if_icmpge -> 2450
/*     */               //   2410: aload_3
/*     */               //   2411: iconst_2
/*     */               //   2412: iload #6
/*     */               //   2414: aload #46
/*     */               //   2416: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2421: invokeinterface size : ()I
/*     */               //   2426: isub
/*     */               //   2427: aconst_null
/*     */               //   2428: iconst_0
/*     */               //   2429: aconst_null
/*     */               //   2430: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2433: aload #46
/*     */               //   2435: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2440: invokeinterface size : ()I
/*     */               //   2445: istore #6
/*     */               //   2447: goto -> 2669
/*     */               //   2450: aload #46
/*     */               //   2452: invokeinterface frameType : ()I
/*     */               //   2457: sipush #251
/*     */               //   2460: if_icmpne -> 2475
/*     */               //   2463: aload_3
/*     */               //   2464: iconst_3
/*     */               //   2465: iconst_0
/*     */               //   2466: aconst_null
/*     */               //   2467: iconst_0
/*     */               //   2468: aconst_null
/*     */               //   2469: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2472: goto -> 2669
/*     */               //   2475: aload #46
/*     */               //   2477: invokeinterface frameType : ()I
/*     */               //   2482: sipush #255
/*     */               //   2485: if_icmpge -> 2568
/*     */               //   2488: aload #46
/*     */               //   2490: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2495: invokeinterface size : ()I
/*     */               //   2500: iload #6
/*     */               //   2502: isub
/*     */               //   2503: istore #47
/*     */               //   2505: aload_3
/*     */               //   2506: iconst_1
/*     */               //   2507: iload #47
/*     */               //   2509: aload #46
/*     */               //   2511: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2516: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   2521: iload #6
/*     */               //   2523: i2l
/*     */               //   2524: invokeinterface skip : (J)Ljava/util/stream/Stream;
/*     */               //   2529: aload #4
/*     */               //   2531: <illegal opcode> apply : (Ljava/util/Map;)Ljava/util/function/Function;
/*     */               //   2536: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   2541: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */               //   2546: iconst_0
/*     */               //   2547: aconst_null
/*     */               //   2548: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2551: aload #46
/*     */               //   2553: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2558: invokeinterface size : ()I
/*     */               //   2563: istore #6
/*     */               //   2565: goto -> 2669
/*     */               //   2568: aload_3
/*     */               //   2569: iconst_0
/*     */               //   2570: aload #46
/*     */               //   2572: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2577: invokeinterface size : ()I
/*     */               //   2582: aload #46
/*     */               //   2584: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2589: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   2594: aload #4
/*     */               //   2596: <illegal opcode> apply : (Ljava/util/Map;)Ljava/util/function/Function;
/*     */               //   2601: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   2606: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */               //   2611: aload #46
/*     */               //   2613: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2618: invokeinterface size : ()I
/*     */               //   2623: aload #46
/*     */               //   2625: invokeinterface stack : ()Ljava/util/List;
/*     */               //   2630: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */               //   2635: aload #4
/*     */               //   2637: <illegal opcode> apply : (Ljava/util/Map;)Ljava/util/function/Function;
/*     */               //   2642: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */               //   2647: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */               //   2652: invokevirtual visitFrame : (II[Ljava/lang/Object;I[Ljava/lang/Object;)V
/*     */               //   2655: aload #46
/*     */               //   2657: invokeinterface locals : ()Ljava/util/List;
/*     */               //   2662: invokeinterface size : ()I
/*     */               //   2667: istore #6
/*     */               //   2669: goto -> 2883
/*     */               //   2672: aload #15
/*     */               //   2674: checkcast java/lang/classfile/instruction/CharacterRange
/*     */               //   2677: astore #46
/*     */               //   2679: aload #11
/*     */               //   2681: aload #46
/*     */               //   2683: invokeinterface add : (Ljava/lang/Object;)Z
/*     */               //   2688: pop
/*     */               //   2689: goto -> 2883
/*     */               //   2692: aload #15
/*     */               //   2694: checkcast java/lang/classfile/attribute/RuntimeVisibleTypeAnnotationsAttribute
/*     */               //   2697: astore #47
/*     */               //   2699: aload_0
/*     */               //   2700: aload #47
/*     */               //   2702: invokeinterface annotations : ()Ljava/util/List;
/*     */               //   2707: iconst_1
/*     */               //   2708: aload_3
/*     */               //   2709: aload #4
/*     */               //   2711: aload #10
/*     */               //   2713: aload #9
/*     */               //   2715: invokevirtual appendCodeAnnotations : (Ljava/util/List;ZLnet/bytebuddy/jar/asm/MethodVisitor;Ljava/util/Map;Ljava/util/List;Ljava/util/Map;)V
/*     */               //   2718: goto -> 2883
/*     */               //   2721: aload #15
/*     */               //   2723: checkcast java/lang/classfile/attribute/RuntimeInvisibleTypeAnnotationsAttribute
/*     */               //   2726: astore #48
/*     */               //   2728: aload_0
/*     */               //   2729: aload #48
/*     */               //   2731: invokeinterface annotations : ()Ljava/util/List;
/*     */               //   2736: iconst_0
/*     */               //   2737: aload_3
/*     */               //   2738: aload #4
/*     */               //   2740: aload #10
/*     */               //   2742: aload #9
/*     */               //   2744: invokevirtual appendCodeAnnotations : (Ljava/util/List;ZLnet/bytebuddy/jar/asm/MethodVisitor;Ljava/util/Map;Ljava/util/List;Ljava/util/Map;)V
/*     */               //   2747: goto -> 2883
/*     */               //   2750: aload #15
/*     */               //   2752: checkcast java/lang/classfile/instruction/DiscontinuedInstruction$JsrInstruction
/*     */               //   2755: astore #49
/*     */               //   2757: aload_3
/*     */               //   2758: aload #49
/*     */               //   2760: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   2765: getstatic java/lang/classfile/Opcode.JSR_W : Ljava/lang/classfile/Opcode;
/*     */               //   2768: if_acmpne -> 2777
/*     */               //   2771: getstatic java/lang/classfile/Opcode.JSR : Ljava/lang/classfile/Opcode;
/*     */               //   2774: goto -> 2784
/*     */               //   2777: aload #49
/*     */               //   2779: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   2784: invokevirtual bytecode : ()I
/*     */               //   2787: aload #4
/*     */               //   2789: aload #49
/*     */               //   2791: invokeinterface target : ()Ljava/lang/classfile/Label;
/*     */               //   2796: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */               //   2801: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */               //   2806: checkcast net/bytebuddy/jar/asm/Label
/*     */               //   2809: invokevirtual visitJumpInsn : (ILnet/bytebuddy/jar/asm/Label;)V
/*     */               //   2812: goto -> 2883
/*     */               //   2815: aload #15
/*     */               //   2817: checkcast java/lang/classfile/instruction/DiscontinuedInstruction$RetInstruction
/*     */               //   2820: astore #50
/*     */               //   2822: aload_3
/*     */               //   2823: aload #50
/*     */               //   2825: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   2830: getstatic java/lang/classfile/Opcode.RET_W : Ljava/lang/classfile/Opcode;
/*     */               //   2833: if_acmpne -> 2842
/*     */               //   2836: getstatic java/lang/classfile/Opcode.RET : Ljava/lang/classfile/Opcode;
/*     */               //   2839: goto -> 2849
/*     */               //   2842: aload #50
/*     */               //   2844: invokeinterface opcode : ()Ljava/lang/classfile/Opcode;
/*     */               //   2849: invokevirtual bytecode : ()I
/*     */               //   2852: aload #50
/*     */               //   2854: invokeinterface slot : ()I
/*     */               //   2859: invokevirtual visitVarInsn : (II)V
/*     */               //   2862: goto -> 2883
/*     */               //   2865: new java/lang/UnsupportedOperationException
/*     */               //   2868: dup
/*     */               //   2869: aload #14
/*     */               //   2871: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */               //   2874: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */               //   2879: invokespecial <init> : (Ljava/lang/String;)V
/*     */               //   2882: athrow
/*     */               //   2883: aload #14
/*     */               //   2885: instanceof java/lang/classfile/Instruction
/*     */               //   2888: ifeq -> 2921
/*     */               //   2891: aload #9
/*     */               //   2893: aload #12
/*     */               //   2895: invokestatic emptyList : ()Ljava/util/List;
/*     */               //   2898: invokeinterface getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */               //   2903: checkcast java/util/List
/*     */               //   2906: aload_0
/*     */               //   2907: aload_3
/*     */               //   2908: <illegal opcode> accept : (Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader;Lnet/bytebuddy/jar/asm/MethodVisitor;)Ljava/util/function/Consumer;
/*     */               //   2913: invokeinterface forEach : (Ljava/util/function/Consumer;)V
/*     */               //   2918: aconst_null
/*     */               //   2919: astore #12
/*     */               //   2921: goto -> 143
/*     */               //   2924: iload_2
/*     */               //   2925: iconst_2
/*     */               //   2926: iand
/*     */               //   2927: ifne -> 2943
/*     */               //   2930: aload #8
/*     */               //   2932: aload_3
/*     */               //   2933: <illegal opcode> accept : (Lnet/bytebuddy/jar/asm/MethodVisitor;)Ljava/util/function/BiConsumer;
/*     */               //   2938: invokeinterface forEach : (Ljava/util/function/BiConsumer;)V
/*     */               //   2943: aload #10
/*     */               //   2945: aload_0
/*     */               //   2946: aload_3
/*     */               //   2947: aload #4
/*     */               //   2949: <illegal opcode> accept : (Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader;Lnet/bytebuddy/jar/asm/MethodVisitor;Ljava/util/Map;)Ljava/util/function/Consumer;
/*     */               //   2954: invokeinterface forEach : (Ljava/util/function/Consumer;)V
/*     */               //   2959: aload #5
/*     */               //   2961: invokestatic characterRangeTable : ()Ljava/lang/classfile/AttributeMapper;
/*     */               //   2964: invokeinterface findAttribute : (Ljava/lang/classfile/AttributeMapper;)Ljava/util/Optional;
/*     */               //   2969: aload_3
/*     */               //   2970: aload #11
/*     */               //   2972: aload #5
/*     */               //   2974: <illegal opcode> accept : (Lnet/bytebuddy/jar/asm/MethodVisitor;Ljava/util/List;Ljava/lang/classfile/attribute/CodeAttribute;)Ljava/util/function/Consumer;
/*     */               //   2979: invokevirtual ifPresent : (Ljava/util/function/Consumer;)V
/*     */               //   2982: aload_0
/*     */               //   2983: aload #5
/*     */               //   2985: iconst_1
/*     */               //   2986: aload_3
/*     */               //   2987: dup
/*     */               //   2988: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */               //   2991: pop
/*     */               //   2992: <illegal opcode> accept : (Lnet/bytebuddy/jar/asm/MethodVisitor;)Ljava/util/function/Consumer;
/*     */               //   2997: invokevirtual acceptAttributes : (Ljava/lang/classfile/AttributedElement;ZLjava/util/function/Consumer;)V
/*     */               //   3000: aload_3
/*     */               //   3001: aload #5
/*     */               //   3003: invokeinterface maxStack : ()I
/*     */               //   3008: aload #5
/*     */               //   3010: invokeinterface maxLocals : ()I
/*     */               //   3015: invokevirtual visitMaxs : (II)V
/*     */               //   3018: return
/*     */               // Line number table:
/*     */               //   Java source line number -> byte code offset
/*     */               //   #330	-> 0
/*     */               //   #331	-> 43
/*     */               //   #333	-> 49
/*     */               //   #331	-> 51
/*     */               //   #332	-> 64
/*     */               //   #333	-> 67
/*     */               //   #334	-> 84
/*     */               //   #335	-> 93
/*     */               //   #336	-> 102
/*     */               //   #337	-> 111
/*     */               //   #338	-> 120
/*     */               //   #339	-> 124
/*     */               //   #340	-> 127
/*     */               //   #341	-> 143
/*     */               //   #342	-> 151
/*     */               //   #343	-> 161
/*     */               //   #344	-> 332
/*     */               //   #345	-> 356
/*     */               //   #346	-> 392
/*     */               //   #347	-> 464
/*     */               //   #348	-> 469
/*     */               //   #349	-> 474
/*     */               //   #350	-> 479
/*     */               //   #351	-> 484
/*     */               //   #352	-> 489
/*     */               //   #346	-> 512
/*     */               //   #353	-> 514
/*     */               //   #346	-> 519
/*     */               //   #354	-> 525
/*     */               //   #355	-> 549
/*     */               //   #356	-> 573
/*     */               //   #357	-> 593
/*     */               //   #358	-> 605
/*     */               //   #359	-> 617
/*     */               //   #360	-> 629
/*     */               //   #356	-> 634
/*     */               //   #361	-> 640
/*     */               //   #362	-> 668
/*     */               //   #363	-> 688
/*     */               //   #364	-> 700
/*     */               //   #365	-> 712
/*     */               //   #362	-> 722
/*     */               //   #366	-> 728
/*     */               //   #367	-> 750
/*     */               //   #368	-> 762
/*     */               //   #369	-> 775
/*     */               //   #366	-> 800
/*     */               //   #370	-> 806
/*     */               //   #371	-> 814
/*     */               //   #372	-> 847
/*     */               //   #370	-> 865
/*     */               //   #373	-> 871
/*     */               //   #374	-> 944
/*     */               //   #375	-> 949
/*     */               //   #376	-> 954
/*     */               //   #377	-> 959
/*     */               //   #378	-> 964
/*     */               //   #379	-> 969
/*     */               //   #373	-> 992
/*     */               //   #380	-> 994
/*     */               //   #373	-> 999
/*     */               //   #381	-> 1005
/*     */               //   #382	-> 1041
/*     */               //   #383	-> 1048
/*     */               //   #384	-> 1073
/*     */               //   #385	-> 1100
/*     */               //   #383	-> 1135
/*     */               //   #386	-> 1138
/*     */               //   #387	-> 1141
/*     */               //   #388	-> 1148
/*     */               //   #389	-> 1181
/*     */               //   #390	-> 1205
/*     */               //   #391	-> 1215
/*     */               //   #393	-> 1224
/*     */               //   #396	-> 1260
/*     */               //   #390	-> 1268
/*     */               //   #397	-> 1271
/*     */               //   #398	-> 1274
/*     */               //   #399	-> 1298
/*     */               //   #400	-> 1322
/*     */               //   #401	-> 1329
/*     */               //   #402	-> 1376
/*     */               //   #403	-> 1393
/*     */               //   #404	-> 1423
/*     */               //   #407	-> 1440
/*     */               //   #408	-> 1464
/*     */               //   #409	-> 1488
/*     */               //   #410	-> 1512
/*     */               //   #411	-> 1548
/*     */               //   #412	-> 1572
/*     */               //   #413	-> 1605
/*     */               //   #414	-> 1639
/*     */               //   #415	-> 1656
/*     */               //   #416	-> 1678
/*     */               //   #417	-> 1698
/*     */               //   #418	-> 1710
/*     */               //   #414	-> 1725
/*     */               //   #420	-> 1734
/*     */               //   #421	-> 1768
/*     */               //   #422	-> 1790
/*     */               //   #423	-> 1810
/*     */               //   #420	-> 1830
/*     */               //   #424	-> 1836
/*     */               //   #425	-> 1853
/*     */               //   #426	-> 1875
/*     */               //   #427	-> 1895
/*     */               //   #428	-> 1907
/*     */               //   #424	-> 1922
/*     */               //   #430	-> 1931
/*     */               //   #431	-> 1938
/*     */               //   #432	-> 1944
/*     */               //   #433	-> 1949
/*     */               //   #434	-> 1958
/*     */               //   #436	-> 1964
/*     */               //   #439	-> 1980
/*     */               //   #440	-> 1987
/*     */               //   #441	-> 2011
/*     */               //   #442	-> 2017
/*     */               //   #443	-> 2036
/*     */               //   #444	-> 2041
/*     */               //   #445	-> 2055
/*     */               //   #446	-> 2065
/*     */               //   #447	-> 2080
/*     */               //   #449	-> 2096
/*     */               //   #452	-> 2103
/*     */               //   #453	-> 2110
/*     */               //   #454	-> 2114
/*     */               //   #455	-> 2124
/*     */               //   #457	-> 2143
/*     */               //   #455	-> 2145
/*     */               //   #456	-> 2162
/*     */               //   #457	-> 2167
/*     */               //   #458	-> 2174
/*     */               //   #459	-> 2184
/*     */               //   #461	-> 2203
/*     */               //   #459	-> 2205
/*     */               //   #460	-> 2222
/*     */               //   #461	-> 2227
/*     */               //   #453	-> 2232
/*     */               //   #462	-> 2238
/*     */               //   #463	-> 2250
/*     */               //   #464	-> 2262
/*     */               //   #465	-> 2275
/*     */               //   #467	-> 2288
/*     */               //   #465	-> 2307
/*     */               //   #468	-> 2313
/*     */               //   #469	-> 2326
/*     */               //   #470	-> 2346
/*     */               //   #471	-> 2359
/*     */               //   #473	-> 2372
/*     */               //   #471	-> 2391
/*     */               //   #474	-> 2397
/*     */               //   #475	-> 2410
/*     */               //   #476	-> 2416
/*     */               //   #475	-> 2430
/*     */               //   #478	-> 2433
/*     */               //   #479	-> 2450
/*     */               //   #480	-> 2463
/*     */               //   #481	-> 2475
/*     */               //   #482	-> 2488
/*     */               //   #483	-> 2505
/*     */               //   #484	-> 2511
/*     */               //   #483	-> 2548
/*     */               //   #486	-> 2551
/*     */               //   #487	-> 2565
/*     */               //   #488	-> 2568
/*     */               //   #489	-> 2572
/*     */               //   #490	-> 2613
/*     */               //   #488	-> 2652
/*     */               //   #491	-> 2655
/*     */               //   #494	-> 2669
/*     */               //   #495	-> 2672
/*     */               //   #496	-> 2692
/*     */               //   #497	-> 2721
/*     */               //   #498	-> 2750
/*     */               //   #499	-> 2758
/*     */               //   #500	-> 2791
/*     */               //   #498	-> 2809
/*     */               //   #501	-> 2815
/*     */               //   #502	-> 2823
/*     */               //   #503	-> 2854
/*     */               //   #501	-> 2859
/*     */               //   #504	-> 2865
/*     */               //   #506	-> 2883
/*     */               //   #507	-> 2891
/*     */               //   #512	-> 2918
/*     */               //   #514	-> 2921
/*     */               //   #515	-> 2924
/*     */               //   #516	-> 2930
/*     */               //   #523	-> 2943
/*     */               //   #534	-> 2959
/*     */               //   #535	-> 2982
/*     */               //   #536	-> 3000
/*     */               //   #537	-> 3018
/*     */               // Local variable table:
/*     */               //   start	length	slot	name	descriptor
/*     */               //   339	17	17	value	Ljava/lang/classfile/instruction/MonitorInstruction;
/*     */               //   363	29	18	value	Ljava/lang/classfile/instruction/TypeCheckInstruction;
/*     */               //   399	126	19	value	Ljava/lang/classfile/instruction/LoadInstruction;
/*     */               //   532	17	20	value	Ljava/lang/classfile/instruction/OperatorInstruction;
/*     */               //   556	17	21	value	Ljava/lang/classfile/instruction/ReturnInstruction;
/*     */               //   580	60	22	value	Ljava/lang/classfile/instruction/InvokeInstruction;
/*     */               //   647	21	23	value	Ljava/lang/classfile/instruction/IncrementInstruction;
/*     */               //   675	53	24	value	Ljava/lang/classfile/instruction/FieldInstruction;
/*     */               //   735	71	25	value	Ljava/lang/classfile/instruction/InvokeDynamicInstruction;
/*     */               //   813	58	26	value	Ljava/lang/classfile/instruction/BranchInstruction;
/*     */               //   878	127	27	value	Ljava/lang/classfile/instruction/StoreInstruction;
/*     */               //   1012	29	28	value	Ljava/lang/classfile/instruction/NewReferenceArrayInstruction;
/*     */               //   1048	93	29	value	Ljava/lang/classfile/instruction/LookupSwitchInstruction;
/*     */               //   1181	90	31	cases	Ljava/util/Map;
/*     */               //   1205	66	32	dflt	Lnet/bytebuddy/jar/asm/Label;
/*     */               //   1148	126	30	value	Ljava/lang/classfile/instruction/TableSwitchInstruction;
/*     */               //   1281	17	31	value	Ljava/lang/classfile/instruction/ArrayStoreInstruction;
/*     */               //   1305	17	32	value	Ljava/lang/classfile/instruction/ArrayLoadInstruction;
/*     */               //   1329	111	33	value	Ljava/lang/classfile/instruction/ConstantInstruction;
/*     */               //   1447	17	34	value	Ljava/lang/classfile/instruction/StackInstruction;
/*     */               //   1471	17	35	value	Ljava/lang/classfile/instruction/NopInstruction;
/*     */               //   1495	17	36	value	Ljava/lang/classfile/instruction/ThrowInstruction;
/*     */               //   1519	29	37	value	Ljava/lang/classfile/instruction/NewObjectInstruction;
/*     */               //   1555	17	38	value	Ljava/lang/classfile/instruction/ConvertInstruction;
/*     */               //   1579	26	39	value	Ljava/lang/classfile/instruction/NewMultiArrayInstruction;
/*     */               //   1612	27	40	value	Ljava/lang/classfile/instruction/NewPrimitiveArrayInstruction;
/*     */               //   1646	88	41	value	Ljava/lang/classfile/instruction/LocalVariableType;
/*     */               //   1741	95	42	value	Ljava/lang/classfile/instruction/ExceptionCatch;
/*     */               //   1843	88	43	value	Ljava/lang/classfile/instruction/LocalVariable;
/*     */               //   1938	42	44	value	Ljava/lang/classfile/instruction/LineNumber;
/*     */               //   2080	16	48	line	Ljava/lang/classfile/instruction/LineNumber;
/*     */               //   2065	38	47	next	Ljava/lang/classfile/CodeElement;
/*     */               //   2505	60	47	appended	I
/*     */               //   2036	633	46	frame	Ljava/lang/classfile/attribute/StackMapFrameInfo;
/*     */               //   1987	685	45	value	Ljava/lang/classfile/instruction/LabelTarget;
/*     */               //   2679	13	46	characterRange	Ljava/lang/classfile/instruction/CharacterRange;
/*     */               //   2699	22	47	value	Ljava/lang/classfile/attribute/RuntimeVisibleTypeAnnotationsAttribute;
/*     */               //   2728	22	48	value	Ljava/lang/classfile/attribute/RuntimeInvisibleTypeAnnotationsAttribute;
/*     */               //   2757	58	49	value	Ljava/lang/classfile/instruction/DiscontinuedInstruction$JsrInstruction;
/*     */               //   2822	43	50	value	Ljava/lang/classfile/instruction/DiscontinuedInstruction$RetInstruction;
/*     */               //   170	2713	15	selector0$temp	Ljava/lang/classfile/CodeElement;
/*     */               //   173	2710	16	index$1	I
/*     */               //   161	2760	14	element	Ljava/lang/classfile/CodeElement;
/*     */               //   0	3019	0	this	Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader;
/*     */               //   0	3019	1	methodModel	Ljava/lang/classfile/MethodModel;
/*     */               //   0	3019	2	flags	I
/*     */               //   0	3019	3	methodVisitor	Lnet/bytebuddy/jar/asm/MethodVisitor;
/*     */               //   0	3019	4	labels	Ljava/util/Map;
/*     */               //   0	3019	5	code	Ljava/lang/classfile/attribute/CodeAttribute;
/*     */               //   43	2976	6	localVariablesSize	I
/*     */               //   84	2935	7	frames	Ljava/util/Map;
/*     */               //   93	2926	8	localVariables	Ljava/util/SequencedMap;
/*     */               //   102	2917	9	offsetTypeAnnotations	Ljava/util/Map;
/*     */               //   111	2908	10	localVariableAnnotations	Ljava/util/List;
/*     */               //   120	2899	11	characterRanges	Ljava/util/List;
/*     */               //   127	2892	12	currentPositionLabel	Lnet/bytebuddy/jar/asm/Label;
/*     */               //   143	2876	13	it	Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader$PushbackIterator;
/*     */               // Local variable type table:
/*     */               //   start	length	slot	name	signature
/*     */               //   1181	90	31	cases	Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/classfile/instruction/SwitchCase;>;
/*     */               //   84	2935	7	frames	Ljava/util/Map<Ljava/lang/classfile/Label;Ljava/lang/classfile/attribute/StackMapFrameInfo;>;
/*     */               //   93	2926	8	localVariables	Ljava/util/SequencedMap<Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader$MergedLocalVariableKey;Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader$MergedLocalVariableValue;>;
/*     */               //   102	2917	9	offsetTypeAnnotations	Ljava/util/Map<Lnet/bytebuddy/jar/asm/Label;Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/classfile/TypeAnnotation;Ljava/lang/Boolean;>;>;>;
/*     */               //   111	2908	10	localVariableAnnotations	Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/classfile/TypeAnnotation;Ljava/lang/Boolean;>;>;
/*     */               //   120	2899	11	characterRanges	Ljava/util/List<Ljava/lang/classfile/instruction/CharacterRange;>;
/*     */               //   143	2876	13	it	Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader$PushbackIterator<Ljava/lang/classfile/CodeElement;>;
/*     */             });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 538 */         methodVisitor.visitEnd();
/*     */       } 
/*     */     } 
/* 541 */     classVisitor.visitEnd();
/*     */   }
/*     */   
/*     */   private void acceptAnnotations(AttributedElement element, AnnotationVisitorSource annotationVisitorSource, TypeAnnotationVisitorSource typeAnnotationVisitorSource) {
/* 545 */     element.findAttribute(Attributes.runtimeVisibleAnnotations()).stream()
/* 546 */       .flatMap(annotations -> annotations.annotations().stream())
/* 547 */       .forEach(annotation -> appendAnnotationValues(annotationVisitorSource.visitAnnotation(annotation.className().stringValue(), true), annotation.elements()));
/* 548 */     element.findAttribute(Attributes.runtimeInvisibleAnnotations()).stream()
/* 549 */       .flatMap(annotations -> annotations.annotations().stream())
/* 550 */       .forEach(annotation -> appendAnnotationValues(annotationVisitorSource.visitAnnotation(annotation.className().stringValue(), false), annotation.elements()));
/* 551 */     element.findAttribute(Attributes.runtimeVisibleTypeAnnotations()).stream()
/* 552 */       .flatMap(annotations -> annotations.annotations().stream())
/* 553 */       .forEach(annotation -> appendAnnotationValues(typeAnnotationVisitorSource.visitTypeAnnotation(toTypeReference(annotation.targetInfo()).getValue(), toTypePath(annotation.targetPath()), annotation.annotation().className().stringValue(), true), annotation.annotation().elements()));
/*     */ 
/*     */ 
/*     */     
/* 557 */     element.findAttribute(Attributes.runtimeInvisibleTypeAnnotations()).stream()
/* 558 */       .flatMap(annotations -> annotations.annotations().stream())
/* 559 */       .forEach(annotation -> appendAnnotationValues(typeAnnotationVisitorSource.visitTypeAnnotation(toTypeReference(annotation.targetInfo()).getValue(), toTypePath(annotation.targetPath()), annotation.annotation().className().stringValue(), false), annotation.annotation().elements()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void acceptParameterAnnotations(MethodModel methodModel, MethodVisitor methodVisitor, boolean visible) {
/* 568 */     int count = ((Integer)methodModel.findAttribute(Attributes.methodParameters()).map(parameters -> Integer.valueOf((int)parameters.parameters().stream().filter(()).count())).orElseGet(() -> Integer.valueOf(methodModel.methodTypeSymbol().parameterCount()))).intValue();
/*     */ 
/*     */     
/* 571 */     Optional<List<List<Annotation>>> target = visible ? methodModel.findAttribute(Attributes.runtimeVisibleParameterAnnotations()).map(RuntimeVisibleParameterAnnotationsAttribute::parameterAnnotations) : methodModel.findAttribute(Attributes.runtimeInvisibleParameterAnnotations()).map(RuntimeInvisibleParameterAnnotationsAttribute::parameterAnnotations);
/* 572 */     target.ifPresent(annotations -> {
/*     */           methodVisitor.visitAnnotableParameterCount(count, visible);
/*     */           for (int index = 0; index < annotations.size(); index++) {
/*     */             for (Annotation annotation : annotations.get(index)) {
/*     */               appendAnnotationValues(methodVisitor.visitParameterAnnotation(index, annotation.className().stringValue(), visible), annotation.elements());
/*     */             }
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   private void acceptAttributes(AttributedElement element, boolean code, Consumer<Attribute> consumer) {
/* 583 */     this.attributes.mappers.forEach((paramString, value) -> element.findAttributes(value.attributeMapper()).forEach(()));
/*     */ 
/*     */     
/* 586 */     element.attributes().stream()
/* 587 */       .filter(attribute -> attribute instanceof UnknownAttribute)
/* 588 */       .forEach(attribute -> consumer.accept(new AsmWrappedAttribute.AsmUnknownAttribute((UnknownAttribute)attribute, code)));
/*     */   }
/*     */   
/*     */   private void appendAnnotationValues(AnnotationVisitor annotationVisitor, List<AnnotationElement> elements) {
/* 592 */     if (annotationVisitor != null) {
/* 593 */       elements.forEach(element -> appendAnnotationValue(annotationVisitor, element.name().stringValue(), element.value()));
/* 594 */       annotationVisitor.visitEnd();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendAnnotationValue(AnnotationVisitor annotationVisitor, String name, AnnotationValue annotationValue) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: instanceof net/bytebuddy/jar/asmjdkbridge/JdkClassWriter$WritingAnnotationVisitor
/*     */     //   4: ifeq -> 33
/*     */     //   7: aload_1
/*     */     //   8: checkcast net/bytebuddy/jar/asmjdkbridge/JdkClassWriter$WritingAnnotationVisitor
/*     */     //   11: astore #4
/*     */     //   13: aload #4
/*     */     //   15: aload_0
/*     */     //   16: getfield classModel : Ljava/lang/classfile/ClassModel;
/*     */     //   19: invokevirtual has : (Ljava/lang/classfile/ClassModel;)Z
/*     */     //   22: ifeq -> 33
/*     */     //   25: aload #4
/*     */     //   27: aload_2
/*     */     //   28: aload_3
/*     */     //   29: invokevirtual add : (Ljava/lang/String;Ljava/lang/classfile/AnnotationValue;)V
/*     */     //   32: return
/*     */     //   33: aload_3
/*     */     //   34: dup
/*     */     //   35: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   38: pop
/*     */     //   39: astore #4
/*     */     //   41: iconst_0
/*     */     //   42: istore #5
/*     */     //   44: aload #4
/*     */     //   46: iload #5
/*     */     //   48: <illegal opcode> typeSwitch : (Ljava/lang/classfile/AnnotationValue;I)I
/*     */     //   53: tableswitch default -> 1304, 0 -> 120, 1 -> 145, 2 -> 170, 3 -> 195, 4 -> 220, 5 -> 245, 6 -> 270, 7 -> 295, 8 -> 320, 9 -> 345, 10 -> 375, 11 -> 423, 12 -> 462
/*     */     //   120: aload #4
/*     */     //   122: checkcast java/lang/classfile/AnnotationValue$OfBoolean
/*     */     //   125: astore #6
/*     */     //   127: aload_1
/*     */     //   128: aload_2
/*     */     //   129: aload #6
/*     */     //   131: invokeinterface booleanValue : ()Z
/*     */     //   136: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */     //   139: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   142: goto -> 1321
/*     */     //   145: aload #4
/*     */     //   147: checkcast java/lang/classfile/AnnotationValue$OfByte
/*     */     //   150: astore #7
/*     */     //   152: aload_1
/*     */     //   153: aload_2
/*     */     //   154: aload #7
/*     */     //   156: invokeinterface byteValue : ()B
/*     */     //   161: invokestatic valueOf : (B)Ljava/lang/Byte;
/*     */     //   164: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   167: goto -> 1321
/*     */     //   170: aload #4
/*     */     //   172: checkcast java/lang/classfile/AnnotationValue$OfShort
/*     */     //   175: astore #8
/*     */     //   177: aload_1
/*     */     //   178: aload_2
/*     */     //   179: aload #8
/*     */     //   181: invokeinterface shortValue : ()S
/*     */     //   186: invokestatic valueOf : (S)Ljava/lang/Short;
/*     */     //   189: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   192: goto -> 1321
/*     */     //   195: aload #4
/*     */     //   197: checkcast java/lang/classfile/AnnotationValue$OfChar
/*     */     //   200: astore #9
/*     */     //   202: aload_1
/*     */     //   203: aload_2
/*     */     //   204: aload #9
/*     */     //   206: invokeinterface charValue : ()C
/*     */     //   211: invokestatic valueOf : (C)Ljava/lang/Character;
/*     */     //   214: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   217: goto -> 1321
/*     */     //   220: aload #4
/*     */     //   222: checkcast java/lang/classfile/AnnotationValue$OfInt
/*     */     //   225: astore #10
/*     */     //   227: aload_1
/*     */     //   228: aload_2
/*     */     //   229: aload #10
/*     */     //   231: invokeinterface intValue : ()I
/*     */     //   236: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   239: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   242: goto -> 1321
/*     */     //   245: aload #4
/*     */     //   247: checkcast java/lang/classfile/AnnotationValue$OfLong
/*     */     //   250: astore #11
/*     */     //   252: aload_1
/*     */     //   253: aload_2
/*     */     //   254: aload #11
/*     */     //   256: invokeinterface longValue : ()J
/*     */     //   261: invokestatic valueOf : (J)Ljava/lang/Long;
/*     */     //   264: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   267: goto -> 1321
/*     */     //   270: aload #4
/*     */     //   272: checkcast java/lang/classfile/AnnotationValue$OfFloat
/*     */     //   275: astore #12
/*     */     //   277: aload_1
/*     */     //   278: aload_2
/*     */     //   279: aload #12
/*     */     //   281: invokeinterface floatValue : ()F
/*     */     //   286: invokestatic valueOf : (F)Ljava/lang/Float;
/*     */     //   289: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   292: goto -> 1321
/*     */     //   295: aload #4
/*     */     //   297: checkcast java/lang/classfile/AnnotationValue$OfDouble
/*     */     //   300: astore #13
/*     */     //   302: aload_1
/*     */     //   303: aload_2
/*     */     //   304: aload #13
/*     */     //   306: invokeinterface doubleValue : ()D
/*     */     //   311: invokestatic valueOf : (D)Ljava/lang/Double;
/*     */     //   314: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   317: goto -> 1321
/*     */     //   320: aload #4
/*     */     //   322: checkcast java/lang/classfile/AnnotationValue$OfString
/*     */     //   325: astore #14
/*     */     //   327: aload_1
/*     */     //   328: aload_2
/*     */     //   329: aload #14
/*     */     //   331: invokeinterface stringValue : ()Ljava/lang/String;
/*     */     //   336: invokestatic toAsmConstant : (Ljava/lang/constant/ConstantDesc;)Ljava/lang/Object;
/*     */     //   339: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   342: goto -> 1321
/*     */     //   345: aload #4
/*     */     //   347: checkcast java/lang/classfile/AnnotationValue$OfClass
/*     */     //   350: astore #15
/*     */     //   352: aload_1
/*     */     //   353: aload_2
/*     */     //   354: aload #15
/*     */     //   356: invokeinterface className : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */     //   361: invokeinterface stringValue : ()Ljava/lang/String;
/*     */     //   366: invokestatic getType : (Ljava/lang/String;)Lnet/bytebuddy/jar/asm/Type;
/*     */     //   369: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   372: goto -> 1321
/*     */     //   375: aload #4
/*     */     //   377: checkcast java/lang/classfile/AnnotationValue$OfAnnotation
/*     */     //   380: astore #16
/*     */     //   382: aload_0
/*     */     //   383: aload_1
/*     */     //   384: aload_2
/*     */     //   385: aload #16
/*     */     //   387: invokeinterface annotation : ()Ljava/lang/classfile/Annotation;
/*     */     //   392: invokeinterface className : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */     //   397: invokeinterface stringValue : ()Ljava/lang/String;
/*     */     //   402: invokevirtual visitAnnotation : (Ljava/lang/String;Ljava/lang/String;)Lnet/bytebuddy/jar/asm/AnnotationVisitor;
/*     */     //   405: aload #16
/*     */     //   407: invokeinterface annotation : ()Ljava/lang/classfile/Annotation;
/*     */     //   412: invokeinterface elements : ()Ljava/util/List;
/*     */     //   417: invokevirtual appendAnnotationValues : (Lnet/bytebuddy/jar/asm/AnnotationVisitor;Ljava/util/List;)V
/*     */     //   420: goto -> 1321
/*     */     //   423: aload #4
/*     */     //   425: checkcast java/lang/classfile/AnnotationValue$OfEnum
/*     */     //   428: astore #17
/*     */     //   430: aload_1
/*     */     //   431: aload_2
/*     */     //   432: aload #17
/*     */     //   434: invokeinterface className : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */     //   439: invokeinterface stringValue : ()Ljava/lang/String;
/*     */     //   444: aload #17
/*     */     //   446: invokeinterface constantName : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */     //   451: invokeinterface stringValue : ()Ljava/lang/String;
/*     */     //   456: invokevirtual visitEnum : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   459: goto -> 1321
/*     */     //   462: aload #4
/*     */     //   464: checkcast java/lang/classfile/AnnotationValue$OfArray
/*     */     //   467: astore #18
/*     */     //   469: aload #18
/*     */     //   471: invokeinterface values : ()Ljava/util/List;
/*     */     //   476: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */     //   481: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   486: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */     //   491: invokestatic toSet : ()Ljava/util/stream/Collector;
/*     */     //   494: invokeinterface collect : (Ljava/util/stream/Collector;)Ljava/lang/Object;
/*     */     //   499: checkcast java/util/Set
/*     */     //   502: astore #19
/*     */     //   504: aload #19
/*     */     //   506: invokeinterface size : ()I
/*     */     //   511: iconst_1
/*     */     //   512: if_icmpne -> 1264
/*     */     //   515: aload #19
/*     */     //   517: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   522: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   527: checkcast java/lang/Integer
/*     */     //   530: invokevirtual intValue : ()I
/*     */     //   533: tableswitch default -> 1264, 66 -> 725, 67 -> 879, 68 -> 1187, 69 -> 1264, 70 -> 1110, 71 -> 1264, 72 -> 1264, 73 -> 956, 74 -> 1033, 75 -> 1264, 76 -> 1264, 77 -> 1264, 78 -> 1264, 79 -> 1264, 80 -> 1264, 81 -> 1264, 82 -> 1264, 83 -> 802, 84 -> 1264, 85 -> 1264, 86 -> 1264, 87 -> 1264, 88 -> 1264, 89 -> 1264, 90 -> 648
/*     */     //   648: aload #18
/*     */     //   650: invokeinterface values : ()Ljava/util/List;
/*     */     //   655: invokeinterface size : ()I
/*     */     //   660: newarray boolean
/*     */     //   662: astore #20
/*     */     //   664: iconst_0
/*     */     //   665: istore #21
/*     */     //   667: iload #21
/*     */     //   669: aload #18
/*     */     //   671: invokeinterface values : ()Ljava/util/List;
/*     */     //   676: invokeinterface size : ()I
/*     */     //   681: if_icmpge -> 717
/*     */     //   684: aload #20
/*     */     //   686: iload #21
/*     */     //   688: aload #18
/*     */     //   690: invokeinterface values : ()Ljava/util/List;
/*     */     //   695: iload #21
/*     */     //   697: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   702: checkcast java/lang/classfile/AnnotationValue$OfBoolean
/*     */     //   705: invokeinterface booleanValue : ()Z
/*     */     //   710: bastore
/*     */     //   711: iinc #21, 1
/*     */     //   714: goto -> 667
/*     */     //   717: aload_1
/*     */     //   718: aload_2
/*     */     //   719: aload #20
/*     */     //   721: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   724: return
/*     */     //   725: aload #18
/*     */     //   727: invokeinterface values : ()Ljava/util/List;
/*     */     //   732: invokeinterface size : ()I
/*     */     //   737: newarray byte
/*     */     //   739: astore #20
/*     */     //   741: iconst_0
/*     */     //   742: istore #21
/*     */     //   744: iload #21
/*     */     //   746: aload #18
/*     */     //   748: invokeinterface values : ()Ljava/util/List;
/*     */     //   753: invokeinterface size : ()I
/*     */     //   758: if_icmpge -> 794
/*     */     //   761: aload #20
/*     */     //   763: iload #21
/*     */     //   765: aload #18
/*     */     //   767: invokeinterface values : ()Ljava/util/List;
/*     */     //   772: iload #21
/*     */     //   774: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   779: checkcast java/lang/classfile/AnnotationValue$OfByte
/*     */     //   782: invokeinterface byteValue : ()B
/*     */     //   787: bastore
/*     */     //   788: iinc #21, 1
/*     */     //   791: goto -> 744
/*     */     //   794: aload_1
/*     */     //   795: aload_2
/*     */     //   796: aload #20
/*     */     //   798: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   801: return
/*     */     //   802: aload #18
/*     */     //   804: invokeinterface values : ()Ljava/util/List;
/*     */     //   809: invokeinterface size : ()I
/*     */     //   814: newarray short
/*     */     //   816: astore #20
/*     */     //   818: iconst_0
/*     */     //   819: istore #21
/*     */     //   821: iload #21
/*     */     //   823: aload #18
/*     */     //   825: invokeinterface values : ()Ljava/util/List;
/*     */     //   830: invokeinterface size : ()I
/*     */     //   835: if_icmpge -> 871
/*     */     //   838: aload #20
/*     */     //   840: iload #21
/*     */     //   842: aload #18
/*     */     //   844: invokeinterface values : ()Ljava/util/List;
/*     */     //   849: iload #21
/*     */     //   851: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   856: checkcast java/lang/classfile/AnnotationValue$OfShort
/*     */     //   859: invokeinterface shortValue : ()S
/*     */     //   864: sastore
/*     */     //   865: iinc #21, 1
/*     */     //   868: goto -> 821
/*     */     //   871: aload_1
/*     */     //   872: aload_2
/*     */     //   873: aload #20
/*     */     //   875: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   878: return
/*     */     //   879: aload #18
/*     */     //   881: invokeinterface values : ()Ljava/util/List;
/*     */     //   886: invokeinterface size : ()I
/*     */     //   891: newarray char
/*     */     //   893: astore #20
/*     */     //   895: iconst_0
/*     */     //   896: istore #21
/*     */     //   898: iload #21
/*     */     //   900: aload #18
/*     */     //   902: invokeinterface values : ()Ljava/util/List;
/*     */     //   907: invokeinterface size : ()I
/*     */     //   912: if_icmpge -> 948
/*     */     //   915: aload #20
/*     */     //   917: iload #21
/*     */     //   919: aload #18
/*     */     //   921: invokeinterface values : ()Ljava/util/List;
/*     */     //   926: iload #21
/*     */     //   928: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   933: checkcast java/lang/classfile/AnnotationValue$OfChar
/*     */     //   936: invokeinterface charValue : ()C
/*     */     //   941: castore
/*     */     //   942: iinc #21, 1
/*     */     //   945: goto -> 898
/*     */     //   948: aload_1
/*     */     //   949: aload_2
/*     */     //   950: aload #20
/*     */     //   952: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   955: return
/*     */     //   956: aload #18
/*     */     //   958: invokeinterface values : ()Ljava/util/List;
/*     */     //   963: invokeinterface size : ()I
/*     */     //   968: newarray int
/*     */     //   970: astore #20
/*     */     //   972: iconst_0
/*     */     //   973: istore #21
/*     */     //   975: iload #21
/*     */     //   977: aload #18
/*     */     //   979: invokeinterface values : ()Ljava/util/List;
/*     */     //   984: invokeinterface size : ()I
/*     */     //   989: if_icmpge -> 1025
/*     */     //   992: aload #20
/*     */     //   994: iload #21
/*     */     //   996: aload #18
/*     */     //   998: invokeinterface values : ()Ljava/util/List;
/*     */     //   1003: iload #21
/*     */     //   1005: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   1010: checkcast java/lang/classfile/AnnotationValue$OfInt
/*     */     //   1013: invokeinterface intValue : ()I
/*     */     //   1018: iastore
/*     */     //   1019: iinc #21, 1
/*     */     //   1022: goto -> 975
/*     */     //   1025: aload_1
/*     */     //   1026: aload_2
/*     */     //   1027: aload #20
/*     */     //   1029: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   1032: return
/*     */     //   1033: aload #18
/*     */     //   1035: invokeinterface values : ()Ljava/util/List;
/*     */     //   1040: invokeinterface size : ()I
/*     */     //   1045: newarray long
/*     */     //   1047: astore #20
/*     */     //   1049: iconst_0
/*     */     //   1050: istore #21
/*     */     //   1052: iload #21
/*     */     //   1054: aload #18
/*     */     //   1056: invokeinterface values : ()Ljava/util/List;
/*     */     //   1061: invokeinterface size : ()I
/*     */     //   1066: if_icmpge -> 1102
/*     */     //   1069: aload #20
/*     */     //   1071: iload #21
/*     */     //   1073: aload #18
/*     */     //   1075: invokeinterface values : ()Ljava/util/List;
/*     */     //   1080: iload #21
/*     */     //   1082: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   1087: checkcast java/lang/classfile/AnnotationValue$OfLong
/*     */     //   1090: invokeinterface longValue : ()J
/*     */     //   1095: lastore
/*     */     //   1096: iinc #21, 1
/*     */     //   1099: goto -> 1052
/*     */     //   1102: aload_1
/*     */     //   1103: aload_2
/*     */     //   1104: aload #20
/*     */     //   1106: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   1109: return
/*     */     //   1110: aload #18
/*     */     //   1112: invokeinterface values : ()Ljava/util/List;
/*     */     //   1117: invokeinterface size : ()I
/*     */     //   1122: newarray float
/*     */     //   1124: astore #20
/*     */     //   1126: iconst_0
/*     */     //   1127: istore #21
/*     */     //   1129: iload #21
/*     */     //   1131: aload #18
/*     */     //   1133: invokeinterface values : ()Ljava/util/List;
/*     */     //   1138: invokeinterface size : ()I
/*     */     //   1143: if_icmpge -> 1179
/*     */     //   1146: aload #20
/*     */     //   1148: iload #21
/*     */     //   1150: aload #18
/*     */     //   1152: invokeinterface values : ()Ljava/util/List;
/*     */     //   1157: iload #21
/*     */     //   1159: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   1164: checkcast java/lang/classfile/AnnotationValue$OfFloat
/*     */     //   1167: invokeinterface floatValue : ()F
/*     */     //   1172: fastore
/*     */     //   1173: iinc #21, 1
/*     */     //   1176: goto -> 1129
/*     */     //   1179: aload_1
/*     */     //   1180: aload_2
/*     */     //   1181: aload #20
/*     */     //   1183: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   1186: return
/*     */     //   1187: aload #18
/*     */     //   1189: invokeinterface values : ()Ljava/util/List;
/*     */     //   1194: invokeinterface size : ()I
/*     */     //   1199: newarray double
/*     */     //   1201: astore #20
/*     */     //   1203: iconst_0
/*     */     //   1204: istore #21
/*     */     //   1206: iload #21
/*     */     //   1208: aload #18
/*     */     //   1210: invokeinterface values : ()Ljava/util/List;
/*     */     //   1215: invokeinterface size : ()I
/*     */     //   1220: if_icmpge -> 1256
/*     */     //   1223: aload #20
/*     */     //   1225: iload #21
/*     */     //   1227: aload #18
/*     */     //   1229: invokeinterface values : ()Ljava/util/List;
/*     */     //   1234: iload #21
/*     */     //   1236: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   1241: checkcast java/lang/classfile/AnnotationValue$OfDouble
/*     */     //   1244: invokeinterface doubleValue : ()D
/*     */     //   1249: dastore
/*     */     //   1250: iinc #21, 1
/*     */     //   1253: goto -> 1206
/*     */     //   1256: aload_1
/*     */     //   1257: aload_2
/*     */     //   1258: aload #20
/*     */     //   1260: invokevirtual visit : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   1263: return
/*     */     //   1264: aload_1
/*     */     //   1265: aload_2
/*     */     //   1266: invokevirtual visitArray : (Ljava/lang/String;)Lnet/bytebuddy/jar/asm/AnnotationVisitor;
/*     */     //   1269: astore #20
/*     */     //   1271: aload #20
/*     */     //   1273: ifnull -> 1301
/*     */     //   1276: aload #18
/*     */     //   1278: invokeinterface values : ()Ljava/util/List;
/*     */     //   1283: aload_0
/*     */     //   1284: aload #20
/*     */     //   1286: <illegal opcode> accept : (Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader;Lnet/bytebuddy/jar/asm/AnnotationVisitor;)Ljava/util/function/Consumer;
/*     */     //   1291: invokeinterface forEach : (Ljava/util/function/Consumer;)V
/*     */     //   1296: aload #20
/*     */     //   1298: invokevirtual visitEnd : ()V
/*     */     //   1301: goto -> 1321
/*     */     //   1304: new java/lang/UnsupportedOperationException
/*     */     //   1307: dup
/*     */     //   1308: aload_3
/*     */     //   1309: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   1312: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1317: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   1320: athrow
/*     */     //   1321: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #599	-> 0
/*     */     //   #600	-> 25
/*     */     //   #601	-> 32
/*     */     //   #603	-> 33
/*     */     //   #604	-> 120
/*     */     //   #605	-> 145
/*     */     //   #606	-> 170
/*     */     //   #607	-> 195
/*     */     //   #608	-> 220
/*     */     //   #609	-> 245
/*     */     //   #610	-> 270
/*     */     //   #611	-> 295
/*     */     //   #612	-> 320
/*     */     //   #613	-> 345
/*     */     //   #614	-> 375
/*     */     //   #615	-> 423
/*     */     //   #616	-> 462
/*     */     //   #617	-> 469
/*     */     //   #618	-> 504
/*     */     //   #619	-> 515
/*     */     //   #621	-> 648
/*     */     //   #622	-> 664
/*     */     //   #623	-> 684
/*     */     //   #622	-> 711
/*     */     //   #625	-> 717
/*     */     //   #626	-> 724
/*     */     //   #629	-> 725
/*     */     //   #630	-> 741
/*     */     //   #631	-> 761
/*     */     //   #630	-> 788
/*     */     //   #633	-> 794
/*     */     //   #634	-> 801
/*     */     //   #637	-> 802
/*     */     //   #638	-> 818
/*     */     //   #639	-> 838
/*     */     //   #638	-> 865
/*     */     //   #641	-> 871
/*     */     //   #642	-> 878
/*     */     //   #645	-> 879
/*     */     //   #646	-> 895
/*     */     //   #647	-> 915
/*     */     //   #646	-> 942
/*     */     //   #649	-> 948
/*     */     //   #650	-> 955
/*     */     //   #653	-> 956
/*     */     //   #654	-> 972
/*     */     //   #655	-> 992
/*     */     //   #654	-> 1019
/*     */     //   #657	-> 1025
/*     */     //   #658	-> 1032
/*     */     //   #661	-> 1033
/*     */     //   #662	-> 1049
/*     */     //   #663	-> 1069
/*     */     //   #662	-> 1096
/*     */     //   #665	-> 1102
/*     */     //   #666	-> 1109
/*     */     //   #669	-> 1110
/*     */     //   #670	-> 1126
/*     */     //   #671	-> 1146
/*     */     //   #670	-> 1173
/*     */     //   #673	-> 1179
/*     */     //   #674	-> 1186
/*     */     //   #677	-> 1187
/*     */     //   #678	-> 1203
/*     */     //   #679	-> 1223
/*     */     //   #678	-> 1250
/*     */     //   #681	-> 1256
/*     */     //   #682	-> 1263
/*     */     //   #686	-> 1264
/*     */     //   #687	-> 1271
/*     */     //   #688	-> 1276
/*     */     //   #689	-> 1296
/*     */     //   #691	-> 1301
/*     */     //   #692	-> 1304
/*     */     //   #694	-> 1321
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   13	20	4	writingAnnotationVisitor	Lnet/bytebuddy/jar/asmjdkbridge/JdkClassWriter$WritingAnnotationVisitor;
/*     */     //   127	18	6	value	Ljava/lang/classfile/AnnotationValue$OfBoolean;
/*     */     //   152	18	7	value	Ljava/lang/classfile/AnnotationValue$OfByte;
/*     */     //   177	18	8	value	Ljava/lang/classfile/AnnotationValue$OfShort;
/*     */     //   202	18	9	value	Ljava/lang/classfile/AnnotationValue$OfChar;
/*     */     //   227	18	10	value	Ljava/lang/classfile/AnnotationValue$OfInt;
/*     */     //   252	18	11	value	Ljava/lang/classfile/AnnotationValue$OfLong;
/*     */     //   277	18	12	value	Ljava/lang/classfile/AnnotationValue$OfFloat;
/*     */     //   302	18	13	value	Ljava/lang/classfile/AnnotationValue$OfDouble;
/*     */     //   327	18	14	value	Ljava/lang/classfile/AnnotationValue$OfString;
/*     */     //   352	23	15	value	Ljava/lang/classfile/AnnotationValue$OfClass;
/*     */     //   382	41	16	value	Ljava/lang/classfile/AnnotationValue$OfAnnotation;
/*     */     //   430	32	17	value	Ljava/lang/classfile/AnnotationValue$OfEnum;
/*     */     //   667	50	21	index	I
/*     */     //   664	61	20	array	[Z
/*     */     //   744	50	21	index	I
/*     */     //   741	61	20	array	[B
/*     */     //   821	50	21	index	I
/*     */     //   818	61	20	array	[S
/*     */     //   898	50	21	index	I
/*     */     //   895	61	20	array	[C
/*     */     //   975	50	21	index	I
/*     */     //   972	61	20	array	[I
/*     */     //   1052	50	21	index	I
/*     */     //   1049	61	20	array	[J
/*     */     //   1129	50	21	index	I
/*     */     //   1126	61	20	array	[F
/*     */     //   1206	50	21	index	I
/*     */     //   1203	61	20	array	[D
/*     */     //   504	797	19	tags	Ljava/util/Set;
/*     */     //   1271	30	20	nested	Lnet/bytebuddy/jar/asm/AnnotationVisitor;
/*     */     //   469	835	18	value	Ljava/lang/classfile/AnnotationValue$OfArray;
/*     */     //   0	1322	0	this	Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader;
/*     */     //   0	1322	1	annotationVisitor	Lnet/bytebuddy/jar/asm/AnnotationVisitor;
/*     */     //   0	1322	2	name	Ljava/lang/String;
/*     */     //   0	1322	3	annotationValue	Ljava/lang/classfile/AnnotationValue;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   504	797	19	tags	Ljava/util/Set<Ljava/lang/Integer;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendCodeAnnotations(List<TypeAnnotation> typeAnnotations, boolean visible, MethodVisitor methodVisitor, Map<Label, Label> labels, List<Map.Entry<TypeAnnotation, Boolean>> localVariableAnnotations, Map<Label, List<Map.Entry<TypeAnnotation, Boolean>>> offsetTypeAnnotations) {
/* 702 */     typeAnnotations.forEach(typeAnnotation -> {
/*     */           // Byte code:
/*     */           //   0: aload #6
/*     */           //   2: invokeinterface targetInfo : ()Ljava/lang/classfile/TypeAnnotation$TargetInfo;
/*     */           //   7: dup
/*     */           //   8: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */           //   11: pop
/*     */           //   12: astore #7
/*     */           //   14: iconst_0
/*     */           //   15: istore #8
/*     */           //   17: aload #7
/*     */           //   19: iload #8
/*     */           //   21: <illegal opcode> typeSwitch : (Ljava/lang/classfile/TypeAnnotation$TargetInfo;I)I
/*     */           //   26: tableswitch default -> 209, 0 -> 52, 1 -> 78, 2 -> 134
/*     */           //   52: aload #7
/*     */           //   54: checkcast java/lang/classfile/TypeAnnotation$LocalVarTarget
/*     */           //   57: astore #9
/*     */           //   59: aload_1
/*     */           //   60: aload #6
/*     */           //   62: iload_2
/*     */           //   63: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */           //   66: invokestatic entry : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;
/*     */           //   69: invokeinterface add : (Ljava/lang/Object;)Z
/*     */           //   74: pop
/*     */           //   75: goto -> 232
/*     */           //   78: aload #7
/*     */           //   80: checkcast java/lang/classfile/TypeAnnotation$OffsetTarget
/*     */           //   83: astore #10
/*     */           //   85: aload_3
/*     */           //   86: aload #4
/*     */           //   88: aload #10
/*     */           //   90: invokeinterface target : ()Ljava/lang/classfile/Label;
/*     */           //   95: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */           //   100: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */           //   105: checkcast net/bytebuddy/jar/asm/Label
/*     */           //   108: aload #6
/*     */           //   110: iload_2
/*     */           //   111: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */           //   114: invokestatic entry : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;
/*     */           //   117: invokestatic singletonList : (Ljava/lang/Object;)Ljava/util/List;
/*     */           //   120: <illegal opcode> apply : ()Ljava/util/function/BiFunction;
/*     */           //   125: invokeinterface merge : (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;
/*     */           //   130: pop
/*     */           //   131: goto -> 232
/*     */           //   134: aload #7
/*     */           //   136: checkcast java/lang/classfile/TypeAnnotation$CatchTarget
/*     */           //   139: astore #11
/*     */           //   141: aload_0
/*     */           //   142: aload #5
/*     */           //   144: aload #11
/*     */           //   146: invokeinterface targetType : ()Ljava/lang/classfile/TypeAnnotation$TargetType;
/*     */           //   151: invokevirtual targetTypeValue : ()I
/*     */           //   154: invokestatic newTypeReference : (I)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */           //   157: invokevirtual getValue : ()I
/*     */           //   160: aload #6
/*     */           //   162: invokeinterface targetPath : ()Ljava/util/List;
/*     */           //   167: invokestatic toTypePath : (Ljava/util/List;)Lnet/bytebuddy/jar/asm/TypePath;
/*     */           //   170: aload #6
/*     */           //   172: invokeinterface annotation : ()Ljava/lang/classfile/Annotation;
/*     */           //   177: invokeinterface className : ()Ljava/lang/classfile/constantpool/Utf8Entry;
/*     */           //   182: invokeinterface stringValue : ()Ljava/lang/String;
/*     */           //   187: iload_2
/*     */           //   188: invokevirtual visitTryCatchAnnotation : (ILnet/bytebuddy/jar/asm/TypePath;Ljava/lang/String;Z)Lnet/bytebuddy/jar/asm/AnnotationVisitor;
/*     */           //   191: aload #6
/*     */           //   193: invokeinterface annotation : ()Ljava/lang/classfile/Annotation;
/*     */           //   198: invokeinterface elements : ()Ljava/util/List;
/*     */           //   203: invokevirtual appendAnnotationValues : (Lnet/bytebuddy/jar/asm/AnnotationVisitor;Ljava/util/List;)V
/*     */           //   206: goto -> 232
/*     */           //   209: new java/lang/UnsupportedOperationException
/*     */           //   212: dup
/*     */           //   213: aload #6
/*     */           //   215: invokeinterface targetInfo : ()Ljava/lang/classfile/TypeAnnotation$TargetInfo;
/*     */           //   220: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */           //   223: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */           //   228: invokespecial <init> : (Ljava/lang/String;)V
/*     */           //   231: athrow
/*     */           //   232: return
/*     */           // Line number table:
/*     */           //   Java source line number -> byte code offset
/*     */           //   #703	-> 0
/*     */           //   #704	-> 52
/*     */           //   #705	-> 78
/*     */           //   #706	-> 111
/*     */           //   #705	-> 125
/*     */           //   #708	-> 134
/*     */           //   #709	-> 146
/*     */           //   #710	-> 162
/*     */           //   #711	-> 172
/*     */           //   #708	-> 188
/*     */           //   #712	-> 193
/*     */           //   #708	-> 203
/*     */           //   #713	-> 209
/*     */           //   #715	-> 232
/*     */           // Local variable table:
/*     */           //   start	length	slot	name	descriptor
/*     */           //   59	19	9	ignored	Ljava/lang/classfile/TypeAnnotation$LocalVarTarget;
/*     */           //   85	49	10	value	Ljava/lang/classfile/TypeAnnotation$OffsetTarget;
/*     */           //   141	68	11	value	Ljava/lang/classfile/TypeAnnotation$CatchTarget;
/*     */           //   14	218	7	selector0$temp	Ljava/lang/classfile/TypeAnnotation$TargetInfo;
/*     */           //   17	215	8	index$1	I
/*     */           //   0	233	0	this	Lnet/bytebuddy/jar/asmjdkbridge/JdkClassReader;
/*     */           //   0	233	1	localVariableAnnotations	Ljava/util/List;
/*     */           //   0	233	2	visible	Z
/*     */           //   0	233	3	offsetTypeAnnotations	Ljava/util/Map;
/*     */           //   0	233	4	labels	Ljava/util/Map;
/*     */           //   0	233	5	methodVisitor	Lnet/bytebuddy/jar/asm/MethodVisitor;
/*     */           //   0	233	6	typeAnnotation	Ljava/lang/classfile/TypeAnnotation;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object toAsmConstant(ConstantDesc constant) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   5: pop
/*     */     //   6: astore_1
/*     */     //   7: iconst_0
/*     */     //   8: istore_2
/*     */     //   9: aload_1
/*     */     //   10: iload_2
/*     */     //   11: <illegal opcode> typeSwitch : (Ljava/lang/constant/ConstantDesc;I)I
/*     */     //   16: tableswitch default -> 72, 0 -> 82, 1 -> 91, 2 -> 102, 3 -> 113, 4 -> 124, 5 -> 135, 6 -> 154, 7 -> 173, 8 -> 227, 9 -> 251
/*     */     //   72: new java/lang/MatchException
/*     */     //   75: dup
/*     */     //   76: aconst_null
/*     */     //   77: aconst_null
/*     */     //   78: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   81: athrow
/*     */     //   82: aload_1
/*     */     //   83: checkcast java/lang/String
/*     */     //   86: astore_3
/*     */     //   87: aload_3
/*     */     //   88: goto -> 315
/*     */     //   91: aload_1
/*     */     //   92: checkcast java/lang/Integer
/*     */     //   95: astore #4
/*     */     //   97: aload #4
/*     */     //   99: goto -> 315
/*     */     //   102: aload_1
/*     */     //   103: checkcast java/lang/Long
/*     */     //   106: astore #5
/*     */     //   108: aload #5
/*     */     //   110: goto -> 315
/*     */     //   113: aload_1
/*     */     //   114: checkcast java/lang/Float
/*     */     //   117: astore #6
/*     */     //   119: aload #6
/*     */     //   121: goto -> 315
/*     */     //   124: aload_1
/*     */     //   125: checkcast java/lang/Double
/*     */     //   128: astore #7
/*     */     //   130: aload #7
/*     */     //   132: goto -> 315
/*     */     //   135: aload_1
/*     */     //   136: checkcast java/lang/constant/ClassDesc
/*     */     //   139: astore #8
/*     */     //   141: aload #8
/*     */     //   143: invokeinterface descriptorString : ()Ljava/lang/String;
/*     */     //   148: invokestatic getType : (Ljava/lang/String;)Lnet/bytebuddy/jar/asm/Type;
/*     */     //   151: goto -> 315
/*     */     //   154: aload_1
/*     */     //   155: checkcast java/lang/constant/MethodTypeDesc
/*     */     //   158: astore #9
/*     */     //   160: aload #9
/*     */     //   162: invokeinterface descriptorString : ()Ljava/lang/String;
/*     */     //   167: invokestatic getMethodType : (Ljava/lang/String;)Lnet/bytebuddy/jar/asm/Type;
/*     */     //   170: goto -> 315
/*     */     //   173: aload_1
/*     */     //   174: checkcast java/lang/constant/DirectMethodHandleDesc
/*     */     //   177: astore #10
/*     */     //   179: new net/bytebuddy/jar/asm/Handle
/*     */     //   182: dup
/*     */     //   183: aload #10
/*     */     //   185: invokeinterface refKind : ()I
/*     */     //   190: aload #10
/*     */     //   192: invokeinterface owner : ()Ljava/lang/constant/ClassDesc;
/*     */     //   197: invokestatic toInternalName : (Ljava/lang/constant/ClassDesc;)Ljava/lang/String;
/*     */     //   200: aload #10
/*     */     //   202: invokeinterface methodName : ()Ljava/lang/String;
/*     */     //   207: aload #10
/*     */     //   209: invokeinterface lookupDescriptor : ()Ljava/lang/String;
/*     */     //   214: aload #10
/*     */     //   216: invokeinterface isOwnerInterface : ()Z
/*     */     //   221: invokespecial <init> : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
/*     */     //   224: goto -> 315
/*     */     //   227: aload_1
/*     */     //   228: checkcast java/lang/constant/MethodHandleDesc
/*     */     //   231: astore #11
/*     */     //   233: new java/lang/UnsupportedOperationException
/*     */     //   236: dup
/*     */     //   237: aload #11
/*     */     //   239: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   242: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   247: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   250: athrow
/*     */     //   251: aload_1
/*     */     //   252: checkcast java/lang/constant/DynamicConstantDesc
/*     */     //   255: astore #12
/*     */     //   257: new net/bytebuddy/jar/asm/ConstantDynamic
/*     */     //   260: dup
/*     */     //   261: aload #12
/*     */     //   263: invokevirtual constantName : ()Ljava/lang/String;
/*     */     //   266: aload #12
/*     */     //   268: invokevirtual constantType : ()Ljava/lang/constant/ClassDesc;
/*     */     //   271: invokeinterface descriptorString : ()Ljava/lang/String;
/*     */     //   276: aload #12
/*     */     //   278: invokevirtual bootstrapMethod : ()Ljava/lang/constant/DirectMethodHandleDesc;
/*     */     //   281: invokestatic toAsmConstant : (Ljava/lang/constant/ConstantDesc;)Ljava/lang/Object;
/*     */     //   284: checkcast net/bytebuddy/jar/asm/Handle
/*     */     //   287: aload #12
/*     */     //   289: invokevirtual bootstrapArgsList : ()Ljava/util/List;
/*     */     //   292: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */     //   297: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   302: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */     //   307: invokeinterface toArray : ()[Ljava/lang/Object;
/*     */     //   312: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lnet/bytebuddy/jar/asm/Handle;[Ljava/lang/Object;)V
/*     */     //   315: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #719	-> 0
/*     */     //   #720	-> 82
/*     */     //   #721	-> 91
/*     */     //   #722	-> 102
/*     */     //   #723	-> 113
/*     */     //   #724	-> 124
/*     */     //   #725	-> 135
/*     */     //   #726	-> 154
/*     */     //   #727	-> 173
/*     */     //   #728	-> 192
/*     */     //   #729	-> 202
/*     */     //   #730	-> 209
/*     */     //   #731	-> 216
/*     */     //   #732	-> 227
/*     */     //   #733	-> 251
/*     */     //   #734	-> 268
/*     */     //   #735	-> 278
/*     */     //   #736	-> 289
/*     */     //   #719	-> 315
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   87	4	3	value	Ljava/lang/String;
/*     */     //   97	5	4	value	Ljava/lang/Integer;
/*     */     //   108	5	5	value	Ljava/lang/Long;
/*     */     //   119	5	6	value	Ljava/lang/Float;
/*     */     //   130	5	7	value	Ljava/lang/Double;
/*     */     //   141	13	8	value	Ljava/lang/constant/ClassDesc;
/*     */     //   160	13	9	value	Ljava/lang/constant/MethodTypeDesc;
/*     */     //   179	48	10	value	Ljava/lang/constant/DirectMethodHandleDesc;
/*     */     //   233	18	11	value	Ljava/lang/constant/MethodHandleDesc;
/*     */     //   257	58	12	value	Ljava/lang/constant/DynamicConstantDesc;
/*     */     //   0	316	0	constant	Ljava/lang/constant/ConstantDesc;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   257	58	12	value	Ljava/lang/constant/DynamicConstantDesc<*>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toInternalName(ClassDesc constant) {
/* 741 */     if (!constant.isClassOrInterface()) {
/* 742 */       throw new IllegalArgumentException("Not a class or interface: " + String.valueOf(constant));
/*     */     }
/* 744 */     String descriptor = constant.descriptorString();
/* 745 */     return descriptor.substring(1, descriptor.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TypeReference toTypeReference(TypeAnnotation.TargetInfo targetInfo) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   5: pop
/*     */     //   6: astore_1
/*     */     //   7: iconst_0
/*     */     //   8: istore_2
/*     */     //   9: aload_1
/*     */     //   10: iload_2
/*     */     //   11: <illegal opcode> typeSwitch : (Ljava/lang/classfile/TypeAnnotation$TargetInfo;I)I
/*     */     //   16: tableswitch default -> 214, 0 -> 56, 1 -> 89, 2 -> 118, 3 -> 154, 4 -> 173, 5 -> 192
/*     */     //   56: aload_1
/*     */     //   57: checkcast java/lang/classfile/TypeAnnotation$SupertypeTarget
/*     */     //   60: astore_3
/*     */     //   61: aload_3
/*     */     //   62: invokeinterface supertypeIndex : ()I
/*     */     //   67: ldc_w 65535
/*     */     //   70: if_icmpne -> 77
/*     */     //   73: iconst_m1
/*     */     //   74: goto -> 83
/*     */     //   77: aload_3
/*     */     //   78: invokeinterface supertypeIndex : ()I
/*     */     //   83: invokestatic newSuperTypeReference : (I)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */     //   86: goto -> 231
/*     */     //   89: aload_1
/*     */     //   90: checkcast java/lang/classfile/TypeAnnotation$TypeParameterTarget
/*     */     //   93: astore #4
/*     */     //   95: aload #4
/*     */     //   97: invokeinterface targetType : ()Ljava/lang/classfile/TypeAnnotation$TargetType;
/*     */     //   102: invokevirtual targetTypeValue : ()I
/*     */     //   105: aload #4
/*     */     //   107: invokeinterface typeParameterIndex : ()I
/*     */     //   112: invokestatic newTypeParameterReference : (II)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */     //   115: goto -> 231
/*     */     //   118: aload_1
/*     */     //   119: checkcast java/lang/classfile/TypeAnnotation$TypeParameterBoundTarget
/*     */     //   122: astore #5
/*     */     //   124: aload #5
/*     */     //   126: invokeinterface targetType : ()Ljava/lang/classfile/TypeAnnotation$TargetType;
/*     */     //   131: invokevirtual targetTypeValue : ()I
/*     */     //   134: aload #5
/*     */     //   136: invokeinterface typeParameterIndex : ()I
/*     */     //   141: aload #5
/*     */     //   143: invokeinterface boundIndex : ()I
/*     */     //   148: invokestatic newTypeParameterBoundReference : (III)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */     //   151: goto -> 231
/*     */     //   154: aload_1
/*     */     //   155: checkcast java/lang/classfile/TypeAnnotation$ThrowsTarget
/*     */     //   158: astore #6
/*     */     //   160: aload #6
/*     */     //   162: invokeinterface throwsTargetIndex : ()I
/*     */     //   167: invokestatic newExceptionReference : (I)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */     //   170: goto -> 231
/*     */     //   173: aload_1
/*     */     //   174: checkcast java/lang/classfile/TypeAnnotation$FormalParameterTarget
/*     */     //   177: astore #7
/*     */     //   179: aload #7
/*     */     //   181: invokeinterface formalParameterIndex : ()I
/*     */     //   186: invokestatic newFormalParameterReference : (I)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */     //   189: goto -> 231
/*     */     //   192: aload_1
/*     */     //   193: checkcast java/lang/classfile/TypeAnnotation$EmptyTarget
/*     */     //   196: astore #8
/*     */     //   198: aload #8
/*     */     //   200: invokeinterface targetType : ()Ljava/lang/classfile/TypeAnnotation$TargetType;
/*     */     //   205: invokevirtual targetTypeValue : ()I
/*     */     //   208: invokestatic newTypeReference : (I)Lnet/bytebuddy/jar/asm/TypeReference;
/*     */     //   211: goto -> 231
/*     */     //   214: new java/lang/UnsupportedOperationException
/*     */     //   217: dup
/*     */     //   218: aload_0
/*     */     //   219: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   222: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   227: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   230: athrow
/*     */     //   231: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #749	-> 0
/*     */     //   #750	-> 56
/*     */     //   #751	-> 89
/*     */     //   #752	-> 118
/*     */     //   #753	-> 154
/*     */     //   #754	-> 173
/*     */     //   #755	-> 192
/*     */     //   #756	-> 214
/*     */     //   #749	-> 231
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   61	28	3	value	Ljava/lang/classfile/TypeAnnotation$SupertypeTarget;
/*     */     //   95	23	4	value	Ljava/lang/classfile/TypeAnnotation$TypeParameterTarget;
/*     */     //   124	30	5	value	Ljava/lang/classfile/TypeAnnotation$TypeParameterBoundTarget;
/*     */     //   160	13	6	value	Ljava/lang/classfile/TypeAnnotation$ThrowsTarget;
/*     */     //   179	13	7	value	Ljava/lang/classfile/TypeAnnotation$FormalParameterTarget;
/*     */     //   198	16	8	value	Ljava/lang/classfile/TypeAnnotation$EmptyTarget;
/*     */     //   0	232	0	targetInfo	Ljava/lang/classfile/TypeAnnotation$TargetInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TypePath toTypePath(List<TypeAnnotation.TypePathComponent> components) {
/* 761 */     if (components.isEmpty()) {
/* 762 */       return null;
/*     */     }
/* 764 */     return TypePath.fromString(components.stream().map(component -> { switch (null.$SwitchMap$java$lang$classfile$TypeAnnotation$TypePathComponent$Kind[component.typePathKind().ordinal()]) { default: throw new MatchException(null, null);
/*     */               case 1: 
/*     */               case 2: 
/*     */               case 3: 
/*     */               case 4:
/* 769 */                 break; }  return "" + component.typeArgumentIndex() + ";"; }).collect(Collectors.joining()));
/*     */   }
/*     */   
/*     */   private static Object toAsmFrameValue(StackMapFrameInfo.VerificationTypeInfo verificationTypeInfo, Map<Label, Label> labels) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   5: pop
/*     */     //   6: astore_2
/*     */     //   7: iconst_0
/*     */     //   8: istore_3
/*     */     //   9: aload_2
/*     */     //   10: iload_3
/*     */     //   11: <illegal opcode> typeSwitch : (Ljava/lang/classfile/attribute/StackMapFrameInfo$VerificationTypeInfo;I)I
/*     */     //   16: tableswitch default -> 44, 0 -> 54, 1 -> 71, 2 -> 92
/*     */     //   44: new java/lang/MatchException
/*     */     //   47: dup
/*     */     //   48: aconst_null
/*     */     //   49: aconst_null
/*     */     //   50: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   53: athrow
/*     */     //   54: aload_2
/*     */     //   55: checkcast java/lang/classfile/attribute/StackMapFrameInfo$SimpleVerificationTypeInfo
/*     */     //   58: astore #4
/*     */     //   60: aload #4
/*     */     //   62: invokevirtual tag : ()I
/*     */     //   65: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   68: goto -> 119
/*     */     //   71: aload_2
/*     */     //   72: checkcast java/lang/classfile/attribute/StackMapFrameInfo$ObjectVerificationTypeInfo
/*     */     //   75: astore #5
/*     */     //   77: aload #5
/*     */     //   79: invokeinterface className : ()Ljava/lang/classfile/constantpool/ClassEntry;
/*     */     //   84: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */     //   89: goto -> 119
/*     */     //   92: aload_2
/*     */     //   93: checkcast java/lang/classfile/attribute/StackMapFrameInfo$UninitializedVerificationTypeInfo
/*     */     //   96: astore #6
/*     */     //   98: aload_1
/*     */     //   99: aload #6
/*     */     //   101: invokeinterface newTarget : ()Ljava/lang/classfile/Label;
/*     */     //   106: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   111: invokeinterface computeIfAbsent : (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;
/*     */     //   116: checkcast net/bytebuddy/jar/asm/Label
/*     */     //   119: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #773	-> 0
/*     */     //   #774	-> 54
/*     */     //   #775	-> 71
/*     */     //   #776	-> 92
/*     */     //   #773	-> 119
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   60	11	4	value	Ljava/lang/classfile/attribute/StackMapFrameInfo$SimpleVerificationTypeInfo;
/*     */     //   77	15	5	value	Ljava/lang/classfile/attribute/StackMapFrameInfo$ObjectVerificationTypeInfo;
/*     */     //   98	21	6	value	Ljava/lang/classfile/attribute/StackMapFrameInfo$UninitializedVerificationTypeInfo;
/*     */     //   0	120	0	verificationTypeInfo	Ljava/lang/classfile/attribute/StackMapFrameInfo$VerificationTypeInfo;
/*     */     //   0	120	1	labels	Ljava/util/Map;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	120	1	labels	Ljava/util/Map<Ljava/lang/classfile/Label;Lnet/bytebuddy/jar/asm/Label;>;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\JdkClassReader.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */