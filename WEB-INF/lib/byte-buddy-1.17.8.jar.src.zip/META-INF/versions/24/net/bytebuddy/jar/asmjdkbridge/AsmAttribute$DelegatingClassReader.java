/*     */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*     */ 
/*     */ import java.lang.classfile.ClassModel;
/*     */ import java.lang.classfile.ClassReader;
/*     */ import java.lang.classfile.constantpool.ClassEntry;
/*     */ import java.lang.classfile.constantpool.ModuleEntry;
/*     */ import java.lang.classfile.constantpool.PackageEntry;
/*     */ import java.lang.classfile.constantpool.Utf8Entry;
/*     */ import java.util.function.Supplier;
/*     */ import net.bytebuddy.jar.asm.Attribute;
/*     */ import net.bytebuddy.jar.asm.ClassReader;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asmjdkbridge.AsmAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DelegatingClassReader
/*     */   extends ClassReader
/*     */ {
/*     */   private final ClassReader delegate;
/*     */   private final Supplier<ClassModel> model;
/*     */   
/*     */   private DelegatingClassReader(byte[] bytes, ClassReader delegate, Supplier<ClassModel> model) {
/* 106 */     super(bytes);
/* 107 */     this.delegate = delegate;
/* 108 */     this.model = model;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAccess() {
/* 113 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 118 */     return this.delegate.thisClassEntry().asInternalName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSuperName() {
/* 123 */     return this.delegate.superclassEntry().map(ClassEntry::asInternalName).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getInterfaces() {
/* 128 */     return (String[])((ClassModel)this.model.get()).interfaces().stream().map(ClassEntry::asInternalName).toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor classVisitor, int parsingOptions) {
/* 133 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(ClassVisitor classVisitor, Attribute[] attributePrototypes, int parsingOptions) {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getItemCount() {
/* 143 */     return this.delegate.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getItem(int constantPoolEntryIndex) {
/* 148 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxStringLength() {
/* 153 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readByte(int offset) {
/* 158 */     return this.delegate.readU1(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readUnsignedShort(int offset) {
/* 163 */     if (this.delegate == null) {
/* 164 */       return 0;
/*     */     }
/* 166 */     return this.delegate.readU2(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public short readShort(int offset) {
/* 171 */     if (this.delegate == null) {
/* 172 */       return 0;
/*     */     }
/* 174 */     return (short)this.delegate.readS2(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt(int offset) {
/* 179 */     return this.delegate.readInt(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public long readLong(int offset) {
/* 184 */     return this.delegate.readLong(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String readUTF8(int offset, char[] charBuffer) {
/* 189 */     return ((Utf8Entry)this.delegate.readEntry(offset, Utf8Entry.class)).stringValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readClass(int offset, char[] charBuffer) {
/* 194 */     return ((ClassEntry)this.delegate.readEntry(offset, ClassEntry.class)).name().stringValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readModule(int offset, char[] charBuffer) {
/* 199 */     return ((ModuleEntry)this.delegate.readEntry(offset, ModuleEntry.class)).name().stringValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String readPackage(int offset, char[] charBuffer) {
/* 204 */     return ((PackageEntry)this.delegate.readEntry(offset, PackageEntry.class)).name().stringValue();
/*     */   }
/*     */   
/*     */   public Object readConst(int constantPoolEntryIndex, char[] charBuffer) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield delegate : Ljava/lang/classfile/ClassReader;
/*     */     //   4: iload_1
/*     */     //   5: invokeinterface entryByIndex : (I)Ljava/lang/classfile/constantpool/PoolEntry;
/*     */     //   10: dup
/*     */     //   11: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   14: pop
/*     */     //   15: astore_3
/*     */     //   16: iconst_0
/*     */     //   17: istore #4
/*     */     //   19: aload_3
/*     */     //   20: iload #4
/*     */     //   22: <illegal opcode> typeSwitch : (Ljava/lang/classfile/constantpool/PoolEntry;I)I
/*     */     //   27: tableswitch default -> 226, 0 -> 72, 1 -> 91, 2 -> 110, 3 -> 129, 4 -> 148, 5 -> 164, 6 -> 188, 7 -> 207
/*     */     //   72: aload_3
/*     */     //   73: checkcast java/lang/classfile/constantpool/IntegerEntry
/*     */     //   76: astore #5
/*     */     //   78: aload #5
/*     */     //   80: invokeinterface intValue : ()I
/*     */     //   85: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   88: goto -> 234
/*     */     //   91: aload_3
/*     */     //   92: checkcast java/lang/classfile/constantpool/LongEntry
/*     */     //   95: astore #6
/*     */     //   97: aload #6
/*     */     //   99: invokeinterface longValue : ()J
/*     */     //   104: invokestatic valueOf : (J)Ljava/lang/Long;
/*     */     //   107: goto -> 234
/*     */     //   110: aload_3
/*     */     //   111: checkcast java/lang/classfile/constantpool/FloatEntry
/*     */     //   114: astore #7
/*     */     //   116: aload #7
/*     */     //   118: invokeinterface floatValue : ()F
/*     */     //   123: invokestatic valueOf : (F)Ljava/lang/Float;
/*     */     //   126: goto -> 234
/*     */     //   129: aload_3
/*     */     //   130: checkcast java/lang/classfile/constantpool/DoubleEntry
/*     */     //   133: astore #8
/*     */     //   135: aload #8
/*     */     //   137: invokeinterface doubleValue : ()D
/*     */     //   142: invokestatic valueOf : (D)Ljava/lang/Double;
/*     */     //   145: goto -> 234
/*     */     //   148: aload_3
/*     */     //   149: checkcast java/lang/classfile/constantpool/StringEntry
/*     */     //   152: astore #9
/*     */     //   154: aload #9
/*     */     //   156: invokeinterface stringValue : ()Ljava/lang/String;
/*     */     //   161: goto -> 234
/*     */     //   164: aload_3
/*     */     //   165: checkcast java/lang/classfile/constantpool/ClassEntry
/*     */     //   168: astore #10
/*     */     //   170: aload #10
/*     */     //   172: invokeinterface asInternalName : ()Ljava/lang/String;
/*     */     //   177: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   182: invokestatic getType : (Ljava/lang/String;)Lnet/bytebuddy/jar/asm/Type;
/*     */     //   185: goto -> 234
/*     */     //   188: aload_3
/*     */     //   189: checkcast java/lang/classfile/constantpool/MethodHandleEntry
/*     */     //   192: astore #11
/*     */     //   194: aload #11
/*     */     //   196: invokeinterface asSymbol : ()Ljava/lang/constant/DirectMethodHandleDesc;
/*     */     //   201: invokestatic toAsmConstant : (Ljava/lang/constant/ConstantDesc;)Ljava/lang/Object;
/*     */     //   204: goto -> 234
/*     */     //   207: aload_3
/*     */     //   208: checkcast java/lang/classfile/constantpool/ConstantDynamicEntry
/*     */     //   211: astore #12
/*     */     //   213: aload #12
/*     */     //   215: invokeinterface asSymbol : ()Ljava/lang/constant/DynamicConstantDesc;
/*     */     //   220: invokestatic toAsmConstant : (Ljava/lang/constant/ConstantDesc;)Ljava/lang/Object;
/*     */     //   223: goto -> 234
/*     */     //   226: new java/lang/IllegalArgumentException
/*     */     //   229: dup
/*     */     //   230: invokespecial <init> : ()V
/*     */     //   233: athrow
/*     */     //   234: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #209	-> 0
/*     */     //   #210	-> 72
/*     */     //   #211	-> 91
/*     */     //   #212	-> 110
/*     */     //   #213	-> 129
/*     */     //   #214	-> 148
/*     */     //   #215	-> 164
/*     */     //   #216	-> 188
/*     */     //   #217	-> 207
/*     */     //   #218	-> 226
/*     */     //   #209	-> 234
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   78	13	5	entry	Ljava/lang/classfile/constantpool/IntegerEntry;
/*     */     //   97	13	6	entry	Ljava/lang/classfile/constantpool/LongEntry;
/*     */     //   116	13	7	entry	Ljava/lang/classfile/constantpool/FloatEntry;
/*     */     //   135	13	8	entry	Ljava/lang/classfile/constantpool/DoubleEntry;
/*     */     //   154	10	9	entry	Ljava/lang/classfile/constantpool/StringEntry;
/*     */     //   170	18	10	entry	Ljava/lang/classfile/constantpool/ClassEntry;
/*     */     //   194	13	11	entry	Ljava/lang/classfile/constantpool/MethodHandleEntry;
/*     */     //   213	13	12	entry	Ljava/lang/classfile/constantpool/ConstantDynamicEntry;
/*     */     //   0	235	0	this	Lnet/bytebuddy/jar/asmjdkbridge/AsmAttribute$DelegatingClassReader;
/*     */     //   0	235	1	constantPoolEntryIndex	I
/*     */     //   0	235	2	charBuffer	[C
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmAttribute$DelegatingClassReader.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */