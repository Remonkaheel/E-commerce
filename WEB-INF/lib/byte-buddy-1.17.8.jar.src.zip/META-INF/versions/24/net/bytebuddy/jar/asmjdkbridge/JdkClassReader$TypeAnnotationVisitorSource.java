package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;

import net.bytebuddy.jar.asm.AnnotationVisitor;
import net.bytebuddy.jar.asm.TypePath;

@FunctionalInterface
interface TypeAnnotationVisitorSource {
  AnnotationVisitor visitTypeAnnotation(int paramInt, TypePath paramTypePath, String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\JdkClassReader$TypeAnnotationVisitorSource.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */