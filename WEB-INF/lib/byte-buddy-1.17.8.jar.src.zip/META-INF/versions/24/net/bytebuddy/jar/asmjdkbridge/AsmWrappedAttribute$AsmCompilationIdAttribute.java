/*    */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*    */ 
/*    */ import java.lang.classfile.Attribute;
/*    */ import java.lang.classfile.attribute.CompilationIDAttribute;
/*    */ import net.bytebuddy.jar.asm.ByteVector;
/*    */ import net.bytebuddy.jar.asm.ClassWriter;
/*    */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AsmCompilationIdAttribute
/*    */   extends AsmWrappedAttribute<CompilationIDAttribute>
/*    */ {
/*    */   AsmCompilationIdAttribute(CompilationIDAttribute attribute) {
/* 52 */     super((Attribute)attribute);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ByteVector write(ClassWriter classWriter, byte[] code, int codeLength, int maxStack, int maxLocals) {
/* 57 */     int index = classWriter.newUTF8(((CompilationIDAttribute)this.attribute).compilationId().stringValue());
/* 58 */     ByteVector byteVector = new ByteVector(2);
/* 59 */     byteVector.putShort(index);
/* 60 */     return byteVector;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmWrappedAttribute$AsmCompilationIdAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */