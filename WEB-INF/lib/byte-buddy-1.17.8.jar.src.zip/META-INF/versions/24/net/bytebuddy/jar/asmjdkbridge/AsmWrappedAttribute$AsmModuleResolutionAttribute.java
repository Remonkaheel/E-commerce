/*    */ package META-INF.versions.24.net.bytebuddy.jar.asmjdkbridge;
/*    */ 
/*    */ import java.lang.classfile.Attribute;
/*    */ import java.lang.classfile.attribute.ModuleResolutionAttribute;
/*    */ import net.bytebuddy.jar.asm.ByteVector;
/*    */ import net.bytebuddy.jar.asm.ClassWriter;
/*    */ import net.bytebuddy.jar.asmjdkbridge.AsmWrappedAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AsmModuleResolutionAttribute
/*    */   extends AsmWrappedAttribute<ModuleResolutionAttribute>
/*    */ {
/*    */   AsmModuleResolutionAttribute(ModuleResolutionAttribute attribute) {
/* 87 */     super((Attribute)attribute);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ByteVector write(ClassWriter classWriter, byte[] code, int codeLength, int maxStack, int maxLocals) {
/* 92 */     ByteVector byteVector = new ByteVector(2);
/* 93 */     byteVector.putShort(((ModuleResolutionAttribute)this.attribute).resolutionFlags());
/* 94 */     return byteVector;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\META-INF\versions\24\net\bytebuddy\jar\asmjdkbridge\AsmWrappedAttribute$AsmModuleResolutionAttribute.class
 * Java compiler version: 24 (68.0)
 * JD-Core Version:       1.1.3
 */