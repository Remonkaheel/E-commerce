/*     */ package net.bytebuddy.implementation.attribute;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.method.ParameterList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MethodAttributeAppender
/*     */ {
/*     */   void apply(MethodVisitor paramMethodVisitor, MethodDescription paramMethodDescription, AnnotationValueFilter paramAnnotationValueFilter);
/*     */   
/*     */   public enum NoOp
/*     */     implements MethodAttributeAppender, Factory
/*     */   {
/*  56 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodAttributeAppender make(TypeDescription typeDescription) {
/*  62 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(MethodVisitor methodVisitor, MethodDescription methodDescription, AnnotationValueFilter annotationValueFilter) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Factory
/*     */   {
/*     */     MethodAttributeAppender make(TypeDescription param1TypeDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Compound
/*     */       implements Factory
/*     */     {
/*     */       public Compound(MethodAttributeAppender.Factory... factory) {
/* 104 */         this(Arrays.asList(factory));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       private final List<MethodAttributeAppender.Factory> factories = new ArrayList<MethodAttributeAppender.Factory>(); public Compound(List<? extends MethodAttributeAppender.Factory> factories) {
/* 114 */         for (MethodAttributeAppender.Factory factory : factories) {
/* 115 */           if (factory instanceof Compound) {
/* 116 */             this.factories.addAll(((Compound)factory).factories); continue;
/* 117 */           }  if (!(factory instanceof MethodAttributeAppender.NoOp)) {
/* 118 */             this.factories.add(factory);
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodAttributeAppender make(TypeDescription typeDescription) {
/* 127 */         List<MethodAttributeAppender> methodAttributeAppenders = new ArrayList<MethodAttributeAppender>(this.factories.size());
/* 128 */         for (MethodAttributeAppender.Factory factory : this.factories) {
/* 129 */           methodAttributeAppenders.add(factory.make(typeDescription));
/*     */         }
/* 131 */         return new MethodAttributeAppender.Compound(methodAttributeAppenders);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.factories.equals(((Compound)param2Object).factories))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.factories.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public enum ForInstrumentedMethod
/*     */     implements MethodAttributeAppender, Factory
/*     */   {
/* 151 */     EXCLUDING_RECEIVER
/*     */     {
/*     */       
/*     */       protected AnnotationAppender appendReceiver(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, MethodDescription methodDescription)
/*     */       {
/* 156 */         return annotationAppender;
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     INCLUDING_RECEIVER
/*     */     {
/*     */       
/*     */       protected AnnotationAppender appendReceiver(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, MethodDescription methodDescription)
/*     */       {
/* 177 */         TypeDescription.Generic receiverType = methodDescription.getReceiverType();
/* 178 */         return (receiverType == null) ? annotationAppender : (AnnotationAppender)receiverType
/*     */           
/* 180 */           .accept(AnnotationAppender.ForTypeAnnotations.ofReceiverType(annotationAppender, annotationValueFilter));
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodAttributeAppender make(TypeDescription typeDescription) {
/* 188 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(MethodVisitor methodVisitor, MethodDescription methodDescription, AnnotationValueFilter annotationValueFilter) {
/* 195 */       AnnotationAppender annotationAppender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnMethod(methodVisitor));
/* 196 */       annotationAppender = (AnnotationAppender)methodDescription.getReturnType().accept(AnnotationAppender.ForTypeAnnotations.ofMethodReturnType(annotationAppender, annotationValueFilter));
/*     */       
/* 198 */       annotationAppender = AnnotationAppender.ForTypeAnnotations.ofTypeVariable(annotationAppender, annotationValueFilter, false, (List<? extends TypeDescription.Generic>)methodDescription
/*     */ 
/*     */           
/* 201 */           .getTypeVariables());
/* 202 */       for (AnnotationDescription annotation : methodDescription.getDeclaredAnnotations().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.annotationType((ElementMatcher)ElementMatchers.nameStartsWith("jdk.internal."))))) {
/* 203 */         annotationAppender = annotationAppender.append(annotation, annotationValueFilter);
/*     */       }
/* 205 */       for (ParameterDescription parameterDescription : methodDescription.getParameters()) {
/*     */         
/* 207 */         AnnotationAppender parameterAppender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnMethodParameter(methodVisitor, parameterDescription.getIndex()));
/* 208 */         parameterAppender = (AnnotationAppender)parameterDescription.getType().accept(AnnotationAppender.ForTypeAnnotations.ofMethodParameterType(parameterAppender, annotationValueFilter, parameterDescription
/*     */               
/* 210 */               .getIndex()));
/* 211 */         for (AnnotationDescription annotation : parameterDescription.getDeclaredAnnotations()) {
/* 212 */           parameterAppender = parameterAppender.append(annotation, annotationValueFilter);
/*     */         }
/*     */       } 
/* 215 */       annotationAppender = appendReceiver(annotationAppender, annotationValueFilter, methodDescription);
/* 216 */       int exceptionTypeIndex = 0;
/* 217 */       for (TypeDescription.Generic exceptionType : methodDescription.getExceptionTypes()) {
/* 218 */         annotationAppender = (AnnotationAppender)exceptionType.accept(AnnotationAppender.ForTypeAnnotations.ofExceptionType(annotationAppender, annotationValueFilter, exceptionTypeIndex++));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract AnnotationAppender appendReceiver(AnnotationAppender param1AnnotationAppender, AnnotationValueFilter param1AnnotationValueFilter, MethodDescription param1MethodDescription);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Explicit
/*     */     implements MethodAttributeAppender, Factory
/*     */   {
/*     */     private final Target target;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(int parameterIndex, List<? extends AnnotationDescription> annotations) {
/* 261 */       this(new Target.OnMethodParameter(parameterIndex), annotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends AnnotationDescription> annotations) {
/* 270 */       this(Target.OnMethod.INSTANCE, annotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Explicit(Target target, List<? extends AnnotationDescription> annotations) {
/* 280 */       this.target = target;
/* 281 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MethodAttributeAppender.Factory of(MethodDescription methodDescription) {
/* 292 */       return new MethodAttributeAppender.Factory.Compound(new MethodAttributeAppender.Factory[] { ofMethodAnnotations(methodDescription), ofParameterAnnotations(methodDescription) });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MethodAttributeAppender.Factory ofMethodAnnotations(MethodDescription methodDescription) {
/* 302 */       return new Explicit((List<? extends AnnotationDescription>)methodDescription.getDeclaredAnnotations());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MethodAttributeAppender.Factory ofParameterAnnotations(MethodDescription methodDescription) {
/* 313 */       ParameterList<?> parameters = methodDescription.getParameters();
/* 314 */       List<MethodAttributeAppender.Factory> factories = new ArrayList<MethodAttributeAppender.Factory>(parameters.size());
/* 315 */       for (ParameterDescription parameter : parameters) {
/* 316 */         factories.add(new Explicit(parameter.getIndex(), (List<? extends AnnotationDescription>)parameter.getDeclaredAnnotations()));
/*     */       }
/* 318 */       return new MethodAttributeAppender.Factory.Compound(factories);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodAttributeAppender make(TypeDescription typeDescription) {
/* 325 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(MethodVisitor methodVisitor, MethodDescription methodDescription, AnnotationValueFilter annotationValueFilter) {
/* 332 */       AnnotationAppender appender = new AnnotationAppender.Default(this.target.make(methodVisitor, methodDescription));
/* 333 */       for (AnnotationDescription annotation : this.annotations) {
/* 334 */         appender = appender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.target.equals(((Explicit)param1Object).target) ? false : (!!this.annotations.equals(((Explicit)param1Object).annotations)))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return (getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.annotations.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum OnMethod
/*     */       implements Target
/*     */     {
/* 362 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public AnnotationAppender.Target make(MethodVisitor methodVisitor, MethodDescription methodDescription) {
/* 368 */         return new AnnotationAppender.Target.OnMethod(methodVisitor);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class OnMethodParameter
/*     */       implements Target
/*     */     {
/*     */       private final int parameterIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected OnMethodParameter(int parameterIndex) {
/* 389 */         this.parameterIndex = parameterIndex;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public AnnotationAppender.Target make(MethodVisitor methodVisitor, MethodDescription methodDescription)
/*     */       {
/* 396 */         if (this.parameterIndex >= methodDescription.getParameters().size()) {
/* 397 */           throw new IllegalArgumentException("Method " + methodDescription + " has less then " + this.parameterIndex + " parameters");
/*     */         }
/* 399 */         return new AnnotationAppender.Target.OnMethodParameter(methodVisitor, this.parameterIndex); } public boolean equals(@MaybeNull Object param2Object) { return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!(this.parameterIndex != ((OnMethodParameter)param2Object).parameterIndex)))); } public int hashCode() { return getClass().hashCode() * 31 + this.parameterIndex; } } protected static interface Target { AnnotationAppender.Target make(MethodVisitor param2MethodVisitor, MethodDescription param2MethodDescription); public enum OnMethod implements Target { INSTANCE; public AnnotationAppender.Target make(MethodVisitor methodVisitor, MethodDescription methodDescription) { return new AnnotationAppender.Target.OnMethod(methodVisitor); } } @Enhance public static class OnMethodParameter implements Target { public AnnotationAppender.Target make(MethodVisitor methodVisitor, MethodDescription methodDescription) { if (this.parameterIndex >= methodDescription.getParameters().size()) throw new IllegalArgumentException("Method " + methodDescription + " has less then " + this.parameterIndex + " parameters");  return new AnnotationAppender.Target.OnMethodParameter(methodVisitor, this.parameterIndex); }
/*     */ 
/*     */         
/*     */         private final int parameterIndex;
/*     */         
/*     */         protected OnMethodParameter(int parameterIndex) {
/*     */           this.parameterIndex = parameterIndex;
/*     */         }
/*     */         
/*     */         public boolean equals(@MaybeNull Object param3Object) {
/*     */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.parameterIndex != ((OnMethodParameter)param3Object).parameterIndex))));
/*     */         }
/*     */         
/*     */         public int hashCode() {
/*     */           return getClass().hashCode() * 31 + this.parameterIndex;
/*     */         } } }
/*     */   }
/*     */   
/*     */   @Enhance
/*     */   public static class ForReceiverType implements MethodAttributeAppender, Factory {
/*     */     private final TypeDescription.Generic receiverType;
/*     */     
/*     */     public ForReceiverType(TypeDescription.Generic receiverType) {
/* 422 */       this.receiverType = receiverType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodAttributeAppender make(TypeDescription typeDescription) {
/* 429 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(MethodVisitor methodVisitor, MethodDescription methodDescription, AnnotationValueFilter annotationValueFilter) {
/* 436 */       this.receiverType.accept(AnnotationAppender.ForTypeAnnotations.ofReceiverType(new AnnotationAppender.Default(new AnnotationAppender.Target.OnMethod(methodVisitor)), annotationValueFilter));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.receiverType.equals(((ForReceiverType)param1Object).receiverType))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.receiverType.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Compound
/*     */     implements MethodAttributeAppender
/*     */   {
/*     */     public Compound(MethodAttributeAppender... methodAttributeAppender) {
/* 459 */       this(Arrays.asList(methodAttributeAppender));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     private final List<MethodAttributeAppender> methodAttributeAppenders = new ArrayList<MethodAttributeAppender>(); public Compound(List<? extends MethodAttributeAppender> methodAttributeAppenders) {
/* 470 */       for (MethodAttributeAppender methodAttributeAppender : methodAttributeAppenders) {
/* 471 */         if (methodAttributeAppender instanceof Compound) {
/* 472 */           this.methodAttributeAppenders.addAll(((Compound)methodAttributeAppender).methodAttributeAppenders); continue;
/* 473 */         }  if (!(methodAttributeAppender instanceof MethodAttributeAppender.NoOp)) {
/* 474 */           this.methodAttributeAppenders.add(methodAttributeAppender);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(MethodVisitor methodVisitor, MethodDescription methodDescription, AnnotationValueFilter annotationValueFilter) {
/* 483 */       for (MethodAttributeAppender methodAttributeAppender : this.methodAttributeAppenders)
/* 484 */         methodAttributeAppender.apply(methodVisitor, methodDescription, annotationValueFilter); 
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.methodAttributeAppenders.equals(((Compound)param1Object).methodAttributeAppenders))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.methodAttributeAppenders.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\implementation\attribute\MethodAttributeAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */