/*     */ package net.bytebuddy.implementation.attribute;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TypeAttributeAppender
/*     */ {
/*     */   void apply(ClassVisitor paramClassVisitor, TypeDescription paramTypeDescription, AnnotationValueFilter paramAnnotationValueFilter);
/*     */   
/*     */   public enum NoOp
/*     */     implements TypeAttributeAppender
/*     */   {
/*  51 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(ClassVisitor classVisitor, TypeDescription instrumentedType, AnnotationValueFilter annotationValueFilter) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ForInstrumentedType
/*     */     implements TypeAttributeAppender
/*     */   {
/*  71 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(ClassVisitor classVisitor, TypeDescription instrumentedType, AnnotationValueFilter annotationValueFilter) {
/*  77 */       AnnotationAppender annotationAppender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnType(classVisitor));
/*  78 */       annotationAppender = AnnotationAppender.ForTypeAnnotations.ofTypeVariable(annotationAppender, annotationValueFilter, true, (List<? extends TypeDescription.Generic>)instrumentedType
/*     */ 
/*     */           
/*  81 */           .getTypeVariables());
/*  82 */       TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/*  83 */       if (superClass != null) {
/*  84 */         annotationAppender = (AnnotationAppender)superClass.accept(AnnotationAppender.ForTypeAnnotations.ofSuperClass(annotationAppender, annotationValueFilter));
/*     */       }
/*  86 */       int interfaceIndex = 0;
/*  87 */       for (TypeDescription.Generic interfaceType : instrumentedType.getInterfaces()) {
/*  88 */         annotationAppender = (AnnotationAppender)interfaceType.accept(AnnotationAppender.ForTypeAnnotations.ofInterfaceType(annotationAppender, annotationValueFilter, interfaceIndex++));
/*     */       }
/*     */ 
/*     */       
/*  92 */       for (AnnotationDescription annotation : instrumentedType.getDeclaredAnnotations()) {
/*  93 */         annotationAppender = annotationAppender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Differentiating
/*     */       implements TypeAttributeAppender
/*     */     {
/*     */       private final int annotationIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final int typeVariableIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final int interfaceTypeIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Differentiating(TypeDescription typeDescription) {
/* 125 */         this(typeDescription.getDeclaredAnnotations().size(), typeDescription.getTypeVariables().size(), typeDescription.getInterfaces().size());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Differentiating(int annotationIndex, int typeVariableIndex, int interfaceTypeIndex) {
/* 136 */         this.annotationIndex = annotationIndex;
/* 137 */         this.typeVariableIndex = typeVariableIndex;
/* 138 */         this.interfaceTypeIndex = interfaceTypeIndex;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void apply(ClassVisitor classVisitor, TypeDescription instrumentedType, AnnotationValueFilter annotationValueFilter) {
/* 145 */         AnnotationAppender annotationAppender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnType(classVisitor));
/* 146 */         AnnotationAppender.ForTypeAnnotations.ofTypeVariable(annotationAppender, annotationValueFilter, true, this.typeVariableIndex, (List<? extends TypeDescription.Generic>)instrumentedType
/*     */ 
/*     */ 
/*     */             
/* 150 */             .getTypeVariables());
/* 151 */         TypeList.Generic interfaceTypes = instrumentedType.getInterfaces();
/* 152 */         int interfaceTypeIndex = this.interfaceTypeIndex;
/* 153 */         for (TypeDescription.Generic interfaceType : interfaceTypes.subList(this.interfaceTypeIndex, interfaceTypes.size())) {
/* 154 */           annotationAppender = (AnnotationAppender)interfaceType.accept(AnnotationAppender.ForTypeAnnotations.ofInterfaceType(annotationAppender, annotationValueFilter, interfaceTypeIndex++));
/*     */         }
/*     */ 
/*     */         
/* 158 */         AnnotationList declaredAnnotations = instrumentedType.getDeclaredAnnotations();
/* 159 */         for (AnnotationDescription annotationDescription : declaredAnnotations.subList(this.annotationIndex, declaredAnnotations.size())) {
/* 160 */           annotationAppender = annotationAppender.append(annotationDescription, annotationValueFilter);
/*     */         }
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.annotationIndex != ((Differentiating)param2Object).annotationIndex) ? false : ((this.typeVariableIndex != ((Differentiating)param2Object).typeVariableIndex) ? false : (!(this.interfaceTypeIndex != ((Differentiating)param2Object).interfaceTypeIndex))))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return ((getClass().hashCode() * 31 + this.annotationIndex) * 31 + this.typeVariableIndex) * 31 + this.interfaceTypeIndex;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Explicit
/*     */     implements TypeAttributeAppender
/*     */   {
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */     
/*     */     public Explicit(List<? extends AnnotationDescription> annotations) {
/* 184 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(ClassVisitor classVisitor, TypeDescription instrumentedType, AnnotationValueFilter annotationValueFilter) {
/* 191 */       AnnotationAppender appender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnType(classVisitor));
/* 192 */       for (AnnotationDescription annotation : this.annotations) {
/* 193 */         appender = appender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.annotations.equals(((Explicit)param1Object).annotations))));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.annotations.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Compound
/*     */     implements TypeAttributeAppender
/*     */   {
/*     */     public Compound(TypeAttributeAppender... typeAttributeAppender) {
/* 215 */       this(Arrays.asList(typeAttributeAppender));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     private final List<TypeAttributeAppender> typeAttributeAppenders = new ArrayList<TypeAttributeAppender>(); public Compound(List<? extends TypeAttributeAppender> typeAttributeAppenders) {
/* 225 */       for (TypeAttributeAppender typeAttributeAppender : typeAttributeAppenders) {
/* 226 */         if (typeAttributeAppender instanceof Compound) {
/* 227 */           this.typeAttributeAppenders.addAll(((Compound)typeAttributeAppender).typeAttributeAppenders); continue;
/* 228 */         }  if (!(typeAttributeAppender instanceof TypeAttributeAppender.NoOp)) {
/* 229 */           this.typeAttributeAppenders.add(typeAttributeAppender);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(ClassVisitor classVisitor, TypeDescription instrumentedType, AnnotationValueFilter annotationValueFilter) {
/* 238 */       for (TypeAttributeAppender typeAttributeAppender : this.typeAttributeAppenders)
/* 239 */         typeAttributeAppender.apply(classVisitor, instrumentedType, annotationValueFilter); 
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.typeAttributeAppenders.equals(((Compound)param1Object).typeAttributeAppenders))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.typeAttributeAppenders.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\implementation\attribute\TypeAttributeAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */