/*     */ package net.bytebuddy.implementation.attribute;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*     */ import net.bytebuddy.jar.asm.Type;
/*     */ import net.bytebuddy.jar.asm.TypePath;
/*     */ import net.bytebuddy.jar.asm.TypeReference;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AnnotationAppender
/*     */ {
/*     */   @AlwaysNull
/*  41 */   public static final String NO_NAME = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationAppender append(AnnotationDescription paramAnnotationDescription, AnnotationValueFilter paramAnnotationValueFilter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationAppender append(AnnotationDescription paramAnnotationDescription, AnnotationValueFilter paramAnnotationValueFilter, int paramInt, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Target
/*     */   {
/*     */     @MaybeNull
/*     */     AnnotationVisitor visit(String param1String, boolean param1Boolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     AnnotationVisitor visit(String param1String1, boolean param1Boolean, int param1Int, String param1String2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class OnType
/*     */       implements Target
/*     */     {
/*     */       private final ClassVisitor classVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public OnType(ClassVisitor classVisitor) {
/* 107 */         this.classVisitor = classVisitor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible) {
/* 115 */         return this.classVisitor.visitAnnotation(annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible, int typeReference, String typePath) {
/* 123 */         return this.classVisitor.visitTypeAnnotation(typeReference, TypePath.fromString(typePath), annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.classVisitor.equals(((OnType)param2Object).classVisitor))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.classVisitor.hashCode();
/*     */       }
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     public static class OnField
/*     */       implements Target
/*     */     {
/*     */       private final FieldVisitor fieldVisitor;
/*     */       
/*     */       public OnField(FieldVisitor fieldVisitor) {
/* 144 */         this.fieldVisitor = fieldVisitor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible) {
/* 152 */         return this.fieldVisitor.visitAnnotation(annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible, int typeReference, String typePath) {
/* 160 */         return this.fieldVisitor.visitTypeAnnotation(typeReference, TypePath.fromString(typePath), annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.fieldVisitor.equals(((OnField)param2Object).fieldVisitor))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.fieldVisitor.hashCode();
/*     */       }
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     public static class OnMethod
/*     */       implements Target
/*     */     {
/*     */       private final MethodVisitor methodVisitor;
/*     */       
/*     */       public OnMethod(MethodVisitor methodVisitor) {
/* 181 */         this.methodVisitor = methodVisitor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible) {
/* 189 */         return this.methodVisitor.visitAnnotation(annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible, int typeReference, String typePath) {
/* 197 */         return this.methodVisitor.visitTypeAnnotation(typeReference, TypePath.fromString(typePath), annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.methodVisitor.equals(((OnMethod)param2Object).methodVisitor))));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.methodVisitor.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class OnMethodParameter
/*     */       implements Target
/*     */     {
/*     */       private final MethodVisitor methodVisitor;
/*     */       
/*     */       private final int parameterIndex;
/*     */ 
/*     */       
/*     */       public OnMethodParameter(MethodVisitor methodVisitor, int parameterIndex) {
/* 224 */         this.methodVisitor = methodVisitor;
/* 225 */         this.parameterIndex = parameterIndex;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible) {
/* 233 */         return this.methodVisitor.visitParameterAnnotation(this.parameterIndex, annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible, int typeReference, String typePath) {
/* 241 */         return this.methodVisitor.visitTypeAnnotation(typeReference, TypePath.fromString(typePath), annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.parameterIndex != ((OnMethodParameter)param2Object).parameterIndex) ? false : (!!this.methodVisitor.equals(((OnMethodParameter)param2Object).methodVisitor)))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.methodVisitor.hashCode()) * 31 + this.parameterIndex;
/*     */       }
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     public static class OnRecordComponent
/*     */       implements Target
/*     */     {
/*     */       private final RecordComponentVisitor recordComponentVisitor;
/*     */       
/*     */       public OnRecordComponent(RecordComponentVisitor recordComponentVisitor) {
/* 262 */         this.recordComponentVisitor = recordComponentVisitor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible) {
/* 270 */         return this.recordComponentVisitor.visitAnnotation(annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visit(String annotationTypeDescriptor, boolean visible, int typeReference, String typePath) {
/* 278 */         return this.recordComponentVisitor.visitTypeAnnotation(typeReference, TypePath.fromString(typePath), annotationTypeDescriptor, visible);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.recordComponentVisitor.equals(((OnRecordComponent)param2Object).recordComponentVisitor))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.recordComponentVisitor.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Default
/*     */     implements AnnotationAppender
/*     */   {
/*     */     private final AnnotationAppender.Target target;
/*     */     
/*     */     public Default(AnnotationAppender.Target target) {
/* 301 */       this.target = target;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void handle(AnnotationVisitor annotationVisitor, AnnotationDescription annotation, AnnotationValueFilter annotationValueFilter) {
/* 312 */       for (MethodDescription.InDefinedShape methodDescription : annotation.getAnnotationType().getDeclaredMethods()) {
/* 313 */         if (annotationValueFilter.isRelevant(annotation, methodDescription)) {
/* 314 */           apply(annotationVisitor, methodDescription.getReturnType().asErasure(), methodDescription.getName(), annotation.getValue(methodDescription).resolve());
/*     */         }
/*     */       } 
/* 317 */       annotationVisitor.visitEnd();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static void apply(AnnotationVisitor annotationVisitor, TypeDescription valueType, @MaybeNull String name, Object value) {
/* 329 */       if (valueType.isArray()) {
/* 330 */         AnnotationVisitor arrayVisitor = annotationVisitor.visitArray(name);
/* 331 */         int length = Array.getLength(value);
/* 332 */         TypeDescription componentType = valueType.getComponentType();
/* 333 */         for (int index = 0; index < length; index++) {
/* 334 */           apply(arrayVisitor, componentType, NO_NAME, Array.get(value, index));
/*     */         }
/* 336 */         arrayVisitor.visitEnd();
/* 337 */       } else if (valueType.isAnnotation()) {
/* 338 */         handle(annotationVisitor.visitAnnotation(name, valueType.getDescriptor()), (AnnotationDescription)value, AnnotationValueFilter.Default.APPEND_DEFAULTS);
/* 339 */       } else if (valueType.isEnum()) {
/* 340 */         annotationVisitor.visitEnum(name, valueType.getDescriptor(), ((EnumerationDescription)value).getValue());
/* 341 */       } else if (valueType.represents(Class.class)) {
/* 342 */         annotationVisitor.visit(name, Type.getType(((TypeDescription)value).getDescriptor()));
/*     */       } else {
/* 344 */         annotationVisitor.visit(name, value);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationAppender append(AnnotationDescription annotationDescription, AnnotationValueFilter annotationValueFilter) {
/* 352 */       switch (annotationDescription.getRetention()) {
/*     */         case RUNTIME:
/* 354 */           doAppend(annotationDescription, true, annotationValueFilter);
/*     */         
/*     */         case CLASS:
/* 357 */           doAppend(annotationDescription, false, annotationValueFilter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case SOURCE:
/* 364 */           return this;
/*     */       } 
/*     */       throw new IllegalStateException("Unexpected retention policy: " + annotationDescription.getRetention());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void doAppend(AnnotationDescription annotation, boolean visible, AnnotationValueFilter annotationValueFilter) {
/* 375 */       AnnotationVisitor annotationVisitor = this.target.visit(annotation.getAnnotationType().getDescriptor(), visible);
/* 376 */       if (annotationVisitor != null) {
/* 377 */         handle(annotationVisitor, annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationAppender append(AnnotationDescription annotationDescription, AnnotationValueFilter annotationValueFilter, int typeReference, String typePath) {
/* 385 */       switch (annotationDescription.getRetention()) {
/*     */         case RUNTIME:
/* 387 */           doAppend(annotationDescription, true, annotationValueFilter, typeReference, typePath);
/*     */         
/*     */         case CLASS:
/* 390 */           doAppend(annotationDescription, false, annotationValueFilter, typeReference, typePath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case SOURCE:
/* 397 */           return this;
/*     */       } 
/*     */       throw new IllegalStateException("Unexpected retention policy: " + annotationDescription.getRetention());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void doAppend(AnnotationDescription annotation, boolean visible, AnnotationValueFilter annotationValueFilter, int typeReference, String typePath) {
/* 414 */       AnnotationVisitor annotationVisitor = this.target.visit(annotation.getAnnotationType().getDescriptor(), visible, typeReference, typePath);
/* 415 */       if (annotationVisitor != null) {
/* 416 */         handle(annotationVisitor, annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.target.equals(((Default)param1Object).target))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.target.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForTypeAnnotations
/*     */     implements TypeDescription.Generic.Visitor<AnnotationAppender>
/*     */   {
/*     */     public static final boolean VARIABLE_ON_TYPE = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final boolean VARIABLE_ON_INVOKEABLE = false;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final String EMPTY_TYPE_PATH = "";
/*     */ 
/*     */ 
/*     */     
/*     */     private static final char COMPONENT_TYPE_PATH = '[';
/*     */ 
/*     */ 
/*     */     
/*     */     private static final char WILDCARD_TYPE_PATH = '*';
/*     */ 
/*     */ 
/*     */     
/*     */     private static final char INNER_CLASS_PATH = '.';
/*     */ 
/*     */ 
/*     */     
/*     */     private static final char INDEXED_TYPE_DELIMITER = ';';
/*     */ 
/*     */ 
/*     */     
/*     */     private static final int SUPER_CLASS_INDEX = -1;
/*     */ 
/*     */ 
/*     */     
/*     */     private final AnnotationAppender annotationAppender;
/*     */ 
/*     */ 
/*     */     
/*     */     private final AnnotationValueFilter annotationValueFilter;
/*     */ 
/*     */ 
/*     */     
/*     */     private final int typeReference;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String typePath;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForTypeAnnotations(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, TypeReference typeReference) {
/* 496 */       this(annotationAppender, annotationValueFilter, typeReference.getValue(), "");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForTypeAnnotations(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, int typeReference, String typePath) {
/* 508 */       this.annotationAppender = annotationAppender;
/* 509 */       this.annotationValueFilter = annotationValueFilter;
/* 510 */       this.typeReference = typeReference;
/* 511 */       this.typePath = typePath;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofSuperClass(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter) {
/* 523 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newSuperTypeReference(-1));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofInterfaceType(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, int index) {
/* 537 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newSuperTypeReference(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofFieldType(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter) {
/* 549 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newTypeReference(19));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofMethodReturnType(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter) {
/* 561 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newTypeReference(20));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofMethodParameterType(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, int index) {
/* 575 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newFormalParameterReference(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofExceptionType(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, int index) {
/* 589 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newExceptionReference(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic.Visitor<AnnotationAppender> ofReceiverType(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter) {
/* 601 */       return new ForTypeAnnotations(annotationAppender, annotationValueFilter, TypeReference.newTypeReference(21));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static AnnotationAppender ofTypeVariable(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, boolean variableOnType, List<? extends TypeDescription.Generic> typeVariables) {
/* 617 */       return ofTypeVariable(annotationAppender, annotationValueFilter, variableOnType, 0, typeVariables);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static AnnotationAppender ofTypeVariable(AnnotationAppender annotationAppender, AnnotationValueFilter annotationValueFilter, boolean variableOnType, int subListIndex, List<? extends TypeDescription.Generic> typeVariables) {
/* 635 */       int variableBaseReference, variableBoundBaseBase, typeVariableIndex = subListIndex;
/* 636 */       if (variableOnType) {
/* 637 */         variableBaseReference = 0;
/* 638 */         variableBoundBaseBase = 17;
/*     */       } else {
/* 640 */         variableBaseReference = 1;
/* 641 */         variableBoundBaseBase = 18;
/*     */       } 
/* 643 */       for (TypeDescription.Generic typeVariable : typeVariables.subList(subListIndex, typeVariables.size())) {
/* 644 */         int typeReference = TypeReference.newTypeParameterReference(variableBaseReference, typeVariableIndex).getValue();
/* 645 */         for (AnnotationDescription annotationDescription : typeVariable.getDeclaredAnnotations()) {
/* 646 */           annotationAppender = annotationAppender.append(annotationDescription, annotationValueFilter, typeReference, "");
/*     */         }
/* 648 */         int boundIndex = (!((TypeDescription.Generic)typeVariable.getUpperBounds().get(0)).getSort().isTypeVariable() && ((TypeDescription.Generic)typeVariable.getUpperBounds().get(0)).isInterface()) ? 1 : 0;
/*     */ 
/*     */         
/* 651 */         for (TypeDescription.Generic typeBound : typeVariable.getUpperBounds()) {
/* 652 */           annotationAppender = (AnnotationAppender)typeBound.accept(new ForTypeAnnotations(annotationAppender, annotationValueFilter, 
/*     */                 
/* 654 */                 TypeReference.newTypeParameterBoundReference(variableBoundBaseBase, typeVariableIndex, boundIndex++)));
/*     */         }
/* 656 */         typeVariableIndex++;
/*     */       } 
/* 658 */       return annotationAppender;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*     */     public AnnotationAppender onGenericArray(TypeDescription.Generic genericArray) {
/* 666 */       return (AnnotationAppender)genericArray.getComponentType().accept(new ForTypeAnnotations(apply(genericArray, this.typePath), this.annotationValueFilter, this.typeReference, this.typePath + '['));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationAppender onWildcard(TypeDescription.Generic wildcard) {
/* 676 */       TypeList.Generic lowerBounds = wildcard.getLowerBounds();
/* 677 */       return (AnnotationAppender)(lowerBounds.isEmpty() ? (TypeDescription.Generic)wildcard
/* 678 */         .getUpperBounds().getOnly() : (TypeDescription.Generic)lowerBounds
/* 679 */         .getOnly()).accept(new ForTypeAnnotations(apply(wildcard, this.typePath), this.annotationValueFilter, this.typeReference, this.typePath + '*'));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationAppender onParameterizedType(TypeDescription.Generic parameterizedType) {
/* 686 */       StringBuilder typePath = new StringBuilder(this.typePath);
/* 687 */       for (int index = 0; index < parameterizedType.asErasure().getInnerClassCount(); index++) {
/* 688 */         typePath = typePath.append('.');
/*     */       }
/* 690 */       AnnotationAppender annotationAppender = apply(parameterizedType, typePath.toString());
/* 691 */       TypeDescription.Generic ownerType = parameterizedType.getOwnerType();
/* 692 */       if (ownerType != null) {
/* 693 */         annotationAppender = (AnnotationAppender)ownerType.accept(new ForTypeAnnotations(annotationAppender, this.annotationValueFilter, this.typeReference, this.typePath));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 698 */       int i = 0;
/* 699 */       for (TypeDescription.Generic typeArgument : parameterizedType.getTypeArguments()) {
/* 700 */         annotationAppender = (AnnotationAppender)typeArgument.accept(new ForTypeAnnotations(annotationAppender, this.annotationValueFilter, this.typeReference, typePath
/*     */ 
/*     */               
/* 703 */               .toString() + i++ + ';'));
/*     */       }
/* 705 */       return annotationAppender;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationAppender onTypeVariable(TypeDescription.Generic typeVariable) {
/* 712 */       return apply(typeVariable, this.typePath);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationAppender onNonGenericType(TypeDescription.Generic typeDescription) {
/* 719 */       StringBuilder typePath = new StringBuilder(this.typePath);
/* 720 */       for (int index = 0; index < typeDescription.asErasure().getInnerClassCount(); index++) {
/* 721 */         typePath = typePath.append('.');
/*     */       }
/* 723 */       AnnotationAppender annotationAppender = apply(typeDescription, typePath.toString());
/* 724 */       TypeDescription.Generic componentType = typeDescription.getComponentType();
/* 725 */       if (componentType != null) {
/* 726 */         annotationAppender = (AnnotationAppender)componentType.accept(new ForTypeAnnotations(annotationAppender, this.annotationValueFilter, this.typeReference, this.typePath + '['));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 731 */       return annotationAppender;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AnnotationAppender apply(TypeDescription.Generic typeDescription, String typePath) {
/* 742 */       AnnotationAppender annotationAppender = this.annotationAppender;
/* 743 */       for (AnnotationDescription annotationDescription : typeDescription.getDeclaredAnnotations()) {
/* 744 */         annotationAppender = annotationAppender.append(annotationDescription, this.annotationValueFilter, this.typeReference, typePath);
/*     */       }
/* 746 */       return annotationAppender;
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.typeReference != ((ForTypeAnnotations)param1Object).typeReference) ? false : (!this.typePath.equals(((ForTypeAnnotations)param1Object).typePath) ? false : (!this.annotationAppender.equals(((ForTypeAnnotations)param1Object).annotationAppender) ? false : (!!this.annotationValueFilter.equals(((ForTypeAnnotations)param1Object).annotationValueFilter)))))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return (((getClass().hashCode() * 31 + this.annotationAppender.hashCode()) * 31 + this.annotationValueFilter.hashCode()) * 31 + this.typeReference) * 31 + this.typePath.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\implementation\attribute\AnnotationAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */