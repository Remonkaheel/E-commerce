/*     */ package net.bytebuddy.implementation.attribute;
/*     */ 
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.RecordComponentDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AnnotationValueFilter
/*     */ {
/*     */   boolean isRelevant(AnnotationDescription paramAnnotationDescription, MethodDescription.InDefinedShape paramInDefinedShape);
/*     */   
/*     */   public enum Default
/*     */     implements AnnotationValueFilter, Factory
/*     */   {
/*  85 */     SKIP_DEFAULTS
/*     */     {
/*     */       public boolean isRelevant(AnnotationDescription annotationDescription, MethodDescription.InDefinedShape methodDescription) {
/*  88 */         Object defaultValue = methodDescription.getDefaultValue();
/*  89 */         return (defaultValue == null || !defaultValue.equals(annotationDescription.getValue(methodDescription)));
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     APPEND_DEFAULTS
/*     */     {
/*     */       public boolean isRelevant(AnnotationDescription annotationDescription, MethodDescription.InDefinedShape methodDescription) {
/*  99 */         return true;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationValueFilter on(TypeDescription instrumentedType) {
/* 107 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationValueFilter on(FieldDescription fieldDescription) {
/* 114 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationValueFilter on(MethodDescription methodDescription) {
/* 121 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationValueFilter on(RecordComponentDescription recordComponentDescription) {
/* 128 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Factory {
/*     */     AnnotationValueFilter on(TypeDescription param1TypeDescription);
/*     */     
/*     */     AnnotationValueFilter on(FieldDescription param1FieldDescription);
/*     */     
/*     */     AnnotationValueFilter on(MethodDescription param1MethodDescription);
/*     */     
/*     */     AnnotationValueFilter on(RecordComponentDescription param1RecordComponentDescription);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\implementation\attribute\AnnotationValueFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */