/*     */ package net.bytebuddy.implementation.attribute;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.type.RecordComponentDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RecordComponentAttributeAppender
/*     */ {
/*     */   void apply(RecordComponentVisitor paramRecordComponentVisitor, RecordComponentDescription paramRecordComponentDescription, AnnotationValueFilter paramAnnotationValueFilter);
/*     */   
/*     */   public enum NoOp
/*     */     implements RecordComponentAttributeAppender, Factory
/*     */   {
/*  50 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentAttributeAppender make(TypeDescription typeDescription) {
/*  56 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(RecordComponentVisitor recordComponentVisitor, RecordComponentDescription recordComponentDescription, AnnotationValueFilter annotationValueFilter) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Factory
/*     */   {
/*     */     RecordComponentAttributeAppender make(TypeDescription param1TypeDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Compound
/*     */       implements Factory
/*     */     {
/*     */       public Compound(RecordComponentAttributeAppender.Factory... factory) {
/*  98 */         this(Arrays.asList(factory));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       private final List<RecordComponentAttributeAppender.Factory> factories = new ArrayList<RecordComponentAttributeAppender.Factory>(); public Compound(List<? extends RecordComponentAttributeAppender.Factory> factories) {
/* 108 */         for (RecordComponentAttributeAppender.Factory factory : factories) {
/* 109 */           if (factory instanceof Compound) {
/* 110 */             this.factories.addAll(((Compound)factory).factories); continue;
/* 111 */           }  if (!(factory instanceof RecordComponentAttributeAppender.NoOp)) {
/* 112 */             this.factories.add(factory);
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RecordComponentAttributeAppender make(TypeDescription typeDescription) {
/* 121 */         List<RecordComponentAttributeAppender> recordComponentAttributeAppenders = new ArrayList<RecordComponentAttributeAppender>(this.factories.size());
/* 122 */         for (RecordComponentAttributeAppender.Factory factory : this.factories) {
/* 123 */           recordComponentAttributeAppenders.add(factory.make(typeDescription));
/*     */         }
/* 125 */         return new RecordComponentAttributeAppender.Compound(recordComponentAttributeAppenders);
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.factories.equals(((Compound)param2Object).factories))));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.factories.hashCode();
/*     */       } }
/*     */   }
/*     */   
/*     */   public enum ForInstrumentedRecordComponent implements RecordComponentAttributeAppender, Factory {
/* 138 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(RecordComponentVisitor recordComponentVisitor, RecordComponentDescription recordComponentDescription, AnnotationValueFilter annotationValueFilter) {
/* 144 */       AnnotationAppender annotationAppender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnRecordComponent(recordComponentVisitor));
/* 145 */       annotationAppender = (AnnotationAppender)recordComponentDescription.getType().accept(AnnotationAppender.ForTypeAnnotations.ofFieldType(annotationAppender, annotationValueFilter));
/* 146 */       for (AnnotationDescription annotation : recordComponentDescription.getDeclaredAnnotations()) {
/* 147 */         annotationAppender = annotationAppender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentAttributeAppender make(TypeDescription typeDescription) {
/* 155 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Explicit
/*     */     implements RecordComponentAttributeAppender, Factory
/*     */   {
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends AnnotationDescription> annotations) {
/* 177 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(RecordComponentVisitor recordComponentVisitor, RecordComponentDescription recordComponentDescription, AnnotationValueFilter annotationValueFilter) {
/* 184 */       AnnotationAppender appender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnRecordComponent(recordComponentVisitor));
/* 185 */       for (AnnotationDescription annotation : this.annotations) {
/* 186 */         appender = appender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentAttributeAppender make(TypeDescription typeDescription) {
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.annotations.equals(((Explicit)param1Object).annotations))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.annotations.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Compound
/*     */     implements RecordComponentAttributeAppender
/*     */   {
/*     */     public Compound(RecordComponentAttributeAppender... recordComponentAttributeAppender) {
/* 217 */       this(Arrays.asList(recordComponentAttributeAppender));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     private final List<RecordComponentAttributeAppender> recordComponentAttributeAppenders = new ArrayList<RecordComponentAttributeAppender>(); public Compound(List<? extends RecordComponentAttributeAppender> recordComponentAttributeAppenders) {
/* 228 */       for (RecordComponentAttributeAppender recordComponentAttributeAppender : recordComponentAttributeAppenders) {
/* 229 */         if (recordComponentAttributeAppender instanceof Compound) {
/* 230 */           this.recordComponentAttributeAppenders.addAll(((Compound)recordComponentAttributeAppender).recordComponentAttributeAppenders); continue;
/* 231 */         }  if (!(recordComponentAttributeAppender instanceof RecordComponentAttributeAppender.NoOp)) {
/* 232 */           this.recordComponentAttributeAppenders.add(recordComponentAttributeAppender);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(RecordComponentVisitor recordComponentVisitor, RecordComponentDescription recordComponentDescription, AnnotationValueFilter annotationValueFilter) {
/* 241 */       for (RecordComponentAttributeAppender recordComponentAttributeAppender : this.recordComponentAttributeAppenders)
/* 242 */         recordComponentAttributeAppender.apply(recordComponentVisitor, recordComponentDescription, annotationValueFilter); 
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.recordComponentAttributeAppenders.equals(((Compound)param1Object).recordComponentAttributeAppenders))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.recordComponentAttributeAppenders.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\implementation\attribute\RecordComponentAttributeAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */