/*     */ package net.bytebuddy.implementation.attribute;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FieldAttributeAppender
/*     */ {
/*     */   void apply(FieldVisitor paramFieldVisitor, FieldDescription paramFieldDescription, AnnotationValueFilter paramAnnotationValueFilter);
/*     */   
/*     */   public enum NoOp
/*     */     implements FieldAttributeAppender, Factory
/*     */   {
/*  50 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldAttributeAppender make(TypeDescription typeDescription) {
/*  56 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(FieldVisitor fieldVisitor, FieldDescription fieldDescription, AnnotationValueFilter annotationValueFilter) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Factory
/*     */   {
/*     */     FieldAttributeAppender make(TypeDescription param1TypeDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Compound
/*     */       implements Factory
/*     */     {
/*     */       public Compound(FieldAttributeAppender.Factory... factory) {
/*  98 */         this(Arrays.asList(factory));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       private final List<FieldAttributeAppender.Factory> factories = new ArrayList<FieldAttributeAppender.Factory>(); public Compound(List<? extends FieldAttributeAppender.Factory> factories) {
/* 108 */         for (FieldAttributeAppender.Factory factory : factories) {
/* 109 */           if (factory instanceof Compound) {
/* 110 */             this.factories.addAll(((Compound)factory).factories); continue;
/* 111 */           }  if (!(factory instanceof FieldAttributeAppender.NoOp)) {
/* 112 */             this.factories.add(factory);
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldAttributeAppender make(TypeDescription typeDescription) {
/* 121 */         List<FieldAttributeAppender> fieldAttributeAppenders = new ArrayList<FieldAttributeAppender>(this.factories.size());
/* 122 */         for (FieldAttributeAppender.Factory factory : this.factories) {
/* 123 */           fieldAttributeAppenders.add(factory.make(typeDescription));
/*     */         }
/* 125 */         return new FieldAttributeAppender.Compound(fieldAttributeAppenders);
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.factories.equals(((Compound)param2Object).factories))));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.factories.hashCode();
/*     */       } }
/*     */   }
/*     */   
/*     */   public enum ForInstrumentedField implements FieldAttributeAppender, Factory {
/* 138 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(FieldVisitor fieldVisitor, FieldDescription fieldDescription, AnnotationValueFilter annotationValueFilter) {
/* 144 */       AnnotationAppender annotationAppender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnField(fieldVisitor));
/* 145 */       annotationAppender = (AnnotationAppender)fieldDescription.getType().accept(AnnotationAppender.ForTypeAnnotations.ofFieldType(annotationAppender, annotationValueFilter));
/* 146 */       for (AnnotationDescription annotation : fieldDescription.getDeclaredAnnotations()) {
/* 147 */         annotationAppender = annotationAppender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldAttributeAppender make(TypeDescription typeDescription) {
/* 155 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Explicit
/*     */     implements FieldAttributeAppender, Factory
/*     */   {
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends AnnotationDescription> annotations) {
/* 177 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(FieldVisitor fieldVisitor, FieldDescription fieldDescription, AnnotationValueFilter annotationValueFilter) {
/* 184 */       AnnotationAppender appender = new AnnotationAppender.Default(new AnnotationAppender.Target.OnField(fieldVisitor));
/* 185 */       for (AnnotationDescription annotation : this.annotations) {
/* 186 */         appender = appender.append(annotation, annotationValueFilter);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldAttributeAppender make(TypeDescription typeDescription) {
/* 194 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.annotations.equals(((Explicit)param1Object).annotations))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.annotations.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Compound
/*     */     implements FieldAttributeAppender
/*     */   {
/*     */     public Compound(FieldAttributeAppender... fieldAttributeAppender) {
/* 217 */       this(Arrays.asList(fieldAttributeAppender));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     private final List<FieldAttributeAppender> fieldAttributeAppenders = new ArrayList<FieldAttributeAppender>(); public Compound(List<? extends FieldAttributeAppender> fieldAttributeAppenders) {
/* 228 */       for (FieldAttributeAppender fieldAttributeAppender : fieldAttributeAppenders) {
/* 229 */         if (fieldAttributeAppender instanceof Compound) {
/* 230 */           this.fieldAttributeAppenders.addAll(((Compound)fieldAttributeAppender).fieldAttributeAppenders); continue;
/* 231 */         }  if (!(fieldAttributeAppender instanceof FieldAttributeAppender.NoOp)) {
/* 232 */           this.fieldAttributeAppenders.add(fieldAttributeAppender);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void apply(FieldVisitor fieldVisitor, FieldDescription fieldDescription, AnnotationValueFilter annotationValueFilter) {
/* 241 */       for (FieldAttributeAppender fieldAttributeAppender : this.fieldAttributeAppenders)
/* 242 */         fieldAttributeAppender.apply(fieldVisitor, fieldDescription, annotationValueFilter); 
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.fieldAttributeAppenders.equals(((Compound)param1Object).fieldAttributeAppenders))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.fieldAttributeAppenders.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\implementation\attribute\FieldAttributeAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */