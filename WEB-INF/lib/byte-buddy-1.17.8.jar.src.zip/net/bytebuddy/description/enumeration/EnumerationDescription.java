/*     */ package net.bytebuddy.description.enumeration;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*     */ import net.bytebuddy.description.NamedElement;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface EnumerationDescription
/*     */   extends NamedElement
/*     */ {
/*     */   String getValue();
/*     */   
/*     */   TypeDescription getEnumerationType();
/*     */   
/*     */   <T extends Enum<T>> T load(Class<T> paramClass);
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     implements EnumerationDescription
/*     */   {
/*     */     public String getActualName() {
/*  64 */       return getValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance("hashCode")
/*     */     public int hashCode() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object other) {
/*  75 */       if (this == other)
/*  76 */         return true; 
/*  77 */       if (!(other instanceof EnumerationDescription)) {
/*  78 */         return false;
/*     */       }
/*  80 */       EnumerationDescription enumerationDescription = (EnumerationDescription)other;
/*  81 */       return (getEnumerationType().equals(enumerationDescription.getEnumerationType()) && getValue().equals(enumerationDescription.getValue()));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  86 */       return getValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedEnumeration
/*     */     extends AbstractBase
/*     */   {
/*     */     private final Enum<?> value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedEnumeration(Enum<?> value) {
/* 106 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static List<EnumerationDescription> asList(Enum<?>[] enumerations) {
/* 116 */       List<EnumerationDescription> result = new ArrayList<EnumerationDescription>(enumerations.length);
/* 117 */       for (Enum<?> enumeration : enumerations) {
/* 118 */         result.add(new ForLoadedEnumeration(enumeration));
/*     */       }
/* 120 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 127 */       return this.value.name();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription getEnumerationType() {
/* 134 */       return TypeDescription.ForLoadedType.of(this.value.getDeclaringClass());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T extends Enum<T>> T load(Class<T> type) {
/* 142 */       return (this.value.getDeclaringClass() == type) ? (T)this.value : 
/*     */         
/* 144 */         Enum.<T>valueOf(type, this.value.name());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Latent
/*     */     extends AbstractBase
/*     */   {
/*     */     private final TypeDescription enumerationType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Latent(TypeDescription enumerationType, String value) {
/* 170 */       this.enumerationType = enumerationType;
/* 171 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 178 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription getEnumerationType() {
/* 185 */       return this.enumerationType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T extends Enum<T>> T load(Class<T> type) {
/* 192 */       if (!this.enumerationType.represents(type)) {
/* 193 */         throw new IllegalArgumentException(type + " does not represent " + this.enumerationType);
/*     */       }
/* 195 */       return Enum.valueOf(type, this.value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\enumeration\EnumerationDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */