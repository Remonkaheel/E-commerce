/*     */ package net.bytebuddy.description.field;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.FilterableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FieldList<T extends FieldDescription>
/*     */   extends FilterableList<T, FieldList<T>>
/*     */ {
/*     */   ByteCodeElement.Token.TokenList<FieldDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*     */   
/*     */   FieldList<FieldDescription.InDefinedShape> asDefined();
/*     */   
/*     */   public static abstract class AbstractBase<S extends FieldDescription>
/*     */     extends FilterableList.AbstractBase<S, FieldList<S>>
/*     */     implements FieldList<S>
/*     */   {
/*     */     public ByteCodeElement.Token.TokenList<FieldDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/*  62 */       List<FieldDescription.Token> tokens = new ArrayList<FieldDescription.Token>(size());
/*  63 */       for (FieldDescription fieldDescription : this) {
/*  64 */         tokens.add(fieldDescription.asToken(matcher));
/*     */       }
/*  66 */       return new ByteCodeElement.Token.TokenList(tokens);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldList<FieldDescription.InDefinedShape> asDefined() {
/*  73 */       List<FieldDescription.InDefinedShape> declaredForms = new ArrayList<FieldDescription.InDefinedShape>(size());
/*  74 */       for (FieldDescription fieldDescription : this) {
/*  75 */         declaredForms.add(fieldDescription.asDefined());
/*     */       }
/*  77 */       return new FieldList.Explicit<FieldDescription.InDefinedShape>(declaredForms);
/*     */     }
/*     */ 
/*     */     
/*     */     protected FieldList<S> wrap(List<S> values) {
/*  82 */       return new FieldList.Explicit<S>(values);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedFields
/*     */     extends AbstractBase<FieldDescription.InDefinedShape>
/*     */   {
/*     */     private final List<? extends Field> fields;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedFields(Field... field) {
/* 102 */       this(Arrays.asList(field));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedFields(List<? extends Field> fields) {
/* 111 */       this.fields = fields;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.InDefinedShape get(int index) {
/* 118 */       return new FieldDescription.ForLoadedField(this.fields.get(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 125 */       return this.fields.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Explicit<S extends FieldDescription>
/*     */     extends AbstractBase<S>
/*     */   {
/*     */     private final List<? extends S> fieldDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(S... fieldDescription) {
/* 148 */       this(Arrays.asList(fieldDescription));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends S> fieldDescriptions) {
/* 157 */       this.fieldDescriptions = fieldDescriptions;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S get(int index) {
/* 164 */       return this.fieldDescriptions.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 171 */       return this.fieldDescriptions.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForTokens
/*     */     extends AbstractBase<FieldDescription.InDefinedShape>
/*     */   {
/*     */     private final TypeDescription declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends FieldDescription.Token> tokens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(TypeDescription declaringType, FieldDescription.Token... token) {
/* 197 */       this(declaringType, Arrays.asList(token));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(TypeDescription declaringType, List<? extends FieldDescription.Token> tokens) {
/* 207 */       this.declaringType = declaringType;
/* 208 */       this.tokens = tokens;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.InDefinedShape get(int index) {
/* 215 */       return new FieldDescription.Latent(this.declaringType, this.tokens.get(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 222 */       return this.tokens.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeSubstituting
/*     */     extends AbstractBase<FieldDescription.InGenericShape>
/*     */   {
/*     */     private final TypeDescription.Generic declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends FieldDescription> fieldDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSubstituting(TypeDescription.Generic declaringType, List<? extends FieldDescription> fieldDescriptions, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 256 */       this.declaringType = declaringType;
/* 257 */       this.fieldDescriptions = fieldDescriptions;
/* 258 */       this.visitor = visitor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.InGenericShape get(int index) {
/* 265 */       return new FieldDescription.TypeSubstituting(this.declaringType, this.fieldDescriptions.get(index), this.visitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 272 */       return this.fieldDescriptions.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Empty<S extends FieldDescription>
/*     */     extends FilterableList.Empty<S, FieldList<S>>
/*     */     implements FieldList<S>
/*     */   {
/*     */     public ByteCodeElement.Token.TokenList<FieldDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/* 287 */       return new ByteCodeElement.Token.TokenList((ByteCodeElement.Token[])new FieldDescription.Token[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldList<FieldDescription.InDefinedShape> asDefined() {
/* 295 */       return (FieldList)this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\field\FieldList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */