/*     */ package net.bytebuddy.description.field;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericSignatureFormatError;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.DeclaredByType;
/*     */ import net.bytebuddy.description.ModifierReviewable;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureVisitor;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureWriter;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FieldDescription
/*     */   extends ModifierReviewable.ForFieldDescription, DeclaredByType.WithMandatoryDeclaration, ByteCodeElement.Member, ByteCodeElement.TypeDependant<FieldDescription.InDefinedShape, FieldDescription.Token>
/*     */ {
/*     */   @AlwaysNull
/*  53 */   public static final Object NO_DEFAULT_VALUE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   TypeDefinition getDeclaringType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeDescription.Generic getType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getActualModifiers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SignatureToken asSignatureToken();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface InGenericShape
/*     */     extends FieldDescription
/*     */   {
/*     */     @Nonnull
/*     */     TypeDescription.Generic getDeclaringType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface InDefinedShape
/*     */     extends FieldDescription
/*     */   {
/*     */     @Nonnull
/*     */     TypeDescription getDeclaringType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static abstract class AbstractBase
/*     */       extends FieldDescription.AbstractBase
/*     */       implements InDefinedShape
/*     */     {
/*     */       public FieldDescription.InDefinedShape asDefined() {
/* 115 */         return this;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     extends ModifierReviewable.AbstractBase
/*     */     implements FieldDescription
/*     */   {
/*     */     public String getInternalName() {
/* 129 */       return getName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getActualName() {
/* 136 */       return getName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDescriptor() {
/* 143 */       return getType().asErasure().getDescriptor();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public String getGenericSignature() {
/* 151 */       TypeDescription.Generic fieldType = getType();
/*     */       try {
/* 153 */         return fieldType.getSort().isNonGeneric() ? NON_GENERIC_SIGNATURE : ((SignatureVisitor)fieldType
/*     */           
/* 155 */           .accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.ForSignatureVisitor((SignatureVisitor)new SignatureWriter()))).toString();
/* 156 */       } catch (GenericSignatureFormatError ignored) {
/* 157 */         return NON_GENERIC_SIGNATURE;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public boolean isVisibleTo(TypeDescription typeDescription) {
/* 166 */       return (getDeclaringType().asErasure().isVisibleTo(typeDescription) && (
/* 167 */         isPublic() || typeDescription
/* 168 */         .equals(getDeclaringType().asErasure()) || (
/* 169 */         isProtected() && getDeclaringType().asErasure().isAssignableFrom(typeDescription)) || (
/* 170 */         !isPrivate() && typeDescription.isSamePackage(getDeclaringType().asErasure())) || (
/* 171 */         isPrivate() && typeDescription.isNestMateOf(getDeclaringType().asErasure()))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public boolean isAccessibleTo(TypeDescription typeDescription) {
/* 179 */       return (isPublic() || typeDescription
/* 180 */         .equals(getDeclaringType().asErasure()) || (
/* 181 */         !isPrivate() && typeDescription.isSamePackage(getDeclaringType().asErasure())) || (
/* 182 */         isPrivate() && typeDescription.isNestMateOf(getDeclaringType().asErasure())));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getActualModifiers() {
/* 189 */       return getModifiers() | (getDeclaredAnnotations().isAnnotationPresent(Deprecated.class) ? 131072 : 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.Token asToken(ElementMatcher<? super TypeDescription> matcher) {
/* 198 */       return new FieldDescription.Token(getName(), 
/* 199 */           getModifiers(), (TypeDescription.Generic)
/* 200 */           getType().accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)), (List<? extends AnnotationDescription>)
/* 201 */           getDeclaredAnnotations());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.SignatureToken asSignatureToken() {
/* 208 */       return new FieldDescription.SignatureToken(getInternalName(), getType().asErasure());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance("hashCode")
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public int hashCode() {}
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public boolean equals(@MaybeNull Object other) {
/* 221 */       if (this == other)
/* 222 */         return true; 
/* 223 */       if (!(other instanceof FieldDescription)) {
/* 224 */         return false;
/*     */       }
/* 226 */       FieldDescription fieldDescription = (FieldDescription)other;
/* 227 */       return (getName().equals(fieldDescription.getName()) && getDeclaringType().equals(fieldDescription.getDeclaringType()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public String toGenericString() {
/* 235 */       StringBuilder stringBuilder = new StringBuilder();
/* 236 */       if (getModifiers() != 0) {
/* 237 */         stringBuilder.append(Modifier.toString(getModifiers())).append(' ');
/*     */       }
/* 239 */       stringBuilder.append(getType().getActualName()).append(' ');
/* 240 */       stringBuilder.append(getDeclaringType().asErasure().getActualName()).append('.');
/* 241 */       return stringBuilder.append(getName()).toString();
/*     */     }
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public String toString() {
/* 247 */       StringBuilder stringBuilder = new StringBuilder();
/* 248 */       if (getModifiers() != 0) {
/* 249 */         stringBuilder.append(Modifier.toString(getModifiers())).append(' ');
/*     */       }
/* 251 */       stringBuilder.append(getType().asErasure().getActualName()).append(' ');
/* 252 */       stringBuilder.append(getDeclaringType().asErasure().getActualName()).append('.');
/* 253 */       return stringBuilder.append(getName()).toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedField
/*     */     extends InDefinedShape.AbstractBase
/*     */   {
/*     */     private final Field field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedField(Field field) {
/* 273 */       this.field = field;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 280 */       if (TypeDescription.AbstractBase.RAW_TYPES) {
/* 281 */         return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.field.getType());
/*     */       }
/* 283 */       return (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.ForLoadedFieldType(this.field);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance("declaredAnnotations")
/*     */     public AnnotationList getDeclaredAnnotations() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 298 */       return this.field.getName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public TypeDescription getDeclaringType() {
/* 306 */       return TypeDescription.ForLoadedType.of(this.field.getDeclaringClass());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getModifiers() {
/* 313 */       return this.field.getModifiers();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSynthetic() {
/* 320 */       return this.field.isSynthetic();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Latent
/*     */     extends InDefinedShape.AbstractBase
/*     */   {
/*     */     private final TypeDescription declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int modifiers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic fieldType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends AnnotationDescription> declaredAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Latent(TypeDescription declaringType, FieldDescription.Token token) {
/* 362 */       this(declaringType, token
/* 363 */           .getName(), token
/* 364 */           .getModifiers(), token
/* 365 */           .getType(), (List<? extends AnnotationDescription>)token
/* 366 */           .getAnnotations());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Latent(TypeDescription declaringType, String name, int modifiers, TypeDescription.Generic fieldType, List<? extends AnnotationDescription> declaredAnnotations) {
/* 383 */       this.declaringType = declaringType;
/* 384 */       this.name = name;
/* 385 */       this.modifiers = modifiers;
/* 386 */       this.fieldType = fieldType;
/* 387 */       this.declaredAnnotations = declaredAnnotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 394 */       return (TypeDescription.Generic)this.fieldType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getDeclaredAnnotations() {
/* 401 */       return (AnnotationList)new AnnotationList.Explicit(this.declaredAnnotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 408 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public TypeDescription getDeclaringType() {
/* 416 */       return this.declaringType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getModifiers() {
/* 423 */       return this.modifiers;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeSubstituting
/*     */     extends AbstractBase
/*     */     implements InGenericShape
/*     */   {
/*     */     private final TypeDescription.Generic declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final FieldDescription fieldDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSubstituting(TypeDescription.Generic declaringType, FieldDescription fieldDescription, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 457 */       this.declaringType = declaringType;
/* 458 */       this.fieldDescription = fieldDescription;
/* 459 */       this.visitor = visitor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 466 */       return (TypeDescription.Generic)this.fieldDescription.getType().accept(this.visitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getDeclaredAnnotations() {
/* 473 */       return this.fieldDescription.getDeclaredAnnotations();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public TypeDescription.Generic getDeclaringType() {
/* 481 */       return this.declaringType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getModifiers() {
/* 488 */       return this.fieldDescription.getModifiers();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 495 */       return this.fieldDescription.getName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.InDefinedShape asDefined() {
/* 502 */       return (FieldDescription.InDefinedShape)this.fieldDescription.asDefined();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Token
/*     */     implements ByteCodeElement.Token<Token>
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int modifiers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Token(String name, int modifiers, TypeDescription.Generic type) {
/* 539 */       this(name, modifiers, type, Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Token(String name, int modifiers, TypeDescription.Generic type, List<? extends AnnotationDescription> annotations) {
/* 551 */       this.name = name;
/* 552 */       this.modifiers = modifiers;
/* 553 */       this.type = type;
/* 554 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 563 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 572 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getModifiers() {
/* 581 */       return this.modifiers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getAnnotations() {
/* 590 */       return (AnnotationList)new AnnotationList.Explicit(this.annotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Token accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 597 */       return new Token(this.name, this.modifiers, (TypeDescription.Generic)this.type
/*     */           
/* 599 */           .accept(visitor), this.annotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDescription.SignatureToken asSignatureToken(TypeDescription declaringType) {
/* 610 */       return new FieldDescription.SignatureToken(this.name, (TypeDescription)this.type.accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Reducing(declaringType, new net.bytebuddy.description.type.TypeVariableToken[0])));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance("hashCode")
/*     */     public int hashCode() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object other) {
/* 625 */       if (this == other)
/* 626 */         return true; 
/* 627 */       if (other == null || getClass() != other.getClass()) {
/* 628 */         return false;
/*     */       }
/* 630 */       Token token = (Token)other;
/* 631 */       return (this.modifiers == token.modifiers && this.name
/* 632 */         .equals(token.name) && this.type
/* 633 */         .equals(token.type) && this.annotations
/* 634 */         .equals(token.annotations));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SignatureToken
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SignatureToken(String name, TypeDescription type) {
/* 660 */       this.name = name;
/* 661 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 670 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription getType() {
/* 679 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance("hashCode")
/*     */     public int hashCode() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object other) {
/* 692 */       if (this == other)
/* 693 */         return true; 
/* 694 */       if (!(other instanceof SignatureToken)) {
/* 695 */         return false;
/*     */       }
/* 697 */       SignatureToken signatureToken = (SignatureToken)other;
/* 698 */       return (this.name.equals(signatureToken.name) && this.type.equals(signatureToken.type));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 703 */       return this.type + " " + this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\field\FieldDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */