/*     */ package net.bytebuddy.description;
/*     */ 
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TypeVariableSource
/*     */   extends ModifierReviewable.OfAbstraction
/*     */ {
/*     */   @AlwaysNull
/*  35 */   public static final TypeVariableSource UNDEFINED = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeList.Generic getTypeVariables();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   TypeVariableSource getEnclosingSource();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isInferrable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @MaybeNull
/*     */   TypeDescription.Generic findVariable(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeDescription.Generic findExpectedVariable(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> T accept(Visitor<T> paramVisitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isGenerified();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Visitor<T>
/*     */   {
/*     */     T onType(TypeDescription param1TypeDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     T onMethod(MethodDescription.InDefinedShape param1InDefinedShape);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum NoOp
/*     */       implements Visitor<TypeVariableSource>
/*     */     {
/* 129 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeVariableSource onType(TypeDescription typeDescription) {
/* 135 */         return (TypeVariableSource)typeDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeVariableSource onMethod(MethodDescription.InDefinedShape methodDescription) {
/* 142 */         return (TypeVariableSource)methodDescription;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     extends ModifierReviewable.AbstractBase
/*     */     implements TypeVariableSource
/*     */   {
/*     */     @MaybeNull
/*     */     public TypeDescription.Generic findVariable(String symbol) {
/* 157 */       TypeList.Generic typeVariables = (TypeList.Generic)getTypeVariables().filter((ElementMatcher)ElementMatchers.named(symbol));
/* 158 */       if (typeVariables.isEmpty()) {
/* 159 */         TypeVariableSource enclosingSource = getEnclosingSource();
/* 160 */         return (enclosingSource == null) ? TypeDescription.Generic.UNDEFINED : enclosingSource
/*     */           
/* 162 */           .findVariable(symbol);
/*     */       } 
/* 164 */       return (TypeDescription.Generic)typeVariables.getOnly();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic findExpectedVariable(String symbol) {
/* 172 */       TypeDescription.Generic variable = findVariable(symbol);
/* 173 */       if (variable == null) {
/* 174 */         throw new IllegalArgumentException("Cannot resolve " + symbol + " from " + toSafeString());
/*     */       }
/* 176 */       return variable;
/*     */     }
/*     */     
/*     */     protected abstract String toSafeString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\TypeVariableSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */