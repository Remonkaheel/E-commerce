/*     */ package net.bytebuddy.description.modifier;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ModifierContributor
/*     */ {
/*     */   public static final int EMPTY_MASK = 0;
/*     */   
/*     */   int getMask();
/*     */   
/*     */   int getRange();
/*     */   
/*     */   boolean isDefault();
/*     */   
/*     */   @Enhance
/*     */   public static class Resolver<T extends ModifierContributor>
/*     */   {
/*     */     private final Collection<? extends T> modifierContributors;
/*     */     
/*     */     protected Resolver(Collection<? extends T> modifierContributors) {
/* 132 */       this.modifierContributors = modifierContributors;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Resolver<ModifierContributor.ForType> of(ModifierContributor.ForType... modifierContributor) {
/* 142 */       return of(Arrays.asList(modifierContributor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Resolver<ModifierContributor.ForField> of(ModifierContributor.ForField... modifierContributor) {
/* 152 */       return of(Arrays.asList(modifierContributor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Resolver<ModifierContributor.ForMethod> of(ModifierContributor.ForMethod... modifierContributor) {
/* 162 */       return of(Arrays.asList(modifierContributor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Resolver<ModifierContributor.ForParameter> of(ModifierContributor.ForParameter... modifierContributor) {
/* 172 */       return of(Arrays.asList(modifierContributor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <S extends ModifierContributor> Resolver<S> of(Collection<? extends S> modifierContributors) {
/* 183 */       return new Resolver<S>(modifierContributors);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int resolve() {
/* 192 */       return resolve(0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int resolve(int modifiers) {
/* 202 */       for (ModifierContributor modifierContributor : this.modifierContributors) {
/* 203 */         modifiers = modifiers & (modifierContributor.getRange() ^ 0xFFFFFFFF) | modifierContributor.getMask();
/*     */       }
/* 205 */       return modifiers;
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.modifierContributors.equals(((Resolver)param1Object).modifierContributors))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.modifierContributors.hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface ForParameter extends ModifierContributor {
/*     */     public static final int MASK = 36880;
/*     */   }
/*     */   
/*     */   public static interface ForMethod extends ModifierContributor {
/*     */     public static final int MASK = 7679;
/*     */   }
/*     */   
/*     */   public static interface ForField extends ModifierContributor {
/*     */     public static final int MASK = 151775;
/*     */   }
/*     */   
/*     */   public static interface ForType extends ModifierContributor {
/*     */     public static final int MASK = 163359;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\modifier\ModifierContributor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */