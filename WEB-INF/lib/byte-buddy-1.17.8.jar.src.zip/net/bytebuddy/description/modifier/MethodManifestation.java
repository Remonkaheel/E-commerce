/*     */ package net.bytebuddy.description.modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MethodManifestation
/*     */   implements ModifierContributor.ForMethod
/*     */ {
/*  30 */   PLAIN(0),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  35 */   NATIVE(256),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   ABSTRACT(1024),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   FINAL(16),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   FINAL_NATIVE(272),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   BRIDGE(64),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   FINAL_BRIDGE(80);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int mask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodManifestation(int mask) {
/*  73 */     this.mask = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMask() {
/*  80 */     return this.mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRange() {
/*  87 */     return 1360;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/*  94 */     return (this == PLAIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNative() {
/* 103 */     return ((this.mask & 0x100) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbstract() {
/* 112 */     return ((this.mask & 0x400) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinal() {
/* 121 */     return ((this.mask & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBridge() {
/* 130 */     return ((this.mask & 0x40) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\modifier\MethodManifestation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */