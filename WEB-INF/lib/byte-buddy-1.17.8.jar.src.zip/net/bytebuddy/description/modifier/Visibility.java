/*     */ package net.bytebuddy.description.modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Visibility
/*     */   implements ModifierContributor.ForType, ModifierContributor.ForMethod, ModifierContributor.ForField
/*     */ {
/*  28 */   PUBLIC(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   PACKAGE_PRIVATE(0),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   PROTECTED(4),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   PRIVATE(2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int mask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Visibility(int mask) {
/*  56 */     this.mask = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMask() {
/*  63 */     return this.mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRange() {
/*  70 */     return 7;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/*  77 */     return (this == PACKAGE_PRIVATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/*  86 */     return ((this.mask & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProtected() {
/*  95 */     return ((this.mask & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPackagePrivate() {
/* 104 */     return (!isPublic() && !isPrivate() && !isProtected());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrivate() {
/* 113 */     return ((this.mask & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Visibility expandTo(Visibility visibility) {
/* 123 */     switch (visibility) {
/*     */       case PUBLIC:
/* 125 */         return PUBLIC;
/*     */       case PROTECTED:
/* 127 */         return (this == PUBLIC) ? PUBLIC : visibility;
/*     */ 
/*     */       
/*     */       case PACKAGE_PRIVATE:
/* 131 */         return (this == PRIVATE) ? PACKAGE_PRIVATE : this;
/*     */ 
/*     */       
/*     */       case PRIVATE:
/* 135 */         return this;
/*     */     } 
/* 137 */     throw new IllegalStateException("Unexpected visibility: " + visibility);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\modifier\Visibility.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */