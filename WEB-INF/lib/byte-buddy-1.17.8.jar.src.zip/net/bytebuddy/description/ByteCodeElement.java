/*     */ package net.bytebuddy.description;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.description.annotation.AnnotationSource;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.FilterableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ByteCodeElement
/*     */   extends NamedElement.WithRuntimeName, NamedElement.WithDescriptor, ModifierReviewable.OfByteCodeElement, DeclaredByType, AnnotationSource
/*     */ {
/*     */   boolean isVisibleTo(TypeDescription paramTypeDescription);
/*     */   
/*     */   boolean isAccessibleTo(TypeDescription paramTypeDescription);
/*     */   
/*     */   public static interface Token<T extends Token<T>>
/*     */   {
/*     */     T accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> param1Visitor);
/*     */     
/*     */     public static class TokenList<S extends Token<S>>
/*     */       extends FilterableList.AbstractBase<S, TokenList<S>>
/*     */     {
/*     */       private final List<? extends S> tokens;
/*     */       
/*     */       public TokenList(S... token) {
/* 148 */         this(Arrays.asList(token));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TokenList(List<? extends S> tokens) {
/* 157 */         this.tokens = tokens;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TokenList<S> accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 167 */         List<S> tokens = new ArrayList<S>(this.tokens.size());
/* 168 */         for (ByteCodeElement.Token<S> token : this.tokens) {
/* 169 */           tokens.add(token.accept(visitor));
/*     */         }
/* 171 */         return new TokenList(tokens);
/*     */       }
/*     */ 
/*     */       
/*     */       protected TokenList<S> wrap(List<S> values) {
/* 176 */         return new TokenList(values);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public S get(int index) {
/* 183 */         return this.tokens.get(index);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int size() {
/* 190 */         return this.tokens.size();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Member extends DeclaredByType.WithMandatoryDeclaration, ByteCodeElement, NamedElement.WithGenericName {}
/*     */   
/*     */   public static interface TypeDependant<T extends TypeDependant<?, S>, S extends Token<S>> {
/*     */     T asDefined();
/*     */     
/*     */     S asToken(ElementMatcher<? super TypeDescription> param1ElementMatcher);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\ByteCodeElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */