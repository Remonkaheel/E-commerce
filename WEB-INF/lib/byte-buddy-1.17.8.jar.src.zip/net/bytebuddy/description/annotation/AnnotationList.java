/*     */ package net.bytebuddy.description.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.FilterableList;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AnnotationList
/*     */   extends FilterableList<AnnotationDescription, AnnotationList>
/*     */ {
/*     */   boolean isAnnotationPresent(Class<? extends Annotation> paramClass);
/*     */   
/*     */   boolean isAnnotationPresent(TypeDescription paramTypeDescription);
/*     */   
/*     */   @MaybeNull
/*     */   <T extends Annotation> AnnotationDescription.Loadable<T> ofType(Class<T> paramClass);
/*     */   
/*     */   AnnotationDescription ofType(TypeDescription paramTypeDescription);
/*     */   
/*     */   AnnotationList inherited(Set<? extends TypeDescription> paramSet);
/*     */   
/*     */   AnnotationList visibility(ElementMatcher<? super RetentionPolicy> paramElementMatcher);
/*     */   
/*     */   TypeList asTypeList();
/*     */   
/*     */   List<String> asTypeNames();
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     extends FilterableList.AbstractBase<AnnotationDescription, AnnotationList>
/*     */     implements AnnotationList
/*     */   {
/*     */     public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/* 113 */       for (AnnotationDescription annotation : this) {
/* 114 */         if (annotation.getAnnotationType().represents(annotationType)) {
/* 115 */           return true;
/*     */         }
/*     */       } 
/* 118 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAnnotationPresent(TypeDescription annotationType) {
/* 125 */       for (AnnotationDescription annotation : this) {
/* 126 */         if (annotation.getAnnotationType().equals(annotationType)) {
/* 127 */           return true;
/*     */         }
/*     */       } 
/* 130 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public <T extends Annotation> AnnotationDescription.Loadable<T> ofType(Class<T> annotationType) {
/* 139 */       for (AnnotationDescription annotation : this) {
/* 140 */         if (annotation.getAnnotationType().represents(annotationType)) {
/* 141 */           return annotation.prepare(annotationType);
/*     */         }
/*     */       } 
/* 144 */       return (AnnotationDescription.Loadable)AnnotationDescription.UNDEFINED;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationDescription ofType(TypeDescription annotationType) {
/* 152 */       for (AnnotationDescription annotation : this) {
/* 153 */         if (annotation.getAnnotationType().equals(annotationType)) {
/* 154 */           return annotation;
/*     */         }
/*     */       } 
/* 157 */       return AnnotationDescription.UNDEFINED;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList inherited(Set<? extends TypeDescription> ignoredTypes) {
/* 164 */       List<AnnotationDescription> inherited = new ArrayList<AnnotationDescription>(size());
/* 165 */       for (AnnotationDescription annotation : this) {
/* 166 */         if (!ignoredTypes.contains(annotation.getAnnotationType()) && annotation.isInherited()) {
/* 167 */           inherited.add(annotation);
/*     */         }
/*     */       } 
/* 170 */       return wrap(inherited);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList visibility(ElementMatcher<? super RetentionPolicy> matcher) {
/* 177 */       List<AnnotationDescription> annotationDescriptions = new ArrayList<AnnotationDescription>(size());
/* 178 */       for (AnnotationDescription annotation : this) {
/* 179 */         if (matcher.matches(annotation.getRetention())) {
/* 180 */           annotationDescriptions.add(annotation);
/*     */         }
/*     */       } 
/* 183 */       return wrap(annotationDescriptions);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeList asTypeList() {
/* 190 */       List<TypeDescription> annotationTypes = new ArrayList<TypeDescription>(size());
/* 191 */       for (AnnotationDescription annotation : this) {
/* 192 */         annotationTypes.add(annotation.getAnnotationType());
/*     */       }
/* 194 */       return (TypeList)new TypeList.Explicit(annotationTypes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> asTypeNames() {
/* 201 */       List<String> typeNames = new ArrayList<String>(size());
/* 202 */       for (AnnotationDescription annotation : this) {
/* 203 */         typeNames.add(annotation.getAnnotationType().getName());
/*     */       }
/* 205 */       return typeNames;
/*     */     }
/*     */ 
/*     */     
/*     */     protected AnnotationList wrap(List<AnnotationDescription> values) {
/* 210 */       return new AnnotationList.Explicit(values);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedAnnotations
/*     */     extends AbstractBase
/*     */   {
/*     */     private final List<? extends Annotation> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedAnnotations(Annotation... annotation) {
/* 230 */       this(Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedAnnotations(List<? extends Annotation> annotations) {
/* 239 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static List<AnnotationList> asList(Annotation[][] annotations) {
/* 249 */       List<AnnotationList> result = new ArrayList<AnnotationList>(annotations.length);
/* 250 */       for (Annotation[] annotation : annotations) {
/* 251 */         result.add(new ForLoadedAnnotations(annotation));
/*     */       }
/* 253 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationDescription get(int index) {
/* 260 */       return AnnotationDescription.ForLoadedAnnotation.of(this.annotations.get(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 267 */       return this.annotations.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Explicit
/*     */     extends AbstractBase
/*     */   {
/*     */     private final List<? extends AnnotationDescription> annotationDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(AnnotationDescription... annotationDescription) {
/* 287 */       this(Arrays.asList(annotationDescription));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends AnnotationDescription> annotationDescriptions) {
/* 296 */       this.annotationDescriptions = annotationDescriptions;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static List<AnnotationList> asList(List<? extends List<? extends AnnotationDescription>> annotations) {
/* 306 */       List<AnnotationList> result = new ArrayList<AnnotationList>(annotations.size());
/* 307 */       for (List<? extends AnnotationDescription> annotation : annotations) {
/* 308 */         result.add(new Explicit(annotation));
/*     */       }
/* 310 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationDescription get(int index) {
/* 317 */       return this.annotationDescriptions.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 324 */       return this.annotationDescriptions.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Empty
/*     */     extends FilterableList.Empty<AnnotationDescription, AnnotationList>
/*     */     implements AnnotationList
/*     */   {
/*     */     public static List<AnnotationList> asList(int length) {
/* 340 */       List<AnnotationList> result = new ArrayList<AnnotationList>(length);
/* 341 */       for (int i = 0; i < length; i++) {
/* 342 */         result.add(new Empty());
/*     */       }
/* 344 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/* 351 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAnnotationPresent(TypeDescription annotationType) {
/* 358 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @AlwaysNull
/*     */     public <T extends Annotation> AnnotationDescription.Loadable<T> ofType(Class<T> annotationType) {
/* 367 */       return (AnnotationDescription.Loadable)AnnotationDescription.UNDEFINED;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @AlwaysNull
/*     */     public AnnotationDescription ofType(TypeDescription annotationType) {
/* 375 */       return AnnotationDescription.UNDEFINED;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList inherited(Set<? extends TypeDescription> ignoredTypes) {
/* 382 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList visibility(ElementMatcher<? super RetentionPolicy> matcher) {
/* 389 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeList asTypeList() {
/* 396 */       return (TypeList)new TypeList.Empty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<String> asTypeNames() {
/* 403 */       return Collections.emptyList();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\annotation\AnnotationList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */