/*      */ package net.bytebuddy.description.annotation;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.annotation.AnnotationTypeMismatchException;
/*      */ import java.lang.annotation.Documented;
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.lang.annotation.IncompleteAnnotationException;
/*      */ import java.lang.annotation.Inherited;
/*      */ import java.lang.annotation.Retention;
/*      */ import java.lang.annotation.RetentionPolicy;
/*      */ import java.lang.annotation.Target;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ import net.bytebuddy.utility.privilege.SetAccessibleAction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface AnnotationDescription
/*      */ {
/*      */   @AlwaysNull
/*   63 */   public static final Loadable<?> UNDEFINED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   AnnotationValue<?, ?> getValue(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   AnnotationValue<?, ?> getValue(MethodDescription.InDefinedShape paramInDefinedShape);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TypeDescription getAnnotationType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   <T extends Annotation> Loadable<T> prepare(Class<T> paramClass);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RetentionPolicy getRetention();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Set<ElementType> getElementTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isSupportedOn(ElementType paramElementType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isSupportedOn(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isInherited();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDocumented();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Loadable<S extends Annotation>
/*      */     extends AnnotationDescription
/*      */   {
/*      */     S load();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum RenderingDispatcher
/*      */   {
/*  170 */     LEGACY_VM,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     JAVA_14_CAPABLE_VM
/*      */     {
/*      */       public void appendPrefix(StringBuilder toString, String key, int count) {
/*  178 */         if (count > 1 || !key.equals("value")) {
/*  179 */           super.appendPrefix(toString, key, count);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */       }
/*      */     },
/*  187 */     JAVA_19_CAPABLE_VM
/*      */     {
/*      */       public void appendPrefix(StringBuilder toString, String key, int count) {
/*  190 */         if (count > 1 || !key.equals("value")) {
/*  191 */           super.appendPrefix(toString, key, count);
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       public void appendType(StringBuilder toString, TypeDescription typeDescription) {
/*  197 */         toString.append(typeDescription.getCanonicalName());
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final RenderingDispatcher CURRENT;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/*  210 */       ClassFileVersion classFileVersion = ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5);
/*  211 */       if (classFileVersion.isAtLeast(ClassFileVersion.JAVA_V19)) {
/*  212 */         CURRENT = JAVA_19_CAPABLE_VM;
/*  213 */       } else if (classFileVersion.isAtLeast(ClassFileVersion.JAVA_V14)) {
/*  214 */         CURRENT = JAVA_14_CAPABLE_VM;
/*      */       } else {
/*  216 */         CURRENT = LEGACY_VM;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void appendPrefix(StringBuilder toString, String key, int count) {
/*  228 */       toString.append(key).append('=');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void appendType(StringBuilder toString, TypeDescription typeDescription) {
/*  238 */       toString.append(typeDescription.getName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class AnnotationInvocationHandler<T extends Annotation>
/*      */     implements InvocationHandler
/*      */   {
/*      */     private static final String HASH_CODE = "hashCode";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String EQUALS = "equals";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String TO_STRING = "toString";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String ANNOTATION_TYPE = "annotationType";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  272 */     private static final Object[] NO_ARGUMENT = new Object[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<? extends Annotation> annotationType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final LinkedHashMap<Method, AnnotationValue.Loaded<?>> values;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected AnnotationInvocationHandler(Class<T> annotationType, LinkedHashMap<Method, AnnotationValue.Loaded<?>> values) {
/*  291 */       this.annotationType = annotationType;
/*  292 */       this.values = values;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <S extends Annotation> S of(@MaybeNull ClassLoader classLoader, Class<S> annotationType, Map<String, ? extends AnnotationValue<?, ?>> values) {
/*  308 */       LinkedHashMap<Method, AnnotationValue.Loaded<?>> loadedValues = new LinkedHashMap<Method, AnnotationValue.Loaded<?>>();
/*  309 */       for (Method method : annotationType.getDeclaredMethods()) {
/*  310 */         AnnotationValue<?, ?> annotationValue = values.get(method.getName());
/*  311 */         if (annotationValue == null) {
/*  312 */           Object defaultValue = method.getDefaultValue();
/*  313 */           loadedValues.put(method, ((defaultValue == null) ? new AnnotationValue.ForMissingValue<Object, Object>((TypeDescription)new TypeDescription.ForLoadedType(method
/*  314 */                   .getDeclaringClass()), method.getName()) : 
/*  315 */               AnnotationDescription.ForLoadedAnnotation.asValue(defaultValue, method.getReturnType())).load(classLoader));
/*      */         } else {
/*  317 */           loadedValues.put(method, annotationValue.filter((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method)).load(classLoader));
/*      */         } 
/*      */       } 
/*  320 */       return (S)Proxy.newProxyInstance(classLoader, new Class[] { annotationType }, new AnnotationInvocationHandler<S>(annotationType, loadedValues));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object invoke(Object proxy, Method method, @MaybeNull Object[] argument) {
/*  327 */       if (method.getDeclaringClass() != this.annotationType) {
/*  328 */         if (method.getName().equals("hashCode"))
/*  329 */           return Integer.valueOf(hashCodeRepresentation()); 
/*  330 */         if (method.getName().equals("equals") && (method.getParameterTypes()).length == 1)
/*  331 */           return Boolean.valueOf(equalsRepresentation(proxy, argument[0])); 
/*  332 */         if (method.getName().equals("toString"))
/*  333 */           return toStringRepresentation(); 
/*  334 */         if (method.getName().equals("annotationType")) {
/*  335 */           return this.annotationType;
/*      */         }
/*  337 */         throw new IllegalStateException("Unexpected method: " + method);
/*      */       } 
/*      */       
/*  340 */       return ((AnnotationValue.Loaded)this.values.get(method)).resolve();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected String toStringRepresentation() {
/*  349 */       StringBuilder toString = new StringBuilder();
/*  350 */       toString.append('@');
/*  351 */       AnnotationDescription.RenderingDispatcher.CURRENT.appendType(toString, TypeDescription.ForLoadedType.of(this.annotationType));
/*  352 */       toString.append('(');
/*  353 */       boolean firstMember = true;
/*  354 */       for (Map.Entry<Method, AnnotationValue.Loaded<?>> entry : this.values.entrySet()) {
/*  355 */         if (!((AnnotationValue.Loaded)entry.getValue()).getState().isDefined()) {
/*      */           continue;
/*      */         }
/*  358 */         if (firstMember) {
/*  359 */           firstMember = false;
/*      */         } else {
/*  361 */           toString.append(", ");
/*      */         } 
/*  363 */         AnnotationDescription.RenderingDispatcher.CURRENT.appendPrefix(toString, ((Method)entry.getKey()).getName(), this.values.entrySet().size());
/*  364 */         toString.append(((AnnotationValue.Loaded)entry.getValue()).toString());
/*      */       } 
/*  366 */       toString.append(')');
/*  367 */       return toString.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int hashCodeRepresentation() {
/*  376 */       int hashCode = 0;
/*  377 */       for (Map.Entry<Method, AnnotationValue.Loaded<?>> entry : this.values.entrySet()) {
/*  378 */         if (!((AnnotationValue.Loaded)entry.getValue()).getState().isDefined()) {
/*      */           continue;
/*      */         }
/*  381 */         hashCode += 127 * ((Method)entry.getKey()).getName().hashCode() ^ ((AnnotationValue.Loaded)entry.getValue()).hashCode();
/*      */       } 
/*  383 */       return hashCode;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean equalsRepresentation(Object self, Object other) {
/*  394 */       if (self == other)
/*  395 */         return true; 
/*  396 */       if (!this.annotationType.isInstance(other))
/*  397 */         return false; 
/*  398 */       if (Proxy.isProxyClass(other.getClass())) {
/*  399 */         InvocationHandler invocationHandler = Proxy.getInvocationHandler(other);
/*  400 */         if (invocationHandler instanceof AnnotationInvocationHandler) {
/*  401 */           return invocationHandler.equals(this);
/*      */         }
/*      */       } 
/*      */       try {
/*  405 */         for (Map.Entry<Method, AnnotationValue.Loaded<?>> entry : this.values.entrySet()) {
/*      */           try {
/*  407 */             if (!((AnnotationValue.Loaded)entry.getValue()).represents(((Method)entry.getKey()).invoke(other, NO_ARGUMENT))) {
/*  408 */               return false;
/*      */             }
/*  410 */           } catch (RuntimeException exception) {
/*  411 */             return false;
/*      */           } 
/*      */         } 
/*  414 */         return true;
/*  415 */       } catch (InvocationTargetException ignored) {
/*  416 */         return false;
/*  417 */       } catch (IllegalAccessException exception) {
/*  418 */         throw new IllegalStateException("Could not access annotation property", exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/*  435 */       if (this == other)
/*  436 */         return true; 
/*  437 */       if (!(other instanceof AnnotationInvocationHandler)) {
/*  438 */         return false;
/*      */       }
/*  440 */       AnnotationInvocationHandler<?> that = (AnnotationInvocationHandler)other;
/*  441 */       if (!this.annotationType.equals(that.annotationType)) {
/*  442 */         return false;
/*      */       }
/*  444 */       for (Map.Entry<Method, AnnotationValue.Loaded<?>> entry : this.values.entrySet()) {
/*  445 */         if (!((AnnotationValue.Loaded)entry.getValue()).equals(that.values.get(entry.getKey()))) {
/*  446 */           return false;
/*      */         }
/*      */       } 
/*  449 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AbstractBase
/*      */     implements AnnotationDescription
/*      */   {
/*  478 */     private static final Set<ElementType> DEFAULT_TARGET = new HashSet<ElementType>(); static {
/*  479 */       for (ElementType elementType : ElementType.values()) {
/*  480 */         if (!elementType.name().equals("TYPE_PARAMETER"))
/*  481 */           DEFAULT_TARGET.add(elementType); 
/*      */       } 
/*      */     }
/*  484 */     private static final MethodDescription.InDefinedShape RETENTION_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Retention.class)
/*  485 */       .getDeclaredMethods()
/*  486 */       .filter((ElementMatcher)ElementMatchers.named("value")))
/*  487 */       .getOnly();
/*  488 */     private static final MethodDescription.InDefinedShape TARGET_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Target.class)
/*  489 */       .getDeclaredMethods()
/*  490 */       .filter((ElementMatcher)ElementMatchers.named("value")))
/*  491 */       .getOnly();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<?, ?> getValue(String property) {
/*  498 */       MethodList<MethodDescription.InDefinedShape> candidates = (MethodList<MethodDescription.InDefinedShape>)getAnnotationType().getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named(property)
/*  499 */           .and((ElementMatcher)ElementMatchers.takesArguments(0))
/*  500 */           .and((ElementMatcher)ElementMatchers.isPublic())
/*  501 */           .and((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic())));
/*  502 */       if (candidates.size() == 1) {
/*  503 */         return getValue((MethodDescription.InDefinedShape)candidates.getOnly());
/*      */       }
/*  505 */       throw new IllegalArgumentException("Unknown property of " + getAnnotationType() + ": " + property);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RetentionPolicy getRetention() {
/*  513 */       AnnotationDescription.Loadable<Retention> retention = getAnnotationType().getDeclaredAnnotations().ofType(Retention.class);
/*  514 */       return (retention == null) ? RetentionPolicy.CLASS : (RetentionPolicy)retention
/*      */         
/*  516 */         .getValue(RETENTION_VALUE).load(ClassLoadingStrategy.BOOTSTRAP_LOADER).resolve(RetentionPolicy.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Set<ElementType> getElementTypes() {
/*  523 */       AnnotationDescription.Loadable<Target> target = getAnnotationType().getDeclaredAnnotations().ofType(Target.class);
/*  524 */       return (target == null) ? 
/*  525 */         Collections.<ElementType>unmodifiableSet(DEFAULT_TARGET) : new HashSet<ElementType>(
/*  526 */           Arrays.asList((Object[])target.getValue(TARGET_VALUE).load(ClassLoadingStrategy.BOOTSTRAP_LOADER).resolve(ElementType[].class)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSupportedOn(ElementType elementType) {
/*  533 */       return isSupportedOn(elementType.name());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSupportedOn(String elementType) {
/*  540 */       AnnotationDescription.Loadable<Target> target = getAnnotationType().getDeclaredAnnotations().ofType(Target.class);
/*  541 */       if (target == null) {
/*  542 */         if (elementType.equals("TYPE_USE")) {
/*  543 */           return true;
/*      */         }
/*  545 */         for (ElementType candidate : DEFAULT_TARGET) {
/*  546 */           if (candidate.name().equals(elementType)) {
/*  547 */             return true;
/*      */           }
/*      */         } 
/*      */       } else {
/*  551 */         for (EnumerationDescription enumerationDescription : (EnumerationDescription[])target.getValue(TARGET_VALUE).<EnumerationDescription[]>resolve((Class)EnumerationDescription[].class)) {
/*  552 */           if (enumerationDescription.getValue().equals(elementType)) {
/*  553 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/*  557 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInherited() {
/*  564 */       return getAnnotationType().getDeclaredAnnotations().isAnnotationPresent((Class)Inherited.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isDocumented() {
/*  571 */       return getAnnotationType().getDeclaredAnnotations().isAnnotationPresent((Class)Documented.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/*  586 */       if (this == other)
/*  587 */         return true; 
/*  588 */       if (!(other instanceof AnnotationDescription)) {
/*  589 */         return false;
/*      */       }
/*  591 */       AnnotationDescription annotationDescription = (AnnotationDescription)other;
/*  592 */       TypeDescription annotationType = getAnnotationType();
/*  593 */       if (!annotationDescription.getAnnotationType().equals(annotationType)) {
/*  594 */         return false;
/*      */       }
/*  596 */       for (MethodDescription.InDefinedShape methodDescription : annotationType.getDeclaredMethods()) {
/*  597 */         if (!getValue(methodDescription).equals(annotationDescription.getValue(methodDescription))) {
/*  598 */           return false;
/*      */         }
/*      */       } 
/*  601 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  606 */       TypeDescription annotationType = getAnnotationType();
/*  607 */       StringBuilder toString = (new StringBuilder()).append('@');
/*  608 */       AnnotationDescription.RenderingDispatcher.CURRENT.appendType(toString, annotationType);
/*  609 */       toString.append('(');
/*  610 */       boolean firstMember = true;
/*  611 */       for (MethodDescription.InDefinedShape methodDescription : annotationType.getDeclaredMethods()) {
/*  612 */         AnnotationValue<?, ?> value = getValue(methodDescription);
/*  613 */         if (value.getState() == AnnotationValue.State.UNDEFINED)
/*      */           continue; 
/*  615 */         if (firstMember) {
/*  616 */           firstMember = false;
/*      */         } else {
/*  618 */           toString.append(", ");
/*      */         } 
/*  620 */         AnnotationDescription.RenderingDispatcher.CURRENT.appendPrefix(toString, methodDescription.getName(), annotationType.getDeclaredMethods().size());
/*  621 */         toString.append(value);
/*      */       } 
/*  623 */       return toString.append(')').toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForLoadedAnnotation<S extends Annotation>
/*      */     extends AbstractBase
/*      */     implements Loadable<S>
/*      */   {
/*  637 */     private static final Object[] NO_ARGUMENT = new Object[0]; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final S annotation;
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<S> annotationType;
/*      */ 
/*      */ 
/*      */     
/*      */     private static final boolean ACCESS_CONTROLLER;
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForLoadedAnnotation(S annotation) {
/*  657 */       this(annotation, (Class)annotation.annotationType());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ForLoadedAnnotation(S annotation, Class<S> annotationType) {
/*  668 */       this.annotation = annotation;
/*  669 */       this.annotationType = annotationType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  681 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <U extends Annotation> AnnotationDescription.Loadable<U> of(U annotation) {
/*  692 */       return new ForLoadedAnnotation<U>(annotation);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public S load() {
/*  699 */       return (this.annotationType == this.annotation.annotationType()) ? this.annotation : 
/*      */         
/*  701 */         AnnotationDescription.AnnotationInvocationHandler.<S>of(this.annotationType.getClassLoader(), this.annotationType, asValue((Annotation)this.annotation));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static Map<String, AnnotationValue<?, ?>> asValue(Annotation annotation) {
/*  712 */       Map<String, AnnotationValue<?, ?>> annotationValues = new HashMap<String, AnnotationValue<?, ?>>();
/*  713 */       for (Method property : annotation.annotationType().getDeclaredMethods()) {
/*      */         try {
/*  715 */           annotationValues.put(property.getName(), asValue(property.invoke(annotation, NO_ARGUMENT), property.getReturnType()));
/*  716 */         } catch (InvocationTargetException exception) {
/*  717 */           Throwable cause = exception.getTargetException();
/*  718 */           if (cause instanceof TypeNotPresentException) {
/*  719 */             annotationValues.put(property.getName(), new AnnotationValue.ForMissingType<Object, Object>(((TypeNotPresentException)cause).typeName()));
/*  720 */           } else if (cause instanceof EnumConstantNotPresentException) {
/*  721 */             annotationValues.put(property.getName(), new AnnotationValue.ForEnumerationDescription.WithUnknownConstant((TypeDescription)new TypeDescription.ForLoadedType(((EnumConstantNotPresentException)cause)
/*  722 */                     .enumType()), ((EnumConstantNotPresentException)cause)
/*  723 */                   .constantName()));
/*  724 */           } else if (cause instanceof AnnotationTypeMismatchException) {
/*  725 */             annotationValues.put(property.getName(), new AnnotationValue.ForMismatchedType<Object, Object>((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(((AnnotationTypeMismatchException)cause)
/*  726 */                     .element()), ((AnnotationTypeMismatchException)cause)
/*  727 */                   .foundType()));
/*  728 */           } else if (!(cause instanceof IncompleteAnnotationException)) {
/*  729 */             throw new IllegalStateException("Cannot read " + property, cause);
/*      */           } 
/*  731 */         } catch (IllegalAccessException exception) {
/*  732 */           throw new IllegalStateException("Cannot access " + property, exception);
/*      */         } 
/*      */       } 
/*  735 */       return annotationValues;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<?, ?> asValue(Object value, Class<?> type) {
/*  748 */       if (Enum.class.isAssignableFrom(type))
/*  749 */         return AnnotationValue.ForEnumerationDescription.of((EnumerationDescription)new EnumerationDescription.ForLoadedEnumeration((Enum)value)); 
/*  750 */       if (Enum[].class.isAssignableFrom(type)) {
/*  751 */         Enum[] arrayOfEnum = (Enum[])value;
/*  752 */         EnumerationDescription[] enumerationDescription = new EnumerationDescription[arrayOfEnum.length];
/*  753 */         int index = 0;
/*  754 */         for (Enum<?> anElement : arrayOfEnum) {
/*  755 */           enumerationDescription[index++] = (EnumerationDescription)new EnumerationDescription.ForLoadedEnumeration(anElement);
/*      */         }
/*  757 */         return AnnotationValue.ForDescriptionArray.of(TypeDescription.ForLoadedType.of(type.getComponentType()), enumerationDescription);
/*  758 */       }  if (Annotation.class.isAssignableFrom(type))
/*  759 */         return AnnotationValue.ForAnnotationDescription.of(TypeDescription.ForLoadedType.of(type), asValue((Annotation)value)); 
/*  760 */       if (Annotation[].class.isAssignableFrom(type)) {
/*  761 */         Annotation[] element = (Annotation[])value;
/*  762 */         AnnotationDescription[] annotationDescription = new AnnotationDescription[element.length];
/*  763 */         int index = 0;
/*  764 */         for (Annotation anElement : element) {
/*  765 */           annotationDescription[index++] = new AnnotationDescription.Latent(TypeDescription.ForLoadedType.of(type.getComponentType()), asValue(anElement));
/*      */         }
/*  767 */         return AnnotationValue.ForDescriptionArray.of(TypeDescription.ForLoadedType.of(type.getComponentType()), annotationDescription);
/*  768 */       }  if (Class.class.isAssignableFrom(type))
/*  769 */         return AnnotationValue.ForTypeDescription.of(TypeDescription.ForLoadedType.of((Class)value)); 
/*  770 */       if (Class[].class.isAssignableFrom(type)) {
/*  771 */         Class<?>[] element = (Class[])value;
/*  772 */         TypeDescription[] typeDescription = new TypeDescription[element.length];
/*  773 */         int index = 0;
/*  774 */         for (Class<?> anElement : element) {
/*  775 */           typeDescription[index++] = TypeDescription.ForLoadedType.of(anElement);
/*      */         }
/*  777 */         return AnnotationValue.ForDescriptionArray.of(typeDescription);
/*      */       } 
/*  779 */       return AnnotationValue.ForConstant.of(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should always be wrapped for clarity.")
/*      */     public AnnotationValue<?, ?> getValue(MethodDescription.InDefinedShape property) {
/*  789 */       if (!property.getDeclaringType().represents(this.annotation.annotationType())) {
/*  790 */         throw new IllegalArgumentException(property + " does not represent " + this.annotation.annotationType());
/*      */       }
/*      */       try {
/*  793 */         boolean accessible = property.getDeclaringType().isPublic();
/*      */         
/*  795 */         Method method = (property instanceof MethodDescription.ForLoadedMethod) ? ((MethodDescription.ForLoadedMethod)property).getLoadedMethod() : null;
/*      */         
/*  797 */         if (method == null || method.getDeclaringClass() != this.annotation.annotationType() || (!accessible && !method.isAccessible())) {
/*  798 */           method = this.annotation.annotationType().getMethod(property.getName(), new Class[0]);
/*  799 */           if (!accessible) {
/*  800 */             doPrivileged((PrivilegedAction<?>)new SetAccessibleAction(method));
/*      */           }
/*      */         } 
/*  803 */         return asValue(method.invoke(this.annotation, NO_ARGUMENT), method.getReturnType()).filter(property);
/*  804 */       } catch (InvocationTargetException exception) {
/*  805 */         Throwable cause = exception.getTargetException();
/*  806 */         if (cause instanceof TypeNotPresentException)
/*  807 */           return new AnnotationValue.ForMissingType<Object, Object>(((TypeNotPresentException)cause).typeName()); 
/*  808 */         if (cause instanceof EnumConstantNotPresentException)
/*  809 */           return new AnnotationValue.ForEnumerationDescription.WithUnknownConstant((TypeDescription)new TypeDescription.ForLoadedType(((EnumConstantNotPresentException)cause)
/*  810 */                 .enumType()), ((EnumConstantNotPresentException)cause)
/*  811 */               .constantName()); 
/*  812 */         if (cause instanceof AnnotationTypeMismatchException)
/*  813 */           return new AnnotationValue.ForMismatchedType<Object, Object>((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(((AnnotationTypeMismatchException)cause)
/*  814 */                 .element()), ((AnnotationTypeMismatchException)cause)
/*  815 */               .foundType()); 
/*  816 */         if (cause instanceof IncompleteAnnotationException) {
/*  817 */           return new AnnotationValue.ForMissingValue<Object, Object>((TypeDescription)new TypeDescription.ForLoadedType(((IncompleteAnnotationException)cause)
/*  818 */                 .annotationType()), ((IncompleteAnnotationException)cause)
/*  819 */               .elementName());
/*      */         }
/*  821 */         throw new IllegalStateException("Error reading annotation property " + property, cause);
/*      */       }
/*  823 */       catch (Exception exception) {
/*  824 */         throw new IllegalStateException("Cannot access annotation property " + property, exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T extends Annotation> AnnotationDescription.Loadable<T> prepare(Class<T> annotationType) {
/*  833 */       if (!this.annotation.annotationType().getName().equals(annotationType.getName())) {
/*  834 */         throw new IllegalArgumentException(annotationType + " does not represent " + this.annotation.annotationType());
/*      */       }
/*  836 */       return (annotationType == this.annotation.annotationType()) ? this : new ForLoadedAnnotation(this.annotation, annotationType);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getAnnotationType() {
/*  845 */       return TypeDescription.ForLoadedType.of(this.annotation.annotationType());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Latent
/*      */     extends AbstractBase
/*      */   {
/*      */     private final TypeDescription annotationType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Map<String, ? extends AnnotationValue<?, ?>> annotationValues;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Latent(TypeDescription annotationType, Map<String, ? extends AnnotationValue<?, ?>> annotationValues) {
/*  871 */       this.annotationType = annotationType;
/*  872 */       this.annotationValues = annotationValues;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<?, ?> getValue(MethodDescription.InDefinedShape property) {
/*  879 */       if (!property.getDeclaringType().equals(this.annotationType)) {
/*  880 */         throw new IllegalArgumentException("Not a property of " + this.annotationType + ": " + property);
/*      */       }
/*  882 */       AnnotationValue<?, ?> value = this.annotationValues.get(property.getName());
/*  883 */       if (value != null) {
/*  884 */         return value.filter(property);
/*      */       }
/*  886 */       AnnotationValue<?, ?> defaultValue = property.getDefaultValue();
/*  887 */       return (defaultValue == null) ? new AnnotationValue.ForMissingValue<Object, Object>(this.annotationType, property
/*  888 */           .getName()) : defaultValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getAnnotationType() {
/*  896 */       return this.annotationType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T extends Annotation> Loadable<T> prepare(Class<T> annotationType) {
/*  903 */       if (!this.annotationType.represents(annotationType)) {
/*  904 */         throw new IllegalArgumentException(annotationType + " does not represent " + this.annotationType);
/*      */       }
/*  906 */       return new Loadable<T>(annotationType);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected class Loadable<S extends Annotation>
/*      */       extends AnnotationDescription.AbstractBase
/*      */       implements AnnotationDescription.Loadable<S>
/*      */     {
/*      */       private final Class<S> annotationType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Loadable(Class<S> annotationType) {
/*  927 */         this.annotationType = annotationType;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public S load() {
/*  934 */         return AnnotationDescription.AnnotationInvocationHandler.of(this.annotationType.getClassLoader(), this.annotationType, AnnotationDescription.Latent.this.annotationValues);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue<?, ?> getValue(MethodDescription.InDefinedShape property) {
/*  941 */         return AnnotationDescription.Latent.this.getValue(property);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription getAnnotationType() {
/*  948 */         return TypeDescription.ForLoadedType.of(this.annotationType);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public <T extends Annotation> AnnotationDescription.Loadable<T> prepare(Class<T> annotationType) {
/*  955 */         return AnnotationDescription.Latent.this.prepare(annotationType);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Builder
/*      */   {
/*      */     private final TypeDescription annotationType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Map<String, AnnotationValue<?, ?>> annotationValues;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Builder(TypeDescription annotationType, Map<String, AnnotationValue<?, ?>> annotationValues) {
/*  983 */       this.annotationType = annotationType;
/*  984 */       this.annotationValues = annotationValues;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Builder ofType(Class<? extends Annotation> annotationType) {
/*  994 */       return ofType(TypeDescription.ForLoadedType.of(annotationType));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Builder ofType(TypeDescription annotationType) {
/* 1004 */       if (!annotationType.isAnnotation()) {
/* 1005 */         throw new IllegalArgumentException("Not an annotation type: " + annotationType);
/*      */       }
/* 1007 */       return new Builder(annotationType, Collections.emptyMap());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, AnnotationValue<?, ?> value) {
/* 1018 */       MethodList<MethodDescription.InDefinedShape> methodDescriptions = (MethodList<MethodDescription.InDefinedShape>)this.annotationType.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named(property));
/* 1019 */       if (methodDescriptions.isEmpty()) {
/* 1020 */         throw new IllegalArgumentException(this.annotationType + " does not define a property named " + property);
/*      */       }
/* 1022 */       Map<String, AnnotationValue<?, ?>> annotationValues = new HashMap<String, AnnotationValue<?, ?>>(this.annotationValues);
/* 1023 */       if (annotationValues.put(((MethodDescription.InDefinedShape)methodDescriptions.getOnly()).getName(), value) != null) {
/* 1024 */         throw new IllegalArgumentException("Property already defined: " + property);
/*      */       }
/* 1026 */       return new Builder(this.annotationType, annotationValues);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, Enum<?> value) {
/* 1037 */       return define(property, (EnumerationDescription)new EnumerationDescription.ForLoadedEnumeration(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, TypeDescription enumerationType, String value) {
/* 1049 */       return define(property, (EnumerationDescription)new EnumerationDescription.Latent(enumerationType, value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, EnumerationDescription value) {
/* 1061 */       return define(property, AnnotationValue.ForEnumerationDescription.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, Annotation annotation) {
/* 1072 */       return define(property, new AnnotationDescription.ForLoadedAnnotation<Annotation>(annotation));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, AnnotationDescription annotationDescription) {
/* 1083 */       return define(property, new AnnotationValue.ForAnnotationDescription(annotationDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, Class<?> type) {
/* 1094 */       return define(property, TypeDescription.ForLoadedType.of(type));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, TypeDescription typeDescription) {
/* 1106 */       return define(property, AnnotationValue.ForTypeDescription.of(typeDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T extends Enum<?>> Builder defineEnumerationArray(String property, Class<T> enumerationType, T... value) {
/* 1120 */       EnumerationDescription[] enumerationDescription = new EnumerationDescription[value.length];
/* 1121 */       int index = 0;
/* 1122 */       for (T aValue : value) {
/* 1123 */         enumerationDescription[index++] = (EnumerationDescription)new EnumerationDescription.ForLoadedEnumeration((Enum)aValue);
/*      */       }
/* 1125 */       return defineEnumerationArray(property, TypeDescription.ForLoadedType.of(enumerationType), enumerationDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineEnumerationArray(String property, TypeDescription enumerationType, String... value) {
/* 1137 */       if (!enumerationType.isEnum()) {
/* 1138 */         throw new IllegalArgumentException("Not an enumeration type: " + enumerationType);
/*      */       }
/* 1140 */       EnumerationDescription[] enumerationDescription = new EnumerationDescription[value.length];
/* 1141 */       for (int i = 0; i < value.length; i++) {
/* 1142 */         enumerationDescription[i] = (EnumerationDescription)new EnumerationDescription.Latent(enumerationType, value[i]);
/*      */       }
/* 1144 */       return defineEnumerationArray(property, enumerationType, enumerationDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineEnumerationArray(String property, TypeDescription enumerationType, EnumerationDescription... value) {
/* 1157 */       return define(property, AnnotationValue.ForDescriptionArray.of(enumerationType, value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T extends Annotation> Builder defineAnnotationArray(String property, Class<T> annotationType, T... annotation) {
/* 1171 */       return defineAnnotationArray(property, 
/* 1172 */           TypeDescription.ForLoadedType.of(annotationType), (AnnotationDescription[])(new AnnotationList.ForLoadedAnnotations((Annotation[])annotation))
/* 1173 */           .toArray((Object[])new AnnotationDescription[0]));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineAnnotationArray(String property, TypeDescription annotationType, AnnotationDescription... annotationDescription) {
/* 1185 */       return define(property, AnnotationValue.ForDescriptionArray.of(annotationType, annotationDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineTypeArray(String property, Class<?>... type) {
/* 1196 */       return defineTypeArray(property, (TypeDescription[])(new TypeList.ForLoadedTypes(type)).toArray((Object[])new TypeDescription[0]));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineTypeArray(String property, TypeDescription... typeDescription) {
/* 1207 */       return define(property, AnnotationValue.ForDescriptionArray.of(typeDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, boolean value) {
/* 1218 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, byte value) {
/* 1229 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, char value) {
/* 1240 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, short value) {
/* 1251 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, int value) {
/* 1262 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, long value) {
/* 1273 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, float value) {
/* 1284 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, double value) {
/* 1295 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder define(String property, String value) {
/* 1306 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, boolean... value) {
/* 1317 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, byte... value) {
/* 1328 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, char... value) {
/* 1339 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, short... value) {
/* 1350 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, int... value) {
/* 1361 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, long... value) {
/* 1372 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, float... value) {
/* 1383 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, double... value) {
/* 1394 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder defineArray(String property, String... value) {
/* 1405 */       return define(property, AnnotationValue.ForConstant.of(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationDescription build() {
/* 1415 */       for (MethodDescription.InDefinedShape methodDescription : this.annotationType.getDeclaredMethods()) {
/* 1416 */         AnnotationValue<?, ?> annotationValue = this.annotationValues.get(methodDescription.getName());
/* 1417 */         if (annotationValue == null && methodDescription.getDefaultValue() == null)
/* 1418 */           throw new IllegalStateException("No value or default value defined for " + methodDescription.getName()); 
/* 1419 */         if (annotationValue != null && annotationValue.filter(methodDescription).getState() != AnnotationValue.State.RESOLVED) {
/* 1420 */           throw new IllegalStateException("Illegal annotation value for " + methodDescription + ": " + annotationValue);
/*      */         }
/*      */       } 
/* 1423 */       return new AnnotationDescription.Latent(this.annotationType, this.annotationValues);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationDescription build(boolean validated) {
/* 1433 */       return validated ? 
/* 1434 */         build() : new AnnotationDescription.Latent(this.annotationType, this.annotationValues);
/*      */     }
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.annotationType.equals(((Builder)param1Object).annotationType) ? false : (!!this.annotationValues.equals(((Builder)param1Object).annotationValues)))));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.annotationValues.hashCode();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\annotation\AnnotationDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */