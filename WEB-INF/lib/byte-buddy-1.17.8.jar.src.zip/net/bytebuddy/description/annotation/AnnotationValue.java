/*      */ package net.bytebuddy.description.annotation;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.annotation.AnnotationTypeMismatchException;
/*      */ import java.lang.annotation.IncompleteAnnotationException;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*      */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface AnnotationValue<T, S>
/*      */ {
/*      */   @AlwaysNull
/*   55 */   public static final AnnotationValue<?, ?> UNDEFINED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   State getState();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Sort getSort();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   AnnotationValue<T, S> filter(MethodDescription.InDefinedShape paramInDefinedShape);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   AnnotationValue<T, S> filter(MethodDescription.InDefinedShape paramInDefinedShape, TypeDefinition paramTypeDefinition);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T resolve();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   <W> W resolve(Class<? extends W> paramClass);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Loaded<S> load(@MaybeNull ClassLoader paramClassLoader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum RenderingDispatcher
/*      */   {
/*  120 */     LEGACY_VM('[', ']', true)
/*      */     {
/*      */       public String toSourceString(char value) {
/*  123 */         return Character.toString(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(long value) {
/*  128 */         return Long.toString(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(float value) {
/*  133 */         return Float.toString(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(double value) {
/*  138 */         return Double.toString(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(String value) {
/*  143 */         return value;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(TypeDescription value) {
/*  148 */         return value.toString();
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  155 */     JAVA_9_CAPABLE_VM('{', '}', true)
/*      */     {
/*      */       public String toSourceString(char value) {
/*  158 */         StringBuilder stringBuilder = (new StringBuilder()).append('\'');
/*  159 */         if (value == '\'') {
/*  160 */           stringBuilder.append("\\'");
/*      */         } else {
/*  162 */           stringBuilder.append(value);
/*      */         } 
/*  164 */         return stringBuilder.append('\'').toString();
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(long value) {
/*  169 */         return (Math.abs(value) <= 2147483647L) ? 
/*  170 */           String.valueOf(value) : (value + "L");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public String toSourceString(float value) {
/*  176 */         return (Math.abs(value) <= Float.MAX_VALUE) ? (value + "f") : (
/*      */           
/*  178 */           Float.isInfinite(value) ? ((value < 0.0F) ? "-1.0f/0.0f" : "1.0f/0.0f") : "0.0f/0.0f");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(double value) {
/*  183 */         return (Math.abs(value) <= Double.MAX_VALUE) ? 
/*  184 */           Double.toString(value) : (
/*  185 */           Double.isInfinite(value) ? ((value < 0.0D) ? "-1.0/0.0" : "1.0/0.0") : "0.0/0.0");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(String value) {
/*  190 */         return "\"" + ((value.indexOf('"') == -1) ? value : value
/*      */           
/*  192 */           .replace("\"", "\\\"")) + "\"";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(TypeDescription value) {
/*  197 */         return value.getActualName() + ".class";
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  204 */     JAVA_14_CAPABLE_VM('{', '}', true)
/*      */     {
/*      */       public String toSourceString(byte value) {
/*  207 */         return "(byte)0x" + Integer.toHexString(value & 0xFF);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(char value) {
/*  212 */         StringBuilder stringBuilder = (new StringBuilder()).append('\'');
/*  213 */         if (value == '\'') {
/*  214 */           stringBuilder.append("\\'");
/*      */         } else {
/*  216 */           stringBuilder.append(value);
/*      */         } 
/*  218 */         return stringBuilder.append('\'').toString();
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(long value) {
/*  223 */         return value + "L";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(float value) {
/*  228 */         return (Math.abs(value) <= Float.MAX_VALUE) ? (value + "f") : (
/*      */           
/*  230 */           Float.isInfinite(value) ? ((value < 0.0F) ? "-1.0f/0.0f" : "1.0f/0.0f") : "0.0f/0.0f");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(double value) {
/*  235 */         return (Math.abs(value) <= Double.MAX_VALUE) ? 
/*  236 */           Double.toString(value) : (
/*  237 */           Double.isInfinite(value) ? ((value < 0.0D) ? "-1.0/0.0" : "1.0/0.0") : "0.0/0.0");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(String value) {
/*  242 */         return "\"" + ((value.indexOf('"') == -1) ? value : value
/*      */           
/*  244 */           .replace("\"", "\\\"")) + "\"";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(TypeDescription value) {
/*  249 */         return value.getActualName() + ".class";
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  256 */     JAVA_17_CAPABLE_VM('{', '}', false)
/*      */     {
/*      */       public String toSourceString(byte value) {
/*  259 */         return "(byte)0x" + Integer.toHexString(value & 0xFF);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(char value) {
/*  264 */         StringBuilder stringBuilder = (new StringBuilder()).append('\'');
/*  265 */         if (value == '\'') {
/*  266 */           stringBuilder.append("\\'");
/*      */         } else {
/*  268 */           stringBuilder.append(value);
/*      */         } 
/*  270 */         return stringBuilder.append('\'').toString();
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(long value) {
/*  275 */         return value + "L";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(float value) {
/*  280 */         return (Math.abs(value) <= Float.MAX_VALUE) ? (value + "f") : (
/*      */           
/*  282 */           Float.isInfinite(value) ? ((value < 0.0F) ? "-1.0f/0.0f" : "1.0f/0.0f") : "0.0f/0.0f");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(double value) {
/*  287 */         return (Math.abs(value) <= Double.MAX_VALUE) ? 
/*  288 */           Double.toString(value) : (
/*  289 */           Double.isInfinite(value) ? ((value < 0.0D) ? "-1.0/0.0" : "1.0/0.0") : "0.0/0.0");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(String value) {
/*  294 */         return "\"" + ((value.indexOf('"') == -1) ? value : value
/*      */           
/*  296 */           .replace("\"", "\\\"")) + "\"";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(TypeDescription value) {
/*  301 */         return value.getActualName() + ".class";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toTypeErrorString(Class<?> type) {
/*  306 */         return type.getName();
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  313 */     JAVA_19_CAPABLE_VM('{', '}', ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isLessThan(ClassFileVersion.JAVA_V17))
/*      */     {
/*      */       public String toSourceString(byte value) {
/*  316 */         return "(byte)0x" + Integer.toHexString(value & 0xFF);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(char value) {
/*  321 */         StringBuilder stringBuilder = (new StringBuilder()).append('\'');
/*  322 */         if (value == '\'') {
/*  323 */           stringBuilder.append("\\'");
/*      */         } else {
/*  325 */           stringBuilder.append(value);
/*      */         } 
/*  327 */         return stringBuilder.append('\'').toString();
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(long value) {
/*  332 */         return value + "L";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(float value) {
/*  337 */         return (Math.abs(value) <= Float.MAX_VALUE) ? (value + "f") : (
/*      */           
/*  339 */           Float.isInfinite(value) ? ((value < 0.0F) ? "-1.0f/0.0f" : "1.0f/0.0f") : "0.0f/0.0f");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(double value) {
/*  344 */         return (Math.abs(value) <= Double.MAX_VALUE) ? 
/*  345 */           Double.toString(value) : (
/*  346 */           Double.isInfinite(value) ? ((value < 0.0D) ? "-1.0/0.0" : "1.0/0.0") : "0.0/0.0");
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(String value) {
/*  351 */         return "\"" + ((value.indexOf('"') == -1) ? value : value
/*      */           
/*  353 */           .replace("\"", "\\\"")) + "\"";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toSourceString(TypeDescription value) {
/*  358 */         return value.getCanonicalName() + ".class";
/*      */       }
/*      */ 
/*      */       
/*      */       public String toTypeErrorString(Class<?> type) {
/*  363 */         return type.getName();
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String ARRAY_PREFIX = "Array with component tag: ";
/*      */     
/*      */     public static final RenderingDispatcher CURRENT;
/*      */     
/*      */     private final char openingBrace;
/*      */     
/*      */     private final char closingBrace;
/*      */     
/*      */     private final boolean componentAsInteger;
/*      */ 
/*      */     
/*      */     static {
/*  381 */       ClassFileVersion classFileVersion = ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5);
/*  382 */       if (classFileVersion.isAtLeast(ClassFileVersion.JAVA_V19)) {
/*  383 */         CURRENT = JAVA_19_CAPABLE_VM;
/*  384 */       } else if (classFileVersion.isAtLeast(ClassFileVersion.JAVA_V17)) {
/*  385 */         CURRENT = JAVA_17_CAPABLE_VM;
/*  386 */       } else if (classFileVersion.isAtLeast(ClassFileVersion.JAVA_V14)) {
/*  387 */         CURRENT = JAVA_14_CAPABLE_VM;
/*  388 */       } else if (classFileVersion.isAtLeast(ClassFileVersion.JAVA_V9)) {
/*  389 */         CURRENT = JAVA_9_CAPABLE_VM;
/*      */       } else {
/*  391 */         CURRENT = LEGACY_VM;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     RenderingDispatcher(char openingBrace, char closingBrace, boolean componentAsInteger) {
/*  418 */       this.openingBrace = openingBrace;
/*  419 */       this.closingBrace = closingBrace;
/*  420 */       this.componentAsInteger = componentAsInteger;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toSourceString(boolean value) {
/*  430 */       return Boolean.toString(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toSourceString(byte value) {
/*  440 */       return Byte.toString(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toSourceString(short value) {
/*  450 */       return Short.toString(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toSourceString(int value) {
/*  468 */       return Integer.toString(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toSourceString(List<?> values) {
/*  518 */       StringBuilder stringBuilder = (new StringBuilder()).append(this.openingBrace);
/*  519 */       boolean first = true;
/*  520 */       for (Object value : values) {
/*  521 */         if (first) {
/*  522 */           first = false;
/*      */         } else {
/*  524 */           stringBuilder.append(", ");
/*      */         } 
/*  526 */         stringBuilder.append(value);
/*      */       } 
/*  528 */       return stringBuilder.append(this.closingBrace).toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toArrayErrorString(AnnotationValue.Sort sort) {
/*  538 */       return "Array with component tag: " + ((this.componentAsInteger || !sort.isDefined()) ? 
/*  539 */         Integer.toString(sort.getTag()) : 
/*  540 */         Character.toString((char)sort.getTag()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toTypeErrorString(Class<?> type) {
/*  550 */       return type.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract String toSourceString(char param1Char);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract String toSourceString(long param1Long);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract String toSourceString(float param1Float);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract String toSourceString(double param1Double);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract String toSourceString(String param1String);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract String toSourceString(TypeDescription param1TypeDescription);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Loaded<U>
/*      */   {
/*      */     AnnotationValue.State getState();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     U resolve();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <V> V resolve(Class<? extends V> param1Class);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean represents(Object param1Object);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static abstract class AbstractBase<W>
/*      */       implements Loaded<W>
/*      */     {
/*      */       public <X> X resolve(Class<? extends X> type) {
/*  621 */         return type.cast(resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class ForUnresolvedProperty<Z>
/*      */         extends AbstractBase<Z>
/*      */       {
/*      */         public AnnotationValue.State getState() {
/*  635 */           return AnnotationValue.State.UNRESOLVED;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean represents(Object value) {
/*  642 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum State
/*      */   {
/*  657 */     UNDEFINED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  663 */     UNRESOLVED,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  668 */     RESOLVED;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isDefined() {
/*  677 */       return (this != UNDEFINED);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isResolved() {
/*  687 */       return (this == RESOLVED);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Sort
/*      */   {
/*  699 */     BOOLEAN(90),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  704 */     BYTE(66),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  709 */     SHORT(83),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  714 */     CHARACTER(67),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  719 */     INTEGER(73),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  724 */     LONG(74),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  729 */     FLOAT(70),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  734 */     DOUBLE(68),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  739 */     STRING(115),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  744 */     TYPE(99),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  749 */     ENUMERATION(101),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  754 */     ANNOTATION(64),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  759 */     ARRAY(91),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  764 */     NONE(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int tag;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Sort(int tag) {
/*  777 */       this.tag = tag;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Sort of(TypeDefinition typeDefinition) {
/*  787 */       if (typeDefinition.represents(boolean.class))
/*  788 */         return BOOLEAN; 
/*  789 */       if (typeDefinition.represents(byte.class))
/*  790 */         return BYTE; 
/*  791 */       if (typeDefinition.represents(short.class))
/*  792 */         return SHORT; 
/*  793 */       if (typeDefinition.represents(char.class))
/*  794 */         return CHARACTER; 
/*  795 */       if (typeDefinition.represents(int.class))
/*  796 */         return INTEGER; 
/*  797 */       if (typeDefinition.represents(long.class))
/*  798 */         return LONG; 
/*  799 */       if (typeDefinition.represents(float.class))
/*  800 */         return FLOAT; 
/*  801 */       if (typeDefinition.represents(double.class))
/*  802 */         return DOUBLE; 
/*  803 */       if (typeDefinition.represents(String.class))
/*  804 */         return STRING; 
/*  805 */       if (typeDefinition.represents(Class.class))
/*  806 */         return TYPE; 
/*  807 */       if (typeDefinition.isEnum())
/*  808 */         return ENUMERATION; 
/*  809 */       if (typeDefinition.isAnnotation())
/*  810 */         return ANNOTATION; 
/*  811 */       if (typeDefinition.isArray()) {
/*  812 */         return ARRAY;
/*      */       }
/*  814 */       return NONE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected int getTag() {
/*  824 */       return this.tag;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isDefined() {
/*  833 */       return (this != NONE);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AbstractBase<U, V>
/*      */     implements AnnotationValue<U, V>
/*      */   {
/*      */     public <W> W resolve(Class<? extends W> type) {
/*  849 */       return type.cast(resolve());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<U, V> filter(MethodDescription.InDefinedShape property) {
/*  856 */       return filter(property, (TypeDefinition)property.getReturnType());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForConstant<U>
/*      */     extends AbstractBase<U, U>
/*      */   {
/*      */     private final U value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final PropertyDelegate propertyDelegate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForConstant(U value, PropertyDelegate propertyDelegate) {
/*  884 */       this.value = value;
/*  885 */       this.propertyDelegate = propertyDelegate;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Boolean, Boolean> of(boolean value) {
/*  895 */       return new ForConstant<Boolean>(Boolean.valueOf(value), PropertyDelegate.ForNonArrayType.BOOLEAN);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Byte, Byte> of(byte value) {
/*  905 */       return new ForConstant<Byte>(Byte.valueOf(value), PropertyDelegate.ForNonArrayType.BYTE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Short, Short> of(short value) {
/*  915 */       return new ForConstant<Short>(Short.valueOf(value), PropertyDelegate.ForNonArrayType.SHORT);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Character, Character> of(char value) {
/*  925 */       return new ForConstant<Character>(Character.valueOf(value), PropertyDelegate.ForNonArrayType.CHARACTER);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Integer, Integer> of(int value) {
/*  935 */       return new ForConstant<Integer>(Integer.valueOf(value), PropertyDelegate.ForNonArrayType.INTEGER);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Long, Long> of(long value) {
/*  945 */       return new ForConstant<Long>(Long.valueOf(value), PropertyDelegate.ForNonArrayType.LONG);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Float, Float> of(float value) {
/*  955 */       return new ForConstant<Float>(Float.valueOf(value), PropertyDelegate.ForNonArrayType.FLOAT);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<Double, Double> of(double value) {
/*  965 */       return new ForConstant<Double>(Double.valueOf(value), PropertyDelegate.ForNonArrayType.DOUBLE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<String, String> of(String value) {
/*  975 */       return new ForConstant<String>(value, PropertyDelegate.ForNonArrayType.STRING);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<boolean[], boolean[]> of(boolean... value) {
/*  985 */       return (AnnotationValue)new ForConstant<boolean>(value, PropertyDelegate.ForArrayType.BOOLEAN);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<byte[], byte[]> of(byte... value) {
/*  995 */       return (AnnotationValue)new ForConstant<byte>(value, PropertyDelegate.ForArrayType.BYTE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<short[], short[]> of(short... value) {
/* 1005 */       return (AnnotationValue)new ForConstant<short>(value, PropertyDelegate.ForArrayType.SHORT);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<char[], char[]> of(char... value) {
/* 1015 */       return (AnnotationValue)new ForConstant<char>(value, PropertyDelegate.ForArrayType.CHARACTER);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<int[], int[]> of(int... value) {
/* 1025 */       return (AnnotationValue)new ForConstant<int>(value, PropertyDelegate.ForArrayType.INTEGER);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<long[], long[]> of(long... value) {
/* 1035 */       return (AnnotationValue)new ForConstant<long>(value, PropertyDelegate.ForArrayType.LONG);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<float[], float[]> of(float... value) {
/* 1045 */       return (AnnotationValue)new ForConstant<float>(value, PropertyDelegate.ForArrayType.FLOAT);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<double[], double[]> of(double... value) {
/* 1055 */       return (AnnotationValue)new ForConstant<double>(value, PropertyDelegate.ForArrayType.DOUBLE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<String[], String[]> of(String... value) {
/* 1065 */       return (AnnotationValue)new ForConstant<String>(value, PropertyDelegate.ForArrayType.STRING);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<?, ?> of(Object value) {
/* 1077 */       if (value instanceof Boolean)
/* 1078 */         return of(((Boolean)value).booleanValue()); 
/* 1079 */       if (value instanceof Byte)
/* 1080 */         return of(((Byte)value).byteValue()); 
/* 1081 */       if (value instanceof Short)
/* 1082 */         return of(((Short)value).shortValue()); 
/* 1083 */       if (value instanceof Character)
/* 1084 */         return of(((Character)value).charValue()); 
/* 1085 */       if (value instanceof Integer)
/* 1086 */         return of(((Integer)value).intValue()); 
/* 1087 */       if (value instanceof Long)
/* 1088 */         return of(((Long)value).longValue()); 
/* 1089 */       if (value instanceof Float)
/* 1090 */         return of(((Float)value).floatValue()); 
/* 1091 */       if (value instanceof Double)
/* 1092 */         return of(((Double)value).doubleValue()); 
/* 1093 */       if (value instanceof String)
/* 1094 */         return of((String)value); 
/* 1095 */       if (value instanceof boolean[])
/* 1096 */         return of((boolean[])value); 
/* 1097 */       if (value instanceof byte[])
/* 1098 */         return of((byte[])value); 
/* 1099 */       if (value instanceof short[])
/* 1100 */         return of((short[])value); 
/* 1101 */       if (value instanceof char[])
/* 1102 */         return of((char[])value); 
/* 1103 */       if (value instanceof int[])
/* 1104 */         return of((int[])value); 
/* 1105 */       if (value instanceof long[])
/* 1106 */         return of((long[])value); 
/* 1107 */       if (value instanceof float[])
/* 1108 */         return of((float[])value); 
/* 1109 */       if (value instanceof double[])
/* 1110 */         return of((double[])value); 
/* 1111 */       if (value instanceof String[]) {
/* 1112 */         return of((String[])value);
/*      */       }
/* 1114 */       throw new IllegalArgumentException("Not a constant annotation value: " + value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 1122 */       return AnnotationValue.State.RESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 1129 */       return AnnotationValue.Sort.of((TypeDefinition)TypeDescription.ForLoadedType.of(this.value.getClass()).asUnboxed());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<U, U> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 1136 */       if (typeDefinition.asErasure().asBoxed().represents(this.value.getClass()))
/* 1137 */         return this; 
/* 1138 */       if (this.value.getClass().isArray())
/* 1139 */         return new AnnotationValue.ForMismatchedType<U, U>(property, AnnotationValue.RenderingDispatcher.CURRENT.toArrayErrorString(AnnotationValue.Sort.of((TypeDefinition)TypeDescription.ForLoadedType.of(this.value.getClass().getComponentType())))); 
/* 1140 */       if (this.value instanceof Enum) {
/* 1141 */         return new AnnotationValue.ForMismatchedType<U, U>(property, this.value.getClass().getName() + '.' + ((Enum)this.value).name());
/*      */       }
/* 1143 */       return new AnnotationValue.ForMismatchedType<U, U>(property, AnnotationValue.RenderingDispatcher.CURRENT.toTypeErrorString(this.value.getClass()) + '[' + this.value + ']');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public U resolve() {
/* 1151 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<U> load(@MaybeNull ClassLoader classLoader) {
/* 1158 */       return new Loaded<U>(this.value, this.propertyDelegate);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 1169 */       return (this == other || (other instanceof AnnotationValue && this.propertyDelegate.equals(this.value, ((AnnotationValue)other).resolve())));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1174 */       return this.propertyDelegate.toString(this.value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum ForNonArrayType
/*      */       implements PropertyDelegate
/*      */     {
/* 1224 */       BOOLEAN
/*      */       {
/*      */         public String toString(Object value) {
/* 1227 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Boolean)value).booleanValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1234 */       BYTE
/*      */       {
/*      */         public String toString(Object value) {
/* 1237 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Byte)value).byteValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1244 */       SHORT
/*      */       {
/*      */         public String toString(Object value) {
/* 1247 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Short)value).shortValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1254 */       CHARACTER
/*      */       {
/*      */         public String toString(Object value) {
/* 1257 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Character)value).charValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1264 */       INTEGER
/*      */       {
/*      */         public String toString(Object value) {
/* 1267 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Integer)value).intValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1274 */       LONG
/*      */       {
/*      */         public String toString(Object value) {
/* 1277 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Long)value).longValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1284 */       FLOAT
/*      */       {
/*      */         public String toString(Object value) {
/* 1287 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Float)value).floatValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1294 */       DOUBLE
/*      */       {
/*      */         public String toString(Object value) {
/* 1297 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Double)value).doubleValue());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1304 */       STRING
/*      */       {
/*      */         public String toString(Object value) {
/* 1307 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString((String)value);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public <S> S copy(S value) {
/* 1315 */         return value;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode(Object value) {
/* 1322 */         return value.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(Object self, Object other)
/*      */       {
/* 1329 */         return self.equals(other); } } protected static interface PropertyDelegate { <S> S copy(S param2S); int hashCode(Object param2Object); boolean equals(Object param2Object1, Object param2Object2); String toString(Object param2Object); public enum ForNonArrayType implements PropertyDelegate { BOOLEAN { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Boolean)value).booleanValue()); } }, BYTE { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Byte)value).byteValue()); } }, SHORT { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Short)value).shortValue()); } }, CHARACTER { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Character)value).charValue()); } }, INTEGER { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Integer)value).intValue()); } }, LONG { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Long)value).longValue()); } }, FLOAT { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Float)value).floatValue()); } }, DOUBLE { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(((Double)value).doubleValue()); } }, STRING { public String toString(Object value) { return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString((String)value); } }; public <S> S copy(S value) { return value; } public int hashCode(Object value) { return value.hashCode(); } public boolean equals(Object self, Object other) { return self.equals(other); }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForArrayType
/*      */         implements PropertyDelegate
/*      */       {
/* 1341 */         BOOLEAN
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1344 */             return ((boolean[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1349 */             return Arrays.hashCode((boolean[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1354 */             return (other instanceof boolean[] && Arrays.equals((boolean[])self, (boolean[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1359 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.BOOLEAN.toString(Boolean.valueOf(Array.getBoolean(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1366 */         BYTE
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1369 */             return ((byte[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1374 */             return Arrays.hashCode((byte[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1379 */             return (other instanceof byte[] && Arrays.equals((byte[])self, (byte[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1384 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.BYTE.toString(Byte.valueOf(Array.getByte(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1391 */         SHORT
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1394 */             return ((short[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1399 */             return Arrays.hashCode((short[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1404 */             return (other instanceof short[] && Arrays.equals((short[])self, (short[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1409 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.SHORT.toString(Short.valueOf(Array.getShort(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1416 */         CHARACTER
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1419 */             return ((char[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1424 */             return Arrays.hashCode((char[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1429 */             return (other instanceof char[] && Arrays.equals((char[])self, (char[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1434 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.CHARACTER.toString(Character.valueOf(Array.getChar(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1441 */         INTEGER
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1444 */             return ((int[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1449 */             return Arrays.hashCode((int[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1454 */             return (other instanceof int[] && Arrays.equals((int[])self, (int[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1459 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.INTEGER.toString(Integer.valueOf(Array.getInt(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1466 */         LONG
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1469 */             return ((long[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1474 */             return Arrays.hashCode((long[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1479 */             return (other instanceof long[] && Arrays.equals((long[])self, (long[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1484 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.LONG.toString(Long.valueOf(Array.getLong(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1491 */         FLOAT
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1494 */             return ((float[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1499 */             return Arrays.hashCode((float[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1504 */             return (other instanceof float[] && Arrays.equals((float[])self, (float[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1509 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.FLOAT.toString(Float.valueOf(Array.getFloat(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1516 */         DOUBLE
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1519 */             return ((double[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1524 */             return Arrays.hashCode((double[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1529 */             return (other instanceof double[] && Arrays.equals((double[])self, (double[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1534 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.DOUBLE.toString(Double.valueOf(Array.getDouble(array, index)));
/*      */           }
/*      */         },
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1541 */         STRING
/*      */         {
/*      */           protected Object doCopy(Object value) {
/* 1544 */             return ((String[])value).clone();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode(Object value) {
/* 1549 */             return Arrays.hashCode((Object[])value);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(Object self, Object other) {
/* 1554 */             return (other instanceof String[] && Arrays.equals((Object[])self, (Object[])other));
/*      */           }
/*      */ 
/*      */           
/*      */           protected String toString(Object array, int index) {
/* 1559 */             return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.STRING.toString(Array.get(array, index));
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public <S> S copy(S value) {
/* 1568 */           return (S)doCopy(value);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public String toString(Object value)
/*      */         {
/* 1583 */           List<String> elements = new ArrayList<String>(Array.getLength(value));
/* 1584 */           for (int index = 0; index < Array.getLength(value); index++) {
/* 1585 */             elements.add(toString(value, index));
/*      */           }
/* 1587 */           return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(elements); } protected abstract Object doCopy(Object param3Object); protected abstract String toString(Object param3Object, int param3Int); } } public enum ForArrayType implements PropertyDelegate { BOOLEAN { protected Object doCopy(Object value) { return ((boolean[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((boolean[])value); } public boolean equals(Object self, Object other) { return (other instanceof boolean[] && Arrays.equals((boolean[])self, (boolean[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.BOOLEAN.toString(Boolean.valueOf(Array.getBoolean(array, index))); } }, BYTE { protected Object doCopy(Object value) { return ((byte[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((byte[])value); } public boolean equals(Object self, Object other) { return (other instanceof byte[] && Arrays.equals((byte[])self, (byte[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.BYTE.toString(Byte.valueOf(Array.getByte(array, index))); } }, SHORT { protected Object doCopy(Object value) { return ((short[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((short[])value); } public boolean equals(Object self, Object other) { return (other instanceof short[] && Arrays.equals((short[])self, (short[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.SHORT.toString(Short.valueOf(Array.getShort(array, index))); } }, CHARACTER { protected Object doCopy(Object value) { return ((char[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((char[])value); } public boolean equals(Object self, Object other) { return (other instanceof char[] && Arrays.equals((char[])self, (char[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.CHARACTER.toString(Character.valueOf(Array.getChar(array, index))); } }, INTEGER { protected Object doCopy(Object value) { return ((int[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((int[])value); } public boolean equals(Object self, Object other) { return (other instanceof int[] && Arrays.equals((int[])self, (int[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.INTEGER.toString(Integer.valueOf(Array.getInt(array, index))); } }, LONG { protected Object doCopy(Object value) { return ((long[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((long[])value); } public boolean equals(Object self, Object other) { return (other instanceof long[] && Arrays.equals((long[])self, (long[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.LONG.toString(Long.valueOf(Array.getLong(array, index))); } }, FLOAT { protected Object doCopy(Object value) { return ((float[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((float[])value); } public boolean equals(Object self, Object other) { return (other instanceof float[] && Arrays.equals((float[])self, (float[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.FLOAT.toString(Float.valueOf(Array.getFloat(array, index))); } }, DOUBLE { protected Object doCopy(Object value) { return ((double[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((double[])value); } public boolean equals(Object self, Object other) { return (other instanceof double[] && Arrays.equals((double[])self, (double[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.DOUBLE.toString(Double.valueOf(Array.getDouble(array, index))); } }, STRING { protected Object doCopy(Object value) { return ((String[])value).clone(); } public int hashCode(Object value) { return Arrays.hashCode((Object[])value); } public boolean equals(Object self, Object other) { return (other instanceof String[] && Arrays.equals((Object[])self, (Object[])other)); } protected String toString(Object array, int index) { return AnnotationValue.ForConstant.PropertyDelegate.ForNonArrayType.STRING.toString(Array.get(array, index)); } }; public <S> S copy(S value) { return (S)doCopy(value); } public String toString(Object value) { List<String> elements = new ArrayList<String>(Array.getLength(value)); for (int index = 0; index < Array.getLength(value); index++) elements.add(toString(value, index));  return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(elements); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected abstract Object doCopy(Object param2Object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected abstract String toString(Object param2Object, int param2Int); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class Loaded<V>
/*      */       extends AnnotationValue.Loaded.AbstractBase<V>
/*      */     {
/*      */       protected Loaded(V value, AnnotationValue.ForConstant.PropertyDelegate propertyDelegate) {
/* 1625 */         this.value = value;
/* 1626 */         this.propertyDelegate = propertyDelegate;
/*      */       }
/*      */       
/*      */       private final V value;
/*      */       private final AnnotationValue.ForConstant.PropertyDelegate propertyDelegate;
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 1633 */         return AnnotationValue.State.RESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public V resolve() {
/* 1640 */         return this.propertyDelegate.copy(this.value);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean represents(Object value) {
/* 1647 */         return this.propertyDelegate.equals(this.value, value);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance("hashCode")
/*      */       public int hashCode() {}
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/* 1658 */         if (this == other)
/* 1659 */           return true; 
/* 1660 */         if (!(other instanceof AnnotationValue.Loaded)) {
/* 1661 */           return false;
/*      */         }
/* 1663 */         AnnotationValue.Loaded<?> annotationValue = (AnnotationValue.Loaded)other;
/* 1664 */         return (annotationValue.getState().isResolved() && this.propertyDelegate.equals(this.value, annotationValue.resolve()));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1669 */         return this.propertyDelegate.toString(this.value);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForAnnotationDescription<U extends Annotation>
/*      */     extends AbstractBase<AnnotationDescription, U>
/*      */   {
/*      */     private final AnnotationDescription annotationDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForAnnotationDescription(AnnotationDescription annotationDescription) {
/* 1692 */       this.annotationDescription = annotationDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <V extends Annotation> AnnotationValue<AnnotationDescription, V> of(TypeDescription annotationType, Map<String, ? extends AnnotationValue<?, ?>> annotationValues) {
/* 1705 */       return new ForAnnotationDescription<V>(new AnnotationDescription.Latent(annotationType, annotationValues));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 1712 */       return AnnotationValue.State.RESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 1719 */       return AnnotationValue.Sort.ANNOTATION;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<AnnotationDescription, U> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 1726 */       return typeDefinition.asErasure().equals(this.annotationDescription.getAnnotationType()) ? this : new AnnotationValue.ForMismatchedType<AnnotationDescription, U>(property, property.getReturnType().isArray() ? AnnotationValue.RenderingDispatcher.CURRENT
/* 1727 */           .toArrayErrorString(AnnotationValue.Sort.ANNOTATION) : this.annotationDescription
/* 1728 */           .toString());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationDescription resolve() {
/* 1735 */       return this.annotationDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<U> load(@MaybeNull ClassLoader classLoader) {
/*      */       try {
/* 1744 */         return new Loaded<U>(this.annotationDescription
/* 1745 */             .<U>prepare((Class)Class.forName(this.annotationDescription.getAnnotationType().getName(), false, classLoader))
/* 1746 */             .load());
/* 1747 */       } catch (ClassNotFoundException exception) {
/* 1748 */         return new AnnotationValue.ForMissingType.Loaded<U>(this.annotationDescription.getAnnotationType().getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1754 */       return this.annotationDescription.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 1759 */       return (this == other || (other instanceof AnnotationValue && this.annotationDescription.equals(((AnnotationValue)other).resolve())));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1764 */       return this.annotationDescription.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Loaded<V extends Annotation>
/*      */       extends AnnotationValue.Loaded.AbstractBase<V>
/*      */     {
/*      */       private final V annotation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(V annotation) {
/* 1785 */         this.annotation = annotation;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 1792 */         return AnnotationValue.State.RESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public V resolve() {
/* 1799 */         return this.annotation;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean represents(Object value) {
/* 1806 */         return this.annotation.equals(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/* 1811 */         return this.annotation.hashCode();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/* 1816 */         if (this == other)
/* 1817 */           return true; 
/* 1818 */         if (!(other instanceof AnnotationValue.Loaded)) {
/* 1819 */           return false;
/*      */         }
/* 1821 */         AnnotationValue.Loaded<?> annotationValue = (AnnotationValue.Loaded)other;
/* 1822 */         return (annotationValue.getState().isResolved() && this.annotation.equals(annotationValue.resolve()));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1827 */         return this.annotation.toString();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForEnumerationDescription<U extends Enum<U>>
/*      */     extends AbstractBase<EnumerationDescription, U>
/*      */   {
/*      */     private final EnumerationDescription enumerationDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForEnumerationDescription(EnumerationDescription enumerationDescription) {
/* 1850 */       this.enumerationDescription = enumerationDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <V extends Enum<V>> AnnotationValue<EnumerationDescription, V> of(EnumerationDescription value) {
/* 1861 */       return new ForEnumerationDescription<V>(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public EnumerationDescription resolve() {
/* 1868 */       return this.enumerationDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 1875 */       return AnnotationValue.State.RESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 1882 */       return AnnotationValue.Sort.ENUMERATION;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<EnumerationDescription, U> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 1889 */       return typeDefinition.asErasure().equals(this.enumerationDescription.getEnumerationType()) ? this : new AnnotationValue.ForMismatchedType<EnumerationDescription, U>(property, property.getReturnType().isArray() ? AnnotationValue.RenderingDispatcher.CURRENT
/* 1890 */           .toArrayErrorString(AnnotationValue.Sort.ENUMERATION) : (this.enumerationDescription
/* 1891 */           .getEnumerationType().getName() + '.' + this.enumerationDescription.getValue()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<U> load(@MaybeNull ClassLoader classLoader) {
/*      */       try {
/* 1900 */         return new Loaded<U>((U)this.enumerationDescription.load(Class.forName(this.enumerationDescription.getEnumerationType().getName(), false, classLoader)));
/* 1901 */       } catch (ClassNotFoundException exception) {
/* 1902 */         return new AnnotationValue.ForMissingType.Loaded<U>(this.enumerationDescription.getEnumerationType().getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1908 */       return this.enumerationDescription.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 1913 */       return (this == other || (other instanceof AnnotationValue && this.enumerationDescription.equals(((AnnotationValue)other).resolve())));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1918 */       return this.enumerationDescription.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Loaded<V extends Enum<V>>
/*      */       extends AnnotationValue.Loaded.AbstractBase<V>
/*      */     {
/*      */       private final V enumeration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(V enumeration) {
/* 1939 */         this.enumeration = enumeration;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 1946 */         return AnnotationValue.State.RESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public V resolve() {
/* 1953 */         return this.enumeration;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean represents(Object value) {
/* 1960 */         return this.enumeration.equals(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/* 1965 */         return this.enumeration.hashCode();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/* 1970 */         if (this == other)
/* 1971 */           return true; 
/* 1972 */         if (!(other instanceof AnnotationValue.Loaded)) {
/* 1973 */           return false;
/*      */         }
/* 1975 */         AnnotationValue.Loaded<?> annotationValue = (AnnotationValue.Loaded)other;
/* 1976 */         return (annotationValue.getState().isResolved() && this.enumeration.equals(annotationValue.resolve()));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 1981 */         return this.enumeration.toString();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static class WithIncompatibleRuntimeType
/*      */         extends AnnotationValue.Loaded.AbstractBase<Enum<?>>
/*      */       {
/*      */         private final Class<?> type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public WithIncompatibleRuntimeType(Class<?> type) {
/* 2007 */           this.type = type;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public AnnotationValue.State getState() {
/* 2014 */           return AnnotationValue.State.UNRESOLVED;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enum<?> resolve() {
/* 2021 */           throw new IncompatibleClassChangeError("Not an enumeration type: " + this.type.getName());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean represents(Object value) {
/* 2028 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class WithUnknownConstant<U extends Enum<U>>
/*      */       extends AnnotationValue.AbstractBase<EnumerationDescription, U>
/*      */     {
/*      */       private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final String value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public WithUnknownConstant(TypeDescription typeDescription, String value) {
/* 2059 */         this.typeDescription = typeDescription;
/* 2060 */         this.value = value;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 2067 */         return AnnotationValue.State.UNRESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.Sort getSort() {
/* 2074 */         return AnnotationValue.Sort.NONE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue<EnumerationDescription, U> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 2081 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public EnumerationDescription resolve() {
/* 2088 */         throw new IllegalStateException(this.typeDescription + " does not declare enumeration constant " + this.value);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.Loaded<U> load(@MaybeNull ClassLoader classLoader) {
/*      */         try {
/* 2098 */           return new Loaded((Class)Class.forName(this.typeDescription.getName(), false, classLoader), this.value);
/* 2099 */         } catch (ClassNotFoundException exception) {
/* 2100 */           return new AnnotationValue.ForMissingType.Loaded<U>(this.typeDescription.getName(), exception);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public String toString() {
/* 2108 */         return this.value + " /* Warning: constant not present! */";
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static class Loaded
/*      */         extends AnnotationValue.Loaded.AbstractBase.ForUnresolvedProperty<Enum<?>>
/*      */       {
/*      */         private final Class<? extends Enum<?>> enumType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final String value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Loaded(Class<? extends Enum<?>> enumType, String value) {
/* 2133 */           this.enumType = enumType;
/* 2134 */           this.value = value;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enum<?> resolve() {
/* 2141 */           throw new EnumConstantNotPresentException(this.enumType, this.value);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public String toString() {
/* 2148 */           return this.value + " /* Warning: constant not present! */";
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForTypeDescription<U extends Class<U>>
/*      */     extends AbstractBase<TypeDescription, U>
/*      */   {
/*      */     private static final boolean NO_INITIALIZATION = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2175 */     private static final Map<TypeDescription, Class<?>> PRIMITIVE_TYPES = new HashMap<TypeDescription, Class<?>>(); private final TypeDescription typeDescription; static {
/* 2176 */       for (Class<?> type : new Class[] { boolean.class, byte.class, short.class, char.class, int.class, long.class, float.class, double.class, void.class
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })
/*      */       {
/* 2185 */         PRIMITIVE_TYPES.put(TypeDescription.ForLoadedType.of(type), type);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForTypeDescription(TypeDescription typeDescription) {
/* 2200 */       this.typeDescription = typeDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <V extends Class<V>> AnnotationValue<TypeDescription, V> of(TypeDescription typeDescription) {
/* 2211 */       return new ForTypeDescription<V>(typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 2218 */       return AnnotationValue.State.RESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 2225 */       return AnnotationValue.Sort.TYPE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<TypeDescription, U> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 2232 */       return typeDefinition.asErasure().represents(Class.class) ? this : new AnnotationValue.ForMismatchedType<TypeDescription, U>(property, property.getReturnType().isArray() ? AnnotationValue.RenderingDispatcher.CURRENT
/* 2233 */           .toArrayErrorString(AnnotationValue.Sort.TYPE) : (Class.class
/* 2234 */           .getName() + '[' + this.typeDescription.getName() + ']'));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription resolve() {
/* 2241 */       return this.typeDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<U> load(@MaybeNull ClassLoader classLoader) {
/*      */       try {
/* 2250 */         return new Loaded<U>(this.typeDescription.isPrimitive() ? (U)PRIMITIVE_TYPES
/* 2251 */             .get(this.typeDescription) : 
/* 2252 */             (U)Class.forName(this.typeDescription.getName(), false, classLoader));
/* 2253 */       } catch (ClassNotFoundException exception) {
/* 2254 */         return new AnnotationValue.ForMissingType.Loaded<U>(this.typeDescription.getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 2260 */       return this.typeDescription.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 2265 */       return (this == other || (other instanceof AnnotationValue && this.typeDescription.equals(((AnnotationValue)other).resolve())));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2270 */       return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class Loaded<U extends Class<U>>
/*      */       extends AnnotationValue.Loaded.AbstractBase<U>
/*      */     {
/*      */       private final U type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(U type) {
/* 2291 */         this.type = type;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 2298 */         return AnnotationValue.State.RESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public U resolve() {
/* 2305 */         return this.type;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean represents(Object value) {
/* 2312 */         return this.type.equals(value);
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/* 2317 */         return this.type.hashCode();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/* 2322 */         if (this == other)
/* 2323 */           return true; 
/* 2324 */         if (!(other instanceof AnnotationValue.Loaded)) {
/* 2325 */           return false;
/*      */         }
/* 2327 */         AnnotationValue.Loaded<?> annotationValue = (AnnotationValue.Loaded)other;
/* 2328 */         return (annotationValue.getState().isResolved() && this.type.equals(annotationValue.resolve()));
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 2333 */         return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(TypeDescription.ForLoadedType.of((Class)this.type));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForDescriptionArray<U, V>
/*      */     extends AbstractBase<U, V>
/*      */   {
/*      */     private final Class<?> unloadedComponentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription componentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends AnnotationValue<?, ?>> values;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForDescriptionArray(Class<?> unloadedComponentType, TypeDescription componentType, List<? extends AnnotationValue<?, ?>> values) {
/* 2373 */       this.unloadedComponentType = unloadedComponentType;
/* 2374 */       this.componentType = componentType;
/* 2375 */       this.values = values;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <W extends Enum<W>> AnnotationValue<EnumerationDescription[], W[]> of(TypeDescription enumerationType, EnumerationDescription[] enumerationDescription) {
/* 2388 */       List<AnnotationValue<EnumerationDescription, W>> values = new ArrayList<AnnotationValue<EnumerationDescription, W>>(enumerationDescription.length);
/* 2389 */       for (EnumerationDescription value : enumerationDescription) {
/* 2390 */         if (!value.getEnumerationType().equals(enumerationType)) {
/* 2391 */           throw new IllegalArgumentException(value + " is not of " + enumerationType);
/*      */         }
/* 2393 */         values.add(AnnotationValue.ForEnumerationDescription.of(value));
/*      */       } 
/* 2395 */       return (AnnotationValue)new ForDescriptionArray<EnumerationDescription, W>(EnumerationDescription.class, enumerationType, values);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <W extends Annotation> AnnotationValue<AnnotationDescription[], W[]> of(TypeDescription annotationType, AnnotationDescription[] annotationDescription) {
/* 2408 */       List<AnnotationValue<AnnotationDescription, W>> values = new ArrayList<AnnotationValue<AnnotationDescription, W>>(annotationDescription.length);
/* 2409 */       for (AnnotationDescription value : annotationDescription) {
/* 2410 */         if (!value.getAnnotationType().equals(annotationType)) {
/* 2411 */           throw new IllegalArgumentException(value + " is not of " + annotationType);
/*      */         }
/* 2413 */         values.add(new AnnotationValue.ForAnnotationDescription<W>(value));
/*      */       } 
/* 2415 */       return (AnnotationValue)new ForDescriptionArray<AnnotationDescription, W>(AnnotationDescription.class, annotationType, values);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static AnnotationValue<TypeDescription[], Class<?>[]> of(TypeDescription[] typeDescription) {
/* 2426 */       List<AnnotationValue<TypeDescription, Class<?>>> values = new ArrayList<AnnotationValue<TypeDescription, Class<?>>>(typeDescription.length);
/* 2427 */       for (TypeDescription value : typeDescription) {
/* 2428 */         values.add(AnnotationValue.ForTypeDescription.of(value));
/*      */       }
/* 2430 */       return (AnnotationValue)new ForDescriptionArray<TypeDescription, Class<?>>(TypeDescription.class, TypeDescription.ForLoadedType.of(Class.class), values);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 2437 */       return AnnotationValue.State.RESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 2444 */       return AnnotationValue.Sort.ARRAY;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*      */     public AnnotationValue<U, V> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 2453 */       if (typeDefinition.isArray() && typeDefinition.getComponentType().asErasure().equals(this.componentType)) {
/* 2454 */         for (AnnotationValue<?, ?> value : this.values) {
/* 2455 */           if (value.getSort() != AnnotationValue.Sort.of((TypeDefinition)this.componentType)) {
/* 2456 */             return new AnnotationValue.ForMismatchedType<U, V>(property, AnnotationValue.RenderingDispatcher.CURRENT.toArrayErrorString(value.getSort()));
/*      */           }
/* 2458 */           value = value.filter(property, typeDefinition.getComponentType());
/* 2459 */           if (value.getState() != AnnotationValue.State.RESOLVED) {
/* 2460 */             return (AnnotationValue)value;
/*      */           }
/*      */         } 
/* 2463 */         return this;
/*      */       } 
/* 2465 */       return new AnnotationValue.ForMismatchedType<U, V>(property, AnnotationValue.RenderingDispatcher.CURRENT.toArrayErrorString(AnnotationValue.Sort.of((TypeDefinition)this.componentType)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public U resolve() {
/* 2474 */       U resolved = (U)Array.newInstance(this.unloadedComponentType, this.values.size());
/* 2475 */       int index = 0;
/* 2476 */       for (AnnotationValue<?, ?> value : this.values) {
/* 2477 */         Array.set(resolved, index++, value.resolve());
/*      */       }
/* 2479 */       return resolved;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<V> load(@MaybeNull ClassLoader classLoader) {
/* 2487 */       List<AnnotationValue.Loaded<?>> values = new ArrayList<AnnotationValue.Loaded<?>>(this.values.size());
/* 2488 */       for (AnnotationValue<?, ?> value : this.values) {
/* 2489 */         values.add(value.load(classLoader));
/*      */       }
/*      */       try {
/* 2492 */         return new Loaded<V>(this.componentType.isPrimitive() ? (Class)this.unloadedComponentType : 
/*      */             
/* 2494 */             (Class)Class.forName(this.componentType.getName(), false, classLoader), values);
/* 2495 */       } catch (ClassNotFoundException exception) {
/* 2496 */         return new AnnotationValue.ForMissingType.Loaded<V>(this.componentType.getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 2512 */       if (this == other)
/* 2513 */         return true; 
/* 2514 */       if (!(other instanceof AnnotationValue)) {
/* 2515 */         return false;
/*      */       }
/* 2517 */       AnnotationValue<?, ?> annotationValue = (AnnotationValue<?, ?>)other;
/* 2518 */       Object value = annotationValue.resolve();
/* 2519 */       if (!value.getClass().isArray()) {
/* 2520 */         return false;
/*      */       }
/* 2522 */       if (this.values.size() != Array.getLength(value)) {
/* 2523 */         return false;
/*      */       }
/* 2525 */       Iterator<? extends AnnotationValue<?, ?>> iterator = this.values.iterator();
/* 2526 */       for (int index = 0; index < this.values.size(); index++) {
/* 2527 */         AnnotationValue<?, ?> self = iterator.next();
/* 2528 */         if (!self.resolve().equals(Array.get(value, index))) {
/* 2529 */           return false;
/*      */         }
/*      */       } 
/* 2532 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2537 */       return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(this.values);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class Loaded<W>
/*      */       extends AnnotationValue.Loaded.AbstractBase<W>
/*      */     {
/*      */       private final Class<W> componentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final List<AnnotationValue.Loaded<?>> values;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Loaded(Class<W> componentType, List<AnnotationValue.Loaded<?>> values) {
/* 2564 */         this.componentType = componentType;
/* 2565 */         this.values = values;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 2572 */         for (AnnotationValue.Loaded<?> value : this.values) {
/* 2573 */           if (!value.getState().isResolved()) {
/* 2574 */             return AnnotationValue.State.UNRESOLVED;
/*      */           }
/*      */         } 
/* 2577 */         return AnnotationValue.State.RESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public W resolve() {
/* 2585 */         W array = (W)Array.newInstance(this.componentType, this.values.size());
/* 2586 */         int index = 0;
/* 2587 */         for (AnnotationValue.Loaded<?> annotationValue : this.values) {
/* 2588 */           Array.set(array, index++, annotationValue.resolve());
/*      */         }
/* 2590 */         return array;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean represents(Object value) {
/* 2597 */         if (!value.getClass().isArray()) return false; 
/* 2598 */         if (value.getClass().getComponentType() != this.componentType) return false; 
/* 2599 */         if (this.values.size() != Array.getLength(value)) return false; 
/* 2600 */         Iterator<AnnotationValue.Loaded<?>> iterator = this.values.iterator();
/* 2601 */         for (int index = 0; index < Array.getLength(value); index++) {
/* 2602 */           AnnotationValue.Loaded<?> self = iterator.next();
/* 2603 */           if (!self.represents(Array.get(value, index))) {
/* 2604 */             return false;
/*      */           }
/*      */         } 
/* 2607 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance("hashCode")
/*      */       public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/* 2622 */         if (this == other)
/* 2623 */           return true; 
/* 2624 */         if (!(other instanceof AnnotationValue.Loaded)) {
/* 2625 */           return false;
/*      */         }
/* 2627 */         AnnotationValue.Loaded<?> annotationValue = (AnnotationValue.Loaded)other;
/* 2628 */         if (!annotationValue.getState().isResolved()) {
/* 2629 */           return false;
/*      */         }
/* 2631 */         Object value = annotationValue.resolve();
/* 2632 */         if (!value.getClass().isArray()) {
/* 2633 */           return false;
/*      */         }
/* 2635 */         if (this.values.size() != Array.getLength(value)) {
/* 2636 */           return false;
/*      */         }
/* 2638 */         Iterator<AnnotationValue.Loaded<?>> iterator = this.values.iterator();
/* 2639 */         for (int index = 0; index < Array.getLength(value); index++) {
/* 2640 */           AnnotationValue.Loaded<?> self = iterator.next();
/* 2641 */           if (!self.getState().isResolved() || !self.resolve().equals(Array.get(value, index))) {
/* 2642 */             return false;
/*      */           }
/*      */         } 
/* 2645 */         return true;
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 2650 */         return AnnotationValue.RenderingDispatcher.CURRENT.toSourceString(this.values);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForMissingType<U, V>
/*      */     extends AbstractBase<U, V>
/*      */   {
/*      */     private final String typeName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForMissingType(String typeName) {
/* 2674 */       this.typeName = typeName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 2681 */       return AnnotationValue.State.UNRESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 2688 */       return AnnotationValue.Sort.NONE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<U, V> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 2695 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public U resolve() {
/* 2702 */       throw new IllegalStateException("Type not found: " + this.typeName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<V> load(@MaybeNull ClassLoader classLoader) {
/* 2709 */       return new Loaded<V>(this.typeName, new ClassNotFoundException(this.typeName));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2716 */       return this.typeName + ".class /* Warning: type not present! */";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Loaded<U>
/*      */       extends AnnotationValue.Loaded.AbstractBase.ForUnresolvedProperty<U>
/*      */     {
/*      */       private final String typeName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ClassNotFoundException exception;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(String typeName, ClassNotFoundException exception) {
/* 2743 */         this.typeName = typeName;
/* 2744 */         this.exception = exception;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public U resolve() {
/* 2751 */         throw new TypeNotPresentException(this.typeName, this.exception);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 2756 */         return this.typeName + ".class /* Warning: type not present! */";
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForMismatchedType<U, V>
/*      */     extends AbstractBase<U, V>
/*      */   {
/*      */     private final MethodDescription.InDefinedShape property;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForMismatchedType(MethodDescription.InDefinedShape property, String value) {
/* 2786 */       this.property = property;
/* 2787 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 2794 */       return AnnotationValue.State.UNRESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 2801 */       return AnnotationValue.Sort.NONE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<U, V> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 2808 */       return new ForMismatchedType(property, this.value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public U resolve() {
/* 2815 */       throw new IllegalStateException(this.value + " cannot be used as value for " + this.property);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<V> load(@MaybeNull ClassLoader classLoader) {
/*      */       try {
/* 2823 */         Class<?> type = Class.forName(this.property.getDeclaringType().getName(), false, classLoader);
/*      */         try {
/* 2825 */           return new Loaded<V>(type.getMethod(this.property.getName(), new Class[0]), this.value);
/* 2826 */         } catch (NoSuchMethodException exception) {
/* 2827 */           return new AnnotationValue.ForIncompatibleType.Loaded<V>(type);
/*      */         } 
/* 2829 */       } catch (ClassNotFoundException exception) {
/* 2830 */         return new AnnotationValue.ForMissingType.Loaded<V>(this.property.getDeclaringType().getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2838 */       return "/* Warning type mismatch! \"" + this.value + "\" */";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Loaded<W>
/*      */       extends AnnotationValue.Loaded.AbstractBase.ForUnresolvedProperty<W>
/*      */     {
/*      */       private final Method property;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final String value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(Method property, String value) {
/* 2865 */         this.property = property;
/* 2866 */         this.value = value;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public W resolve() {
/* 2873 */         throw new AnnotationTypeMismatchException(this.property, this.value);
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 2878 */         return "/* Warning type mismatch! \"" + this.value + "\" */";
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForMissingValue<U, V>
/*      */     extends AbstractBase<U, V>
/*      */   {
/*      */     private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String property;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForMissingValue(TypeDescription typeDescription, String property) {
/* 2908 */       this.typeDescription = typeDescription;
/* 2909 */       this.property = property;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 2916 */       return AnnotationValue.State.UNDEFINED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 2923 */       return AnnotationValue.Sort.NONE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<U, V> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 2930 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<V> load(@MaybeNull ClassLoader classLoader) {
/*      */       try {
/* 2939 */         Class<? extends Annotation> type = (Class)Class.forName(this.typeDescription.getName(), false, classLoader);
/* 2940 */         return type.isAnnotation() ? new Loaded<V>(type, this.property) : new AnnotationValue.ForIncompatibleType.Loaded<V>(type);
/*      */       
/*      */       }
/* 2943 */       catch (ClassNotFoundException exception) {
/* 2944 */         return new AnnotationValue.ForMissingType.Loaded<V>(this.typeDescription.getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public U resolve() {
/* 2952 */       throw new IllegalStateException(this.typeDescription + " does not define " + this.property);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Loaded<W>
/*      */       extends AnnotationValue.Loaded.AbstractBase<W>
/*      */     {
/*      */       private final Class<? extends Annotation> type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final String property;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(Class<? extends Annotation> type, String property) {
/* 2981 */         this.type = type;
/* 2982 */         this.property = property;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationValue.State getState() {
/* 2989 */         return AnnotationValue.State.UNDEFINED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public W resolve() {
/* 2996 */         throw new IncompleteAnnotationException(this.type, this.property);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean represents(Object value) {
/* 3003 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForIncompatibleType<U, V>
/*      */     extends AbstractBase<U, V>
/*      */   {
/*      */     private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForIncompatibleType(TypeDescription typeDescription) {
/* 3029 */       this.typeDescription = typeDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.State getState() {
/* 3036 */       return AnnotationValue.State.UNRESOLVED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Sort getSort() {
/* 3043 */       return AnnotationValue.Sort.NONE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue<U, V> filter(MethodDescription.InDefinedShape property, TypeDefinition typeDefinition) {
/* 3050 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public U resolve() {
/* 3057 */       throw new IllegalStateException("Property is defined with an incompatible runtime type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationValue.Loaded<V> load(@MaybeNull ClassLoader classLoader) {
/*      */       try {
/* 3065 */         return new Loaded<V>(Class.forName(this.typeDescription.getName(), false, classLoader));
/* 3066 */       } catch (ClassNotFoundException exception) {
/* 3067 */         return new AnnotationValue.ForMissingType.Loaded<V>(this.typeDescription.getName(), exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 3075 */       return "/* Warning type incompatibility! \"" + this.typeDescription.getName() + "\" */";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Loaded<W>
/*      */       extends AnnotationValue.Loaded.AbstractBase.ForUnresolvedProperty<W>
/*      */     {
/*      */       private final Class<?> type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Loaded(Class<?> type) {
/* 3096 */         this.type = type;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public W resolve() {
/* 3103 */         throw new IncompatibleClassChangeError(this.type.toString());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public String toString() {
/* 3110 */         return "/* Warning type incompatibility! \"" + this.type.getName() + "\" */";
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\annotation\AnnotationValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */