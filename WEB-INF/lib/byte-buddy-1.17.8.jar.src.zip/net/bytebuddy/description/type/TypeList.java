/*      */ package net.bytebuddy.description.type;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.GenericDeclaration;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*      */ import net.bytebuddy.description.ByteCodeElement;
/*      */ import net.bytebuddy.description.TypeVariableSource;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.ParameterDescription;
/*      */ import net.bytebuddy.implementation.bytecode.StackSize;
/*      */ import net.bytebuddy.jar.asm.Type;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.FilterableList;
/*      */ import net.bytebuddy.utility.JavaConstant;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface TypeList
/*      */   extends FilterableList<TypeDescription, TypeList>
/*      */ {
/*      */   @AlwaysNull
/*   51 */   public static final TypeList UNDEFINED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @AlwaysNull
/*      */   @SuppressFBWarnings(value = {"MS_MUTABLE_ARRAY", "MS_OOI_PKGPROTECT"}, justification = "Null reference cannot be mutated.")
/*   58 */   public static final String[] NO_INTERFACES = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   String[] toInternalNames();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getStackSize();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Generic asGenericTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AbstractBase
/*      */     extends FilterableList.AbstractBase<TypeDescription, TypeList>
/*      */     implements TypeList
/*      */   {
/*      */     protected TypeList wrap(List<TypeDescription> values) {
/*   89 */       return new TypeList.Explicit(values);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getStackSize() {
/*   96 */       return StackSize.of((Collection)this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public String[] toInternalNames() {
/*  104 */       String[] internalNames = new String[size()];
/*  105 */       int i = 0;
/*  106 */       for (TypeDescription typeDescription : this) {
/*  107 */         internalNames[i++] = typeDescription.getInternalName();
/*      */       }
/*  109 */       return (internalNames.length == 0) ? NO_INTERFACES : internalNames;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic asGenericTypes() {
/*  118 */       return new TypeList.Generic.Explicit((List<? extends TypeDefinition>)this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForLoadedTypes
/*      */     extends AbstractBase
/*      */   {
/*      */     private final List<? extends Class<?>> types;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForLoadedTypes(Class<?>... type) {
/*  138 */       this(Arrays.asList(type));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForLoadedTypes(List<? extends Class<?>> types) {
/*  147 */       this.types = types;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription get(int index) {
/*  154 */       return TypeDescription.ForLoadedType.of(this.types.get(index));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  161 */       return this.types.size();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public String[] toInternalNames() {
/*  169 */       String[] internalNames = new String[this.types.size()];
/*  170 */       int i = 0;
/*  171 */       for (Class<?> type : this.types) {
/*  172 */         internalNames[i++] = Type.getInternalName(type);
/*      */       }
/*  174 */       return (internalNames.length == 0) ? NO_INTERFACES : internalNames;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Explicit
/*      */     extends AbstractBase
/*      */   {
/*      */     private final List<? extends TypeDescription> typeDescriptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Explicit(TypeDescription... typeDescription) {
/*  196 */       this(Arrays.asList(typeDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Explicit(List<? extends TypeDescription> typeDescriptions) {
/*  205 */       this.typeDescriptions = typeDescriptions;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static TypeList of(List<? extends JavaConstant> constants) {
/*  215 */       List<TypeDescription> typeDescriptions = new ArrayList<TypeDescription>(constants.size());
/*  216 */       for (JavaConstant constant : constants) {
/*  217 */         typeDescriptions.add(constant.getTypeDescription());
/*      */       }
/*  219 */       return new Explicit(typeDescriptions);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription get(int index) {
/*  226 */       return this.typeDescriptions.get(index);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  233 */       return this.typeDescriptions.size();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Empty
/*      */     extends FilterableList.Empty<TypeDescription, TypeList>
/*      */     implements TypeList
/*      */   {
/*      */     @SuppressFBWarnings(value = {"EI_EXPOSE_REP"}, justification = "Value is null")
/*      */     public String[] toInternalNames() {
/*  247 */       return NO_INTERFACES;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getStackSize() {
/*  254 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic asGenericTypes() {
/*  261 */       return new TypeList.Generic.Empty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Generic
/*      */     extends FilterableList<TypeDescription.Generic, Generic>
/*      */   {
/*      */     TypeList asErasures();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Generic asRawTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ByteCodeElement.Token.TokenList<TypeVariableToken> asTokenList(ElementMatcher<? super TypeDescription> param1ElementMatcher);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Generic accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> param1Visitor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getStackSize();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static abstract class AbstractBase
/*      */       extends FilterableList.AbstractBase<TypeDescription.Generic, Generic>
/*      */       implements Generic
/*      */     {
/*      */       protected TypeList.Generic wrap(List<TypeDescription.Generic> values) {
/*  315 */         return new TypeList.Generic.Explicit((List)values);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList.Generic accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  322 */         List<TypeDescription.Generic> visited = new ArrayList<TypeDescription.Generic>(size());
/*  323 */         for (TypeDescription.Generic typeDescription : this) {
/*  324 */           visited.add(typeDescription.accept((TypeDescription.Generic.Visitor)visitor));
/*      */         }
/*  326 */         return new TypeList.Generic.Explicit((List)visited);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ByteCodeElement.Token.TokenList<TypeVariableToken> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/*  333 */         List<TypeVariableToken> tokens = new ArrayList<TypeVariableToken>(size());
/*  334 */         for (TypeDescription.Generic typeVariable : this) {
/*  335 */           tokens.add(TypeVariableToken.of(typeVariable, matcher));
/*      */         }
/*  337 */         return new ByteCodeElement.Token.TokenList(tokens);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int getStackSize() {
/*  344 */         int stackSize = 0;
/*  345 */         for (TypeDescription.Generic typeDescription : this) {
/*  346 */           stackSize += typeDescription.getStackSize().getSize();
/*      */         }
/*  348 */         return stackSize;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList asErasures() {
/*  355 */         List<TypeDescription> typeDescriptions = new ArrayList<TypeDescription>(size());
/*  356 */         for (TypeDescription.Generic typeDescription : this) {
/*  357 */           typeDescriptions.add(typeDescription.asErasure());
/*      */         }
/*  359 */         return new TypeList.Explicit(typeDescriptions);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList.Generic asRawTypes() {
/*  366 */         List<TypeDescription.Generic> typeDescriptions = new ArrayList<TypeDescription.Generic>(size());
/*  367 */         for (TypeDescription.Generic typeDescription : this) {
/*  368 */           typeDescriptions.add(typeDescription.asRawType());
/*      */         }
/*  370 */         return new TypeList.Generic.Explicit((List)typeDescriptions);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Explicit
/*      */       extends AbstractBase
/*      */     {
/*      */       private final List<? extends TypeDefinition> typeDefinitions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Explicit(TypeDefinition... typeDefinition) {
/*  390 */         this(Arrays.asList(typeDefinition));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Explicit(List<? extends TypeDefinition> typeDefinitions) {
/*  399 */         this.typeDefinitions = typeDefinitions;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic get(int index) {
/*  406 */         return ((TypeDefinition)this.typeDefinitions.get(index)).asGenericType();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/*  413 */         return this.typeDefinitions.size();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class ForLoadedTypes
/*      */       extends AbstractBase
/*      */     {
/*      */       private final List<? extends Type> types;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForLoadedTypes(Type... type) {
/*  433 */         this(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForLoadedTypes(List<? extends Type> types) {
/*  442 */         this.types = types;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic get(int index) {
/*  449 */         return TypeDefinition.Sort.describe(this.types.get(index));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/*  456 */         return this.types.size();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static class OfTypeVariables
/*      */         extends TypeList.Generic.AbstractBase
/*      */       {
/*      */         private final List<TypeVariable<?>> typeVariables;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected OfTypeVariables(TypeVariable<?>... typeVariable) {
/*  475 */           this(Arrays.asList(typeVariable));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected OfTypeVariables(List<TypeVariable<?>> typeVariables) {
/*  484 */           this.typeVariables = typeVariables;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public static TypeList.Generic of(GenericDeclaration genericDeclaration) {
/*  494 */           return new OfTypeVariables(genericDeclaration.getTypeParameters());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription.Generic get(int index) {
/*  501 */           TypeVariable<?> typeVariable = this.typeVariables.get(index);
/*  502 */           return TypeDefinition.Sort.describe(typeVariable, new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedTypeVariable(typeVariable));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int size() {
/*  509 */           return this.typeVariables.size();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class ForDetachedTypes
/*      */       extends AbstractBase
/*      */     {
/*      */       private final List<? extends TypeDescription.Generic> detachedTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForDetachedTypes(List<? extends TypeDescription.Generic> detachedTypes, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  537 */         this.detachedTypes = detachedTypes;
/*  538 */         this.visitor = visitor;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static TypeList.Generic attachVariables(TypeDescription typeDescription, List<? extends TypeVariableToken> detachedTypeVariables) {
/*  549 */         return new OfTypeVariables(typeDescription, detachedTypeVariables, TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(typeDescription));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static TypeList.Generic attach(FieldDescription fieldDescription, List<? extends TypeDescription.Generic> detachedTypes) {
/*  560 */         return new ForDetachedTypes(detachedTypes, TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(fieldDescription));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static TypeList.Generic attach(MethodDescription methodDescription, List<? extends TypeDescription.Generic> detachedTypes) {
/*  571 */         return new ForDetachedTypes(detachedTypes, TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(methodDescription));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static TypeList.Generic attachVariables(MethodDescription methodDescription, List<? extends TypeVariableToken> detachedTypeVariables) {
/*  582 */         return new OfTypeVariables((TypeVariableSource)methodDescription, detachedTypeVariables, TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(methodDescription));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static TypeList.Generic attach(ParameterDescription parameterDescription, List<? extends TypeDescription.Generic> detachedTypes) {
/*  593 */         return new ForDetachedTypes(detachedTypes, TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(parameterDescription));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic get(int index) {
/*  600 */         return ((TypeDescription.Generic)this.detachedTypes.get(index)).<TypeDescription.Generic>accept((TypeDescription.Generic.Visitor)this.visitor);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/*  607 */         return this.detachedTypes.size();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static class WithResolvedErasure
/*      */         extends TypeList.Generic.AbstractBase
/*      */       {
/*      */         private final List<? extends TypeDescription.Generic> detachedTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public WithResolvedErasure(List<? extends TypeDescription.Generic> detachedTypes, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  634 */           this.detachedTypes = detachedTypes;
/*  635 */           this.visitor = visitor;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription.Generic get(int index) {
/*  642 */           return new TypeDescription.Generic.LazyProjection.WithResolvedErasure(this.detachedTypes.get(index), this.visitor);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int size() {
/*  649 */           return this.detachedTypes.size();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static class OfTypeVariables
/*      */         extends TypeList.Generic.AbstractBase
/*      */       {
/*      */         private final TypeVariableSource typeVariableSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final List<? extends TypeVariableToken> detachedTypeVariables;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public OfTypeVariables(TypeVariableSource typeVariableSource, List<? extends TypeVariableToken> detachedTypeVariables, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  683 */           this.typeVariableSource = typeVariableSource;
/*  684 */           this.detachedTypeVariables = detachedTypeVariables;
/*  685 */           this.visitor = visitor;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription.Generic get(int index) {
/*  692 */           return new AttachedTypeVariable(this.typeVariableSource, this.detachedTypeVariables.get(index), this.visitor);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int size() {
/*  699 */           return this.detachedTypeVariables.size();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class AttachedTypeVariable
/*      */           extends TypeDescription.Generic.OfTypeVariable
/*      */         {
/*      */           private final TypeVariableSource typeVariableSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final TypeVariableToken typeVariableToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected AttachedTypeVariable(TypeVariableSource typeVariableSource, TypeVariableToken typeVariableToken, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  732 */             this.typeVariableSource = typeVariableSource;
/*  733 */             this.typeVariableToken = typeVariableToken;
/*  734 */             this.visitor = visitor;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeList.Generic getUpperBounds() {
/*  741 */             return this.typeVariableToken.getBounds().accept(this.visitor);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeVariableSource getTypeVariableSource() {
/*  748 */             return this.typeVariableSource;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public String getSymbol() {
/*  755 */             return this.typeVariableToken.getSymbol();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public AnnotationList getDeclaredAnnotations() {
/*  762 */             return this.typeVariableToken.getAnnotations();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class OfLoadedInterfaceTypes
/*      */       extends AbstractBase
/*      */     {
/*      */       private final Class<?> type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public OfLoadedInterfaceTypes(Class<?> type) {
/*  784 */         this.type = type;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic get(int index) {
/*  791 */         return new TypeProjection(this.type, index, this.type.getInterfaces());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/*  798 */         return (this.type.getInterfaces()).length;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList asErasures() {
/*  805 */         return new TypeList.ForLoadedTypes(this.type.getInterfaces());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private static class TypeProjection
/*      */         extends TypeDescription.Generic.LazyProjection.WithLazyNavigation.OfAnnotatedElement
/*      */       {
/*      */         private final Class<?> type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Class<?>[] erasure;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private TypeProjection(Class<?> type, int index, Class<?>[] erasure) {
/*  836 */           this.type = type;
/*  837 */           this.index = index;
/*  838 */           this.erasure = erasure;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance("resolved")
/*      */         protected TypeDescription.Generic resolve() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription asErasure() {
/*  854 */           return TypeDescription.ForLoadedType.of(this.erasure[this.index]);
/*      */         }
/*      */ 
/*      */         
/*      */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  859 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedInterface(this.type, this.index);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class OfConstructorExceptionTypes
/*      */       extends AbstractBase
/*      */     {
/*      */       private final Constructor<?> constructor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public OfConstructorExceptionTypes(Constructor<?> constructor) {
/*  880 */         this.constructor = constructor;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic get(int index) {
/*  887 */         return new TypeProjection(this.constructor, index, this.constructor.getExceptionTypes());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/*  894 */         return (this.constructor.getExceptionTypes()).length;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList asErasures() {
/*  901 */         return new TypeList.ForLoadedTypes(this.constructor.getExceptionTypes());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private static class TypeProjection
/*      */         extends TypeDescription.Generic.LazyProjection.WithEagerNavigation.OfAnnotatedElement
/*      */       {
/*      */         private final Constructor<?> constructor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Class<?>[] erasure;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private TypeProjection(Constructor<?> constructor, int index, Class<?>[] erasure) {
/*  932 */           this.constructor = constructor;
/*  933 */           this.index = index;
/*  934 */           this.erasure = erasure;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance("resolved")
/*      */         protected TypeDescription.Generic resolve() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription asErasure() {
/*  950 */           return TypeDescription.ForLoadedType.of(this.erasure[this.index]);
/*      */         }
/*      */ 
/*      */         
/*      */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  955 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedExecutableExceptionType(this.constructor, this.index);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class OfMethodExceptionTypes
/*      */       extends AbstractBase
/*      */     {
/*      */       private final Method method;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public OfMethodExceptionTypes(Method method) {
/*  976 */         this.method = method;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic get(int index) {
/*  983 */         return new TypeProjection(this.method, index, this.method.getExceptionTypes());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/*  990 */         return (this.method.getExceptionTypes()).length;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList asErasures() {
/*  997 */         return new TypeList.ForLoadedTypes(this.method.getExceptionTypes());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private static class TypeProjection
/*      */         extends TypeDescription.Generic.LazyProjection.WithEagerNavigation.OfAnnotatedElement
/*      */       {
/*      */         private final Method method;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Class<?>[] erasure;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeProjection(Method method, int index, Class<?>[] erasure) {
/* 1028 */           this.method = method;
/* 1029 */           this.index = index;
/* 1030 */           this.erasure = erasure;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance("resolved")
/*      */         protected TypeDescription.Generic resolve() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription asErasure() {
/* 1046 */           return TypeDescription.ForLoadedType.of(this.erasure[this.index]);
/*      */         }
/*      */ 
/*      */         
/*      */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/* 1051 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedExecutableExceptionType(this.method, this.index);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class Empty
/*      */       extends FilterableList.Empty<TypeDescription.Generic, Generic>
/*      */       implements Generic
/*      */     {
/*      */       public TypeList asErasures() {
/* 1065 */         return new TypeList.Empty();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList.Generic asRawTypes() {
/* 1072 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList.Generic accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 1079 */         return new Empty();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ByteCodeElement.Token.TokenList<TypeVariableToken> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/* 1086 */         return new ByteCodeElement.Token.TokenList((ByteCodeElement.Token[])new TypeVariableToken[0]);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int getStackSize() {
/* 1093 */         return 0;
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\type\TypeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */