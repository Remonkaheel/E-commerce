/*     */ package net.bytebuddy.description.type;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.FilterableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RecordComponentList<T extends RecordComponentDescription>
/*     */   extends FilterableList<T, RecordComponentList<T>>
/*     */ {
/*     */   ByteCodeElement.Token.TokenList<RecordComponentDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*     */   
/*     */   TypeList.Generic asTypeList();
/*     */   
/*     */   RecordComponentList<RecordComponentDescription.InDefinedShape> asDefined();
/*     */   
/*     */   public static abstract class AbstractBase<S extends RecordComponentDescription>
/*     */     extends FilterableList.AbstractBase<S, RecordComponentList<S>>
/*     */     implements RecordComponentList<S>
/*     */   {
/*     */     public ByteCodeElement.Token.TokenList<RecordComponentDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/*  68 */       List<RecordComponentDescription.Token> tokens = new ArrayList<RecordComponentDescription.Token>(size());
/*  69 */       for (RecordComponentDescription recordComponentDescription : this) {
/*  70 */         tokens.add(recordComponentDescription.asToken(matcher));
/*     */       }
/*  72 */       return new ByteCodeElement.Token.TokenList(tokens);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeList.Generic asTypeList() {
/*  79 */       List<TypeDescription.Generic> typeDescriptions = new ArrayList<TypeDescription.Generic>(size());
/*  80 */       for (RecordComponentDescription recordComponentDescription : this) {
/*  81 */         typeDescriptions.add(recordComponentDescription.getType());
/*     */       }
/*  83 */       return new TypeList.Generic.Explicit((List)typeDescriptions);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentList<RecordComponentDescription.InDefinedShape> asDefined() {
/*  90 */       List<RecordComponentDescription.InDefinedShape> recordComponents = new ArrayList<RecordComponentDescription.InDefinedShape>(size());
/*  91 */       for (RecordComponentDescription recordComponentDescription : this) {
/*  92 */         recordComponents.add(recordComponentDescription.asDefined());
/*     */       }
/*  94 */       return new RecordComponentList.Explicit<RecordComponentDescription.InDefinedShape>(recordComponents);
/*     */     }
/*     */ 
/*     */     
/*     */     protected RecordComponentList<S> wrap(List<S> values) {
/*  99 */       return new RecordComponentList.Explicit<S>(values);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedRecordComponents
/*     */     extends AbstractBase<RecordComponentDescription.InDefinedShape>
/*     */   {
/*     */     private final List<?> recordComponents;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForLoadedRecordComponents(Object... recordComponent) {
/* 119 */       this(Arrays.asList(recordComponent));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForLoadedRecordComponents(List<?> recordComponents) {
/* 128 */       this.recordComponents = recordComponents;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentDescription.InDefinedShape get(int index) {
/* 135 */       return new RecordComponentDescription.ForLoadedRecordComponent((AnnotatedElement)this.recordComponents.get(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 142 */       return this.recordComponents.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Explicit<S extends RecordComponentDescription>
/*     */     extends AbstractBase<S>
/*     */   {
/*     */     private final List<? extends S> recordComponents;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(S... recordComponent) {
/* 165 */       this(Arrays.asList(recordComponent));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends S> recordComponents) {
/* 174 */       this.recordComponents = recordComponents;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S get(int index) {
/* 181 */       return this.recordComponents.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 188 */       return this.recordComponents.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForTokens
/*     */     extends AbstractBase<RecordComponentDescription.InDefinedShape>
/*     */   {
/*     */     private final TypeDescription typeDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends RecordComponentDescription.Token> tokens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(TypeDescription typeDescription, RecordComponentDescription.Token... token) {
/* 214 */       this(typeDescription, Arrays.asList(token));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(TypeDescription typeDescription, List<? extends RecordComponentDescription.Token> tokens) {
/* 224 */       this.typeDescription = typeDescription;
/* 225 */       this.tokens = tokens;
/*     */     }
/*     */ 
/*     */     
/*     */     public RecordComponentDescription.InDefinedShape get(int index) {
/* 230 */       return new RecordComponentDescription.Latent(this.typeDescription, this.tokens.get(index));
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 235 */       return this.tokens.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeSubstituting
/*     */     extends AbstractBase<RecordComponentDescription.InGenericShape>
/*     */   {
/*     */     private final TypeDescription.Generic declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends RecordComponentDescription> recordComponentDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSubstituting(TypeDescription.Generic declaringType, List<? extends RecordComponentDescription> recordComponentDescriptions, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 269 */       this.declaringType = declaringType;
/* 270 */       this.recordComponentDescriptions = recordComponentDescriptions;
/* 271 */       this.visitor = visitor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentDescription.InGenericShape get(int index) {
/* 278 */       return new RecordComponentDescription.TypeSubstituting(this.declaringType, this.recordComponentDescriptions.get(index), this.visitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 285 */       return this.recordComponentDescriptions.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Empty<S extends RecordComponentDescription>
/*     */     extends FilterableList.Empty<S, RecordComponentList<S>>
/*     */     implements RecordComponentList<S>
/*     */   {
/*     */     public RecordComponentList<RecordComponentDescription.InDefinedShape> asDefined() {
/* 300 */       return new Empty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteCodeElement.Token.TokenList<RecordComponentDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/* 307 */       return new ByteCodeElement.Token.TokenList((ByteCodeElement.Token[])new RecordComponentDescription.Token[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeList.Generic asTypeList() {
/* 314 */       return new TypeList.Generic.Empty();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\type\RecordComponentList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */