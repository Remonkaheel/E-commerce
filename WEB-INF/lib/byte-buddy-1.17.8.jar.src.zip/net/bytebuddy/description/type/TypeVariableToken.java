/*     */ package net.bytebuddy.description.type;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeVariableToken
/*     */   implements ByteCodeElement.Token<TypeVariableToken>
/*     */ {
/*     */   private final String symbol;
/*     */   private final List<? extends TypeDescription.Generic> bounds;
/*     */   private final List<? extends AnnotationDescription> annotations;
/*     */   
/*     */   public TypeVariableToken(String symbol, List<? extends TypeDescription.Generic> bounds) {
/*  55 */     this(symbol, bounds, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeVariableToken(String symbol, List<? extends TypeDescription.Generic> bounds, List<? extends AnnotationDescription> annotations) {
/*  66 */     this.symbol = symbol;
/*  67 */     this.bounds = bounds;
/*  68 */     this.annotations = annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeVariableToken of(TypeDescription.Generic typeVariable, ElementMatcher<? super TypeDescription> matcher) {
/*  79 */     return new TypeVariableToken(typeVariable.getSymbol(), (List<? extends TypeDescription.Generic>)typeVariable
/*  80 */         .getUpperBounds().accept(new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)), (List<? extends AnnotationDescription>)typeVariable
/*  81 */         .getDeclaredAnnotations());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSymbol() {
/*  90 */     return this.symbol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeList.Generic getBounds() {
/*  99 */     return new TypeList.Generic.Explicit((List)this.bounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationList getAnnotations() {
/* 108 */     return (AnnotationList)new AnnotationList.Explicit(this.annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeVariableToken accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 115 */     return new TypeVariableToken(this.symbol, (List<? extends TypeDescription.Generic>)getBounds().accept(visitor), this.annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance("hashCode")
/*     */   public int hashCode() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object other) {
/* 129 */     if (this == other)
/* 130 */       return true; 
/* 131 */     if (!(other instanceof TypeVariableToken)) {
/* 132 */       return false;
/*     */     }
/* 134 */     TypeVariableToken typeVariableToken = (TypeVariableToken)other;
/* 135 */     return (this.symbol.equals(typeVariableToken.symbol) && this.bounds
/* 136 */       .equals(typeVariableToken.bounds) && this.annotations
/* 137 */       .equals(typeVariableToken.annotations));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 142 */     return this.symbol;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\type\TypeVariableToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */