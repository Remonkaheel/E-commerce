/*     */ package net.bytebuddy.description.type;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.description.ModifierReviewable;
/*     */ import net.bytebuddy.description.NamedElement;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.implementation.bytecode.StackSize;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Instance;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ import net.bytebuddy.utility.nullability.UnknownNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TypeDefinition
/*     */   extends NamedElement, ModifierReviewable.ForTypeDefinition, Iterable<TypeDefinition>
/*     */ {
/*     */   public static final String RAW_TYPES_PROPERTY = "net.bytebuddy.raw";
/*     */   
/*     */   TypeDescription.Generic asGenericType();
/*     */   
/*     */   TypeDescription asErasure();
/*     */   
/*     */   @MaybeNull
/*     */   TypeDescription.Generic getSuperClass();
/*     */   
/*     */   TypeList.Generic getInterfaces();
/*     */   
/*     */   FieldList<?> getDeclaredFields();
/*     */   
/*     */   MethodList<?> getDeclaredMethods();
/*     */   
/*     */   @MaybeNull
/*     */   TypeDefinition getComponentType();
/*     */   
/*     */   RecordComponentList<?> getRecordComponents();
/*     */   
/*     */   Sort getSort();
/*     */   
/*     */   String getTypeName();
/*     */   
/*     */   StackSize getStackSize();
/*     */   
/*     */   boolean isArray();
/*     */   
/*     */   boolean isRecord();
/*     */   
/*     */   boolean isPrimitive();
/*     */   
/*     */   boolean represents(Type paramType);
/*     */   
/*     */   public enum Sort
/*     */   {
/* 192 */     NON_GENERIC,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     GENERIC_ARRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     PARAMETERIZED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     WILDCARD,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     VARIABLE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     VARIABLE_SYMBOLIC;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     private static final AnnotatedType ANNOTATED_TYPE = doPrivileged(JavaDispatcher.of(AnnotatedType.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */        }
/*     */     
/*     */     private static final boolean ACCESS_CONTROLLER;
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 234 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic describe(Type type) {
/* 244 */       return describe(type, TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TypeDescription.Generic describeAnnotated(AnnotatedElement annotatedType) {
/* 254 */       if (!ANNOTATED_TYPE.isInstance(annotatedType)) {
/* 255 */         throw new IllegalArgumentException("Not an instance of AnnotatedType: " + annotatedType);
/*     */       }
/* 257 */       return describe(ANNOTATED_TYPE.getType(annotatedType), new TypeDescription.Generic.AnnotationReader.Delegator.Simple(annotatedType));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static TypeDescription.Generic describe(Type type, TypeDescription.Generic.AnnotationReader annotationReader) {
/* 269 */       if (type instanceof Class)
/* 270 */         return new TypeDescription.Generic.OfNonGenericType.ForLoadedType((Class)type, annotationReader); 
/* 271 */       if (type instanceof GenericArrayType)
/* 272 */         return new TypeDescription.Generic.OfGenericArray.ForLoadedType((GenericArrayType)type, annotationReader); 
/* 273 */       if (type instanceof ParameterizedType)
/* 274 */         return new TypeDescription.Generic.OfParameterizedType.ForLoadedType((ParameterizedType)type, annotationReader); 
/* 275 */       if (type instanceof TypeVariable)
/* 276 */         return new TypeDescription.Generic.OfTypeVariable.ForLoadedType((TypeVariable)type, annotationReader); 
/* 277 */       if (type instanceof WildcardType) {
/* 278 */         return new TypeDescription.Generic.OfWildcardType.ForLoadedType((WildcardType)type, annotationReader);
/*     */       }
/* 280 */       throw new IllegalArgumentException("Unknown type: " + type);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static TypeDescription.Generic describeOrNull(@MaybeNull Type type, TypeDescription.Generic.AnnotationReader annotationReader) {
/* 294 */       if (type == null) {
/* 295 */         throw new TypeNotPresentException("<unknown>", null);
/*     */       }
/* 297 */       return describe(type, annotationReader);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isNonGeneric() {
/* 306 */       return (this == NON_GENERIC);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isParameterized() {
/* 315 */       return (this == PARAMETERIZED);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isGenericArray() {
/* 324 */       return (this == GENERIC_ARRAY);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isWildcard() {
/* 333 */       return (this == WILDCARD);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isTypeVariable() {
/* 342 */       return (this == VARIABLE || this == VARIABLE_SYMBOLIC);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Proxied("java.lang.reflect.AnnotatedType")
/*     */     protected static interface AnnotatedType
/*     */     {
/*     */       @Instance
/*     */       @Proxied("isInstance")
/*     */       boolean isInstance(AnnotatedElement param2AnnotatedElement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getType")
/*     */       Type getType(AnnotatedElement param2AnnotatedElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SuperClassIterator
/*     */     implements Iterator<TypeDefinition>
/*     */   {
/*     */     @UnknownNull
/*     */     private TypeDefinition nextClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SuperClassIterator(TypeDefinition initialType) {
/* 387 */       this.nextClass = initialType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 394 */       return (this.nextClass != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDefinition next() {
/* 401 */       if (!hasNext()) {
/* 402 */         throw new NoSuchElementException("End of type hierarchy");
/*     */       }
/*     */       try {
/* 405 */         return this.nextClass;
/*     */       } finally {
/* 407 */         this.nextClass = this.nextClass.getSuperClass();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 415 */       throw new UnsupportedOperationException("remove");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\type\TypeDefinition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */