/*       */ package net.bytebuddy.description.type;
/*       */ 
/*       */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*       */ import java.io.Serializable;
/*       */ import java.lang.annotation.Annotation;
/*       */ import java.lang.reflect.AccessibleObject;
/*       */ import java.lang.reflect.AnnotatedElement;
/*       */ import java.lang.reflect.Constructor;
/*       */ import java.lang.reflect.Field;
/*       */ import java.lang.reflect.GenericArrayType;
/*       */ import java.lang.reflect.GenericDeclaration;
/*       */ import java.lang.reflect.GenericSignatureFormatError;
/*       */ import java.lang.reflect.InvocationHandler;
/*       */ import java.lang.reflect.InvocationTargetException;
/*       */ import java.lang.reflect.Method;
/*       */ import java.lang.reflect.ParameterizedType;
/*       */ import java.lang.reflect.Proxy;
/*       */ import java.lang.reflect.Type;
/*       */ import java.lang.reflect.TypeVariable;
/*       */ import java.lang.reflect.WildcardType;
/*       */ import java.security.AccessController;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Arrays;
/*       */ import java.util.Collection;
/*       */ import java.util.Collections;
/*       */ import java.util.HashMap;
/*       */ import java.util.HashSet;
/*       */ import java.util.Iterator;
/*       */ import java.util.List;
/*       */ import java.util.Map;
/*       */ import java.util.Set;
/*       */ import net.bytebuddy.ClassFileVersion;
/*       */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*       */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*       */ import net.bytebuddy.description.ByteCodeElement;
/*       */ import net.bytebuddy.description.ModifierReviewable;
/*       */ import net.bytebuddy.description.TypeVariableSource;
/*       */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*       */ import net.bytebuddy.description.annotation.AnnotationList;
/*       */ import net.bytebuddy.description.annotation.AnnotationSource;
/*       */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*       */ import net.bytebuddy.description.field.FieldDescription;
/*       */ import net.bytebuddy.description.field.FieldList;
/*       */ import net.bytebuddy.description.method.MethodDescription;
/*       */ import net.bytebuddy.description.method.MethodList;
/*       */ import net.bytebuddy.description.method.ParameterDescription;
/*       */ import net.bytebuddy.dynamic.TargetType;
/*       */ import net.bytebuddy.implementation.bytecode.StackSize;
/*       */ import net.bytebuddy.jar.asm.Type;
/*       */ import net.bytebuddy.jar.asm.signature.SignatureVisitor;
/*       */ import net.bytebuddy.jar.asm.signature.SignatureWriter;
/*       */ import net.bytebuddy.matcher.ElementMatcher;
/*       */ import net.bytebuddy.matcher.ElementMatchers;
/*       */ import net.bytebuddy.utility.CompoundList;
/*       */ import net.bytebuddy.utility.JavaType;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Defaults;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Instance;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*       */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*       */ import net.bytebuddy.utility.nullability.MaybeNull;
/*       */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*       */ 
/*       */ public interface TypeDescription
/*       */   extends TypeDefinition, ByteCodeElement, TypeVariableSource {
/*       */   @Deprecated
/*    71 */   public static final TypeDescription OBJECT = LazyProxy.of(Object.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*    79 */   public static final TypeDescription STRING = LazyProxy.of(String.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*    87 */   public static final TypeDescription CLASS = LazyProxy.of(Class.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*    95 */   public static final TypeDescription THROWABLE = LazyProxy.of(Throwable.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Deprecated
/*   103 */   public static final TypeDescription VOID = LazyProxy.of(void.class);
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   108 */   public static final TypeList.Generic ARRAY_INTERFACES = new TypeList.Generic.ForLoadedTypes(new Type[] { Cloneable.class, Serializable.class });
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @AlwaysNull
/*   115 */   public static final TypeDescription UNDEFINED = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   FieldList<FieldDescription.InDefinedShape> getDeclaredFields();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   MethodList<MethodDescription.InDefinedShape> getDeclaredMethods();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isInstance(Object paramObject);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAssignableFrom(Class<?> paramClass);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAssignableFrom(TypeDescription paramTypeDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAssignableTo(Class<?> paramClass);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAssignableTo(TypeDescription paramTypeDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isInHierarchyWith(Class<?> paramClass);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isInHierarchyWith(TypeDescription paramTypeDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   TypeDescription getComponentType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   TypeDescription getDeclaringType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   TypeList getDeclaredTypes();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   MethodDescription.InDefinedShape getEnclosingMethod();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   TypeDescription getEnclosingType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getActualModifiers(boolean paramBoolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String getSimpleName();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String getLongSimpleName();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   String getCanonicalName();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAnonymousType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isLocalType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isMemberType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   PackageDescription getPackage();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   AnnotationList getInheritedAnnotations();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isSamePackage(TypeDescription paramTypeDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isPrimitiveWrapper();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAnnotationReturnType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAnnotationValue();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isAnnotationValue(Object paramObject);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isPackageType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getInnerClassCount();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isInnerClass();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isNestedClass();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   TypeDescription asBoxed();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   TypeDescription asUnboxed();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   Object getDefaultValue();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   TypeDescription getNestHost();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   TypeList getNestMembers();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isNestHost();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isNestMateOf(Class<?> paramClass);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isNestMateOf(TypeDescription paramTypeDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isCompileTimeConstant();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   TypeList getPermittedSubtypes();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isSealed();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @MaybeNull
/*       */   ClassFileVersion getClassFileVersion();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface Generic
/*       */     extends TypeDefinition, AnnotationSource
/*       */   {
/*       */     @Deprecated
/*   494 */     public static final Generic OBJECT = LazyProxy.of(Object.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Deprecated
/*   502 */     public static final Generic CLASS = LazyProxy.of(Class.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Deprecated
/*   510 */     public static final Generic VOID = LazyProxy.of(void.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Deprecated
/*   518 */     public static final Generic ANNOTATION = LazyProxy.of(Annotation.class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @AlwaysNull
/*   525 */     public static final Generic UNDEFINED = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     Generic asRawType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypeList.Generic getUpperBounds();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypeList.Generic getLowerBounds();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypeList.Generic getTypeArguments();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     Generic getOwnerType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     Generic findBindingOf(Generic param1Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypeVariableSource getTypeVariableSource();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     String getSymbol();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     Generic getComponentType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     FieldList<FieldDescription.InGenericShape> getDeclaredFields();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     MethodList<MethodDescription.InGenericShape> getDeclaredMethods();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     <T> T accept(Visitor<T> param1Visitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Visitor<T>
/*       */     {
/*       */       T onGenericArray(TypeDescription.Generic param2Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       T onWildcard(TypeDescription.Generic param2Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       T onParameterizedType(TypeDescription.Generic param2Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       T onTypeVariable(TypeDescription.Generic param2Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       T onNonGenericType(TypeDescription.Generic param2Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum NoOp
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*   711 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*   717 */           return genericArray;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*   724 */           return wildcard;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*   731 */           return parameterizedType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*   738 */           return typeVariable;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*   745 */           return typeDescription;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum TypeErasing
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*   757 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*   763 */           return genericArray.asRawType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*   770 */           throw new IllegalArgumentException("Cannot erase a wildcard type: " + wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*   777 */           return parameterizedType.asRawType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*   784 */           return typeVariable.asRawType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*   791 */           return typeDescription.asRawType();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Generalizing
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*   804 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*   811 */           int arity = 0;
/*       */           while (true) {
/*   813 */             arity++;
/*   814 */             genericArray = genericArray.getComponentType();
/*   815 */             if (!genericArray.isArray()) {
/*   816 */               return TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(Object.class), arity).asGenericType();
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*   823 */           throw new IllegalArgumentException("Cannot erase a wildcard type: " + wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*   830 */           return TypeDescription.ForLoadedType.of(Object.class).asGenericType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*   837 */           return TypeDescription.ForLoadedType.of(Object.class).asGenericType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*   845 */           int arity = 0;
/*   846 */           TypeDescription.Generic componentType = typeDescription;
/*   847 */           while (componentType.isArray()) {
/*   848 */             arity++;
/*   849 */             componentType = componentType.getComponentType();
/*       */           } 
/*   851 */           return componentType.isPrimitive() ? typeDescription : 
/*       */             
/*   853 */             TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(Object.class), arity).asGenericType();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum AnnotationStripper
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*   865 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*   872 */           return new TypeDescription.Generic.OfGenericArray.Latent(genericArray.getComponentType().<TypeDescription.Generic>accept(this), (AnnotationSource)AnnotationSource.Empty.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*   879 */           return new TypeDescription.Generic.OfWildcardType.Latent((List<? extends TypeDescription.Generic>)wildcard.getUpperBounds().accept(this), (List<? extends TypeDescription.Generic>)wildcard.getLowerBounds().accept(this), (AnnotationSource)AnnotationSource.Empty.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*   886 */           TypeDescription.Generic ownerType = parameterizedType.getOwnerType();
/*   887 */           return new TypeDescription.Generic.OfParameterizedType.Latent(parameterizedType.asErasure(), (ownerType == null) ? TypeDescription.Generic.UNDEFINED : ownerType
/*       */ 
/*       */               
/*   890 */               .<TypeDescription.Generic>accept(this), (List<? extends TypeDescription.Generic>)parameterizedType
/*   891 */               .getTypeArguments().accept(this), (AnnotationSource)AnnotationSource.Empty.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*   899 */           return new NonAnnotatedTypeVariable(typeVariable);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*   907 */           return typeDescription.isArray() ? new TypeDescription.Generic.OfGenericArray.Latent(
/*   908 */               onNonGenericType(typeDescription.getComponentType()), (AnnotationSource)AnnotationSource.Empty.INSTANCE) : new TypeDescription.Generic.OfNonGenericType.Latent(typeDescription
/*   909 */               .asErasure(), (AnnotationSource)AnnotationSource.Empty.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class NonAnnotatedTypeVariable
/*       */           extends TypeDescription.Generic.OfTypeVariable
/*       */         {
/*       */           private final TypeDescription.Generic typeVariable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected NonAnnotatedTypeVariable(TypeDescription.Generic typeVariable) {
/*   928 */             this.typeVariable = typeVariable;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeList.Generic getUpperBounds() {
/*   935 */             return this.typeVariable.getUpperBounds();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeVariableSource getTypeVariableSource() {
/*   942 */             return this.typeVariable.getTypeVariableSource();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public String getSymbol() {
/*   949 */             return this.typeVariable.getSymbol();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotationList getDeclaredAnnotations() {
/*   956 */             return (AnnotationList)new AnnotationList.Empty();
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Assigner
/*       */         implements Visitor<Assigner.Dispatcher>
/*       */       {
/*   971 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Dispatcher onGenericArray(TypeDescription.Generic genericArray) {
/*   977 */           return new Dispatcher.ForGenericArray(genericArray);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Dispatcher onWildcard(TypeDescription.Generic wildcard) {
/*   984 */           throw new IllegalArgumentException("A wildcard is not a first level type: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Dispatcher onParameterizedType(TypeDescription.Generic parameterizedType) {
/*   991 */           return new Dispatcher.ForParameterizedType(parameterizedType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Dispatcher onTypeVariable(TypeDescription.Generic typeVariable) {
/*   998 */           return new Dispatcher.ForTypeVariable(typeVariable);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Dispatcher onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1005 */           return new Dispatcher.ForNonGenericType(typeDescription.asErasure());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForNonGenericType
/*       */           extends Dispatcher.AbstractBase
/*       */         {
/*       */           private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ForNonGenericType(TypeDescription typeDescription) {
/*  1051 */             this.typeDescription = typeDescription;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */           public Boolean onGenericArray(TypeDescription.Generic genericArray) {
/*  1059 */             return Boolean.valueOf(this.typeDescription.isArray() ? ((Boolean)genericArray
/*  1060 */                 .getComponentType().<Boolean>accept(new ForNonGenericType(this.typeDescription.getComponentType()))).booleanValue() : ((this.typeDescription
/*  1061 */                 .represents(Object.class) || TypeDescription.ARRAY_INTERFACES.contains(this.typeDescription.asGenericType()))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*  1068 */             throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1075 */             if (this.typeDescription.equals(parameterizedType.asErasure())) {
/*  1076 */               return Boolean.valueOf(true);
/*       */             }
/*  1078 */             TypeDescription.Generic superClass = parameterizedType.getSuperClass();
/*  1079 */             if (superClass != null && isAssignableFrom(superClass)) {
/*  1080 */               return Boolean.valueOf(true);
/*       */             }
/*  1082 */             for (TypeDescription.Generic interfaceType : parameterizedType.getInterfaces()) {
/*  1083 */               if (isAssignableFrom(interfaceType)) {
/*  1084 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1087 */             return Boolean.valueOf(this.typeDescription.represents(Object.class));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1094 */             for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) {
/*  1095 */               if (isAssignableFrom(upperBound)) {
/*  1096 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1099 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1106 */             return Boolean.valueOf(this.typeDescription.isAssignableFrom(typeDescription.asErasure()));
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.typeDescription.equals(((ForNonGenericType)param4Object).typeDescription))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*       */           }
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         public static class ForTypeVariable
/*       */           extends Dispatcher.AbstractBase
/*       */         {
/*       */           private final TypeDescription.Generic typeVariable;
/*       */           
/*       */           protected ForTypeVariable(TypeDescription.Generic typeVariable) {
/*  1127 */             this.typeVariable = typeVariable;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onGenericArray(TypeDescription.Generic genericArray) {
/*  1134 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*  1141 */             throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1148 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1155 */             if (typeVariable.equals(this.typeVariable)) {
/*  1156 */               return Boolean.valueOf(true);
/*       */             }
/*  1158 */             for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) {
/*  1159 */               if (isAssignableFrom(upperBound)) {
/*  1160 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1163 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1170 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.typeVariable.equals(((ForTypeVariable)param4Object).typeVariable))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.typeVariable.hashCode();
/*       */           }
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         public static class ForParameterizedType
/*       */           extends Dispatcher.AbstractBase
/*       */         {
/*       */           private final TypeDescription.Generic parameterizedType;
/*       */           
/*       */           protected ForParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1191 */             this.parameterizedType = parameterizedType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onGenericArray(TypeDescription.Generic genericArray) {
/*  1198 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*  1205 */             throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1212 */             if (this.parameterizedType.asErasure().equals(parameterizedType.asErasure())) {
/*  1213 */               TypeDescription.Generic fromOwner = this.parameterizedType.getOwnerType(), toOwner = parameterizedType.getOwnerType();
/*  1214 */               if (fromOwner != null && toOwner != null && !((TypeDescription.Generic.Visitor.Assigner.Dispatcher)fromOwner.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(toOwner)) {
/*  1215 */                 return Boolean.valueOf(false);
/*       */               }
/*  1217 */               TypeList.Generic fromArguments = this.parameterizedType.getTypeArguments(), toArguments = parameterizedType.getTypeArguments();
/*  1218 */               if (fromArguments.size() == toArguments.size()) {
/*  1219 */                 for (int index = 0; index < fromArguments.size(); index++) {
/*  1220 */                   if (!((TypeDescription.Generic.Visitor.Assigner.Dispatcher)((TypeDescription.Generic)fromArguments.get(index)).<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(ParameterAssigner.INSTANCE)).isAssignableFrom((TypeDescription.Generic)toArguments.get(index))) {
/*  1221 */                     return Boolean.valueOf(false);
/*       */                   }
/*       */                 } 
/*  1224 */                 return Boolean.valueOf(true);
/*       */               } 
/*  1226 */               throw new IllegalArgumentException("Incompatible generic types: " + parameterizedType + " and " + this.parameterizedType);
/*       */             } 
/*       */             
/*  1229 */             TypeDescription.Generic superClass = parameterizedType.getSuperClass();
/*  1230 */             if (superClass != null && isAssignableFrom(superClass)) {
/*  1231 */               return Boolean.valueOf(true);
/*       */             }
/*  1233 */             for (TypeDescription.Generic interfaceType : parameterizedType.getInterfaces()) {
/*  1234 */               if (isAssignableFrom(interfaceType)) {
/*  1235 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1238 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1245 */             for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) {
/*  1246 */               if (isAssignableFrom(upperBound)) {
/*  1247 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1250 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1257 */             if (this.parameterizedType.asErasure().equals(typeDescription.asErasure())) {
/*  1258 */               return Boolean.valueOf(true);
/*       */             }
/*  1260 */             TypeDescription.Generic superClass = typeDescription.getSuperClass();
/*  1261 */             if (superClass != null && isAssignableFrom(superClass)) {
/*  1262 */               return Boolean.valueOf(true);
/*       */             }
/*  1264 */             for (TypeDescription.Generic interfaceType : typeDescription.getInterfaces()) {
/*  1265 */               if (isAssignableFrom(interfaceType)) {
/*  1266 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1269 */             return Boolean.valueOf(false);
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.parameterizedType.equals(((ForParameterizedType)param4Object).parameterizedType))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.parameterizedType.hashCode();
/*       */           }
/*       */           
/*  1280 */           protected enum ParameterAssigner implements TypeDescription.Generic.Visitor<TypeDescription.Generic.Visitor.Assigner.Dispatcher> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic.Visitor.Assigner.Dispatcher onGenericArray(TypeDescription.Generic genericArray) {
/*  1286 */               return new InvariantBinding(genericArray);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic.Visitor.Assigner.Dispatcher onWildcard(TypeDescription.Generic wildcard) {
/*  1293 */               TypeList.Generic lowerBounds = wildcard.getLowerBounds();
/*  1294 */               return lowerBounds.isEmpty() ? new CovariantBinding((TypeDescription.Generic)wildcard
/*  1295 */                   .getUpperBounds().getOnly()) : new ContravariantBinding((TypeDescription.Generic)lowerBounds
/*  1296 */                   .getOnly());
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic.Visitor.Assigner.Dispatcher onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1303 */               return new InvariantBinding(parameterizedType);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic.Visitor.Assigner.Dispatcher onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1310 */               return new InvariantBinding(typeVariable);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic.Visitor.Assigner.Dispatcher onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1317 */               return new InvariantBinding(typeDescription);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             @Enhance
/*       */             protected static class InvariantBinding
/*       */               implements TypeDescription.Generic.Visitor.Assigner.Dispatcher
/*       */             {
/*       */               private final TypeDescription.Generic typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               protected InvariantBinding(TypeDescription.Generic typeDescription) {
/*  1337 */                 this.typeDescription = typeDescription;
/*       */               }
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               public boolean isAssignableFrom(TypeDescription.Generic typeDescription) {
/*  1344 */                 return typeDescription.equals(this.typeDescription);
/*       */               }
/*       */ 
/*       */               
/*       */               public boolean equals(@MaybeNull Object param7Object) {
/*       */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.typeDescription.equals(((InvariantBinding)param7Object).typeDescription))));
/*       */               }
/*       */ 
/*       */               
/*       */               public int hashCode() {
/*       */                 return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*       */               }
/*       */             }
/*       */             
/*       */             @Enhance
/*       */             protected static class CovariantBinding
/*       */               implements TypeDescription.Generic.Visitor.Assigner.Dispatcher
/*       */             {
/*       */               private final TypeDescription.Generic upperBound;
/*       */               
/*       */               protected CovariantBinding(TypeDescription.Generic upperBound) {
/*  1365 */                 this.upperBound = upperBound;
/*       */               }
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               public boolean isAssignableFrom(TypeDescription.Generic typeDescription) {
/*  1372 */                 if (typeDescription.getSort().isWildcard()) {
/*  1373 */                   return (typeDescription.getLowerBounds().isEmpty() && ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.upperBound.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE))
/*  1374 */                     .isAssignableFrom((TypeDescription.Generic)typeDescription.getUpperBounds().getOnly()));
/*       */                 }
/*  1376 */                 return ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.upperBound.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(typeDescription);
/*       */               }
/*       */ 
/*       */               
/*       */               public boolean equals(@MaybeNull Object param7Object) {
/*       */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.upperBound.equals(((CovariantBinding)param7Object).upperBound))));
/*       */               }
/*       */ 
/*       */               
/*       */               public int hashCode() {
/*       */                 return getClass().hashCode() * 31 + this.upperBound.hashCode();
/*       */               }
/*       */             }
/*       */ 
/*       */             
/*       */             @Enhance
/*       */             protected static class ContravariantBinding
/*       */               implements TypeDescription.Generic.Visitor.Assigner.Dispatcher
/*       */             {
/*       */               private final TypeDescription.Generic lowerBound;
/*       */               
/*       */               protected ContravariantBinding(TypeDescription.Generic lowerBound) {
/*  1398 */                 this.lowerBound = lowerBound;
/*       */               }
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               public boolean isAssignableFrom(TypeDescription.Generic typeDescription) {
/*  1405 */                 if (typeDescription.getSort().isWildcard()) {
/*  1406 */                   TypeList.Generic lowerBounds = typeDescription.getLowerBounds();
/*  1407 */                   return (!lowerBounds.isEmpty() && ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)((TypeDescription.Generic)lowerBounds.getOnly()).<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(this.lowerBound));
/*       */                 } 
/*  1409 */                 return (typeDescription.getSort().isWildcard() || ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)typeDescription.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(this.lowerBound));
/*       */               }
/*       */ 
/*       */               
/*       */               public boolean equals(@MaybeNull Object param7Object) {
/*       */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.lowerBound.equals(((ContravariantBinding)param7Object).lowerBound))));
/*       */               }
/*       */ 
/*       */               
/*       */               public int hashCode() {
/*       */                 return getClass().hashCode() * 31 + this.lowerBound.hashCode();
/*       */               }
/*       */             } }
/*       */         
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForGenericArray
/*       */           extends Dispatcher.AbstractBase
/*       */         {
/*       */           private final TypeDescription.Generic genericArray;
/*       */           
/*       */           protected ForGenericArray(TypeDescription.Generic genericArray) {
/*  1433 */             this.genericArray = genericArray;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */           public Boolean onGenericArray(TypeDescription.Generic genericArray) {
/*  1441 */             return Boolean.valueOf(((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.genericArray.getComponentType().<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(genericArray.getComponentType()));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*  1448 */             throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1455 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1462 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription)
/*       */           {
/*  1470 */             return Boolean.valueOf((typeDescription.isArray() && ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.genericArray
/*  1471 */                 .getComponentType().<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(typeDescription.getComponentType()))); } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.genericArray.equals(((ForGenericArray)param4Object).genericArray)))); } public int hashCode() { return getClass().hashCode() * 31 + this.genericArray.hashCode(); } } public static interface Dispatcher { boolean isAssignableFrom(TypeDescription.Generic param4Generic); public static abstract class AbstractBase implements Dispatcher, TypeDescription.Generic.Visitor<Boolean> { public boolean isAssignableFrom(TypeDescription.Generic typeDescription) { return ((Boolean)typeDescription.<Boolean>accept(this)).booleanValue(); } } @Enhance public static class ForNonGenericType extends AbstractBase { private final TypeDescription typeDescription; protected ForNonGenericType(TypeDescription typeDescription) { this.typeDescription = typeDescription; } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.") public Boolean onGenericArray(TypeDescription.Generic genericArray) { return Boolean.valueOf(this.typeDescription.isArray() ? ((Boolean)genericArray.getComponentType().<Boolean>accept(new ForNonGenericType(this.typeDescription.getComponentType()))).booleanValue() : ((this.typeDescription.represents(Object.class) || TypeDescription.ARRAY_INTERFACES.contains(this.typeDescription.asGenericType())))); } public Boolean onWildcard(TypeDescription.Generic wildcard) { throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard); } public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) { if (this.typeDescription.equals(parameterizedType.asErasure())) return Boolean.valueOf(true);  TypeDescription.Generic superClass = parameterizedType.getSuperClass(); if (superClass != null && isAssignableFrom(superClass)) return Boolean.valueOf(true);  for (TypeDescription.Generic interfaceType : parameterizedType.getInterfaces()) { if (isAssignableFrom(interfaceType)) return Boolean.valueOf(true);  }  return Boolean.valueOf(this.typeDescription.represents(Object.class)); } public Boolean onTypeVariable(TypeDescription.Generic typeVariable) { for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) { if (isAssignableFrom(upperBound)) return Boolean.valueOf(true);  }  return Boolean.valueOf(false); } public Boolean onNonGenericType(TypeDescription.Generic typeDescription) { return Boolean.valueOf(this.typeDescription.isAssignableFrom(typeDescription.asErasure())); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.typeDescription.equals(((ForNonGenericType)param5Object).typeDescription)))); } public int hashCode() { return getClass().hashCode() * 31 + this.typeDescription.hashCode(); } } @Enhance public static class ForTypeVariable extends AbstractBase { private final TypeDescription.Generic typeVariable; protected ForTypeVariable(TypeDescription.Generic typeVariable) { this.typeVariable = typeVariable; } public Boolean onGenericArray(TypeDescription.Generic genericArray) { return Boolean.valueOf(false); } public Boolean onWildcard(TypeDescription.Generic wildcard) { throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard); } public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) { return Boolean.valueOf(false); } public Boolean onTypeVariable(TypeDescription.Generic typeVariable) { if (typeVariable.equals(this.typeVariable)) return Boolean.valueOf(true);  for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) { if (isAssignableFrom(upperBound)) return Boolean.valueOf(true);  }  return Boolean.valueOf(false); } public Boolean onNonGenericType(TypeDescription.Generic typeDescription) { return Boolean.valueOf(false); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.typeVariable.equals(((ForTypeVariable)param5Object).typeVariable)))); } public int hashCode() { return getClass().hashCode() * 31 + this.typeVariable.hashCode(); } } @Enhance public static class ForParameterizedType extends AbstractBase { private final TypeDescription.Generic parameterizedType; protected ForParameterizedType(TypeDescription.Generic parameterizedType) { this.parameterizedType = parameterizedType; } public Boolean onGenericArray(TypeDescription.Generic genericArray) { return Boolean.valueOf(false); } public Boolean onWildcard(TypeDescription.Generic wildcard) { throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard); } public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) { if (this.parameterizedType.asErasure().equals(parameterizedType.asErasure())) { TypeDescription.Generic fromOwner = this.parameterizedType.getOwnerType(), toOwner = parameterizedType.getOwnerType(); if (fromOwner != null && toOwner != null && !((TypeDescription.Generic.Visitor.Assigner.Dispatcher)fromOwner.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(toOwner)) return Boolean.valueOf(false);  TypeList.Generic fromArguments = this.parameterizedType.getTypeArguments(), toArguments = parameterizedType.getTypeArguments(); if (fromArguments.size() == toArguments.size()) { for (int index = 0; index < fromArguments.size(); index++) { if (!((TypeDescription.Generic.Visitor.Assigner.Dispatcher)((TypeDescription.Generic)fromArguments.get(index)).<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(ParameterAssigner.INSTANCE)).isAssignableFrom((TypeDescription.Generic)toArguments.get(index))) return Boolean.valueOf(false);  }  return Boolean.valueOf(true); }  throw new IllegalArgumentException("Incompatible generic types: " + parameterizedType + " and " + this.parameterizedType); }  TypeDescription.Generic superClass = parameterizedType.getSuperClass(); if (superClass != null && isAssignableFrom(superClass)) return Boolean.valueOf(true);  for (TypeDescription.Generic interfaceType : parameterizedType.getInterfaces()) { if (isAssignableFrom(interfaceType)) return Boolean.valueOf(true);  }  return Boolean.valueOf(false); } public Boolean onTypeVariable(TypeDescription.Generic typeVariable) { for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) { if (isAssignableFrom(upperBound)) return Boolean.valueOf(true);  }  return Boolean.valueOf(false); } public Boolean onNonGenericType(TypeDescription.Generic typeDescription) { if (this.parameterizedType.asErasure().equals(typeDescription.asErasure())) return Boolean.valueOf(true);  TypeDescription.Generic superClass = typeDescription.getSuperClass(); if (superClass != null && isAssignableFrom(superClass)) return Boolean.valueOf(true);  for (TypeDescription.Generic interfaceType : typeDescription.getInterfaces()) { if (isAssignableFrom(interfaceType)) return Boolean.valueOf(true);  }  return Boolean.valueOf(false); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.parameterizedType.equals(((ForParameterizedType)param5Object).parameterizedType)))); } public int hashCode() { return getClass().hashCode() * 31 + this.parameterizedType.hashCode(); } protected enum ParameterAssigner implements TypeDescription.Generic.Visitor<TypeDescription.Generic.Visitor.Assigner.Dispatcher> { INSTANCE; public TypeDescription.Generic.Visitor.Assigner.Dispatcher onGenericArray(TypeDescription.Generic genericArray) { return new InvariantBinding(genericArray); } public TypeDescription.Generic.Visitor.Assigner.Dispatcher onWildcard(TypeDescription.Generic wildcard) { TypeList.Generic lowerBounds = wildcard.getLowerBounds(); return lowerBounds.isEmpty() ? new CovariantBinding((TypeDescription.Generic)wildcard.getUpperBounds().getOnly()) : new ContravariantBinding((TypeDescription.Generic)lowerBounds.getOnly()); } public TypeDescription.Generic.Visitor.Assigner.Dispatcher onParameterizedType(TypeDescription.Generic parameterizedType) { return new InvariantBinding(parameterizedType); } public TypeDescription.Generic.Visitor.Assigner.Dispatcher onTypeVariable(TypeDescription.Generic typeVariable) { return new InvariantBinding(typeVariable); } public TypeDescription.Generic.Visitor.Assigner.Dispatcher onNonGenericType(TypeDescription.Generic typeDescription) { return new InvariantBinding(typeDescription); } @Enhance protected static class InvariantBinding implements TypeDescription.Generic.Visitor.Assigner.Dispatcher { private final TypeDescription.Generic typeDescription; protected InvariantBinding(TypeDescription.Generic typeDescription) { this.typeDescription = typeDescription; } public boolean isAssignableFrom(TypeDescription.Generic typeDescription) { return typeDescription.equals(this.typeDescription); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.typeDescription.equals(((InvariantBinding)param7Object).typeDescription)))); } public int hashCode() { return getClass().hashCode() * 31 + this.typeDescription.hashCode(); } } @Enhance protected static class CovariantBinding implements TypeDescription.Generic.Visitor.Assigner.Dispatcher { private final TypeDescription.Generic upperBound; protected CovariantBinding(TypeDescription.Generic upperBound) { this.upperBound = upperBound; } public boolean isAssignableFrom(TypeDescription.Generic typeDescription) { if (typeDescription.getSort().isWildcard()) return (typeDescription.getLowerBounds().isEmpty() && ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.upperBound.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom((TypeDescription.Generic)typeDescription.getUpperBounds().getOnly()));  return ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.upperBound.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(typeDescription); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.upperBound.equals(((CovariantBinding)param7Object).upperBound)))); } public int hashCode() { return getClass().hashCode() * 31 + this.upperBound.hashCode(); } } @Enhance protected static class ContravariantBinding implements TypeDescription.Generic.Visitor.Assigner.Dispatcher { private final TypeDescription.Generic lowerBound; protected ContravariantBinding(TypeDescription.Generic lowerBound) { this.lowerBound = lowerBound; } public boolean isAssignableFrom(TypeDescription.Generic typeDescription) { if (typeDescription.getSort().isWildcard()) { TypeList.Generic lowerBounds = typeDescription.getLowerBounds(); return (!lowerBounds.isEmpty() && ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)((TypeDescription.Generic)lowerBounds.getOnly()).<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(this.lowerBound)); }  return (typeDescription.getSort().isWildcard() || ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)typeDescription.<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(this.lowerBound)); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.lowerBound.equals(((ContravariantBinding)param7Object).lowerBound)))); } public int hashCode() { return getClass().hashCode() * 31 + this.lowerBound.hashCode(); } } } } @Enhance public static class ForGenericArray extends AbstractBase { private final TypeDescription.Generic genericArray; protected ForGenericArray(TypeDescription.Generic genericArray) { this.genericArray = genericArray; } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.") public Boolean onGenericArray(TypeDescription.Generic genericArray) { return Boolean.valueOf(((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.genericArray.getComponentType().<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(genericArray.getComponentType())); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.") public Boolean onNonGenericType(TypeDescription.Generic typeDescription) { return Boolean.valueOf((typeDescription.isArray() && ((TypeDescription.Generic.Visitor.Assigner.Dispatcher)this.genericArray.getComponentType().<TypeDescription.Generic.Visitor.Assigner.Dispatcher>accept(TypeDescription.Generic.Visitor.Assigner.INSTANCE)).isAssignableFrom(typeDescription.getComponentType()))); }
/*       */              public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*       */               throw new IllegalArgumentException("A wildcard is not a first-level type: " + wildcard);
/*       */             } public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*       */               return Boolean.valueOf(false);
/*       */             } public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*       */               return Boolean.valueOf(false);
/*       */             }
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.genericArray.equals(((ForGenericArray)param5Object).genericArray))));
/*       */             }
/*       */             public int hashCode() {
/*       */               return getClass().hashCode() * 31 + this.genericArray.hashCode();
/*       */             } } } }
/*  1485 */       public enum Validator implements Visitor<Boolean> { SUPER_CLASS(false, false, false, false)
/*       */         {
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1488 */             return Boolean.valueOf((super.onNonGenericType(typeDescription).booleanValue() && !typeDescription.isInterface()));
/*       */           }
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1493 */             return Boolean.valueOf(!parameterizedType.isInterface());
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1500 */         INTERFACE(false, false, false, false)
/*       */         {
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1503 */             return Boolean.valueOf((super.onNonGenericType(typeDescription).booleanValue() && typeDescription.isInterface()));
/*       */           }
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1508 */             return Boolean.valueOf(parameterizedType.isInterface());
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1515 */         TYPE_VARIABLE(false, false, true, false),
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1520 */         FIELD(true, true, true, false),
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1525 */         METHOD_RETURN(true, true, true, true),
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1530 */         METHOD_PARAMETER(true, true, true, false),
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1535 */         EXCEPTION(false, false, true, false)
/*       */         {
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1538 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */           
/*       */           public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1543 */             for (TypeDescription.Generic bound : typeVariable.getUpperBounds()) {
/*  1544 */               if (((Boolean)bound.<Boolean>accept(this)).booleanValue()) {
/*  1545 */                 return Boolean.valueOf(true);
/*       */               }
/*       */             } 
/*  1548 */             return Boolean.valueOf(false);
/*       */           }
/*       */ 
/*       */           
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1553 */             return Boolean.valueOf(typeDescription.asErasure().isAssignableTo(Throwable.class));
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1560 */         RECEIVER(false, false, false, false);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean acceptsArray;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean acceptsPrimitive;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean acceptsVariable;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean acceptsVoid;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         Validator(boolean acceptsArray, boolean acceptsPrimitive, boolean acceptsVariable, boolean acceptsVoid) {
/*  1591 */           this.acceptsArray = acceptsArray;
/*  1592 */           this.acceptsPrimitive = acceptsPrimitive;
/*  1593 */           this.acceptsVariable = acceptsVariable;
/*  1594 */           this.acceptsVoid = acceptsVoid;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Boolean onGenericArray(TypeDescription.Generic genericArray) {
/*  1601 */           return Boolean.valueOf(this.acceptsArray);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*  1608 */           return Boolean.valueOf(false);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1615 */           return Boolean.valueOf(true);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1622 */           return Boolean.valueOf(this.acceptsVariable);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1629 */           return Boolean.valueOf(((this.acceptsArray || !typeDescription.isArray()) && (this.acceptsPrimitive || 
/*  1630 */               !typeDescription.isPrimitive()) && (this.acceptsVoid || 
/*  1631 */               !typeDescription.represents(void.class))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public enum ForTypeAnnotations
/*       */           implements TypeDescription.Generic.Visitor<Boolean>
/*       */         {
/*  1642 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final String TYPE_PARAMETER = "TYPE_PARAMETER";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final String TYPE_USE = "TYPE_USE";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public static boolean ofFormalTypeVariable(TypeDescription.Generic typeVariable) {
/*  1661 */             Set<TypeDescription> annotationTypes = new HashSet<TypeDescription>();
/*  1662 */             for (AnnotationDescription annotationDescription : typeVariable.getDeclaredAnnotations()) {
/*  1663 */               if (!annotationDescription.isSupportedOn("TYPE_PARAMETER") || !annotationTypes.add(annotationDescription.getAnnotationType())) {
/*  1664 */                 return false;
/*       */               }
/*       */             } 
/*  1667 */             return true;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */           public Boolean onGenericArray(TypeDescription.Generic genericArray) {
/*  1675 */             return Boolean.valueOf((isValid(genericArray) && ((Boolean)genericArray.getComponentType().<Boolean>accept(this)).booleanValue()));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onWildcard(TypeDescription.Generic wildcard) {
/*  1682 */             if (!isValid(wildcard)) {
/*  1683 */               return Boolean.valueOf(false);
/*       */             }
/*  1685 */             TypeList.Generic lowerBounds = wildcard.getLowerBounds();
/*  1686 */             return ((TypeDescription.Generic)(lowerBounds.isEmpty() ? wildcard
/*  1687 */               .getUpperBounds() : lowerBounds)
/*  1688 */               .getOnly()).<Boolean>accept(this);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1695 */             if (!isValid(parameterizedType)) {
/*  1696 */               return Boolean.valueOf(false);
/*       */             }
/*  1698 */             TypeDescription.Generic ownerType = parameterizedType.getOwnerType();
/*  1699 */             if (ownerType != null && !((Boolean)ownerType.<Boolean>accept(this)).booleanValue()) {
/*  1700 */               return Boolean.valueOf(false);
/*       */             }
/*  1702 */             for (TypeDescription.Generic typeArgument : parameterizedType.getTypeArguments()) {
/*  1703 */               if (!((Boolean)typeArgument.<Boolean>accept(this)).booleanValue()) {
/*  1704 */                 return Boolean.valueOf(false);
/*       */               }
/*       */             } 
/*  1707 */             return Boolean.valueOf(true);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Boolean onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1714 */             return Boolean.valueOf(isValid(typeVariable));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */           public Boolean onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1722 */             return Boolean.valueOf((isValid(typeDescription) && (!typeDescription.isArray() || ((Boolean)typeDescription.getComponentType().<Boolean>accept(this)).booleanValue())));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private boolean isValid(TypeDescription.Generic typeDescription) {
/*  1732 */             Set<TypeDescription> annotationTypes = new HashSet<TypeDescription>();
/*  1733 */             for (AnnotationDescription annotationDescription : typeDescription.getDeclaredAnnotations()) {
/*  1734 */               if (!annotationDescription.isSupportedOn("TYPE_USE") || !annotationTypes.add(annotationDescription.getAnnotationType())) {
/*  1735 */                 return false;
/*       */               }
/*       */             } 
/*  1738 */             return true;
/*       */           }
/*       */         } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Reifying
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*  1752 */         INITIATING
/*       */         {
/*       */           public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1755 */             return parameterizedType;
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1763 */         INHERITING
/*       */         {
/*       */           public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1766 */             return new TypeDescription.Generic.OfParameterizedType.ForReifiedType(parameterizedType);
/*       */           }
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*  1774 */           throw new IllegalArgumentException("Cannot reify a generic array: " + genericArray);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*  1781 */           throw new IllegalArgumentException("Cannot reify a wildcard: " + wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1788 */           throw new IllegalArgumentException("Cannot reify a type variable: " + typeVariable);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1795 */           TypeDescription erasure = typeDescription.asErasure();
/*  1796 */           return erasure.isGenerified() ? new TypeDescription.Generic.OfNonGenericType.ForReifiedErasure(erasure) : typeDescription;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForSignatureVisitor
/*       */         implements Visitor<SignatureVisitor>
/*       */       {
/*       */         private static final int ONLY_CHARACTER = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final SignatureVisitor signatureVisitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForSignatureVisitor(SignatureVisitor signatureVisitor) {
/*  1824 */           this.signatureVisitor = signatureVisitor;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public SignatureVisitor onGenericArray(TypeDescription.Generic genericArray) {
/*  1832 */           genericArray.getComponentType().accept(new ForSignatureVisitor(this.signatureVisitor.visitArrayType()));
/*  1833 */           return this.signatureVisitor;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public SignatureVisitor onWildcard(TypeDescription.Generic wildcard) {
/*  1840 */           throw new IllegalStateException("Unexpected wildcard: " + wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public SignatureVisitor onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1847 */           onOwnableType(parameterizedType);
/*  1848 */           this.signatureVisitor.visitEnd();
/*  1849 */           return this.signatureVisitor;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private void onOwnableType(TypeDescription.Generic ownableType) {
/*  1858 */           TypeDescription.Generic ownerType = ownableType.getOwnerType();
/*  1859 */           if (ownerType != null && ownerType.getSort().isParameterized()) {
/*  1860 */             onOwnableType(ownerType);
/*  1861 */             this.signatureVisitor.visitInnerClassType(ownableType.asErasure().getSimpleName());
/*       */           } else {
/*  1863 */             this.signatureVisitor.visitClassType(ownableType.asErasure().getInternalName());
/*       */           } 
/*  1865 */           for (TypeDescription.Generic typeArgument : ownableType.getTypeArguments()) {
/*  1866 */             typeArgument.accept(new OfTypeArgument(this.signatureVisitor));
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public SignatureVisitor onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1874 */           this.signatureVisitor.visitTypeVariable(typeVariable.getSymbol());
/*  1875 */           return this.signatureVisitor;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public SignatureVisitor onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1883 */           if (typeDescription.isArray()) {
/*  1884 */             typeDescription.getComponentType().accept(new ForSignatureVisitor(this.signatureVisitor.visitArrayType()));
/*  1885 */           } else if (typeDescription.isPrimitive()) {
/*  1886 */             this.signatureVisitor.visitBaseType(typeDescription.asErasure().getDescriptor().charAt(0));
/*       */           } else {
/*  1888 */             this.signatureVisitor.visitClassType(typeDescription.asErasure().getInternalName());
/*  1889 */             this.signatureVisitor.visitEnd();
/*       */           } 
/*  1891 */           return this.signatureVisitor;
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.signatureVisitor.equals(((ForSignatureVisitor)param3Object).signatureVisitor))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.signatureVisitor.hashCode();
/*       */         }
/*       */         
/*       */         protected static class OfTypeArgument
/*       */           extends ForSignatureVisitor {
/*       */           protected OfTypeArgument(SignatureVisitor signatureVisitor) {
/*  1905 */             super(signatureVisitor);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public SignatureVisitor onWildcard(TypeDescription.Generic wildcard) {
/*  1912 */             TypeList.Generic upperBounds = wildcard.getUpperBounds(), lowerBounds = wildcard.getLowerBounds();
/*  1913 */             if (lowerBounds.isEmpty() && ((TypeDescription.Generic)upperBounds.getOnly()).represents(Object.class)) {
/*  1914 */               this.signatureVisitor.visitTypeArgument();
/*  1915 */             } else if (!lowerBounds.isEmpty()) {
/*  1916 */               ((TypeDescription.Generic)lowerBounds.getOnly()).accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(this.signatureVisitor.visitTypeArgument('-')));
/*       */             } else {
/*  1918 */               ((TypeDescription.Generic)upperBounds.getOnly()).accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(this.signatureVisitor.visitTypeArgument('+')));
/*       */             } 
/*  1920 */             return this.signatureVisitor;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public SignatureVisitor onGenericArray(TypeDescription.Generic genericArray) {
/*  1927 */             genericArray.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(this.signatureVisitor.visitTypeArgument('=')));
/*  1928 */             return this.signatureVisitor;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public SignatureVisitor onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  1935 */             parameterizedType.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(this.signatureVisitor.visitTypeArgument('=')));
/*  1936 */             return this.signatureVisitor;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public SignatureVisitor onTypeVariable(TypeDescription.Generic typeVariable) {
/*  1943 */             typeVariable.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(this.signatureVisitor.visitTypeArgument('=')));
/*  1944 */             return this.signatureVisitor;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public SignatureVisitor onNonGenericType(TypeDescription.Generic typeDescription) {
/*  1951 */             typeDescription.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(this.signatureVisitor.visitTypeArgument('=')));
/*  1952 */             return this.signatureVisitor;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static abstract class Substitutor
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*       */         public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*       */           List<TypeDescription.Generic> typeArguments;
/*  1967 */           TypeDescription.Generic ownerType = parameterizedType.getOwnerType();
/*       */           
/*  1969 */           if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  1970 */             typeArguments = Collections.emptyList();
/*       */           } else {
/*  1972 */             typeArguments = new ArrayList<TypeDescription.Generic>(parameterizedType.getTypeArguments().size());
/*  1973 */             for (TypeDescription.Generic typeArgument : parameterizedType.getTypeArguments()) {
/*  1974 */               typeArguments.add(typeArgument.accept(this));
/*       */             }
/*       */           } 
/*  1977 */           return new TypeDescription.Generic.OfParameterizedType.Latent(((TypeDescription.Generic)parameterizedType.asRawType().<TypeDescription.Generic>accept(this)).asErasure(), (ownerType == null) ? TypeDescription.Generic.UNDEFINED : ownerType
/*       */ 
/*       */               
/*  1980 */               .<TypeDescription.Generic>accept(this), typeArguments, parameterizedType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*  1990 */           return new TypeDescription.Generic.OfGenericArray.Latent(genericArray.getComponentType().<TypeDescription.Generic>accept(this), genericArray);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*  1997 */           return new TypeDescription.Generic.OfWildcardType.Latent((List<? extends TypeDescription.Generic>)wildcard.getUpperBounds().accept(this), (List<? extends TypeDescription.Generic>)wildcard.getLowerBounds().accept(this), wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*  2005 */           return typeDescription.isArray() ? new TypeDescription.Generic.OfGenericArray.Latent(typeDescription
/*  2006 */               .getComponentType().<TypeDescription.Generic>accept(this), typeDescription) : 
/*  2007 */             onSimpleType(typeDescription);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract TypeDescription.Generic onSimpleType(TypeDescription.Generic param3Generic);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static abstract class WithoutTypeSubstitution
/*       */           extends Substitutor
/*       */         {
/*       */           public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*  2027 */             return typeDescription;
/*       */           }
/*       */ 
/*       */           
/*       */           protected TypeDescription.Generic onSimpleType(TypeDescription.Generic typeDescription) {
/*  2032 */             return typeDescription;
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForAttachment
/*       */           extends Substitutor
/*       */         {
/*       */           private final TypeDescription declaringType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeVariableSource typeVariableSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ForAttachment(TypeDefinition declaringType, TypeVariableSource typeVariableSource) {
/*  2060 */             this(declaringType.asErasure(), typeVariableSource);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ForAttachment(TypeDescription declaringType, TypeVariableSource typeVariableSource) {
/*  2070 */             this.declaringType = declaringType;
/*  2071 */             this.typeVariableSource = typeVariableSource;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public static ForAttachment of(TypeDescription typeDescription) {
/*  2081 */             return new ForAttachment(typeDescription, typeDescription);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*       */           public static ForAttachment of(FieldDescription fieldDescription) {
/*  2092 */             return new ForAttachment(fieldDescription.getDeclaringType(), fieldDescription.getDeclaringType().asErasure());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public static ForAttachment of(MethodDescription methodDescription) {
/*  2102 */             return new ForAttachment(methodDescription.getDeclaringType(), (TypeVariableSource)methodDescription);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public static ForAttachment of(ParameterDescription parameterDescription) {
/*  2112 */             return new ForAttachment(parameterDescription.getDeclaringMethod().getDeclaringType(), (TypeVariableSource)parameterDescription.getDeclaringMethod());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public static ForAttachment of(RecordComponentDescription recordComponentDescription) {
/*  2122 */             return new ForAttachment(recordComponentDescription.getDeclaringType(), recordComponentDescription.getDeclaringType().asErasure());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2129 */             return new TypeDescription.Generic.OfTypeVariable.WithAnnotationOverlay(this.typeVariableSource.findExpectedVariable(typeVariable.getSymbol()), typeVariable);
/*       */           }
/*       */ 
/*       */           
/*       */           protected TypeDescription.Generic onSimpleType(TypeDescription.Generic typeDescription) {
/*  2134 */             return typeDescription.represents(TargetType.class) ? new TypeDescription.Generic.OfNonGenericType.Latent(this.declaringType, typeDescription) : typeDescription;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.declaringType.equals(((ForAttachment)param4Object).declaringType) ? false : (!!this.typeVariableSource.equals(((ForAttachment)param4Object).typeVariableSource)))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.declaringType.hashCode()) * 31 + this.typeVariableSource.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForDetachment
/*       */           extends Substitutor
/*       */         {
/*       */           private final ElementMatcher<? super TypeDescription> typeMatcher;
/*       */ 
/*       */           
/*       */           public ForDetachment(ElementMatcher<? super TypeDescription> typeMatcher) {
/*  2159 */             this.typeMatcher = typeMatcher;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public static TypeDescription.Generic.Visitor<TypeDescription.Generic> of(TypeDefinition typeDefinition) {
/*  2169 */             return new ForDetachment((ElementMatcher<? super TypeDescription>)ElementMatchers.is(typeDefinition));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2176 */             return new TypeDescription.Generic.OfTypeVariable.Symbolic(typeVariable.getSymbol(), typeVariable);
/*       */           }
/*       */ 
/*       */           
/*       */           protected TypeDescription.Generic onSimpleType(TypeDescription.Generic typeDescription) {
/*  2181 */             return this.typeMatcher.matches(typeDescription.asErasure()) ? new TypeDescription.Generic.OfNonGenericType.Latent(TargetType.DESCRIPTION, typeDescription
/*  2182 */                 .getOwnerType(), typeDescription) : typeDescription;
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.typeMatcher.equals(((ForDetachment)param4Object).typeMatcher))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.typeMatcher.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForTypeVariableBinding
/*       */           extends WithoutTypeSubstitution
/*       */         {
/*       */           private final TypeDescription.Generic parameterizedType;
/*       */           
/*       */           protected ForTypeVariableBinding(TypeDescription.Generic parameterizedType) {
/*  2204 */             this.parameterizedType = parameterizedType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2211 */             return (TypeDescription.Generic)typeVariable.getTypeVariableSource().accept(new TypeVariableSubstitutor(typeVariable));
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.parameterizedType.equals(((ForTypeVariableBinding)param4Object).parameterizedType))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.parameterizedType.hashCode();
/*       */           }
/*       */ 
/*       */           
/*       */           @Enhance(includeSyntheticFields = true)
/*       */           protected class TypeVariableSubstitutor
/*       */             implements TypeVariableSource.Visitor<TypeDescription.Generic>
/*       */           {
/*       */             private final TypeDescription.Generic typeVariable;
/*       */             
/*       */             protected TypeVariableSubstitutor(TypeDescription.Generic typeVariable) {
/*  2232 */               this.typeVariable = typeVariable;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic onType(TypeDescription typeDescription) {
/*  2240 */               TypeDescription.Generic typeArgument = TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.access$200(TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.this).findBindingOf(this.typeVariable);
/*  2241 */               return (typeArgument == null) ? this.typeVariable
/*  2242 */                 .asRawType() : typeArgument;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription.Generic onMethod(MethodDescription.InDefinedShape methodDescription) {
/*  2250 */               return new TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.RetainedMethodTypeVariable(this.typeVariable);
/*       */             }
/*       */ 
/*       */             
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.typeVariable.equals(((TypeVariableSubstitutor)param5Object).typeVariable) ? false : (!!TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.this.equals(TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.this)))));
/*       */             }
/*       */ 
/*       */             
/*       */             public int hashCode() {
/*       */               return (getClass().hashCode() * 31 + this.typeVariable.hashCode()) * 31 + TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.this.hashCode();
/*       */             }
/*       */           }
/*       */           
/*       */           protected class RetainedMethodTypeVariable
/*       */             extends TypeDescription.Generic.OfTypeVariable
/*       */           {
/*       */             private final TypeDescription.Generic typeVariable;
/*       */             
/*       */             protected RetainedMethodTypeVariable(TypeDescription.Generic typeVariable) {
/*  2270 */               this.typeVariable = typeVariable;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeList.Generic getUpperBounds() {
/*  2277 */               return this.typeVariable.getUpperBounds().accept(TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding.this);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeVariableSource getTypeVariableSource() {
/*  2284 */               return this.typeVariable.getTypeVariableSource();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public String getSymbol() {
/*  2291 */               return this.typeVariable.getSymbol();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public AnnotationList getDeclaredAnnotations() {
/*  2298 */               return this.typeVariable.getDeclaredAnnotations();
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForTokenNormalization
/*       */           extends Substitutor
/*       */         {
/*       */           private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForTokenNormalization(TypeDescription typeDescription) {
/*  2320 */             this.typeDescription = typeDescription;
/*       */           }
/*       */ 
/*       */           
/*       */           protected TypeDescription.Generic onSimpleType(TypeDescription.Generic typeDescription) {
/*  2325 */             return typeDescription.represents(TargetType.class) ? new TypeDescription.Generic.OfNonGenericType.Latent(this.typeDescription, typeDescription) : typeDescription;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2334 */             return new TypeDescription.Generic.OfTypeVariable.Symbolic(typeVariable.getSymbol(), typeVariable);
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.typeDescription.equals(((ForTokenNormalization)param4Object).typeDescription))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*       */           }
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         public static class ForReplacement
/*       */           extends Substitutor
/*       */         {
/*       */           private final TypeDescription typeDescription;
/*       */           
/*       */           public ForReplacement(TypeDescription typeDescription) {
/*  2355 */             this.typeDescription = typeDescription;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2362 */             return typeVariable;
/*       */           }
/*       */ 
/*       */           
/*       */           protected TypeDescription.Generic onSimpleType(TypeDescription.Generic typeDescription) {
/*  2367 */             return typeDescription.asErasure().equals(this.typeDescription) ? new TypeDescription.Generic.OfNonGenericType.Latent(this.typeDescription, typeDescription) : typeDescription;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.typeDescription.equals(((ForReplacement)param4Object).typeDescription))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       public static class ForRawType
/*       */         implements Visitor<TypeDescription.Generic>
/*       */       {
/*       */         private final TypeDescription declaringType;
/*       */ 
/*       */         
/*       */         public ForRawType(TypeDescription declaringType) {
/*  2391 */           this.declaringType = declaringType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onGenericArray(TypeDescription.Generic genericArray) {
/*  2398 */           return this.declaringType.isGenerified() ? new TypeDescription.Generic.OfNonGenericType.Latent(genericArray
/*  2399 */               .asErasure(), genericArray) : genericArray;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onWildcard(TypeDescription.Generic wildcard) {
/*  2407 */           throw new IllegalStateException("Did not expect wildcard on top-level: " + wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  2414 */           return this.declaringType.isGenerified() ? new TypeDescription.Generic.OfNonGenericType.Latent(parameterizedType
/*  2415 */               .asErasure(), parameterizedType) : parameterizedType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2423 */           return this.declaringType.isGenerified() ? new TypeDescription.Generic.OfNonGenericType.Latent(typeVariable
/*  2424 */               .asErasure(), typeVariable) : typeVariable;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic onNonGenericType(TypeDescription.Generic typeDescription) {
/*  2432 */           return typeDescription;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Reducing
/*       */         implements Visitor<TypeDescription>
/*       */       {
/*       */         private final TypeDescription declaringType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final List<? extends TypeVariableToken> typeVariableTokens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Reducing(TypeDescription declaringType, TypeVariableToken... typeVariableToken) {
/*  2459 */           this(declaringType, Arrays.asList(typeVariableToken));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Reducing(TypeDescription declaringType, List<? extends TypeVariableToken> typeVariableTokens) {
/*  2469 */           this.declaringType = declaringType;
/*  2470 */           this.typeVariableTokens = typeVariableTokens;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription onGenericArray(TypeDescription.Generic genericArray) {
/*  2478 */           TypeDescription.Generic targetType = genericArray;
/*  2479 */           int arity = 0;
/*       */           while (true) {
/*  2481 */             targetType = targetType.getComponentType();
/*  2482 */             arity++;
/*  2483 */             if (!targetType.isArray()) {
/*  2484 */               if (targetType.getSort().isTypeVariable()) {
/*  2485 */                 for (TypeVariableToken typeVariableToken : this.typeVariableTokens) {
/*  2486 */                   if (targetType.getSymbol().equals(typeVariableToken.getSymbol())) {
/*  2487 */                     return TypeDescription.ArrayProjection.of(((TypeDescription.Generic)typeVariableToken.getBounds().get(0)).<TypeDescription>accept(this), arity);
/*       */                   }
/*       */                 } 
/*  2490 */                 return TargetType.resolve(TypeDescription.ArrayProjection.of(this.declaringType
/*  2491 */                       .findExpectedVariable(targetType.getSymbol()).asErasure(), arity), this.declaringType);
/*       */               } 
/*       */               
/*  2494 */               return TargetType.resolve(genericArray.asErasure(), this.declaringType);
/*       */             } 
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription onWildcard(TypeDescription.Generic wildcard) {
/*  2502 */           throw new IllegalStateException("A wildcard cannot be a top-level type: " + wildcard);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  2509 */           return TargetType.resolve(parameterizedType.asErasure(), this.declaringType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription onTypeVariable(TypeDescription.Generic typeVariable) {
/*  2516 */           for (TypeVariableToken typeVariableToken : this.typeVariableTokens) {
/*  2517 */             if (typeVariable.getSymbol().equals(typeVariableToken.getSymbol())) {
/*  2518 */               return ((TypeDescription.Generic)typeVariableToken.getBounds().get(0)).<TypeDescription>accept(this);
/*       */             }
/*       */           } 
/*  2521 */           return TargetType.resolve(this.declaringType.findExpectedVariable(typeVariable.getSymbol()).asErasure(), this.declaringType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription onNonGenericType(TypeDescription.Generic typeDescription) {
/*  2528 */           return TargetType.resolve(typeDescription.asErasure(), this.declaringType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.declaringType.equals(((Reducing)param3Object).declaringType) ? false : (!!this.typeVariableTokens.equals(((Reducing)param3Object).typeVariableTokens)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.declaringType.hashCode()) * 31 + this.typeVariableTokens.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface AnnotationReader
/*       */     {
/*       */       AnnotatedElement resolve();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationList asList();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofWildcardUpperBoundType(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofWildcardLowerBoundType(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofTypeVariableBoundType(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofTypeArgument(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofOwnerType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofOuterClass();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AnnotationReader ofComponentType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum NoOp
/*       */         implements AnnotationReader, AnnotatedElement
/*       */       {
/*  2624 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotatedElement resolve() {
/*  2630 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList asList() {
/*  2637 */           return (AnnotationList)new AnnotationList.Empty();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofWildcardUpperBoundType(int index) {
/*  2644 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofWildcardLowerBoundType(int index) {
/*  2651 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofTypeVariableBoundType(int index) {
/*  2658 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofTypeArgument(int index) {
/*  2665 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofOwnerType() {
/*  2672 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofOuterClass() {
/*  2679 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofComponentType() {
/*  2686 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isAnnotationPresent(Class<? extends Annotation> annotationClass) {
/*  2693 */           throw new IllegalStateException("Cannot resolve annotations for no-op reader: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public <T extends Annotation> T getAnnotation(Class<T> annotationClass) {
/*  2700 */           throw new IllegalStateException("Cannot resolve annotations for no-op reader: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Annotation[] getAnnotations() {
/*  2707 */           throw new IllegalStateException("Cannot resolve annotations for no-op reader: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Annotation[] getDeclaredAnnotations() {
/*  2714 */           return new Annotation[0];
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static abstract class Delegator
/*       */         implements AnnotationReader
/*       */       {
/*       */         private static final boolean ACCESS_CONTROLLER;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  2732 */           return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofWildcardUpperBoundType(int index) {
/*  2739 */           return new TypeDescription.Generic.AnnotationReader.ForWildcardUpperBoundType(this, index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofWildcardLowerBoundType(int index) {
/*  2746 */           return new TypeDescription.Generic.AnnotationReader.ForWildcardLowerBoundType(this, index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofTypeVariableBoundType(int index) {
/*  2753 */           return new TypeDescription.Generic.AnnotationReader.ForTypeVariableBoundType(this, index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofTypeArgument(int index) {
/*  2760 */           return new TypeDescription.Generic.AnnotationReader.ForTypeArgument(this, index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofOwnerType() {
/*  2767 */           return new TypeDescription.Generic.AnnotationReader.ForOwnerType(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofOuterClass() {
/*  2774 */           return new TypeDescription.Generic.AnnotationReader.ForOwnerType(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.AnnotationReader ofComponentType() {
/*  2781 */           return new TypeDescription.Generic.AnnotationReader.ForComponentType(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList asList() {
/*  2788 */           return (AnnotationList)new AnnotationList.ForLoadedAnnotations(resolve().getDeclaredAnnotations());
/*       */         }
/*       */         
/*       */         static {
/*       */           try {
/*       */             Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*       */             ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*       */           } catch (ClassNotFoundException classNotFoundException) {
/*       */             ACCESS_CONTROLLER = false;
/*       */           } catch (SecurityException securityException) {
/*       */             ACCESS_CONTROLLER = true;
/*       */           } 
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         public static class Simple
/*       */           extends Delegator {
/*       */           private final AnnotatedElement annotatedElement;
/*       */           
/*       */           public Simple(AnnotatedElement annotatedElement) {
/*  2808 */             this.annotatedElement = annotatedElement;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  2815 */             return this.annotatedElement;
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.annotatedElement.equals(((Simple)param4Object).annotatedElement))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.annotatedElement.hashCode();
/*       */           }
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         protected static abstract class Chained
/*       */           extends Delegator
/*       */         {
/*       */           protected final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */           
/*       */           protected Chained(TypeDescription.Generic.AnnotationReader annotationReader) {
/*  2836 */             this.annotationReader = annotationReader;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  2843 */             return resolve(this.annotationReader.resolve());
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           protected abstract AnnotatedElement resolve(AnnotatedElement param4AnnotatedElement);
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.annotationReader.equals(((Chained)param4Object).annotationReader))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.annotationReader.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForLoadedTypeVariable
/*       */           extends Delegator
/*       */         {
/*       */           private final TypeVariable<?> typeVariable;
/*       */ 
/*       */           
/*       */           public ForLoadedTypeVariable(TypeVariable<?> typeVariable) {
/*  2872 */             this.typeVariable = typeVariable;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"BC_VACUOUS_INSTANCEOF"}, justification = "Cast is required for JVMs before Java 8.")
/*       */           public AnnotatedElement resolve() {
/*  2881 */             return (this.typeVariable instanceof AnnotatedElement) ? this.typeVariable : TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic.AnnotationReader ofTypeVariableBoundType(int index) {
/*  2890 */             return new TypeDescription.Generic.AnnotationReader.ForTypeVariableBoundType.OfFormalTypeVariable(this.typeVariable, index);
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.typeVariable.equals(((ForLoadedTypeVariable)param4Object).typeVariable))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.typeVariable.hashCode();
/*       */           }
/*       */         }
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         public static class ForLoadedSuperClass
/*       */           extends Delegator
/*       */         {
/*       */           private final Class<?> type;
/*       */           
/*       */           public ForLoadedSuperClass(Class<?> type) {
/*  2911 */             this.type = type;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  2918 */             AnnotatedElement element = TypeDescription.ForLoadedType.DISPATCHER.getAnnotatedSuperclass(this.type);
/*  2919 */             return (element == null) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : element;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.type.equals(((ForLoadedSuperClass)param4Object).type))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.type.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         public static class ForLoadedInterface
/*       */           extends Delegator
/*       */         {
/*       */           private final Class<?> type;
/*       */ 
/*       */           
/*       */           private final int index;
/*       */ 
/*       */           
/*       */           public ForLoadedInterface(Class<?> type, int index) {
/*  2948 */             this.type = type;
/*  2949 */             this.index = index;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  2956 */             AnnotatedElement[] element = TypeDescription.ForLoadedType.DISPATCHER.getAnnotatedInterfaces(this.type);
/*  2957 */             return (element.length == 0) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : element[this.index];
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((ForLoadedInterface)param4Object).index) ? false : (!!this.type.equals(((ForLoadedInterface)param4Object).type)))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.type.hashCode()) * 31 + this.index;
/*       */           } }
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         public static class ForLoadedField extends Delegator {
/*  2970 */           protected static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Field field;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForLoadedField(Field field) {
/*  2983 */             this.field = field;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  2990 */             AnnotatedElement element = DISPATCHER.getAnnotatedType(this.field);
/*  2991 */             return (element == null) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : element;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.field.equals(((ForLoadedField)param4Object).field))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.field.hashCode();
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("java.lang.reflect.Field")
/*       */           protected static interface Dispatcher
/*       */           {
/*       */             @MaybeNull
/*       */             @Defaults
/*       */             @Proxied("getAnnotatedType")
/*       */             AnnotatedElement getAnnotatedType(Field param5Field);
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         public static class ForLoadedMethodReturnType
/*       */           extends Delegator
/*       */         {
/*  3023 */           protected static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Method method;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForLoadedMethodReturnType(Method method) {
/*  3036 */             this.method = method;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  3043 */             AnnotatedElement element = DISPATCHER.getAnnotatedReturnType(this.method);
/*  3044 */             return (element == null) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : element;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.method.equals(((ForLoadedMethodReturnType)param4Object).method))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.method.hashCode();
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("java.lang.reflect.Method")
/*       */           protected static interface Dispatcher
/*       */           {
/*       */             @MaybeNull
/*       */             @Defaults
/*       */             @Proxied("getAnnotatedReturnType")
/*       */             AnnotatedElement getAnnotatedReturnType(Method param5Method);
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         public static class ForLoadedExecutableParameterType
/*       */           extends Delegator
/*       */         {
/*  3076 */           protected static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AccessibleObject executable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForLoadedExecutableParameterType(AccessibleObject executable, int index) {
/*  3095 */             this.executable = executable;
/*  3096 */             this.index = index;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  3103 */             AnnotatedElement[] element = DISPATCHER.getAnnotatedParameterTypes(this.executable);
/*  3104 */             return (element.length == 0) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : element[this.index];
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((ForLoadedExecutableParameterType)param4Object).index) ? false : (!!this.executable.equals(((ForLoadedExecutableParameterType)param4Object).executable)))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.executable.hashCode()) * 31 + this.index;
/*       */           }
/*       */ 
/*       */           
/*       */           @Proxied("java.lang.reflect.Executable")
/*       */           protected static interface Dispatcher
/*       */           {
/*       */             @Defaults
/*       */             @Proxied("getAnnotatedParameterTypes")
/*       */             AnnotatedElement[] getAnnotatedParameterTypes(Object param5Object);
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         public static class ForLoadedExecutableExceptionType
/*       */           extends Delegator
/*       */         {
/*  3133 */           protected static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AccessibleObject executable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForLoadedExecutableExceptionType(AccessibleObject executable, int index) {
/*  3152 */             this.executable = executable;
/*  3153 */             this.index = index;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  3160 */             AnnotatedElement[] element = DISPATCHER.getAnnotatedExceptionTypes(this.executable);
/*  3161 */             return (element.length == 0) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : element[this.index];
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((ForLoadedExecutableExceptionType)param4Object).index) ? false : (!!this.executable.equals(((ForLoadedExecutableExceptionType)param4Object).executable)))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.executable.hashCode()) * 31 + this.index;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("java.lang.reflect.Executable")
/*       */           protected static interface Dispatcher
/*       */           {
/*       */             @Defaults
/*       */             @Proxied("getAnnotatedExceptionTypes")
/*       */             AnnotatedElement[] getAnnotatedExceptionTypes(Object param5Object);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public static class ForLoadedRecordComponent
/*       */           extends Delegator
/*       */         {
/*       */           private final Object recordComponent;
/*       */ 
/*       */ 
/*       */           
/*       */           public ForLoadedRecordComponent(Object recordComponent) {
/*  3197 */             this.recordComponent = recordComponent;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*  3204 */             return RecordComponentDescription.ForLoadedRecordComponent.RECORD_COMPONENT.getAnnotatedType(this.recordComponent);
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForWildcardUpperBoundType
/*       */         extends Delegator.Chained
/*       */       {
/*  3218 */         private static final AnnotatedWildcardType ANNOTATED_WILDCARD_TYPE = doPrivileged(JavaDispatcher.of(AnnotatedWildcardType.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForWildcardUpperBoundType(TypeDescription.Generic.AnnotationReader annotationReader, int index) {
/*  3232 */           super(annotationReader);
/*  3233 */           this.index = index;
/*       */         }
/*       */ 
/*       */         
/*       */         protected AnnotatedElement resolve(AnnotatedElement annotatedElement) {
/*  3238 */           if (!ANNOTATED_WILDCARD_TYPE.isInstance(annotatedElement)) {
/*  3239 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           }
/*       */           try {
/*  3242 */             AnnotatedElement[] annotatedUpperBound = ANNOTATED_WILDCARD_TYPE.getAnnotatedUpperBounds(annotatedElement);
/*  3243 */             return (annotatedUpperBound.length == 0) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : annotatedUpperBound[this.index];
/*       */           
/*       */           }
/*  3246 */           catch (ClassCastException ignored) {
/*  3247 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.index != ((ForWildcardUpperBoundType)param3Object).index)))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Proxied("java.lang.reflect.AnnotatedWildcardType")
/*       */         protected static interface AnnotatedWildcardType
/*       */         {
/*       */           @Instance
/*       */           @Proxied("isInstance")
/*       */           boolean isInstance(AnnotatedElement param4AnnotatedElement);
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("getAnnotatedUpperBounds")
/*       */           AnnotatedElement[] getAnnotatedUpperBounds(AnnotatedElement param4AnnotatedElement);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForWildcardLowerBoundType
/*       */         extends Delegator.Chained
/*       */       {
/*  3285 */         private static final AnnotatedWildcardType ANNOTATED_WILDCARD_TYPE = doPrivileged(JavaDispatcher.of(AnnotatedWildcardType.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForWildcardLowerBoundType(TypeDescription.Generic.AnnotationReader annotationReader, int index) {
/*  3299 */           super(annotationReader);
/*  3300 */           this.index = index;
/*       */         }
/*       */ 
/*       */         
/*       */         protected AnnotatedElement resolve(AnnotatedElement annotatedElement) {
/*  3305 */           if (!ANNOTATED_WILDCARD_TYPE.isInstance(annotatedElement)) {
/*  3306 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           }
/*       */           try {
/*  3309 */             return ANNOTATED_WILDCARD_TYPE.getAnnotatedLowerBounds(annotatedElement)[this.index];
/*  3310 */           } catch (ClassCastException ignored) {
/*  3311 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.index != ((ForWildcardLowerBoundType)param3Object).index)))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Proxied("java.lang.reflect.AnnotatedWildcardType")
/*       */         protected static interface AnnotatedWildcardType
/*       */         {
/*       */           @Instance
/*       */           @Proxied("isInstance")
/*       */           boolean isInstance(AnnotatedElement param4AnnotatedElement);
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("getAnnotatedLowerBounds")
/*       */           AnnotatedElement[] getAnnotatedLowerBounds(AnnotatedElement param4AnnotatedElement);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForTypeVariableBoundType
/*       */         extends Delegator.Chained
/*       */       {
/*  3349 */         private static final AnnotatedTypeVariable ANNOTATED_TYPE_VARIABLE = doPrivileged(JavaDispatcher.of(AnnotatedTypeVariable.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForTypeVariableBoundType(TypeDescription.Generic.AnnotationReader annotationReader, int index) {
/*  3363 */           super(annotationReader);
/*  3364 */           this.index = index;
/*       */         }
/*       */ 
/*       */         
/*       */         protected AnnotatedElement resolve(AnnotatedElement annotatedElement) {
/*  3369 */           if (!ANNOTATED_TYPE_VARIABLE.isInstance(annotatedElement)) {
/*  3370 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           }
/*       */           try {
/*  3373 */             return ANNOTATED_TYPE_VARIABLE.getAnnotatedBounds(annotatedElement)[this.index];
/*  3374 */           } catch (ClassCastException ignored) {
/*  3375 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.index != ((ForTypeVariableBoundType)param3Object).index)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class OfFormalTypeVariable
/*       */           extends TypeDescription.Generic.AnnotationReader.Delegator
/*       */         {
/*  3412 */           private static final FormalTypeVariable TYPE_VARIABLE = doPrivileged(JavaDispatcher.of(FormalTypeVariable.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeVariable<?> typeVariable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected OfFormalTypeVariable(TypeVariable<?> typeVariable, int index) {
/*  3431 */             this.typeVariable = typeVariable;
/*  3432 */             this.index = index;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotatedElement resolve() {
/*       */             try {
/*  3440 */               AnnotatedElement[] annotatedBound = TYPE_VARIABLE.getAnnotatedBounds(this.typeVariable);
/*  3441 */               return (annotatedBound.length == 0) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : annotatedBound[this.index];
/*       */             
/*       */             }
/*  3444 */             catch (ClassCastException ignored) {
/*  3445 */               return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */             } 
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((OfFormalTypeVariable)param4Object).index) ? false : (!!this.typeVariable.equals(((OfFormalTypeVariable)param4Object).typeVariable)))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.typeVariable.hashCode()) * 31 + this.index;
/*       */           }
/*       */           
/*       */           @Proxied("java.lang.reflect.TypeVariable")
/*       */           protected static interface FormalTypeVariable {
/*       */             @Defaults
/*       */             @Proxied("getAnnotatedBounds")
/*       */             AnnotatedElement[] getAnnotatedBounds(Object param5Object);
/*       */           }
/*       */         }
/*       */         
/*       */         @Proxied("java.lang.reflect.AnnotatedTypeVariable")
/*       */         protected static interface AnnotatedTypeVariable {
/*       */           @Instance
/*       */           @Proxied("isInstance")
/*       */           boolean isInstance(AnnotatedElement param4AnnotatedElement);
/*       */           
/*       */           @Proxied("getAnnotatedBounds")
/*       */           AnnotatedElement[] getAnnotatedBounds(AnnotatedElement param4AnnotatedElement);
/*       */         }
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       public static class ForTypeArgument extends Delegator.Chained {
/*  3478 */         private static final AnnotatedParameterizedType ANNOTATED_PARAMETERIZED_TYPE = doPrivileged(JavaDispatcher.of(AnnotatedParameterizedType.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForTypeArgument(TypeDescription.Generic.AnnotationReader annotationReader, int index) {
/*  3492 */           super(annotationReader);
/*  3493 */           this.index = index;
/*       */         }
/*       */ 
/*       */         
/*       */         protected AnnotatedElement resolve(AnnotatedElement annotatedElement) {
/*  3498 */           if (!ANNOTATED_PARAMETERIZED_TYPE.isInstance(annotatedElement)) {
/*  3499 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           }
/*       */           try {
/*  3502 */             return ANNOTATED_PARAMETERIZED_TYPE.getAnnotatedActualTypeArguments(annotatedElement)[this.index];
/*  3503 */           } catch (ClassCastException ignored) {
/*  3504 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.index != ((ForTypeArgument)param3Object).index)))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Proxied("java.lang.reflect.AnnotatedParameterizedType")
/*       */         protected static interface AnnotatedParameterizedType
/*       */         {
/*       */           @Instance
/*       */           @Proxied("isInstance")
/*       */           boolean isInstance(AnnotatedElement param4AnnotatedElement);
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("getAnnotatedActualTypeArguments")
/*       */           AnnotatedElement[] getAnnotatedActualTypeArguments(AnnotatedElement param4AnnotatedElement);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForComponentType
/*       */         extends Delegator.Chained
/*       */       {
/*  3541 */         private static final AnnotatedParameterizedType ANNOTATED_PARAMETERIZED_TYPE = doPrivileged(JavaDispatcher.of(AnnotatedParameterizedType.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForComponentType(TypeDescription.Generic.AnnotationReader annotationReader) {
/*  3549 */           super(annotationReader);
/*       */         }
/*       */ 
/*       */         
/*       */         protected AnnotatedElement resolve(AnnotatedElement annotatedElement) {
/*  3554 */           if (!ANNOTATED_PARAMETERIZED_TYPE.isInstance(annotatedElement)) {
/*  3555 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           }
/*       */           try {
/*  3558 */             return ANNOTATED_PARAMETERIZED_TYPE.getAnnotatedGenericComponentType(annotatedElement);
/*  3559 */           } catch (ClassCastException ignored) {
/*  3560 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Proxied("java.lang.reflect.AnnotatedArrayType")
/*       */         protected static interface AnnotatedParameterizedType
/*       */         {
/*       */           @Instance
/*       */           @Proxied("isInstance")
/*       */           boolean isInstance(AnnotatedElement param4AnnotatedElement);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Proxied("getAnnotatedGenericComponentType")
/*       */           AnnotatedElement getAnnotatedGenericComponentType(AnnotatedElement param4AnnotatedElement);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForOwnerType
/*       */         extends Delegator.Chained
/*       */       {
/*  3597 */         private static final AnnotatedType ANNOTATED_TYPE = doPrivileged(JavaDispatcher.of(AnnotatedType.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForOwnerType(TypeDescription.Generic.AnnotationReader annotationReader) {
/*  3605 */           super(annotationReader);
/*       */         }
/*       */ 
/*       */         
/*       */         protected AnnotatedElement resolve(AnnotatedElement annotatedElement) {
/*       */           try {
/*  3611 */             AnnotatedElement annotatedOwnerType = ANNOTATED_TYPE.getAnnotatedOwnerType(annotatedElement);
/*  3612 */             return (annotatedOwnerType == null) ? TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE : annotatedOwnerType;
/*       */           
/*       */           }
/*  3615 */           catch (ClassCastException ignored) {
/*  3616 */             return TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Proxied("java.lang.reflect.AnnotatedType")
/*       */         protected static interface AnnotatedType
/*       */         {
/*       */           @MaybeNull
/*       */           @Defaults
/*       */           @Proxied("getAnnotatedOwnerType")
/*       */           AnnotatedElement getAnnotatedOwnerType(AnnotatedElement param4AnnotatedElement);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class AbstractBase
/*       */       extends ModifierReviewable.AbstractBase
/*       */       implements Generic
/*       */     {
/*       */       public int getModifiers() {
/*  3648 */         return asErasure().getModifiers();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asGenericType() {
/*  3655 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asRawType() {
/*  3662 */         return asErasure().asGenericType();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean represents(Type type) {
/*  3669 */         return equals(TypeDefinition.Sort.describe(type));
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class LazyProxy
/*       */       implements InvocationHandler
/*       */     {
/*       */       private final Class<?> type;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected LazyProxy(Class<?> type) {
/*  3691 */         this.type = type;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static TypeDescription.Generic of(Class<?> type) {
/*  3701 */         return (TypeDescription.Generic)Proxy.newProxyInstance(TypeDescription.Generic.class.getClassLoader(), new Class[] { TypeDescription.Generic.class }, new LazyProxy(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Object invoke(Object proxy, Method method, @MaybeNull Object[] argument) throws Throwable {
/*       */         try {
/*  3711 */           return method.invoke(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.type), argument);
/*  3712 */         } catch (InvocationTargetException exception) {
/*  3713 */           throw exception.getTargetException();
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.type.equals(((LazyProxy)param2Object).type))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.type.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     public static abstract class OfNonGenericType
/*       */       extends AbstractBase
/*       */     {
/*       */       public TypeDefinition.Sort getSort() {
/*  3734 */         return TypeDefinition.Sort.NON_GENERIC;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getSuperClass() {
/*  3742 */         TypeDescription erasure = asErasure();
/*  3743 */         TypeDescription.Generic superClass = erasure.getSuperClass();
/*  3744 */         if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  3745 */           return superClass;
/*       */         }
/*  3747 */         return (superClass == null) ? TypeDescription.Generic.UNDEFINED : new TypeDescription.Generic.LazyProjection.WithResolvedErasure(superClass, new TypeDescription.Generic.Visitor.ForRawType(erasure), (AnnotationSource)AnnotationSource.Empty.INSTANCE);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getInterfaces() {
/*  3756 */         TypeDescription erasure = asErasure();
/*  3757 */         if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  3758 */           return erasure.getInterfaces();
/*       */         }
/*  3760 */         return new TypeList.Generic.ForDetachedTypes.WithResolvedErasure((List<? extends TypeDescription.Generic>)erasure.getInterfaces(), new TypeDescription.Generic.Visitor.ForRawType(erasure));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  3767 */         TypeDescription erasure = asErasure();
/*  3768 */         return (FieldList<FieldDescription.InGenericShape>)new FieldList.TypeSubstituting(this, (List)erasure.getDeclaredFields(), TypeDescription.AbstractBase.RAW_TYPES ? TypeDescription.Generic.Visitor.NoOp.INSTANCE : new TypeDescription.Generic.Visitor.ForRawType(erasure));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  3777 */         TypeDescription erasure = asErasure();
/*  3778 */         return (MethodList<MethodDescription.InGenericShape>)new MethodList.TypeSubstituting(this, (List)erasure.getDeclaredMethods(), TypeDescription.AbstractBase.RAW_TYPES ? TypeDescription.Generic.Visitor.NoOp.INSTANCE : new TypeDescription.Generic.Visitor.ForRawType(erasure));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  3787 */         TypeDescription erasure = asErasure();
/*  3788 */         return new RecordComponentList.TypeSubstituting(this, (List)erasure.getRecordComponents(), TypeDescription.AbstractBase.RAW_TYPES ? TypeDescription.Generic.Visitor.NoOp.INSTANCE : new TypeDescription.Generic.Visitor.ForRawType(erasure));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getTypeArguments() {
/*  3797 */         throw new IllegalStateException("A non-generic type does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  3804 */         throw new IllegalStateException("A non-generic type does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  3811 */         return visitor.onNonGenericType(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getTypeName() {
/*  3818 */         return asErasure().getTypeName();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getUpperBounds() {
/*  3825 */         throw new IllegalStateException("A non-generic type does not imply upper type bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getLowerBounds() {
/*  3832 */         throw new IllegalStateException("A non-generic type does not imply lower type bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeVariableSource getTypeVariableSource() {
/*  3839 */         throw new IllegalStateException("A non-generic type does not imply a type variable source: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getSymbol() {
/*  3846 */         throw new IllegalStateException("A non-generic type does not imply a symbol: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  3853 */         return asErasure().getStackSize();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getActualName() {
/*  3860 */         return asErasure().getActualName();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  3867 */         return asErasure().isArray();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrimitive() {
/*  3874 */         return asErasure().isPrimitive();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isRecord() {
/*  3881 */         return asErasure().isRecord();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean represents(Type type) {
/*  3888 */         return asErasure().represents(type);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<TypeDefinition> iterator() {
/*  3895 */         return new TypeDefinition.SuperClassIterator(this);
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("hashCode")
/*       */       public int hashCode() {}
/*       */ 
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"EQ_CHECK_FOR_OPERAND_NOT_COMPATIBLE_WITH_THIS"}, justification = "Type check is performed by erasure implementation.")
/*       */       public boolean equals(@MaybeNull Object other) {
/*  3907 */         return (this == other || asErasure().equals(other));
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/*  3912 */         return asErasure().toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedType
/*       */         extends OfNonGenericType
/*       */       {
/*  3929 */         private static final Map<Class<?>, TypeDescription.Generic> TYPE_CACHE = new HashMap<Class<?>, TypeDescription.Generic>(); private final Class<?> type; private final TypeDescription.Generic.AnnotationReader annotationReader; static {
/*  3930 */           TYPE_CACHE.put(TargetType.class, new ForLoadedType(TargetType.class));
/*  3931 */           TYPE_CACHE.put(Class.class, new ForLoadedType(Class.class));
/*  3932 */           TYPE_CACHE.put(Throwable.class, new ForLoadedType(Throwable.class));
/*  3933 */           TYPE_CACHE.put(Annotation.class, new ForLoadedType(Annotation.class));
/*  3934 */           TYPE_CACHE.put(Object.class, new ForLoadedType(Object.class));
/*  3935 */           TYPE_CACHE.put(String.class, new ForLoadedType(String.class));
/*  3936 */           TYPE_CACHE.put(Boolean.class, new ForLoadedType(Boolean.class));
/*  3937 */           TYPE_CACHE.put(Byte.class, new ForLoadedType(Byte.class));
/*  3938 */           TYPE_CACHE.put(Short.class, new ForLoadedType(Short.class));
/*  3939 */           TYPE_CACHE.put(Character.class, new ForLoadedType(Character.class));
/*  3940 */           TYPE_CACHE.put(Integer.class, new ForLoadedType(Integer.class));
/*  3941 */           TYPE_CACHE.put(Long.class, new ForLoadedType(Long.class));
/*  3942 */           TYPE_CACHE.put(Float.class, new ForLoadedType(Float.class));
/*  3943 */           TYPE_CACHE.put(Double.class, new ForLoadedType(Double.class));
/*  3944 */           TYPE_CACHE.put(void.class, new ForLoadedType(void.class));
/*  3945 */           TYPE_CACHE.put(boolean.class, new ForLoadedType(boolean.class));
/*  3946 */           TYPE_CACHE.put(byte.class, new ForLoadedType(byte.class));
/*  3947 */           TYPE_CACHE.put(short.class, new ForLoadedType(short.class));
/*  3948 */           TYPE_CACHE.put(char.class, new ForLoadedType(char.class));
/*  3949 */           TYPE_CACHE.put(int.class, new ForLoadedType(int.class));
/*  3950 */           TYPE_CACHE.put(long.class, new ForLoadedType(long.class));
/*  3951 */           TYPE_CACHE.put(float.class, new ForLoadedType(float.class));
/*  3952 */           TYPE_CACHE.put(double.class, new ForLoadedType(double.class));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedType(Class<?> type) {
/*  3972 */           this(type, TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForLoadedType(Class<?> type, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  3983 */           this.type = type;
/*  3984 */           this.annotationReader = annotationReader;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static TypeDescription.Generic of(Class<?> type) {
/*  3994 */           TypeDescription.Generic typeDescription = TYPE_CACHE.get(type);
/*  3995 */           return (typeDescription == null) ? new ForLoadedType(type) : typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  4004 */           return TypeDescription.ForLoadedType.of(this.type);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  4012 */           Class<?> declaringClass = this.type.getDeclaringClass();
/*  4013 */           return (declaringClass == null) ? TypeDescription.Generic.UNDEFINED : new ForLoadedType(declaringClass, this.annotationReader
/*       */               
/*  4015 */               .ofOuterClass());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getComponentType() {
/*  4023 */           Class<?> componentType = this.type.getComponentType();
/*  4024 */           return (componentType == null) ? TypeDescription.Generic.UNDEFINED : new ForLoadedType(componentType, this.annotationReader
/*       */               
/*  4026 */               .ofComponentType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4033 */           return this.annotationReader.asList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean represents(Type type) {
/*  4040 */           return (this.type == type || super.represents(type));
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForErasure
/*       */         extends OfNonGenericType
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForErasure(TypeDescription typeDescription) {
/*  4062 */           this.typeDescription = typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  4069 */           return this.typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  4077 */           TypeDescription declaringType = this.typeDescription.getDeclaringType();
/*  4078 */           return (declaringType == null) ? TypeDescription.Generic.UNDEFINED : declaringType
/*       */             
/*  4080 */             .asGenericType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getComponentType() {
/*  4088 */           TypeDescription componentType = this.typeDescription.getComponentType();
/*  4089 */           return (componentType == null) ? TypeDescription.Generic.UNDEFINED : componentType
/*       */             
/*  4091 */             .asGenericType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4098 */           return (AnnotationList)new AnnotationList.Empty();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Latent
/*       */         extends OfNonGenericType
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         private final TypeDescription.Generic declaringType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Latent(TypeDescription typeDescription, AnnotationSource annotationSource) {
/*  4130 */           this(typeDescription, typeDescription.getDeclaringType(), annotationSource);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private Latent(TypeDescription typeDescription, @MaybeNull TypeDescription declaringType, AnnotationSource annotationSource) {
/*  4141 */           this(typeDescription, (declaringType == null) ? TypeDescription.Generic.UNDEFINED : declaringType
/*       */ 
/*       */               
/*  4144 */               .asGenericType(), annotationSource);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Latent(TypeDescription typeDescription, @MaybeNull TypeDescription.Generic declaringType, AnnotationSource annotationSource) {
/*  4156 */           this.typeDescription = typeDescription;
/*  4157 */           this.declaringType = declaringType;
/*  4158 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  4166 */           return this.declaringType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getComponentType() {
/*  4174 */           TypeDescription componentType = this.typeDescription.getComponentType();
/*  4175 */           return (componentType == null) ? TypeDescription.Generic.UNDEFINED : componentType
/*       */             
/*  4177 */             .asGenericType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4184 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  4191 */           return this.typeDescription;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForReifiedErasure
/*       */         extends OfNonGenericType
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForReifiedErasure(TypeDescription typeDescription) {
/*  4212 */           this.typeDescription = typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static TypeDescription.Generic of(TypeDescription typeDescription) {
/*  4222 */           return typeDescription.isGenerified() ? new ForReifiedErasure(typeDescription) : new TypeDescription.Generic.OfNonGenericType.ForErasure(typeDescription);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getSuperClass() {
/*  4232 */           TypeDescription.Generic superClass = this.typeDescription.getSuperClass();
/*  4233 */           return (superClass == null) ? TypeDescription.Generic.UNDEFINED : new TypeDescription.Generic.LazyProjection.WithResolvedErasure(superClass, TypeDescription.Generic.Visitor.Reifying.INHERITING);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getInterfaces() {
/*  4242 */           return new TypeList.Generic.ForDetachedTypes.WithResolvedErasure((List<? extends TypeDescription.Generic>)this.typeDescription.getInterfaces(), TypeDescription.Generic.Visitor.Reifying.INHERITING);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  4249 */           return (FieldList<FieldDescription.InGenericShape>)new FieldList.TypeSubstituting(this, (List)this.typeDescription.getDeclaredFields(), TypeDescription.Generic.Visitor.TypeErasing.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  4256 */           return (MethodList<MethodDescription.InGenericShape>)new MethodList.TypeSubstituting(this, (List)this.typeDescription.getDeclaredMethods(), TypeDescription.Generic.Visitor.TypeErasing.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  4263 */           return this.typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  4271 */           TypeDescription declaringType = this.typeDescription.getDeclaringType();
/*  4272 */           return (declaringType == null) ? TypeDescription.Generic.UNDEFINED : 
/*       */             
/*  4274 */             of(declaringType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getComponentType() {
/*  4282 */           TypeDescription componentType = this.typeDescription.getComponentType();
/*  4283 */           return (componentType == null) ? TypeDescription.Generic.UNDEFINED : 
/*       */             
/*  4285 */             of(componentType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4292 */           return (AnnotationList)new AnnotationList.Empty();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class OfGenericArray
/*       */       extends AbstractBase
/*       */     {
/*       */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */       public TypeDefinition.Sort getSort() {
/*  4308 */         return getComponentType().getSort().isNonGeneric() ? TypeDefinition.Sort.NON_GENERIC : TypeDefinition.Sort.GENERIC_ARRAY;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */       public TypeDescription asErasure() {
/*  4318 */         return TypeDescription.ArrayProjection.of(getComponentType().asErasure(), 1);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getSuperClass() {
/*  4326 */         return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getInterfaces() {
/*  4333 */         return TypeDescription.ARRAY_INTERFACES;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  4340 */         return (FieldList<FieldDescription.InGenericShape>)new FieldList.Empty();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  4347 */         return (MethodList<MethodDescription.InGenericShape>)new MethodList.Empty();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  4354 */         return new RecordComponentList.Empty<RecordComponentDescription.InGenericShape>();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getUpperBounds() {
/*  4361 */         throw new IllegalStateException("A generic array type does not imply upper type bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getLowerBounds() {
/*  4368 */         throw new IllegalStateException("A generic array type does not imply lower type bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeVariableSource getTypeVariableSource() {
/*  4375 */         throw new IllegalStateException("A generic array type does not imply a type variable source: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getTypeArguments() {
/*  4382 */         throw new IllegalStateException("A generic array type does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  4389 */         throw new IllegalStateException("A generic array type does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getOwnerType() {
/*  4397 */         return TypeDescription.Generic.UNDEFINED;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getSymbol() {
/*  4404 */         throw new IllegalStateException("A generic array type does not imply a symbol: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getTypeName() {
/*  4411 */         return getSort().isNonGeneric() ? 
/*  4412 */           asErasure().getTypeName() : 
/*  4413 */           toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getActualName() {
/*  4420 */         return getSort().isNonGeneric() ? 
/*  4421 */           asErasure().getActualName() : 
/*  4422 */           toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  4429 */         return true;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrimitive() {
/*  4436 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isRecord() {
/*  4443 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<TypeDefinition> iterator() {
/*  4450 */         return new TypeDefinition.SuperClassIterator(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  4457 */         return getSort().isNonGeneric() ? visitor
/*  4458 */           .onNonGenericType(this) : visitor
/*  4459 */           .onGenericArray(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  4466 */         return StackSize.SINGLE;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("hashCode")
/*       */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */       public int hashCode() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"EQ_CHECK_FOR_OPERAND_NOT_COMPATIBLE_WITH_THIS", "NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Type check is performed by erasure implementation. Assuming component type for array type.")
/*       */       public boolean equals(@MaybeNull Object other) {
/*  4483 */         if (this == other)
/*  4484 */           return true; 
/*  4485 */         if (getSort().isNonGeneric()) {
/*  4486 */           return asErasure().equals(other);
/*       */         }
/*  4488 */         if (!(other instanceof TypeDescription.Generic)) {
/*  4489 */           return false;
/*       */         }
/*  4491 */         TypeDescription.Generic typeDescription = (TypeDescription.Generic)other;
/*  4492 */         return (typeDescription.getSort().isGenericArray() && getComponentType().equals(typeDescription.getComponentType()));
/*       */       }
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */       public String toString() {
/*  4498 */         return getSort().isNonGeneric() ? 
/*  4499 */           asErasure().toString() : (
/*  4500 */           getComponentType().getTypeName() + "[]");
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedType
/*       */         extends OfGenericArray
/*       */       {
/*       */         private final GenericArrayType genericArrayType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedType(GenericArrayType genericArrayType) {
/*  4524 */           this(genericArrayType, TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForLoadedType(GenericArrayType genericArrayType, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  4534 */           this.genericArrayType = genericArrayType;
/*  4535 */           this.annotationReader = annotationReader;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getComponentType() {
/*  4543 */           return TypeDefinition.Sort.describeOrNull(this.genericArrayType.getGenericComponentType(), this.annotationReader.ofComponentType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4550 */           return this.annotationReader.asList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean represents(Type type) {
/*  4557 */           return (this.genericArrayType == type || super.represents(type));
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Latent
/*       */         extends OfGenericArray
/*       */       {
/*       */         private final TypeDescription.Generic componentType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Latent(TypeDescription.Generic componentType, AnnotationSource annotationSource) {
/*  4583 */           this.componentType = componentType;
/*  4584 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic getComponentType() {
/*  4591 */           return this.componentType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4598 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class OfWildcardType
/*       */       extends AbstractBase
/*       */     {
/*       */       public static final String SYMBOL = "?";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDefinition.Sort getSort() {
/*  4617 */         return TypeDefinition.Sort.WILDCARD;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription asErasure() {
/*  4624 */         throw new IllegalStateException("A wildcard does not represent an erasable type: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getSuperClass() {
/*  4632 */         throw new IllegalStateException("A wildcard does not imply a super type definition: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getInterfaces() {
/*  4639 */         throw new IllegalStateException("A wildcard does not imply an interface type definition: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  4646 */         throw new IllegalStateException("A wildcard does not imply field definitions: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  4653 */         throw new IllegalStateException("A wildcard does not imply method definitions: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  4660 */         throw new IllegalStateException("A wildcard does not imply record component definitions: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic getComponentType() {
/*  4667 */         throw new IllegalStateException("A wildcard does not imply a component type: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeVariableSource getTypeVariableSource() {
/*  4674 */         throw new IllegalStateException("A wildcard does not imply a type variable source: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getTypeArguments() {
/*  4681 */         throw new IllegalStateException("A wildcard does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  4688 */         throw new IllegalStateException("A wildcard does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic getOwnerType() {
/*  4695 */         throw new IllegalStateException("A wildcard does not imply an owner type: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getSymbol() {
/*  4702 */         throw new IllegalStateException("A wildcard does not imply a symbol: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getTypeName() {
/*  4709 */         return toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getActualName() {
/*  4716 */         return toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrimitive() {
/*  4723 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  4730 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isRecord() {
/*  4737 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean represents(Type type) {
/*  4744 */         return equals(TypeDefinition.Sort.describe(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<TypeDefinition> iterator() {
/*  4751 */         throw new IllegalStateException("A wildcard does not imply a super type definition: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  4758 */         return visitor.onWildcard(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  4765 */         throw new IllegalStateException("A wildcard does not imply an operand stack size: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("hashCode")
/*       */       public int hashCode() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object other) {
/*  4783 */         if (this == other)
/*  4784 */           return true; 
/*  4785 */         if (!(other instanceof TypeDescription.Generic)) {
/*  4786 */           return false;
/*       */         }
/*  4788 */         TypeDescription.Generic typeDescription = (TypeDescription.Generic)other;
/*  4789 */         return (typeDescription.getSort().isWildcard() && 
/*  4790 */           getUpperBounds().equals(typeDescription.getUpperBounds()) && 
/*  4791 */           getLowerBounds().equals(typeDescription.getLowerBounds()));
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/*  4796 */         StringBuilder stringBuilder = new StringBuilder("?");
/*  4797 */         TypeList.Generic bounds = getLowerBounds();
/*  4798 */         if (!bounds.isEmpty()) {
/*  4799 */           stringBuilder.append(" super ");
/*       */         } else {
/*  4801 */           bounds = getUpperBounds();
/*  4802 */           if (((TypeDescription.Generic)bounds.getOnly()).equals(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class))) {
/*  4803 */             return "?";
/*       */           }
/*  4805 */           stringBuilder.append(" extends ");
/*       */         } 
/*  4807 */         return stringBuilder.append(((TypeDescription.Generic)bounds.getOnly()).getTypeName()).toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedType
/*       */         extends OfWildcardType
/*       */       {
/*       */         private final WildcardType wildcardType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedType(WildcardType wildcardType) {
/*  4831 */           this(wildcardType, TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForLoadedType(WildcardType wildcardType, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  4841 */           this.wildcardType = wildcardType;
/*  4842 */           this.annotationReader = annotationReader;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getUpperBounds() {
/*  4849 */           return new WildcardUpperBoundTypeList(this.wildcardType.getUpperBounds(), this.annotationReader);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getLowerBounds() {
/*  4856 */           return new WildcardLowerBoundTypeList(this.wildcardType.getLowerBounds(), this.annotationReader);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  4863 */           return this.annotationReader.asList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean represents(Type type) {
/*  4870 */           return (this.wildcardType == type || super.represents(type));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class WildcardUpperBoundTypeList
/*       */           extends TypeList.Generic.AbstractBase
/*       */         {
/*       */           private final Type[] upperBound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected WildcardUpperBoundTypeList(Type[] upperBound, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  4895 */             this.upperBound = upperBound;
/*  4896 */             this.annotationReader = annotationReader;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic get(int index) {
/*  4903 */             return TypeDefinition.Sort.describeOrNull(this.upperBound[index], this.annotationReader.ofWildcardUpperBoundType(index));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int size() {
/*  4910 */             return this.upperBound.length;
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class WildcardLowerBoundTypeList
/*       */           extends TypeList.Generic.AbstractBase
/*       */         {
/*       */           private final Type[] lowerBound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected WildcardLowerBoundTypeList(Type[] lowerBound, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  4936 */             this.lowerBound = lowerBound;
/*  4937 */             this.annotationReader = annotationReader;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic get(int index) {
/*  4944 */             return TypeDefinition.Sort.describeOrNull(this.lowerBound[index], this.annotationReader.ofWildcardLowerBoundType(index));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int size() {
/*  4951 */             return this.lowerBound.length;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Latent
/*       */         extends OfWildcardType
/*       */       {
/*       */         private final List<? extends TypeDescription.Generic> upperBounds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final List<? extends TypeDescription.Generic> lowerBounds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Latent(List<? extends TypeDescription.Generic> upperBounds, List<? extends TypeDescription.Generic> lowerBounds, AnnotationSource annotationSource) {
/*  4984 */           this.upperBounds = upperBounds;
/*  4985 */           this.lowerBounds = lowerBounds;
/*  4986 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static TypeDescription.Generic unbounded(AnnotationSource annotationSource) {
/*  4996 */           return new Latent(Collections.singletonList(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)), Collections.emptyList(), annotationSource);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static TypeDescription.Generic boundedAbove(TypeDescription.Generic upperBound, AnnotationSource annotationSource) {
/*  5007 */           return new Latent(Collections.singletonList(upperBound), Collections.emptyList(), annotationSource);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static TypeDescription.Generic boundedBelow(TypeDescription.Generic lowerBound, AnnotationSource annotationSource) {
/*  5018 */           return new Latent(Collections.singletonList(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)), Collections.singletonList(lowerBound), annotationSource);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getUpperBounds() {
/*  5025 */           return new TypeList.Generic.Explicit((List)this.upperBounds);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getLowerBounds() {
/*  5032 */           return new TypeList.Generic.Explicit((List)this.lowerBounds);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  5039 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class OfParameterizedType
/*       */       extends AbstractBase
/*       */     {
/*       */       public TypeDefinition.Sort getSort() {
/*  5053 */         return TypeDefinition.Sort.PARAMETERIZED;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getSuperClass() {
/*  5061 */         TypeDescription.Generic superClass = asErasure().getSuperClass();
/*  5062 */         return (superClass == null) ? TypeDescription.Generic.UNDEFINED : new TypeDescription.Generic.LazyProjection.WithResolvedErasure(superClass, new TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding(this));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getInterfaces() {
/*  5071 */         return new TypeList.Generic.ForDetachedTypes.WithResolvedErasure((List<? extends TypeDescription.Generic>)asErasure().getInterfaces(), new TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding(this));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  5078 */         return (FieldList<FieldDescription.InGenericShape>)new FieldList.TypeSubstituting(this, (List)asErasure().getDeclaredFields(), new TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding(this));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  5085 */         return (MethodList<MethodDescription.InGenericShape>)new MethodList.TypeSubstituting(this, (List)asErasure().getDeclaredMethods(), new TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding(this));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  5092 */         return new RecordComponentList.TypeSubstituting(this, (List)asErasure().getRecordComponents(), new TypeDescription.Generic.Visitor.Substitutor.ForTypeVariableBinding(this));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  5100 */         TypeDescription.Generic typeDescription = this;
/*       */         do {
/*  5102 */           TypeList.Generic typeArguments = typeDescription.getTypeArguments(), typeVariables = typeDescription.asErasure().getTypeVariables();
/*  5103 */           for (int index = 0; index < Math.min(typeArguments.size(), typeVariables.size()); index++) {
/*  5104 */             if (typeVariable.equals(typeVariables.get(index))) {
/*  5105 */               return (TypeDescription.Generic)typeArguments.get(index);
/*       */             }
/*       */           } 
/*  5108 */           typeDescription = typeDescription.getOwnerType();
/*  5109 */         } while (typeDescription != null && typeDescription.getSort().isParameterized());
/*  5110 */         return TypeDescription.Generic.UNDEFINED;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getUpperBounds() {
/*  5117 */         throw new IllegalStateException("A parameterized type does not imply upper bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getLowerBounds() {
/*  5124 */         throw new IllegalStateException("A parameterized type does not imply lower bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic getComponentType() {
/*  5131 */         throw new IllegalStateException("A parameterized type does not imply a component type: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeVariableSource getTypeVariableSource() {
/*  5138 */         throw new IllegalStateException("A parameterized type does not imply a type variable source: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getSymbol() {
/*  5145 */         throw new IllegalStateException("A parameterized type does not imply a symbol: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getTypeName() {
/*  5152 */         return toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getActualName() {
/*  5159 */         return toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrimitive() {
/*  5166 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  5173 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isRecord() {
/*  5180 */         return asErasure().isRecord();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean represents(Type type) {
/*  5187 */         return equals(TypeDefinition.Sort.describe(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<TypeDefinition> iterator() {
/*  5194 */         return new TypeDefinition.SuperClassIterator(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  5201 */         return visitor.onParameterizedType(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  5208 */         return StackSize.SINGLE;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("hashCode")
/*       */       public int hashCode() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object other) {
/*  5226 */         if (this == other)
/*  5227 */           return true; 
/*  5228 */         if (!(other instanceof TypeDescription.Generic)) {
/*  5229 */           return false;
/*       */         }
/*  5231 */         TypeDescription.Generic typeDescription = (TypeDescription.Generic)other;
/*  5232 */         if (!typeDescription.getSort().isParameterized()) {
/*  5233 */           return false;
/*       */         }
/*  5235 */         TypeDescription.Generic ownerType = getOwnerType(), otherOwnerType = typeDescription.getOwnerType();
/*  5236 */         return (asErasure().equals(typeDescription.asErasure()) && (ownerType != null || otherOwnerType == null) && (ownerType == null || ownerType
/*  5237 */           .equals(otherOwnerType)) && 
/*  5238 */           getTypeArguments().equals(typeDescription.getTypeArguments()));
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/*  5243 */         StringBuilder stringBuilder = new StringBuilder();
/*  5244 */         RenderingDelegate.CURRENT.apply(stringBuilder, asErasure(), getOwnerType());
/*  5245 */         TypeList.Generic typeArguments = getTypeArguments();
/*  5246 */         if (!typeArguments.isEmpty()) {
/*  5247 */           stringBuilder.append('<');
/*  5248 */           boolean multiple = false;
/*  5249 */           for (TypeDescription.Generic typeArgument : typeArguments) {
/*  5250 */             if (multiple) {
/*  5251 */               stringBuilder.append(", ");
/*       */             }
/*  5253 */             stringBuilder.append(typeArgument.getTypeName());
/*  5254 */             multiple = true;
/*       */           } 
/*  5256 */           stringBuilder.append('>');
/*       */         } 
/*  5258 */         return stringBuilder.toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected enum RenderingDelegate
/*       */       {
/*  5270 */         FOR_LEGACY_VM
/*       */         {
/*       */           protected void apply(StringBuilder stringBuilder, TypeDescription erasure, @MaybeNull TypeDescription.Generic ownerType) {
/*  5273 */             if (ownerType != null) {
/*  5274 */               stringBuilder.append(ownerType.getTypeName()).append('.').append(ownerType.getSort().isParameterized() ? erasure
/*  5275 */                   .getSimpleName() : erasure
/*  5276 */                   .getName());
/*       */             } else {
/*  5278 */               stringBuilder.append(erasure.getName());
/*       */ 
/*       */ 
/*       */             
/*       */             }
/*       */           
/*       */           }
/*       */         },
/*  5286 */         FOR_JAVA_8_CAPABLE_VM
/*       */         {
/*       */           protected void apply(StringBuilder stringBuilder, TypeDescription erasure, @MaybeNull TypeDescription.Generic ownerType) {
/*  5289 */             if (ownerType != null) {
/*  5290 */               stringBuilder.append(ownerType.getTypeName()).append('$');
/*  5291 */               if (ownerType.getSort().isParameterized()) {
/*  5292 */                 stringBuilder.append(erasure.getName().replace(ownerType.asErasure().getName() + "$", ""));
/*       */               } else {
/*  5294 */                 stringBuilder.append(erasure.getSimpleName());
/*       */               } 
/*       */             } else {
/*  5297 */               stringBuilder.append(erasure.getName());
/*       */             } 
/*       */           }
/*       */         };
/*       */ 
/*       */         
/*       */         protected abstract void apply(StringBuilder param3StringBuilder, TypeDescription param3TypeDescription, @MaybeNull TypeDescription.Generic param3Generic);
/*       */         
/*  5305 */         protected static final RenderingDelegate CURRENT = ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtLeast(ClassFileVersion.JAVA_V8) ? FOR_JAVA_8_CAPABLE_VM : FOR_LEGACY_VM;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*       */         
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedType
/*       */         extends OfParameterizedType
/*       */       {
/*       */         private final ParameterizedType parameterizedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedType(ParameterizedType parameterizedType) {
/*  5340 */           this(parameterizedType, TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForLoadedType(ParameterizedType parameterizedType, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  5350 */           this.parameterizedType = parameterizedType;
/*  5351 */           this.annotationReader = annotationReader;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getTypeArguments() {
/*  5358 */           return new ParameterArgumentTypeList(this.parameterizedType.getActualTypeArguments(), this.annotationReader);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  5366 */           Type ownerType = this.parameterizedType.getOwnerType();
/*  5367 */           return (ownerType == null) ? TypeDescription.Generic.UNDEFINED : 
/*       */             
/*  5369 */             TypeDefinition.Sort.describe(ownerType, this.annotationReader.ofOwnerType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  5376 */           return TypeDescription.ForLoadedType.of((Class)this.parameterizedType.getRawType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  5383 */           return this.annotationReader.asList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean represents(Type type) {
/*  5390 */           return (this.parameterizedType == type || super.represents(type));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class ParameterArgumentTypeList
/*       */           extends TypeList.Generic.AbstractBase
/*       */         {
/*       */           private final Type[] argumentType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ParameterArgumentTypeList(Type[] argumentType, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  5415 */             this.argumentType = argumentType;
/*  5416 */             this.annotationReader = annotationReader;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic get(int index) {
/*  5423 */             return TypeDefinition.Sort.describeOrNull(this.argumentType[index], this.annotationReader.ofTypeArgument(index));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int size() {
/*  5430 */             return this.argumentType.length;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Latent
/*       */         extends OfParameterizedType
/*       */       {
/*       */         private final TypeDescription rawType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         private final TypeDescription.Generic ownerType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final List<? extends TypeDescription.Generic> parameters;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Latent(TypeDescription rawType, @MaybeNull TypeDescription.Generic ownerType, List<? extends TypeDescription.Generic> parameters, AnnotationSource annotationSource) {
/*  5473 */           this.rawType = rawType;
/*  5474 */           this.ownerType = ownerType;
/*  5475 */           this.parameters = parameters;
/*  5476 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  5483 */           return this.rawType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  5491 */           return this.ownerType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getTypeArguments() {
/*  5498 */           return new TypeList.Generic.Explicit((List)this.parameters);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  5505 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForReifiedType
/*       */         extends OfParameterizedType
/*       */       {
/*       */         private final TypeDescription.Generic parameterizedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForReifiedType(TypeDescription.Generic parameterizedType) {
/*  5527 */           this.parameterizedType = parameterizedType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getSuperClass() {
/*  5535 */           TypeDescription.Generic superClass = super.getSuperClass();
/*  5536 */           return (superClass == null) ? TypeDescription.Generic.UNDEFINED : new TypeDescription.Generic.LazyProjection.WithResolvedErasure(superClass, TypeDescription.Generic.Visitor.Reifying.INHERITING);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getInterfaces() {
/*  5545 */           return new TypeList.Generic.ForDetachedTypes.WithResolvedErasure((List<? extends TypeDescription.Generic>)super.getInterfaces(), TypeDescription.Generic.Visitor.Reifying.INHERITING);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  5552 */           return (FieldList<FieldDescription.InGenericShape>)new FieldList.TypeSubstituting(this, (List)super.getDeclaredFields(), TypeDescription.Generic.Visitor.TypeErasing.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  5559 */           return (MethodList<MethodDescription.InGenericShape>)new MethodList.TypeSubstituting(this, (List)super.getDeclaredMethods(), TypeDescription.Generic.Visitor.TypeErasing.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getTypeArguments() {
/*  5566 */           return new TypeList.Generic.ForDetachedTypes((List<? extends TypeDescription.Generic>)this.parameterizedType.getTypeArguments(), TypeDescription.Generic.Visitor.TypeErasing.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  5574 */           TypeDescription.Generic ownerType = this.parameterizedType.getOwnerType();
/*  5575 */           return (ownerType == null) ? TypeDescription.Generic.UNDEFINED : ownerType
/*       */             
/*  5577 */             .<TypeDescription.Generic>accept(TypeDescription.Generic.Visitor.Reifying.INHERITING);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  5584 */           return this.parameterizedType.asErasure();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  5591 */           return (AnnotationList)new AnnotationList.Empty();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForGenerifiedErasure
/*       */         extends OfParameterizedType
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForGenerifiedErasure(TypeDescription typeDescription) {
/*  5611 */           this.typeDescription = typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static TypeDescription.Generic of(TypeDescription typeDescription) {
/*  5621 */           return typeDescription.isGenerified() ? new ForGenerifiedErasure(typeDescription) : new TypeDescription.Generic.OfNonGenericType.ForErasure(typeDescription);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  5630 */           return this.typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getTypeArguments() {
/*  5637 */           return new TypeList.Generic.ForDetachedTypes((List<? extends TypeDescription.Generic>)this.typeDescription.getTypeVariables(), TypeDescription.Generic.Visitor.AnnotationStripper.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getOwnerType() {
/*  5645 */           TypeDescription declaringType = this.typeDescription.getDeclaringType();
/*  5646 */           return (declaringType == null) ? TypeDescription.Generic.UNDEFINED : 
/*       */             
/*  5648 */             of(declaringType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  5655 */           return (AnnotationList)new AnnotationList.Empty();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class OfTypeVariable
/*       */       extends AbstractBase
/*       */     {
/*       */       public TypeDefinition.Sort getSort() {
/*  5669 */         return TypeDefinition.Sort.VARIABLE;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription asErasure() {
/*  5676 */         TypeList.Generic upperBounds = getUpperBounds();
/*  5677 */         return upperBounds.isEmpty() ? 
/*  5678 */           TypeDescription.ForLoadedType.of(Object.class) : ((TypeDescription.Generic)upperBounds
/*  5679 */           .get(0)).asErasure();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getSuperClass() {
/*  5687 */         throw new IllegalStateException("A type variable does not imply a super type definition: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getInterfaces() {
/*  5694 */         throw new IllegalStateException("A type variable does not imply an interface type definition: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  5701 */         throw new IllegalStateException("A type variable does not imply field definitions: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  5708 */         throw new IllegalStateException("A type variable does not imply method definitions: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  5715 */         throw new IllegalStateException("A type variable does not imply record component definitions: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic getComponentType() {
/*  5722 */         throw new IllegalStateException("A type variable does not imply a component type: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getTypeArguments() {
/*  5729 */         throw new IllegalStateException("A type variable does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  5736 */         throw new IllegalStateException("A type variable does not imply type arguments: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getLowerBounds() {
/*  5743 */         throw new IllegalStateException("A type variable does not imply lower bounds: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic getOwnerType() {
/*  5750 */         throw new IllegalStateException("A type variable does not imply an owner type: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getTypeName() {
/*  5757 */         return toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getActualName() {
/*  5764 */         return getSymbol();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  5771 */         return visitor.onTypeVariable(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  5778 */         return StackSize.SINGLE;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  5785 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrimitive() {
/*  5792 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isRecord() {
/*  5799 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean represents(Type type) {
/*  5806 */         return equals(TypeDefinition.Sort.describe(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<TypeDefinition> iterator() {
/*  5813 */         throw new IllegalStateException("A type variable does not imply a super type definition: " + this);
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("hashCode")
/*       */       public int hashCode() {}
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object other) {
/*  5824 */         if (this == other)
/*  5825 */           return true; 
/*  5826 */         if (!(other instanceof TypeDescription.Generic)) {
/*  5827 */           return false;
/*       */         }
/*  5829 */         TypeDescription.Generic typeDescription = (TypeDescription.Generic)other;
/*  5830 */         return (typeDescription.getSort().isTypeVariable() && 
/*  5831 */           getSymbol().equals(typeDescription.getSymbol()) && 
/*  5832 */           getTypeVariableSource().equals(typeDescription.getTypeVariableSource()));
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/*  5837 */         return getSymbol();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Symbolic
/*       */         extends TypeDescription.Generic.AbstractBase
/*       */       {
/*       */         private final String symbol;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Symbolic(String symbol, AnnotationSource annotationSource) {
/*  5862 */           this.symbol = symbol;
/*  5863 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDefinition.Sort getSort() {
/*  5870 */           return TypeDefinition.Sort.VARIABLE_SYMBOLIC;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String getSymbol() {
/*  5877 */           return this.symbol;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  5884 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  5891 */           throw new IllegalStateException("A symbolic type variable does not imply an erasure: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getUpperBounds() {
/*  5898 */           throw new IllegalStateException("A symbolic type variable does not imply an upper type bound: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeVariableSource getTypeVariableSource() {
/*  5905 */           throw new IllegalStateException("A symbolic type variable does not imply a variable source: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getSuperClass() {
/*  5913 */           throw new IllegalStateException("A symbolic type variable does not imply a super type definition: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getInterfaces() {
/*  5920 */           throw new IllegalStateException("A symbolic type variable does not imply an interface type definition: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  5927 */           throw new IllegalStateException("A symbolic type variable does not imply field definitions: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  5934 */           throw new IllegalStateException("A symbolic type variable does not imply method definitions: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  5941 */           throw new IllegalStateException("A symbolic type variable does not imply record component definitions: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic getComponentType() {
/*  5948 */           throw new IllegalStateException("A symbolic type variable does not imply a component type: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getTypeArguments() {
/*  5955 */           throw new IllegalStateException("A symbolic type variable does not imply type arguments: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  5962 */           throw new IllegalStateException("A symbolic type variable does not imply type arguments: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getLowerBounds() {
/*  5969 */           throw new IllegalStateException("A symbolic type variable does not imply lower bounds: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic getOwnerType() {
/*  5976 */           throw new IllegalStateException("A symbolic type variable does not imply an owner type: " + this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String getTypeName() {
/*  5983 */           return toString();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String getActualName() {
/*  5990 */           return getSymbol();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  5997 */           return visitor.onTypeVariable(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public StackSize getStackSize() {
/*  6004 */           return StackSize.SINGLE;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isArray() {
/*  6011 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isPrimitive() {
/*  6018 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isRecord() {
/*  6025 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean represents(Type type) {
/*  6032 */           if (type == null) {
/*  6033 */             throw new NullPointerException();
/*       */           }
/*  6035 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterator<TypeDefinition> iterator() {
/*  6042 */           throw new IllegalStateException("A symbolic type variable does not imply a super type definition: " + this);
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*  6047 */           return this.symbol.hashCode();
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object other) {
/*  6052 */           if (this == other)
/*  6053 */             return true; 
/*  6054 */           if (!(other instanceof TypeDescription.Generic)) {
/*  6055 */             return false;
/*       */           }
/*  6057 */           TypeDescription.Generic typeDescription = (TypeDescription.Generic)other;
/*  6058 */           return (typeDescription.getSort().isTypeVariable() && getSymbol().equals(typeDescription.getSymbol()));
/*       */         }
/*       */ 
/*       */         
/*       */         public String toString() {
/*  6063 */           return getSymbol();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedType
/*       */         extends OfTypeVariable
/*       */       {
/*       */         private final TypeVariable<?> typeVariable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedType(TypeVariable<?> typeVariable) {
/*  6088 */           this(typeVariable, TypeDescription.Generic.AnnotationReader.NoOp.INSTANCE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForLoadedType(TypeVariable<?> typeVariable, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  6098 */           this.typeVariable = typeVariable;
/*  6099 */           this.annotationReader = annotationReader;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeVariableSource getTypeVariableSource() {
/*  6106 */           GenericDeclaration genericDeclaration = (GenericDeclaration)this.typeVariable.getGenericDeclaration();
/*  6107 */           if (genericDeclaration instanceof Class)
/*  6108 */             return TypeDescription.ForLoadedType.of((Class)genericDeclaration); 
/*  6109 */           if (genericDeclaration instanceof Method)
/*  6110 */             return (TypeVariableSource)new MethodDescription.ForLoadedMethod((Method)genericDeclaration); 
/*  6111 */           if (genericDeclaration instanceof Constructor) {
/*  6112 */             return (TypeVariableSource)new MethodDescription.ForLoadedConstructor((Constructor)genericDeclaration);
/*       */           }
/*  6114 */           throw new IllegalStateException("Unknown declaration: " + genericDeclaration);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getUpperBounds() {
/*  6122 */           return new TypeVariableBoundList(this.typeVariable.getBounds(), this.annotationReader);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String getSymbol() {
/*  6129 */           return this.typeVariable.getName();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  6136 */           return this.annotationReader.asList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean represents(Type type) {
/*  6143 */           return (this.typeVariable == type || super.represents(type));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class TypeVariableBoundList
/*       */           extends TypeList.Generic.AbstractBase
/*       */         {
/*       */           private final Type[] bound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeDescription.Generic.AnnotationReader annotationReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected TypeVariableBoundList(Type[] bound, TypeDescription.Generic.AnnotationReader annotationReader) {
/*  6168 */             this.bound = bound;
/*  6169 */             this.annotationReader = annotationReader;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic get(int index) {
/*  6176 */             return TypeDefinition.Sort.describeOrNull(this.bound[index], this.annotationReader.ofTypeVariableBoundType(index));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int size() {
/*  6183 */             return this.bound.length;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class WithAnnotationOverlay
/*       */         extends OfTypeVariable
/*       */       {
/*       */         private final TypeDescription.Generic typeVariable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public WithAnnotationOverlay(TypeDescription.Generic typeVariable, AnnotationSource annotationSource) {
/*  6210 */           this.typeVariable = typeVariable;
/*  6211 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  6218 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getUpperBounds() {
/*  6225 */           return this.typeVariable.getUpperBounds();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeVariableSource getTypeVariableSource() {
/*  6232 */           return this.typeVariable.getTypeVariableSource();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String getSymbol() {
/*  6239 */           return this.typeVariable.getSymbol();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class LazyProjection
/*       */       extends AbstractBase
/*       */     {
/*       */       public TypeDefinition.Sort getSort() {
/*  6262 */         return resolve().getSort();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public FieldList<FieldDescription.InGenericShape> getDeclaredFields() {
/*  6269 */         return resolve().getDeclaredFields();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodList<MethodDescription.InGenericShape> getDeclaredMethods() {
/*  6276 */         return resolve().getDeclaredMethods();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public RecordComponentList<RecordComponentDescription.InGenericShape> getRecordComponents() {
/*  6283 */         return resolve().getRecordComponents();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getUpperBounds() {
/*  6290 */         return resolve().getUpperBounds();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getLowerBounds() {
/*  6297 */         return resolve().getLowerBounds();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getComponentType() {
/*  6305 */         return resolve().getComponentType();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeList.Generic getTypeArguments() {
/*  6312 */         return resolve().getTypeArguments();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic findBindingOf(TypeDescription.Generic typeVariable) {
/*  6320 */         return resolve().findBindingOf(typeVariable);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeVariableSource getTypeVariableSource() {
/*  6327 */         return resolve().getTypeVariableSource();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription.Generic getOwnerType() {
/*  6335 */         return resolve().getOwnerType();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getTypeName() {
/*  6342 */         return resolve().getTypeName();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getSymbol() {
/*  6349 */         return resolve().getSymbol();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getActualName() {
/*  6356 */         return resolve().getActualName();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public <T> T accept(TypeDescription.Generic.Visitor<T> visitor) {
/*  6363 */         return resolve().accept(visitor);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  6370 */         return asErasure().getStackSize();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  6377 */         return asErasure().isArray();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrimitive() {
/*  6384 */         return asErasure().isPrimitive();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isRecord() {
/*  6391 */         return asErasure().isRecord();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean represents(Type type) {
/*  6398 */         return resolve().represents(type);
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("hashCode")
/*       */       public int hashCode() {}
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object other) {
/*  6409 */         return (this == other || (other instanceof TypeDefinition && resolve().equals(other)));
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/*  6414 */         return resolve().toString();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract TypeDescription.Generic resolve();
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static abstract class WithLazyNavigation
/*       */         extends LazyProjection
/*       */       {
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getSuperClass() {
/*  6430 */           return LazySuperClass.of(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getInterfaces() {
/*  6437 */           return LazyInterfaceList.of(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterator<TypeDefinition> iterator() {
/*  6444 */           return new TypeDefinition.SuperClassIterator(this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class LazySuperClass
/*       */           extends WithLazyNavigation
/*       */         {
/*       */           private final TypeDescription.Generic.LazyProjection delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected LazySuperClass(TypeDescription.Generic.LazyProjection delegate) {
/*  6463 */             this.delegate = delegate;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @MaybeNull
/*       */           protected static TypeDescription.Generic of(TypeDescription.Generic.LazyProjection delegate) {
/*  6474 */             return (delegate.asErasure().getSuperClass() == null) ? TypeDescription.Generic.UNDEFINED : new LazySuperClass(delegate);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotationList getDeclaredAnnotations() {
/*  6483 */             return resolve().getDeclaredAnnotations();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming super class for given instance.")
/*       */           public TypeDescription asErasure() {
/*  6491 */             return this.delegate.asErasure().getSuperClass().asErasure();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Enhance("resolved")
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming super class for given instance.")
/*       */           protected TypeDescription.Generic resolve() {}
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class LazyInterfaceType
/*       */           extends WithLazyNavigation
/*       */         {
/*       */           private final TypeDescription.Generic.LazyProjection delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeDescription.Generic rawInterface;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected LazyInterfaceType(TypeDescription.Generic.LazyProjection delegate, int index, TypeDescription.Generic rawInterface) {
/*  6530 */             this.delegate = delegate;
/*  6531 */             this.index = index;
/*  6532 */             this.rawInterface = rawInterface;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public AnnotationList getDeclaredAnnotations() {
/*  6539 */             return resolve().getDeclaredAnnotations();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription asErasure() {
/*  6546 */             return this.rawInterface.asErasure();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Enhance("resolved")
/*       */           protected TypeDescription.Generic resolve() {}
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class LazyInterfaceList
/*       */           extends TypeList.Generic.AbstractBase
/*       */         {
/*       */           private final TypeDescription.Generic.LazyProjection delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeList.Generic rawInterfaces;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected LazyInterfaceList(TypeDescription.Generic.LazyProjection delegate, TypeList.Generic rawInterfaces) {
/*  6578 */             this.delegate = delegate;
/*  6579 */             this.rawInterfaces = rawInterfaces;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static TypeList.Generic of(TypeDescription.Generic.LazyProjection delegate) {
/*  6589 */             return new LazyInterfaceList(delegate, delegate.asErasure().getInterfaces());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDescription.Generic get(int index) {
/*  6596 */             return new TypeDescription.Generic.LazyProjection.WithLazyNavigation.LazyInterfaceType(this.delegate, index, (TypeDescription.Generic)this.rawInterfaces.get(index));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int size() {
/*  6603 */             return this.rawInterfaces.size();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static abstract class OfAnnotatedElement
/*       */           extends WithLazyNavigation
/*       */         {
/*       */           public AnnotationList getDeclaredAnnotations() {
/*  6623 */             return getAnnotationReader().asList();
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           protected abstract TypeDescription.Generic.AnnotationReader getAnnotationReader();
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       public static abstract class WithEagerNavigation
/*       */         extends LazyProjection
/*       */       {
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getSuperClass() {
/*  6638 */           return resolve().getSuperClass();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getInterfaces() {
/*  6645 */           return resolve().getInterfaces();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterator<TypeDefinition> iterator() {
/*  6652 */           return resolve().iterator();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static abstract class OfAnnotatedElement
/*       */           extends WithEagerNavigation
/*       */         {
/*       */           public AnnotationList getDeclaredAnnotations() {
/*  6671 */             return getAnnotationReader().asList();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected abstract TypeDescription.Generic.AnnotationReader getAnnotationReader();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedSuperClass
/*       */         extends WithLazyNavigation.OfAnnotatedElement
/*       */       {
/*       */         private final Class<?> type;
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForLoadedSuperClass(Class<?> type) {
/*  6692 */           this.type = type;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public static TypeDescription.Generic of(Class<?> type) {
/*  6703 */           return (type.getSuperclass() == null) ? TypeDescription.Generic.UNDEFINED : new ForLoadedSuperClass(type);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("resolved")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  6720 */           return TypeDescription.ForLoadedType.of(this.type.getSuperclass());
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  6725 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedSuperClass(this.type);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedFieldType
/*       */         extends WithEagerNavigation.OfAnnotatedElement
/*       */       {
/*       */         private final Field field;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedFieldType(Field field) {
/*  6745 */           this.field = field;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("resolved")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  6758 */           return TypeDescription.ForLoadedType.of(this.field.getType());
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  6763 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedField(this.field);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class ForLoadedReturnType
/*       */         extends WithEagerNavigation.OfAnnotatedElement
/*       */       {
/*       */         private final Method method;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForLoadedReturnType(Method method) {
/*  6783 */           this.method = method;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("resolved")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  6796 */           return TypeDescription.ForLoadedType.of(this.method.getReturnType());
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  6801 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedMethodReturnType(this.method);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class OfConstructorParameter
/*       */         extends WithEagerNavigation.OfAnnotatedElement
/*       */       {
/*       */         private final Constructor<?> constructor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Class<?>[] erasure;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"EI_EXPOSE_REP2"}, justification = "The array is not modified by class contract.")
/*       */         public OfConstructorParameter(Constructor<?> constructor, int index, Class<?>[] erasure) {
/*  6834 */           this.constructor = constructor;
/*  6835 */           this.index = index;
/*  6836 */           this.erasure = erasure;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("delegate")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  6852 */           return TypeDescription.ForLoadedType.of(this.erasure[this.index]);
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  6857 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedExecutableParameterType(this.constructor, this.index);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class OfMethodParameter
/*       */         extends WithEagerNavigation.OfAnnotatedElement
/*       */       {
/*       */         private final Method method;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Class<?>[] erasure;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"EI_EXPOSE_REP2"}, justification = "The array is not modified by class contract.")
/*       */         public OfMethodParameter(Method method, int index, Class<?>[] erasure) {
/*  6890 */           this.method = method;
/*  6891 */           this.index = index;
/*  6892 */           this.erasure = erasure;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("resolved")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  6908 */           return TypeDescription.ForLoadedType.of(this.erasure[this.index]);
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  6913 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedExecutableParameterType(this.method, this.index);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class OfRecordComponent
/*       */         extends WithEagerNavigation.OfAnnotatedElement
/*       */       {
/*       */         private final Object recordComponent;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfRecordComponent(Object recordComponent) {
/*  6933 */           this.recordComponent = recordComponent;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("resolved")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  6946 */           return TypeDescription.ForLoadedType.of(RecordComponentDescription.ForLoadedRecordComponent.RECORD_COMPONENT.getType(this.recordComponent));
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.AnnotationReader getAnnotationReader() {
/*  6951 */           return new TypeDescription.Generic.AnnotationReader.Delegator.ForLoadedRecordComponent(this.recordComponent);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class WithResolvedErasure
/*       */         extends WithEagerNavigation
/*       */       {
/*       */         private final TypeDescription.Generic delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AnnotationSource annotationSource;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public WithResolvedErasure(TypeDescription.Generic delegate, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  6982 */           this(delegate, visitor, delegate);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public WithResolvedErasure(TypeDescription.Generic delegate, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor, AnnotationSource annotationSource) {
/*  6993 */           this.delegate = delegate;
/*  6994 */           this.visitor = visitor;
/*  6995 */           this.annotationSource = annotationSource;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  7002 */           return this.annotationSource.getDeclaredAnnotations();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription asErasure() {
/*  7009 */           return this.delegate.asErasure();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance("resolved")
/*       */         protected TypeDescription.Generic resolve() {}
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static abstract class Builder
/*       */     {
/*       */       @AlwaysNull
/*  7030 */       private static final Type UNDEFINED = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends AnnotationDescription> annotations;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Builder(List<? extends AnnotationDescription> annotations) {
/*  7043 */         this.annotations = annotations;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder of(Type type) {
/*  7053 */         return of(TypeDefinition.Sort.describe(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder of(TypeDescription.Generic typeDescription) {
/*  7063 */         return typeDescription.<Builder>accept(Visitor.INSTANCE);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder rawType(Class<?> type) {
/*  7073 */         return rawType(TypeDescription.ForLoadedType.of(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder rawType(TypeDescription type) {
/*  7083 */         return new OfNonGenericType(type);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder rawType(Class<?> type, @MaybeNull TypeDescription.Generic ownerType) {
/*  7094 */         return rawType(TypeDescription.ForLoadedType.of(type), ownerType);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder rawType(TypeDescription type, @MaybeNull TypeDescription.Generic ownerType) {
/*  7105 */         TypeDescription declaringType = type.getDeclaringType();
/*  7106 */         if (declaringType == null && ownerType != null)
/*  7107 */           throw new IllegalArgumentException(type + " does not have a declaring type: " + ownerType); 
/*  7108 */         if (declaringType != null && (ownerType == null || !declaringType.equals(ownerType.asErasure()))) {
/*  7109 */           throw new IllegalArgumentException(ownerType + " is not the declaring type of " + type);
/*       */         }
/*  7111 */         return new OfNonGenericType(type, ownerType);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static TypeDescription.Generic unboundWildcard() {
/*  7120 */         return unboundWildcard(Collections.emptySet());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static TypeDescription.Generic unboundWildcard(Annotation... annotation) {
/*  7130 */         return unboundWildcard(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static TypeDescription.Generic unboundWildcard(List<? extends Annotation> annotations) {
/*  7140 */         return unboundWildcard((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static TypeDescription.Generic unboundWildcard(AnnotationDescription... annotation) {
/*  7150 */         return unboundWildcard(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static TypeDescription.Generic unboundWildcard(Collection<? extends AnnotationDescription> annotations) {
/*  7160 */         return TypeDescription.Generic.OfWildcardType.Latent.unbounded((AnnotationSource)new AnnotationSource.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder typeVariable(String symbol) {
/*  7170 */         return new OfTypeVariable(symbol);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder parameterizedType(Class<?> rawType, Type... parameter) {
/*  7181 */         return parameterizedType(rawType, Arrays.asList(parameter));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder parameterizedType(Class<?> rawType, List<? extends Type> parameters) {
/*  7192 */         return parameterizedType(rawType, UNDEFINED, parameters);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder parameterizedType(Class<?> rawType, @MaybeNull Type ownerType, List<? extends Type> parameters) {
/*  7206 */         return parameterizedType(TypeDescription.ForLoadedType.of(rawType), (ownerType == null) ? null : 
/*       */ 
/*       */             
/*  7209 */             TypeDefinition.Sort.describe(ownerType), (Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(parameters));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder parameterizedType(TypeDescription rawType, TypeDefinition... parameter) {
/*  7221 */         return parameterizedType(rawType, Arrays.asList(parameter));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder parameterizedType(TypeDescription rawType, Collection<? extends TypeDefinition> parameters) {
/*  7232 */         return parameterizedType(rawType, TypeDescription.Generic.UNDEFINED, parameters);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Builder parameterizedType(TypeDescription rawType, @MaybeNull TypeDescription.Generic ownerType, Collection<? extends TypeDefinition> parameters) {
/*  7246 */         TypeDescription declaringType = rawType.getDeclaringType();
/*  7247 */         if (ownerType == null && declaringType != null && rawType.isStatic()) {
/*  7248 */           ownerType = declaringType.asGenericType();
/*       */         }
/*  7250 */         if (!rawType.represents(TargetType.class)) {
/*  7251 */           if (!rawType.isGenerified())
/*  7252 */             throw new IllegalArgumentException(rawType + " is not a parameterized type"); 
/*  7253 */           if (ownerType == null && declaringType != null && !rawType.isStatic())
/*  7254 */             throw new IllegalArgumentException(rawType + " requires an owner type"); 
/*  7255 */           if (ownerType != null && !ownerType.asErasure().equals(declaringType))
/*  7256 */             throw new IllegalArgumentException(ownerType + " does not represent required owner for " + rawType); 
/*  7257 */           if (ownerType != null && (rawType.isStatic() ^ ownerType.getSort().isNonGeneric()) != 0)
/*  7258 */             throw new IllegalArgumentException(ownerType + " does not define the correct parameters for owning " + rawType); 
/*  7259 */           if (rawType.getTypeVariables().size() != parameters.size()) {
/*  7260 */             throw new IllegalArgumentException(parameters + " does not contain number of required parameters for " + rawType);
/*       */           }
/*       */         } 
/*  7263 */         return new OfParameterizedType(rawType, ownerType, (List<? extends TypeDescription.Generic>)new TypeList.Generic.Explicit(new ArrayList<TypeDefinition>(parameters)));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardUpperBound() {
/*  7272 */         return asWildcardUpperBound(Collections.emptySet());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardUpperBound(Annotation... annotation) {
/*  7282 */         return asWildcardUpperBound(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardUpperBound(List<? extends Annotation> annotations) {
/*  7292 */         return asWildcardUpperBound((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardUpperBound(AnnotationDescription... annotation) {
/*  7302 */         return asWildcardUpperBound(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardUpperBound(Collection<? extends AnnotationDescription> annotations) {
/*  7312 */         return TypeDescription.Generic.OfWildcardType.Latent.boundedAbove(build(), (AnnotationSource)new AnnotationSource.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardLowerBound() {
/*  7321 */         return asWildcardLowerBound(Collections.emptySet());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardLowerBound(Annotation... annotation) {
/*  7331 */         return asWildcardLowerBound(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardLowerBound(List<? extends Annotation> annotations) {
/*  7341 */         return asWildcardLowerBound((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardLowerBound(AnnotationDescription... annotation) {
/*  7351 */         return asWildcardLowerBound(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic asWildcardLowerBound(Collection<? extends AnnotationDescription> annotations) {
/*  7361 */         return TypeDescription.Generic.OfWildcardType.Latent.boundedBelow(build(), (AnnotationSource)new AnnotationSource.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Builder asArray() {
/*  7370 */         return asArray(1);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Builder asArray(int arity) {
/*  7380 */         if (arity < 1) {
/*  7381 */           throw new IllegalArgumentException("Cannot define an array of a non-positive arity: " + arity);
/*       */         }
/*  7383 */         TypeDescription.Generic typeDescription = build();
/*  7384 */         while (--arity > 0) {
/*  7385 */           typeDescription = new TypeDescription.Generic.OfGenericArray.Latent(typeDescription, (AnnotationSource)AnnotationSource.Empty.INSTANCE);
/*       */         }
/*  7387 */         return new OfGenericArrayType(typeDescription);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Builder annotate(Annotation... annotation) {
/*  7397 */         return annotate(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Builder annotate(List<? extends Annotation> annotations) {
/*  7407 */         return annotate((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Builder annotate(AnnotationDescription... annotation) {
/*  7417 */         return annotate(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Builder annotate(Collection<? extends AnnotationDescription> annotations) {
/*  7427 */         return doAnnotate(new ArrayList<AnnotationDescription>(annotations));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract Builder doAnnotate(List<? extends AnnotationDescription> param2List);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic build() {
/*  7444 */         return doBuild();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic build(Annotation... annotation) {
/*  7454 */         return build(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic build(List<? extends Annotation> annotations) {
/*  7464 */         return build((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic build(AnnotationDescription... annotation) {
/*  7474 */         return build(Arrays.asList(annotation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic build(Collection<? extends AnnotationDescription> annotations) {
/*  7484 */         return doAnnotate(new ArrayList<AnnotationDescription>(annotations)).doBuild();
/*       */       }
/*       */ 
/*       */       
/*       */       protected abstract TypeDescription.Generic doBuild();
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.annotations.equals(((Builder)param2Object).annotations))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.annotations.hashCode();
/*       */       }
/*       */       
/*       */       protected enum Visitor
/*       */         implements TypeDescription.Generic.Visitor<Builder>
/*       */       {
/*  7502 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic.Builder onGenericArray(TypeDescription.Generic genericArray) {
/*  7509 */           return new TypeDescription.Generic.Builder.OfGenericArrayType(genericArray.getComponentType(), (List<? extends AnnotationDescription>)genericArray.getDeclaredAnnotations());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.Builder onWildcard(TypeDescription.Generic wildcard) {
/*  7516 */           throw new IllegalArgumentException("Cannot resolve wildcard type " + wildcard + " to builder");
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.Builder onParameterizedType(TypeDescription.Generic parameterizedType) {
/*  7523 */           return new TypeDescription.Generic.Builder.OfParameterizedType(parameterizedType.asErasure(), parameterizedType
/*  7524 */               .getOwnerType(), (List<? extends TypeDescription.Generic>)parameterizedType
/*  7525 */               .getTypeArguments(), (List<? extends AnnotationDescription>)parameterizedType
/*  7526 */               .getDeclaredAnnotations());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription.Generic.Builder onTypeVariable(TypeDescription.Generic typeVariable) {
/*  7533 */           return new TypeDescription.Generic.Builder.OfTypeVariable(typeVariable.getSymbol(), (List<? extends AnnotationDescription>)typeVariable.getDeclaredAnnotations());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public TypeDescription.Generic.Builder onNonGenericType(TypeDescription.Generic typeDescription) {
/*  7541 */           return typeDescription.isArray() ? ((TypeDescription.Generic.Builder)typeDescription
/*  7542 */             .getComponentType().<TypeDescription.Generic.Builder>accept(this)).asArray().annotate((Collection<? extends AnnotationDescription>)typeDescription.getDeclaredAnnotations()) : new TypeDescription.Generic.Builder.OfNonGenericType(typeDescription
/*  7543 */               .asErasure(), typeDescription.getOwnerType(), (List<? extends AnnotationDescription>)typeDescription.getDeclaredAnnotations());
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class OfNonGenericType
/*       */         extends Builder
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final TypeDescription.Generic ownerType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfNonGenericType(TypeDescription typeDescription) {
/*  7571 */           this(typeDescription, typeDescription.getDeclaringType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfNonGenericType(TypeDescription typeDescription, @MaybeNull TypeDescription ownerType) {
/*  7581 */           this(typeDescription, (ownerType == null) ? TypeDescription.Generic.UNDEFINED : ownerType
/*       */               
/*  7583 */               .asGenericType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfNonGenericType(TypeDescription typeDescription, @MaybeNull TypeDescription.Generic ownerType) {
/*  7593 */           this(typeDescription, ownerType, Collections.emptyList());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfNonGenericType(TypeDescription typeDescription, @MaybeNull TypeDescription.Generic ownerType, List<? extends AnnotationDescription> annotations) {
/*  7606 */           super(annotations);
/*  7607 */           this.ownerType = ownerType;
/*  7608 */           this.typeDescription = typeDescription;
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.Builder doAnnotate(List<? extends AnnotationDescription> annotations) {
/*  7613 */           return new OfNonGenericType(this.typeDescription, this.ownerType, CompoundList.of(this.annotations, annotations));
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic doBuild() {
/*  7618 */           if (this.typeDescription.represents(void.class) && !this.annotations.isEmpty()) {
/*  7619 */             throw new IllegalArgumentException("The void non-type cannot be annotated");
/*       */           }
/*  7621 */           return new TypeDescription.Generic.OfNonGenericType.Latent(this.typeDescription, this.ownerType, (AnnotationSource)new AnnotationSource.Explicit(this.annotations));
/*       */         }
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           if (!super.equals(param3Object))
/*       */             return false; 
/*       */           if (this == param3Object)
/*       */             return true; 
/*       */           if (param3Object == null)
/*       */             return false; 
/*       */           if (getClass() != param3Object.getClass())
/*       */             return false; 
/*       */           if (!this.typeDescription.equals(((OfNonGenericType)param3Object).typeDescription))
/*       */             return false; 
/*       */           TypeDescription.Generic generic1 = ((OfNonGenericType)param3Object).ownerType;
/*       */           TypeDescription.Generic generic2 = this.ownerType;
/*       */           if (generic1 != null) {
/*       */             if (generic2 != null) {
/*       */               if (!generic2.equals(generic1))
/*       */                 return false; 
/*       */             } else {
/*       */               return false;
/*       */             } 
/*       */           } else if (generic2 != null) {
/*       */             return false;
/*       */           } 
/*       */           return true;
/*       */         }
/*       */         public int hashCode() {
/*       */           TypeDescription.Generic generic = this.ownerType;
/*       */           if (generic != null);
/*       */           return (super.hashCode() * 31 + this.typeDescription.hashCode()) * 31 + generic.hashCode();
/*       */         } }
/*       */       @Enhance
/*       */       protected static class OfParameterizedType extends Builder { private final TypeDescription rawType; @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final TypeDescription.Generic ownerType; private final List<? extends TypeDescription.Generic> parameterTypes;
/*       */         protected OfParameterizedType(TypeDescription rawType, @MaybeNull TypeDescription.Generic ownerType, List<? extends TypeDescription.Generic> parameterTypes) {
/*  7658 */           this(rawType, ownerType, parameterTypes, Collections.emptyList());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfParameterizedType(TypeDescription rawType, @MaybeNull TypeDescription.Generic ownerType, List<? extends TypeDescription.Generic> parameterTypes, List<? extends AnnotationDescription> annotations) {
/*  7673 */           super(annotations);
/*  7674 */           this.rawType = rawType;
/*  7675 */           this.ownerType = ownerType;
/*  7676 */           this.parameterTypes = parameterTypes;
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.Builder doAnnotate(List<? extends AnnotationDescription> annotations) {
/*  7681 */           return new OfParameterizedType(this.rawType, this.ownerType, this.parameterTypes, CompoundList.of(this.annotations, annotations));
/*       */         }
/*       */         
/*       */         protected TypeDescription.Generic doBuild()
/*       */         {
/*  7686 */           return new TypeDescription.Generic.OfParameterizedType.Latent(this.rawType, this.ownerType, this.parameterTypes, (AnnotationSource)new AnnotationSource.Explicit(this.annotations));
/*       */         } public boolean equals(@MaybeNull Object param3Object) { if (!super.equals(param3Object))
/*       */             return false;  if (this == param3Object)
/*       */             return true;  if (param3Object == null)
/*       */             return false;  if (getClass() != param3Object.getClass())
/*       */             return false;  if (!this.rawType.equals(((OfParameterizedType)param3Object).rawType))
/*       */             return false;  TypeDescription.Generic generic1 = ((OfParameterizedType)param3Object).ownerType;
/*       */           TypeDescription.Generic generic2 = this.ownerType;
/*       */           if (generic1 != null) {
/*       */             if (generic2 != null) {
/*       */               if (!generic2.equals(generic1))
/*       */                 return false; 
/*       */             } else {
/*       */               return false;
/*       */             } 
/*       */           } else if (generic2 != null) {
/*       */             return false;
/*       */           } 
/*       */           return !!this.parameterTypes.equals(((OfParameterizedType)param3Object).parameterTypes); } public int hashCode() { TypeDescription.Generic generic = this.ownerType;
/*       */           if (generic != null);
/*       */           return ((super.hashCode() * 31 + this.rawType.hashCode()) * 31 + generic.hashCode()) * 31 + this.parameterTypes.hashCode(); } } @Enhance protected static class OfGenericArrayType extends Builder { private final TypeDescription.Generic componentType;
/*  7707 */         protected OfGenericArrayType(TypeDescription.Generic componentType) { this(componentType, Collections.emptyList()); }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfGenericArrayType(TypeDescription.Generic componentType, List<? extends AnnotationDescription> annotations) {
/*  7717 */           super(annotations);
/*  7718 */           this.componentType = componentType;
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.Builder doAnnotate(List<? extends AnnotationDescription> annotations) {
/*  7723 */           return new OfGenericArrayType(this.componentType, CompoundList.of(this.annotations, annotations));
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic doBuild() {
/*  7728 */           return new TypeDescription.Generic.OfGenericArray.Latent(this.componentType, (AnnotationSource)new AnnotationSource.Explicit(this.annotations));
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.componentType.equals(((OfGenericArrayType)param3Object).componentType)))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.componentType.hashCode();
/*       */         } }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class OfTypeVariable
/*       */         extends Builder
/*       */       {
/*       */         private final String symbol;
/*       */         
/*       */         protected OfTypeVariable(String symbol) {
/*  7749 */           this(symbol, Collections.emptyList());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected OfTypeVariable(String symbol, List<? extends AnnotationDescription> annotations) {
/*  7759 */           super(annotations);
/*  7760 */           this.symbol = symbol;
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic.Builder doAnnotate(List<? extends AnnotationDescription> annotations) {
/*  7765 */           return new OfTypeVariable(this.symbol, CompoundList.of(this.annotations, annotations));
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypeDescription.Generic doBuild() {
/*  7770 */           return new TypeDescription.Generic.OfTypeVariable.Symbolic(this.symbol, (AnnotationSource)new AnnotationSource.Explicit(this.annotations));
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.symbol.equals(((OfTypeVariable)param3Object).symbol)))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.symbol.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   
/*       */   public static abstract class AbstractBase
/*       */     extends TypeVariableSource.AbstractBase
/*       */     implements TypeDescription
/*       */   {
/*       */     public static final boolean RAW_TYPES;
/*       */     private static final boolean ACCESS_CONTROLLER;
/*       */     
/*       */     static {
/*       */       boolean rawTypes;
/*       */       
/*  7797 */       try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*       */       
/*       */       try {
/*       */         rawTypes = Boolean.parseBoolean(doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.raw")));
/*       */       } catch (Exception ignored) {
/*       */         rawTypes = false;
/*       */       } 
/*       */       RAW_TYPES = rawTypes;
/*       */     }
/*       */     @Enhance
/*       */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  7808 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     private static boolean isAssignable(TypeDescription sourceType, TypeDescription targetType) {
/*  7823 */       if (sourceType.equals(targetType)) {
/*  7824 */         return true;
/*       */       }
/*       */       
/*  7827 */       if (targetType.isArray()) {
/*  7828 */         return sourceType.isArray() ? 
/*  7829 */           isAssignable(sourceType.getComponentType(), targetType.getComponentType()) : ((sourceType
/*  7830 */           .represents(Object.class) || ARRAY_INTERFACES.contains(sourceType.asGenericType())));
/*       */       }
/*       */       
/*  7833 */       if (sourceType.represents(Object.class)) {
/*  7834 */         return !targetType.isPrimitive();
/*       */       }
/*       */       
/*  7837 */       TypeDescription.Generic superClass = targetType.getSuperClass();
/*  7838 */       if (superClass != null && sourceType.isAssignableFrom(superClass.asErasure())) {
/*  7839 */         return true;
/*       */       }
/*       */       
/*  7842 */       if (sourceType.isInterface()) {
/*  7843 */         for (TypeDescription interfaceType : targetType.getInterfaces().asErasures()) {
/*  7844 */           if (sourceType.isAssignableFrom(interfaceType)) {
/*  7845 */             return true;
/*       */           }
/*       */         } 
/*       */       }
/*       */       
/*  7850 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAssignableFrom(Class<?> type) {
/*  7857 */       return isAssignableFrom(TypeDescription.ForLoadedType.of(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAssignableFrom(TypeDescription typeDescription) {
/*  7864 */       return isAssignable(this, typeDescription);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAssignableTo(Class<?> type) {
/*  7871 */       return isAssignableTo(TypeDescription.ForLoadedType.of(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAssignableTo(TypeDescription typeDescription) {
/*  7878 */       return isAssignable(typeDescription, this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isInHierarchyWith(Class<?> type) {
/*  7885 */       return (isAssignableTo(type) || isAssignableFrom(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isInHierarchyWith(TypeDescription typeDescription) {
/*  7892 */       return (isAssignableTo(typeDescription) || isAssignableFrom(typeDescription));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription asErasure() {
/*  7899 */       return this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription.Generic asGenericType() {
/*  7906 */       return new TypeDescription.Generic.OfNonGenericType.ForErasure(this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDefinition.Sort getSort() {
/*  7913 */       return TypeDefinition.Sort.NON_GENERIC;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isInstance(Object value) {
/*  7920 */       return isAssignableFrom(value.getClass());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAnnotationValue(Object value) {
/*  7927 */       if ((represents(Class.class) && value instanceof TypeDescription) || (value instanceof AnnotationDescription && ((AnnotationDescription)value)
/*  7928 */         .getAnnotationType().equals(this)) || (value instanceof EnumerationDescription && ((EnumerationDescription)value)
/*  7929 */         .getEnumerationType().equals(this)) || (
/*  7930 */         represents(String.class) && value instanceof String) || (
/*  7931 */         represents(boolean.class) && value instanceof Boolean) || (
/*  7932 */         represents(byte.class) && value instanceof Byte) || (
/*  7933 */         represents(short.class) && value instanceof Short) || (
/*  7934 */         represents(char.class) && value instanceof Character) || (
/*  7935 */         represents(int.class) && value instanceof Integer) || (
/*  7936 */         represents(long.class) && value instanceof Long) || (
/*  7937 */         represents(float.class) && value instanceof Float) || (
/*  7938 */         represents(double.class) && value instanceof Double) || (
/*  7939 */         represents(String[].class) && value instanceof String[]) || (
/*  7940 */         represents(boolean[].class) && value instanceof boolean[]) || (
/*  7941 */         represents(byte[].class) && value instanceof byte[]) || (
/*  7942 */         represents(short[].class) && value instanceof short[]) || (
/*  7943 */         represents(char[].class) && value instanceof char[]) || (
/*  7944 */         represents(int[].class) && value instanceof int[]) || (
/*  7945 */         represents(long[].class) && value instanceof long[]) || (
/*  7946 */         represents(float[].class) && value instanceof float[]) || (
/*  7947 */         represents(double[].class) && value instanceof double[]) || (
/*  7948 */         represents(Class[].class) && value instanceof TypeDescription[]))
/*  7949 */         return true; 
/*  7950 */       if (isAssignableTo(Annotation[].class) && value instanceof AnnotationDescription[]) {
/*  7951 */         for (AnnotationDescription annotationDescription : (AnnotationDescription[])value) {
/*  7952 */           if (!annotationDescription.getAnnotationType().equals(getComponentType())) {
/*  7953 */             return false;
/*       */           }
/*       */         } 
/*  7956 */         return true;
/*  7957 */       }  if (isAssignableTo(Enum[].class) && value instanceof EnumerationDescription[]) {
/*  7958 */         for (EnumerationDescription enumerationDescription : (EnumerationDescription[])value) {
/*  7959 */           if (!enumerationDescription.getEnumerationType().equals(getComponentType())) {
/*  7960 */             return false;
/*       */           }
/*       */         } 
/*  7963 */         return true;
/*       */       } 
/*  7965 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getInternalName() {
/*  7973 */       return getName().replace('.', '/');
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int getActualModifiers(boolean superFlag) {
/*  7982 */       int actualModifiers = getModifiers() | (getDeclaredAnnotations().isAnnotationPresent(Deprecated.class) ? 131072 : 0) | (isRecord() ? 65536 : 0) | (superFlag ? 32 : 0);
/*       */       
/*  7984 */       if (isPrivate())
/*  7985 */         return actualModifiers & 0xFFFFFFF5; 
/*  7986 */       if (isProtected()) {
/*  7987 */         return actualModifiers & 0xFFFFFFF3 | 0x1;
/*       */       }
/*  7989 */       return actualModifiers & 0xFFFFFFF7;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public String getGenericSignature() {
/*       */       try {
/*  7999 */         SignatureWriter signatureWriter = new SignatureWriter();
/*  8000 */         boolean generic = false;
/*  8001 */         for (TypeDescription.Generic typeVariable : getTypeVariables()) {
/*  8002 */           signatureWriter.visitFormalTypeParameter(typeVariable.getSymbol());
/*  8003 */           for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) {
/*  8004 */             upperBound.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(upperBound.asErasure().isInterface() ? signatureWriter
/*  8005 */                   .visitInterfaceBound() : signatureWriter
/*  8006 */                   .visitClassBound()));
/*       */           }
/*  8008 */           generic = true;
/*       */         } 
/*  8010 */         TypeDescription.Generic superClass = getSuperClass();
/*       */         
/*  8012 */         if (superClass == null) {
/*  8013 */           superClass = TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class);
/*       */         }
/*  8015 */         superClass.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(signatureWriter.visitSuperclass()));
/*  8016 */         generic = (generic || !superClass.getSort().isNonGeneric());
/*  8017 */         for (TypeDescription.Generic interfaceType : getInterfaces()) {
/*  8018 */           interfaceType.accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor(signatureWriter.visitInterface()));
/*  8019 */           generic = (generic || !interfaceType.getSort().isNonGeneric());
/*       */         } 
/*  8021 */         return generic ? signatureWriter
/*  8022 */           .toString() : NON_GENERIC_SIGNATURE;
/*       */       }
/*  8024 */       catch (GenericSignatureFormatError ignored) {
/*  8025 */         return NON_GENERIC_SIGNATURE;
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isSamePackage(TypeDescription typeDescription) {
/*  8033 */       PackageDescription thisPackage = getPackage(), otherPackage = typeDescription.getPackage();
/*  8034 */       return (thisPackage == null || otherPackage == null) ? ((thisPackage == otherPackage)) : thisPackage
/*       */         
/*  8036 */         .equals(otherPackage);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public boolean isVisibleTo(TypeDescription typeDescription) {
/*  8044 */       return (isPrimitive() || (isArray() ? 
/*  8045 */         getComponentType().isVisibleTo(typeDescription) : (
/*  8046 */         isPublic() || isProtected() || isSamePackage(typeDescription))));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public boolean isAccessibleTo(TypeDescription typeDescription) {
/*  8054 */       return (isPrimitive() || (isArray() ? 
/*  8055 */         getComponentType().isVisibleTo(typeDescription) : (
/*  8056 */         isPublic() || isSamePackage(typeDescription))));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationList getInheritedAnnotations() {
/*  8063 */       TypeDescription.Generic superClass = getSuperClass();
/*  8064 */       AnnotationList declaredAnnotations = getDeclaredAnnotations();
/*  8065 */       if (superClass == null) {
/*  8066 */         return declaredAnnotations;
/*       */       }
/*  8068 */       Set<TypeDescription> annotationTypes = new HashSet<TypeDescription>();
/*  8069 */       for (AnnotationDescription annotationDescription : declaredAnnotations) {
/*  8070 */         annotationTypes.add(annotationDescription.getAnnotationType());
/*       */       }
/*  8072 */       return (AnnotationList)new AnnotationList.Explicit(CompoundList.of((List)declaredAnnotations, (List)superClass.asErasure().getInheritedAnnotations().inherited(annotationTypes)));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public String getActualName() {
/*  8081 */       if (isArray()) {
/*  8082 */         TypeDescription typeDescription = this;
/*  8083 */         int dimensions = 0;
/*       */         while (true) {
/*  8085 */           dimensions++;
/*  8086 */           typeDescription = typeDescription.getComponentType();
/*  8087 */           if (!typeDescription.isArray())
/*  8088 */           { StringBuilder stringBuilder = new StringBuilder();
/*  8089 */             stringBuilder.append(typeDescription.getActualName());
/*  8090 */             for (int i = 0; i < dimensions; i++) {
/*  8091 */               stringBuilder.append("[]");
/*       */             }
/*  8093 */             return stringBuilder.toString(); } 
/*       */         } 
/*  8095 */       }  return getName();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getLongSimpleName() {
/*  8103 */       TypeDescription declaringType = getDeclaringType();
/*  8104 */       return (declaringType == null) ? 
/*  8105 */         getSimpleName() : (declaringType
/*  8106 */         .getLongSimpleName() + "." + getSimpleName());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isPrimitiveWrapper() {
/*  8113 */       return (represents(Boolean.class) || 
/*  8114 */         represents(Byte.class) || 
/*  8115 */         represents(Short.class) || 
/*  8116 */         represents(Character.class) || 
/*  8117 */         represents(Integer.class) || 
/*  8118 */         represents(Long.class) || 
/*  8119 */         represents(Float.class) || 
/*  8120 */         represents(Double.class));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public boolean isAnnotationReturnType() {
/*  8128 */       return (isPrimitive() || 
/*  8129 */         represents(String.class) || (
/*  8130 */         isAssignableTo(Enum.class) && !represents(Enum.class)) || (
/*  8131 */         isAssignableTo(Annotation.class) && !represents(Annotation.class)) || 
/*  8132 */         represents(Class.class) || (
/*  8133 */         isArray() && !getComponentType().isArray() && getComponentType().isAnnotationReturnType()));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public boolean isAnnotationValue() {
/*  8141 */       return (isPrimitive() || 
/*  8142 */         represents(String.class) || 
/*  8143 */         isAssignableTo(TypeDescription.class) || 
/*  8144 */         isAssignableTo(AnnotationDescription.class) || 
/*  8145 */         isAssignableTo(EnumerationDescription.class) || (
/*  8146 */         isArray() && !getComponentType().isArray() && getComponentType().isAnnotationValue()));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"EC_UNRELATED_CLASS_AND_INTERFACE"}, justification = "Fits equality contract for type definitions.")
/*       */     public boolean represents(Type type) {
/*  8154 */       return equals(TypeDefinition.Sort.describe(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getTypeName() {
/*  8161 */       return getName();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeVariableSource getEnclosingSource() {
/*  8169 */       MethodDescription.InDefinedShape inDefinedShape = getEnclosingMethod();
/*  8170 */       return (inDefinedShape == null) ? (
/*  8171 */         isStatic() ? TypeVariableSource.UNDEFINED : getEnclosingType()) : (TypeVariableSource)inDefinedShape;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isInferrable() {
/*  8179 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T> T accept(TypeVariableSource.Visitor<T> visitor) {
/*  8186 */       return (T)visitor.onType(this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isPackageType() {
/*  8193 */       return getSimpleName().equals("package-info");
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isGenerified() {
/*  8200 */       if (!getTypeVariables().isEmpty())
/*  8201 */         return true; 
/*  8202 */       if (!isStatic()) {
/*  8203 */         TypeDescription declaringType = getDeclaringType();
/*  8204 */         if (declaringType != null && declaringType.isGenerified()) {
/*  8205 */           return true;
/*       */         }
/*       */       } 
/*       */       try {
/*  8209 */         MethodDescription.InDefinedShape enclosingMethod = getEnclosingMethod();
/*  8210 */         return (enclosingMethod != null && enclosingMethod.isGenerified());
/*  8211 */       } catch (Throwable ignored) {
/*  8212 */         return false;
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int getInnerClassCount() {
/*  8220 */       if (isStatic()) {
/*  8221 */         return 0;
/*       */       }
/*  8223 */       TypeDescription declaringType = getDeclaringType();
/*  8224 */       return (declaringType == null) ? 0 : (declaringType
/*       */         
/*  8226 */         .getInnerClassCount() + 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isInnerClass() {
/*  8233 */       return (!isStatic() && isNestedClass());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isNestedClass() {
/*  8240 */       return (getDeclaringType() != null);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription asBoxed() {
/*  8247 */       if (represents(boolean.class))
/*  8248 */         return TypeDescription.ForLoadedType.of(Boolean.class); 
/*  8249 */       if (represents(byte.class))
/*  8250 */         return TypeDescription.ForLoadedType.of(Byte.class); 
/*  8251 */       if (represents(short.class))
/*  8252 */         return TypeDescription.ForLoadedType.of(Short.class); 
/*  8253 */       if (represents(char.class))
/*  8254 */         return TypeDescription.ForLoadedType.of(Character.class); 
/*  8255 */       if (represents(int.class))
/*  8256 */         return TypeDescription.ForLoadedType.of(Integer.class); 
/*  8257 */       if (represents(long.class))
/*  8258 */         return TypeDescription.ForLoadedType.of(Long.class); 
/*  8259 */       if (represents(float.class))
/*  8260 */         return TypeDescription.ForLoadedType.of(Float.class); 
/*  8261 */       if (represents(double.class)) {
/*  8262 */         return TypeDescription.ForLoadedType.of(Double.class);
/*       */       }
/*  8264 */       return this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription asUnboxed() {
/*  8272 */       if (represents(Boolean.class))
/*  8273 */         return TypeDescription.ForLoadedType.of(boolean.class); 
/*  8274 */       if (represents(Byte.class))
/*  8275 */         return TypeDescription.ForLoadedType.of(byte.class); 
/*  8276 */       if (represents(Short.class))
/*  8277 */         return TypeDescription.ForLoadedType.of(short.class); 
/*  8278 */       if (represents(Character.class))
/*  8279 */         return TypeDescription.ForLoadedType.of(char.class); 
/*  8280 */       if (represents(Integer.class))
/*  8281 */         return TypeDescription.ForLoadedType.of(int.class); 
/*  8282 */       if (represents(Long.class))
/*  8283 */         return TypeDescription.ForLoadedType.of(long.class); 
/*  8284 */       if (represents(Float.class))
/*  8285 */         return TypeDescription.ForLoadedType.of(float.class); 
/*  8286 */       if (represents(Double.class)) {
/*  8287 */         return TypeDescription.ForLoadedType.of(double.class);
/*       */       }
/*  8289 */       return this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public Object getDefaultValue() {
/*  8298 */       if (represents(boolean.class))
/*  8299 */         return Boolean.valueOf(false); 
/*  8300 */       if (represents(byte.class))
/*  8301 */         return Byte.valueOf((byte)0); 
/*  8302 */       if (represents(short.class))
/*  8303 */         return Short.valueOf((short)0); 
/*  8304 */       if (represents(char.class))
/*  8305 */         return Character.valueOf(false); 
/*  8306 */       if (represents(int.class))
/*  8307 */         return Integer.valueOf(0); 
/*  8308 */       if (represents(long.class))
/*  8309 */         return Long.valueOf(0L); 
/*  8310 */       if (represents(float.class))
/*  8311 */         return Float.valueOf(0.0F); 
/*  8312 */       if (represents(double.class)) {
/*  8313 */         return Double.valueOf(0.0D);
/*       */       }
/*  8315 */       return null;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isNestHost() {
/*  8323 */       return equals(getNestHost());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isNestMateOf(Class<?> type) {
/*  8330 */       return isNestMateOf(TypeDescription.ForLoadedType.of(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isNestMateOf(TypeDescription typeDescription) {
/*  8337 */       return getNestHost().equals(typeDescription.getNestHost());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isMemberType() {
/*  8344 */       return (!isLocalType() && !isAnonymousType() && getDeclaringType() != null);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isCompileTimeConstant() {
/*  8351 */       return (represents(int.class) || 
/*  8352 */         represents(long.class) || 
/*  8353 */         represents(float.class) || 
/*  8354 */         represents(double.class) || 
/*  8355 */         represents(String.class) || 
/*  8356 */         represents(Class.class) || 
/*  8357 */         equals(JavaType.METHOD_TYPE.getTypeStub()) || 
/*  8358 */         equals(JavaType.METHOD_HANDLE.getTypeStub()));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isSealed() {
/*  8365 */       return (!isPrimitive() && !isArray() && !getPermittedSubtypes().isEmpty());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public ClassFileVersion getClassFileVersion() {
/*  8373 */       return null;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Iterator<TypeDefinition> iterator() {
/*  8380 */       return new TypeDefinition.SuperClassIterator(this);
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance("hashCode")
/*       */     public int hashCode() {}
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean equals(@MaybeNull Object other) {
/*  8391 */       if (this == other)
/*  8392 */         return true; 
/*  8393 */       if (!(other instanceof TypeDefinition)) {
/*  8394 */         return false;
/*       */       }
/*  8396 */       TypeDefinition typeDefinition = (TypeDefinition)other;
/*  8397 */       return (typeDefinition.getSort().isNonGeneric() && getName().equals(typeDefinition.asErasure().getName()));
/*       */     }
/*       */ 
/*       */     
/*       */     public String toString() {
/*  8402 */       return (isPrimitive() ? "" : ((isInterface() ? "interface" : "class") + " ")) + getName();
/*       */     }
/*       */ 
/*       */     
/*       */     protected String toSafeString() {
/*  8407 */       return toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class OfSimpleType
/*       */       extends AbstractBase
/*       */     {
/*       */       public boolean isPrimitive() {
/*  8420 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isArray() {
/*  8427 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public TypeDescription getComponentType() {
/*  8435 */         return TypeDescription.UNDEFINED;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getDescriptor() {
/*  8442 */         return "L" + getInternalName() + ";";
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public String getCanonicalName() {
/*  8450 */         if (isAnonymousType() || isLocalType()) {
/*  8451 */           return NO_NAME;
/*       */         }
/*  8453 */         String internalName = getInternalName();
/*  8454 */         TypeDescription enclosingType = getEnclosingType();
/*  8455 */         if (enclosingType != null && internalName.startsWith(enclosingType.getInternalName() + "$")) {
/*  8456 */           return enclosingType.getCanonicalName() + "." + internalName.substring(enclosingType.getInternalName().length() + 1);
/*       */         }
/*  8458 */         return getName();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public String getSimpleName() {
/*       */         int simpleNameIndex;
/*  8466 */         String internalName = getInternalName();
/*  8467 */         TypeDescription enclosingType = getEnclosingType();
/*       */         
/*  8469 */         if (enclosingType != null && internalName.startsWith(enclosingType.getInternalName() + "$")) {
/*  8470 */           simpleNameIndex = enclosingType.getInternalName().length() + 1;
/*       */         } else {
/*  8472 */           simpleNameIndex = internalName.lastIndexOf('/');
/*  8473 */           if (simpleNameIndex == -1) {
/*  8474 */             return internalName;
/*       */           }
/*       */         } 
/*  8477 */         while (simpleNameIndex < internalName.length() && !Character.isJavaIdentifierStart(internalName.charAt(simpleNameIndex))) {
/*  8478 */           simpleNameIndex++;
/*       */         }
/*  8480 */         return internalName.substring(simpleNameIndex);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackSize getStackSize() {
/*  8487 */         return StackSize.SINGLE;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static abstract class WithDelegation
/*       */         extends OfSimpleType
/*       */       {
/*       */         @MaybeNull
/*       */         public TypeDescription.Generic getSuperClass() {
/*  8507 */           return delegate().getSuperClass();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getInterfaces() {
/*  8514 */           return delegate().getInterfaces();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/*  8521 */           return delegate().getDeclaredFields();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/*  8528 */           return delegate().getDeclaredMethods();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription getDeclaringType() {
/*  8536 */           return delegate().getDeclaringType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public MethodDescription.InDefinedShape getEnclosingMethod() {
/*  8544 */           return delegate().getEnclosingMethod();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public TypeDescription getEnclosingType() {
/*  8552 */           return delegate().getEnclosingType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList getDeclaredTypes() {
/*  8559 */           return delegate().getDeclaredTypes();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isAnonymousType() {
/*  8566 */           return delegate().isAnonymousType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isLocalType() {
/*  8573 */           return delegate().isLocalType();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public PackageDescription getPackage() {
/*  8581 */           return delegate().getPackage();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AnnotationList getDeclaredAnnotations() {
/*  8588 */           return delegate().getDeclaredAnnotations();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList.Generic getTypeVariables() {
/*  8595 */           return delegate().getTypeVariables();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getModifiers() {
/*  8602 */           return delegate().getModifiers();
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean isAbstract() {
/*  8607 */           return delegate().isAbstract();
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean isEnum() {
/*  8612 */           return delegate().isEnum();
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean isInterface() {
/*  8617 */           return delegate().isInterface();
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean isAnnotation() {
/*  8622 */           return delegate().isAnnotation();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public String getGenericSignature() {
/*  8629 */           return delegate().getGenericSignature();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int getActualModifiers(boolean superFlag) {
/*  8635 */           return delegate().getActualModifiers(superFlag);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription getNestHost() {
/*  8642 */           return delegate().getNestHost();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList getNestMembers() {
/*  8649 */           return delegate().getNestMembers();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/*  8656 */           return delegate().getRecordComponents();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isRecord() {
/*  8663 */           return delegate().isRecord();
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean isSealed() {
/*  8668 */           return delegate().isSealed();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeList getPermittedSubtypes() {
/*  8675 */           return delegate().getPermittedSubtypes();
/*       */         }
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public ClassFileVersion getClassFileVersion() {
/*  8681 */           return delegate().getClassFileVersion();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract TypeDescription delegate();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Enhance
/*       */   public static class LazyProxy
/*       */     implements InvocationHandler
/*       */   {
/*       */     private final Class<?> type;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected LazyProxy(Class<?> type) {
/*  8705 */       this.type = type;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static TypeDescription of(Class<?> type) {
/*  8715 */       return (TypeDescription)Proxy.newProxyInstance(TypeDescription.class.getClassLoader(), new Class[] { TypeDescription.class }, new LazyProxy(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Object invoke(Object proxy, Method method, @MaybeNull Object[] argument) throws Throwable {
/*       */       try {
/*  8725 */         return method.invoke(TypeDescription.ForLoadedType.of(this.type), argument);
/*  8726 */       } catch (InvocationTargetException exception) {
/*  8727 */         throw exception.getTargetException();
/*       */       } 
/*       */     }
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.type.equals(((LazyProxy)param1Object).type))));
/*       */     }
/*       */     
/*       */     public int hashCode() {
/*       */       return getClass().hashCode() * 31 + this.type.hashCode();
/*       */     }
/*       */   }
/*       */   
/*       */   @SuppressFBWarnings(value = {"SE_TRANSIENT_FIELD_NOT_RESTORED"}, justification = "Field is only used as a cache store and is implicitly recomputed")
/*       */   public static class ForLoadedType
/*       */     extends AbstractBase
/*       */     implements Serializable
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/*  8746 */     private static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8757 */     private static final Map<Class<?>, TypeDescription> TYPE_CACHE = new HashMap<Class<?>, TypeDescription>(); private final Class<?> type; private static final boolean ACCESS_CONTROLLER;
/*  8758 */     static { TYPE_CACHE.put(TargetType.class, new ForLoadedType(TargetType.class));
/*  8759 */       TYPE_CACHE.put(Class.class, new ForLoadedType(Class.class));
/*  8760 */       TYPE_CACHE.put(Throwable.class, new ForLoadedType(Throwable.class));
/*  8761 */       TYPE_CACHE.put(Annotation.class, new ForLoadedType(Annotation.class));
/*  8762 */       TYPE_CACHE.put(Object.class, new ForLoadedType(Object.class));
/*  8763 */       TYPE_CACHE.put(String.class, new ForLoadedType(String.class));
/*  8764 */       TYPE_CACHE.put(Boolean.class, new ForLoadedType(Boolean.class));
/*  8765 */       TYPE_CACHE.put(Byte.class, new ForLoadedType(Byte.class));
/*  8766 */       TYPE_CACHE.put(Short.class, new ForLoadedType(Short.class));
/*  8767 */       TYPE_CACHE.put(Character.class, new ForLoadedType(Character.class));
/*  8768 */       TYPE_CACHE.put(Integer.class, new ForLoadedType(Integer.class));
/*  8769 */       TYPE_CACHE.put(Long.class, new ForLoadedType(Long.class));
/*  8770 */       TYPE_CACHE.put(Float.class, new ForLoadedType(Float.class));
/*  8771 */       TYPE_CACHE.put(Double.class, new ForLoadedType(Double.class));
/*  8772 */       TYPE_CACHE.put(void.class, new ForLoadedType(void.class));
/*  8773 */       TYPE_CACHE.put(boolean.class, new ForLoadedType(boolean.class));
/*  8774 */       TYPE_CACHE.put(byte.class, new ForLoadedType(byte.class));
/*  8775 */       TYPE_CACHE.put(short.class, new ForLoadedType(short.class));
/*  8776 */       TYPE_CACHE.put(char.class, new ForLoadedType(char.class));
/*  8777 */       TYPE_CACHE.put(int.class, new ForLoadedType(int.class));
/*  8778 */       TYPE_CACHE.put(long.class, new ForLoadedType(long.class));
/*  8779 */       TYPE_CACHE.put(float.class, new ForLoadedType(float.class));
/*  8780 */       TYPE_CACHE.put(double.class, new ForLoadedType(double.class)); } static { 
/*  8781 */       try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*       */        }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ForLoadedType(Class<?> type) {
/*  8795 */       this.type = type;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  8807 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static String getName(Class<?> type) {
/*  8819 */       String name = type.getName();
/*  8820 */       int anonymousLoaderIndex = name.indexOf('/');
/*  8821 */       return (anonymousLoaderIndex == -1) ? name : name
/*       */         
/*  8823 */         .substring(0, anonymousLoaderIndex);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static TypeDescription of(Class<?> type) {
/*  8833 */       TypeDescription typeDescription = TYPE_CACHE.get(type);
/*  8834 */       return (typeDescription == null) ? new ForLoadedType(type) : typeDescription;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAssignableFrom(Class<?> type) {
/*  8841 */       return (this.type.isAssignableFrom(type) || super.isAssignableFrom(type));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isAssignableFrom(TypeDescription typeDescription) {
/*  8846 */       return ((typeDescription instanceof ForLoadedType && this.type.isAssignableFrom(((ForLoadedType)typeDescription).type)) || super.isAssignableFrom(typeDescription));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isAssignableTo(Class<?> type) {
/*  8851 */       return (type.isAssignableFrom(this.type) || super.isAssignableTo(type));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isAssignableTo(TypeDescription typeDescription) {
/*  8856 */       return ((typeDescription instanceof ForLoadedType && ((ForLoadedType)typeDescription).type.isAssignableFrom(this.type)) || super.isAssignableTo(typeDescription));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isInHierarchyWith(Class<?> type) {
/*  8861 */       return (type.isAssignableFrom(this.type) || this.type.isAssignableFrom(type) || super.isInHierarchyWith(type));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isInHierarchyWith(TypeDescription typeDescription) {
/*  8866 */       return ((typeDescription instanceof ForLoadedType && (((ForLoadedType)typeDescription).type.isAssignableFrom(this.type) || this.type
/*  8867 */         .isAssignableFrom(((ForLoadedType)typeDescription).type))) || super.isInHierarchyWith(typeDescription));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean represents(Type type) {
/*  8872 */       return (type == this.type || super.represents(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getComponentType() {
/*  8880 */       Class<?> componentType = this.type.getComponentType();
/*  8881 */       return (componentType == null) ? TypeDescription.UNDEFINED : 
/*       */         
/*  8883 */         of(componentType);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isArray() {
/*  8890 */       return this.type.isArray();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isPrimitive() {
/*  8897 */       return this.type.isPrimitive();
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isAnnotation() {
/*  8902 */       return this.type.isAnnotation();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription.Generic getSuperClass() {
/*  8910 */       if (RAW_TYPES) {
/*  8911 */         return (this.type.getSuperclass() == null) ? TypeDescription.Generic.UNDEFINED : 
/*       */           
/*  8913 */           TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.type.getSuperclass());
/*       */       }
/*  8915 */       return TypeDescription.Generic.LazyProjection.ForLoadedSuperClass.of(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getInterfaces() {
/*  8922 */       if (RAW_TYPES) {
/*  8923 */         return isArray() ? ARRAY_INTERFACES : new TypeList.Generic.ForLoadedTypes((Type[])this.type
/*       */             
/*  8925 */             .getInterfaces());
/*       */       }
/*  8927 */       return isArray() ? ARRAY_INTERFACES : new TypeList.Generic.OfLoadedInterfaceTypes(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getDeclaringType() {
/*  8937 */       Class<?> declaringType = this.type.getDeclaringClass();
/*  8938 */       return (declaringType == null) ? TypeDescription.UNDEFINED : 
/*       */         
/*  8940 */         of(declaringType);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/*  8948 */       Method enclosingMethod = this.type.getEnclosingMethod();
/*  8949 */       Constructor<?> enclosingConstructor = this.type.getEnclosingConstructor();
/*  8950 */       if (enclosingMethod != null)
/*  8951 */         return (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(enclosingMethod); 
/*  8952 */       if (enclosingConstructor != null) {
/*  8953 */         return (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(enclosingConstructor);
/*       */       }
/*  8955 */       return MethodDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getEnclosingType() {
/*  8963 */       Class<?> enclosingType = this.type.getEnclosingClass();
/*  8964 */       return (enclosingType == null) ? TypeDescription.UNDEFINED : 
/*       */         
/*  8966 */         of(enclosingType);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getDeclaredTypes() {
/*  8973 */       return new TypeList.ForLoadedTypes(this.type.getDeclaredClasses());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getSimpleName() {
/*  8980 */       String simpleName = this.type.getSimpleName();
/*  8981 */       int anonymousLoaderIndex = simpleName.indexOf('/');
/*  8982 */       if (anonymousLoaderIndex == -1) {
/*  8983 */         return simpleName;
/*       */       }
/*  8985 */       StringBuilder normalized = new StringBuilder(simpleName.substring(0, anonymousLoaderIndex));
/*  8986 */       Class<?> type = this.type;
/*  8987 */       while (type.isArray()) {
/*  8988 */         normalized.append("[]");
/*  8989 */         type = type.getComponentType();
/*       */       } 
/*  8991 */       return normalized.toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAnonymousType() {
/*  8999 */       return this.type.isAnonymousClass();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isLocalType() {
/*  9006 */       return this.type.isLocalClass();
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isMemberType() {
/*  9011 */       return this.type.isMemberClass();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance("declaredFields")
/*       */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance("declaredMethods")
/*       */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public PackageDescription getPackage() {
/*  9035 */       if (this.type.isArray() || this.type.isPrimitive()) {
/*  9036 */         return PackageDescription.UNDEFINED;
/*       */       }
/*  9038 */       Package aPackage = this.type.getPackage();
/*  9039 */       if (aPackage == null) {
/*  9040 */         String name = this.type.getName();
/*  9041 */         int index = name.lastIndexOf('.');
/*  9042 */         return (index == -1) ? PackageDescription.DEFAULT : new PackageDescription.Simple(name
/*       */             
/*  9044 */             .substring(0, index));
/*       */       } 
/*  9046 */       return new PackageDescription.ForLoadedPackage(aPackage);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public StackSize getStackSize() {
/*  9055 */       return StackSize.of(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getName() {
/*  9062 */       return getName(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public String getCanonicalName() {
/*  9070 */       String canonicalName = this.type.getCanonicalName();
/*  9071 */       if (canonicalName == null) {
/*  9072 */         return NO_NAME;
/*       */       }
/*  9074 */       int anonymousLoaderIndex = canonicalName.indexOf('/');
/*  9075 */       if (anonymousLoaderIndex == -1) {
/*  9076 */         return canonicalName;
/*       */       }
/*  9078 */       StringBuilder normalized = new StringBuilder(canonicalName.substring(0, anonymousLoaderIndex));
/*  9079 */       Class<?> type = this.type;
/*  9080 */       while (type.isArray()) {
/*  9081 */         normalized.append("[]");
/*  9082 */         type = type.getComponentType();
/*       */       } 
/*  9084 */       return normalized.toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getDescriptor() {
/*  9092 */       String name = this.type.getName();
/*  9093 */       int anonymousLoaderIndex = name.indexOf('/');
/*  9094 */       return (anonymousLoaderIndex == -1) ? 
/*  9095 */         Type.getDescriptor(this.type) : ("L" + name
/*  9096 */         .substring(0, anonymousLoaderIndex).replace('.', '/') + ";");
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int getModifiers() {
/*  9103 */       return this.type.getModifiers();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getTypeVariables() {
/*  9110 */       if (RAW_TYPES) {
/*  9111 */         return new TypeList.Generic.Empty();
/*       */       }
/*  9113 */       return TypeList.Generic.ForLoadedTypes.OfTypeVariables.of(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance("declaredAnnotations")
/*       */     public AnnotationList getDeclaredAnnotations() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription.Generic asGenericType() {
/*  9128 */       return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getNestHost() {
/*  9135 */       Class<?> host = DISPATCHER.getNestHost(this.type);
/*  9136 */       return (host == null) ? this : 
/*       */         
/*  9138 */         of(host);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getNestMembers() {
/*  9145 */       Class<?>[] member = DISPATCHER.getNestMembers(this.type);
/*  9146 */       (new Class[1])[0] = this.type; return new TypeList.ForLoadedTypes((member.length == 0) ? new Class[1] : member);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isNestHost() {
/*  9153 */       Class<?> host = DISPATCHER.getNestHost(this.type);
/*  9154 */       return (host == null || host == this.type);
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isNestMateOf(Class<?> type) {
/*  9159 */       return (DISPATCHER.isNestmateOf(this.type, type) || super.isNestMateOf(of(type)));
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isNestMateOf(TypeDescription typeDescription) {
/*  9164 */       return ((typeDescription instanceof ForLoadedType && DISPATCHER.isNestmateOf(this.type, ((ForLoadedType)typeDescription).type)) || super.isNestMateOf(typeDescription));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/*  9171 */       Object[] recordComponent = DISPATCHER.getRecordComponents(this.type);
/*  9172 */       return (recordComponent == null) ? new RecordComponentList.Empty<RecordComponentDescription.InDefinedShape>() : new RecordComponentList.ForLoadedRecordComponents(recordComponent);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isRecord() {
/*  9181 */       return DISPATCHER.isRecord(this.type);
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isSealed() {
/*  9186 */       return DISPATCHER.isSealed(this.type);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getPermittedSubtypes() {
/*  9193 */       Class<?>[] permittedSubclass = DISPATCHER.getPermittedSubclasses(this.type);
/*  9194 */       return (permittedSubclass == null) ? new TypeList.Empty() : new TypeList.ForLoadedTypes(permittedSubclass);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     @Enhance("classFileVersion")
/*       */     public ClassFileVersion getClassFileVersion() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Defaults
/*       */     @Proxied("java.lang.Class")
/*       */     protected static interface Dispatcher
/*       */     {
/*       */       @MaybeNull
/*       */       @Proxied("getAnnotatedSuperclass")
/*       */       AnnotatedElement getAnnotatedSuperclass(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Proxied("getAnnotatedInterfaces")
/*       */       AnnotatedElement[] getAnnotatedInterfaces(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       @Proxied("getNestHost")
/*       */       Class<?> getNestHost(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Proxied("getNestMembers")
/*       */       Class<?>[] getNestMembers(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Proxied("isNestmateOf")
/*       */       boolean isNestmateOf(Class<?> param2Class1, Class<?> param2Class2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Proxied("isSealed")
/*       */       boolean isSealed(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       @Proxied("getPermittedSubclasses")
/*       */       Class<?>[] getPermittedSubclasses(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Proxied("isRecord")
/*       */       boolean isRecord(Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       @Proxied("getRecordComponents")
/*       */       Object[] getRecordComponents(Class<?> param2Class);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static class ArrayProjection
/*       */     extends AbstractBase
/*       */   {
/*       */     private static final int ARRAY_IMPLIED = 1040;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private static final int ARRAY_EXCLUDED = 8712;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final TypeDescription componentType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final int arity;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected ArrayProjection(TypeDescription componentType, int arity) {
/*  9329 */       this.componentType = componentType;
/*  9330 */       this.arity = arity;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static TypeDescription of(TypeDescription componentType) {
/*  9340 */       return of(componentType, 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public static TypeDescription of(TypeDescription componentType, int arity) {
/*  9352 */       if (arity < 0) {
/*  9353 */         throw new IllegalArgumentException("Arrays cannot have a negative arity");
/*       */       }
/*  9355 */       while (componentType.isArray()) {
/*  9356 */         componentType = componentType.getComponentType();
/*  9357 */         arity++;
/*       */       } 
/*  9359 */       return (arity == 0) ? componentType : new ArrayProjection(componentType, arity);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isArray() {
/*  9368 */       return true;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getComponentType() {
/*  9376 */       return (this.arity == 1) ? this.componentType : new ArrayProjection(this.componentType, this.arity - 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isPrimitive() {
/*  9385 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription.Generic getSuperClass() {
/*  9393 */       return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getInterfaces() {
/*  9400 */       return ARRAY_INTERFACES;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/*  9408 */       return MethodDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getEnclosingType() {
/*  9416 */       return TypeDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getDeclaredTypes() {
/*  9423 */       return new TypeList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getSimpleName() {
/*  9430 */       StringBuilder stringBuilder = new StringBuilder(this.componentType.getSimpleName());
/*  9431 */       for (int i = 0; i < this.arity; i++) {
/*  9432 */         stringBuilder.append("[]");
/*       */       }
/*  9434 */       return stringBuilder.toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public String getCanonicalName() {
/*  9442 */       String canonicalName = this.componentType.getCanonicalName();
/*  9443 */       if (canonicalName == null) {
/*  9444 */         return NO_NAME;
/*       */       }
/*  9446 */       StringBuilder stringBuilder = new StringBuilder(canonicalName);
/*  9447 */       for (int i = 0; i < this.arity; i++) {
/*  9448 */         stringBuilder.append("[]");
/*       */       }
/*  9450 */       return stringBuilder.toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAnonymousType() {
/*  9457 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isLocalType() {
/*  9464 */       return false;
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isMemberType() {
/*  9469 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/*  9476 */       return (FieldList<FieldDescription.InDefinedShape>)new FieldList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/*  9483 */       return (MethodList<MethodDescription.InDefinedShape>)new MethodList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public StackSize getStackSize() {
/*  9490 */       return StackSize.SINGLE;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationList getDeclaredAnnotations() {
/*  9497 */       return (AnnotationList)new AnnotationList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationList getInheritedAnnotations() {
/*  9504 */       return (AnnotationList)new AnnotationList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public PackageDescription getPackage() {
/*  9512 */       return PackageDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getName() {
/*  9519 */       String descriptor = this.componentType.getDescriptor();
/*  9520 */       StringBuilder stringBuilder = new StringBuilder(descriptor.length() + this.arity); int index;
/*  9521 */       for (index = 0; index < this.arity; index++) {
/*  9522 */         stringBuilder.append('[');
/*       */       }
/*  9524 */       for (index = 0; index < descriptor.length(); index++) {
/*  9525 */         char character = descriptor.charAt(index);
/*  9526 */         stringBuilder.append((character == '/') ? 46 : character);
/*       */       } 
/*  9528 */       return stringBuilder.toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getDescriptor() {
/*  9535 */       StringBuilder stringBuilder = new StringBuilder();
/*  9536 */       for (int i = 0; i < this.arity; i++) {
/*  9537 */         stringBuilder.append('[');
/*       */       }
/*  9539 */       return stringBuilder.append(this.componentType.getDescriptor()).toString();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @AlwaysNull
/*       */     public TypeDescription getDeclaringType() {
/*  9547 */       return TypeDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */     public int getModifiers() {
/*  9555 */       return getComponentType().getModifiers() & 0xFFFFDDF7 | 0x410;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getTypeVariables() {
/*  9562 */       return new TypeList.Generic.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getNestHost() {
/*  9569 */       return this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getNestMembers() {
/*  9576 */       return new TypeList.Explicit(new TypeDescription[] { this });
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/*  9583 */       return new RecordComponentList.Empty<RecordComponentDescription.InDefinedShape>();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isRecord() {
/*  9590 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getPermittedSubtypes() {
/*  9597 */       return new TypeList.Empty();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static class Latent
/*       */     extends AbstractBase.OfSimpleType
/*       */   {
/*       */     private final String name;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final int modifiers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     private final TypeDescription.Generic superClass;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final List<? extends TypeDescription.Generic> interfaces;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Latent(String name, int modifiers, @MaybeNull TypeDescription.Generic superClass, TypeDescription.Generic... anInterface) {
/*  9642 */       this(name, modifiers, superClass, Arrays.asList(anInterface));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Latent(String name, int modifiers, @MaybeNull TypeDescription.Generic superClass, List<? extends TypeDescription.Generic> interfaces) {
/*  9654 */       this.name = name;
/*  9655 */       this.modifiers = modifiers;
/*  9656 */       this.superClass = superClass;
/*  9657 */       this.interfaces = interfaces;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription.Generic getSuperClass() {
/*  9665 */       return this.superClass;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getInterfaces() {
/*  9672 */       return new TypeList.Generic.Explicit((List)this.interfaces);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/*  9679 */       throw new IllegalStateException("Cannot resolve enclosing method of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getEnclosingType() {
/*  9686 */       throw new IllegalStateException("Cannot resolve enclosing type of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getDeclaredTypes() {
/*  9693 */       throw new IllegalStateException("Cannot resolve inner types of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAnonymousType() {
/*  9700 */       throw new IllegalStateException("Cannot resolve anonymous type property of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isLocalType() {
/*  9707 */       throw new IllegalStateException("Cannot resolve local class property of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/*  9714 */       throw new IllegalStateException("Cannot resolve declared fields of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/*  9721 */       throw new IllegalStateException("Cannot resolve declared methods of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public PackageDescription getPackage() {
/*  9729 */       String name = getName();
/*  9730 */       int index = name.lastIndexOf('.');
/*  9731 */       return (index == -1) ? PackageDescription.DEFAULT : new PackageDescription.Simple(name
/*       */           
/*  9733 */           .substring(0, index));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationList getDeclaredAnnotations() {
/*  9740 */       throw new IllegalStateException("Cannot resolve declared annotations of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getDeclaringType() {
/*  9747 */       throw new IllegalStateException("Cannot resolve declared type of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int getModifiers() {
/*  9754 */       return this.modifiers;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getName() {
/*  9761 */       return this.name;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getTypeVariables() {
/*  9768 */       throw new IllegalStateException("Cannot resolve type variables of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getNestHost() {
/*  9775 */       throw new IllegalStateException("Cannot resolve nest host of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getNestMembers() {
/*  9782 */       throw new IllegalStateException("Cannot resolve nest mates of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/*  9789 */       throw new IllegalStateException("Cannot resolve record components of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isRecord() {
/*  9796 */       throw new IllegalStateException("Cannot resolve record attribute of a latent type description: " + this);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getPermittedSubtypes() {
/*  9803 */       throw new IllegalStateException("Cannot resolve permitted subclasses of a latent type description: " + this);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static class ForPackageDescription
/*       */     extends AbstractBase.OfSimpleType
/*       */   {
/*       */     private final PackageDescription packageDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ForPackageDescription(PackageDescription packageDescription) {
/*  9823 */       this.packageDescription = packageDescription;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription.Generic getSuperClass() {
/*  9831 */       return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getInterfaces() {
/*  9838 */       return new TypeList.Generic.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/*  9846 */       return MethodDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getEnclosingType() {
/*  9854 */       return TypeDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAnonymousType() {
/*  9861 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isLocalType() {
/*  9868 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getDeclaredTypes() {
/*  9875 */       return new TypeList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/*  9882 */       return (FieldList<FieldDescription.InDefinedShape>)new FieldList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/*  9889 */       return (MethodList<MethodDescription.InDefinedShape>)new MethodList.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public PackageDescription getPackage() {
/*  9896 */       return this.packageDescription;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationList getDeclaredAnnotations() {
/*  9903 */       return this.packageDescription.getDeclaredAnnotations();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getDeclaringType() {
/*  9911 */       return TypeDescription.UNDEFINED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getTypeVariables() {
/*  9918 */       return new TypeList.Generic.Empty();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int getModifiers() {
/*  9925 */       return 5632;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getName() {
/*  9932 */       return this.packageDescription.getName() + "." + "package-info";
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getNestHost() {
/*  9939 */       return this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getNestMembers() {
/*  9946 */       return new TypeList.Explicit(new TypeDescription[] { this });
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/*  9953 */       return new RecordComponentList.Empty<RecordComponentDescription.InDefinedShape>();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isRecord() {
/*  9960 */       return false;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getPermittedSubtypes() {
/*  9967 */       return new TypeList.Empty();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static class SuperTypeLoading
/*       */     extends AbstractBase
/*       */   {
/*       */     private final TypeDescription delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     private final ClassLoader classLoader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final ClassLoadingDelegate classLoadingDelegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public SuperTypeLoading(TypeDescription delegate, @MaybeNull ClassLoader classLoader) {
/*  9999 */       this(delegate, classLoader, ClassLoadingDelegate.Simple.INSTANCE);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public SuperTypeLoading(TypeDescription delegate, @MaybeNull ClassLoader classLoader, ClassLoadingDelegate classLoadingDelegate) {
/* 10010 */       this.delegate = delegate;
/* 10011 */       this.classLoader = classLoader;
/* 10012 */       this.classLoadingDelegate = classLoadingDelegate;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationList getDeclaredAnnotations() {
/* 10019 */       return this.delegate.getDeclaredAnnotations();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int getModifiers() {
/* 10026 */       return this.delegate.getModifiers();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getTypeVariables() {
/* 10033 */       return this.delegate.getTypeVariables();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getDescriptor() {
/* 10040 */       return this.delegate.getDescriptor();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getName() {
/* 10047 */       return this.delegate.getName();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription.Generic getSuperClass() {
/* 10055 */       TypeDescription.Generic superClass = this.delegate.getSuperClass();
/* 10056 */       return (superClass == null) ? TypeDescription.Generic.UNDEFINED : new ClassLoadingTypeProjection(superClass, this.classLoader, this.classLoadingDelegate);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList.Generic getInterfaces() {
/* 10065 */       return new ClassLoadingTypeList(this.delegate.getInterfaces(), this.classLoader, this.classLoadingDelegate);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/* 10072 */       return this.delegate.getDeclaredFields();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/* 10079 */       return this.delegate.getDeclaredMethods();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public StackSize getStackSize() {
/* 10086 */       return this.delegate.getStackSize();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isArray() {
/* 10093 */       return this.delegate.isArray();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isPrimitive() {
/* 10100 */       return this.delegate.isPrimitive();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getComponentType() {
/* 10108 */       return this.delegate.getComponentType();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getDeclaringType() {
/* 10116 */       return this.delegate.getDeclaringType();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getDeclaredTypes() {
/* 10123 */       return this.delegate.getDeclaredTypes();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/* 10131 */       return this.delegate.getEnclosingMethod();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public TypeDescription getEnclosingType() {
/* 10139 */       return this.delegate.getEnclosingType();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public String getSimpleName() {
/* 10146 */       return this.delegate.getSimpleName();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public String getCanonicalName() {
/* 10154 */       return this.delegate.getCanonicalName();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isAnonymousType() {
/* 10161 */       return this.delegate.isAnonymousType();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isLocalType() {
/* 10168 */       return this.delegate.isLocalType();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public PackageDescription getPackage() {
/* 10176 */       return this.delegate.getPackage();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeDescription getNestHost() {
/* 10183 */       return this.delegate.getNestHost();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getNestMembers() {
/* 10190 */       return this.delegate.getNestMembers();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/* 10197 */       return this.delegate.getRecordComponents();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isRecord() {
/* 10204 */       return this.delegate.isRecord();
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean isSealed() {
/* 10209 */       return this.delegate.isSealed();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public TypeList getPermittedSubtypes() {
/* 10216 */       return this.delegate.getPermittedSubtypes();
/*       */     }
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     public ClassFileVersion getClassFileVersion() {
/* 10222 */       return this.delegate.getClassFileVersion();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Simple
/*       */       implements ClassLoadingDelegate
/*       */     {
/* 10248 */       INSTANCE;
/*       */ 
/*       */ 
/*       */       
/*       */       public Class<?> load(String name, @MaybeNull ClassLoader classLoader) throws ClassNotFoundException
/*       */       {
/* 10254 */         return Class.forName(name, false, classLoader); } } public static interface ClassLoadingDelegate { Class<?> load(String param2String, @MaybeNull ClassLoader param2ClassLoader) throws ClassNotFoundException; public enum Simple implements ClassLoadingDelegate { INSTANCE; public Class<?> load(String name, @MaybeNull ClassLoader classLoader) throws ClassNotFoundException { return Class.forName(name, false, classLoader); }
/*       */          }
/*       */        }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static class ClassLoadingTypeProjection
/*       */       extends TypeDescription.Generic.LazyProjection
/*       */     {
/*       */       private final TypeDescription.Generic delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       private final ClassLoader classLoader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription.SuperTypeLoading.ClassLoadingDelegate classLoadingDelegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ClassLoadingTypeProjection(TypeDescription.Generic delegate, @MaybeNull ClassLoader classLoader, TypeDescription.SuperTypeLoading.ClassLoadingDelegate classLoadingDelegate) {
/* 10288 */         this.delegate = delegate;
/* 10289 */         this.classLoader = classLoader;
/* 10290 */         this.classLoadingDelegate = classLoadingDelegate;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AnnotationList getDeclaredAnnotations() {
/* 10297 */         return this.delegate.getDeclaredAnnotations();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("erasure")
/*       */       public TypeDescription asErasure() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected TypeDescription.Generic resolve() {
/* 10314 */         return this.delegate;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       @Enhance("superClass")
/*       */       public TypeDescription.Generic getSuperClass() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance("interfaces")
/*       */       public TypeList.Generic getInterfaces() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<TypeDefinition> iterator() {
/* 10356 */         return new TypeDefinition.SuperClassIterator(this);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static class ClassLoadingTypeList
/*       */       extends TypeList.Generic.AbstractBase
/*       */     {
/*       */       private final TypeList.Generic delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       private final ClassLoader classLoader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription.SuperTypeLoading.ClassLoadingDelegate classLoadingDelegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ClassLoadingTypeList(TypeList.Generic delegate, @MaybeNull ClassLoader classLoader, TypeDescription.SuperTypeLoading.ClassLoadingDelegate classLoadingDelegate) {
/* 10389 */         this.delegate = delegate;
/* 10390 */         this.classLoader = classLoader;
/* 10391 */         this.classLoadingDelegate = classLoadingDelegate;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription.Generic get(int index) {
/* 10398 */         return new TypeDescription.SuperTypeLoading.ClassLoadingTypeProjection((TypeDescription.Generic)this.delegate.get(index), this.classLoader, this.classLoadingDelegate);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int size() {
/* 10405 */         return this.delegate.size();
/*       */       }
/*       */     }
/*       */   }
/*       */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\type\TypeDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */