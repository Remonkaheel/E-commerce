/*     */ package net.bytebuddy.description.type;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.GenericSignatureFormatError;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.DeclaredByType;
/*     */ import net.bytebuddy.description.NamedElement;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.annotation.AnnotationSource;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureVisitor;
/*     */ import net.bytebuddy.jar.asm.signature.SignatureWriter;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Instance;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RecordComponentDescription
/*     */   extends DeclaredByType.WithMandatoryDeclaration, NamedElement.WithDescriptor, AnnotationSource, ByteCodeElement.TypeDependant<RecordComponentDescription.InDefinedShape, RecordComponentDescription.Token>
/*     */ {
/*     */   TypeDescription.Generic getType();
/*     */   
/*     */   MethodDescription getAccessor();
/*     */   
/*     */   Token asToken(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*     */   
/*     */   public static interface InGenericShape
/*     */     extends RecordComponentDescription
/*     */   {
/*     */     MethodDescription.InGenericShape getAccessor();
/*     */   }
/*     */   
/*     */   public static interface InDefinedShape
/*     */     extends RecordComponentDescription
/*     */   {
/*     */     MethodDescription.InDefinedShape getAccessor();
/*     */     
/*     */     @Nonnull
/*     */     TypeDescription getDeclaringType();
/*     */     
/*     */     public static abstract class AbstractBase
/*     */       extends RecordComponentDescription.AbstractBase
/*     */       implements InDefinedShape
/*     */     {
/*     */       public MethodDescription.InDefinedShape getAccessor() {
/* 109 */         return (MethodDescription.InDefinedShape)((MethodList)getDeclaringType().getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named(getActualName()))).getOnly();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RecordComponentDescription.InDefinedShape asDefined() {
/* 116 */         return this;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     implements RecordComponentDescription
/*     */   {
/*     */     public RecordComponentDescription.Token asToken(ElementMatcher<? super TypeDescription> matcher) {
/* 130 */       return new RecordComponentDescription.Token(getActualName(), 
/* 131 */           getType().<TypeDescription.Generic>accept(new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)), (List<? extends AnnotationDescription>)
/* 132 */           getDeclaredAnnotations());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDescriptor() {
/* 139 */       return getType().asErasure().getDescriptor();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public String getGenericSignature() {
/* 147 */       TypeDescription.Generic recordComponentType = getType();
/*     */       try {
/* 149 */         return recordComponentType.getSort().isNonGeneric() ? NON_GENERIC_SIGNATURE : ((SignatureVisitor)recordComponentType
/*     */           
/* 151 */           .<SignatureVisitor>accept(new TypeDescription.Generic.Visitor.ForSignatureVisitor((SignatureVisitor)new SignatureWriter()))).toString();
/* 152 */       } catch (GenericSignatureFormatError ignored) {
/* 153 */         return NON_GENERIC_SIGNATURE;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 159 */       return getActualName().hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object other) {
/* 164 */       if (this == other)
/* 165 */         return true; 
/* 166 */       if (!(other instanceof RecordComponentDescription)) {
/* 167 */         return false;
/*     */       }
/* 169 */       RecordComponentDescription recordComponentDescription = (RecordComponentDescription)other;
/* 170 */       return getActualName().equals(recordComponentDescription.getActualName());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 175 */       return getType().getTypeName() + " " + getActualName();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedRecordComponent
/*     */     extends InDefinedShape.AbstractBase
/*     */   {
/* 187 */     protected static final RecordComponent RECORD_COMPONENT = doPrivileged(JavaDispatcher.of(RecordComponent.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */        }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final AnnotatedElement recordComponent;
/*     */ 
/*     */     
/*     */     private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */     
/*     */     protected ForLoadedRecordComponent(AnnotatedElement recordComponent) {
/* 200 */       this.recordComponent = recordComponent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 212 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static RecordComponentDescription of(Object recordComponent) {
/* 222 */       if (!RECORD_COMPONENT.isInstance(recordComponent)) {
/* 223 */         throw new IllegalArgumentException("Not a record component: " + recordComponent);
/*     */       }
/* 225 */       return new ForLoadedRecordComponent((AnnotatedElement)recordComponent);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 232 */       return new TypeDescription.Generic.LazyProjection.OfRecordComponent(this.recordComponent);
/*     */     }
/*     */ 
/*     */     
/*     */     public MethodDescription.InDefinedShape getAccessor() {
/* 237 */       return (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(RECORD_COMPONENT.getAccessor(this.recordComponent));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public TypeDescription getDeclaringType() {
/* 245 */       return TypeDescription.ForLoadedType.of(RECORD_COMPONENT.getDeclaringRecord(this.recordComponent));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getActualName() {
/* 252 */       return RECORD_COMPONENT.getName(this.recordComponent);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public String getGenericSignature() {
/* 258 */       return RECORD_COMPONENT.getGenericSignature(this.recordComponent);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getDeclaredAnnotations() {
/* 265 */       return (AnnotationList)new AnnotationList.ForLoadedAnnotations(this.recordComponent.getDeclaredAnnotations());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Proxied("java.lang.reflect.RecordComponent")
/*     */     protected static interface RecordComponent
/*     */     {
/*     */       @Instance
/*     */       @Proxied("isInstance")
/*     */       boolean isInstance(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getName")
/*     */       String getName(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getDeclaringRecord")
/*     */       Class<?> getDeclaringRecord(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getAccessor")
/*     */       Method getAccessor(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getType")
/*     */       Class<?> getType(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getGenericType")
/*     */       Type getGenericType(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       @Proxied("getGenericSignature")
/*     */       String getGenericSignature(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getAnnotatedType")
/*     */       AnnotatedElement getAnnotatedType(Object param2Object);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Latent
/*     */     extends InDefinedShape.AbstractBase
/*     */   {
/*     */     private final TypeDescription declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Latent(TypeDescription declaringType, RecordComponentDescription.Token token) {
/* 374 */       this(declaringType, token
/* 375 */           .getName(), token
/* 376 */           .getType(), (List<? extends AnnotationDescription>)token
/* 377 */           .getAnnotations());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Latent(TypeDescription declaringType, String name, TypeDescription.Generic type, List<? extends AnnotationDescription> annotations) {
/* 389 */       this.declaringType = declaringType;
/* 390 */       this.name = name;
/* 391 */       this.type = type;
/* 392 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 399 */       return this.type.<TypeDescription.Generic>accept(TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public TypeDescription getDeclaringType() {
/* 407 */       return this.declaringType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getActualName() {
/* 414 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getDeclaredAnnotations() {
/* 421 */       return (AnnotationList)new AnnotationList.Explicit(this.annotations);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeSubstituting
/*     */     extends AbstractBase
/*     */     implements InGenericShape
/*     */   {
/*     */     private final TypeDescription.Generic declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final RecordComponentDescription recordComponentDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSubstituting(TypeDescription.Generic declaringType, RecordComponentDescription recordComponentDescription, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 455 */       this.declaringType = declaringType;
/* 456 */       this.recordComponentDescription = recordComponentDescription;
/* 457 */       this.visitor = visitor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodDescription.InGenericShape getAccessor() {
/* 464 */       return (MethodDescription.InGenericShape)((MethodList)this.declaringType.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named(getActualName()))).getOnly();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 471 */       return this.recordComponentDescription.getType().<TypeDescription.Generic>accept((TypeDescription.Generic.Visitor)this.visitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentDescription.InDefinedShape asDefined() {
/* 478 */       return (RecordComponentDescription.InDefinedShape)this.recordComponentDescription.asDefined();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nonnull
/*     */     public TypeDefinition getDeclaringType() {
/* 486 */       return this.declaringType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getActualName() {
/* 493 */       return this.recordComponentDescription.getActualName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getDeclaredAnnotations() {
/* 500 */       return this.recordComponentDescription.getDeclaredAnnotations();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Token
/*     */     implements ByteCodeElement.Token<Token>
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Token(String name, TypeDescription.Generic type) {
/* 531 */       this(name, type, Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Token(String name, TypeDescription.Generic type, List<? extends AnnotationDescription> annotations) {
/* 542 */       this.name = name;
/* 543 */       this.type = type;
/* 544 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 553 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription.Generic getType() {
/* 562 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotationList getAnnotations() {
/* 571 */       return (AnnotationList)new AnnotationList.Explicit(this.annotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Token accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 578 */       return new Token(this.name, this.type.<TypeDescription.Generic>accept((TypeDescription.Generic.Visitor)visitor), this.annotations);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance("hashCode")
/*     */     public int hashCode() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object other) {
/* 592 */       if (this == other)
/* 593 */         return true; 
/* 594 */       if (other == null || getClass() != other.getClass()) {
/* 595 */         return false;
/*     */       }
/* 597 */       Token token = (Token)other;
/* 598 */       return (this.name.equals(token.name) && this.type
/* 599 */         .equals(token.type) && this.annotations
/* 600 */         .equals(token.annotations));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\type\RecordComponentDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */