/*     */ package net.bytebuddy.description.method;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.FilterableList;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Instance;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ParameterList<T extends ParameterDescription>
/*     */   extends FilterableList<T, ParameterList<T>>
/*     */ {
/*     */   TypeList.Generic asTypeList();
/*     */   
/*     */   ByteCodeElement.Token.TokenList<ParameterDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*     */   
/*     */   ParameterList<ParameterDescription.InDefinedShape> asDefined();
/*     */   
/*     */   boolean hasExplicitMetaData();
/*     */   
/*     */   public static abstract class AbstractBase<S extends ParameterDescription>
/*     */     extends FilterableList.AbstractBase<S, ParameterList<S>>
/*     */     implements ParameterList<S>
/*     */   {
/*     */     public boolean hasExplicitMetaData() {
/*  82 */       int size = size();
/*  83 */       for (int index = 0; index < size; index++) {
/*  84 */         ParameterDescription parameterDescription = (ParameterDescription)get(index);
/*  85 */         if (!parameterDescription.isNamed() || !parameterDescription.hasModifiers()) {
/*  86 */           return false;
/*     */         }
/*     */       } 
/*  89 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteCodeElement.Token.TokenList<ParameterDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/*  96 */       int size = size();
/*  97 */       List<ParameterDescription.Token> tokens = new ArrayList<ParameterDescription.Token>(size);
/*  98 */       for (int index = 0; index < size; index++) {
/*  99 */         tokens.add(((ParameterDescription)get(index)).asToken(matcher));
/*     */       }
/* 101 */       return new ByteCodeElement.Token.TokenList(tokens);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeList.Generic asTypeList() {
/* 108 */       int size = size();
/* 109 */       List<TypeDescription.Generic> types = new ArrayList<TypeDescription.Generic>(size);
/* 110 */       for (int index = 0; index < size; index++) {
/* 111 */         types.add(((ParameterDescription)get(index)).getType());
/*     */       }
/* 113 */       return (TypeList.Generic)new TypeList.Generic.Explicit(types);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ParameterList<ParameterDescription.InDefinedShape> asDefined() {
/* 120 */       int size = size();
/* 121 */       List<ParameterDescription.InDefinedShape> declaredForms = new ArrayList<ParameterDescription.InDefinedShape>(size);
/* 122 */       for (int index = 0; index < size; index++) {
/* 123 */         declaredForms.add(((ParameterDescription)get(index)).asDefined());
/*     */       }
/* 125 */       return new ParameterList.Explicit<ParameterDescription.InDefinedShape>(declaredForms);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ParameterList<S> wrap(List<S> values) {
/* 130 */       return new ParameterList.Explicit<S>(values);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class ForLoadedExecutable<T>
/*     */     extends AbstractBase<ParameterDescription.InDefinedShape>
/*     */   {
/* 144 */     protected static final Executable EXECUTABLE = doPrivileged(JavaDispatcher.of(Executable.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */        }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final T executable;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource;
/*     */ 
/*     */ 
/*     */     
/*     */     private int size;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForLoadedExecutable(T executable, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 170 */       this.executable = executable;
/* 171 */       this.parameterAnnotationSource = parameterAnnotationSource;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 183 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ParameterList<ParameterDescription.InDefinedShape> of(Constructor<?> constructor) {
/* 193 */       return of(constructor, new ParameterDescription.ForLoadedParameter.ParameterAnnotationSource.ForLoadedConstructor(constructor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ParameterList<ParameterDescription.InDefinedShape> of(Constructor<?> constructor, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 205 */       return EXECUTABLE.isInstance(constructor) ? new OfConstructor(constructor, parameterAnnotationSource) : new OfLegacyVmConstructor(constructor, parameterAnnotationSource);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ParameterList<ParameterDescription.InDefinedShape> of(Method method) {
/* 217 */       return of(method, new ParameterDescription.ForLoadedParameter.ParameterAnnotationSource.ForLoadedMethod(method));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ParameterList<ParameterDescription.InDefinedShape> of(Method method, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 229 */       return EXECUTABLE.isInstance(method) ? new OfMethod(method, parameterAnnotationSource) : new OfLegacyVmMethod(method, parameterAnnotationSource);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 238 */       int size = this.size;
/* 239 */       if (size == 0) {
/* 240 */         int actual = EXECUTABLE.getParameterCount(this.executable);
/* 241 */         this.size = size = (actual == 0) ? -1 : actual;
/*     */       } 
/* 243 */       return (size == -1) ? 0 : size;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Proxied("java.lang.reflect.Executable")
/*     */     protected static interface Executable
/*     */     {
/*     */       @Instance
/*     */       @Proxied("isInstance")
/*     */       boolean isInstance(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getParameterCount")
/*     */       int getParameterCount(Object param2Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Proxied("getParameters")
/*     */       Object[] getParameters(Object param2Object);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class OfConstructor
/*     */       extends ForLoadedExecutable<Constructor<?>>
/*     */     {
/*     */       protected OfConstructor(Constructor<?> constructor, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 290 */         super(constructor, parameterAnnotationSource);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ParameterDescription.InDefinedShape get(int index) {
/* 297 */         return new ParameterDescription.ForLoadedParameter.OfConstructor(this.executable, index, this.parameterAnnotationSource);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class OfMethod
/*     */       extends ForLoadedExecutable<Method>
/*     */     {
/*     */       protected OfMethod(Method method, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 313 */         super(method, parameterAnnotationSource);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ParameterDescription.InDefinedShape get(int index) {
/* 320 */         return new ParameterDescription.ForLoadedParameter.OfMethod(this.executable, index, this.parameterAnnotationSource);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class OfLegacyVmConstructor
/*     */       extends ParameterList.AbstractBase<ParameterDescription.InDefinedShape>
/*     */     {
/*     */       private final Constructor<?> constructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final Class<?>[] parameterType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected OfLegacyVmConstructor(Constructor<?> constructor, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 352 */         this.constructor = constructor;
/* 353 */         this.parameterType = constructor.getParameterTypes();
/* 354 */         this.parameterAnnotationSource = parameterAnnotationSource;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ParameterDescription.InDefinedShape get(int index) {
/* 361 */         return new ParameterDescription.ForLoadedParameter.OfLegacyVmConstructor(this.constructor, index, this.parameterType, this.parameterAnnotationSource);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int size() {
/* 368 */         return this.parameterType.length;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class OfLegacyVmMethod
/*     */       extends ParameterList.AbstractBase<ParameterDescription.InDefinedShape>
/*     */     {
/*     */       private final Method method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final Class<?>[] parameterType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected OfLegacyVmMethod(Method method, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/* 400 */         this.method = method;
/* 401 */         this.parameterType = method.getParameterTypes();
/* 402 */         this.parameterAnnotationSource = parameterAnnotationSource;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ParameterDescription.InDefinedShape get(int index) {
/* 409 */         return new ParameterDescription.ForLoadedParameter.OfLegacyVmMethod(this.method, index, this.parameterType, this.parameterAnnotationSource);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int size() {
/* 416 */         return this.parameterType.length;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Explicit<S extends ParameterDescription>
/*     */     extends AbstractBase<S>
/*     */   {
/*     */     private final List<? extends S> parameterDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(S... parameterDescription) {
/* 440 */       this(Arrays.asList(parameterDescription));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends S> parameterDescriptions) {
/* 449 */       this.parameterDescriptions = parameterDescriptions;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S get(int index) {
/* 456 */       return this.parameterDescriptions.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 463 */       return this.parameterDescriptions.size();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class ForTypes
/*     */       extends ParameterList.AbstractBase<ParameterDescription.InDefinedShape>
/*     */     {
/*     */       private final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final List<? extends TypeDefinition> typeDefinitions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ForTypes(MethodDescription.InDefinedShape methodDescription, TypeDefinition... typeDefinition) {
/* 488 */         this(methodDescription, Arrays.asList(typeDefinition));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ForTypes(MethodDescription.InDefinedShape methodDescription, List<? extends TypeDefinition> typeDefinitions) {
/* 498 */         this.methodDescription = methodDescription;
/* 499 */         this.typeDefinitions = typeDefinitions;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ParameterDescription.InDefinedShape get(int index) {
/* 506 */         int offset = this.methodDescription.isStatic() ? 0 : 1;
/* 507 */         for (int previous = 0; previous < index; previous++) {
/* 508 */           offset += ((TypeDefinition)this.typeDefinitions.get(previous)).getStackSize().getSize();
/*     */         }
/* 510 */         return new ParameterDescription.Latent(this.methodDescription, ((TypeDefinition)this.typeDefinitions.get(index)).asGenericType(), index, offset);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int size() {
/* 517 */         return this.typeDefinitions.size();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForTokens
/*     */     extends AbstractBase<ParameterDescription.InDefinedShape>
/*     */   {
/*     */     private final MethodDescription.InDefinedShape declaringMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends ParameterDescription.Token> tokens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(MethodDescription.InDefinedShape declaringMethod, List<? extends ParameterDescription.Token> tokens) {
/* 544 */       this.declaringMethod = declaringMethod;
/* 545 */       this.tokens = tokens;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ParameterDescription.InDefinedShape get(int index) {
/* 552 */       int offset = this.declaringMethod.isStatic() ? 0 : 1;
/* 553 */       for (ParameterDescription.Token token : this.tokens.subList(0, index)) {
/* 554 */         offset += token.getType().getStackSize().getSize();
/*     */       }
/* 556 */       return new ParameterDescription.Latent(this.declaringMethod, this.tokens.get(index), index, offset);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 563 */       return this.tokens.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeSubstituting
/*     */     extends AbstractBase<ParameterDescription.InGenericShape>
/*     */   {
/*     */     private final MethodDescription.InGenericShape declaringMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends ParameterDescription> parameterDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSubstituting(MethodDescription.InGenericShape declaringMethod, List<? extends ParameterDescription> parameterDescriptions, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 604 */       this.declaringMethod = declaringMethod;
/* 605 */       this.parameterDescriptions = parameterDescriptions;
/* 606 */       this.visitor = visitor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ParameterDescription.InGenericShape get(int index) {
/* 613 */       return new ParameterDescription.TypeSubstituting(this.declaringMethod, this.parameterDescriptions.get(index), this.visitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 620 */       int size = this.size;
/* 621 */       if (size == 0) {
/* 622 */         int actual = this.parameterDescriptions.size();
/* 623 */         this.size = size = (actual == 0) ? -1 : actual;
/*     */       } 
/* 625 */       return (size == -1) ? 0 : size;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Empty<S extends ParameterDescription>
/*     */     extends FilterableList.Empty<S, ParameterList<S>>
/*     */     implements ParameterList<S>
/*     */   {
/*     */     public boolean hasExplicitMetaData() {
/* 640 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeList.Generic asTypeList() {
/* 647 */       return (TypeList.Generic)new TypeList.Generic.Empty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteCodeElement.Token.TokenList<ParameterDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/* 654 */       return new ByteCodeElement.Token.TokenList((ByteCodeElement.Token[])new ParameterDescription.Token[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ParameterList<ParameterDescription.InDefinedShape> asDefined() {
/* 662 */       return (ParameterList)this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\method\ParameterList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */