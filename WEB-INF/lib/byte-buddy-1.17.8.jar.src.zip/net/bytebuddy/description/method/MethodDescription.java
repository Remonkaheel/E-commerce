/*      */ package net.bytebuddy.description.method;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.GenericSignatureFormatError;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Type;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import javax.annotation.Nonnull;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*      */ import net.bytebuddy.description.ByteCodeElement;
/*      */ import net.bytebuddy.description.DeclaredByType;
/*      */ import net.bytebuddy.description.ModifierReviewable;
/*      */ import net.bytebuddy.description.TypeVariableSource;
/*      */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.annotation.AnnotationValue;
/*      */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.description.type.TypeVariableToken;
/*      */ import net.bytebuddy.jar.asm.Type;
/*      */ import net.bytebuddy.jar.asm.signature.SignatureWriter;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.utility.JavaType;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Defaults;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface MethodDescription
/*      */   extends TypeVariableSource, ModifierReviewable.ForMethodDescription, DeclaredByType.WithMandatoryDeclaration, ByteCodeElement.Member, ByteCodeElement.TypeDependant<MethodDescription.InDefinedShape, MethodDescription.Token>
/*      */ {
/*      */   public static final String CONSTRUCTOR_INTERNAL_NAME = "<init>";
/*      */   public static final String TYPE_INITIALIZER_INTERNAL_NAME = "<clinit>";
/*      */   public static final int TYPE_INITIALIZER_MODIFIER = 8;
/*      */   @AlwaysNull
/*   84 */   public static final InDefinedShape UNDEFINED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nonnull
/*      */   TypeDefinition getDeclaringType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TypeDescription.Generic getReturnType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ParameterList<?> getParameters();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TypeList.Generic getExceptionTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getActualModifiers();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getActualModifiers(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getActualModifiers(boolean paramBoolean, Visibility paramVisibility);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isConstructor();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isMethod();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isTypeInitializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean represents(Method paramMethod);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean represents(Constructor<?> paramConstructor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isVirtual();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getStackSize();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDefaultMethod();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isSpecializableFor(TypeDescription paramTypeDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   AnnotationValue<?, ?> getDefaultValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   <T> T getDefaultValue(Class<T> paramClass);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isInvokableOn(TypeDescription paramTypeDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isInvokeBootstrap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isInvokeBootstrap(List<? extends TypeDefinition> paramList);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isConstantBootstrap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isConstantBootstrap(List<? extends TypeDefinition> paramList);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDefaultValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDefaultValue(AnnotationValue<?, ?> paramAnnotationValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   TypeDescription.Generic getReceiverType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SignatureToken asSignatureToken();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TypeToken asTypeToken();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isBridgeCompatible(TypeToken paramTypeToken);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface InGenericShape
/*      */     extends MethodDescription
/*      */   {
/*      */     @Nonnull
/*      */     TypeDescription.Generic getDeclaringType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ParameterList<ParameterDescription.InGenericShape> getParameters();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface InDefinedShape
/*      */     extends MethodDescription
/*      */   {
/*      */     @Nonnull
/*      */     TypeDescription getDeclaringType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ParameterList<ParameterDescription.InDefinedShape> getParameters();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static abstract class AbstractBase
/*      */       extends MethodDescription.AbstractBase
/*      */       implements InDefinedShape
/*      */     {
/*      */       public MethodDescription.InDefinedShape asDefined() {
/*  358 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public TypeDescription.Generic getReceiverType() {
/*  366 */         if (isStatic())
/*  367 */           return TypeDescription.Generic.UNDEFINED; 
/*  368 */         if (isConstructor()) {
/*  369 */           TypeDescription declaringType = getDeclaringType(), enclosingDeclaringType = getDeclaringType().getEnclosingType();
/*  370 */           if (enclosingDeclaringType == null) {
/*  371 */             return TypeDescription.Generic.OfParameterizedType.ForGenerifiedErasure.of(declaringType);
/*      */           }
/*  373 */           return declaringType.isStatic() ? enclosingDeclaringType
/*  374 */             .asGenericType() : 
/*  375 */             TypeDescription.Generic.OfParameterizedType.ForGenerifiedErasure.of(enclosingDeclaringType);
/*      */         } 
/*      */         
/*  378 */         return TypeDescription.Generic.OfParameterizedType.ForGenerifiedErasure.of(getDeclaringType());
/*      */       }
/*      */       
/*      */       @Proxied("java.lang.reflect.Executable")
/*      */       protected static interface Executable
/*      */       {
/*      */         @MaybeNull
/*      */         @Defaults
/*      */         @Proxied("getAnnotatedReceiverType")
/*      */         AnnotatedElement getAnnotatedReceiverType(Object param3Object);
/*      */       }
/*      */       
/*      */       protected static abstract class ForLoadedExecutable<T extends AnnotatedElement>
/*      */         extends AbstractBase {
/*  392 */         protected static final MethodDescription.InDefinedShape.AbstractBase.Executable EXECUTABLE = doPrivileged(JavaDispatcher.of(MethodDescription.InDefinedShape.AbstractBase.Executable.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */            }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final T executable;
/*      */ 
/*      */         
/*      */         private static final boolean ACCESS_CONTROLLER;
/*      */ 
/*      */         
/*      */         protected ForLoadedExecutable(T executable) {
/*  405 */           this.executable = executable;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  417 */           return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription.Generic getReceiverType() {
/*  424 */           AnnotatedElement element = EXECUTABLE.getAnnotatedReceiverType(this.executable);
/*  425 */           return (element == null) ? super
/*  426 */             .getReceiverType() : 
/*  427 */             TypeDefinition.Sort.describeAnnotated(element);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AbstractBase
/*      */     extends TypeVariableSource.AbstractBase
/*      */     implements MethodDescription
/*      */   {
/*      */     private static final int SOURCE_MODIFIERS = 1343;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getStackSize() {
/*  471 */       return getParameters().asTypeList().getStackSize() + (isStatic() ? 0 : 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isMethod() {
/*  478 */       return (!isConstructor() && !isTypeInitializer());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isConstructor() {
/*  485 */       return "<init>".equals(getInternalName());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isTypeInitializer() {
/*  492 */       return "<clinit>".equals(getInternalName());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean represents(Method method) {
/*  499 */       return equals(new MethodDescription.ForLoadedMethod(method));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean represents(Constructor<?> constructor) {
/*  506 */       return equals(new MethodDescription.ForLoadedConstructor(constructor));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  513 */       return isMethod() ? 
/*  514 */         getInternalName() : 
/*  515 */         getDeclaringType().asErasure().getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getActualName() {
/*  522 */       return isMethod() ? 
/*  523 */         getName() : "";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getDescriptor() {
/*  531 */       StringBuilder descriptor = (new StringBuilder()).append('(');
/*  532 */       for (TypeDescription parameterType : getParameters().asTypeList().asErasures()) {
/*  533 */         descriptor.append(parameterType.getDescriptor());
/*      */       }
/*  535 */       return descriptor.append(')').append(getReturnType().asErasure().getDescriptor()).toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public String getGenericSignature() {
/*      */       try {
/*  544 */         SignatureWriter signatureWriter = new SignatureWriter();
/*  545 */         boolean generic = false;
/*  546 */         for (TypeDescription.Generic typeVariable : getTypeVariables()) {
/*  547 */           signatureWriter.visitFormalTypeParameter(typeVariable.getSymbol());
/*  548 */           boolean classBound = true;
/*  549 */           for (TypeDescription.Generic upperBound : typeVariable.getUpperBounds()) {
/*  550 */             upperBound.accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.ForSignatureVisitor(classBound ? signatureWriter
/*  551 */                   .visitClassBound() : signatureWriter
/*  552 */                   .visitInterfaceBound()));
/*  553 */             classBound = false;
/*      */           } 
/*  555 */           generic = true;
/*      */         } 
/*  557 */         for (TypeDescription.Generic parameterType : getParameters().asTypeList()) {
/*  558 */           parameterType.accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.ForSignatureVisitor(signatureWriter.visitParameterType()));
/*  559 */           generic = (generic || !parameterType.getSort().isNonGeneric());
/*      */         } 
/*  561 */         TypeDescription.Generic returnType = getReturnType();
/*  562 */         returnType.accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.ForSignatureVisitor(signatureWriter.visitReturnType()));
/*  563 */         generic = (generic || !returnType.getSort().isNonGeneric());
/*  564 */         TypeList.Generic exceptionTypes = getExceptionTypes();
/*  565 */         if (!((TypeList.Generic)exceptionTypes.filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.ofSort(TypeDefinition.Sort.NON_GENERIC)))).isEmpty()) {
/*  566 */           for (TypeDescription.Generic exceptionType : exceptionTypes) {
/*  567 */             exceptionType.accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.ForSignatureVisitor(signatureWriter.visitExceptionType()));
/*  568 */             generic = (generic || !exceptionType.getSort().isNonGeneric());
/*      */           } 
/*      */         }
/*  571 */         return generic ? signatureWriter
/*  572 */           .toString() : NON_GENERIC_SIGNATURE;
/*      */       }
/*  574 */       catch (GenericSignatureFormatError ignored) {
/*  575 */         return NON_GENERIC_SIGNATURE;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getActualModifiers() {
/*  583 */       return getModifiers() | (getDeclaredAnnotations().isAnnotationPresent(Deprecated.class) ? 131072 : 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getActualModifiers(boolean manifest) {
/*  592 */       int modifiers = getActualModifiers();
/*  593 */       if (manifest)
/*  594 */         return modifiers & 0xFFFFFAFF; 
/*  595 */       if ((modifiers & 0x500) == 0) {
/*  596 */         return modifiers | 0x400;
/*      */       }
/*  598 */       return modifiers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getActualModifiers(boolean manifest, Visibility visibility) {
/*  606 */       return ModifierContributor.Resolver.of(Collections.singleton(getVisibility().expandTo(visibility))).resolve(getActualModifiers(manifest));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVisibleTo(TypeDescription typeDescription) {
/*  613 */       return (getDeclaringType().asErasure().equals(typeDescription) || (
/*  614 */         isPublic() && getDeclaringType().isPublic()) || ((
/*  615 */         isPublic() || isProtected()) && getDeclaringType().asErasure().isAssignableFrom(typeDescription)) || (
/*  616 */         !isPrivate() && getDeclaringType().asErasure().isSamePackage(typeDescription)) || (
/*  617 */         isPrivate() && getDeclaringType().asErasure().isNestMateOf(typeDescription)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAccessibleTo(TypeDescription typeDescription) {
/*  624 */       return (getDeclaringType().asErasure().equals(typeDescription) || (
/*  625 */         isPublic() && getDeclaringType().isPublic()) || (
/*  626 */         !isPrivate() && getDeclaringType().asErasure().isSamePackage(typeDescription)) || (
/*  627 */         isPrivate() && getDeclaringType().asErasure().isNestMateOf(typeDescription)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVirtual() {
/*  634 */       return (!isConstructor() && !isPrivate() && !isStatic() && !isTypeInitializer());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isDefaultMethod() {
/*  641 */       return (!isAbstract() && !isBridge() && getDeclaringType().isInterface());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSpecializableFor(TypeDescription targetType) {
/*  648 */       if (isStatic())
/*  649 */         return false; 
/*  650 */       if (isPrivate() || isConstructor()) {
/*  651 */         return getDeclaringType().equals(targetType);
/*      */       }
/*  653 */       return (!isAbstract() && getDeclaringType().asErasure().isAssignableFrom(targetType));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public <T> T getDefaultValue(Class<T> type) {
/*  662 */       return type.cast(getDefaultValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInvokableOn(TypeDescription typeDescription) {
/*  669 */       return (!isStatic() && 
/*  670 */         !isTypeInitializer() && 
/*  671 */         isVisibleTo(typeDescription) && (
/*  672 */         isVirtual() ? 
/*  673 */         getDeclaringType().asErasure().isAssignableFrom(typeDescription) : 
/*  674 */         getDeclaringType().asErasure().equals(typeDescription)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*      */     private boolean isBootstrap(TypeDescription bootstrapped) {
/*  685 */       TypeList parameterTypes = getParameters().asTypeList().asErasures();
/*  686 */       switch (parameterTypes.size()) {
/*      */         case 0:
/*  688 */           return false;
/*      */         case 1:
/*  690 */           return ((TypeDescription)parameterTypes.getOnly()).represents(Object[].class);
/*      */         case 2:
/*  692 */           return (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().isAssignableTo((TypeDescription)parameterTypes.get(0)) && ((TypeDescription)parameterTypes
/*  693 */             .get(1)).represents(Object[].class));
/*      */         case 3:
/*  695 */           return (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().isAssignableTo((TypeDescription)parameterTypes.get(0)) && (((TypeDescription)parameterTypes
/*  696 */             .get(1)).represents(Object.class) || ((TypeDescription)parameterTypes.get(1)).represents(String.class)) && ((((TypeDescription)parameterTypes
/*  697 */             .get(2)).isArray() && ((TypeDescription)parameterTypes.get(2)).getComponentType().isAssignableFrom(bootstrapped)) || ((TypeDescription)parameterTypes.get(2)).isAssignableFrom(bootstrapped)));
/*      */       } 
/*  699 */       return (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().isAssignableTo((TypeDescription)parameterTypes.get(0)) && (((TypeDescription)parameterTypes
/*  700 */         .get(1)).represents(Object.class) || ((TypeDescription)parameterTypes.get(1)).represents(String.class)) && ((TypeDescription)parameterTypes
/*  701 */         .get(2)).isAssignableFrom(bootstrapped));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*      */     private boolean isBootstrapping(List<? extends TypeDefinition> arguments) {
/*  714 */       TypeList targets = getParameters().asTypeList().asErasures();
/*  715 */       if (targets.size() < 4) {
/*  716 */         if (arguments.isEmpty())
/*  717 */           return true; 
/*  718 */         if (((TypeDescription)targets.get(targets.size() - 1)).isArray()) {
/*  719 */           for (TypeDefinition argument : arguments) {
/*  720 */             if (!argument.asErasure().isAssignableTo(((TypeDescription)targets.get(targets.size() - 1)).getComponentType())) {
/*  721 */               return false;
/*      */             }
/*      */           } 
/*  724 */           return true;
/*      */         } 
/*  726 */         return false;
/*      */       } 
/*      */       
/*  729 */       Iterator<TypeDescription> iterator = ((TypeList)targets.subList(3, targets.size())).iterator();
/*  730 */       for (TypeDefinition type : arguments) {
/*  731 */         if (!iterator.hasNext()) {
/*  732 */           return false;
/*      */         }
/*  734 */         TypeDescription target = iterator.next();
/*  735 */         if (!iterator.hasNext() && target.isArray())
/*  736 */           return true; 
/*  737 */         if (!type.asErasure().isAssignableTo(target)) {
/*  738 */           return false;
/*      */         }
/*      */       } 
/*  741 */       if (iterator.hasNext()) {
/*  742 */         return (((TypeDescription)iterator.next()).isArray() && !iterator.hasNext());
/*      */       }
/*  744 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInvokeBootstrap() {
/*  753 */       TypeDescription returnType = getReturnType().asErasure();
/*  754 */       if ((isMethod() && (!isStatic() || (
/*  755 */         !JavaType.CALL_SITE.getTypeStub().isAssignableFrom(returnType) && !JavaType.CALL_SITE.getTypeStub().isAssignableTo(returnType)))) || (
/*  756 */         isConstructor() && !JavaType.CALL_SITE.getTypeStub().isAssignableFrom(getDeclaringType().asErasure()))) {
/*  757 */         return false;
/*      */       }
/*  759 */       return isBootstrap(JavaType.METHOD_TYPE.getTypeStub());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInvokeBootstrap(List<? extends TypeDefinition> arguments) {
/*  766 */       return (isInvokeBootstrap() && isBootstrapping(arguments));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isConstantBootstrap() {
/*  773 */       return isBootstrap(TypeDescription.ForLoadedType.of(Class.class));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isConstantBootstrap(List<? extends TypeDefinition> arguments) {
/*  780 */       return (isConstantBootstrap() && isBootstrapping(arguments));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isDefaultValue() {
/*  787 */       return (!isConstructor() && 
/*  788 */         !isStatic() && 
/*  789 */         getReturnType().asErasure().isAnnotationReturnType() && 
/*  790 */         getParameters().isEmpty());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*      */     public boolean isDefaultValue(AnnotationValue<?, ?> annotationValue) {
/*  798 */       if (!isDefaultValue()) {
/*  799 */         return false;
/*      */       }
/*  801 */       TypeDescription returnType = getReturnType().asErasure();
/*  802 */       Object value = annotationValue.resolve();
/*  803 */       return ((returnType.represents(boolean.class) && value instanceof Boolean) || (returnType
/*  804 */         .represents(byte.class) && value instanceof Byte) || (returnType
/*  805 */         .represents(char.class) && value instanceof Character) || (returnType
/*  806 */         .represents(short.class) && value instanceof Short) || (returnType
/*  807 */         .represents(int.class) && value instanceof Integer) || (returnType
/*  808 */         .represents(long.class) && value instanceof Long) || (returnType
/*  809 */         .represents(float.class) && value instanceof Float) || (returnType
/*  810 */         .represents(double.class) && value instanceof Double) || (returnType
/*  811 */         .represents(String.class) && value instanceof String) || (returnType
/*  812 */         .isAssignableTo(Enum.class) && value instanceof EnumerationDescription && isEnumerationType(returnType, new EnumerationDescription[] { (EnumerationDescription)value })) || (returnType
/*  813 */         .isAssignableTo(Annotation.class) && value instanceof AnnotationDescription && isAnnotationType(returnType, new AnnotationDescription[] { (AnnotationDescription)value })) || (returnType
/*  814 */         .represents(Class.class) && value instanceof TypeDescription) || (returnType
/*  815 */         .represents(boolean[].class) && value instanceof boolean[]) || (returnType
/*  816 */         .represents(byte[].class) && value instanceof byte[]) || (returnType
/*  817 */         .represents(char[].class) && value instanceof char[]) || (returnType
/*  818 */         .represents(short[].class) && value instanceof short[]) || (returnType
/*  819 */         .represents(int[].class) && value instanceof int[]) || (returnType
/*  820 */         .represents(long[].class) && value instanceof long[]) || (returnType
/*  821 */         .represents(float[].class) && value instanceof float[]) || (returnType
/*  822 */         .represents(double[].class) && value instanceof double[]) || (returnType
/*  823 */         .represents(String[].class) && value instanceof String[]) || (returnType
/*  824 */         .isAssignableTo(Enum[].class) && value instanceof EnumerationDescription[] && isEnumerationType(returnType.getComponentType(), (EnumerationDescription[])value)) || (returnType
/*  825 */         .isAssignableTo(Annotation[].class) && value instanceof AnnotationDescription[] && isAnnotationType(returnType.getComponentType(), (AnnotationDescription[])value)) || (returnType
/*  826 */         .represents(Class[].class) && value instanceof TypeDescription[]));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isEnumerationType(TypeDescription enumerationType, EnumerationDescription... enumerationDescription) {
/*  837 */       for (EnumerationDescription anEnumerationDescription : enumerationDescription) {
/*  838 */         if (!anEnumerationDescription.getEnumerationType().equals(enumerationType)) {
/*  839 */           return false;
/*      */         }
/*      */       } 
/*  842 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isAnnotationType(TypeDescription annotationType, AnnotationDescription... annotationDescription) {
/*  853 */       for (AnnotationDescription anAnnotationDescription : annotationDescription) {
/*  854 */         if (!anAnnotationDescription.getAnnotationType().equals(annotationType)) {
/*  855 */           return false;
/*      */         }
/*      */       } 
/*  858 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeVariableSource getEnclosingSource() {
/*  866 */       return isStatic() ? TypeVariableSource.UNDEFINED : (TypeVariableSource)
/*      */         
/*  868 */         getDeclaringType().asErasure();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInferrable() {
/*  875 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public <T> T accept(TypeVariableSource.Visitor<T> visitor) {
/*  882 */       return (T)visitor.onMethod((MethodDescription.InDefinedShape)asDefined());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isGenerified() {
/*  889 */       return !getTypeVariables().isEmpty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.Token asToken(ElementMatcher<? super TypeDescription> matcher) {
/*  896 */       TypeDescription.Generic receiverType = getReceiverType();
/*  897 */       return new MethodDescription.Token(getInternalName(), 
/*  898 */           getModifiers(), (List<? extends TypeVariableToken>)
/*  899 */           getTypeVariables().asTokenList(matcher), (TypeDescription.Generic)
/*  900 */           getReturnType().accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)), (List<? extends ParameterDescription.Token>)
/*  901 */           getParameters().asTokenList(matcher), (List<? extends TypeDescription.Generic>)
/*  902 */           getExceptionTypes().accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)), (List<? extends AnnotationDescription>)
/*  903 */           getDeclaredAnnotations(), 
/*  904 */           getDefaultValue(), (receiverType == null) ? TypeDescription.Generic.UNDEFINED : (TypeDescription.Generic)receiverType
/*      */ 
/*      */           
/*  907 */           .accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.SignatureToken asSignatureToken() {
/*  914 */       return new MethodDescription.SignatureToken(getInternalName(), getReturnType().asErasure(), (List<? extends TypeDescription>)getParameters().asTypeList().asErasures());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.TypeToken asTypeToken() {
/*  921 */       return new MethodDescription.TypeToken(getReturnType().asErasure(), (List<? extends TypeDescription>)getParameters().asTypeList().asErasures());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isBridgeCompatible(MethodDescription.TypeToken typeToken) {
/*  928 */       TypeList<TypeDescription> typeList = getParameters().asTypeList().asErasures(); List<TypeDescription> bridgeTypes = typeToken.getParameterTypes();
/*  929 */       if (typeList.size() != bridgeTypes.size()) {
/*  930 */         return false;
/*      */       }
/*  932 */       for (int index = 0; index < typeList.size(); index++) {
/*  933 */         if (!((TypeDescription)typeList.get(index)).equals(bridgeTypes.get(index)) && (((TypeDescription)typeList.get(index)).isPrimitive() || ((TypeDescription)bridgeTypes.get(index)).isPrimitive())) {
/*  934 */           return false;
/*      */         }
/*      */       } 
/*  937 */       TypeDescription returnType = getReturnType().asErasure(), bridgeReturnType = typeToken.getReturnType();
/*  938 */       return (returnType.equals(bridgeReturnType) || (!returnType.isPrimitive() && !bridgeReturnType.isPrimitive()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/*  952 */       if (this == other)
/*  953 */         return true; 
/*  954 */       if (!(other instanceof MethodDescription)) {
/*  955 */         return false;
/*      */       }
/*  957 */       MethodDescription methodDescription = (MethodDescription)other;
/*  958 */       return (getInternalName().equals(methodDescription.getInternalName()) && 
/*  959 */         getDeclaringType().equals(methodDescription.getDeclaringType()) && 
/*  960 */         getReturnType().asErasure().equals(methodDescription.getReturnType().asErasure()) && 
/*  961 */         getParameters().asTypeList().asErasures().equals(methodDescription.getParameters().asTypeList().asErasures()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toGenericString() {
/*  968 */       StringBuilder stringBuilder = new StringBuilder();
/*  969 */       int modifiers = getModifiers() & 0x53F;
/*  970 */       if (modifiers != 0) {
/*  971 */         stringBuilder.append(Modifier.toString(modifiers)).append(' ');
/*      */       }
/*  973 */       if (isMethod()) {
/*  974 */         stringBuilder.append(getReturnType().getActualName()).append(' ');
/*  975 */         stringBuilder.append(getDeclaringType().asErasure().getActualName()).append('.');
/*      */       } 
/*  977 */       stringBuilder.append(getName()).append('(');
/*  978 */       boolean first = true;
/*  979 */       for (TypeDescription.Generic typeDescription : getParameters().asTypeList()) {
/*  980 */         if (!first) {
/*  981 */           stringBuilder.append(',');
/*      */         } else {
/*  983 */           first = false;
/*      */         } 
/*  985 */         stringBuilder.append(typeDescription.getActualName());
/*      */       } 
/*  987 */       stringBuilder.append(')');
/*  988 */       TypeList.Generic exceptionTypes = getExceptionTypes();
/*  989 */       if (!exceptionTypes.isEmpty()) {
/*  990 */         stringBuilder.append(" throws ");
/*  991 */         first = true;
/*  992 */         for (TypeDescription.Generic typeDescription : exceptionTypes) {
/*  993 */           if (!first) {
/*  994 */             stringBuilder.append(',');
/*      */           } else {
/*  996 */             first = false;
/*      */           } 
/*  998 */           stringBuilder.append(typeDescription.getActualName());
/*      */         } 
/*      */       } 
/* 1001 */       return stringBuilder.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1006 */       StringBuilder stringBuilder = new StringBuilder();
/* 1007 */       int modifiers = getModifiers() & 0x53F;
/* 1008 */       if (modifiers != 0) {
/* 1009 */         stringBuilder.append(Modifier.toString(modifiers)).append(' ');
/*      */       }
/* 1011 */       if (isMethod()) {
/* 1012 */         stringBuilder.append(getReturnType().asErasure().getActualName()).append(' ');
/* 1013 */         stringBuilder.append(getDeclaringType().asErasure().getActualName()).append('.');
/*      */       } 
/* 1015 */       stringBuilder.append(getName()).append('(');
/* 1016 */       boolean first = true;
/* 1017 */       for (TypeDescription typeDescription : getParameters().asTypeList().asErasures()) {
/* 1018 */         if (!first) {
/* 1019 */           stringBuilder.append(',');
/*      */         } else {
/* 1021 */           first = false;
/*      */         } 
/* 1023 */         stringBuilder.append(typeDescription.getActualName());
/*      */       } 
/* 1025 */       stringBuilder.append(')');
/* 1026 */       TypeList exceptionTypes = getExceptionTypes().asErasures();
/* 1027 */       if (!exceptionTypes.isEmpty()) {
/* 1028 */         stringBuilder.append(" throws ");
/* 1029 */         first = true;
/* 1030 */         for (TypeDescription typeDescription : exceptionTypes) {
/* 1031 */           if (!first) {
/* 1032 */             stringBuilder.append(',');
/*      */           } else {
/* 1034 */             first = false;
/*      */           } 
/* 1036 */           stringBuilder.append(typeDescription.getActualName());
/*      */         } 
/*      */       } 
/* 1039 */       return stringBuilder.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     protected String toSafeString() {
/* 1044 */       StringBuilder stringBuilder = new StringBuilder();
/* 1045 */       int modifiers = getModifiers() & 0x53F;
/* 1046 */       if (modifiers != 0) {
/* 1047 */         stringBuilder.append(Modifier.toString(modifiers)).append(' ');
/*      */       }
/* 1049 */       if (isMethod()) {
/* 1050 */         stringBuilder.append('?').append(' ');
/* 1051 */         stringBuilder.append(getDeclaringType().asErasure().getActualName()).append('.');
/*      */       } 
/* 1053 */       return stringBuilder.append(getName()).append("(?)").toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForLoadedConstructor
/*      */     extends InDefinedShape.AbstractBase.ForLoadedExecutable<Constructor<?>>
/*      */     implements ParameterDescription.ForLoadedParameter.ParameterAnnotationSource
/*      */   {
/*      */     public ForLoadedConstructor(Constructor<?> constructor) {
/* 1068 */       super(constructor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nonnull
/*      */     public TypeDescription getDeclaringType() {
/* 1076 */       return TypeDescription.ForLoadedType.of(this.executable.getDeclaringClass());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getReturnType() {
/* 1083 */       return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(void.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("parameters")
/*      */     public ParameterList<ParameterDescription.InDefinedShape> getParameters() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getExceptionTypes() {
/* 1098 */       return (TypeList.Generic)new TypeList.Generic.OfConstructorExceptionTypes(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isConstructor() {
/* 1105 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isTypeInitializer() {
/* 1112 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean represents(Method method) {
/* 1119 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean represents(Constructor<?> constructor) {
/* 1126 */       return (this.executable.equals(constructor) || equals(new ForLoadedConstructor(constructor)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 1133 */       return this.executable.getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1140 */       return this.executable.getModifiers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSynthetic() {
/* 1147 */       return this.executable.isSynthetic();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getInternalName() {
/* 1154 */       return "<init>";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getDescriptor() {
/* 1161 */       return Type.getConstructorDescriptor(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @AlwaysNull
/*      */     public AnnotationValue<?, ?> getDefaultValue() {
/* 1169 */       return AnnotationValue.UNDEFINED;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("declaredAnnotations")
/*      */     public AnnotationList getDeclaredAnnotations() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getTypeVariables() {
/* 1184 */       return TypeList.Generic.ForLoadedTypes.OfTypeVariables.of(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("parameterAnnotations")
/*      */     public Annotation[][] getParameterAnnotations() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForLoadedMethod
/*      */     extends InDefinedShape.AbstractBase.ForLoadedExecutable<Method>
/*      */     implements ParameterDescription.ForLoadedParameter.ParameterAnnotationSource
/*      */   {
/*      */     public ForLoadedMethod(Method method) {
/* 1207 */       super(method);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nonnull
/*      */     public TypeDescription getDeclaringType() {
/* 1215 */       return TypeDescription.ForLoadedType.of(this.executable.getDeclaringClass());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getReturnType() {
/* 1222 */       if (TypeDescription.AbstractBase.RAW_TYPES) {
/* 1223 */         return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.executable.getReturnType());
/*      */       }
/* 1225 */       return (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.ForLoadedReturnType(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("parameters")
/*      */     public ParameterList<ParameterDescription.InDefinedShape> getParameters() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getExceptionTypes() {
/* 1240 */       if (TypeDescription.AbstractBase.RAW_TYPES) {
/* 1241 */         return (TypeList.Generic)new TypeList.Generic.ForLoadedTypes((Type[])this.executable.getExceptionTypes());
/*      */       }
/* 1243 */       return (TypeList.Generic)new TypeList.Generic.OfMethodExceptionTypes(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isConstructor() {
/* 1250 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isTypeInitializer() {
/* 1257 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isBridge() {
/* 1264 */       return this.executable.isBridge();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean represents(Method method) {
/* 1271 */       return (this.executable.equals(method) || equals(new ForLoadedMethod(method)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean represents(Constructor<?> constructor) {
/* 1278 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 1285 */       return this.executable.getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1292 */       return this.executable.getModifiers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSynthetic() {
/* 1299 */       return this.executable.isSynthetic();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getInternalName() {
/* 1306 */       return this.executable.getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getDescriptor() {
/* 1313 */       return Type.getMethodDescriptor(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Method getLoadedMethod() {
/* 1322 */       return this.executable;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("declaredAnnotations")
/*      */     public AnnotationList getDeclaredAnnotations() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public AnnotationValue<?, ?> getDefaultValue() {
/* 1338 */       Object value = this.executable.getDefaultValue();
/* 1339 */       return (value == null) ? AnnotationValue.UNDEFINED : 
/*      */         
/* 1341 */         AnnotationDescription.ForLoadedAnnotation.asValue(value, this.executable.getReturnType());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getTypeVariables() {
/* 1348 */       if (TypeDescription.AbstractBase.RAW_TYPES) {
/* 1349 */         return (TypeList.Generic)new TypeList.Generic.Empty();
/*      */       }
/* 1351 */       return TypeList.Generic.ForLoadedTypes.OfTypeVariables.of(this.executable);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("parameterAnnotations")
/*      */     public Annotation[][] getParameterAnnotations() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Latent
/*      */     extends InDefinedShape.AbstractBase
/*      */   {
/*      */     private final TypeDescription declaringType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String internalName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeVariableToken> typeVariables;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription.Generic returnType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends ParameterDescription.Token> parameterTokens;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription.Generic> exceptionTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends AnnotationDescription> declaredAnnotations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final AnnotationValue<?, ?> defaultValue;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final TypeDescription.Generic receiverType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Latent(TypeDescription declaringType, MethodDescription.Token token) {
/* 1428 */       this(declaringType, token
/* 1429 */           .getName(), token
/* 1430 */           .getModifiers(), (List<? extends TypeVariableToken>)token
/* 1431 */           .getTypeVariableTokens(), token
/* 1432 */           .getReturnType(), (List<? extends ParameterDescription.Token>)token
/* 1433 */           .getParameterTokens(), (List<? extends TypeDescription.Generic>)token
/* 1434 */           .getExceptionTypes(), (List<? extends AnnotationDescription>)token
/* 1435 */           .getAnnotations(), token
/* 1436 */           .getDefaultValue(), token
/* 1437 */           .getReceiverType());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Latent(TypeDescription declaringType, String internalName, int modifiers, List<? extends TypeVariableToken> typeVariables, TypeDescription.Generic returnType, List<? extends ParameterDescription.Token> parameterTokens, List<? extends TypeDescription.Generic> exceptionTypes, List<? extends AnnotationDescription> declaredAnnotations, @MaybeNull AnnotationValue<?, ?> defaultValue, @MaybeNull TypeDescription.Generic receiverType) {
/* 1464 */       this.declaringType = declaringType;
/* 1465 */       this.internalName = internalName;
/* 1466 */       this.modifiers = modifiers;
/* 1467 */       this.typeVariables = typeVariables;
/* 1468 */       this.returnType = returnType;
/* 1469 */       this.parameterTokens = parameterTokens;
/* 1470 */       this.exceptionTypes = exceptionTypes;
/* 1471 */       this.declaredAnnotations = declaredAnnotations;
/* 1472 */       this.defaultValue = defaultValue;
/* 1473 */       this.receiverType = receiverType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getTypeVariables() {
/* 1480 */       return TypeList.Generic.ForDetachedTypes.attachVariables(this, this.typeVariables);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getReturnType() {
/* 1487 */       return (TypeDescription.Generic)this.returnType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 1494 */       return new ParameterList.ForTokens(this, this.parameterTokens);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getExceptionTypes() {
/* 1501 */       return TypeList.Generic.ForDetachedTypes.attach(this, this.exceptionTypes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getDeclaredAnnotations() {
/* 1508 */       return (AnnotationList)new AnnotationList.Explicit(this.declaredAnnotations);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getInternalName() {
/* 1515 */       return this.internalName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nonnull
/*      */     public TypeDescription getDeclaringType() {
/* 1523 */       return this.declaringType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1530 */       return this.modifiers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public AnnotationValue<?, ?> getDefaultValue() {
/* 1538 */       return this.defaultValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription.Generic getReceiverType() {
/* 1546 */       return (this.receiverType == null) ? super
/* 1547 */         .getReceiverType() : (TypeDescription.Generic)this.receiverType
/* 1548 */         .accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class TypeInitializer
/*      */       extends MethodDescription.InDefinedShape.AbstractBase
/*      */     {
/*      */       private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeInitializer(TypeDescription typeDescription) {
/* 1567 */         this.typeDescription = typeDescription;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic getReturnType() {
/* 1574 */         return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(void.class);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 1581 */         return new ParameterList.Empty<ParameterDescription.InDefinedShape>();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList.Generic getExceptionTypes() {
/* 1588 */         return (TypeList.Generic)new TypeList.Generic.Empty();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @AlwaysNull
/*      */       public AnnotationValue<?, ?> getDefaultValue() {
/* 1596 */         return AnnotationValue.UNDEFINED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList.Generic getTypeVariables() {
/* 1603 */         return (TypeList.Generic)new TypeList.Generic.Empty();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationList getDeclaredAnnotations() {
/* 1610 */         return (AnnotationList)new AnnotationList.Empty();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Nonnull
/*      */       public TypeDescription getDeclaringType() {
/* 1618 */         return this.typeDescription;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int getModifiers() {
/* 1625 */         return 8;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public String getInternalName() {
/* 1632 */         return "<clinit>";
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TypeSubstituting
/*      */     extends AbstractBase
/*      */     implements InGenericShape
/*      */   {
/*      */     private final TypeDescription.Generic declaringType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeSubstituting(TypeDescription.Generic declaringType, MethodDescription methodDescription, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 1667 */       this.declaringType = declaringType;
/* 1668 */       this.methodDescription = methodDescription;
/* 1669 */       this.visitor = visitor;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getReturnType() {
/* 1676 */       return (TypeDescription.Generic)this.methodDescription.getReturnType().accept(this.visitor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getTypeVariables() {
/* 1683 */       return (TypeList.Generic)this.methodDescription.getTypeVariables().accept(this.visitor).filter((ElementMatcher)ElementMatchers.ofSort(TypeDefinition.Sort.VARIABLE));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ParameterList<ParameterDescription.InGenericShape> getParameters() {
/* 1690 */       return new ParameterList.TypeSubstituting(this, (List)this.methodDescription.getParameters(), this.visitor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getExceptionTypes() {
/* 1697 */       return (TypeList.Generic)new TypeList.Generic.ForDetachedTypes((List)this.methodDescription.getExceptionTypes(), this.visitor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public AnnotationValue<?, ?> getDefaultValue() {
/* 1705 */       return this.methodDescription.getDefaultValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getReceiverType() {
/* 1712 */       TypeDescription.Generic receiverType = this.methodDescription.getReceiverType();
/* 1713 */       return (receiverType == null) ? TypeDescription.Generic.UNDEFINED : (TypeDescription.Generic)receiverType
/*      */         
/* 1715 */         .accept(this.visitor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getDeclaredAnnotations() {
/* 1722 */       return this.methodDescription.getDeclaredAnnotations();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nonnull
/*      */     public TypeDescription.Generic getDeclaringType() {
/* 1730 */       return this.declaringType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1737 */       return this.methodDescription.getModifiers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getInternalName() {
/* 1744 */       return this.methodDescription.getInternalName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.InDefinedShape asDefined() {
/* 1751 */       return (MethodDescription.InDefinedShape)this.methodDescription.asDefined();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isConstructor() {
/* 1758 */       return this.methodDescription.isConstructor();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isMethod() {
/* 1765 */       return this.methodDescription.isMethod();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isTypeInitializer() {
/* 1772 */       return this.methodDescription.isTypeInitializer();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Token
/*      */     implements ByteCodeElement.Token<Token>
/*      */   {
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeVariableToken> typeVariableTokens;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription.Generic returnType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends ParameterDescription.Token> parameterTokens;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription.Generic> exceptionTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends AnnotationDescription> annotations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final AnnotationValue<?, ?> defaultValue;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final TypeDescription.Generic receiverType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(int modifiers) {
/* 1835 */       this("<init>", modifiers, TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(void.class));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(String name, int modifiers, TypeDescription.Generic returnType) {
/* 1847 */       this(name, modifiers, returnType, Collections.emptyList());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(String name, int modifiers, TypeDescription.Generic returnType, List<? extends TypeDescription.Generic> parameterTypes) {
/* 1859 */       this(name, modifiers, 
/*      */           
/* 1861 */           Collections.emptyList(), returnType, new ParameterDescription.Token.TypeList((List)parameterTypes), 
/*      */ 
/*      */           
/* 1864 */           Collections.emptyList(), 
/* 1865 */           Collections.emptyList(), AnnotationValue.UNDEFINED, TypeDescription.Generic.UNDEFINED);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(String name, int modifiers, List<? extends TypeVariableToken> typeVariableTokens, TypeDescription.Generic returnType, List<? extends ParameterDescription.Token> parameterTokens, List<? extends TypeDescription.Generic> exceptionTypes, List<? extends AnnotationDescription> annotations, @MaybeNull AnnotationValue<?, ?> defaultValue, @MaybeNull TypeDescription.Generic receiverType) {
/* 1892 */       this.name = name;
/* 1893 */       this.modifiers = modifiers;
/* 1894 */       this.typeVariableTokens = typeVariableTokens;
/* 1895 */       this.returnType = returnType;
/* 1896 */       this.parameterTokens = parameterTokens;
/* 1897 */       this.exceptionTypes = exceptionTypes;
/* 1898 */       this.annotations = annotations;
/* 1899 */       this.defaultValue = defaultValue;
/* 1900 */       this.receiverType = receiverType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 1909 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1918 */       return this.modifiers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeElement.Token.TokenList<TypeVariableToken> getTypeVariableTokens() {
/* 1927 */       return new ByteCodeElement.Token.TokenList(this.typeVariableTokens);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getReturnType() {
/* 1936 */       return this.returnType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeElement.Token.TokenList<ParameterDescription.Token> getParameterTokens() {
/* 1945 */       return new ByteCodeElement.Token.TokenList(this.parameterTokens);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getExceptionTypes() {
/* 1954 */       return (TypeList.Generic)new TypeList.Generic.Explicit(this.exceptionTypes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getAnnotations() {
/* 1963 */       return (AnnotationList)new AnnotationList.Explicit(this.annotations);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public AnnotationValue<?, ?> getDefaultValue() {
/* 1973 */       return this.defaultValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription.Generic getReceiverType() {
/* 1983 */       return this.receiverType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 1990 */       return new Token(this.name, this.modifiers, (List<? extends TypeVariableToken>)
/*      */           
/* 1992 */           getTypeVariableTokens().accept(visitor), (TypeDescription.Generic)this.returnType
/* 1993 */           .accept(visitor), (List<? extends ParameterDescription.Token>)
/* 1994 */           getParameterTokens().accept(visitor), (List<? extends TypeDescription.Generic>)
/* 1995 */           getExceptionTypes().accept(visitor), this.annotations, this.defaultValue, (this.receiverType == null) ? TypeDescription.Generic.UNDEFINED : (TypeDescription.Generic)this.receiverType
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2000 */           .accept(visitor));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.SignatureToken asSignatureToken(TypeDescription declaringType) {
/* 2010 */       TypeDescription.Generic.Visitor.Reducing reducing = new TypeDescription.Generic.Visitor.Reducing(declaringType, this.typeVariableTokens);
/* 2011 */       List<TypeDescription> parameters = new ArrayList<TypeDescription>(this.parameterTokens.size());
/* 2012 */       for (ParameterDescription.Token parameter : this.parameterTokens) {
/* 2013 */         parameters.add(parameter.getType().accept((TypeDescription.Generic.Visitor)reducing));
/*      */       }
/* 2015 */       return new MethodDescription.SignatureToken(this.name, (TypeDescription)this.returnType.accept((TypeDescription.Generic.Visitor)reducing), parameters);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 2035 */       if (this == other)
/* 2036 */         return true; 
/* 2037 */       if (other == null || getClass() != other.getClass()) {
/* 2038 */         return false;
/*      */       }
/* 2040 */       Token token = (Token)other;
/* 2041 */       return (this.modifiers == token.modifiers && this.name
/* 2042 */         .equals(token.name) && this.typeVariableTokens
/* 2043 */         .equals(token.typeVariableTokens) && this.returnType
/* 2044 */         .equals(token.returnType) && this.parameterTokens
/* 2045 */         .equals(token.parameterTokens) && this.exceptionTypes
/* 2046 */         .equals(token.exceptionTypes) && this.annotations
/* 2047 */         .equals(token.annotations) && ((this.defaultValue != null) ? this.defaultValue
/* 2048 */         .equals(token.defaultValue) : (token.defaultValue == null)) && ((this.receiverType != null) ? this.receiverType
/* 2049 */         .equals(token.receiverType) : (token.receiverType == null)));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2054 */       return "MethodDescription.Token{name='" + this.name + '\'' + ", modifiers=" + this.modifiers + ", typeVariableTokens=" + this.typeVariableTokens + ", returnType=" + this.returnType + ", parameterTokens=" + this.parameterTokens + ", exceptionTypes=" + this.exceptionTypes + ", annotations=" + this.annotations + ", defaultValue=" + this.defaultValue + ", receiverType=" + this.receiverType + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SignatureToken
/*      */   {
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription returnType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription> parameterTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SignatureToken(String name, TypeDescription returnType, TypeDescription... parameterType) {
/* 2096 */       this(name, returnType, Arrays.asList(parameterType));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SignatureToken(String name, TypeDescription returnType, List<? extends TypeDescription> parameterTypes) {
/* 2107 */       this.name = name;
/* 2108 */       this.returnType = returnType;
/* 2109 */       this.parameterTypes = parameterTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 2118 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getReturnType() {
/* 2127 */       return this.returnType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TypeDescription> getParameterTypes() {
/* 2137 */       return (List)this.parameterTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.TypeToken asTypeToken() {
/* 2146 */       return new MethodDescription.TypeToken(this.returnType, this.parameterTypes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getDescriptor() {
/* 2155 */       StringBuilder stringBuilder = (new StringBuilder()).append('(');
/* 2156 */       for (TypeDescription typeDescription : this.parameterTypes) {
/* 2157 */         stringBuilder.append(typeDescription.getDescriptor());
/*      */       }
/* 2159 */       return stringBuilder.append(')').append(this.returnType.getDescriptor()).toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 2173 */       if (this == other)
/* 2174 */         return true; 
/* 2175 */       if (!(other instanceof SignatureToken)) {
/* 2176 */         return false;
/*      */       }
/* 2178 */       SignatureToken signatureToken = (SignatureToken)other;
/* 2179 */       return (this.name.equals(signatureToken.name) && this.returnType
/* 2180 */         .equals(signatureToken.returnType) && this.parameterTypes
/* 2181 */         .equals(signatureToken.parameterTypes));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2186 */       StringBuilder stringBuilder = (new StringBuilder()).append(this.returnType).append(' ').append(this.name).append('(');
/* 2187 */       boolean first = true;
/* 2188 */       for (TypeDescription parameterType : this.parameterTypes) {
/* 2189 */         if (first) {
/* 2190 */           first = false;
/*      */         } else {
/* 2192 */           stringBuilder.append(',');
/*      */         } 
/* 2194 */         stringBuilder.append(parameterType);
/*      */       } 
/* 2196 */       return stringBuilder.append(')').toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TypeToken
/*      */   {
/*      */     private final TypeDescription returnType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription> parameterTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeToken(TypeDescription returnType, List<? extends TypeDescription> parameterTypes) {
/* 2222 */       this.returnType = returnType;
/* 2223 */       this.parameterTypes = parameterTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getReturnType() {
/* 2232 */       return this.returnType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<TypeDescription> getParameterTypes() {
/* 2242 */       return (List)this.parameterTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 2255 */       if (this == other)
/* 2256 */         return true; 
/* 2257 */       if (!(other instanceof TypeToken)) {
/* 2258 */         return false;
/*      */       }
/* 2260 */       TypeToken typeToken = (TypeToken)other;
/* 2261 */       return (this.returnType.equals(typeToken.returnType) && this.parameterTypes.equals(typeToken.parameterTypes));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 2266 */       StringBuilder stringBuilder = (new StringBuilder()).append('(');
/* 2267 */       for (TypeDescription parameterType : this.parameterTypes) {
/* 2268 */         stringBuilder.append(parameterType.getDescriptor());
/*      */       }
/* 2270 */       return stringBuilder.append(')').append(this.returnType.getDescriptor()).toString();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\method\MethodDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */