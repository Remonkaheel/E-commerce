/*      */ package net.bytebuddy.description.method;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.AbstractList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.CachedReturnPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.description.ByteCodeElement;
/*      */ import net.bytebuddy.description.ModifierReviewable;
/*      */ import net.bytebuddy.description.NamedElement;
/*      */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.annotation.AnnotationSource;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface ParameterDescription
/*      */   extends AnnotationSource, NamedElement.WithRuntimeName, NamedElement.WithOptionalName, ModifierReviewable.ForParameterDescription, ByteCodeElement.TypeDependant<ParameterDescription.InDefinedShape, ParameterDescription.Token>
/*      */ {
/*      */   public static final String NAME_PREFIX = "arg";
/*      */   
/*      */   TypeDescription.Generic getType();
/*      */   
/*      */   MethodDescription getDeclaringMethod();
/*      */   
/*      */   int getIndex();
/*      */   
/*      */   boolean hasModifiers();
/*      */   
/*      */   int getOffset();
/*      */   
/*      */   public static interface InGenericShape
/*      */     extends ParameterDescription
/*      */   {
/*      */     MethodDescription.InGenericShape getDeclaringMethod();
/*      */   }
/*      */   
/*      */   public static interface InDefinedShape
/*      */     extends ParameterDescription
/*      */   {
/*      */     MethodDescription.InDefinedShape getDeclaringMethod();
/*      */     
/*      */     public static abstract class AbstractBase
/*      */       extends ParameterDescription.AbstractBase
/*      */       implements InDefinedShape
/*      */     {
/*      */       public ParameterDescription.InDefinedShape asDefined() {
/*  127 */         return this;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class AbstractBase
/*      */     extends ModifierReviewable.AbstractBase
/*      */     implements ParameterDescription
/*      */   {
/*      */     public String getName() {
/*  141 */       return "arg".concat(String.valueOf(getIndex()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getInternalName() {
/*  148 */       return getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getActualName() {
/*  155 */       return isNamed() ? 
/*  156 */         getName() : "";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/*  164 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("offset")
/*      */     public int getOffset() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ParameterDescription.Token asToken(ElementMatcher<? super TypeDescription> matcher) {
/*  186 */       return new ParameterDescription.Token((TypeDescription.Generic)getType().accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForDetachment(matcher)), (List<? extends AnnotationDescription>)
/*  187 */           getDeclaredAnnotations(), 
/*  188 */           isNamed() ? 
/*  189 */           getName() : ParameterDescription.Token.NO_NAME, 
/*      */           
/*  191 */           hasModifiers() ? 
/*  192 */           Integer.valueOf(getModifiers()) : ParameterDescription.Token.NO_MODIFIERS);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/*  204 */       if (this == other)
/*  205 */         return true; 
/*  206 */       if (!(other instanceof ParameterDescription)) {
/*  207 */         return false;
/*      */       }
/*  209 */       ParameterDescription parameterDescription = (ParameterDescription)other;
/*  210 */       return (getDeclaringMethod().equals(parameterDescription.getDeclaringMethod()) && getIndex() == parameterDescription.getIndex());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  215 */       StringBuilder stringBuilder = new StringBuilder(Modifier.toString(getModifiers()));
/*  216 */       if (getModifiers() != 0) {
/*  217 */         stringBuilder.append(' ');
/*      */       }
/*  219 */       stringBuilder.append(isVarArgs() ? 
/*  220 */           getType().asErasure().getName().replaceFirst("\\[]$", "...") : 
/*  221 */           getType().asErasure().getName());
/*  222 */       return stringBuilder.append(' ').append(getName()).toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class ForLoadedParameter<T extends AccessibleObject>
/*      */     extends InDefinedShape.AbstractBase
/*      */   {
/*  236 */     private static final Parameter PARAMETER = doPrivileged(JavaDispatcher.of(Parameter.class)); static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final T executable;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final int index;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final ParameterAnnotationSource parameterAnnotationSource;
/*      */ 
/*      */ 
/*      */     
/*      */     private static final boolean ACCESS_CONTROLLER;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForLoadedParameter(T executable, int index, ParameterAnnotationSource parameterAnnotationSource) {
/*  261 */       this.executable = executable;
/*  262 */       this.index = index;
/*  263 */       this.parameterAnnotationSource = parameterAnnotationSource;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  275 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  282 */       return PARAMETER.getName(ParameterList.ForLoadedExecutable.EXECUTABLE.getParameters(this.executable)[this.index]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIndex() {
/*  289 */       return this.index;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNamed() {
/*  296 */       return PARAMETER.isNamePresent(ParameterList.ForLoadedExecutable.EXECUTABLE.getParameters(this.executable)[this.index]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/*  303 */       return PARAMETER.getModifiers(ParameterList.ForLoadedExecutable.EXECUTABLE.getParameters(this.executable)[this.index]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasModifiers() {
/*  312 */       return (isNamed() || getModifiers() != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface ParameterAnnotationSource
/*      */     {
/*      */       Annotation[][] getParameterAnnotations();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class ForLoadedConstructor
/*      */         implements ParameterAnnotationSource
/*      */       {
/*      */         private final Constructor<?> constructor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ForLoadedConstructor(Constructor<?> constructor) {
/*  344 */           this.constructor = constructor;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Annotation[][] getParameterAnnotations() {
/*  351 */           return this.constructor.getParameterAnnotations();
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.constructor.equals(((ForLoadedConstructor)param3Object).constructor))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.constructor.hashCode();
/*      */         }
/*      */       }
/*      */       
/*      */       @Enhance
/*      */       public static class ForLoadedMethod
/*      */         implements ParameterAnnotationSource
/*      */       {
/*      */         private final Method method;
/*      */         
/*      */         public ForLoadedMethod(Method method) {
/*  372 */           this.method = method;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Annotation[][] getParameterAnnotations() {
/*  379 */           return this.method.getParameterAnnotations();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.method.equals(((ForLoadedMethod)param3Object).method))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.method.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Proxied("java.lang.reflect.Parameter")
/*      */     protected static interface Parameter
/*      */     {
/*      */       @Proxied("getModifiers")
/*      */       int getModifiers(Object param2Object);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Proxied("isNamePresent")
/*      */       boolean isNamePresent(Object param2Object);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Proxied("getName")
/*      */       String getName(Object param2Object);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class OfMethod
/*      */       extends ForLoadedParameter<Method>
/*      */     {
/*      */       protected OfMethod(Method method, int index, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/*  428 */         super(method, index, parameterAnnotationSource);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"BC_UNCONFIRMED_CAST"}, justification = "The implicit field type casting is not understood by Findbugs.")
/*      */       public MethodDescription.InDefinedShape getDeclaringMethod() {
/*  436 */         return new MethodDescription.ForLoadedMethod(this.executable);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"BC_UNCONFIRMED_CAST"}, justification = "The implicit field type casting is not understood by Findbugs.")
/*      */       public TypeDescription.Generic getType() {
/*  444 */         if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  445 */           return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.executable.getParameterTypes()[this.index]);
/*      */         }
/*  447 */         return (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.OfMethodParameter(this.executable, this.index, this.executable.getParameterTypes());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"BC_UNCONFIRMED_CAST"}, justification = "The implicit field type casting is not understood by Findbugs.")
/*      */       public AnnotationList getDeclaredAnnotations() {
/*  455 */         return (AnnotationList)new AnnotationList.ForLoadedAnnotations(this.parameterAnnotationSource.getParameterAnnotations()[this.index]);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class OfConstructor
/*      */       extends ForLoadedParameter<Constructor<?>>
/*      */     {
/*      */       protected OfConstructor(Constructor<?> constructor, int index, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/*  472 */         super(constructor, index, parameterAnnotationSource);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"BC_UNCONFIRMED_CAST"}, justification = "The implicit field type casting is not understood by Findbugs.")
/*      */       public MethodDescription.InDefinedShape getDeclaringMethod() {
/*  480 */         return new MethodDescription.ForLoadedConstructor(this.executable);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"BC_UNCONFIRMED_CAST"}, justification = "The implicit field type casting is not understood by Findbugs.")
/*      */       public TypeDescription.Generic getType() {
/*  488 */         if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  489 */           return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.executable.getParameterTypes()[this.index]);
/*      */         }
/*  491 */         return (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.OfConstructorParameter(this.executable, this.index, this.executable.getParameterTypes());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"BC_UNCONFIRMED_CAST"}, justification = "The implicit field type casting is not understood by Findbugs")
/*      */       public AnnotationList getDeclaredAnnotations() {
/*  499 */         Annotation[][] annotation = this.parameterAnnotationSource.getParameterAnnotations();
/*  500 */         MethodDescription.InDefinedShape declaringMethod = getDeclaringMethod();
/*  501 */         if (annotation.length != declaringMethod.getParameters().size() && declaringMethod.getDeclaringType().isInnerClass()) {
/*  502 */           return (this.index == 0) ? (AnnotationList)new AnnotationList.Empty() : (AnnotationList)new AnnotationList.ForLoadedAnnotations(annotation[this.index - 1]);
/*      */         }
/*      */ 
/*      */         
/*  506 */         return (AnnotationList)new AnnotationList.ForLoadedAnnotations(annotation[this.index]);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class OfLegacyVmMethod
/*      */       extends ParameterDescription.InDefinedShape.AbstractBase
/*      */     {
/*      */       private final Method method;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final Class<?>[] parameterType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected OfLegacyVmMethod(Method method, int index, Class<?>[] parameterType, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/*  546 */         this.method = method;
/*  547 */         this.index = index;
/*  548 */         this.parameterType = parameterType;
/*  549 */         this.parameterAnnotationSource = parameterAnnotationSource;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic getType() {
/*  556 */         if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  557 */           return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.parameterType[this.index]);
/*      */         }
/*  559 */         return (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.OfMethodParameter(this.method, this.index, this.parameterType);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodDescription.InDefinedShape getDeclaringMethod() {
/*  566 */         return new MethodDescription.ForLoadedMethod(this.method);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int getIndex() {
/*  573 */         return this.index;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isNamed() {
/*  580 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean hasModifiers() {
/*  587 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationList getDeclaredAnnotations() {
/*  594 */         return (AnnotationList)new AnnotationList.ForLoadedAnnotations(this.parameterAnnotationSource.getParameterAnnotations()[this.index]);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class OfLegacyVmConstructor
/*      */       extends ParameterDescription.InDefinedShape.AbstractBase
/*      */     {
/*      */       private final Constructor<?> constructor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final Class<?>[] parameterType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected OfLegacyVmConstructor(Constructor<?> constructor, int index, Class<?>[] parameterType, ParameterDescription.ForLoadedParameter.ParameterAnnotationSource parameterAnnotationSource) {
/*  633 */         this.constructor = constructor;
/*  634 */         this.index = index;
/*  635 */         this.parameterType = parameterType;
/*  636 */         this.parameterAnnotationSource = parameterAnnotationSource;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription.Generic getType() {
/*  643 */         if (TypeDescription.AbstractBase.RAW_TYPES) {
/*  644 */           return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(this.parameterType[this.index]);
/*      */         }
/*  646 */         return (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.OfConstructorParameter(this.constructor, this.index, this.parameterType);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodDescription.InDefinedShape getDeclaringMethod() {
/*  653 */         return new MethodDescription.ForLoadedConstructor(this.constructor);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int getIndex() {
/*  660 */         return this.index;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isNamed() {
/*  667 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean hasModifiers() {
/*  674 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public AnnotationList getDeclaredAnnotations() {
/*  681 */         MethodDescription.InDefinedShape declaringMethod = getDeclaringMethod();
/*  682 */         Annotation[][] parameterAnnotation = this.parameterAnnotationSource.getParameterAnnotations();
/*  683 */         if (parameterAnnotation.length != declaringMethod.getParameters().size() && declaringMethod.getDeclaringType().isInnerClass()) {
/*  684 */           return (this.index == 0) ? (AnnotationList)new AnnotationList.Empty() : (AnnotationList)new AnnotationList.ForLoadedAnnotations(parameterAnnotation[this.index - 1]);
/*      */         }
/*      */ 
/*      */         
/*  688 */         return (AnnotationList)new AnnotationList.ForLoadedAnnotations(parameterAnnotation[this.index]);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Latent
/*      */     extends InDefinedShape.AbstractBase
/*      */   {
/*      */     private final MethodDescription.InDefinedShape declaringMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription.Generic parameterType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends AnnotationDescription> declaredAnnotations;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final Integer modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Latent(MethodDescription.InDefinedShape declaringMethod, ParameterDescription.Token token, int index, int offset) {
/*  745 */       this(declaringMethod, token
/*  746 */           .getType(), (List<? extends AnnotationDescription>)token
/*  747 */           .getAnnotations(), token
/*  748 */           .getName(), token
/*  749 */           .getModifiers(), index, offset);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Latent(MethodDescription.InDefinedShape declaringMethod, TypeDescription.Generic parameterType, int index, int offset) {
/*  766 */       this(declaringMethod, parameterType, 
/*      */           
/*  768 */           Collections.emptyList(), ParameterDescription.Token.NO_NAME, ParameterDescription.Token.NO_MODIFIERS, index, offset);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Latent(MethodDescription.InDefinedShape declaringMethod, TypeDescription.Generic parameterType, List<? extends AnnotationDescription> declaredAnnotations, @MaybeNull String name, @MaybeNull Integer modifiers, int index, int offset) {
/*  793 */       this.declaringMethod = declaringMethod;
/*  794 */       this.parameterType = parameterType;
/*  795 */       this.declaredAnnotations = declaredAnnotations;
/*  796 */       this.name = name;
/*  797 */       this.modifiers = modifiers;
/*  798 */       this.index = index;
/*  799 */       this.offset = offset;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getType() {
/*  806 */       return (TypeDescription.Generic)this.parameterType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.InDefinedShape getDeclaringMethod() {
/*  813 */       return this.declaringMethod;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIndex() {
/*  820 */       return this.index;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getOffset() {
/*  827 */       return this.offset;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNamed() {
/*  834 */       return (this.name != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasModifiers() {
/*  841 */       return (this.modifiers != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  848 */       return (this.name == null) ? super
/*  849 */         .getName() : this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/*  857 */       return (this.modifiers == null) ? super
/*  858 */         .getModifiers() : this.modifiers
/*  859 */         .intValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getDeclaredAnnotations() {
/*  866 */       return (AnnotationList)new AnnotationList.Explicit(this.declaredAnnotations);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TypeSubstituting
/*      */     extends AbstractBase
/*      */     implements InGenericShape
/*      */   {
/*      */     private final MethodDescription.InGenericShape declaringMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ParameterDescription parameterDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeSubstituting(MethodDescription.InGenericShape declaringMethod, ParameterDescription parameterDescription, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  905 */       this.declaringMethod = declaringMethod;
/*  906 */       this.parameterDescription = parameterDescription;
/*  907 */       this.visitor = visitor;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getType() {
/*  914 */       return (TypeDescription.Generic)this.parameterDescription.getType().accept(this.visitor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodDescription.InGenericShape getDeclaringMethod() {
/*  921 */       return this.declaringMethod;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIndex() {
/*  928 */       return this.parameterDescription.getIndex();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNamed() {
/*  935 */       return this.parameterDescription.isNamed();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasModifiers() {
/*  942 */       return this.parameterDescription.hasModifiers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getOffset() {
/*  949 */       return this.parameterDescription.getOffset();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  956 */       return this.parameterDescription.getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/*  963 */       return this.parameterDescription.getModifiers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getDeclaredAnnotations() {
/*  970 */       return this.parameterDescription.getDeclaredAnnotations();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ParameterDescription.InDefinedShape asDefined() {
/*  977 */       return (ParameterDescription.InDefinedShape)this.parameterDescription.asDefined();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Token
/*      */     implements ByteCodeElement.Token<Token>
/*      */   {
/*      */     @AlwaysNull
/*  990 */     public static final String NO_NAME = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @AlwaysNull
/*  996 */     public static final Integer NO_MODIFIERS = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription.Generic type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends AnnotationDescription> annotations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final Integer modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(TypeDescription.Generic type) {
/* 1027 */       this(type, Collections.emptyList());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(TypeDescription.Generic type, List<? extends AnnotationDescription> annotations) {
/* 1037 */       this(type, annotations, NO_NAME, NO_MODIFIERS);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(TypeDescription.Generic type, @MaybeNull String name, @MaybeNull Integer modifiers) {
/* 1048 */       this(type, Collections.emptyList(), name, modifiers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token(TypeDescription.Generic type, List<? extends AnnotationDescription> annotations, @MaybeNull String name, @MaybeNull Integer modifiers) {
/* 1063 */       this.type = type;
/* 1064 */       this.annotations = annotations;
/* 1065 */       this.name = name;
/* 1066 */       this.modifiers = modifiers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription.Generic getType() {
/* 1075 */       return this.type;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getAnnotations() {
/* 1084 */       return (AnnotationList)new AnnotationList.Explicit(this.annotations);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public String getName() {
/* 1094 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public Integer getModifiers() {
/* 1104 */       return this.modifiers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Token accept(TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 1111 */       return new Token((TypeDescription.Generic)this.type.accept(visitor), this.annotations, this.name, this.modifiers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance("hashCode")
/*      */     public int hashCode() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object other) {
/* 1129 */       if (this == other)
/* 1130 */         return true; 
/* 1131 */       if (!(other instanceof Token)) {
/* 1132 */         return false;
/*      */       }
/* 1134 */       Token token = (Token)other;
/* 1135 */       return (this.type.equals(token.type) && this.annotations
/* 1136 */         .equals(token.annotations) && ((this.name != null) ? this.name
/* 1137 */         .equals(token.name) : (token.name == null)) && ((this.modifiers != null) ? this.modifiers
/* 1138 */         .equals(token.modifiers) : (token.modifiers == null)));
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1143 */       return "ParameterDescription.Token{type=" + this.type + ", annotations=" + this.annotations + ", name='" + this.name + '\'' + ", modifiers=" + this.modifiers + '}';
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class TypeList
/*      */       extends AbstractList<Token>
/*      */     {
/*      */       private final List<? extends TypeDefinition> typeDescriptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeList(List<? extends TypeDefinition> typeDescriptions) {
/* 1167 */         this.typeDescriptions = typeDescriptions;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ParameterDescription.Token get(int index) {
/* 1174 */         return new ParameterDescription.Token(((TypeDefinition)this.typeDescriptions.get(index)).asGenericType());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int size() {
/* 1181 */         return this.typeDescriptions.size();
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\method\ParameterDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */