/*     */ package net.bytebuddy.description.method;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.FilterableList;
/*     */ import net.bytebuddy.utility.ConstructorComparator;
/*     */ import net.bytebuddy.utility.GraalImageCode;
/*     */ import net.bytebuddy.utility.MethodComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MethodList<T extends MethodDescription>
/*     */   extends FilterableList<T, MethodList<T>>
/*     */ {
/*     */   ByteCodeElement.Token.TokenList<MethodDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*     */   
/*     */   List<MethodDescription.SignatureToken> asSignatureTokenList();
/*     */   
/*     */   List<MethodDescription.SignatureToken> asSignatureTokenList(ElementMatcher<? super TypeDescription> paramElementMatcher, TypeDescription paramTypeDescription);
/*     */   
/*     */   MethodList<MethodDescription.InDefinedShape> asDefined();
/*     */   
/*     */   public static abstract class AbstractBase<S extends MethodDescription>
/*     */     extends FilterableList.AbstractBase<S, MethodList<S>>
/*     */     implements MethodList<S>
/*     */   {
/*     */     protected MethodList<S> wrap(List<S> values) {
/*  81 */       return new MethodList.Explicit<S>(values);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteCodeElement.Token.TokenList<MethodDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/*  88 */       List<MethodDescription.Token> tokens = new ArrayList<MethodDescription.Token>(size());
/*  89 */       for (MethodDescription methodDescription : this) {
/*  90 */         tokens.add(methodDescription.asToken(matcher));
/*     */       }
/*  92 */       return new ByteCodeElement.Token.TokenList(tokens);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MethodDescription.SignatureToken> asSignatureTokenList() {
/*  99 */       List<MethodDescription.SignatureToken> tokens = new ArrayList<MethodDescription.SignatureToken>(size());
/* 100 */       for (MethodDescription methodDescription : this) {
/* 101 */         tokens.add(methodDescription.asSignatureToken());
/*     */       }
/* 103 */       return tokens;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MethodDescription.SignatureToken> asSignatureTokenList(ElementMatcher<? super TypeDescription> matcher, TypeDescription typeDescription) {
/* 110 */       List<MethodDescription.SignatureToken> tokens = new ArrayList<MethodDescription.SignatureToken>(size());
/* 111 */       for (MethodDescription methodDescription : this) {
/* 112 */         tokens.add(((MethodDescription.Token)methodDescription.asToken(matcher)).asSignatureToken(typeDescription));
/*     */       }
/* 114 */       return tokens;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodList<MethodDescription.InDefinedShape> asDefined() {
/* 121 */       List<MethodDescription.InDefinedShape> declaredForms = new ArrayList<MethodDescription.InDefinedShape>(size());
/* 122 */       for (MethodDescription methodDescription : this) {
/* 123 */         declaredForms.add(methodDescription.asDefined());
/*     */       }
/* 125 */       return new MethodList.Explicit<MethodDescription.InDefinedShape>(declaredForms);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForLoadedMethods
/*     */     extends AbstractBase<MethodDescription.InDefinedShape>
/*     */   {
/*     */     private final List<? extends Method> methods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends Constructor<?>> constructors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedMethods(Class<?> type) {
/* 151 */       this((Constructor<?>[])GraalImageCode.getCurrent().sorted((Object[])type.getDeclaredConstructors(), (Comparator)ConstructorComparator.INSTANCE), 
/* 152 */           (Method[])GraalImageCode.getCurrent().sorted((Object[])type.getDeclaredMethods(), (Comparator)MethodComparator.INSTANCE));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedMethods(Constructor<?>[] constructor, Method[] method) {
/* 163 */       this(Arrays.asList(constructor), Arrays.asList(method));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForLoadedMethods(List<? extends Constructor<?>> constructors, List<? extends Method> methods) {
/* 174 */       this.constructors = constructors;
/* 175 */       this.methods = methods;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodDescription.InDefinedShape get(int index) {
/* 182 */       return (index < this.constructors.size()) ? new MethodDescription.ForLoadedConstructor(this.constructors
/* 183 */           .get(index)) : new MethodDescription.ForLoadedMethod(this.methods
/* 184 */           .get(index - this.constructors.size()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 192 */       return this.constructors.size() + this.methods.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Explicit<S extends MethodDescription>
/*     */     extends AbstractBase<S>
/*     */   {
/*     */     private final List<? extends S> methodDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(S... methodDescription) {
/* 215 */       this(Arrays.asList(methodDescription));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Explicit(List<? extends S> methodDescriptions) {
/* 224 */       this.methodDescriptions = methodDescriptions;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S get(int index) {
/* 231 */       return this.methodDescriptions.get(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 238 */       return this.methodDescriptions.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForTokens
/*     */     extends AbstractBase<MethodDescription.InDefinedShape>
/*     */   {
/*     */     private final TypeDescription declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends MethodDescription.Token> tokens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(TypeDescription declaringType, MethodDescription.Token... token) {
/* 264 */       this(declaringType, Arrays.asList(token));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForTokens(TypeDescription declaringType, List<? extends MethodDescription.Token> tokens) {
/* 274 */       this.declaringType = declaringType;
/* 275 */       this.tokens = tokens;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodDescription.InDefinedShape get(int index) {
/* 282 */       return new MethodDescription.Latent(this.declaringType, this.tokens.get(index));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 289 */       return this.tokens.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeSubstituting
/*     */     extends AbstractBase<MethodDescription.InGenericShape>
/*     */   {
/*     */     protected final TypeDescription.Generic declaringType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final List<? extends MethodDescription> methodDescriptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSubstituting(TypeDescription.Generic declaringType, List<? extends MethodDescription> methodDescriptions, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 323 */       this.declaringType = declaringType;
/* 324 */       this.methodDescriptions = methodDescriptions;
/* 325 */       this.visitor = visitor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodDescription.InGenericShape get(int index) {
/* 332 */       return new MethodDescription.TypeSubstituting(this.declaringType, this.methodDescriptions.get(index), this.visitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 339 */       return this.methodDescriptions.size();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Empty<S extends MethodDescription>
/*     */     extends FilterableList.Empty<S, MethodList<S>>
/*     */     implements MethodList<S>
/*     */   {
/*     */     public ByteCodeElement.Token.TokenList<MethodDescription.Token> asTokenList(ElementMatcher<? super TypeDescription> matcher) {
/* 354 */       return new ByteCodeElement.Token.TokenList((ByteCodeElement.Token[])new MethodDescription.Token[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MethodDescription.SignatureToken> asSignatureTokenList() {
/* 361 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MethodDescription.SignatureToken> asSignatureTokenList(ElementMatcher<? super TypeDescription> matcher, TypeDescription typeDescription) {
/* 368 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodList<MethodDescription.InDefinedShape> asDefined() {
/* 376 */       return (MethodList)this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\method\MethodList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */