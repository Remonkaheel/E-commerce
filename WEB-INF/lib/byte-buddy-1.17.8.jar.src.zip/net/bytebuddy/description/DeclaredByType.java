package net.bytebuddy.description;

import javax.annotation.Nonnull;
import net.bytebuddy.description.type.TypeDefinition;
import net.bytebuddy.utility.nullability.MaybeNull;

public interface DeclaredByType {
  @MaybeNull
  TypeDefinition getDeclaringType();
  
  public static interface WithMandatoryDeclaration extends DeclaredByType {
    @Nonnull
    TypeDefinition getDeclaringType();
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\description\DeclaredByType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */