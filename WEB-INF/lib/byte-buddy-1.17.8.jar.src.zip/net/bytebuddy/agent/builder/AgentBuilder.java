/*       */ package net.bytebuddy.agent.builder;
/*       */ 
/*       */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*       */ import java.io.File;
/*       */ import java.io.IOException;
/*       */ import java.io.NotSerializableException;
/*       */ import java.io.ObjectInputStream;
/*       */ import java.io.ObjectOutputStream;
/*       */ import java.io.PrintStream;
/*       */ import java.io.Serializable;
/*       */ import java.lang.instrument.ClassDefinition;
/*       */ import java.lang.instrument.ClassFileTransformer;
/*       */ import java.lang.instrument.IllegalClassFormatException;
/*       */ import java.lang.instrument.Instrumentation;
/*       */ import java.lang.instrument.UnmodifiableClassException;
/*       */ import java.lang.ref.WeakReference;
/*       */ import java.lang.reflect.Constructor;
/*       */ import java.lang.reflect.InvocationTargetException;
/*       */ import java.lang.reflect.Type;
/*       */ import java.net.URLClassLoader;
/*       */ import java.security.AccessControlContext;
/*       */ import java.security.AccessController;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.security.ProtectionDomain;
/*       */ import java.util.AbstractSet;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Arrays;
/*       */ import java.util.Collection;
/*       */ import java.util.Collections;
/*       */ import java.util.HashMap;
/*       */ import java.util.HashSet;
/*       */ import java.util.Iterator;
/*       */ import java.util.LinkedHashMap;
/*       */ import java.util.LinkedHashSet;
/*       */ import java.util.List;
/*       */ import java.util.Map;
/*       */ import java.util.NoSuchElementException;
/*       */ import java.util.Random;
/*       */ import java.util.Set;
/*       */ import java.util.concurrent.Callable;
/*       */ import java.util.concurrent.ConcurrentHashMap;
/*       */ import java.util.concurrent.ConcurrentMap;
/*       */ import java.util.concurrent.ExecutionException;
/*       */ import java.util.concurrent.ExecutorService;
/*       */ import java.util.concurrent.Future;
/*       */ import java.util.concurrent.ScheduledExecutorService;
/*       */ import java.util.concurrent.TimeUnit;
/*       */ import java.util.concurrent.atomic.AtomicBoolean;
/*       */ import java.util.concurrent.atomic.AtomicInteger;
/*       */ import java.util.concurrent.locks.Lock;
/*       */ import java.util.concurrent.locks.ReentrantLock;
/*       */ import net.bytebuddy.ByteBuddy;
/*       */ import net.bytebuddy.ClassFileVersion;
/*       */ import net.bytebuddy.asm.Advice;
/*       */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*       */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*       */ import net.bytebuddy.build.EntryPoint;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*       */ import net.bytebuddy.build.Plugin;
/*       */ import net.bytebuddy.build.SafeVarargsPlugin.Enhance;
/*       */ import net.bytebuddy.description.field.FieldDescription;
/*       */ import net.bytebuddy.description.method.MethodDescription;
/*       */ import net.bytebuddy.description.method.MethodList;
/*       */ import net.bytebuddy.description.method.ParameterDescription;
/*       */ import net.bytebuddy.description.modifier.FieldManifestation;
/*       */ import net.bytebuddy.description.modifier.MethodManifestation;
/*       */ import net.bytebuddy.description.modifier.ModifierContributor;
/*       */ import net.bytebuddy.description.modifier.Ownership;
/*       */ import net.bytebuddy.description.modifier.TypeManifestation;
/*       */ import net.bytebuddy.description.modifier.Visibility;
/*       */ import net.bytebuddy.description.type.PackageDescription;
/*       */ import net.bytebuddy.description.type.TypeDefinition;
/*       */ import net.bytebuddy.description.type.TypeDescription;
/*       */ import net.bytebuddy.dynamic.ClassFileLocator;
/*       */ import net.bytebuddy.dynamic.DynamicType;
/*       */ import net.bytebuddy.dynamic.NexusAccessor;
/*       */ import net.bytebuddy.dynamic.TypeResolutionStrategy;
/*       */ import net.bytebuddy.dynamic.VisibilityBridgeStrategy;
/*       */ import net.bytebuddy.dynamic.loading.ClassInjector;
/*       */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*       */ import net.bytebuddy.dynamic.loading.ClassReloadingStrategy;
/*       */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*       */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*       */ import net.bytebuddy.dynamic.scaffold.inline.MethodNameTransformer;
/*       */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*       */ import net.bytebuddy.implementation.ExceptionMethod;
/*       */ import net.bytebuddy.implementation.Implementation;
/*       */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*       */ import net.bytebuddy.implementation.MethodCall;
/*       */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*       */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*       */ import net.bytebuddy.implementation.bytecode.Duplication;
/*       */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*       */ import net.bytebuddy.implementation.bytecode.TypeCreation;
/*       */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*       */ import net.bytebuddy.implementation.bytecode.assign.TypeCasting;
/*       */ import net.bytebuddy.implementation.bytecode.collection.ArrayFactory;
/*       */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*       */ import net.bytebuddy.implementation.bytecode.constant.IntegerConstant;
/*       */ import net.bytebuddy.implementation.bytecode.constant.TextConstant;
/*       */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*       */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*       */ import net.bytebuddy.implementation.bytecode.member.MethodReturn;
/*       */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*       */ import net.bytebuddy.jar.asm.ConstantDynamic;
/*       */ import net.bytebuddy.jar.asm.Handle;
/*       */ import net.bytebuddy.jar.asm.Label;
/*       */ import net.bytebuddy.jar.asm.MethodVisitor;
/*       */ import net.bytebuddy.jar.asm.Opcodes;
/*       */ import net.bytebuddy.jar.asm.Type;
/*       */ import net.bytebuddy.matcher.ElementMatcher;
/*       */ import net.bytebuddy.matcher.ElementMatchers;
/*       */ import net.bytebuddy.matcher.LatentMatcher;
/*       */ import net.bytebuddy.pool.TypePool;
/*       */ import net.bytebuddy.utility.CompoundList;
/*       */ import net.bytebuddy.utility.JavaConstant;
/*       */ import net.bytebuddy.utility.JavaModule;
/*       */ import net.bytebuddy.utility.JavaType;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Defaults;
/*       */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*       */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*       */ import net.bytebuddy.utility.nullability.MaybeNull;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ public interface AgentBuilder
/*       */ {
/*       */   AgentBuilder with(ByteBuddy paramByteBuddy);
/*       */   
/*       */   AgentBuilder with(Listener paramListener);
/*       */   
/*       */   AgentBuilder with(CircularityLock paramCircularityLock);
/*       */   
/*       */   AgentBuilder with(PoolStrategy paramPoolStrategy);
/*       */   
/*       */   AgentBuilder with(LocationStrategy paramLocationStrategy);
/*       */   
/*       */   AgentBuilder with(ClassFileLocator paramClassFileLocator);
/*       */   
/*       */   AgentBuilder with(TypeStrategy paramTypeStrategy);
/*       */   
/*       */   AgentBuilder with(InitializationStrategy paramInitializationStrategy);
/*       */   
/*       */   RedefinitionListenable.WithoutBatchStrategy with(RedefinitionStrategy paramRedefinitionStrategy);
/*       */   
/*       */   AgentBuilder with(LambdaInstrumentationStrategy paramLambdaInstrumentationStrategy);
/*       */   
/*       */   AgentBuilder with(DescriptionStrategy paramDescriptionStrategy);
/*       */   
/*       */   AgentBuilder with(FallbackStrategy paramFallbackStrategy);
/*       */   
/*       */   AgentBuilder with(ClassFileBufferStrategy paramClassFileBufferStrategy);
/*       */   
/*       */   AgentBuilder with(InstallationListener paramInstallationListener);
/*       */   
/*       */   AgentBuilder with(InjectionStrategy paramInjectionStrategy);
/*       */   
/*       */   AgentBuilder with(TransformerDecorator paramTransformerDecorator);
/*       */   
/*       */   AgentBuilder enableNativeMethodPrefix(String paramString);
/*       */   
/*       */   AgentBuilder disableNativeMethodPrefix();
/*       */   
/*       */   AgentBuilder disableClassFormatChanges();
/*       */   
/*       */   AgentBuilder warmUp(Class<?>... paramVarArgs);
/*       */   
/*       */   AgentBuilder warmUp(Collection<Class<?>> paramCollection);
/*       */   
/*       */   AgentBuilder assureReadEdgeTo(Instrumentation paramInstrumentation, Class<?>... paramVarArgs);
/*       */   
/*       */   AgentBuilder assureReadEdgeTo(Instrumentation paramInstrumentation, JavaModule... paramVarArgs);
/*       */   
/*       */   AgentBuilder assureReadEdgeTo(Instrumentation paramInstrumentation, Collection<? extends JavaModule> paramCollection);
/*       */   
/*       */   AgentBuilder assureReadEdgeFromAndTo(Instrumentation paramInstrumentation, Class<?>... paramVarArgs);
/*       */   
/*       */   AgentBuilder assureReadEdgeFromAndTo(Instrumentation paramInstrumentation, JavaModule... paramVarArgs);
/*       */   
/*       */   AgentBuilder assureReadEdgeFromAndTo(Instrumentation paramInstrumentation, Collection<? extends JavaModule> paramCollection);
/*       */   
/*       */   Identified.Narrowable type(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*       */   
/*       */   Identified.Narrowable type(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1);
/*       */   
/*       */   Identified.Narrowable type(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1, ElementMatcher<? super JavaModule> paramElementMatcher2);
/*       */   
/*       */   Identified.Narrowable type(RawMatcher paramRawMatcher);
/*       */   
/*       */   Ignored ignore(ElementMatcher<? super TypeDescription> paramElementMatcher);
/*       */   
/*       */   Ignored ignore(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1);
/*       */   
/*       */   Ignored ignore(ElementMatcher<? super TypeDescription> paramElementMatcher, ElementMatcher<? super ClassLoader> paramElementMatcher1, ElementMatcher<? super JavaModule> paramElementMatcher2);
/*       */   
/*       */   Ignored ignore(RawMatcher paramRawMatcher);
/*       */   
/*       */   ClassFileTransformer makeRaw();
/*       */   
/*       */   ResettableClassFileTransformer installOn(Instrumentation paramInstrumentation);
/*       */   
/*       */   ResettableClassFileTransformer installOnByteBuddyAgent();
/*       */   
/*       */   ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer);
/*       */   
/*       */   ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, RawMatcher paramRawMatcher);
/*       */   
/*       */   ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, PatchMode paramPatchMode);
/*       */   
/*       */   ResettableClassFileTransformer patchOn(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, RawMatcher paramRawMatcher, PatchMode paramPatchMode);
/*       */   
/*       */   ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer paramResettableClassFileTransformer);
/*       */   
/*       */   ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer paramResettableClassFileTransformer, PatchMode paramPatchMode);
/*       */   
/*       */   public static interface Narrowable
/*       */     extends Matchable<Identified.Narrowable>, Identified {}
/*       */   
/*       */   public static interface WithoutBatchStrategy
/*       */     extends RedefinitionListenable.WithImplicitDiscoveryStrategy
/*       */   {
/*       */     AgentBuilder.RedefinitionListenable.WithImplicitDiscoveryStrategy with(AgentBuilder.RedefinitionStrategy.BatchAllocator param1BatchAllocator);
/*       */   }
/*       */   
/*       */   public static interface Matchable<T extends Matchable<T>>
/*       */   {
/*       */     T and(ElementMatcher<? super TypeDescription> param1ElementMatcher);
/*       */     
/*       */     T and(ElementMatcher<? super TypeDescription> param1ElementMatcher, ElementMatcher<? super ClassLoader> param1ElementMatcher1);
/*       */     
/*       */     T and(ElementMatcher<? super TypeDescription> param1ElementMatcher, ElementMatcher<? super ClassLoader> param1ElementMatcher1, ElementMatcher<? super JavaModule> param1ElementMatcher2);
/*       */     
/*       */     T and(AgentBuilder.RawMatcher param1RawMatcher);
/*       */     
/*       */     T or(ElementMatcher<? super TypeDescription> param1ElementMatcher);
/*       */     
/*       */     T or(ElementMatcher<? super TypeDescription> param1ElementMatcher, ElementMatcher<? super ClassLoader> param1ElementMatcher1);
/*       */     
/*       */     T or(ElementMatcher<? super TypeDescription> param1ElementMatcher, ElementMatcher<? super ClassLoader> param1ElementMatcher1, ElementMatcher<? super JavaModule> param1ElementMatcher2);
/*       */     
/*       */     T or(AgentBuilder.RawMatcher param1RawMatcher);
/*       */   }
/*       */   
/*       */   public static interface Ignored
/*       */     extends Matchable<Ignored>, AgentBuilder {}
/*       */   
/*       */   public static interface RedefinitionListenable
/*       */     extends AgentBuilder
/*       */   {
/*       */     RedefinitionListenable with(AgentBuilder.RedefinitionStrategy.Listener param1Listener);
/*       */     
/*       */     WithoutResubmissionSpecification withResubmission(AgentBuilder.RedefinitionStrategy.ResubmissionScheduler param1ResubmissionScheduler);
/*       */     
/*       */     public static interface ResubmissionOnErrorMatcher
/*       */     {
/*       */       boolean matches(Throwable param2Throwable, String param2String, @MaybeNull ClassLoader param2ClassLoader, @MaybeNull JavaModule param2JavaModule);
/*       */       
/*       */       public enum Trivial
/*       */         implements ResubmissionOnErrorMatcher
/*       */       {
/*   966 */         MATCHING(true),
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*   971 */         NON_MATCHING(false);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean matching;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         Trivial(boolean matching) {
/*   984 */           this.matching = matching;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(Throwable throwable, String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*   991 */           return this.matching;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Conjunction
/*       */         implements ResubmissionOnErrorMatcher
/*       */       {
/*       */         private final List<AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher> matchers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Conjunction(AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher... matcher) {
/*  1012 */           this(Arrays.asList(matcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Conjunction(List<? extends AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher> matchers) {
/*  1021 */           this.matchers = new ArrayList<AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher>(matchers.size());
/*  1022 */           for (AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher matcher : matchers) {
/*  1023 */             if (matcher instanceof Conjunction) {
/*  1024 */               this.matchers.addAll(((Conjunction)matcher).matchers); continue;
/*  1025 */             }  if (matcher != AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher.Trivial.MATCHING) {
/*  1026 */               this.matchers.add(matcher);
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(Throwable throwable, String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1035 */           for (AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher matcher : this.matchers) {
/*  1036 */             if (!matcher.matches(throwable, typeName, classLoader, module)) {
/*  1037 */               return false;
/*       */             }
/*       */           } 
/*  1040 */           return true;
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matchers.equals(((Conjunction)param3Object).matchers))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */         }
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       public static class Disjunction
/*       */         implements ResubmissionOnErrorMatcher
/*       */       {
/*       */         private final List<AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher> matchers;
/*       */         
/*       */         public Disjunction(AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher... matcher) {
/*  1061 */           this(Arrays.asList(matcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Disjunction(List<? extends AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher> matchers) {
/*  1070 */           this.matchers = new ArrayList<AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher>(matchers.size());
/*  1071 */           for (AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher matcher : matchers) {
/*  1072 */             if (matcher instanceof Disjunction) {
/*  1073 */               this.matchers.addAll(((Disjunction)matcher).matchers); continue;
/*  1074 */             }  if (matcher != AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher.Trivial.NON_MATCHING) {
/*  1075 */               this.matchers.add(matcher);
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(Throwable throwable, String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1084 */           for (AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher matcher : this.matchers) {
/*  1085 */             if (matcher.matches(throwable, typeName, classLoader, module)) {
/*  1086 */               return true;
/*       */             }
/*       */           } 
/*  1089 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matchers.equals(((Disjunction)param3Object).matchers))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForElementMatchers
/*       */         implements ResubmissionOnErrorMatcher
/*       */       {
/*       */         private final ElementMatcher<? super Throwable> exceptionMatcher;
/*       */ 
/*       */ 
/*       */         
/*       */         private final ElementMatcher<String> typeNameMatcher;
/*       */ 
/*       */ 
/*       */         
/*       */         private final ElementMatcher<? super ClassLoader> classLoaderMatcher;
/*       */ 
/*       */ 
/*       */         
/*       */         private final ElementMatcher<? super JavaModule> moduleMatcher;
/*       */ 
/*       */ 
/*       */         
/*       */         public ForElementMatchers(ElementMatcher<? super Throwable> exceptionMatcher, ElementMatcher<String> typeNameMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/*  1131 */           this.exceptionMatcher = exceptionMatcher;
/*  1132 */           this.typeNameMatcher = typeNameMatcher;
/*  1133 */           this.classLoaderMatcher = classLoaderMatcher;
/*  1134 */           this.moduleMatcher = moduleMatcher;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(Throwable throwable, String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1141 */           return (this.exceptionMatcher.matches(throwable) && this.typeNameMatcher
/*  1142 */             .matches(typeName) && this.classLoaderMatcher
/*  1143 */             .matches(classLoader) && this.moduleMatcher
/*  1144 */             .matches(module));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.exceptionMatcher.equals(((ForElementMatchers)param3Object).exceptionMatcher) ? false : (!this.typeNameMatcher.equals(((ForElementMatchers)param3Object).typeNameMatcher) ? false : (!this.classLoaderMatcher.equals(((ForElementMatchers)param3Object).classLoaderMatcher) ? false : (!!this.moduleMatcher.equals(((ForElementMatchers)param3Object).moduleMatcher)))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (((getClass().hashCode() * 31 + this.exceptionMatcher.hashCode()) * 31 + this.typeNameMatcher.hashCode()) * 31 + this.classLoaderMatcher.hashCode()) * 31 + this.moduleMatcher.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ResubmissionImmediateMatcher
/*       */     {
/*       */       boolean matches(String param2String, @MaybeNull ClassLoader param2ClassLoader, @MaybeNull JavaModule param2JavaModule);
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Trivial
/*       */         implements ResubmissionImmediateMatcher
/*       */       {
/*  1172 */         MATCHING(true),
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  1177 */         NON_MATCHING(false);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean matching;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         Trivial(boolean matching) {
/*  1190 */           this.matching = matching;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1197 */           return this.matching;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Conjunction
/*       */         implements ResubmissionImmediateMatcher
/*       */       {
/*       */         private final List<AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher> matchers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Conjunction(AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher... matcher) {
/*  1218 */           this(Arrays.asList(matcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Conjunction(List<? extends AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher> matchers) {
/*  1227 */           this.matchers = new ArrayList<AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher>(matchers.size());
/*  1228 */           for (AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher matcher : matchers) {
/*  1229 */             if (matcher instanceof Conjunction) {
/*  1230 */               this.matchers.addAll(((Conjunction)matcher).matchers); continue;
/*  1231 */             }  if (matcher != AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher.Trivial.NON_MATCHING) {
/*  1232 */               this.matchers.add(matcher);
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1241 */           for (AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher matcher : this.matchers) {
/*  1242 */             if (!matcher.matches(typeName, classLoader, module)) {
/*  1243 */               return false;
/*       */             }
/*       */           } 
/*  1246 */           return true;
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matchers.equals(((Conjunction)param3Object).matchers))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */         }
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       public static class Disjunction
/*       */         implements ResubmissionImmediateMatcher
/*       */       {
/*       */         private final List<AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher> matchers;
/*       */         
/*       */         public Disjunction(AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher... matcher) {
/*  1267 */           this(Arrays.asList(matcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Disjunction(List<? extends AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher> matchers) {
/*  1276 */           this.matchers = new ArrayList<AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher>(matchers.size());
/*  1277 */           for (AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher matcher : matchers) {
/*  1278 */             if (matcher instanceof Disjunction) {
/*  1279 */               this.matchers.addAll(((Disjunction)matcher).matchers); continue;
/*  1280 */             }  if (matcher != AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher.Trivial.NON_MATCHING) {
/*  1281 */               this.matchers.add(matcher);
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1290 */           for (AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher matcher : this.matchers) {
/*  1291 */             if (matcher.matches(typeName, classLoader, module)) {
/*  1292 */               return true;
/*       */             }
/*       */           } 
/*  1295 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matchers.equals(((Disjunction)param3Object).matchers))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForElementMatchers
/*       */         implements ResubmissionImmediateMatcher
/*       */       {
/*       */         private final ElementMatcher<String> typeNameMatcher;
/*       */ 
/*       */         
/*       */         private final ElementMatcher<? super ClassLoader> classLoaderMatcher;
/*       */ 
/*       */         
/*       */         private final ElementMatcher<? super JavaModule> moduleMatcher;
/*       */ 
/*       */ 
/*       */         
/*       */         public ForElementMatchers(ElementMatcher<String> typeNameMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/*  1330 */           this.typeNameMatcher = typeNameMatcher;
/*  1331 */           this.classLoaderMatcher = classLoaderMatcher;
/*  1332 */           this.moduleMatcher = moduleMatcher;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  1339 */           return (this.typeNameMatcher.matches(typeName) && this.classLoaderMatcher
/*  1340 */             .matches(classLoader) && this.moduleMatcher
/*  1341 */             .matches(module));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.typeNameMatcher.equals(((ForElementMatchers)param3Object).typeNameMatcher) ? false : (!this.classLoaderMatcher.equals(((ForElementMatchers)param3Object).classLoaderMatcher) ? false : (!!this.moduleMatcher.equals(((ForElementMatchers)param3Object).moduleMatcher))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.typeNameMatcher.hashCode()) * 31 + this.classLoaderMatcher.hashCode()) * 31 + this.moduleMatcher.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface WithoutResubmissionSpecification
/*       */     {
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> param2ElementMatcher);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> param2ElementMatcher, ElementMatcher<String> param2ElementMatcher1);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> param2ElementMatcher, ElementMatcher<String> param2ElementMatcher1, ElementMatcher<? super ClassLoader> param2ElementMatcher2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> param2ElementMatcher, ElementMatcher<String> param2ElementMatcher1, ElementMatcher<? super ClassLoader> param2ElementMatcher2, ElementMatcher<? super JavaModule> param2ElementMatcher3);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher param2ResubmissionOnErrorMatcher);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(ElementMatcher<String> param2ElementMatcher);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(ElementMatcher<String> param2ElementMatcher, ElementMatcher<? super ClassLoader> param2ElementMatcher1);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(ElementMatcher<String> param2ElementMatcher, ElementMatcher<? super ClassLoader> param2ElementMatcher1, ElementMatcher<? super JavaModule> param2ElementMatcher2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher param2ResubmissionImmediateMatcher);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface WithResubmissionSpecification
/*       */       extends WithoutResubmissionSpecification, AgentBuilder {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface WithImplicitDiscoveryStrategy
/*       */       extends RedefinitionListenable
/*       */     {
/*       */       AgentBuilder.RedefinitionListenable redefineOnly(Class<?>... param2VarArgs);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AgentBuilder.RedefinitionListenable with(AgentBuilder.RedefinitionStrategy.DiscoveryStrategy param2DiscoveryStrategy);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface WithoutBatchStrategy
/*       */       extends WithImplicitDiscoveryStrategy
/*       */     {
/*       */       AgentBuilder.RedefinitionListenable.WithImplicitDiscoveryStrategy with(AgentBuilder.RedefinitionStrategy.BatchAllocator param2BatchAllocator);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface Identified
/*       */   {
/*       */     Extendable transform(AgentBuilder.Transformer param1Transformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Extendable
/*       */       extends AgentBuilder, Identified
/*       */     {
/*       */       AgentBuilder asTerminalTransformation();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Narrowable
/*       */       extends AgentBuilder.Matchable<Narrowable>, Identified {}
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface RawMatcher
/*       */   {
/*       */     boolean matches(TypeDescription param1TypeDescription, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, @MaybeNull Class<?> param1Class, @MaybeNull ProtectionDomain param1ProtectionDomain);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Trivial
/*       */       implements RawMatcher
/*       */     {
/*  1590 */       MATCHING(true),
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1595 */       NON_MATCHING(false);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean matches;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Trivial(boolean matches) {
/*  1608 */         this.matches = matches;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1619 */         return this.matches;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForLoadState
/*       */       implements RawMatcher
/*       */     {
/*  1631 */       LOADED(false),
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1636 */       UNLOADED(true);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean unloaded;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       ForLoadState(boolean unloaded) {
/*  1649 */         this.unloaded = unloaded;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1660 */         return (((classBeingRedefined == null)) == this.unloaded);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForResolvableTypes
/*       */       implements RawMatcher
/*       */     {
/*  1673 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1683 */         if (classBeingRedefined != null) {
/*       */           try {
/*  1685 */             return (Class.forName(classBeingRedefined.getName(), true, classLoader) == classBeingRedefined);
/*  1686 */           } catch (Throwable ignored) {
/*  1687 */             return false;
/*       */           } 
/*       */         }
/*  1690 */         return true;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RawMatcher inverted() {
/*  1700 */         return new AgentBuilder.RawMatcher.Inversion(this);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Conjunction
/*       */       implements RawMatcher
/*       */     {
/*       */       private final List<AgentBuilder.RawMatcher> matchers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Conjunction(AgentBuilder.RawMatcher... matcher) {
/*  1721 */         this(Arrays.asList(matcher));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Conjunction(List<? extends AgentBuilder.RawMatcher> matchers) {
/*  1730 */         this.matchers = new ArrayList<AgentBuilder.RawMatcher>(matchers.size());
/*  1731 */         for (AgentBuilder.RawMatcher matcher : matchers) {
/*  1732 */           if (matcher instanceof Conjunction) {
/*  1733 */             this.matchers.addAll(((Conjunction)matcher).matchers); continue;
/*  1734 */           }  if (matcher != AgentBuilder.RawMatcher.Trivial.MATCHING) {
/*  1735 */             this.matchers.add(matcher);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1748 */         for (AgentBuilder.RawMatcher matcher : this.matchers) {
/*  1749 */           if (!matcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/*  1750 */             return false;
/*       */           }
/*       */         } 
/*  1753 */         return true;
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.matchers.equals(((Conjunction)param2Object).matchers))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */       }
/*       */     }
/*       */     
/*       */     @Enhance
/*       */     public static class Disjunction
/*       */       implements RawMatcher
/*       */     {
/*       */       private final List<AgentBuilder.RawMatcher> matchers;
/*       */       
/*       */       protected Disjunction(AgentBuilder.RawMatcher... matcher) {
/*  1774 */         this(Arrays.asList(matcher));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Disjunction(List<? extends AgentBuilder.RawMatcher> matchers) {
/*  1783 */         this.matchers = new ArrayList<AgentBuilder.RawMatcher>(matchers.size());
/*  1784 */         for (AgentBuilder.RawMatcher matcher : matchers) {
/*  1785 */           if (matcher instanceof Disjunction) {
/*  1786 */             this.matchers.addAll(((Disjunction)matcher).matchers); continue;
/*  1787 */           }  if (matcher != AgentBuilder.RawMatcher.Trivial.NON_MATCHING) {
/*  1788 */             this.matchers.add(matcher);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1801 */         for (AgentBuilder.RawMatcher matcher : this.matchers) {
/*  1802 */           if (matcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/*  1803 */             return true;
/*       */           }
/*       */         } 
/*  1806 */         return false;
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.matchers.equals(((Disjunction)param2Object).matchers))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */       }
/*       */     }
/*       */     
/*       */     @Enhance
/*       */     public static class Inversion
/*       */       implements RawMatcher
/*       */     {
/*       */       private final AgentBuilder.RawMatcher matcher;
/*       */       
/*       */       public Inversion(AgentBuilder.RawMatcher matcher) {
/*  1827 */         this.matcher = matcher;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1838 */         return !this.matcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.matcher.equals(((Inversion)param2Object).matcher))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.matcher.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForElementMatchers
/*       */       implements RawMatcher
/*       */     {
/*       */       private final ElementMatcher<? super TypeDescription> typeMatcher;
/*       */ 
/*       */       
/*       */       private final ElementMatcher<? super ClassLoader> classLoaderMatcher;
/*       */ 
/*       */       
/*       */       private final ElementMatcher<? super JavaModule> moduleMatcher;
/*       */ 
/*       */ 
/*       */       
/*       */       public ForElementMatchers(ElementMatcher<? super TypeDescription> typeMatcher) {
/*  1873 */         this(typeMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForElementMatchers(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/*  1886 */         this(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForElementMatchers(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/*  1901 */         this.typeMatcher = typeMatcher;
/*  1902 */         this.classLoaderMatcher = classLoaderMatcher;
/*  1903 */         this.moduleMatcher = moduleMatcher;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/*  1914 */         return (this.moduleMatcher.matches(module) && this.classLoaderMatcher.matches(classLoader) && this.typeMatcher.matches(typeDescription));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.typeMatcher.equals(((ForElementMatchers)param2Object).typeMatcher) ? false : (!this.classLoaderMatcher.equals(((ForElementMatchers)param2Object).classLoaderMatcher) ? false : (!!this.moduleMatcher.equals(((ForElementMatchers)param2Object).moduleMatcher))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.typeMatcher.hashCode()) * 31 + this.classLoaderMatcher.hashCode()) * 31 + this.moduleMatcher.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface Listener
/*       */   {
/*       */     public static final boolean LOADED = true;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onDiscovery(String param1String, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, boolean param1Boolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onTransformation(TypeDescription param1TypeDescription, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, boolean param1Boolean, DynamicType param1DynamicType);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onIgnored(TypeDescription param1TypeDescription, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, boolean param1Boolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onError(String param1String, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, boolean param1Boolean, Throwable param1Throwable);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onComplete(String param1String, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, boolean param1Boolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements Listener
/*       */     {
/*  1989 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onDiscovery(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onIgnored(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onComplete(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class Adapter
/*       */       implements Listener
/*       */     {
/*       */       public void onDiscovery(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onIgnored(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onComplete(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class StreamWriting
/*       */       implements Listener
/*       */     {
/*       */       protected static final String PREFIX = "[Byte Buddy]";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final PrintStream printStream;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StreamWriting(PrintStream printStream) {
/*  2091 */         this.printStream = printStream;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static StreamWriting toSystemOut() {
/*  2100 */         return new StreamWriting(System.out);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static StreamWriting toSystemError() {
/*  2109 */         return new StreamWriting(System.err);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Listener withTransformationsOnly() {
/*  2118 */         return new AgentBuilder.Listener.WithTransformationsOnly(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Listener withErrorsOnly() {
/*  2127 */         return new AgentBuilder.Listener.WithErrorsOnly(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onDiscovery(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2134 */         this.printStream.printf("[Byte Buddy] DISCOVERY %s [%s, %s, %s, loaded=%b]%n", new Object[] { typeName, classLoader, module, Thread.currentThread(), Boolean.valueOf(loaded) });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {
/*  2141 */         this.printStream.printf("[Byte Buddy] TRANSFORM %s [%s, %s, %s, loaded=%b]%n", new Object[] { typeDescription.getName(), classLoader, module, Thread.currentThread(), Boolean.valueOf(loaded) });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onIgnored(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2148 */         this.printStream.printf("[Byte Buddy] IGNORE %s [%s, %s, %s, loaded=%b]%n", new Object[] { typeDescription.getName(), classLoader, module, Thread.currentThread(), Boolean.valueOf(loaded) });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {
/*  2155 */         synchronized (this.printStream) {
/*  2156 */           this.printStream.printf("[Byte Buddy] ERROR %s [%s, %s, %s, loaded=%b]%n", new Object[] { typeName, classLoader, module, Thread.currentThread(), Boolean.valueOf(loaded) });
/*  2157 */           throwable.printStackTrace(this.printStream);
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onComplete(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2165 */         this.printStream.printf("[Byte Buddy] COMPLETE %s [%s, %s, %s, loaded=%b]%n", new Object[] { typeName, classLoader, module, Thread.currentThread(), Boolean.valueOf(loaded) });
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.printStream.equals(((StreamWriting)param2Object).printStream))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.printStream.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Filtering
/*       */       implements Listener
/*       */     {
/*       */       private final ElementMatcher<? super String> matcher;
/*       */       
/*       */       private final AgentBuilder.Listener delegate;
/*       */ 
/*       */       
/*       */       public Filtering(ElementMatcher<? super String> matcher, AgentBuilder.Listener delegate) {
/*  2192 */         this.matcher = matcher;
/*  2193 */         this.delegate = delegate;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onDiscovery(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2200 */         if (this.matcher.matches(typeName)) {
/*  2201 */           this.delegate.onDiscovery(typeName, classLoader, module, loaded);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {
/*  2209 */         if (this.matcher.matches(typeDescription.getName())) {
/*  2210 */           this.delegate.onTransformation(typeDescription, classLoader, module, loaded, dynamicType);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onIgnored(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2218 */         if (this.matcher.matches(typeDescription.getName())) {
/*  2219 */           this.delegate.onIgnored(typeDescription, classLoader, module, loaded);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {
/*  2227 */         if (this.matcher.matches(typeName)) {
/*  2228 */           this.delegate.onError(typeName, classLoader, module, loaded, throwable);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onComplete(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2236 */         if (this.matcher.matches(typeName)) {
/*  2237 */           this.delegate.onComplete(typeName, classLoader, module, loaded);
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.matcher.equals(((Filtering)param2Object).matcher) ? false : (!!this.delegate.equals(((Filtering)param2Object).delegate)))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.delegate.hashCode();
/*       */       }
/*       */     }
/*       */     
/*       */     @Enhance
/*       */     public static class WithTransformationsOnly
/*       */       extends Adapter
/*       */     {
/*       */       private final AgentBuilder.Listener delegate;
/*       */       
/*       */       public WithTransformationsOnly(AgentBuilder.Listener delegate) {
/*  2259 */         this.delegate = delegate;
/*       */       }
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {
/*  2264 */         this.delegate.onTransformation(typeDescription, classLoader, module, loaded, dynamicType);
/*       */       }
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {
/*  2269 */         this.delegate.onError(typeName, classLoader, module, loaded, throwable);
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.delegate.equals(((WithTransformationsOnly)param2Object).delegate))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.delegate.hashCode();
/*       */       }
/*       */     }
/*       */     
/*       */     @Enhance
/*       */     public static class WithErrorsOnly
/*       */       extends Adapter
/*       */     {
/*       */       private final AgentBuilder.Listener delegate;
/*       */       
/*       */       public WithErrorsOnly(AgentBuilder.Listener delegate) {
/*  2290 */         this.delegate = delegate;
/*       */       }
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {
/*  2295 */         this.delegate.onError(typeName, classLoader, module, loaded, throwable);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.delegate.equals(((WithErrorsOnly)param2Object).delegate))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.delegate.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ModuleReadEdgeCompleting
/*       */       extends Adapter
/*       */     {
/*       */       private final Instrumentation instrumentation;
/*       */ 
/*       */       
/*       */       private final boolean addTargetEdge;
/*       */ 
/*       */       
/*       */       private final Set<? extends JavaModule> modules;
/*       */ 
/*       */ 
/*       */       
/*       */       public ModuleReadEdgeCompleting(Instrumentation instrumentation, boolean addTargetEdge, Set<? extends JavaModule> modules) {
/*  2331 */         this.instrumentation = instrumentation;
/*  2332 */         this.addTargetEdge = addTargetEdge;
/*  2333 */         this.modules = modules;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static AgentBuilder.Listener of(Instrumentation instrumentation, boolean addTargetEdge, Class<?>... type) {
/*  2347 */         Set<JavaModule> modules = new HashSet<JavaModule>();
/*  2348 */         for (Class<?> aType : type) {
/*  2349 */           modules.add(JavaModule.ofType(aType));
/*       */         }
/*  2351 */         return modules.isEmpty() ? AgentBuilder.Listener.NoOp.INSTANCE : new ModuleReadEdgeCompleting(instrumentation, addTargetEdge, modules);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {
/*  2358 */         if (module != JavaModule.UNSUPPORTED && module.isNamed()) {
/*  2359 */           for (JavaModule target : this.modules) {
/*  2360 */             if (!module.canRead(target) || (this.addTargetEdge && !module.isOpened(typeDescription.getPackage(), target))) {
/*  2361 */               PackageDescription location = typeDescription.getPackage();
/*  2362 */               ClassInjector.UsingInstrumentation.redefineModule(this.instrumentation, module, 
/*       */                   
/*  2364 */                   Collections.singleton(target), 
/*  2365 */                   Collections.emptyMap(), (!this.addTargetEdge || location == null || location
/*  2366 */                   .isDefault()) ? 
/*  2367 */                   Collections.emptyMap() : 
/*  2368 */                   Collections.singletonMap(location.getName(), Collections.singleton(target)), 
/*  2369 */                   Collections.emptySet(), 
/*  2370 */                   Collections.emptyMap());
/*       */             } 
/*  2372 */             if (this.addTargetEdge && !target.canRead(module)) {
/*  2373 */               ClassInjector.UsingInstrumentation.redefineModule(this.instrumentation, target, 
/*       */                   
/*  2375 */                   Collections.singleton(module), 
/*  2376 */                   Collections.emptyMap(), 
/*  2377 */                   Collections.emptyMap(), 
/*  2378 */                   Collections.emptySet(), 
/*  2379 */                   Collections.emptyMap());
/*       */             }
/*       */           } 
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.addTargetEdge != ((ModuleReadEdgeCompleting)param2Object).addTargetEdge) ? false : (!this.instrumentation.equals(((ModuleReadEdgeCompleting)param2Object).instrumentation) ? false : (!!this.modules.equals(((ModuleReadEdgeCompleting)param2Object).modules))))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.addTargetEdge) * 31 + this.modules.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Compound
/*       */       implements Listener
/*       */     {
/*       */       public Compound(AgentBuilder.Listener... listener) {
/*  2403 */         this(Arrays.asList(listener));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2412 */       private final List<AgentBuilder.Listener> listeners = new ArrayList<AgentBuilder.Listener>(); public Compound(List<? extends AgentBuilder.Listener> listeners) {
/*  2413 */         for (AgentBuilder.Listener listener : listeners) {
/*  2414 */           if (listener instanceof Compound) {
/*  2415 */             this.listeners.addAll(((Compound)listener).listeners); continue;
/*  2416 */           }  if (!(listener instanceof AgentBuilder.Listener.NoOp)) {
/*  2417 */             this.listeners.add(listener);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onDiscovery(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2426 */         for (AgentBuilder.Listener listener : this.listeners) {
/*  2427 */           listener.onDiscovery(typeName, classLoader, module, loaded);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onTransformation(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, DynamicType dynamicType) {
/*  2435 */         for (AgentBuilder.Listener listener : this.listeners) {
/*  2436 */           listener.onTransformation(typeDescription, classLoader, module, loaded, dynamicType);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onIgnored(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2444 */         for (AgentBuilder.Listener listener : this.listeners) {
/*  2445 */           listener.onIgnored(typeDescription, classLoader, module, loaded);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {
/*  2453 */         for (AgentBuilder.Listener listener : this.listeners) {
/*  2454 */           listener.onError(typeName, classLoader, module, loaded, throwable);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onComplete(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded) {
/*  2462 */         for (AgentBuilder.Listener listener : this.listeners) {
/*  2463 */           listener.onComplete(typeName, classLoader, module, loaded);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.listeners.equals(((Compound)param2Object).listeners))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.listeners.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface CircularityLock
/*       */   {
/*       */     boolean acquire();
/*       */ 
/*       */ 
/*       */     
/*       */     void release();
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Inactive
/*       */       implements CircularityLock
/*       */     {
/*  2497 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean acquire() {
/*  2503 */         return true;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void release() {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class WithInnerClassLoadingLock
/*       */       implements CircularityLock
/*       */     {
/*       */       protected static final int DEFAULT_SIZE = 100;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TrivialLock[] lock;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected WithInnerClassLoadingLock(int size) {
/*  2537 */         this.lock = new TrivialLock[size];
/*  2538 */         for (int index = 0; index < size; index++) {
/*  2539 */           this.lock[index] = new TrivialLock();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean acquire() {
/*       */         TrivialLock lock;
/*  2547 */         if (this.lock.length == 0) {
/*  2548 */           return doAcquire();
/*       */         }
/*       */         
/*  2551 */         if (this.lock.length == 1) {
/*  2552 */           lock = this.lock[0];
/*       */         } else {
/*  2554 */           int hash = System.identityHashCode(Thread.currentThread());
/*  2555 */           lock = this.lock[(hash == Integer.MIN_VALUE) ? 0 : (Math.abs(hash) % this.lock.length)];
/*       */         } 
/*  2557 */         synchronized (lock) {
/*  2558 */           if (lock.locked) {
/*  2559 */             return false;
/*       */           }
/*  2561 */           lock.locked = true;
/*       */           try {
/*  2563 */             return doAcquire();
/*       */           } finally {
/*  2565 */             lock.locked = false;
/*       */           } 
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract boolean doAcquire();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class TrivialLock
/*       */       {
/*       */         protected boolean locked;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static class Default
/*       */       extends WithInnerClassLoadingLock
/*       */     {
/*  2602 */       private final ConcurrentMap<Thread, Boolean> threads = new ConcurrentHashMap<Thread, Boolean>();
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Default() {
/*  2608 */         super(100);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Default(int size) {
/*  2617 */         super(size);
/*       */       }
/*       */ 
/*       */       
/*       */       protected boolean doAcquire() {
/*  2622 */         return (this.threads.putIfAbsent(Thread.currentThread(), Boolean.valueOf(true)) == null);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void release() {
/*  2629 */         this.threads.remove(Thread.currentThread());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected boolean isLocked() {
/*  2638 */         return this.threads.containsKey(Thread.currentThread());
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Global
/*       */       extends WithInnerClassLoadingLock
/*       */     {
/*       */       private final Lock lock;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final long time;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TimeUnit timeUnit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Global() {
/*  2668 */         this(100);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Global(long time, TimeUnit timeUnit) {
/*  2678 */         this(100, time, timeUnit);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Global(int size) {
/*  2687 */         this(size, 0L, TimeUnit.MILLISECONDS);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Global(int size, long time, TimeUnit timeUnit) {
/*  2698 */         super(size);
/*  2699 */         this.lock = new ReentrantLock();
/*  2700 */         this.time = time;
/*  2701 */         this.timeUnit = timeUnit;
/*       */       }
/*       */ 
/*       */       
/*       */       protected boolean doAcquire() {
/*       */         try {
/*  2707 */           return (this.time == 0L) ? this.lock
/*  2708 */             .tryLock() : this.lock
/*  2709 */             .tryLock(this.time, this.timeUnit);
/*  2710 */         } catch (InterruptedException ignored) {
/*  2711 */           return false;
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void release() {
/*  2719 */         this.lock.unlock();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.time != ((Global)param2Object).time) ? false : (!this.timeUnit.equals(((Global)param2Object).timeUnit) ? false : (!!this.lock.equals(((Global)param2Object).lock))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.lock.hashCode()) * 31 + (int)(this.time ^ this.time >>> 32L)) * 31 + this.timeUnit.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface TypeStrategy
/*       */   {
/*       */     DynamicType.Builder<?> builder(TypeDescription param1TypeDescription, ByteBuddy param1ByteBuddy, ClassFileLocator param1ClassFileLocator, MethodNameTransformer param1MethodNameTransformer, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, @MaybeNull ProtectionDomain param1ProtectionDomain);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Default
/*       */       implements TypeStrategy
/*       */     {
/*  2757 */       REBASE
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public DynamicType.Builder<?> builder(TypeDescription typeDescription, ByteBuddy byteBuddy, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain)
/*       */         {
/*  2766 */           return byteBuddy.rebase(typeDescription, classFileLocator, methodNameTransformer);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2783 */       REDEFINE
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public DynamicType.Builder<?> builder(TypeDescription typeDescription, ByteBuddy byteBuddy, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain)
/*       */         {
/*  2792 */           return byteBuddy.redefine(typeDescription, classFileLocator);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2810 */       REDEFINE_FROZEN
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public DynamicType.Builder<?> builder(TypeDescription typeDescription, ByteBuddy byteBuddy, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain)
/*       */         {
/*  2819 */           return byteBuddy.with((InstrumentedType.Factory)InstrumentedType.Factory.Default.FROZEN)
/*  2820 */             .with((VisibilityBridgeStrategy)VisibilityBridgeStrategy.Default.NEVER)
/*  2821 */             .redefine(typeDescription, classFileLocator)
/*  2822 */             .ignoreAlso((LatentMatcher)LatentMatcher.ForSelfDeclaredMethod.NOT_DECLARED);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2843 */       DECORATE
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public DynamicType.Builder<?> builder(TypeDescription typeDescription, ByteBuddy byteBuddy, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain)
/*       */         {
/*  2852 */           return byteBuddy.decorate(typeDescription, classFileLocator);
/*       */         }
/*       */       };
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForBuildEntryPoint
/*       */       implements TypeStrategy
/*       */     {
/*       */       private final EntryPoint entryPoint;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForBuildEntryPoint(EntryPoint entryPoint) {
/*  2874 */         this.entryPoint = entryPoint;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public DynamicType.Builder<?> builder(TypeDescription typeDescription, ByteBuddy byteBuddy, ClassFileLocator classFileLocator, MethodNameTransformer methodNameTransformer, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain) {
/*  2887 */         return this.entryPoint.transform(typeDescription, byteBuddy, classFileLocator, methodNameTransformer);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.entryPoint.equals(((ForBuildEntryPoint)param2Object).entryPoint))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.entryPoint.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface Transformer
/*       */   {
/*       */     DynamicType.Builder<?> transform(DynamicType.Builder<?> param1Builder, TypeDescription param1TypeDescription, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, @MaybeNull ProtectionDomain param1ProtectionDomain);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForBuildPlugin
/*       */       implements Transformer
/*       */     {
/*       */       private final Plugin plugin;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForBuildPlugin(Plugin plugin) {
/*  2932 */         this.plugin = plugin;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public DynamicType.Builder<?> transform(DynamicType.Builder<?> builder, TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain) {
/*  2943 */         return this.plugin.apply(builder, typeDescription, ClassFileLocator.ForClassLoader.of(classLoader));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.plugin.equals(((ForBuildPlugin)param2Object).plugin))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.plugin.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForAdvice
/*       */       implements Transformer
/*       */     {
/*       */       private final Advice.WithCustomMapping advice;
/*       */ 
/*       */ 
/*       */       
/*       */       private final Advice.ExceptionHandler exceptionHandler;
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner assigner;
/*       */ 
/*       */ 
/*       */       
/*       */       private final ClassFileLocator classFileLocator;
/*       */ 
/*       */ 
/*       */       
/*       */       private final AgentBuilder.PoolStrategy poolStrategy;
/*       */ 
/*       */ 
/*       */       
/*       */       private final AgentBuilder.LocationStrategy locationStrategy;
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<Entry> entries;
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<String> auxiliaries;
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice() {
/*  3001 */         this(Advice.withCustomMapping());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice(Advice.WithCustomMapping advice) {
/*  3010 */         this(advice, (Advice.ExceptionHandler)Advice.ExceptionHandler.Default.SUPPRESSING, Assigner.DEFAULT, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE, AgentBuilder.PoolStrategy.Default.FAST, AgentBuilder.LocationStrategy.ForClassLoader.STRONG, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  3016 */             Collections.emptyList(), 
/*  3017 */             Collections.emptyList());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForAdvice(Advice.WithCustomMapping advice, Advice.ExceptionHandler exceptionHandler, Assigner assigner, ClassFileLocator classFileLocator, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, List<Entry> entries, List<String> auxiliaries) {
/*  3040 */         this.advice = advice;
/*  3041 */         this.exceptionHandler = exceptionHandler;
/*  3042 */         this.assigner = assigner;
/*  3043 */         this.classFileLocator = classFileLocator;
/*  3044 */         this.poolStrategy = poolStrategy;
/*  3045 */         this.locationStrategy = locationStrategy;
/*  3046 */         this.entries = entries;
/*  3047 */         this.auxiliaries = auxiliaries;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public DynamicType.Builder<?> transform(DynamicType.Builder<?> builder, TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain) {
/*  3058 */         ClassFileLocator.Compound compound = new ClassFileLocator.Compound(new ClassFileLocator[] { this.classFileLocator, this.locationStrategy.classFileLocator(classLoader, module) });
/*  3059 */         TypePool typePool = this.poolStrategy.typePool((ClassFileLocator)compound, classLoader);
/*  3060 */         for (String auxiliary : this.auxiliaries) {
/*  3061 */           builder = builder.require(new DynamicType[] { (DynamicType)new LazyDynamicType(typePool.describe(auxiliary).resolve(), (ClassFileLocator)compound) });
/*       */         } 
/*  3063 */         AsmVisitorWrapper.ForDeclaredMethods asmVisitorWrapper = new AsmVisitorWrapper.ForDeclaredMethods();
/*  3064 */         for (Entry entry : this.entries) {
/*  3065 */           asmVisitorWrapper = asmVisitorWrapper.invokable(entry.getMatcher().resolve(typeDescription), new AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper[] { wrap(typeDescription, classLoader, module, protectionDomain, entry
/*       */ 
/*       */ 
/*       */                   
/*  3069 */                   .resolve(this.advice, typePool, (ClassFileLocator)compound).withAssigner(this.assigner).withExceptionHandler(this.exceptionHandler)) });
/*       */         } 
/*  3071 */         return builder.visit((AsmVisitorWrapper)asmVisitorWrapper);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper wrap(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain, Advice advice) {
/*  3092 */         return (AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper)advice;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForAdvice make(Advice.WithCustomMapping advice, Advice.ExceptionHandler exceptionHandler, Assigner assigner, ClassFileLocator classFileLocator, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, List<Entry> entries, List<String> auxiliaries) {
/*  3116 */         return new ForAdvice(advice, exceptionHandler, assigner, classFileLocator, poolStrategy, locationStrategy, entries, auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice with(AgentBuilder.PoolStrategy poolStrategy) {
/*  3126 */         return make(this.advice, this.exceptionHandler, this.assigner, this.classFileLocator, poolStrategy, this.locationStrategy, this.entries, this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice with(AgentBuilder.LocationStrategy locationStrategy) {
/*  3137 */         return make(this.advice, this.exceptionHandler, this.assigner, this.classFileLocator, this.poolStrategy, locationStrategy, this.entries, this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice withExceptionHandler(Advice.ExceptionHandler exceptionHandler) {
/*  3148 */         return make(this.advice, exceptionHandler, this.assigner, this.classFileLocator, this.poolStrategy, this.locationStrategy, this.entries, this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice with(Assigner assigner) {
/*  3159 */         return make(this.advice, this.exceptionHandler, assigner, this.classFileLocator, this.poolStrategy, this.locationStrategy, this.entries, this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice include(ClassLoader... classLoader) {
/*  3170 */         Set<ClassFileLocator> classFileLocators = new LinkedHashSet<ClassFileLocator>();
/*  3171 */         for (ClassLoader aClassLoader : classLoader) {
/*  3172 */           classFileLocators.add(ClassFileLocator.ForClassLoader.of(aClassLoader));
/*       */         }
/*  3174 */         return include(new ArrayList<ClassFileLocator>(classFileLocators));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice include(ClassFileLocator... classFileLocator) {
/*  3185 */         return include(Arrays.asList(classFileLocator));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice include(List<? extends ClassFileLocator> classFileLocators) {
/*  3196 */         return make(this.advice, this.exceptionHandler, this.assigner, (ClassFileLocator)new ClassFileLocator.Compound(
/*       */ 
/*       */               
/*  3199 */               CompoundList.of(this.classFileLocator, classFileLocators)), this.poolStrategy, this.locationStrategy, this.entries, this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice advice(ElementMatcher<? super MethodDescription> matcher, String name) {
/*  3214 */         return advice((LatentMatcher<? super MethodDescription>)new LatentMatcher.Resolved(matcher), name);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice advice(LatentMatcher<? super MethodDescription> matcher, String name) {
/*  3225 */         return make(this.advice, this.exceptionHandler, this.assigner, this.classFileLocator, this.poolStrategy, this.locationStrategy, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  3231 */             CompoundList.of(this.entries, new Entry.ForUnifiedAdvice(matcher, name)), this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice advice(ElementMatcher<? super MethodDescription> matcher, String enter, String exit) {
/*  3244 */         return advice((LatentMatcher<? super MethodDescription>)new LatentMatcher.Resolved(matcher), enter, exit);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice advice(LatentMatcher<? super MethodDescription> matcher, String enter, String exit) {
/*  3256 */         return make(this.advice, this.exceptionHandler, this.assigner, this.classFileLocator, this.poolStrategy, this.locationStrategy, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  3262 */             CompoundList.of(this.entries, new Entry.ForSplitAdvice(matcher, enter, exit)), this.auxiliaries);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice auxiliary(String... auxiliary) {
/*  3273 */         return auxiliary(Arrays.asList(auxiliary));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAdvice auxiliary(List<String> auxiliaries) {
/*  3283 */         return make(this.advice, this.exceptionHandler, this.assigner, this.classFileLocator, this.poolStrategy, this.locationStrategy, this.entries, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  3290 */             CompoundList.of(this.auxiliaries, auxiliaries));
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.advice.equals(((ForAdvice)param2Object).advice) ? false : (!this.exceptionHandler.equals(((ForAdvice)param2Object).exceptionHandler) ? false : (!this.assigner.equals(((ForAdvice)param2Object).assigner) ? false : (!this.classFileLocator.equals(((ForAdvice)param2Object).classFileLocator) ? false : (!this.poolStrategy.equals(((ForAdvice)param2Object).poolStrategy) ? false : (!this.locationStrategy.equals(((ForAdvice)param2Object).locationStrategy) ? false : (!this.entries.equals(((ForAdvice)param2Object).entries) ? false : (!!this.auxiliaries.equals(((ForAdvice)param2Object).auxiliaries)))))))))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (((((((getClass().hashCode() * 31 + this.advice.hashCode()) * 31 + this.exceptionHandler.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.classFileLocator.hashCode()) * 31 + this.poolStrategy.hashCode()) * 31 + this.locationStrategy.hashCode()) * 31 + this.entries.hashCode()) * 31 + this.auxiliaries.hashCode();
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static abstract class Entry
/*       */       {
/*       */         private final LatentMatcher<? super MethodDescription> matcher;
/*       */         
/*       */         protected Entry(LatentMatcher<? super MethodDescription> matcher) {
/*  3310 */           this.matcher = matcher;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected LatentMatcher<? super MethodDescription> getMatcher() {
/*  3319 */           return this.matcher;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract Advice resolve(Advice.WithCustomMapping param3WithCustomMapping, TypePool param3TypePool, ClassFileLocator param3ClassFileLocator);
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matcher.equals(((Entry)param3Object).matcher))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.matcher.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class ForUnifiedAdvice
/*       */           extends Entry
/*       */         {
/*       */           protected final String name;
/*       */ 
/*       */ 
/*       */           
/*       */           protected ForUnifiedAdvice(LatentMatcher<? super MethodDescription> matcher, String name) {
/*  3350 */             super(matcher);
/*  3351 */             this.name = name;
/*       */           }
/*       */ 
/*       */           
/*       */           protected Advice resolve(Advice.WithCustomMapping advice, TypePool typePool, ClassFileLocator classFileLocator) {
/*  3356 */             return advice.to(typePool.describe(this.name).resolve(), classFileLocator);
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.name.equals(((ForUnifiedAdvice)param4Object).name)))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return super.hashCode() * 31 + this.name.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class ForSplitAdvice
/*       */           extends Entry
/*       */         {
/*       */           private final String enter;
/*       */           
/*       */           private final String exit;
/*       */ 
/*       */           
/*       */           protected ForSplitAdvice(LatentMatcher<? super MethodDescription> matcher, String enter, String exit) {
/*  3384 */             super(matcher);
/*  3385 */             this.enter = enter;
/*  3386 */             this.exit = exit;
/*       */           }
/*       */           
/*       */           protected Advice resolve(Advice.WithCustomMapping advice, TypePool typePool, ClassFileLocator classFileLocator)
/*       */           {
/*  3391 */             return advice.to(typePool.describe(this.enter).resolve(), typePool.describe(this.exit).resolve(), classFileLocator); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.enter.equals(((ForSplitAdvice)param4Object).enter) ? false : (!!this.exit.equals(((ForSplitAdvice)param4Object).exit)))))); } public int hashCode() { return (super.hashCode() * 31 + this.enter.hashCode()) * 31 + this.exit.hashCode(); } } } @Enhance protected static class ForUnifiedAdvice extends Entry { protected final String name; protected ForUnifiedAdvice(LatentMatcher<? super MethodDescription> matcher, String name) { super(matcher); this.name = name; } protected Advice resolve(Advice.WithCustomMapping advice, TypePool typePool, ClassFileLocator classFileLocator) { return advice.to(typePool.describe(this.name).resolve(), classFileLocator); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.name.equals(((ForUnifiedAdvice)param3Object).name))))); } public int hashCode() { return super.hashCode() * 31 + this.name.hashCode(); } } @Enhance protected static class ForSplitAdvice extends Entry { private final String enter; private final String exit; protected ForSplitAdvice(LatentMatcher<? super MethodDescription> matcher, String enter, String exit) { super(matcher); this.enter = enter; this.exit = exit; } protected Advice resolve(Advice.WithCustomMapping advice, TypePool typePool, ClassFileLocator classFileLocator) { return advice.to(typePool.describe(this.enter).resolve(), typePool.describe(this.exit).resolve(), classFileLocator); }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.enter.equals(((ForSplitAdvice)param3Object).enter) ? false : (!!this.exit.equals(((ForSplitAdvice)param3Object).exit))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (super.hashCode() * 31 + this.enter.hashCode()) * 31 + this.exit.hashCode();
/*       */         } }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class LazyDynamicType
/*       */         extends DynamicType.AbstractBase
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */         
/*       */         private final ClassFileLocator classFileLocator;
/*       */ 
/*       */         
/*       */         protected LazyDynamicType(TypeDescription typeDescription, ClassFileLocator classFileLocator) {
/*  3419 */           this.typeDescription = typeDescription;
/*  3420 */           this.classFileLocator = classFileLocator;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription getTypeDescription() {
/*  3427 */           return this.typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public byte[] getBytes() {
/*       */           try {
/*  3435 */             return this.classFileLocator.locate(this.typeDescription.getName()).resolve();
/*  3436 */           } catch (IOException exception) {
/*  3437 */             throw new IllegalStateException("Failed to resolve class file for " + this.typeDescription, exception);
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public List<? extends DynamicType> getAuxiliaries() {
/*  3445 */           return Collections.emptyList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public LoadedTypeInitializer getLoadedTypeInitializer() {
/*  3452 */           return (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.typeDescription.equals(((LazyDynamicType)param3Object).typeDescription) ? false : (!!this.classFileLocator.equals(((LazyDynamicType)param3Object).classFileLocator))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (super.hashCode() * 31 + this.typeDescription.hashCode()) * 31 + this.classFileLocator.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface PoolStrategy
/*       */   {
/*       */     TypePool typePool(ClassFileLocator param1ClassFileLocator, @MaybeNull ClassLoader param1ClassLoader);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypePool typePool(ClassFileLocator param1ClassFileLocator, @MaybeNull ClassLoader param1ClassLoader, String param1String);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Default
/*       */       implements PoolStrategy
/*       */     {
/*  3502 */       EXTENDED((String)TypePool.Default.ReaderMode.EXTENDED),
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3510 */       FAST((String)TypePool.Default.ReaderMode.FAST);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypePool.Default.ReaderMode readerMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Default(TypePool.Default.ReaderMode readerMode) {
/*  3523 */         this.readerMode = readerMode;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader) {
/*  3530 */         return (TypePool)new TypePool.LazyFacade((TypePool)new TypePool.Default.WithLazyResolution(TypePool.CacheProvider.Simple.withObjectType(), classFileLocator, this.readerMode));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  3539 */         return typePool(classFileLocator, classLoader);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ExtraLazy
/*       */       implements PoolStrategy
/*       */     {
/*  3562 */       EXTENDED((String)TypePool.Default.ReaderMode.EXTENDED),
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3570 */       FAST((String)TypePool.Default.ReaderMode.FAST);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypePool.Default.ReaderMode readerMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       ExtraLazy(TypePool.Default.ReaderMode readerMode) {
/*  3583 */         this.readerMode = readerMode;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader) {
/*  3590 */         return (TypePool)new TypePool.LazyFacade((TypePool)new TypePool.Default.WithLazyResolution(TypePool.CacheProvider.Simple.withObjectType(), classFileLocator, this.readerMode, TypePool.Default.WithLazyResolution.LazinessMode.EXTENDED));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  3600 */         return typePool(classFileLocator, classLoader);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Eager
/*       */       implements PoolStrategy
/*       */     {
/*  3621 */       EXTENDED((String)TypePool.Default.ReaderMode.EXTENDED),
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3629 */       FAST((String)TypePool.Default.ReaderMode.FAST);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypePool.Default.ReaderMode readerMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Eager(TypePool.Default.ReaderMode readerMode) {
/*  3642 */         this.readerMode = readerMode;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader) {
/*  3649 */         return (TypePool)new TypePool.Default(TypePool.CacheProvider.Simple.withObjectType(), classFileLocator, this.readerMode);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  3656 */         return typePool(classFileLocator, classLoader);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ClassLoading
/*       */       implements PoolStrategy
/*       */     {
/*  3678 */       EXTENDED((String)TypePool.Default.ReaderMode.EXTENDED),
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3686 */       FAST((String)TypePool.Default.ReaderMode.FAST);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypePool.Default.ReaderMode readerMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       ClassLoading(TypePool.Default.ReaderMode readerMode) {
/*  3699 */         this.readerMode = readerMode;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader) {
/*  3706 */         return TypePool.ClassLoading.of(classLoader, (TypePool)new TypePool.Default.WithLazyResolution(TypePool.CacheProvider.Simple.withObjectType(), classFileLocator, this.readerMode));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  3713 */         return typePool(classFileLocator, classLoader);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static abstract class WithTypePoolCache
/*       */       implements PoolStrategy
/*       */     {
/*       */       protected final TypePool.Default.ReaderMode readerMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final TypePool.Default.WithLazyResolution.LazinessMode lazinessMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected WithTypePoolCache(TypePool.Default.ReaderMode readerMode) {
/*  3747 */         this(readerMode, TypePool.Default.WithLazyResolution.LazinessMode.NAME);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected WithTypePoolCache(TypePool.Default.ReaderMode readerMode, TypePool.Default.WithLazyResolution.LazinessMode lazinessMode) {
/*  3757 */         this.readerMode = readerMode;
/*  3758 */         this.lazinessMode = lazinessMode;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader) {
/*  3765 */         return (TypePool)new TypePool.LazyFacade((TypePool)new TypePool.Default.WithLazyResolution(locate(classLoader), classFileLocator, this.readerMode, this.lazinessMode));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypePool typePool(ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  3772 */         return (TypePool)new TypePool.LazyFacade((TypePool)new TypePool.Default.WithLazyResolution((TypePool.CacheProvider)new TypePool.CacheProvider.Discriminating((ElementMatcher)ElementMatchers.is(name), (TypePool.CacheProvider)new TypePool.CacheProvider.Simple(), 
/*       */                 
/*  3774 */                 locate(classLoader)), classFileLocator, this.readerMode, this.lazinessMode));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract TypePool.CacheProvider locate(@MaybeNull ClassLoader param2ClassLoader);
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.readerMode.equals(((WithTypePoolCache)param2Object).readerMode) ? false : (!!this.lazinessMode.equals(((WithTypePoolCache)param2Object).lazinessMode)))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.readerMode.hashCode()) * 31 + this.lazinessMode.hashCode();
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Simple
/*       */         extends WithTypePoolCache
/*       */       {
/*  3796 */         private static final ClassLoader BOOTSTRAP_MARKER = doPrivileged(BootstrapMarkerAction.INSTANCE); private final ConcurrentMap<? super ClassLoader, TypePool.CacheProvider> cacheProviders; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*       */            }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Simple(ConcurrentMap<? super ClassLoader, TypePool.CacheProvider> cacheProviders) {
/*  3810 */           this(TypePool.Default.ReaderMode.FAST, cacheProviders);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Simple(TypePool.Default.ReaderMode readerMode, ConcurrentMap<? super ClassLoader, TypePool.CacheProvider> cacheProviders) {
/*  3820 */           super(readerMode);
/*  3821 */           this.cacheProviders = cacheProviders;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Simple(TypePool.Default.ReaderMode readerMode, TypePool.Default.WithLazyResolution.LazinessMode lazinessMode, ConcurrentMap<? super ClassLoader, TypePool.CacheProvider> cacheProviders) {
/*  3832 */           super(readerMode, lazinessMode);
/*  3833 */           this.cacheProviders = cacheProviders;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  3845 */           return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*       */         }
/*       */ 
/*       */         
/*       */         protected TypePool.CacheProvider locate(@MaybeNull ClassLoader classLoader) {
/*  3850 */           classLoader = (classLoader == null) ? getBootstrapMarkerLoader() : classLoader;
/*  3851 */           TypePool.CacheProvider cacheProvider = this.cacheProviders.get(classLoader);
/*  3852 */           while (cacheProvider == null) {
/*  3853 */             cacheProvider = TypePool.CacheProvider.Simple.withObjectType();
/*  3854 */             TypePool.CacheProvider previous = this.cacheProviders.putIfAbsent(classLoader, cacheProvider);
/*  3855 */             if (previous != null) {
/*  3856 */               cacheProvider = previous;
/*       */             }
/*       */           } 
/*  3859 */           return cacheProvider;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ClassLoader getBootstrapMarkerLoader() {
/*  3875 */           return BOOTSTRAP_MARKER;
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.cacheProviders.equals(((Simple)param3Object).cacheProviders)))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.cacheProviders.hashCode();
/*       */         }
/*       */         
/*  3886 */         protected enum BootstrapMarkerAction implements PrivilegedAction<ClassLoader> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ClassLoader run() {
/*  3892 */             return new URLClassLoader(new java.net.URL[0], ClassLoadingStrategy.BOOTSTRAP_LOADER);
/*       */           } }
/*       */       
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface InitializationStrategy
/*       */   {
/*       */     Dispatcher dispatcher();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Dispatcher
/*       */     {
/*       */       DynamicType.Builder<?> apply(DynamicType.Builder<?> param2Builder);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void register(DynamicType param2DynamicType, @MaybeNull ClassLoader param2ClassLoader, @MaybeNull ProtectionDomain param2ProtectionDomain, AgentBuilder.InjectionStrategy param2InjectionStrategy);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements InitializationStrategy, Dispatcher
/*       */     {
/*  3948 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.InitializationStrategy.Dispatcher dispatcher() {
/*  3954 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public DynamicType.Builder<?> apply(DynamicType.Builder<?> builder) {
/*  3961 */         return builder;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void register(DynamicType dynamicType, @MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, AgentBuilder.InjectionStrategy injectionStrategy) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Minimal
/*       */       implements InitializationStrategy, Dispatcher
/*       */     {
/*  3985 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.InitializationStrategy.Dispatcher dispatcher() {
/*  3991 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public DynamicType.Builder<?> apply(DynamicType.Builder<?> builder) {
/*  3998 */         return builder;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void register(DynamicType dynamicType, @MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, AgentBuilder.InjectionStrategy injectionStrategy) {
/*  4008 */         Set<TypeDescription> auxiliaryTypes = dynamicType.getAuxiliaryTypeDescriptions(), independentTypes = new LinkedHashSet<TypeDescription>(auxiliaryTypes);
/*  4009 */         for (TypeDescription auxiliaryType : auxiliaryTypes) {
/*  4010 */           if (!auxiliaryType.getDeclaredAnnotations().isAnnotationPresent(AuxiliaryType.SignatureRelevant.class)) {
/*  4011 */             independentTypes.remove(auxiliaryType);
/*       */           }
/*       */         } 
/*  4014 */         if (!independentTypes.isEmpty()) {
/*  4015 */           ClassInjector classInjector = injectionStrategy.resolve(classLoader, protectionDomain);
/*  4016 */           Map<TypeDescription, LoadedTypeInitializer> loadedTypeInitializers = dynamicType.getLoadedTypeInitializers();
/*  4017 */           for (Map.Entry<TypeDescription, Class<?>> entry : (Iterable<Map.Entry<TypeDescription, Class<?>>>)classInjector.inject(independentTypes, (ClassFileLocator)dynamicType).entrySet()) {
/*  4018 */             ((LoadedTypeInitializer)loadedTypeInitializers.get(entry.getKey())).onLoad(entry.getValue());
/*       */           }
/*       */         } 
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static abstract class SelfInjection
/*       */       implements InitializationStrategy
/*       */     {
/*       */       protected final NexusAccessor nexusAccessor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected SelfInjection(NexusAccessor nexusAccessor) {
/*  4042 */         this.nexusAccessor = nexusAccessor;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"DMI_RANDOM_USED_ONLY_ONCE"}, justification = "Avoids thread-contention.")
/*       */       public AgentBuilder.InitializationStrategy.Dispatcher dispatcher() {
/*  4050 */         return dispatcher((new Random()).nextInt());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract AgentBuilder.InitializationStrategy.Dispatcher dispatcher(int param2Int);
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.nexusAccessor.equals(((SelfInjection)param2Object).nexusAccessor))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.nexusAccessor.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static abstract class Dispatcher
/*       */         implements AgentBuilder.InitializationStrategy.Dispatcher
/*       */       {
/*       */         protected final NexusAccessor nexusAccessor;
/*       */ 
/*       */         
/*       */         protected final int identification;
/*       */ 
/*       */ 
/*       */         
/*       */         protected Dispatcher(NexusAccessor nexusAccessor, int identification) {
/*  4084 */           this.nexusAccessor = nexusAccessor;
/*  4085 */           this.identification = identification;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public DynamicType.Builder<?> apply(DynamicType.Builder<?> builder) {
/*  4092 */           return builder.initializer((ByteCodeAppender)new NexusAccessor.InitializationAppender(this.identification));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.identification != ((Dispatcher)param3Object).identification) ? false : (!!this.nexusAccessor.equals(((Dispatcher)param3Object).nexusAccessor)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.nexusAccessor.hashCode()) * 31 + this.identification;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class InjectingInitializer
/*       */           implements LoadedTypeInitializer
/*       */         {
/*       */           private final TypeDescription instrumentedType;
/*       */ 
/*       */ 
/*       */           
/*       */           private final Set<TypeDescription> auxiliaryTypes;
/*       */ 
/*       */ 
/*       */           
/*       */           private final ClassFileLocator classFileLocator;
/*       */ 
/*       */ 
/*       */           
/*       */           private final Map<TypeDescription, LoadedTypeInitializer> loadedTypeInitializers;
/*       */ 
/*       */ 
/*       */           
/*       */           private final ClassInjector classInjector;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected InjectingInitializer(TypeDescription instrumentedType, Set<TypeDescription> auxiliaryTypes, ClassFileLocator classFileLocator, Map<TypeDescription, LoadedTypeInitializer> loadedTypeInitializers, ClassInjector classInjector) {
/*  4141 */             this.instrumentedType = instrumentedType;
/*  4142 */             this.auxiliaryTypes = auxiliaryTypes;
/*  4143 */             this.classFileLocator = classFileLocator;
/*  4144 */             this.loadedTypeInitializers = loadedTypeInitializers;
/*  4145 */             this.classInjector = classInjector;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void onLoad(Class<?> type) {
/*  4152 */             for (Map.Entry<TypeDescription, Class<?>> auxiliary : (Iterable<Map.Entry<TypeDescription, Class<?>>>)this.classInjector.inject(this.auxiliaryTypes, this.classFileLocator).entrySet()) {
/*  4153 */               ((LoadedTypeInitializer)this.loadedTypeInitializers.get(auxiliary.getKey())).onLoad(auxiliary.getValue());
/*       */             }
/*  4155 */             ((LoadedTypeInitializer)this.loadedTypeInitializers.get(this.instrumentedType)).onLoad(type);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean isAlive() {
/*  4162 */             return true;
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.instrumentedType.equals(((InjectingInitializer)param4Object).instrumentedType) ? false : (!this.auxiliaryTypes.equals(((InjectingInitializer)param4Object).auxiliaryTypes) ? false : (!this.classFileLocator.equals(((InjectingInitializer)param4Object).classFileLocator) ? false : (!this.loadedTypeInitializers.equals(((InjectingInitializer)param4Object).loadedTypeInitializers) ? false : (!!this.classInjector.equals(((InjectingInitializer)param4Object).classInjector))))))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return ((((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.auxiliaryTypes.hashCode()) * 31 + this.classFileLocator.hashCode()) * 31 + this.loadedTypeInitializers.hashCode()) * 31 + this.classInjector.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */       public static class Split
/*       */         extends SelfInjection {
/*       */         public Split() {
/*  4178 */           this(new NexusAccessor());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Split(NexusAccessor nexusAccessor) {
/*  4187 */           super(nexusAccessor);
/*       */         }
/*       */ 
/*       */         
/*       */         protected AgentBuilder.InitializationStrategy.Dispatcher dispatcher(int identification) {
/*  4192 */           return new Dispatcher(this.nexusAccessor, identification);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class Dispatcher
/*       */           extends AgentBuilder.InitializationStrategy.SelfInjection.Dispatcher
/*       */         {
/*       */           protected Dispatcher(NexusAccessor nexusAccessor, int identification) {
/*  4207 */             super(nexusAccessor, identification);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void register(DynamicType dynamicType, @MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, AgentBuilder.InjectionStrategy injectionStrategy) {
/*       */             LoadedTypeInitializer loadedTypeInitializer;
/*  4217 */             Set<TypeDescription> auxiliaryTypes = dynamicType.getAuxiliaryTypeDescriptions();
/*       */             
/*  4219 */             if (!auxiliaryTypes.isEmpty()) {
/*  4220 */               TypeDescription instrumentedType = dynamicType.getTypeDescription();
/*  4221 */               ClassInjector classInjector = injectionStrategy.resolve(classLoader, protectionDomain);
/*  4222 */               Set<TypeDescription> independentTypes = new LinkedHashSet<TypeDescription>(auxiliaryTypes);
/*  4223 */               Set<TypeDescription> dependentTypes = new LinkedHashSet<TypeDescription>(auxiliaryTypes);
/*  4224 */               for (TypeDescription auxiliaryType : auxiliaryTypes) {
/*  4225 */                 (auxiliaryType.getDeclaredAnnotations().isAnnotationPresent(AuxiliaryType.SignatureRelevant.class) ? dependentTypes : independentTypes)
/*       */                   
/*  4227 */                   .remove(auxiliaryType);
/*       */               }
/*  4229 */               Map<TypeDescription, LoadedTypeInitializer> loadedTypeInitializers = dynamicType.getLoadedTypeInitializers();
/*  4230 */               if (!independentTypes.isEmpty()) {
/*  4231 */                 for (Map.Entry<TypeDescription, Class<?>> entry : (Iterable<Map.Entry<TypeDescription, Class<?>>>)classInjector.inject(independentTypes, (ClassFileLocator)dynamicType).entrySet()) {
/*  4232 */                   ((LoadedTypeInitializer)loadedTypeInitializers.get(entry.getKey())).onLoad(entry.getValue());
/*       */                 }
/*       */               }
/*  4235 */               Map<TypeDescription, LoadedTypeInitializer> lazyInitializers = new HashMap<TypeDescription, LoadedTypeInitializer>(loadedTypeInitializers);
/*  4236 */               loadedTypeInitializers.keySet().removeAll(independentTypes);
/*       */ 
/*       */               
/*  4239 */               loadedTypeInitializer = (lazyInitializers.size() > 1) ? new AgentBuilder.InitializationStrategy.SelfInjection.Dispatcher.InjectingInitializer(instrumentedType, dependentTypes, (ClassFileLocator)dynamicType, lazyInitializers, classInjector) : lazyInitializers.get(instrumentedType);
/*       */             } else {
/*  4241 */               loadedTypeInitializer = (LoadedTypeInitializer)dynamicType.getLoadedTypeInitializers().get(dynamicType.getTypeDescription());
/*       */             } 
/*  4243 */             this.nexusAccessor.register(dynamicType.getTypeDescription().getName(), classLoader, this.identification, loadedTypeInitializer);
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Lazy
/*       */         extends SelfInjection
/*       */       {
/*       */         public Lazy() {
/*  4257 */           this(new NexusAccessor());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Lazy(NexusAccessor nexusAccessor) {
/*  4266 */           super(nexusAccessor);
/*       */         }
/*       */ 
/*       */         
/*       */         protected AgentBuilder.InitializationStrategy.Dispatcher dispatcher(int identification) {
/*  4271 */           return new Dispatcher(this.nexusAccessor, identification);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class Dispatcher
/*       */           extends AgentBuilder.InitializationStrategy.SelfInjection.Dispatcher
/*       */         {
/*       */           protected Dispatcher(NexusAccessor nexusAccessor, int identification) {
/*  4286 */             super(nexusAccessor, identification);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void register(DynamicType dynamicType, @MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, AgentBuilder.InjectionStrategy injectionStrategy) {
/*  4296 */             Set<TypeDescription> auxiliaryTypes = dynamicType.getAuxiliaryTypeDescriptions();
/*       */ 
/*       */             
/*  4299 */             LoadedTypeInitializer loadedTypeInitializer = auxiliaryTypes.isEmpty() ? (LoadedTypeInitializer)dynamicType.getLoadedTypeInitializers().get(dynamicType.getTypeDescription()) : new AgentBuilder.InitializationStrategy.SelfInjection.Dispatcher.InjectingInitializer(dynamicType.getTypeDescription(), auxiliaryTypes, (ClassFileLocator)dynamicType, dynamicType.getLoadedTypeInitializers(), injectionStrategy.resolve(classLoader, protectionDomain));
/*  4300 */             this.nexusAccessor.register(dynamicType.getTypeDescription().getName(), classLoader, this.identification, loadedTypeInitializer);
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static class Eager
/*       */         extends SelfInjection
/*       */       {
/*       */         public Eager() {
/*  4314 */           this(new NexusAccessor());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Eager(NexusAccessor nexusAccessor) {
/*  4323 */           super(nexusAccessor);
/*       */         }
/*       */ 
/*       */         
/*       */         protected AgentBuilder.InitializationStrategy.Dispatcher dispatcher(int identification) {
/*  4328 */           return new Dispatcher(this.nexusAccessor, identification);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class Dispatcher
/*       */           extends AgentBuilder.InitializationStrategy.SelfInjection.Dispatcher
/*       */         {
/*       */           protected Dispatcher(NexusAccessor nexusAccessor, int identification) {
/*  4343 */             super(nexusAccessor, identification);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void register(DynamicType dynamicType, @MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, AgentBuilder.InjectionStrategy injectionStrategy) {
/*  4353 */             Set<TypeDescription> auxiliaryTypes = dynamicType.getAuxiliaryTypeDescriptions();
/*  4354 */             Map<TypeDescription, LoadedTypeInitializer> loadedTypeInitializers = dynamicType.getLoadedTypeInitializers();
/*  4355 */             if (!auxiliaryTypes.isEmpty()) {
/*  4356 */               for (Map.Entry<TypeDescription, Class<?>> entry : (Iterable<Map.Entry<TypeDescription, Class<?>>>)injectionStrategy.resolve(classLoader, protectionDomain).inject(auxiliaryTypes, (ClassFileLocator)dynamicType).entrySet()) {
/*  4357 */                 ((LoadedTypeInitializer)loadedTypeInitializers.get(entry.getKey())).onLoad(entry.getValue());
/*       */               }
/*       */             }
/*  4360 */             LoadedTypeInitializer loadedTypeInitializer = loadedTypeInitializers.get(dynamicType.getTypeDescription());
/*  4361 */             this.nexusAccessor.register(dynamicType.getTypeDescription().getName(), classLoader, this.identification, loadedTypeInitializer);
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface InjectionStrategy
/*       */   {
/*       */     ClassInjector resolve(@MaybeNull ClassLoader param1ClassLoader, @MaybeNull ProtectionDomain param1ProtectionDomain);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Disabled
/*       */       implements InjectionStrategy
/*       */     {
/*  4390 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassInjector resolve(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  4396 */         throw new IllegalStateException("Class injection is disabled");
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum UsingReflection
/*       */       implements InjectionStrategy
/*       */     {
/*  4408 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassInjector resolve(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  4414 */         if (classLoader == null)
/*  4415 */           throw new IllegalStateException("Cannot inject auxiliary class into bootstrap loader using reflection"); 
/*  4416 */         if (ClassInjector.UsingReflection.isAvailable()) {
/*  4417 */           return (ClassInjector)new ClassInjector.UsingReflection(classLoader, protectionDomain);
/*       */         }
/*  4419 */         throw new IllegalStateException("Reflection-based injection is not available on the current VM");
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum UsingUnsafe
/*       */       implements InjectionStrategy
/*       */     {
/*  4432 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassInjector resolve(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  4438 */         if (ClassInjector.UsingUnsafe.isAvailable()) {
/*  4439 */           return (ClassInjector)new ClassInjector.UsingUnsafe(classLoader, protectionDomain);
/*       */         }
/*  4441 */         throw new IllegalStateException("Unsafe-based injection is not available on the current VM");
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class OfFactory
/*       */         implements AgentBuilder.InjectionStrategy
/*       */       {
/*       */         private final ClassInjector.UsingUnsafe.Factory factory;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public OfFactory(ClassInjector.UsingUnsafe.Factory factory) {
/*  4462 */           this.factory = factory;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ClassInjector resolve(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  4469 */           return this.factory.make(classLoader, protectionDomain);
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.factory.equals(((OfFactory)param3Object).factory))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.factory.hashCode();
/*       */         } }
/*       */     }
/*       */     
/*       */     public enum UsingJna implements InjectionStrategy {
/*  4482 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassInjector resolve(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  4488 */         if (ClassInjector.UsingJna.isAvailable()) {
/*  4489 */           return (ClassInjector)new ClassInjector.UsingJna(classLoader, protectionDomain);
/*       */         }
/*  4491 */         throw new IllegalStateException("JNA-based injection is not available on the current VM");
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class UsingInstrumentation
/*       */       implements InjectionStrategy
/*       */     {
/*       */       private final Instrumentation instrumentation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final File folder;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public UsingInstrumentation(Instrumentation instrumentation, File folder) {
/*  4519 */         this.instrumentation = instrumentation;
/*  4520 */         this.folder = folder;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassInjector resolve(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  4527 */         return (classLoader == null) ? 
/*  4528 */           ClassInjector.UsingInstrumentation.of(this.folder, ClassInjector.UsingInstrumentation.Target.BOOTSTRAP, this.instrumentation) : AgentBuilder.InjectionStrategy.UsingReflection.INSTANCE
/*  4529 */           .resolve(classLoader, protectionDomain);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.instrumentation.equals(((UsingInstrumentation)param2Object).instrumentation) ? false : (!!this.folder.equals(((UsingInstrumentation)param2Object).folder)))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.folder.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface DescriptionStrategy
/*       */   {
/*       */     boolean isLoadedFirst();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypeDescription apply(String param1String, @MaybeNull Class<?> param1Class, TypePool param1TypePool, AgentBuilder.CircularityLock param1CircularityLock, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Default
/*       */       implements DescriptionStrategy
/*       */     {
/*  4577 */       HYBRID(true)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription apply(String name, @MaybeNull Class<?> type, TypePool typePool, AgentBuilder.CircularityLock circularityLock, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module)
/*       */         {
/*  4585 */           return (type == null) ? typePool
/*  4586 */             .describe(name).resolve() : 
/*  4587 */             TypeDescription.ForLoadedType.of(type);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4604 */       POOL_ONLY(false)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription apply(String name, @MaybeNull Class<?> type, TypePool typePool, AgentBuilder.CircularityLock circularityLock, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module)
/*       */         {
/*  4612 */           return typePool.describe(name).resolve();
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  4628 */       POOL_FIRST(false)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription apply(String name, @MaybeNull Class<?> type, TypePool typePool, AgentBuilder.CircularityLock circularityLock, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module)
/*       */         {
/*  4636 */           TypePool.Resolution resolution = typePool.describe(name);
/*  4637 */           return (resolution.isResolved() || type == null) ? resolution
/*  4638 */             .resolve() : 
/*  4639 */             TypeDescription.ForLoadedType.of(type);
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean loadedFirst;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Default(boolean loadedFirst) {
/*  4654 */         this.loadedFirst = loadedFirst;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.DescriptionStrategy withSuperTypeLoading() {
/*  4666 */         return new AgentBuilder.DescriptionStrategy.SuperTypeLoading(this);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isLoadedFirst() {
/*  4673 */         return this.loadedFirst;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.DescriptionStrategy withSuperTypeLoading(ExecutorService executorService) {
/*  4687 */         return new AgentBuilder.DescriptionStrategy.SuperTypeLoading.Asynchronous(this, executorService);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class SuperTypeLoading
/*       */       implements DescriptionStrategy
/*       */     {
/*       */       private final AgentBuilder.DescriptionStrategy delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public SuperTypeLoading(AgentBuilder.DescriptionStrategy delegate) {
/*  4715 */         this.delegate = delegate;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isLoadedFirst() {
/*  4722 */         return this.delegate.isLoadedFirst();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription apply(String name, @MaybeNull Class<?> type, TypePool typePool, AgentBuilder.CircularityLock circularityLock, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  4734 */         TypeDescription typeDescription = this.delegate.apply(name, type, typePool, circularityLock, classLoader, module);
/*  4735 */         return (typeDescription instanceof TypeDescription.ForLoadedType) ? typeDescription : (TypeDescription)new TypeDescription.SuperTypeLoading(typeDescription, classLoader, new UnlockingClassLoadingDelegate(circularityLock));
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.delegate.equals(((SuperTypeLoading)param2Object).delegate))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.delegate.hashCode();
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class UnlockingClassLoadingDelegate
/*       */         implements TypeDescription.SuperTypeLoading.ClassLoadingDelegate
/*       */       {
/*       */         private final AgentBuilder.CircularityLock circularityLock;
/*       */ 
/*       */         
/*       */         protected UnlockingClassLoadingDelegate(AgentBuilder.CircularityLock circularityLock) {
/*  4757 */           this.circularityLock = circularityLock;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<?> load(String name, @MaybeNull ClassLoader classLoader) throws ClassNotFoundException {
/*  4764 */           this.circularityLock.release();
/*       */           try {
/*  4766 */             return Class.forName(name, false, classLoader);
/*       */           } finally {
/*  4768 */             this.circularityLock.acquire();
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.circularityLock.equals(((UnlockingClassLoadingDelegate)param3Object).circularityLock))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.circularityLock.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Asynchronous
/*       */         implements AgentBuilder.DescriptionStrategy
/*       */       {
/*       */         private final AgentBuilder.DescriptionStrategy delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final ExecutorService executorService;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Asynchronous(AgentBuilder.DescriptionStrategy delegate, ExecutorService executorService) {
/*  4823 */           this.delegate = delegate;
/*  4824 */           this.executorService = executorService;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isLoadedFirst() {
/*  4831 */           return this.delegate.isLoadedFirst();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypeDescription apply(String name, @MaybeNull Class<?> type, TypePool typePool, AgentBuilder.CircularityLock circularityLock, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  4843 */           TypeDescription typeDescription = this.delegate.apply(name, type, typePool, circularityLock, classLoader, module);
/*  4844 */           return (typeDescription instanceof TypeDescription.ForLoadedType) ? typeDescription : (TypeDescription)new TypeDescription.SuperTypeLoading(typeDescription, classLoader, new ThreadSwitchingClassLoadingDelegate(this.executorService));
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.delegate.equals(((Asynchronous)param3Object).delegate) ? false : (!!this.executorService.equals(((Asynchronous)param3Object).executorService)))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.delegate.hashCode()) * 31 + this.executorService.hashCode();
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class ThreadSwitchingClassLoadingDelegate
/*       */           implements TypeDescription.SuperTypeLoading.ClassLoadingDelegate
/*       */         {
/*       */           private final ExecutorService executorService;
/*       */ 
/*       */           
/*       */           protected ThreadSwitchingClassLoadingDelegate(ExecutorService executorService) {
/*  4866 */             this.executorService = executorService;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<?> load(String name, @MaybeNull ClassLoader classLoader) {
/*  4873 */             boolean holdsLock = (classLoader != null && Thread.holdsLock(classLoader));
/*  4874 */             AtomicBoolean signal = new AtomicBoolean(holdsLock);
/*  4875 */             Future<Class<?>> future = this.executorService.submit(holdsLock ? new NotifyingClassLoadingAction(name, classLoader, signal) : new SimpleClassLoadingAction(name, classLoader));
/*       */ 
/*       */             
/*       */             try {
/*  4879 */               while (holdsLock && signal.get()) {
/*  4880 */                 classLoader.wait();
/*       */               }
/*  4882 */               return future.get();
/*  4883 */             } catch (ExecutionException exception) {
/*  4884 */               throw new IllegalStateException("Could not load " + name + " asynchronously", exception.getCause());
/*  4885 */             } catch (Exception exception) {
/*  4886 */               throw new IllegalStateException("Could not load " + name + " asynchronously", exception);
/*       */             } 
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.executorService.equals(((ThreadSwitchingClassLoadingDelegate)param4Object).executorService))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.executorService.hashCode();
/*       */           }
/*       */ 
/*       */           
/*       */           @Enhance
/*       */           protected static class SimpleClassLoadingAction
/*       */             implements Callable<Class<?>>
/*       */           {
/*       */             private final String name;
/*       */             
/*       */             @MaybeNull
/*       */             @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */             private final ClassLoader classLoader;
/*       */ 
/*       */             
/*       */             protected SimpleClassLoadingAction(String name, @MaybeNull ClassLoader classLoader) {
/*  4915 */               this.name = name;
/*  4916 */               this.classLoader = classLoader;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public Class<?> call() throws ClassNotFoundException {
/*  4923 */               return Class.forName(this.name, false, this.classLoader);
/*       */             }
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               if (this == param5Object)
/*       */                 return true; 
/*       */               if (param5Object == null)
/*       */                 return false; 
/*       */               if (getClass() != param5Object.getClass())
/*       */                 return false; 
/*       */               if (!this.name.equals(((SimpleClassLoadingAction)param5Object).name))
/*       */                 return false; 
/*       */               ClassLoader classLoader1 = ((SimpleClassLoadingAction)param5Object).classLoader;
/*       */               ClassLoader classLoader2 = this.classLoader;
/*       */               if (classLoader1 != null) {
/*       */                 if (classLoader2 != null) {
/*       */                   if (!classLoader2.equals(classLoader1))
/*       */                     return false; 
/*       */                 } else {
/*       */                   return false;
/*       */                 } 
/*       */               } else if (classLoader2 != null) {
/*       */                 return false;
/*       */               } 
/*       */               return true;
/*       */             }
/*       */             public int hashCode() {
/*       */               ClassLoader classLoader = this.classLoader;
/*       */               if (classLoader != null);
/*       */               return (getClass().hashCode() * 31 + this.name.hashCode()) * 31 + classLoader.hashCode();
/*       */             } }
/*       */           @Enhance
/*       */           protected static class NotifyingClassLoadingAction implements Callable<Class<?>> { private final String name; private final ClassLoader classLoader; private final AtomicBoolean signal;
/*       */             protected NotifyingClassLoadingAction(String name, ClassLoader classLoader, AtomicBoolean signal) {
/*  4956 */               this.name = name;
/*  4957 */               this.classLoader = classLoader;
/*  4958 */               this.signal = signal;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public Class<?> call() throws ClassNotFoundException {
/*  4965 */               synchronized (this.classLoader) {
/*       */                 try {
/*  4967 */                   return Class.forName(this.name, false, this.classLoader);
/*       */                 } finally {
/*  4969 */                   this.signal.set(false);
/*  4970 */                   this.classLoader.notifyAll();
/*       */                 } 
/*       */               } 
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.name.equals(((NotifyingClassLoadingAction)param5Object).name) ? false : (!this.classLoader.equals(((NotifyingClassLoadingAction)param5Object).classLoader) ? false : (!!this.signal.equals(((NotifyingClassLoadingAction)param5Object).signal))))));
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public int hashCode() {
/*       */               return ((getClass().hashCode() * 31 + this.name.hashCode()) * 31 + this.classLoader.hashCode()) * 31 + this.signal.hashCode();
/*       */             } }
/*       */         
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface LocationStrategy
/*       */   {
/*       */     ClassFileLocator classFileLocator(@MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule);
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements LocationStrategy
/*       */     {
/*  5002 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassFileLocator classFileLocator(@MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  5008 */         return (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForClassLoader
/*       */       implements LocationStrategy
/*       */     {
/*  5020 */       STRONG
/*       */       {
/*       */         public ClassFileLocator classFileLocator(@MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  5023 */           return ClassFileLocator.ForClassLoader.of(classLoader);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5031 */       WEAK
/*       */       {
/*       */         public ClassFileLocator classFileLocator(@MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  5034 */           return ClassFileLocator.ForClassLoader.WeaklyReferenced.of(classLoader);
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.LocationStrategy withFallbackTo(ClassFileLocator... classFileLocator) {
/*  5045 */         return withFallbackTo(Arrays.asList(classFileLocator));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.LocationStrategy withFallbackTo(Collection<? extends ClassFileLocator> classFileLocators) {
/*  5055 */         List<AgentBuilder.LocationStrategy> locationStrategies = new ArrayList<AgentBuilder.LocationStrategy>(classFileLocators.size());
/*  5056 */         for (ClassFileLocator classFileLocator : classFileLocators) {
/*  5057 */           locationStrategies.add(new AgentBuilder.LocationStrategy.Simple(classFileLocator));
/*       */         }
/*  5059 */         return withFallbackTo(locationStrategies);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.LocationStrategy withFallbackTo(AgentBuilder.LocationStrategy... locationStrategy) {
/*  5070 */         return withFallbackTo(Arrays.asList(locationStrategy));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.LocationStrategy withFallbackTo(List<? extends AgentBuilder.LocationStrategy> locationStrategies) {
/*  5081 */         List<AgentBuilder.LocationStrategy> allLocationStrategies = new ArrayList<AgentBuilder.LocationStrategy>(locationStrategies.size() + 1);
/*  5082 */         allLocationStrategies.add(this);
/*  5083 */         allLocationStrategies.addAll(locationStrategies);
/*  5084 */         return new AgentBuilder.LocationStrategy.Compound(allLocationStrategies);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Simple
/*       */       implements LocationStrategy
/*       */     {
/*       */       private final ClassFileLocator classFileLocator;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Simple(ClassFileLocator classFileLocator) {
/*  5105 */         this.classFileLocator = classFileLocator;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassFileLocator classFileLocator(@MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  5112 */         return this.classFileLocator;
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.classFileLocator.equals(((Simple)param2Object).classFileLocator))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.classFileLocator.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Compound
/*       */       implements LocationStrategy
/*       */     {
/*       */       public Compound(AgentBuilder.LocationStrategy... locationStrategy) {
/*  5133 */         this(Arrays.asList(locationStrategy));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5142 */       private final List<AgentBuilder.LocationStrategy> locationStrategies = new ArrayList<AgentBuilder.LocationStrategy>(); public Compound(List<? extends AgentBuilder.LocationStrategy> locationStrategies) {
/*  5143 */         for (AgentBuilder.LocationStrategy locationStrategy : locationStrategies) {
/*  5144 */           if (locationStrategy instanceof Compound) {
/*  5145 */             this.locationStrategies.addAll(((Compound)locationStrategy).locationStrategies); continue;
/*  5146 */           }  if (!(locationStrategy instanceof AgentBuilder.LocationStrategy.NoOp)) {
/*  5147 */             this.locationStrategies.add(locationStrategy);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassFileLocator classFileLocator(@MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module) {
/*  5156 */         List<ClassFileLocator> classFileLocators = new ArrayList<ClassFileLocator>(this.locationStrategies.size());
/*  5157 */         for (AgentBuilder.LocationStrategy locationStrategy : this.locationStrategies) {
/*  5158 */           classFileLocators.add(locationStrategy.classFileLocator(classLoader, module));
/*       */         }
/*  5160 */         return (ClassFileLocator)new ClassFileLocator.Compound(classFileLocators);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.locationStrategies.equals(((Compound)param2Object).locationStrategies))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.locationStrategies.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface FallbackStrategy
/*       */   {
/*       */     boolean isFallback(Class<?> param1Class, Throwable param1Throwable);
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Simple
/*       */       implements FallbackStrategy
/*       */     {
/*  5191 */       ENABLED(true),
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5196 */       DISABLED(false);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean enabled;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Simple(boolean enabled) {
/*  5209 */         this.enabled = enabled;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isFallback(Class<?> type, Throwable throwable) {
/*  5216 */         return this.enabled;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ByThrowableType
/*       */       implements FallbackStrategy
/*       */     {
/*       */       private final Set<? extends Class<? extends Throwable>> types;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       @SafeVarargs
/*       */       public ByThrowableType(Class<? extends Throwable>... type) {
/*  5239 */         this(new HashSet<Class<? extends Throwable>>(Arrays.asList(type)));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ByThrowableType(Set<? extends Class<? extends Throwable>> types) {
/*  5248 */         this.types = types;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static AgentBuilder.FallbackStrategy ofOptionalTypes() {
/*  5258 */         return new ByThrowableType((Class<? extends Throwable>[])new Class[] { LinkageError.class, TypeNotPresentException.class });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isFallback(Class<?> type, Throwable throwable) {
/*  5265 */         for (Class<? extends Throwable> aType : this.types) {
/*  5266 */           if (aType.isInstance(throwable)) {
/*  5267 */             return true;
/*       */           }
/*       */         } 
/*  5270 */         return false;
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.types.equals(((ByThrowableType)param2Object).types))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.types.hashCode();
/*       */       } }
/*       */   }
/*       */   
/*       */   public static interface InstallationListener {
/*       */     @AlwaysNull
/*  5284 */     public static final Throwable SUPPRESS_ERROR = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onBeforeInstall(Instrumentation param1Instrumentation, ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onInstall(Instrumentation param1Instrumentation, ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @MaybeNull
/*       */     Throwable onError(Instrumentation param1Instrumentation, ResettableClassFileTransformer param1ResettableClassFileTransformer, Throwable param1Throwable);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onReset(Instrumentation param1Instrumentation, ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onBeforeWarmUp(Set<Class<?>> param1Set, ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onWarmUpError(Class<?> param1Class, ResettableClassFileTransformer param1ResettableClassFileTransformer, Throwable param1Throwable);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void onAfterWarmUp(Map<Class<?>, byte[]> param1Map, ResettableClassFileTransformer param1ResettableClassFileTransformer, boolean param1Boolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements InstallationListener
/*       */     {
/*  5358 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Throwable onError(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5378 */         return throwable;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onReset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeWarmUp(Set<Class<?>> types, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onWarmUpError(Class<?> type, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onAfterWarmUp(Map<Class<?>, byte[]> types, ResettableClassFileTransformer classFileTransformer, boolean transformed) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ErrorSuppressing
/*       */       implements InstallationListener
/*       */     {
/*  5418 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public Throwable onError(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5439 */         return SUPPRESS_ERROR;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onReset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeWarmUp(Set<Class<?>> types, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onWarmUpError(Class<?> type, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onAfterWarmUp(Map<Class<?>, byte[]> types, ResettableClassFileTransformer classFileTransformer, boolean transformed) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class Adapter
/*       */       implements InstallationListener
/*       */     {
/*       */       public void onBeforeInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Throwable onError(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5494 */         return throwable;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onReset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeWarmUp(Set<Class<?>> types, ResettableClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onWarmUpError(Class<?> type, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onAfterWarmUp(Map<Class<?>, byte[]> types, ResettableClassFileTransformer classFileTransformer, boolean transformed) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class StreamWriting
/*       */       implements InstallationListener
/*       */     {
/*       */       protected static final String PREFIX = "[Byte Buddy]";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final PrintStream printStream;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StreamWriting(PrintStream printStream) {
/*  5548 */         this.printStream = printStream;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static AgentBuilder.InstallationListener toSystemOut() {
/*  5557 */         return new StreamWriting(System.out);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static AgentBuilder.InstallationListener toSystemError() {
/*  5566 */         return new StreamWriting(System.err);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  5573 */         this.printStream.printf("[Byte Buddy] BEFORE_INSTALL %s on %s%n", new Object[] { classFileTransformer, instrumentation });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  5580 */         this.printStream.printf("[Byte Buddy] INSTALL %s on %s%n", new Object[] { classFileTransformer, instrumentation });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Throwable onError(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5587 */         synchronized (this.printStream) {
/*  5588 */           this.printStream.printf("[Byte Buddy] ERROR %s on %s%n", new Object[] { classFileTransformer, instrumentation });
/*  5589 */           throwable.printStackTrace(this.printStream);
/*       */         } 
/*  5591 */         return throwable;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onReset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  5598 */         this.printStream.printf("[Byte Buddy] RESET %s on %s%n", new Object[] { classFileTransformer, instrumentation });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeWarmUp(Set<Class<?>> types, ResettableClassFileTransformer classFileTransformer) {
/*  5605 */         this.printStream.printf("[Byte Buddy] BEFORE_WARMUP %s on %s%n", new Object[] { classFileTransformer, types });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onWarmUpError(Class<?> type, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5612 */         synchronized (this.printStream) {
/*  5613 */           this.printStream.printf("[Byte Buddy] ERROR_WARMUP %s on %s%n", new Object[] { classFileTransformer, type });
/*  5614 */           throwable.printStackTrace(this.printStream);
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onAfterWarmUp(Map<Class<?>, byte[]> types, ResettableClassFileTransformer classFileTransformer, boolean transformed) {
/*  5622 */         this.printStream.printf("[Byte Buddy] AFTER_WARMUP %s %s on %s%n", new Object[] { transformed ? "transformed" : "not transformed", classFileTransformer, types.keySet() });
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.printStream.equals(((StreamWriting)param2Object).printStream))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.printStream.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Compound
/*       */       implements InstallationListener
/*       */     {
/*       */       public Compound(AgentBuilder.InstallationListener... installationListener) {
/*  5643 */         this(Arrays.asList(installationListener));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5652 */       private final List<AgentBuilder.InstallationListener> installationListeners = new ArrayList<AgentBuilder.InstallationListener>(); public Compound(List<? extends AgentBuilder.InstallationListener> installationListeners) {
/*  5653 */         for (AgentBuilder.InstallationListener installationListener : installationListeners) {
/*  5654 */           if (installationListener instanceof Compound) {
/*  5655 */             this.installationListeners.addAll(((Compound)installationListener).installationListeners); continue;
/*  5656 */           }  if (!(installationListener instanceof AgentBuilder.InstallationListener.NoOp)) {
/*  5657 */             this.installationListeners.add(installationListener);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  5666 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5667 */           installationListener.onBeforeInstall(instrumentation, classFileTransformer);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  5675 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5676 */           installationListener.onInstall(instrumentation, classFileTransformer);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public Throwable onError(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5685 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5686 */           if (throwable == SUPPRESS_ERROR) {
/*  5687 */             return SUPPRESS_ERROR;
/*       */           }
/*  5689 */           throwable = installationListener.onError(instrumentation, classFileTransformer, throwable);
/*       */         } 
/*  5691 */         return throwable;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onReset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  5698 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5699 */           installationListener.onReset(instrumentation, classFileTransformer);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onBeforeWarmUp(Set<Class<?>> types, ResettableClassFileTransformer classFileTransformer) {
/*  5707 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5708 */           installationListener.onBeforeWarmUp(types, classFileTransformer);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onWarmUpError(Class<?> type, ResettableClassFileTransformer classFileTransformer, Throwable throwable) {
/*  5716 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5717 */           installationListener.onWarmUpError(type, classFileTransformer, throwable);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void onAfterWarmUp(Map<Class<?>, byte[]> types, ResettableClassFileTransformer classFileTransformer, boolean transformed) {
/*  5725 */         for (AgentBuilder.InstallationListener installationListener : this.installationListeners) {
/*  5726 */           installationListener.onAfterWarmUp(types, classFileTransformer, transformed);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.installationListeners.equals(((Compound)param2Object).installationListeners))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.installationListeners.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface ClassFileBufferStrategy
/*       */   {
/*       */     ClassFileLocator resolve(String param1String, byte[] param1ArrayOfbyte, @MaybeNull ClassLoader param1ClassLoader, @MaybeNull JavaModule param1JavaModule, @MaybeNull ProtectionDomain param1ProtectionDomain);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypePool typePool(AgentBuilder.PoolStrategy param1PoolStrategy, ClassFileLocator param1ClassFileLocator, @MaybeNull ClassLoader param1ClassLoader, String param1String);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Default
/*       */       implements ClassFileBufferStrategy
/*       */     {
/*  5772 */       RETAINING
/*       */       {
/*       */ 
/*       */ 
/*       */         
/*       */         public ClassFileLocator resolve(String name, byte[] binaryRepresentation, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain)
/*       */         {
/*  5779 */           return ClassFileLocator.Simple.of(name, binaryRepresentation);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypePool typePool(AgentBuilder.PoolStrategy poolStrategy, ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  5787 */           return poolStrategy.typePool(classFileLocator, classLoader, name);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5799 */       DISCARDING
/*       */       {
/*       */ 
/*       */ 
/*       */         
/*       */         public ClassFileLocator resolve(String name, byte[] binaryRepresentation, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull ProtectionDomain protectionDomain)
/*       */         {
/*  5806 */           return (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public TypePool typePool(AgentBuilder.PoolStrategy poolStrategy, ClassFileLocator classFileLocator, @MaybeNull ClassLoader classLoader, String name) {
/*  5814 */           return poolStrategy.typePool(classFileLocator, classLoader);
/*       */         }
/*       */       };
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface TransformerDecorator
/*       */   {
/*       */     ResettableClassFileTransformer decorate(ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements TransformerDecorator
/*       */     {
/*  5841 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer decorate(ResettableClassFileTransformer classFileTransformer) {
/*  5847 */         return classFileTransformer;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForSubstitution
/*       */       implements TransformerDecorator
/*       */     {
/*  5859 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer decorate(ResettableClassFileTransformer classFileTransformer) {
/*  5865 */         return ResettableClassFileTransformer.WithDelegation.Substitutable.of(classFileTransformer);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Compound
/*       */       implements TransformerDecorator
/*       */     {
/*       */       public Compound(AgentBuilder.TransformerDecorator... transformerDecorator) {
/*  5886 */         this(Arrays.asList(transformerDecorator));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5895 */       private final List<AgentBuilder.TransformerDecorator> transformerDecorators = new ArrayList<AgentBuilder.TransformerDecorator>(); public Compound(List<? extends AgentBuilder.TransformerDecorator> transformerDecorators) {
/*  5896 */         for (AgentBuilder.TransformerDecorator transformerDecorator : transformerDecorators) {
/*  5897 */           if (transformerDecorator instanceof Compound) {
/*  5898 */             this.transformerDecorators.addAll(((Compound)transformerDecorator).transformerDecorators); continue;
/*  5899 */           }  if (!(transformerDecorator instanceof AgentBuilder.TransformerDecorator.NoOp)) {
/*  5900 */             this.transformerDecorators.add(transformerDecorator);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer decorate(ResettableClassFileTransformer classFileTransformer) {
/*  5909 */         for (AgentBuilder.TransformerDecorator transformerDecorator : this.transformerDecorators) {
/*  5910 */           classFileTransformer = transformerDecorator.decorate(classFileTransformer);
/*       */         }
/*  5912 */         return classFileTransformer;
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.transformerDecorators.equals(((Compound)param2Object).transformerDecorators))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.transformerDecorators.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */   
/*       */   public enum RedefinitionStrategy
/*       */   {
/*  5932 */     DISABLED(false, false)
/*       */     {
/*       */       public void apply(Instrumentation instrumentation, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, DiscoveryStrategy discoveryStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.Listener listener, Listener redefinitionListener, AgentBuilder.RawMatcher matcher, BatchAllocator redefinitionBatchAllocator, AgentBuilder.CircularityLock circularityLock) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void check(Instrumentation instrumentation) {
/*  5942 */         throw new IllegalStateException("Cannot apply redefinition on disabled strategy");
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Collector make(AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.Listener listener, AgentBuilder.RawMatcher matcher, AgentBuilder.CircularityLock circularityLock) {
/*  5953 */         throw new IllegalStateException("A disabled redefinition strategy cannot create a collector");
/*       */       }
/*       */     },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  5973 */     REDEFINITION(true, false)
/*       */     {
/*       */       protected void check(Instrumentation instrumentation) {
/*  5976 */         if (!instrumentation.isRedefineClassesSupported()) {
/*  5977 */           throw new IllegalStateException("Cannot apply redefinition on " + instrumentation);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Collector make(AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.Listener listener, AgentBuilder.RawMatcher matcher, AgentBuilder.CircularityLock circularityLock) {
/*  5989 */         return new Collector.ForRedefinition(matcher, poolStrategy, locationStrategy, descriptionStrategy, listener, fallbackStrategy, circularityLock);
/*       */       }
/*       */     },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  6015 */     RETRANSFORMATION(true, true)
/*       */     {
/*       */       protected void check(Instrumentation instrumentation) {
/*  6018 */         if (!DISPATCHER.isRetransformClassesSupported(instrumentation)) {
/*  6019 */           throw new IllegalStateException("Cannot apply retransformation on " + instrumentation);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Collector make(AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.Listener listener, AgentBuilder.RawMatcher matcher, AgentBuilder.CircularityLock circularityLock) {
/*  6031 */         return new Collector.ForRetransformation(matcher, poolStrategy, locationStrategy, descriptionStrategy, listener, fallbackStrategy, circularityLock);
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  6044 */     protected static final Dispatcher DISPATCHER = (Dispatcher)AgentBuilder.Default.doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */     
/*       */     private final boolean enabled;
/*       */ 
/*       */ 
/*       */     
/*       */     private final boolean retransforming;
/*       */ 
/*       */ 
/*       */     
/*       */     static {
/*       */     
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     RedefinitionStrategy(boolean enabled, boolean retransforming) {
/*  6063 */       this.enabled = enabled;
/*  6064 */       this.retransforming = retransforming;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected boolean isRetransforming() {
/*  6074 */       return this.retransforming;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected boolean isEnabled() {
/*  6090 */       return this.enabled;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected void apply(Instrumentation instrumentation, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.Listener listener, Listener redefinitionListener, AgentBuilder.RawMatcher matcher, BatchAllocator redefinitionBatchAllocator, AgentBuilder.CircularityLock circularityLock) {
/*  6143 */       check(instrumentation);
/*  6144 */       int batch = 0;
/*  6145 */       for (Iterable<Class<?>> types : redefinitionDiscoveryStrategy.resolve(instrumentation)) {
/*  6146 */         Collector collector = make(poolStrategy, locationStrategy, descriptionStrategy, fallbackStrategy, listener, matcher, circularityLock);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  6153 */         for (Class<?> type : types) {
/*  6154 */           if (type == null || type.isArray() || type.isPrimitive() || !lambdaInstrumentationStrategy.isInstrumented(type)) {
/*       */             continue;
/*       */           }
/*  6157 */           collector.consider(type, (DISPATCHER.isModifiableClass(instrumentation, type) || ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtMost(ClassFileVersion.JAVA_V5)));
/*       */         } 
/*  6159 */         batch = collector.apply(instrumentation, redefinitionBatchAllocator, redefinitionListener, batch);
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract void check(Instrumentation param1Instrumentation);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract Collector make(AgentBuilder.PoolStrategy param1PoolStrategy, AgentBuilder.LocationStrategy param1LocationStrategy, AgentBuilder.DescriptionStrategy param1DescriptionStrategy, AgentBuilder.FallbackStrategy param1FallbackStrategy, AgentBuilder.Listener param1Listener, AgentBuilder.RawMatcher param1RawMatcher, AgentBuilder.CircularityLock param1CircularityLock);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface BatchAllocator
/*       */     {
/*       */       public static final int FIRST_BATCH = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Iterable<? extends List<Class<?>>> batch(List<Class<?>> param2List);
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForTotal
/*       */         implements BatchAllocator
/*       */       {
/*  6192 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> batch(List<Class<?>> types) {
/*  6198 */           return types.isEmpty() ? 
/*  6199 */             Collections.<List<Class<?>>>emptySet() : 
/*  6200 */             Collections.<List<Class<?>>>singleton(types);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForFixedSize
/*       */         implements BatchAllocator
/*       */       {
/*       */         private final int size;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForFixedSize(int size) {
/*  6221 */           this.size = size;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.BatchAllocator ofSize(int size) {
/*  6231 */           if (size > 0)
/*  6232 */             return new ForFixedSize(size); 
/*  6233 */           if (size == 0) {
/*  6234 */             return AgentBuilder.RedefinitionStrategy.BatchAllocator.ForTotal.INSTANCE;
/*       */           }
/*  6236 */           throw new IllegalArgumentException("Cannot define a batch with a negative size: " + size);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> batch(List<Class<?>> types) {
/*  6244 */           List<List<Class<?>>> batches = new ArrayList<List<Class<?>>>();
/*  6245 */           for (int index = 0; index < types.size(); index += this.size) {
/*  6246 */             batches.add(new ArrayList<Class<?>>(types.subList(index, Math.min(types.size(), index + this.size))));
/*       */           }
/*  6248 */           return batches;
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.size != ((ForFixedSize)param3Object).size))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.size;
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForMatchedGrouping
/*       */         implements BatchAllocator
/*       */       {
/*       */         private final Collection<? extends ElementMatcher<? super TypeDescription>> matchers;
/*       */         
/*       */         @Enhance
/*       */         @SafeVarargs
/*       */         public ForMatchedGrouping(ElementMatcher<? super TypeDescription>... matcher) {
/*  6272 */           this(new LinkedHashSet<ElementMatcher<? super TypeDescription>>(Arrays.asList(matcher)));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForMatchedGrouping(Collection<? extends ElementMatcher<? super TypeDescription>> matchers) {
/*  6282 */           this.matchers = matchers;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.BatchAllocator withMinimum(int threshold) {
/*  6293 */           return AgentBuilder.RedefinitionStrategy.BatchAllocator.Slicing.withMinimum(threshold, this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.BatchAllocator withMaximum(int threshold) {
/*  6304 */           return AgentBuilder.RedefinitionStrategy.BatchAllocator.Slicing.withMaximum(threshold, this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.BatchAllocator withinRange(int minimum, int maximum) {
/*  6316 */           return AgentBuilder.RedefinitionStrategy.BatchAllocator.Slicing.withinRange(minimum, maximum, this);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> batch(List<Class<?>> types) {
/*  6323 */           Map<ElementMatcher<? super TypeDescription>, List<Class<?>>> matched = new LinkedHashMap<ElementMatcher<? super TypeDescription>, List<Class<?>>>();
/*  6324 */           List<Class<?>> unmatched = new ArrayList<Class<?>>();
/*  6325 */           for (ElementMatcher<? super TypeDescription> matcher : this.matchers) {
/*  6326 */             matched.put(matcher, new ArrayList<Class<?>>());
/*       */           }
/*       */           
/*  6329 */           for (Class<?> type : types) {
/*  6330 */             for (ElementMatcher<? super TypeDescription> matcher : this.matchers) {
/*  6331 */               if (matcher.matches(TypeDescription.ForLoadedType.of(type))) {
/*  6332 */                 ((List<Class<?>>)matched.get(matcher)).add(type);
/*       */               }
/*       */             } 
/*       */             
/*  6336 */             unmatched.add(type);
/*       */           } 
/*  6338 */           List<List<Class<?>>> batches = new ArrayList<List<Class<?>>>(this.matchers.size() + 1);
/*  6339 */           for (List<Class<?>> batch : matched.values()) {
/*  6340 */             if (!batch.isEmpty()) {
/*  6341 */               batches.add(batch);
/*       */             }
/*       */           } 
/*  6344 */           if (!unmatched.isEmpty()) {
/*  6345 */             batches.add(unmatched);
/*       */           }
/*  6347 */           return batches;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matchers.equals(((ForMatchedGrouping)param3Object).matchers))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.matchers.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Slicing
/*       */         implements BatchAllocator
/*       */       {
/*       */         private final int minimum;
/*       */ 
/*       */         
/*       */         private final int maximum;
/*       */ 
/*       */         
/*       */         private final AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator;
/*       */ 
/*       */ 
/*       */         
/*       */         protected Slicing(int minimum, int maximum, AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator) {
/*  6380 */           this.minimum = minimum;
/*  6381 */           this.maximum = maximum;
/*  6382 */           this.batchAllocator = batchAllocator;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.BatchAllocator withMinimum(int minimum, AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator) {
/*  6393 */           return withinRange(minimum, 2147483647, batchAllocator);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.BatchAllocator withMaximum(int maximum, AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator) {
/*  6404 */           return withinRange(1, maximum, batchAllocator);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.BatchAllocator withinRange(int minimum, int maximum, AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator) {
/*  6416 */           if (minimum <= 0)
/*  6417 */             throw new IllegalArgumentException("Minimum must be a positive number: " + minimum); 
/*  6418 */           if (minimum > maximum) {
/*  6419 */             throw new IllegalArgumentException("Minimum must not be bigger than maximum: " + minimum + " >" + maximum);
/*       */           }
/*  6421 */           return new Slicing(minimum, maximum, batchAllocator);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> batch(List<Class<?>> types) {
/*  6428 */           return new SlicingIterable(this.minimum, this.maximum, this.batchAllocator.batch(types));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.minimum != ((Slicing)param3Object).minimum) ? false : ((this.maximum != ((Slicing)param3Object).maximum) ? false : (!!this.batchAllocator.equals(((Slicing)param3Object).batchAllocator))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.minimum) * 31 + this.maximum) * 31 + this.batchAllocator.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class SlicingIterable
/*       */           implements Iterable<List<Class<?>>>
/*       */         {
/*       */           private final int minimum;
/*       */ 
/*       */           
/*       */           private final int maximum;
/*       */ 
/*       */           
/*       */           private final Iterable<? extends List<Class<?>>> iterable;
/*       */ 
/*       */ 
/*       */           
/*       */           protected SlicingIterable(int minimum, int maximum, Iterable<? extends List<Class<?>>> iterable) {
/*  6459 */             this.minimum = minimum;
/*  6460 */             this.maximum = maximum;
/*  6461 */             this.iterable = iterable;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Iterator<List<Class<?>>> iterator() {
/*  6468 */             return new SlicingIterator(this.minimum, this.maximum, this.iterable.iterator());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class SlicingIterator
/*       */             implements Iterator<List<Class<?>>>
/*       */           {
/*       */             private final int minimum;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private final int maximum;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private final Iterator<? extends List<Class<?>>> iterator;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private List<Class<?>> buffer;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected SlicingIterator(int minimum, int maximum, Iterator<? extends List<Class<?>>> iterator) {
/*  6504 */               this.minimum = minimum;
/*  6505 */               this.maximum = maximum;
/*  6506 */               this.iterator = iterator;
/*  6507 */               this.buffer = new ArrayList<Class<?>>();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean hasNext() {
/*  6514 */               return (!this.buffer.isEmpty() || this.iterator.hasNext());
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public List<Class<?>> next() {
/*  6521 */               if (this.buffer.isEmpty()) {
/*  6522 */                 this.buffer = this.iterator.next();
/*       */               }
/*  6524 */               while (this.buffer.size() < this.minimum && this.iterator.hasNext()) {
/*  6525 */                 this.buffer.addAll(this.iterator.next());
/*       */               }
/*  6527 */               if (this.buffer.size() > this.maximum) {
/*       */                 try {
/*  6529 */                   return this.buffer.subList(0, this.maximum);
/*       */                 } finally {
/*  6531 */                   this.buffer = new ArrayList<Class<?>>(this.buffer.subList(this.maximum, this.buffer.size()));
/*       */                 } 
/*       */               }
/*       */               try {
/*  6535 */                 return this.buffer;
/*       */               } finally {
/*  6537 */                 this.buffer = new ArrayList<Class<?>>();
/*       */               } 
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public void remove() {
/*  6546 */               throw new UnsupportedOperationException("remove");
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Partitioning
/*       */         implements BatchAllocator
/*       */       {
/*       */         private final int parts;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Partitioning(int parts) {
/*  6569 */           this.parts = parts;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.BatchAllocator of(int parts) {
/*  6579 */           if (parts < 1) {
/*  6580 */             throw new IllegalArgumentException("A batch size must be positive: " + parts);
/*       */           }
/*  6582 */           return new Partitioning(parts);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> batch(List<Class<?>> types) {
/*  6589 */           if (types.isEmpty()) {
/*  6590 */             return Collections.emptyList();
/*       */           }
/*  6592 */           List<List<Class<?>>> batches = new ArrayList<List<Class<?>>>();
/*  6593 */           int size = types.size() / this.parts, reminder = types.size() % this.parts; int index;
/*  6594 */           for (index = reminder; index < types.size(); index += size) {
/*  6595 */             batches.add(new ArrayList<Class<?>>(types.subList(index, index + size)));
/*       */           }
/*  6597 */           if (batches.isEmpty()) {
/*  6598 */             return Collections.singletonList(types);
/*       */           }
/*  6600 */           ((List)batches.get(0)).addAll(0, types.subList(0, reminder));
/*  6601 */           return batches;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.parts != ((Partitioning)param3Object).parts))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.parts;
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Listener
/*       */     {
/*       */       void onBatch(int param2Int, List<Class<?>> param2List1, List<Class<?>> param2List2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Iterable<? extends List<Class<?>>> onError(int param2Int, List<Class<?>> param2List1, Throwable param2Throwable, List<Class<?>> param2List2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void onComplete(int param2Int, List<Class<?>> param2List, Map<List<Class<?>>, Throwable> param2Map);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum NoOp
/*       */         implements Listener
/*       */       {
/*  6651 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6664 */           return Collections.emptyList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Yielding
/*       */         implements Listener
/*       */       {
/*  6683 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {
/*  6689 */           if (index > 0) {
/*  6690 */             Thread.yield();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6698 */           return Collections.emptyList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ErrorEscalating
/*       */         implements Listener
/*       */       {
/*  6717 */         FAIL_FAST
/*       */         {
/*       */           public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6720 */             throw new IllegalStateException("Could not transform any of " + batch, throwable);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {}
/*       */         },
/*  6732 */         FAIL_LAST
/*       */         {
/*       */           public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6735 */             return Collections.emptyList();
/*       */           }
/*       */ 
/*       */           
/*       */           public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {
/*  6740 */             if (!failures.isEmpty()) {
/*  6741 */               throw new IllegalStateException("Could not transform any of " + failures);
/*       */             }
/*       */           }
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static abstract class Adapter
/*       */         implements Listener
/*       */       {
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6771 */           return Collections.emptyList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : (!(getClass() != param3Object.getClass())));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class BatchReallocator
/*       */         extends Adapter
/*       */       {
/*       */         private final AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public BatchReallocator(AgentBuilder.RedefinitionStrategy.BatchAllocator batchAllocator) {
/*  6807 */           this.batchAllocator = batchAllocator;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.Listener splitting() {
/*  6816 */           return new BatchReallocator(new AgentBuilder.RedefinitionStrategy.BatchAllocator.Partitioning(2));
/*       */         }
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6821 */           return (batch.size() < 2) ? 
/*  6822 */             Collections.<List<Class<?>>>emptyList() : this.batchAllocator
/*  6823 */             .batch(batch);
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.batchAllocator.equals(((BatchReallocator)param3Object).batchAllocator)))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.batchAllocator.hashCode();
/*       */         }
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       public static class Pausing
/*       */         extends Adapter
/*       */       {
/*       */         private final long value;
/*       */         
/*       */         protected Pausing(long value) {
/*  6844 */           this.value = value;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.Listener of(long value, TimeUnit timeUnit) {
/*  6856 */           if (value > 0L)
/*  6857 */             return new Pausing(timeUnit.toMillis(value)); 
/*  6858 */           if (value == 0L) {
/*  6859 */             return AgentBuilder.RedefinitionStrategy.Listener.NoOp.INSTANCE;
/*       */           }
/*  6861 */           throw new IllegalArgumentException("Cannot sleep for a non-positive amount of time: " + value);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {
/*  6867 */           if (index > 0) {
/*       */             try {
/*  6869 */               Thread.sleep(this.value);
/*  6870 */             } catch (InterruptedException exception) {
/*  6871 */               Thread.currentThread().interrupt();
/*  6872 */               throw new IllegalStateException(exception);
/*       */             } 
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.value != ((Pausing)param3Object).value)))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + (int)(this.value ^ this.value >>> 32L);
/*       */         }
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       public static class StreamWriting
/*       */         implements Listener
/*       */       {
/*       */         private final PrintStream printStream;
/*       */         
/*       */         public StreamWriting(PrintStream printStream) {
/*  6895 */           this.printStream = printStream;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.Listener toSystemOut() {
/*  6904 */           return new StreamWriting(System.out);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static AgentBuilder.RedefinitionStrategy.Listener toSystemError() {
/*  6913 */           return new StreamWriting(System.err);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {
/*  6920 */           this.printStream.printf("[Byte Buddy] REDEFINE BATCH #%d [%d of %d type(s)]%n", new Object[] { Integer.valueOf(index), Integer.valueOf(batch.size()), Integer.valueOf(types.size()) });
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6927 */           synchronized (this.printStream) {
/*  6928 */             this.printStream.printf("[Byte Buddy] REDEFINE ERROR #%d [%d of %d type(s)]%n", new Object[] { Integer.valueOf(index), Integer.valueOf(batch.size()), Integer.valueOf(types.size()) });
/*  6929 */             throwable.printStackTrace(this.printStream);
/*       */           } 
/*  6931 */           return Collections.emptyList();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {
/*  6938 */           this.printStream.printf("[Byte Buddy] REDEFINE COMPLETE %d batch(es) containing %d types [%d failed batch(es)]%n", new Object[] { Integer.valueOf(amount), Integer.valueOf(types.size()), Integer.valueOf(failures.size()) });
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.printStream.equals(((StreamWriting)param3Object).printStream))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.printStream.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Compound
/*       */         implements Listener
/*       */       {
/*       */         public Compound(AgentBuilder.RedefinitionStrategy.Listener... listener) {
/*  6959 */           this(Arrays.asList(listener));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  6968 */         private final List<AgentBuilder.RedefinitionStrategy.Listener> listeners = new ArrayList<AgentBuilder.RedefinitionStrategy.Listener>(); public Compound(List<? extends AgentBuilder.RedefinitionStrategy.Listener> listeners) {
/*  6969 */           for (AgentBuilder.RedefinitionStrategy.Listener listener : listeners) {
/*  6970 */             if (listener instanceof Compound) {
/*  6971 */               this.listeners.addAll(((Compound)listener).listeners); continue;
/*  6972 */             }  if (!(listener instanceof AgentBuilder.RedefinitionStrategy.Listener.NoOp)) {
/*  6973 */               this.listeners.add(listener);
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBatch(int index, List<Class<?>> batch, List<Class<?>> types) {
/*  6982 */           for (AgentBuilder.RedefinitionStrategy.Listener listener : this.listeners) {
/*  6983 */             listener.onBatch(index, batch, types);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<? extends List<Class<?>>> onError(int index, List<Class<?>> batch, Throwable throwable, List<Class<?>> types) {
/*  6991 */           List<Iterable<? extends List<Class<?>>>> reattempts = new ArrayList<Iterable<? extends List<Class<?>>>>();
/*  6992 */           for (AgentBuilder.RedefinitionStrategy.Listener listener : this.listeners) {
/*  6993 */             reattempts.add(listener.onError(index, batch, throwable, types));
/*       */           }
/*  6995 */           return new CompoundIterable(reattempts);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onComplete(int amount, List<Class<?>> types, Map<List<Class<?>>, Throwable> failures) {
/*  7002 */           for (AgentBuilder.RedefinitionStrategy.Listener listener : this.listeners) {
/*  7003 */             listener.onComplete(amount, types, failures);
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.listeners.equals(((Compound)param3Object).listeners))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.listeners.hashCode();
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         protected static class CompoundIterable
/*       */           implements Iterable<List<Class<?>>>
/*       */         {
/*       */           private final List<Iterable<? extends List<Class<?>>>> iterables;
/*       */           
/*       */           protected CompoundIterable(List<Iterable<? extends List<Class<?>>>> iterables) {
/*  7024 */             this.iterables = iterables;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Iterator<List<Class<?>>> iterator() {
/*  7031 */             return new CompoundIterator(new ArrayList<Iterable<? extends List<Class<?>>>>(this.iterables));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.iterables.equals(((CompoundIterable)param4Object).iterables))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.iterables.hashCode();
/*       */           }
/*       */ 
/*       */           
/*       */           protected static class CompoundIterator
/*       */             implements Iterator<List<Class<?>>>
/*       */           {
/*       */             @MaybeNull
/*       */             private Iterator<? extends List<Class<?>>> current;
/*       */             
/*       */             private final List<Iterable<? extends List<Class<?>>>> backlog;
/*       */ 
/*       */             
/*       */             protected CompoundIterator(List<Iterable<? extends List<Class<?>>>> iterables) {
/*  7056 */               this.backlog = iterables;
/*  7057 */               forward();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean hasNext() {
/*  7064 */               return (this.current != null && this.current.hasNext());
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public List<Class<?>> next() {
/*       */               try {
/*  7072 */                 if (this.current != null) {
/*  7073 */                   return this.current.next();
/*       */                 }
/*  7075 */                 throw new NoSuchElementException();
/*       */               } finally {
/*       */                 
/*  7078 */                 forward();
/*       */               } 
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private void forward() {
/*  7086 */               while ((this.current == null || !this.current.hasNext()) && !this.backlog.isEmpty()) {
/*  7087 */                 this.current = ((Iterable<? extends List<Class<?>>>)this.backlog.remove(0)).iterator();
/*       */               }
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public void remove() {
/*  7095 */               throw new UnsupportedOperationException("remove");
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface DiscoveryStrategy
/*       */     {
/*       */       Iterable<Iterable<Class<?>>> resolve(Instrumentation param2Instrumentation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum SinglePass
/*       */         implements DiscoveryStrategy
/*       */       {
/*  7124 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<Iterable<Class<?>>> resolve(Instrumentation instrumentation) {
/*  7130 */           return Collections.singleton(Arrays.asList(instrumentation.getAllLoadedClasses()));
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Reiterating
/*       */         implements DiscoveryStrategy
/*       */       {
/*  7144 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<Iterable<Class<?>>> resolve(Instrumentation instrumentation) {
/*  7150 */           return new ReiteratingIterable(instrumentation);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class ReiteratingIterable
/*       */           implements Iterable<Iterable<Class<?>>>
/*       */         {
/*       */           private final Instrumentation instrumentation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ReiteratingIterable(Instrumentation instrumentation) {
/*  7170 */             this.instrumentation = instrumentation;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Iterator<Iterable<Class<?>>> iterator() {
/*  7177 */             return new AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.Reiterating.ReiteratingIterator(this.instrumentation);
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.instrumentation.equals(((ReiteratingIterable)param4Object).instrumentation))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.instrumentation.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class ReiteratingIterator
/*       */           implements Iterator<Iterable<Class<?>>>
/*       */         {
/*       */           private final Instrumentation instrumentation;
/*       */ 
/*       */           
/*       */           private final Set<Class<?>> processed;
/*       */           
/*       */           @MaybeNull
/*       */           private List<Class<?>> types;
/*       */ 
/*       */           
/*       */           protected ReiteratingIterator(Instrumentation instrumentation) {
/*  7208 */             this.instrumentation = instrumentation;
/*  7209 */             this.processed = new HashSet<Class<?>>();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean hasNext() {
/*  7216 */             if (this.types == null) {
/*  7217 */               this.types = new ArrayList<Class<?>>();
/*  7218 */               for (Class<?> type : this.instrumentation.getAllLoadedClasses()) {
/*  7219 */                 if (type != null && this.processed.add(type)) {
/*  7220 */                   this.types.add(type);
/*       */                 }
/*       */               } 
/*       */             } 
/*  7224 */             return !this.types.isEmpty();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Iterable<Class<?>> next() {
/*  7231 */             if (hasNext()) {
/*       */               try {
/*  7233 */                 return this.types;
/*       */               } finally {
/*  7235 */                 this.types = null;
/*       */               } 
/*       */             }
/*  7238 */             throw new NoSuchElementException();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void remove() {
/*  7246 */             throw new UnsupportedOperationException("remove");
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public enum WithSortOrderAssumption
/*       */           implements AgentBuilder.RedefinitionStrategy.DiscoveryStrategy
/*       */         {
/*  7267 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Iterable<Iterable<Class<?>>> resolve(Instrumentation instrumentation) {
/*  7273 */             return new OrderedReiteratingIterable(instrumentation);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Enhance
/*       */           protected static class OrderedReiteratingIterable
/*       */             implements Iterable<Iterable<Class<?>>>
/*       */           {
/*       */             private final Instrumentation instrumentation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected OrderedReiteratingIterable(Instrumentation instrumentation) {
/*  7293 */               this.instrumentation = instrumentation;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public Iterator<Iterable<Class<?>>> iterator() {
/*  7300 */               return new AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.Reiterating.WithSortOrderAssumption.OrderedReiteratingIterator(this.instrumentation);
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.instrumentation.equals(((OrderedReiteratingIterable)param5Object).instrumentation))));
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public int hashCode() {
/*       */               return getClass().hashCode() * 31 + this.instrumentation.hashCode();
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class OrderedReiteratingIterator
/*       */             implements Iterator<Iterable<Class<?>>>
/*       */           {
/*       */             private final Instrumentation instrumentation;
/*       */ 
/*       */             
/*       */             private int index;
/*       */             
/*       */             @MaybeNull
/*       */             private List<Class<?>> types;
/*       */ 
/*       */             
/*       */             protected OrderedReiteratingIterator(Instrumentation instrumentation) {
/*  7331 */               this.instrumentation = instrumentation;
/*  7332 */               this.index = 0;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean hasNext() {
/*  7339 */               if (this.types == null) {
/*  7340 */                 Class<?>[] type = this.instrumentation.getAllLoadedClasses();
/*  7341 */                 this.types = new ArrayList<Class<?>>(Arrays.<Class<?>>asList(type).subList(this.index, type.length));
/*  7342 */                 this.index = type.length;
/*       */               } 
/*  7344 */               return !this.types.isEmpty();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public Iterable<Class<?>> next() {
/*  7351 */               if (hasNext()) {
/*       */                 try {
/*  7353 */                   return this.types;
/*       */                 } finally {
/*  7355 */                   this.types = null;
/*       */                 } 
/*       */               }
/*  7358 */               throw new NoSuchElementException();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public void remove() {
/*  7366 */               throw new UnsupportedOperationException("remove");
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Explicit
/*       */         implements DiscoveryStrategy
/*       */       {
/*       */         private final Set<Class<?>> types;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Explicit(Class<?>... type) {
/*  7389 */           this(new LinkedHashSet<Class<?>>(Arrays.asList(type)));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Explicit(Set<Class<?>> types) {
/*  7398 */           this.types = types;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Iterable<Iterable<Class<?>>> resolve(Instrumentation instrumentation) {
/*  7405 */           return Collections.singleton(this.types);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.types.equals(((Explicit)param3Object).types))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.types.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ResubmissionScheduler
/*       */     {
/*       */       boolean isAlive();
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Cancelable schedule(Runnable param2Runnable);
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static interface Cancelable
/*       */       {
/*       */         void cancel();
/*       */ 
/*       */ 
/*       */         
/*       */         public enum NoOp
/*       */           implements Cancelable
/*       */         {
/*  7448 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void cancel() {}
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForFuture
/*       */           implements Cancelable
/*       */         {
/*       */           private final Future<?> future;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForFuture(Future<?> future) {
/*  7475 */             this.future = future;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void cancel() {
/*  7482 */             this.future.cancel(true);
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.future.equals(((ForFuture)param4Object).future))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.future.hashCode();
/*       */           } }
/*       */       }
/*       */       
/*       */       public enum NoOp implements ResubmissionScheduler {
/*  7495 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isAlive() {
/*  7501 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable schedule(Runnable job) {
/*  7508 */           return AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable.NoOp.INSTANCE;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class AtFixedRate
/*       */         implements ResubmissionScheduler
/*       */       {
/*       */         private final ScheduledExecutorService scheduledExecutorService;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final long time;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TimeUnit timeUnit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AtFixedRate(ScheduledExecutorService scheduledExecutorService, long time, TimeUnit timeUnit) {
/*  7541 */           this.scheduledExecutorService = scheduledExecutorService;
/*  7542 */           this.time = time;
/*  7543 */           this.timeUnit = timeUnit;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isAlive() {
/*  7550 */           return !this.scheduledExecutorService.isShutdown();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable schedule(Runnable job) {
/*  7557 */           return new AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable.ForFuture(this.scheduledExecutorService.scheduleAtFixedRate(job, this.time, this.time, this.timeUnit));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.time != ((AtFixedRate)param3Object).time) ? false : (!this.timeUnit.equals(((AtFixedRate)param3Object).timeUnit) ? false : (!!this.scheduledExecutorService.equals(((AtFixedRate)param3Object).scheduledExecutorService))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.scheduledExecutorService.hashCode()) * 31 + (int)(this.time ^ this.time >>> 32L)) * 31 + this.timeUnit.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class WithFixedDelay
/*       */         implements ResubmissionScheduler
/*       */       {
/*       */         private final ScheduledExecutorService scheduledExecutorService;
/*       */ 
/*       */         
/*       */         private final long time;
/*       */ 
/*       */         
/*       */         private final TimeUnit timeUnit;
/*       */ 
/*       */ 
/*       */         
/*       */         public WithFixedDelay(ScheduledExecutorService scheduledExecutorService, long time, TimeUnit timeUnit) {
/*  7590 */           this.scheduledExecutorService = scheduledExecutorService;
/*  7591 */           this.time = time;
/*  7592 */           this.timeUnit = timeUnit;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isAlive() {
/*  7599 */           return !this.scheduledExecutorService.isShutdown();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable schedule(Runnable job) {
/*  7606 */           return new AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable.ForFuture(this.scheduledExecutorService.scheduleWithFixedDelay(job, this.time, this.time, this.timeUnit));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.time != ((WithFixedDelay)param3Object).time) ? false : (!this.timeUnit.equals(((WithFixedDelay)param3Object).timeUnit) ? false : (!!this.scheduledExecutorService.equals(((WithFixedDelay)param3Object).scheduledExecutorService))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.scheduledExecutorService.hashCode()) * 31 + (int)(this.time ^ this.time >>> 32L)) * 31 + this.timeUnit.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static interface ResubmissionStrategy
/*       */     {
/*       */       Installation apply(Instrumentation param2Instrumentation, AgentBuilder.PoolStrategy param2PoolStrategy, AgentBuilder.LocationStrategy param2LocationStrategy, AgentBuilder.DescriptionStrategy param2DescriptionStrategy, AgentBuilder.FallbackStrategy param2FallbackStrategy, AgentBuilder.Listener param2Listener, AgentBuilder.InstallationListener param2InstallationListener, AgentBuilder.CircularityLock param2CircularityLock, AgentBuilder.RawMatcher param2RawMatcher, AgentBuilder.RedefinitionStrategy param2RedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator param2BatchAllocator, AgentBuilder.RedefinitionStrategy.Listener param2Listener1);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Disabled
/*       */         implements ResubmissionStrategy
/*       */       {
/*  7654 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Installation apply(Instrumentation instrumentation, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.Listener listener, AgentBuilder.InstallationListener installationListener, AgentBuilder.CircularityLock circularityLock, AgentBuilder.RawMatcher matcher, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionBatchListener) {
/*  7671 */           return new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Installation(listener, installationListener, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer.Disabled.INSTANCE);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Enabled
/*       */         implements ResubmissionStrategy
/*       */       {
/*       */         private final AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher resubmissionOnErrorMatcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher resubmissionImmediateMatcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Enabled(AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler, AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher resubmissionOnErrorMatcher, AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher resubmissionImmediateMatcher) {
/*  7706 */           this.resubmissionScheduler = resubmissionScheduler;
/*  7707 */           this.resubmissionOnErrorMatcher = resubmissionOnErrorMatcher;
/*  7708 */           this.resubmissionImmediateMatcher = resubmissionImmediateMatcher;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Installation apply(Instrumentation instrumentation, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.Listener listener, AgentBuilder.InstallationListener installationListener, AgentBuilder.CircularityLock circularityLock, AgentBuilder.RawMatcher matcher, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionBatchListener) {
/*  7726 */           if (this.resubmissionScheduler.isAlive()) {
/*  7727 */             ConcurrentMap<StorageKey, Set<String>> types = new ConcurrentHashMap<StorageKey, Set<String>>();
/*  7728 */             Resubmitter resubmitter = new Resubmitter(this.resubmissionOnErrorMatcher, this.resubmissionImmediateMatcher, types);
/*  7729 */             return new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Installation(new AgentBuilder.Listener.Compound(new AgentBuilder.Listener[] { resubmitter, listener }, ), new AgentBuilder.InstallationListener.Compound(new AgentBuilder.InstallationListener[] { new ResubmissionInstallationListener(instrumentation, this.resubmissionScheduler, poolStrategy, locationStrategy, descriptionStrategy, fallbackStrategy, listener, circularityLock, matcher, redefinitionStrategy, redefinitionBatchAllocator, redefinitionBatchListener, types), installationListener }), resubmitter);
/*       */           } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  7745 */           throw new IllegalStateException("Resubmission scheduler " + this.resubmissionScheduler + " is not alive");
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.resubmissionScheduler.equals(((Enabled)param3Object).resubmissionScheduler) ? false : (!this.resubmissionOnErrorMatcher.equals(((Enabled)param3Object).resubmissionOnErrorMatcher) ? false : (!!this.resubmissionImmediateMatcher.equals(((Enabled)param3Object).resubmissionImmediateMatcher))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.resubmissionScheduler.hashCode()) * 31 + this.resubmissionOnErrorMatcher.hashCode()) * 31 + this.resubmissionImmediateMatcher.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class Resubmitter
/*       */           extends AgentBuilder.Listener.Adapter
/*       */           implements AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer
/*       */         {
/*       */           private final AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher resubmissionOnErrorMatcher;
/*       */ 
/*       */           
/*       */           private final AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher resubmissionImmediateMatcher;
/*       */ 
/*       */           
/*       */           private final ConcurrentMap<AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey, Set<String>> types;
/*       */ 
/*       */ 
/*       */           
/*       */           protected Resubmitter(AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher resubmissionOnErrorMatcher, AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher resubmissionImmediateMatcher, ConcurrentMap<AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey, Set<String>> types) {
/*  7779 */             this.resubmissionOnErrorMatcher = resubmissionOnErrorMatcher;
/*  7780 */             this.resubmissionImmediateMatcher = resubmissionImmediateMatcher;
/*  7781 */             this.types = types;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"GC_UNRELATED_TYPES"}, justification = "Cross-comparison is intended.")
/*       */           public void onError(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, boolean loaded, Throwable throwable) {
/*  7789 */             if (!loaded && this.resubmissionOnErrorMatcher.matches(throwable, typeName, classLoader, module)) {
/*  7790 */               Set<String> types = this.types.get(new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey(classLoader));
/*  7791 */               if (types == null) {
/*  7792 */                 types = new ConcurrentHashSet<String>();
/*  7793 */                 Set<String> previous = this.types.putIfAbsent(new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey(classLoader), types);
/*  7794 */                 if (previous != null) {
/*  7795 */                   types = previous;
/*       */                 }
/*       */               } 
/*  7798 */               types.add(typeName);
/*       */             } 
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"GC_UNRELATED_TYPES"}, justification = "Cross-comparison is intended.")
/*       */           public boolean isEnforced(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined) {
/*  7807 */             if (classBeingRedefined == null && this.resubmissionImmediateMatcher.matches(typeName, classLoader, module)) {
/*  7808 */               Set<String> types = this.types.get(new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey(classLoader));
/*  7809 */               if (types == null) {
/*  7810 */                 types = new ConcurrentHashSet<String>();
/*  7811 */                 Set<String> previous = this.types.putIfAbsent(new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey(classLoader), types);
/*  7812 */                 if (previous != null) {
/*  7813 */                   types = previous;
/*       */                 }
/*       */               } 
/*  7816 */               types.add(typeName);
/*  7817 */               return true;
/*       */             } 
/*  7819 */             return false;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class ConcurrentHashSet<T>
/*       */             extends AbstractSet<T>
/*       */           {
/*  7839 */             private final ConcurrentMap<T, Boolean> delegate = new ConcurrentHashMap<T, Boolean>();
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean add(T value) {
/*  7844 */               return (this.delegate.put(value, Boolean.TRUE) == null);
/*       */             }
/*       */ 
/*       */             
/*       */             public boolean remove(Object value) {
/*  7849 */               return (this.delegate.remove(value) != null);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public Iterator<T> iterator() {
/*  7856 */               return this.delegate.keySet().iterator();
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public int size() {
/*  7863 */               return this.delegate.size();
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class ResubmissionInstallationListener
/*       */           extends AgentBuilder.InstallationListener.Adapter
/*       */           implements Runnable
/*       */         {
/*       */           private final Instrumentation instrumentation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.LocationStrategy locationStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.PoolStrategy poolStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.DescriptionStrategy descriptionStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.FallbackStrategy fallbackStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.Listener listener;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.CircularityLock circularityLock;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.RawMatcher matcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.RedefinitionStrategy redefinitionStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final AgentBuilder.RedefinitionStrategy.Listener redefinitionBatchListener;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final ConcurrentMap<AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey, Set<String>> types;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @MaybeNull
/*       */           private volatile AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable cancelable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ResubmissionInstallationListener(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.Listener listener, AgentBuilder.CircularityLock circularityLock, AgentBuilder.RawMatcher matcher, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionBatchListener, ConcurrentMap<AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey, Set<String>> types) {
/*  7974 */             this.instrumentation = instrumentation;
/*  7975 */             this.resubmissionScheduler = resubmissionScheduler;
/*  7976 */             this.poolStrategy = poolStrategy;
/*  7977 */             this.locationStrategy = locationStrategy;
/*  7978 */             this.descriptionStrategy = descriptionStrategy;
/*  7979 */             this.fallbackStrategy = fallbackStrategy;
/*  7980 */             this.listener = listener;
/*  7981 */             this.circularityLock = circularityLock;
/*  7982 */             this.matcher = matcher;
/*  7983 */             this.redefinitionStrategy = redefinitionStrategy;
/*  7984 */             this.redefinitionBatchAllocator = redefinitionBatchAllocator;
/*  7985 */             this.redefinitionBatchListener = redefinitionBatchListener;
/*  7986 */             this.types = types;
/*       */           }
/*       */ 
/*       */           
/*       */           public void onInstall(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  7991 */             this.cancelable = this.resubmissionScheduler.schedule(this);
/*       */           }
/*       */ 
/*       */           
/*       */           public void onReset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/*  7996 */             AgentBuilder.RedefinitionStrategy.ResubmissionScheduler.Cancelable cancelable = this.cancelable;
/*  7997 */             if (cancelable != null) {
/*  7998 */               cancelable.cancel();
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void run() {
/*  8006 */             boolean release = this.circularityLock.acquire();
/*       */             try {
/*  8008 */               AgentBuilder.RedefinitionStrategy.Collector collector = this.redefinitionStrategy.make(this.poolStrategy, this.locationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.listener, this.matcher, this.circularityLock);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*  8015 */               Iterator<Map.Entry<AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey, Set<String>>> entries = this.types.entrySet().iterator();
/*  8016 */               while (entries.hasNext()) {
/*  8017 */                 if (Thread.interrupted()) {
/*       */                   return;
/*       */                 }
/*  8020 */                 Map.Entry<AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey, Set<String>> entry = entries.next();
/*  8021 */                 ClassLoader classLoader = ((AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey)entry.getKey()).get();
/*  8022 */                 if (classLoader != null || ((AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey)entry.getKey()).isBootstrapLoader()) {
/*  8023 */                   Iterator<String> iterator = ((Set<String>)entry.getValue()).iterator();
/*  8024 */                   while (iterator.hasNext()) {
/*  8025 */                     if (Thread.interrupted()) {
/*       */                       return;
/*       */                     }
/*       */                     try {
/*  8029 */                       Class<?> type = Class.forName(iterator.next(), false, classLoader);
/*  8030 */                       collector.consider(type, (!type.isArray() && 
/*  8031 */                           !type.isPrimitive() && (AgentBuilder.RedefinitionStrategy.DISPATCHER
/*  8032 */                           .isModifiableClass(this.instrumentation, type) || 
/*  8033 */                           ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtMost(ClassFileVersion.JAVA_V5))));
/*  8034 */                     } catch (Throwable throwable) {
/*       */                     
/*       */                     } finally {
/*  8037 */                       iterator.remove();
/*       */                     } 
/*       */                   }  continue;
/*       */                 } 
/*  8041 */                 entries.remove();
/*       */               } 
/*       */               
/*  8044 */               collector.apply(this.instrumentation, this.redefinitionBatchAllocator, this.redefinitionBatchListener, 0);
/*       */             
/*       */             }
/*       */             finally {
/*       */               
/*  8049 */               if (release) {
/*  8050 */                 this.circularityLock.release();
/*       */               }
/*       */             } 
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class LookupKey
/*       */         {
/*       */           @MaybeNull
/*       */           private final ClassLoader classLoader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final int hashCode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected LookupKey(@MaybeNull ClassLoader classLoader) {
/*  8078 */             this.classLoader = classLoader;
/*  8079 */             this.hashCode = System.identityHashCode(classLoader);
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*  8084 */             return this.hashCode;
/*       */           }
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"EQ_CHECK_FOR_OPERAND_NOT_COMPATIBLE_WITH_THIS"}, justification = "Cross-comparison is intended.")
/*       */           public boolean equals(@MaybeNull Object other) {
/*  8090 */             if (this == other)
/*  8091 */               return true; 
/*  8092 */             if (other instanceof LookupKey)
/*  8093 */               return (this.classLoader == ((LookupKey)other).classLoader); 
/*  8094 */             if (other instanceof AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey) {
/*  8095 */               AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey storageKey = (AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey)other;
/*  8096 */               return (this.hashCode == AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.StorageKey.access$700(storageKey) && this.classLoader == storageKey.get());
/*       */             } 
/*  8098 */             return false;
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class StorageKey
/*       */           extends WeakReference<ClassLoader>
/*       */         {
/*       */           private final int hashCode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected StorageKey(@MaybeNull ClassLoader classLoader) {
/*  8119 */             super(classLoader);
/*  8120 */             this.hashCode = System.identityHashCode(classLoader);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected boolean isBootstrapLoader() {
/*  8129 */             return (this.hashCode == 0);
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*  8134 */             return this.hashCode;
/*       */           }
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"EQ_CHECK_FOR_OPERAND_NOT_COMPATIBLE_WITH_THIS"}, justification = "Cross-comparison is intended.")
/*       */           public boolean equals(@MaybeNull Object other) {
/*  8140 */             if (this == other)
/*  8141 */               return true; 
/*  8142 */             if (other instanceof AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey) {
/*  8143 */               AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey lookupKey = (AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey)other;
/*  8144 */               return (this.hashCode == AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey.access$800(lookupKey) && get() == AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled.LookupKey.access$900(lookupKey));
/*  8145 */             }  if (other instanceof StorageKey) {
/*  8146 */               StorageKey storageKey = (StorageKey)other;
/*  8147 */               return (this.hashCode == storageKey.hashCode && get() == storageKey.get());
/*       */             } 
/*  8149 */             return false;
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Installation
/*       */       {
/*       */         private final AgentBuilder.Listener listener;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AgentBuilder.InstallationListener installationListener;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Installation(AgentBuilder.Listener listener, AgentBuilder.InstallationListener installationListener, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer) {
/*  8184 */           this.listener = listener;
/*  8185 */           this.installationListener = installationListener;
/*  8186 */           this.resubmissionEnforcer = resubmissionEnforcer;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected AgentBuilder.Listener getListener() {
/*  8195 */           return this.listener;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected AgentBuilder.InstallationListener getInstallationListener() {
/*  8204 */           return this.installationListener;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer getResubmissionEnforcer() {
/*  8213 */           return this.resubmissionEnforcer;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.listener.equals(((Installation)param3Object).listener) ? false : (!this.installationListener.equals(((Installation)param3Object).installationListener) ? false : (!!this.resubmissionEnforcer.equals(((Installation)param3Object).resubmissionEnforcer))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.listener.hashCode()) * 31 + this.installationListener.hashCode()) * 31 + this.resubmissionEnforcer.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     protected static interface ResubmissionEnforcer
/*       */     {
/*       */       boolean isEnforced(String param2String, @MaybeNull ClassLoader param2ClassLoader, @MaybeNull JavaModule param2JavaModule, @MaybeNull Class<?> param2Class);
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Disabled
/*       */         implements ResubmissionEnforcer
/*       */       {
/*  8242 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isEnforced(String typeName, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined) {
/*  8248 */           return false;
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Proxied("java.lang.instrument.Instrumentation")
/*       */     protected static interface Dispatcher
/*       */     {
/*       */       @Proxied("isModifiableClass")
/*       */       boolean isModifiableClass(Instrumentation param2Instrumentation, Class<?> param2Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Defaults
/*       */       @Proxied("isRetransformClassesSupported")
/*       */       boolean isRetransformClassesSupported(Instrumentation param2Instrumentation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Proxied("retransformClasses")
/*       */       void retransformClasses(Instrumentation param2Instrumentation, Class<?>[] param2ArrayOfClass) throws UnmodifiableClassException;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static abstract class Collector
/*       */     {
/*       */       private final AgentBuilder.RawMatcher matcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final AgentBuilder.PoolStrategy poolStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final AgentBuilder.LocationStrategy locationStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final AgentBuilder.DescriptionStrategy descriptionStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final AgentBuilder.Listener listener;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final AgentBuilder.FallbackStrategy fallbackStrategy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final AgentBuilder.CircularityLock circularityLock;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<Class<?>> types;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Collector(AgentBuilder.RawMatcher matcher, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.Listener listener, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.CircularityLock circularityLock) {
/*  8350 */         this.matcher = matcher;
/*  8351 */         this.poolStrategy = poolStrategy;
/*  8352 */         this.locationStrategy = locationStrategy;
/*  8353 */         this.descriptionStrategy = descriptionStrategy;
/*  8354 */         this.listener = listener;
/*  8355 */         this.fallbackStrategy = fallbackStrategy;
/*  8356 */         this.circularityLock = circularityLock;
/*  8357 */         this.types = new ArrayList<Class<?>>();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void consider(Class<?> type, boolean modifiable) {
/*  8367 */         JavaModule module = JavaModule.ofType(type);
/*       */         try {
/*  8369 */           TypePool typePool = this.poolStrategy.typePool(this.locationStrategy.classFileLocator(type.getClassLoader(), module), type.getClassLoader());
/*       */           try {
/*  8371 */             doConsider(this.matcher, this.listener, this.descriptionStrategy
/*       */                 
/*  8373 */                 .apply(TypeDescription.ForLoadedType.getName(type), type, typePool, this.circularityLock, type.getClassLoader(), module), type, type, module, modifiable);
/*       */ 
/*       */ 
/*       */           
/*       */           }
/*  8378 */           catch (Throwable throwable) {
/*  8379 */             if (this.descriptionStrategy.isLoadedFirst() && this.fallbackStrategy.isFallback(type, throwable)) {
/*  8380 */               doConsider(this.matcher, this.listener, typePool
/*       */                   
/*  8382 */                   .describe(TypeDescription.ForLoadedType.getName(type)).resolve(), type, null, module, true);
/*       */             
/*       */             }
/*       */             else {
/*       */ 
/*       */               
/*  8388 */               throw throwable;
/*       */             } 
/*       */           } 
/*  8391 */         } catch (Throwable throwable) {
/*       */           try {
/*       */             try {
/*  8394 */               this.listener.onDiscovery(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, true);
/*       */             } finally {
/*       */               try {
/*  8397 */                 this.listener.onError(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, true, throwable);
/*       */               } finally {
/*  8399 */                 this.listener.onComplete(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, true);
/*       */               } 
/*       */             } 
/*  8402 */           } catch (Throwable throwable1) {}
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private void doConsider(AgentBuilder.RawMatcher matcher, AgentBuilder.Listener listener, TypeDescription typeDescription, Class<?> type, @MaybeNull Class<?> classBeingRedefined, @MaybeNull JavaModule module, boolean modifiable) {
/*  8426 */         if (!modifiable || !matcher.matches(typeDescription, type.getClassLoader(), module, classBeingRedefined, type.getProtectionDomain())) {
/*       */           try {
/*       */             try {
/*  8429 */               listener.onDiscovery(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, (classBeingRedefined != null));
/*  8430 */               listener.onIgnored(typeDescription, type.getClassLoader(), module, (classBeingRedefined != null));
/*  8431 */             } catch (Throwable throwable) {
/*  8432 */               listener.onError(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, (classBeingRedefined != null), throwable);
/*       */             } finally {
/*  8434 */               listener.onComplete(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, (classBeingRedefined != null));
/*       */             } 
/*  8436 */           } catch (Throwable throwable) {}
/*       */         }
/*       */         else {
/*       */           
/*  8440 */           this.types.add(type);
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected int apply(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener, int batch) {
/*  8457 */         Map<List<Class<?>>, Throwable> failures = new HashMap<List<Class<?>>, Throwable>();
/*  8458 */         PrependableIterator prependableIterator = new PrependableIterator(redefinitionBatchAllocator.batch(this.types));
/*  8459 */         while (prependableIterator.hasNext()) {
/*  8460 */           List<Class<?>> types = prependableIterator.next();
/*  8461 */           redefinitionListener.onBatch(batch, types, this.types);
/*       */           try {
/*  8463 */             doApply(instrumentation, types);
/*  8464 */           } catch (Throwable throwable) {
/*  8465 */             prependableIterator.prepend(redefinitionListener.onError(batch, types, throwable, this.types));
/*  8466 */             failures.put(types, throwable);
/*       */           } 
/*  8468 */           batch++;
/*       */         } 
/*  8470 */         redefinitionListener.onComplete(batch, this.types, failures);
/*  8471 */         return batch;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract void doApply(Instrumentation param2Instrumentation, List<Class<?>> param2List) throws UnmodifiableClassException, ClassNotFoundException;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class PrependableIterator
/*       */         implements Iterator<List<Class<?>>>
/*       */       {
/*       */         private Iterator<? extends List<Class<?>>> current;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final List<Iterator<? extends List<Class<?>>>> backlog;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected PrependableIterator(Iterable<? extends List<Class<?>>> origin) {
/*  8506 */           this.current = origin.iterator();
/*  8507 */           this.backlog = new ArrayList<Iterator<? extends List<Class<?>>>>();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void prepend(Iterable<? extends List<Class<?>>> iterable) {
/*  8516 */           Iterator<? extends List<Class<?>>> iterator = iterable.iterator();
/*  8517 */           if (iterator.hasNext()) {
/*  8518 */             if (this.current.hasNext()) {
/*  8519 */               this.backlog.add(this.current);
/*       */             }
/*  8521 */             this.current = iterator;
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean hasNext() {
/*  8529 */           return this.current.hasNext();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public List<Class<?>> next() {
/*       */           try {
/*  8537 */             return this.current.next();
/*       */           } finally {
/*  8539 */             while (!this.current.hasNext() && !this.backlog.isEmpty()) {
/*  8540 */               this.current = this.backlog.remove(this.backlog.size() - 1);
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void remove() {
/*  8549 */           throw new UnsupportedOperationException("remove");
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class ForRedefinition
/*       */         extends Collector
/*       */       {
/*       */         protected ForRedefinition(AgentBuilder.RawMatcher matcher, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.Listener listener, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.CircularityLock circularityLock) {
/*  8576 */           super(matcher, poolStrategy, locationStrategy, descriptionStrategy, listener, fallbackStrategy, circularityLock);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected void doApply(Instrumentation instrumentation, List<Class<?>> types) throws UnmodifiableClassException, ClassNotFoundException {
/*  8582 */           List<ClassDefinition> classDefinitions = new ArrayList<ClassDefinition>(types.size());
/*  8583 */           for (Class<?> type : types) {
/*       */             try {
/*       */               try {
/*  8586 */                 classDefinitions.add(new ClassDefinition(type, this.locationStrategy.classFileLocator(type.getClassLoader(), JavaModule.ofType(type))
/*  8587 */                       .locate(TypeDescription.ForLoadedType.getName(type))
/*  8588 */                       .resolve()));
/*  8589 */               } catch (Throwable throwable) {
/*  8590 */                 JavaModule module = JavaModule.ofType(type);
/*       */                 try {
/*  8592 */                   this.listener.onDiscovery(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, true);
/*       */                 } finally {
/*       */                   try {
/*  8595 */                     this.listener.onError(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, true, throwable);
/*       */                   } finally {
/*  8597 */                     this.listener.onComplete(TypeDescription.ForLoadedType.getName(type), type.getClassLoader(), module, true);
/*       */                   } 
/*       */                 } 
/*       */               } 
/*  8601 */             } catch (Throwable throwable) {}
/*       */           } 
/*       */ 
/*       */           
/*  8605 */           if (!classDefinitions.isEmpty()) {
/*  8606 */             this.circularityLock.release();
/*       */             try {
/*  8608 */               instrumentation.redefineClasses(classDefinitions.<ClassDefinition>toArray(new ClassDefinition[0]));
/*       */             } finally {
/*  8610 */               this.circularityLock.acquire();
/*       */             } 
/*       */           } 
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class ForRetransformation
/*       */         extends Collector
/*       */       {
/*       */         protected ForRetransformation(AgentBuilder.RawMatcher matcher, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.Listener listener, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.CircularityLock circularityLock) {
/*  8639 */           super(matcher, poolStrategy, locationStrategy, descriptionStrategy, listener, fallbackStrategy, circularityLock);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected void doApply(Instrumentation instrumentation, List<Class<?>> types) throws UnmodifiableClassException {
/*  8645 */           if (!types.isEmpty()) {
/*  8646 */             this.circularityLock.release();
/*       */             try {
/*  8648 */               AgentBuilder.RedefinitionStrategy.DISPATCHER.retransformClasses(instrumentation, (Class[])types.<Class<?>[]>toArray((Class<?>[][])new Class[0]));
/*       */             } finally {
/*  8650 */               this.circularityLock.acquire();
/*       */             } 
/*       */           } 
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public enum LambdaInstrumentationStrategy
/*       */   {
/*  8681 */     ENABLED
/*       */     {
/*       */       
/*       */       protected void apply(ByteBuddy byteBuddy, Instrumentation instrumentation, ClassFileTransformer classFileTransformer)
/*       */       {
/*  8686 */         if (LambdaFactory.register(classFileTransformer, new LambdaInstanceFactory(byteBuddy))) {
/*       */           Class<?> lambdaMetaFactory;
/*       */           try {
/*  8689 */             lambdaMetaFactory = Class.forName("java.lang.invoke.LambdaMetafactory");
/*  8690 */           } catch (ClassNotFoundException ignored) {
/*       */             return;
/*       */           } 
/*  8693 */           byteBuddy.with((Implementation.Context.Factory)Implementation.Context.Disabled.Factory.INSTANCE)
/*  8694 */             .redefine(lambdaMetaFactory)
/*  8695 */             .method((ElementMatcher)ElementMatchers.isPublic().and((ElementMatcher)ElementMatchers.named("metafactory")))
/*  8696 */             .intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { LambdaMetafactoryFactory.REGULAR
/*  8697 */                 })).method((ElementMatcher)ElementMatchers.isPublic().and((ElementMatcher)ElementMatchers.named("altMetafactory")))
/*  8698 */             .intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { LambdaMetafactoryFactory.ALTERNATIVE
/*  8699 */                 })).make()
/*  8700 */             .load(lambdaMetaFactory.getClassLoader(), (ClassLoadingStrategy)ClassReloadingStrategy.of(instrumentation));
/*       */         } 
/*       */       }
/*       */ 
/*       */       
/*       */       protected boolean isInstrumented(@MaybeNull Class<?> type) {
/*  8706 */         return true;
/*       */       }
/*       */     },
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8713 */     DISABLED
/*       */     {
/*       */       protected void apply(ByteBuddy byteBuddy, Instrumentation instrumentation, ClassFileTransformer classFileTransformer) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected boolean isInstrumented(@MaybeNull Class<?> type) {
/*  8723 */         return (type == null || !type.getName().contains("/"));
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static void release(ClassFileTransformer classFileTransformer, Instrumentation instrumentation) {
/*  8735 */       if (LambdaFactory.release(classFileTransformer)) {
/*       */         try {
/*  8737 */           ClassReloadingStrategy.of(instrumentation).reset(new Class[] { Class.forName("java.lang.invoke.LambdaMetafactory") });
/*  8738 */         } catch (Exception exception) {
/*  8739 */           throw new IllegalStateException("Could not release lambda transformer", exception);
/*       */         } 
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static LambdaInstrumentationStrategy of(boolean enabled) {
/*  8751 */       return enabled ? ENABLED : DISABLED;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean isEnabled() {
/*  8771 */       return (this == ENABLED);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract void apply(ByteBuddy param1ByteBuddy, Instrumentation param1Instrumentation, ClassFileTransformer param1ClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract boolean isInstrumented(@MaybeNull Class<?> param1Class);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected enum LambdaMetafactoryFactory
/*       */       implements ByteCodeAppender
/*       */     {
/*  8861 */       REGULAR(6, 11)
/*       */       {
/*       */         protected void onDispatch(MethodVisitor methodVisitor) {
/*  8864 */           methodVisitor.visitInsn(3);
/*  8865 */           methodVisitor.visitVarInsn(54, 6);
/*  8866 */           methodVisitor.visitMethodInsn(184, "java/util/Collections", "emptyList", "()Ljava/util/List;", false);
/*  8867 */           methodVisitor.visitVarInsn(58, 7);
/*  8868 */           methodVisitor.visitMethodInsn(184, "java/util/Collections", "emptyList", "()Ljava/util/List;", false);
/*  8869 */           methodVisitor.visitVarInsn(58, 8);
/*  8870 */           methodVisitor.visitFrame(1, 3, new Object[] { Opcodes.INTEGER, "java/util/List", "java/util/List" }, 0, null);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  8877 */       ALTERNATIVE(6, 16)
/*       */       {
/*       */         protected void onDispatch(MethodVisitor methodVisitor) {
/*  8880 */           methodVisitor.visitVarInsn(25, 3);
/*  8881 */           methodVisitor.visitInsn(6);
/*  8882 */           methodVisitor.visitInsn(50);
/*  8883 */           methodVisitor.visitTypeInsn(192, "java/lang/Integer");
/*  8884 */           methodVisitor.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I", false);
/*  8885 */           methodVisitor.visitVarInsn(54, 4);
/*  8886 */           methodVisitor.visitInsn(7);
/*  8887 */           methodVisitor.visitVarInsn(54, 5);
/*  8888 */           methodVisitor.visitVarInsn(21, 4);
/*  8889 */           methodVisitor.visitInsn(5);
/*  8890 */           methodVisitor.visitInsn(126);
/*  8891 */           Label first = new Label();
/*  8892 */           methodVisitor.visitJumpInsn(153, first);
/*  8893 */           methodVisitor.visitVarInsn(25, 3);
/*  8894 */           methodVisitor.visitVarInsn(21, 5);
/*  8895 */           methodVisitor.visitIincInsn(5, 1);
/*  8896 */           methodVisitor.visitInsn(50);
/*  8897 */           methodVisitor.visitTypeInsn(192, "java/lang/Integer");
/*  8898 */           methodVisitor.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I", false);
/*  8899 */           methodVisitor.visitVarInsn(54, 7);
/*  8900 */           methodVisitor.visitVarInsn(21, 7);
/*  8901 */           methodVisitor.visitTypeInsn(189, "java/lang/Class");
/*  8902 */           methodVisitor.visitVarInsn(58, 6);
/*  8903 */           methodVisitor.visitVarInsn(25, 3);
/*  8904 */           methodVisitor.visitVarInsn(21, 5);
/*  8905 */           methodVisitor.visitVarInsn(25, 6);
/*  8906 */           methodVisitor.visitInsn(3);
/*  8907 */           methodVisitor.visitVarInsn(21, 7);
/*  8908 */           methodVisitor.visitMethodInsn(184, "java/lang/System", "arraycopy", "(Ljava/lang/Object;ILjava/lang/Object;II)V", false);
/*  8909 */           methodVisitor.visitVarInsn(21, 5);
/*  8910 */           methodVisitor.visitVarInsn(21, 7);
/*  8911 */           methodVisitor.visitInsn(96);
/*  8912 */           methodVisitor.visitVarInsn(54, 5);
/*  8913 */           Label second = new Label();
/*  8914 */           methodVisitor.visitJumpInsn(167, second);
/*  8915 */           methodVisitor.visitLabel(first);
/*  8916 */           methodVisitor.visitFrame(1, 2, new Object[] { Opcodes.INTEGER, Opcodes.INTEGER }, 0, null);
/*  8917 */           methodVisitor.visitInsn(3);
/*  8918 */           methodVisitor.visitTypeInsn(189, "java/lang/Class");
/*  8919 */           methodVisitor.visitVarInsn(58, 6);
/*  8920 */           methodVisitor.visitLabel(second);
/*  8921 */           methodVisitor.visitFrame(1, 1, new Object[] { "[Ljava/lang/Class;" }, 0, null);
/*  8922 */           methodVisitor.visitVarInsn(21, 4);
/*  8923 */           methodVisitor.visitInsn(5);
/*  8924 */           methodVisitor.visitInsn(126);
/*  8925 */           Label third = new Label();
/*  8926 */           methodVisitor.visitJumpInsn(153, third);
/*  8927 */           methodVisitor.visitVarInsn(25, 3);
/*  8928 */           methodVisitor.visitVarInsn(21, 5);
/*  8929 */           methodVisitor.visitIincInsn(5, 1);
/*  8930 */           methodVisitor.visitInsn(50);
/*  8931 */           methodVisitor.visitTypeInsn(192, "java/lang/Integer");
/*  8932 */           methodVisitor.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I", false);
/*  8933 */           methodVisitor.visitVarInsn(54, 8);
/*  8934 */           methodVisitor.visitVarInsn(21, 8);
/*  8935 */           methodVisitor.visitTypeInsn(189, "java/lang/invoke/MethodType");
/*  8936 */           methodVisitor.visitVarInsn(58, 7);
/*  8937 */           methodVisitor.visitVarInsn(25, 3);
/*  8938 */           methodVisitor.visitVarInsn(21, 5);
/*  8939 */           methodVisitor.visitVarInsn(25, 7);
/*  8940 */           methodVisitor.visitInsn(3);
/*  8941 */           methodVisitor.visitVarInsn(21, 8);
/*  8942 */           methodVisitor.visitMethodInsn(184, "java/lang/System", "arraycopy", "(Ljava/lang/Object;ILjava/lang/Object;II)V", false);
/*  8943 */           Label forth = new Label();
/*  8944 */           methodVisitor.visitJumpInsn(167, forth);
/*  8945 */           methodVisitor.visitLabel(third);
/*  8946 */           methodVisitor.visitFrame(3, 0, null, 0, null);
/*  8947 */           methodVisitor.visitInsn(3);
/*  8948 */           methodVisitor.visitTypeInsn(189, "java/lang/invoke/MethodType");
/*  8949 */           methodVisitor.visitVarInsn(58, 7);
/*  8950 */           methodVisitor.visitLabel(forth);
/*  8951 */           methodVisitor.visitFrame(1, 1, new Object[] { "[Ljava/lang/invoke/MethodType;" }, 0, null);
/*  8952 */           methodVisitor.visitVarInsn(25, 3);
/*  8953 */           methodVisitor.visitInsn(3);
/*  8954 */           methodVisitor.visitInsn(50);
/*  8955 */           methodVisitor.visitTypeInsn(192, "java/lang/invoke/MethodType");
/*  8956 */           methodVisitor.visitVarInsn(58, 8);
/*  8957 */           methodVisitor.visitVarInsn(25, 3);
/*  8958 */           methodVisitor.visitInsn(4);
/*  8959 */           methodVisitor.visitInsn(50);
/*  8960 */           methodVisitor.visitTypeInsn(192, "java/lang/invoke/MethodHandle");
/*  8961 */           methodVisitor.visitVarInsn(58, 9);
/*  8962 */           methodVisitor.visitVarInsn(25, 3);
/*  8963 */           methodVisitor.visitInsn(5);
/*  8964 */           methodVisitor.visitInsn(50);
/*  8965 */           methodVisitor.visitTypeInsn(192, "java/lang/invoke/MethodType");
/*  8966 */           methodVisitor.visitVarInsn(58, 10);
/*  8967 */           methodVisitor.visitVarInsn(21, 4);
/*  8968 */           methodVisitor.visitInsn(4);
/*  8969 */           methodVisitor.visitInsn(126);
/*  8970 */           Label fifth = new Label();
/*  8971 */           methodVisitor.visitJumpInsn(153, fifth);
/*  8972 */           methodVisitor.visitInsn(4);
/*  8973 */           Label sixth = new Label();
/*  8974 */           methodVisitor.visitJumpInsn(167, sixth);
/*  8975 */           methodVisitor.visitLabel(fifth);
/*  8976 */           methodVisitor.visitFrame(1, 3, new Object[] { "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType" }, 0, null);
/*  8977 */           methodVisitor.visitInsn(3);
/*  8978 */           methodVisitor.visitLabel(sixth);
/*  8979 */           methodVisitor.visitFrame(4, 0, null, 1, new Object[] { Opcodes.INTEGER });
/*  8980 */           methodVisitor.visitVarInsn(54, 11);
/*  8981 */           methodVisitor.visitVarInsn(25, 6);
/*  8982 */           methodVisitor.visitMethodInsn(184, "java/util/Arrays", "asList", "([Ljava/lang/Object;)Ljava/util/List;", false);
/*  8983 */           methodVisitor.visitVarInsn(58, 12);
/*  8984 */           methodVisitor.visitVarInsn(25, 7);
/*  8985 */           methodVisitor.visitMethodInsn(184, "java/util/Arrays", "asList", "([Ljava/lang/Object;)Ljava/util/List;", false);
/*  8986 */           methodVisitor.visitVarInsn(58, 13);
/*  8987 */           methodVisitor.visitVarInsn(25, 8);
/*  8988 */           methodVisitor.visitVarInsn(58, 3);
/*  8989 */           methodVisitor.visitVarInsn(25, 9);
/*  8990 */           methodVisitor.visitVarInsn(58, 4);
/*  8991 */           methodVisitor.visitVarInsn(25, 10);
/*  8992 */           methodVisitor.visitVarInsn(58, 5);
/*  8993 */           methodVisitor.visitVarInsn(21, 11);
/*  8994 */           methodVisitor.visitVarInsn(54, 6);
/*  8995 */           methodVisitor.visitVarInsn(25, 12);
/*  8996 */           methodVisitor.visitVarInsn(58, 7);
/*  8997 */           methodVisitor.visitVarInsn(25, 13);
/*  8998 */           methodVisitor.visitVarInsn(58, 8);
/*  8999 */           methodVisitor.visitFrame(0, 9, new Object[] { "java/lang/invoke/MethodHandles$Lookup", "java/lang/String", "java/lang/invoke/MethodType", "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType", Opcodes.INTEGER, "java/util/List", "java/util/List" }, 0, null);
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9014 */       private static final Loader LOADER = resolve(); private final int stackSize;
/*       */       private final int localVariableLength;
/*       */       
/*       */       static {
/*       */       
/*       */       }
/*       */       
/*       */       @SuppressFBWarnings(value = {"DE_MIGHT_IGNORE", "REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*       */       private static Loader resolve() {
/*       */         try {
/*  9024 */           Class<?> type = Class.forName("java.lang.invoke.MethodHandles$Lookup", false, (ClassLoader)null);
/*  9025 */           type.getMethod("defineHiddenClass", new Class[] { byte[].class, boolean.class, 
/*       */ 
/*       */                 
/*  9028 */                 Class.forName("[Ljava.lang.invoke.MethodHandles$Lookup$ClassOption;", false, (ClassLoader)null) });
/*  9029 */           type.getMethod("defineHiddenClassWithClassData", new Class[] { byte[].class, Object.class, boolean.class, 
/*       */ 
/*       */ 
/*       */                 
/*  9033 */                 Class.forName("[Ljava.lang.invoke.MethodHandles$Lookup$ClassOption;", false, (ClassLoader)null) });
/*  9034 */           return Loader.UsingMethodHandleLookup.INSTANCE;
/*  9035 */         } catch (Exception exception) {
/*       */ 
/*       */           
/*  9038 */           for (Loader.UsingUnsafe loader : Loader.UsingUnsafe.values()) {
/*       */             try {
/*  9040 */               Class.forName(loader.getType().replace('/', '.'), false, (ClassLoader)null)
/*       */                 
/*  9042 */                 .getMethod("defineAnonymousClass", new Class[] { Class.class, byte[].class, Object[].class });
/*  9043 */               return loader;
/*  9044 */             } catch (Exception exception1) {}
/*       */           } 
/*       */ 
/*       */           
/*  9048 */           return Loader.Unavailable.INSTANCE;
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       LambdaMetafactoryFactory(int stackSize, int localVariableLength) {
/*  9068 */         this.stackSize = stackSize;
/*  9069 */         this.localVariableLength = localVariableLength;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  9076 */         onDispatch(methodVisitor);
/*  9077 */         methodVisitor.visitMethodInsn(184, "java/lang/ClassLoader", "getSystemClassLoader", "()Ljava/lang/ClassLoader;", false);
/*  9078 */         methodVisitor.visitLdcInsn("net.bytebuddy.agent.builder.LambdaFactory");
/*  9079 */         methodVisitor.visitMethodInsn(182, "java/lang/ClassLoader", "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;", false);
/*  9080 */         methodVisitor.visitLdcInsn("make");
/*  9081 */         methodVisitor.visitIntInsn(16, 9);
/*  9082 */         methodVisitor.visitTypeInsn(189, "java/lang/Class");
/*  9083 */         methodVisitor.visitInsn(89);
/*  9084 */         methodVisitor.visitInsn(3);
/*  9085 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/lang/Object;"));
/*  9086 */         methodVisitor.visitInsn(83);
/*  9087 */         methodVisitor.visitInsn(89);
/*  9088 */         methodVisitor.visitInsn(4);
/*  9089 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/lang/String;"));
/*  9090 */         methodVisitor.visitInsn(83);
/*  9091 */         methodVisitor.visitInsn(89);
/*  9092 */         methodVisitor.visitInsn(5);
/*  9093 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/lang/Object;"));
/*  9094 */         methodVisitor.visitInsn(83);
/*  9095 */         methodVisitor.visitInsn(89);
/*  9096 */         methodVisitor.visitInsn(6);
/*  9097 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/lang/Object;"));
/*  9098 */         methodVisitor.visitInsn(83);
/*  9099 */         methodVisitor.visitInsn(89);
/*  9100 */         methodVisitor.visitInsn(7);
/*  9101 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/lang/Object;"));
/*  9102 */         methodVisitor.visitInsn(83);
/*  9103 */         methodVisitor.visitInsn(89);
/*  9104 */         methodVisitor.visitInsn(8);
/*  9105 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/lang/Object;"));
/*  9106 */         methodVisitor.visitInsn(83);
/*  9107 */         methodVisitor.visitInsn(89);
/*  9108 */         methodVisitor.visitIntInsn(16, 6);
/*  9109 */         methodVisitor.visitFieldInsn(178, "java/lang/Boolean", "TYPE", "Ljava/lang/Class;");
/*  9110 */         methodVisitor.visitInsn(83);
/*  9111 */         methodVisitor.visitInsn(89);
/*  9112 */         methodVisitor.visitIntInsn(16, 7);
/*  9113 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/util/List;"));
/*  9114 */         methodVisitor.visitInsn(83);
/*  9115 */         methodVisitor.visitInsn(89);
/*  9116 */         methodVisitor.visitIntInsn(16, 8);
/*  9117 */         methodVisitor.visitLdcInsn(Type.getType("Ljava/util/List;"));
/*  9118 */         methodVisitor.visitInsn(83);
/*  9119 */         methodVisitor.visitMethodInsn(182, "java/lang/Class", "getDeclaredMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;", false);
/*  9120 */         methodVisitor.visitInsn(1);
/*  9121 */         methodVisitor.visitIntInsn(16, 9);
/*  9122 */         methodVisitor.visitTypeInsn(189, "java/lang/Object");
/*  9123 */         methodVisitor.visitInsn(89);
/*  9124 */         methodVisitor.visitInsn(3);
/*  9125 */         methodVisitor.visitVarInsn(25, 0);
/*  9126 */         methodVisitor.visitInsn(83);
/*  9127 */         methodVisitor.visitInsn(89);
/*  9128 */         methodVisitor.visitInsn(4);
/*  9129 */         methodVisitor.visitVarInsn(25, 1);
/*  9130 */         methodVisitor.visitInsn(83);
/*  9131 */         methodVisitor.visitInsn(89);
/*  9132 */         methodVisitor.visitInsn(5);
/*  9133 */         methodVisitor.visitVarInsn(25, 2);
/*  9134 */         methodVisitor.visitInsn(83);
/*  9135 */         methodVisitor.visitInsn(89);
/*  9136 */         methodVisitor.visitInsn(6);
/*  9137 */         methodVisitor.visitVarInsn(25, 3);
/*  9138 */         methodVisitor.visitInsn(83);
/*  9139 */         methodVisitor.visitInsn(89);
/*  9140 */         methodVisitor.visitInsn(7);
/*  9141 */         methodVisitor.visitVarInsn(25, 4);
/*  9142 */         methodVisitor.visitInsn(83);
/*  9143 */         methodVisitor.visitInsn(89);
/*  9144 */         methodVisitor.visitInsn(8);
/*  9145 */         methodVisitor.visitVarInsn(25, 5);
/*  9146 */         methodVisitor.visitInsn(83);
/*  9147 */         methodVisitor.visitInsn(89);
/*  9148 */         methodVisitor.visitIntInsn(16, 6);
/*  9149 */         methodVisitor.visitVarInsn(21, 6);
/*  9150 */         methodVisitor.visitMethodInsn(184, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", false);
/*  9151 */         methodVisitor.visitInsn(83);
/*  9152 */         methodVisitor.visitInsn(89);
/*  9153 */         methodVisitor.visitIntInsn(16, 7);
/*  9154 */         methodVisitor.visitVarInsn(25, 7);
/*  9155 */         methodVisitor.visitInsn(83);
/*  9156 */         methodVisitor.visitInsn(89);
/*  9157 */         methodVisitor.visitIntInsn(16, 8);
/*  9158 */         methodVisitor.visitVarInsn(25, 8);
/*  9159 */         methodVisitor.visitInsn(83);
/*  9160 */         methodVisitor.visitMethodInsn(182, "java/lang/reflect/Method", "invoke", "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;", false);
/*  9161 */         methodVisitor.visitTypeInsn(192, "[B");
/*  9162 */         methodVisitor.visitVarInsn(58, 9);
/*  9163 */         LOADER.apply(methodVisitor);
/*  9164 */         methodVisitor.visitVarInsn(25, 2);
/*  9165 */         methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodType", "parameterCount", "()I", false);
/*  9166 */         Label first = new Label();
/*  9167 */         methodVisitor.visitJumpInsn(154, first);
/*  9168 */         methodVisitor.visitTypeInsn(187, "java/lang/invoke/ConstantCallSite");
/*  9169 */         methodVisitor.visitInsn(89);
/*  9170 */         methodVisitor.visitVarInsn(25, 2);
/*  9171 */         methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodType", "returnType", "()Ljava/lang/Class;", false);
/*  9172 */         methodVisitor.visitVarInsn(25, 10);
/*  9173 */         methodVisitor.visitMethodInsn(182, "java/lang/Class", "getDeclaredConstructors", "()[Ljava/lang/reflect/Constructor;", false);
/*  9174 */         methodVisitor.visitInsn(3);
/*  9175 */         methodVisitor.visitInsn(50);
/*  9176 */         methodVisitor.visitInsn(3);
/*  9177 */         methodVisitor.visitTypeInsn(189, "java/lang/Object");
/*  9178 */         methodVisitor.visitMethodInsn(182, "java/lang/reflect/Constructor", "newInstance", "([Ljava/lang/Object;)Ljava/lang/Object;", false);
/*  9179 */         methodVisitor.visitMethodInsn(184, "java/lang/invoke/MethodHandles", "constant", "(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/invoke/MethodHandle;", false);
/*  9180 */         methodVisitor.visitMethodInsn(183, "java/lang/invoke/ConstantCallSite", "<init>", "(Ljava/lang/invoke/MethodHandle;)V", false);
/*  9181 */         Label second = new Label();
/*  9182 */         methodVisitor.visitJumpInsn(167, second);
/*  9183 */         methodVisitor.visitLabel(first);
/*  9184 */         methodVisitor.visitFrame(0, 11, new Object[] { "java/lang/invoke/MethodHandles$Lookup", "java/lang/String", "java/lang/invoke/MethodType", "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType", Opcodes.INTEGER, "java/util/List", "java/util/List", "[B", "java/lang/Class" }, 0, new Object[0]);
/*  9185 */         methodVisitor.visitTypeInsn(187, "java/lang/invoke/ConstantCallSite");
/*  9186 */         methodVisitor.visitInsn(89);
/*  9187 */         methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup", "IMPL_LOOKUP", "Ljava/lang/invoke/MethodHandles$Lookup;");
/*  9188 */         methodVisitor.visitVarInsn(25, 10);
/*  9189 */         methodVisitor.visitLdcInsn("get$Lambda");
/*  9190 */         methodVisitor.visitVarInsn(25, 2);
/*  9191 */         methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "findStatic", "(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/MethodHandle;", false);
/*  9192 */         methodVisitor.visitMethodInsn(183, "java/lang/invoke/ConstantCallSite", "<init>", "(Ljava/lang/invoke/MethodHandle;)V", false);
/*  9193 */         methodVisitor.visitLabel(second);
/*  9194 */         methodVisitor.visitFrame(4, 0, null, 1, new Object[] { "java/lang/invoke/CallSite" });
/*  9195 */         methodVisitor.visitInsn(176);
/*  9196 */         return new ByteCodeAppender.Size(Math.max(this.stackSize, LOADER.getStackSize()), Math.max(this.localVariableLength, LOADER.getLocalVariableLength()));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract void onDispatch(MethodVisitor param2MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Unavailable
/*       */         implements Loader
/*       */       {
/*  9241 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void apply(MethodVisitor methodVisitor) {
/*  9247 */           throw new IllegalStateException("No lambda expression loading strategy available on current VM");
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getStackSize() {
/*  9254 */           throw new IllegalStateException("No lambda expression loading strategy available on current VM");
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getLocalVariableLength() {
/*  9261 */           throw new IllegalStateException("No lambda expression loading strategy available on current VM");
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum UsingMethodHandleLookup
/*       */         implements Loader
/*       */       {
/*  9293 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void apply(MethodVisitor methodVisitor) {
/*  9299 */           methodVisitor.visitVarInsn(25, 0);
/*  9300 */           methodVisitor.visitVarInsn(25, 4);
/*  9301 */           methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "revealDirect", "(Ljava/lang/invoke/MethodHandle;)Ljava/lang/invoke/MethodHandleInfo;", false);
/*  9302 */           methodVisitor.visitVarInsn(58, 10);
/*  9303 */           methodVisitor.visitVarInsn(25, 10);
/*  9304 */           methodVisitor.visitMethodInsn(185, "java/lang/invoke/MethodHandleInfo", "getModifiers", "()I", true);
/*  9305 */           methodVisitor.visitMethodInsn(184, "java/lang/reflect/Modifier", "isProtected", "(I)Z", false);
/*  9306 */           Label first = new Label();
/*  9307 */           methodVisitor.visitJumpInsn(153, first);
/*  9308 */           methodVisitor.visitVarInsn(25, 0);
/*  9309 */           methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "lookupClass", "()Ljava/lang/Class;", false);
/*  9310 */           methodVisitor.visitVarInsn(25, 10);
/*  9311 */           methodVisitor.visitMethodInsn(185, "java/lang/invoke/MethodHandleInfo", "getDeclaringClass", "()Ljava/lang/Class;", true);
/*  9312 */           methodVisitor.visitMethodInsn(184, "sun/invoke/util/VerifyAccess", "isSamePackage", "(Ljava/lang/Class;Ljava/lang/Class;)Z", false);
/*  9313 */           Label second = new Label();
/*  9314 */           methodVisitor.visitJumpInsn(153, second);
/*  9315 */           methodVisitor.visitLabel(first);
/*  9316 */           methodVisitor.visitFrame(0, 11, new Object[] { "java/lang/invoke/MethodHandles$Lookup", "java/lang/String", "java/lang/invoke/MethodType", "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType", Opcodes.INTEGER, "java/util/List", "java/util/List", "[B", "java/lang/invoke/MethodHandleInfo" }, 0, new Object[0]);
/*  9317 */           methodVisitor.visitVarInsn(25, 10);
/*  9318 */           methodVisitor.visitMethodInsn(185, "java/lang/invoke/MethodHandleInfo", "getReferenceKind", "()I", true);
/*  9319 */           methodVisitor.visitIntInsn(16, 7);
/*  9320 */           Label third = new Label();
/*  9321 */           methodVisitor.visitJumpInsn(160, third);
/*  9322 */           methodVisitor.visitLabel(second);
/*  9323 */           methodVisitor.visitFrame(3, 0, null, 0, null);
/*  9324 */           methodVisitor.visitInsn(4);
/*  9325 */           Label forth = new Label();
/*  9326 */           methodVisitor.visitJumpInsn(167, forth);
/*  9327 */           methodVisitor.visitLabel(third);
/*  9328 */           methodVisitor.visitFrame(3, 0, null, 0, null);
/*  9329 */           methodVisitor.visitInsn(3);
/*  9330 */           methodVisitor.visitLabel(forth);
/*  9331 */           methodVisitor.visitFrame(4, 0, null, 1, new Object[] { Opcodes.INTEGER });
/*  9332 */           methodVisitor.visitVarInsn(54, 11);
/*  9333 */           methodVisitor.visitVarInsn(21, 11);
/*  9334 */           Label fifth = new Label();
/*  9335 */           methodVisitor.visitJumpInsn(153, fifth);
/*  9336 */           methodVisitor.visitVarInsn(25, 0);
/*  9337 */           methodVisitor.visitVarInsn(25, 9);
/*  9338 */           methodVisitor.visitVarInsn(25, 10);
/*  9339 */           methodVisitor.visitInsn(4);
/*  9340 */           methodVisitor.visitInsn(5);
/*  9341 */           methodVisitor.visitTypeInsn(189, "java/lang/invoke/MethodHandles$Lookup$ClassOption");
/*  9342 */           methodVisitor.visitInsn(89);
/*  9343 */           methodVisitor.visitInsn(3);
/*  9344 */           methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "NESTMATE", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;");
/*  9345 */           methodVisitor.visitInsn(83);
/*  9346 */           methodVisitor.visitInsn(89);
/*  9347 */           methodVisitor.visitInsn(4);
/*  9348 */           methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "STRONG", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;");
/*  9349 */           methodVisitor.visitInsn(83);
/*  9350 */           methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "defineHiddenClassWithClassData", "([BLjava/lang/Object;Z[Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;)Ljava/lang/invoke/MethodHandles$Lookup;", false);
/*  9351 */           methodVisitor.visitVarInsn(58, 12);
/*  9352 */           Label sixth = new Label();
/*  9353 */           methodVisitor.visitLabel(sixth);
/*  9354 */           Label seventh = new Label();
/*  9355 */           methodVisitor.visitJumpInsn(167, seventh);
/*  9356 */           methodVisitor.visitLabel(fifth);
/*  9357 */           methodVisitor.visitFrame(1, 1, new Object[] { Opcodes.INTEGER }, 0, null);
/*  9358 */           methodVisitor.visitVarInsn(25, 0);
/*  9359 */           methodVisitor.visitVarInsn(25, 9);
/*  9360 */           methodVisitor.visitInsn(4);
/*  9361 */           methodVisitor.visitInsn(5);
/*  9362 */           methodVisitor.visitTypeInsn(189, "java/lang/invoke/MethodHandles$Lookup$ClassOption");
/*  9363 */           methodVisitor.visitInsn(89);
/*  9364 */           methodVisitor.visitInsn(3);
/*  9365 */           methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "NESTMATE", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;");
/*  9366 */           methodVisitor.visitInsn(83);
/*  9367 */           methodVisitor.visitInsn(89);
/*  9368 */           methodVisitor.visitInsn(4);
/*  9369 */           methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "STRONG", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;");
/*  9370 */           methodVisitor.visitInsn(83);
/*  9371 */           methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "defineHiddenClass", "([BZ[Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;)Ljava/lang/invoke/MethodHandles$Lookup;", false);
/*  9372 */           methodVisitor.visitVarInsn(58, 12);
/*  9373 */           methodVisitor.visitLabel(seventh);
/*  9374 */           methodVisitor.visitFrame(1, 1, new Object[] { "java/lang/invoke/MethodHandles$Lookup" }, 0, null);
/*  9375 */           methodVisitor.visitVarInsn(25, 12);
/*  9376 */           methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "lookupClass", "()Ljava/lang/Class;", false);
/*  9377 */           methodVisitor.visitVarInsn(58, 10);
/*  9378 */           methodVisitor.visitFrame(0, 10, new Object[] { "java/lang/invoke/MethodHandles$Lookup", "java/lang/String", "java/lang/invoke/MethodType", "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType", Opcodes.INTEGER, "java/util/List", "java/util/List", "java/lang/Class" }, 0, null);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getStackSize() {
/*  9394 */           return 8;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int getLocalVariableLength()
/*       */         {
/*  9401 */           return 15; } } protected static interface Loader { void apply(MethodVisitor param3MethodVisitor); int getStackSize(); int getLocalVariableLength(); public enum Unavailable implements Loader { INSTANCE; public void apply(MethodVisitor methodVisitor) { throw new IllegalStateException("No lambda expression loading strategy available on current VM"); } public int getStackSize() { throw new IllegalStateException("No lambda expression loading strategy available on current VM"); } public int getLocalVariableLength() { throw new IllegalStateException("No lambda expression loading strategy available on current VM"); } } public enum UsingMethodHandleLookup implements Loader { INSTANCE; public void apply(MethodVisitor methodVisitor) { methodVisitor.visitVarInsn(25, 0); methodVisitor.visitVarInsn(25, 4); methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "revealDirect", "(Ljava/lang/invoke/MethodHandle;)Ljava/lang/invoke/MethodHandleInfo;", false); methodVisitor.visitVarInsn(58, 10); methodVisitor.visitVarInsn(25, 10); methodVisitor.visitMethodInsn(185, "java/lang/invoke/MethodHandleInfo", "getModifiers", "()I", true); methodVisitor.visitMethodInsn(184, "java/lang/reflect/Modifier", "isProtected", "(I)Z", false); Label first = new Label(); methodVisitor.visitJumpInsn(153, first); methodVisitor.visitVarInsn(25, 0); methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "lookupClass", "()Ljava/lang/Class;", false); methodVisitor.visitVarInsn(25, 10); methodVisitor.visitMethodInsn(185, "java/lang/invoke/MethodHandleInfo", "getDeclaringClass", "()Ljava/lang/Class;", true); methodVisitor.visitMethodInsn(184, "sun/invoke/util/VerifyAccess", "isSamePackage", "(Ljava/lang/Class;Ljava/lang/Class;)Z", false); Label second = new Label(); methodVisitor.visitJumpInsn(153, second); methodVisitor.visitLabel(first); methodVisitor.visitFrame(0, 11, new Object[] { "java/lang/invoke/MethodHandles$Lookup", "java/lang/String", "java/lang/invoke/MethodType", "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType", Opcodes.INTEGER, "java/util/List", "java/util/List", "[B", "java/lang/invoke/MethodHandleInfo" }, 0, new Object[0]); methodVisitor.visitVarInsn(25, 10); methodVisitor.visitMethodInsn(185, "java/lang/invoke/MethodHandleInfo", "getReferenceKind", "()I", true); methodVisitor.visitIntInsn(16, 7); Label third = new Label(); methodVisitor.visitJumpInsn(160, third); methodVisitor.visitLabel(second); methodVisitor.visitFrame(3, 0, null, 0, null); methodVisitor.visitInsn(4); Label forth = new Label(); methodVisitor.visitJumpInsn(167, forth); methodVisitor.visitLabel(third); methodVisitor.visitFrame(3, 0, null, 0, null); methodVisitor.visitInsn(3); methodVisitor.visitLabel(forth); methodVisitor.visitFrame(4, 0, null, 1, new Object[] { Opcodes.INTEGER }); methodVisitor.visitVarInsn(54, 11); methodVisitor.visitVarInsn(21, 11); Label fifth = new Label(); methodVisitor.visitJumpInsn(153, fifth); methodVisitor.visitVarInsn(25, 0); methodVisitor.visitVarInsn(25, 9); methodVisitor.visitVarInsn(25, 10); methodVisitor.visitInsn(4); methodVisitor.visitInsn(5); methodVisitor.visitTypeInsn(189, "java/lang/invoke/MethodHandles$Lookup$ClassOption"); methodVisitor.visitInsn(89); methodVisitor.visitInsn(3); methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "NESTMATE", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;"); methodVisitor.visitInsn(83); methodVisitor.visitInsn(89); methodVisitor.visitInsn(4); methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "STRONG", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;"); methodVisitor.visitInsn(83); methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "defineHiddenClassWithClassData", "([BLjava/lang/Object;Z[Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;)Ljava/lang/invoke/MethodHandles$Lookup;", false); methodVisitor.visitVarInsn(58, 12); Label sixth = new Label(); methodVisitor.visitLabel(sixth); Label seventh = new Label(); methodVisitor.visitJumpInsn(167, seventh); methodVisitor.visitLabel(fifth); methodVisitor.visitFrame(1, 1, new Object[] { Opcodes.INTEGER }, 0, null); methodVisitor.visitVarInsn(25, 0); methodVisitor.visitVarInsn(25, 9); methodVisitor.visitInsn(4); methodVisitor.visitInsn(5); methodVisitor.visitTypeInsn(189, "java/lang/invoke/MethodHandles$Lookup$ClassOption"); methodVisitor.visitInsn(89); methodVisitor.visitInsn(3); methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "NESTMATE", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;"); methodVisitor.visitInsn(83); methodVisitor.visitInsn(89); methodVisitor.visitInsn(4); methodVisitor.visitFieldInsn(178, "java/lang/invoke/MethodHandles$Lookup$ClassOption", "STRONG", "Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;"); methodVisitor.visitInsn(83); methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "defineHiddenClass", "([BZ[Ljava/lang/invoke/MethodHandles$Lookup$ClassOption;)Ljava/lang/invoke/MethodHandles$Lookup;", false); methodVisitor.visitVarInsn(58, 12); methodVisitor.visitLabel(seventh); methodVisitor.visitFrame(1, 1, new Object[] { "java/lang/invoke/MethodHandles$Lookup" }, 0, null); methodVisitor.visitVarInsn(25, 12); methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "lookupClass", "()Ljava/lang/Class;", false); methodVisitor.visitVarInsn(58, 10); methodVisitor.visitFrame(0, 10, new Object[] { "java/lang/invoke/MethodHandles$Lookup", "java/lang/String", "java/lang/invoke/MethodType", "java/lang/invoke/MethodType", "java/lang/invoke/MethodHandle", "java/lang/invoke/MethodType", Opcodes.INTEGER, "java/util/List", "java/util/List", "java/lang/Class" }, 0, null); } public int getLocalVariableLength() { return 15; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int getStackSize() {
/*       */             return 8;
/*       */           } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public enum UsingUnsafe
/*       */           implements Loader
/*       */         {
/*  9421 */           JDK_INTERNAL_MISC_UNSAFE("jdk/internal/misc/Unsafe"),
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  9426 */           SUN_MISC_UNSAFE("sun/misc/Unsafe");
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final String type;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           UsingUnsafe(String type) {
/*  9439 */             this.type = type;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected String getType() {
/*  9448 */             return this.type;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void apply(MethodVisitor methodVisitor) {
/*  9455 */             methodVisitor.visitMethodInsn(184, this.type, "getUnsafe", "()L" + this.type + ";", false);
/*  9456 */             methodVisitor.visitVarInsn(58, 11);
/*  9457 */             methodVisitor.visitVarInsn(25, 11);
/*  9458 */             methodVisitor.visitVarInsn(25, 0);
/*  9459 */             methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "lookupClass", "()Ljava/lang/Class;", false);
/*  9460 */             methodVisitor.visitVarInsn(25, 9);
/*  9461 */             methodVisitor.visitInsn(1);
/*  9462 */             methodVisitor.visitMethodInsn(182, this.type, "defineAnonymousClass", "(Ljava/lang/Class;[B[Ljava/lang/Object;)Ljava/lang/Class;", false);
/*  9463 */             methodVisitor.visitVarInsn(58, 10);
/*  9464 */             methodVisitor.visitVarInsn(25, 11);
/*  9465 */             methodVisitor.visitVarInsn(25, 10);
/*  9466 */             methodVisitor.visitMethodInsn(182, this.type, "ensureClassInitialized", "(Ljava/lang/Class;)V", false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int getStackSize() {
/*  9473 */             return 4;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int getLocalVariableLength()
/*       */           {
/*  9480 */             return 13; } } } public enum UsingUnsafe implements Loader { JDK_INTERNAL_MISC_UNSAFE("jdk/internal/misc/Unsafe"), SUN_MISC_UNSAFE("sun/misc/Unsafe"); private final String type; UsingUnsafe(String type) { this.type = type; } protected String getType() { return this.type; } public void apply(MethodVisitor methodVisitor) { methodVisitor.visitMethodInsn(184, this.type, "getUnsafe", "()L" + this.type + ";", false); methodVisitor.visitVarInsn(58, 11); methodVisitor.visitVarInsn(25, 11); methodVisitor.visitVarInsn(25, 0); methodVisitor.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "lookupClass", "()Ljava/lang/Class;", false); methodVisitor.visitVarInsn(25, 9); methodVisitor.visitInsn(1); methodVisitor.visitMethodInsn(182, this.type, "defineAnonymousClass", "(Ljava/lang/Class;[B[Ljava/lang/Object;)Ljava/lang/Class;", false); methodVisitor.visitVarInsn(58, 10); methodVisitor.visitVarInsn(25, 11); methodVisitor.visitVarInsn(25, 10); methodVisitor.visitMethodInsn(182, this.type, "ensureClassInitialized", "(Ljava/lang/Class;)V", false); } public int getStackSize() { return 4; } public int getLocalVariableLength() { return 13; }
/*       */          }
/*       */     
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     protected static class LambdaInstanceFactory
/*       */     {
/*       */       private static final String LAMBDA_FACTORY = "get$Lambda";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private static final String FIELD_PREFIX = "arg$";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private static final String LAMBDA_TYPE_INFIX = "$$Lambda$ByteBuddy$";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @AlwaysNull
/*  9513 */       private static final Class<?> NOT_PREVIOUSLY_DEFINED = null;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  9518 */       private static final AtomicInteger LAMBDA_NAME_COUNTER = new AtomicInteger();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final ByteBuddy byteBuddy;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected LambdaInstanceFactory(ByteBuddy byteBuddy) {
/*  9531 */         this.byteBuddy = byteBuddy;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public byte[] make(Object targetTypeLookup, String lambdaMethodName, Object factoryMethodType, Object lambdaMethodType, Object targetMethodHandle, Object specializedLambdaMethodType, boolean serializable, List<Class<?>> markerInterfaces, List<?> additionalBridges, Collection<? extends ClassFileTransformer> classFileTransformers) {
/*       */         DynamicType.Builder.FieldDefinition.Optional.Valuable valuable;
/*       */         DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition1;
/*  9559 */         JavaConstant.MethodType factoryMethod = JavaConstant.MethodType.ofLoaded(factoryMethodType);
/*  9560 */         JavaConstant.MethodType lambdaMethod = JavaConstant.MethodType.ofLoaded(lambdaMethodType);
/*  9561 */         JavaConstant.MethodHandle targetMethod = JavaConstant.MethodHandle.ofLoaded(targetMethodHandle, targetTypeLookup);
/*  9562 */         JavaConstant.MethodType specializedLambdaMethod = JavaConstant.MethodType.ofLoaded(specializedLambdaMethodType);
/*  9563 */         Class<?> targetType = JavaConstant.MethodHandle.lookupType(targetTypeLookup);
/*  9564 */         String lambdaClassName = targetType.getName() + "$$Lambda$ByteBuddy$" + LAMBDA_NAME_COUNTER.incrementAndGet();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  9576 */         DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition2 = this.byteBuddy.subclass((TypeDefinition)factoryMethod.getReturnType(), (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).modifiers(new ModifierContributor.ForType[] { (ModifierContributor.ForType)TypeManifestation.FINAL, (ModifierContributor.ForType)Visibility.PUBLIC }).implement(markerInterfaces).name(lambdaClassName).defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters((Collection)factoryMethod.getParameterTypes()).intercept(ConstructorImplementation.INSTANCE).method((ElementMatcher)ElementMatchers.named(lambdaMethodName).and((ElementMatcher)ElementMatchers.takesArguments((Iterable)lambdaMethod.getParameterTypes())).and((ElementMatcher)ElementMatchers.returns(lambdaMethod.getReturnType()))).intercept(new LambdaMethodImplementation(TypeDescription.ForLoadedType.of(targetType), targetMethod, specializedLambdaMethod));
/*  9577 */         int index = 0;
/*  9578 */         for (TypeDescription capturedType : factoryMethod.getParameterTypes()) {
/*  9579 */           valuable = receiverTypeDefinition2.defineField("arg$" + ++index, (TypeDefinition)capturedType, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)FieldManifestation.FINAL });
/*       */         } 
/*  9581 */         if (!factoryMethod.getParameterTypes().isEmpty())
/*       */         {
/*       */           
/*  9584 */           receiverTypeDefinition1 = valuable.defineMethod("get$Lambda", (TypeDefinition)factoryMethod.getReturnType(), new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters((Collection)factoryMethod.getParameterTypes()).intercept(FactoryImplementation.INSTANCE);
/*       */         }
/*  9586 */         if (serializable) {
/*  9587 */           DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional optional; if (!markerInterfaces.contains(Serializable.class)) {
/*  9588 */             optional = receiverTypeDefinition1.implement(new Type[] { Serializable.class });
/*       */           }
/*       */           
/*  9591 */           receiverTypeDefinition1 = optional.defineMethod("writeReplace", Object.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).intercept(new SerializationImplementation(TypeDescription.ForLoadedType.of(targetType), factoryMethod
/*  9592 */                 .getReturnType(), lambdaMethodName, lambdaMethod, targetMethod, 
/*       */ 
/*       */ 
/*       */                 
/*  9596 */                 JavaConstant.MethodType.ofLoaded(specializedLambdaMethodType)));
/*  9597 */         } else if (factoryMethod.getReturnType().isAssignableTo(Serializable.class)) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  9605 */           receiverTypeDefinition1 = receiverTypeDefinition1.defineMethod("readObject", void.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { ObjectInputStream.class }).throwing(new Type[] { NotSerializableException.class }).intercept(ExceptionMethod.throwing(NotSerializableException.class, "Non-serializable lambda")).defineMethod("writeObject", void.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { ObjectOutputStream.class }).throwing(new Type[] { NotSerializableException.class }).intercept(ExceptionMethod.throwing(NotSerializableException.class, "Non-serializable lambda"));
/*       */         } 
/*  9607 */         for (Object additionalBridgeType : additionalBridges) {
/*  9608 */           JavaConstant.MethodType additionalBridge = JavaConstant.MethodType.ofLoaded(additionalBridgeType);
/*       */ 
/*       */           
/*  9611 */           receiverTypeDefinition1 = receiverTypeDefinition1.defineMethod(lambdaMethodName, (TypeDefinition)additionalBridge.getReturnType(), new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)MethodManifestation.BRIDGE, (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters((Collection)additionalBridge.getParameterTypes()).intercept(new BridgeMethodImplementation(lambdaMethodName, lambdaMethod));
/*       */         } 
/*  9613 */         byte[] classFile = receiverTypeDefinition1.make().getBytes();
/*  9614 */         for (ClassFileTransformer classFileTransformer : classFileTransformers) {
/*       */           try {
/*  9616 */             byte[] transformedClassFile = classFileTransformer.transform(targetType.getClassLoader(), lambdaClassName
/*  9617 */                 .replace('.', '/'), NOT_PREVIOUSLY_DEFINED, targetType
/*       */                 
/*  9619 */                 .getProtectionDomain(), classFile);
/*       */             
/*  9621 */             classFile = (transformedClassFile == null) ? classFile : transformedClassFile;
/*       */           
/*       */           }
/*  9624 */           catch (Throwable throwable) {}
/*       */         } 
/*       */ 
/*       */         
/*  9628 */         return classFile;
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.byteBuddy.equals(((LambdaInstanceFactory)param2Object).byteBuddy))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.byteBuddy.hashCode();
/*       */       }
/*       */       
/*  9639 */       protected enum ConstructorImplementation implements Implementation { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final transient MethodDescription.InDefinedShape objectConstructor;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         ConstructorImplementation() {
/*  9650 */           this.objectConstructor = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Object.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/*  9657 */           return new Appender((List<FieldDescription.InDefinedShape>)implementationTarget.getInstrumentedType().getDeclaredFields());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  9664 */           return instrumentedType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class Appender
/*       */           implements ByteCodeAppender
/*       */         {
/*       */           private final List<FieldDescription.InDefinedShape> declaredFields;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Appender(List<FieldDescription.InDefinedShape> declaredFields) {
/*  9684 */             this.declaredFields = declaredFields;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  9691 */             List<StackManipulation> fieldAssignments = new ArrayList<StackManipulation>(this.declaredFields.size() * 3);
/*  9692 */             for (ParameterDescription parameterDescription : instrumentedMethod.getParameters()) {
/*  9693 */               fieldAssignments.add(MethodVariableAccess.loadThis());
/*  9694 */               fieldAssignments.add(MethodVariableAccess.load(parameterDescription));
/*  9695 */               fieldAssignments.add(FieldAccess.forField(this.declaredFields.get(parameterDescription.getIndex())).write());
/*       */             } 
/*  9697 */             return new ByteCodeAppender.Size((new StackManipulation.Compound(new StackManipulation[] {
/*  9698 */                     MethodVariableAccess.loadThis(), 
/*  9699 */                     (StackManipulation)MethodInvocation.invoke(AgentBuilder.LambdaInstrumentationStrategy.LambdaInstanceFactory.ConstructorImplementation.access$1200(AgentBuilder.LambdaInstrumentationStrategy.LambdaInstanceFactory.ConstructorImplementation.INSTANCE)), (StackManipulation)new StackManipulation.Compound(fieldAssignments), (StackManipulation)MethodReturn.VOID
/*       */                   },
/*       */                 
/*  9702 */                 )).apply(methodVisitor, implementationContext).getMaximalSize(), instrumentedMethod.getStackSize());
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.declaredFields.equals(((Appender)param4Object).declaredFields))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.declaredFields.hashCode();
/*       */           } } }
/*       */ 
/*       */       
/*       */       protected enum FactoryImplementation implements Implementation {
/*  9715 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/*  9721 */           return new Appender(implementationTarget.getInstrumentedType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  9728 */           return instrumentedType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class Appender
/*       */           implements ByteCodeAppender
/*       */         {
/*       */           private final TypeDescription instrumentedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Appender(TypeDescription instrumentedType) {
/*  9748 */             this.instrumentedType = instrumentedType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  9755 */             return new ByteCodeAppender.Size((new StackManipulation.Compound(new StackManipulation[] {
/*  9756 */                     TypeCreation.of(this.instrumentedType), (StackManipulation)Duplication.SINGLE, 
/*       */                     
/*  9758 */                     (StackManipulation)MethodVariableAccess.allArgumentsOf(instrumentedMethod), 
/*  9759 */                     (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)((MethodList)this.instrumentedType.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).getOnly()), (StackManipulation)MethodReturn.REFERENCE
/*       */                   },
/*  9761 */                 )).apply(methodVisitor, implementationContext).getMaximalSize(), instrumentedMethod.getStackSize());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.instrumentedType.equals(((Appender)param4Object).instrumentedType))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.instrumentedType.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class LambdaMethodImplementation
/*       */         implements Implementation
/*       */       {
/*       */         private final TypeDescription targetType;
/*       */ 
/*       */         
/*       */         private final JavaConstant.MethodHandle targetMethod;
/*       */ 
/*       */         
/*       */         private final JavaConstant.MethodType specializedLambdaMethod;
/*       */ 
/*       */ 
/*       */         
/*       */         protected LambdaMethodImplementation(TypeDescription targetType, JavaConstant.MethodHandle targetMethod, JavaConstant.MethodType specializedLambdaMethod) {
/*  9797 */           this.targetType = targetType;
/*  9798 */           this.targetMethod = targetMethod;
/*  9799 */           this.specializedLambdaMethod = specializedLambdaMethod;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/*  9806 */           return Appender.of((MethodDescription)((MethodList)this.targetMethod.getOwnerType()
/*  9807 */               .getDeclaredMethods()
/*  9808 */               .filter((ElementMatcher)ElementMatchers.hasMethodName(this.targetMethod.getName())
/*  9809 */                 .and((ElementMatcher)ElementMatchers.returns(this.targetMethod.getReturnType()))
/*  9810 */                 .and((ElementMatcher)ElementMatchers.takesArguments((Iterable)this.targetMethod.getParameterTypes()))))
/*  9811 */               .getOnly(), this.specializedLambdaMethod, (List<FieldDescription.InDefinedShape>)implementationTarget
/*       */               
/*  9813 */               .getInstrumentedType().getDeclaredFields(), this.targetMethod
/*  9814 */               .getHandleType(), this.targetType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  9822 */           return instrumentedType;
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.targetType.equals(((LambdaMethodImplementation)param3Object).targetType) ? false : (!this.targetMethod.equals(((LambdaMethodImplementation)param3Object).targetMethod) ? false : (!!this.specializedLambdaMethod.equals(((LambdaMethodImplementation)param3Object).specializedLambdaMethod))))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.targetMethod.hashCode()) * 31 + this.specializedLambdaMethod.hashCode();
/*       */         }
/*       */         
/*       */         @Enhance
/*  9834 */         protected static class Appender implements ByteCodeAppender { private static final Dispatcher LOOKUP_DATA_DISPATCHER = dispatcher();
/*       */           
/*       */           private final MethodDescription targetMethod;
/*       */           private final JavaConstant.MethodType specializedLambdaMethod;
/*       */           private final List<FieldDescription.InDefinedShape> declaredFields;
/*       */           private final Dispatcher dispatcher;
/*       */           
/*       */           @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*       */           private static Dispatcher dispatcher() {
/*       */             try {
/*  9844 */               Class<?> type = Class.forName("java.lang.invoke.MethodHandles$Lookup", false, (ClassLoader)null);
/*  9845 */               type.getMethod("classData", new Class[] { type, String.class, Class.class });
/*  9846 */               return new Dispatcher.UsingMethodHandle((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(Class.forName("java.lang.invoke.MethodHandle", false, (ClassLoader)null)
/*       */                     
/*  9848 */                     .getMethod("invokeExact", new Class[] { Object[].class })));
/*  9849 */             } catch (Exception ignored) {
/*  9850 */               return Dispatcher.UsingDirectInvocation.INSTANCE;
/*       */             } 
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Appender(MethodDescription targetMethod, JavaConstant.MethodType specializedLambdaMethod, List<FieldDescription.InDefinedShape> declaredFields, Dispatcher dispatcher) {
/*  9886 */             this.targetMethod = targetMethod;
/*  9887 */             this.specializedLambdaMethod = specializedLambdaMethod;
/*  9888 */             this.declaredFields = declaredFields;
/*  9889 */             this.dispatcher = dispatcher;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static ByteCodeAppender of(MethodDescription targetMethod, JavaConstant.MethodType specializedLambdaMethod, List<FieldDescription.InDefinedShape> declaredFields, JavaConstant.MethodHandle.HandleType handleType, TypeDescription targetType) {
/*  9907 */             return new Appender(targetMethod, specializedLambdaMethod, declaredFields, (handleType == JavaConstant.MethodHandle.HandleType.INVOKE_SPECIAL || 
/*       */ 
/*       */                 
/*  9910 */                 !targetMethod.getDeclaringType().asErasure().isVisibleTo(targetType)) ? LOOKUP_DATA_DISPATCHER : Dispatcher.UsingDirectInvocation.INSTANCE);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  9919 */             List<StackManipulation> fieldAccess = new ArrayList<StackManipulation>(this.declaredFields.size() * 2 + 1);
/*  9920 */             for (FieldDescription.InDefinedShape fieldDescription : this.declaredFields) {
/*  9921 */               fieldAccess.add(MethodVariableAccess.loadThis());
/*  9922 */               fieldAccess.add(FieldAccess.forField(fieldDescription).read());
/*       */             } 
/*  9924 */             List<StackManipulation> parameterAccess = new ArrayList<StackManipulation>(instrumentedMethod.getParameters().size() * 2);
/*  9925 */             for (ParameterDescription parameterDescription : instrumentedMethod.getParameters()) {
/*  9926 */               parameterAccess.add(MethodVariableAccess.load(parameterDescription));
/*  9927 */               parameterAccess.add(Assigner.DEFAULT.assign(parameterDescription.getType(), ((TypeDescription)this.specializedLambdaMethod
/*  9928 */                     .getParameterTypes().get(parameterDescription.getIndex())).asGenericType(), Assigner.Typing.DYNAMIC));
/*       */             } 
/*       */             
/*  9931 */             return new ByteCodeAppender.Size((new StackManipulation.Compound(new StackManipulation[] {
/*  9932 */                     this.targetMethod.isConstructor() ? (StackManipulation)new StackManipulation.Compound(new StackManipulation[] {
/*  9933 */                         TypeCreation.of(this.targetMethod.getDeclaringType().asErasure()), (StackManipulation)Duplication.SINGLE }, ) : (StackManipulation)StackManipulation.Trivial.INSTANCE, this.dispatcher
/*       */                     
/*  9935 */                     .initialize(), (StackManipulation)new StackManipulation.Compound(fieldAccess), (StackManipulation)new StackManipulation.Compound(parameterAccess), this.dispatcher
/*       */ 
/*       */                     
/*  9938 */                     .invoke(this.targetMethod), Assigner.DEFAULT
/*  9939 */                     .assign(this.targetMethod.isConstructor() ? this.targetMethod
/*  9940 */                       .getDeclaringType().asGenericType() : this.targetMethod
/*  9941 */                       .getReturnType(), this.specializedLambdaMethod
/*  9942 */                       .getReturnType().asGenericType(), Assigner.Typing.DYNAMIC), 
/*       */                     
/*  9944 */                     MethodReturn.of((TypeDefinition)this.specializedLambdaMethod.getReturnType())
/*  9945 */                   })).apply(methodVisitor, implementationContext).getMaximalSize(), instrumentedMethod.getStackSize());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.targetMethod.equals(((Appender)param4Object).targetMethod) ? false : (!this.specializedLambdaMethod.equals(((Appender)param4Object).specializedLambdaMethod) ? false : (!this.declaredFields.equals(((Appender)param4Object).declaredFields) ? false : (!!this.dispatcher.equals(((Appender)param4Object).dispatcher)))))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (((getClass().hashCode() * 31 + this.targetMethod.hashCode()) * 31 + this.specializedLambdaMethod.hashCode()) * 31 + this.declaredFields.hashCode()) * 31 + this.dispatcher.hashCode();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public enum UsingDirectInvocation
/*       */             implements Dispatcher
/*       */           {
/*  9976 */             INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public StackManipulation initialize() {
/*  9982 */               return (StackManipulation)StackManipulation.Trivial.INSTANCE;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public StackManipulation invoke(MethodDescription methodDescription) {
/*  9989 */               return (StackManipulation)MethodInvocation.invoke(methodDescription);
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Enhance
/*       */           public static class UsingMethodHandle
/*       */             extends StackManipulation.AbstractBase
/*       */             implements Dispatcher
/*       */           {
/*       */             private final MethodDescription.InDefinedShape invokeExact;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected UsingMethodHandle(MethodDescription.InDefinedShape invokeExact) {
/* 10010 */               this.invokeExact = invokeExact;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public StackManipulation initialize() {
/* 10017 */               return (StackManipulation)this;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public StackManipulation invoke(MethodDescription methodDescription) {
/* 10024 */               return (StackManipulation)MethodInvocation.invoke(this.invokeExact);
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext)
/*       */             {
/* 10031 */               methodVisitor.visitLdcInsn(new ConstantDynamic("_", "Ljava/lang/invoke/MethodHandle;", new Handle(6, "java/lang/invoke/MethodHandles", "classData", "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;", false), new Object[0]));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10038 */               return new StackManipulation.Size(1, 1); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.invokeExact.equals(((UsingMethodHandle)param5Object).invokeExact)))); } public int hashCode() { return getClass().hashCode() * 31 + this.invokeExact.hashCode(); } } protected static interface Dispatcher { StackManipulation initialize(); StackManipulation invoke(MethodDescription param5MethodDescription); public enum UsingDirectInvocation implements Dispatcher { INSTANCE; public StackManipulation initialize() { return (StackManipulation)StackManipulation.Trivial.INSTANCE; } public StackManipulation invoke(MethodDescription methodDescription) { return (StackManipulation)MethodInvocation.invoke(methodDescription); } } @Enhance public static class UsingMethodHandle extends StackManipulation.AbstractBase implements Dispatcher { private final MethodDescription.InDefinedShape invokeExact; protected UsingMethodHandle(MethodDescription.InDefinedShape invokeExact) { this.invokeExact = invokeExact; } public StackManipulation initialize() { return (StackManipulation)this; } public StackManipulation invoke(MethodDescription methodDescription) { return (StackManipulation)MethodInvocation.invoke(this.invokeExact); } public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) { methodVisitor.visitLdcInsn(new ConstantDynamic("_", "Ljava/lang/invoke/MethodHandle;", new Handle(6, "java/lang/invoke/MethodHandles", "classData", "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;", false), new Object[0])); return new StackManipulation.Size(1, 1); }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               public boolean equals(@MaybeNull Object param6Object) {
/*       */                 return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!!this.invokeExact.equals(((UsingMethodHandle)param6Object).invokeExact))));
/*       */               }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               public int hashCode() {
/*       */                 return getClass().hashCode() * 31 + this.invokeExact.hashCode();
/*       */               } }
/*       */              }
/*       */            }
/*       */       
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class SerializationImplementation
/*       */         implements Implementation
/*       */       {
/*       */         private final TypeDescription targetType;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription lambdaType;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final String lambdaMethodName;
/*       */ 
/*       */ 
/*       */         
/*       */         private final JavaConstant.MethodType lambdaMethod;
/*       */ 
/*       */ 
/*       */         
/*       */         private final JavaConstant.MethodHandle targetMethod;
/*       */ 
/*       */ 
/*       */         
/*       */         private final JavaConstant.MethodType specializedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected SerializationImplementation(TypeDescription targetType, TypeDescription lambdaType, String lambdaMethodName, JavaConstant.MethodType lambdaMethod, JavaConstant.MethodHandle targetMethod, JavaConstant.MethodType specializedMethod) {
/* 10097 */           this.targetType = targetType;
/* 10098 */           this.lambdaType = lambdaType;
/* 10099 */           this.lambdaMethodName = lambdaMethodName;
/* 10100 */           this.lambdaMethod = lambdaMethod;
/* 10101 */           this.targetMethod = targetMethod;
/* 10102 */           this.specializedMethod = specializedMethod;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/*       */           TypeDescription serializedLambda;
/*       */           try {
/* 10111 */             serializedLambda = TypeDescription.ForLoadedType.of(Class.forName("java.lang.invoke.SerializedLambda"));
/* 10112 */           } catch (ClassNotFoundException exception) {
/* 10113 */             throw new IllegalStateException("Cannot find class for lambda serialization", exception);
/*       */           } 
/* 10115 */           List<StackManipulation> lambdaArguments = new ArrayList<StackManipulation>(implementationTarget.getInstrumentedType().getDeclaredFields().size());
/* 10116 */           for (FieldDescription.InDefinedShape fieldDescription : implementationTarget.getInstrumentedType().getDeclaredFields()) {
/* 10117 */             lambdaArguments.add(new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.loadThis(), 
/* 10118 */                     FieldAccess.forField(fieldDescription).read(), Assigner.DEFAULT
/* 10119 */                     .assign(fieldDescription.getType(), TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), Assigner.Typing.STATIC) }));
/*       */           } 
/* 10121 */           return (ByteCodeAppender)new ByteCodeAppender.Simple(new StackManipulation[] { (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { 
/* 10122 */                     TypeCreation.of(serializedLambda), (StackManipulation)Duplication.SINGLE, 
/*       */                     
/* 10124 */                     ClassConstant.of(this.targetType), (StackManipulation)new TextConstant(this.lambdaType
/* 10125 */                       .getInternalName()), (StackManipulation)new TextConstant(this.lambdaMethodName), (StackManipulation)new TextConstant(this.lambdaMethod
/*       */                       
/* 10127 */                       .getDescriptor()), 
/* 10128 */                     IntegerConstant.forValue(this.targetMethod.getHandleType().getIdentifier()), (StackManipulation)new TextConstant(this.targetMethod
/* 10129 */                       .getOwnerType().getInternalName()), (StackManipulation)new TextConstant(this.targetMethod
/* 10130 */                       .getName()), (StackManipulation)new TextConstant(this.targetMethod
/* 10131 */                       .getDescriptor()), (StackManipulation)new TextConstant(this.specializedMethod
/* 10132 */                       .getDescriptor()), 
/* 10133 */                     ArrayFactory.forType(TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class)).withValues(lambdaArguments), 
/* 10134 */                     (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)((MethodList)serializedLambda.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).getOnly()), (StackManipulation)MethodReturn.REFERENCE }) });
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 10143 */           return instrumentedType;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.lambdaMethodName.equals(((SerializationImplementation)param3Object).lambdaMethodName) ? false : (!this.targetType.equals(((SerializationImplementation)param3Object).targetType) ? false : (!this.lambdaType.equals(((SerializationImplementation)param3Object).lambdaType) ? false : (!this.lambdaMethod.equals(((SerializationImplementation)param3Object).lambdaMethod) ? false : (!this.targetMethod.equals(((SerializationImplementation)param3Object).targetMethod) ? false : (!!this.specializedMethod.equals(((SerializationImplementation)param3Object).specializedMethod)))))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.lambdaType.hashCode()) * 31 + this.lambdaMethodName.hashCode()) * 31 + this.lambdaMethod.hashCode()) * 31 + this.targetMethod.hashCode()) * 31 + this.specializedMethod.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class BridgeMethodImplementation
/*       */         implements Implementation
/*       */       {
/*       */         private final String lambdaMethodName;
/*       */         
/*       */         private final JavaConstant.MethodType lambdaMethod;
/*       */ 
/*       */         
/*       */         protected BridgeMethodImplementation(String lambdaMethodName, JavaConstant.MethodType lambdaMethod) {
/* 10170 */           this.lambdaMethodName = lambdaMethodName;
/* 10171 */           this.lambdaMethod = lambdaMethod;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/* 10178 */           return new Appender(implementationTarget.invokeSuper(new MethodDescription.SignatureToken(this.lambdaMethodName, this.lambdaMethod
/* 10179 */                   .getReturnType(), (List)this.lambdaMethod
/* 10180 */                   .getParameterTypes())));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public InstrumentedType prepare(InstrumentedType instrumentedType) {
/* 10187 */           return instrumentedType;
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.lambdaMethodName.equals(((BridgeMethodImplementation)param3Object).lambdaMethodName) ? false : (!!this.lambdaMethod.equals(((BridgeMethodImplementation)param3Object).lambdaMethod)))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.lambdaMethodName.hashCode()) * 31 + this.lambdaMethod.hashCode();
/*       */         }
/*       */         
/*       */         @Enhance
/*       */         protected static class Appender
/*       */           implements ByteCodeAppender
/*       */         {
/*       */           private final Implementation.SpecialMethodInvocation bridgeTargetInvocation;
/*       */           
/*       */           protected Appender(Implementation.SpecialMethodInvocation bridgeTargetInvocation) {
/* 10207 */             this.bridgeTargetInvocation = bridgeTargetInvocation;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 10214 */             return (new ByteCodeAppender.Compound(new ByteCodeAppender[] { (ByteCodeAppender)new ByteCodeAppender.Simple(new StackManipulation[] {
/* 10215 */                       MethodVariableAccess.allArgumentsOf(instrumentedMethod)
/* 10216 */                       .asBridgeOf(this.bridgeTargetInvocation.getMethodDescription())
/* 10217 */                       .prependThisReference(), (StackManipulation)this.bridgeTargetInvocation, 
/*       */                       
/* 10219 */                       this.bridgeTargetInvocation.getMethodDescription().getReturnType().asErasure().isAssignableTo(instrumentedMethod.getReturnType().asErasure()) ? (StackManipulation)StackManipulation.Trivial.INSTANCE : 
/*       */                       
/* 10221 */                       TypeCasting.to((TypeDefinition)instrumentedMethod.getReturnType()), 
/* 10222 */                       MethodReturn.of((TypeDefinition)instrumentedMethod.getReturnType())
/*       */                     
/* 10224 */                     }) })).apply(methodVisitor, implementationContext, instrumentedMethod);
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.bridgeTargetInvocation.equals(((Appender)param4Object).bridgeTargetInvocation))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.bridgeTargetInvocation.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */   public enum PatchMode
/*       */   {
/* 10242 */     GAP
/*       */     {
/*       */       protected Handler toHandler(ResettableClassFileTransformer classFileTransformer) {
/* 10245 */         return new Handler.ForPatchWithGap(classFileTransformer);
/*       */       }
/*       */     },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10254 */     OVERLAP
/*       */     {
/*       */       protected Handler toHandler(ResettableClassFileTransformer classFileTransformer) {
/* 10257 */         return new Handler.ForPatchWithOverlap(classFileTransformer);
/*       */       }
/*       */     },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10267 */     SUBSTITUTE
/*       */     {
/*       */       protected Handler toHandler(ResettableClassFileTransformer classFileTransformer) {
/* 10270 */         if (!(classFileTransformer instanceof ResettableClassFileTransformer.Substitutable)) {
/* 10271 */           throw new IllegalArgumentException("Original class file transformer is not substitutable: " + classFileTransformer);
/*       */         }
/* 10273 */         return new Handler.ForPatchWithSubstitution((ResettableClassFileTransformer.Substitutable)classFileTransformer);
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static PatchMode of(ResettableClassFileTransformer classFileTransformer) {
/* 10284 */       return (classFileTransformer instanceof ResettableClassFileTransformer.Substitutable) ? SUBSTITUTE : OVERLAP;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract Handler toHandler(ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static interface Handler
/*       */     {
/*       */       void onBeforeRegistration(Instrumentation param2Instrumentation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       boolean onRegistration(ResettableClassFileTransformer param2ResettableClassFileTransformer);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void onAfterRegistration(Instrumentation param2Instrumentation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum NoOp
/*       */         implements Handler
/*       */       {
/* 10332 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBeforeRegistration(Instrumentation instrumentation) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean onRegistration(ResettableClassFileTransformer classFileTransformer) {
/* 10345 */           return true;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onAfterRegistration(Instrumentation instrumentation) {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForPatchWithGap
/*       */         implements Handler
/*       */       {
/*       */         private final ResettableClassFileTransformer classFileTransformer;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForPatchWithGap(ResettableClassFileTransformer classFileTransformer) {
/* 10373 */           this.classFileTransformer = classFileTransformer;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBeforeRegistration(Instrumentation instrumentation) {
/* 10380 */           if (!this.classFileTransformer.reset(instrumentation, AgentBuilder.RedefinitionStrategy.DISABLED)) {
/* 10381 */             throw new IllegalArgumentException("Failed to deregister patched class file transformer: " + this.classFileTransformer);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean onRegistration(ResettableClassFileTransformer classFileTransformer) {
/* 10389 */           return true;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public void onAfterRegistration(Instrumentation instrumentation) {}
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.classFileTransformer.equals(((ForPatchWithGap)param3Object).classFileTransformer))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.classFileTransformer.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForPatchWithOverlap
/*       */         implements Handler
/*       */       {
/*       */         private final ResettableClassFileTransformer classFileTransformer;
/*       */ 
/*       */         
/*       */         protected ForPatchWithOverlap(ResettableClassFileTransformer classFileTransformer) {
/* 10417 */           this.classFileTransformer = classFileTransformer;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBeforeRegistration(Instrumentation instrumentation) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean onRegistration(ResettableClassFileTransformer classFileTransformer) {
/* 10431 */           return true;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onAfterRegistration(Instrumentation instrumentation) {
/* 10438 */           if (!this.classFileTransformer.reset(instrumentation, AgentBuilder.RedefinitionStrategy.DISABLED)) {
/* 10439 */             throw new IllegalArgumentException("Failed to deregister patched class file transformer: " + this.classFileTransformer);
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.classFileTransformer.equals(((ForPatchWithOverlap)param3Object).classFileTransformer))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.classFileTransformer.hashCode();
/*       */         }
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       public static class ForPatchWithSubstitution
/*       */         implements Handler
/*       */       {
/*       */         private final ResettableClassFileTransformer.Substitutable classFileTransformer;
/*       */         
/*       */         protected ForPatchWithSubstitution(ResettableClassFileTransformer.Substitutable classFileTransformer) {
/* 10461 */           this.classFileTransformer = classFileTransformer;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onBeforeRegistration(Instrumentation instrumentation) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean onRegistration(ResettableClassFileTransformer classFileTransformer) {
/* 10475 */           this.classFileTransformer.substitute(classFileTransformer);
/* 10476 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onAfterRegistration(Instrumentation instrumentation) {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.classFileTransformer.equals(((ForPatchWithSubstitution)param3Object).classFileTransformer))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.classFileTransformer.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Enhance
/*       */   public static class Default
/*       */     implements AgentBuilder
/*       */   {
/*       */     private static final String INSTALLER_TYPE = "net.bytebuddy.agent.Installer";
/*       */ 
/*       */ 
/*       */     
/*       */     private static final String INSTALLER_GETTER = "getInstrumentation";
/*       */ 
/*       */ 
/*       */     
/*       */     @AlwaysNull
/* 10518 */     private static final byte[] NO_TRANSFORMATION = null;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @AlwaysNull
/* 10524 */     private static final Class<?> NOT_PREVIOUSLY_DEFINED = null;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10529 */     private static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10535 */     private static final AgentBuilder.CircularityLock DEFAULT_LOCK = new AgentBuilder.CircularityLock.Default(); protected final ByteBuddy byteBuddy; protected final AgentBuilder.Listener listener; protected final AgentBuilder.CircularityLock circularityLock; protected final AgentBuilder.PoolStrategy poolStrategy; protected final AgentBuilder.TypeStrategy typeStrategy; protected final AgentBuilder.LocationStrategy locationStrategy; protected final ClassFileLocator classFileLocator; protected final NativeMethodStrategy nativeMethodStrategy; protected final WarmupStrategy warmupStrategy; protected final AgentBuilder.TransformerDecorator transformerDecorator; protected final AgentBuilder.InitializationStrategy initializationStrategy; protected final AgentBuilder.RedefinitionStrategy redefinitionStrategy; protected final AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy; protected final AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator; protected final AgentBuilder.RedefinitionStrategy.Listener redefinitionListener; protected final AgentBuilder.RedefinitionStrategy.ResubmissionStrategy redefinitionResubmissionStrategy; protected final AgentBuilder.InjectionStrategy injectionStrategy; protected final AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy; protected final AgentBuilder.DescriptionStrategy descriptionStrategy; protected final AgentBuilder.FallbackStrategy fallbackStrategy; protected final AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy; protected final AgentBuilder.InstallationListener installationListener; protected final AgentBuilder.RawMatcher ignoreMatcher; protected final List<Transformation> transformations; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*       */        }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Default() {
/* 10662 */       this(new ByteBuddy());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Default(ByteBuddy byteBuddy) {
/* 10674 */       this(byteBuddy, AgentBuilder.Listener.NoOp.INSTANCE, DEFAULT_LOCK, AgentBuilder.PoolStrategy.Default.FAST, AgentBuilder.TypeStrategy.Default.REBASE, AgentBuilder.LocationStrategy.ForClassLoader.STRONG, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE, NativeMethodStrategy.Disabled.INSTANCE, WarmupStrategy.NoOp.INSTANCE, AgentBuilder.TransformerDecorator.NoOp.INSTANCE, new AgentBuilder.InitializationStrategy.SelfInjection.Split(), AgentBuilder.RedefinitionStrategy.DISABLED, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.SinglePass.INSTANCE, AgentBuilder.RedefinitionStrategy.BatchAllocator.ForTotal.INSTANCE, AgentBuilder.RedefinitionStrategy.Listener.NoOp.INSTANCE, AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Disabled.INSTANCE, AgentBuilder.InjectionStrategy.UsingReflection.INSTANCE, AgentBuilder.LambdaInstrumentationStrategy.DISABLED, AgentBuilder.DescriptionStrategy.Default.HYBRID, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10693 */           AgentBuilder.FallbackStrategy.ByThrowableType.ofOptionalTypes(), AgentBuilder.ClassFileBufferStrategy.Default.RETAINING, AgentBuilder.InstallationListener.NoOp.INSTANCE, new AgentBuilder.RawMatcher.Disjunction(new AgentBuilder.RawMatcher[] { new AgentBuilder.RawMatcher.ForElementMatchers(
/*       */ 
/*       */ 
/*       */                 
/* 10697 */                 (ElementMatcher<? super TypeDescription>)ElementMatchers.any(), (ElementMatcher<? super ClassLoader>)ElementMatchers.isBootstrapClassLoader().or((ElementMatcher)ElementMatchers.isExtensionClassLoader())), new AgentBuilder.RawMatcher.ForElementMatchers(
/* 10698 */                 (ElementMatcher<? super TypeDescription>)ElementMatchers.nameStartsWith("net.bytebuddy.")
/* 10699 */                 .and((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.nameStartsWith("net.bytebuddy.renamed.")))
/* 10700 */                 .or((ElementMatcher)ElementMatchers.nameStartsWith("sun.reflect.").or((ElementMatcher)ElementMatchers.nameStartsWith("jdk.internal.reflect.")))
/* 10701 */                 .or((ElementMatcher)ElementMatchers.isSynthetic()))
/* 10702 */             }), Collections.emptyList());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected Default(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.CircularityLock circularityLock, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, NativeMethodStrategy nativeMethodStrategy, WarmupStrategy warmupStrategy, AgentBuilder.TransformerDecorator transformerDecorator, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener, AgentBuilder.RedefinitionStrategy.ResubmissionStrategy redefinitionResubmissionStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, List<Transformation> transformations) {
/* 10758 */       this.byteBuddy = byteBuddy;
/* 10759 */       this.listener = listener;
/* 10760 */       this.circularityLock = circularityLock;
/* 10761 */       this.poolStrategy = poolStrategy;
/* 10762 */       this.typeStrategy = typeStrategy;
/* 10763 */       this.locationStrategy = locationStrategy;
/* 10764 */       this.classFileLocator = classFileLocator;
/* 10765 */       this.nativeMethodStrategy = nativeMethodStrategy;
/* 10766 */       this.warmupStrategy = warmupStrategy;
/* 10767 */       this.transformerDecorator = transformerDecorator;
/* 10768 */       this.initializationStrategy = initializationStrategy;
/* 10769 */       this.redefinitionStrategy = redefinitionStrategy;
/* 10770 */       this.redefinitionDiscoveryStrategy = redefinitionDiscoveryStrategy;
/* 10771 */       this.redefinitionBatchAllocator = redefinitionBatchAllocator;
/* 10772 */       this.redefinitionListener = redefinitionListener;
/* 10773 */       this.redefinitionResubmissionStrategy = redefinitionResubmissionStrategy;
/* 10774 */       this.injectionStrategy = injectionStrategy;
/* 10775 */       this.lambdaInstrumentationStrategy = lambdaInstrumentationStrategy;
/* 10776 */       this.descriptionStrategy = descriptionStrategy;
/* 10777 */       this.fallbackStrategy = fallbackStrategy;
/* 10778 */       this.classFileBufferStrategy = classFileBufferStrategy;
/* 10779 */       this.installationListener = installationListener;
/* 10780 */       this.ignoreMatcher = ignoreMatcher;
/* 10781 */       this.transformations = transformations;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 10793 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(Plugin... plugin) {
/* 10803 */       return of(Arrays.asList(plugin));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(List<? extends Plugin> plugins) {
/* 10813 */       return of((EntryPoint)EntryPoint.Default.REBASE, plugins);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(EntryPoint entryPoint, Plugin... plugin) {
/* 10824 */       return of(entryPoint, Arrays.asList(plugin));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(EntryPoint entryPoint, List<? extends Plugin> plugins) {
/* 10835 */       return of(entryPoint, ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5), plugins);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(ClassFileVersion classFileVersion, Plugin... plugin) {
/* 10846 */       return of(classFileVersion, Arrays.asList(plugin));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(ClassFileVersion classFileVersion, List<? extends Plugin> plugins) {
/* 10857 */       return of((EntryPoint)EntryPoint.Default.REBASE, classFileVersion, plugins);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(EntryPoint entryPoint, ClassFileVersion classFileVersion, Plugin... plugin) {
/* 10869 */       return of(entryPoint, classFileVersion, Arrays.asList(plugin));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static AgentBuilder of(EntryPoint entryPoint, ClassFileVersion classFileVersion, List<? extends Plugin> plugins) {
/* 10881 */       AgentBuilder agentBuilder = (new Default(entryPoint.byteBuddy(classFileVersion))).with(new AgentBuilder.TypeStrategy.ForBuildEntryPoint(entryPoint));
/* 10882 */       for (Plugin plugin : plugins) {
/* 10883 */         agentBuilder = agentBuilder.type((ElementMatcher<? super TypeDescription>)plugin).transform(new AgentBuilder.Transformer.ForBuildPlugin(plugin));
/*       */       }
/* 10885 */       return agentBuilder;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(ByteBuddy byteBuddy) {
/* 10892 */       return new Default(byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.Listener listener) {
/* 10922 */       return new Default(this.byteBuddy, new AgentBuilder.Listener.Compound(new AgentBuilder.Listener[] { this.listener, listener }, ), this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.CircularityLock circularityLock) {
/* 10952 */       return new Default(this.byteBuddy, this.listener, circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.TypeStrategy typeStrategy) {
/* 10982 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.PoolStrategy poolStrategy) {
/* 11012 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.LocationStrategy locationStrategy) {
/* 11042 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(ClassFileLocator classFileLocator) {
/* 11072 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, (ClassFileLocator)new ClassFileLocator.Compound(new ClassFileLocator[] { this.classFileLocator, classFileLocator }, ), this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder enableNativeMethodPrefix(String prefix) {
/* 11102 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 11109 */           NativeMethodStrategy.ForPrefix.of(prefix), this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder disableNativeMethodPrefix() {
/* 11132 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, NativeMethodStrategy.Disabled.INSTANCE, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder warmUp(Class<?>... type) {
/* 11162 */       return warmUp(Arrays.asList(type));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder warmUp(Collection<Class<?>> types) {
/* 11169 */       if (types.isEmpty()) {
/* 11170 */         return this;
/*       */       }
/* 11172 */       for (Class<?> type : types) {
/* 11173 */         if (type.isPrimitive() || type.isArray()) {
/* 11174 */           throw new IllegalArgumentException("Cannot warm up primitive or array type: " + type);
/*       */         }
/*       */       } 
/* 11177 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 11185 */           .with(types), this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.TransformerDecorator transformerDecorator) {
/* 11207 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, new AgentBuilder.TransformerDecorator.Compound(new AgentBuilder.TransformerDecorator[] { this.transformerDecorator, transformerDecorator }, ), this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.RedefinitionListenable.WithoutBatchStrategy with(AgentBuilder.RedefinitionStrategy redefinitionStrategy) {
/* 11237 */       return new Redefining(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.SinglePass.INSTANCE, AgentBuilder.RedefinitionStrategy.BatchAllocator.ForTotal.INSTANCE, AgentBuilder.RedefinitionStrategy.Listener.NoOp.INSTANCE, AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Disabled.INSTANCE, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.InitializationStrategy initializationStrategy) {
/* 11267 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy) {
/* 11297 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.DescriptionStrategy descriptionStrategy) {
/* 11327 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.FallbackStrategy fallbackStrategy) {
/* 11357 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy) {
/* 11387 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.InstallationListener installationListener) {
/* 11417 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, new AgentBuilder.InstallationListener.Compound(new AgentBuilder.InstallationListener[] { this.installationListener, installationListener }, ), this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder with(AgentBuilder.InjectionStrategy injectionStrategy) {
/* 11447 */       return new Default(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder disableClassFormatChanges() {
/* 11477 */       return new Default(this.byteBuddy.with((Implementation.Context.Factory)Implementation.Context.Disabled.Factory.INSTANCE), this.listener, this.circularityLock, this.poolStrategy, (this.typeStrategy == AgentBuilder.TypeStrategy.Default.DECORATE) ? AgentBuilder.TypeStrategy.Default.DECORATE : AgentBuilder.TypeStrategy.Default.REDEFINE_FROZEN, this.locationStrategy, this.classFileLocator, NativeMethodStrategy.Disabled.INSTANCE, this.warmupStrategy, this.transformerDecorator, AgentBuilder.InitializationStrategy.NoOp.INSTANCE, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder assureReadEdgeTo(Instrumentation instrumentation, Class<?>... type) {
/* 11509 */       return JavaModule.isSupported() ? 
/* 11510 */         with(AgentBuilder.Listener.ModuleReadEdgeCompleting.of(instrumentation, false, type)) : this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder assureReadEdgeTo(Instrumentation instrumentation, JavaModule... module) {
/* 11518 */       return assureReadEdgeTo(instrumentation, Arrays.asList(module));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder assureReadEdgeTo(Instrumentation instrumentation, Collection<? extends JavaModule> modules) {
/* 11525 */       return with(new AgentBuilder.Listener.ModuleReadEdgeCompleting(instrumentation, false, new HashSet<JavaModule>(modules)));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder assureReadEdgeFromAndTo(Instrumentation instrumentation, Class<?>... type) {
/* 11532 */       return JavaModule.isSupported() ? 
/* 11533 */         with(AgentBuilder.Listener.ModuleReadEdgeCompleting.of(instrumentation, true, type)) : this;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder assureReadEdgeFromAndTo(Instrumentation instrumentation, JavaModule... module) {
/* 11541 */       return assureReadEdgeFromAndTo(instrumentation, Arrays.asList(module));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder assureReadEdgeFromAndTo(Instrumentation instrumentation, Collection<? extends JavaModule> modules) {
/* 11548 */       return with(new AgentBuilder.Listener.ModuleReadEdgeCompleting(instrumentation, true, new HashSet<JavaModule>(modules)));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Identified.Narrowable type(AgentBuilder.RawMatcher matcher) {
/* 11555 */       return new Transforming(matcher, Collections.emptyList(), false);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Identified.Narrowable type(ElementMatcher<? super TypeDescription> typeMatcher) {
/* 11562 */       return type(typeMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Identified.Narrowable type(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 11569 */       return type(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Identified.Narrowable type(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 11578 */       return type(new AgentBuilder.RawMatcher.ForElementMatchers(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.not((ElementMatcher)ElementMatchers.supportsModules()).or(moduleMatcher)));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Ignored ignore(ElementMatcher<? super TypeDescription> typeMatcher) {
/* 11585 */       return ignore(typeMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Ignored ignore(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 11592 */       return ignore(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Ignored ignore(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 11601 */       return ignore(new AgentBuilder.RawMatcher.ForElementMatchers(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.not((ElementMatcher)ElementMatchers.supportsModules()).or(moduleMatcher)));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AgentBuilder.Ignored ignore(AgentBuilder.RawMatcher rawMatcher) {
/* 11608 */       return new Ignoring(rawMatcher);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer makeRaw() {
/* 11615 */       return makeRaw(this.listener, AgentBuilder.InstallationListener.NoOp.INSTANCE, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer.Disabled.INSTANCE);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private ResettableClassFileTransformer makeRaw(AgentBuilder.Listener listener, AgentBuilder.InstallationListener installationListener, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer) {
/* 11629 */       return ExecutingTransformer.FACTORY.make(this.byteBuddy, listener, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.initializationStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, installationListener, this.ignoreMatcher, resubmissionEnforcer, this.transformations, this.circularityLock);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private static Instrumentation resolveByteBuddyAgentInstrumentation() {
/*       */       try {
/* 11656 */         Class<?> installer = ClassLoader.getSystemClassLoader().loadClass("net.bytebuddy.agent.Installer");
/* 11657 */         JavaModule source = JavaModule.ofType(AgentBuilder.class), target = JavaModule.ofType(installer);
/* 11658 */         if (source != null && !source.canRead(target)) {
/* 11659 */           Class<?> module = Class.forName("java.lang.Module");
/* 11660 */           module.getMethod("addReads", new Class[] { module }).invoke(source.unwrap(), new Object[] { target.unwrap() });
/*       */         } 
/* 11662 */         return (Instrumentation)installer.getMethod("getInstrumentation", new Class[0]).invoke(null, new Object[0]);
/* 11663 */       } catch (RuntimeException exception) {
/* 11664 */         throw exception;
/* 11665 */       } catch (Exception exception) {
/* 11666 */         throw new IllegalStateException("The Byte Buddy agent is not installed or not accessible", exception);
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer installOn(Instrumentation instrumentation) {
/* 11674 */       return doInstall(instrumentation, new Transformation.SimpleMatcher(this.ignoreMatcher, this.transformations), AgentBuilder.PatchMode.Handler.NoOp.INSTANCE);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer installOnByteBuddyAgent() {
/* 11681 */       return installOn(resolveByteBuddyAgentInstrumentation());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/* 11688 */       return patchOn(instrumentation, classFileTransformer, AgentBuilder.PatchMode.of(classFileTransformer));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RawMatcher differentialMatcher) {
/* 11695 */       return patchOn(instrumentation, classFileTransformer, differentialMatcher, AgentBuilder.PatchMode.of(classFileTransformer));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.PatchMode patchMode) {
/* 11702 */       return patchOn(instrumentation, classFileTransformer, new Transformation.DifferentialMatcher(this.ignoreMatcher, this.transformations, (classFileTransformer instanceof ResettableClassFileTransformer.Substitutable) ? ((ResettableClassFileTransformer.Substitutable)classFileTransformer)
/* 11703 */             .unwrap() : classFileTransformer), patchMode);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RawMatcher differentialMatcher, AgentBuilder.PatchMode patchMode) {
/* 11711 */       return doInstall(instrumentation, differentialMatcher, patchMode.toHandler(classFileTransformer));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer classFileTransformer) {
/* 11718 */       return patchOn(resolveByteBuddyAgentInstrumentation(), classFileTransformer);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer classFileTransformer, AgentBuilder.PatchMode patchMode) {
/* 11725 */       return patchOn(resolveByteBuddyAgentInstrumentation(), classFileTransformer, patchMode);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private ResettableClassFileTransformer doInstall(Instrumentation instrumentation, AgentBuilder.RawMatcher matcher, AgentBuilder.PatchMode.Handler handler) {
/* 11737 */       if (!this.circularityLock.acquire()) {
/* 11738 */         throw new IllegalStateException("Could not acquire the circularity lock upon installation.");
/*       */       }
/*       */       try {
/* 11741 */         AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Installation installation = this.redefinitionResubmissionStrategy.apply(instrumentation, this.poolStrategy, this.locationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.listener, this.installationListener, this.circularityLock, new Transformation.SimpleMatcher(this.ignoreMatcher, this.transformations), this.redefinitionStrategy, this.redefinitionBatchAllocator, this.redefinitionListener);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 11753 */         ResettableClassFileTransformer classFileTransformer = this.transformerDecorator.decorate(makeRaw(installation.getListener(), installation
/* 11754 */               .getInstallationListener(), installation
/* 11755 */               .getResubmissionEnforcer()));
/* 11756 */         installation.getInstallationListener().onBeforeInstall(instrumentation, classFileTransformer);
/*       */         try {
/* 11758 */           this.warmupStrategy.apply(classFileTransformer, this.locationStrategy, this.redefinitionStrategy, this.circularityLock, installation
/*       */ 
/*       */ 
/*       */               
/* 11762 */               .getInstallationListener());
/* 11763 */           handler.onBeforeRegistration(instrumentation);
/* 11764 */           if (handler.onRegistration(classFileTransformer)) {
/* 11765 */             if (this.redefinitionStrategy.isRetransforming()) {
/* 11766 */               DISPATCHER.addTransformer(instrumentation, classFileTransformer, true);
/*       */             } else {
/* 11768 */               instrumentation.addTransformer(classFileTransformer);
/*       */             } 
/*       */           }
/* 11771 */           handler.onAfterRegistration(instrumentation);
/* 11772 */           this.nativeMethodStrategy.apply(instrumentation, classFileTransformer);
/* 11773 */           this.lambdaInstrumentationStrategy.apply(this.byteBuddy, instrumentation, classFileTransformer);
/* 11774 */           this.redefinitionStrategy.apply(instrumentation, this.poolStrategy, this.locationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.redefinitionDiscoveryStrategy, this.lambdaInstrumentationStrategy, installation
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 11781 */               .getListener(), this.redefinitionListener, matcher, this.redefinitionBatchAllocator, this.circularityLock);
/*       */ 
/*       */ 
/*       */         
/*       */         }
/* 11786 */         catch (Throwable throwable) {
/* 11787 */           throwable = installation.getInstallationListener().onError(instrumentation, classFileTransformer, throwable);
/* 11788 */           if (throwable != null) {
/* 11789 */             instrumentation.removeTransformer(classFileTransformer);
/* 11790 */             throw new IllegalStateException("Could not install class file transformer", throwable);
/*       */           } 
/*       */         } 
/* 11793 */         installation.getInstallationListener().onInstall(instrumentation, classFileTransformer);
/* 11794 */         return classFileTransformer;
/*       */       } finally {
/* 11796 */         this.circularityLock.release();
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.redefinitionStrategy.equals(((Default)param1Object).redefinitionStrategy) ? false : (!this.lambdaInstrumentationStrategy.equals(((Default)param1Object).lambdaInstrumentationStrategy) ? false : (!this.byteBuddy.equals(((Default)param1Object).byteBuddy) ? false : (!this.listener.equals(((Default)param1Object).listener) ? false : (!this.circularityLock.equals(((Default)param1Object).circularityLock) ? false : (!this.poolStrategy.equals(((Default)param1Object).poolStrategy) ? false : (!this.typeStrategy.equals(((Default)param1Object).typeStrategy) ? false : (!this.locationStrategy.equals(((Default)param1Object).locationStrategy) ? false : (!this.classFileLocator.equals(((Default)param1Object).classFileLocator) ? false : (!this.nativeMethodStrategy.equals(((Default)param1Object).nativeMethodStrategy) ? false : (!this.warmupStrategy.equals(((Default)param1Object).warmupStrategy) ? false : (!this.transformerDecorator.equals(((Default)param1Object).transformerDecorator) ? false : (!this.initializationStrategy.equals(((Default)param1Object).initializationStrategy) ? false : (!this.redefinitionDiscoveryStrategy.equals(((Default)param1Object).redefinitionDiscoveryStrategy) ? false : (!this.redefinitionBatchAllocator.equals(((Default)param1Object).redefinitionBatchAllocator) ? false : (!this.redefinitionListener.equals(((Default)param1Object).redefinitionListener) ? false : (!this.redefinitionResubmissionStrategy.equals(((Default)param1Object).redefinitionResubmissionStrategy) ? false : (!this.injectionStrategy.equals(((Default)param1Object).injectionStrategy) ? false : (!this.descriptionStrategy.equals(((Default)param1Object).descriptionStrategy) ? false : (!this.fallbackStrategy.equals(((Default)param1Object).fallbackStrategy) ? false : (!this.classFileBufferStrategy.equals(((Default)param1Object).classFileBufferStrategy) ? false : (!this.installationListener.equals(((Default)param1Object).installationListener) ? false : (!this.ignoreMatcher.equals(((Default)param1Object).ignoreMatcher) ? false : (!!this.transformations.equals(((Default)param1Object).transformations)))))))))))))))))))))))))));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int hashCode() {
/*       */       return (((((((((((((((((((((((getClass().hashCode() * 31 + this.byteBuddy.hashCode()) * 31 + this.listener.hashCode()) * 31 + this.circularityLock.hashCode()) * 31 + this.poolStrategy.hashCode()) * 31 + this.typeStrategy.hashCode()) * 31 + this.locationStrategy.hashCode()) * 31 + this.classFileLocator.hashCode()) * 31 + this.nativeMethodStrategy.hashCode()) * 31 + this.warmupStrategy.hashCode()) * 31 + this.transformerDecorator.hashCode()) * 31 + this.initializationStrategy.hashCode()) * 31 + this.redefinitionStrategy.hashCode()) * 31 + this.redefinitionDiscoveryStrategy.hashCode()) * 31 + this.redefinitionBatchAllocator.hashCode()) * 31 + this.redefinitionListener.hashCode()) * 31 + this.redefinitionResubmissionStrategy.hashCode()) * 31 + this.injectionStrategy.hashCode()) * 31 + this.lambdaInstrumentationStrategy.hashCode()) * 31 + this.descriptionStrategy.hashCode()) * 31 + this.fallbackStrategy.hashCode()) * 31 + this.classFileBufferStrategy.hashCode()) * 31 + this.installationListener.hashCode()) * 31 + this.ignoreMatcher.hashCode()) * 31 + this.transformations.hashCode();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum Disabled
/*       */       implements NativeMethodStrategy
/*       */     {
/* 11862 */       INSTANCE;
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodNameTransformer resolve()
/*       */       {
/* 11868 */         return MethodNameTransformer.Suffixing.withRandomSuffix(); } public void apply(Instrumentation instrumentation, ClassFileTransformer classFileTransformer) {} } protected static interface NativeMethodStrategy { MethodNameTransformer resolve(); void apply(Instrumentation param2Instrumentation, ClassFileTransformer param2ClassFileTransformer); public enum Disabled implements NativeMethodStrategy { INSTANCE; public MethodNameTransformer resolve() { return MethodNameTransformer.Suffixing.withRandomSuffix(); }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void apply(Instrumentation instrumentation, ClassFileTransformer classFileTransformer) {} }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForPrefix
/*       */         implements NativeMethodStrategy
/*       */       {
/*       */         private final String prefix;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForPrefix(String prefix) {
/* 11896 */           this.prefix = prefix;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static AgentBuilder.Default.NativeMethodStrategy of(String prefix) {
/* 11906 */           if (prefix.length() == 0) {
/* 11907 */             throw new IllegalArgumentException("A method name prefix must not be the empty string");
/*       */           }
/* 11909 */           return new ForPrefix(prefix);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public MethodNameTransformer resolve() {
/* 11916 */           return (MethodNameTransformer)new MethodNameTransformer.Prefixing(this.prefix);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public void apply(Instrumentation instrumentation, ClassFileTransformer classFileTransformer)
/*       */         {
/* 11923 */           if (!AgentBuilder.Default.DISPATCHER.isNativeMethodPrefixSupported(instrumentation)) {
/* 11924 */             throw new IllegalArgumentException("A prefix for native methods is not supported: " + instrumentation);
/*       */           }
/* 11926 */           AgentBuilder.Default.DISPATCHER.setNativeMethodPrefix(instrumentation, classFileTransformer, this.prefix); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.prefix.equals(((ForPrefix)param3Object).prefix)))); } public int hashCode() { return getClass().hashCode() * 31 + this.prefix.hashCode(); } } } @Enhance public static class ForPrefix implements NativeMethodStrategy { private final String prefix; protected ForPrefix(String prefix) { this.prefix = prefix; } protected static AgentBuilder.Default.NativeMethodStrategy of(String prefix) { if (prefix.length() == 0) throw new IllegalArgumentException("A method name prefix must not be the empty string");  return new ForPrefix(prefix); } public MethodNameTransformer resolve() { return (MethodNameTransformer)new MethodNameTransformer.Prefixing(this.prefix); } public void apply(Instrumentation instrumentation, ClassFileTransformer classFileTransformer) { if (!AgentBuilder.Default.DISPATCHER.isNativeMethodPrefixSupported(instrumentation)) throw new IllegalArgumentException("A prefix for native methods is not supported: " + instrumentation);  AgentBuilder.Default.DISPATCHER.setNativeMethodPrefix(instrumentation, classFileTransformer, this.prefix); }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.prefix.equals(((ForPrefix)param2Object).prefix))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.prefix.hashCode();
/*       */       } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements WarmupStrategy
/*       */     {
/* 11968 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void apply(ResettableClassFileTransformer classFileTransformer, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.CircularityLock circularityLock, AgentBuilder.InstallationListener listener) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Default.WarmupStrategy with(Collection<Class<?>> types)
/*       */       {
/* 11985 */         return new AgentBuilder.Default.WarmupStrategy.Enabled(new LinkedHashSet<Class<?>>(types)); } } protected static interface WarmupStrategy { void apply(ResettableClassFileTransformer param2ResettableClassFileTransformer, AgentBuilder.LocationStrategy param2LocationStrategy, AgentBuilder.RedefinitionStrategy param2RedefinitionStrategy, AgentBuilder.CircularityLock param2CircularityLock, AgentBuilder.InstallationListener param2InstallationListener); WarmupStrategy with(Collection<Class<?>> param2Collection); public enum NoOp implements WarmupStrategy { INSTANCE; public void apply(ResettableClassFileTransformer classFileTransformer, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.CircularityLock circularityLock, AgentBuilder.InstallationListener listener) {} public AgentBuilder.Default.WarmupStrategy with(Collection<Class<?>> types) { return new AgentBuilder.Default.WarmupStrategy.Enabled(new LinkedHashSet<Class<?>>(types)); }
/*       */          }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Enabled
/*       */         implements WarmupStrategy
/*       */       {
/* 11998 */         private static final Dispatcher DISPATCHER = (Dispatcher)AgentBuilder.Default.doPrivileged(JavaDispatcher.of(Dispatcher.class));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Set<Class<?>> types;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Enabled(Set<Class<?>> types) {
/* 12011 */           this.types = types;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void apply(ResettableClassFileTransformer classFileTransformer, AgentBuilder.LocationStrategy locationStrategy, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.CircularityLock circularityLock, AgentBuilder.InstallationListener listener) {
/*       */           int i;
/* 12022 */           listener.onBeforeWarmUp(this.types, classFileTransformer);
/* 12023 */           boolean transformed = false;
/* 12024 */           Map<Class<?>, byte[]> results = (Map)new LinkedHashMap<Class<?>, byte>();
/* 12025 */           for (Class<?> type : this.types) {
/*       */             try {
/* 12027 */               JavaModule module = JavaModule.ofType(type);
/*       */ 
/*       */               
/* 12030 */               byte[] binaryRepresentation = locationStrategy.classFileLocator(type.getClassLoader(), module).locate(type.getName()).resolve();
/* 12031 */               circularityLock.release();
/*       */               try {
/*       */                 byte[] result;
/* 12034 */                 if (module == null) {
/* 12035 */                   result = classFileTransformer.transform(type.getClassLoader(), 
/* 12036 */                       Type.getInternalName(type), AgentBuilder.Default
/* 12037 */                       .NOT_PREVIOUSLY_DEFINED, type
/* 12038 */                       .getProtectionDomain(), binaryRepresentation);
/*       */                   
/* 12040 */                   i = transformed | ((result != null) ? 1 : 0);
/* 12041 */                   if (redefinitionStrategy.isEnabled()) {
/* 12042 */                     result = classFileTransformer.transform(type.getClassLoader(), 
/* 12043 */                         Type.getInternalName(type), type, type
/*       */                         
/* 12045 */                         .getProtectionDomain(), binaryRepresentation);
/*       */                     
/* 12047 */                     i |= (result != null) ? 1 : 0;
/*       */                   } 
/*       */                 } else {
/* 12050 */                   result = DISPATCHER.transform(classFileTransformer, module
/* 12051 */                       .unwrap(), type
/* 12052 */                       .getClassLoader(), 
/* 12053 */                       Type.getInternalName(type), AgentBuilder.Default
/* 12054 */                       .NOT_PREVIOUSLY_DEFINED, type
/* 12055 */                       .getProtectionDomain(), binaryRepresentation);
/*       */                   
/* 12057 */                   i |= (result != null) ? 1 : 0;
/* 12058 */                   if (redefinitionStrategy.isEnabled()) {
/* 12059 */                     result = DISPATCHER.transform(classFileTransformer, module
/* 12060 */                         .unwrap(), type
/* 12061 */                         .getClassLoader(), 
/* 12062 */                         Type.getInternalName(type), type, type
/*       */                         
/* 12064 */                         .getProtectionDomain(), binaryRepresentation);
/*       */                     
/* 12066 */                     i |= (result != null) ? 1 : 0;
/*       */                   } 
/*       */                 } 
/* 12069 */                 results.put(type, result);
/*       */               } finally {
/* 12071 */                 circularityLock.acquire();
/*       */               } 
/* 12073 */             } catch (Throwable throwable) {
/* 12074 */               listener.onWarmUpError(type, classFileTransformer, throwable);
/* 12075 */               results.put(type, AgentBuilder.Default.NO_TRANSFORMATION);
/*       */             } 
/*       */           } 
/* 12078 */           listener.onAfterWarmUp(results, classFileTransformer, i);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.Default.WarmupStrategy with(Collection<Class<?>> types) {
/* 12085 */           Set<Class<?>> combined = new LinkedHashSet<Class<?>>(this.types);
/* 12086 */           combined.addAll(types);
/* 12087 */           return new Enabled(combined);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.types.equals(((Enabled)param3Object).types))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.types.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Proxied("java.lang.instrument.ClassFileTransformer")
/*       */         protected static interface Dispatcher
/*       */         {
/*       */           @MaybeNull
/*       */           @Proxied("transform")
/*       */           byte[] transform(ClassFileTransformer param4ClassFileTransformer, @MaybeNull @Proxied("java.lang.Module") Object param4Object, @MaybeNull ClassLoader param4ClassLoader, String param4String, @MaybeNull Class<?> param4Class, @MaybeNull ProtectionDomain param4ProtectionDomain, byte[] param4ArrayOfbyte) throws IllegalClassFormatException;
/*       */         }
/*       */       } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     protected static class Transformation
/*       */     {
/*       */       @AlwaysNull
/* 12131 */       private static final byte[] NONE = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final AgentBuilder.RawMatcher matcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<AgentBuilder.Transformer> transformers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean terminal;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Transformation(AgentBuilder.RawMatcher matcher, List<AgentBuilder.Transformer> transformers, boolean terminal) {
/* 12156 */         this.matcher = matcher;
/* 12157 */         this.transformers = transformers;
/* 12158 */         this.terminal = terminal;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected AgentBuilder.RawMatcher getMatcher() {
/* 12167 */         return this.matcher;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected List<AgentBuilder.Transformer> getTransformers() {
/* 12176 */         return this.transformers;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected boolean isTerminal() {
/* 12185 */         return this.terminal;
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.terminal != ((Transformation)param2Object).terminal) ? false : (!this.matcher.equals(((Transformation)param2Object).matcher) ? false : (!!this.transformers.equals(((Transformation)param2Object).transformers))))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.transformers.hashCode()) * 31 + this.terminal;
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class SimpleMatcher
/*       */         implements AgentBuilder.RawMatcher
/*       */       {
/*       */         private final AgentBuilder.RawMatcher ignoreMatcher;
/*       */         
/*       */         private final List<AgentBuilder.Default.Transformation> transformations;
/*       */ 
/*       */         
/*       */         protected SimpleMatcher(AgentBuilder.RawMatcher ignoreMatcher, List<AgentBuilder.Default.Transformation> transformations) {
/* 12211 */           this.ignoreMatcher = ignoreMatcher;
/* 12212 */           this.transformations = transformations;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/* 12223 */           if (this.ignoreMatcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12224 */             return false;
/*       */           }
/* 12226 */           for (AgentBuilder.Default.Transformation transformation : this.transformations) {
/* 12227 */             if (transformation.getMatcher().matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12228 */               return true;
/*       */             }
/*       */           } 
/* 12231 */           return false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.ignoreMatcher.equals(((SimpleMatcher)param3Object).ignoreMatcher) ? false : (!!this.transformations.equals(((SimpleMatcher)param3Object).transformations)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.ignoreMatcher.hashCode()) * 31 + this.transformations.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class DifferentialMatcher
/*       */         implements AgentBuilder.RawMatcher
/*       */       {
/*       */         private final AgentBuilder.RawMatcher ignoreMatcher;
/*       */ 
/*       */         
/*       */         private final List<AgentBuilder.Default.Transformation> transformations;
/*       */ 
/*       */         
/*       */         private final ResettableClassFileTransformer classFileTransformer;
/*       */ 
/*       */ 
/*       */         
/*       */         protected DifferentialMatcher(AgentBuilder.RawMatcher ignoreMatcher, List<AgentBuilder.Default.Transformation> transformations, ResettableClassFileTransformer classFileTransformer) {
/* 12266 */           this.ignoreMatcher = ignoreMatcher;
/* 12267 */           this.transformations = transformations;
/* 12268 */           this.classFileTransformer = classFileTransformer;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/* 12279 */           Iterator<AgentBuilder.Transformer> iterator = this.classFileTransformer.iterator(typeDescription, classLoader, module, classBeingRedefined, protectionDomain);
/* 12280 */           if (this.ignoreMatcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12281 */             return iterator.hasNext();
/*       */           }
/* 12283 */           for (AgentBuilder.Default.Transformation transformation : this.transformations) {
/* 12284 */             if (transformation.getMatcher().matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12285 */               for (AgentBuilder.Transformer transformer : transformation.getTransformers()) {
/* 12286 */                 if (!iterator.hasNext() || !((AgentBuilder.Transformer)iterator.next()).equals(transformer)) {
/* 12287 */                   return true;
/*       */                 }
/*       */               } 
/*       */             }
/*       */           } 
/* 12292 */           return iterator.hasNext();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.ignoreMatcher.equals(((DifferentialMatcher)param3Object).ignoreMatcher) ? false : (!this.transformations.equals(((DifferentialMatcher)param3Object).transformations) ? false : (!!this.classFileTransformer.equals(((DifferentialMatcher)param3Object).classFileTransformer))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.ignoreMatcher.hashCode()) * 31 + this.transformations.hashCode()) * 31 + this.classFileTransformer.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class TransformerIterator
/*       */         implements Iterator<AgentBuilder.Transformer>
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         private final ClassLoader classLoader;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         private final JavaModule module;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         private final Class<?> classBeingRedefined;
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         private final ProtectionDomain protectionDomain;
/*       */ 
/*       */ 
/*       */         
/*       */         private final Iterator<AgentBuilder.Default.Transformation> transformations;
/*       */ 
/*       */ 
/*       */         
/*       */         private Iterator<AgentBuilder.Transformer> transformers;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected TransformerIterator(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, List<AgentBuilder.Default.Transformation> transformations) {
/* 12356 */           this.typeDescription = typeDescription;
/* 12357 */           this.classLoader = classLoader;
/* 12358 */           this.module = module;
/* 12359 */           this.classBeingRedefined = classBeingRedefined;
/* 12360 */           this.protectionDomain = protectionDomain;
/* 12361 */           this.transformations = transformations.iterator();
/* 12362 */           this.transformers = Collections.<AgentBuilder.Transformer>emptySet().iterator();
/* 12363 */           while (!this.transformers.hasNext() && this.transformations.hasNext()) {
/* 12364 */             AgentBuilder.Default.Transformation transformation = this.transformations.next();
/* 12365 */             if (transformation.getMatcher().matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12366 */               this.transformers = transformation.getTransformers().iterator();
/*       */             }
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean hasNext() {
/* 12375 */           return this.transformers.hasNext();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.Transformer next() {
/*       */           try {
/* 12383 */             return this.transformers.next();
/*       */           } finally {
/* 12385 */             while (!this.transformers.hasNext() && this.transformations.hasNext()) {
/* 12386 */               AgentBuilder.Default.Transformation transformation = this.transformations.next();
/* 12387 */               if (transformation.getMatcher().matches(this.typeDescription, this.classLoader, this.module, this.classBeingRedefined, this.protectionDomain)) {
/* 12388 */                 this.transformers = transformation.getTransformers().iterator();
/*       */               }
/*       */             } 
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void remove() {
/* 12398 */           throw new UnsupportedOperationException("remove");
/*       */         } } } @Enhance protected static class SimpleMatcher implements AgentBuilder.RawMatcher { private final AgentBuilder.RawMatcher ignoreMatcher; private final List<AgentBuilder.Default.Transformation> transformations; protected SimpleMatcher(AgentBuilder.RawMatcher ignoreMatcher, List<AgentBuilder.Default.Transformation> transformations) { this.ignoreMatcher = ignoreMatcher; this.transformations = transformations; }
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) { if (this.ignoreMatcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) return false;  for (AgentBuilder.Default.Transformation transformation : this.transformations) { if (transformation.getMatcher().matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain))
/*       */             return true;  }  return false; }
/*       */       public boolean equals(@MaybeNull Object param2Object) { return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.ignoreMatcher.equals(((SimpleMatcher)param2Object).ignoreMatcher) ? false : (!!this.transformations.equals(((SimpleMatcher)param2Object).transformations))))); }
/*       */       public int hashCode() { return (getClass().hashCode() * 31 + this.ignoreMatcher.hashCode()) * 31 + this.transformations.hashCode(); } }
/*       */     @Enhance protected static class DifferentialMatcher implements AgentBuilder.RawMatcher { private final AgentBuilder.RawMatcher ignoreMatcher; private final List<AgentBuilder.Default.Transformation> transformations; private final ResettableClassFileTransformer classFileTransformer;
/*       */       protected DifferentialMatcher(AgentBuilder.RawMatcher ignoreMatcher, List<AgentBuilder.Default.Transformation> transformations, ResettableClassFileTransformer classFileTransformer) { this.ignoreMatcher = ignoreMatcher; this.transformations = transformations; this.classFileTransformer = classFileTransformer; }
/*       */       public boolean matches(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) { Iterator<AgentBuilder.Transformer> iterator = this.classFileTransformer.iterator(typeDescription, classLoader, module, classBeingRedefined, protectionDomain); if (this.ignoreMatcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain))
/*       */           return iterator.hasNext();  for (AgentBuilder.Default.Transformation transformation : this.transformations) { if (transformation.getMatcher().matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain))
/*       */             for (AgentBuilder.Transformer transformer : transformation.getTransformers()) { if (!iterator.hasNext() || !((AgentBuilder.Transformer)iterator.next()).equals(transformer))
/*       */                 return true;  }   }  return iterator.hasNext(); }
/*       */       public boolean equals(@MaybeNull Object param2Object) { return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.ignoreMatcher.equals(((DifferentialMatcher)param2Object).ignoreMatcher) ? false : (!this.transformations.equals(((DifferentialMatcher)param2Object).transformations) ? false : (!!this.classFileTransformer.equals(((DifferentialMatcher)param2Object).classFileTransformer)))))); }
/*       */       public int hashCode() { return ((getClass().hashCode() * 31 + this.ignoreMatcher.hashCode()) * 31 + this.transformations.hashCode()) * 31 + this.classFileTransformer.hashCode(); } }
/* 12412 */     protected static class ExecutingTransformer extends ResettableClassFileTransformer.AbstractBase { protected static final Factory FACTORY = (Factory)AgentBuilder.Default.doPrivileged(Factory.CreationAction.INSTANCE); private final ByteBuddy byteBuddy; private final AgentBuilder.PoolStrategy poolStrategy; private final AgentBuilder.TypeStrategy typeStrategy; private final AgentBuilder.Listener listener; private final AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy; private final AgentBuilder.InitializationStrategy initializationStrategy; private final AgentBuilder.InjectionStrategy injectionStrategy; private final AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy; private final AgentBuilder.DescriptionStrategy descriptionStrategy; private final AgentBuilder.LocationStrategy locationStrategy; private final ClassFileLocator classFileLocator; private final AgentBuilder.FallbackStrategy fallbackStrategy; private final AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy; private final AgentBuilder.InstallationListener installationListener; private final AgentBuilder.RawMatcher ignoreMatcher; private final AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer; private final List<AgentBuilder.Default.Transformation> transformations; private final AgentBuilder.CircularityLock circularityLock; @MaybeNull private final Object accessControlContext; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*       */          }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ExecutingTransformer(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer, List<AgentBuilder.Default.Transformation> transformations, AgentBuilder.CircularityLock circularityLock) {
/* 12551 */         this.byteBuddy = byteBuddy;
/* 12552 */         this.typeStrategy = typeStrategy;
/* 12553 */         this.poolStrategy = poolStrategy;
/* 12554 */         this.locationStrategy = locationStrategy;
/* 12555 */         this.classFileLocator = classFileLocator;
/* 12556 */         this.listener = listener;
/* 12557 */         this.nativeMethodStrategy = nativeMethodStrategy;
/* 12558 */         this.initializationStrategy = initializationStrategy;
/* 12559 */         this.injectionStrategy = injectionStrategy;
/* 12560 */         this.lambdaInstrumentationStrategy = lambdaInstrumentationStrategy;
/* 12561 */         this.descriptionStrategy = descriptionStrategy;
/* 12562 */         this.fallbackStrategy = fallbackStrategy;
/* 12563 */         this.classFileBufferStrategy = classFileBufferStrategy;
/* 12564 */         this.installationListener = installationListener;
/* 12565 */         this.ignoreMatcher = ignoreMatcher;
/* 12566 */         this.resubmissionEnforcer = resubmissionEnforcer;
/* 12567 */         this.transformations = transformations;
/* 12568 */         this.circularityLock = circularityLock;
/* 12569 */         this.accessControlContext = getContext();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       @Enhance
/*       */       private static Object getContext() {
/* 12580 */         return ACCESS_CONTROLLER ? AccessController.getContext() : null;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       private static <T> T doPrivileged(PrivilegedAction<T> action, @MaybeNull Object context) {
/* 12593 */         return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0, (AccessControlContext)SYNTHETIC_LOCAL_VARIABLE_1) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       public byte[] transform(@MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/* 12605 */         if (this.circularityLock.acquire()) {
/*       */           try {
/* 12607 */             return doPrivileged(new LegacyVmDispatcher(classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation), this.accessControlContext);
/*       */           
/*       */           }
/*       */           finally {
/*       */ 
/*       */             
/* 12613 */             this.circularityLock.release();
/*       */           } 
/*       */         }
/* 12616 */         return AgentBuilder.Default.NO_TRANSFORMATION;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       protected byte[] transform(Object rawModule, @MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/* 12639 */         if (this.circularityLock.acquire()) {
/*       */           try {
/* 12641 */             return doPrivileged(new Java9CapableVmDispatcher(rawModule, classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation), this.accessControlContext);
/*       */ 
/*       */           
/*       */           }
/*       */           finally {
/*       */ 
/*       */             
/* 12648 */             this.circularityLock.release();
/*       */           } 
/*       */         }
/* 12651 */         return AgentBuilder.Default.NO_TRANSFORMATION;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       private byte[] transform(@MaybeNull JavaModule module, @MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/* 12673 */         if (internalName == null || !this.lambdaInstrumentationStrategy.isInstrumented(classBeingRedefined)) {
/* 12674 */           return AgentBuilder.Default.NO_TRANSFORMATION;
/*       */         }
/* 12676 */         String name = internalName.replace('/', '.');
/*       */         try {
/* 12678 */           if (this.resubmissionEnforcer.isEnforced(name, classLoader, module, classBeingRedefined)) {
/* 12679 */             return AgentBuilder.Default.NO_TRANSFORMATION;
/*       */           }
/* 12681 */         } catch (Throwable throwable) {
/*       */           try {
/* 12683 */             this.listener.onDiscovery(name, classLoader, module, (classBeingRedefined != null));
/*       */           } finally {
/* 12685 */             this.listener.onError(name, classLoader, module, (classBeingRedefined != null), throwable);
/*       */           } 
/* 12687 */           throw new IllegalStateException("Failed transformation of " + name, throwable);
/*       */         } 
/*       */         try {
/* 12690 */           this.listener.onDiscovery(name, classLoader, module, (classBeingRedefined != null));
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 12695 */           ClassFileLocator.Compound compound = new ClassFileLocator.Compound(new ClassFileLocator[] { this.classFileBufferStrategy.resolve(name, binaryRepresentation, classLoader, module, protectionDomain), this.classFileLocator, this.locationStrategy.classFileLocator(classLoader, module) });
/* 12696 */           TypePool typePool = this.classFileBufferStrategy.typePool(this.poolStrategy, (ClassFileLocator)compound, classLoader, name);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         }
/* 12706 */         catch (Throwable throwable) {
/* 12707 */           this.listener.onError(name, classLoader, module, (classBeingRedefined != null), throwable);
/* 12708 */           throw new IllegalStateException("Failed transformation of " + name, throwable);
/*       */         } finally {
/* 12710 */           this.listener.onComplete(name, classLoader, module, (classBeingRedefined != null));
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @MaybeNull
/*       */       private byte[] doTransform(@MaybeNull JavaModule module, @MaybeNull ClassLoader classLoader, String name, @MaybeNull Class<?> classBeingRedefined, boolean loaded, @MaybeNull ProtectionDomain protectionDomain, TypePool typePool, ClassFileLocator classFileLocator) {
/* 12736 */         TypeDescription typeDescription = this.descriptionStrategy.apply(name, classBeingRedefined, typePool, this.circularityLock, classLoader, module);
/* 12737 */         List<AgentBuilder.Transformer> transformers = new ArrayList<AgentBuilder.Transformer>();
/* 12738 */         if (!this.ignoreMatcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12739 */           for (AgentBuilder.Default.Transformation transformation : this.transformations) {
/* 12740 */             if (transformation.getMatcher().matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain)) {
/* 12741 */               transformers.addAll(transformation.getTransformers());
/* 12742 */               if (transformation.isTerminal()) {
/*       */                 break;
/*       */               }
/*       */             } 
/*       */           } 
/*       */         }
/* 12748 */         if (transformers.isEmpty()) {
/* 12749 */           this.listener.onIgnored(typeDescription, classLoader, module, loaded);
/* 12750 */           return AgentBuilder.Default.Transformation.NONE;
/*       */         } 
/* 12752 */         DynamicType.Builder<?> builder = this.typeStrategy.builder(typeDescription, this.byteBuddy, classFileLocator, this.nativeMethodStrategy
/*       */ 
/*       */             
/* 12755 */             .resolve(), classLoader, module, protectionDomain);
/*       */ 
/*       */ 
/*       */         
/* 12759 */         AgentBuilder.InitializationStrategy.Dispatcher dispatcher = this.initializationStrategy.dispatcher();
/* 12760 */         for (AgentBuilder.Transformer transformer : transformers) {
/* 12761 */           builder = transformer.transform(builder, typeDescription, classLoader, module, protectionDomain);
/*       */         }
/* 12763 */         DynamicType.Unloaded<?> dynamicType = dispatcher.apply(builder).make((TypeResolutionStrategy)TypeResolutionStrategy.Disabled.INSTANCE, typePool);
/* 12764 */         dispatcher.register((DynamicType)dynamicType, classLoader, protectionDomain, this.injectionStrategy);
/* 12765 */         this.listener.onTransformation(typeDescription, classLoader, module, loaded, (DynamicType)dynamicType);
/* 12766 */         return dynamicType.getBytes();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Iterator<AgentBuilder.Transformer> iterator(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/* 12777 */         return this.ignoreMatcher.matches(typeDescription, classLoader, module, classBeingRedefined, protectionDomain) ? 
/* 12778 */           Collections.<AgentBuilder.Transformer>emptySet().iterator() : new AgentBuilder.Default.Transformation.TransformerIterator(typeDescription, classLoader, module, classBeingRedefined, protectionDomain, this.transformations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public synchronized boolean reset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 12791 */         if (instrumentation.removeTransformer(classFileTransformer)) {
/* 12792 */           redefinitionStrategy.apply(instrumentation, this.poolStrategy, this.locationStrategy, this.descriptionStrategy, this.fallbackStrategy, redefinitionDiscoveryStrategy, this.lambdaInstrumentationStrategy, AgentBuilder.Listener.NoOp.INSTANCE, redefinitionListener, new AgentBuilder.Default.Transformation.SimpleMatcher(this.ignoreMatcher, this.transformations), redefinitionBatchAllocator, AgentBuilder.CircularityLock.Inactive.INSTANCE);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 12804 */           this.installationListener.onReset(instrumentation, classFileTransformer);
/* 12805 */           return true;
/*       */         } 
/* 12807 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum CreationAction
/*       */         implements PrivilegedAction<Factory>
/*       */       {
/* 12868 */         INSTANCE;
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*       */         public AgentBuilder.Default.ExecutingTransformer.Factory run()
/*       */         {
/*       */           
/* 12876 */           try { return new AgentBuilder.Default.ExecutingTransformer.Factory.ForJava9CapableVm((new ByteBuddy())
/* 12877 */                 .with(TypeValidation.DISABLED)
/* 12878 */                 .subclass(AgentBuilder.Default.ExecutingTransformer.class)
/* 12879 */                 .name(AgentBuilder.Default.ExecutingTransformer.class.getName() + "$ByteBuddy$ModuleSupport")
/* 12880 */                 .method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArgument(0, JavaType.MODULE.load())))
/* 12881 */                 .intercept((Implementation)MethodCall.invoke(AgentBuilder.Default.ExecutingTransformer.class.getDeclaredMethod("transform", new Class[] {
/*       */                         
/*       */                         Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class
/*       */ 
/*       */ 
/*       */                       
/* 12887 */                       })).onSuper().withAllArguments())
/* 12888 */                 .make()
/* 12889 */                 .load(AgentBuilder.Default.ExecutingTransformer.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT
/* 12890 */                   .with(AgentBuilder.Default.ExecutingTransformer.class.getProtectionDomain()))
/* 12891 */                 .getLoaded()
/* 12892 */                 .getDeclaredConstructor(new Class[] { 
/*       */                     ByteBuddy.class, AgentBuilder.Listener.class, AgentBuilder.PoolStrategy.class, AgentBuilder.TypeStrategy.class, AgentBuilder.LocationStrategy.class, ClassFileLocator.class, AgentBuilder.Default.NativeMethodStrategy.class, AgentBuilder.InitializationStrategy.class, AgentBuilder.InjectionStrategy.class, AgentBuilder.LambdaInstrumentationStrategy.class, 
/*       */                     AgentBuilder.DescriptionStrategy.class, AgentBuilder.FallbackStrategy.class, AgentBuilder.ClassFileBufferStrategy.class, AgentBuilder.InstallationListener.class, AgentBuilder.RawMatcher.class, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer.class, List.class, AgentBuilder.CircularityLock.class }));
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */              }
/*       */           
/* 12910 */           catch (Exception ignored)
/* 12911 */           { return AgentBuilder.Default.ExecutingTransformer.Factory.ForLegacyVm.INSTANCE; }  } } protected static interface Factory { ResettableClassFileTransformer make(ByteBuddy param3ByteBuddy, AgentBuilder.Listener param3Listener, AgentBuilder.PoolStrategy param3PoolStrategy, AgentBuilder.TypeStrategy param3TypeStrategy, AgentBuilder.LocationStrategy param3LocationStrategy, ClassFileLocator param3ClassFileLocator, AgentBuilder.Default.NativeMethodStrategy param3NativeMethodStrategy, AgentBuilder.InitializationStrategy param3InitializationStrategy, AgentBuilder.InjectionStrategy param3InjectionStrategy, AgentBuilder.LambdaInstrumentationStrategy param3LambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy param3DescriptionStrategy, AgentBuilder.FallbackStrategy param3FallbackStrategy, AgentBuilder.ClassFileBufferStrategy param3ClassFileBufferStrategy, AgentBuilder.InstallationListener param3InstallationListener, AgentBuilder.RawMatcher param3RawMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer param3ResubmissionEnforcer, List<AgentBuilder.Default.Transformation> param3List, AgentBuilder.CircularityLock param3CircularityLock); public enum CreationAction implements PrivilegedAction<Factory> { INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public AgentBuilder.Default.ExecutingTransformer.Factory run() { try { return new AgentBuilder.Default.ExecutingTransformer.Factory.ForJava9CapableVm((new ByteBuddy()).with(TypeValidation.DISABLED).subclass(AgentBuilder.Default.ExecutingTransformer.class).name(AgentBuilder.Default.ExecutingTransformer.class.getName() + "$ByteBuddy$ModuleSupport").method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArgument(0, JavaType.MODULE.load()))).intercept((Implementation)MethodCall.invoke(AgentBuilder.Default.ExecutingTransformer.class.getDeclaredMethod("transform", new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).onSuper().withAllArguments()).make().load(AgentBuilder.Default.ExecutingTransformer.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT.with(AgentBuilder.Default.ExecutingTransformer.class.getProtectionDomain())).getLoaded().getDeclaredConstructor(new Class[] { ByteBuddy.class, AgentBuilder.Listener.class, AgentBuilder.PoolStrategy.class, AgentBuilder.TypeStrategy.class, AgentBuilder.LocationStrategy.class, ClassFileLocator.class, AgentBuilder.Default.NativeMethodStrategy.class, AgentBuilder.InitializationStrategy.class, AgentBuilder.InjectionStrategy.class, AgentBuilder.LambdaInstrumentationStrategy.class, AgentBuilder.DescriptionStrategy.class, AgentBuilder.FallbackStrategy.class, AgentBuilder.ClassFileBufferStrategy.class, AgentBuilder.InstallationListener.class, AgentBuilder.RawMatcher.class, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer.class, List.class, AgentBuilder.CircularityLock.class })); } catch (Exception ignored) { return AgentBuilder.Default.ExecutingTransformer.Factory.ForLegacyVm.INSTANCE; }
/*       */              }
/*       */            }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForJava9CapableVm
/*       */           implements Factory
/*       */         {
/*       */           private final Constructor<? extends ResettableClassFileTransformer> executingTransformer;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ForJava9CapableVm(Constructor<? extends ResettableClassFileTransformer> executingTransformer) {
/* 12936 */             this.executingTransformer = executingTransformer;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ResettableClassFileTransformer make(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer, List<AgentBuilder.Default.Transformation> transformations, AgentBuilder.CircularityLock circularityLock) {
/*       */             try {
/* 12961 */               return this.executingTransformer.newInstance(new Object[] { byteBuddy, listener, poolStrategy, typeStrategy, locationStrategy, classFileLocator, nativeMethodStrategy, initializationStrategy, injectionStrategy, lambdaInstrumentationStrategy, descriptionStrategy, fallbackStrategy, classFileBufferStrategy, installationListener, ignoreMatcher, resubmissionEnforcer, transformations, circularityLock });
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             }
/* 12979 */             catch (IllegalAccessException exception) {
/* 12980 */               throw new IllegalStateException("Cannot access " + this.executingTransformer, exception);
/* 12981 */             } catch (InstantiationException exception) {
/* 12982 */               throw new IllegalStateException("Cannot instantiate " + this.executingTransformer.getDeclaringClass(), exception);
/* 12983 */             } catch (InvocationTargetException exception) {
/* 12984 */               throw new IllegalStateException("Cannot invoke " + this.executingTransformer, exception.getTargetException());
/*       */             } 
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.executingTransformer.equals(((ForJava9CapableVm)param4Object).executingTransformer))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.executingTransformer.hashCode();
/*       */           } }
/*       */         
/*       */         public enum ForLegacyVm implements Factory {
/* 12997 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ResettableClassFileTransformer make(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer, List<AgentBuilder.Default.Transformation> transformations, AgentBuilder.CircularityLock circularityLock) {
/* 13020 */             return new AgentBuilder.Default.ExecutingTransformer(byteBuddy, listener, poolStrategy, typeStrategy, locationStrategy, classFileLocator, nativeMethodStrategy, initializationStrategy, injectionStrategy, lambdaInstrumentationStrategy, descriptionStrategy, fallbackStrategy, classFileBufferStrategy, installationListener, ignoreMatcher, resubmissionEnforcer, transformations, circularityLock);
/*       */           }
/*       */         } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance(includeSyntheticFields = true)
/*       */       protected class LegacyVmDispatcher
/*       */         implements PrivilegedAction<byte[]>
/*       */       {
/*       */         @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final ClassLoader classLoader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final String internalName;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final Class<?> classBeingRedefined;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final ProtectionDomain protectionDomain;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final byte[] binaryRepresentation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected LegacyVmDispatcher(@MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/* 13095 */           this.classLoader = classLoader;
/* 13096 */           this.internalName = internalName;
/* 13097 */           this.classBeingRedefined = classBeingRedefined;
/* 13098 */           this.protectionDomain = protectionDomain;
/* 13099 */           this.binaryRepresentation = binaryRepresentation;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public byte[] run() {
/* 13107 */           return AgentBuilder.Default.ExecutingTransformer.this.transform(JavaModule.UNSUPPORTED, this.classLoader, this.internalName, this.classBeingRedefined, this.protectionDomain, this.binaryRepresentation);
/*       */         } public boolean equals(@MaybeNull Object param3Object) { if (this == param3Object)
/*       */             return true; 
/*       */           if (param3Object == null)
/*       */             return false; 
/*       */           if (getClass() != param3Object.getClass())
/*       */             return false; 
/*       */           String str1 = ((LegacyVmDispatcher)param3Object).internalName;
/*       */           String str2 = this.internalName;
/*       */           if (str1 != null) {
/*       */             if (str2 != null) {
/*       */               if (!str2.equals(str1))
/*       */                 return false; 
/*       */             } else {
/*       */               return false;
/*       */             } 
/*       */           } else if (str2 != null) {
/*       */             return false;
/*       */           } 
/*       */           ClassLoader classLoader1 = ((LegacyVmDispatcher)param3Object).classLoader;
/*       */           ClassLoader classLoader2 = this.classLoader;
/*       */           if (classLoader1 != null) {
/*       */             if (classLoader2 != null) {
/*       */               if (!classLoader2.equals(classLoader1))
/*       */                 return false; 
/*       */             } else {
/*       */               return false;
/*       */             } 
/*       */           } else if (classLoader2 != null) {
/*       */             return false;
/*       */           } 
/*       */           Class<?> clazz1 = ((LegacyVmDispatcher)param3Object).classBeingRedefined;
/*       */           Class<?> clazz2 = this.classBeingRedefined;
/*       */           if (clazz1 != null) {
/*       */             if (clazz2 != null) {
/*       */               if (!clazz2.equals(clazz1))
/*       */                 return false; 
/*       */             } else {
/*       */               return false;
/*       */             } 
/*       */           } else if (clazz2 != null) {
/*       */             return false;
/*       */           } 
/*       */           ProtectionDomain protectionDomain1 = ((LegacyVmDispatcher)param3Object).protectionDomain;
/*       */           ProtectionDomain protectionDomain2 = this.protectionDomain;
/*       */           if (protectionDomain1 != null) {
/*       */             if (protectionDomain2 != null) {
/*       */               if (!protectionDomain2.equals(protectionDomain1))
/*       */                 return false; 
/*       */             } else {
/*       */               return false;
/*       */             } 
/*       */           } else if (protectionDomain2 != null) {
/*       */             return false;
/*       */           } 
/*       */           return !Arrays.equals(this.binaryRepresentation, ((LegacyVmDispatcher)param3Object).binaryRepresentation) ? false : (!!AgentBuilder.Default.ExecutingTransformer.this.equals(AgentBuilder.Default.ExecutingTransformer.this)); } public int hashCode() { ClassLoader classLoader = this.classLoader;
/*       */           if (classLoader != null);
/*       */           String str = this.internalName;
/*       */           if (str != null);
/*       */           Class<?> clazz = this.classBeingRedefined;
/*       */           if (clazz != null);
/*       */           ProtectionDomain protectionDomain = this.protectionDomain;
/*       */           if (protectionDomain != null);
/*       */           return (((((getClass().hashCode() * 31 + classLoader.hashCode()) * 31 + str.hashCode()) * 31 + clazz.hashCode()) * 31 + protectionDomain.hashCode()) * 31 + Arrays.hashCode(this.binaryRepresentation)) * 31 + AgentBuilder.Default.ExecutingTransformer.this.hashCode(); } } @Enhance(includeSyntheticFields = true) protected class Java9CapableVmDispatcher implements PrivilegedAction<byte[]> { private final Object rawModule; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final ClassLoader classLoader; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final String internalName; @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final Class<?> classBeingRedefined; @MaybeNull
/*       */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*       */         private final ProtectionDomain protectionDomain; private final byte[] binaryRepresentation;
/* 13176 */         protected Java9CapableVmDispatcher(@MaybeNull Object rawModule, @MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] binaryRepresentation) { this.rawModule = rawModule;
/* 13177 */           this.classLoader = classLoader;
/* 13178 */           this.internalName = internalName;
/* 13179 */           this.classBeingRedefined = classBeingRedefined;
/* 13180 */           this.protectionDomain = protectionDomain;
/* 13181 */           this.binaryRepresentation = binaryRepresentation; } public boolean equals(@MaybeNull Object param3Object) { if (this == param3Object) return true;  if (param3Object == null)
/*       */             return false;  if (getClass() != param3Object.getClass())
/*       */             return false;  String str1 = ((Java9CapableVmDispatcher)param3Object).internalName; String str2 = this.internalName; if (str1 != null) { if (str2 != null) { if (!str2.equals(str1))
/*       */                 return false;  } else { return false; }  } else if (str2 != null) { return false; }  if (!this.rawModule.equals(((Java9CapableVmDispatcher)param3Object).rawModule))
/*       */             return false;  ClassLoader classLoader1 = ((Java9CapableVmDispatcher)param3Object).classLoader; ClassLoader classLoader2 = this.classLoader; if (classLoader1 != null) { if (classLoader2 != null) { if (!classLoader2.equals(classLoader1))
/*       */                 return false;  } else { return false; }  } else if (classLoader2 != null) { return false; }  Class<?> clazz1 = ((Java9CapableVmDispatcher)param3Object).classBeingRedefined; Class<?> clazz2 = this.classBeingRedefined; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*       */                 return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  ProtectionDomain protectionDomain1 = ((Java9CapableVmDispatcher)param3Object).protectionDomain; ProtectionDomain protectionDomain2 = this.protectionDomain; if (protectionDomain1 != null) { if (protectionDomain2 != null) { if (!protectionDomain2.equals(protectionDomain1))
/*       */                 return false;  } else { return false; }  } else if (protectionDomain2 != null) { return false; }  return !Arrays.equals(this.binaryRepresentation, ((Java9CapableVmDispatcher)param3Object).binaryRepresentation) ? false : (!!AgentBuilder.Default.ExecutingTransformer.this.equals(AgentBuilder.Default.ExecutingTransformer.this)); }
/* 13189 */         @MaybeNull public byte[] run() { return AgentBuilder.Default.ExecutingTransformer.this.transform(JavaModule.of(this.rawModule), this.classLoader, this.internalName, this.classBeingRedefined, this.protectionDomain, this.binaryRepresentation); } public int hashCode() { ClassLoader classLoader = this.classLoader; if (classLoader != null); String str = this.internalName; if (str != null); Class<?> clazz = this.classBeingRedefined; if (clazz != null); ProtectionDomain protectionDomain = this.protectionDomain; if (protectionDomain != null); return ((((((getClass().hashCode() * 31 + this.rawModule.hashCode()) * 31 + classLoader.hashCode()) * 31 + str.hashCode()) * 31 + clazz.hashCode()) * 31 + protectionDomain.hashCode()) * 31 + Arrays.hashCode(this.binaryRepresentation)) * 31 + AgentBuilder.Default.ExecutingTransformer.this.hashCode(); } } } protected static interface Factory { ResettableClassFileTransformer make(ByteBuddy param2ByteBuddy, AgentBuilder.Listener param2Listener, AgentBuilder.PoolStrategy param2PoolStrategy, AgentBuilder.TypeStrategy param2TypeStrategy, AgentBuilder.LocationStrategy param2LocationStrategy, ClassFileLocator param2ClassFileLocator, AgentBuilder.Default.NativeMethodStrategy param2NativeMethodStrategy, AgentBuilder.InitializationStrategy param2InitializationStrategy, AgentBuilder.InjectionStrategy param2InjectionStrategy, AgentBuilder.LambdaInstrumentationStrategy param2LambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy param2DescriptionStrategy, AgentBuilder.FallbackStrategy param2FallbackStrategy, AgentBuilder.ClassFileBufferStrategy param2ClassFileBufferStrategy, AgentBuilder.InstallationListener param2InstallationListener, AgentBuilder.RawMatcher param2RawMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer param2ResubmissionEnforcer, List<AgentBuilder.Default.Transformation> param2List, AgentBuilder.CircularityLock param2CircularityLock); public enum CreationAction implements PrivilegedAction<Factory> {
/*       */         INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public AgentBuilder.Default.ExecutingTransformer.Factory run() { try { return new AgentBuilder.Default.ExecutingTransformer.Factory.ForJava9CapableVm((new ByteBuddy()).with(TypeValidation.DISABLED).subclass(AgentBuilder.Default.ExecutingTransformer.class).name(AgentBuilder.Default.ExecutingTransformer.class.getName() + "$ByteBuddy$ModuleSupport").method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArgument(0, JavaType.MODULE.load()))).intercept((Implementation)MethodCall.invoke(AgentBuilder.Default.ExecutingTransformer.class.getDeclaredMethod("transform", new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).onSuper().withAllArguments()).make().load(AgentBuilder.Default.ExecutingTransformer.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT.with(AgentBuilder.Default.ExecutingTransformer.class.getProtectionDomain())).getLoaded().getDeclaredConstructor(new Class[] { 
/*       */                     ByteBuddy.class, AgentBuilder.Listener.class, AgentBuilder.PoolStrategy.class, AgentBuilder.TypeStrategy.class, AgentBuilder.LocationStrategy.class, ClassFileLocator.class, AgentBuilder.Default.NativeMethodStrategy.class, AgentBuilder.InitializationStrategy.class, AgentBuilder.InjectionStrategy.class, AgentBuilder.LambdaInstrumentationStrategy.class, 
/*       */                     AgentBuilder.DescriptionStrategy.class, AgentBuilder.FallbackStrategy.class, AgentBuilder.ClassFileBufferStrategy.class, AgentBuilder.InstallationListener.class, AgentBuilder.RawMatcher.class, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer.class, List.class, AgentBuilder.CircularityLock.class })); }
/*       */           catch (Exception ignored)
/*       */           { return AgentBuilder.Default.ExecutingTransformer.Factory.ForLegacyVm.INSTANCE; }
/*       */            }
/*       */       } @Enhance public static class ForJava9CapableVm implements Factory {
/*       */         private final Constructor<? extends ResettableClassFileTransformer> executingTransformer;
/*       */         protected ForJava9CapableVm(Constructor<? extends ResettableClassFileTransformer> executingTransformer) { this.executingTransformer = executingTransformer; }
/*       */         public ResettableClassFileTransformer make(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer, List<AgentBuilder.Default.Transformation> transformations, AgentBuilder.CircularityLock circularityLock) { try {
/*       */             return this.executingTransformer.newInstance(new Object[] { 
/*       */                   byteBuddy, listener, poolStrategy, typeStrategy, locationStrategy, classFileLocator, nativeMethodStrategy, initializationStrategy, injectionStrategy, lambdaInstrumentationStrategy, 
/*       */                   descriptionStrategy, fallbackStrategy, classFileBufferStrategy, installationListener, ignoreMatcher, resubmissionEnforcer, transformations, circularityLock });
/*       */           } catch (IllegalAccessException exception) {
/*       */             throw new IllegalStateException("Cannot access " + this.executingTransformer, exception);
/*       */           } catch (InstantiationException exception) {
/*       */             throw new IllegalStateException("Cannot instantiate " + this.executingTransformer.getDeclaringClass(), exception);
/*       */           } catch (InvocationTargetException exception) {
/*       */             throw new IllegalStateException("Cannot invoke " + this.executingTransformer, exception.getTargetException());
/*       */           }  }
/*       */         public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.executingTransformer.equals(((ForJava9CapableVm)param4Object).executingTransformer)))); }
/*       */         public int hashCode() { return getClass().hashCode() * 31 + this.executingTransformer.hashCode(); }
/*       */       }
/*       */       public enum ForLegacyVm implements Factory { INSTANCE;
/*       */         public ResettableClassFileTransformer make(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, AgentBuilder.RedefinitionStrategy.ResubmissionEnforcer resubmissionEnforcer, List<AgentBuilder.Default.Transformation> transformations, AgentBuilder.CircularityLock circularityLock) { return new AgentBuilder.Default.ExecutingTransformer(byteBuddy, listener, poolStrategy, typeStrategy, locationStrategy, classFileLocator, nativeMethodStrategy, initializationStrategy, injectionStrategy, lambdaInstrumentationStrategy, descriptionStrategy, fallbackStrategy, classFileBufferStrategy, installationListener, ignoreMatcher, resubmissionEnforcer, transformations, circularityLock); } } }
/* 13215 */     protected static abstract class Delegator implements AgentBuilder { public AgentBuilder with(ByteBuddy byteBuddy) { return materialize().with(byteBuddy); }
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract AgentBuilder materialize();
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.Listener listener) {
/* 13222 */         return materialize().with(listener);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.CircularityLock circularityLock) {
/* 13229 */         return materialize().with(circularityLock);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.TypeStrategy typeStrategy) {
/* 13236 */         return materialize().with(typeStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.PoolStrategy poolStrategy) {
/* 13243 */         return materialize().with(poolStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.LocationStrategy locationStrategy) {
/* 13250 */         return materialize().with(locationStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(ClassFileLocator classFileLocator) {
/* 13257 */         return materialize().with(classFileLocator);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.InitializationStrategy initializationStrategy) {
/* 13264 */         return materialize().with(initializationStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RedefinitionListenable.WithoutBatchStrategy with(AgentBuilder.RedefinitionStrategy redefinitionStrategy) {
/* 13271 */         return materialize().with(redefinitionStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy) {
/* 13278 */         return materialize().with(lambdaInstrumentationStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.DescriptionStrategy descriptionStrategy) {
/* 13285 */         return materialize().with(descriptionStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.FallbackStrategy fallbackStrategy) {
/* 13292 */         return materialize().with(fallbackStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy) {
/* 13299 */         return materialize().with(classFileBufferStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.InstallationListener installationListener) {
/* 13306 */         return materialize().with(installationListener);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.InjectionStrategy injectionStrategy) {
/* 13313 */         return materialize().with(injectionStrategy);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder with(AgentBuilder.TransformerDecorator transformerDecorator) {
/* 13320 */         return materialize().with(transformerDecorator);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder enableNativeMethodPrefix(String prefix) {
/* 13327 */         return materialize().enableNativeMethodPrefix(prefix);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder disableNativeMethodPrefix() {
/* 13334 */         return materialize().disableNativeMethodPrefix();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder disableClassFormatChanges() {
/* 13341 */         return materialize().disableClassFormatChanges();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder warmUp(Class<?>... type) {
/* 13348 */         return materialize().warmUp(type);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder warmUp(Collection<Class<?>> types) {
/* 13355 */         return materialize().warmUp(types);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder assureReadEdgeTo(Instrumentation instrumentation, Class<?>... type) {
/* 13362 */         return materialize().assureReadEdgeTo(instrumentation, type);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder assureReadEdgeTo(Instrumentation instrumentation, JavaModule... module) {
/* 13369 */         return materialize().assureReadEdgeTo(instrumentation, module);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder assureReadEdgeTo(Instrumentation instrumentation, Collection<? extends JavaModule> modules) {
/* 13376 */         return materialize().assureReadEdgeTo(instrumentation, modules);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder assureReadEdgeFromAndTo(Instrumentation instrumentation, Class<?>... type) {
/* 13383 */         return materialize().assureReadEdgeFromAndTo(instrumentation, type);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder assureReadEdgeFromAndTo(Instrumentation instrumentation, JavaModule... module) {
/* 13390 */         return materialize().assureReadEdgeFromAndTo(instrumentation, module);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder assureReadEdgeFromAndTo(Instrumentation instrumentation, Collection<? extends JavaModule> modules) {
/* 13397 */         return materialize().assureReadEdgeFromAndTo(instrumentation, modules);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Narrowable type(ElementMatcher<? super TypeDescription> typeMatcher) {
/* 13404 */         return materialize().type(typeMatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Narrowable type(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 13411 */         return materialize().type(typeMatcher, classLoaderMatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Narrowable type(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 13420 */         return materialize().type(typeMatcher, classLoaderMatcher, moduleMatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Narrowable type(AgentBuilder.RawMatcher matcher) {
/* 13427 */         return materialize().type(matcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Ignored ignore(ElementMatcher<? super TypeDescription> ignoredTypes) {
/* 13434 */         return materialize().ignore(ignoredTypes);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Ignored ignore(ElementMatcher<? super TypeDescription> ignoredTypes, ElementMatcher<? super ClassLoader> ignoredClassLoaders) {
/* 13441 */         return materialize().ignore(ignoredTypes, ignoredClassLoaders);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Ignored ignore(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 13450 */         return materialize().ignore(typeMatcher, classLoaderMatcher, moduleMatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Ignored ignore(AgentBuilder.RawMatcher rawMatcher) {
/* 13457 */         return materialize().ignore(rawMatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ClassFileTransformer makeRaw() {
/* 13464 */         return materialize().makeRaw();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer installOn(Instrumentation instrumentation) {
/* 13471 */         return materialize().installOn(instrumentation);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer installOnByteBuddyAgent() {
/* 13478 */         return materialize().installOnByteBuddyAgent();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer) {
/* 13485 */         return materialize().patchOn(instrumentation, classFileTransformer);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RawMatcher differentialMatcher) {
/* 13492 */         return materialize().patchOn(instrumentation, classFileTransformer, differentialMatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.PatchMode patchMode) {
/* 13499 */         return materialize().patchOn(instrumentation, classFileTransformer, patchMode);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer patchOn(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RawMatcher differentialMatcher, AgentBuilder.PatchMode patchMode) {
/* 13506 */         return materialize().patchOn(instrumentation, classFileTransformer, differentialMatcher, patchMode);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer classFileTransformer) {
/* 13513 */         return materialize().patchOnByteBuddyAgent(classFileTransformer);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ResettableClassFileTransformer patchOnByteBuddyAgent(ResettableClassFileTransformer classFileTransformer, AgentBuilder.PatchMode patchMode) {
/* 13520 */         return materialize().patchOnByteBuddyAgent(classFileTransformer, patchMode);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static abstract class Matchable<S extends AgentBuilder.Matchable<S>>
/*       */         extends Delegator
/*       */         implements AgentBuilder.Matchable<S>
/*       */       {
/*       */         public S and(ElementMatcher<? super TypeDescription> typeMatcher) {
/* 13534 */           return and(typeMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public S and(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 13541 */           return and(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public S and(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 13550 */           return and(new AgentBuilder.RawMatcher.ForElementMatchers(typeMatcher, classLoaderMatcher, moduleMatcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public S or(ElementMatcher<? super TypeDescription> typeMatcher) {
/* 13557 */           return or(typeMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public S or(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 13564 */           return or(typeMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public S or(ElementMatcher<? super TypeDescription> typeMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 13573 */           return or(new AgentBuilder.RawMatcher.ForElementMatchers(typeMatcher, classLoaderMatcher, moduleMatcher));
/*       */         }
/*       */       } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance(includeSyntheticFields = true)
/*       */     protected class Ignoring
/*       */       extends Delegator.Matchable<AgentBuilder.Ignored>
/*       */       implements AgentBuilder.Ignored
/*       */     {
/*       */       private final AgentBuilder.RawMatcher rawMatcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Ignoring(AgentBuilder.RawMatcher rawMatcher) {
/* 13595 */         this.rawMatcher = rawMatcher;
/*       */       }
/*       */ 
/*       */       
/*       */       protected AgentBuilder materialize() {
/* 13600 */         return new AgentBuilder.Default(AgentBuilder.Default.this.byteBuddy, AgentBuilder.Default.this.listener, AgentBuilder.Default.this.circularityLock, AgentBuilder.Default.this.poolStrategy, AgentBuilder.Default.this.typeStrategy, AgentBuilder.Default.this.locationStrategy, AgentBuilder.Default.this.classFileLocator, AgentBuilder.Default.this.nativeMethodStrategy, AgentBuilder.Default.this.warmupStrategy, AgentBuilder.Default.this.transformerDecorator, AgentBuilder.Default.this.initializationStrategy, AgentBuilder.Default.this.redefinitionStrategy, AgentBuilder.Default.this.redefinitionDiscoveryStrategy, AgentBuilder.Default.this.redefinitionBatchAllocator, AgentBuilder.Default.this.redefinitionListener, AgentBuilder.Default.this.redefinitionResubmissionStrategy, AgentBuilder.Default.this.injectionStrategy, AgentBuilder.Default.this.lambdaInstrumentationStrategy, AgentBuilder.Default.this.descriptionStrategy, AgentBuilder.Default.this.fallbackStrategy, AgentBuilder.Default.this.classFileBufferStrategy, AgentBuilder.Default.this.installationListener, this.rawMatcher, AgentBuilder.Default.this.transformations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Ignored and(AgentBuilder.RawMatcher rawMatcher) {
/* 13630 */         return new Ignoring(new AgentBuilder.RawMatcher.Conjunction(new AgentBuilder.RawMatcher[] { this.rawMatcher, rawMatcher }));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Ignored or(AgentBuilder.RawMatcher rawMatcher) {
/* 13637 */         return new Ignoring(new AgentBuilder.RawMatcher.Disjunction(new AgentBuilder.RawMatcher[] { this.rawMatcher, rawMatcher }));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.rawMatcher.equals(((Ignoring)param2Object).rawMatcher) ? false : (!!AgentBuilder.Default.this.equals(AgentBuilder.Default.this)))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.rawMatcher.hashCode()) * 31 + AgentBuilder.Default.this.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance(includeSyntheticFields = true)
/*       */     protected class Transforming
/*       */       extends Delegator.Matchable<AgentBuilder.Identified.Narrowable>
/*       */       implements AgentBuilder.Identified.Extendable, AgentBuilder.Identified.Narrowable
/*       */     {
/*       */       private final AgentBuilder.RawMatcher rawMatcher;
/*       */ 
/*       */       
/*       */       private final List<AgentBuilder.Transformer> transformers;
/*       */ 
/*       */       
/*       */       private final boolean terminal;
/*       */ 
/*       */ 
/*       */       
/*       */       protected Transforming(AgentBuilder.RawMatcher rawMatcher, List<AgentBuilder.Transformer> transformers, boolean terminal) {
/* 13672 */         this.rawMatcher = rawMatcher;
/* 13673 */         this.transformers = transformers;
/* 13674 */         this.terminal = terminal;
/*       */       }
/*       */ 
/*       */       
/*       */       protected AgentBuilder materialize() {
/* 13679 */         return new AgentBuilder.Default(AgentBuilder.Default.this.byteBuddy, AgentBuilder.Default.this.listener, AgentBuilder.Default.this.circularityLock, AgentBuilder.Default.this.poolStrategy, AgentBuilder.Default.this.typeStrategy, AgentBuilder.Default.this.locationStrategy, AgentBuilder.Default.this.classFileLocator, AgentBuilder.Default.this.nativeMethodStrategy, AgentBuilder.Default.this.warmupStrategy, AgentBuilder.Default.this.transformerDecorator, AgentBuilder.Default.this.initializationStrategy, AgentBuilder.Default.this.redefinitionStrategy, AgentBuilder.Default.this.redefinitionDiscoveryStrategy, AgentBuilder.Default.this.redefinitionBatchAllocator, AgentBuilder.Default.this.redefinitionListener, AgentBuilder.Default.this.redefinitionResubmissionStrategy, AgentBuilder.Default.this.injectionStrategy, AgentBuilder.Default.this.lambdaInstrumentationStrategy, AgentBuilder.Default.this.descriptionStrategy, AgentBuilder.Default.this.fallbackStrategy, AgentBuilder.Default.this.classFileBufferStrategy, AgentBuilder.Default.this.installationListener, AgentBuilder.Default.this.ignoreMatcher, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 13702 */             CompoundList.of(AgentBuilder.Default.this.transformations, new AgentBuilder.Default.Transformation(this.rawMatcher, this.transformers, this.terminal)));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Extendable transform(AgentBuilder.Transformer transformer) {
/* 13709 */         return new Transforming(this.rawMatcher, CompoundList.of(this.transformers, transformer), this.terminal);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder asTerminalTransformation() {
/* 13716 */         return new Transforming(this.rawMatcher, this.transformers, true);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Narrowable and(AgentBuilder.RawMatcher rawMatcher) {
/* 13723 */         return new Transforming(new AgentBuilder.RawMatcher.Conjunction(new AgentBuilder.RawMatcher[] { this.rawMatcher, rawMatcher }, ), this.transformers, this.terminal);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.Identified.Narrowable or(AgentBuilder.RawMatcher rawMatcher) {
/* 13730 */         return new Transforming(new AgentBuilder.RawMatcher.Disjunction(new AgentBuilder.RawMatcher[] { this.rawMatcher, rawMatcher }, ), this.transformers, this.terminal);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.terminal != ((Transforming)param2Object).terminal) ? false : (!this.rawMatcher.equals(((Transforming)param2Object).rawMatcher) ? false : (!this.transformers.equals(((Transforming)param2Object).transformers) ? false : (!!AgentBuilder.Default.this.equals(AgentBuilder.Default.this)))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.rawMatcher.hashCode()) * 31 + this.transformers.hashCode()) * 31 + this.terminal) * 31 + AgentBuilder.Default.this.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static class Redefining
/*       */       extends Default
/*       */       implements AgentBuilder.RedefinitionListenable.WithoutBatchStrategy
/*       */     {
/*       */       protected Redefining(ByteBuddy byteBuddy, AgentBuilder.Listener listener, AgentBuilder.CircularityLock circularityLock, AgentBuilder.PoolStrategy poolStrategy, AgentBuilder.TypeStrategy typeStrategy, AgentBuilder.LocationStrategy locationStrategy, ClassFileLocator classFileLocator, AgentBuilder.Default.NativeMethodStrategy nativeMethodStrategy, AgentBuilder.Default.WarmupStrategy warmupStrategy, AgentBuilder.TransformerDecorator transformerDecorator, AgentBuilder.InitializationStrategy initializationStrategy, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener, AgentBuilder.RedefinitionStrategy.ResubmissionStrategy redefinitionResubmissionStrategy, AgentBuilder.InjectionStrategy injectionStrategy, AgentBuilder.LambdaInstrumentationStrategy lambdaInstrumentationStrategy, AgentBuilder.DescriptionStrategy descriptionStrategy, AgentBuilder.FallbackStrategy fallbackStrategy, AgentBuilder.ClassFileBufferStrategy classFileBufferStrategy, AgentBuilder.InstallationListener installationListener, AgentBuilder.RawMatcher ignoreMatcher, List<AgentBuilder.Default.Transformation> transformations) {
/* 13792 */         super(byteBuddy, listener, circularityLock, poolStrategy, typeStrategy, locationStrategy, classFileLocator, nativeMethodStrategy, warmupStrategy, transformerDecorator, initializationStrategy, redefinitionStrategy, redefinitionDiscoveryStrategy, redefinitionBatchAllocator, redefinitionListener, redefinitionResubmissionStrategy, injectionStrategy, lambdaInstrumentationStrategy, descriptionStrategy, fallbackStrategy, classFileBufferStrategy, installationListener, ignoreMatcher, transformations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RedefinitionListenable.WithImplicitDiscoveryStrategy with(AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator) {
/* 13822 */         if (!this.redefinitionStrategy.isEnabled()) {
/* 13823 */           throw new IllegalStateException("Cannot set redefinition batch allocator when redefinition is disabled");
/*       */         }
/* 13825 */         return new Redefining(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RedefinitionListenable redefineOnly(Class<?>... type) {
/* 13855 */         return with(new AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.Explicit(type));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RedefinitionListenable with(AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy) {
/* 13862 */         if (!this.redefinitionStrategy.isEnabled()) {
/* 13863 */           throw new IllegalStateException("Cannot set redefinition discovery strategy when redefinition is disabled");
/*       */         }
/* 13865 */         return new Redefining(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, this.redefinitionListener, this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RedefinitionListenable with(AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 13895 */         if (!this.redefinitionStrategy.isEnabled()) {
/* 13896 */           throw new IllegalStateException("Cannot set redefinition listener when redefinition is disabled");
/*       */         }
/* 13898 */         return new Redefining(this.byteBuddy, this.listener, this.circularityLock, this.poolStrategy, this.typeStrategy, this.locationStrategy, this.classFileLocator, this.nativeMethodStrategy, this.warmupStrategy, this.transformerDecorator, this.initializationStrategy, this.redefinitionStrategy, this.redefinitionDiscoveryStrategy, this.redefinitionBatchAllocator, new AgentBuilder.RedefinitionStrategy.Listener.Compound(new AgentBuilder.RedefinitionStrategy.Listener[] { this.redefinitionListener, redefinitionListener }, ), this.redefinitionResubmissionStrategy, this.injectionStrategy, this.lambdaInstrumentationStrategy, this.descriptionStrategy, this.fallbackStrategy, this.classFileBufferStrategy, this.installationListener, this.ignoreMatcher, this.transformations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public AgentBuilder.RedefinitionListenable.WithoutResubmissionSpecification withResubmission(AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler) {
/* 13928 */         if (!this.redefinitionStrategy.isEnabled()) {
/* 13929 */           throw new IllegalStateException("Cannot enable resubmission when redefinition is disabled");
/*       */         }
/* 13931 */         return new WithResubmission(resubmissionScheduler, AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher.Trivial.NON_MATCHING, AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher.Trivial.NON_MATCHING);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected class WithResubmission
/*       */         extends AgentBuilder.Default.Delegator
/*       */         implements AgentBuilder.RedefinitionListenable.WithResubmissionSpecification
/*       */       {
/*       */         private final AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher resubmissionOnErrorMatcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher resubmissionImmediateMatcher;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected WithResubmission(AgentBuilder.RedefinitionStrategy.ResubmissionScheduler resubmissionScheduler, AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher resubmissionOnErrorMatcher, AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher resubmissionImmediateMatcher) {
/* 13966 */           this.resubmissionScheduler = resubmissionScheduler;
/* 13967 */           this.resubmissionOnErrorMatcher = resubmissionOnErrorMatcher;
/* 13968 */           this.resubmissionImmediateMatcher = resubmissionImmediateMatcher;
/*       */         }
/*       */ 
/*       */         
/*       */         protected AgentBuilder materialize() {
/* 13973 */           return new AgentBuilder.Default(AgentBuilder.Default.Redefining.this.byteBuddy, AgentBuilder.Default.Redefining.this.listener, AgentBuilder.Default.Redefining.this.circularityLock, AgentBuilder.Default.Redefining.this.poolStrategy, AgentBuilder.Default.Redefining.this.typeStrategy, AgentBuilder.Default.Redefining.this.locationStrategy, AgentBuilder.Default.Redefining.this.classFileLocator, AgentBuilder.Default.Redefining.this.nativeMethodStrategy, AgentBuilder.Default.Redefining.this.warmupStrategy, AgentBuilder.Default.Redefining.this.transformerDecorator, AgentBuilder.Default.Redefining.this.initializationStrategy, AgentBuilder.Default.Redefining.this.redefinitionStrategy, AgentBuilder.Default.Redefining.this.redefinitionDiscoveryStrategy, AgentBuilder.Default.Redefining.this.redefinitionBatchAllocator, AgentBuilder.Default.Redefining.this.redefinitionListener, new AgentBuilder.RedefinitionStrategy.ResubmissionStrategy.Enabled(this.resubmissionScheduler, this.resubmissionOnErrorMatcher, this.resubmissionImmediateMatcher), AgentBuilder.Default.Redefining.this.injectionStrategy, AgentBuilder.Default.Redefining.this.lambdaInstrumentationStrategy, AgentBuilder.Default.Redefining.this.descriptionStrategy, AgentBuilder.Default.Redefining.this.fallbackStrategy, AgentBuilder.Default.Redefining.this.classFileBufferStrategy, AgentBuilder.Default.Redefining.this.installationListener, AgentBuilder.Default.Redefining.this.ignoreMatcher, AgentBuilder.Default.Redefining.this.transformations);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError() {
/* 14003 */           return resubmitOnError((ElementMatcher<? super Throwable>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> exceptionMatcher) {
/* 14010 */           return resubmitOnError(exceptionMatcher, (ElementMatcher<String>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> exceptionMatcher, ElementMatcher<String> typeNameMatcher) {
/* 14018 */           return resubmitOnError(exceptionMatcher, typeNameMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> exceptionMatcher, ElementMatcher<String> typeNameMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 14027 */           return resubmitOnError(exceptionMatcher, typeNameMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(ElementMatcher<? super Throwable> exceptionMatcher, ElementMatcher<String> typeNameMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 14037 */           return resubmitOnError(new AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher.ForElementMatchers(exceptionMatcher, typeNameMatcher, classLoaderMatcher, moduleMatcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitOnError(AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher matcher) {
/* 14044 */           return new WithResubmission(this.resubmissionScheduler, new AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher.Disjunction(new AgentBuilder.RedefinitionListenable.ResubmissionOnErrorMatcher[] { this.resubmissionOnErrorMatcher, matcher }, ), this.resubmissionImmediateMatcher);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate() {
/* 14053 */           return resubmitImmediate((ElementMatcher<String>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(ElementMatcher<String> typeNameMatcher) {
/* 14060 */           return resubmitImmediate(typeNameMatcher, (ElementMatcher<? super ClassLoader>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(ElementMatcher<String> typeNameMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher) {
/* 14068 */           return resubmitImmediate(typeNameMatcher, classLoaderMatcher, (ElementMatcher<? super JavaModule>)ElementMatchers.any());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(ElementMatcher<String> typeNameMatcher, ElementMatcher<? super ClassLoader> classLoaderMatcher, ElementMatcher<? super JavaModule> moduleMatcher) {
/* 14077 */           return resubmitImmediate(new AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher.ForElementMatchers(typeNameMatcher, classLoaderMatcher, moduleMatcher));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public AgentBuilder.RedefinitionListenable.WithResubmissionSpecification resubmitImmediate(AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher matcher) {
/* 14084 */           return new WithResubmission(this.resubmissionScheduler, this.resubmissionOnErrorMatcher, new AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher.Disjunction(new AgentBuilder.RedefinitionListenable.ResubmissionImmediateMatcher[] { this.resubmissionImmediateMatcher, matcher }));
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */     @Proxied("java.lang.instrument.Instrumentation")
/*       */     protected static interface Dispatcher {
/*       */       @Defaults
/*       */       @Proxied("isNativeMethodPrefixSupported")
/*       */       boolean isNativeMethodPrefixSupported(Instrumentation param2Instrumentation);
/*       */       
/*       */       @Proxied("setNativeMethodPrefix")
/*       */       void setNativeMethodPrefix(Instrumentation param2Instrumentation, ClassFileTransformer param2ClassFileTransformer, String param2String);
/*       */       
/*       */       @Proxied("addTransformer")
/*       */       void addTransformer(Instrumentation param2Instrumentation, ClassFileTransformer param2ClassFileTransformer, boolean param2Boolean);
/*       */     }
/*       */   }
/*       */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\agent\builder\AgentBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */