package net.bytebuddy.agent.builder;

import net.bytebuddy.utility.nullability.NeverNull.ByDefault;

@ByDefault
interface package-info {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\agent\builder\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */