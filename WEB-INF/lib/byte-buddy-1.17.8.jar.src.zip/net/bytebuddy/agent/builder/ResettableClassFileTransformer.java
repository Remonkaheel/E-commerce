/*     */ package net.bytebuddy.agent.builder;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.IllegalClassFormatException;
/*     */ import java.lang.instrument.Instrumentation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Iterator;
/*     */ import net.bytebuddy.ByteBuddy;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*     */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.MethodCall;
/*     */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.JavaModule;
/*     */ import net.bytebuddy.utility.JavaType;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ResettableClassFileTransformer
/*     */   extends ClassFileTransformer
/*     */ {
/*     */   Iterator<AgentBuilder.Transformer> iterator(TypeDescription paramTypeDescription, @MaybeNull ClassLoader paramClassLoader, @MaybeNull JavaModule paramJavaModule, @MaybeNull Class<?> paramClass, @MaybeNull ProtectionDomain paramProtectionDomain);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.Listener paramListener);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener paramListener);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener paramListener);
/*     */   
/*     */   boolean reset(Instrumentation paramInstrumentation, ResettableClassFileTransformer paramResettableClassFileTransformer, AgentBuilder.RedefinitionStrategy paramRedefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy paramDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator paramBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener paramListener);
/*     */   
/*     */   public static interface Substitutable
/*     */     extends ResettableClassFileTransformer
/*     */   {
/*     */     void substitute(ResettableClassFileTransformer param1ResettableClassFileTransformer);
/*     */     
/*     */     ResettableClassFileTransformer unwrap();
/*     */   }
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     implements ResettableClassFileTransformer
/*     */   {
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy) {
/* 320 */       return reset(instrumentation, redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator.ForTotal.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator) {
/* 329 */       return reset(instrumentation, redefinitionStrategy, redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy) {
/* 338 */       return reset(instrumentation, redefinitionStrategy, redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.Listener.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy) {
/* 348 */       return reset(instrumentation, redefinitionStrategy, redefinitionDiscoveryStrategy, redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 358 */       return reset(instrumentation, redefinitionStrategy, redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator.ForTotal.INSTANCE, redefinitionListener);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 368 */       return reset(instrumentation, redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.SinglePass.INSTANCE, redefinitionBatchAllocator, redefinitionListener);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 379 */       return reset(instrumentation, this, redefinitionStrategy, redefinitionDiscoveryStrategy, redefinitionBatchAllocator, redefinitionListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static abstract class WithDelegation
/*     */     extends AbstractBase
/*     */   {
/*     */     protected final ResettableClassFileTransformer classFileTransformer;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final boolean ACCESS_CONTROLLER;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected WithDelegation(ResettableClassFileTransformer classFileTransformer) {
/* 401 */       this.classFileTransformer = classFileTransformer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 413 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ResettableClassFileTransformer of(ResettableClassFileTransformer classFileTransformer, Callback<?> callback) {
/* 426 */       return WithCallback.DISPATCHER.make(classFileTransformer, callback);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<AgentBuilder.Transformer> iterator(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/* 437 */       return this.classFileTransformer.iterator(typeDescription, classLoader, module, classBeingRedefined, protectionDomain);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean reset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 449 */       return this.classFileTransformer.reset(instrumentation, classFileTransformer, redefinitionStrategy, redefinitionDiscoveryStrategy, redefinitionBatchAllocator, redefinitionListener);
/*     */     } public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classFileTransformer.equals(((WithDelegation)param1Object).classFileTransformer))));
/*     */     } public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.classFileTransformer.hashCode();
/*     */     }
/*     */     static {
/*     */       try {
/*     */         Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*     */         ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*     */       } catch (ClassNotFoundException classNotFoundException) {
/*     */         ACCESS_CONTROLLER = false;
/*     */       } catch (SecurityException securityException) {
/*     */         ACCESS_CONTROLLER = true;
/*     */       } 
/*     */     }
/*     */     @Enhance
/* 466 */     protected static class Substitutable extends ResettableClassFileTransformer.AbstractBase implements ResettableClassFileTransformer.Substitutable { private static final Factory DISPATCHER = (Factory)ResettableClassFileTransformer.WithDelegation.doPrivileged(Factory.CreationAction.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected volatile ResettableClassFileTransformer classFileTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Substitutable(ResettableClassFileTransformer classFileTransformer) {
/* 479 */         this.classFileTransformer = classFileTransformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static ResettableClassFileTransformer.Substitutable of(ResettableClassFileTransformer classFileTransformer) {
/* 489 */         return DISPATCHER.make(classFileTransformer);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void substitute(ResettableClassFileTransformer classFileTransformer) {
/* 496 */         while (classFileTransformer instanceof ResettableClassFileTransformer.Substitutable) {
/* 497 */           classFileTransformer = ((ResettableClassFileTransformer.Substitutable)classFileTransformer).unwrap();
/*     */         }
/* 499 */         this.classFileTransformer = classFileTransformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ResettableClassFileTransformer unwrap() {
/* 506 */         return this.classFileTransformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Iterator<AgentBuilder.Transformer> iterator(TypeDescription typeDescription, @MaybeNull ClassLoader classLoader, @MaybeNull JavaModule module, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain) {
/* 517 */         return this.classFileTransformer.iterator(typeDescription, classLoader, module, classBeingRedefined, protectionDomain);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean reset(Instrumentation instrumentation, ResettableClassFileTransformer classFileTransformer, AgentBuilder.RedefinitionStrategy redefinitionStrategy, AgentBuilder.RedefinitionStrategy.DiscoveryStrategy redefinitionDiscoveryStrategy, AgentBuilder.RedefinitionStrategy.BatchAllocator redefinitionBatchAllocator, AgentBuilder.RedefinitionStrategy.Listener redefinitionListener) {
/* 529 */         return this.classFileTransformer.reset(instrumentation, classFileTransformer, redefinitionStrategy, redefinitionDiscoveryStrategy, redefinitionBatchAllocator, redefinitionListener);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public byte[] transform(@MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) throws IllegalClassFormatException {
/* 545 */         return this.classFileTransformer.transform(classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.classFileTransformer.equals(((Substitutable)param2Object).classFileTransformer))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.classFileTransformer.hashCode();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public enum CreationAction
/*     */         implements PrivilegedAction<Factory>
/*     */       {
/* 569 */         INSTANCE;
/*     */ 
/*     */ 
/*     */         
/*     */         @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*     */         public ResettableClassFileTransformer.WithDelegation.Substitutable.Factory run()
/*     */         {
/*     */           
/* 577 */           try { return new ResettableClassFileTransformer.WithDelegation.Substitutable.Factory.ForJava9CapableVm((new ByteBuddy())
/* 578 */                 .with(TypeValidation.DISABLED)
/* 579 */                 .subclass(ResettableClassFileTransformer.WithDelegation.Substitutable.class, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING)
/* 580 */                 .name(ResettableClassFileTransformer.WithDelegation.Substitutable.class.getName() + "$ByteBuddy$ModuleSupport")
/* 581 */                 .method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArgument(0, JavaType.MODULE.load())))
/* 582 */                 .intercept((Implementation)MethodCall.invoke(ClassFileTransformer.class.getMethod("transform", new Class[] {
/* 583 */                         JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 588 */                       })).onField("classFileTransformer").withAllArguments())
/* 589 */                 .make()
/* 590 */                 .load(ResettableClassFileTransformer.WithDelegation.Substitutable.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT
/* 591 */                   .with(ResettableClassFileTransformer.WithDelegation.Substitutable.class.getProtectionDomain()))
/* 592 */                 .getLoaded()
/* 593 */                 .getConstructor(new Class[] { ResettableClassFileTransformer.class })); }
/* 594 */           catch (Exception ignored)
/* 595 */           { return ResettableClassFileTransformer.WithDelegation.Substitutable.Factory.ForLegacyVm.INSTANCE; }  } } static interface Factory { ResettableClassFileTransformer.Substitutable make(ResettableClassFileTransformer param3ResettableClassFileTransformer); public enum CreationAction implements PrivilegedAction<Factory> { INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public ResettableClassFileTransformer.WithDelegation.Substitutable.Factory run() { try { return new ResettableClassFileTransformer.WithDelegation.Substitutable.Factory.ForJava9CapableVm((new ByteBuddy()).with(TypeValidation.DISABLED).subclass(ResettableClassFileTransformer.WithDelegation.Substitutable.class, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING).name(ResettableClassFileTransformer.WithDelegation.Substitutable.class.getName() + "$ByteBuddy$ModuleSupport").method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArgument(0, JavaType.MODULE.load()))).intercept((Implementation)MethodCall.invoke(ClassFileTransformer.class.getMethod("transform", new Class[] { JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).onField("classFileTransformer").withAllArguments()).make().load(ResettableClassFileTransformer.WithDelegation.Substitutable.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT.with(ResettableClassFileTransformer.WithDelegation.Substitutable.class.getProtectionDomain())).getLoaded().getConstructor(new Class[] { ResettableClassFileTransformer.class })); } catch (Exception ignored) { return ResettableClassFileTransformer.WithDelegation.Substitutable.Factory.ForLegacyVm.INSTANCE; }
/*     */              }
/*     */            }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @Enhance
/*     */         public static class ForJava9CapableVm
/*     */           implements Factory
/*     */         {
/*     */           private final Constructor<? extends ResettableClassFileTransformer.Substitutable> substitutable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           protected ForJava9CapableVm(Constructor<? extends ResettableClassFileTransformer.Substitutable> substitutable) {
/* 617 */             this.substitutable = substitutable;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public ResettableClassFileTransformer.Substitutable make(ResettableClassFileTransformer classFileTransformer) {
/*     */             try {
/* 625 */               return this.substitutable.newInstance(new Object[] { classFileTransformer });
/* 626 */             } catch (IllegalAccessException exception) {
/* 627 */               throw new IllegalStateException("Cannot access " + this.substitutable, exception);
/* 628 */             } catch (InstantiationException exception) {
/* 629 */               throw new IllegalStateException("Cannot instantiate " + this.substitutable.getDeclaringClass(), exception);
/* 630 */             } catch (InvocationTargetException exception) {
/* 631 */               throw new IllegalStateException("Cannot invoke " + this.substitutable, exception.getTargetException());
/*     */             } 
/*     */           }
/*     */           
/*     */           public boolean equals(@MaybeNull Object param4Object) {
/*     */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.substitutable.equals(((ForJava9CapableVm)param4Object).substitutable))));
/*     */           }
/*     */           
/*     */           public int hashCode() {
/*     */             return getClass().hashCode() * 31 + this.substitutable.hashCode();
/*     */           } }
/*     */         
/*     */         public enum ForLegacyVm implements Factory {
/* 644 */           INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public ResettableClassFileTransformer.Substitutable make(ResettableClassFileTransformer classFileTransformer) {
/* 650 */             return new ResettableClassFileTransformer.WithDelegation.Substitutable(classFileTransformer);
/*     */           }
/*     */         } }
/*     */        }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class WithCallback<T>
/*     */       extends WithDelegation
/*     */     {
/* 667 */       private static final Factory DISPATCHER = (Factory)ResettableClassFileTransformer.WithDelegation.doPrivileged(Factory.CreationAction.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final ResettableClassFileTransformer.WithDelegation.Callback<T> callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected WithCallback(ResettableClassFileTransformer classFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<T> callback) {
/* 681 */         super(classFileTransformer);
/* 682 */         this.callback = callback;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public byte[] transform(@MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) throws IllegalClassFormatException {
/* 694 */         T value = this.callback.onBeforeTransform(null, classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */         try {
/* 696 */           return this.classFileTransformer.transform(classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */         } finally {
/* 698 */           this.callback.onAfterTransform(value, null, classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       protected byte[] transform(Object rawModule, @MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) throws IllegalClassFormatException {
/* 721 */         JavaModule module = JavaModule.of(rawModule);
/* 722 */         T value = this.callback.onBeforeTransform(module, classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */         try {
/* 724 */           return doTransform(rawModule, classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */         } finally {
/* 726 */           this.callback.onAfterTransform(value, module, classLoader, internalName, classBeingRedefined, protectionDomain, binaryRepresentation);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       protected byte[] doTransform(Object rawModule, @MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) throws IllegalClassFormatException {
/* 749 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.callback.equals(((WithCallback)param2Object).callback)))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return super.hashCode() * 31 + this.callback.hashCode();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public enum CreationAction
/*     */         implements PrivilegedAction<Factory>
/*     */       {
/* 774 */         INSTANCE;
/*     */ 
/*     */ 
/*     */         
/*     */         @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*     */         public ResettableClassFileTransformer.WithDelegation.WithCallback.Factory run()
/*     */         {
/*     */           
/* 782 */           try { return new ResettableClassFileTransformer.WithDelegation.WithCallback.Factory.ForJava9CapableVm((new ByteBuddy())
/* 783 */                 .with(TypeValidation.DISABLED)
/* 784 */                 .subclass(ResettableClassFileTransformer.WithDelegation.WithCallback.class, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING)
/* 785 */                 .name(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getName() + "$ByteBuddy$ModuleSupport")
/* 786 */                 .method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 792 */                       }))).intercept((Implementation)MethodCall.invoke(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getDeclaredMethod("transform", new Class[] {
/*     */                         
/*     */                         Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class
/*     */ 
/*     */ 
/*     */                       
/* 798 */                       })).withAllArguments())
/* 799 */                 .method((ElementMatcher)ElementMatchers.named("doTransform").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 805 */                       }))).intercept((Implementation)MethodCall.invoke(ClassFileTransformer.class.getMethod("transform", new Class[] {
/* 806 */                         JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 811 */                       })).onField("classFileTransformer").withAllArguments().withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC))
/* 812 */                 .make()
/* 813 */                 .load(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT
/* 814 */                   .with(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getProtectionDomain()))
/* 815 */                 .getLoaded()
/* 816 */                 .getConstructor(new Class[] { ResettableClassFileTransformer.class, ResettableClassFileTransformer.WithDelegation.Callback.class })); }
/* 817 */           catch (Exception ignored)
/* 818 */           { return ResettableClassFileTransformer.WithDelegation.WithCallback.Factory.ForLegacyVm.INSTANCE; }  } } static interface Factory { ResettableClassFileTransformer make(ResettableClassFileTransformer param3ResettableClassFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<?> param3Callback); public enum CreationAction implements PrivilegedAction<Factory> { INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public ResettableClassFileTransformer.WithDelegation.WithCallback.Factory run() { try { return new ResettableClassFileTransformer.WithDelegation.WithCallback.Factory.ForJava9CapableVm((new ByteBuddy()).with(TypeValidation.DISABLED).subclass(ResettableClassFileTransformer.WithDelegation.WithCallback.class, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING).name(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getName() + "$ByteBuddy$ModuleSupport").method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class }))).intercept((Implementation)MethodCall.invoke(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getDeclaredMethod("transform", new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).withAllArguments()).method((ElementMatcher)ElementMatchers.named("doTransform").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class }))).intercept((Implementation)MethodCall.invoke(ClassFileTransformer.class.getMethod("transform", new Class[] { JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).onField("classFileTransformer").withAllArguments().withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC)).make().load(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT.with(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getProtectionDomain())).getLoaded().getConstructor(new Class[] { ResettableClassFileTransformer.class, ResettableClassFileTransformer.WithDelegation.Callback.class })); } catch (Exception ignored) { return ResettableClassFileTransformer.WithDelegation.WithCallback.Factory.ForLegacyVm.INSTANCE; }
/*     */              }
/*     */            }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @Enhance
/*     */         public static class ForJava9CapableVm
/*     */           implements Factory
/*     */         {
/*     */           private final Constructor<? extends ResettableClassFileTransformer> withCallback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           protected ForJava9CapableVm(Constructor<? extends ResettableClassFileTransformer> withCallback) {
/* 840 */             this.withCallback = withCallback;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public ResettableClassFileTransformer make(ResettableClassFileTransformer classFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<?> callback) {
/*     */             try {
/* 848 */               return this.withCallback.newInstance(new Object[] { classFileTransformer, callback });
/* 849 */             } catch (IllegalAccessException exception) {
/* 850 */               throw new IllegalStateException("Cannot access " + this.withCallback, exception);
/* 851 */             } catch (InstantiationException exception) {
/* 852 */               throw new IllegalStateException("Cannot instantiate " + this.withCallback.getDeclaringClass(), exception);
/* 853 */             } catch (InvocationTargetException exception) {
/* 854 */               throw new IllegalStateException("Cannot invoke " + this.withCallback, exception.getTargetException());
/*     */             } 
/*     */           }
/*     */           
/*     */           public boolean equals(@MaybeNull Object param4Object) {
/*     */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.withCallback.equals(((ForJava9CapableVm)param4Object).withCallback))));
/*     */           }
/*     */           
/*     */           public int hashCode() {
/*     */             return getClass().hashCode() * 31 + this.withCallback.hashCode();
/*     */           }
/*     */         }
/*     */         
/* 867 */         public enum ForLegacyVm implements Factory { INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public ResettableClassFileTransformer make(ResettableClassFileTransformer classFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<?> callback)
/*     */           {
/* 875 */             return new ResettableClassFileTransformer.WithDelegation.WithCallback(classFileTransformer, callback); } } } } static interface Factory { ResettableClassFileTransformer make(ResettableClassFileTransformer param2ResettableClassFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<?> param2Callback); public enum CreationAction implements PrivilegedAction<Factory> { INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public ResettableClassFileTransformer.WithDelegation.WithCallback.Factory run() { try { return new ResettableClassFileTransformer.WithDelegation.WithCallback.Factory.ForJava9CapableVm((new ByteBuddy()).with(TypeValidation.DISABLED).subclass(ResettableClassFileTransformer.WithDelegation.WithCallback.class, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING).name(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getName() + "$ByteBuddy$ModuleSupport").method((ElementMatcher)ElementMatchers.named("transform").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class }))).intercept((Implementation)MethodCall.invoke(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getDeclaredMethod("transform", new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).withAllArguments()).method((ElementMatcher)ElementMatchers.named("doTransform").and((ElementMatcher)ElementMatchers.takesArguments(new Class[] { Object.class, ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class }))).intercept((Implementation)MethodCall.invoke(ClassFileTransformer.class.getMethod("transform", new Class[] { JavaType.MODULE.load(), ClassLoader.class, String.class, Class.class, ProtectionDomain.class, byte[].class })).onField("classFileTransformer").withAllArguments().withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC)).make().load(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getClassLoader(), (ClassLoadingStrategy)ClassLoadingStrategy.Default.WRAPPER_PERSISTENT.with(ResettableClassFileTransformer.WithDelegation.WithCallback.class.getProtectionDomain())).getLoaded().getConstructor(new Class[] { ResettableClassFileTransformer.class, ResettableClassFileTransformer.WithDelegation.Callback.class })); } catch (Exception ignored) { return ResettableClassFileTransformer.WithDelegation.WithCallback.Factory.ForLegacyVm.INSTANCE; }  } } @Enhance public static class ForJava9CapableVm implements Factory { private final Constructor<? extends ResettableClassFileTransformer> withCallback; protected ForJava9CapableVm(Constructor<? extends ResettableClassFileTransformer> withCallback) { this.withCallback = withCallback; } public ResettableClassFileTransformer make(ResettableClassFileTransformer classFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<?> callback) { try { return this.withCallback.newInstance(new Object[] { classFileTransformer, callback }); } catch (IllegalAccessException exception) { throw new IllegalStateException("Cannot access " + this.withCallback, exception); } catch (InstantiationException exception) { throw new IllegalStateException("Cannot instantiate " + this.withCallback.getDeclaringClass(), exception); } catch (InvocationTargetException exception) { throw new IllegalStateException("Cannot invoke " + this.withCallback, exception.getTargetException()); }  } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.withCallback.equals(((ForJava9CapableVm)param4Object).withCallback)))); } public int hashCode() { return getClass().hashCode() * 31 + this.withCallback.hashCode(); } } public enum ForLegacyVm implements Factory { public ResettableClassFileTransformer make(ResettableClassFileTransformer classFileTransformer, ResettableClassFileTransformer.WithDelegation.Callback<?> callback) { return new ResettableClassFileTransformer.WithDelegation.WithCallback(classFileTransformer, callback); }
/*     */ 
/*     */         
/*     */         INSTANCE; }
/*     */        }
/*     */ 
/*     */     
/*     */     public static interface Callback<T> {
/*     */       @MaybeNull
/*     */       T onBeforeTransform(@MaybeNull JavaModule param2JavaModule, @MaybeNull ClassLoader param2ClassLoader, @MaybeNull String param2String, @MaybeNull Class<?> param2Class, @MaybeNull ProtectionDomain param2ProtectionDomain, byte[] param2ArrayOfbyte) throws IllegalClassFormatException;
/*     */       
/*     */       void onAfterTransform(@MaybeNull T param2T, @MaybeNull JavaModule param2JavaModule, @MaybeNull ClassLoader param2ClassLoader, @MaybeNull String param2String, @MaybeNull Class<?> param2Class, @MaybeNull ProtectionDomain param2ProtectionDomain, byte[] param2ArrayOfbyte) throws IllegalClassFormatException;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\agent\builder\ResettableClassFileTransformer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */